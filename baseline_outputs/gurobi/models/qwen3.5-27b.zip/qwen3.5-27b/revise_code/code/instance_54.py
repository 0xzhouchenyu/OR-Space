import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Get script directory
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load general parameters
def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            value = float(row['Value'])
            params[param_name] = value
    return params

# Load table 1 data
def load_table_1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    equipment_names = []
    products = []
    processing_times = {}
    effective_hours = {}
    base_profit = {}
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: Equipment_Code, I, II, III, Effective_Monthly_Equipment_Hours
        products = header[1:-1]  # ['I', 'II', 'III']
        
        for row in reader:
            if row[0].startswith('Unit_Product_Profit'):
                # This is the profit row
                for j, prod in enumerate(products):
                    base_profit[prod] = float(row[j + 1])
            else:
                equip = row[0]
                equipment_names.append(equip)
                effective_hours[equip] = float(row[-1])
                for j, prod in enumerate(products):
                    processing_times[(equip, prod)] = float(row[j + 1])
    
    return products, equipment_names, processing_times, effective_hours, base_profit

# Load data
params = load_general_parameters(data_dir)
products, equipment_names, processing_times, effective_hours, base_profit = load_table_1(data_dir)

# Extract parameters
overtime_hours_cap = params['overtime_hours_cap']
overtime_cost_multiplier = params['overtime_cost_multiplier']
min_prod = {
    'I': params['min_prod_I'],
    'II': params['min_prod_II'],
    'III': params['min_prod_III']
}

# Create Gurobi model
model = gp.Model("Factory_Production_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
x_reg = {}
x_ot = {}
for p in products:
    x_reg[p] = model.addVar(lb=0, name=f"x_reg_{p}")
    x_ot[p] = model.addVar(lb=0, name=f"x_ot_{p}")

# Calculate costs
regular_cost = {p: base_profit[p] for p in products}
overtime_cost = {p: overtime_cost_multiplier * base_profit[p] for p in products}

# Objective: minimize total cost
model.setObjective(
    gp.quicksum(regular_cost[p] * x_reg[p] + overtime_cost[p] * x_ot[p] for p in products),
    GRB.MINIMIZE
)

# Constraint 1: Equipment capacity (both regular and overtime use same capacity)
for equip in equipment_names:
    model.addConstr(
        gp.quicksum(processing_times[(equip, p)] * (x_reg[p] + x_ot[p]) for p in products)
        <= effective_hours[equip],
        f"Equipment_{equip}_capacity"
    )

# Constraint 2: Overtime hours cap (total overtime processing hours across all equipment)
model.addConstr(
    gp.quicksum(processing_times[(equip, p)] * x_ot[p] for equip in equipment_names for p in products)
    <= overtime_hours_cap,
    "Overtime_hours_cap"
)

# Constraint 3: Minimum production for each product
for p in products:
    model.addConstr(
        x_reg[p] + x_ot[p] >= min_prod[p],
        f"Min_production_{p}"
    )

# Optimize
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal:.6f}")
else:
    print(f"FINAL_OBJ_VALUE: {model.objVal:.6f}")
