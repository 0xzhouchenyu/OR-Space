import os
import sys
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_data():
    # Determine script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load general parameters
    params_path = os.path.join(script_dir, 'data', 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['parameter']
            val = row['value']
            # Try to convert to float/int
            try:
                if '.' in val:
                    params[key] = float(val)
                else:
                    params[key] = int(val)
            except ValueError:
                params[key] = val
                
    # Load table 1
    table_path = os.path.join(script_dir, 'data', 'table_1.csv')
    batches = []
    processing_times_raw = []
    
    with open(table_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        num_vats = len(header) - 1
        
        for row in reader:
            batch_id = int(row[0])
            times = []
            for j in range(num_vats):
                t = float(row[j+1])
                times.append(math.ceil(t)) # Round up to next full time unit
            batches.append(batch_id)
            processing_times_raw.append(times)
            
    return params, batches, processing_times_raw, num_vats

def solve():
    params, batches, processing_times_raw, num_vats = load_data()
    
    T_horizon = int(params['planning_horizon_T'])
    energy_costs = {
        1: float(params['energy_cost_v1']),
        2: float(params['energy_cost_v2']),
        3: float(params['energy_cost_v3'])
    }
    peak_mult = float(params['peak_energy_multiplier'])
    peak_cap = float(params['peak_energy_cap'])
    makespan_w = float(params['makespan_weight'])
    energy_w = float(params['energy_weight'])
    
    n_batches = len(batches)
    batch_indices = list(range(n_batches))
    vat_indices = [1, 2, 3]
    time_periods = list(range(1, T_horizon + 1))
    
    # Precompute valid start times and energy costs
    # valid_starts[v][j] = list of valid t
    # job_energy[j][v][t] = total energy cost for job j on vat v starting at t
    # job_peak_energy[j][v][t] = peak energy cost portion
    
    valid_starts = {v: {j: [] for j in batch_indices} for v in vat_indices}
    job_energy = {j: {v: {} for v in vat_indices} for j in batch_indices}
    job_peak_energy = {j: {v: {} for v in vat_indices} for j in batch_indices}
    
    for j in batch_indices:
        for v in vat_indices:
            p = processing_times_raw[j][v-1]
            # Check maintenance for Vat 2
            # Interval [t, t+p-1] must not intersect {4, 5}
            # Condition: t+p-1 < 4 OR t > 5
            
            for t in time_periods:
                end_t = t + p - 1
                if end_t > T_horizon:
                    continue
                
                # Maintenance check
                if v == 2:
                    # Occupies t, ..., end_t
                    # Forbidden if any period in [t, end_t] is in {4, 5}
                    # Equivalent to: end_t < 4 OR t > 5
                    if not (end_t < 4 or t > 5):
                        continue
                
                valid_starts[v][j].append(t)
                
                # Calculate Energy Costs
                total_e = 0.0
                peak_e = 0.0
                for tau in range(t, end_t + 1):
                    rate = energy_costs[v]
                    if tau in [6, 7, 8]:
                        rate *= peak_mult
                        peak_e += rate
                    else:
                        pass # Not peak
                    
                    total_e += rate
                
                job_energy[j][v][t] = total_e
                job_peak_energy[j][v][t] = peak_e

    # Create Model
    model = gp.Model("Dyeing_Schedule")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    # x[j, v, t] = 1 if batch j starts on vat v at time t
    x = {}
    for j in batch_indices:
        for v in vat_indices:
            for t in valid_starts[v][j]:
                x[(j, v, t)] = model.addVar(vtype=GRB.BINARY, name=f"x_{j}_{v}_{t}")
    
    # Makespan Variable
    makespan = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="makespan")
    
    # Constraints
    
    # 1. Each batch processed exactly once on each vat
    for j in batch_indices:
        for v in vat_indices:
            model.addConstr(gp.quicksum(x[(j, v, t)] for t in valid_starts[v][j]) == 1)
            
    # 2. Precedence (Flow Shop)
    # Start[j, v+1] >= Start[j, v] + P[j, v] - 1
    for j in batch_indices:
        for v in range(1, num_vats):
            # Current vat v, Next vat v+1
            # Start time expressions
            start_curr = gp.quicksum(t * x[(j, v, t)] for t in valid_starts[v][j])
            start_next = gp.quicksum(t * x[(j, v+1, t)] for t in valid_starts[v+1][j])
            p_curr = processing_times_raw[j][v-1]
            
            model.addConstr(start_next >= start_curr + p_curr - 1)
            
    # 3. Capacity (No overlap on vats)
    # For each vat v, time t: sum of active jobs <= 1
    # Job j is active on v at t if it started at k such that k <= t < k + P
    for v in vat_indices:
        for t in time_periods:
            active_jobs = []
            for j in batch_indices:
                p = processing_times_raw[j][v-1]
                # Find start times k that cover t
                # k <= t < k + p  =>  k <= t  AND  k > t - p
                # k in [t - p + 1, t]
                min_k = max(1, t - p + 1)
                max_k = t
                
                for k in range(min_k, max_k + 1):
                    if (j, v, k) in x:
                        active_jobs.append(x[(j, v, k)])
            
            if active_jobs:
                model.addConstr(gp.quicksum(active_jobs) <= 1)
                
    # 4. Peak Energy Cap
    # Sum of peak energy contributions <= Cap
    peak_usage_expr = gp.quicksum(
        x[(j, v, t)] * job_peak_energy[j][v][t] 
        for j in batch_indices 
        for v in vat_indices 
        for t in valid_starts[v][j]
    )
    model.addConstr(peak_usage_expr <= peak_cap)
    
    # 5. Makespan Definition
    # Makespan >= Completion of last batch on Vat 3
    # Completion = Start + P - 1
    for j in batch_indices:
        start_v3 = gp.quicksum(t * x[(j, 3, t)] for t in valid_starts[3][j])
        p_v3 = processing_times_raw[j][2]
        model.addConstr(makespan >= start_v3 + p_v3 - 1)
        
    # Objective
    # Minimize makespan_weight * makespan + energy_weight * total_energy
    total_energy_expr = gp.quicksum(
        x[(j, v, t)] * job_energy[j][v][t] 
        for j in batch_indices 
        for v in vat_indices 
        for t in valid_starts[v][j]
    )
    
    model.setObjective(makespan_w * makespan + energy_w * total_energy_expr, GRB.MINIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == '__main__':
    solve()
