import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine base directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load processing costs
    cost = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p) for p in header[1:]]
        for row in reader:
            machine = row[0].strip()
            for j, p in enumerate(parts):
                cost[(machine, p)] = float(row[j + 1])

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            val_str = row['Value'].strip()
            try:
                params[key] = int(val_str)
            except ValueError:
                params[key] = float(val_str)

    d = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    max_C = params['max_parts_on_C']
    overtime_threshold = params['overtime_threshold']
    overtime_penalty = params['overtime_penalty']

    machines = ['A', 'B', 'C']

    # Create model
    model = gp.Model("MachineAssignment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[m][p] = 1 if part p is assigned to machine m
    x = model.addVars(machines, parts, vtype=GRB.BINARY, name="x")

    # y[m] = 1 if machine m is used (setup cost incurred)
    y = model.addVars(machines, vtype=GRB.BINARY, name="y")

    # z[m] = 1 if machine m incurs overtime penalty
    z = model.addVars(machines, vtype=GRB.BINARY, name="z")

    # Objective: minimize processing costs + setup costs + overtime penalties
    obj = gp.quicksum(cost[(m, p)] * x[m, p] for m in machines for p in parts)
    obj += gp.quicksum(d[m] * y[m] for m in machines)
    obj += gp.quicksum(overtime_penalty * z[m] for m in machines)
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraint 1: Each part assigned to exactly one machine
    for p in parts:
        model.addConstr(gp.quicksum(x[m, p] for m in machines) == 1)

    # Linking y to x: if any part on machine m, y[m] = 1
    # Since we minimize cost, y[m] will be 0 if no parts assigned.
    # We just need to force y[m]=1 if sum(x) >= 1.
    # sum(x) <= 10 * y[m]
    for m in machines:
        model.addConstr(gp.quicksum(x[m, p] for p in parts) <= len(parts) * y[m])

    # Constraint 2: Parts 1 and 2 logic
    # Exactly one of Part 1 or Part 2 is on Machine A
    model.addConstr(x['A', 1] + x['A', 2] == 1)

    # Constraint 3: Fixed assignments
    model.addConstr(x['A', 3] == 1)
    model.addConstr(x['B', 4] == 1)
    model.addConstr(x['C', 5] == 1)

    # Constraint 4: At most 3 parts on machine C
    model.addConstr(gp.quicksum(x['C', p] for p in parts) <= max_C)

    # Constraint 5: Overtime penalty logic
    # If sum(x[m, p]) > overtime_threshold, then z[m] = 1
    # Let N_m = sum(x[m, p])
    # N_m <= threshold + (10 - threshold) * z[m]  => if z=0, N_m <= threshold
    # N_m >= (threshold + 1) * z[m]               => if z=1, N_m >= threshold + 1
    
    # Max parts is 10.
    M = len(parts) 
    
    for m in machines:
        N_m = gp.quicksum(x[m, p] for p in parts)
        # If z[m] == 0, N_m <= threshold
        model.addConstr(N_m <= overtime_threshold + M * z[m])
        # If z[m] == 1, N_m >= threshold + 1
        model.addConstr(N_m >= (overtime_threshold + 1) * z[m])

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()
