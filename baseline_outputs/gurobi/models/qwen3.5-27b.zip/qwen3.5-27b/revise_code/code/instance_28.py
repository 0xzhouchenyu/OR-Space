import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

initial_fund = params['initial_fund']  # 300000
annual_rate = params['annual_profit_rate'] / 100  # 0.20
inv_limit_y1 = params['investment_limit_year1']  # 150000
return_rate_y1y2 = params['return_rate_year1_to_year2'] / 100  # 1.50
inv_limit_y2 = params['investment_limit_year2']  # 200000
return_rate_y2y3 = params['return_rate_year2_to_year3'] / 100  # 1.60
inv_limit_y3 = params['investment_limit_year3']  # 100000
profit_rate_y3 = params['profit_rate_year3'] / 100  # 0.40
fee_year1 = params['fee_year1']  # 10000
fee_year2 = params['fee_year2']  # 12000
fee_year3 = params['fee_year3']  # 5000

# Create model
model = gp.Model("Investment_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
# a1, a2, a3: amount invested in annual 20% investment at beginning of year 1, 2, 3
a1 = model.addVar(lb=0, name="a1")
a2 = model.addVar(lb=0, name="a2")
a3 = model.addVar(lb=0, name="a3")

# b1: 2-year investment at beginning of year 1 (returns end of year 2), max 150000
b1 = model.addVar(lb=0, ub=inv_limit_y1, name="b1")

# c2: 2-year investment at beginning of year 2 (returns end of year 3), max 200000
c2 = model.addVar(lb=0, ub=inv_limit_y2, name="c2")

# d3: special 1-year investment at beginning of year 3, max 100000
d3 = model.addVar(lb=0, ub=inv_limit_y3, name="d3")

# Binary variables for special investment usage
y1 = model.addVar(vtype=GRB.BINARY, name="y1")
y2 = model.addVar(vtype=GRB.BINARY, name="y2")
y3 = model.addVar(vtype=GRB.BINARY, name="y3")

# Link continuous variables to binary variables (big-M constraints)
model.addConstr(b1 <= inv_limit_y1 * y1, "link_b1_y1")
model.addConstr(c2 <= inv_limit_y2 * y2, "link_c2_y2")
model.addConstr(d3 <= inv_limit_y3 * y3, "link_d3_y3")

# Budget constraint at beginning of Year 1:
model.addConstr(a1 + b1 <= initial_fund, "Year1_budget")

# Budget constraint at beginning of Year 2:
# Available: a1*(1+0.20) + leftover from year 1
# Leftover from year 1 = initial_fund - a1 - b1
model.addConstr(a2 + c2 <= (initial_fund - a1 - b1) + a1 * (1 + annual_rate), "Year2_budget")

# Budget constraint at beginning of Year 3:
# Available: cash from year 2 + a2*(1+0.20) + b1*1.50
# Cash from year 2 = (funds available at year 2) - a2 - c2
# funds_year2 = (initial_fund - a1 - b1) + a1*(1+annual_rate)
model.addConstr(a3 + d3 <= (initial_fund - a1 - b1) + a1*(1+annual_rate) - a2 - c2 + a2*(1+annual_rate) + b1*return_rate_y1y2, "Year3_budget")

# Objective: total funds at end of year 3 minus fees
# End of year 3: cash leftover from year 3 + a3*(1+0.20) + c2*1.60 + d3*(1+0.40)
cash_year3 = (initial_fund - a1 - b1) + a1*(1+annual_rate) - a2 - c2 + a2*(1+annual_rate) + b1*return_rate_y1y2 - a3 - d3
total_end = cash_year3 + a3*(1+annual_rate) + c2*return_rate_y2y3 + d3*(1+profit_rate_y3)

# Subtract fees
objective = total_end - fee_year1*y1 - fee_year2*y2 - fee_year3*y3

model.setObjective(objective, GRB.MAXIMIZE)

# Optimize
model.optimize()

obj_val = model.ObjVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
