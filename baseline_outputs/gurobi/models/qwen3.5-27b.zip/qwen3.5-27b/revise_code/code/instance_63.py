import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

produce = params['produce_to_transport']
horse_poll = params['horse_pollution_per_trip']
bike_poll = params['bicycle_pollution_per_trip']
cart_poll = params['handcart_pollution_per_trip']
max_poll = params['max_total_pollution']
min_horse = params['min_horse_trips']
horse_cap = params['horse_capacity_per_trip']
bike_cap = params['bicycle_capacity_per_trip']
cart_cap = params['handcart_capacity_per_trip']
min_produce = params['min_total_produce']
horse_cost = params['horse_cost_per_trip']
bike_cost = params['bicycle_cost_per_trip']
cart_cost = params['handcart_cost_per_trip']
horse_fixed = params['horse_fixed_cost']
bike_fixed = params['bicycle_fixed_cost']
cart_fixed = params['handcart_fixed_cost']
poll_penalty = params['pollution_penalty_per_unit']
permit_threshold = params['horse_pollution_permit_threshold']
permit_fee = params['horse_pollution_permit_fee']

M = 10000

# Create model
model = gp.Model("FarmTransport")
model.setParam('OutputFlag', 0)

# Decision variables
x_horse = model.addVar(vtype=GRB.INTEGER, name="horse_trips", lb=0)
x_bike = model.addVar(vtype=GRB.INTEGER, name="bike_trips", lb=0)
x_cart = model.addVar(vtype=GRB.INTEGER, name="cart_trips", lb=0)

y_bike = model.addVar(vtype=GRB.BINARY, name="choose_bike")
y_cart = model.addVar(vtype=GRB.BINARY, name="choose_cart")

z_permit = model.addVar(vtype=GRB.BINARY, name="permit_fee_triggered")

# Objective: minimize total cost
# Variable trip costs + fixed setup costs + pollution penalty + permit fee
obj = (horse_cost * x_horse + bike_cost * x_bike + cart_cost * x_cart +
       horse_fixed * (x_horse > 0) + bike_fixed * (x_bike > 0) + cart_fixed * (x_cart > 0) +
       poll_penalty * (horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart) +
       permit_fee * z_permit)

model.setObjective(obj, GRB.MINIMIZE)

# Constraints
# 1. Produce requirement
model.addConstr(horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce)

# 2. Pollution limit
model.addConstr(horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart <= max_poll)

# 3. Minimum horse trips
model.addConstr(x_horse >= min_horse)

# 4. Choose exactly one of bike or cart
model.addConstr(y_bike + y_cart == 1)

# 5. Link bike trips to bike choice
model.addConstr(x_bike <= M * y_bike)

# 6. Link cart trips to cart choice
model.addConstr(x_cart <= M * y_cart)

# 7. Permit fee trigger (pollution > 600)
total_poll = horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart
model.addConstr(total_poll - permit_threshold <= M * z_permit)
model.addConstr(total_poll - permit_threshold >= 1 - M * (1 - z_permit))

# Optimize
model.optimize()

# Get results
print(f"Horse trips: {x_horse.X}")
print(f"Bicycle trips: {x_bike.X}")
print(f"Handcart trips: {x_cart.X}")
print(f"Choose bicycle: {y_bike.X}")
print(f"Choose handcart: {y_cart.X}")
print(f"Permit fee triggered: {z_permit.X}")
print(f"Total pollution: {total_poll.X}")
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
