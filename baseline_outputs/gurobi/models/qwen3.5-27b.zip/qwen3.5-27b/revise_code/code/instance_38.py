import os
import sys
from itertools import permutations
import gurobipy as gp
from gurobipy import GRB

def load_processing_times(filepath):
    """Load processing times from CSV file."""
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times

def load_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if len(row) >= 2:
                param_name = row[0]
                value = row[1]
                try:
                    if '.' in value:
                        params[param_name] = float(value)
                    else:
                        params[param_name] = int(value)
                except ValueError:
                    params[param_name] = value
    return params

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    processing_times = load_processing_times(os.path.join(data_dir, 'table_1.csv'))
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    n_products = len(processing_times)
    n_machines = len(processing_times[0])
    
    # Extract parameters
    time_window = {
        1: params['time_window_1'],
        2: params['time_window_2'],
        3: params['time_window_3']
    }
    overtime_window = {
        1: params['overtime_window_1'],
        2: params['overtime_window_2'],
        3: params['overtime_window_3']
    }
    overtime_penalty = params['overtime_penalty_per_unit']
    m1_overtime_threshold = params['machine1_overtime_review_threshold']
    m1_overtime_review_fee = params['machine1_overtime_review_fee']
    
    # Create model
    model = gp.Model('FlowShop_Optimization')
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i][j] = 1 if product i is processed before product j on any machine
    x = {}
    for i in range(n_products):
        for j in range(i+1, n_products):
            x[(i,j)] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
    
    # C[i][m] = completion time of product i on machine m
    C = {}
    for i in range(n_products):
        for m in range(n_machines):
            C[(i,m)] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"C_{i}_{m}")
    
    # Makespan variable
    makespan = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="makespan")
    
    # Overtime variables for each machine
    overtime = {}
    for m in range(n_machines):
        overtime[m] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"overtime_{m+1}")
    
    # Binary variable for Machine 1 overtime exceeding threshold
    m1_exceeds_threshold = model.addVar(vtype=GRB.BINARY, name="m1_exceeds_threshold")
    
    # Big-M values
    M = max(params.get(f'M_{m+1}', 100) for m in range(n_machines))
    
    # Flow shop constraints
    # For each product, completion time on machine m depends on previous machine
    for i in range(n_products):
        for m in range(n_machines):
            if m == 0:
                # First machine: just processing time
                model.addConstr(C[(i, m)] >= processing_times[i][m], name=f"proc_time_{i}_{m}")
            else:
                # Must wait for same product on previous machine
                model.addConstr(C[(i, m)] >= C[(i, m-1)] + processing_times[i][m], 
                               name=f"flow_{i}_{m}")
    
    # Sequencing constraints: for each pair of products on each machine
    for m in range(n_machines):
        for i in range(n_products):
            for j in range(i+1, n_products):
                # If i before j: C[j][m] >= C[i][m] + p[j][m]
                model.addConstr(C[(j, m)] >= C[(i, m)] + processing_times[j][m] - M * (1 - x[(i,j)]),
                               name=f"seq_{i}_{j}_{m}_1")
                # If j before i: C[i][m] >= C[j][m] + p[i][m]
                model.addConstr(C[(i, m)] >= C[(j, m)] + processing_times[i][m] - M * x[(i,j)],
                               name=f"seq_{i}_{j}_{m}_2")
    
    # Makespan constraint
    for i in range(n_products):
        model.addConstr(makespan >= C[(i, n_machines-1)], name=f"makespan_{i}")
    
    # Overtime calculation for each machine
    # Total time on machine m = sum of processing times for all products
    for m in range(n_machines):
        total_time = sum(processing_times[i][m] for i in range(n_products))
        model.addConstr(overtime[m] >= total_time - time_window[m+1], name=f"overtime_calc_{m+1}")
        model.addConstr(overtime[m] <= overtime_window[m+1], name=f"overtime_limit_{m+1}")
    
    # Machine 1 special overtime rule
    # If overtime > threshold, add review fee
    model.addConstr(overtime[0] <= m1_overtime_threshold + M * m1_exceeds_threshold,
                   name="m1_threshold_check")
    
    # Objective: minimize makespan + overtime penalties + Machine 1 review fee
    overtime_cost = sum(overtime_penalty * overtime[m] for m in range(n_machines))
    m1_review_cost = m1_overtime_review_fee * m1_exceeds_threshold
    
    model.setObjective(makespan + overtime_cost + m1_review_cost, GRB.MINIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        final_obj = model.objVal
        print(f"FINAL_OBJ_VALUE: {final_obj}")
    else:
        print("No optimal solution found")

if __name__ == "__main__":
    main()
