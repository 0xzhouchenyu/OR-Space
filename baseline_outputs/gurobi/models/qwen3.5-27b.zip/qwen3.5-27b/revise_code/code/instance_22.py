import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    # Determine script directory to locate data folder
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    t1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    t2 = pd.read_csv(os.path.join(data_dir, 'table_2.csv'))
    t3 = pd.read_csv(os.path.join(data_dir, 'table_3.csv'))
    gp_df = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Merge product data
    df = t1.merge(t2, on='Product').merge(t3, on='Product')
    
    # Parse general parameters
    prod_days = float(gp_df[gp_df['Parameter_Name'] == 'production_days']['Value'].iloc[0])
    a1_watch_threshold = float(gp_df[gp_df['Parameter_Name'] == 'a1_watch_threshold']['Value'].iloc[0])
    a1_deep_service_threshold = float(gp_df[gp_df['Parameter_Name'] == 'a1_deep_service_threshold']['Value'].iloc[0])
    maintenance_penalty_watch = float(gp_df[gp_df['Parameter_Name'] == 'maintenance_penalty_watch']['Value'].iloc[0])
    maintenance_penalty_deep = float(gp_df[gp_df['Parameter_Name'] == 'maintenance_penalty_deep']['Value'].iloc[0])
    a1_quality_release_fee = float(gp_df[gp_df['Parameter_Name'] == 'a1_quality_release_fee']['Value'].iloc[0])
    a1_deep_service_fee = float(gp_df[gp_df['Parameter_Name'] == 'a1_deep_service_fee']['Value'].iloc[0])
    a1_priority_price_lift = float(gp_df[gp_df['Parameter_Name'] == 'a1_priority_price_lift']['Value'].iloc[0])
    
    return df, {
        'prod_days': prod_days,
        'a1_watch_threshold': a1_watch_threshold,
        'a1_deep_service_threshold': a1_deep_service_threshold,
        'maintenance_penalty_watch': maintenance_penalty_watch,
        'maintenance_penalty_deep': maintenance_penalty_deep,
        'a1_quality_release_fee': a1_quality_release_fee,
        'a1_deep_service_fee': a1_deep_service_fee,
        'a1_priority_price_lift': a1_priority_price_lift
    }

def solve():
    df, params = load_data()
    
    # Create model
    model = gp.Model("Production_Planning_Revised")
    model.setParam('OutputFlag', 0)
    
    products = df['Product'].tolist()
    
    # Variables
    # x[p]: Production quantity
    x = model.addVars(products, lb=0, name="x")
    # y[p]: Activation binary
    y = model.addVars(products, vtype=GRB.BINARY, name="y")
    
    # A1 specific variables
    # z1: 1 if A1 > watch_threshold
    z1 = model.addVar(vtype=GRB.BINARY, name="z_watch")
    # z2: 1 if A1 > deep_service_threshold
    z2 = model.addVar(vtype=GRB.BINARY, name="z_deep")
    # x_lift: Amount of A1 above watch_threshold
    x_lift = model.addVar(lb=0, name="x_lift")
    
    # Constants
    M = 10000  # Big M, larger than max demand (5400)
    eps = 1e-5
    
    # Objective Function
    # Profit = Sum((Price - Cost) * x) - Sum(Activation * y) - Fees + Lift
    profit_terms = []
    for _, row in df.iterrows():
        p = row['Product']
        margin = row['Selling_Price'] - row['Production_Cost']
        profit_terms.append(margin * x[p])
        profit_terms.append(-row['Activation_Cost'] * y[p])
        
    # A1 specific adjustments
    # Lift revenue
    profit_terms.append(params['a1_priority_price_lift'] * x_lift)
    # Fees
    profit_terms.append(-params['a1_quality_release_fee'] * z1)
    profit_terms.append(-params['a1_deep_service_fee'] * z2)
    
    model.setObjective(gp.quicksum(profit_terms), GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. All products must be produced (based on original heuristic y[p]==1)
    for p in products:
        model.addConstr(y[p] == 1, name=f"activate_{p}")
        
    # 2. Demand and Batch Constraints
    for _, row in df.iterrows():
        p = row['Product']
        model.addConstr(x[p] <= row['Maximum_Demand'], name=f"demand_{p}")
        model.addConstr(x[p] >= row['Minimum_Batch'] * y[p], name=f"min_batch_{p}")
        # Upper bound linked to y is redundant if y=1, but good practice
        model.addConstr(x[p] <= row['Maximum_Demand'] * y[p], name=f"link_demand_{p}")
        
    # 3. Production Days Constraint
    # Sum(x[p] / Quota[p]) + Penalties <= Prod_Days
    days_used = gp.quicksum([x[p] / row['Production_Quota'] for _, row in df.iterrows() if row['Product'] == p for p in [row['Product']]]) 
    # Correction: iterate properly
    days_expr = gp.LinExpr()
    for _, row in df.iterrows():
        p = row['Product']
        days_expr += x[p] / row['Production_Quota']
    
    days_expr += params['maintenance_penalty_watch'] * z1
    days_expr += params['maintenance_penalty_deep'] * z2
    
    model.addConstr(days_expr <= params['prod_days'], name="total_days")
    
    # 4. A1 Threshold Logic
    # Watch Threshold (3000)
    # If z1=0 -> x_A1 <= 3000
    # If z1=1 -> x_A1 >= 3000 + eps
    model.addConstr(x['A1'] <= params['a1_watch_threshold'] + M * z1, name="watch_upper")
    model.addConstr(x['A1'] >= params['a1_watch_threshold'] + eps - M * (1 - z1), name="watch_lower")
    
    # Deep Threshold (3600)
    # If z2=0 -> x_A1 <= 3600
    # If z2=1 -> x_A1 >= 3600 + eps
    model.addConstr(x['A1'] <= params['a1_deep_service_threshold'] + M * z2, name="deep_upper")
    model.addConstr(x['A1'] >= params['a1_deep_service_threshold'] + eps - M * (1 - z2), name="deep_lower")
    
    # Linkage: Cannot cross deep without crossing watch
    model.addConstr(z2 <= z1, name="threshold_link")
    
    # 5. Lift Variable Logic
    # x_lift represents amount above watch_threshold
    # If z1=0, x_lift must be 0
    # If z1=1, x_lift = x_A1 - 3000 (approx)
    # Constraints:
    # x_lift <= x_A1 - 3000 + M*(1-z1)
    # x_lift >= x_A1 - 3000
    # x_lift <= M*z1
    
    model.addConstr(x_lift <= x['A1'] - params['a1_watch_threshold'] + M * (1 - z1), name="lift_upper_bound")
    model.addConstr(x_lift >= x['A1'] - params['a1_watch_threshold'], name="lift_lower_bound")
    model.addConstr(x_lift <= M * z1, name="lift_activation")
    
    # Solve
    model.optimize()
    
    if model.Status == GRB.OPTIMAL:
        return model.ObjVal
    else:
        return None

if __name__ == "__main__":
    obj = solve()
    print(f"FINAL_OBJ_VALUE: {round(obj, 4)}")
