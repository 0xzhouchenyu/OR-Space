import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Load Params
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            try:
                params[key] = int(val)
            except ValueError:
                params[key] = float(val)
                
    # Load Candidates
    candidates = []
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            })
            
    # Extract Params
    budget = params['company_budget']
    max_emp = params['max_employees']
    min_skill = params['min_skill_level']
    min_pm = params['min_project_experience']
    max_gj = params['max_one_candidate_g_j']
    lead_prem = params['lead_premium']
    min_leads = params['min_leads']
    ment_bonus = params['mentor_bonus']
    max_pairs = params['max_pairs']
    
    # Model
    model = gp.Model("HiringOptimization")
    model.setParam('OutputFlag', 0)
    
    # Vars
    x = {} # Hire
    lead = {} # Role Lead
    eng = {} # Role Eng
    
    for c in candidates:
        name = c['name']
        x[name] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}")
        lead[name] = model.addVar(vtype=GRB.BINARY, name=f"lead_{name}")
        eng[name] = model.addVar(vtype=GRB.BINARY, name=f"eng_{name}")
        
    num_pairs = model.addVar(vtype=GRB.INTEGER, name="num_pairs", lb=0, ub=max_pairs)
    
    # Constraints
    # Role assignment
    for c in candidates:
        name = c['name']
        model.addConstr(lead[name] + eng[name] == x[name], f"role_{name}")
        
    # Max Employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_emp, "max_emp")
    
    # Min Skill
    model.addConstr(gp.quicksum(c['skill'] * x[c['name']] for c in candidates) >= min_skill, "min_skill")
    
    # Min PM
    model.addConstr(gp.quicksum(c['pm_exp'] * x[c['name']] for c in candidates) >= min_pm, "min_pm")
    
    # G vs J
    model.addConstr(x['G'] + x['J'] <= max_gj, "max_gj")
    
    # Min Leads
    model.addConstr(gp.quicksum(lead[c['name']] for c in candidates) >= min_leads, "min_leads")
    
    # Mentorship Pairs
    total_leads = gp.quicksum(lead[c['name']] for c in candidates)
    total_eng = gp.quicksum(eng[c['name']] for c in candidates)
    model.addConstr(num_pairs <= total_leads, "pair_leads")
    model.addConstr(num_pairs <= total_eng, "pair_eng")
    model.addConstr(num_pairs <= max_pairs, "pair_max")
    
    # Budget Constraint (Net Cost <= Budget)
    # Net Cost = Sum(Salary*x) + LeadPrem*Sum(Lead) - MentBonus*num_pairs
    gross_cost = gp.quicksum(c['salary'] * x[c['name']] for c in candidates)
    lead_cost = lead_prem * gp.quicksum(lead[c['name']] for c in candidates)
    net_cost_expr = gross_cost + lead_cost - ment_bonus * num_pairs
    
    model.addConstr(net_cost_expr <= budget, "budget")
    
    # Objective
    model.setObjective(net_cost_expr, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Should not happen based on analysis, but handle gracefully
        print(f"FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
