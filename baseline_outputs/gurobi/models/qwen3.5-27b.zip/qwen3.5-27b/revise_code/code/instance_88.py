import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_params(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            k = row['Parameter_Name']
            v = float(row['Value'])
            params[k] = v
    return params

# Paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')
params_file = os.path.join(data_dir, 'general_parameters.csv')

params = load_params(params_file)

# Extract
m1_t_l = params['machine_1_time_per_liquid_lot'] # 50
m2_t_l = params['model_2_time_per_liquid_lot'] # Wait, key name check
# Re-check keys from CSV content provided in prompt:
# machine_1_time_per_liquid_lot
# machine_2_time_per_liquid_lot
# ...
# machine_1_available_time (hours)
# ...
# extended_extra_minutes
# labor_hours_per_machine_extended
# labor_budget_hours
# extended_mode_penalty
# priority_reserve_lots
# excess_reserve_credit
