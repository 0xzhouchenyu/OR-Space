net_export[c] = x[c] - consumed
