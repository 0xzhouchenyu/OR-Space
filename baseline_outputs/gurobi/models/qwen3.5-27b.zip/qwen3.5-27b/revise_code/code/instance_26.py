import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if param_name == 'shift_duration':
                params[param_name] = int(value)
            elif param_name == 'shift_start_times':
                params[param_name] = value.split(';')
            elif param_name == 'full_time_cost':
                params[param_name] = float(value)
            elif param_name == 'part_time_cost':
                params[param_name] = float(value)
            elif param_name == 'part_time_cap_per_period':
                params[param_name] = int(value)
            elif param_name == 'min_full_time_per_period':
                params[param_name] = int(value)
    
    # Read staffing requirements
    requirements = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row['Time_Period'].strip()
            req = int(row['Required_Salespeople'].strip())
            requirements[period] = req
    
    # Define periods in order
    periods = ['2:00-6:00', '6:00-10:00', '10:00-14:00', '14:00-18:00', '18:00-22:00', '22:00-2:00']
    n = len(periods)  # 6 periods
    
    # Extract requirement values in order
    req_values = [requirements[p] for p in periods]
    
    # Create Gurobi model
    model = gp.Model("StaffingOptimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i] = number of full-time salespeople starting shift at period i
    x = model.addVars(n, vtype=GRB.INTEGER, name="x", lb=0)
    
    # y[j] = number of part-time salespeople assigned to period j
    y = model.addVars(n, vtype=GRB.INTEGER, name="y", lb=0)
    
    # Objective: minimize total daily labor cost
    model.setObjective(
        gp.quicksum(x[i] * params['full_time_cost'] for i in range(n)) +
        gp.quicksum(y[j] * params['part_time_cost'] for j in range(n)),
        GRB.MINIMIZE
    )
    
    # Constraints
    for j in range(n):
        # Coverage constraint: full-time from period j and (j-1) + part-time in period j >= required
        prev_period = (j - 1) % n
        model.addConstr(
            x[j] + x[prev_period] + y[j] >= req_values[j],
            name=f"coverage_{j}"
        )
        
        # Minimum full-time constraint: full-time from period j and (j-1) >= min_full_time
        model.addConstr(
            x[j] + x[prev_period] >= params['min_full_time_per_period'],
            name=f"min_fulltime_{j}"
        )
        
        # Part-time cap constraint: part-time in period j <= cap
        model.addConstr(
            y[j] <= params['part_time_cap_per_period'],
            name=f"pt_cap_{j}"
        )
    
    # Solve
    model.optimize()
    
    # Print solution details
    if model.status == GRB.OPTIMAL:
        for i in range(n):
            print(f"Full-time starting at period {periods[i]}: {int(x[i].X)} salespeople")
        for j in range(n):
            print(f"Part-time in period {periods[j]}: {int(y[j].X)} salespeople")
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found")

if __name__ == "__main__":
    main()
