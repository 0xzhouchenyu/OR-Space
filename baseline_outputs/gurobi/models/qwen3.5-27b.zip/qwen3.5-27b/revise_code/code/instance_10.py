import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_coverage_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    
    return areas, coverage

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    small_cost = int(params.get('small_cost', 1))
    large_cost = int(params.get('large_cost', 2))
    small_cap_areas = int(params.get('small_cap_areas', 3))
    max_large_stores = int(params.get('max_large_stores', 1))
    min_small_stores = int(params.get('minimum_neighborhood_counters', 6))
    
    # Create Gurobi model
    model = gp.Model("MinChainStores")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_S[j] = 1 if small store at location j
    # x_L[j] = 1 if large store at location j
    x_S = {j: model.addVar(vtype=GRB.BINARY, name=f"x_S_{j}") for j in areas}
    x_L = {j: model.addVar(vtype=GRB.BINARY, name=f"x_L_{j}") for j in areas}
    
    # y[i][j] = 1 if area i is covered by store at location j
    y = {}
    for i in areas:
        for j in areas:
            if i in coverage.get(j, set()):
                y[(i, j)] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{j}")
    
    # Constraint: at most one store type per location
    for j in areas:
        model.addConstr(x_S[j] + x_L[j] <= 1)
    
    # Constraint: maximum large stores
    model.addConstr(gp.quicksum(x_L[j] for j in areas) <= max_large_stores)
    
    # Constraint: minimum small stores
    model.addConstr(gp.quicksum(x_S[j] for j in areas) >= min_small_stores)
    
    # Constraint: small store capacity (can only cover up to small_cap_areas)
    for j in areas:
        model.addConstr(gp.quicksum(y[(i, j)] for i in areas if i in coverage.get(j, set())) <= small_cap_areas * x_S[j])
    
    # Constraint: large store has no capacity limit (can cover all areas in its range)
    for j in areas:
        for i in areas:
            if i in coverage.get(j, set()):
                model.addConstr(y[(i, j)] <= x_L[j])
    
    # Constraint: each area must be covered by at least one store
    for i in areas:
        model.addConstr(gp.quicksum(y[(i, j)] for j in areas if i in coverage.get(j, set())) >= 1)
    
    # Objective: minimize total cost
    model.setObjective(gp.quicksum(small_cost * x_S[j] for j in areas) + 
                       gp.quicksum(large_cost * x_L[j] for j in areas), GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Print results
    print(f"Status: {model.Status}")
    print(f"Optimal cost: {model.ObjVal}")
    
    selected_small = [j for j in areas if x_S[j].X > 0.5]
    selected_large = [j for j in areas if x_L[j].X > 0.5]
    
    print(f"Small stores: {selected_small}")
    print(f"Large stores: {selected_large}")
    
    # Verify coverage
    covered_total = set()
    for j in selected_small:
        covered_total |= coverage[j]
    for j in selected_large:
        covered_total |= coverage[j]
    
    print(f"All areas covered: {set(areas).issubset(covered_total)}")
    print(f"Covered areas: {sorted(covered_total)}")
    
    print(f"\nFINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
