import os
import csv
import gurobipy as gp
from gurobipy import Model, GRB

def main():
    # Set up paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'name': row['Product Name'].strip(),
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            })
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            try:
                params[key] = float(value)
            except:
                params[key] = value
    
    available_labor = params.get('available_labor', 1500)
    available_material = params.get('available_material', 1600)
    fixed_costs = [
        params.get('fixed_cost_shirts', 2000),
        params.get('fixed_cost_short_sleeves', 1500),
        params.get('fixed_cost_casual_clothes', 1000)
    ]
    
    # Segment parameters
    regular_discount = params.get('segment_regular_discount', 1.0)
    promo_discount = params.get('segment_promo_discount', 0.9)
    promo_labor_cap = params.get('segment_promo_labor_cap', 600)
    promo_material_cap = params.get('segment_promo_material_cap', 600)
    
    # Batch size constraints
    min_batches = [
        params.get('min_batch_shirts', 50),
        params.get('min_batch_short_sleeves', 50),
        params.get('min_batch_casual_clothes', 30)
    ]
    
    # Production capacity limits
    max_productions = [
        params.get('max_prod_shirts', 400),
        params.get('max_prod_short_sleeves', 500),
        params.get('max_prod_casual_clothes', 300)
    ]
    
    n = len(products)
    
    # Create Gurobi model
    model = gp.Model("Clothing_Production")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    y = model.addVars(n, vtype=GRB.BINARY, name="activate")
    x_r = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="regular_sales")
    x_p = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="promo_sales")
    
    # Objective function: maximize profit
    profit_terms = []
    for i in range(n):
        unit_profit_r = (products[i]['price'] * regular_discount - products[i]['var_cost'])
        unit_profit_p = (products[i]['price'] * promo_discount - products[i]['var_cost'])
        profit_terms.append(unit_profit_r * x_r[i])
        profit_terms.append(unit_profit_p * x_p[i])
    
    fixed_cost_penalty = [
        fixed_costs[0] * y[0],
        fixed_costs[1] * y[1],
        fixed_costs[2] * y[2]
    ]
    
    objective = gp.quicksum(profit_terms) - gp.quicksum(fixed_cost_penalty)
    model += gp.quickSum([term for term in profit_terms]) - gp.quickSum(fixed_cost_penalty)
    model.optimize()
    
    print(f"Optimal Profit: ${model.objVal:.2f}")
    for i in range(n):
        print(f"Product {i+1}: Produce {model.getVarByName(f"x_r[{i}]").X} units")

if __name__ == "__main__":
    main()
