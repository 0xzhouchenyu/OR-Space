import os


import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data from CSV files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Read table_1_7.csv
    table_data = []
    filepath = os.path.join(base_dir, 'data', 'table_1_7.csv')
    with open(filepath, 'r') as f:
        lines = f.readlines()
        for line in lines:
            table_data.append(line.strip().split(','))
    
    # Parse general_parameters.csv
    params = {}
    filepath = os.path.join(base_dir, 'data', 'general_parameters.csv')
    with open(filepath, 'r') as f:
        lines = f.readlines()[1:]  # Skip header
        for line in lines:
            parts = line.strip().split(',')
            if len(parts) >= 2:
                params[parts[0]] = parts[1]
    
    # Extract parameters from table_1_7.csv
    # Row structure: Item,A,B,C,Raw Material Cost,Monthly Limit
    # Row 0: Header
    # Row 1: A,>=60%,>=15%,,2.00,2000
    # Row 2: B,,,,1.50,2500
    # Row 3: C,<=20%,<=60%,<=50%,1.00,1200
    # Row 4: Processing Fee,0.50,0.40,0.30,,
    # Row 5: Selling Price,3.40,2.85,2.25,,
    
    raw_materials = ['A', 'B', 'C']
    brands = ['A', 'B', 'C']
    
    # Raw material costs and limits
    raw_cost = [2.00, 1.50, 1.00]
    limits = [2000, 2500, 1200]
    
    # Processing fees per brand
    proc_fee = [0.50, 0.40, 0.30]
    
    # Selling prices per brand
    sell_price = [3.40, 2.85, 2.25]
    
    # Setup costs from general_parameters.csv
    setup_cost_A = float(params.get('SetupCost_A', 300))
    setup_cost_B = float(params.get('SetupCost_B', 500))
    setup_cost_C = float(params.get('SetupCost_C', 200))
    shared_wrapper_fee = float(params.get('BrandAB_SharedWrapper_Fee', 300))
    
    # Create Gurobi model
    model = gp.Model("CandyFactory")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i][j] = kg of raw material i used in brand j
    x = {}
    for i in range(3):
        for j in range(3):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    # Total production of each brand
    y = {}
    for j in range(3):
        y[j] = gp.quicksum(x[i, j] for i in range(3))
    
    # Binary variables: z[j] = 1 if brand j is produced
    z = {}
    for j in range(3):
        z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{j}")
    
    # Binary variable for shared wrapper (1 if both A and B are produced)
    w = model.addVar(vtype=GRB.BINARY, name="w_shared_wrapper")
    
    # Big-M value (use sum of all raw material limits as upper bound)
    M = sum(limits)
    
    # Link production to binary variables
    for j in range(3):
        model.addConstr(y[j] <= M * z[j], name=f"link_{j}")
    
    # Raw material supply constraints
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= limits[i], name=f"supply_{i}")
    
    # Composition constraints
    # Raw material A (i=0): >=60% in brand A (j=0), >=15% in brand B (j=1)
    model.addConstr(x[0, 0] >= 0.60 * y[0], name="comp_A_in_brandA")
    model.addConstr(x[0, 1] >= 0.15 * y[1], name="comp_A_in_brandB")
    
    # Raw material C (i=2): <=20% in brand A (j=0), <=60% in brand B (j=1), <=50% in brand C (j=2)
    model.addConstr(x[2, 0] <= 0.20 * y[0], name="comp_C_in_brandA")
    model.addConstr(x[2, 1] <= 0.60 * y[1], name="comp_C_in_brandB")
    model.addConstr(x[2, 2] <= 0.50 * y[2], name="comp_C_in_brandC")
    
    # Shared wrapper constraint: w = 1 if z[0]=1 AND z[1]=1
    # w >= z[0] + z[1] - 1
    # w <= z[0]
    # w <= z[1]
    model.addConstr(w >= z[0] + z[1] - 1, name="shared_wrapper_lower")
    model.addConstr(w <= z[0], name="shared_wrapper_upper1")
    model.addConstr(w <= z[1], name="shared_wrapper_upper2")
    
    # Objective: maximize profit
    revenue = gp.quicksum(sell_price[j] * y[j] for j in range(3))
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in range(3))
    setup_cost = setup_cost_A * z[0] + setup_cost_B * z[1] + setup_cost_C * z[2]
    wrapper_cost = shared_wrapper_fee * w
    
    profit = revenue - material_cost - processing_cost - setup_cost - wrapper_cost
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    # Print result
    print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")

if __name__ == "__main__":
    main()
