import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_data():
    # Determine the directory of the current script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.join(script_dir, 'data')
    
    # Load table_1.csv
    parts = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
    
    # Load general_parameters.csv
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    return parts, params

def main():
    parts, params = load_data()
    n = len(parts)

    # Extract parameters
    max_heavy = int(params['max_heavy_bombs'])
    max_light = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts = int(params['min_parts_destroyed'])
    
    eff_heavy = params['fuel_efficiency_heavy_bomb']
    eff_light = params['fuel_efficiency_light_bomb']
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    overhead_A = params['sortie_fuel_overhead_A']
    overhead_B = params['sortie_fuel_overhead_B']
    
    # Effective sortie limit is the minimum of the two scenarios
    max_sorties = min(max_sorties_A, max_sorties_B)

    # Precompute fuel costs per bomb type per part for both scenarios
    # Fuel = distance/eff_loaded + distance/eff_empty + takeoff + overhead
    fuel_costs_A = []
    fuel_costs_B = []
    
    for p in parts:
        dist = p['distance']
        
        # Heavy Bomb
        base_fuel_h = dist / eff_heavy + dist / eff_empty + takeoff_landing
        cost_h_A = base_fuel_h + overhead_A
        cost_h_B = base_fuel_h + overhead_B
        
        # Light Bomb
        base_fuel_l = dist / eff_light + dist / eff_empty + takeoff_landing
        cost_l_A = base_fuel_l + overhead_A
        cost_l_B = base_fuel_l + overhead_B
        
        fuel_costs_A.append({'h': cost_h_A, 'l': cost_l_A})
        fuel_costs_B.append({'h': cost_h_B, 'l': cost_l_B})

    # Create Model
    model = gp.Model("BombAllocationRevised")
    model.setParam('OutputFlag', 0)
    model.setParam('NonConvex', 2) # Required for nonlinear expressions with variables

    # Decision Variables: h[i], l[i]
    h_vars = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="h")
    l_vars = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="l")

    # Constraints
    
    # 1. Inventory Limits
    model.addConstr(gp.quicksum(h_vars[i] for i in range(n)) <= max_heavy, name="max_heavy_inv")
    model.addConstr(gp.quicksum(l_vars[i] for i in range(n)) <= max_light, name="max_light_inv")
    
    # 2. Sortie Limits (Must fit in BOTH scenarios, so min)
    model.addConstr(gp.quicksum(h_vars[i] + l_vars[i] for i in range(n)) <= max_sorties, name="max_sorties")
    
    # 3. Fuel Limits (Must fit in BOTH scenarios)
    fuel_expr_A = gp.quicksum(h_vars[i] * fuel_costs_A[i]['h'] + l_vars[i] * fuel_costs_A[i]['l'] for i in range(n))
    model.addConstr(fuel_expr_A <= fuel_limit, name="fuel_limit_A")
    
    fuel_expr_B = gp.quicksum(h_vars[i] * fuel_costs_B[i]['h'] + l_vars[i] * fuel_costs_B[i]['l'] for i in range(n))
    model.addConstr(fuel_expr_B <= fuel_limit, name="fuel_limit_B")

    # Objective: Maximize Probability of at least min_parts destroyed
    # P(Success) = 1 - P(0 destroyed) - P(1 destroyed)
    # P(0 destroyed) = Product(Q_i) where Q_i = (1-p_H)^h * (1-p_L)^l
    # P(1 destroyed) = Sum_i [ (1-Q_i) * Product_{j!=i}(Q_j) ]
    
    # Auxiliary variables for Q_i (Survival Probability of part i)
    Q_vars = []
    
    for i in range(n):
        p_h = parts[i]['p_heavy']
        p_l = parts[i]['p_light']
        
        # Q_i = (1 - p_h)^h_i * (1 - p_l)^l_i
        # We use GenConstrPow for base^var
        # Note: 1-p is constant, h/l are variables
        
        # Term H: (1-p_h)^h_i
        term_h = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=1, name=f"Q_term_h_{i}")
        model.addGenConstrPow(term_h, 1.0 - p_h, h_vars[i])
        
        # Term L: (1-p_l)^l_i
        term_l = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=1, name=f"Q_term_l_{i}")
        model.addGenConstrPow(term_l, 1.0 - p_l, l_vars[i])
        
        # Q_i = term_h * term_l
        q_i = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=1, name=f"Q_{i}")
        model.addGenConstrMult(q_i, term_h, term_l)
        
        Q_vars.append(q_i)

    # Construct Objective Expression
    # P(0) = Q_0 * Q_1 * Q_2 * Q_3
    p_zero = Q_vars[0] * Q_vars[1] * Q_vars[2] * Q_vars[3]
    
    # P(1) = Sum_i ( (1-Q_i) * Product_{j!=i} Q_j )
    p_one = 0.0
    for i in range(n):
        prod_others = 1.0
        for j in range(n):
            if i != j:
                prod_others *= Q_vars[j]
        p_one += (1.0 - Q_vars[i]) * prod_others
        
    # Objective = 1 - P(0) - P(1)
    obj_expr = 1.0 - p_zero - p_one
    
    model.setObjective(obj_expr, GRB.MAXIMIZE)

    # Optimize
    model.optimize()

    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal:.4f}")
    else:
        # Fallback if no optimal found (should not happen with valid data)
        print(f"FINAL_OBJ_VALUE: 0.0000")

if __name__ == '__main__':
    main()
