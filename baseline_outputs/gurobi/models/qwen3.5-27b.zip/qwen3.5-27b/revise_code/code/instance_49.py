import os
import sys
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Load Data
    table_1_path = os.path.join(data_dir, "table_1.csv")
    table_2_path = os.path.join(data_dir, "table_2.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    
    df_demand = pd.read_csv(table_1_path)
    df_cost = pd.read_csv(table_2_path)
    df_params = pd.read_csv(params_path)
    
    # Parse Parameters
    def get_param(name):
        val = df_params.loc[df_params['Parameter_Name'] == name, 'Value'].values[0]
        return val
    
    min_contract_types = int(get_param('min_contract_types'))
    max_contract_types = int(get_param('max_contract_types'))
    mutual_exclusion = str(get_param('mutual_exclusion_1_and_4')).strip().lower() == 'true'
    monthly_max_parallel = int(get_param('monthly_max_parallel_contracts'))
    min_area = int(get_param('min_area_per_contract_units'))
    activation_fee = float(get_param('activation_fee_per_contract'))
    onboarding_loss = float(get_param('onboarding_loss_units'))
    expedited_fee = float(get_param('expedited_onboarding_fee'))
    
    # Process Demands (convert to 100 sqm units)
    demands = {}
    for _, row in df_demand.iterrows():
        m = int(row['Month'])
        d = float(row['Required_area_㎡']) / 100.0
        demands[m] = d
        
    # Process Costs
    costs = {}
    for _, row in df_cost.iterrows():
        l = int(row['Contract_length_months'])
        c = float(row['Rental_fee_per_100㎡_yuan'])
        costs[l] = c
        
    months = sorted(demands.keys())
    lengths = sorted(costs.keys())
    max_month = max(months)
    
    # Create Model
    model = gp.Model("Warehouse_Rental_Revised")
    model.setParam('OutputFlag', 0)
    
    # Valid (start_month, length) pairs
    valid_pairs = []
    for i in months:
        for l in lengths:
            if i + l - 1 <= max_month:
                valid_pairs.append((i, l))
                
    # Variables
    # x[i, l]: Area (units of 100 sqm) for contract starting at i with length l
    x = model.addVars(valid_pairs, vtype=GRB.INTEGER, name="x")
    
    # z[i, l]: Binary, 1 if contract (i, l) is opened
    z = model.addVars(valid_pairs, vtype=GRB.BINARY, name="z")
    
    # e[i, l]: Binary, 1 if expedited onboarding for contract (i, l)
    e = model.addVars(valid_pairs, vtype=GRB.BINARY, name="e")
    
    # y[l]: Binary, 1 if contract length l is used
    y = model.addVars(lengths, vtype=GRB.BINARY, name="y")
    
    # Objective
    # Rental Cost + Activation Fee + Expedited Fee
    obj = gp.quicksum(costs[l] * x[i, l] for i, l in valid_pairs)
    obj += gp.quicksum(activation_fee * z[i, l] for i, l in valid_pairs)
    obj += gp.quicksum(expedited_fee * e[i, l] for i, l in valid_pairs)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    
    # 1. Demand Fulfillment
    # For each month m, sum of effective areas = demand
    for m in months:
        # Sum of x for all active contracts
        active_x = gp.quicksum(x[i, l] for i, l in valid_pairs if i <= m < i + l)
        
        # Subtract onboarding loss for contracts starting at m without expedite
        # Loss applies to (m, l) pairs
        loss_term = gp.quicksum(onboarding_loss * (1 - e[m, l]) for l in lengths if (m, l) in valid_pairs)
        
        model.addConstr(active_x - loss_term == demands[m], f"Demand_{m}")
        
    # 2. Link x and z (Min Area & Existence)
    # x[i, l] >= min_area * z[i, l]
    # x[i, l] <= big_M * z[i, l]
    big_M = sum(demands.values()) + 100 # Sufficiently large
    for i, l in valid_pairs:
        model.addConstr(x[i, l] >= min_area * z[i, l])
        model.addConstr(x[i, l] <= big_M * z[i, l])
        
    # 3. Link e and z
    # e[i, l] <= z[i, l]
    for i, l in valid_pairs:
        model.addConstr(e[i, l] <= z[i, l])
        
    # 4. Link z and y (Contract Types)
    # y[l] = 1 if sum(z[i, l]) > 0
    for l in lengths:
        model.addConstr(gp.quicksum(z[i, l] for i in months if (i, l) in valid_pairs) <= big_M * y[l])
        model.addConstr(gp.quicksum(z[i, l] for i in months if (i, l) in valid_pairs) >= y[l])
        
    # 5. Contract Type Limits
    model.addConstr(gp.quicksum(y[l] for l in lengths) >= min_contract_types)
    model.addConstr(gp.quicksum(y[l] for l in lengths) <= max_contract_types)
    
    # 6. Mutual Exclusion
    if mutual_exclusion:
        if 1 in y and 4 in y:
            model.addConstr(y[1] + y[4] <= 1)
            
    # 7. Monthly Max Parallel Contracts
    for m in months:
        active_z = gp.quicksum(z[i, l] for i, l in valid_pairs if i <= m < i + l)
        model.addConstr(active_z <= monthly_max_parallel, f"Parallel_{m}")
        
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
