import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
cow_price = params['cow_selling_price']
sheep_price = params['sheep_selling_price']
chicken_price = params['chicken_selling_price']
cow_feed = params['cow_feed_cost']
sheep_feed = params['sheep_feed_cost']
chicken_feed = params['chicken_feed_cost']
cow_manure = params['cow_manure_production']
sheep_manure = params['sheep_manure_production']
chicken_manure = params['chicken_manure_production']
max_manure_base = params['max_manure_capacity']
max_chickens = params['max_chickens']
min_cows = params['min_cows']
min_sheep = params['min_sheep']
max_total_base = params['max_total_animals']

# New parameters from revision
premium_capacity_multiplier = params['premium_capacity_multiplier']
premium_manure_multiplier = params['premium_manure_multiplier']
expansion_cost = params['expansion_cost']
premium_feed_multiplier = params['premium_feed_multiplier']
base_land_usage_cow = params['base_land_usage_cow']
base_land_usage_sheep = params['base_land_usage_sheep']
base_land_usage_chicken = params['base_land_usage_chicken']
base_land_capacity = params['base_land_capacity']
expansion_land_increase = params['expansion_land_increase']

# Create model
model = gp.Model("FarmProfit")
model.setParam('OutputFlag', 0)

# Decision variables
expand_mode = model.addVar(vtype=GRB.BINARY, name="expand_mode")
cows = model.addVar(vtype=GRB.INTEGER, lb=min_cows, name="cows")
sheep = model.addVar(vtype=GRB.INTEGER, lb=min_sheep, name="sheep")
chickens = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_chickens, name="chickens")

# Calculate effective capacities based on expand_mode
# When expand_mode=0: use base values
# When expand_mode=1: use multiplied values + expansion cost

# Profit calculation
# Base profit per animal
cow_profit = cow_price - cow_feed
sheep_profit = sheep_price - sheep_feed
chicken_profit = chicken_price - chicken_feed

# Premium feed cost applies when expanded
# Need to model this carefully - premium feed multiplier applies to feed costs
# So effective feed cost = base_feed * premium_feed_multiplier when expanded

# Actually, re-reading the brief: "Premium animals are only credible when the expanded arrangement is actually in use"
# This suggests premium animals might be a separate category, OR it means all animals get premium treatment when expanded

# Looking at the parameters more carefully:
# - premium_feed_multiplier: Multiplier applied to feed costs of premium animals
# - premium_capacity_multiplier: Multiplier for max_total_animals when expanded mode is selected
# - premium_manure_multiplier: Multiplier for max_manure_capacity when expanded mode is selected

# I think the interpretation is:
# When expanded mode is ON:
#   - Total animal capacity increases by premium_capacity_multiplier
#   - Manure capacity increases by premium_manure_multiplier
#   - Feed costs increase by premium_feed_multiplier (for all animals or just premium?)
#   - Expansion cost is charged
#   - Land capacity increases by expansion_land_increase

# The phrase "Premium animals are only credible when the expanded arrangement is actually in use" 
# suggests there might be premium versions of animals, but I don't see separate premium animal parameters.
# I'll interpret this as: when expanded, all animals benefit from the expanded setup (higher capacity, etc.)
# but also incur higher feed costs due to premium_feed_multiplier

# Objective function
# Profit = revenue - feed_cost - expansion_cost(if expanded)
# Revenue = cow_price*cows + sheep_price*sheep + chicken_price*chickens
# Feed cost = cow_feed*cows + sheep_feed*sheep + chicken_feed*chickens
# But when expanded, feed costs are multiplied by premium_feed_multiplier

# This is tricky because feed cost depends on expand_mode
# We can model this as:
# feed_cost = (cow_feed*cows + sheep_feed*sheep + chicken_feed*chickens) * (1 + (premium_feed_multiplier-1)*expand_mode)

# Actually, let me reconsider. The premium_feed_multiplier is 1.3, meaning 30% increase in feed costs.
# So when expanded, feed cost = base_feed * 1.3
# When not expanded, feed cost = base_feed * 1.0

# We can model this linearly:
# effective_feed_cost = base_feed + (premium_feed_multiplier - 1) * base_feed * expand_mode
#                    = base_feed * (1 + (premium_feed_multiplier - 1) * expand_mode)

# For the objective:
# profit = sum(price_i * x_i) - sum(feed_i * x_i * (1 + (premium_feed_multiplier-1)*expand_mode)) - expansion_cost * expand_mode

# This creates non-linear terms (x_i * expand_mode). We need to linearize this.

# Linearization approach:
# Let feed_cost_normal = sum(base_feed_i * x_i)
# Let feed_cost_premium = sum(base_feed_i * premium_feed_multiplier * x_i)
# Actual feed cost = feed_cost_normal * (1-expand_mode) + feed_cost_premium * expand_mode
#                  = feed_cost_normal + (feed_cost_premium - feed_cost_normal) * expand_mode
#                  = feed_cost_normal + (premium_feed_multiplier - 1) * feed_cost_normal * expand_mode

# Still has product term. Better approach:
# Use auxiliary variables for feed costs in each mode
# Or use indicator constraints

# Simpler approach: Since expand_mode is binary, we can use big-M constraints
# But actually, the cleanest way is to create two sets of constraints and use expand_mode to activate them

# Let me use a different approach - model the feed cost directly:
# feed_cost = cow_feed*cows*(1-expand_mode) + cow_feed*premium_feed_multiplier*cows*expand_mode + ...
#           = cow_feed*cows + cow_feed*cows*(premium_feed_multiplier-1)*expand_mode + ...

# To avoid non-linearity, I'll use auxiliary variables:
# Let cows_normal = cows when expand_mode=0
# Let cows_premium = cows when expand_mode=1
# But cows is the same variable...

# Actually, the simplest correct approach:
# Model feed cost as: base_feed_cost + additional_feed_cost_when_expanded
# additional_feed_cost_when_expanded = (premium_feed_multiplier - 1) * base_feed_cost * expand_mode

# This still has the product. Let me use Gurobi's quadratic support or linearize properly.

# Linearization: For each animal type i:
# Let y_i = x_i * expand_mode (auxiliary variable)
# Then feed_cost = sum(base_feed_i * x_i) + sum(base_feed_i * (premium_feed_multiplier-1) * y_i)
# With constraints:
# y_i <= M * expand_mode
# y_i <= x_i
# y_i >= x_i - M * (1 - expand_mode)
# y_i >= 0

# Where M is a large enough number (e.g., max possible animals)

# Actually, Gurobi supports quadratic objectives natively! Let me check if I should use that.
# Yes, Gurobi can handle quadratic objectives. So I can write:
# profit = sum(price_i * x_i) - sum(feed_i * x_i * (1 + (premium_feed_multiplier-1)*expand_mode)) - expansion_cost * expand_mode

# This is quadratic but convex (since we're maximizing a concave function, which is minimizing a convex one).
# Wait, we're maximizing profit, so the objective should be concave for maximization.
# The term -feed_i * x_i * expand_mode is bilinear (product of two variables), which makes it non-convex.

# Better to linearize properly. Let me use the standard linearization technique.

# Actually, let me reconsider the business logic again:
# "Premium animals are only credible when the expanded arrangement is actually in use"
# This could mean there are PREMIUM versions of animals that can only be raised in expanded mode.
# But I don't see separate premium animal parameters in the CSV.

# Alternative interpretation: All animals become "premium" when expanded, meaning they have higher feed costs
# but also the farm has higher capacity limits.

# Let me go with the simpler interpretation:
# - When expanded: higher capacity limits, higher feed costs (by premium_feed_multiplier), pay expansion_cost
# - When not expanded: base capacity limits, base feed costs, no expansion_cost

# For the feed cost linearization, I'll use auxiliary variables.

# Capacity constraints:
# Total animals: cows + sheep + chickens <= max_total_base + (premium_capacity_multiplier - 1) * max_total_base * expand_mode
#               = max_total_base * (1 + (premium_capacity_multiplier - 1) * expand_mode)
#               = max_total_base * (1 + 0.5 * expand_mode)
#               = 100 * (1 + 0.5 * expand_mode)
#               = 100 + 50 * expand_mode

# Manure capacity: cow_manure*cows + sheep_manure*sheep + chicken_manure*chickens <= max_manure_base * (1 + (premium_manure_multiplier-1)*expand_mode)
#                 = 800 * (1 + 0.2 * expand_mode)
#                 = 800 + 160 * expand_mode

# Land capacity: base_land_usage_cow*cows + base_land_usage_sheep*sheep + base_land_usage_chicken*chickens <= base_land_capacity + expansion_land_increase * expand_mode
#               = 40 + 20 * expand_mode

# Now for the feed cost linearization:
# I'll create auxiliary variables for the interaction between animal counts and expand_mode

M = 200  # Large enough number (more than max_total_animals)

# Auxiliary variables for feed cost linearization
cows_expand = model.addVar(vtype=GRB.CONTINUOUS, name="cows_expand")
sheep_expand = model.addVar(vtype=GRB.CONTINUOUS, name="sheep_expand")
chickens_expand = model.addVar(vtype=GRB.CONTINUOUS, name="chickens_expand")

# Linearization constraints for cows_expand = cows * expand_mode
model.addConstr(cows_expand <= M * expand_mode)
model.addConstr(cows_expand <= cows)
model.addConstr(cows_expand >= cows - M * (1 - expand_mode))
model.addConstr(cows_expand >= 0)

# Linearization constraints for sheep_expand = sheep * expand_mode
model.addConstr(sheep_expand <= M * expand_mode)
model.addConstr(sheep_expand <= sheep)
model.addConstr(sheep_expand >= sheep - M * (1 - expand_mode))
model.addConstr(sheep_expand >= 0)

# Linearization constraints for chickens_expand = chickens * expand_mode
model.addConstr(chickens_expand <= M * expand_mode)
model.addConstr(chickens_expand <= chickens)
model.addConstr(chickens_expand >= chickens - M * (1 - expand_mode))
model.addConstr(chickens_expand >= 0)

# Objective function
# Revenue
revenue = cow_price * cows + sheep_price * sheep + chicken_price * chickens

# Feed cost (with premium multiplier when expanded)
# base_feed_cost = cow_feed*cows + sheep_feed*sheep + chicken_feed*chickens
# additional_feed_cost = (premium_feed_multiplier - 1) * (cow_feed*cows_expand + sheep_feed*sheep_expand + chicken_feed*chickens_expand)
base_feed_cost = cow_feed * cows + sheep_feed * sheep + chicken_feed * chickens
additional_feed_cost = (premium_feed_multiplier - 1) * (cow_feed * cows_expand + sheep_feed * sheep_expand + chicken_feed * chickens_expand)
total_feed_cost = base_feed_cost + additional_feed_cost

# Expansion cost
expansion_fee = expansion_cost * expand_mode

# Profit
profit = revenue - total_feed_cost - expansion_fee

model.setObjective(profit, GRB.MAXIMIZE)

# Constraints
# Total animals capacity
model.addConstr(cows + sheep + chickens <= max_total_base * (1 + (premium_capacity_multiplier - 1) * expand_mode))

# Manure capacity
model.addConstr(cow_manure * cows + sheep_manure * sheep + chicken_manure * chickens <= max_manure_base * (1 + (premium_manure_multiplier - 1) * expand_mode))

# Land capacity
model.addConstr(base_land_usage_cow * cows + base_land_usage_sheep * sheep + base_land_usage_chicken * chickens <= base_land_capacity + expansion_land_increase * expand_mode)

# Chicken maximum
model.addConstr(chickens <= max_chickens)

# Solve
model.optimize()

# Print result
print(f"FINAL_OBJ_VALUE: {model.objVal}")
