import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Read General Parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            try:
                params[key] = int(val)
            except ValueError:
                try:
                    params[key] = float(val)
                except ValueError:
                    params[key] = val
    
    # Read Table 1 for Children and Costs
    children = []
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Child'].strip()
            cost = int(row['Cost'].strip())
            children.append(name)
            costs[name] = cost
            
    # Extract specific parameters
    min_children = params['min_children_trip']
    max_children = params['max_children_trip']
    max_distinct = params['max_distinct_children_trip']
    budget = params['total_cost_budget']
    bonus = params['bonus_saving']
    min_bob = params['min_bob_days']
    
    # Create Model
    model = gp.Model("FamilyTripTwoDay")
    model.setParam('OutputFlag', 0)
    
    # Days
    days = [1, 2]
    
    # Decision Variables
    # x[child][day]
    x = {}
    for c in children:
        for d in days:
            x[(c, d)] = model.addVar(vtype=GRB.BINARY, name=f"x_{c}_{d}")
            
    # y[child]: 1 if child attends both days
    y = {}
    for c in children:
        y[c] = model.addVar(vtype=GRB.BINARY, name=f"y_{c}")
        
    # z[child]: 1 if child attends at least one day
    z = {}
    for c in children:
        z[c] = model.addVar(vtype=GRB.BINARY, name=f"z_{c}")
        
    # Objective: Minimize Net Cost
    # Cost = sum(cost[c] * x[c,d]) - sum(bonus * y[c])
    total_cost_expr = gp.quicksum(costs[c] * x[(c, d)] for c in children for d in days)
    total_bonus_expr = gp.quicksum(bonus * y[c] for c in children)
    net_cost_expr = total_cost_expr - total_bonus_expr
    
    model.setObjective(net_cost_expr, GRB.MINIMIZE)
    
    # Constraints
    
    # 1. Daily Headcount
    for d in days:
        model.addConstr(gp.quicksum(x[(c, d)] for c in children) >= min_children, f"MinChildren_Day{d}")
        model.addConstr(gp.quicksum(x[(c, d)] for c in children) <= max_children, f"MaxChildren_Day{d}")
        
    # 2. Distinct Children Limit
    model.addConstr(gp.quicksum(z[c] for c in children) <= max_distinct, "MaxDistinctChildren")
    
    # 3. Bob Minimum Days
    model.addConstr(gp.quicksum(x[('Bob', d)] for d in days) >= min_bob, "MinBobDays")
    
    # 4. Budget Constraint
    model.addConstr(net_cost_expr <= budget, "TotalBudget")
    
    # 5. Availability Constraints
    # Alice: Only Day 1
    model.addConstr(x[('Alice', 2)] == 0, "AliceOnlyDay1")
    # Charlie: Only Day 2
    model.addConstr(x[('Charlie', 1)] == 0, "CharlieOnlyDay2")
    # Diana: Only Day 2
    model.addConstr(x[('Diana', 1)] == 0, "DianaOnlyDay2")
    
    # 6. Relationship Constraints (Per Day)
    for d in days:
        # Alice and Diana cannot both be taken
        model.addConstr(x[('Alice', d)] + x[('Diana', d)] <= 1, f"AliceDianaConflict_Day{d}")
        
        # Bob and Charlie cannot both be taken
        model.addConstr(x[('Bob', d)] + x[('Charlie', d)] <= 1, f"BobCharlieConflict_Day{d}")
        
        # Charlie must be accompanied by Diana
        model.addConstr(x[('Charlie', d)] <= x[('Diana', d)], f"CharlieRequiresDiana_Day{d}")
        
        # Diana must be accompanied by Ella
        model.addConstr(x[('Diana', d)] <= x[('Ella', d)], f"DianaRequiresElla_Day{d}")
        
    # 7. Linking Constraints for y (Both Days)
    for c in children:
        model.addConstr(y[c] <= x[(c, 1)], f"Y_Limit1_{c}")
        model.addConstr(y[c] <= x[(c, 2)], f"Y_Limit2_{c}")
        model.addConstr(y[c] >= x[(c, 1)] + x[(c, 2)] - 1, f"Y_Min_{c}")
        
    # 8. Linking Constraints for z (Any Day)
    for c in children:
        model.addConstr(z[c] >= x[(c, 1)], f"Z_Gte1_{c}")
        model.addConstr(z[c] >= x[(c, 2)], f"Z_Gte2_{c}")
        model.addConstr(z[c] <= x[(c, 1)] + x[(c, 2)], f"Z_Lte_{c}")
        
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of infeasibility, still print something or handle error? 
        # Instructions say "Print exactly one line at the end: FINAL_OBJ_VALUE: <number>"
        # Assuming feasible solution exists based on problem type.
        # If not optimal, objVal might be None or NaN.
        # I will assume optimal for the output format requirement.
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
