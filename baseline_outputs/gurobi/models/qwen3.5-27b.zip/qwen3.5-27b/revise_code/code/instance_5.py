import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    # Load data
    table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'table_1.csv')
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    
    df = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)
    
    # Extract parameters
    budget = float(params[params['Parameter_Name'] == 'budget']['Value'].iloc[0])
    food_intake = float(params[params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
    weekday_budget_share = float(params[params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
    max_prep_time_weekday = float(params[params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
    max_prep_time_weekend = float(params[params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
    weekend_protein_ban = int(params[params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
    veg_balance_penalty = float(params[params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])
    
    # Fill missing fiber content with 0
    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)
    
    foods = df['Food'].tolist()
    types = df.set_index('Food')['Type'].to_dict()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()
    
    # Create model
    model = gp.Model("Dinner_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_weekday[f]: amount of food f in weekday dinner (100g units)
    # x_weekend[f]: amount of food f in weekend dinner (100g units)
    # y[f]: binary - is food f in shopping list?
    # z_p[f]: binary - is protein f selected?
    
    x_weekday = {f: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"x_weekday_{f}") for f in foods}
    x_weekend = {f: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"x_weekend_{f}") for f in foods}
    y = {f: model.addVar(vtype=GRB.BINARY, name=f"y_{f}") for f in foods}
    
    # Protein selection variables
    proteins = [f for f in foods if types[f] == 'protein']
    z_p = {f: model.addVar(vtype=GRB.BINARY, name=f"z_p_{f}") for f in proteins}
    
    # Vegetables
    vegetables = [f for f in foods if types[f] == 'vegetable']
    
    # Objective: maximize fiber - penalty for vegetable imbalance
    # Need to handle absolute value for penalty
    # Let's use auxiliary variable for the absolute difference
    
    veg_diff = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="veg_diff")
    
    # Objective
    obj = gp.quicksum(fiber[f] * (x_weekday[f] + x_weekend[f]) for f in foods) - veg_balance_penalty * veg_diff
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Food intake per dinner (500g = 5 units of 100g)
    model.addConstr(gp.quicksum(x_weekday[f] for f in foods) == food_intake / 100.0, "intake_weekday")
    model.addConstr(gp.quicksum(x_weekend[f] for f in foods) == food_intake / 100.0, "intake_weekend")
    
    # 2. Budget constraints
    weekday_budget = budget * weekday_budget_share
    weekend_budget = budget * (1 - weekday_budget_share)
    model.addConstr(gp.quicksum(price[f] * x_weekday[f] for f in foods) <= weekday_budget, "budget_weekday")
    model.addConstr(gp.quicksum(price[f] * x_weekend[f] for f in foods) <= weekend_budget, "budget_weekend")
    
    # 3. Prep time constraints
    model.addConstr(gp.quicksum(prep_time[f] * x_weekday[f] for f in foods) <= max_prep_time_weekday, "prep_weekday")
    model.addConstr(gp.quicksum(prep_time[f] * x_weekend[f] for f in foods) <= max_prep_time_weekend, "prep_weekend")
    
    # 4. Exactly one protein source selected
    model.addConstr(gp.quicksum(z_p[f] for f in proteins) == 1, "one_protein")
    
    # 5. At least two kinds of vegetables in shopping list
    model.addConstr(gp.quicksum(y[f] for f in vegetables) >= 2, "min_vegetables")
    
    # 6. Weekend protein ban
    if weekend_protein_ban == 1:
        for f in proteins:
            model.addConstr(x_weekend[f] == 0, f"no_protein_weekend_{f}")
    
    # 7. Linking constraints - if food is in shopping list, minimum amount
    M = food_intake / 100.0  # Maximum possible amount per food
    for f in foods:
        model.addConstr(x_weekday[f] >= 0.1 * y[f], f"min_weekday_{f}")
        model.addConstr(x_weekday[f] <= M * y[f], f"max_weekday_{f}")
        model.addConstr(x_weekend[f] >= 0.1 * y[f], f"min_weekend_{f}")
        model.addConstr(x_weekend[f] <= M * y[f], f"max_weekend_{f}")
    
    # 8. Protein label constraint - if protein is selected, it must appear in at least one meal
    for f in proteins:
        model.addConstr(z_p[f] <= y[f], f"protein_label_{f}")
        model.addConstr(x_weekday[f] + x_weekend[f] >= 0.1 * z_p[f], f"protein_appears_{f}")
    
    # 9. Vegetable balance penalty - absolute difference
    # veg_diff >= sum(veg_weekday) - sum(veg_weekend)
    # veg_diff >= sum(veg_weekend) - sum(veg_weekday)
    model.addConstr(veg_diff >= gp.quicksum(x_weekday[f] for f in vegetables) - gp.quicksum(x_weekend[f] for f in vegetables), "veg_diff_1")
    model.addConstr(veg_diff >= gp.quicksum(x_weekend[f] for f in vegetables) - gp.quicksum(x_weekday[f] for f in vegetables), "veg_diff_2")
    
    # Solve
    model.optimize()
    
    return round(model.objVal, 4)

if __name__ == '__main__':
    print(f"FINAL_OBJ_VALUE: {solve()}")
