import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    # Determine base directory relative to this script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, 'data', 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = row['Value']
            try:
                params[name] = int(val)
            except ValueError:
                try:
                    params[name] = float(val)
                except ValueError:
                    params[name] = val
    
    # Load student data
    students = []
    with open(os.path.join(base_dir, 'data', 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            s = {
                'Student_ID': int(row['Student_ID']),
                'Wage_CNY_per_hour': float(row['Wage_CNY_per_hour'])
            }
            for d in ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']:
                s[d] = float(row[d])
            students.append(s)
            
    return students, params

def main():
    students, params = load_data()
    
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    student_ids = [s['Student_ID'] for s in students]
    
    # Identify graduate students (IDs 5 and 6 based on description)
    grad_students = {5, 6}
    
    # Extract parameters
    min_undergrad_hours = params.get('min_undergrad_hours', 8)
    min_grad_hours = params.get('min_grad_hours', 7)
    max_shifts_per_student = params.get('max_shifts_per_student', 2)
    max_students_per_day = params.get('max_students_per_day', 3)
    daily_open_fee_cny = params.get('daily_open_fee_cny', 12)
    min_grad_weekly_coverage_hours = params.get('min_grad_weekly_coverage_hours', 16)
    
    # Lab operating hours per day (8AM to 10PM = 14 hours)
    hours_per_day = 14 
    
    # Wage and availability dictionaries
    wage = {s['Student_ID']: s['Wage_CNY_per_hour'] for s in students}
    avail = {(s['Student_ID'], d): s[d] for s in students for d in days}
    
    # Create Model
    model = gp.Model("Lab_Scheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    # x[i, d]: hours student i works on day d
    x = {}
    # y[i, d]: binary, 1 if student i works on day d
    y = {}
    
    for i in student_ids:
        for d in days:
            x[i, d] = model.addVar(lb=0, ub=avail[i, d], vtype=GRB.CONTINUOUS, name=f"x_{i}_{d}")
            y[i, d] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{d}")
    
    model.update()
    
    # Objective Function: Minimize Total Cost (Wages + Fixed Fees)
    obj_terms = []
    for i in student_ids:
        for d in days:
            obj_terms.append(wage[i] * x[i, d])
            obj_terms.append(daily_open_fee_cny * y[i, d])
    
    model.setObjective(gp.quicksum(obj_terms), GRB.MINIMIZE)
    
    # Constraint 1: Daily Coverage (Exactly 14 hours per day)
    for d in days:
        model.addConstr(gp.quicksum(x[i, d] for i in student_ids) == hours_per_day, name=f"coverage_{d}")
    
    # Constraint 2: Linking x and y (If x > 0, y must be 1)
    # x[i, d] <= avail[i, d] * y[i, d]
    for i in student_ids:
        for d in days:
            model.addConstr(x[i, d] <= avail[i, d] * y[i, d], name=f"link_{i}_{d}")
    
    # Constraint 3: Max shifts per student per week (Max 2 days)
    for i in student_ids:
        model.addConstr(gp.quicksum(y[i, d] for d in days) <= max_shifts_per_student, name=f"max_shifts_{i}")
    
    # Constraint 4: Max students per day (Max 3 students)
    for d in days:
        model.addConstr(gp.quicksum(y[i, d] for i in student_ids) <= max_students_per_day, name=f"max_students_{d}")
    
    # Constraint 5: Minimum weekly hours per student
    for i in student_ids:
        if i in grad_students:
            min_h = min_grad_hours
        else:
            min_h = min_undergrad_hours
        
        model.addConstr(gp.quicksum(x[i, d] for d in days) >= min_h, name=f"min_hours_{i}")
    
    # Constraint 6: Minimum graduate weekly coverage (Collective)
    grad_hours_sum = gp.quicksum(x[i, d] for i in grad_students for d in days)
    model.addConstr(grad_hours_sum >= min_grad_weekly_coverage_hours, name="min_grad_coverage")
    
    # Solve
    model.optimize()
    
    # Output Result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
