import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'table_1.csv')
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    
    # Parse process data
    a_I = float(rows[0][1])  # Model A hours for Process I
    b_I = float(rows[0][2])  # Model B hours for Process I
    cap_I = float(rows[0][3])  # Max weekly capacity Process I
    
    a_II = float(rows[1][1])  # Model A hours for Process II
    b_II = float(rows[1][2])  # Model B hours for Process II
    cap_II = float(rows[1][3])  # Max weekly capacity Process II
    
    profit_A = float(rows[2][1])  # Profit per unit Model A
    profit_B = float(rows[2][2])  # Profit per unit Model B
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Extract parameters
    min_total_profit = params['min_weekly_profit']
    min_total_A = params['min_model_A_units']
    min_total_B = params['min_model_B_units']
    week1_min_A = params['week1_min_model_A_units']
    week1_min_B = params['week1_min_model_B_units']
    week2_min_A = params['week2_min_model_A_units']
    week2_min_B = params['week2_min_model_B_units']
    normal_cap_I = params['process_I_hours']
    normal_cap_II = params['process_II_hours']
    max_ot_I = params['max_overtime_I_per_week']
    max_ot_II = params['max_overtime_II_per_week']
    ot_cost_I = params['overtime_premium_I']
    ot_cost_II = params['overtime_premium_II']
    min_util_I = params['min_avg_utilization_I']
    min_util_II = params['min_avg_utilization_II']
    ot_thresh_I = params['week1_overtime_fatigue_threshold_I']
    ot_thresh_II = params['week1_overtime_fatigue_threshold_II']
    recovery_loss_I = params['week2_recovery_loss_I']
    recovery_loss_II = params['week2_recovery_loss_II']
    
    # Create Gurobi model
    model = gp.Model("Microcomputer_Production_TwoWeek")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Production quantities
    x_A_w1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="x_A_w1")
    x_B_w1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="x_B_w1")
    x_A_w2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="x_A_w2")
    x_B_w2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="x_B_w2")
    
    # Overtime hours
    ot_I_w1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="ot_I_w1")
    ot_II_w1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="ot_II_w1")
    ot_I_w2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="ot_I_w2")
    ot_II_w2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="ot_II_w2")
    
    # Binary variable for recovery penalty (1 if week 1 overtime exceeds threshold)
    rec_I = model.addVar(vtype=GRB.BINARY, name="rec_I")
    rec_II = model.addVar(vtype=GRB.BINARY, name="rec_II")
    
    # Objective: Maximize net profit (gross profit - overtime costs)
    gross_profit = profit_A * (x_A_w1 + x_A_w2) + profit_B * (x_B_w1 + x_B_w2)
    ot_costs = ot_cost_I * (ot_I_w1 + ot_I_w2) + ot_cost_II * (ot_II_w1 + ot_II_w2)
    model.setObjective(gross_profit - ot_costs, GRB.MAXIMIZE)
    
    # Weekly production constraints
    model.addConstr(x_A_w1 >= week1_min_A, "w1_min_A")
    model.addConstr(x_B_w1 >= week1_min_B, "w1_min_B")
    model.addConstr(x_A_w2 >= week2_min_A, "w2_min_A")
    model.addConstr(x_B_w2 >= week2_min_B, "w2_min_B")
    
    # Total production constraints
    model.addConstr(x_A_w1 + x_A_w2 >= min_total_A, "total_min_A")
    model.addConstr(x_B_w1 + x_B_w2 >= min_total_B, "total_min_B")
    
    # Process capacity constraints (normal + overtime)
    # Week 1
    model.addConstr(a_I * x_A_w1 + b_I * x_B_w1 <= normal_cap_I + ot_I_w1, "cap_I_w1")
    model.addConstr(a_II * x_A_w1 + b_II * x_B_w1 <= normal_cap_II + ot_II_w1, "cap_II_w1")
    
    # Week 2 (with potential recovery loss)
    model.addConstr(a_I * x_A_w2 + b_I * x_B_w2 <= normal_cap_I + ot_I_w2 - recovery_loss_I * rec_I, "cap_I_w2")
    model.addConstr(a_II * x_A_w2 + b_II * x_B_w2 <= normal_cap_II + ot_II_w2 - recovery_loss_II * rec_II, "cap_II_w2")
    
    # Overtime limits
    model.addConstr(ot_I_w1 <= max_ot_I, "max_ot_I_w1")
    model.addConstr(ot_II_w1 <= max_ot_II, "max_ot_II_w1")
    model.addConstr(ot_I_w2 <= max_ot_I, "max_ot_I_w2")
    model.addConstr(ot_II_w2 <= max_ot_II, "max_ot_II_w2")
    
    # Recovery penalty trigger (big-M formulation)
    M = 1000  # Large enough value
    model.addConstr(ot_I_w1 - ot_thresh_I <= M * rec_I, "trigger_rec_I")
    model.addConstr(ot_I_w1 - ot_thresh_I >= epsilon - M * (1 - rec_I), "force_rec_I")
    model.addConstr(ot_II_w1 - ot_thresh_II <= M * rec_II, "trigger_rec_II")
    model.addConstr(ot_II_w1 - ot_thresh_II >= epsilon - M * (1 - rec_II), "force_rec_II")
    
    # Minimum average utilization constraints
    model.addConstr((a_I * x_A_w1 + b_I * x_B_w1 + a_I * x_A_w2 + b_I * x_B_w2) / (2 * normal_cap_I) >= min_util_I, "util_I")
    model.addConstr((a_II * x_A_w1 + b_II * x_B_w1 + a_II * x_A_w2 + b_II * x_B_w2) / (2 * normal_cap_II) >= min_util_II, "util_II")
    
    # Minimum total profit constraint
    model.addConstr(gross_profit - ot_costs >= min_total_profit, "min_profit")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
