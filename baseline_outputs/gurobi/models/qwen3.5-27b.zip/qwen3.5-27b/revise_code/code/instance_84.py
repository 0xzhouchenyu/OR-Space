import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load Candidates
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })

    # Load Params
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            try:
                params[key] = float(val)
            except ValueError:
                params[key] = val

    # Extract Params
    max_emp = int(params['max_employees'])
    budget = params['budget_limit']
    min_adv = int(params['min_advanced_degree_candidates'])
    min_exp = params['min_work_experience']
    max_eq = int(params['max_equivalent_candidates'])
    min_emp = int(params['min_employees'])
    min_mgr = int(params['min_managers'])
    max_mgr = int(params['max_managers'])
    min_mgr_exp = params['min_manager_experience']
    mgr_bonus = params['manager_bonus_per_candidate']

    # Model
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0)

    # Variables
    # y[i][role] where role is 'M' or 'S'
    y = {}
    for c in candidates:
        name = c['name']
        y[(name, 'M')] = model.addVar(vtype=GRB.BINARY, name=f"M_{name}")
        y[(name, 'S')] = model.addVar(vtype=GRB.BINARY, name=f"S_{name}")

    # Helper for hired status
    def is_hired(name):
        return y[(name, 'M')] + y[(name, 'S')]

    # Objective: Min Salary + Bonus
    obj = gp.quicksum(c['salary'] * is_hired(c['name']) for c in candidates)
    obj += gp.quicksum(mgr_bonus * y[(c['name'], 'M')] for c in candidates)
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    # 1. Total Employees
    model.addConstr(gp.quicksum(is_hired(c['name']) for c in candidates) >= min_emp)
    model.addConstr(gp.quicksum(is_hired(c['name']) for c in candidates) <= max_emp)

    # 2. Budget (Base Salary only)
    model.addConstr(gp.quicksum(c['salary'] * is_hired(c['name']) for c in candidates) <= budget)

    # 3. Advanced Degree
    advanced_names = [c['name'] for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(is_hired(name) for name in advanced_names) >= min_adv)

    # 4. Total Experience
    model.addConstr(gp.quicksum(c['experience'] * is_hired(c['name']) for c in candidates) >= min_exp)

    # 5. Equivalent Pair (A and E)
    # Check if A and E exist in candidates list
    names = [c['name'] for c in candidates]
    if 'A' in names and 'E' in names:
        model.addConstr(is_hired('A') + is_hired('E') <= max_eq)

    # 6. Role Constraints
    # Min/Max Managers
    model.addConstr(gp.quicksum(y[(c['name'], 'M')] for c in candidates) >= min_mgr)
    model.addConstr(gp.quicksum(y[(c['name'], 'M')] for c in candidates) <= max_mgr)

    # Manager Experience Floor
    model.addConstr(gp.quicksum(c['experience'] * y[(c['name'], 'M')] for c in candidates) >= min_mgr_exp)

    # One Role Per Person
    for c in candidates:
        model.addConstr(y[(c['name'], 'M')] + y[(c['name'], 'S')] <= 1)

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Fallback if no solution found, though problem implies feasible
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
