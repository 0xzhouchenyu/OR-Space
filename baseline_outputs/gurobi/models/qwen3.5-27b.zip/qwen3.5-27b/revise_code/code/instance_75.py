import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Determine path to data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')
params_file = os.path.join(data_dir, 'general_parameters.csv')

# Load parameters
params = load_parameters(params_file)

# Extract parameters
a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']

T1_norm = params['available_time_process_1']
T2_norm = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']

c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
bigM_disposal = params['bigM_disposal']

disposal_cost_base = params['disposal_cost_per_unit_c']
disposal_cost_high = params['disposal_cost_per_unit_c_high']

profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

# Create Model
model = gp.Model("MaxProfit_Revised")
model.setParam('OutputFlag', 0)

# Decision Variables
xA = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="xA")
xB = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="xB")
cSold = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="cSold")
cDisposed = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="cDisposed")

# High Throughput Mode Binary Variables
y1 = model.addVar(vtype=GRB.BINARY, name="y1") # Process 1 High
y2 = model.addVar(vtype=GRB.BINARY, name="y2") # Process 2 High

# Disposal Gate Binary Variable
z = model.addVar(vtype=GRB.BINARY, name="z") # 1 if disposal exceeds threshold

# Disposal Cost Tier Variables
c_base_rate = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="c_base_rate")
c_high_rate = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="c_high_rate")

# Objective Function
# Maximize Profit = Revenue - Disposal Cost
# Revenue = profit_a * xA + profit_b * xB + profit_c * cSold
# Cost = disposal_cost_base * c_base_rate + disposal_cost_high * c_high_rate
model.setObjective(
    profit_a * xA + profit_b * xB + profit_c * cSold 
    - disposal_cost_base * c_base_rate - disposal_cost_high * c_high_rate,
    GRB.MAXIMIZE
)

# Constraints

# 1. Process 1 Time Constraint (Conditional on High Throughput)
# Time <= T1_norm + y1 * (T1_high - T1_norm)
model.addConstr(
    a_p1 * xA + b_p1 * xB <= T1_norm + y1 * (T1_high - T1_norm),
    name="Process1Time"
)

# 2. Process 2 Time Constraint (Conditional on High Throughput)
# Time <= T2_norm + y2 * (T2_high - T2_norm)
model.addConstr(
    a_p2 * xA + b_p2 * xB <= T2_norm + y2 * (T2_high - T2_norm),
    name="Process2Time"
)

# 3. At most one reaction stage may use high-throughput
model.addConstr(y1 + y2 <= 1, name="MaxOneHighThroughput")

# 4. By-product C balance
model.addConstr(cSold + cDisposed == c_per_b * xB, name="ByproductBalance")

# 5. Maximum C that can be sold
model.addConstr(cSold <= max_c_sales, name="MaxCSales")

# 6. Disposal Gate Logic
# Total disposed = base part + high part
model.addConstr(cDisposed == c_base_rate + c_high_rate, name="DisposalSplit")

# If z=0 (under threshold): c_base_rate <= threshold, c_high_rate = 0
# If z=1 (over threshold): c_base_rate = 0, c_high_rate <= M
# Enforce c_base_rate limit based on z
model.addConstr(c_base_rate <= threshold_c * (1 - z), name="BaseRateLimit")

# Enforce c_high_rate limit based on z
model.addConstr(c_high_rate <= bigM_disposal * z, name="HighRateLimit")

# Enforce z=1 if cDisposed > threshold_c
# cDisposed <= threshold_c + M * z
model.addConstr(cDisposed <= threshold_c + bigM_disposal * z, name="ThresholdTrigger")

# Update model
model.update()

# Solve
model.optimize()

# Output results
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: 0")
