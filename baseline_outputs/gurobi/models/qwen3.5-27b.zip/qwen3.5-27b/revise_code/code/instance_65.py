import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
    for row in csv.DictReader(f):
        params[row['Parameter_Name'].strip()] = float(row['Value'])

# Load product data
products = {}
with open(os.path.join(data_dir, 'table_1.csv')) as f:
    for row in csv.DictReader(f):
        products[row['Product'].strip()] = {
            'a_hrs': float(row['Workshop_A_Hours']),
            'b_hrs': float(row['Workshop_B_Hours']),
            'insp_cost': float(row['Inspection_Sales_Cost'])
        }

m = products['Microwave_Oven']
w = products['Water_Heater']

# Create model
model = gp.Model("production_optimization")
model.setParam('OutputFlag', 0)

# Decision variables
x1 = model.addVar(lb=params['microwave_minimum_sales'], name="microwave")
x2 = model.addVar(lb=params['water_heater_minimum_sales'], name="water_heater")

# Binary variables for workshop A activation
y1 = model.addVar(vtype=GRB.BINARY, name="activate_microwave_A")
y2 = model.addVar(vtype=GRB.BINARY, name="activate_waterheater_A")

# Big-M value
bigM = params['bigM']

# Linking constraints: if production > 0, then y = 1
model.addConstr(x1 <= bigM * y1, name="link_microwave_A")
model.addConstr(x2 <= bigM * y2, name="link_waterheater_A")

# Workshop A hours constraint (including setup)
model.addConstr(
    m['a_hrs'] * x1 + w['a_hrs'] * x2 + 
    params['setup_hours_A'] * (y1 + y2) <= 
    params['workshop_a_available_hours'] + params['workshop_a_overtime_limit'],
    name="workshop_a_hours"
)

# Workshop B hours constraint
model.addConstr(
    m['b_hrs'] * x1 + w['b_hrs'] * x2 <= params['workshop_b_available_hours'],
    name="workshop_b_hours"
)

# Technician pool constraint
model.addConstr(
    params['tech_rate_m'] * x1 + params['tech_rate_w'] * x2 <= params['tech_pool_hours'],
    name="technician_pool"
)

# Inspection/sales cost constraint
model.addConstr(
    m['insp_cost'] * x1 + w['insp_cost'] * x2 <= params['inspection_sales_cost_limit'],
    name="inspection_sales_cost"
)

# Objective: Maximize profit
# Revenue components: workshop costs + inspection costs + green bonuses
# Actually looking at the original code, it seems like they're calculating some kind of revenue/profit
# Let me reconsider - the original was maximizing what looks like costs, which doesn't make sense

# Looking more carefully at the original heuristic:
# rev_m = m['a_hrs']*params['workshop_a_hourly_cost'] + m['b_hrs']*params['workshop_b_hourly_cost'] + m['insp_cost']
# This calculates the COST per unit, not revenue

# For a proper optimization, we should maximize profit = revenue - costs
# But we don't have selling price information in the data

# Given the context and the fact that the original was trying to maximize something related to these values,
# I'll assume we want to maximize the green bonus minus the additional costs incurred

# Actually, re-reading the problem: the company wants to optimize production planning
# The most logical interpretation is to maximize profit where:
# - Costs include: workshop hours * hourly cost + inspection/sales cost
# - Benefits include: green bonus for certified products

# Since we don't have selling prices, let's focus on minimizing costs while meeting requirements
# OR maximize the net benefit (green bonus - additional costs)

# Given the original code structure maximized something, I'll create a reasonable objective:
# Maximize: green_bonus - (workshop costs + inspection costs)
# But this would likely be negative...

# Alternative interpretation: The company wants to maximize production value considering all factors
# Let's maximize: green_bonus contribution (since that's the new incentive)

# Most sensible approach: Minimize total cost while meeting minimum requirements
# Total cost = workshop costs + inspection costs - green bonuses

# Let me calculate the objective properly:
# Cost per microwave = m['a_hrs']*80 + m['b_hrs']*20 + m['insp_cost'] - green_bonus_m*y1
# Cost per water heater = w['a_hrs']*80 + w['b_hrs']*20 + w['insp_cost'] - green_bonus_w*y2

# Since we want to minimize cost (or maximize negative cost), let's set up:
# Maximize: -(total_cost) = green_bonus - (workshop_costs + inspection_costs)

cost_per_m = m['a_hrs'] * params['workshop_a_hourly_cost'] + \
             m['b_hrs'] * params['workshop_b_hourly_cost'] + \
             m['insp_cost']

cost_per_w = w['a_hrs'] * params['workshop_a_hourly_cost'] + \
             w['b_hrs'] * params['workshop_b_hourly_cost'] + \
             w['insp_cost']

# Objective: Maximize net benefit (green bonus - costs)
# Or equivalently: Minimize (costs - green bonus)
# Since Gurobi can do both, let's maximize: green_bonus - costs

obj = (params['green_bonus_m'] * y1 * x1 + params['green_bonus_w'] * y2 * x2 - 
       cost_per_m * x1 - cost_per_w * x2)

# Wait, this creates a non-linear term (y1 * x1). We need to linearize this.
# When y1 = 1, we get green_bonus_m * x1
# When y1 = 0, we get 0

# Linearization: introduce auxiliary variables z1 = y1 * x1, z2 = y2 * x2
z1 = model.addVar(name="bonus_microwave")
z2 = model.addVar(name="bonus_waterheater")

# z1 <= M * y1
# z1 <= x1
# z1 >= x1 - M * (1 - y1)
# z1 >= 0

model.addConstr(z1 <= bigM * y1, name="z1_upper_y")
model.addConstr(z1 <= x1, name="z1_upper_x")
model.addConstr(z1 >= x1 - bigM * (1 - y1), name="z1_lower")
model.addConstr(z1 >= 0, name="z1_nonneg")

model.addConstr(z2 <= bigM * y2, name="z2_upper_y")
model.addConstr(z2 <= x2, name="z2_upper_x")
model.addConstr(z2 >= x2 - bigM * (1 - y2), name="z2_lower")
model.addConstr(z2 >= 0, name="z2_nonneg")

# Now objective becomes linear
model.setObjective(
    params['green_bonus_m'] * z1 + params['green_bonus_w'] * z2 - 
    cost_per_m * x1 - cost_per_w * x2,
    GRB.MAXIMIZE
)

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.objVal}")
