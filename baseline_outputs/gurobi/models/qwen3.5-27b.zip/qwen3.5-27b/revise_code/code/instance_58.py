import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            # Handle potential float/int conversion
            try:
                value = float(value_str)
            except ValueError:
                value = value_str
            params[name] = value
    return params

def solve():
    # Paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    param_file = os.path.join(data_dir, 'general_parameters.csv')
    
    params = load_parameters(param_file)
    
    # Extract Params
    profits = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons'],
    }
    
    total_area = params['total_farm_area']
    min_a_p = params['min_apples_to_pears_ratio']
    min_a_l = params['min_apples_to_lemons_ratio']
    o_l = params['oranges_to_lemons_ratio']
    max_types = int(params['max_fruit_types'])
    
    water_params = {
        'apples': {'spring': params['water_per_acre_apples_spring'], 'autumn': params['water_per_acre_apples_autumn']},
        'pears': {'spring': params['water_per_acre_pears_spring'], 'autumn': params['water_per_acre_pears_autumn']},
        'oranges': {'spring': params['water_per_acre_oranges_spring'], 'autumn': params['water_per_acre_oranges_autumn']},
        'lemons': {'spring': params['water_per_acre_lemons_spring'], 'autumn': params['water_per_acre_lemons_autumn']},
    }
    
    cap_spring = params['water_cap_spring']
    cap_autumn = params['water_cap_autumn']
    total_water = params['total_water_budget']
    min_water_fruit = params['min_annual_water_per_fruit']
    div_reward = params['diversification_reward']
    
    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']
    
    model = gp.Model("Farm_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Variables
    # x[f][s]: acres
    x = {}
    for f in fruits:
        for s in seasons:
            x[f, s] = model.addVar(lb=0, name=f"x_{f}_{s}")
            
    # z[f]: binary, is fruit active?
    z = {}
    for f in fruits:
        z[f] = model.addVar(vtype=GRB.BINARY, name=f"z_{f}")
        
    # y_div: binary, diversification active?
    y_div = model.addVar(vtype=GRB.BINARY, name="y_div")
    
    # Constraints
    
    # 1. Land per season
    for s in seasons:
        model.addConstr(gp.quickSum(x[f, s] for f in fruits) <= total_area, name=f"land_{s}")
        
    # 2. Water per season
    model.addConstr(gp.quickSum(water_params[f]['spring'] * x[f, 'spring'] for f in fruits) <= cap_spring, name="water_spring")
    model.addConstr(gp.quickSum(water_params[f]['autumn'] * x[f, 'autumn'] for f in fruits) <= cap_autumn, name="water_autumn")
    
    # 3. Total Water
    model.addConstr(gp.quickSum(water_params[f][s] * x[f, s] for f in fruits for s in seasons) <= total_water, name="water_total")
    
    # 4. Annual Totals for Ratios
    # A_f = x[f, spring] + x[f, autumn]
    # Helper expression for annual acres
    annual_acres = {f: x[f, 'spring'] + x[f, 'autumn'] for f in fruits}
    
    # Ratios
    model.addConstr(annual_acres['apples'] >= min_a_p * annual_acres['pears'], name="ratio_ap")
    model.addConstr(annual_acres['apples'] >= min_a_l * annual_acres['lemons'], name="ratio_al")
    model.addConstr(annual_acres['oranges'] == o_l * annual_acres['lemons'], name="ratio_ol")
    
    # 5. Fruit Selection & Water Threshold
    # W_f = sum(water * x)
    # W_f >= min_water * z_f
    # W_f <= M * z_f
    M = total_water # Safe big M
    
    for f in fruits:
        W_f = gp.quickSum(water_params[f][s] * x[f, s] for s in seasons)
        model.addConstr(W_f >= min_water_fruit * z[f], name=f"min_water_{f}")
        model.addConstr(W_f <= M * z[f], name=f"max_water_{f}")
        
    # Max fruit types
    model.addConstr(gp.quickSum(z[f] for f in fruits) <= max_types, name="max_types")
    
    # 6. Diversification
    # sum(z) >= 2 * y_div
    model.addConstr(gp.quickSum(z[f] for f in fruits) >= 2 * y_div, name="div_condition")
    
    # Objective
    # Profit = sum(profit * annual_acres) + div_reward * y_div
    obj_expr = gp.quickSum(profits[f] * annual_acres[f] for f in fruits) + div_reward * y_div
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
