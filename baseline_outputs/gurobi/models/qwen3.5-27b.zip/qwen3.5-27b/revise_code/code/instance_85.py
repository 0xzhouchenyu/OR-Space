import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'table_1.csv')
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    machine_avail = params['machine_time_available']  # hours
    craftsman_regular_avail = params['craftsman_regular_time_available']  # hours
    craftsman_overtime_avail = params['craftsman_overtime_available']  # hours
    machine_cost = params['machine_time_cost']  # GBP per hour
    craftsman_regular_cost = params['craftsman_time_cost']  # GBP per hour (regular)
    craftsman_overtime_cost = params['craftsman_overtime_cost']  # GBP per hour
    rev_X = params['revenue_product_X']  # GBP per batch
    rev_Y = params['revenue_product_Y']  # GBP per batch
    min_X = params['min_batches_product_X']  # batches
    y_qa_threshold = params['product_Y_QA_threshold']  # batches
    y_qa_fee = params['product_Y_QA_fee']  # GBP
    
    # Create MIP model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    X = model.addVar(lb=0, name="X")  # Batches of product X
    Y = model.addVar(lb=0, name="Y")  # Batches of product Y
    
    # Craftsman time variables
    craftsman_regular_used = model.addVar(lb=0, name="craftsman_regular_used")
    craftsman_overtime_used = model.addVar(lb=0, name="craftsman_overtime_used")
    
    # Binary variable for QA fee (1 if Y > 60, 0 otherwise)
    qa_fee_active = model.addVar(vtype=GRB.BINARY, name="qa_fee_active")
    
    # Calculate machine hours used
    machine_hours_used = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0
    
    # Calculate total craftsman hours needed
    total_craftsman_hours_needed = (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0
    
    # Objective: maximize revenue - costs
    profit = (rev_X * X + rev_Y * Y 
              - machine_cost * machine_hours_used 
              - craftsman_regular_cost * craftsman_regular_used 
              - craftsman_overtime_cost * craftsman_overtime_used
              - y_qa_fee * qa_fee_active)
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Constraints
    # Machine time constraint
    model.addConstr(machine_hours_used <= machine_avail, "Machine_Time_Constraint")
    
    # Total craftsman time equals sum of regular and overtime
    model.addConstr(craftsman_regular_used + craftsman_overtime_used == total_craftsman_hours_needed, "Total_Craftsman_Time")
    
    # Regular craftsman time limit
    model.addConstr(craftsman_regular_used <= craftsman_regular_avail, "Regular_Craftsman_Limit")
    
    # Overtime craftsman time limit
    model.addConstr(craftsman_overtime_used <= craftsman_overtime_avail, "Overtime_Craftsman_Limit")
    
    # Minimum production of X
    model.addConstr(X >= min_X, "Min_Production_X")
    
    # QA fee trigger: if Y > 60, then qa_fee_active = 1
    # Using big-M formulation: Y <= 60 + M * qa_fee_active
    # And: Y >= 60 + epsilon - M * (1 - qa_fee_active)
    M = 1000  # Large enough value
    epsilon = 0.001
    
    # If qa_fee_active = 0, then Y <= 60
    model.addConstr(Y <= y_qa_threshold + M * qa_fee_active, "QA_Fee_Trigger_1")
    
    # If qa_fee_active = 1, then Y >= 60 + epsilon (to ensure fee is charged when above threshold)
    model.addConstr(Y >= y_qa_threshold + epsilon - M * (1 - qa_fee_active), "QA_Fee_Trigger_2")
    
    # Solve
    model.optimize()
    
    obj_val = model.objVal
    
    print(f"FINAL_OBJ_VALUE: {obj_val:.2f}")

if __name__ == "__main__":
    main()
