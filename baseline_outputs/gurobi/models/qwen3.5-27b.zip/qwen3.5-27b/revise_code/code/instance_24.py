import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Extract parameters
    product_units = int(params['product_units'])
    truck_pollution = params['truck_pollution']
    van_pollution = params['van_pollution']
    motorcycle_pollution = params['motorcycle_pollution']
    ev_pollution = params['electric_vehicle_pollution']
    max_total_pollution = params['max_total_pollution']
    min_truck_trips = int(params['min_truck_trips'])
    truck_capacity = params['truck_capacity']
    van_capacity = params['van_capacity']
    motorcycle_capacity = params['motorcycle_capacity']
    ev_capacity = params['electric_vehicle_capacity']
    
    # Sales point shares
    sp1_share = params['sales_point_share_sp1']
    sp2_share = params['sales_point_share_sp2']
    sp3_share = params['sales_point_share_sp3']
    
    # Min truck share per sales point
    min_truck_share_sp1 = params['min_truck_share_sp1']
    min_truck_share_sp2 = params['min_truck_share_sp2']
    min_truck_share_sp3 = params['min_truck_share_sp3']
    
    # Big-M values
    M_truck = params['M_truck_sp_day']
    M_ev = params['M_ev_sp_day']
    M_van = params['M_van_sp_day']
    M_moto = params['M_moto_sp_day']
    
    # Define sets
    sales_points = ['sp1', 'sp2', 'sp3']
    days = [1, 2, 3]
    vehicles = ['truck', 'van', 'motorcycle', 'ev']
    
    # Create model
    model = gp.Model("Transportation_Pollution_Minimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: trips by vehicle, sales point, day
    x = {}
    for v in vehicles:
        for sp in sales_points:
            for d in days:
                x[(v, sp, d)] = model.addVar(vtype=GRB.INTEGER, name=f"x_{v}_{sp}_d{d}")
    
    # Binary variables for vehicle family selection per sales point-day
    z = {}
    for sp in sales_points:
        for d in days:
            z[(sp, d)] = model.addVar(vtype=GRB.BINARY, name=f"z_{sp}_d{d}")
    
    # Objective: minimize total pollution
    obj = 0
    for v in vehicles:
        for sp in sales_points:
            for d in days:
                if v == 'truck':
                    obj += truck_pollution * x[(v, sp, d)]
                elif v == 'van':
                    obj += van_pollution * x[(v, sp, d)]
                elif v == 'motorcycle':
                    obj += motorcycle_pollution * x[(v, sp, d)]
                elif v == 'ev':
                    obj += ev_pollution * x[(v, sp, d)]
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraint: Demand satisfaction per sales point
    for i, sp in enumerate(sales_points):
        share = [sp1_share, sp2_share, sp3_share][i]
        demand = product_units * share
        
        cap_expr = 0
        for v in vehicles:
            for d in days:
                if v == 'truck':
                    cap_expr += truck_capacity * x[(v, sp, d)]
                elif v == 'van':
                    cap_expr += van_capacity * x[(v, sp, d)]
                elif v == 'motorcycle':
                    cap_expr += motorcycle_capacity * x[(v, sp, d)]
                elif v == 'ev':
                    cap_expr += ev_capacity * x[(v, sp, d)]
        
        model.addConstr(cap_expr >= demand, name=f"demand_{sp}")
    
    # Constraint: Vehicle family selection (binary gate)
    # If z[sp,d] = 1: truck/EV family allowed, van/motorcycle = 0
    # If z[sp,d] = 0: van/motorcycle family allowed, truck/EV = 0
    
    for sp in sales_points:
        for d in days:
            # When z=1, van and motorcycle must be 0
            model.addConstr(x[('van', sp, d)] <= M_van * (1 - z[(sp, d)]))
            model.addConstr(x[('motorcycle', sp, d)] <= M_moto * (1 - z[(sp, d)]))
            
            # When z=0, truck and EV must be 0
            model.addConstr(x[('truck', sp, d)] <= M_truck * z[(sp, d)])
            model.addConstr(x[('ev', sp, d)] <= M_ev * z[(sp, d)])
    
    # Constraint: Total pollution limit
    poll_expr = 0
    for v in vehicles:
        for sp in sales_points:
            for d in days:
                if v == 'truck':
                    poll_expr += truck_pollution * x[(v, sp, d)]
                elif v == 'van':
                    poll_expr += van_pollution * x[(v, sp, d)]
                elif v == 'motorcycle':
                    poll_expr += motorcycle_pollution * x[(v, sp, d)]
                elif v == 'ev':
                    poll_expr += ev_pollution * x[(v, sp, d)]
    
    model.addConstr(poll_expr <= max_total_pollution, name="max_pollution")
    
    # Constraint: Minimum total truck trips
    truck_trips_expr = 0
    for sp in sales_points:
        for d in days:
            truck_trips_expr += x[('truck', sp, d)]
    
    model.addConstr(truck_trips_expr >= min_truck_trips, name="min_truck_trips")
    
    # Constraint: Minimum truck share per sales point
    for i, sp in enumerate(sales_points):
        min_share = [min_truck_share_sp1, min_truck_share_sp2, min_truck_share_sp3][i]
        
        truck_trips_sp = 0
        total_trips_sp = 0
        for d in days:
            truck_trips_sp += x[('truck', sp, d)]
            for v in vehicles:
                total_trips_sp += x[(v, sp, d)]
        
        # truck_trips / total_trips >= min_share
        # truck_trips >= min_share * total_trips
        # truck_trips - min_share * total_trips >= 0
        model.addConstr(truck_trips_sp - min_share * total_trips_sp >= 0, name=f"min_truck_share_{sp}")
    
    # Solve
    model.optimize()
    
    # Print solution
    print(f"Status: {model.Status}")
    
    if model.Status == GRB.OPTIMAL:
        for v in vehicles:
            for sp in sales_points:
                for d in days:
                    val = x[(v, sp, d)].X
                    if val > 0:
                        print(f"{v} trips to {sp} on day {d}: {val}")
        
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found")

if __name__ == "__main__":
    main()
