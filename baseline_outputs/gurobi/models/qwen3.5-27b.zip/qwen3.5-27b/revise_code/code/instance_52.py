import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    
    n = len(shifts)  # number of periods (6)
    required = [s['required'] for s in shifts]
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    
    shift_duration = int(params['shift_duration'])  # 8 hours
    max_night_driver_fraction = float(params['max_night_driver_fraction'])  # 0.4
    max_night_crew_fraction = float(params['max_night_crew_fraction'])  # 0.5
    max_overtime_shifts = int(params['max_overtime_shifts'])  # 20
    overtime_cost_factor = float(params['overtime_cost_factor'])  # 1.5
    
    # Each time period is 4 hours, shift_duration is 8 hours = 2 periods
    periods_per_shift = shift_duration // 4  # = 2
    
    # Create model
    model = gp.Model("BusScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # d_reg[i] = regular driver shifts starting at period i
    # d_ot[i] = overtime driver shifts starting at period i
    # c_reg[i] = regular crew shifts starting at period i
    # c_ot[i] = overtime crew shifts starting at period i
    d_reg = model.addVars(n, vtype=GRB.INTEGER, name="d_reg")
    d_ot = model.addVars(n, vtype=GRB.INTEGER, name="d_ot")
    c_reg = model.addVars(n, vtype=GRB.INTEGER, name="c_reg")
    c_ot = model.addVars(n, vtype=GRB.INTEGER, name="c_ot")
    
    # Objective: minimize total cost (regular + 1.5 * overtime)
    model.setObjective(
        gp.quicksum(d_reg[i] for i in range(n)) +
        gp.quicksum(c_reg[i] for i in range(n)) +
        overtime_cost_factor * (gp.quicksum(d_ot[i] for i in range(n)) + 
                               gp.quicksum(c_ot[i] for i in range(n))),
        GRB.MINIMIZE
    )
    
    # Coverage constraints for drivers
    for j in range(n):
        covering = []
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                covering.append(d_reg[i] + d_ot[i])
        model.addConstr(gp.quicksum(covering) >= required[j], f"DriverCoverage_{j}")
    
    # Coverage constraints for crew
    for j in range(n):
        covering = []
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                covering.append(c_reg[i] + c_ot[i])
        model.addConstr(gp.quicksum(covering) >= required[j], f"CrewCoverage_{j}")
    
    # Night start fraction constraints (periods 4 and 5 are late-night)
    night_periods = [4, 5]
    
    # Driver night fraction: night_starts <= 0.4 * total_starts
    driver_night = gp.quicksum(d_reg[i] + d_ot[i] for i in night_periods)
    driver_total = gp.quicksum(d_reg[i] + d_ot[i] for i in range(n))
    model.addConstr(driver_night <= max_night_driver_fraction * driver_total, "DriverNightFraction")
    
    # Crew night fraction: night_starts <= 0.5 * total_starts
    crew_night = gp.quicksum(c_reg[i] + c_ot[i] for i in night_periods)
    crew_total = gp.quicksum(c_reg[i] + c_ot[i] for i in range(n))
    model.addConstr(crew_night <= max_night_crew_fraction * crew_total, "CrewNightFraction")
    
    # Total overtime constraint
    model.addConstr(
        gp.quicksum(d_ot[i] for i in range(n)) + 
        gp.quicksum(c_ot[i] for i in range(n)) <= max_overtime_shifts,
        "MaxOvertime"
    )
    
    # Solve
    model.optimize()
    
    # Print solution
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
