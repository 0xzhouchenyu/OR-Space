import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Set up paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

def load_csv(filename):
    """Load a CSV file and return a list of dictionaries."""
    filepath = os.path.join(data_dir, filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

def load_general_parameters(filename='general_parameters.csv'):
    """Load general parameters into a dictionary."""
    rows = load_csv(filename)
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = row['Value']
        # Try to convert to numeric
        try:
            if '.' in value:
                params[name] = float(value)
            else:
                params[name] = int(value)
        except ValueError:
            params[name] = value
    return params

def load_task_methods(filename='table_1.csv'):
    """Load task-method data."""
    rows = load_csv(filename)
    data = []
    for row in rows:
        data.append({
            'Task': row['Task'],
            'Method': row['Method'],
            'Effective_Hours': float(row['Effective_Hours']),
            'Fixed_Cost': float(row['Fixed_Cost'])
        })
    return data

# Load data
params = load_general_parameters()
task_methods = load_task_methods()

# Extract parameters
skilled_wage = params['skilled_worker_weekly_wage']  # 110
laborer_wage = params['laborer_weekly_wage']  # 80
skilled_hours = params['skilled_worker_weekly_hours']  # 42
laborer_hours = params['laborer_weekly_hours']  # 36
max_skilled = params['max_skilled_workers']  # 430
max_laborers = params['max_laborers']  # 800
min_skilled_task3_B = params['min_skilled_workers_task3_methodB']  # 20
skilled_hiring_ratio = params['skilled_worker_hiring_ratio']  # 0.6

# Task-specific skill share bounds
min_skilled_share_task1 = params['min_skilled_share_task1']  # 0.30
max_skilled_share_task1 = params['max_skilled_share_task1']  # 0.70
min_skilled_share_task2 = params['min_skilled_share_task2']  # 0.10
max_skilled_share_task2 = params['max_skilled_share_task2']  # 0.50
min_skilled_share_task3 = params['min_skilled_share_task3']  # 0.20
max_skilled_share_task3 = params['max_skilled_share_task3']  # 0.60

# Organize task-method data
tasks = ['Task_1', 'Task_2', 'Task_3']
methods = ['Method_A', 'Method_B']

# Build dictionary: (task, method) -> {Effective_Hours, Fixed_Cost}
tm_data = {}
for row in task_methods:
    key = (row['Task'], row['Method'])
    tm_data[key] = row

# Create the model
model = gp.Model("WorkerAllocation")
model.setParam('OutputFlag', 0)

# Decision variables

# Binary: y[task][method] = 1 if method is chosen for task
y = {}
for t in tasks:
    for m in methods:
        y[t, m] = model.addVar(vtype=GRB.BINARY, name=f"y_{t}_{m}")

# Continuous: number of skilled workers assigned to (task, method)
s = {}
for t in tasks:
    for m in methods:
        s[t, m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"s_{t}_{m}")

# Continuous: number of laborers assigned to (task, method)
l = {}
for t in tasks:
    for m in methods:
        l[t, m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"l_{t}_{m}")

# Total skilled workers and laborers
total_skilled = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_skilled")
total_laborers = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_laborers")

# Objective: minimize total weekly cost (wages + fixed costs)
objective = (skilled_wage * total_skilled + laborer_wage * total_laborers +
             gp.quicksum(tm_data[t, m]['Fixed_Cost'] * y[t, m] for t in tasks for m in methods))
model.setObjective(objective, GRB.MINIMIZE)

# Constraints

# Total skilled = sum of skilled workers across chosen methods
model.addConstr(total_skilled == gp.quicksum(s[t, m] for t in tasks for m in methods), "TotalSkilledDef")
model.addConstr(total_laborers == gp.quicksum(l[t, m] for t in tasks for m in methods), "TotalLaborersDef")

# Exactly one method per task
for t in tasks:
    model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1, f"OneMethod_{t}")

# Hours requirement: for each task, the chosen method must meet effective hours
M_big = 10000  # Big-M

for t in tasks:
    for m in methods:
        req_hours = tm_data[t, m]['Effective_Hours']
        # Hours constraint
        model.addConstr(skilled_hours * s[t, m] + laborer_hours * l[t, m] >= req_hours * y[t, m],
                        f"Hours_{t}_{m}")
        # Linking: if y=0, then s and l must be 0
        model.addConstr(s[t, m] <= M_big * y[t, m], f"LinkS_{t}_{m}")
        model.addConstr(l[t, m] <= M_big * y[t, m], f"LinkL_{t}_{m}")

# Max constraints
model.addConstr(total_skilled <= max_skilled, "MaxSkilled")
model.addConstr(total_laborers <= max_laborers, "MaxLaborers")

# Skilled workers cannot exceed 60% of total laborers
model.addConstr(total_skilled <= skilled_hiring_ratio * total_laborers, "SkilledRatio")

# Exclusion rule: Task 1 using Method B excludes Task 3 using Method A
model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1, "ExclusionRule")

# Minimum skilled workers for Task 3 if Method B is chosen
model.addConstr(s['Task_3', 'Method_B'] >= min_skilled_task3_B * y['Task_3', 'Method_B'], "MinSkilledTask3B")

# Task-level skill-balance bands
# For each task, the skilled share must be between min and max bounds
# Skilled share = s[t,m] / (s[t,m] + l[t,m]) when y[t,m] = 1
# This means: min_share * (s + l) <= s <= max_share * (s + l)
# Which simplifies to: min_share * l <= (1 - min_share) * s and (1 - max_share) * s >= max_share * l

for t_idx, t in enumerate(tasks):
    if t == 'Task_1':
        min_share = min_skilled_share_task1
        max_share = max_skilled_share_task1
    elif t == 'Task_2':
        min_share = min_skilled_share_task2
        max_share = max_skilled_share_task2
    else:  # Task_3
        min_share = min_skilled_share_task3
        max_share = max_skilled_share_task3
    
    for m in methods:
        # When y[t,m] = 1, enforce skill balance
        # min_share <= s/(s+l) <= max_share
        # Equivalent to: min_share*(s+l) <= s and s <= max_share*(s+l)
        # Rearranging: min_share*l <= (1-min_share)*s and (1-max_share)*s >= max_share*l
        
        # Lower bound: min_share * (s + l) <= s
        # => min_share * s + min_share * l <= s
        # => min_share * l <= (1 - min_share) * s
        model.addConstr(min_share * l[t, m] <= (1 - min_share) * s[t, m] + M_big * (1 - y[t, m]), 
                        f"SkillBalanceLower_{t}_{m}")
        
        # Upper bound: s <= max_share * (s + l)
        # => s <= max_share * s + max_share * l
        # => (1 - max_share) * s <= max_share * l
        model.addConstr((1 - max_share) * s[t, m] <= max_share * l[t, m] + M_big * (1 - y[t, m]), 
                        f"SkillBalanceUpper_{t}_{m}")

# Optimize
model.optimize()

# Get objective value
obj_val = model.objVal

print(f"FINAL_OBJ_VALUE: {obj_val}")
