import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')

    # Load General Parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            val = row['Value']
            try:
                params[key] = float(val)
            except ValueError:
                params[key] = val

    # Load Toy Data
    toys = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                'type': row['Toy_Type'].strip(),
                'profit': float(row['Profit_Per_Unit']),
                'wood': float(row['Wood_Required_Per_Unit']),
                'steel': float(row['Steel_Required_Per_Unit'])
            })

    # Extract Parameters
    available_wood = params['available_wood']
    available_steel = params['available_steel']
    profit_premium_bonus = params['profit_premium_bonus']
    premium_steel_factor = params['premium_steel_factor']
    premium_shift_capacity = params['premium_shift_capacity']

    # Create Model
    model = gp.Model("HausToys_Revised")
    model.setParam('OutputFlag', 0)

    # Constants
    M = 1000  # Big M
    shifts = ['Standard', 'Premium']
    toy_types = [t['type'] for t in toys]

    # Decision Variables
    # x[t][s]: Quantity of toy t on shift s
    x = {}
    for t in toy_types:
        for s in shifts:
            x[(t, s)] = model.addVar(lb=0, name=f"x_{t}_{s}")

    # z[t][s]: Binary, 1 if toy t is produced on shift s
    z = {}
    for t in toy_types:
        for s in shifts:
            z[(t, s)] = model.addVar(vtype=GRB.BINARY, name=f"z_{t}_{s}")

    # Helper to get toy attributes
    def get_toy_attr(t):
        for toy in toys:
            if toy['type'] == t:
                return toy
        return None

    # Objective Function
    # Maximize Profit
    obj_expr = gp.quicksum(
        (get_toy_attr(t)['profit'] + (profit_premium_bonus if s == 'Premium' else 0)) * x[(t, s)]
        for t in toy_types for s in shifts
    )
    model.setObjective(obj_expr, GRB.MAXIMIZE)

    # Resource Constraints
    # Wood: Sum(wood_req * x) <= available_wood
    wood_expr = gp.quicksum(
        get_toy_attr(t)['wood'] * x[(t, s)]
        for t in toy_types for s in shifts
    )
    model.addConstr(wood_expr <= available_wood, "Wood_Constraint")

    # Steel: Sum(steel_req * factor * x) <= available_steel
    steel_expr = gp.quicksum(
        get_toy_attr(t)['steel'] * (premium_steel_factor if s == 'Premium' else 1.0) * x[(t, s)]
        for t in toy_types for s in shifts
    )
    model.addConstr(steel_expr <= available_steel, "Steel_Constraint")

    # Premium Shift Capacity
    premium_cap_expr = gp.quicksum(x[(t, 'Premium')] for t in toy_types)
    model.addConstr(premium_cap_expr <= premium_shift_capacity, "Premium_Capacity")

    # Shift Exclusivity & Linking
    # Each toy type can be on at most one shift
    for t in toy_types:
        model.addConstr(z[(t, 'Standard')] + z[(t, 'Premium')] <= 1, f"Shift_Exclusivity_{t}")
        
        # Link x to z
        model.addConstr(x[(t, 'Standard')] <= M * z[(t, 'Standard')], f"Link_{t}_Standard")
        model.addConstr(x[(t, 'Premium')] <= M * z[(t, 'Premium')], f"Link_{t}_Premium")

    # Business Logic Constraints
    
    # 1. Truck-Train Exclusion: If trucks (any shift) -> No trains (any shift)
    # Sum(z_truck) + Sum(z_train) <= 1
    truck_prod = z[('truck', 'Standard')] + z[('truck', 'Premium')]
    train_prod = z[('train', 'Standard')] + z[('train', 'Premium')]
    model.addConstr(truck_prod + train_prod <= 1, "Truck_Train_Exclusion")

    # 2. Boat-Airplane Dependency: If boats (any shift) -> Airplanes (any shift)
    # Sum(z_boat) <= Sum(z_airplane)
    boat_prod = z[('boat', 'Standard')] + z[('boat', 'Premium')]
    airplane_prod = z[('airplane', 'Standard')] + z[('airplane', 'Premium')]
    model.addConstr(boat_prod <= airplane_prod, "Boat_Airplane_Dependency")

    # 3. Boat-Train Limit: Total boats <= Total trains
    # Sum(x_boat) <= Sum(x_train)
    total_boats = x[('boat', 'Standard')] + x[('boat', 'Premium')]
    total_trains = x[('train', 'Standard')] + x[('train', 'Premium')]
    model.addConstr(total_boats <= total_trains, "Boat_Train_Limit")

    # Solve
    model.optimize()

    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
    else:
        print(f"FINAL_OBJ_VALUE: 0.00")

if __name__ == "__main__":
    main()
