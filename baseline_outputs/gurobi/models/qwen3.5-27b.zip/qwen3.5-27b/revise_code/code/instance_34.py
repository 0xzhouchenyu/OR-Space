import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    # Determine base directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load parameters
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[key] = val
            
    # Load goods
    goods_path = os.path.join(base_dir, "data", "table_1.csv")
    goods = {}
    with open(goods_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            g_type = row['Goods_Type'].strip()
            goods[g_type] = {
                'quantity': int(row['Quantity'].strip()),
                'weight': float(row['Weight_per_Unit'].strip())
            }
            
    return params, goods

def main():
    params, goods = load_data()
    
    max_cap = params['max_container_capacity']
    min_load = params['min_container_load']
    min_d = int(params['min_d_goods_per_container'])
    min_c_per_a = int(params['min_c_per_a'])
    
    goods_types = list(goods.keys())
    quantities = {g: goods[g]['quantity'] for g in goods_types}
    weights = {g: goods[g]['weight'] for g in goods_types}
    
    # Calculate upper bound on containers based on D constraint
    # Total D = 90, Min D per container = 10 -> Max containers = 9
    # We add a small buffer just in case, but 10 is safe.
    max_containers = 10 
    N = range(max_containers)
    
    # Create Model
    model = gp.Model("ContainerMinimization")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    # x[g][j]: units of good g in container j
    x = {}
    for g in goods_types:
        x[g] = model.addVars(N, lb=0, vtype=GRB.INTEGER, name=f"x_{g}")
        
    # y[j]: 1 if container j is used
    y = model.addVars(N, vtype=GRB.BINARY, name="y")
    
    # z_e[j]: 1 if container j contains Good E (for capacity reduction)
    z_e = model.addVars(N, vtype=GRB.BINARY, name="z_e")
    
    # z_a[j]: 1 if container j contains Good A (for C dependency)
    z_a = model.addVars(N, vtype=GRB.BINARY, name="z_a")
    
    # Objective: Minimize number of containers
    model.setObjective(gp.quicksum(y[j] for j in N), GRB.MINIMIZE)
    
    # 1. All goods must be transported
    for g in goods_types:
        model.addConstr(gp.quicksum(x[g][j] for j in N) == quantities[g], name=f"demand_{g}")
        
    # 2. Container capacity constraint
    # If y[j]=1 and z_e[j]=0 -> Cap 60
    # If y[j]=1 and z_e[j]=1 -> Cap 45
    # If y[j]=0 -> Cap 0 (and z_e must be 0 due to non-negativity of weight sum)
    # Formula: Sum(weight * x) <= 60*y - 15*z_e
    for j in N:
        weight_sum = gp.quicksum(weights[g] * x[g][j] for g in goods_types)
        model.addConstr(weight_sum <= max_cap * y[j] - (max_cap - 45) * z_e[j], name=f"cap_{j}")
        
    # 3. Minimum load constraint
    for j in N:
        weight_sum = gp.quicksum(weights[g] * x[g][j] for g in goods_types)
        model.addConstr(weight_sum >= min_load * y[j], name=f"min_load_{j}")
        
    # 4. Minimum D goods per container
    for j in N:
        model.addConstr(x['D'][j] >= min_d * y[j], name=f"min_D_{j}")
        
    # 5. E Indicator Logic
    # If x[E][j] > 0, then z_e[j] must be 1
    # x[E][j] <= Total_E * z_e[j]
    total_e = quantities['E']
    for j in N:
        model.addConstr(x['E'][j] <= total_e * z_e[j], name=f"E_indicator_{j}")
        
    # 6. A Indicator Logic & C Dependency
    # If x[A][j] > 0, then z_a[j] must be 1
    # If z_a[j] == 1, then x[C][j] >= min_c_per_a
    total_a = quantities['A']
    for j in N:
        model.addConstr(x['A'][j] <= total_a * z_a[j], name=f"A_indicator_{j}")
        model.addConstr(x['C'][j] >= min_c_per_a * z_a[j], name=f"C_if_A_{j}")
        
    # 7. Symmetry Breaking
    # y[0] >= y[1] >= ...
    for j in range(len(N) - 1):
        model.addConstr(y[j] >= y[j+1], name=f"symmetry_{j}")
        
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
