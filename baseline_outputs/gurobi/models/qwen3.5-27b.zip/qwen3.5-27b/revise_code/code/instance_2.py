import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

a1 = params['a1']
a2 = params['a2']
training_capacity = params['training_capacity_per_jet']
dual_use_efficiency = params['dual_use_training_efficiency']
training_intensity_cap = params['training_intensity_cap']
combat_min_year2 = params['combat_jet_min_year2']
combat_weight = params['combat_weight']
training_weight = params['training_weight']

model = gp.Model('fighter_jet_allocation')
model.setParam('OutputFlag', 0)

# Decision variables for year 1
x1_train = model.addVar(vtype=GRB.CONTINUOUS, name='x1_train', lb=0)
x1_combat = model.addVar(vtype=GRB.CONTINUOUS, name='x1_combat', lb=0)
x1_mixed = model.addVar(vtype=GRB.CONTINUOUS, name='x1_mixed', lb=0)

# Decision variables for year 2
x2_train = model.addVar(vtype=GRB.CONTINUOUS, name='x2_train', lb=0)
x2_combat = model.addVar(vtype=GRB.CONTINUOUS, name='x2_combat', lb=0)
x2_mixed = model.addVar(vtype=GRB.CONTINUOUS, name='x2_mixed', lb=0)

# Constraints
# Year 1 production limit
model.addConstr(x1_train + x1_combat + x1_mixed <= a1, "year1_production")

# Year 2 production limit (cumulative)
model.addConstr(x2_train + x2_combat + x2_mixed <= a1 + a2, "year2_production")

# Training intensity cap year 1
model.addConstr((x1_train + x1_mixed) <= training_intensity_cap * a1, "train_cap_y1")

# Training intensity cap year 2
model.addConstr((x2_train + x2_mixed) <= training_intensity_cap * (a1 + a2), "train_cap_y2")

# Combat requirement year 2
model.addConstr(x2_combat + x2_mixed >= combat_min_year2, "combat_req_y2")

# Calculate pilots trained
pilots_y1 = training_capacity * x1_train + training_capacity * dual_use_efficiency * x1_mixed
pilots_y2 = training_capacity * x2_train + training_capacity * dual_use_efficiency * x2_mixed
total_pilots = pilots_y1 + pilots_y2

# Combat jets in year 2
combat_y2 = x2_combat + x2_mixed

# Objective: maximize weighted sum
model.setObjective(combat_weight * combat_y2 + training_weight * total_pilots, GRB.MAXIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found")
