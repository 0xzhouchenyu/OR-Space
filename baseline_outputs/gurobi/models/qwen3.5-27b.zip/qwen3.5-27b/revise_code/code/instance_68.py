import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Load utilities
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from utils import load_distances, load_parameters

# Load data
data_dir = os.path.join(script_dir, 'data')
distances = load_distances(data_dir)
params = load_parameters(data_dir)

# Extract parameters
min_supply = {
    'A': params['min_coal_yard_A'],
    'B': params['min_coal_yard_B_adjusted']
}

demand = {
    1: params['residential_area_1_demand'],
    2: params['residential_area_2_demand'],
    3: params['residential_area_3_demand']
}

min_share_area3_from_A = params['min_share_area3_from_A']
area3_A_staging_threshold = params['area3_A_staging_threshold']
area3_A_excess_staging_cost = params['area3_A_excess_staging_cost']

coal_yards = ['A', 'B']
areas = [1, 2, 3]

# Create the MIP model
model = gp.Model("Coal_Distribution")
model.setParam('OutputFlag', 0)

# Decision variables: amount of coal shipped from yard i to area j
x = {}
for yard in coal_yards:
    for area in areas:
        if (yard, area) in distances:
            x[(yard, area)] = model.addVar(lb=0, name=f"x_{yard}_{area}")

# Special handling for A-to-Area-3 with piecewise cost
# Split into base (up to threshold) and excess portions
x_A3_base = model.addVar(lb=0, ub=area3_A_staging_threshold, name="x_A3_base")
x_A3_excess = model.addVar(lb=0, name="x_A3_excess")

# Objective: minimize total transportation cost
# Normal routes
obj = gp.quicksum(distances[(yard, area)] * x[(yard, area)] 
                  for yard in coal_yards 
                  for area in areas 
                  if (yard, area) in distances and not (yard == 'A' and area == 3))

# A-to-Area-3 with piecewise cost
obj += distances[('A', 3)] * x_A3_base
obj += (distances[('A', 3)] + area3_A_excess_staging_cost) * x_A3_excess

model.setObjective(obj, GRB.MINIMIZE)

# Constraints:
# 1. Each coal yard must supply at least its minimum requirement
for yard in coal_yards:
    if yard == 'A':
        # A's total includes both base and excess for Area 3
        model.addConstr(
            gp.quicksum(x[(yard, area)] for area in areas if (yard, area) in distances and area != 3) + 
            x_A3_base + x_A3_excess >= min_supply[yard],
            f"Min_Supply_{yard}"
        )
    else:
        model.addConstr(
            gp.quicksum(x[(yard, area)] for area in areas if (yard, area) in distances) >= min_supply[yard],
            f"Min_Supply_{yard}"
        )

# 2. Each residential area must receive exactly its demand
for area in areas:
    if area == 3:
        # Area 3 receives from A (base + excess)
        model.addConstr(
            x_A3_base + x_A3_excess == demand[area],
            f"Demand_{area}"
        )
    else:
        model.addConstr(
            gp.quicksum(x[(yard, area)] for yard in coal_yards if (yard, area) in distances) == demand[area],
            f"Demand_{area}"
        )

# 3. Minimum share of Area 3 demand from A
# Since only A supplies Area 3, this is automatically satisfied
# But let's add it for completeness
model.addConstr(
    x_A3_base + x_A3_excess >= min_share_area3_from_A * demand[3],
    "Min_Share_Area3_From_A"
)

# Optimize
model.optimize()

# Print solution details
print(f"Status: {model.Status}")
print()
for yard in coal_yards:
    for area in areas:
        if (yard, area) in distances:
            val = x[(yard, area)].X
            if val > 0:
                print(f"Coal Yard {yard} -> Area {area}: {val} tons (distance: {distances[(yard, area)]} km)")

# Print A-to-Area-3 breakdown
print(f"\nCoal Yard A -> Area 3:")
print(f"  Base portion (<= {area3_A_staging_threshold} tons): {x_A3_base.X} tons")
print(f"  Excess portion (> {area3_A_staging_threshold} tons): {x_A3_excess.X} tons")

print()
total_supply = {yard: sum(x[(yard, area)].X for area in areas if (yard, area) in distances) for yard in coal_yards}
if 'A' in total_supply:
    total_supply['A'] += x_A3_base.X + x_A3_excess.X
for yard in coal_yards:
    print(f"Coal Yard {yard} total supply: {total_supply[yard]} tons (min: {min_supply[yard]})")

obj_val = model.ObjVal
print(f"\nFINAL_OBJ_VALUE: {obj_val}")
