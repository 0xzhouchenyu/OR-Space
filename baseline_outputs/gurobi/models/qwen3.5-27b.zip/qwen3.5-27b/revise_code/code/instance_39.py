import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters from CSV
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Get script directory
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load parameters
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
motorcycle_pollution = params['motorcycle_pollution']
small_truck_pollution = params['small_truck_pollution']
large_truck_pollution = params['large_truck_pollution']
max_motorcycle_trips = int(params['max_motorcycle_trips'])
motorcycle_capacity = params['motorcycle_capacity']
small_truck_capacity = params['small_truck_capacity']
large_truck_capacity = params['large_truck_capacity']
max_total_trips = int(params['max_total_trips'])
demand_peak = params['demand_peak_units']
demand_offpeak = params['demand_offpeak_units']
leasing_capacity = params['leasing_capacity']
leasing_pollution_per_unit = params['leasing_pollution_per_unit']
leasing_fixed_pollution = params['leasing_fixed_pollution']
max_leasing_fraction_peak = params['max_leasing_fraction_peak']
bigM_leasing = params['bigM_leasing']
epsilon = params['epsilon']

# Create model
model = gp.Model("Transport_Optimization")
model.setParam('OutputFlag', 0)

# Methods
methods = ['motorcycle', 'small_truck', 'large_truck']
periods = ['peak', 'offpeak']

# Pollution rates
pollution = {
    'motorcycle': motorcycle_pollution,
    'small_truck': small_truck_pollution,
    'large_truck': large_truck_pollution
}

# Capacities
capacity = {
    'motorcycle': motorcycle_capacity,
    'small_truck': small_truck_capacity,
    'large_truck': large_truck_capacity
}

# Decision variables
# Binary: which methods are active
method_active = model.addVars(methods, vtype=GRB.BINARY, name="method_active")

# Integer: trips per method per period
trips = model.addVars(methods, periods, lb=0, vtype=GRB.INTEGER, name="trips")

# Continuous: leasing units per period
leasing = model.addVars(periods, lb=0, vtype=GRB.CONTINUOUS, name="leasing")

# Binary: whether leasing is used at all
leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")

# Constraint: exactly 2 methods active
model.addConstr(gp.quicksum(method_active[m] for m in methods) == 2, "two_methods")

# Constraint: trips only allowed for active methods
for m in methods:
    for p in periods:
        model.addConstr(trips[m, p] <= bigM_leasing * method_active[m], f"trip_limit_{m}_{p}")

# Constraint: peak demand satisfaction
model.addConstr(
    gp.quicksum(capacity[m] * trips[m, 'peak'] for m in methods) + leasing['peak'] >= demand_peak,
    "peak_demand"
)

# Constraint: off-peak demand satisfaction
model.addConstr(
    gp.quicksum(capacity[m] * trips[m, 'offpeak'] for m in methods) + leasing['offpeak'] >= demand_offpeak,
    "offpeak_demand"
)

# Constraint: total trips limit
model.addConstr(
    gp.quicksum(trips[m, p] for m in methods for p in periods) <= max_total_trips,
    "total_trips"
)

# Constraint: motorcycle trips limit
model.addConstr(
    gp.quicksum(trips['motorcycle', p] for p in periods) <= max_motorcycle_trips,
    "motorcycle_limit"
)

# Constraint: total leasing capacity
model.addConstr(
    gp.quicksum(leasing[p] for p in periods) <= leasing_capacity,
    "leasing_capacity"
)

# Constraint: peak leasing fraction
model.addConstr(
    leasing['peak'] <= max_leasing_fraction_peak * demand_peak,
    "leasing_fraction_peak"
)

# Constraint: leasing fixed charge (Big-M formulation)
# If leasing_used = 0, then total leasing = 0
# If leasing_used = 1, then total leasing >= epsilon
model.addConstr(
    gp.quicksum(leasing[p] for p in periods) <= bigM_leasing * leasing_used,
    "leasing_upper_bound"
)
model.addConstr(
    gp.quicksum(leasing[p] for p in periods) >= epsilon * leasing_used,
    "leasing_lower_bound"
)

# Objective: minimize total pollution
# Owned trips pollution + leasing pollution (per unit + fixed)
objective = (
    gp.quicksum(pollution[m] * trips[m, p] for m in methods for p in periods) +
    leasing_pollution_per_unit * gp.quicksum(leasing[p] for p in periods) +
    leasing_fixed_pollution * leasing_used
)

model.setObjective(objective, GRB.MINIMIZE)

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: {float('inf')}")
