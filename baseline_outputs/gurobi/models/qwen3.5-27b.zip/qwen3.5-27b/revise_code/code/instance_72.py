import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read property data
properties = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_risky_multiplier = params['scen_1_risky_multiplier']
scen_2_risky_multiplier = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = int(params['max_risky_properties'])

# Create optimization model
model = gp.Model("RealEstateInvestment")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}  # Binary: purchase property
y = {}  # Continuous: fraction of property allocated to risky tenants
z = {}  # Binary: whether property has any risky tenants

for p in properties:
    name = p['name']
    x[name] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}")
    y[name] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=1, name=f"y_{name}")
    z[name] = model.addVar(vtype=GRB.BINARY, name=f"z_{name}")

model.update()

# Calculate expected risky multiplier
expected_risky_multiplier = scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier

# Objective: maximize expected annual income
objective_terms = []
for p in properties:
    name = p['name']
    # Income = base_income * x * ((1-y) + y * expected_risky_multiplier)
    # = base_income * x * (1 + y * (expected_risky_multiplier - 1))
    income_term = p['income'] * x[name] * (1 + y[name] * (expected_risky_multiplier - 1))
    objective_terms.append(income_term)

model.setObjective(gp.quicksum(objective_terms), GRB.MAXIMIZE)

# Budget constraint
model.addConstr(gp.quicksum(p['cost'] * x[p['name']] for p in properties) <= budget)

# Property 4 excludes Property 3
model.addConstr(x['Property_4'] + x['Property_3'] <= 1)

# Risky allocation only on purchased properties
for p in properties:
    name = p['name']
    model.addConstr(y[name] <= x[name])

# Per property risky cap
for p in properties:
    name = p['name']
    model.addConstr(y[name] <= per_property_risky_cap)

# Total risky budget
model.addConstr(gp.quicksum(p['cost'] * y[p['name']] for p in properties) <= total_risky_budget)

# Max risky properties
model.addConstr(gp.quicksum(z[p['name']] for p in properties) <= max_risky_properties)

# Link z to y (if y > 0 then z = 1)
M = 1.0  # Big-M value (since y is bounded by 1)
for p in properties:
    name = p['name']
    model.addConstr(y[name] <= M * z[name])

# Solve
model.optimize()

# Print results
obj_val = model.ObjVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
