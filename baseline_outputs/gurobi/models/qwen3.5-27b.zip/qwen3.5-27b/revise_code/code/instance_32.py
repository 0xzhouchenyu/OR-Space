import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv for production rates
    workshops = []
    rates = {}
    
    filepath = os.path.join(data_dir, 'table_1.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    # Read general_parameters.csv
    params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    
    components = [1, 2, 3]
    shifts = ['day', 'night']
    hour_types = ['regular', 'overtime']
    
    # Create model
    model = gp.Model("Maximize_Completed_Products")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[w][c][shift][hour_type] = hours allocated
    x = {}
    for w in workshops:
        for c in components:
            for s in shifts:
                for h in hour_types:
                    var_name = f"x_{w}_{c}_{s}_{h}"
                    x[(w, c, s, h)] = model.addVar(lb=0, name=var_name)
    
    # Binary indicators for workshop activity per shift
    # y[w][shift] = 1 if workshop w is active in shift
    y = {}
    for w in workshops:
        for s in shifts:
            var_name = f"y_{w}_{s}"
            y[(w, s)] = model.addVar(vtype=GRB.BINARY, name=var_name)
    
    # z = number of completed products
    z = model.addVar(lb=0, name="z")
    
    # shortage = max(0, z_target - z)
    shortage = model.addVar(lb=0, name="shortage")
    
    # Get parameters
    z_target = params['z_target']
    penalty_night = params['penalty_night_hour']
    penalty_overtime = params['penalty_overtime_hour']
    penalty_shortage = params['penalty_shortage_per_unit']
    
    # Objective: minimize penalty costs
    # Night hours penalty (regular night only)
    night_penalty = gp.quicksum(
        x[(w, c, 'night', 'regular')] * penalty_night
        for w in workshops for c in components
    )
    
    # Overtime penalty (both day and night)
    overtime_penalty = gp.quicksum(
        x[(w, c, s, 'overtime')] * penalty_overtime
        for w in workshops for c in components for s in shifts
    )
    
    # Shortage penalty
    shortage_penalty = shortage * penalty_shortage
    
    model.setObjective(night_penalty + overtime_penalty + shortage_penalty, GRB.MINIMIZE)
    
    # Regular hours limits per workshop per shift
    for w in workshops:
        for s in shifts:
            param_name = f"regular_hours_limit_{s}_{w}"
            limit = params[param_name]
            model.addConstr(
                gp.quicksum(x[(w, c, s, 'regular')] for c in components) <= limit,
                f"regular_limit_{w}_{s}"
            )
    
    # Overtime capacity per workshop per shift
    for w in workshops:
        for s in shifts:
            param_name = f"overtime_capacity_{s}_{w}"
            cap = params[param_name]
            model.addConstr(
                gp.quicksum(x[(w, c, s, 'overtime')] for c in components) <= cap,
                f"overtime_cap_{w}_{s}"
            )
    
    # Big-M constraints linking binary indicators to hours
    for w in workshops:
        for s in shifts:
            bigM = params[f"bigM_shift_{w}"]
            model.addConstr(
                gp.quicksum(x[(w, c, s, 'regular')] for c in components) + 
                gp.quicksum(x[(w, c, s, 'overtime')] for c in components) <= bigM * y[(w, s)],
                f"bigM_{w}_{s}"
            )
    
    # Maximum 2 workshops active per shift
    for s in shifts:
        model.addConstr(
            gp.quicksum(y[(w, s)] for w in workshops) <= 2,
            f"max_active_{s}"
        )
    
    # Component balance: all components must produce equal amounts for complete products
    for c in components:
        total_production = gp.quicksum(
            rates[(w, c)] * (x[(w, c, s, h)])
            for w in workshops for s in shifts for h in hour_types
        )
        model.addConstr(total_production >= z, f"component_balance_{c}")
    
    # Shortage definition: shortage >= z_target - z
    model.addConstr(shortage >= z_target - z, "shortage_def")
    
    # Solve
    model.optimize()
    
    # Print result
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val:.1f}")

if __name__ == "__main__":
    main()
