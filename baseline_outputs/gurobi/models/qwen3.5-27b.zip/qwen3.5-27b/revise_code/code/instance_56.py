import os
                    import csv
                    import gurobipy as gp
                    from gurobipy import GRB

                    # Paths
                    script_dir = os.path.dirname(os.path.abspath(__file__))
                    data_dir = os.path.join(script_dir, 'data')
                    
                    # Load Params
                    params = {}
                    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
                        reader = csv.DictReader(f)
                        for row in reader:
                            params[row['Parameter_Name']] = float(row['Value'])
                            
                    # Load Prices
                    prices = {}
                    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
                        reader = csv.DictReader(f)
                        for row in reader:
                            m = int(row['Month'])
                            prices[m] = {
                                'buy': float(row['Purchase_Price_yuan_per_dan']),
                                'sell': float(row['Selling_Price_yuan_per_dan'])
                            }
                            
                    months = [1, 2, 3]
                    
                    # Extract Params
                    W_CAP = params['warehouse_capacity']
                    INIT_STOCK = params['initial_stock']
                    INIT_FUNDS = params['initial_funds']
                    END_INV = params['end_of_quarter_inventory']
                    FAST_CAP = params['buy_fast_capacity']
                    FAST_PREM = params['fast_purchase_premium_ratio']
                    CREDIT_LIM = params['credit_limit']
                    INT_RATE = params['monthly_interest_rate']
                    MIN_INV = {1: params['min_inventory_month_1'], 
                               2: params['min_inventory_month_2'], 
                               3: params['min_inventory_month_3']}
                    
                    # Model
                    model = gp.Model("GrainTrading")
                    model.setParam('OutputFlag', 0)
                    
                    # Vars
                    buy_reg = model.addVars(months, lb=0, name="buy_reg")
                    buy_fast = model.addVars(months, lb=0, name="buy_fast")
                    sell = model.addVars(months, lb=0, name="sell")
                    stock = model.addVars(months, lb=0, name="stock")
                    funds = model.addVars(months, lb=0, name="funds")
                    credit = model.addVars(months, lb=0, name="credit")
                    
                    # Constraints
                    # Stock Balance
                    # stock[1] = init_stock - sell[1] + buy_reg[1] + buy_fast[1]
                    # stock[m] = stock[m-1] - sell[m] + buy_reg[m] + buy_fast[m]
                    
                    prev_stock = INIT_STOCK
                    for m in months:
                        model.addConstr(stock[m] == prev_stock - sell[m] + buy_reg[m] + buy_fast[m], name=f"stock_bal_{m}")
                        prev_stock = stock[m]
                        
                    # Sell Limit
                    prev_stock_val = INIT_STOCK
                    for m in months:
                        model.addConstr(sell[m] <= prev_stock_val, name=f"sell_lim_{m}")
                        prev_stock_val = stock[m]
                        
                    # Warehouse Cap
                    for m in months:
                        model.addConstr(stock[m] <= W_CAP, name=f"wh_cap_{m}")
                        
                    # Min Inventory
                    for m in months:
                        model.addConstr(stock[m] >= MIN_INV[m], name=f"min_inv_{m}")
                        
                    # End Inventory (Redundant if min_inv[3] == end_inv, but explicit)
                    model.addConstr(stock[3] >= END_INV, name="end_inv")
                    
                    # Fast Cap
                    for m in months:
                        model.addConstr(buy_fast[m] <= FAST_CAP, name=f"fast_cap_{m}")
                        
                    # Credit Limit
                    for m in months:
                        model.addConstr(credit[m] <= CREDIT_LIM, name=f"cred_lim_{m}")
                        
                    # Funds Balance
                    # funds[m] = funds[m-1] + Rev - Cost - Int + (credit[m] - credit[m-1])
                    # Rev = sell[m] * price_sell
                    # Cost = buy_reg[m] * price_buy + buy_fast[m] * price_buy * (1 + prem)
                    # Int = credit[m] * rate
                    
                    prev_funds = INIT_FUNDS
                    prev_credit = 0
                    for m in months:
                        rev = sell[m] * prices[m]['sell']
                        cost_reg = buy_reg[m] * prices[m]['buy']
                        cost_fast = buy_fast[m] * prices[m]['buy'] * (1 + FAST_PREM)
                        interest = credit[m] * INT_RATE
                        
                        model.addConstr(
                            funds[m] == prev_funds + rev - cost_reg - cost_fast - interest + (credit[m] - prev_credit),
                            name=f"funds_bal_{m}"
                        )
                        prev_funds = funds[m]
                        prev_credit = credit[m]
                        
                    # Objective
                    # Maximize (funds[3] - initial_funds) - sum(interest)
                    # sum(interest) = INT_RATE * sum(credit[m])
                    
                    total_interest = gp.quicksum(credit[m] * INT_RATE for m in months)
                    model.setObjective((funds[3] - INIT_FUNDS) - total_interest, GRB.MAXIMIZE)
                    
                    # Solve
                    model.optimize()
                    
                    print(f"FINAL_OBJ_VALUE: {model.objVal}")
