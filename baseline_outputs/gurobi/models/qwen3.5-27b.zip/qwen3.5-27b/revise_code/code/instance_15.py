import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    # Determine script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    
    df_demand = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    demand = {}
    for _, row in df_demand.iterrows():
        demand[int(row['stage'])] = int(row['tool_requirement'])
        
    param_dict = {}
    for _, row in df_params.iterrows():
        val = row['Value']
        # Try to convert to int if possible, else float
        try:
            param_dict[row['Parameter_Name']] = int(val)
        except ValueError:
            param_dict[row['Parameter_Name']] = float(val)
            
    return param_dict, demand

def solve():
    params, demand = load_data()
    
    n = params['n']
    cost_new = params['cost_new_tool']
    cost_slow = params['cost_slow_repair']
    cost_fast = params['cost_fast_repair']
    dur_slow = params['slow_repair_duration']
    dur_fast = params['fast_repair_duration']
    max_fast = params['max_fast_stage']
    max_slow = params['max_slow_stage']
    em_buy = params['emission_buy']
    em_fast = params['emission_fast_repair']
    em_slow = params['emission_slow_repair']
    carbon_budget = params['carbon_budget']
    penalty_short = params['penalty_shortage']
    
    model = gp.Model("Tool_Repair_Optimization")
    model.setParam('OutputFlag', 0)
    
    stages = range(1, n + 1)
    
    # Variables
    # x[t]: buy new at stage t
    x = model.addVars(stages, vtype=GRB.INTEGER, name="buy")
    # y[t]: fast repair at stage t
    y = model.addVars(stages, vtype=GRB.INTEGER, name="fast")
    # z[t]: slow repair at stage t
    z = model.addVars(stages, vtype=GRB.INTEGER, name="slow")
    # c[t]: clean inventory at end of stage t (c[0] is pre-buy)
    c = model.addVars(range(n + 1), vtype=GRB.INTEGER, name="clean")
    # d[t]: dirty inventory at end of stage t (d[0] is 0)
    d = model.addVars(range(n + 1), vtype=GRB.INTEGER, name="dirty")
    # s[t]: shortage at stage t
    s = model.addVars(stages, vtype=GRB.INTEGER, name="shortage")
    
    # Initial Conditions
    model.addConstr(d[0] == 0)
    # c[0] is free variable >= 0 (pre-buy)
    
    # Constraints
    for t in stages:
        # Clean Flow
        # Available: c[t-1] + x[t] + returns
        returns = 0
        if t - dur_fast >= 1:
            returns += y[t - dur_fast]
        if t - dur_slow >= 1:
            returns += z[t - dur_slow]
            
        # Equation: c[t-1] + x[t] + returns + s[t] == demand[t] + c[t]
        model.addConstr(c[t-1] + x[t] + returns + s[t] == demand[t] + c[t], f"clean_flow_{t}")
        
        # Dirty Flow
        # Input: d[t-1] + (demand[t] - s[t])
        # Output: y[t] + z[t] + d[t]
        model.addConstr(d[t-1] + demand[t] - s[t] == y[t] + z[t] + d[t], f"dirty_flow_{t}")
        
        # Caps
        model.addConstr(y[t] <= max_fast, f"cap_fast_{t}")
        model.addConstr(z[t] <= max_slow, f"cap_slow_{t}")
        
    # Carbon Budget
    # Emissions from pre-buy (c[0]), purchases (x), fast repair (y), slow repair (z)
    total_emissions = em_buy * c[0]
    for t in stages:
        total_emissions += em_buy * x[t]
        total_emissions += em_fast * y[t]
        total_emissions += em_slow * z[t]
        
    model.addConstr(total_emissions <= carbon_budget, "carbon_budget")
    
    # Objective
    # Cost: pre-buy (c[0]), purchases (x), fast (y), slow (z), shortage (s)
    obj = cost_new * c[0]
    for t in stages:
        obj += cost_new * x[t]
        obj += cost_fast * y[t]
        obj += cost_slow * z[t]
        obj += penalty_short * s[t]
        
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
