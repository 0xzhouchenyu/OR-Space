import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Set up path
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

m = int(params['m'])
n = int(params['n'])
p = int(params['p'])

a = {i: params[f'a_{i}'] for i in range(1, m+1)}
b = {j: params[f'b_{j}'] for j in range(1, n+1)}
f_cost = {k: params[f'f_{k}'] for k in range(1, p+1)}
q = {k: params[f'q_{k}'] for k in range(1, p+1)}
qexp = {k: params[f'qexp_{k}'] for k in range(1, p+1)}
alpha = {j: params[f'alpha_{j}'] for j in range(1, n+1)}
eps = params['eps']
M_val = params['M']

# Load table 1 (Production to Station)
cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row['i'])
        k = int(row['k'])
        cR_ik[(i, k)] = float(row['cR_ik'])
        cE_ik[(i, k)] = float(row['cE_ik'])

# Load table 2 (Station to Demand)
cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, 'table_2.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row['k'])
        j = int(row['j'])
        cR_kj[(k, j)] = float(row['cR_kj'])
        cE_kj[(k, j)] = float(row['cE_kj'])

# Create Model
model = gp.Model("Transportation_Revised")
model.setParam('OutputFlag', 0)

# Decision Variables
# xR[i][k], xE[i][k]
xR = {}
xE = {}
for i in range(1, m+1):
    for k in range(1, p+1):
        xR[(i, k)] = model.addVar(lb=0, name=f"xR_{i}_{k}")
        xE[(i, k)] = model.addVar(lb=0, name=f"xE_{i}_{k}")

# yR[k][j], yE[k][j]
yR = {}
yE = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        yR[(k, j)] = model.addVar(lb=0, name=f"yR_{k}_{j}")
        yE[(k, j)] = model.addVar(lb=0, name=f"yE_{k}_{j}")

# z[k]: Station open
z = {}
for k in range(1, p+1):
    z[k] = model.addVar(vtype=GRB.BINARY, name=f"z_{k}")

# u[k][j]: Express flow from k to j active
u = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        u[(k, j)] = model.addVar(vtype=GRB.BINARY, name=f"u_{k}_{j}")

# Objective Function
obj = gp.GRBLinearExpr()
# Transportation Costs
for i in range(1, m+1):
    for k in range(1, p+1):
        obj += cR_ik[(i, k)] * xR[(i, k)]
        obj += cE_ik[(i, k)] * xE[(i, k)]
for k in range(1, p+1):
    for j in range(1, n+1):
        obj += cR_kj[(k, j)] * yR[(k, j)]
        obj += cE_kj[(k, j)] * yE[(k, j)]
# Fixed Costs
for k in range(1, p+1):
    obj += f_cost[k] * z[k]

model.setObjective(obj, GRB.MINIMIZE)

# Constraints

# 1. Supply Constraints
for i in range(1, m+1):
    model.addConstr(gp.quickSum(xR[(i, k)] + xE[(i, k)] for k in range(1, p+1)) <= a[i], f"Supply_{i}")

# 2. Demand Constraints
for j in range(1, n+1):
    model.addConstr(gp.quickSum(yR[(k, j)] + yE[(k, j)] for k in range(1, p+1)) >= b[j], f"Demand_{j}")

# 3. Flow Conservation (Mode Preserved)
# Regular
for k in range(1, p+1):
    model.addConstr(gp.quickSum(xR[(i, k)] for i in range(1, m+1)) == gp.quickSum(yR[(k, j)] for j in range(1, n+1)), f"FlowReg_{k}")
# Express
for k in range(1, p+1):
    model.addConstr(gp.quickSum(xE[(i, k)] for i in range(1, m+1)) == gp.quickSum(yE[(k, j)] for j in range(1, n+1)), f"FlowExp_{k}")

# 4. Station Capacity (Total)
for k in range(1, p+1):
    model.addConstr(gp.quickSum(xR[(i, k)] + xE[(i, k)] for i in range(1, m+1)) <= q[k] * z[k], f"CapTotal_{k}")

# 5. Station Capacity (Express)
for k in range(1, p+1):
    model.addConstr(gp.quickSum(xE[(i, k)] for i in range(1, m+1)) <= qexp[k] * z[k], f"CapExp_{k}")

# 6. Express Indicator Logic
for k in range(1, p+1):
    for j in range(1, n+1):
        # yE <= M * u
        model.addConstr(yE[(k, j)] <= M_val * u[(k, j)], f"LinkU_Max_{k}_{j}")
        # yE >= eps * u
        model.addConstr(yE[(k, j)] >= eps * u[(k, j)], f"LinkU_Min_{k}_{j}")
        # u <= z
        model.addConstr(u[(k, j)] <= z[k], f"LinkZ_{k}_{j}")

# 7. Diversification Constraint (At least 2 stations provide express to each demand)
# Based on interpretation of "Demand points with more than one open station... across two station links"
# Given p=2, this enforces both stations to provide express if they are open/serving.
# To ensure robustness as per "risk review", we enforce sum(u) >= 2 for all j.
for j in range(1, n+1):
    model.addConstr(gp.quickSum(u[(k, j)] for k in range(1, p+1)) >= 2, f"Diversify_{j}")

# 8. Express Share Constraint
# Sum(yE) >= alpha * Sum(yR + yE)
# => Sum(yE) >= alpha * TotalFlow
# => (1-alpha)*Sum(yE) - alpha*Sum(yR) >= 0
for j in range(1, n+1):
    total_flow_j = gp.quickSum(yR[(k, j)] + yE[(k, j)] for k in range(1, p+1))
    expr_flow_j = gp.quickSum(yE[(k, j)] for k in range(1, p+1))
    model.addConstr(expr_flow_j >= alpha[j] * total_flow_j, f"Share_{j}")

# Solve
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
