import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load container data
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    
    n = len(containers)
    
    # Create model
    model = gp.Model("PlasticContainers")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # y_reg[i] = 1 if regular mode activated for type i
    y_reg = model.addVars(n, vtype=GRB.BINARY, name="y_reg")
    
    # y_eco[i] = 1 if eco mode activated for type i
    y_eco = model.addVars(n, vtype=GRB.BINARY, name="y_eco")
    
    # x_reg[i][j] = units of type i in regular mode fulfilling demand of type j
    # x_eco[i][j] = units of type i in eco mode fulfilling demand of type j
    x_reg = {}
    x_eco = {}
    
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x_reg[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_reg_{i}_{j}")
                x_eco[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_eco_{i}_{j}")
    
    # Objective: minimize total cost
    # Variable production costs
    var_cost = gp.quicksum(
        containers[i]['cost'] * (x_reg[i, j] + x_eco[i, j])
        for i in range(n) for j in range(n) if (i, j) in x_reg
    )
    
    # Fixed setup costs (regular mode)
    setup_cost_reg = gp.quicksum(params['fixed_setup_cost'] * y_reg[i] for i in range(n))
    
    # Eco overhead costs
    setup_cost_eco = gp.quicksum(params['eco_overhead_cost'] * y_eco[i] for i in range(n))
    
    # Energy costs
    energy_usage = gp.quicksum(
        params['regular_energy_intensity_kwh_per_unit'] * x_reg[i, j] +
        params['eco_energy_intensity_kwh_per_unit'] * x_eco[i, j]
        for i in range(n) for j in range(n) if (i, j) in x_reg
    )
    energy_cost = params['energy_cost_per_kwh'] * energy_usage
    
    model.setObjective(var_cost + setup_cost_reg + setup_cost_eco + energy_cost, GRB.MINIMIZE)
    
    # Demand constraints
    for j in range(n):
        model.addConstr(
            gp.quicksum(x_reg[i, j] + x_eco[i, j] for i in range(n) if (i, j) in x_reg) >= containers[j]['demand'],
            name=f"demand_{j}"
        )
    
    # Linking constraints for regular mode
    M = sum(c['demand'] for c in containers)
    for i in range(n):
        total_reg_i = gp.quicksum(x_reg[i, j] for j in range(n) if (i, j) in x_reg)
        model.addConstr(total_reg_i <= M * y_reg[i], name=f"link_reg_{i}")
    
    # Linking constraints for eco mode
    for i in range(n):
        total_eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(total_eco_i <= M * y_eco[i], name=f"link_eco_{i}")
    
    # Eco capacity share constraint: eco production <= 0.6 * total production for each type
    for i in range(n):
        total_eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        total_reg_i = gp.quicksum(x_reg[i, j] for j in range(n) if (i, j) in x_reg)
        model.addConstr(total_eco_i <= params['eco_capacity_share'] * (total_reg_i + total_eco_i), name=f"eco_share_{i}")
    
    # Energy constraint
    model.addConstr(energy_usage <= params['max_total_energy_kwh'], name="energy_limit")
    
    # Solve
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
