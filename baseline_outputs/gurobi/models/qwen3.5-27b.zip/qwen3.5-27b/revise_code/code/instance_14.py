import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load Items
    items = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g']),
                'cost': float(row['Cost_per_100g']),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g']),
                'sodium': float(row['Sodium_mg_per_100g'])
            })
            
    # Load Params
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_cal = params['min_daily_calories']
    max_cal = params['max_daily_calories']
    max_sodium = params['max_daily_sodium']
    
    n_items = len(items)
    max_units = int(total_weight_limit // 100)
    max_meal_units = 3
    
    # Model
    model = gp.Model("Dinner_Lunch_Plan")
    model.setParam('OutputFlag', 0)
    
    # Variables
    # purchase_units[i], lunch_units[i], dinner_units[i]
    purchase = model.addVars(n_items, vtype=GRB.INTEGER, name="purchase")
    lunch = model.addVars(n_items, vtype=GRB.INTEGER, name="lunch")
    dinner = model.addVars(n_items, vtype=GRB.INTEGER, name="dinner")
    
    # select_item[i]
    select = model.addVars(n_items, vtype=GRB.BINARY, name="select")
    
    # veg selection binaries (only for veggies)
    veg_indices = [i for i in range(n_items) if items[i]['type'] == 'Vegetable']
    lunch_veg_sel = model.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg_sel")
    dinner_veg_sel = model.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg_sel")
    
    # Constraints
    
    # 1. Purchase >= Lunch + Dinner
    for i in range(n_items):
        model.addConstr(purchase[i] >= lunch[i] + dinner[i])
        
    # 2. Budget
    model.addConstr(gp.quicksum(items[i]['cost'] * purchase[i] for i in range(n_items)) <= max_budget)
    
    # 3. Total Weight Limit
    model.addConstr(gp.quicksum(100 * purchase[i] for i in range(n_items)) <= total_weight_limit)
    
    # 4. Meal Weight Balance (Exactly 3 units per meal)
    model.addConstr(gp.quicksum(lunch[i] for i in range(n_items)) == 3)
    model.addConstr(gp.quicksum(dinner[i] for i in range(n_items)) == 3)
    
    # 5. Calorie Bounds
    total_cal_expr = gp.quicksum(items[i]['calories'] * (lunch[i] + dinner[i]) for i in range(n_items))
    model.addConstr(total_cal_expr >= min_cal)
    model.addConstr(total_cal_expr <= max_cal)
    
    # 6. Sodium Bound
    total_sodium_expr = gp.quicksum(items[i]['sodium'] * (lunch[i] + dinner[i]) for i in range(n_items))
    model.addConstr(total_sodium_expr <= max_sodium)
    
    # 7. Selection Linkage (Big-M)
    for i in range(n_items):
        model.addConstr(purchase[i] <= max_units * select[i])
        model.addConstr(lunch[i] <= max_meal_units * select[i])
        model.addConstr(dinner[i] <= max_meal_units * select[i])
        
    # 8. Veg Selection Linkage
    for i in veg_indices:
        model.addConstr(lunch[i] >= lunch_veg_sel[i])
        model.addConstr(lunch[i] <= max_meal_units * lunch_veg_sel[i])
        model.addConstr(dinner[i] >= dinner_veg_sel[i])
        model.addConstr(dinner[i] <= max_meal_units * dinner_veg_sel[i])
        
    # 9. Min Veg Types per Meal
    model.addConstr(gp.quicksum(lunch_veg_sel[i] for i in veg_indices) >= min_veg_types)
    model.addConstr(gp.quicksum(dinner_veg_sel[i] for i in veg_indices) >= min_veg_types)
    
    # Objective: Maximize Protein
    obj_expr = gp.quicksum(items[i]['protein'] * (lunch[i] + dinner[i]) for i in range(n_items))
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
