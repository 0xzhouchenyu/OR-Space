import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load General Parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            # Try to convert to float/int
            try:
                if '.' in val:
                    params[key] = float(val)
                else:
                    params[key] = int(val)
            except ValueError:
                params[key] = val
                
    # Load Costs
    costs = {} # {child: {mode: cost}}
    children = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row['Child'].strip()
            children.append(child)
            costs[child] = {
                'budget': float(row['Cost_budget']),
                'balanced': float(row['Cost_balanced']),
                'premium': float(row['Cost_premium'])
            }
            
    modes = ['budget', 'balanced', 'premium']
    
    # Create Model
    model = gp.Model("ZhangFamilyTrip")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    x = model.addVars(children, vtype=GRB.BINARY, name="x")
    y = model.addVars(modes, vtype=GRB.BINARY, name="y")
    z = model.addVars(children, modes, vtype=GRB.BINARY, name="z")
    
    v_max = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="v_max")
    v_min = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="v_min")
    
    # Constraints
    
    # 1. One mode selected
    model.addConstr(gp.quicksum(y[m] for m in modes) == 1, "OneMode")
    
    # 2. Link z to x and y
    # z[i][m] <= x[i]
    # z[i][m] <= y[m]
    # z[i][m] >= x[i] + y[m] - 1
    for c in children:
        for m in modes:
            model.addConstr(z[c, m] <= x[c])
            model.addConstr(z[c, m] <= y[m])
            model.addConstr(z[c, m] >= x[c] + y[m] - 1)
            
    # 3. Ginny mandatory
    model.addConstr(x['Ginny'] == 1, "GinnyMandatory")
    
    # 4. Group size limits
    # Max children
    model.addConstr(gp.quicksum(x[c] for c in children) <= params['max_children'], "MaxChildren")
    
    # Min children dependent on mode
    # Sum x >= min_children * y_budget + min_children_per_mode * (y_balanced + y_premium)
    min_c = params['min_children']
    min_c_mode = params['min_children_per_mode']
    model.addConstr(
        gp.quicksum(x[c] for c in children) >= 
        min_c * y['budget'] + min_c_mode * (y['balanced'] + y['premium']), 
        "MinChildrenMode"
    )
    
    # 5. Compatibility
    # Harry no Fred
    model.addConstr(x['Harry'] + x['Fred'] <= 1, "HarryNoFred")
    # Harry no George
    model.addConstr(x['Harry'] + x['George'] <= 1, "HarryNoGeorge")
    # George requires Fred
    model.addConstr(x['George'] <= x['Fred'], "GeorgeRequiresFred")
    # George requires Hermione
    model.addConstr(x['George'] <= x['Hermione'], "GeorgeRequiresHermione")
    
    # 6. Fairness Bounds
    # M constant
    M = 10000.0 
    
    # v_max >= Cost - M*(1-z)
    for c in children:
        for m in modes:
            cost_val = costs[c][m]
            model.addConstr(v_max >= cost_val - M * (1 - z[c, m]), f"MaxBound_{c}_{m}")
            
    # v_min <= Cost + M*(1-z)
    for c in children:
        for m in modes:
            cost_val = costs[c][m]
            model.addConstr(v_min <= cost_val + M * (1 - z[c, m]), f"MinBound_{c}_{m}")
            
    # 7. Max Total Cost (Actual Spend)
    total_spend_expr = gp.quicksum(costs[c][m] * z[c, m] for c in children for m in modes)
    model.addConstr(total_spend_expr <= params['max_total_cost'], "MaxTotalCost")
    
    # Objective
    # Minimize Total Spend + Penalty * (v_max - v_min)
    penalty = params['fairness_penalty']
    obj = total_spend_expr + penalty * (v_max - v_min)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
