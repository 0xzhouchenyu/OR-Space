import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Construct paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load general parameters
    params = {}
    param_file = os.path.join(data_dir, 'general_parameters.csv')
    with open(param_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    min_protein = params['min_protein_requirement']
    min_minerals = params['min_minerals_requirement']
    min_vitamins = params['min_vitamins_requirement']

    # Load feed data
    feeds = []
    feed_file = os.path.join(data_dir, 'table_1.csv')
    with open(feed_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            feed = {
                'Feed': int(row['Feed']),
                'Protein_g': float(row['Protein_g']),
                'Minerals_g': float(row['Minerals_g']),
                'Vitamins_mg': float(row['Vitamins_mg']),
                'Price_Y_per_kg': float(row['Price_Y_per_kg']),
            }
            feeds.append(feed)

    # Create Model
    model = gp.Model("FeedMixOptimization")
    model.setParam('OutputFlag', 0)

    # Decision Variables
    # x[feed_id] = amount of feed in kg
    x_vars = {}
    for f in feeds:
        x_vars[f['Feed']] = model.addVar(lb=0, name=f"x_{f['Feed']}")

    # Binary variable for mutual exclusion between Feed 4 and Feed 5
    # y = 1 => Feed 4 allowed, Feed 5 forbidden
    # y = 0 => Feed 4 forbidden, Feed 5 allowed
    y_var = model.addVar(vtype=GRB.BINARY, name="switch_4_5")

    # Update model to register variables
    model.update()

    # Objective: Minimize Cost
    cost_expr = gp.quicksum(f['Price_Y_per_kg'] * x_vars[f['Feed']] for f in feeds)
    model.setObjective(cost_expr, GRB.MINIMIZE)

    # Nutritional Constraints
    # Protein
    protein_expr = gp.quicksum(f['Protein_g'] * x_vars[f['Feed']] for f in feeds)
    model.addConstr(protein_expr >= min_protein, "ProteinRequirement")

    # Minerals
    minerals_expr = gp.quicksum(f['Minerals_g'] * x_vars[f['Feed']] for f in feeds)
    model.addConstr(minerals_expr >= min_minerals, "MineralsRequirement")

    # Vitamins
    vitamins_expr = gp.quicksum(f['Vitamins_mg'] * x_vars[f['Feed']] for f in feeds)
    model.addConstr(vitamins_expr >= min_vitamins, "VitaminsRequirement")

    # Mutual Exclusion Constraint (Big-M)
    # If y=1, x_4 <= M, x_5 <= 0
    # If y=0, x_4 <= 0, x_5 <= M
    # M needs to be large enough. 
    # Max requirement is 700g protein. Min protein density is 1g/kg (Feed 3). 
    # So max kg needed is around 700. Let's use 10000 as a safe Big-M.
    M = 10000.0
    
    # Get variables for Feed 4 and 5
    x4 = x_vars.get(4)
    x5 = x_vars.get(5)

    if x4 is not None and x5 is not None:
        model.addConstr(x4 <= M * y_var, "Excl_Feed4")
        model.addConstr(x5 <= M * (1 - y_var), "Excl_Feed5")

    # Solve
    model.optimize()

    # Output
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # In case of no solution, though problem seems feasible
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
