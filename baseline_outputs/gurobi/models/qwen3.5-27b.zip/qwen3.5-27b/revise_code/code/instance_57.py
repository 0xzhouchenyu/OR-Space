import csv
import os
import math
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def solve():
    # Read order data
    table_1_path = get_data_path('table_1.csv')
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'order_number': int(row['Order_Number']),
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
    
    # Read parameters
    params_path = get_data_path('general_parameters.csv')
    params = {}
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    std_widths = [params['standard_width_1'], params['standard_width_2']]
    pattern_setup_penalty = params['pattern_setup_penalty']
    wide_roll_threshold_width = params['wide_roll_threshold_width']
    wide_roll_extra_setup_penalty = params['wide_roll_extra_setup_penalty']
    
    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    
    total_required_area = sum(w * l for w, l in zip(widths, lengths))
    
    # Generate all feasible cutting patterns for each standard width
    patterns_by_std_width = {}
    for idx, sw in enumerate(std_widths):
        patterns = []
        
        def build_pattern(index, current_pattern, current_sum):
            if index == len(widths):
                if any(c > 0 for c in current_pattern):
                    patterns.append(current_pattern)
                return
            
            max_count = int(math.floor((sw - current_sum + 1e-7) / widths[index]))
            for count in range(max_count + 1):
                build_pattern(index + 1, current_pattern + [count], current_sum + count * widths[index])
        
        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {'sw': sw, 'patterns': patterns}
    
    # Create Gurobi model
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)
    
    # Variables
    x_vars = {}  # Continuous: amount of each pattern used (in terms of length)
    y_vars = {}  # Binary: whether each pattern is used
    
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            x_vars[(idx, i)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{idx}_{i}")
            y_vars[(idx, i)] = model.addVar(vtype=GRB.BINARY, name=f"y_{idx}_{i}")
    
    # Big-M constraint: link x and y variables
    # If x > 0, then y must be 1
    # Use a large enough M (sum of all required lengths)
    big_M = sum(lengths) + 1000
    
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            model.addConstr(x_vars[(idx, i)] <= big_M * y_vars[(idx, i)])
    
    # Objective: Minimize total waste
    # Waste = (total area used - total required area) + setup penalties
    # Total area used = sum(sw * x) for all patterns
    # Setup penalty = pattern_setup_penalty * y for all patterns
    # Extra wide roll penalty = wide_roll_extra_setup_penalty * y for patterns on wide rolls
    
    total_area_used = gp.quicksum(
        data['sw'] * x_vars[(idx, i)] 
        for idx, data in patterns_by_std_width.items() 
        for i, p in enumerate(data['patterns'])
    )
    
    setup_penalties = gp.quicksum(
        pattern_setup_penalty * y_vars[(idx, i)]
        for idx, data in patterns_by_std_width.items()
        for i, p in enumerate(data['patterns'])
    )
    
    wide_roll_penalties = gp.quicksum(
        wide_roll_extra_setup_penalty * y_vars[(idx, i)]
        for idx, data in patterns_by_std_width.items()
        for i, p in enumerate(data['patterns'])
        if data['sw'] >= wide_roll_threshold_width
    )
    
    model.setObjective(total_area_used - total_required_area + setup_penalties + wide_roll_penalties, GRB.MINIMIZE)
    
    # Constraints: Satisfy length requirements for each order width
    for j in range(len(widths)):
        model.addConstr(
            gp.quicksum(
                p[j] * x_vars[(idx, i)] 
                for idx, data in patterns_by_std_width.items() 
                for i, p in enumerate(data['patterns'])
            ) >= lengths[j],
            name=f"demand_{j}"
        )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        final_obj_value = model.objVal
        print(f"FINAL_OBJ_VALUE: {round(final_obj_value, 4)}")
    else:
        print("FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    solve()
