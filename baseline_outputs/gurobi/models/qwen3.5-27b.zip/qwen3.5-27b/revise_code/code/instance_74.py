import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Get data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Read precedence relationships
    precedences = []
    with open(os.path.join(data_dir, 'table_1.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))
    
    # Define activities
    activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    
    # Extract durations
    dur = {a: int(params[f'activity_{a}_duration']) for a in activities}
    
    # Extract costs
    work_cost = params['work_cost_per_day']
    machine_cost = params['machine_rental_cost_per_day']
    e_overtime_reduction = int(params['activity_E_overtime_reduction'])
    e_overtime_cost = params['activity_E_overtime_cost']
    e_review_cost = params['activity_E_followup_review_cost']
    
    # Create Gurobi model
    model = gp.Model("Project_Cost_Minimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Start times for each activity
    S = {a: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f'S_{a}') for a in activities}
    
    # Binary variable for E overtime
    overtime_E = model.addVar(vtype=GRB.BINARY, name='overtime_E')
    
    # Project completion time
    T = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name='T')
    
    # Precedence constraints
    for pred, succ in precedences:
        model.addConstr(S[succ] >= S[pred] + dur[pred], name=f'prec_{pred}_{succ}')
    
    # E duration constraint based on overtime decision
    # If overtime_E = 0, duration = 10; if overtime_E = 1, duration = 7
    # Using big-M formulation: S[E] + dur[E] - overtime_E * reduction <= end_E
    # Actually, we need to express the end time of E properly
    
    # End time of E = S[E] + dur[E] - overtime_E * e_overtime_reduction
    # We'll add this to the precedence constraints where E is a predecessor
    
    # For E -> F constraint: S[F] >= S[E] + dur[E] - overtime_E * e_overtime_reduction
    model.addConstr(S['F'] >= S['E'] + dur['E'] - overtime_E * e_overtime_reduction, name='prec_E_F')
    
    # Update other E-related precedence constraints
    # Remove the generic E->F constraint and replace with the one above
    # Actually, let me rebuild the precedence constraints properly
    
    # Clear and rebuild precedence constraints
    for pred, succ in precedences:
        if pred == 'E':
            # Special handling for E due to overtime
            model.addConstr(S[succ] >= S[pred] + dur[pred] - overtime_E * e_overtime_reduction, 
                          name=f'prec_{pred}_{succ}')
        else:
            model.addConstr(S[succ] >= S[pred] + dur[pred], name=f'prec_{pred}_{succ}')
    
    # Project completion time constraints
    # T must be >= end time of all terminal activities
    # From the original code: T >= S['C'] + dur['C'] and T >= S['B'] + dur['B']
    model.addConstr(T >= S['C'] + dur['C'], name='T_C')
    model.addConstr(T >= S['B'] + dur['B'], name='T_B')
    
    # Objective function
    # Work cost: work_cost * T
    # Machine rental: machine_cost * (S[B] + dur[B] - S[A])
    # Overtime cost: e_overtime_cost * overtime_E
    # Review cost: e_review_cost * overtime_E
    
    obj = work_cost * T + machine_cost * (S['B'] + dur['B'] - S['A']) + \
          e_overtime_cost * overtime_E + e_review_cost * overtime_E
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Print result
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
