import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils import load_demand, load_parameters
import gurobipy as gp
from gurobipy import GRB

def main():
    demand_data = load_demand()
    params = load_parameters()
    
    # Planning months: July to December
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']
    
    # Production costs (June to December rates)
    cost_I = params['product_I_cost_jun_to_dec']  # 4.5
    cost_II = params['product_II_cost_jun_to_dec']  # 7
    prod_cost = {'Product_I': cost_I, 'Product_II': cost_II}
    
    # Volume per unit
    vol_I = params['product_I_volume']  # 0.2
    vol_II = params['product_II_volume']  # 0.4
    volume = {'Product_I': vol_I, 'Product_II': vol_II}
    
    # Warehouse capacity (revised: 30,000 cubic meters)
    warehouse_cap = params['warehouse_capacity']  # 30,000
    
    # Warehouse cost (own warehouse only)
    own_cost = params['own_warehouse_cost']  # 1 yuan/m³/month
    
    # Machine hours per unit
    mh_I = params['product_I_machine_hours']  # 0.8
    mh_II = params['product_II_machine_hours']  # 1.6
    machine_hours = {'Product_I': mh_I, 'Product_II': mh_II}
    
    # Machine hours capacity per month
    mh_capacity = params['machine_hours_capacity_monthly']  # 120,000
    
    # Electricity consumption per unit
    power_I = params['product_I_power_kwh']  # 2 kWh
    power_II = params['product_II_power_kwh']  # 3 kWh
    power = {'Product_I': power_I, 'Product_II': power_II}
    
    # Electricity costs
    grid_cost = params['grid_electricity_cost']  # 0.6 yuan/kWh
    gen_cost = params['generator_electricity_cost']  # 0.9 yuan/kWh
    
    # Grid quotas by month
    grid_quota = {
        'July': params['grid_quota_july'],
        'August': params['grid_quota_august'],
        'September': params['grid_quota_september'],
        'October': params['grid_quota_october'],
        'November': params['grid_quota_november'],
        'December': params['grid_quota_december']
    }
    
    # Generator maximums by month
    gen_max = {
        'July': params['generator_max_july'],
        'August': params['generator_max_august'],
        'September': params['generator_max_september'],
        'October': params['generator_max_october'],
        'November': params['generator_max_november'],
        'December': params['generator_max_december']
    }
    
    # Demand for planning months
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]
    
    # Initial inventory (July start)
    initial_inv = params['initial_inventory_july']  # 0
    
    # Create model
    model = gp.Model("Production_Planning_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Production quantities
    x = model.addVars(months, products, lb=0, name="prod")
    
    # Inventory at end of month
    inv = model.addVars(months, products, lb=0, name="inv")
    
    # Grid electricity usage (kWh)
    grid_elec = model.addVars(months, lb=0, name="grid_elec")
    
    # Generator electricity usage (kWh)
    gen_elec = model.addVars(months, lb=0, name="gen_elec")
    
    # Warehouse volume used (cubic meters)
    wh_vol = model.addVars(months, lb=0, name="wh_vol")
    
    # Objective: minimize production cost + electricity cost + warehouse holding cost
    obj = (
        gp.quicksum(prod_cost[p] * x[m, p] for m in months for p in products) +
        gp.quicksum(grid_cost * grid_elec[m] for m in months) +
        gp.quicksum(gen_cost * gen_elec[m] for m in months) +
        gp.quicksum(own_cost * wh_vol[m] for m in months)
    )
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    for i, m in enumerate(months):
        # Inventory balance for each product
        for p in products:
            if i == 0:
                # First month (July): initial inventory is 0
                model.addConstr(inv[m, p] == initial_inv + x[m, p] - demand[(m, p)])
            else:
                prev_m = months[i - 1]
                model.addConstr(inv[m, p] == inv[prev_m, p] + x[m, p] - demand[(m, p)])
        
        # Machine hours capacity constraint
        model.addConstr(gp.quicksum(machine_hours[p] * x[m, p] for p in products) <= mh_capacity)
        
        # Electricity demand must equal grid + generator
        elec_demand = gp.quicksum(power[p] * x[m, p] for p in products)
        model.addConstr(grid_elec[m] + gen_elec[m] == elec_demand)
        
        # Grid electricity quota constraint
        model.addConstr(grid_elec[m] <= grid_quota[m])
        
        # Generator maximum constraint
        model.addConstr(gen_elec[m] <= gen_max[m])
        
        # Warehouse volume constraint
        total_vol = gp.quicksum(volume[p] * inv[m, p] for p in products)
        model.addConstr(wh_vol[m] >= total_vol)
        model.addConstr(wh_vol[m] <= warehouse_cap)
    
    # Solve
    model.optimize()
    
    # Get objective value
    obj_val = model.ObjVal
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
