import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Get directory paths
    base = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base, 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    n = int(params['n'])
    premium_multiplier = params['premium_cost_multiplier']
    min_premium_share = params['min_premium_share']
    
    # Read factory data
    factories = []
    d = []  # Transportation volumes
    c = []  # Transportation costs
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            factories.append(row['Factory'])
            d.append([float(row[f'Transportation_volume_to_Location_{j+1}']) for j in range(n)])
            c.append([float(row[f'Transportation_cost_to_Location_{j+1}']) for j in range(n)])
    
    # Calculate outbound volume for each factory
    outbound_volume = [sum(d[i]) for i in range(n)]
    
    # Calculate standard and premium costs
    c_std = [[0.0] * n for _ in range(n)]
    c_prem = [[0.0] * n for _ in range(n)]
    
    for i in range(n):
        for p in range(n):
            if outbound_volume[i] > 0:
                weighted_cost = sum(d[i][j] * c[p][j] for j in range(n))
                c_std[i][p] = weighted_cost / outbound_volume[i]
                c_prem[i][p] = premium_multiplier * c_std[i][p]
    
    # Create Gurobi model
    model = gp.Model("factory_assignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(n, n, vtype=GRB.BINARY, name="assign")  # x[i,p] = 1 if factory i assigned to location p
    y = model.addVars(n, n, vtype=GRB.BINARY, name="premium")  # y[i,p] = 1 if premium mode for (i,p)
    v_std = model.addVars(n, n, lb=0, name="v_std")  # Standard volume
    v_prem = model.addVars(n, n, lb=0, name="v_prem")  # Premium volume
    
    # Constraint: Each factory assigned to exactly one location
    model.addConstrs((gp.quicksum(x[i, p] for p in range(n)) == 1 for i in range(n)), "one_location_per_factory")
    
    # Constraint: Each location hosts at most one factory
    model.addConstrs((gp.quicksum(x[i, p] for i in range(n)) <= 1 for p in range(n)), "one_factory_per_location")
    
    # Constraint: Premium implies minimum volume share
    for i in range(n):
        for p in range(n):
            model.addConstr(v_prem[i, p] >= min_premium_share * outbound_volume[i] * y[i, p])
    
    # Constraint: Volume only at assigned location
    for i in range(n):
        for p in range(n):
            model.addConstr(v_std[i, p] + v_prem[i, p] <= outbound_volume[i] * x[i, p])
            model.addConstr(v_std[i, p] + v_prem[i, p] >= outbound_volume[i] * x[i, p])
    
    # Objective: Minimize total cost
    model.setObjective(
        gp.quicksum(c_std[i][p] * v_std[i, p] + c_prem[i][p] * v_prem[i, p] 
                   for i in range(n) for p in range(n)),
        GRB.MINIMIZE
    )
    
    # Solve
    model.optimize()
    
    # Output results
    print(f"Optimal cost: {model.objVal}")
    print("\nAssignments:")
    for i in range(n):
        for p in range(n):
            if x[i, p].X > 0.5:
                print(f"Factory {i} -> Location {p}")
                print(f"  Standard volume: {v_std[i, p].X}")
                print(f"  Premium volume: {v_prem[i, p].X}")
                print(f"  Premium mode: {'Yes' if y[i, p].X > 0.5 else 'No'}")

solve()
