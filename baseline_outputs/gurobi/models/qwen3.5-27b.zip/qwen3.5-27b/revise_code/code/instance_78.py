import os
import gurobipy as gp
from gurobipy import GRB
import pandas as pd

def solve():
    # Get data paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    table_path = os.path.join(script_dir, 'data', 'table_3_3.csv')
    params_path = os.path.join(script_dir, 'data', 'general_parameters.csv')
    
    # Load data
    df = pd.read_csv(table_path)
    params_df = pd.read_csv(params_path)
    
    # Extract parameters
    sales_goal = float(params_df.loc[params_df['Parameter_Name'] == 'monthly_sales_goal', 'Value'].values[0])
    pt_ft_ratio = float(params_df.loc[params_df['Parameter_Name'] == 'pt_ft_overtime_ratio', 'Value'].values[0])
    
    # Extract clerk data
    ft_row = df[df['Role'] == 'Full-time'].iloc[0]
    pt_row = df[df['Role'] == 'Part-time'].iloc[0]
    
    # Number of clerks (from classic textbook problem)
    num_ft = 5
    num_pt = 4
    
    # Calculate normal sales from full employment
    normal_sales_ft = num_ft * ft_row['Monthly_Working_Hours'] * ft_row['Sales_Volume_Pairs_Per_Hour']
    normal_sales_pt = num_pt * pt_row['Monthly_Working_Hours'] * pt_row['Sales_Volume_Pairs_Per_Hour']
    total_normal_sales = normal_sales_ft + normal_sales_pt
    
    # Create Gurobi model
    model = gp.Model("Minimize_Overtime")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: overtime hours for each role
    y_ft = model.addVar(lb=0, name='y_ft')
    y_pt = model.addVar(lb=0, name='y_pt')
    
    # Objective: Minimize total overtime hours
    model.setObjective(y_ft + y_pt, GRB.MINIMIZE)
    
    # Constraint 1: Achieve monthly sales goal
    overtime_sales_needed = sales_goal - total_normal_sales
    model.addConstr(
        y_ft * ft_row['Sales_Volume_Pairs_Per_Hour'] + 
        y_pt * pt_row['Sales_Volume_Pairs_Per_Hour'] >= overtime_sales_needed,
        name='sales_constraint'
    )
    
    # Constraint 2: Part-time overtime >= 50% of full-time overtime
    model.addConstr(
        y_pt >= pt_ft_ratio * y_ft,
        name='overtime_ratio_constraint'
    )
    
    # Optimize
    model.optimize()
    
    # Output result
    print(f"FINAL_OBJ_VALUE: {round(model.objVal, 4)}")

if __name__ == '__main__':
    solve()
