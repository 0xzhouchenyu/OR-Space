import os
import csv
import gurobipy as gp
from gurobipy import GRB
import sys

def main():
    # Determine base directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load General Parameters
    params = {}
    param_file = os.path.join(data_dir, 'general_parameters.csv')
    with open(param_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name']
            val_str = row['Value']
            try:
                val = float(val_str)
            except ValueError:
                val = val_str
            params[key] = val

    # Load Demand Forecast
    demand = {}
    demand_file = os.path.join(data_dir, 'table_1.csv')
    with open(demand_file, 'r') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            demand[i] = float(row['Demand_Forecast'])
    
    T = len(demand)
    
    # Extract parameters
    initial_workforce = int(params['initial_workforce'])
    initial_inventory = params['initial_inventory']
    sales_price = params['sales_price']
    raw_material_cost = params['raw_material_cost']
    outsourcing_cost = params['outsourcing_cost']
    inventory_holding_cost = params['inventory_holding_cost']
    backorder_cost = params['backorder_cost']
    labor_requirement = params['labor_requirement']
    regular_labor_hours = params['regular_labor_hours']
    regular_wage = params['regular_wage']
    overtime_hours_limit = params['overtime_hours_limit']
    overtime_wage = params['overtime_wage']
    hiring_cost = params['hiring_cost']
    firing_cost = params['firing_cost']
    terminal_inventory = params['terminal_inventory']
    terminal_backorders = params['terminal_backorders']
    contract_min_units = params.get('contract_min_units', 0)
    contract_bigM = params.get('contract_bigM', 60000)
    
    # Create Model
    m = gp.Model("FoldableTableProduction")
    m.setParam('OutputFlag', 0)
    
    # Decision Variables
    # Workforce
    W = [m.addVar(lb=0, name=f"W_{t}") for t in range(T)]
    H = [m.addVar(lb=0, name=f"H_{t}") for t in range(T)]
    F = [m.addVar(lb=0, name=f"F_{t}") for t in range(T)]
    
    # Production (Split into Regular and Overtime for clarity and constraints)
    P_reg = [m.addVar(lb=0, name=f"Preg_{t}") for t in range(T)]
    P_ot = [m.addVar(lb=0, name=f"Pot_{t}") for t in range(T)]
    
    # Outsourcing
    O = [m.addVar(lb=0, name=f"O_{t}") for t in range(T)]
    
    # Inventory and Backorders
    Inv = [m.addVar(lb=0, name=f"I_{t}") for t in range(T)]
    B = [m.addVar(lb=0, name=f"B_{t}") for t in range(T)]
    
    # Contract Switch Binaries (For April, May, June -> Indices 3, 4, 5)
    # Although the requirement is hard, we introduce binaries as requested.
    Z = [m.addVar(vtype=GRB.BINARY, name=f"Z_{t}") for t in range(T)]
    
    # Constraints
    for t in range(T):
        # Workforce Balance
        if t == 0:
            m.addConstr(W[t] == initial_workforce + H[t] - F[t])
        else:
            m.addConstr(W[t] == W[t-1] + H[t] - F[t])
        
        # Capacity Constraints
        # Regular Time Capacity
        m.addConstr(P_reg[t] * labor_requirement <= W[t] * regular_labor_hours)
        # Overtime Capacity
        m.addConstr(P_ot[t] * labor_requirement <= W[t] * overtime_hours_limit)
        
        # Inventory Balance
        prev_inv = initial_inventory if t == 0 else Inv[t-1]
        prev_b = 0 if t == 0 else B[t-1]
        # Flow: Start + Prod + Outsource - Demand = End - Backlog
        # Inv[t] - B[t] = (Prev_Inv - Prev_B) + P_reg[t] + P_ot[t] + O[t] - Demand[t]
        m.addConstr(Inv[t] - B[t] == prev_inv - prev_b + P_reg[t] + P_ot[t] + O[t] - demand[t])
        
        # Contract Constraints for April, May, June (Indices 3, 4, 5)
        if t >= 3 and t <= 5:
            # Enforce Minimum Regular Production
            # Using Big-M and Binary Switch as requested
            # Constraint: P_reg[t] >= contract_min_units - BigM * (1 - Z[t])
            # And force Z[t] = 1 to activate the constraint
            m.addConstr(Z[t] == 1)
            m.addConstr(P_reg[t] >= contract_min_units - contract_bigM * (1 - Z[t]))
            
    # Terminal Conditions
    m.addConstr(Inv[T-1] >= terminal_inventory)
    m.addConstr(B[T-1] <= terminal_backorders)
    
    # Objective Function
    # Revenue
    # Total Sold = Sum(Demand) - Final_Backlog + Initial_Backlog
    # Since Initial Backlog = 0 and Final Backlog = 0, Total Sold = Sum(Demand)
    total_demand = sum(demand.values())
    revenue = sales_price * total_demand
    
    # Costs
    material_cost = gp.quicksum([raw_material_cost * (P_reg[t] + P_ot[t]) for t in range(T)])
    outsource_cost = gp.quicksum([outsourcing_cost * O[t] for t in range(T)])
    holding_cost = gp.quicksum([inventory_holding_cost * Inv[t] for t in range(T)])
    backorder_cost = gp.quicksum([backorder_cost * B[t] for t in range(T)])
    regular_labor_cost = gp.quicksum([regular_wage * regular_labor_hours * W[t] for t in range(T)])
    overtime_cost = gp.quicksum([overtime_wage * labor_requirement * P_ot[t] for t in range(T)])
    hiring_cost_total = gp.quicksum([hiring_cost * H[t] for t in range(T)])
    firing_cost_total = gp.quicksum([firing_cost * F[t] for t in range(T)])
    
    total_cost = (material_cost + outsource_cost + holding_cost + backorder_cost + 
                  regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total)
    
    profit = revenue - total_cost
    
    m.setObjective(profit, GRB.MAXIMIZE)
    
    # Solve
    m.optimize()
    
    obj_val = m.MRXNObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
