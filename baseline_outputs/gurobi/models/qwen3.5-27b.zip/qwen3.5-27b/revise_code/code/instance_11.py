import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    # Read CSVs
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    # Parse Table 1
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]
    
    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    insp_a_base = float(row_a['Inspection_hours_per_unit']) # Not used directly, replaced by params
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])
    
    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    insp_b_base = float(row_b['Inspection_hours_per_unit']) # Not used directly
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])
    
    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp_ih = float(row_cap['Inspection_hours_per_unit']) # In-house capacity
    
    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])
    cost_asm = float(row_cost['Assembly_hours_per_unit'])
    # cost_insp_base = float(row_cost['Inspection_hours_per_unit']) # Replaced by params
    
    # Parse Parameters
    def get_param(name):
        return float(df_params[df_params['Parameter_Name'] == name]['Value'].iloc[0])
    
    min_profit = get_param('min_weekly_profit')
    min_a = get_param('min_type_a_production')
    insp_a_M = get_param('insp_a_M')
    insp_b_M = get_param('insp_b_M')
    insp_a_E = get_param('insp_a_E')
    insp_b_E = get_param('insp_b_E')
    cap_ext = get_param('cap_ext')
    cost_insp_M = get_param('cost_insp_M')
    cost_insp_E = get_param('cost_insp_E')
    cost_ext = get_param('cost_ext')
    mode_fee_M = get_param('mode_fee_M')
    mode_fee_E = get_param('mode_fee_E')
    risk_penalty_M = get_param('risk_penalty_M')
    cost_insp_weight = get_param('cost_insp_weight')
    planning_horizon = int(get_param('planning_horizon_weeks'))
    idle_tolerance = get_param('idle_tolerance')
    
    # Initialize Model
    model = gp.Model("Motorcycle_Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Sets
    weeks = range(planning_horizon)
    products = ['A', 'B']
    
    # Decision Variables
    # Production quantities split by mode to handle mode-dependent hours/costs linearly
    # x_prod_mode[week][product][mode_idx] where mode_idx 0=Manual, 1=Enhanced
    x = {}
    for t in weeks:
        for p in products:
            x[(t, p, 0)] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{p}_M_{t}")
            x[(t, p, 1)] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{p}_E_{t}")
            
    # Mode Selection Binary Variable: z[t] = 1 if Manual, 0 if Enhanced
    z = {}
    for t in weeks:
        z[t] = model.addVar(vtype=GRB.BINARY, name=f"z_{t}")
        
    # Inspection Usage Variables
    h_IH = {} # In-House Inspection Hours Used
    h_Ext = {} # External Inspection Hours Used
    for t in weeks:
        h_IH[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"h_IH_{t}")
        h_Ext[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"h_Ext_{t}")
        
    # Idle Time Variables
    idle_mfg = {}
    idle_asm = {}
    idle_insp_ih = {} # Only In-House Idle Time weighted
    for t in weeks:
        idle_mfg[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"idle_mfg_{t}")
        idle_asm[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"idle_asm_{t}")
        idle_insp_ih[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"idle_insp_ih_{t}")
        
    # Helper for BigM (Capacity bounds)
    # Max possible units roughly: Mfg Cap / Min Mfg Hours = 120 / 20 = 6. 
    # Safe BigM = 100.
    BIGM = 100
    
    # Constraints
    for t in weeks:
        # 1. Link Production to Mode
        # If z[t]=1 (Manual), x_E must be 0. If z[t]=0 (Enhanced), x_M must be 0.
        for p in products:
            model.addConstr(x[(t, p, 0)] <= BIGM * z[t], name=f"link_M_{p}_{t}")
            model.addConstr(x[(t, p, 1)] <= BIGM * (1 - z[t]), name=f"link_E_{p}_{t}")
            
        # 2. Total Production
        x_A_total = x[(t, 'A', 0)] + x[(t, 'A', 1)]
        x_B_total = x[(t, 'B', 0)] + x[(t, 'B', 1)]
        
        # 3. Minimum Type A Production
        model.addConstr(x_A_total >= min_a, name=f"min_A_{t}")
        
        # 4. Capacity Constraints
        # Manufacturing
        used_mfg = mfg_a * x_A_total + mfg_b * x_B_total
        model.addConstr(used_mfg <= cap_mfg, name=f"cap_mfg_{t}")
        model.addConstr(idle_mfg[t] == cap_mfg - used_mfg, name=f"idle_def_mfg_{t}")
        
        # Assembly
        used_asm = asm_a * x_A_total + asm_b * x_B_total
        model.addConstr(used_asm <= cap_asm, name=f"cap_asm_{t}")
        model.addConstr(idle_asm[t] == cap_asm - used_asm, name=f"idle_def_asm_{t}")
        
        # Inspection
        # Used Hours depends on mode-specific rates
        used_insp_M = insp_a_M * x[(t, 'A', 0)] + insp_b_M * x[(t, 'B', 0)]
        used_insp_E = insp_a_E * x[(t, 'A', 1)] + insp_b_E * x[(t, 'B', 1)]
        total_used_insp = used_insp_M + used_insp_E
        
        # Split into In-House and External
        model.addConstr(h_IH[t] + h_Ext[t] == total_used_insp, name=f"insp_split_{t}")
        
        # In-House Capacity Limit
        model.addConstr(h_IH[t] <= cap_insp_ih, name=f"cap_insp_ih_{t}")
        
        # External Capacity Limit (Only available if Enhanced, i.e., z=0)
        model.addConstr(h_Ext[t] <= cap_ext * (1 - z[t]), name=f"cap_insp_ext_{t}")
        
        # Idle In-House Inspection
        model.addConstr(idle_insp_ih[t] == cap_insp_ih - h_IH[t], name=f"idle_def_insp_ih_{t}")
        
        # 5. Weekly Profit Constraint
        # Revenue
        revenue = price_a * x_A_total + price_b * x_B_total
        
        # Variable Costs
        var_cost_mfg = cost_mfg * used_mfg
        var_cost_asm = cost_asm * used_asm
        # Inspection Cost: Manual uses cost_insp_M, Enhanced uses cost_insp_E (IH) + cost_ext (Ext)
        # Note: used_insp_M is only > 0 if z=1. h_IH/h_Ext only > 0 if z=0.
        var_cost_insp = cost_insp_M * used_insp_M + cost_insp_E * h_IH[t] + cost_ext * h_Ext[t]
        
        # Mode Fees
        mode_fee = mode_fee_M * z[t] + mode_fee_E * (1 - z[t])
        
        profit = revenue - var_cost_mfg - var_cost_asm - var_cost_insp - mode_fee
        model.addConstr(profit >= min_profit, name=f"min_profit_{t}")
        
    # --- Stage 1: Minimize Weighted Idle Time + Risk Penalty ---
    obj1_terms = []
    for t in weeks:
        # Idle Costs
        c_idle_mfg = cost_mfg * idle_mfg[t]
        c_idle_asm = cost_asm * idle_asm[t]
        c_idle_insp = cost_insp_weight * idle_insp_ih[t]
        
        # Risk Penalty (Manual Mode)
        c_risk = risk_penalty_M * z[t]
        
        obj1_terms.append(c_idle_mfg + c_idle_asm + c_idle_insp + c_risk)
        
    model.setObjective(gp.quicksum(obj1_terms), GRB.MINIMIZE)
    model.optimize()
    
    if model.status != GRB.OPTIMAL:
        print("ERROR: Stage 1 did not find optimal solution.")
        return

    stage1_val = model.objVal
    
    # --- Stage 2: Maximize Profit subject to Stage 1 Objective ---
    # Add constraint to lock Stage 1 performance
    model.addConstr(gp.quicksum(obj1_terms) <= stage1_val + idle_tolerance, name="lex_constraint")
    
    # Change Objective to Maximize Total Profit
    profit_terms = []
    for t in weeks:
        x_A_total = x[(t, 'A', 0)] + x[(t, 'A', 1)]
        x_B_total = x[(t, 'B', 0)] + x[(t, 'B', 1)]
        
        used_mfg = mfg_a * x_A_total + mfg_b * x_B_total
        used_asm = asm_a * x_A_total + asm_b * x_B_total
        used_insp_M = insp_a_M * x[(t, 'A', 0)] + insp_b_M * x[(t, 'B', 0)]
        used_insp_E = insp_a_E * x[(t, 'A', 1)] + insp_b_E * x[(t, 'B', 1)]
        
        revenue = price_a * x_A_total + price_b * x_B_total
        var_cost = (cost_mfg * used_mfg + cost_asm * used_asm + 
                    cost_insp_M * used_insp_M + cost_insp_E * h_IH[t] + cost_ext * h_Ext[t])
        mode_fee = mode_fee_M * z[t] + mode_fee_E * (1 - z[t])
        
        profit = revenue - var_cost - mode_fee
        profit_terms.append(profit)
        
    model.setObjective(gp.quicksum(profit_terms), GRB.MAXIMIZE)
    model.optimize()
    
    if model.status != GRB.OPTIMAL:
        print("ERROR: Stage 2 did not find optimal solution.")
        return
        
    final_obj = model.objVal
    print(f"FINAL_OBJ_VALUE: {round(final_obj, 4)}")

if __name__ == '__main__':
    solve()
