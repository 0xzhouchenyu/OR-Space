import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            val_str = row['Value'].strip()
            try:
                params[key] = float(val_str)
            except ValueError:
                params[key] = val_str
    
    total_space = params['mall_total_space']
    rent_pct = params['rent_percentage'] / 100.0
    common_area_factor = params.get('common_area_factor', 1.0)
    gm_concession = params.get('general_merchandise_third_store_concession', 0.0)
    cat_security_cost = params.get('catering_third_store_security_cost', 0.0)
    
    # Read store data
    stores = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            store_type = row['Store_Type'].strip()
            area = float(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            
            # Skip if range is invalid or zero width (e.g., 0 to 0)
            if min_n > max_n:
                continue
            
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            
            stores.append({
                'name': store_type,
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits
            })
    
    # Create Model
    model = gp.Model("Mall_Lease_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Variables
    # For each store type i, and possible count n (from min to max), 
    # binary variable y[i][n] = 1 if count is n.
    y_vars = {}
    
    for idx, s in enumerate(stores):
        store_name = s['name']
        y_vars[store_name] = {}
        for n in range(s['min'], s['max'] + 1):
            var = model.addVar(vtype=GRB.BINARY, name=f"{store_name}_{n}")
            y_vars[store_name][n] = var
    
    # Constraints: Exactly one count selected per store type
    for s in stores:
        store_name = s['name']
        model.addConstr(gp.quicksum(y_vars[store_name][n] for n in range(s['min'], s['max'] + 1)) == 1)
        
    # Constraint: Total Space
    # Effective Area = Area * common_area_factor
    space_expr = gp.quicksum(
        n * s['area'] * common_area_factor * y_vars[s['name']][n]
        for s in stores
        for n in range(s['min'], s['max'] + 1)
    )
    model.addConstr(space_expr <= total_space)
    
    # Objective: Maximize Rent Income - Penalties
    # Rent Income = Sum(Count * Profit_Per_Store * Rent_Pct)
    obj_expr = gp.quicksum(
        n * s['profits'].get(n, 0) * rent_pct * y_vars[s['name']][n]
        for s in stores
        for n in range(s['min'], s['max'] + 1)
    )
    
    # Penalty: Catering Security Cost if count == 3
    catering_idx = None
    for i, s in enumerate(stores):
        if s['name'] == 'Catering':
            catering_idx = i
            break
    
    if catering_idx is not None:
        s = stores[catering_idx]
        if 3 in range(s['min'], s['max'] + 1):
            obj_expr -= cat_security_cost * y_vars[s['name']][3]
            
    # Penalty: GM Concession if count == 3
    gm_idx = None
    for i, s in enumerate(stores):
        if s['name'] == 'General_Merchandise':
            gm_idx = i
            break
            
    if gm_idx is not None:
        s = stores[gm_idx]
        if 3 in range(s['min'], s['max'] + 1):
            obj_expr -= gm_concession * y_vars[s['name']][3]
            
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()
