import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = int(params['fixed_order_cost'])
    august_bulk_threshold = int(params['august_bulk_order_threshold'])
    august_bulk_fee = int(params['august_bulk_receiving_fee'])
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create MIP model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = {m: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"buy_{m}") for m in months}
    sell = {m: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"sell_{m}") for m in months}
    stock = {m: model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=warehouse_capacity, name=f"stock_{m}") for m in months}
    
    # Binary variables for fixed order cost (if any purchase in month)
    order_binary = {m: model.addVar(vtype=GRB.BINARY, name=f"order_{m}") for m in months}
    
    # Binary variable for August bulk receiving fee
    august_bulk_binary = model.addVar(vtype=GRB.BINARY, name="august_bulk")
    
    # Big-M value (use warehouse capacity as reasonable upper bound)
    M = warehouse_capacity
    
    # Objective: maximize total profit (revenue - cost - fixed costs)
    obj = gp.quicksum(sell_price[m] * sell[m] - buy_price[m] * buy[m] for m in months)
    obj -= gp.quicksum(fixed_order_cost * order_binary[m] for m in months)
    obj -= august_bulk_fee * august_bulk_binary
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Stock balance constraints
    for i, m in enumerate(months):
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_stock = stock[months[i-1]]
        
        # Stock balance: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], f"balance_{m}")
        
        # After buying, before selling, warehouse constraint:
        # prev_stock + buy[m] <= warehouse_capacity
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, f"warehouse_after_buy_{m}")
        
        # Fixed order cost constraint: if buy[m] > 0, then order_binary[m] = 1
        # buy[m] <= M * order_binary[m]
        model.addConstr(buy[m] <= M * order_binary[m], f"order_fixed_{m}")
    
    # August bulk receiving fee constraint: if buy[8] > 300, then august_bulk_binary = 1
    # buy[8] <= august_bulk_threshold + M * august_bulk_binary
    # This means: if buy[8] > 300, august_bulk_binary must be 1
    model.addConstr(buy[8] <= august_bulk_threshold + M * august_bulk_binary, f"august_bulk_gate")
    
    # Update model
    model.update()
    
    # Solve
    model.optimize()
    
    # Print solution details
    for m in months:
        print(f"Month {m}: Buy={buy[m].X:.1f} @ {buy_price[m]}, "
              f"Sell={sell[m].X:.1f} @ {sell_price[m]}, "
              f"Stock={stock[m].X:.1f}")
    
    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
