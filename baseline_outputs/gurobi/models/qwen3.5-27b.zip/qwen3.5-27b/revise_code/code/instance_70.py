import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_distance_matrix(filepath):
    """Load distance matrix from CSV file."""
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: ['City', '1', '2', '3', '4', ...]
        city_labels = header[1:]
        
        dist = []
        cities = []
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
    
    return cities, dist

def load_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['parameter']] = row['value']
    return params

def solve_tsp():
    # Get directory paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load data
    params_file = os.path.join(data_dir, 'general_parameters.csv')
    dist_file = os.path.join(data_dir, 'table_1.csv')
    
    params = load_parameters(params_file)
    cities, dist = load_distance_matrix(dist_file)
    
    n = len(cities)
    
    # Parse parameters
    start_city = int(params['start_city']) - 1  # Convert to 0-indexed
    end_city = int(params['end_city']) - 1      # Convert to 0-indexed
    prohibited_from = int(params['prohibited_from']) - 1
    prohibited_to = int(params['prohibited_to']) - 1
    inspection_from = int(params['inspection_arc_from']) - 1
    inspection_to = int(params['inspection_arc_to']) - 1
    inspection_cost = float(params['inspection_stop_cost'])
    
    # Create Gurobi model
    model = gp.Model("TSP_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i,j] = 1 if we travel from city i to city j
    x = {}
    for i in range(n):
        for j in range(n):
            if i != j:
                x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
    
    # MTZ variables for subtour elimination
    u = {}
    for i in range(1, n):
        u[i] = model.addVar(lb=1, ub=n-1, vtype=GRB.CONTINUOUS, name=f"u_{i}")
    
    # Objective function with inspection cost adjustment
    obj = gp.quicksum(dist[i][j] * x[i, j] for i in range(n) for j in range(n) if i != j)
    # Add inspection cost for arc 2->3
    obj += inspection_cost * x[inspection_from][inspection_to]
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Each city is left exactly once (except end city)
    for i in range(n):
        if i != end_city:
            model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1)
    
    # Each city is entered exactly once (except start city)
    for j in range(n):
        if j != start_city:
            model.addConstr(gp.quicksum(x[i, j] for i in range(n) if i != j) == 1)
    
    # Start city has no incoming edge
    model.addConstr(gp.quicksum(x[i, start_city] for i in range(n) if i != start_city) == 0)
    
    # End city has no outgoing edge
    model.addConstr(gp.quicksum(x[end_city, j] for j in range(n) if j != end_city) == 0)
    
    # Prohibit arc from prohibited_from to prohibited_to
    model.addConstr(x[prohibited_from][prohibited_to] == 0)
    
    # MTZ subtour elimination constraints
    for i in range(1, n):
        for j in range(1, n):
            if i != j:
                model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_tsp()
