import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Path handling
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')

    # Load General Parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    # Load Segments
    products = []
    segments = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row['Product']
            if p not in segments:
                segments[p] = []
                products.append(p)
            rng = row['Sales_Volume_Range']
            profit = float(row['Profit'])
            
            if rng.startswith('Above_'):
                lower = float(rng.split('_')[1])
                upper = None
            else:
                parts = rng.split('_')
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({'lower': lower, 'upper': upper, 'profit': profit})

    # Model
    model = gp.Model("Factory_Optimization")
    model.setParam('OutputFlag', 0)
    
    M = 100000 # Large constant
    
    # Decision Variables
    x = {} # Production quantity
    y = {} # Segment selection
    w = {} # Linearized x*y
    profit_vars = {} # Profit per product
    
    for prod in products:
        pname = prod.split('_')[1] # e.g., 'A'
        x[prod] = model.addVar(vtype=GRB.INTEGER, name=f"x_{pname}", lb=0)
        profit_vars[prod] = model.addVar(name=f"profit_{pname}")
        
        y[prod] = []
        w[prod] = []
        for i in range(len(segments[prod])):
            yi = model.addVar(vtype=GRB.BINARY, name=f"y_{pname}_{i}")
            wi = model.addVar(vtype=GRB.CONTINUOUS, name=f"w_{pname}_{i}", lb=0)
            y[prod].append(yi)
            w[prod].append(wi)

    # Objective
    # Maximize Total Profit - Overtime Cost - Review Fee
    overtime = model.addVar(vtype=GRB.CONTINUOUS, name="overtime", lb=0)
    z = model.addVar(vtype=GRB.BINARY, name="overtime_tier_flag")
    
    obj_expr = gp.quicksum(profit_vars[prod] for prod in products)
    obj_expr -= params['overtime_cost_per_hour'] * overtime
    obj_expr -= params['overtime_second_review_fee'] * z
    
    model.setObjective(obj_expr, GRB.MAXIMIZE)

    # Constraints
    # 1. Resource Constraints
    # Tech Prep
    model.addConstr(
        gp.quicksum(params[f"technical_prep_time_{prod.split('_')[1]}"] * x[prod] for prod in products) 
        <= params['available_technical_prep_time'], 
        name="Tech_Prep"
    )
    
    # Materials
    model.addConstr(
        gp.quicksum(params[f"materials_{prod.split('_')[1]}"] * x[prod] for prod in products) 
        <= params['available_materials'], 
        name="Materials"
    )
    
    # Packaging
    model.addConstr(
        gp.quicksum(params[f"pack_units_{prod.split('_')[1]}"] * x[prod] for prod in products) 
        <= params['packaging_cap_units'], 
        name="Packaging"
    )
    
    # Labor & Overtime
    # Total Labor Used <= Regular + Overtime
    model.addConstr(
        gp.quicksum(params[f"labor_time_{prod.split('_')[1]}"] * x[prod] for prod in products) 
        <= params['available_labor_time'] + overtime, 
        name="Labor_Total"
    )
    
    # Overtime Cap
    model.addConstr(overtime <= params['overtime_cap_hours'], name="Overtime_Cap")
    
    # Overtime Tier Logic
    # If overtime > 100, z=1.
    # overtime <= 100 + M * z
    model.addConstr(overtime <= params['overtime_second_review_threshold'] + M * z, name="Overtime_Tier")
    
    # 2. Piecewise Profit Logic
    for prod in products:
        segs = segments[prod]
        
        # Mutual Exclusivity
        model.addConstr(gp.quicksum(y[prod]) <= 1, name=f"Seg_Excl_{prod}")
        
        # Link x and y (if x > 0, at least one y must be 1)
        model.addConstr(x[prod] <= M * gp.quicksum(y[prod]), name=f"Link_x_y_{prod}")
        
        for i, seg in enumerate(segs):
            lo = seg['lower']
            hi = seg['upper']
            pr = seg['profit']
            
            # Linearization: w = x * y
            # w <= x
            model.addConstr(w[prod][i] <= x[prod], name=f"W_leq_X_{prod}_{i}")
            # w <= M * y
            model.addConstr(w[prod][i] <= M * y[prod][i], name=f"W_leq_My_{prod}_{i}")
            # w >= x - M * (1 - y)
            model.addConstr(w[prod][i] >= x[prod] - M * (1 - y[prod][i]), name=f"W_geq_X_minus_M_{prod}_{i}")
            
            # Range Enforcement
            # x >= lo * y
            model.addConstr(x[prod] >= lo * y[prod][i], name=f"Range_Lo_{prod}_{i}")
            
            # x <= hi * y + M * (1 - y)
            if hi is not None:
                model.addConstr(x[prod] <= hi * y[prod][i] + M * (1 - y[prod][i]), name=f"Range_Hi_{prod}_{i}")
            else:
                # If upper is None, effectively infinity, so no upper bound constraint needed from this segment
                pass
            
            # Profit Contribution
            # profit_prod = sum(pr * w)
            # We accumulate this in the objective or via equality constraint.
            # Let's use equality constraint for clarity.
            # Actually, adding to objective directly is harder with sum.
            # Let's keep profit_vars[prod] and constrain it.
            pass

        # Set profit variable
        model.addConstr(
            profit_vars[prod] == gp.quicksum(seg['profit'] * w[prod][i] for i, seg in enumerate(segs)),
            name=f"Profit_Def_{prod}"
        )

    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
