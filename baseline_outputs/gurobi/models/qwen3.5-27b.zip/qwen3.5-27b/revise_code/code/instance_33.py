import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name']
        value = row['Value']
        if value:
            try:
                params[param_name] = float(value)
            except ValueError:
                params[param_name] = value

# Read items and values
items = []
values = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        items.append(row['Item'].strip())
        values.append(int(row['Value'].strip()))

n = len(items)
total_value = sum(values)

# Create the optimization model
model = gp.Model("Inheritance_Split")
model.setParam('OutputFlag', 0)

# Binary variables: x[i] = 1 if item i goes to son 1, 0 if to son 2
x = model.addVars(n, vtype=GRB.BINARY, name="x")

# Deferred diamond variables: d[i] = 1 if diamond i is deferred, 0 otherwise
diamond_indices = [i for i, item in enumerate(items) if 'Diamond' in item]
d = model.addVars(diamond_indices, vtype=GRB.BINARY, name="d")

# Variables for absolute differences
diff_immediate = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="diff_immediate")
diff_total = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="diff_total")

# Calculate total value for each son
value_son1_total = gp.quicksum(values[i] * x[i] for i in range(n))
value_son2_total = total_value - value_son1_total

# Calculate immediate value for each son (excluding deferred diamonds)
value_son1_immediate = gp.quicksum(
    values[i] * x[i] * (1 - d[i]) if i in diamond_indices else values[i] * x[i] 
    for i in range(n)
)
value_son2_immediate = total_value - value_son1_immediate

# Constraints for absolute differences
model.addConstr(diff_immediate >= value_son1_immediate - value_son2_immediate)
model.addConstr(diff_immediate >= value_son2_immediate - value_son1_immediate)
model.addConstr(diff_total >= value_son1_total - value_son2_total)
model.addConstr(diff_total >= value_son2_total - value_son1_total)

# Jack Russell racing dogs must not be separated
jr_indices = [i for i, item in enumerate(items) if 'Jack Russell' in item]
if len(jr_indices) == 2:
    model.addConstr(x[jr_indices[0]] == x[jr_indices[1]])

# Son 1 minimum share constraint
model.addConstr(value_son1_total >= params['son1_min_share'] * total_value)

# High-value items concentration limit
high_value_threshold = params['high_value_threshold']
max_high_value = params['max_high_value_items_per_son']
high_value_indices = [i for i in range(n) if values[i] > high_value_threshold]

model.addConstr(gp.quicksum(x[i] for i in high_value_indices) <= max_high_value)
model.addConstr(gp.quicksum(1 - x[i] for i in high_value_indices) <= max_high_value)

# Deferred diamonds per son limit
deferred_limit = params['deferred_diamonds_per_son']
model.addConstr(gp.quicksum(d[i] * x[i] for i in diamond_indices) <= deferred_limit)
model.addConstr(gp.quicksum(d[i] * (1 - x[i]) for i in diamond_indices) <= deferred_limit)

# Objective: minimize weighted combination of imbalances
immediate_weight = params['immediate_tax_weight']
total_weight = params['total_tax_weight']
model.setObjective(immediate_weight * diff_immediate + total_weight * diff_total, GRB.MINIMIZE)

# Solve
model.optimize()

# Print solution details
obj_val = model.ObjVal

print("Status:", gp.GRB.StatusNames[model.status])
print(f"Total inheritance value: {total_value}")
print()

son1_items = []
son2_items = []
son1_val = 0
son2_val = 0
for i in range(n):
    if x[i].X > 0.5:
        son1_items.append((items[i], values[i]))
        son1_val += values[i]
    else:
        son2_items.append((items[i], values[i]))
        son2_val += values[i]

print("Son 1 receives:")
for item, val in son1_items:
    print(f"  {item}: {val}")
print(f"  Total: {son1_val}")
print()
print("Son 2 receives:")
for item, val in son2_items:
    print(f"  {item}: {val}")
print(f"  Total: {son2_val}")
print()
print(f"Difference: {abs(son1_val - son2_val)}")

print(f"FINAL_OBJ_VALUE: {obj_val}")
