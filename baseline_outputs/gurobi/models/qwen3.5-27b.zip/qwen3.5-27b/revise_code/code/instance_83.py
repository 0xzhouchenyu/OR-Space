import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read time periods and minimum waiters needed
time_periods = []
min_waiters = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        time_periods.append(row['Time'].strip())
        min_waiters.append(int(row['Minimum_Number_of_Waiters_Needed'].strip()))

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        params[param_name] = float(row['Value'].strip())

n = len(time_periods)  # 6 periods

# Extract parameters
work_hours = int(params.get('waiter_work_hours', 8))
waiter_cost_per_shift = float(params.get('waiter_cost_per_shift', 1))
waiter_budget = float(params.get('waiter_budget', 30))

# Peak indicators for each period
peak = []
for i in range(n):
    peak.append(int(params.get(f'peak_{i}', 0)))

# Quality weights for each period
quality = []
for i in range(n):
    quality.append(float(params.get(f'quality_{i}', 1)))

# Determine valid shift start times (must cover one peak and one off-peak)
valid_shifts = []
for i in range(n):
    next_period = (i + 1) % n
    if peak[i] != peak[next_period]:  # One peak, one off-peak
        valid_shifts.append(i)

# Create model
model = gp.Model("Restaurant_Waiters")
model.setParam('OutputFlag', 0)

# Decision variables: x[i] = number of waiters starting at period i
x = {}
for i in valid_shifts:
    x[i] = model.addVar(vtype=GRB.INTEGER, name=f"x_{i}")

# Objective: Maximize service quality score
# Service quality = sum over all periods of (waiters in period * quality weight)
obj = gp.quicksum(
    quality[j] * (x.get(j, 0) + x.get((j - 1) % n, 0))
    for j in range(n)
)
model.setObjective(obj, GRB.MAXIMIZE)

# Constraints: Coverage in each period >= minimum required
for j in range(n):
    prev = (j - 1) % n
    current_coverage = x.get(j, 0) + x.get(prev, 0)
    model.addConstr(current_coverage >= min_waiters[j], f"coverage_{j}")

# Budget constraint: total cost <= waiter_budget
total_cost = gp.quicksum(waiter_cost_per_shift * x[i] for i in valid_shifts)
model.addConstr(total_cost <= waiter_budget, "budget")

# Solve
model.optimize()

# Print results
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: 0")
