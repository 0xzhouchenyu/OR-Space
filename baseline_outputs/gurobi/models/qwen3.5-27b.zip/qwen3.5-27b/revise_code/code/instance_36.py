import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def solve():
    # Paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load Params
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
            
    num_customers = int(params['num_customers'])
    truck_capacity = float(params['truck_capacity'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])
    
    depot_str = params['depot_coordinates'].strip('"').strip("'").strip()
    # Remove parentheses
    depot_str = depot_str.replace('(', '').replace(')', '')
    depot_x, depot_y = map(float, depot_str.split(','))
    depot_coords = (depot_x, depot_y)
    
    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])
    
    # Load Customers
    customers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cust = {
                'id': int(row['Customer_ID']),
                'coords': (float(row['Coordinates_X']), float(row['Coordinates_Y'])),
                'demand': float(row['Demand']),
                'tw_start': float(row['Time_Window_Start']),
                'tw_end': float(row['Time_Window_End']),
                'svc_dur': float(row['Service_Duration']),
                'out_cost': float(row['Outsource_Cost']),
                'mand_ext': int(row['Mandatory_External'])
            }
            customers.append(cust)
            
    # Classify
    internal_ids = [c['id'] for c in customers if c['mand_ext'] == 0]
    external_ids = [c['id'] for c in customers if c['mand_ext'] == 1]
    
    # Map ID to Index for easier handling (0 is depot)
    # Node 0: Depot
    # Node 1..N: Customers
    # We will filter nodes to only include internal ones for routing
    
    # Create mapping from Customer ID to Node Index (1-based relative to internal list)
    # Actually, let's keep IDs as keys for clarity, but build sets.
    
    # Valid Nodes for Routing: Depot (0) + Internal Customers
    # Let's assign indices: 0 = Depot, 1..len(internal) = Internal Customers
    # We need a lookup from ID to Index
    
    id_to_idx = {0: 0}
    idx_to_id = {0: 0}
    current_idx = 1
    
    internal_cust_map = {} # ID -> Cust Dict
    
    for c in customers:
        if c['mand_ext'] == 0:
            id_to_idx[c['id']] = current_idx
            idx_to_id[current_idx] = c['id']
            internal_cust_map[c['id']] = c
            current_idx += 1
            
    n_internal = len(internal_ids)
    V_indices = list(range(n_internal + 1)) # 0 to n_internal
    
    # Coordinates List (Index based)
    coords_list = [depot_coords]
    for idx in range(1, n_internal + 1):
        cid = idx_to_id[idx]
        coords_list.append(internal_cust_map[cid]['coords'])
        
    # Demands List
    demands_list = [0]
    for idx in range(1, n_internal + 1):
        cid = idx_to_id[idx]
        demands_list.append(internal_cust_map[cid]['demand'])
        
    # TW List
    tw_list = [(depot_tw_start, depot_tw_end)]
    for idx in range(1, n_internal + 1):
        cid = idx_to_id[idx]
        tw_list.append((internal_cust_map[cid]['tw_start'], internal_cust_map[cid]['tw_end']))
        
    # SVC List
    svc_list = [0]
    for idx in range(1, n_internal + 1):
        cid = idx_to_id[idx]
        svc_list.append(internal_cust_map[cid]['svc_dur'])
        
    # Outsource Cost List (for internal candidates)
    out_cost_list = [0]
    for idx in range(1, n_internal + 1):
        cid = idx_to_id[idx]
        out_cost_list.append(internal_cust_map[cid]['out_cost'])
        
    # Fixed External Cost
    fixed_external_cost = sum(c['out_cost'] for c in customers if c['mand_ext'] == 1)
    
    # Distance Matrix
    dist = {}
    for i in V_indices:
        for j in V_indices:
            dist[i, j] = calculate_distance(coords_list[i], coords_list[j])
            
    # Arc Generation (Feasibility Check)
    A = []
    for i in V_indices:
        for j in V_indices:
            if i == j: continue
            # Check Time Window Feasibility
            # If i=0 (Depot)
            if i == 0:
                if tw_list[0][0] + dist[i, j] > tw_list[j][1]:
                    continue
            else:
                # i is customer
                if tw_list[i][0] + svc_list[i] + dist[i, j] > tw_list[j][1]:
                    continue
            
            # Check Return to Depot
            if j == 0:
                 if tw_list[i][0] + svc_list[i] + dist[i, j] > tw_list[0][1]:
                     continue
                     
            A.append((i, j))
            
    A_set = set(A)
    
    # Model
    model = gp.Model("VRPHTW_Revised")
    model.setParam('OutputFlag', 0)
    
    # Variables
    x = model.addVars(A, vtype=GRB.BINARY, name="x")
    y = model.addVars(V_indices[1:], vtype=GRB.BINARY, name="y") # Visit indicator for internal customers
    t = model.addVars(V_indices, lb=0, name="t") # Arrival time
    load = model.addVars(V_indices, lb=0, name="load") # Cumulative load
    
    # Objective
    # Minimize Distance + Outsourcing Cost for internal customers not visited
    obj_dist = gp.quicksum(dist[i, j] * x[i, j] for i, j in A)
    obj_out = gp.quicksum(out_cost_list[i] * (1 - y[i]) for i in V_indices[1:])
    
    model.setObjective(obj_dist + obj_out + fixed_external_cost, GRB.MINIMIZE)
    
    # Constraints
    
    # 1. Flow Conservation
    # For each internal customer i: sum(in) = y[i], sum(out) = y[i]
    for i in V_indices[1:]:
        model.addConstr(gp.quicksum(x[j, i] for j in V_indices if (j, i) in A_set) == y[i])
        model.addConstr(gp.quicksum(x[i, j] for j in V_indices if (i, j) in A_set) == y[i])
        
    # 2. Fleet Size Limit
    # Trucks leaving depot <= limit
    model.addConstr(gp.quicksum(x[0, j] for j in V_indices[1:] if (0, j) in A_set) <= inhouse_truck_limit)
    
    # 3. Time Windows
    for i in V_indices:
        model.addConstr(t[i] >= tw_list[i][0])
        model.addConstr(t[i] <= tw_list[i][1])
        
    # 4. Time Propagation
    M_val = 10000 # Large enough
    for i, j in A:
        if j != 0: # Don't enforce time propagation to depot for arrival time logic usually, but here t[0] is start/end
             # t[j] >= t[i] + svc[i] + dist[i,j] - M(1-x)
             model.addConstr(t[j] >= t[i] + svc_list[i] + dist[i, j] - M_val * (1 - x[i, j]))
             
    # 5. Capacity / Load
    # Load at depot is 0
    model.addConstr(load[0] == 0)
    
    # Load propagation
    for i, j in A:
        if j != 0:
            model.addConstr(load[j] >= load[i] + demands_list[j] - truck_capacity * (1 - x[i, j]))
            
    # Load bounds
    for i in V_indices[1:]:
        model.addConstr(load[i] <= truck_capacity * y[i])
        model.addConstr(load[i] >= demands_list[i] * y[i])
        
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

solve()
