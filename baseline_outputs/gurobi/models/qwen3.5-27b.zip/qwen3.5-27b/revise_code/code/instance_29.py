import pandas as pd
import gurobipy as gp
from gurobipy import GRB
import os

def solve():
    # Load data
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    demand_df = pd.read_csv(os.path.join(data_dir, 'table_4_3.csv'))
    supply_df = pd.read_csv(os.path.join(data_dir, 'table_4_4.csv'))
    params_df = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Parse parameters
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])
    
    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem
        
    # Parse supply
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = float(row['Number_of_people'])
        suit = [int(x) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }
        
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]
    
    # Create model
    model = gp.Model("Personnel_Assignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[type, city, specialty]
    x = {}
    for i in types:
        for j in cities:
            for k in specs:
                x[i, j, k] = model.addVar(vtype=GRB.INTEGER, name=f"x_{i}_{j}_{k}")
    
    # Constraint 1: Supply limit for each type
    for i in types:
        model.addConstr(gp.quicksum(x[i, j, k] for j in cities for k in specs) <= supply[i]['num'], f"supply_{i}")
    
    # Constraint 2: Demand must be met for each city-specialty combination
    for j in cities:
        for k in specs:
            model.addConstr(gp.quicksum(x[i, j, k] for i in types) >= demand[(j, k)], f"demand_{j}_{k}")
    
    # Constraint 3: Only assign to suitable specialties
    for i in types:
        for j in cities:
            for k in specs:
                if k not in supply[i]['suit']:
                    model.addConstr(x[i, j, k] == 0, f"suitable_{i}_{j}_{k}")
    
    # Constraint 4: Priority 2 - at least p2_target people get their preferred specialty
    pref_spec_count = gp.quicksum(
        x[i, j, supply[i]['pref_spec']] 
        for i in types 
        for j in cities
    )
    model.addConstr(pref_spec_count >= p2_target, "priority_2")
    
    # Objective: Maximize dual matches (preferred specialty AND preferred city)
    dual_match = gp.quicksum(
        x[i, supply[i]['pref_city'], supply[i]['pref_spec']] 
        for i in types
    )
    model.setObjective(dual_match, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    # Output result
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    solve()
