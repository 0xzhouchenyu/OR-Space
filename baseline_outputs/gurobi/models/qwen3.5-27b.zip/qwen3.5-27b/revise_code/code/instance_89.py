import os
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
profit_A = params['profit_per_kg_product_A']
profit_B = params['profit_per_kg_product_B']
max_hours_w1 = params['max_production_hours_week_1']
max_hours_w2 = params['max_production_hours_week_2']
hours_A = params['hours_per_kg_product_A']
hours_B = params['hours_per_kg_product_B']
min_ratio_B_to_A = params['min_output_ratio_product_B_to_A']
storage_ratio_A_to_B = params['storage_space_ratio_product_A_to_B']
max_storage_A_equiv_w1 = params['max_storage_product_A_equiv_week_1']
max_storage_A_equiv_w2 = params['max_storage_product_A_equiv_week_2']
initial_inv_A = params['initial_inventory_A']
initial_inv_B = params['initial_inventory_B']
storage_cost_A = params['storage_cost_per_kg_A']
storage_cost_B = params['storage_cost_per_kg_B']
promo_bonus_A = params['promo_profit_bonus_A']
promo_bonus_B = params['promo_profit_bonus_B']
max_promo_A = params['max_promotions_product_A']
max_promo_B = params['max_promotions_product_B']

# Calculate max storage units (in terms of B-equivalent units)
max_storage_units_w1 = max_storage_A_equiv_w1 * storage_ratio_A_to_B
max_storage_units_w2 = max_storage_A_equiv_w2 * storage_ratio_A_to_B

# Create the MIP model
model = gp.Model("TwoWeekProductionPlan")
model.setParam('OutputFlag', 0)

# Decision variables - Production (continuous, >= 0)
prod_A_w1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="prod_A_w1")
prod_B_w1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="prod_B_w1")
prod_A_w2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="prod_A_w2")
prod_B_w2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="prod_B_w2")

# Decision variables - Sales (continuous, >= 0)
sell_A_w1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="sell_A_w1")
sell_B_w1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="sell_B_w1")
sell_A_w2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="sell_A_w2")
sell_B_w2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="sell_B_w2")

# Decision variables - Ending Inventory (continuous, >= 0)
inv_A_w1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="inv_A_w1")
inv_B_w1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="inv_B_w1")
inv_A_w2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="inv_A_w2")
inv_B_w2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="inv_B_w2")

# Decision variables - Promotion (binary)
promo_A_w1 = model.addVar(vtype=GRB.BINARY, name="promo_A_w1")
promo_A_w2 = model.addVar(vtype=GRB.BINARY, name="promo_A_w2")
promo_B_w1 = model.addVar(vtype=GRB.BINARY, name="promo_B_w1")
promo_B_w2 = model.addVar(vtype=GRB.BINARY, name="promo_B_w2")

# Objective function: maximize total profit minus storage costs
# Week 1 profit
obj_w1 = (profit_A + promo_bonus_A * promo_A_w1) * sell_A_w1 + \
         (profit_B + promo_bonus_B * promo_B_w1) * sell_B_w1

# Week 2 profit
obj_w2 = (profit_A + promo_bonus_A * promo_A_w2) * sell_A_w2 + \
         (profit_B + promo_bonus_B * promo_B_w2) * sell_B_w2

# Storage costs (only for inventory carried from w1 to w2)
storage_costs = storage_cost_A * inv_A_w1 + storage_cost_B * inv_B_w1

# Total objective
model.setObjective(obj_w1 + obj_w2 - storage_costs, GRB.MAXIMIZE)

# Constraints

# Week 1 Production time constraint
model.addConstr(hours_A * prod_A_w1 + hours_B * prod_B_w1 <= max_hours_w1, "ProdHours_W1")

# Week 2 Production time constraint
model.addConstr(hours_A * prod_A_w2 + hours_B * prod_B_w2 <= max_hours_w2, "ProdHours_W2")

# Week 1 Market demand: B >= 3 * A (on sales/output)
model.addConstr(sell_B_w1 >= min_ratio_B_to_A * sell_A_w1, "MarketDemand_W1")

# Week 2 Market demand: B >= 3 * A (on sales/output)
model.addConstr(sell_B_w2 >= min_ratio_B_to_A * sell_A_w2, "MarketDemand_W2")

# Week 1 Storage capacity constraint (ending inventory)
# Storage space: A takes 4 units/kg, B takes 1 unit/kg
model.addConstr(storage_ratio_A_to_B * inv_A_w1 + inv_B_w1 <= max_storage_units_w1, "Storage_W1")

# Week 2 Storage capacity constraint (ending inventory)
model.addConstr(storage_ratio_A_to_B * inv_A_w2 + inv_B_w2 <= max_storage_units_w2, "Storage_W2")

# Week 1 Inventory balance for Product A
# initial_inv_A + prod_A_w1 = sell_A_w1 + inv_A_w1
model.addConstr(initial_inv_A + prod_A_w1 == sell_A_w1 + inv_A_w1, "InvBalance_A_W1")

# Week 1 Inventory balance for Product B
# initial_inv_B + prod_B_w1 = sell_B_w1 + inv_B_w1
model.addConstr(initial_inv_B + prod_B_w1 == sell_B_w1 + inv_B_w1, "InvBalance_B_W1")

# Week 2 Inventory balance for Product A
# inv_A_w1 + prod_A_w2 = sell_A_w2 + inv_A_w2
model.addConstr(inv_A_w1 + prod_A_w2 == sell_A_w2 + inv_A_w2, "InvBalance_A_W2")

# Week 2 Inventory balance for Product B
# inv_B_w1 + prod_B_w2 = sell_B_w2 + inv_B_w2, "InvBalance_B_W2")
model.addConstr(inv_B_w1 + prod_B_w2 == sell_B_w2 + inv_B_w2, "InvBalance_B_W2")

# Promotion constraints - max 1 promotion per product across both weeks
model.addConstr(promo_A_w1 + promo_A_w2 <= max_promo_A, "MaxPromo_A")
model.addConstr(promo_B_w1 + promo_B_w2 <= max_promo_B, "MaxPromo_B")

# Solve the model
model.optimize()

# Print results
if model.status == GRB.OPTIMAL:
    print(f"Status: {model.status}")
    print(f"Week 1 - Product A: prod={prod_A_w1.X:.4f}, sell={sell_A_w1.X:.4f}, inv={inv_A_w1.X:.4f}, promo={promo_A_w1.X}")
    print(f"Week 1 - Product B: prod={prod_B_w1.X:.4f}, sell={sell_B_w1.X:.4f}, inv={inv_B_w1.X:.4f}, promo={promo_B_w1.X}")
    print(f"Week 2 - Product A: prod={prod_A_w2.X:.4f}, sell={sell_A_w2.X:.4f}, inv={inv_A_w2.X:.4f}, promo={promo_A_w2.X}")
    print(f"Week 2 - Product B: prod={prod_B_w2.X:.4f}, sell={sell_B_w2.X:.4f}, inv={inv_B_w2.X:.4f}, promo={promo_B_w2.X}")
    print(f"FINAL_OBJ_VALUE: {model.objVal:.3f}")
else:
    print(f"Status: {model.status}")
    print("FINAL_OBJ_VALUE: 0.000")
