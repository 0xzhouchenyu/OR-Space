import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read device data
devices = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            'name': row['Device'].strip(),
            'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
            'max_cap': float(row['Max_Processing_Capacity_Units'].strip())
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        value = row['Value'].strip()
        params[param_name] = float(value)

required_units = params['required_units']
energy_budget_peak = params['energy_budget_peak']
energy_budget_offpeak = params['energy_budget_offpeak']
energy_per_unit = {
    'A': params['energy_per_unit_A'],
    'B': params['energy_per_unit_B'],
    'C': params['energy_per_unit_C'],
    'D': params['energy_per_unit_D']
}
startup_energy = {
    'A': params['startup_energy_A'],
    'B': params['startup_energy_B'],
    'C': params['startup_energy_C'],
    'D': params['startup_energy_D']
}
startup_cost = params['startup_cost']
startup_budget = params['startup_budget']
energy_price_peak = params['energy_price_peak']
energy_price_offpeak = params['energy_price_offpeak']

# Create the optimization model
model = gp.Model("MinCostProduction")
model.setParam('OutputFlag', 0)

n = len(devices)
periods = ['peak', 'offpeak']

# Decision variables
# x[i][p]: number of units produced on device i in period p
x = {}
for i in range(n):
    for p in periods:
        x[(i, p)] = model.addVar(lb=0, ub=devices[i]['max_cap'], name=f"x_{devices[i]['name']}_{p}")

# y[i][p]: binary variable indicating whether device i is used in period p
y = {}
for i in range(n):
    for p in periods:
        y[(i, p)] = model.addVar(vtype=GRB.BINARY, name=f"y_{devices[i]['name']}_{p}")

# z[i]: binary variable indicating whether device i is used at all (for prep cost)
z = {}
for i in range(n):
    z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{devices[i]['name']}")

# Objective: minimize total cost
# = sum of (prep_cost * z_i + unit_cost * x_i_p + energy_cost + startup_cost * y_i_p)
objective = 0

# Prep costs (one-time per device)
for i in range(n):
    objective += devices[i]['prep_cost'] * z[i]

# Unit production costs
for i in range(n):
    for p in periods:
        objective += devices[i]['unit_cost'] * x[(i, p)]

# Energy costs
for i in range(n):
    for p in periods:
        energy_price = energy_price_peak if p == 'peak' else energy_price_offpeak
        energy_consumption = energy_per_unit[devices[i]['name']] * x[(i, p)]
        objective += energy_price * energy_consumption

# Startup costs
for i in range(n):
    for p in periods:
        objective += startup_cost * y[(i, p)]

model.setObjective(objective, GRB.MINIMIZE)

# Constraint: total production must equal required units
model.addConstr(gp.quicksum(x[(i, p)] for i in range(n) for p in periods) == required_units, "TotalProduction")

# Linking constraints: x_i_p <= max_cap * y_i_p
for i in range(n):
    for p in periods:
        model.addConstr(x[(i, p)] <= devices[i]['max_cap'] * y[(i, p)], f"Link_{devices[i]['name']}_{p}")

# Linking constraints: y_i_p <= z_i (if device not used at all, can't use in any period)
for i in range(n):
    for p in periods:
        model.addConstr(y[(i, p)] <= z[i], f"Y_Z_Link_{devices[i]['name']}_{p}")

# Peak energy budget constraint
peak_energy = 0
for i in range(n):
    peak_energy += startup_energy[devices[i]['name']] * y[(i, 'peak')]
    peak_energy += energy_per_unit[devices[i]['name']] * x[(i, 'peak')]
model.addConstr(peak_energy <= energy_budget_peak, "PeakEnergyBudget")

# Off-peak energy budget constraint
offpeak_energy = 0
for i in range(n):
    offpeak_energy += startup_energy[devices[i]['name']] * y[(i, 'offpeak')]
    offpeak_energy += energy_per_unit[devices[i]['name']] * x[(i, 'offpeak')]
model.addConstr(offpeak_energy <= energy_budget_offpeak, "OffpeakEnergyBudget")

# Startup budget constraint
startup_spend = 0
for i in range(n):
    for p in periods:
        startup_spend += startup_cost * y[(i, p)]
model.addConstr(startup_spend <= startup_budget, "StartupBudget")

# Solve
model.optimize()

# Print results
for i in range(n):
    print(f"Device {devices[i]['name']}: used={int(z[i].X)}, units_peak={x[(i, 'peak')].X:.1f}, units_offpeak={x[(i, 'offpeak')].X:.1f}")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
