import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load general parameters
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Parameter_Name'].strip() == 'initial_capital':
            initial_capital = float(row['Value'].strip())

# Load liquidity policy
min_year3_reserve = 0
reserve_shortfall_penalty = 0
with open(os.path.join(data_dir, 'liquidity_policy.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Parameter_Name'].strip() == 'min_year3_reserve':
            min_year3_reserve = float(row['Value'].strip())
        elif row['Parameter_Name'].strip() == 'reserve_shortfall_penalty':
            reserve_shortfall_penalty = float(row['Value'].strip())

# Create model
model = gp.Model("Investment_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
# x1_1: amount invested in Project 1 at beginning of Year 1
# x1_2: amount invested in Project 1 at beginning of Year 2
# x1_3: amount invested in Project 1 at beginning of Year 3
# x2: amount invested in Project 2 at beginning of Year 1
# x3: amount invested in Project 3 at beginning of Year 2
# x4: amount invested in Project 4 at beginning of Year 3
# reserve_y3: cash held as reserve at beginning of Year 3 (not invested in Year 3 projects)

x1_1 = model.addVar(lb=0, name="x1_1")
x1_2 = model.addVar(lb=0, name="x1_2")
x1_3 = model.addVar(lb=0, name="x1_3")
x2 = model.addVar(lb=0, ub=120000, name="x2")
x3 = model.addVar(lb=0, ub=150000, name="x3")
x4 = model.addVar(lb=0, ub=100000, name="x4")
reserve_y3 = model.addVar(lb=0, name="reserve_y3")

# Year 1 budget constraint: x1_1 + x2 <= initial_capital
model.addConstr(x1_1 + x2 <= initial_capital, "Year1_Budget")

# Year 2 budget constraint: available cash = proceeds from x1_1 (matured same year = end of year 1)
# x1_1 * 1.20 is available at beginning of Year 2
# x1_2 + x3 <= x1_1 * 1.20
model.addConstr(x1_2 + x3 <= x1_1 * 1.20, "Year2_Budget")

# Year 3 budget constraint: proceeds from x1_2 (matures same year = end of year 2) + x2 matures end of year 2 + x3 matures end of year 2
# Available at beginning of Year 3: x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60
# This must cover: x1_3 + x4 + reserve_y3
model.addConstr(x1_3 + x4 + reserve_y3 <= x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60, "Year3_Budget")

# Objective: total money at end of Year 3 minus penalty for reserve shortfall
# x1_3 matures end of Year 3: x1_3 * 1.20
# x4 matures end of Year 3: x4 * 1.40
# reserve_y3 remains as cash through Year 3: reserve_y3 * 1.00
# Penalty: if reserve_y3 < min_year3_reserve, penalty = reserve_shortfall_penalty * (min_year3_reserve - reserve_y3)

# To handle the penalty, I need to introduce a variable for shortfall
shortfall = model.addVar(lb=0, name="shortfall")

# Shortfall constraint: shortfall >= min_year3_reserve - reserve_y3
model.addConstr(shortfall >= min_year3_reserve - reserve_y3, "Shortfall_Definition")

# Objective: maximize (x1_3 * 1.20 + x4 * 1.40 + reserve_y3) - reserve_shortfall_penalty * shortfall
model.setObjective(
    x1_3 * 1.20 + x4 * 1.40 + reserve_y3 - reserve_shortfall_penalty * shortfall,
    GRB.MAXIMIZE
)

# Optimize
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: 0")
