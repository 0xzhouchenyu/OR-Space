import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(script_dir, 'data', 'general_parameters.csv')
    
    # Read parameters
    params = {}
    with open(data_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[key] = val
            
    # Extract parameters
    p_corn = params['profit_per_acre_corn']
    p_wheat = params['profit_per_acre_wheat']
    p_soy = params['profit_per_acre_soybeans']
    p_sorg = params['profit_per_acre_sorghum']
    total_area = params['total_farm_area']
    r_corn_wheat = params['corn_wheat_ratio']
    r_soy_sorg = params['soybeans_sorghum_ratio']
    r_wheat_sorg = params['wheat_sorghum_ratio']
    
    # Create Model
    model = gp.Model("Farm_Optimization_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    corn = model.addVar(lb=0, name="corn")
    wheat = model.addVar(lb=0, name="wheat")
    soybeans = model.addVar(lb=0, name="soybeans")
    sorghum = model.addVar(lb=0, name="sorghum")
    
    # Binary variable for mutual exclusion
    # 1 = Corn selected (Soybeans excluded)
    # 0 = Soybeans selected (Corn excluded)
    select_corn = model.addVar(vtype=GRB.BINARY, name="select_corn")
    
    # Objective
    model.setObjective(p_corn*corn + p_wheat*wheat + p_soy*soybeans + p_sorg*sorghum, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Total Area
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")
    
    # 2. Corn >= 2 * Wheat
    model.addConstr(corn >= r_corn_wheat * wheat, "corn_wheat_ratio")
    
    # 3. Soybeans >= 0.5 * Sorghum
    model.addConstr(soybeans >= r_soy_sorg * sorghum, "soybeans_sorghum_ratio")
    
    # 4. Wheat = 3 * Sorghum
    model.addConstr(wheat == r_wheat_sorg * sorghum, "wheat_sorghum_ratio")
    
    # 5. Minimum Corn Requirement
    model.addConstr(corn >= 20, "min_corn")
    
    # 6. Mutual Exclusion (Corn and Soybeans)
    # If select_corn == 1, corn can be > 0, soybeans must be 0
    # If select_corn == 0, corn must be 0, soybeans can be > 0
    # Using Big-M (total_area is sufficient upper bound)
    M = total_area
    model.addConstr(corn <= M * select_corn, "exclude_soy_if_corn")
    model.addConstr(soybeans <= M * (1 - select_corn), "exclude_corn_if_soy")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Fallback if not optimal, though shouldn't happen
        print(f"FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
