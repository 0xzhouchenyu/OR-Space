import os
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
sell_price_table = params['sell_price_table']
sell_price_chair = params['sell_price_chair']
sell_price_bookshelf = params['sell_price_bookshelf']

cost_table = params['manufacturing_cost_table']
cost_chair = params['manufacturing_cost_chair']
cost_bookshelf = params['manufacturing_cost_bookshelf']

space_table = params['warehouse_space_table']
space_chair = params['warehouse_space_chair']
space_bookshelf = params['warehouse_space_bookshelf']

max_warehouse = params['max_warehouse_space']
min_tables = params['min_tables']
min_bookshelves = params['min_bookshelves']
max_total = params['max_total_items']

labor_hours_table = params['labor_hours_table']
labor_hours_chair = params['labor_hours_chair']
labor_hours_bookshelf = params['labor_hours_bookshelf']

max_labor_regular = params['max_labor_hours_month_regular']
max_labor_rush = params['max_labor_hours_month_rush']
max_rush_items = params['max_rush_items_month']

rush_bonus_table = params['rush_profit_bonus_table']
rush_bonus_chair = params['rush_profit_bonus_chair']
rush_bonus_bookshelf = params['rush_profit_bonus_bookshelf']

# Base profit per item (selling price - manufacturing cost)
profit_table = sell_price_table - cost_table
profit_chair = sell_price_chair - cost_chair
profit_bookshelf = sell_price_bookshelf - cost_bookshelf

# Create the MIP model
model = gp.Model("Furniture_Production_Revised")
model.setParam('OutputFlag', 0)

# Decision variables (integer, non-negative)
# Regular production
x_tables_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="tables_reg")
x_chairs_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="chairs_reg")
x_bookshelves_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="bookshelves_reg")

# Rush production
x_tables_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="tables_rush")
x_chairs_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="chairs_rush")
x_bookshelves_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="bookshelves_rush")

# Objective: maximize total profit (base profit + rush bonus for rush items)
objective = (
    profit_table * x_tables_reg + 
    profit_chair * x_chairs_reg + 
    profit_bookshelf * x_bookshelves_reg +
    (profit_table + rush_bonus_table) * x_tables_rush +
    (profit_chair + rush_bonus_chair) * x_chairs_rush +
    (profit_bookshelf + rush_bonus_bookshelf) * x_bookshelves_rush
)
model.setObjective(objective, GRB.MAXIMIZE)

# Constraint: Warehouse space (all items share warehouse)
model.addConstr(
    space_table * (x_tables_reg + x_tables_rush) +
    space_chair * (x_chairs_reg + x_chairs_rush) +
    space_bookshelf * (x_bookshelves_reg + x_bookshelves_rush) <= max_warehouse,
    "Warehouse_Space"
)

# Constraint: Minimum production requirements (total of regular + rush)
model.addConstr(x_tables_reg + x_tables_rush >= min_tables, "Min_Tables")
model.addConstr(x_bookshelves_reg + x_bookshelves_rush >= min_bookshelves, "Min_Bookshelves")

# Constraint: Maximum total production (all items)
model.addConstr(
    x_tables_reg + x_tables_rush +
    x_chairs_reg + x_chairs_rush +
    x_bookshelves_reg + x_bookshelves_rush <= max_total,
    "Max_Total_Items"
)

# Constraint: Regular labor hours
model.addConstr(
    labor_hours_table * x_tables_reg +
    labor_hours_chair * x_chairs_reg +
    labor_hours_bookshelf * x_bookshelves_reg <= max_labor_regular,
    "Labor_Hours_Regular"
)

# Constraint: Rush labor hours
model.addConstr(
    labor_hours_table * x_tables_rush +
    labor_hours_chair * x_chairs_rush +
    labor_hours_bookshelf * x_bookshelves_rush <= max_labor_rush,
    "Labor_Hours_Rush"
)

# Constraint: Maximum rush items
model.addConstr(
    x_tables_rush + x_chairs_rush + x_bookshelves_rush <= max_rush_items,
    "Max_Rush_Items"
)

# Solve the model
model.optimize()

# Output results
if model.status == GRB.OPTIMAL:
    print(f"Tables Regular: {int(x_tables_reg.X)}")
    print(f"Chairs Regular: {int(x_chairs_reg.X)}")
    print(f"Bookshelves Regular: {int(x_bookshelves_reg.X)}")
    print(f"Tables Rush: {int(x_tables_rush.X)}")
    print(f"Chairs Rush: {int(x_chairs_rush.X)}")
    print(f"Bookshelves Rush: {int(x_bookshelves_rush.X)}")
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"Status: {model.status}")
    print("FINAL_OBJ_VALUE: 0")
