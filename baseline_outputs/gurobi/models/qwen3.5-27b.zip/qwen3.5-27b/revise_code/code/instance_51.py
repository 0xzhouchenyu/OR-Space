import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data functions
def load_demand(filepath):
    """Load nurse demand per time period from CSV."""
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand

def load_parameters(filepath):
    """Load general parameters from CSV."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    return params

# Set up file paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load data
demand = load_demand(os.path.join(data_dir, 'table_1.csv'))
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Parse parameters
shift_duration = int(params['shift_duration'])  # 8 hours
regular_pay = float(params['regular_nurse_pay'])  # 10 yuan/hour
contract_pay = float(params['contract_nurse_pay'])  # 15 yuan/hour

num_periods = len(demand)  # 6 periods, each 4 hours
periods_per_shift = shift_duration // 4  # 2 periods per shift

# Additional constraints from revision
outsourced_regular_start_index = int(params['outsourced_regular_start_index'])  # 2
banned_contract_start_index = int(params['banned_contract_start_index'])  # 5
max_total_contract_starts = int(params['max_total_contract_starts'])  # 20
min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])  # 8
daytime_period_indices = [int(x) for x in params['daytime_period_indices'].split(';')]  # [1, 2, 3, 4]

# Create Gurobi model
model = gp.Model("NurseScheduling")
model.setParam('OutputFlag', 0)

# Decision variables: regular and contract nurses starting at each shift
x = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="x")  # regular nurses
y = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="y")  # contract nurses

# Objective: minimize total cost
# Each nurse works 8 hours
cost = gp.quicksum((regular_pay * shift_duration) * x[j] + (contract_pay * shift_duration) * y[j] for j in range(num_periods))
model.setObjective(cost, GRB.MINIMIZE)

# Constraint 1: Regular nurses cannot start at outsourced index
model.addConstr(x[outsourced_regular_start_index] == 0)

# Constraint 2: Contract nurses cannot start at banned index
model.addConstr(y[banned_contract_start_index] == 0)

# Constraint 3: Total contract starts capped
model.addConstr(gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts)

# Constraint 4: Coverage constraints for each period
for i in range(num_periods):
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i])

# Constraint 5: Minimum regular coverage for daytime periods
for i in daytime_period_indices:
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(gp.quicksum(x[j] for j in covering_shifts) >= min_regular_daytime_coverage)

# Optimize
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
