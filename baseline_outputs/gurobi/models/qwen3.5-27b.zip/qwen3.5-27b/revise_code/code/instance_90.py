import os
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
shirts_inventory = params['shirts_inventory']
pants_inventory = params['pants_inventory']
price_a = params['package_a_price']
price_b = params['package_b_price']
price_c = params['package_c_price']
shirts_a = params['package_a_shirts']
pants_a = params['package_a_pants']
shirts_b = params['package_b_shirts']
pants_b = params['package_b_pants']
shirts_c = params['package_c_shirts']
pants_c = params['package_c_pants']
min_batch_a = params['min_campaign_batch_a']
min_batch_b = params['min_campaign_batch_b']
min_batch_c = params['min_campaign_batch_c']
activation_cost_a = params['activation_cost_a']
activation_cost_b = params['activation_cost_b']
activation_cost_c = params['activation_cost_c']
labor_hours_per_A = params['labor_hours_per_A']
labor_hours_per_B = params['labor_hours_per_B']
labor_hours_per_C = params['labor_hours_per_C']
labor_hours_total = params['labor_hours_total']
bigM_a = params['bigM_a']
bigM_b = params['bigM_b']
bigM_c = params['bigM_c']
threshold_b = params['package_b_review_threshold']
charge_b = params['package_b_review_charge']
threshold_c = params['package_c_review_threshold']
charge_c = params['package_c_review_charge']

# Create the MIP model
model = gp.Model("Maximize_Revenue")
model.setParam('OutputFlag', 0)

# Decision variables
x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_A")
x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_B")
x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_C")

# Binary variables for campaign activation
y_a = model.addVar(vtype=GRB.BINARY, name="Activate_A")
y_b = model.addVar(vtype=GRB.BINARY, name="Activate_B")
y_c = model.addVar(vtype=GRB.BINARY, name="Activate_C")

# Binary variables for review threshold exceeded
z_b = model.addVar(vtype=GRB.BINARY, name="Review_Threshold_B")
z_c = model.addVar(vtype=GRB.BINARY, name="Review_Threshold_C")

# Objective: maximize net revenue (revenue - activation costs - review charges)
model.setObjective(
    price_a * x_a + price_b * x_b + price_c * x_c
    - activation_cost_a * y_a - activation_cost_b * y_b - activation_cost_c * y_c
    - charge_b * z_b - charge_c * z_c,
    GRB.MAXIMIZE
)

# Inventory constraints
model.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inventory, "Shirts_Inventory")
model.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inventory, "Pants_Inventory")

# Labor hours constraint
model.addConstr(labor_hours_per_A * x_a + labor_hours_per_B * x_b + labor_hours_per_C * x_c <= labor_hours_total, "Labor_Hours")

# Link x_a to y_a (if x_a > 0, then y_a = 1)
model.addConstr(x_a <= bigM_a * y_a, "Link_A_Activation")
# Minimum batch if activated
model.addConstr(x_a >= min_batch_a * y_a, "Min_Batch_A")

# Link x_b to y_b (if x_b > 0, then y_b = 1)
model.addConstr(x_b <= bigM_b * y_b, "Link_B_Activation")
# Minimum batch if activated
model.addConstr(x_b >= min_batch_b * y_b, "Min_Batch_B")

# Link x_c to y_c (if x_c > 0, then y_c = 1)
model.addConstr(x_c <= bigM_c * y_c, "Link_C_Activation")
# Minimum batch if activated
model.addConstr(x_c >= min_batch_c * y_c, "Min_Batch_C")

# Review threshold for Package B: if x_b > threshold_b, then z_b = 1
model.addConstr(x_b <= threshold_b + bigM_b * z_b, "Review_Threshold_B_Upper")
model.addConstr(x_b >= threshold_b + 1 - bigM_b * (1 - z_b), "Review_Threshold_B_Lower")

# Review threshold for Package C: if x_c > threshold_c, then z_c = 1
model.addConstr(x_c <= threshold_c + bigM_c * z_c, "Review_Threshold_C_Upper")
model.addConstr(x_c >= threshold_c + 1 - bigM_c * (1 - z_c), "Review_Threshold_C_Lower")

# Optimize
model.optimize()

# Output results
print(f"Status: {model.Status}")
print(f"Package A: {int(x_a.X)}")
print(f"Package B: {int(x_b.X)}")
print(f"Package C: {int(x_c.X)}")

objective_value = model.ObjVal
print(f"FINAL_OBJ_VALUE: {objective_value}")
