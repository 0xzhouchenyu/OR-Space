import os
import sys
from utils import load_parameters
import gurobipy as gp
from gurobipy import GRB

def main():
    # Get the directory where this script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load parameters
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Extract parameters
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    
    # New parameters from revision
    base_fleet_a = int(params['base_fleet_type_a'])
    base_fleet_b = int(params['base_fleet_type_b'])
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    type_b_threshold = int(params['type_b_recovery_threshold'])
    type_b_fee = params['type_b_recovery_fee']
    total_fleet_threshold = int(params['total_fleet_surge_threshold'])
    total_fleet_fee = params['total_fleet_surge_fee']
    
    # Create the optimization model
    model = gp.Model("TruckRental")
    model.setParam('OutputFlag', 0)
    
    # Decision variables (integer, non-negative)
    x = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeA_trucks")
    y = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeB_trucks")
    
    # Binary variables for threshold gates
    z_b = model.addVar(vtype=GRB.BINARY, name="TypeB_recovery_gate")
    z_total = model.addVar(vtype=GRB.BINARY, name="TotalFleet_surge_gate")
    
    # Variables for excess over base fleet (for penalty calculation)
    excess_a = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="Excess_A")
    excess_b = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="Excess_B")
    
    # Big-M values (use reasonable upper bounds)
    M = 1000
    
    # Objective: minimize total cost
    # Base rental costs + penalty costs for exceeding base fleet + threshold fees
    model.setObjective(
        cost_a * x + cost_b * y + 
        penalty_a * excess_a + penalty_b * excess_b +
        type_b_fee * z_b + total_fleet_fee * z_total,
        GRB.MINIMIZE
    )
    
    # Cargo capacity constraints
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedRequirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedRequirement")
    
    # Excess over base fleet constraints
    model.addConstr(excess_a >= x - base_fleet_a, "ExcessA_lower")
    model.addConstr(excess_a <= M * (x - base_fleet_a), "ExcessA_upper")
    model.addConstr(excess_b >= y - base_fleet_b, "ExcessB_lower")
    model.addConstr(excess_b <= M * (y - base_fleet_b), "ExcessB_upper")
    
    # Type B recovery threshold gate: z_b = 1 if y > type_b_threshold
    # y <= type_b_threshold + M * z_b
    # y >= type_b_threshold + 1 - M * (1 - z_b)
    model.addConstr(y <= type_b_threshold + M * z_b, "TypeB_threshold_upper")
    model.addConstr(y >= type_b_threshold + 1 - M * (1 - z_b), "TypeB_threshold_lower")
    
    # Total fleet surge threshold gate: z_total = 1 if x + y > total_fleet_threshold
    # x + y <= total_fleet_threshold + M * z_total
    # x + y >= total_fleet_threshold + 1 - M * (1 - z_total)
    model.addConstr(x + y <= total_fleet_threshold + M * z_total, "TotalFleet_threshold_upper")
    model.addConstr(x + y >= total_fleet_threshold + 1 - M * (1 - z_total), "TotalFleet_threshold_lower")
    
    # Optimize
    model.optimize()
    
    # Print results
    print(f"Type A trucks: {int(x.X)}")
    print(f"Type B trucks: {int(y.X)}")
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
