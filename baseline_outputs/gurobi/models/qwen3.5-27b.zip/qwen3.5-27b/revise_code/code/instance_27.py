import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data(data_dir):
    # Load general parameters
    params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[key] = val
    
    # Extract specific params
    raw_costs = {
        'Product_I': params.get('raw_material_cost_product_I', 0),
        'Product_II': params.get('raw_material_cost_product_II', 0),
        'Product_III': params.get('raw_material_cost_product_III', 0),
    }
    prices = {
        'Product_I': params.get('unit_price_product_I', 0),
        'Product_II': params.get('unit_price_product_II', 0),
        'Product_III': params.get('unit_price_product_III', 0),
    }
    shared_labor_hours = params.get('shared_labor_hours', 0)
    b2_activation_fee = params.get('b2_activation_fee', 0)
    
    labor_coeffs = {}
    for equip in ['A1', 'A2', 'B1', 'B2', 'B3']:
        key = f'labor_coeff_{equip}'
        labor_coeffs[equip] = params.get(key, 0)
        
    # Load table 1
    equipment_list = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    
    filepath = os.path.join(data_dir, 'table_1.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment_list.append(e)
            proc_times[e] = {}
            for p in ['Product_I', 'Product_II', 'Product_III']:
                val_str = row[p].strip()
                if val_str:
                    proc_times[e][p] = float(val_str)
                else:
                    proc_times[e][p] = None
            
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())
            
    return raw_costs, prices, shared_labor_hours, b2_activation_fee, labor_coeffs, equipment_list, proc_times, eff_hours, op_costs

def main():
    # Determine data directory relative to script location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    raw_costs, prices, shared_labor_hours, b2_activation_fee, labor_coeffs, equipment_list, proc_times, eff_hours, op_costs = load_data(data_dir)
    
    products = ['Product_I', 'Product_II', 'Product_III']
    A_equip = [e for e in equipment_list if e.startswith('A')]
    B_equip = [e for e in equipment_list if e.startswith('B')]
    
    model = gp.Model("Factory_Production")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    # x[e][p]: units of product p on equipment e
    x = {}
    for e in equipment_list:
        x[e] = {}
        for p in products:
            if proc_times[e][p] is not None:
                x[e][p] = model.addVar(lb=0, name=f"x_{e}_{p}")
    
    # Binary variable for B2 activation
    y_b2 = model.addVar(vtype=GRB.BINARY, name="y_b2")
    
    # Update model
    model.update()
    
    # 1. Capacity Constraints
    for e in equipment_list:
        usage_expr = gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None)
        model.addConstr(usage_expr <= eff_hours[e], name=f"capacity_{e}")
    
    # 2. Flow Balance Constraints
    for p in products:
        a_sum = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
        b_sum = gp.quicksum(x[e][p] for e in B_equip if proc_times[e][p] is not None)
        model.addConstr(a_sum == b_sum, name=f"balance_{p}")
    
    # 3. Labor Constraint
    # Total labor = sum over e of (usage_time_e * labor_coeff_e)
    labor_usage = gp.quicksum(
        (gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None)) * labor_coeffs[e]
        for e in equipment_list
    )
    model.addConstr(labor_usage <= shared_labor_hours, name="labor_pool")
    
    # 4. B2 Activation Constraint
    # If B2 is used (sum x > 0), y_b2 must be 1.
    # sum x <= M * y_b2
    # Calculate M: Max possible units on B2 given capacity
    # Max units = eff_hours[B2] / min_proc_time_on_B2
    b2_min_time = min(proc_times['B2'][p] for p in products if proc_times['B2'][p] is not None)
    M = eff_hours['B2'] / b2_min_time + 100 # Add buffer
    
    b2_usage_units = gp.quicksum(x['B2'][p] for p in products if proc_times['B2'][p] is not None)
    model.addConstr(b2_usage_units <= M * y_b2, name="b2_activation_link")
    
    # Objective Function
    # Revenue
    # Total production of p is sum over A (or B)
    total_prod = {}
    for p in products:
        total_prod[p] = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
    
    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)
    
    # Raw Material Cost
    raw_cost_total = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)
    
    # Operating Cost (Variable)
    # Cost = op_costs[e] * (usage_time / eff_hours[e])
    operating_cost = gp.quicksum(
        op_costs[e] * (gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None) / eff_hours[e])
        for e in equipment_list
    )
    
    # Fixed Cost (B2)
    fixed_cost = b2_activation_fee * y_b2
    
    # Profit = Revenue - Raw - Op - Fixed
    profit = revenue - raw_cost_total - operating_cost - fixed_cost
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.4f}")
    else:
        print(f"FINAL_OBJ_VALUE: 0.0000")

if __name__ == "__main__":
    main()
