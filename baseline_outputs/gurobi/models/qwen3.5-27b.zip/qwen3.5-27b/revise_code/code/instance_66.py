import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read table_1.csv
toys = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            'type': row['Toy_Type'],
            'labor': float(row['Manufacturing_Labor_Hours']),
            'inspection': float(row['Inspection_Hours']),
            'profit': float(row['Profit_Per_Unit'])
        })

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Extract parameters
available_labor_p1 = params['available_labor_hours_period1']
available_labor_p2 = params['available_labor_hours_period2']
available_inspection_p1 = params['available_inspection_hours_period1']
available_inspection_p2 = params['available_inspection_hours_period2']

max_demand = {
    'High-End': {1: params['max_demand_high_end_period1'], 2: params['max_demand_high_end_period2']},
    'Mid-Range': {1: params['max_demand_mid_range_period1'], 2: params['max_demand_mid_range_period2']},
    'Low-End': {1: params['max_demand_low_end_period1'], 2: params['max_demand_low_end_period2']}
}

overtime_cap = params['overtime_labor_cap']
overtime_cost = params['overtime_labor_cost']
fatigue_threshold = params['period1_overtime_fatigue_threshold']
recovery_loss = params['period2_labor_recovery_loss']
review_threshold = params['overtime_review_threshold']
review_fee = params['seasonal_safety_review_fee']

# Build optimization model
model = gp.Model("ToyProduction")
model.setParam('OutputFlag', 0)

# Decision variables
# Production quantities
x = {}
for toy in toys:
    for period in [1, 2]:
        x[(toy['type'], period)] = model.addVar(lb=0, name=f"x_{toy['type']}_p{period}")

# Overtime hours
ot_p1 = model.addVar(lb=0, name="ot_p1")
ot_p2 = model.addVar(lb=0, name="ot_p2")

# Binary variable for safety review
safety_review = model.addVar(vtype=GRB.BINARY, name="safety_review")

# Objective: maximize profit - overtime costs - safety review fee
profit_terms = []
for toy in toys:
    for period in [1, 2]:
        profit_terms.append(toy['profit'] * x[(toy['type'], period)])

objective = gp.quicksum(profit_terms) - overtime_cost * (ot_p1 + ot_p2) - review_fee * safety_review
model.setObjective(objective, GRB.MAXIMIZE)

# Constraints
# Labor hours per period
for period in [1, 2]:
    labor_used = gp.quicksum(toy['labor'] * x[(toy['type'], period)] for toy in toys)
    if period == 1:
        model.addConstr(labor_used <= available_labor_p1 + ot_p1, f"Labor_p{period}")
    else:
        # Period 2: need to handle fatigue carryover
        # If ot_p1 > fatigue_threshold, then available_labor_p2 is reduced by recovery_loss
        # This requires a big-M formulation
        pass

# For fatigue carryover, I need to use binary variable or piecewise linear
# Let me use a binary variable to indicate if fatigue threshold is exceeded
fatigue_exceeded = model.addVar(vtype=GRB.BINARY, name="fatigue_exceeded")

# Big-M for fatigue threshold check
M = 1000  # Large enough number
model.addConstr(ot_p1 - fatigue_threshold <= M * fatigue_exceeded, "Fatigue_check_upper")
model.addConstr(ot_p1 - fatigue_threshold >= epsilon - M * (1 - fatigue_exceeded), "Fatigue_check_lower")

# Actually, let me reconsider. The constraint says:
# "Period-1 overtime above `period1_overtime_fatigue_threshold` reduces period-2 regular labor by `period2_labor_recovery_loss`"
# This means if ot_p1 > 20, then period2 regular labor becomes 600 - 25 = 575

# I'll use a simpler approach with conditional constraint
# If ot_p1 > fatigue_threshold, then effective_labor_p2 = available_labor_p2 - recovery_loss
# Otherwise, effective_labor_p2 = available_labor_p2

# Using big-M formulation for this
effective_labor_p2 = model.addVar(lb=0, name="effective_labor_p2")
model.addConstr(effective_labor_p2 <= available_labor_p2, "Effective_labor_p2_upper")
model.addConstr(effective_labor_p2 >= available_labor_p2 - recovery_loss * fatigue_exceeded, "Effective_labor_p2_lower")

# Period 2 labor constraint
labor_used_p2 = gp.quicksum(toy['labor'] * x[(toy['type'], 2)] for toy in toys)
model.addConstr(labor_used_p2 <= effective_labor_p2 + ot_p2, "Labor_p2")

# Period 1 labor constraint
labor_used_p1 = gp.quicksum(toy['labor'] * x[(toy['type'], 1)] for toy in toys)
model.addConstr(labor_used_p1 <= available_labor_p1 + ot_p1, "Labor_p1")

# Inspection hours per period
for period in [1, 2]:
    inspection_used = gp.quicksum(toy['inspection'] * x[(toy['type'], period)] for toy in toys)
    if period == 1:
        model.addConstr(inspection_used <= available_inspection_p1, f"Inspection_p{period}")
    else:
        model.addConstr(inspection_used <= available_inspection_p2, f"Inspection_p{period}")

# Demand constraints per period
for toy in toys:
    for period in [1, 2]:
        model.addConstr(x[(toy['type'], period)] <= max_demand[toy['type']][period], f"Demand_{toy['type']}_p{period}")

# Total overtime constraint
model.addConstr(ot_p1 + ot_p2 <= overtime_cap, "Total_Overtime_Cap")

# Safety review trigger
# If total overtime > review_threshold, then safety_review = 1
# Using big-M formulation
total_ot = ot_p1 + ot_p2
model.addConstr(total_ot - review_threshold <= M * safety_review, "Safety_review_trigger_upper")
model.addConstr(total_ot - review_threshold >= epsilon - M * (1 - safety_review), "Safety_review_trigger_lower")

# Solve
model.optimize()

# Print results
obj_val = model.ObjVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
