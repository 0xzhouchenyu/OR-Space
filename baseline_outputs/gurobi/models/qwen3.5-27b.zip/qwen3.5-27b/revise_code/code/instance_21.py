import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Parse general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    cost_a = params['cost_supplier_a']
    cost_b = params['cost_supplier_b']
    cost_c = params['cost_supplier_c']
    size_a = int(params['order_size_supplier_a'])
    size_b = int(params['order_size_supplier_b'])
    size_c = int(params['order_size_supplier_c'])
    min_tables = int(params['min_tables_required'])
    max_tables = int(params['max_tables_allowed'])
    min_b_if_a = int(params['min_tables_supplier_b_if_a'])
    b_requires_c = int(params['supplier_b_requires_c'])
    max_free_c = int(params['max_free_orders_c'])
    penalty_c = params['penalty_per_extra_order_c']
    bc_trigger = int(params['supplier_bc_shared_inbound_trigger'])
    bc_fee = params['supplier_bc_shared_inbound_fee']
    
    M = 1000
    
    model = gp.Model("Restaurant_Tables")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of orders from each supplier (integer >= 0)
    x_a = model.addVar(vtype=GRB.INTEGER, name="orders_a", lb=0)
    x_b = model.addVar(vtype=GRB.INTEGER, name="orders_b", lb=0)
    x_c = model.addVar(vtype=GRB.INTEGER, name="orders_c", lb=0)
    
    # Binary variables for conditional constraints
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")
    
    # Binary variable for B+C combination
    z_bc = model.addVar(vtype=GRB.BINARY, name="z_bc")
    
    # Integer variable for extra C orders beyond free limit
    extra_c = model.addVar(vtype=GRB.INTEGER, name="extra_c", lb=0)
    
    # Objective: minimize total cost
    obj = (cost_a * size_a * x_a + 
           cost_b * size_b * x_b + 
           cost_c * size_c * x_c + 
           penalty_c * extra_c + 
           bc_fee * z_bc)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Total tables constraints
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c >= min_tables)
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c <= max_tables)
    
    # Link binary variables to order variables
    model.addConstr(x_a <= M * y_a)
    model.addConstr(x_a >= y_a)
    model.addConstr(x_b <= M * y_b)
    model.addConstr(x_b >= y_b)
    model.addConstr(x_c <= M * y_c)
    model.addConstr(x_c >= y_c)
    
    # If ordering from A, then tables from B >= 30
    model.addConstr(size_b * x_b >= min_b_if_a * y_a)
    
    # If ordering from B, must order from C
    if b_requires_c:
        model.addConstr(y_b <= y_c)
    
    # If both B and C are used, trigger shared inbound fee
    if bc_trigger:
        model.addConstr(z_bc >= y_b + y_c - 1)
        model.addConstr(z_bc <= y_b)
        model.addConstr(z_bc <= y_c)
    
    # Extra C orders calculation
    model.addConstr(extra_c >= x_c - max_free_c)
    model.addConstr(extra_c >= 0)
    
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
