import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data

def main():
    # Determine base directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load data
    products_raw = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params_raw = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Parse general parameters
    params = {}
    for row in params_raw:
        key = row['Parameter_Name']
        val_str = row['Value']
        if val_str:
            params[key] = float(val_str)
        else:
            params[key] = None
            
    # Extract parameters
    max_grains = params.get('max_grains', 0)
    price_grains = params.get('price_per_lb_grains', 0)
    max_meat = params.get('max_meat', 0)
    price_meat = params.get('price_per_lb_meat', 0)
    
    line_fixed_cost = params.get('line_fixed_cost', 0)
    line_capacity_packs = params.get('line_capacity_packs', 0)
    min_batch_packs = params.get('min_batch_packs', 0)
    min_yummies = params.get('min_yummies', 0)
    
    rebate_y_thresh = params.get('retailer_rebate_yummies_threshold', 0)
    rebate_m_thresh = params.get('retailer_rebate_min_meaties', 0)
    rebate_fixed = params.get('retailer_rebate_fixed', 0)
    
    # Parse product data
    product_data = {}
    for row in products_raw:
        name = row['Product']
        cap_str = row.get('Production_capacity', '').strip()
        cap_val = float(cap_str) if cap_str else None
        
        product_data[name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'variable_cost': float(row['Variable_cost_per_pack']),
            'capacity': cap_val
        }
        
    m_info = product_data['Meaties']
    y_info = product_data['Yummies']
    
    # Calculate unit profits
    # Profit = Price - VarCost - (Grains * Price_Grain + Meat * Price_Meat)
    mat_cost_m = m_info['grains'] * price_grains + m_info['meat'] * price_meat
    profit_m = m_info['price'] - m_info['variable_cost'] - mat_cost_m
    
    mat_cost_y = y_info['grains'] * price_grains + y_info['meat'] * price_meat
    profit_y = y_info['price'] - y_info['variable_cost'] - mat_cost_y
    
    # Create Model
    model = gp.Model("HealthyPetFoods_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    x_m = model.addVar(lb=0, name="Meaties_Production")
    x_y = model.addVar(lb=0, name="Yummies_Production")
    
    z_line = model.addVar(vtype=GRB.BINARY, name="Line_Active")
    z_rebate = model.addVar(vtype=GRB.BINARY, name="Rebate_Eligible")
    
    # Objective: Maximize Profit
    # Profit = Unit_Profit_M * x_m + Unit_Profit_Y * x_y - Line_Cost * z_line + Rebate * z_rebate
    model.setObjective(
        profit_m * x_m + profit_y * x_y 
        - line_fixed_cost * z_line 
        + rebate_fixed * z_rebate, 
        GRB.MAXIMIZE
    )
    
    # Constraints
    
    # 1. Resource Constraints
    model.addConstr(m_info['grains'] * x_m + y_info['grains'] * x_y <= max_grains, "Grains_Limit")
    model.addConstr(m_info['meat'] * x_m + y_info['meat'] * x_y <= max_meat, "Meat_Limit")
    
    # 2. Product Capacity Constraints
    if m_info['capacity'] is not None:
        model.addConstr(x_m <= m_info['capacity'], "Meaties_Capacity")
    if y_info['capacity'] is not None:
        model.addConstr(x_y <= y_info['capacity'], "Yummies_Capacity")
        
    # 3. Co-packing Line Logic
    # If line is active (z_line=1):
    #   Total production <= line_capacity
    #   Total production >= min_batch
    #   Yummies >= min_yummies
    # If line is inactive (z_line=0):
    #   Total production = 0 (enforced by <= capacity * 0)
    
    # Upper bound on production linked to line activation
    model.addConstr(x_m + x_y <= line_capacity_packs * z_line, "Line_Capacity_Upper")
    
    # Minimum batch size if line active
    model.addConstr(x_m + x_y >= min_batch_packs * z_line, "Line_Min_Batch")
    
    # Minimum Yummies if line active
    model.addConstr(x_y >= min_yummies * z_line, "Line_Min_Yummies")
    
    # 4. Retailer Rebate Logic
    # Rebate earned ONLY IF Yummies >= rebate_y_thresh AND Meaties >= rebate_m_thresh
    # Since we maximize profit, z_rebate will be 1 if possible.
    # We must constrain z_rebate to be 0 if thresholds are NOT met.
    # Equivalent to: If z_rebate = 1, then thresholds must be met.
    
    model.addConstr(x_y >= rebate_y_thresh * z_rebate, "Rebate_Y_Threshold")
    model.addConstr(x_m >= rebate_m_thresh * z_rebate, "Rebate_M_Threshold")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of infeasibility or other status, print best found or 0
        # But for this task, assume optimal is reachable
        print(f"FINAL_OBJ_VALUE: {model.ObjVal if model.status in [GRB.OPTIMAL, GRB.SUBOPTIMAL] else 0.0}")

if __name__ == "__main__":
    main()
