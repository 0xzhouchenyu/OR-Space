import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def load_car_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    cars = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            i = int(row['i'])
            length = float(row['lambda_i'])
            cars[i] = length
    return cars

def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'])
            params[name] = value
    return params

# Data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load data
cars = load_car_data(data_dir)
params = load_parameters(data_dir)

num_cars = int(params['num_cars'])
max_length_one_side = params['max_length_one_side']
available_sides = int(params.get('available_party_side_count', 1))

car_ids = list(cars.keys())
lengths = cars

# Model: All cars must park on the single available side
# x_i = 1 if car i is parked, 0 otherwise
# Constraint: sum(lengths[i] * x_i) <= max_length_one_side
# Objective: minimize sum(lengths[i] * x_i) but all cars should be parked

prob = gp.Model("ParkingMinStreetLength")
prob.setParam('OutputFlag', 0)

# Decision variables
x = {i: prob.addVar(vtype=GRB.BINARY, name=f"x_{i}") for i in car_ids}

# Total length of parked cars
total_parked = gp.quicksum(lengths[i] * x[i] for i in car_ids)

# Objective: minimize total length (but we want to park all cars)
prob.setObjective(total_parked, GRB.MINIMIZE)

# Constraint: total length <= max_length_one_side
prob.addConstr(total_parked <= max_length_one_side, "max_length_constraint")

# Constraint: all cars must be parked (since we have enough space)
for i in car_ids:
    prob.addConstr(x[i] == 1, f"park_car_{i}")

# Solve
prob.optimize()

# Extract solution
obj_val = prob.objVal

print(f"FINAL_OBJ_VALUE: {obj_val}")
