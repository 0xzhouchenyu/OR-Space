import os
import sys
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
min_A = params['min_raw_material_A']
min_B = params['min_raw_material_B']
min_C = params['min_raw_material_C']

cap_A_a = params['warehouse_A_truck_capacity_A']
cap_A_b = params['warehouse_A_truck_capacity_B']
cap_A_c = params['warehouse_A_truck_capacity_C']
cost_A = params['warehouse_A_truck_cost']

cap_B_a = params['warehouse_B_truck_capacity_A']
cap_B_b = params['warehouse_B_truck_capacity_B']
cap_B_c = params['warehouse_B_truck_capacity_C']
cost_B = params['warehouse_B_truck_cost']

fixed_cost_A = params['warehouse_A_fixed_cost']
fixed_cost_B = params['warehouse_B_fixed_cost']
overflow_threshold_B = params['warehouse_B_overflow_threshold_trucks']
overflow_cost_B = params['warehouse_B_overflow_coordination_cost']
dual_recon_fee = params['dual_warehouse_reconciliation_fee']

# Create MIP model
model = gp.Model("MinFreightCost")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_A")
y = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_B")

# Binary variables for fixed costs
z_A = model.addVar(vtype=GRB.BINARY, name="use_warehouse_A")
z_B = model.addVar(vtype=GRB.BINARY, name="use_warehouse_B")

# Binary variable for dual warehouse reconciliation
z_both = model.addVar(vtype=GRB.BINARY, name="both_warehouses_used")

# Binary variable for overflow
z_overflow = model.addVar(vtype=GRB.BINARY, name="warehouse_B_overflow")

# Big-M values (reasonable upper bounds)
M = 1000  # Maximum reasonable number of trucks

# Link x to z_A (if x > 0 then z_A = 1)
model.addConstr(x <= M * z_A, "link_x_zA")

# Link y to z_B (if y > 0 then z_B = 1)
model.addConstr(y <= M * z_B, "link_y_zB")

# Link z_both to z_A and z_B (z_both = 1 iff z_A = 1 AND z_B = 1)
model.addConstr(z_both <= z_A, "link_both_zA")
model.addConstr(z_both <= z_B, "link_both_zB")
model.addConstr(z_both >= z_A + z_B - 1, "link_both_sum")

# Link z_overflow to y (if y > 55 then z_overflow = 1)
model.addConstr(y <= overflow_threshold_B + M * z_overflow, "link_overflow_upper")
model.addConstr(y >= overflow_threshold_B + 1 - M * (1 - z_overflow), "link_overflow_lower")

# Objective function
model.setObjective(
    cost_A * x + cost_B * y + 
    fixed_cost_A * z_A + fixed_cost_B * z_B + 
    overflow_cost_B * z_overflow + 
    dual_recon_fee * z_both,
    GRB.MINIMIZE
)

# Raw material constraints
model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# Solve
model.optimize()

# Output results
print(f"FINAL_OBJ_VALUE: {model.objVal}")
