import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Adjust path to import utils
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'src'))

from utils import load_parameters, load_demand

def main():
    # Load Data
    params = load_parameters()
    demand = load_demand()
    
    T = 8
    weeks = range(1, T + 1)
    
    # Parameters
    S0 = params['skilled_worker_count']
    rate_I = params['food_I_production_rate']
    rate_II = params['food_II_production_rate']
    normal_hours = params['worker_weekly_hours']
    overtime_hours = params['skilled_worker_overtime_hours']
    train_cap = params['training_capacity']
    train_period = params['training_period']
    wage_skilled = params['skilled_worker_weekly_wage']
    wage_trainee_during = params['trainee_weekly_wage_during_training']
    wage_trainee_after = params['trainee_weekly_wage_after_training']
    wage_overtime = params['skilled_worker_overtime_wage']
    comp_I = params['compensation_fee_food_I']
    comp_II = params['compensation_fee_food_II']
    new_worker_goal = params['new_worker_training_goal']
    
    # Initialize Model
    model = gp.Model("Factory_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    # n_train[t]: Skilled workers starting training in week t (t=1..7)
    n_train = {}
    for t in range(1, 8):
        n_train[t] = model.addVar(vtype=GRB.INTEGER, name=f"n_train_{t}")
    
    # n_ot[t]: Skilled workers working overtime in week t (t=1..8)
    n_ot = {}
    for t in weeks:
        n_ot[t] = model.addVar(vtype=GRB.INTEGER, name=f"n_ot_{t}")
        
    # y_I[t], y_II[t]: Binary, 1 if producing Food I/II in week t
    y_I = {}
    y_II = {}
    for t in weeks:
        y_I[t] = model.addVar(vtype=GRB.BINARY, name=f"y_I_{t}")
        y_II[t] = model.addVar(vtype=GRB.BINARY, name=f"y_II_{t}")
        
    # h_I[t], h_II[t]: Production hours in week t
    h_I = {}
    h_II = {}
    for t in weeks:
        h_I[t] = model.addVar(vtype=GRB.CONTINUOUS, name=f"h_I_{t}")
        h_II[t] = model.addVar(vtype=GRB.CONTINUOUS, name=f"h_II_{t}")
        
    # Backlog
    b_I = {}
    b_II = {}
    for t in weeks:
        b_I[t] = model.addVar(vtype=GRB.CONTINUOUS, name=f"b_I_{t}")
        b_II[t] = model.addVar(vtype=GRB.CONTINUOUS, name=f"b_II_{t}")
        
    model.update()
    
    # Helper to get n_train with boundary conditions
    def get_n_train(t):
        if t < 1 or t > 7:
            return 0
        return n_train[t]
    
    # Constraints
    for t in weeks:
        # 1. Training Busy Workers
        # Workers busy training in week t are those who started in t or t-1
        busy_train_expr = get_n_train(t) + get_n_train(t-1)
        
        # 2. Available Skilled Workers for Production
        avail_skilled = S0 - busy_train_expr
        
        # 3. Overtime Limit
        model.addConstr(n_ot[t] <= avail_skilled, f"ot_limit_{t}")
        
        # 4. Graduates Available
        # Graduates available in week t are those who started training in s where s+2 <= t => s <= t-2
        grads_expr = 0
        for s in range(1, 8):
            if s <= t - 2:
                grads_expr += train_cap * get_n_train(s)
        
        # 5. Active Trainees (for wage calculation)
        # Trainees active in week t are those who started in t or t-1
        active_trainees_expr = train_cap * (get_n_train(t) + get_n_train(t-1))
        
        # 6. Hours Availability
        # Skilled Normal: (avail_skilled - n_ot[t]) * normal_hours
        # Skilled OT: n_ot[t] * overtime_hours
        # Graduates: grads_expr * normal_hours
        max_hours = (avail_skilled - n_ot[t]) * normal_hours + n_ot[t] * overtime_hours + grads_expr * normal_hours
        
        # 7. Production Hours Constraint
        model.addConstr(h_I[t] + h_II[t] <= max_hours, f"hours_limit_{t}")
        
        # 8. Mutual Exclusion
        # Big M
        M = 10000 
        model.addConstr(h_I[t] <= M * y_I[t], f"mut_excl_I_{t}")
        model.addConstr(h_II[t] <= M * y_II[t], f"mut_excl_II_{t}")
        model.addConstr(y_I[t] + y_II[t] <= 1, f"single_product_{t}")
        
        # 9. Backlog Balance
        prev_bI = b_I[t-1] if t > 1 else 0
        prev_bII = b_II[t-1] if t > 1 else 0
        
        prod_I = h_I[t] * rate_I
        prod_II = h_II[t] * rate_II
        
        model.addConstr(b_I[t] >= prev_bI + demand[t]['I'] - prod_I, f"backlog_I_{t}")
        model.addConstr(b_II[t] >= prev_bII + demand[t]['II'] - prod_II, f"backlog_II_{t}")
        
        # Ensure backlog non-negative (already done by var lowBound=0 default, but explicit is good)
        # Gurobi default lower bound is 0 for continuous vars created without lb.
        # But let's ensure.
        model.addConstr(b_I[t] >= 0, f"nonneg_bI_{t}")
        model.addConstr(b_II[t] >= 0, f"nonneg_bII_{t}")
        
        # 10. Skilled Worker Availability for Training
        # Implicitly handled by avail_skilled >= 0 which is enforced by n_ot <= avail_skilled and n_ot >= 0
        # But we must ensure avail_skilled >= 0 explicitly for training assignment validity
        model.addConstr(avail_skilled >= 0, f"avail_skilled_{t}")
        
    # 11. Training Goal
    # Total trainees started in weeks 1..7 * cap >= goal
    total_trained = 0
    for t in range(1, 8):
        total_trained += train_cap * n_train[t]
    model.addConstr(total_trained >= new_worker_goal, f"training_goal")
    
    # Objective Function
    obj = 0
    
    # 1. Skilled Wages
    # Base: S0 * wage_skilled * 8
    # Overtime Premium: n_ot[t] * (wage_overtime - wage_skilled)
    skilled_base_cost = S0 * wage_skilled * T
    for t in weeks:
        obj += n_ot[t] * (wage_overtime - wage_skilled)
    obj += skilled_base_cost
    
    # 2. Trainee Wages (During Training)
    for t in weeks:
        active_trainees = train_cap * (get_n_train(t) + get_n_train(t-1))
        obj += active_trainees * wage_trainee_during
        
    # 3. Graduate Wages (After Training)
    for t in weeks:
        grads = 0
        for s in range(1, 8):
            if s <= t - 2:
                grads += train_cap * get_n_train(s)
        obj += grads * wage_trainee_after
        
    # 4. Compensation Fees
    for t in weeks:
        obj += b_I[t] * comp_I
        obj += b_II[t] * comp_II
        
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
