import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load courses
def load_courses(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    courses = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            categories = [c.strip() for c in row['Category'].split(';')]
            courses[course] = categories
    return courses

# Load parameters
def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    prerequisites = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if name == 'min_courses_required':
                params['min_courses_required'] = int(value)
            elif name.startswith('prerequisite_'):
                course_key = name[len('prerequisite_'):]
                prerequisites[course_key] = value
            elif name == 'mandatory_foundation_for_cs_counting':
                params['mandatory_foundation_for_cs_counting'] = value
            elif name == 'cs_category_name':
                params['cs_category_name'] = value
    return params, prerequisites

# Match prerequisite key to course name
def match_prerequisite_course(prereq_key, course_list):
    key_lower = prereq_key.lower().replace('_', ' ')
    for course in course_list:
        if course.lower() == key_lower:
            return course
    return None

# Load data
courses = load_courses(data_dir)
params, prereq_raw = load_parameters(data_dir)

min_required = params['min_courses_required']
cs_foundation = params.get('mandatory_foundation_for_cs_counting', 'Computer Programming')
cs_category = params.get('cs_category_name', 'Computer Science')

# Build prerequisite mapping
course_list = list(courses.keys())
prerequisites = {}

for prereq_key, prereq_value in prereq_raw.items():
    course_name = match_prerequisite_course(prereq_key, course_list)
    if course_name:
        if course_name not in prerequisites:
            prerequisites[course_name] = []
        prerequisites[course_name].append(prereq_value.strip())

# Get all categories
all_categories = set()
for cats in courses.values():
    for c in cats:
        all_categories.add(c)

# Create model
model = gp.Model("CourseSelection")
model.setParam('OutputFlag', 0)

# Decision variables
x = {course: model.addVar(vtype=GRB.BINARY, name=f"x_{course.replace(' ', '_')}") for course in course_list}

# Category assignment variables: y[course][category] = 1 if course counts toward category
y = {}
for course in course_list:
    for category in courses[course]:
        y[(course, category)] = model.addVar(vtype=GRB.BINARY, name=f"y_{course.replace(' ', '_')}_{category.replace(' ', '_')}")

# Objective: minimize total courses taken
model.setObjective(gp.quicksum(x[course] for course in course_list), GRB.MINIMIZE)

# Constraint: each course can count for at most one category
for course in course_list:
    model.addConstr(gp.quicksum(y[(course, cat)] for cat in courses[course]) <= 1, f"OneCatPerCourse_{course.replace(' ', '_')}")

# Constraint: course can only count if taken
for course in course_list:
    for category in courses[course]:
        model.addConstr(y[(course, category)] <= x[course], f"CountOnlyIfTaken_{course.replace(' ', '_')}_{category.replace(' ', '_')}")

# Constraint: minimum courses per category
for category in all_categories:
    courses_in_cat = [course for course, cats in courses.items() if category in cats]
    model.addConstr(gp.quicksum(y[(course, category)] for course in courses_in_cat) >= min_required, f"Min_{category.replace(' ', '_')}")

# Prerequisite constraints
for course, prereqs in prerequisites.items():
    for prereq in prereqs:
        model.addConstr(x[course] <= x[prereq], f"Prereq_{course.replace(' ', '_')}_needs_{prereq.replace(' ', '_')}")

# CS foundation constraint: if any CS course counts toward CS, Computer Programming must be taken
cs_courses = [course for course, cats in courses.items() if cs_category in cats]
if cs_courses:
    model.addConstr(gp.quicksum(y[(course, cs_category)] for course in cs_courses) <= len(cs_courses) * x[cs_foundation], f"CSFoundation")

# Solve
model.optimize()

# Print result
print(f"FINAL_OBJ_VALUE: {model.objVal}")
