import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Get the data directory path
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

# Load warehouse data
warehouses_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
warehouses = []
supply = {}
for row in warehouses_data:
    name = row['Warehouse']
    warehouses.append(name)
    supply[name] = int(row['Empty_Containers'])

# Load port data
ports_data = load_csv_data(os.path.join(data_dir, 'table_2.csv'))
ports = []
demand = {}
for row in ports_data:
    name = row['Port']
    ports.append(name)
    demand[name] = int(row['Container_Demand'])

# Load distance data
distance_data = load_csv_data(os.path.join(data_dir, 'table_3.csv'))
distance = {}
for row in distance_data:
    wh = row['Warehouse']
    for port in ports:
        distance[(wh, port)] = float(row[port])

# Load general parameters
params_data = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
params = {}
for row in params_data:
    params[row['Parameter_Name']] = float(row['Value'])

cost_per_km = params['cost_per_km']
truck_capacity = params['truck_capacity']
adriatic_pool_shortage_trigger = int(params['adriatic_pool_shortage_trigger'])
adriatic_pool_recovery_fee = params['adriatic_pool_recovery_fee']

# Load shortage penalty data
shortage_data = load_csv_data(os.path.join(data_dir, 'shortage_penalty.csv'))
shortage_charge = {}
grace_containers = {}
recovery_fee = {}
for row in shortage_data:
    port = row['Port']
    shortage_charge[port] = float(row['Shortage_Charge'])
    grace_containers[port] = int(row['Grace_Containers'])
    recovery_fee[port] = float(row['Recovery_Fee'])

# Create model
model = gp.Model("Container_Transportation")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}  # containers from warehouse i to port j
for i in warehouses:
    for j in ports:
        x[(i, j)] = model.addVar(vtype=GRB.INTEGER, name=f"x_{i}_{j}")

s = {}  # shortage at port j
for j in ports:
    s[j] = model.addVar(vtype=GRB.CONTINUOUS, name=f"s_{j}")

r = {}  # binary: recovery desk opened for port j
for j in ports:
    r[j] = model.addVar(vtype=GRB.BINARY, name=f"r_{j}")

R_adriatic = model.addVar(vtype=GRB.BINARY, name="R_adriatic")

# Objective function
transport_cost = gp.quicksum(x[(i, j)] * distance[(i, j)] * cost_per_km 
                             for i in warehouses for j in ports)
shortage_cost = gp.quicksum(s[j] * shortage_charge[j] for j in ports)
local_recovery_cost = gp.quicksum(r[j] * recovery_fee[j] for j in ports)
adriatic_recovery_cost = R_adriatic * adriatic_pool_recovery_fee

model.setObjective(transport_cost + shortage_cost + local_recovery_cost + adriatic_recovery_cost, GRB.MINIMIZE)

# Supply constraints
for i in warehouses:
    model.addConstr(gp.quicksum(x[(i, j)] for j in ports) <= supply[i], name=f"supply_{i}")

# Demand balance constraints
for j in ports:
    model.addConstr(gp.quicksum(x[(i, j)] for i in warehouses) + s[j] >= demand[j], name=f"demand_{j}")

# Recovery desk activation constraints
M = max(demand.values())  # Big M value
for j in ports:
    # If shortage > grace_containers, then r[j] = 1
    model.addConstr(s[j] <= grace_containers[j] + M * r[j], name=f"recovery_trigger_{j}")

# Adriatic pool constraint
adriatic_ports = ['Venice', 'Ancona', 'Bari']
model.addConstr(gp.quicksum(s[j] for j in adriatic_ports) <= adriatic_pool_shortage_trigger + M * R_adriatic, name="adriatic_pool_trigger")

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found")
