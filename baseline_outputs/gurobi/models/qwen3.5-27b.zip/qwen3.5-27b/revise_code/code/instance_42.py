import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            # Handle potential float/int conversion safely
            try:
                value = float(row['Value'].strip())
            except ValueError:
                value = row['Value'].strip()
            params[name] = value
    return params

def main():
    # Determine path to data folder relative to this script location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    params_file = os.path.join(data_dir, 'general_parameters.csv')
    
    params = load_parameters(params_file)
    
    # Extract parameters
    a = params['a']              # Time method 1
    b = params['b']              # Time method 2
    k = params['k']              # Tons per batch
    d = params['d']              # Min production
    
    c_offpeak = params['c_offpeak']
    c_peak = params['c_peak']
    cap_offpeak = params['cap_offpeak']
    cap_peak = params['cap_peak']
    
    m_offpeak = params['m_offpeak']
    n_offpeak = params['n_offpeak']
    m_peak = params['m_peak']
    n_peak = params['n_peak']
    
    f_offpeak = params['f_offpeak']
    f_peak = params['f_peak']
    
    thresh = int(params['offpeak_cooldown_batch_threshold'])
    fee = params['offpeak_cooldown_fee']
    
    # Initialize Model
    model = gp.Model("SteelFurnaceOptimization")
    model.setParam('OutputFlag', 0)
    
    # Sets
    furnaces = [1, 2]
    methods = [1, 2]
    periods = ['offpeak', 'peak']
    
    # Decision Variables
    # x[i][j][p]: Number of batches for furnace i, method j, period p
    x = {}
    for i in furnaces:
        for j in methods:
            for p in periods:
                x[i, j, p] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}_{p}")
    
    # y[i][p]: Binary, 1 if furnace i is active in period p
    y = {}
    for i in furnaces:
        for p in periods:
            y[i, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{p}")
            
    # z[i]: Binary, 1 if furnace i exceeds off-peak batch threshold
    z = {}
    for i in furnaces:
        z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{i}")
        
    model.update()
    
    # Objective Function
    # Variable Fuel Costs
    obj_expr = 0
    for i in furnaces:
        for j in methods:
            for p in periods:
                cost = m_offpeak if (j == 1 and p == 'offpeak') else \
                       n_offpeak if (j == 2 and p == 'offpeak') else \
                       m_peak if (j == 1 and p == 'peak') else \
                       n_peak
                obj_expr += cost * x[i, j, p]
                
    # Fixed Activation Costs
    for i in furnaces:
        obj_expr += f_offpeak * y[i, 'offpeak']
        obj_expr += f_peak * y[i, 'peak']
        
    # Cooldown Fees
    for i in furnaces:
        obj_expr += fee * z[i]
        
    model.setObjective(obj_expr, GRB.MINIMIZE)
    
    # Constraints
    
    # 1. Minimum Production Requirement
    total_production = 0
    for i in furnaces:
        for j in methods:
            for p in periods:
                total_production += k * x[i, j, p]
    model.addConstr(total_production >= d, name="MinProduction")
    
    # 2. Furnace Time Constraints (Per Furnace Per Period)
    for i in furnaces:
        for p in periods:
            time_used = 0
            for j in methods:
                time_per_batch = a if j == 1 else b
                time_used += time_per_batch * x[i, j, p]
            
            limit = c_offpeak if p == 'offpeak' else c_peak
            model.addConstr(time_used <= limit, name=f"FurnaceTime_{i}_{p}")
            
    # 3. Plant-Wide Time Constraints (Across Both Furnaces Per Period)
    for p in periods:
        time_used_plant = 0
        for i in furnaces:
            for j in methods:
                time_per_batch = a if j == 1 else b
                time_used_plant += time_per_batch * x[i, j, p]
        
        limit = cap_offpeak if p == 'offpeak' else cap_peak
        model.addConstr(time_used_plant <= limit, name=f"PlantCapacity_{p}")
        
    # 4. Activation Linking (If any batch, pay fixed cost)
    # Big M: Max possible batches is limited by time. 
    # Max time 12h, min batch time 2h -> Max 6 batches. M=10 is safe.
    M = 100 
    for i in furnaces:
        for p in periods:
            total_batches = 0
            for j in methods:
                total_batches += x[i, j, p]
            model.addConstr(total_batches <= M * y[i, p], name=f"ActivationLink_{i}_{p}")
            
    # 5. Cooldown Rule (Off-peak batches > threshold => fee)
    # If sum(x_offpeak) > thresh, then z = 1.
    # Constraint: sum(x) <= thresh + M * z
    for i in furnaces:
        offpeak_batches = 0
        for j in methods:
            offpeak_batches += x[i, j, 'offpeak']
        model.addConstr(offpeak_batches <= thresh + M * z[i], name=f"CooldownRule_{i}")
        
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Fallback if not optimal, though problem should be feasible
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
