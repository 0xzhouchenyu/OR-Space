import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add parent directory to path
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from utils import load_monthly_data, load_general_parameters

# Load data
data_dir = os.path.join(script_dir, 'data')
months, purchasing_prices, selling_prices = load_monthly_data(os.path.join(data_dir, 'table_1.csv'))
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params['fixed_ordering_cost']
month2_bulk_receiving_threshold = params['month2_bulk_receiving_threshold']
month2_bulk_receiving_fee = params['month2_bulk_receiving_fee']

# Create the MIP model
model = gp.Model("Maximize_Profit")
model.setParam('OutputFlag', 0)

# Decision variables
# x[m] = units purchased at the beginning of month m
x = {m: model.addVar(lb=0, name=f"purchase_{m}") for m in months}

# s[m] = units sold during month m
s = {m: model.addVar(lb=0, name=f"sell_{m}") for m in months}

# inv[m] = inventory at end of month m
inv = {m: model.addVar(lb=0, name=f"inventory_{m}") for m in months}

# y[m] = binary variable = 1 if any purchase in month m (for fixed ordering cost)
y = {m: model.addVar(vtype=GRB.BINARY, name=f"order_flag_{m}") for m in months}

# z = binary variable = 1 if February purchase > 300 (for bulk receiving fee)
z = model.addVar(vtype=GRB.BINARY, name="bulk_receiving_flag")

# Big-M value (use warehouse capacity as reasonable upper bound)
M = warehouse_capacity * 2  # Safe upper bound

# Objective: maximize total profit = sum of (selling revenue - purchasing cost - fixed costs)
profit_terms = []
for m in months:
    profit_terms.append(selling_prices[m] * s[m])
    profit_terms.append(-purchasing_prices[m] * x[m])
    profit_terms.append(-fixed_ordering_cost * y[m])

# Add February bulk receiving fee
profit_terms.append(-month2_bulk_receiving_fee * z)

model.setObjective(gp.quicksum(profit_terms), GRB.MAXIMIZE)

# Constraints
for m in months:
    # Inventory balance: inv[m] = inv[m-1] + x[m] - s[m]
    if m == months[0]:
        prev_inv = initial_stock
    else:
        prev_inv = inv[m - 1]
    
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], f"inventory_balance_{m}")
    
    # Warehouse capacity constraint: inventory after purchasing (before selling) <= warehouse_capacity
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, f"warehouse_after_purchase_{m}")
    
    # End-of-month inventory also cannot exceed warehouse capacity
    model.addConstr(inv[m] <= warehouse_capacity, f"warehouse_end_{m}")
    
    # Can't sell more than what's available (prev_inv + x[m])
    model.addConstr(s[m] <= prev_inv + x[m], f"sell_limit_{m}")
    
    # Linking constraint: if x[m] > 0 then y[m] = 1
    # x[m] <= M * y[m]
    model.addConstr(x[m] <= M * y[m], f"order_link_{m}")

# February bulk receiving constraint: if x[2] > 300 then z = 1
# x[2] - 300 <= M * z
model.addConstr(x[2] - month2_bulk_receiving_threshold <= M * z, f"bulk_receiving_link")

# Solve
model.optimize()

# Print results
for m in months:
    print(f"Month {m}: Purchase = {x[m].X}, Sell = {s[m].X}, End Inventory = {inv[m].X}")

obj_val = model.ObjVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
