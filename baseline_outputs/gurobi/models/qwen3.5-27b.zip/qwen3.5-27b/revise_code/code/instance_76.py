import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
            
    n = len(quarters)
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
            
    # Convert parameters to consistent units (10k m3, 10k yuan)
    # max_storage_capacity: 200000 m3 -> 20 10k m3
    max_storage = float(params['max_storage_capacity']) / 10000.0
    
    # storage_cost_a: 70 yuan/m3 -> 70 10k yuan / 10k m3
    storage_cost_a = float(params['storage_cost_a']) 
    
    # storage_cost_b: 100 yuan/m3/q -> 100 10k yuan / 10k m3 / q
    storage_cost_b = float(params['storage_cost_b'])
    
    # safety_inventory_level: 20 10k m3
    safety_level = float(params['safety_inventory_level_10k_m3'])
    
    # terminal_inventory_value: 455 10k yuan / 10k m3
    terminal_value = float(params['terminal_inventory_value_per_10k_m3'])
    
    # over_purchase_penalty: 300 10k yuan / 10k m3
    penalty_cost = float(params['over_purchase_penalty_cost_per_10k_m3'])
    
    # Create Model
    model = gp.Model("Timber_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    # x[i][j]: Buy in quarter i, Sell in quarter j (0 <= i <= j <= 3)
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
            
    # h[i]: Buy in quarter i, Hold to end of Autumn
    h = {}
    for i in range(n):
        h[i] = model.addVar(lb=0, name=f"h_{i}")
        
    # Inventory components at end of Autumn
    I_safe = model.addVar(lb=0, name="I_safe")
    I_excess = model.addVar(lb=0, name="I_excess")
    
    # Objective Function
    # Profit = Revenue - Purchase Cost - Storage Cost + Terminal Value - Penalty
    
    obj_terms = []
    
    # Revenue
    for i in range(n):
        for j in range(i, n):
            rev = sale_price[quarters[j]] * x[i, j]
            obj_terms.append(rev)
            
    # Purchase Cost
    for i in range(n):
        total_bought_i = gp.quicksum(x[i, j] for j in range(i, n)) + h[i]
        cost = purchase_price[quarters[i]] * total_bought_i
        obj_terms.append(-cost)
        
    # Storage Cost
    # For x[i,j]: u = j - i. If u > 0, cost = (A + B*u)
    for i in range(n):
        for j in range(i, n):
            u = j - i
            if u > 0:
                s_cost = (storage_cost_a + storage_cost_b * u) * x[i, j]
                obj_terms.append(-s_cost)
                
    # For h[i]: u = 4 - i (Held to end of Autumn, which is after Q3)
    # Q0(Winter) -> End(Q3): 4 quarters.
    # Q3(Autumn) -> End(Q3): 1 quarter.
    for i in range(n):
        u = 4 - i
        # Always stored at least 1 quarter if held to end of year
        s_cost = (storage_cost_a + storage_cost_b * u) * h[i]
        obj_terms.append(-s_cost)
        
    # Terminal Value & Penalty
    # Value = Terminal_Value * (I_safe + I_excess) - Penalty * I_excess
    #       = Terminal_Value * I_safe + (Terminal_Value - Penalty) * I_excess
    val_term = terminal_value * I_safe + (terminal_value - penalty_cost) * I_excess
    obj_terms.append(val_term)
    
    model.setObjective(gp.quicksum(obj_terms), GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Sales Volume Limits
    for j in range(n):
        sold_in_j = gp.quicksum(x[i, j] for i in range(j + 1))
        model.addConstr(sold_in_j <= max_sales[quarters[j]], name=f"sales_limit_{j}")
        
    # 2. Purchase Caps
    for i in range(n):
        bought_in_i = gp.quicksum(x[i, j] for j in range(i, n)) + h[i]
        model.addConstr(bought_in_i <= max_purchase[quarters[i]], name=f"purchase_cap_{i}")
        
    # 3. Storage Capacity Constraints
    # At end of each quarter t (0, 1, 2, 3)
    # Inventory = Sum of items bought in i <= t and not yet sold/held out
    # Items not sold by end of t:
    #   - x[i, j] where j > t
    #   - h[i] (held to end of year)
    for t in range(n):
        stored_at_t = gp.quicksum(
            x[i, j] for i in range(t + 1) for j in range(t + 1, n)
        ) + gp.quicksum(h[i] for i in range(t + 1))
        model.addConstr(stored_at_t <= max_storage, name=f"storage_cap_{t}")
        
    # 4. Inventory Balance at End of Autumn
    # Total held = I_safe + I_excess
    total_held = gp.quicksum(h[i] for i in range(n))
    model.addConstr(total_held == I_safe + I_excess, name="inv_balance")
    
    # 5. Safety Inventory Limit
    model.addConstr(I_safe <= safety_level, name="safety_limit")
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
