import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Determine path to data file
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(script_dir, 'data', 'general_parameters.csv')
    
    # Load parameters
    df = pd.read_csv(data_path)
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = float(row['Value'])
        
    # Extract specific parameters
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = int(params['raw_bar_length'])
    setup_cost = float(params['setup_cost_per_pattern'])
    max_patterns = int(params['max_distinct_patterns'])
    
    # Lengths of the three types of steel bars
    lengths = [3, 4, 5]
    demands = [q3, q4, q5]
    
    # Generate all valid cutting patterns
    # A pattern is a tuple (n3, n4, n5)
    patterns = []
    # Max possible count for each type
    max_n3 = L // lengths[0]
    max_n4 = L // lengths[1]
    max_n5 = L // lengths[2]
    
    for n3 in range(max_n3 + 1):
        for n4 in range(max_n4 + 1):
            for n5 in range(max_n5 + 1):
                used_len = lengths[0]*n3 + lengths[1]*n4 + lengths[2]*n5
                if used_len <= L:
                    if n3 > 0 or n4 > 0 or n5 > 0:
                        patterns.append((n3, n4, n5))
                        
    num_patterns = len(patterns)
    
    # Create Gurobi Model
    model = gp.Model("CuttingStock_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[p]: number of raw bars cut using pattern p
    x_vars = model.addVars(num_patterns, vtype=GRB.INTEGER, name="x")
    # y[p]: binary, 1 if pattern p is used
    y_vars = model.addVars(num_patterns, vtype=GRB.BINARY, name="y")
    
    # Objective: Minimize Total Waste
    # Total Waste = (Total Raw Length Used - Total Required Length) + (Setup Cost * Num Patterns Used)
    # Total Required Length is constant, so we can minimize (Total Raw Length + Setup Cost) 
    # and subtract Required Length at the end, OR include it in the objective.
    # To match the original heuristic's output style (Waste), we include the subtraction.
    
    total_required_length = lengths[0]*q3 + lengths[1]*q4 + lengths[2]*q5
    
    # Objective Expression
    obj_expr = gp.quicksum(L * x_vars[p] for p in range(num_patterns)) \
               + gp.quicksum(setup_cost * y_vars[p] for p in range(num_patterns)) \
               - total_required_length
    
    model.setObjective(obj_expr, GRB.MINIMIZE)
    
    # Constraints: Satisfy demand
    for i in range(3): # 0->3m, 1->4m, 2->5m
        model.addConstr(gp.quicksum(patterns[p][i] * x_vars[p] for p in range(num_patterns)) >= demands[i], f"Demand_{lengths[i]}m")
        
    # Constraints: Link x and y (Big-M)
    # M can be the maximum possible bars needed. Sum of demands is a safe upper bound.
    M = sum(demands) + 100 
    for p in range(num_patterns):
        model.addConstr(x_vars[p] <= M * y_vars[p], f"Link_{p}")
        
    # Constraint: Max distinct patterns
    model.addConstr(gp.quicksum(y_vars[p] for p in range(num_patterns)) <= max_patterns, "Max_Patterns")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # Fallback if not optimal (though expected to be solvable)
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
