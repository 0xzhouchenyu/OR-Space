import os
import gurobipy as gp
from gurobipy import GRB
import csv

def load_restaurant_data(filepath):
    """Load restaurant data from CSV file."""
    restaurants = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'standard_staff_hours': float(row['Standard_Staff_Hours'].strip()),
                'premium_staff_hours': float(row['Premium_Staff_Hours'].strip())
            })
    return restaurants

def load_general_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    return params

def main():
    # Determine data directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load data
    restaurants = load_restaurant_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    budget = params['investment_budget']
    premium_revenue_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']
    
    # Create the optimization model
    model = gp.Model("Restaurant_Investment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i] = 1 if restaurant i is purchased, 0 otherwise
    # y[i] = 1 if restaurant i is operated in Premium mode, 0 otherwise
    x = {}
    y = {}
    for r in restaurants:
        name = r['name']
        x[name] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}")
        y[name] = model.addVar(vtype=GRB.BINARY, name=f"y_{name}")
    
    # Objective: maximize total annual revenue
    # Revenue = base_revenue * x + base_revenue * premium_revenue_uplift * y
    obj_expr = gp.quicksum(
        r['revenue'] * x[r['name']] + 
        r['revenue'] * premium_revenue_uplift * y[r['name']] 
        for r in restaurants
    )
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Budget constraint: purchase cost + premium upgrade cost <= budget
    budget_expr = gp.quicksum(
        r['cost'] * x[r['name']] + 
        premium_upgrade_cost * y[r['name']] 
        for r in restaurants
    )
    model.addConstr(budget_expr <= budget, "Budget_Constraint")
    
    # Staff hours constraint: only premium staff hours count towards cap
    staff_expr = gp.quicksum(
        r['premium_staff_hours'] * y[r['name']] 
        for r in restaurants
    )
    model.addConstr(staff_expr <= staff_hours_cap, "Staff_Hours_Cap")
    
    # Premium only if purchased: y[i] <= x[i]
    for r in restaurants:
        name = r['name']
        model.addConstr(y[name] <= x[name], f"Premium_Requires_Purchase_{name}")
    
    # D-A exclusion constraint: if D is purchased, A cannot be purchased
    if 'Restaurant_D' in x and 'Restaurant_A' in x:
        model.addConstr(x['Restaurant_D'] + x['Restaurant_A'] <= 1, "D_A_Exclusion_Constraint")
    
    # Solve
    model.optimize()
    
    # Print results
    print(f"Status: {model.Status}")
    for r in restaurants:
        name = r['name']
        x_val = x[name].X
        y_val = y[name].X
        if x_val > 0.5:
            mode = "Premium" if y_val > 0.5 else "Standard"
            print(f"{name}: Buy ({mode}) (x={x_val}, y={y_val})")
        else:
            print(f"{name}: Do not buy (x={x_val})")
    
    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
