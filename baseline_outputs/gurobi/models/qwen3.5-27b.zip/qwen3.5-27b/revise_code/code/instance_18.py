import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

# Extract parameters
fabric_production_rate = params['fabric_production_rate']
min_curtain_fabric_sales = params['min_curtain_fabric_sales']
min_clothing_fabric_sales = params['min_clothing_fabric_sales']
day_shift_regular_capacity = params['day_shift_regular_capacity']
night_shift_regular_capacity = params['night_shift_regular_capacity']
day_overtime_limit = params['day_overtime_limit']
night_overtime_limit = params['night_overtime_limit']
day_overtime_penalty = params['day_overtime_penalty']
night_overtime_penalty = params['night_overtime_penalty']
day_min_utilization_ratio = params['day_min_utilization_ratio']
night_min_utilization_ratio = params['night_min_utilization_ratio']

# Convert sales requirements to hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

# Create model
model = gp.Model("Textile_Factory_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
# Regular hours for each fabric type in each shift
x_clothing_day_reg = model.addVar(lb=0, name="clothing_day_reg")
x_curtain_day_reg = model.addVar(lb=0, name="curtain_day_reg")
x_clothing_night_reg = model.addVar(lb=0, name="clothing_night_reg")
x_curtain_night_reg = model.addVar(lb=0, name="curtain_night_reg")

# Overtime hours for each fabric type in each shift
x_clothing_day_ot = model.addVar(lb=0, ub=day_overtime_limit, name="clothing_day_ot")
x_curtain_day_ot = model.addVar(lb=0, ub=day_overtime_limit, name="curtain_day_ot")
x_clothing_night_ot = model.addVar(lb=0, ub=night_overtime_limit, name="clothing_night_ot")
x_curtain_night_ot = model.addVar(lb=0, ub=night_overtime_limit, name="curtain_night_ot")

# Total regular hours per shift
total_day_reg = x_clothing_day_reg + x_curtain_day_reg
total_night_reg = x_clothing_night_reg + x_curtain_night_reg

# Constraints
# Shift capacity constraints
model.addConstr(total_day_reg <= day_shift_regular_capacity, "day_capacity")
model.addConstr(total_night_reg <= night_shift_regular_capacity, "night_capacity")

# Utilization ratio constraints
total_regular = total_day_reg + total_night_reg
model.addConstr(total_day_reg >= day_min_utilization_ratio * total_regular, "day_utilization")
model.addConstr(total_night_reg >= night_min_utilization_ratio * total_regular, "night_utilization")

# Sales requirements
total_clothing = x_clothing_day_reg + x_clothing_day_ot + x_clothing_night_reg + x_clothing_night_ot
total_curtain = x_curtain_day_reg + x_curtain_day_ot + x_curtain_night_reg + x_curtain_night_ot
model.addConstr(total_clothing >= min_clothing_hours, "clothing_sales")
model.addConstr(total_curtain >= min_curtain_hours, "curtain_sales")

# Objective: minimize overtime penalty cost
overtime_cost = (day_overtime_penalty * (x_clothing_day_ot + x_curtain_day_ot) + 
                 night_overtime_penalty * (x_clothing_night_ot + x_curtain_night_ot))
model.setObjective(overtime_cost, GRB.MINIMIZE)

# Solve
model.optimize()

# Print results
print(f"Status: {model.Status}")
print(f"Clothing fabric hours (day reg): {x_clothing_day_reg.X}")
print(f"Curtain fabric hours (day reg): {x_curtain_day_reg.X}")
print(f"Clothing fabric hours (night reg): {x_clothing_night_reg.X}")
print(f"Curtain fabric hours (night reg): {x_curtain_night_reg.X}")
print(f"Clothing fabric hours (day ot): {x_clothing_day_ot.X}")
print(f"Curtain fabric hours (day ot): {x_curtain_day_ot.X}")
print(f"Clothing fabric hours (night ot): {x_clothing_night_ot.X}")
print(f"Curtain fabric hours (night ot): {x_curtain_night_ot.X}")
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
