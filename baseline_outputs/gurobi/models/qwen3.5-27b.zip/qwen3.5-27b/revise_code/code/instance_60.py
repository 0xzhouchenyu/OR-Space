with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        lines = f.readlines()
        for line in lines[1:]: # Skip header
            nums = re.findall(r'\d+', line)
            if not nums:
                continue
            row_idx = int(nums[0]) - 1
            for j, val in enumerate(nums[1:]):
                col_idx = row_idx + 1 + j
                if col_idx < num_customers:
                    D[row_idx][col_idx] = int(val)
                    D[col_idx][row_idx] = int(val)
