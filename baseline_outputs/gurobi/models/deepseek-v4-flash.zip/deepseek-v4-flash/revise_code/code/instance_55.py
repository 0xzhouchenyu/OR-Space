import os
import csv
import gurobipy as gp
from gurobipy import GRB

# ========== DATA LOADING ==========
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load courses
courses_file = os.path.join(data_dir, "table_1.csv")
courses = {}
with open(courses_file, "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        course = row["Course"].strip()
        categories = [c.strip() for c in row["Category"].split(";")]
        courses[course] = categories

# Load parameters
params_file = os.path.join(data_dir, "general_parameters.csv")
min_required = None
prerequisites = {}
mandatory_foundation = None
cs_category = None

with open(params_file, "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        value = row["Value"].strip()
        if name == "min_courses_required":
            min_required = int(value)
        elif name == "prerequisite_computer_simulation":
            prerequisites["Computer Simulation"] = value
        elif name == "prerequisite_data_structures":
            prerequisites["Data Structures"] = value
        elif name == "prerequisite_management_statistics":
            prerequisites["Management Statistics"] = value
        elif name == "prerequisite_forecasting":
            prerequisites["Forecasting"] = value
        elif name == "mandatory_foundation_for_cs_counting":
            mandatory_foundation = value
        elif name == "cs_category_name":
            cs_category = value

# ========== MODEL SETUP ==========
model = gp.Model("CourseSelection")
model.setParam('OutputFlag', 0)

course_list = list(courses.keys())
all_categories = set()
for cats in courses.values():
    for c in cats:
        all_categories.add(c)

# Decision variables
x = model.addVars(course_list, vtype=GRB.BINARY, name="x")

# Objective: minimize total courses taken
model.setObjective(gp.quicksum(x[course] for course in course_list), GRB.MINIMIZE)

# ========== CONSTRAINTS ==========

# 1. Category minimum requirements with distinct courses
# For each category, at least min_required distinct courses
for category in all_categories:
    courses_in_cat = [c for c, cats in courses.items() if category in cats]
    model.addConstr(
        gp.quicksum(x[c] for c in courses_in_cat) >= min_required,
        name=f"Min_{category.replace(' ', '_')}"
    )

# 2. Prerequisite constraints
for course, prereq in prerequisites.items():
    if prereq in course_list:
        model.addConstr(x[course] <= x[prereq], name=f"Prereq_{course.replace(' ', '_')}")

# 3. Cross-listed courses cannot satisfy multiple category minima simultaneously
# We need to ensure that each course is counted for at most one category
# Create binary variables for each course-category assignment
y = {}
for course in course_list:
    for cat in courses[course]:
        y[(course, cat)] = model.addVar(vtype=GRB.BINARY, name=f"y_{course}_{cat}")

# Link y to x: if course is taken, it can be assigned to at most one category
for course in course_list:
    model.addConstr(
        gp.quicksum(y[(course, cat)] for cat in courses[course]) <= x[course],
        name=f"Assign_{course.replace(' ', '_')}"
    )

# For each category, the sum of assigned courses must meet the minimum
for category in all_categories:
    courses_in_cat = [c for c, cats in courses.items() if category in cats]
    model.addConstr(
        gp.quicksum(y[(c, category)] for c in courses_in_cat) >= min_required,
        name=f"DistinctMin_{category.replace(' ', '_')}"
    )

# 4. Mandatory foundation for CS counting
# If any course is assigned to CS category, then mandatory_foundation must be taken
cs_courses = [c for c, cats in courses.items() if cs_category in cats]
for course in cs_courses:
    model.addConstr(
        y[(course, cs_category)] <= x[mandatory_foundation],
        name=f"Foundation_{course.replace(' ', '_')}"
    )

# ========== SOLVE ==========
model.optimize()

# ========== OUTPUT ==========
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {int(model.objVal)}")
else:
    print(f"FINAL_OBJ_VALUE: -1")
