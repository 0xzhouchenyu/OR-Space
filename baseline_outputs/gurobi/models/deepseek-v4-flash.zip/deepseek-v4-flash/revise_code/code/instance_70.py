import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_distance_matrix(filepath):
    """Load distance matrix from CSV file."""
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        city_labels = header[1:]
        dist = []
        cities = []
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
    return cities, dist

def load_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            if row:
                params[row[0].strip()] = row[1].strip()
    return params

def solve_tsp_revised():
    # Get data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load parameters
    params_file = os.path.join(data_dir, 'general_parameters.csv')
    params = load_parameters(params_file)
    
    start_city = int(params['start_city'])
    end_city = int(params['end_city'])
    prohibited_from = int(params['prohibited_from'])
    prohibited_to = int(params['prohibited_to'])
    inspection_arc_from = int(params['inspection_arc_from'])
    inspection_arc_to = int(params['inspection_arc_to'])
    inspection_stop_cost = float(params['inspection_stop_cost'])
    
    # Load distance matrix
    dist_file = os.path.join(data_dir, 'table_1.csv')
    cities, dist = load_distance_matrix(dist_file)
    n = len(cities)
    
    # Convert city names to indices (cities are 1-indexed in data)
    city_to_idx = {int(cities[i]): i for i in range(n)}
    
    # Create Gurobi model
    model = gp.Model("TSP_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i,j] = 1 if we travel from city i to city j
    x = {}
    for i in range(n):
        for j in range(n):
            if i != j:
                x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
    
    # MTZ variables for subtour elimination
    u = {}
    for i in range(1, n):
        u[i] = model.addVar(lb=1, ub=n-1, vtype=GRB.CONTINUOUS, name=f"u_{i}")
    
    # Objective: minimize total distance + inspection costs
    obj = gp.LinExpr()
    for i in range(n):
        for j in range(n):
            if i != j:
                # Add base distance
                obj += dist[i][j] * x[i, j]
                # Add inspection cost if going from city 2 to city 3
                if cities[i] == str(inspection_arc_from) and cities[j] == str(inspection_arc_to):
                    obj += inspection_stop_cost * x[i, j]
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    # Each city is left exactly once
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1, f"out_{i}")
    
    # Each city is entered exactly once
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(n) if i != j) == 1, f"in_{j}")
    
    # Start constraint: must leave start city
    start_idx = city_to_idx[start_city]
    model.addConstr(gp.quicksum(x[start_idx, j] for j in range(n) if j != start_idx) == 1, "start_out")
    
    # End constraint: must enter end city
    end_idx = city_to_idx[end_city]
    model.addConstr(gp.quicksum(x[i, end_idx] for i in range(n) if i != end_idx) == 1, "end_in")
    
    # Prohibition: cannot go directly from prohibited_from to prohibited_to
    prohibited_from_idx = city_to_idx[prohibited_from]
    prohibited_to_idx = city_to_idx[prohibited_to]
    model.addConstr(x[prohibited_from_idx, prohibited_to_idx] == 0, "prohibition")
    
    # MTZ subtour elimination constraints
    for i in range(1, n):
        for j in range(1, n):
            if i != j:
                model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1, f"mtz_{i}_{j}")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    solve_tsp_revised()
