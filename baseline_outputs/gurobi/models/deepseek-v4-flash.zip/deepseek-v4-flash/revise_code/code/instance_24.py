import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    product_units = int(params['product_units'])
    truck_pollution = params['truck_pollution']
    van_pollution = params['van_pollution']
    motorcycle_pollution = params['motorcycle_pollution']
    ev_pollution = params['electric_vehicle_pollution']
    max_total_pollution = params['max_total_pollution']
    min_truck_trips = int(params['min_truck_trips'])
    truck_capacity = params['truck_capacity']
    van_capacity = params['van_capacity']
    motorcycle_capacity = params['motorcycle_capacity']
    ev_capacity = params['electric_vehicle_capacity']
    
    sales_point_share = {
        1: params['sales_point_share_sp1'],
        2: params['sales_point_share_sp2'],
        3: params['sales_point_share_sp3']
    }
    
    min_truck_share = {
        1: params['min_truck_share_sp1'],
        2: params['min_truck_share_sp2'],
        3: params['min_truck_share_sp3']
    }
    
    M_truck = int(params['M_truck_sp_day'])
    M_ev = int(params['M_ev_sp_day'])
    M_van = int(params['M_van_sp_day'])
    M_moto = int(params['M_moto_sp_day'])
    
    sales_points = [1, 2, 3]
    days = [1, 2, 3]
    
    # Demand per sales point
    demand = {sp: product_units * sales_point_share[sp] for sp in sales_points}
    
    # Create model
    model = gp.Model("Transportation_Pollution_Minimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: trips per vehicle type per sales point per day
    x_truck = {}
    x_van = {}
    x_moto = {}
    x_ev = {}
    
    for sp in sales_points:
        for d in days:
            x_truck[(sp, d)] = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_truck, name=f"truck_{sp}_{d}")
            x_van[(sp, d)] = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_van, name=f"van_{sp}_{d}")
            x_moto[(sp, d)] = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_moto, name=f"moto_{sp}_{d}")
            x_ev[(sp, d)] = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_ev, name=f"ev_{sp}_{d}")
    
    # Binary variables for mode selection per sales point and day
    # z[sp,d] = 1 means use truck/EV family, 0 means use van/motorcycle family
    z = {}
    for sp in sales_points:
        for d in days:
            z[(sp, d)] = model.addVar(vtype=GRB.BINARY, name=f"mode_{sp}_{d}")
    
    # Objective: minimize total pollution
    obj = gp.QuadExpr()
    for sp in sales_points:
        for d in days:
            obj += truck_pollution * x_truck[(sp, d)]
            obj += van_pollution * x_van[(sp, d)]
            obj += motorcycle_pollution * x_moto[(sp, d)]
            obj += ev_pollution * x_ev[(sp, d)]
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraint 1: Demand satisfaction per sales point (across all days)
    for sp in sales_points:
        model.addConstr(
            gp.quicksum(truck_capacity * x_truck[(sp, d)] + 
                       van_capacity * x_van[(sp, d)] + 
                       motorcycle_capacity * x_moto[(sp, d)] + 
                       ev_capacity * x_ev[(sp, d)] for d in days) >= demand[sp],
            f"Demand_{sp}"
        )
    
    # Constraint 2: Total pollution limit
    total_pollution = gp.QuadExpr()
    for sp in sales_points:
        for d in days:
            total_pollution += truck_pollution * x_truck[(sp, d)]
            total_pollution += van_pollution * x_van[(sp, d)]
            total_pollution += motorcycle_pollution * x_moto[(sp, d)]
            total_pollution += ev_pollution * x_ev[(sp, d)]
    model.addConstr(total_pollution <= max_total_pollution, "Max_Pollution")
    
    # Constraint 3: Minimum total truck trips across all sales points and days
    total_truck_trips = gp.quicksum(x_truck[(sp, d)] for sp in sales_points for d in days)
    model.addConstr(total_truck_trips >= min_truck_trips, "Min_Truck_Trips")
    
    # Constraint 4: Minimum truck share per sales point (across all days for that sales point)
    for sp in sales_points:
        total_trips_sp = gp.quicksum(x_truck[(sp, d)] + x_van[(sp, d)] + x_moto[(sp, d)] + x_ev[(sp, d)] for d in days)
        truck_trips_sp = gp.quicksum(x_truck[(sp, d)] for d in days)
        model.addConstr(truck_trips_sp >= min_truck_share[sp] * total_trips_sp, f"Min_Truck_Share_{sp}")
    
    # Constraint 5: Mode selection per sales point and day
    # If z[sp,d] = 1: only truck and EV can be used (van and moto must be 0)
    # If z[sp,d] = 0: only van and moto can be used (truck and EV must be 0)
    for sp in sales_points:
        for d in days:
            # Truck/EV family (z=1)
            model.addConstr(x_van[(sp, d)] <= M_van * (1 - z[(sp, d)]), f"Van_off_{sp}_{d}")
            model.addConstr(x_moto[(sp, d)] <= M_moto * (1 - z[(sp, d)]), f"Moto_off_{sp}_{d}")
            # Van/Moto family (z=0)
            model.addConstr(x_truck[(sp, d)] <= M_truck * z[(sp, d)], f"Truck_off_{sp}_{d}")
            model.addConstr(x_ev[(sp, d)] <= M_ev * z[(sp, d)], f"EV_off_{sp}_{d}")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
