import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load food items
    items = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })
    
    # Load parameters
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_daily_calories = params['min_daily_calories']
    max_daily_calories = params['max_daily_calories']
    max_daily_sodium = params['max_daily_sodium']
    
    max_units = int(total_weight_limit // 100)
    max_meal_units = 3  # 300g / 100g per unit
    
    n = len(items)
    
    # Create model
    model = gp.Model("dinner_planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    purchase_units = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="purchase_units")
    lunch_units = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="lunch_units")
    dinner_units = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="dinner_units")
    select_item = model.addVars(n, vtype=GRB.BINARY, name="select_item")
    
    # Vegetable selection variables for each meal
    veg_indices = [i for i in range(n) if items[i]['type'] == 'Vegetable']
    lunch_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg_selected")
    dinner_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg_selected")
    
    # Objective: maximize total protein from assigned units
    total_protein = gp.quicksum(items[i]['protein'] * (lunch_units[i] + dinner_units[i]) for i in range(n))
    model.setObjective(total_protein, GRB.MAXIMIZE)
    
    # Constraint 1: Budget
    model.addConstr(gp.quicksum(items[i]['cost'] * purchase_units[i] for i in range(n)) <= max_budget)
    
    # Constraint 2: Total weight limit
    model.addConstr(100 * gp.quicksum(purchase_units[i] for i in range(n)) <= total_weight_limit)
    
    # Constraint 3: Per-meal weight exactly 300g
    model.addConstr(gp.quicksum(100 * lunch_units[i] for i in range(n)) == 300)
    model.addConstr(gp.quicksum(100 * dinner_units[i] for i in range(n)) == 300)
    
    # Constraint 4: Purchase linkage
    model.addConstrs(purchase_units[i] >= lunch_units[i] + dinner_units[i] for i in range(n))
    
    # Constraint 5: Selection linkage with big-M
    model.addConstrs(purchase_units[i] <= max_units * select_item[i] for i in range(n))
    model.addConstrs(lunch_units[i] <= max_meal_units * select_item[i] for i in range(n))
    model.addConstrs(dinner_units[i] <= max_meal_units * select_item[i] for i in range(n))
    
    # Constraint 6: Daily calories
    total_calories = gp.quicksum(items[i]['calories'] * (lunch_units[i] + dinner_units[i]) for i in range(n))
    model.addConstr(total_calories >= min_daily_calories)
    model.addConstr(total_calories <= max_daily_calories)
    
    # Constraint 7: Daily sodium
    total_sodium = gp.quicksum(items[i]['sodium'] * (lunch_units[i] + dinner_units[i]) for i in range(n))
    model.addConstr(total_sodium <= max_daily_sodium)
    
    # Constraint 8: Vegetable coverage per meal
    for i in veg_indices:
        # Lunch vegetable selection linkage
        model.addConstr(lunch_units[i] >= lunch_veg_selected[i])
        model.addConstr(lunch_units[i] <= max_meal_units * lunch_veg_selected[i])
        # Dinner vegetable selection linkage
        model.addConstr(dinner_units[i] >= dinner_veg_selected[i])
        model.addConstr(dinner_units[i] <= max_meal_units * dinner_veg_selected[i])
    
    # Minimum vegetable types per meal
    model.addConstr(gp.quicksum(lunch_veg_selected[i] for i in veg_indices) >= min_veg_types)
    model.addConstr(gp.quicksum(dinner_veg_selected[i] for i in veg_indices) >= min_veg_types)
    
    # Solve
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
