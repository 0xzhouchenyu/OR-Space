import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    """Load a CSV file and return headers and rows."""
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    return headers, rows

def load_general_parameters(filename='general_parameters.csv'):
    """Load general parameters into a dictionary."""
    headers, rows = load_csv(filename)
    params = {}
    for row in rows:
        name = row[0].strip()
        try:
            value = float(row[1].strip())
        except ValueError:
            value = row[1].strip()
        params[name] = value
    return params

def load_crop_data(filename='table_1.csv'):
    """Load crop data from table_1.csv."""
    headers, rows = load_csv(filename)
    crops = [h.strip() for h in headers[1:]]
    data = {}
    for row in rows:
        item = row[0].strip()
        values = [float(v.strip()) for v in row[1:]]
        data[item] = dict(zip(crops, values))
    return crops, data

def main():
    # Load data
    params = load_general_parameters()
    crops, crop_data = load_crop_data()
    
    # Extract parameters
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']
    
    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = params['max_chickens']
    max_dairy_cows = params['max_dairy_cows']
    
    # New parameters from revision
    fixed_cost_chicken_setup = params['fixed_cost_chicken_setup']
    min_chickens_if_coop_open = params['min_chickens_if_coop_open']
    second_biosecurity_threshold = params['second_biosecurity_threshold']
    second_biosecurity_cost = params['second_biosecurity_cost']
    biosecurity_training_aw_days = params['biosecurity_training_aw_days']
    biosecurity_training_ss_days = params['biosecurity_training_ss_days']
    
    # Crop data
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']
    
    # Create model
    model = gp.Model("Farm_Optimization_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Crop areas
    x = {}
    for c in crops:
        x[c] = model.addVar(lb=0, name=f"x_{c}")
    
    # Number of dairy cows and chickens
    y_dairy = model.addVar(lb=0, ub=max_dairy_cows, name="dairy_cows")
    y_chicken = model.addVar(lb=0, ub=max_chickens, name="chickens")
    
    # Surplus labor for external work
    surplus_aw = model.addVar(lb=0, name="surplus_aw")
    surplus_ss = model.addVar(lb=0, name="surplus_ss")
    
    # Binary variables for chicken biosecurity decisions
    z_coop_open = model.addVar(vtype=GRB.BINARY, name="coop_open")  # 1 if any chickens raised
    z_second_biosecurity = model.addVar(vtype=GRB.BINARY, name="second_biosecurity")  # 1 if flock >= second threshold
    
    # Update model to include variables
    model.update()
    
    # Objective: maximize net income from crops + animals + external work - fixed costs
    obj = gp.LinExpr()
    obj += gp.quicksum(crop_income[c] * x[c] for c in crops)
    obj += income_dairy * y_dairy
    obj += income_chicken * y_chicken
    obj += ext_rate_aw * surplus_aw
    obj += ext_rate_ss * surplus_ss
    obj -= fixed_cost_chicken_setup * z_coop_open
    obj -= second_biosecurity_cost * z_second_biosecurity
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Land constraint
    model.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, "Land")
    
    # Funds constraint
    model.addConstr(inv_dairy * y_dairy + inv_chicken * y_chicken <= funds_available, "Funds")
    
    # Labor autumn/winter constraint (including biosecurity training if coop open)
    model.addConstr(
        gp.quicksum(crop_aw[c] * x[c] for c in crops) +
        labor_aw_dairy * y_dairy +
        labor_aw_chicken * y_chicken +
        biosecurity_training_aw_days * z_coop_open +
        surplus_aw <= labor_aw, "Labor_AW"
    )
    
    # Labor spring/summer constraint (including biosecurity training if coop open)
    model.addConstr(
        gp.quicksum(crop_ss[c] * x[c] for c in crops) +
        labor_ss_dairy * y_dairy +
        labor_ss_chicken * y_chicken +
        biosecurity_training_ss_days * z_coop_open +
        surplus_ss <= labor_ss, "Labor_SS"
    )
    
    # Chicken biosecurity constraints:
    # If coop is open, chickens must be at least min_chickens_if_coop_open
    model.addConstr(y_chicken >= min_chickens_if_coop_open * z_coop_open, "MinChickensIfOpen")
    
    # If coop is closed, no chickens
    model.addConstr(y_chicken <= max_chickens * z_coop_open, "MaxChickensOnlyIfOpen")
    
    # Second biosecurity threshold: if chickens >= second_biosecurity_threshold, then z_second_biosecurity = 1
    # Use big-M: y_chicken - second_biosecurity_threshold <= max_chickens * z_second_biosecurity
    model.addConstr(
        y_chicken - second_biosecurity_threshold <= max_chickens * z_second_biosecurity,
        "SecondBiosecurityTrigger"
    )
    
    # If z_second_biosecurity = 1, then chickens must be >= second_biosecurity_threshold
    model.addConstr(
        y_chicken >= second_biosecurity_threshold * z_second_biosecurity,
        "SecondBiosecurityMin"
    )
    
    # Solve
    model.optimize()
    
    # Output results
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        
        # Print solution details
        for c in crops:
            print(f"{c}: {x[c].X:.4f} hectares")
        print(f"Dairy cows: {y_dairy.X:.4f}")
        print(f"Chickens: {y_chicken.X:.4f}")
        print(f"Coop open: {z_coop_open.X}")
        print(f"Second biosecurity: {z_second_biosecurity.X}")
        print(f"Surplus labor AW: {surplus_aw.X:.4f} person-days")
        print(f"Surplus labor SS: {surplus_ss.X:.4f} person-days")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Problem status: {model.status}")
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
