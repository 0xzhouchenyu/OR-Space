import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            params[name] = val
    
    # Extract parameters
    a1_yield = float(params['product_A1_yield'])       # 3 kg per barrel
    a1_time = float(params['product_A1_time'])          # 12 hours per barrel
    a2_yield = float(params['product_A2_yield'])        # 4 kg per barrel
    a2_time = float(params['product_A2_time'])          # 8 hours per barrel
    a3_yield = float(params['product_A3_yield'])        # 2 kg per barrel
    a3_time = float(params['product_A3_time'])          # 10 hours per barrel
    profit_a1 = float(params['profit_per_kg_A1'])       # 24 yuan/kg
    profit_a2 = float(params['profit_per_kg_A2'])       # 16 yuan/kg
    profit_a3 = float(params['profit_per_kg_A3'])       # 30 yuan/kg
    milk_supply = float(params['daily_milk_supply'])     # 50 barrels
    labor_hours = float(params['daily_labor_hours'])     # 480 hours
    cap_A_shared = float(params['cap_A_shared'])         # 90 kg shared capacity for A1 and A3
    min_A2_kg = float(params['min_A2_kg'])               # 40 kg minimum A2
    min_A3_kg = float(params['min_A3_kg'])               # 20 kg minimum A3
    cleaning_loss = float(params['type_A_cleaning_loss_if_A3'])  # 12 kg
    bonus_threshold = float(params['cold_chain_bonus_threshold_kg'])  # 30 kg
    bonus_yuan = float(params['cold_chain_bonus_yuan'])  # 300 yuan
    
    # Create model
    model = gp.Model("Dairy_Production_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: barrels of milk for each product
    x1 = model.addVar(lb=0, name="x1")  # barrels for A1
    x2 = model.addVar(lb=0, name="x2")  # barrels for A2
    x3 = model.addVar(lb=0, name="x3")  # barrels for A3
    
    # Binary variable for cold-chain bonus
    z = model.addVar(vtype=GRB.BINARY, name="z")  # 1 if A3 >= bonus_threshold
    
    # Objective: maximize profit + bonus
    profit_expr = (profit_a1 * a1_yield * x1 + 
                   profit_a2 * a2_yield * x2 + 
                   profit_a3 * a3_yield * x3 + 
                   bonus_yuan * z)
    model.setObjective(profit_expr, GRB.MAXIMIZE)
    
    # Constraints
    # Milk supply
    model.addConstr(x1 + x2 + x3 <= milk_supply, "Milk_Supply")
    
    # Labor hours
    model.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours, "Labor_Hours")
    
    # Shared Type A capacity (A1 and A3) with cleaning loss if A3 is produced
    # If A3 > 0, cleaning_loss is subtracted from cap_A_shared
    # Use big-M formulation: let M be a large number
    M = 1000
    # Cleaning loss applies when x3 > 0
    # Introduce binary variable for whether A3 is produced
    y = model.addVar(vtype=GRB.BINARY, name="y")  # 1 if A3 is produced (x3 > 0)
    
    # Link y to x3
    model.addConstr(x3 <= M * y, "Link_y_x3")
    model.addConstr(x3 >= 0.001 * y, "Link_y_x3_lower")  # if y=1, x3 must be > 0
    
    # Type A capacity constraint
    model.addConstr(a1_yield * x1 + a3_yield * x3 <= cap_A_shared - cleaning_loss * y, "Type_A_Capacity")
    
    # Minimum A2 production
    model.addConstr(a2_yield * x2 >= min_A2_kg, "Min_A2")
    
    # Minimum A3 production
    model.addConstr(a3_yield * x3 >= min_A3_kg, "Min_A3")
    
    # Cold-chain bonus threshold
    model.addConstr(a3_yield * x3 >= bonus_threshold * z, "Bonus_Threshold")
    # If z=1, then A3 >= threshold; if z=0, no constraint (but we also need to ensure z=0 when below threshold)
    # The constraint a3_yield * x3 >= bonus_threshold * z already ensures z=1 only if threshold met
    # We also need to ensure z=0 when below threshold - this is handled by the objective (no incentive to set z=1 if not met)
    # But to be safe, add: a3_yield * x3 <= bonus_threshold + M*(1-z)  (if z=0, x3 can be anything; if z=1, x3 >= threshold)
    # Actually the first constraint is sufficient for correctness, but we add the second to prevent z=1 when x3 < threshold
    model.addConstr(a3_yield * x3 <= bonus_threshold + M * (1 - z), "Bonus_Threshold_Upper")
    
    # Optimize
    model.optimize()
    
    # Get results
    obj_val = model.objVal
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
