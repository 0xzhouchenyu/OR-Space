import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
def load_parameters():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            try:
                if '.' in val:
                    params[name] = float(val)
                else:
                    params[name] = int(val)
            except ValueError:
                params[name] = val
    return params

def load_demand():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "table_1.csv")
    demand = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            week = int(row['Week'].strip())
            demand[week] = {
                'I': int(row['I'].strip()),
                'II': int(row['II'].strip())
            }
    return demand

params = load_parameters()
demand = load_demand()

T = 8
weeks = range(1, T + 1)

# Parameters
S0 = params['skilled_worker_count']
rate_I = params['food_I_production_rate']
rate_II = params['food_II_production_rate']
normal_hours = params['worker_weekly_hours']
overtime_hours = params['skilled_worker_overtime_hours']
train_cap = params['training_capacity']
train_period = params['training_period']
wage_skilled = params['skilled_worker_weekly_wage']
wage_trainee_during = params['trainee_weekly_wage_during_training']
wage_trainee_after = params['trainee_weekly_wage_after_training']
wage_overtime = params['skilled_worker_overtime_wage']
comp_I = params['compensation_fee_food_I']
comp_II = params['compensation_fee_food_II']
new_worker_goal = params['new_worker_training_goal']

# Create model
model = gp.Model("factory_training")
model.setParam('OutputFlag', 0)

# Decision variables
# n_train[t] = number of skilled workers starting training in week t (t=1..7)
n_train = {}
for t in range(1, T):
    n_train[t] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_train_{t}")

# Binary variable: 1 if week t produces Food I, 0 if Food II (or idle)
# We'll use two binary variables: y_I[t], y_II[t] with y_I[t] + y_II[t] <= 1
y_I = {}
y_II = {}
for t in weeks:
    y_I[t] = model.addVar(vtype=GRB.BINARY, name=f"y_I_{t}")
    y_II[t] = model.addVar(vtype=GRB.BINARY, name=f"y_II_{t}")

# Hours allocated to each product by each worker type
# Skilled normal hours
h_I_s = {}
h_II_s = {}
for t in weeks:
    h_I_s[t] = model.addVar(lb=0, name=f"hIs_{t}")
    h_II_s[t] = model.addVar(lb=0, name=f"hIIs_{t}")

# Skilled overtime hours
h_I_ot = {}
h_II_ot = {}
for t in weeks:
    h_I_ot[t] = model.addVar(lb=0, name=f"hIot_{t}")
    h_II_ot[t] = model.addVar(lb=0, name=f"hIIot_{t}")

# Graduate hours
h_I_g = {}
h_II_g = {}
for t in weeks:
    h_I_g[t] = model.addVar(lb=0, name=f"hIg_{t}")
    h_II_g[t] = model.addVar(lb=0, name=f"hIIg_{t}")

# Number of skilled workers doing overtime in week t
n_overtime = {}
for t in weeks:
    n_overtime[t] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_ot_{t}")

# Backlog variables
backlog_I = {}
backlog_II = {}
for t in weeks:
    backlog_I[t] = model.addVar(lb=0, name=f"bI_{t}")
    backlog_II[t] = model.addVar(lb=0, name=f"bII_{t}")

# Helper functions
def trainers_busy(t):
    expr = 0
    for s in range(1, T):
        if s <= t <= s + train_period - 1:
            expr += n_train[s]
    return expr

def graduates_available(t):
    expr = 0
    for s in range(1, T):
        if s + train_period <= t:
            expr += train_cap * n_train[s]
    return expr

# Constraints
for t in weeks:
    busy_t = trainers_busy(t)
    avail_skilled_t = S0 - busy_t
    grads_t = graduates_available(t)
    
    # Mutual exclusion: only one product type per week
    model.addConstr(y_I[t] + y_II[t] <= 1, f"mutual_excl_{t}")
    
    # Overtime limit
    model.addConstr(n_overtime[t] <= avail_skilled_t, f"ot_limit_{t}")
    
    # Skilled normal hours constraint
    model.addConstr(h_I_s[t] + h_II_s[t] <= (avail_skilled_t - n_overtime[t]) * normal_hours, 
                    f"skilled_normal_hours_{t}")
    
    # Skilled overtime hours constraint
    model.addConstr(h_I_ot[t] + h_II_ot[t] <= n_overtime[t] * overtime_hours, 
                    f"skilled_ot_hours_{t}")
    
    # Graduate hours constraint
    model.addConstr(h_I_g[t] + h_II_g[t] <= grads_t * normal_hours, 
                    f"grad_hours_{t}")
    
    # Mutual exclusion: if y_I[t]=1, then h_II_s[t]=h_II_ot[t]=h_II_g[t]=0
    # If y_II[t]=1, then h_I_s[t]=h_I_ot[t]=h_I_g[t]=0
    # Use big-M constraints
    M = 10000  # Large enough
    
    model.addConstr(h_II_s[t] <= M * (1 - y_I[t]), f"mutex_IIs_{t}")
    model.addConstr(h_II_ot[t] <= M * (1 - y_I[t]), f"mutex_IIot_{t}")
    model.addConstr(h_II_g[t] <= M * (1 - y_I[t]), f"mutex_IIg_{t}")
    
    model.addConstr(h_I_s[t] <= M * (1 - y_II[t]), f"mutex_Is_{t}")
    model.addConstr(h_I_ot[t] <= M * (1 - y_II[t]), f"mutex_Iot_{t}")
    model.addConstr(h_I_g[t] <= M * (1 - y_II[t]), f"mutex_Ig_{t}")
    
    # Production
    prod_I_t = (h_I_s[t] + h_I_ot[t] + h_I_g[t]) * rate_I
    prod_II_t = (h_II_s[t] + h_II_ot[t] + h_II_g[t]) * rate_II
    
    # Backlog balance
    prev_bI = backlog_I[t-1] if t > 1 else 0
    prev_bII = backlog_II[t-1] if t > 1 else 0
    
    model.addConstr(backlog_I[t] >= prev_bI + demand[t]['I'] - prod_I_t, f"backlog_I_{t}")
    model.addConstr(backlog_II[t] >= prev_bII + demand[t]['II'] - prod_II_t, f"backlog_II_{t}")

# Skilled worker availability constraint
for t in weeks:
    busy_t = trainers_busy(t)
    model.addConstr(S0 - busy_t >= 0, f"enough_skilled_{t}")

# Training goal: at least 50 new workers trained by end of week 8
total_trained = gp.quicksum(train_cap * n_train[s] for s in range(1, T))
model.addConstr(total_trained >= new_worker_goal, "training_goal")

# Objective function
obj = 0

# Skilled worker wages (all skilled workers get paid regardless of role)
for t in weeks:
    busy_t = trainers_busy(t)
    avail_skilled_t = S0 - busy_t
    # Normal skilled workers (including trainers) get wage_skilled
    obj += S0 * wage_skilled  # All skilled workers get normal wage
    
    # Overtime premium: overtime workers get extra (wage_overtime - wage_skilled)
    obj += n_overtime[t] * (wage_overtime - wage_skilled)
    
    # Trainee wages during training
    for s in range(1, T):
        if s <= t <= s + train_period - 1:
            obj += n_train[s] * train_cap * wage_trainee_during
    
    # Graduate wages
    grads_t = graduates_available(t)
    obj += grads_t * wage_trainee_after

# Compensation costs
for t in weeks:
    obj += comp_I * backlog_I[t]
    obj += comp_II * backlog_II[t]

model.setObjective(obj, GRB.MINIMIZE)

# Optimize
model.optimize()

# Print result
print(f"FINAL_OBJ_VALUE: {model.objVal}")
