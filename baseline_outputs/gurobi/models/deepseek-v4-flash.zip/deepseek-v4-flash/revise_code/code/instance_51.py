import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load demand
demand = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        demand.append(int(row["Required_Nurses"]))

# Load parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = row["Value"]

shift_duration = int(params["shift_duration"])  # 8 hours
regular_pay = float(params["regular_nurse_pay"])  # 10
contract_pay = float(params["contract_nurse_pay"])  # 15
outsourced_start_index = int(params["outsourced_regular_start_index"])  # 2 (10:00 start)
banned_contract_start_index = int(params["banned_contract_start_index"])  # 5 (22:00 start)
max_total_contract_starts = int(params["max_total_contract_starts"])  # 20
min_regular_daytime_coverage = int(params["min_regular_daytime_coverage"])  # 8
daytime_period_indices = [int(x) for x in params["daytime_period_indices"].split(";")]  # [1,2,3,4]

num_periods = len(demand)  # 6 periods
periods_per_shift = shift_duration // 4  # 2 periods per shift

# Create model
model = gp.Model("NurseScheduling")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="regular")
y = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="contract")

# Objective: minimize total cost (8 hours per nurse)
cost = gp.quicksum((regular_pay * shift_duration) * x[j] + (contract_pay * shift_duration) * y[j] for j in range(num_periods))
model.setObjective(cost, GRB.MINIMIZE)

# Coverage constraints: for each period i, sum of nurses from covering shifts >= demand[i]
for i in range(num_periods):
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i], f"coverage_{i}")

# Constraint: Regular nurses cannot start at outsourced shift (index 2)
model.addConstr(x[outsourced_start_index] == 0, "no_regular_outsourced")

# Constraint: Contract nurses cannot start at overnight shift (index 5)
model.addConstr(y[banned_contract_start_index] == 0, "no_contract_overnight")

# Constraint: Total contract starts capped
model.addConstr(gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts, "max_contract_starts")

# Constraint: Minimum regular nurses on duty during daytime periods (indices 1,2,3,4)
for i in daytime_period_indices:
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(gp.quicksum(x[j] for j in covering_shifts) >= min_regular_daytime_coverage, f"min_regular_daytime_{i}")

# Solve
model.optimize()

# Get objective value
total_cost = model.objVal

# Print solution details (optional, but keep for consistency)
for j in range(num_periods):
    print(f"Shift {j}: Regular={int(x[j].X)}, Contract={int(y[j].X)}")

print(f"FINAL_OBJ_VALUE: {total_cost}")
