import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params_file = os.path.join(data_dir, 'general_parameters.csv')

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']
T1 = params['available_time_process_1']
T2 = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']
c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
bigM = params['bigM_disposal']
disposal_cost = params['disposal_cost_per_unit_c']
disposal_cost_high = params['disposal_cost_per_unit_c_high']
profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

# Create model
model = gp.Model("MaxProfit")
model.setParam('OutputFlag', 0)

# Decision variables
xA = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="xA")
xB = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="xB")
cSold = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="cSold")
cDisposed_base = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="cDisposed_base")
cDisposed_high = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="cDisposed_high")

# Binary variables for high-throughput mode selection
y1 = model.addVar(vtype=GRB.BINARY, name="y1")  # 1 if process 1 uses high-throughput
y2 = model.addVar(vtype=GRB.BINARY, name="y2")  # 1 if process 2 uses high-throughput

# Binary variable for disposal threshold crossing
z = model.addVar(vtype=GRB.BINARY, name="z")  # 1 if disposal exceeds threshold_c

# Objective: maximize total profit
model.setObjective(
    profit_a * xA + profit_b * xB + profit_c * cSold 
    - disposal_cost * cDisposed_base - disposal_cost_high * cDisposed_high,
    GRB.MAXIMIZE
)

# Constraints
# At most one process can use high-throughput mode
model.addConstr(y1 + y2 <= 1, "AtMostOneHighThroughput")

# Process time constraints with mode selection
model.addConstr(a_p1 * xA + b_p1 * xB <= T1 + (T1_high - T1) * y1, "Process1Time")
model.addConstr(a_p2 * xA + b_p2 * xB <= T2 + (T2_high - T2) * y2, "Process2Time")

# By-product C balance
model.addConstr(cSold + cDisposed_base + cDisposed_high == c_per_b * xB, "ByproductBalance")

# Maximum C sales
model.addConstr(cSold <= max_c_sales, "MaxCSales")

# Disposal threshold logic
# cDisposed_base <= threshold_c
model.addConstr(cDisposed_base <= threshold_c, "BaseDisposalCap")

# If z=0: cDisposed_high = 0, cDisposed_base <= threshold_c
# If z=1: cDisposed_base = threshold_c, cDisposed_high >= 0
model.addConstr(cDisposed_base >= threshold_c * z, "ThresholdTrigger")
model.addConstr(cDisposed_base <= threshold_c, "BaseDisposalMax")
model.addConstr(cDisposed_high <= bigM * z, "HighDisposalOnlyIfZ")
model.addConstr(cDisposed_high >= 0, "HighDisposalNonneg")

# Solve
model.optimize()

# Output
print(f"FINAL_OBJ_VALUE: {model.objVal}")
