import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                "name": row["Product Name"].strip(),
                "labor": float(row["Labor per unit"].strip()),
                "material": float(row["Material per unit"].strip()),
                "price": float(row["Selling Price"].strip()),
                "var_cost": float(row["Variable Cost"].strip())
            })
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    available_labor = params["available_labor"]
    available_material = params["available_material"]
    fixed_costs = [
        params["fixed_cost_shirts"],
        params["fixed_cost_short_sleeves"],
        params["fixed_cost_casual_clothes"]
    ]
    reg_discount = params["segment_regular_discount"]
    promo_discount = params["segment_promo_discount"]
    promo_labor_cap = params["segment_promo_labor_cap"]
    promo_material_cap = params["segment_promo_material_cap"]
    min_batch = [
        params["min_batch_shirts"],
        params["min_batch_short_sleeves"],
        params["min_batch_casual_clothes"]
    ]
    max_prod = [
        params["max_prod_shirts"],
        params["max_prod_short_sleeves"],
        params["max_prod_casual_clothes"]
    ]
    
    n = len(products)
    
    # Create model
    model = gp.Model("clothing_production")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Regular segment production quantities
    x_reg = [model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_reg_{i}") for i in range(n)]
    # Promotional segment production quantities
    x_promo = [model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_promo_{i}") for i in range(n)]
    # Binary variables for equipment activation (1 if product line is open)
    y = [model.addVar(vtype=GRB.BINARY, name=f"y_{i}") for i in range(n)]
    # Binary variables for segment presence (1 if segment has at least min_batch units)
    z_reg = [model.addVar(vtype=GRB.BINARY, name=f"z_reg_{i}") for i in range(n)]
    z_promo = [model.addVar(vtype=GRB.BINARY, name=f"z_promo_{i}") for i in range(n)]
    
    model.update()
    
    # Objective: maximize profit
    # Revenue from regular segment: price * reg_discount * x_reg
    # Revenue from promotional segment: price * promo_discount * x_promo
    # Variable costs: var_cost * (x_reg + x_promo)
    # Fixed costs: sum of fixed_costs[i] * y[i]
    total_revenue = gp.QuadExpr()
    total_var_cost = gp.QuadExpr()
    for i in range(n):
        total_revenue += products[i]["price"] * reg_discount * x_reg[i]
        total_revenue += products[i]["price"] * promo_discount * x_promo[i]
        total_var_cost += products[i]["var_cost"] * (x_reg[i] + x_promo[i])
    
    total_fixed = gp.QuadExpr()
    for i in range(n):
        total_fixed += fixed_costs[i] * y[i]
    
    model.setObjective(total_revenue - total_var_cost - total_fixed, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Total labor constraint
    model.addConstr(
        gp.quicksum(products[i]["labor"] * (x_reg[i] + x_promo[i]) for i in range(n)) <= available_labor,
        "total_labor"
    )
    
    # 2. Total material constraint
    model.addConstr(
        gp.quicksum(products[i]["material"] * (x_reg[i] + x_promo[i]) for i in range(n)) <= available_material,
        "total_material"
    )
    
    # 3. Promotional segment labor cap
    model.addConstr(
        gp.quicksum(products[i]["labor"] * x_promo[i] for i in range(n)) <= promo_labor_cap,
        "promo_labor_cap"
    )
    
    # 4. Promotional segment material cap
    model.addConstr(
        gp.quicksum(products[i]["material"] * x_promo[i] for i in range(n)) <= promo_material_cap,
        "promo_material_cap"
    )
    
    # 5. Equipment activation and production bounds
    for i in range(n):
        # If equipment is not activated, no production in either segment
        model.addConstr(x_reg[i] + x_promo[i] <= max_prod[i] * y[i], f"max_prod_{i}")
        # If equipment is activated, total production must meet minimum batch
        model.addConstr(x_reg[i] + x_promo[i] >= min_batch[i] * y[i], f"min_batch_{i}")
    
    # 6. Segment presence logic: a product is present in a segment only if that segment's quantity >= min_batch
    for i in range(n):
        # Regular segment presence
        model.addConstr(x_reg[i] >= min_batch[i] * z_reg[i], f"reg_presence_lower_{i}")
        model.addConstr(x_reg[i] <= max_prod[i] * z_reg[i], f"reg_presence_upper_{i}")
        # Promotional segment presence
        model.addConstr(x_promo[i] >= min_batch[i] * z_promo[i], f"promo_presence_lower_{i}")
        model.addConstr(x_promo[i] <= max_prod[i] * z_promo[i], f"promo_presence_upper_{i}")
    
    # 7. If equipment is activated, at least one segment must be present
    for i in range(n):
        model.addConstr(z_reg[i] + z_promo[i] >= y[i], f"segment_presence_{i}")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    
    # Print results
    for i in range(n):
        reg_val = int(x_reg[i].X)
        promo_val = int(x_promo[i].X)
        print(f"{products[i]['name']} Regular: {reg_val}, Promo: {promo_val}")
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
