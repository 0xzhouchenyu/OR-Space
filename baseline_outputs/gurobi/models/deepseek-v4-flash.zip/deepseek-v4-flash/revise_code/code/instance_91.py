import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            
            # Handle ratio values like "5:2"
            if ':' in value_str:
                params[name + '_raw'] = value_str
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params

def main():
    # Load parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Extract parameters
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_hours = params['machine_working_time']
    machine_working_time_minutes = machine_working_time_hours * 60
    
    # Ratio constraint: at least 2 units of B for every 5 units of A
    ratio_A, ratio_B = params['production_ratio_A_to_B']
    
    # Overtime parameters
    max_overtime_hours = params['max_overtime_hours']
    max_overtime_minutes = max_overtime_hours * 60
    overtime_penalty_per_hour = params['overtime_penalty_per_hour']
    overtime_penalty_per_minute = overtime_penalty_per_hour / 60.0
    overtime_review_threshold_hours = params['overtime_review_threshold_hours']
    overtime_review_threshold_minutes = overtime_review_threshold_hours * 60
    overtime_review_fee = params['overtime_review_fee']
    
    # Senior batch parameters
    senior_batch_threshold = params['product_A_senior_batch_threshold']
    senior_batch_fee = params['product_A_senior_batch_fee']
    
    # Create model
    model = gp.Model("Product_Mix_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    A = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_A")
    B = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_B")
    overtime = model.addVar(lb=0, ub=max_overtime_minutes, vtype=GRB.CONTINUOUS, name="Overtime_Minutes")
    
    # Binary variable for overtime review fee (1 if overtime > threshold)
    z_overtime = model.addVar(vtype=GRB.BINARY, name="Overtime_Review_Flag")
    
    # Binary variable for senior batch fee (1 if A > threshold)
    z_senior = model.addVar(vtype=GRB.BINARY, name="Senior_Batch_Flag")
    
    # Big-M values
    M_overtime = max_overtime_minutes + 1
    M_senior = 10000  # sufficiently large
    
    # Objective: maximize profit minus costs
    profit_term = profit_A * A + profit_B * B
    overtime_penalty = overtime_penalty_per_minute * overtime
    review_fee_term = overtime_review_fee * z_overtime
    senior_fee_term = senior_batch_fee * z_senior
    
    model.setObjective(profit_term - overtime_penalty - review_fee_term - senior_fee_term, GRB.MAXIMIZE)
    
    # Constraint 1: Machine time (regular time + overtime)
    model.addConstr(assembly_time_A * A + assembly_time_B * B <= machine_working_time_minutes + overtime, "Machine_Time")
    
    # Constraint 2: Production ratio
    model.addConstr(ratio_B * A - ratio_A * B <= 0, "Production_Ratio")
    
    # Constraint 3: Overtime review fee trigger
    # If overtime > threshold, then z_overtime = 1
    model.addConstr(overtime <= overtime_review_threshold_minutes + M_overtime * z_overtime, "Overtime_Review_1")
    # If z_overtime = 0, then overtime <= threshold
    model.addConstr(overtime >= overtime_review_threshold_minutes + 1e-5 - M_overtime * (1 - z_overtime), "Overtime_Review_2")
    
    # Constraint 4: Senior batch fee trigger
    # If A > threshold, then z_senior = 1
    model.addConstr(A <= senior_batch_threshold + M_senior * z_senior, "Senior_Batch_1")
    # If z_senior = 0, then A <= threshold
    model.addConstr(A >= senior_batch_threshold + 1e-5 - M_senior * (1 - z_senior), "Senior_Batch_2")
    
    # Solve
    model.optimize()
    
    # Get results
    obj_val = model.objVal
    
    print(f"FINAL_OBJ_VALUE: {obj_val:.1f}")

if __name__ == "__main__":
    main()
