import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Get data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Parse table_1.csv
    proc_time = {}  # (equipment, product) -> hours per unit
    capacity = {}   # equipment -> available hours
    cost_rate = {}  # equipment -> cost per machine hour
    raw_cost = {}
    price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            if equip == 'Raw_Material_Cost':
                raw_cost = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            elif equip == 'Unit_Price':
                price = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            else:
                for prod, col in [('I', 'Product_I'), ('II', 'Product_II'), ('III', 'Product_III')]:
                    val = row[col].strip()
                    if val != '-':
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row['Effective_Machine_Hours'])
                cost_rate[equip] = float(row['Processing_Cost_per_Machine_Hour'])
    
    # Parse setup_costs.csv
    setup_cost = {}
    with open(os.path.join(data_dir, 'setup_costs.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            setup_cost[equip] = float(row['Fixed_Setup_Cost'])
    
    # Equipment assignments
    stage_A_equip = {'I': ['A1', 'A2'], 'II': ['A1', 'A2'], 'III': ['A2']}
    stage_B_equip = {'I': ['B1', 'B2', 'B3'], 'II': ['B1'], 'III': ['B2']}
    
    # Create model
    model = gp.Model("Factory_Production_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[(equip, prod)] = units of product processed on equipment
    x = {}
    for prod in ['I', 'II', 'III']:
        for equip in stage_A_equip[prod]:
            x[(equip, prod)] = model.addVar(lb=0, name=f"x_{equip}_{prod}")
        for equip in stage_B_equip[prod]:
            x[(equip, prod)] = model.addVar(lb=0, name=f"x_{equip}_{prod}")
    
    # Binary variables for equipment usage (setup)
    z = {}
    for equip in ['A1', 'A2', 'B1', 'B2', 'B3']:
        z[equip] = model.addVar(vtype=GRB.BINARY, name=f"z_{equip}")
    
    # Binary variable for joint calibration
    w = model.addVar(vtype=GRB.BINARY, name="joint_calibration")
    
    # Total production of each product
    total = {}
    for prod in ['I', 'II', 'III']:
        total[prod] = gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod])
    
    # Flow conservation: stage A total == stage B total for each product
    for prod in ['I', 'II', 'III']:
        model.addConstr(
            gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod]) == 
            gp.quicksum(x[(e, prod)] for e in stage_B_equip[prod]),
            name=f"flow_{prod}"
        )
    
    # Capacity constraints
    for equip in ['A1', 'A2', 'B1', 'B2', 'B3']:
        relevant = [(equip, prod) for prod in ['I', 'II', 'III'] if (equip, prod) in x]
        if relevant:
            model.addConstr(
                gp.quicksum(proc_time[(equip, prod)] * x[(equip, prod)] for equip2, prod in relevant) <= capacity[equip],
                name=f"capacity_{equip}"
            )
    
    # Setup cost constraints: if any production on equipment, must pay setup cost
    bigM = 1e6
    for equip in ['A1', 'A2', 'B1', 'B2', 'B3']:
        relevant = [(equip, prod) for prod in ['I', 'II', 'III'] if (equip, prod) in x]
        if relevant:
            # Production on equipment implies setup
            model.addConstr(
                gp.quicksum(x[(equip, prod)] for prod in ['I', 'II', 'III'] if (equip, prod) in x) <= bigM * z[equip],
                name=f"setup_{equip}"
            )
            # If setup is 0, no production
            model.addConstr(
                gp.quicksum(x[(equip, prod)] for prod in ['I', 'II', 'III'] if (equip, prod) in x) >= 0,
                name=f"setup_lower_{equip}"
            )
    
    # Joint calibration constraint: w = 1 if both A2 and B2 are active
    model.addConstr(w >= z['A2'] + z['B2'] - 1, name="joint_calibration_on")
    model.addConstr(w <= z['A2'], name="joint_calibration_a2")
    model.addConstr(w <= z['B2'], name="joint_calibration_b2")
    
    # Objective: profit = revenue - raw material - processing cost - setup costs - joint calibration fee
    revenue = gp.quicksum(price[p] * total[p] for p in ['I', 'II', 'III'])
    raw_mat = gp.quicksum(raw_cost[p] * total[p] for p in ['I', 'II', 'III'])
    proc_cost = gp.quicksum(cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x)
    setup_costs = gp.quicksum(setup_cost[e] * z[e] for e in ['A1', 'A2', 'B1', 'B2', 'B3'])
    joint_fee = 100 * w
    
    model.setObjective(revenue - raw_mat - proc_cost - setup_costs - joint_fee, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    # Print results
    print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")

if __name__ == "__main__":
    main()
