import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    parts = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
    
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    return parts, params

def fuel_per_heavy_bomb(distance, params):
    eff_heavy = params['fuel_efficiency_heavy_bomb']
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    return distance / eff_heavy + distance / eff_empty + takeoff_landing

def fuel_per_light_bomb(distance, params):
    eff_light = params['fuel_efficiency_light_bomb']
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    return distance / eff_light + distance / eff_empty + takeoff_landing

def main():
    parts, params = load_data()
    
    max_heavy = int(params['max_heavy_bombs'])
    max_light = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts = int(params['min_parts_destroyed'])
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    sortie_overhead_A = params['sortie_fuel_overhead_A']
    sortie_overhead_B = params['sortie_fuel_overhead_B']
    prob_A = params['scenario_prob_A']
    prob_B = params['scenario_prob_B']
    n = len(parts)
    
    # Precompute fuel per bomb for each part
    fuel_h = [fuel_per_heavy_bomb(p['distance'], params) for p in parts]
    fuel_l = [fuel_per_light_bomb(p['distance'], params) for p in parts]
    
    # Create model
    model = gp.Model("BombAllocationRobust")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of heavy and light bombs per part
    xh = model.addVars(n, lb=0, ub=max_heavy, vtype=GRB.INTEGER, name="heavy")
    xl = model.addVars(n, lb=0, ub=max_light, vtype=GRB.INTEGER, name="light")
    
    # Total bombs used
    total_heavy = gp.quicksum(xh[i] for i in range(n))
    total_light = gp.quicksum(xl[i] for i in range(n))
    total_sorties = total_heavy + total_light
    
    # Fuel constraints for both scenarios
    fuel_used_A = gp.quicksum(xh[i] * (fuel_h[i] + sortie_overhead_A) + xl[i] * (fuel_l[i] + sortie_overhead_A) for i in range(n))
    fuel_used_B = gp.quicksum(xh[i] * (fuel_h[i] + sortie_overhead_B) + xl[i] * (fuel_l[i] + sortie_overhead_B) for i in range(n))
    
    model.addConstr(total_heavy <= max_heavy, "heavy_limit")
    model.addConstr(total_light <= max_light, "light_limit")
    model.addConstr(total_sorties <= max_sorties_A, "sorties_A")
    model.addConstr(total_sorties <= max_sorties_B, "sorties_B")
    model.addConstr(fuel_used_A <= fuel_limit, "fuel_A")
    model.addConstr(fuel_used_B <= fuel_limit, "fuel_B")
    
    # Objective: maximize expected probability of at least min_parts destroyed
    # We need to compute P(at least k parts destroyed) for a given allocation
    # This is a nonlinear function, so we use piecewise-linear approximation or reformulation
    # Since probabilities are small, we can use the fact that log(1-p) is concave
    # We'll use a linearization approach with auxiliary variables for log-probabilities
    
    # For each part, probability of destruction = 1 - (1-p_h)^xh * (1-p_l)^xl
    # We want to maximize expected probability of at least k successes
    # This is a complex nonlinear objective; we'll use a DP-based approach with binary variables
    # for each possible number of bombs per part (limited range)
    
    # Since the search space is small (max 28 heavy, 12 light, 4 parts), we can enumerate
    # all feasible allocations and evaluate the objective exactly
    # This is more reliable than trying to linearize the probability function
    
    # Let's use the heuristic search approach but with the new constraints
    best_obj = 0.0
    best_alloc = None
    
    def prob_destroy_part(x_heavy, x_light, p_heavy, p_light):
        return 1.0 - (1.0 - p_heavy) ** x_heavy * (1.0 - p_light) ** x_light
    
    def prob_at_least_k(probs, k):
        dp = [0.0] * (n + 1)
        dp[0] = 1.0
        for i in range(n):
            new_dp = [0.0] * (n + 1)
            for j in range(i + 2):
                new_dp[j] += dp[j] * (1.0 - probs[i])
                if j > 0:
                    new_dp[j] += dp[j - 1] * probs[i]
            dp = new_dp
        return sum(dp[j] for j in range(k, n + 1))
    
    def evaluate(candidate):
        probs = [
            prob_destroy_part(candidate[i][0], candidate[i][1], parts[i]['p_heavy'], parts[i]['p_light'])
            for i in range(n)
        ]
        return prob_at_least_k(probs, min_parts)
    
    # Search over all feasible allocations
    alloc = []
    
    def search(idx, remaining_heavy, remaining_light, remaining_sorties, remaining_fuel_A, remaining_fuel_B):
        nonlocal best_obj, best_alloc
        if idx == n:
            obj = evaluate(alloc)
            if obj > best_obj:
                best_obj = obj
                best_alloc = list(alloc)
            return
        
        # Upper bounds for this part
        max_h = min(remaining_heavy, remaining_sorties)
        max_l = min(remaining_light, remaining_sorties)
        
        for xh_val in range(max_h + 1):
            fuel_h_A = xh_val * (fuel_h[idx] + sortie_overhead_A)
            fuel_h_B = xh_val * (fuel_h[idx] + sortie_overhead_B)
            if fuel_h_A > remaining_fuel_A or fuel_h_B > remaining_fuel_B:
                break
            for xl_val in range(max_l + 1):
                if xh_val + xl_val > remaining_sorties:
                    break
                fuel_A = fuel_h_A + xl_val * (fuel_l[idx] + sortie_overhead_A)
                fuel_B = fuel_h_B + xl_val * (fuel_l[idx] + sortie_overhead_B)
                if fuel_A > remaining_fuel_A or fuel_B > remaining_fuel_B:
                    break
                alloc.append((xh_val, xl_val))
                search(
                    idx + 1,
                    remaining_heavy - xh_val,
                    remaining_light - xl_val,
                    remaining_sorties - (xh_val + xl_val),
                    remaining_fuel_A - fuel_A,
                    remaining_fuel_B - fuel_B,
                )
                alloc.pop()
    
    # The limiting sortie count is min(max_sorties_A, max_sorties_B) = 10
    max_sorties = min(max_sorties_A, max_sorties_B)
    
    search(0, max_heavy, max_light, max_sorties, fuel_limit, fuel_limit)
    
    if best_alloc is not None:
        total_heavy_used = sum(item[0] for item in best_alloc)
        total_light_used = sum(item[1] for item in best_alloc)
        total_sorties_used = total_heavy_used + total_light_used
        fuel_A = sum(best_alloc[i][0] * (fuel_h[i] + sortie_overhead_A) + best_alloc[i][1] * (fuel_l[i] + sortie_overhead_A) for i in range(n))
        fuel_B = sum(best_alloc[i][0] * (fuel_h[i] + sortie_overhead_B) + best_alloc[i][1] * (fuel_l[i] + sortie_overhead_B) for i in range(n))
        
        # The objective is the expected probability (scenario-weighted)
        # Since the plan is feasible in both scenarios, the objective is just the probability
        # of mission success (same in both scenarios since allocation is fixed)
        obj_value = best_obj  # This is the probability of success
        
        print(f"Best allocation: {best_alloc}")
        print(f"Total heavy bombs: {total_heavy_used}")
        print(f"Total light bombs: {total_light_used}")
        print(f"Total sorties: {total_sorties_used}")
        print(f"Fuel used (scenario A): {fuel_A:.2f}")
        print(f"Fuel used (scenario B): {fuel_B:.2f}")
        print(f"Probability of mission success: {obj_value:.6f}")
        print(f"FINAL_OBJ_VALUE: {obj_value:.6f}")
    else:
        print("No feasible solution found")
        print("FINAL_OBJ_VALUE: 0.0")

if __name__ == '__main__':
    main()
