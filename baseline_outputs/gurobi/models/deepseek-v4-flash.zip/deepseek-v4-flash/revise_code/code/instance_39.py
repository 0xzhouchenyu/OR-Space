import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters from CSV
script_dir = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(script_dir, "data", "general_parameters.csv")

params = {}
with open(data_path, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract all parameters
motorcycle_pollution = params['motorcycle_pollution']
small_truck_pollution = params['small_truck_pollution']
large_truck_pollution = params['large_truck_pollution']
max_motorcycle_trips = int(params['max_motorcycle_trips'])
motorcycle_capacity = params['motorcycle_capacity']
small_truck_capacity = params['small_truck_capacity']
large_truck_capacity = params['large_truck_capacity']
max_total_trips = int(params['max_total_trips'])
demand_peak = params['demand_peak_units']
demand_offpeak = params['demand_offpeak_units']
leasing_capacity = params['leasing_capacity']
leasing_pollution_per_unit = params['leasing_pollution_per_unit']
leasing_fixed_pollution = params['leasing_fixed_pollution']
max_leasing_fraction_peak = params['max_leasing_fraction_peak']
bigM_leasing = params['bigM_leasing']
epsilon = params['epsilon']

# Methods and their properties
methods = ['motorcycle', 'small_truck', 'large_truck']
pollution = {
    'motorcycle': motorcycle_pollution,
    'small_truck': small_truck_pollution,
    'large_truck': large_truck_pollution
}
capacity = {
    'motorcycle': motorcycle_capacity,
    'small_truck': small_truck_capacity,
    'large_truck': large_truck_capacity
}

# Periods
periods = ['peak', 'offpeak']
demand = {'peak': demand_peak, 'offpeak': demand_offpeak}

# Create model
model = gp.Model("Transport_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables: trips per method per period (integer, non-negative)
trips = {}
for m in methods:
    for p in periods:
        trips[m, p] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"trips_{m}_{p}")

# Leasing variables
leasing_peak = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="leasing_peak")
leasing_offpeak = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="leasing_offpeak")
leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")

# Binary variables for method selection (choose exactly 2 out of 3)
method_selected = {}
for m in methods:
    method_selected[m] = model.addVar(vtype=GRB.BINARY, name=f"method_selected_{m}")

# Objective: minimize total pollution
total_pollution = gp.quicksum(pollution[m] * trips[m, p] for m in methods for p in period)
total_pollution += leasing_pollution_per_unit * (leasing_peak + leasing_offpeak)
total_pollution += leasing_fixed_pollution * leasing_used
model.setObjective(total_pollution, GRB.MINIMIZE)

# Constraint: exactly 2 methods selected
model.addConstr(gp.quicksum(method_selected[m] for m in methods) == 2, "exactly_two_methods")

# Constraint: only selected methods can have trips
for m in methods:
    for p in periods:
        model.addConstr(trips[m, p] <= max_total_trips * method_selected[m], f"method_activation_{m}_{p}")

# Constraint: demand satisfaction per period
for p in periods:
    model.addConstr(
        gp.quicksum(capacity[m] * trips[m, p] for m in methods) + 
        (leasing_peak if p == 'peak' else leasing_offpeak) >= demand[p],
        f"demand_{p}"
    )

# Constraint: maximum total trips across both periods
model.addConstr(
    gp.quicksum(trips[m, p] for m in methods for p in periods) <= max_total_trips,
    "max_total_trips"
)

# Constraint: motorcycle trips limit (total across both periods)
model.addConstr(
    gp.quicksum(trips['motorcycle', p] for p in periods) <= max_motorcycle_trips,
    "max_motorcycle_trips"
)

# Constraint: leasing capacity (total across both periods)
model.addConstr(leasing_peak + leasing_offpeak <= leasing_capacity, "leasing_capacity")

# Constraint: leasing fraction in peak period
model.addConstr(leasing_peak <= max_leasing_fraction_peak * demand_peak, "max_leasing_fraction_peak")

# Constraint: leasing activation (if any leasing used, leasing_used must be 1)
model.addConstr(leasing_peak + leasing_offpeak <= bigM_leasing * leasing_used, "leasing_activation_upper")
model.addConstr(leasing_peak + leasing_offpeak >= epsilon * leasing_used, "leasing_activation_lower")

# Optimize
model.optimize()

# Get objective value
if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
else:
    obj_val = None

print(f"FINAL_OBJ_VALUE: {obj_val}")
