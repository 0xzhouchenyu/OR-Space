import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Extract parameters
    a = params['a']  # hours per furnace, method 1
    b = params['b']  # hours per furnace, method 2
    k = params['k']  # tons per furnace batch
    d = params['d']  # minimum production
    c_offpeak = params['c_offpeak']  # max off-peak time per furnace
    c_peak = params['c_peak']  # max peak time per furnace
    cap_offpeak = params['cap_offpeak']  # plant-wide max off-peak time
    cap_peak = params['cap_peak']  # plant-wide max peak time
    m_offpeak = params['m_offpeak']  # cost method 1 off-peak
    n_offpeak = params['n_offpeak']  # cost method 2 off-peak
    m_peak = params['m_peak']  # cost method 1 peak
    n_peak = params['n_peak']  # cost method 2 peak
    f_offpeak = params['f_offpeak']  # fixed activation cost off-peak
    f_peak = params['f_peak']  # fixed activation cost peak
    offpeak_cooldown_threshold = params['offpeak_cooldown_batch_threshold']
    offpeak_cooldown_fee = params['offpeak_cooldown_fee']
    
    # Create model
    model = gp.Model("SteelFurnace")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of batches for each furnace, method, and period
    # x_fmp = batches for furnace f, method m, period p
    # f = 1,2; m = 1,2; p = 0 (off-peak), 1 (peak)
    x = {}
    for f in [1, 2]:
        for m in [1, 2]:
            for p in [0, 1]:
                x[f, m, p] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{f}_{m}_{p}")
    
    # Binary variables for furnace activation in each period
    # y_fp = 1 if furnace f is used in period p
    y = {}
    for f in [1, 2]:
        for p in [0, 1]:
            y[f, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{f}_{p}")
    
    # Binary variables for cooldown penalty (1 if furnace f exceeds threshold in off-peak)
    z = {}
    for f in [1, 2]:
        z[f] = model.addVar(vtype=GRB.BINARY, name=f"z_{f}")
    
    # Continuous variable for excess off-peak batches beyond threshold
    excess = {}
    for f in [1, 2]:
        excess[f] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"excess_{f}")
    
    model.update()
    
    # Objective: minimize total cost
    # Fuel costs
    fuel_cost = gp.quicksum(
        m_offpeak * x[f, 1, 0] + n_offpeak * x[f, 2, 0] +
        m_peak * x[f, 1, 1] + n_peak * x[f, 2, 1]
        for f in [1, 2]
    )
    
    # Fixed activation costs
    activation_cost = gp.quicksum(
        f_offpeak * y[f, 0] + f_peak * y[f, 1]
        for f in [1, 2]
    )
    
    # Cooldown penalty costs
    cooldown_cost = gp.quicksum(
        offpeak_cooldown_fee * z[f]
        for f in [1, 2]
    )
    
    model.setObjective(fuel_cost + activation_cost + cooldown_cost, GRB.MINIMIZE)
    
    # Constraints
    
    # Time constraints per furnace per period
    for f in [1, 2]:
        # Off-peak time constraint
        model.addConstr(
            a * x[f, 1, 0] + b * x[f, 2, 0] <= c_offpeak * y[f, 0],
            f"Furnace{f}_OffPeak_Time"
        )
        # Peak time constraint
        model.addConstr(
            a * x[f, 1, 1] + b * x[f, 2, 1] <= c_peak * y[f, 1],
            f"Furnace{f}_Peak_Time"
        )
    
    # Plant-wide time constraints
    model.addConstr(
        gp.quicksum(a * x[f, 1, 0] + b * x[f, 2, 0] for f in [1, 2]) <= cap_offpeak,
        "Plant_OffPeak_Time"
    )
    model.addConstr(
        gp.quicksum(a * x[f, 1, 1] + b * x[f, 2, 1] for f in [1, 2]) <= cap_peak,
        "Plant_Peak_Time"
    )
    
    # Minimum production constraint
    model.addConstr(
        k * gp.quicksum(x[f, m, p] for f in [1, 2] for m in [1, 2] for p in [0, 1]) >= d,
        "MinProduction"
    )
    
    # Link activation variables to batch variables
    for f in [1, 2]:
        for p in [0, 1]:
            total_batches_fp = gp.quicksum(x[f, m, p] for m in [1, 2])
            # If any batches in period p, then y_fp must be 1
            model.addConstr(total_batches_fp <= 1000 * y[f, p], f"Activation_{f}_{p}")
    
    # Cooldown constraints: if off-peak batches > threshold, then z_f = 1
    for f in [1, 2]:
        offpeak_batches_f = gp.quicksum(x[f, m, 0] for m in [1, 2])
        # excess_f >= offpeak_batches_f - threshold
        model.addConstr(excess[f] >= offpeak_batches_f - offpeak_cooldown_threshold, f"Excess_{f}_1")
        # excess_f <= M * z_f (where M is large)
        model.addConstr(excess[f] <= 1000 * z[f], f"Excess_{f}_2")
        # z_f <= excess_f (if excess_f > 0, z_f must be 1; if excess_f = 0, z_f can be 0)
        model.addConstr(z[f] <= 1000 * excess[f], f"Excess_{f}_3")
    
    # Optimize
    model.optimize()
    
    # Print results
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
