import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        value = float(row["Value"].strip())
        params[name] = value

# Extract parameters
sell_price_table = params["sell_price_table"]
sell_price_chair = params["sell_price_chair"]
sell_price_bookshelf = params["sell_price_bookshelf"]

cost_table = params["manufacturing_cost_table"]
cost_chair = params["manufacturing_cost_chair"]
cost_bookshelf = params["manufacturing_cost_bookshelf"]

space_table = params["warehouse_space_table"]
space_chair = params["warehouse_space_chair"]
space_bookshelf = params["warehouse_space_bookshelf"]

max_warehouse = params["max_warehouse_space"]
min_tables = params["min_tables"]
min_bookshelves = params["min_bookshelves"]
max_total = params["max_total_items"]

labor_table = params["labor_hours_table"]
labor_chair = params["labor_hours_chair"]
labor_bookshelf = params["labor_hours_bookshelf"]

max_regular_labor = params["max_labor_hours_month_regular"]
max_rush_labor = params["max_labor_hours_month_rush"]
max_rush_items = params["max_rush_items_month"]

rush_bonus_table = params["rush_profit_bonus_table"]
rush_bonus_chair = params["rush_profit_bonus_chair"]
rush_bonus_bookshelf = params["rush_profit_bonus_bookshelf"]

# Base profit per item
profit_table = sell_price_table - cost_table
profit_chair = sell_price_chair - cost_chair
profit_bookshelf = sell_price_bookshelf - cost_bookshelf

# Create model
model = gp.Model("Furniture_Production_Rush")
model.setParam('OutputFlag', 0)

# Decision variables: regular and rush quantities
reg_tables = model.addVar(vtype=GRB.INTEGER, lb=0, name="reg_tables")
reg_chairs = model.addVar(vtype=GRB.INTEGER, lb=0, name="reg_chairs")
reg_bookshelves = model.addVar(vtype=GRB.INTEGER, lb=0, name="reg_bookshelves")

rush_tables = model.addVar(vtype=GRB.INTEGER, lb=0, name="rush_tables")
rush_chairs = model.addVar(vtype=GRB.INTEGER, lb=0, name="rush_chairs")
rush_bookshelves = model.addVar(vtype=GRB.INTEGER, lb=0, name="rush_bookshelves")

# Objective: maximize profit including rush bonuses
model.setObjective(
    profit_table * (reg_tables + rush_tables) + 
    profit_chair * (reg_chairs + rush_chairs) + 
    profit_bookshelf * (reg_bookshelves + rush_bookshelves) +
    rush_bonus_table * rush_tables +
    rush_bonus_chair * rush_chairs +
    rush_bonus_bookshelf * rush_bookshelves,
    GRB.MAXIMIZE
)

# Warehouse space constraint (all items use same space)
model.addConstr(
    space_table * (reg_tables + rush_tables) +
    space_chair * (reg_chairs + rush_chairs) +
    space_bookshelf * (reg_bookshelves + rush_bookshelves) <= max_warehouse,
    "Warehouse_Space"
)

# Minimum production requirements (total of regular + rush)
model.addConstr(reg_tables + rush_tables >= min_tables, "Min_Tables")
model.addConstr(reg_bookshelves + rush_bookshelves >= min_bookshelves, "Min_Bookshelves")

# Maximum total production
model.addConstr(
    reg_tables + reg_chairs + reg_bookshelves +
    rush_tables + rush_chairs + rush_bookshelves <= max_total,
    "Max_Total_Items"
)

# Regular labor constraint
model.addConstr(
    labor_table * reg_tables + labor_chair * reg_chairs + labor_bookshelf * reg_bookshelves <= max_regular_labor,
    "Regular_Labor"
)

# Rush labor constraint
model.addConstr(
    labor_table * rush_tables + labor_chair * rush_chairs + labor_bookshelf * rush_bookshelves <= max_rush_labor,
    "Rush_Labor"
)

# Rush capacity limit (total rush items)
model.addConstr(
    rush_tables + rush_chairs + rush_bookshelves <= max_rush_items,
    "Max_Rush_Items"
)

# Solve
model.optimize()

# Output result
obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
