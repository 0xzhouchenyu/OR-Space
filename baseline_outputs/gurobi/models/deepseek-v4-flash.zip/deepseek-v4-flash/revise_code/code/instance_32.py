import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    workshops = []
    capacities = {}
    rates = {}
    
    filepath = os.path.join(data_dir, 'table_1.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    # Read general_parameters.csv
    params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    
    # Extract parameters
    regular_day = {}
    regular_night = {}
    overtime_day = {}
    overtime_night = {}
    bigM = {}
    
    for w in workshops:
        w_lower = w.lower()
        regular_day[w] = params[f'regular_hours_limit_day_{w_lower}']
        regular_night[w] = params[f'regular_hours_limit_night_{w_lower}']
        overtime_day[w] = params[f'overtime_capacity_day_{w_lower}']
        overtime_night[w] = params[f'overtime_capacity_night_{w_lower}']
        bigM[w] = params[f'bigM_shift_{w_lower}']
    
    penalty_night = params['penalty_night_hour']
    penalty_overtime = params['penalty_overtime_hour']
    penalty_shortage = params['penalty_shortage_per_unit']
    z_target = params['z_target']
    
    components = [1, 2, 3]
    shifts = ['day', 'night']
    
    # Create model
    model = gp.Model("Maximize_Completed_Products")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: hours per workshop, shift, component
    x = {}
    for w in workshops:
        for s in shifts:
            for c in components:
                x[(w, s, c)] = model.addVar(lb=0, name=f"x_{w}_{s}_{c}")
    
    # Overtime hours per workshop and shift
    ot = {}
    for w in workshops:
        for s in shifts:
            ot[(w, s)] = model.addVar(lb=0, name=f"ot_{w}_{s}")
    
    # Binary indicators: whether workshop is active in a shift
    y = {}
    for w in workshops:
        for s in shifts:
            y[(w, s)] = model.addVar(vtype=GRB.BINARY, name=f"y_{w}_{s}")
    
    # z = number of completed products
    z = model.addVar(lb=0, name="z")
    
    # Shortfall below target
    shortage = model.addVar(lb=0, name="shortage")
    
    # Objective: maximize z minus penalties
    total_penalty = gp.quicksum(
        penalty_night * gp.quicksum(x[(w, 'night', c)] for c in components)
        for w in workshops
    ) + gp.quicksum(
        penalty_overtime * ot[(w, s)]
        for w in workshops for s in shifts
    ) + penalty_shortage * shortage
    
    model.setObjective(z - total_penalty, GRB.MAXIMIZE)
    
    # Regular hour constraints (day shift)
    for w in workshops:
        model.addConstr(
            gp.quicksum(x[(w, 'day', c)] for c in components) <= regular_day[w],
            f"RegularDay_{w}"
        )
    
    # Regular hour constraints (night shift)
    for w in workshops:
        model.addConstr(
            gp.quicksum(x[(w, 'night', c)] for c in components) <= regular_night[w],
            f"RegularNight_{w}"
        )
    
    # Overtime constraints
    for w in workshops:
        for s in shifts:
            model.addConstr(
                ot[(w, s)] <= (overtime_day[w] if s == 'day' else overtime_night[w]),
                f"OTCap_{w}_{s}"
            )
    
    # Total hours = regular + overtime for each shift
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x[(w, s, c)] for c in components) + ot[(w, s)] <= 
                (regular_day[w] + overtime_day[w] if s == 'day' else regular_night[w] + overtime_night[w]),
                f"TotalHours_{w}_{s}"
            )
    
    # Link active indicator to hours (big-M constraints)
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x[(w, s, c)] for c in components) + ot[(w, s)] <= bigM[w] * y[(w, s)],
                f"ActiveLink_{w}_{s}"
            )
    
    # At most 2 workshops active in each shift
    for s in shifts:
        model.addConstr(
            gp.quicksum(y[(w, s)] for w in workshops) <= 2,
            f"MaxActive_{s}"
        )
    
    # Component production constraints
    for c in components:
        total_production = gp.quicksum(
            rates[(w, c)] * (x[(w, s, c)] + ot[(w, s)] * (x[(w, s, c)] / (gp.quicksum(x[(w, s, cc)] for cc in components) + 1e-10) if False else 0)
            for w in workshops for s in shifts
        )
        # Actually, overtime hours also produce at same rate, so total hours = regular + overtime
        # We need to allocate overtime hours to components proportionally or as separate variables
        # Better approach: use total hours variable per workshop-shift-component
        pass
    
    # Revised approach: use total hours (regular + overtime) per workshop-shift-component
    # Redefine: x_total[(w,s,c)] = total hours (regular + overtime) for that workshop, shift, component
    # Then regular hours + overtime hours = sum over components of x_total
    # But we need to separate regular and overtime for penalty calculation
    # Let's use a cleaner formulation
    
    # Clear previous variables and rebuild
    model.remove(model.getVars())
    
    # Total hours per workshop, shift, component (includes both regular and overtime)
    x_total = {}
    for w in workshops:
        for s in shifts:
            for c in components:
                x_total[(w, s, c)] = model.addVar(lb=0, name=f"x_total_{w}_{s}_{c}")
    
    # Regular hours per workshop, shift, component
    x_reg = {}
    for w in workshops:
        for s in shifts:
            for c in components:
                x_reg[(w, s, c)] = model.addVar(lb=0, name=f"x_reg_{w}_{s}_{c}")
    
    # Overtime hours per workshop, shift, component
    x_ot = {}
    for w in workshops:
        for s in shifts:
            for c in components:
                x_ot[(w, s, c)] = model.addVar(lb=0, name=f"x_ot_{w}_{s}_{c}")
    
    # Binary indicators
    y = {}
    for w in workshops:
        for s in shifts:
            y[(w, s)] = model.addVar(vtype=GRB.BINARY, name=f"y_{w}_{s}")
    
    # z and shortage
    z = model.addVar(lb=0, name="z")
    shortage = model.addVar(lb=0, name="shortage")
    
    # Objective
    total_penalty = gp.quicksum(
        penalty_night * gp.quicksum(x_reg[(w, 'night', c)] for c in components)
        for w in workshops
    ) + gp.quicksum(
        penalty_overtime * gp.quicksum(x_ot[(w, s, c)] for c in components)
        for w in workshops for s in shifts
    ) + penalty_shortage * shortage
    
    model.setObjective(z - total_penalty, GRB.MAXIMIZE)
    
    # Link total = regular + overtime
    for w in workshops:
        for s in shifts:
            for c in components:
                model.addConstr(
                    x_total[(w, s, c)] == x_reg[(w, s, c)] + x_ot[(w, s, c)],
                    f"TotalRegOT_{w}_{s}_{c}"
                )
    
    # Regular hour limits per shift
    for w in workshops:
        for s in shifts:
            limit = regular_day[w] if s == 'day' else regular_night[w]
            model.addConstr(
                gp.quicksum(x_reg[(w, s, c)] for c in components) <= limit,
                f"RegLimit_{w}_{s}"
            )
    
    # Overtime limits per shift
    for w in workshops:
        for s in shifts:
            limit = overtime_day[w] if s == 'day' else overtime_night[w]
            model.addConstr(
                gp.quicksum(x_ot[(w, s, c)] for c in components) <= limit,
                f"OTLimit_{w}_{s}"
            )
    
    # Total hours per workshop-shift cannot exceed capacity (from table_1)
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x_total[(w, s, c)] for c in components) <= capacities[w],
                f"TotalCap_{w}_{s}"
            )
    
    # Link active indicator
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x_total[(w, s, c)] for c in components) <= bigM[w] * y[(w, s)],
                f"ActiveLink_{w}_{s}"
            )
    
    # At most 2 workshops active per shift
    for s in shifts:
        model.addConstr(
            gp.quicksum(y[(w, s)] for w in workshops) <= 2,
            f"MaxActive_{s}"
        )
    
    # Component production constraints
    for c in components:
        model.addConstr(
            z <= gp.quicksum(rates[(w, c)] * x_total[(w, s, c)] for w in workshops for s in shifts),
            f"Component_{c}"
        )
    
    # Shortfall constraint
    model.addConstr(z + shortage >= z_target, "Shortfall")
    
    # Solve
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val:.1f}")

if __name__ == "__main__":
    main()
