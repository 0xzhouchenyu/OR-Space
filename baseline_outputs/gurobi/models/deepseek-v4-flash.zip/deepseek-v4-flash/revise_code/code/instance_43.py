import os
import sys
import gurobipy as gp
from gurobipy import GRB
import csv

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
min_A = int(params['min_raw_material_A'])
min_B = int(params['min_raw_material_B'])
min_C = int(params['min_raw_material_C'])

cap_A_a = int(params['warehouse_A_truck_capacity_A'])
cap_A_b = int(params['warehouse_A_truck_capacity_B'])
cap_A_c = int(params['warehouse_A_truck_capacity_C'])
cost_A = int(params['warehouse_A_truck_cost'])

cap_B_a = int(params['warehouse_B_truck_capacity_A'])
cap_B_b = int(params['warehouse_B_truck_capacity_B'])
cap_B_c = int(params['warehouse_B_truck_capacity_C'])
cost_B = int(params['warehouse_B_truck_cost'])

fixed_A = int(params['warehouse_A_fixed_cost'])
fixed_B = int(params['warehouse_B_fixed_cost'])

overflow_threshold = int(params['warehouse_B_overflow_threshold_trucks'])
overflow_cost = int(params['warehouse_B_overflow_coordination_cost'])

dual_reconciliation_fee = int(params['dual_warehouse_reconciliation_fee'])

# Create model
model = gp.Model("MinFreightCost")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_A")
y = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_B")

# Binary variables for fixed costs
z_A = model.addVar(vtype=GRB.BINARY, name="use_warehouse_A")
z_B = model.addVar(vtype=GRB.BINARY, name="use_warehouse_B")

# Binary variable for overflow at warehouse B
z_overflow = model.addVar(vtype=GRB.BINARY, name="overflow_B")

# Binary variable for dual warehouse reconciliation
z_dual = model.addVar(vtype=GRB.BINARY, name="dual_warehouse")

# Objective: minimize total cost
total_cost = (cost_A * x + cost_B * y + 
              fixed_A * z_A + fixed_B * z_B + 
              overflow_cost * z_overflow + 
              dual_reconciliation_fee * z_dual)

model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints: meet minimum raw material requirements
model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# Fixed cost activation constraints
model.addConstr(x <= 10000 * z_A, "FixedCostA_activation")
model.addConstr(y <= 10000 * z_B, "FixedCostB_activation")

# Overflow constraint for warehouse B
model.addConstr(y <= overflow_threshold + 10000 * z_overflow, "Overflow_threshold")
model.addConstr(y >= overflow_threshold + 1 - 10000 * (1 - z_overflow), "Overflow_activation")

# Dual warehouse reconciliation
model.addConstr(z_dual >= z_A + z_B - 1, "Dual_warehouse_activation")
model.addConstr(z_dual <= z_A, "Dual_warehouse_upper_A")
model.addConstr(z_dual <= z_B, "Dual_warehouse_upper_B")

# Solve
model.optimize()

# Output results
print(f"FINAL_OBJ_VALUE: {model.objVal}")
