import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            params[row[0]] = float(row[1])
    
    T = int(params['planning_horizon_T'])
    energy_cost_v1 = params['energy_cost_v1']
    energy_cost_v2 = params['energy_cost_v2']
    energy_cost_v3 = params['energy_cost_v3']
    peak_mult = params['peak_energy_multiplier']
    peak_cap = params['peak_energy_cap']
    makespan_weight = params['makespan_weight']
    energy_weight = params['energy_weight']
    
    # Load processing times and round up
    batches = []
    processing_times = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        num_vats = len(header) - 1
        for row in reader:
            batch_id = int(row[0])
            times = [int(-(-float(row[j+1]) // 1)) for j in range(num_vats)]  # ceiling
            batches.append(batch_id)
            processing_times.append(times)
    
    return batches, processing_times, num_vats, T, energy_cost_v1, energy_cost_v2, energy_cost_v3, peak_mult, peak_cap, makespan_weight, energy_weight

def solve():
    (batches, processing_times, num_vats, T, 
     ec1, ec2, ec3, peak_mult, peak_cap, 
     makespan_weight, energy_weight) = load_data()
    
    n = len(batches)
    vats = [0, 1, 2]  # Vat 1, Vat 2, Vat 3
    periods = list(range(1, T+1))
    peak_periods = [6, 7, 8]
    
    # Energy cost per vat per period (base rate)
    base_cost = {0: ec1, 1: ec2, 2: ec3}
    
    model = gp.Model("FlowShopScheduling")
    model.setParam('OutputFlag', 0)
    
    # x[b, v, t] = 1 if batch b starts processing on vat v at time t
    x = {}
    for b in range(n):
        for v in vats:
            p = processing_times[b][v]
            for t in range(1, T - p + 2):
                x[b, v, t] = model.addVar(vtype=GRB.BINARY, name=f"x_{b}_{v}_{t}")
    
    # y[v, t] = 1 if vat v is active at time t
    y = {}
    for v in vats:
        for t in periods:
            y[v, t] = model.addVar(vtype=GRB.BINARY, name=f"y_{v}_{t}")
    
    # Makespan variable (completion time of last batch on Vat 3)
    C_max = model.addVar(vtype=GRB.INTEGER, lb=0, ub=T, name="C_max")
    
    # Each batch must start exactly once on each vat
    for b in range(n):
        for v in vats:
            p = processing_times[b][v]
            model.addConstr(
                gp.quicksum(x[b, v, t] for t in range(1, T - p + 2)) == 1,
                name=f"start_once_{b}_{v}"
            )
    
    # Vat capacity: at most one batch active per vat per period
    for v in vats:
        for t in periods:
            # Batches that cover period t
            active = []
            for b in range(n):
                p = processing_times[b][v]
                for s in range(max(1, t - p + 1), min(t, T - p + 1) + 1):
                    if s <= T - p + 1:
                        active.append(x[b, v, s])
            model.addConstr(
                gp.quicksum(active) <= 1,
                name=f"vat_capacity_{v}_{t}"
            )
    
    # Link y[v,t] to x: y[v,t] = 1 if any batch is active on vat v at time t
    for v in vats:
        for t in periods:
            active = []
            for b in range(n):
                p = processing_times[b][v]
                for s in range(max(1, t - p + 1), min(t, T - p + 1) + 1):
                    if s <= T - p + 1:
                        active.append(x[b, v, s])
            model.addConstr(
                y[v, t] >= gp.quicksum(active),
                name=f"link_y_{v}_{t}"
            )
            model.addConstr(
                y[v, t] <= gp.quicksum(active),
                name=f"link_y_ub_{v}_{t}"
            )
    
    # Flow constraints: batch b on vat v+1 must start after or at the same period 
    # as it finishes on vat v (handoff convention: same period allowed)
    for b in range(n):
        for v in range(num_vats - 1):
            p_curr = processing_times[b][v]
            for t_curr in range(1, T - p_curr + 2):
                for t_next in range(1, t_curr + p_curr):
                    model.addConstr(
                        x[b, v, t_curr] + x[b, v+1, t_next] <= 1,
                        name=f"flow_{b}_{v}_{t_curr}_{t_next}"
                    )
    
    # Maintenance on Vat 2: no activity in periods 4 and 5
    for t in [4, 5]:
        model.addConstr(y[1, t] == 0, name=f"maintenance_{t}")
    
    # Makespan definition: C_max >= completion time of each batch on Vat 3
    for b in range(n):
        p3 = processing_times[b][2]
        for t in range(1, T - p3 + 2):
            model.addConstr(
                C_max >= t + p3 - 1 - T * (1 - x[b, 2, t]),
                name=f"makespan_{b}_{t}"
            )
    
    # Energy cost calculation
    energy_cost_expr = 0
    for v in vats:
        for t in periods:
            cost = base_cost[v]
            if t in peak_periods:
                cost *= peak_mult
            energy_cost_expr += cost * y[v, t]
    
    # Peak energy cap
    peak_usage = gp.quicksum(
        base_cost[v] * peak_mult * y[v, t] 
        for v in vats 
        for t in peak_periods
    )
    model.addConstr(peak_usage <= peak_cap, name="peak_cap")
    
    # Objective
    model.setObjective(
        makespan_weight * C_max + energy_weight * energy_cost_expr,
        GRB.MINIMIZE
    )
    
    model.optimize()
    
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == '__main__':
    solve()
