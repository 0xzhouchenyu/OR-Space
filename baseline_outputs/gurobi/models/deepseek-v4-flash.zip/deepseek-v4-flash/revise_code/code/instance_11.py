import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    # Read CSVs
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    # Parse Table 1
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]
    
    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    insp_a_orig = float(row_a['Inspection_hours_per_unit'])
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])
    
    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    insp_b_orig = float(row_b['Inspection_hours_per_unit'])
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])
    
    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp_orig = float(row_cap['Inspection_hours_per_unit'])
    
    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])
    cost_asm = float(row_cost['Assembly_hours_per_unit'])
    cost_insp_orig = float(row_cost['Inspection_hours_per_unit'])
    
    # Parse Parameters
    params_dict = {}
    for _, row in df_params.iterrows():
        params_dict[row['Parameter_Name']] = float(row['Value'])
    
    min_profit = params_dict['min_weekly_profit']
    min_a = params_dict['min_type_a_production']
    insp_a_M = params_dict['insp_a_M']
    insp_b_M = params_dict['insp_b_M']
    insp_a_E = params_dict['insp_a_E']
    insp_b_E = params_dict['insp_b_E']
    cap_ext = params_dict['cap_ext']
    cost_insp_M = params_dict['cost_insp_M']
    cost_insp_E = params_dict['cost_insp_E']
    cost_ext = params_dict['cost_ext']
    mode_fee_M = params_dict['mode_fee_M']
    mode_fee_E = params_dict['mode_fee_E']
    risk_penalty_M = params_dict['risk_penalty_M']
    cost_insp_weight = params_dict['cost_insp_weight']
    planning_horizon_weeks = int(params_dict['planning_horizon_weeks'])
    idle_tolerance = params_dict['idle_tolerance']
    
    weeks = range(planning_horizon_weeks)
    
    # Create model for first stage: minimize weighted idle time + risk penalty
    model1 = gp.Model("Stage1_Min_Idle_Risk")
    model1.setParam('OutputFlag', 0)
    
    # Decision variables
    x_A = {}
    x_B = {}
    y_M = {}
    y_E = {}
    insp_hours_internal = {}
    ext_hours = {}
    
    for w in weeks:
        x_A[w] = model1.addVar(lb=min_a, vtype=GRB.INTEGER, name=f"x_A_{w}")
        x_B[w] = model1.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_B_{w}")
        y_M[w] = model1.addVar(vtype=GRB.BINARY, name=f"y_M_{w}")
        y_E[w] = model1.addVar(vtype=GRB.BINARY, name=f"y_E_{w}")
        insp_hours_internal[w] = model1.addVar(lb=0, name=f"insp_int_{w}")
        ext_hours[w] = model1.addVar(lb=0, name=f"ext_hours_{w}")
    
    # Constraints
    for w in weeks:
        # Exactly one inspection mode per week
        model1.addConstr(y_M[w] + y_E[w] == 1, name=f"mode_selection_{w}")
        
        # Manufacturing capacity
        model1.addConstr(mfg_a * x_A[w] + mfg_b * x_B[w] <= cap_mfg, name=f"mfg_cap_{w}")
        
        # Assembly capacity
        model1.addConstr(asm_a * x_A[w] + asm_b * x_B[w] <= cap_asm, name=f"asm_cap_{w}")
        
        # Inspection capacity - internal
        model1.addConstr(insp_hours_internal[w] <= cap_insp_orig, name=f"insp_int_cap_{w}")
        
        # External inspection capacity (only available under Enhanced)
        model1.addConstr(ext_hours[w] <= cap_ext * y_E[w], name=f"ext_cap_{w}")
        
        # Inspection hours definition
        model1.addConstr(
            insp_hours_internal[w] + ext_hours[w] == 
            (insp_a_M * y_M[w] + insp_a_E * y_E[w]) * x_A[w] + 
            (insp_b_M * y_M[w] + insp_b_E * y_E[w]) * x_B[w],
            name=f"insp_balance_{w}"
        )
        
        # Profit constraint per week
        cost_a = mfg_a * cost_mfg + asm_a * cost_asm + \
                 (insp_a_M * cost_insp_M * y_M[w] + insp_a_E * cost_insp_E * y_E[w]) + \
                 (insp_a_M * y_M[w] + insp_a_E * y_E[w]) * (cost_ext * ext_hours[w] / (x_A[w] + 1e-10)) * 0  # handled via total cost
        
        # Better: compute profit directly
        weekly_revenue = price_a * x_A[w] + price_b * x_B[w]
        weekly_mfg_cost = cost_mfg * (mfg_a * x_A[w] + mfg_b * x_B[w])
        weekly_asm_cost = cost_asm * (asm_a * x_A[w] + asm_b * x_B[w])
        weekly_insp_int_cost = cost_insp_M * y_M[w] * (insp_a_M * x_A[w] + insp_b_M * x_B[w]) + \
                               cost_insp_E * y_E[w] * (insp_a_E * x_A[w] + insp_b_E * x_B[w])
        weekly_ext_cost = cost_ext * ext_hours[w]
        weekly_mode_fee = mode_fee_M * y_M[w] + mode_fee_E * y_E[w]
        weekly_risk = risk_penalty_M * y_M[w]
        
        weekly_profit = weekly_revenue - weekly_mfg_cost - weekly_asm_cost - \
                        weekly_insp_int_cost - weekly_ext_cost - weekly_mode_fee - weekly_risk
        
        model1.addConstr(weekly_profit >= min_profit, name=f"profit_{w}")
    
    # Objective 1: Minimize weighted idle time + risk penalty
    total_idle_cost = 0
    for w in weeks:
        idle_mfg = cap_mfg - (mfg_a * x_A[w] + mfg_b * x_B[w])
        idle_asm = cap_asm - (asm_a * x_A[w] + asm_b * x_B[w])
        idle_insp = cap_insp_orig - insp_hours_internal[w]
        
        total_idle_cost += cost_mfg * idle_mfg + cost_asm * idle_asm + cost_insp_weight * idle_insp
    
    total_risk = gp.quicksum(risk_penalty_M * y_M[w] for w in weeks)
    
    model1.setObjective(total_idle_cost + total_risk, GRB.MINIMIZE)
    model1.optimize()
    
    if model1.Status != GRB.OPTIMAL:
        print("FINAL_OBJ_VALUE: infeasible")
        return
    
    min_idle_risk_val = model1.ObjVal
    
    # Stage 2: Maximize total profit over two weeks with idle+risk constraint
    model2 = gp.Model("Stage2_Max_Profit")
    model2.setParam('OutputFlag', 0)
    
    # Recreate variables
    x_A2 = {}
    x_B2 = {}
    y_M2 = {}
    y_E2 = {}
    insp_hours_internal2 = {}
    ext_hours2 = {}
    
    for w in weeks:
        x_A2[w] = model2.addVar(lb=min_a, vtype=GRB.INTEGER, name=f"x_A2_{w}")
        x_B2[w] = model2.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_B2_{w}")
        y_M2[w] = model2.addVar(vtype=GRB.BINARY, name=f"y_M2_{w}")
        y_E2[w] = model2.addVar(vtype=GRB.BINARY, name=f"y_E2_{w}")
        insp_hours_internal2[w] = model2.addVar(lb=0, name=f"insp_int2_{w}")
        ext_hours2[w] = model2.addVar(lb=0, name=f"ext_hours2_{w}")
    
    # Constraints
    for w in weeks:
        model2.addConstr(y_M2[w] + y_E2[w] == 1, name=f"mode_selection2_{w}")
        model2.addConstr(mfg_a * x_A2[w] + mfg_b * x_B2[w] <= cap_mfg, name=f"mfg_cap2_{w}")
        model2.addConstr(asm_a * x_A2[w] + asm_b * x_B2[w] <= cap_asm, name=f"asm_cap2_{w}")
        model2.addConstr(insp_hours_internal2[w] <= cap_insp_orig, name=f"insp_int_cap2_{w}")
        model2.addConstr(ext_hours2[w] <= cap_ext * y_E2[w], name=f"ext_cap2_{w}")
        model2.addConstr(
            insp_hours_internal2[w] + ext_hours2[w] == 
            (insp_a_M * y_M2[w] + insp_a_E * y_E2[w]) * x_A2[w] + 
            (insp_b_M * y_M2[w] + insp_b_E * y_E2[w]) * x_B2[w],
            name=f"insp_balance2_{w}"
        )
        
        # Profit per week
        weekly_revenue2 = price_a * x_A2[w] + price_b * x_B2[w]
        weekly_mfg_cost2 = cost_mfg * (mfg_a * x_A2[w] + mfg_b * x_B2[w])
        weekly_asm_cost2 = cost_asm * (asm_a * x_A2[w] + asm_b * x_B2[w])
        weekly_insp_int_cost2 = cost_insp_M * y_M2[w] * (insp_a_M * x_A2[w] + insp_b_M * x_B2[w]) + \
                                cost_insp_E * y_E2[w] * (insp_a_E * x_A2[w] + insp_b_E * x_B2[w])
        weekly_ext_cost2 = cost_ext * ext_hours2[w]
        weekly_mode_fee2 = mode_fee_M * y_M2[w] + mode_fee_E * y_E2[w]
        weekly_risk2 = risk_penalty_M * y_M2[w]
        
        weekly_profit2 = weekly_revenue2 - weekly_mfg_cost2 - weekly_asm_cost2 - \
                         weekly_insp_int_cost2 - weekly_ext_cost2 - weekly_mode_fee2 - weekly_risk2
        
        model2.addConstr(weekly_profit2 >= min_profit, name=f"profit2_{w}")
    
    # Idle + risk constraint
    total_idle_cost2 = 0
    for w in weeks:
        idle_mfg2 = cap_mfg - (mfg_a * x_A2[w] + mfg_b * x_B2[w])
        idle_asm2 = cap_asm - (asm_a * x_A2[w] + asm_b * x_B2[w])
        idle_insp2 = cap_insp_orig - insp_hours_internal2[w]
        total_idle_cost2 += cost_mfg * idle_mfg2 + cost_asm * idle_asm2 + cost_insp_weight * idle_insp2
    
    total_risk2 = gp.quicksum(risk_penalty_M * y_M2[w] for w in weeks)
    model2.addConstr(total_idle_cost2 + total_risk2 <= min_idle_risk_val + idle_tolerance, name="idle_risk_bound")
    
    # Objective: maximize total two-week profit
    total_profit = 0
    for w in weeks:
        weekly_revenue2 = price_a * x_A2[w] + price_b * x_B2[w]
        weekly_mfg_cost2 = cost_mfg * (mfg_a * x_A2[w] + mfg_b * x_B2[w])
        weekly_asm_cost2 = cost_asm * (asm_a * x_A2[w] + asm_b * x_B2[w])
        weekly_insp_int_cost2 = cost_insp_M * y_M2[w] * (insp_a_M * x_A2[w] + insp_b_M * x_B2[w]) + \
                                cost_insp_E * y_E2[w] * (insp_a_E * x_A2[w] + insp_b_E * x_B2[w])
        weekly_ext_cost2 = cost_ext * ext_hours2[w]
        weekly_mode_fee2 = mode_fee_M * y_M2[w] + mode_fee_E * y_E2[w]
        weekly_risk2 = risk_penalty_M * y_M2[w]
        weekly_profit2 = weekly_revenue2 - weekly_mfg_cost2 - weekly_asm_cost2 - \
                         weekly_insp_int_cost2 - weekly_ext_cost2 - weekly_mode_fee2 - weekly_risk2
        total_profit += weekly_profit2
    
    model2.setObjective(total_profit, GRB.MAXIMIZE)
    model2.optimize()
    
    if model2.Status != GRB.OPTIMAL:
        print("FINAL_OBJ_VALUE: infeasible")
        return
    
    final_obj = model2.ObjVal
    print(f"FINAL_OBJ_VALUE: {round(final_obj, 4)}")

if __name__ == '__main__':
    solve()
