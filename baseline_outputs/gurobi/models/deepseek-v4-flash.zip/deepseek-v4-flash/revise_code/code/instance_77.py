import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load processing costs from table_1.csv
    cost = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p) for p in header[1:]]
        for row in reader:
            machine = row[0].strip()
            for j, p in enumerate(parts):
                cost[(machine, p)] = float(row[j + 1])

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    d = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    max_C = int(params['max_parts_on_C'])
    overtime_threshold = int(params['overtime_threshold'])
    overtime_penalty = params['overtime_penalty']

    machines = ['A', 'B', 'C']

    # Create model
    prob = gp.Model("MachineAssignment")
    prob.setParam('OutputFlag', 0)

    # Decision variables
    x = {}
    for m in machines:
        for p in parts:
            x[(m, p)] = prob.addVar(vtype=GRB.BINARY, name=f"x_{m}_{p}")

    y = {}
    for m in machines:
        y[m] = prob.addVar(vtype=GRB.BINARY, name=f"y_{m}")

    # Overtime variables: z[m] = 1 if machine m processes more than threshold parts
    z = {}
    for m in machines:
        z[m] = prob.addVar(vtype=GRB.BINARY, name=f"z_{m}")

    # Objective: minimize processing costs + setup costs + overtime penalties
    obj = gp.LinExpr()
    obj += gp.quicksum(cost[(m, p)] * x[(m, p)] for m in machines for p in parts)
    obj += gp.quicksum(d[m] * y[m] for m in machines)
    obj += gp.quicksum(overtime_penalty * z[m] for m in machines)
    prob.setObjective(obj, GRB.MINIMIZE)

    # Each part assigned to exactly one machine
    for p in parts:
        prob.addConstr(gp.quicksum(x[(m, p)] for m in machines) == 1, f"assign_{p}")

    # Linking y to x: if any part on machine m, y[m] = 1
    for m in machines:
        for p in parts:
            prob.addConstr(x[(m, p)] <= y[m], f"link_y_{m}_{p}")

    # Constraint 2: Parts 1 and 2 - exactly one of them on machine A
    prob.addConstr(x[('A', 1)] + x[('A', 2)] == 1, "constraint_2")

    # Constraint 3: Fixed assignments
    prob.addConstr(x[('A', 3)] == 1, "fixed_3")
    prob.addConstr(x[('B', 4)] == 1, "fixed_4")
    prob.addConstr(x[('C', 5)] == 1, "fixed_5")

    # Constraint 4: At most 3 parts on machine C
    prob.addConstr(gp.quicksum(x[('C', p)] for p in parts) <= max_C, "max_C")

    # Constraint 5: Overtime penalty logic
    # z[m] = 1 if number of parts on machine m > overtime_threshold
    # Use big-M formulation: sum(x) <= threshold + M * (1 - z)  and sum(x) >= threshold + 1 - M * z
    M = len(parts) + 1
    for m in machines:
        prob.addConstr(gp.quicksum(x[(m, p)] for p in parts) <= overtime_threshold + M * (1 - z[m]), 
                       f"overtime_upper_{m}")
        prob.addConstr(gp.quicksum(x[(m, p)] for p in parts) >= overtime_threshold + 1 - M * z[m], 
                       f"overtime_lower_{m}")

    # Solve
    prob.optimize()

    obj_val = prob.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == '__main__':
    main()
