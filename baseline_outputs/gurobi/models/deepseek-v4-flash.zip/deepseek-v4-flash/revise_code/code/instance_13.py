import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    profit_corn = params["profit_per_acre_corn"]
    profit_wheat = params["profit_per_acre_wheat"]
    profit_soybeans = params["profit_per_acre_soybeans"]
    profit_sorghum = params["profit_per_acre_sorghum"]
    total_area = params["total_farm_area"]
    corn_wheat_ratio = params["corn_wheat_ratio"]
    soybeans_sorghum_ratio = params["soybeans_sorghum_ratio"]
    wheat_sorghum_ratio = params["wheat_sorghum_ratio"]
    
    # Create model
    model = gp.Model("Farm_Optimization_Revised")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    corn = model.addVar(lb=0, name="corn")
    wheat = model.addVar(lb=0, name="wheat")
    soybeans = model.addVar(lb=0, name="soybeans")
    sorghum = model.addVar(lb=0, name="sorghum")
    
    # Binary variable for mutual exclusion: 1 = plant corn, 0 = plant soybeans
    y = model.addVar(vtype=GRB.BINARY, name="choose_corn")
    
    # Objective: maximize profit
    model.setObjective(
        profit_corn * corn + profit_wheat * wheat + profit_soybeans * soybeans + profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )
    
    # Constraints
    # Total area
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")
    
    # Corn >= 2 * wheat
    model.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio")
    
    # Soybeans >= 0.5 * sorghum
    model.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio")
    
    # Wheat = 3 * sorghum
    model.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_ratio")
    
    # Mutual exclusion: corn and soybeans cannot both be planted
    # If y=1, corn can be planted (soybeans=0); if y=0, soybeans can be planted (corn=0)
    # Use big-M constraints
    M = total_area  # sufficient upper bound
    model.addConstr(corn <= M * y, "corn_only_if_y")
    model.addConstr(soybeans <= M * (1 - y), "soybeans_only_if_not_y")
    
    # Minimum 20 acres of corn
    model.addConstr(corn >= 20, "min_corn")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
