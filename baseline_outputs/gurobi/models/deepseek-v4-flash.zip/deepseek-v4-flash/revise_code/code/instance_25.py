import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Get data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Extract parameters
    W = params['initial_investment']       # 100000
    r1 = params['return_rate_option_1']    # 0.7
    r2 = params['return_rate_option_2']    # 2.0
    T = int(params['planning_horizon'])    # 3
    min_reserve_y1 = params['min_reserve_year1']  # 10000
    min_reserve_y2 = params['min_reserve_year2']  # 15000
    max_option2_start = params['max_option2_start']  # 30000
    late_settle_rate = params['option2_year0_late_settlement_rate']  # 0.02
    
    # Create model
    model = gp.Model("Investment_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[t][i]: amount invested in option i at start of year t
    # i=1: one-year option, i=2: two-year option
    x0_1 = model.addVar(lb=0, name="x0_1")
    x0_2 = model.addVar(lb=0, ub=max_option2_start, name="x0_2")
    x1_1 = model.addVar(lb=0, name="x1_1")
    x1_2 = model.addVar(lb=0, ub=max_option2_start, name="x1_2")
    x2_1 = model.addVar(lb=0, name="x2_1")
    
    # Cash reserve variables (cash held at end of each year)
    cash_y1 = model.addVar(lb=0, name="cash_y1")
    cash_y2 = model.addVar(lb=0, name="cash_y2")
    cash_y3 = model.addVar(lb=0, name="cash_y3")
    
    # Year 0: initial investment allocation
    model.addConstr(x0_1 + x0_2 <= W, "year0_budget")
    
    # Year 1: money available = returns from x0_1 (matures at end of year 1)
    # x0_2 does NOT mature yet (2-year product)
    # Cash at end of year 1 = x0_1 * (1 + r1) - (x1_1 + x1_2)
    model.addConstr(x1_1 + x1_2 + cash_y1 == x0_1 * (1 + r1), "year1_balance")
    model.addConstr(cash_y1 >= min_reserve_y1, "year1_reserve")
    
    # Year 2: money available = returns from x1_1 (matures end of year 2)
    # x0_2 settles AFTER year-2 reinvestment cut-off, so it cannot be reinvested in year 2
    # It will be available at end of year 2 but with late settlement deduction
    # Cash at end of year 2 = x1_1*(1+r1) + cash_y1 + x0_2*(1+r2)*(1-late_settle_rate) - x2_1
    model.addConstr(x2_1 + cash_y2 == x1_1 * (1 + r1) + cash_y1 + 
                    x0_2 * (1 + r2) * (1 - late_settle_rate), "year2_balance")
    model.addConstr(cash_y2 >= min_reserve_y2, "year2_reserve")
    
    # Year 3 (end): total money = returns from x2_1 + returns from x1_2 + cash_y2
    # x1_2 matures at end of year 3 (2-year product started at year 1)
    model.addConstr(cash_y3 == x2_1 * (1 + r1) + x1_2 * (1 + r2) + cash_y2, "year3_balance")
    
    # Objective: maximize final cash at end of year 3
    model.setObjective(cash_y3, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
