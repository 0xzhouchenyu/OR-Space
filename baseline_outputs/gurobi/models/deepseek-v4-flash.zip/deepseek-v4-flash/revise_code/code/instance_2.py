import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

a1 = int(params['a1'])
a2 = int(params['a2'])
training_capacity = params['training_capacity_per_jet']
dual_use_efficiency = params['dual_use_training_efficiency']
intensity_cap = params['training_intensity_cap']
combat_min_year2 = int(params['combat_jet_min_year2'])
combat_weight = params['combat_weight']
training_weight = params['training_weight']

# Create model
model = gp.Model("Fighter_Jet_Readiness")
model.setParam('OutputFlag', 0)

# Decision variables
# Year 1
train1 = model.addVar(vtype=GRB.INTEGER, lb=0, name="train1")
combat1 = model.addVar(vtype=GRB.INTEGER, lb=0, name="combat1")
dual1 = model.addVar(vtype=GRB.INTEGER, lb=0, name="dual1")

# Year 2
train2 = model.addVar(vtype=GRB.INTEGER, lb=0, name="train2")
combat2 = model.addVar(vtype=GRB.INTEGER, lb=0, name="combat2")
dual2 = model.addVar(vtype=GRB.INTEGER, lb=0, name="dual2")

# Fleet availability constraints
model.addConstr(train1 + combat1 + dual1 == a1, "fleet_balance_y1")
model.addConstr(train2 + combat2 + dual2 == a1 + a2, "fleet_balance_y2")

# Training intensity cap (fraction of fleet in training or dual use)
model.addConstr(train1 + dual1 <= intensity_cap * a1, "intensity_cap_y1")
model.addConstr(train2 + dual2 <= intensity_cap * (a1 + a2), "intensity_cap_y2")

# Year 2 combat minimum
model.addConstr(combat2 >= combat_min_year2, "combat_min_y2")

# Training continuity: training jets in year 1 continue in year 2
# Training-only jets from year 1 must still be training in year 2
model.addConstr(train2 >= train1, "training_continuity")

# Dual-use jets from year 1 can be used in year 2 as dual or combat
# No explicit continuity constraint needed for dual-use (they can switch)

# Objective: maximize weighted sum of combat jets in year 2 and total pilots trained
# Pilots trained = training_capacity * (train1 + train2) + dual_use_efficiency * training_capacity * (dual1 + dual2)
total_pilots = training_capacity * (train1 + train2) + dual_use_efficiency * training_capacity * (dual1 + dual2)
objective = combat_weight * combat2 + training_weight * total_pilots

model.setObjective(objective, GRB.MAXIMIZE)

# Optimize
model.optimize()

# Get objective value
obj_val = model.objVal

print(f"FINAL_OBJ_VALUE: {obj_val}")
