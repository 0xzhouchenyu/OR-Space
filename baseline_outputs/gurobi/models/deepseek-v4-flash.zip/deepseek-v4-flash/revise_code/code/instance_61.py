import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read device data
devices = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            'name': row['Device'].strip(),
            'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
            'max_cap': float(row['Max_Processing_Capacity_Units'].strip())
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

required_units = params['required_units']
energy_budget_peak = params['energy_budget_peak']
energy_budget_offpeak = params['energy_budget_offpeak']
startup_budget = params['startup_budget']
startup_cost = params['startup_cost']
energy_price_peak = params['energy_price_peak']
energy_price_offpeak = params['energy_price_offpeak']

# Energy per unit per device
energy_per_unit = {
    'A': params['energy_per_unit_A'],
    'B': params['energy_per_unit_B'],
    'C': params['energy_per_unit_C'],
    'D': params['energy_per_unit_D']
}

# Startup energy per device
startup_energy = {
    'A': params['startup_energy_A'],
    'B': params['startup_energy_B'],
    'C': params['startup_energy_C'],
    'D': params['startup_energy_D']
}

# Create model
model = gp.Model("MinCostProduction")
model.setParam('OutputFlag', 0)

n = len(devices)
periods = ['peak', 'offpeak']

# Decision variables
# x[i,p]: units produced on device i in period p
x = {}
for i in range(n):
    for p in periods:
        x[i, p] = model.addVar(lb=0, ub=devices[i]['max_cap'], name=f"x_{devices[i]['name']}_{p}")

# y[i,p]: binary, 1 if device i is started in period p
y = {}
for i in range(n):
    for p in periods:
        y[i, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{devices[i]['name']}_{p}")

# Objective: minimize total cost
# Cost components:
# 1. Preparation completion costs (one-time per device if used in any period)
# 2. Unit production costs
# 3. Startup costs (monetary)
# 4. Energy costs (peak and off-peak)

# We need auxiliary binary variables for whether a device is used at all
z = {}
for i in range(n):
    z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{devices[i]['name']}")

# Objective expression
obj = gp.LinExpr()

# Preparation completion costs
for i in range(n):
    obj += devices[i]['prep_cost'] * z[i]

# Unit production costs
for i in range(n):
    for p in periods:
        obj += devices[i]['unit_cost'] * x[i, p]

# Startup costs
for i in range(n):
    for p in periods:
        obj += startup_cost * y[i, p]

# Energy costs
for i in range(n):
    obj += energy_price_peak * energy_per_unit[devices[i]['name']] * x[i, 'peak']
    obj += energy_price_offpeak * energy_per_unit[devices[i]['name']] * x[i, 'offpeak']

model.setObjective(obj, GRB.MINIMIZE)

# Constraints

# Total production must equal required units
model.addConstr(gp.quicksum(x[i, p] for i in range(n) for p in periods) == required_units, "TotalProduction")

# Capacity constraints per device (total across periods)
for i in range(n):
    model.addConstr(gp.quicksum(x[i, p] for p in periods) <= devices[i]['max_cap'], f"Cap_{devices[i]['name']}")

# Linking: if device is used in a period, it must be started in that period
for i in range(n):
    for p in periods:
        model.addConstr(x[i, p] <= devices[i]['max_cap'] * y[i, p], f"Link_{devices[i]['name']}_{p}")

# Linking: z[i] = 1 if device is used in any period
for i in range(n):
    model.addConstr(z[i] >= y[i, 'peak'], f"Z_peak_{devices[i]['name']}")
    model.addConstr(z[i] >= y[i, 'offpeak'], f"Z_offpeak_{devices[i]['name']}")
    model.addConstr(z[i] <= y[i, 'peak'] + y[i, 'offpeak'], f"Z_sum_{devices[i]['name']}")

# Energy budget constraints
# Peak energy: startup energy + production energy
peak_energy = gp.LinExpr()
for i in range(n):
    peak_energy += startup_energy[devices[i]['name']] * y[i, 'peak']
    peak_energy += energy_per_unit[devices[i]['name']] * x[i, 'peak']
model.addConstr(peak_energy <= energy_budget_peak, "EnergyBudgetPeak")

# Off-peak energy
offpeak_energy = gp.LinExpr()
for i in range(n):
    offpeak_energy += startup_energy[devices[i]['name']] * y[i, 'offpeak']
    offpeak_energy += energy_per_unit[devices[i]['name']] * x[i, 'offpeak']
model.addConstr(offpeak_energy <= energy_budget_offpeak, "EnergyBudgetOffpeak")

# Startup budget constraint
startup_total = gp.LinExpr()
for i in range(n):
    for p in periods:
        startup_total += startup_cost * y[i, p]
model.addConstr(startup_total <= startup_budget, "StartupBudget")

# Optimize
model.optimize()

# Print results
for i in range(n):
    for p in periods:
        if x[i, p].X > 0.5:
            print(f"Device {devices[i]['name']} period {p}: units={x[i, p].X:.1f}, started={int(y[i, p].X)}")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
