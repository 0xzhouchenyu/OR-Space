import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Get data directory path
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Extract parameters
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    base_a = params['base_fleet_type_a']
    base_b = params['base_fleet_type_b']
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    type_b_threshold = params['type_b_recovery_threshold']
    type_b_fee = params['type_b_recovery_fee']
    total_fleet_threshold = params['total_fleet_surge_threshold']
    total_fleet_fee = params['total_fleet_surge_fee']
    
    # Create model
    model = gp.Model("TruckRental")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeA_trucks")
    y = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeB_trucks")
    
    # Binary variables for thresholds
    z_b = model.addVar(vtype=GRB.BINARY, name="ExceedsTypeBThreshold")
    z_total = model.addVar(vtype=GRB.BINARY, name="ExceedsTotalFleetThreshold")
    
    # Auxiliary variables for penalty costs (excess over base fleet)
    excess_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="ExcessTypeA")
    excess_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="ExcessTypeB")
    
    # Big M values (large enough to not constrain)
    M1 = 1000
    M2 = 1000
    
    # Objective: minimize total cost
    # Base rental cost + penalty for exceeding base fleet + Type B recovery fee + total fleet surge fee
    model.setObjective(
        cost_a * x + cost_b * y + 
        penalty_a * excess_a + penalty_b * excess_b + 
        type_b_fee * z_b + 
        total_fleet_fee * z_total,
        GRB.MINIMIZE
    )
    
    # Cargo constraints
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedRequirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedRequirement")
    
    # Excess over base fleet constraints
    model.addConstr(excess_a >= x - base_a, "ExcessA_Def")
    model.addConstr(excess_b >= y - base_b, "ExcessB_Def")
    
    # Type B recovery threshold (binary indicator)
    model.addConstr(y - type_b_threshold <= M1 * z_b, "TypeB_Threshold_Upper")
    model.addConstr(type_b_threshold - y <= M1 * (1 - z_b), "TypeB_Threshold_Lower")
    # Ensure z_b = 1 when y > type_b_threshold
    model.addConstr(y - type_b_threshold >= 0.001 - M1 * (1 - z_b), "TypeB_Threshold_Activate")
    
    # Total fleet surge threshold (binary indicator)
    model.addConstr(x + y - total_fleet_threshold <= M2 * z_total, "TotalFleet_Threshold_Upper")
    model.addConstr(total_fleet_threshold - (x + y) <= M2 * (1 - z_total), "TotalFleet_Threshold_Lower")
    # Ensure z_total = 1 when x + y > total_fleet_threshold
    model.addConstr(x + y - total_fleet_threshold >= 0.001 - M2 * (1 - z_total), "TotalFleet_Threshold_Activate")
    
    # Optimize
    model.optimize()
    
    # Get results
    obj_val = model.objVal
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
