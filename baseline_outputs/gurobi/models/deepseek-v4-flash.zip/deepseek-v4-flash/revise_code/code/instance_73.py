import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Get data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    # Parse parameters
    max_children = int(params['max_children_trip'])
    min_children = int(params['min_children_trip'])
    max_distinct = int(params['max_distinct_children_trip'])
    total_budget = float(params['total_cost_budget'])
    bonus_saving = float(params['bonus_saving'])
    min_bob_days = int(params['min_bob_days'])
    
    # Read table_1 for children and costs
    children = []
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Child'].strip()
            cost = int(row['Cost'].strip())
            children.append(name)
            costs[name] = cost
    
    # Days
    days = [1, 2]
    
    # Create model
    model = gp.Model("FamilyTripTwoDay")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[child, day] = 1 if child attends on that day
    x = {}
    for child in children:
        for day in days:
            x[child, day] = model.addVar(vtype=GRB.BINARY, name=f"x_{child}_day{day}")
    
    # y[child] = 1 if child attends both days (bonus eligible)
    y = {}
    for child in children:
        y[child] = model.addVar(vtype=GRB.BINARY, name=f"y_{child}_both")
    
    # z[child] = 1 if child attends at least one day (for distinct count)
    z = {}
    for child in children:
        z[child] = model.addVar(vtype=GRB.BINARY, name=f"z_{child}_any")
    
    # Objective: minimize total cost - bonus savings
    total_cost = gp.quicksum(costs[child] * (x[child, 1] + x[child, 2]) for child in children)
    total_bonus = gp.quicksum(bonus_saving * y[child] for child in children)
    model.setObjective(total_cost - total_bonus, GRB.MINIMIZE)
    
    # Constraints for each day
    for day in days:
        # Min and max children per day
        model.addConstr(gp.quicksum(x[child, day] for child in children) >= min_children, f"MinChildren_day{day}")
        model.addConstr(gp.quicksum(x[child, day] for child in children) <= max_children, f"MaxChildren_day{day}")
        
        # Alice and Diana cannot be together on same day
        model.addConstr(x['Alice', day] + x['Diana', day] <= 1, f"AliceDiana_day{day}")
        
        # Bob and Charlie cannot be together on same day
        model.addConstr(x['Bob', day] + x['Charlie', day] <= 1, f"BobCharlie_day{day}")
        
        # Charlie requires Diana on same day
        model.addConstr(x['Charlie', day] <= x['Diana', day], f"CharlieRequiresDiana_day{day}")
        
        # Diana requires Ella on same day
        model.addConstr(x['Diana', day] <= x['Ella', day], f"DianaRequiresElla_day{day}")
    
    # Availability constraints
    # Charlie only on day 2
    model.addConstr(x['Charlie', 1] == 0, "CharlieOnlyDay2")
    # Diana only on day 2
    model.addConstr(x['Diana', 1] == 0, "DianaOnlyDay2")
    # Alice only on day 1
    model.addConstr(x['Alice', 2] == 0, "AliceOnlyDay1")
    
    # Bob must attend at least min_bob_days
    model.addConstr(x['Bob', 1] + x['Bob', 2] >= min_bob_days, "BobMinDays")
    
    # Link y[child] to both days attendance
    for child in children:
        model.addConstr(y[child] <= x[child, 1], f"BothDays1_{child}")
        model.addConstr(y[child] <= x[child, 2], f"BothDays2_{child}")
        model.addConstr(y[child] >= x[child, 1] + x[child, 2] - 1, f"BothDaysLink_{child}")
    
    # Link z[child] to at least one day attendance
    for child in children:
        model.addConstr(z[child] >= x[child, 1], f"AnyDay1_{child}")
        model.addConstr(z[child] >= x[child, 2], f"AnyDay2_{child}")
        model.addConstr(z[child] <= x[child, 1] + x[child, 2], f"AnyDayLink_{child}")
    
    # Distinct children constraint
    model.addConstr(gp.quicksum(z[child] for child in children) <= max_distinct, "MaxDistinct")
    
    # Total cost budget constraint (costs minus bonus)
    model.addConstr(total_cost - total_bonus <= total_budget, "TotalBudget")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
