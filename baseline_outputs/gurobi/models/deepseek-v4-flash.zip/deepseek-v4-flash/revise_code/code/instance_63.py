import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

produce = params['produce_to_transport']
horse_poll = params['horse_pollution_per_trip']
bike_poll = params['bicycle_pollution_per_trip']
cart_poll = params['handcart_pollution_per_trip']
max_poll = params['max_total_pollution']
min_horse = params['min_horse_trips']
horse_cap = params['horse_capacity_per_trip']
bike_cap = params['bicycle_capacity_per_trip']
cart_cap = params['handcart_capacity_per_trip']
min_produce = params['min_total_produce']
horse_cost = params['horse_cost_per_trip']
bike_cost = params['bicycle_cost_per_trip']
cart_cost = params['handcart_cost_per_trip']
horse_fixed = params['horse_fixed_cost']
bike_fixed = params['bicycle_fixed_cost']
cart_fixed = params['handcart_fixed_cost']
poll_penalty = params['pollution_penalty_per_unit']
permit_threshold = params['horse_pollution_permit_threshold']
permit_fee = params['horse_pollution_permit_fee']

# Model
model = gp.Model("FarmTransport")
model.setParam('OutputFlag', 0)

# Decision variables
x_horse = model.addVar(vtype=GRB.INTEGER, lb=0, name="horse_trips")
x_bike = model.addVar(vtype=GRB.INTEGER, lb=0, name="bike_trips")
x_cart = model.addVar(vtype=GRB.INTEGER, lb=0, name="cart_trips")

# Binary variables for mode selection
y_bike = model.addVar(vtype=GRB.BINARY, name="choose_bike")  # 1 if bicycle chosen, 0 if handcart
z_horse = model.addVar(vtype=GRB.BINARY, name="use_horse")   # 1 if horse is used

# Binary variable for permit fee
p = model.addVar(vtype=GRB.BINARY, name="permit_fee")  # 1 if pollution > threshold

# Big-M values
M1 = 10000
M2 = 10000

# Objective: minimize total cost (variable + fixed + pollution penalty + permit fee)
total_pollution = horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart

total_variable_cost = horse_cost * x_horse + bike_cost * x_bike + cart_cost * x_cart
total_fixed_cost = horse_fixed * z_horse + bike_fixed * y_bike + cart_fixed * (1 - y_bike)
total_penalty = poll_penalty * total_pollution
total_permit_fee = permit_fee * p

model.setObjective(total_variable_cost + total_fixed_cost + total_penalty + total_permit_fee, GRB.MINIMIZE)

# Constraints
# Must transport at least min_produce
model.addConstr(horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce)

# Pollution constraint
model.addConstr(total_pollution <= max_poll)

# Minimum horse trips
model.addConstr(x_horse >= min_horse)

# Either bicycle or handcart, not both
model.addConstr(x_bike <= M1 * y_bike)
model.addConstr(x_cart <= M1 * (1 - y_bike))

# Horse fixed cost activation
model.addConstr(x_horse <= M2 * z_horse)
model.addConstr(z_horse >= (1 / M2) * x_horse)  # ensure z_horse=1 if x_horse>0

# Permit fee logic: p=1 if total_pollution > permit_threshold
model.addConstr(total_pollution <= permit_threshold + M2 * p)
model.addConstr(total_pollution >= permit_threshold + 1 - M2 * (1 - p))

# Solve
model.optimize()

# Get results
obj_val = model.objVal

print(f"Horse trips: {int(x_horse.X)}")
print(f"Bicycle trips: {int(x_bike.X)}")
print(f"Handcart trips: {int(x_cart.X)}")
print(f"Choose bicycle: {int(y_bike.X)}")
print(f"Use horse: {int(z_horse.X)}")
print(f"Permit fee applied: {int(p.X)}")
total_produce = horse_cap * x_horse.X + bike_cap * x_bike.X + cart_cap * x_cart.X
print(f"Total produce: {total_produce}")
print(f"Total pollution: {total_pollution.getValue()}")
print(f"OBJECTIVE_VALUE: {obj_val}")
print(f"FINAL_OBJ_VALUE: {obj_val}")
