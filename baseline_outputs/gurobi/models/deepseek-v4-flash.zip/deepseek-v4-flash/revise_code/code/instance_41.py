import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "initial_capital":
            initial_capital = float(row["Value"].strip())

# Load liquidity policy
with open(os.path.join(data_dir, "liquidity_policy.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "min_year3_reserve":
            min_reserve = float(row["Value"].strip())
        elif row["Parameter_Name"].strip() == "reserve_shortfall_penalty":
            penalty = float(row["Value"].strip())

# Load project data
projects = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        projects.append(row)

# Create model
model = gp.Model("Investment_Maximization")
model.setParam('OutputFlag', 0)

# Decision variables
x1_1 = model.addVar(lb=0, name="x1_1")  # Project 1, Year 1
x1_2 = model.addVar(lb=0, name="x1_2")  # Project 1, Year 2
x1_3 = model.addVar(lb=0, name="x1_3")  # Project 1, Year 3
x2 = model.addVar(lb=0, ub=120000, name="x2")  # Project 2, Year 1
x3 = model.addVar(lb=0, ub=150000, name="x3")  # Project 3, Year 2
x4 = model.addVar(lb=0, ub=100000, name="x4")  # Project 4, Year 3

# Cash reserve at beginning of Year 3 (uninvested cash)
cash_reserve = model.addVar(lb=0, name="cash_reserve")

# Shortfall variable for penalty
shortfall = model.addVar(lb=0, name="shortfall")

# Year 1 budget constraint
model.addConstr(x1_1 + x2 <= initial_capital, "Year1_Budget")

# Year 2 budget constraint: available cash = proceeds from x1_1 (matured same year)
model.addConstr(x1_2 + x3 <= x1_1 * 1.20, "Year2_Budget")

# Year 3 budget constraint: available cash = proceeds from x1_2 + x2 + x3
# cash_reserve is the amount held back at beginning of Year 3
model.addConstr(x1_3 + x4 + cash_reserve <= x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60, "Year3_Budget")

# Shortfall definition: shortfall = max(0, min_reserve - cash_reserve)
model.addConstr(shortfall >= min_reserve - cash_reserve, "Shortfall_Def")

# Objective: maximize total end-of-Year-3 wealth minus penalty for shortfall
# End of Year 3 wealth = proceeds from x1_3 + x4 + cash_reserve (uninvested cash)
end_wealth = x1_3 * 1.20 + x4 * 1.40 + cash_reserve
model.setObjective(end_wealth - penalty * shortfall, GRB.MAXIMIZE)

# Optimize
model.optimize()

# Get objective value
obj_val = model.objVal

# Print results
print(f"OBJECTIVE_VALUE: {obj_val}")
