import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_1 = pd.read_csv(os.path.join(base_dir, 'data', 'table_1.csv'))
    table_2 = pd.read_csv(os.path.join(base_dir, 'data', 'table_2.csv'))
    params = pd.read_csv(os.path.join(base_dir, 'data', 'general_parameters.csv'))

    # Parse parameters
    param_dict = dict(zip(params['Parameter_Name'], params['Value']))
    min_contract_types = int(param_dict['min_contract_types'])
    max_contract_types = int(param_dict['max_contract_types'])
    mutual_exclusion = str(param_dict['mutual_exclusion_1_and_4']).strip().lower() == 'true'
    monthly_max_parallel = int(param_dict['monthly_max_parallel_contracts'])
    min_area_per_contract = int(param_dict['min_area_per_contract_units'])
    activation_fee = float(param_dict['activation_fee_per_contract'])
    onboarding_loss = float(param_dict['onboarding_loss_units'])
    expedited_fee = float(param_dict['expedited_onboarding_fee'])

    # Convert required area to units of 100 sqm
    demands = {int(row['Month']): float(row['Required_area_㎡']) / 100.0 for _, row in table_1.iterrows()}
    costs = {int(row['Contract_length_months']): float(row['Rental_fee_per_100㎡_yuan']) for _, row in table_2.iterrows()}

    months = list(demands.keys())
    max_month = max(months)
    contract_lengths = list(costs.keys())

    # Create model
    model = gp.Model("Warehouse_Rental")
    model.setParam('OutputFlag', 0)

    # Variables
    # x[i, j] = number of 100 sqm units rented starting at month i for j months
    x = {}
    for i in months:
        for j in contract_lengths:
            if i + j - 1 <= max_month:
                x[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}")

    # y[j] = 1 if contract length j is used, 0 otherwise
    y = {}
    for j in contract_lengths:
        y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")

    # z[i, j] = 1 if we use expedited onboarding for contract starting at i with length j
    z = {}
    for (i, j) in x:
        z[i, j] = model.addVar(vtype=GRB.BINARY, name=f"z_{i}_{j}")

    # w[i, j] = 1 if contract (i,j) is active (has at least min_area units)
    w = {}
    for (i, j) in x:
        w[i, j] = model.addVar(vtype=GRB.BINARY, name=f"w_{i}_{j}")

    # Objective: minimize total cost
    obj = gp.LinExpr()
    # Rental costs
    for (i, j) in x:
        obj += costs[j] * x[i, j]
    # Activation fees
    for (i, j) in x:
        obj += activation_fee * w[i, j]
    # Expedited onboarding fees
    for (i, j) in x:
        obj += expedited_fee * z[i, j]
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    # 1. Demand fulfillment for each month
    for m in months:
        lhs = gp.LinExpr()
        for (i, j) in x:
            if i <= m and i + j - 1 >= m:
                # In start month, apply onboarding loss unless expedited
                if i == m:
                    lhs += x[i, j] - onboarding_loss * w[i, j] + onboarding_loss * z[i, j]
                else:
                    lhs += x[i, j]
        model.addConstr(lhs == demands[m], f"demand_{m}")

    # 2. Link x to y (contract length usage)
    M = sum(demands.values()) * 2  # Big M
    for j in contract_lengths:
        lhs = gp.LinExpr()
        for i in months:
            if (i, j) in x:
                lhs += x[i, j]
        model.addConstr(lhs <= M * y[j], f"link_up_{j}")
        model.addConstr(lhs >= y[j], f"link_down_{j}")

    # 3. Contract types limits
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) >= min_contract_types, "min_types")
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) <= max_contract_types, "max_types")

    # 4. Mutual exclusion between 1-month and 4-month contracts
    if mutual_exclusion:
        if 1 in y and 4 in y:
            model.addConstr(y[1] + y[4] <= 1, "mutual_exclusion")

    # 5. Maximum active contracts per month
    for m in months:
        lhs = gp.LinExpr()
        for (i, j) in x:
            if i <= m and i + j - 1 >= m:
                lhs += w[i, j]
        model.addConstr(lhs <= monthly_max_parallel, f"max_parallel_{m}")

    # 6. Minimum area per active contract
    for (i, j) in x:
        model.addConstr(x[i, j] >= min_area_per_contract * w[i, j], f"min_area_{i}_{j}")
        model.addConstr(x[i, j] <= M * w[i, j], f"area_link_{i}_{j}")

    # 7. Expedited onboarding only if contract is active
    for (i, j) in x:
        model.addConstr(z[i, j] <= w[i, j], f"expedite_link_{i}_{j}")

    # Solve
    model.optimize()

    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
