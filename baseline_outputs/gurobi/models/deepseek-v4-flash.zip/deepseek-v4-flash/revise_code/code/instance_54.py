import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Get the directory where this script is located
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load table_1.csv
table1_path = os.path.join(data_dir, "table_1.csv")
products = []
equipment_names = []
processing_times = {}
effective_hours = {}
base_profit = {}

with open(table1_path, 'r') as f:
    reader = csv.reader(f)
    header = next(reader)
    products = header[1:-1]  # ['I', 'II', 'III']
    
    for row in reader:
        if row[0].startswith('Unit_Product_Profit'):
            for j, prod in enumerate(products):
                base_profit[prod] = float(row[j + 1])
        else:
            equip = row[0]
            equipment_names.append(equip)
            effective_hours[equip] = float(row[-1])
            for j, prod in enumerate(products):
                processing_times[(equip, prod)] = float(row[j + 1])

# Load general_parameters.csv
general_params_path = os.path.join(data_dir, "general_parameters.csv")
params = {}
with open(general_params_path, 'r') as f:
    reader = csv.reader(f)
    next(reader)  # skip header
    for row in reader:
        if row:
            params[row[0]] = float(row[1])

overtime_hours_cap = params['overtime_hours_cap']
overtime_cost_multiplier = params['overtime_cost_multiplier']
min_prod = {
    'I': params['min_prod_I'],
    'II': params['min_prod_II'],
    'III': params['min_prod_III']
}

# Create the optimization model
model = gp.Model("Factory_Production_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
x_reg = {}
x_ot = {}
for p in products:
    x_reg[p] = model.addVar(lb=0, name=f"x_reg_{p}")
    x_ot[p] = model.addVar(lb=0, name=f"x_ot_{p}")

# Objective: minimize total cost
total_cost = gp.LinExpr()
for p in products:
    total_cost += base_profit[p] * x_reg[p]  # regular time cost = base profit
    total_cost += overtime_cost_multiplier * base_profit[p] * x_ot[p]  # overtime cost
model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints: equipment capacity (regular + overtime share the same machine hours)
for equip in equipment_names:
    machine_usage = gp.LinExpr()
    for p in products:
        machine_usage += processing_times[(equip, p)] * (x_reg[p] + x_ot[p])
    model.addConstr(machine_usage <= effective_hours[equip], f"Equipment_{equip}_capacity")

# Constraint: plant-wide overtime hours cap
overtime_hours = gp.LinExpr()
for equip in equipment_names:
    for p in products:
        overtime_hours += processing_times[(equip, p)] * x_ot[p]
model.addConstr(overtime_hours <= overtime_hours_cap, "Overtime_hours_cap")

# Constraints: minimum production for each product
for p in products:
    model.addConstr(x_reg[p] + x_ot[p] >= min_prod[p], f"Min_prod_{p}")

# Solve the model
model.optimize()

# Get the objective value
obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
