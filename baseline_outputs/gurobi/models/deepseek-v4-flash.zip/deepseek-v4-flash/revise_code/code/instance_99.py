import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Add parent directory to path if needed
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def load_csv(filename):
    """Load a CSV file and return headers and rows."""
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    return rows

def load_general_parameters(filename='general_parameters.csv'):
    """Load general parameters into a dictionary."""
    rows = load_csv(filename)
    params = {}
    for row in rows:
        params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_reliability_table(filename='table_1.csv'):
    """Load reliability table. Returns dict: {num_spares: [r1, r2, r3]}"""
    rows = load_csv(filename)
    reliability = {}
    for row in rows:
        n_spares = int(row['Number_of_Spares'])
        r1 = float(row['Component_1_Reliability'])
        r2 = float(row['Component_2_Reliability'])
        r3 = float(row['Component_3_Reliability'])
        reliability[n_spares] = [r1, r2, r3]
    return reliability

def solve():
    # Load data
    params = load_general_parameters()
    reliability = load_reliability_table()
    
    # Extract parameters
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    
    # Scenario-specific budgets and weight limits
    budget_A = params['total_budget_scenario_A']
    budget_B = params['total_budget_scenario_B']
    weight_A = params['weight_limit_scenario_A']
    weight_B = params['weight_limit_scenario_B']
    
    # Number of components
    num_components = 3
    max_spares = 5  # from table: 0..5
    
    # Create model
    model = gp.Model("Spare_Parts_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i][n] = 1 if component i gets n spares, else 0
    x = {}
    for i in range(num_components):
        for n in range(max_spares + 1):
            x[i, n] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{n}")
    
    # Each component must have exactly one spare count
    for i in range(num_components):
        model.addConstr(gp.quicksum(x[i, n] for n in range(max_spares + 1)) == 1, 
                       name=f"one_spare_count_{i}")
    
    # Cost and weight expressions
    cost = gp.quicksum(unit_price[i] * n * x[i, n] 
                       for i in range(num_components) 
                       for n in range(max_spares + 1))
    weight = gp.quicksum(unit_weight[i] * n * x[i, n] 
                         for i in range(num_components) 
                         for n in range(max_spares + 1))
    
    # Budget constraints for both scenarios
    model.addConstr(cost <= budget_A, name="budget_A")
    model.addConstr(cost <= budget_B, name="budget_B")
    
    # Weight constraints for both scenarios
    model.addConstr(weight <= weight_A, name="weight_A")
    model.addConstr(weight <= weight_B, name="weight_B")
    
    # Objective: maximize expected reliability = 0.5 * SysRel_A + 0.5 * SysRel_B
    # Since SysRel_A = SysRel_B for same configuration, it's just SysRel
    # But we'll compute it properly
    obj_expr = 0
    for n1 in range(max_spares + 1):
        for n2 in range(max_spares + 1):
            for n3 in range(max_spares + 1):
                # Reliability for this combination
                r1 = reliability[n1][0]
                r2 = reliability[n2][1]
                r3 = reliability[n3][2]
                sys_rel = r1 * r2 * r3
                # Expected reliability (same for both scenarios)
                expected_rel = 0.5 * sys_rel + 0.5 * sys_rel  # = sys_rel
                # Product of binary variables for this combination
                combo_var = x[0, n1] * x[1, n2] * x[2, n3]
                obj_expr += expected_rel * combo_var
    
    # Set objective (maximize)
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    # Get results
    if model.status == GRB.OPTIMAL:
        # Extract solution
        s = [0, 0, 0]
        for i in range(num_components):
            for n in range(max_spares + 1):
                if x[i, n].X > 0.5:
                    s[i] = n
                    break
        
        # Calculate objective value
        r1 = reliability[s[0]][0]
        r2 = reliability[s[1]][1]
        r3 = reliability[s[2]][2]
        sys_rel = r1 * r2 * r3
        expected_rel = 0.5 * sys_rel + 0.5 * sys_rel  # = sys_rel
        
        total_cost = s[0]*unit_price[0] + s[1]*unit_price[1] + s[2]*unit_price[2]
        total_weight = s[0]*unit_weight[0] + s[1]*unit_weight[1] + s[2]*unit_weight[2]
        
        print(f"Optimal spare parts allocation: Component 1: {s[0]}, Component 2: {s[1]}, Component 3: {s[2]}")
        print(f"Total cost: {total_cost}")
        print(f"Total weight: {total_weight}")
        print(f"Component reliabilities: {r1}, {r2}, {r3}")
        print(f"System reliability (both scenarios): {sys_rel}")
        print(f"FINAL_OBJ_VALUE: {expected_rel}")
    else:
        print(f"Optimization failed with status: {model.status}")

if __name__ == '__main__':
    solve()
