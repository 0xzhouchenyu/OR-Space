import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
    
    # Read general_parameters.csv
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_storage = float(params['max_storage_capacity'])  # 200000 m³
    storage_cost_a = float(params['storage_cost_a'])      # 70 yuan/m³
    storage_cost_b = float(params['storage_cost_b'])      # 100 yuan/m³/quarter
    safety_inventory = float(params['safety_inventory_level_10k_m3'])  # 20 万m³
    terminal_value = float(params['terminal_inventory_value_per_10k_m3'])  # 455 万元/万m³
    over_penalty = float(params['over_purchase_penalty_cost_per_10k_m3'])  # 300 万元/万m³
    
    # Convert storage capacity to 万m³
    max_storage_wm3 = max_storage / 10000.0  # 20 万m³
    
    # Convert storage costs to 万元/万m³
    storage_cost_a_w = storage_cost_a * 10000.0 / 10000.0  # 70 万元/万m³
    storage_cost_b_w = storage_cost_b * 10000.0 / 10000.0  # 100 万元/万m³/quarter
    
    n = len(quarters)  # 4 quarters
    
    # Create model
    model = gp.Model("Timber_Profit_Maximization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables:
    # x[i][j] = amount purchased in quarter i and sold in quarter j (万m³)
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    # end_inv = inventory at end of autumn (after all sales in autumn)
    end_inv = model.addVar(lb=0, name="end_inv")
    
    # over_inv = inventory above safety level at end of autumn
    over_inv = model.addVar(lb=0, name="over_inv")
    
    model.update()
    
    # Objective: maximize profit
    # Revenue from sales + terminal value of end inventory - purchase costs - storage costs - over-purchase penalty
    profit_terms = []
    
    for i in range(n):
        for j in range(i, n):
            u = j - i  # quarters stored
            revenue = sale_price[quarters[j]]
            cost = purchase_price[quarters[i]]
            if u > 0:
                s_cost = storage_cost_a_w + storage_cost_b_w * u
            else:
                s_cost = 0
            profit_terms.append((revenue - cost - s_cost) * x[i, j])
    
    # Terminal value of end inventory
    profit_terms.append(terminal_value * end_inv)
    
    # Over-purchase penalty
    profit_terms.append(-over_penalty * over_inv)
    
    model.setObjective(gp.quicksum(profit_terms), GRB.MAXIMIZE)
    
    # Constraint 1: Sales constraints - total sold in quarter j <= max_sales[j]
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(j + 1)) <= max_sales[quarters[j]], 
                        f"sales_limit_{j}")
    
    # Constraint 2: Purchase constraints - total purchased in quarter i <= max_purchase[i]
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(i, n)) <= max_purchase[quarters[i]], 
                        f"purchase_limit_{i}")
    
    # Constraint 3: Storage constraints - at end of each quarter, stored timber <= max_storage
    for t in range(n - 1):
        stored = gp.quicksum(x[i, j] for i in range(t + 1) for j in range(t + 1, n))
        model.addConstr(stored <= max_storage_wm3, f"storage_limit_{t}")
    
    # Constraint 4: End inventory definition
    # End inventory = total purchased - total sold across all quarters
    total_purchased = gp.quicksum(x[i, j] for i in range(n) for j in range(i, n))
    total_sold = gp.quicksum(x[i, j] for i in range(n) for j in range(i, n))
    model.addConstr(end_inv == total_purchased - total_sold, "end_inv_def")
    
    # Constraint 5: Over-inventory definition
    model.addConstr(over_inv >= end_inv - safety_inventory, "over_inv_def")
    model.addConstr(over_inv >= 0, "over_inv_nonneg")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    
    # Print result
    print(f"FINAL_OBJ_VALUE: {obj_val:.1f}")

if __name__ == "__main__":
    main()
