import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value_str = row['Value'].strip()
        try:
            value = int(value_str)
        except ValueError:
            try:
                value = float(value_str)
            except ValueError:
                value = value_str
        params[name] = value

# Extract parameters
cost_A = params['cost_per_chair_A']
cost_B = params['cost_per_chair_B']
cost_C = params['cost_per_chair_C']
chairs_per_order_A = params['chairs_per_order_A']
chairs_per_order_B = params['chairs_per_order_B']
chairs_per_order_C = params['chairs_per_order_C']
min_total = params['min_total_chairs']
max_total = params['max_total_chairs']
min_chairs_B_if_A = params['min_chairs_B_if_A']
dependency_B_C = params['dependency_B_C']
fixed_fee_A_regular = params['fixed_fee_A_regular']
fixed_fee_A_express = params['fixed_fee_A_express']
fixed_fee_B_regular = params['fixed_fee_B_regular']
fixed_fee_B_express = params['fixed_fee_B_express']
fixed_fee_C_regular = params['fixed_fee_C_regular']
fixed_fee_C_express = params['fixed_fee_C_express']
weekly_order_budget = params['weekly_order_budget']

# Create model
model = gp.Model("FurnitureOrder")
model.setParam('OutputFlag', 0)

# Decision variables: number of orders from each manufacturer (integer, >= 0)
max_orders_A = max_total // chairs_per_order_A + 1
max_orders_B = max_total // chairs_per_order_B + 1
max_orders_C = max_total // chairs_per_order_C + 1

x_A = model.addVar(lb=0, ub=max_orders_A, vtype=GRB.INTEGER, name="orders_A")
x_B = model.addVar(lb=0, ub=max_orders_B, vtype=GRB.INTEGER, name="orders_B")
x_C = model.addVar(lb=0, ub=max_orders_C, vtype=GRB.INTEGER, name="orders_C")

# Binary variables for whether we use each manufacturer
y_A = model.addVar(vtype=GRB.BINARY, name="y_A")
y_B = model.addVar(vtype=GRB.BINARY, name="y_B")
y_C = model.addVar(vtype=GRB.BINARY, name="y_C")

# Binary variables for channel selection (regular=1, express=0 for each manufacturer)
# z_A = 1 means regular channel, 0 means express channel (if manufacturer used)
z_A = model.addVar(vtype=GRB.BINARY, name="z_A")
z_B = model.addVar(vtype=GRB.BINARY, name="z_B")
z_C = model.addVar(vtype=GRB.BINARY, name="z_C")

# Binary variables for whether a specific channel is active (for budget constraint)
# r_A = 1 if regular channel used for A, e_A = 1 if express channel used for A
r_A = model.addVar(vtype=GRB.BINARY, name="r_A")
e_A = model.addVar(vtype=GRB.BINARY, name="e_A")
r_B = model.addVar(vtype=GRB.BINARY, name="r_B")
e_B = model.addVar(vtype=GRB.BINARY, name="e_B")
r_C = model.addVar(vtype=GRB.BINARY, name="r_C")
e_C = model.addVar(vtype=GRB.BINARY, name="e_C")

# Total chairs from each manufacturer
chairs_A = chairs_per_order_A * x_A
chairs_B = chairs_per_order_B * x_B
chairs_C = chairs_per_order_C * x_C

# Objective: minimize total cost (variable cost + fixed fees)
variable_cost = cost_A * chairs_A + cost_B * chairs_B + cost_C * chairs_C
fixed_cost = (fixed_fee_A_regular * r_A + fixed_fee_A_express * e_A +
              fixed_fee_B_regular * r_B + fixed_fee_B_express * e_B +
              fixed_fee_C_regular * r_C + fixed_fee_C_express * e_C)
model.setObjective(variable_cost + fixed_cost, GRB.MINIMIZE)

# Constraint: total chairs between min and max
model.addConstr(chairs_A + chairs_B + chairs_C >= min_total, "MinChairs")
model.addConstr(chairs_A + chairs_B + chairs_C <= max_total, "MaxChairs")

# Big M for linking
M = max_total + 1

# Link y variables to x variables
model.addConstr(x_A <= M * y_A, "LinkA1")
model.addConstr(x_A >= y_A, "LinkA2")
model.addConstr(x_B <= M * y_B, "LinkB1")
model.addConstr(x_B >= y_B, "LinkB2")
model.addConstr(x_C <= M * y_C, "LinkC1")
model.addConstr(x_C >= y_C, "LinkC2")

# Dependency: if ordering from A, must order at least min_chairs_B_if_A chairs from B
model.addConstr(chairs_B >= min_chairs_B_if_A * y_A, "DepAB")

# Dependency: if ordering from B, must also order from C
model.addConstr(y_B <= y_C, "DepBC")

# Channel selection constraints: if manufacturer used, exactly one channel chosen
# For each manufacturer: r_i + e_i = y_i
model.addConstr(r_A + e_A == y_A, "ChannelA")
model.addConstr(r_B + e_B == y_B, "ChannelB")
model.addConstr(r_C + e_C == y_C, "ChannelC")

# Link z variables to channel selection (z_i = 1 means regular, 0 means express)
# r_i = y_i * z_i, e_i = y_i * (1 - z_i)
# Linearize: r_i <= y_i, r_i <= z_i, r_i >= y_i + z_i - 1
# e_i <= y_i, e_i <= 1 - z_i, e_i >= y_i - z_i
model.addConstr(r_A <= y_A)
model.addConstr(r_A <= z_A)
model.addConstr(r_A >= y_A + z_A - 1)
model.addConstr(e_A <= y_A)
model.addConstr(e_A <= 1 - z_A)
model.addConstr(e_A >= y_A - z_A)

model.addConstr(r_B <= y_B)
model.addConstr(r_B <= z_B)
model.addConstr(r_B >= y_B + z_B - 1)
model.addConstr(e_B <= y_B)
model.addConstr(e_B <= 1 - z_B)
model.addConstr(e_B >= y_B - z_B)

model.addConstr(r_C <= y_C)
model.addConstr(r_C <= z_C)
model.addConstr(r_C >= y_C + z_C - 1)
model.addConstr(e_C <= y_C)
model.addConstr(e_C <= 1 - z_C)
model.addConstr(e_C >= y_C - z_C)

# Weekly order budget: maximum number of active manufacturer-mode combinations
model.addConstr(r_A + e_A + r_B + e_B + r_C + e_C <= weekly_order_budget, "Budget")

# Optimize
model.optimize()

# Get results
obj_val = model.objVal

print(f"FINAL_OBJ_VALUE: {obj_val}")
