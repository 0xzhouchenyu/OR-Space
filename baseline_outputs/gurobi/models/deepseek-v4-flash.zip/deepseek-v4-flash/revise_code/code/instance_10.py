import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_coverage_data(data_dir):
    """Load the coverage data from table_1.csv."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    
    return areas, coverage

def load_general_parameters(data_dir):
    """Load general parameters from general_parameters.csv."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    return params

def main():
    # Get data directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load data
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    # Parse parameters
    small_cost = int(params.get('small_cost', 1))
    large_cost = int(params.get('large_cost', 2))
    small_cap_areas = int(params.get('small_cap_areas', 3))
    max_large_stores = int(params.get('max_large_stores', 1))
    min_neighborhood_counters = int(params.get('minimum_neighborhood_counters', 6))
    small_store_counter_credit = int(params.get('small_store_counter_credit', 1))
    
    # Create model
    model = gp.Model("MinChainStores")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_small[j] = 1 if we build a Small-format store in area j
    # x_large[j] = 1 if we build a Large-format store in area j
    x_small = {j: model.addVar(vtype=GRB.BINARY, name=f"x_small_{j}") for j in areas}
    x_large = {j: model.addVar(vtype=GRB.BINARY, name=f"x_large_{j}") for j in areas}
    
    # Objective: minimize total cost
    obj = gp.quicksum(small_cost * x_small[j] + large_cost * x_large[j] for j in areas)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraint 1: Each area must be covered by at least one store
    for i in areas:
        covering_stores = []
        for j in areas:
            if i in coverage.get(j, set()):
                covering_stores.append(x_small[j])
                covering_stores.append(x_large[j])
        model.addConstr(gp.quicksum(covering_stores) >= 1, f"Cover_{i}")
    
    # Constraint 2: Small stores can serve at most small_cap_areas from their coverage list
    for j in areas:
        num_covered = len(coverage.get(j, set()))
        model.addConstr(x_small[j] * num_covered <= small_cap_areas, f"SmallCap_{j}")
    
    # Constraint 3: Maximum number of Large stores
    model.addConstr(gp.quicksum(x_large[j] for j in areas) <= max_large_stores, "MaxLarge")
    
    # Constraint 4: Minimum number of Small-format stores (neighborhood counters)
    model.addConstr(gp.quicksum(x_small[j] for j in areas) >= min_neighborhood_counters, "MinSmall")
    
    # Constraint 5: Each area can have at most one store (either small or large, not both)
    for j in areas:
        model.addConstr(x_small[j] + x_large[j] <= 1, f"OneStore_{j}")
    
    # Optimize
    model.optimize()
    
    # Get results
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        selected_small = [j for j in areas if x_small[j].x > 0.5]
        selected_large = [j for j in areas if x_large[j].x > 0.5]
        
        # Verify coverage
        all_areas = set(areas)
        covered_total = set()
        for j in selected_small:
            covered_total |= coverage[j]
        for j in selected_large:
            covered_total |= coverage[j]
        
        print(f"Optimal total cost: {obj_val}")
        print(f"Small stores: {sorted(selected_small)}")
        print(f"Large stores: {sorted(selected_large)}")
        print(f"All areas covered: {all_areas.issubset(covered_total)}")
        print(f"Number of small stores: {len(selected_small)}")
        print(f"Number of large stores: {len(selected_large)}")
        
        print(f"\nFINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Problem status: {model.status}")
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
