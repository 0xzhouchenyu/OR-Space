import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data

def main():
    # Get data directory path
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load data
    products = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params_raw = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Parse general parameters
    params = {}
    for row in params_raw:
        params[row['Parameter_Name']] = float(row['Value'])
    
    max_grains = params['max_grains']
    price_grains = params['price_per_lb_grains']
    max_meat = params['max_meat']
    price_meat = params['price_per_lb_meat']
    line_fixed_cost = params['line_fixed_cost']
    line_capacity_packs = params['line_capacity_packs']
    min_batch_packs = params['min_batch_packs']
    min_yummies = params['min_yummies']
    rebate_yummies_threshold = params['retailer_rebate_yummies_threshold']
    rebate_min_meaties = params['retailer_rebate_min_meaties']
    rebate_fixed = params['retailer_rebate_fixed']
    
    # Parse product data
    product_data = {}
    for row in products:
        name = row['Product']
        product_data[name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'variable_cost': float(row['Variable_cost_per_pack']),
            'capacity': float(row['Production_capacity']) if row['Production_capacity'].strip() else None
        }
    
    m = product_data['Meaties']
    y = product_data['Yummies']
    
    # Create model
    model = gp.Model("HealthyPetFoods")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_meaties = model.addVar(lb=0, name="Meaties")
    x_yummies = model.addVar(lb=0, name="Yummies")
    z = model.addVar(vtype=GRB.BINARY, name="LineActive")  # 1 if co-packing line is used
    
    # Rebate indicator variables
    r_yummies = model.addVar(vtype=GRB.BINARY, name="RebateYummiesMet")
    r_meaties = model.addVar(vtype=GRB.BINARY, name="RebateMeatiesMet")
    r_total = model.addVar(vtype=GRB.BINARY, name="RebateTotalMet")
    
    # Profit per pack (excluding fixed costs and rebate)
    profit_meaties = m['price'] - m['variable_cost'] - (m['grains'] * price_grains + m['meat'] * price_meat)
    profit_yummies = y['price'] - y['variable_cost'] - (y['grains'] * price_grains + y['meat'] * price_meat)
    
    # Objective: maximize total profit
    model.setObjective(
        profit_meaties * x_meaties + profit_yummies * x_yummies 
        - line_fixed_cost * z 
        + rebate_fixed * r_total,
        GRB.MAXIMIZE
    )
    
    # Constraints
    
    # Grains availability
    model.addConstr(m['grains'] * x_meaties + y['grains'] * x_yummies <= max_grains, "Grains_Constraint")
    
    # Meat availability
    model.addConstr(m['meat'] * x_meaties + y['meat'] * x_yummies <= max_meat, "Meat_Constraint")
    
    # Production capacity for Meaties
    if m['capacity'] is not None:
        model.addConstr(x_meaties <= m['capacity'], "Meaties_Capacity")
    
    # Line activation constraints
    # If line is not active, production must be 0
    model.addConstr(x_meaties + x_yummies <= line_capacity_packs * z, "Line_Capacity")
    model.addConstr(x_meaties + x_yummies >= min_batch_packs * z, "Min_Batch")
    
    # Minimum Yummies if line is active
    model.addConstr(x_yummies >= min_yummies * z, "Min_Yummies")
    
    # Rebate logic: r_total = 1 only if both r_yummies = 1 and r_meaties = 1
    model.addConstr(r_total <= r_yummies, "Rebate_Link1")
    model.addConstr(r_total <= r_meaties, "Rebate_Link2")
    model.addConstr(r_total >= r_yummies + r_meaties - 1, "Rebate_Link3")
    
    # Rebate thresholds
    model.addConstr(x_yummies >= rebate_yummies_threshold * r_yummies, "Rebate_Yummies_Threshold")
    model.addConstr(x_meaties >= rebate_min_meaties * r_meaties, "Rebate_Meaties_Threshold")
    
    # Solve
    model.optimize()
    
    # Print results
    print(f"Status: {model.status}")
    if model.status == GRB.OPTIMAL:
        print(f"Meaties: {x_meaties.X}")
        print(f"Yummies: {x_yummies.X}")
        print(f"Line Active: {z.X}")
        print(f"Rebate Earned: {r_total.X}")
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
