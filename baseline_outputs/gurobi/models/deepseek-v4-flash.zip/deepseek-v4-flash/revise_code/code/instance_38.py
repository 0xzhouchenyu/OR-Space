import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_processing_times(filepath):
    """Load processing times from CSV file."""
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times

def load_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if row[1] != '':
                params[row[0]] = float(row[1])
    return params

def main():
    # Get data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load data
    processing_times = load_processing_times(os.path.join(data_dir, 'table_1.csv'))
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    n_products = len(processing_times)
    n_machines = len(processing_times[0])
    
    # Extract parameters
    time_windows = [
        params['time_window_1'],
        params['time_window_2'],
        params['time_window_3']
    ]
    overtime_windows = [
        params['overtime_window_1'],
        params['overtime_window_2'],
        params['overtime_window_3']
    ]
    overtime_penalty = params['overtime_penalty_per_unit']
    big_M = [
        params['M_1'],
        params['M_2'],
        params['M_3']
    ]
    review_threshold = params['machine1_overtime_review_threshold']
    review_fee = params['machine1_overtime_review_fee']
    
    # Create model
    model = gp.Model('FlowShopScheduling')
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i][j] = start time of product i on machine j
    x = {}
    for i in range(n_products):
        for j in range(n_machines):
            x[i, j] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f'x_{i}_{j}')
    
    # y[i][k] = 1 if product i comes before product k in sequence (i < k)
    y = {}
    for i in range(n_products):
        for k in range(n_products):
            if i != k:
                y[i, k] = model.addVar(vtype=GRB.BINARY, name=f'y_{i}_{k}')
    
    # Overtime variables
    # o[j] = overtime on machine j
    o = {}
    for j in range(n_machines):
        o[j] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f'overtime_{j}')
    
    # z = binary variable for machine 1 review fee
    z = model.addVar(vtype=GRB.BINARY, name='review_fee_flag')
    
    # Makespan variable
    Cmax = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name='Cmax')
    
    # Update model to add variables
    model.update()
    
    # Constraints
    
    # 1. Processing order constraints (product must finish on machine j before starting on j+1)
    for i in range(n_products):
        for j in range(n_machines - 1):
            model.addConstr(
                x[i, j] + processing_times[i][j] <= x[i, j+1],
                name=f'order_{i}_{j}'
            )
    
    # 2. Sequencing constraints (same machine, different products)
    for i in range(n_products):
        for k in range(n_products):
            if i != k:
                for j in range(n_machines):
                    # If i before k: x[i,j] + p[i,j] <= x[k,j]
                    # If k before i: x[k,j] + p[k,j] <= x[i,j]
                    model.addConstr(
                        x[i, j] + processing_times[i][j] <= x[k, j] + big_M[j] * (1 - y[i, k]),
                        name=f'seq_{i}_{k}_{j}_1'
                    )
                    model.addConstr(
                        x[k, j] + processing_times[k][j] <= x[i, j] + big_M[j] * y[i, k],
                        name=f'seq_{i}_{k}_{j}_2'
                    )
    
    # 3. Overtime constraints
    for j in range(n_machines):
        # Last product completion on machine j minus time window = overtime
        last_completion = gp.LinExpr()
        for i in range(n_products):
            last_completion += x[i, j] + processing_times[i][j]
        # We need to capture the maximum completion time on each machine
        # Use auxiliary variables and constraints
        max_completion_j = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f'max_comp_{j}')
        model.update()
        for i in range(n_products):
            model.addConstr(max_completion_j >= x[i, j] + processing_times[i][j], name=f'max_comp_{j}_{i}')
        
        # Overtime = max(0, max_completion - time_window)
        model.addConstr(o[j] >= max_completion_j - time_windows[j], name=f'overtime_def_{j}')
        model.addConstr(o[j] >= 0, name=f'overtime_nonneg_{j}')
        # Overtime cannot exceed overtime window
        model.addConstr(o[j] <= overtime_windows[j], name=f'overtime_limit_{j}')
    
    # 4. Machine 1 special review constraint
    # If overtime on machine 1 > review_threshold, then z = 1
    model.addConstr(o[0] - review_threshold <= 1000 * z, name=f'review_flag_1')
    model.addConstr(review_threshold - o[0] <= 1000 * (1 - z), name=f'review_flag_2')
    
    # 5. Makespan definition (completion time of last product on last machine)
    for i in range(n_products):
        model.addConstr(Cmax >= x[i, n_machines-1] + processing_times[i][n_machines-1], name=f'cmax_{i}')
    
    # Objective: minimize makespan + overtime penalty + review fee
    obj = Cmax + overtime_penalty * gp.quicksum(o[j] for j in range(n_machines)) + review_fee * z
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.Status == GRB.OPTIMAL:
        final_obj = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {final_obj}")
    else:
        print(f"FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
