import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    base = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base, "data")
    
    # Read general parameters
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row["Parameter_Name"]] = row["Value"]
    
    n = int(params["n"])
    premium_multiplier = float(params["premium_cost_multiplier"])
    min_premium_share = float(params["min_premium_share"])
    
    # Read table_1.csv
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    # Parse d_ij (transportation volume from factory i to factory j)
    # and c_pq (unit transportation cost from location p to location q)
    d = [[0.0 for _ in range(n)] for _ in range(n)]
    c = [[0.0 for _ in range(n)] for _ in range(n)]
    
    for i, row in enumerate(rows):
        for j in range(n):
            d[i][j] = float(row[f"Transportation_volume_to_Location_{j+1}"])
            c[i][j] = float(row[f"Transportation_cost_to_Location_{j+1}"])
    
    # Compute outbound volume for each factory
    outbound = [sum(d[i][j] for j in range(n)) for i in range(n)]
    
    # Compute standard and premium costs for each factory-location pair
    c_std = [[0.0 for _ in range(n)] for _ in range(n)]
    c_prem = [[0.0 for _ in range(n)] for _ in range(n)]
    
    for i in range(n):
        for p in range(n):
            if outbound[i] > 0:
                # c_std_ip = (sum_j d_ij * c_pj) / outbound_volume_i
                total = sum(d[i][j] * c[p][j] for j in range(n))
                c_std[i][p] = total / outbound[i]
            else:
                c_std[i][p] = 0.0
            c_prem[i][p] = premium_multiplier * c_std[i][p]
    
    # Create model
    model = gp.Model("FactoryAssignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i,p] = 1 if factory i assigned to location p
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")
    
    # y[i,p] = 1 if premium handling selected for factory i at location p
    y = model.addVars(n, n, vtype=GRB.BINARY, name="y")
    
    # v_std[i,p] = volume handled in standard mode for factory i at location p
    v_std = model.addVars(n, n, lb=0.0, name="v_std")
    
    # v_prem[i,p] = volume handled in premium mode for factory i at location p
    v_prem = model.addVars(n, n, lb=0.0, name="v_prem")
    
    # Constraints
    
    # Each factory assigned to exactly one location
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, p] for p in range(n)) == 1, name=f"assign_factory_{i}")
    
    # Each location hosts at most one factory
    for p in range(n):
        model.addConstr(gp.quicksum(x[i, p] for i in range(n)) <= 1, name=f"capacity_loc_{p}")
    
    # Premium mode only possible if factory assigned to that location
    for i in range(n):
        for p in range(n):
            model.addConstr(y[i, p] <= x[i, p], name=f"premium_only_if_assigned_{i}_{p}")
    
    # Volume split: total outbound volume must be processed at assigned location
    for i in range(n):
        for p in range(n):
            model.addConstr(v_std[i, p] + v_prem[i, p] == outbound[i] * x[i, p], 
                           name=f"volume_split_{i}_{p}")
    
    # Premium volume only if premium mode selected
    for i in range(n):
        for p in range(n):
            model.addConstr(v_prem[i, p] <= outbound[i] * y[i, p], 
                           name=f"premium_volume_only_{i}_{p}")
    
    # Minimum premium share if premium activated
    for i in range(n):
        for p in range(n):
            model.addConstr(v_prem[i, p] >= min_premium_share * outbound[i] * y[i, p],
                           name=f"min_premium_share_{i}_{p}")
    
    # Objective: minimize total cost
    obj = gp.QuadExpr()
    for i in range(n):
        for p in range(n):
            obj += c_std[i][p] * v_std[i, p] + c_prem[i][p] * v_prem[i, p]
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    solve()
