import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'table_1.csv')
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    
    # Parse process data
    a_I = float(rows[0][1])  # Model A hours for Process I
    b_I = float(rows[0][2])  # Model B hours for Process I
    cap_I = float(rows[0][3])  # Max weekly capacity Process I (normal hours)
    
    a_II = float(rows[1][1])  # Model A hours for Process II
    b_II = float(rows[1][2])  # Model B hours for Process II
    cap_II = float(rows[1][3])  # Max weekly capacity Process II (normal hours)
    
    profit_A = float(rows[2][1])  # Profit per unit Model A
    profit_B = float(rows[2][2])  # Profit per unit Model B
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    min_profit = params['min_weekly_profit']
    min_A_total = params['min_model_A_units']
    min_B_total = params['min_model_B_units']
    week1_min_A = params['week1_min_model_A_units']
    week1_min_B = params['week1_min_model_B_units']
    week2_min_A = params['week2_min_model_A_units']
    week2_min_B = params['week2_min_model_B_units']
    
    normal_hours_I = params['process_I_hours']
    normal_hours_II = params['process_II_hours']
    max_ot_I = params['max_overtime_I_per_week']
    max_ot_II = params['max_overtime_II_per_week']
    ot_cost_I = params['overtime_premium_I']
    ot_cost_II = params['overtime_premium_II']
    min_util_I = params['min_avg_utilization_I']
    min_util_II = params['min_avg_utilization_II']
    fatigue_thresh_I = params['week1_overtime_fatigue_threshold_I']
    fatigue_thresh_II = params['week1_overtime_fatigue_threshold_II']
    recovery_loss_I = params['week2_recovery_loss_I']
    recovery_loss_II = params['week2_recovery_loss_II']
    
    # Create model
    model = gp.Model("Microcomputer_TwoWeek")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Week 1 production
    x_A1 = model.addVar(lb=0, name="x_A1")
    x_B1 = model.addVar(lb=0, name="x_B1")
    # Week 2 production
    x_A2 = model.addVar(lb=0, name="x_A2")
    x_B2 = model.addVar(lb=0, name="x_B2")
    
    # Overtime hours per process per week
    ot_I1 = model.addVar(lb=0, ub=max_ot_I, name="ot_I1")
    ot_II1 = model.addVar(lb=0, ub=max_ot_II, name="ot_II1")
    ot_I2 = model.addVar(lb=0, ub=max_ot_I, name="ot_I2")
    ot_II2 = model.addVar(lb=0, ub=max_ot_II, name="ot_II2")
    
    # Binary variables for fatigue threshold (1 if overtime exceeds threshold)
    z_I = model.addVar(vtype=GRB.BINARY, name="z_I")
    z_II = model.addVar(vtype=GRB.BINARY, name="z_II")
    
    # Available normal hours in week 2 (after recovery loss)
    avail_I2 = model.addVar(lb=0, ub=normal_hours_I, name="avail_I2")
    avail_II2 = model.addVar(lb=0, ub=normal_hours_II, name="avail_II2")
    
    # Objective: Maximize two-week profit minus overtime costs
    total_revenue = profit_A * (x_A1 + x_A2) + profit_B * (x_B1 + x_B2)
    total_ot_cost = ot_cost_I * (ot_I1 + ot_I2) + ot_cost_II * (ot_II1 + ot_II2)
    model.setObjective(total_revenue - total_ot_cost, GRB.MAXIMIZE)
    
    # Constraints
    
    # Week 1 capacity constraints (normal + overtime)
    model.addConstr(a_I * x_A1 + b_I * x_B1 <= normal_hours_I + ot_I1, "Cap_I_Week1")
    model.addConstr(a_II * x_A1 + b_II * x_B1 <= normal_hours_II + ot_II1, "Cap_II_Week1")
    
    # Week 2 capacity constraints (available normal hours + overtime)
    model.addConstr(a_I * x_A2 + b_I * x_B2 <= avail_I2 + ot_I2, "Cap_I_Week2")
    model.addConstr(a_II * x_A2 + b_II * x_B2 <= avail_II2 + ot_I2, "Cap_II_Week2")
    
    # Week 2 available normal hours with recovery rule
    # If ot_I1 > fatigue_thresh_I, then avail_I2 = normal_hours_I - recovery_loss_I
    # Else avail_I2 = normal_hours_I
    M_I = max_ot_I + 1
    model.addConstr(avail_I2 <= normal_hours_I, "Avail_I2_ub")
    model.addConstr(avail_I2 >= normal_hours_I - recovery_loss_I * z_I, "Avail_I2_lb")
    model.addConstr(ot_I1 <= fatigue_thresh_I + M_I * (1 - z_I), "Fatigue_I_on")
    model.addConstr(ot_I1 >= fatigue_thresh_I + 0.001 - M_I * z_I, "Fatigue_I_off")
    
    M_II = max_ot_II + 1
    model.addConstr(avail_II2 <= normal_hours_II, "Avail_II2_ub")
    model.addConstr(avail_II2 >= normal_hours_II - recovery_loss_II * z_II, "Avail_II2_lb")
    model.addConstr(ot_II1 <= fatigue_thresh_II + M_II * (1 - z_II), "Fatigue_II_on")
    model.addConstr(ot_II1 >= fatigue_thresh_II + 0.001 - M_II * z_II, "Fatigue_II_off")
    
    # Weekly delivery promises
    model.addConstr(x_A1 >= week1_min_A, "Week1_Min_A")
    model.addConstr(x_B1 >= week1_min_B, "Week1_Min_B")
    model.addConstr(x_A2 >= week2_min_A, "Week2_Min_A")
    model.addConstr(x_B2 >= week2_min_B, "Week2_Min_B")
    
    # Total production requirements
    model.addConstr(x_A1 + x_A2 >= min_A_total, "Total_Min_A")
    model.addConstr(x_B1 + x_B2 >= min_B_total, "Total_Min_B")
    
    # Minimum total profit (after overtime costs)
    model.addConstr(total_revenue - total_ot_cost >= min_profit, "Min_Profit")
    
    # Minimum average utilization of regular hours over two weeks
    # Utilization = (total regular hours used) / (2 * normal_hours)
    # Regular hours used = total hours - overtime hours
    reg_used_I = (a_I * x_A1 + b_I * x_B1 - ot_I1) + (a_I * x_A2 + b_I * x_B2 - ot_I2)
    model.addConstr(reg_used_I >= min_util_I * 2 * normal_hours_I, "Min_Util_I")
    
    reg_used_II = (a_II * x_A1 + b_II * x_B1 - ot_II1) + (a_II * x_A2 + b_II * x_B2 - ot_II2)
    model.addConstr(reg_used_II >= min_util_II * 2 * normal_hours_II, "Min_Util_II")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val:.2f}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.status}")

if __name__ == "__main__":
    main()
