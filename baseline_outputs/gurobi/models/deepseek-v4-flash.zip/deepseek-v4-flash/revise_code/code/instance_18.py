import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

# Extract parameters
fabric_production_rate = params['fabric_production_rate']       # 1000 meters/hour
min_curtain_fabric_sales = params['min_curtain_fabric_sales']   # 70000 meters
min_clothing_fabric_sales = params['min_clothing_fabric_sales'] # 45000 meters
day_shift_regular_capacity = params['day_shift_regular_capacity']       # 60 hours
night_shift_regular_capacity = params['night_shift_regular_capacity']   # 60 hours
day_overtime_limit = params['day_overtime_limit']                       # 3 hours
night_overtime_limit = params['night_overtime_limit']                   # 3 hours
day_overtime_penalty = params['day_overtime_penalty']                   # 1.0 yuan/hour
night_overtime_penalty = params['night_overtime_penalty']               # 1.5 yuan/hour
day_min_utilization_ratio = params['day_min_utilization_ratio']         # 0.45
night_min_utilization_ratio = params['night_min_utilization_ratio']     # 0.45

# Convert sales requirements to hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate  # 70 hours
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate  # 45 hours

# Create model
model = gp.Model("Textile_Factory_Shift_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
# Regular production hours per shift per fabric type
day_clothing = model.addVar(lb=0, name="day_clothing_hours")
day_curtain = model.addVar(lb=0, name="day_curtain_hours")
night_clothing = model.addVar(lb=0, name="night_clothing_hours")
night_curtain = model.addVar(lb=0, name="night_curtain_hours")

# Overtime hours per shift
day_overtime = model.addVar(lb=0, ub=day_overtime_limit, name="day_overtime_hours")
night_overtime = model.addVar(lb=0, ub=night_overtime_limit, name="night_overtime_hours")

# Objective: minimize total overtime penalty cost
model.setObjective(
    day_overtime_penalty * day_overtime + night_overtime_penalty * night_overtime,
    GRB.MINIMIZE
)

# Constraints

# 1. Total regular hours per shift must not exceed shift capacity
model.addConstr(day_clothing + day_curtain <= day_shift_regular_capacity, "Day_Regular_Capacity")
model.addConstr(night_clothing + night_curtain <= night_shift_regular_capacity, "Night_Regular_Capacity")

# 2. Minimum utilization ratios (based on total regular hours across both shifts)
total_regular = day_clothing + day_curtain + night_clothing + night_curtain
model.addConstr(day_clothing + day_curtain >= day_min_utilization_ratio * total_regular, "Day_Min_Utilization")
model.addConstr(night_clothing + night_curtain >= night_min_utilization_ratio * total_regular, "Night_Min_Utilization")

# 3. Meet minimum sales requirements for each fabric type
model.addConstr(day_clothing + night_clothing >= min_clothing_hours, "Clothing_Sales_Requirement")
model.addConstr(day_curtain + night_curtain >= min_curtain_hours, "Curtain_Sales_Requirement")

# 4. Production time balance: total production = regular hours + overtime hours
model.addConstr(
    day_clothing + day_curtain + night_clothing + night_curtain + day_overtime + night_overtime
    >= min_clothing_hours + min_curtain_hours,
    "Production_Balance"
)

# Solve
model.optimize()

# Get results
obj_val = model.objVal

print(f"FINAL_OBJ_VALUE: {obj_val}")
