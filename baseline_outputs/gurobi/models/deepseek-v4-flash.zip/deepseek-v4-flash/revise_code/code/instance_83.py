import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Get the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load time periods and minimum waiters needed
time_periods = []
min_waiters = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        time_periods.append(row["Time"].strip())
        min_waiters.append(int(row["Minimum_Number_of_Waiters_Needed"].strip()))

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = row["Value"].strip()

# Extract parameters
work_hours = int(params["waiter_work_hours"])
waiter_cost = int(params["waiter_cost_per_shift"])
waiter_budget = int(params["waiter_budget"])

# Peak indicators and quality weights
peak = [int(params[f"peak_{i}"]) for i in range(6)]
quality = [int(params[f"quality_{i}"]) for i in range(6)]

n = len(time_periods)  # 6 periods

# Create model
model = gp.Model("Restaurant_Waiters_Revised")
model.setParam('OutputFlag', 0)

# Decision variables: x_i = number of waiters starting at period i
x = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="x")

# Auxiliary variables for peak/off-peak composition per shift
# For each shift starting at period i, we need to know if it has one peak and one off-peak
# A shift covers periods i and (i+1)%n
# We create binary variables for each shift type
# y_i = 1 if shift starting at i is "compliant" (one peak, one off-peak), 0 otherwise
# But since we need integer number of waiters, we can model it differently:
# For each shift starting at i, the number of waiters assigned to that shift
# must be such that the total peak coverage and off-peak coverage constraints are met.
# Actually, the requirement says: "one peak window and one off-peak window" per shift.
# This means each waiter's 8-hour block must consist of one peak period and one off-peak period.
# So we need to ensure that for each shift start i, the waiters assigned there
# only work if the two periods (i and i+1) consist of one peak and one off-peak.

# Let's create a binary indicator for each shift start: is it a valid shift?
valid_shift = []
for i in range(n):
    j = (i + 1) % n
    if (peak[i] == 1 and peak[j] == 0) or (peak[i] == 0 and peak[j] == 1):
        valid_shift.append(1)
    else:
        valid_shift.append(0)

# We can only assign waiters to valid shifts
# So we create variables only for valid shifts
# But to keep the model simple, we'll create all x_i but add constraints
# that x_i = 0 for invalid shifts

# Objective: minimize total number of waiters (since cost per shift is 1, this also minimizes cost)
# But we have a budget constraint, so we minimize number of waiters subject to budget
model.setObjective(gp.quicksum(x[i] for i in range(n)), GRB.MINIMIZE)

# Coverage constraints: for each period j, waiters working = those starting at j or j-1
for j in range(n):
    prev = (j - 1) % n
    model.addConstr(x[prev] + x[j] >= min_waiters[j], f"Coverage_{j}")

# Budget constraint: total cost <= waiter_budget
model.addConstr(gp.quicksum(waiter_cost * x[i] for i in range(n)) <= waiter_budget, "Budget")

# Only allow valid shifts (one peak, one off-peak)
for i in range(n):
    if valid_shift[i] == 0:
        model.addConstr(x[i] == 0, f"InvalidShift_{i}")

# Optimize
model.optimize()

# Get objective value
if model.status == GRB.OPTIMAL:
    total = int(model.objVal)
else:
    total = -1  # Infeasible or unbounded

print(f"FINAL_OBJ_VALUE: {total}")
