import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load table_1.csv
weeks_data = []
with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Week'].strip().lower() == 'total':
            continue
        weeks_data.append({
            'week': int(row['Week']),
            'demand': float(row['Demand_1000_boxes']),
            'capacity': float(row['Production_Capacity_1000_boxes']),
            'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
        })

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'])

storage_cost = params['storage_cost_per_thousand_boxes']
fixed_setup_cost = params['fixed_setup_cost']
week2_push_threshold = params['week2_push_threshold']
week3_capacity_loss = params['week3_capacity_loss_after_week2_push']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']

n_weeks = len(weeks_data)

# Create model
model = gp.Model("Beverage_Production_Planning")
model.setParam('OutputFlag', 0)

# Decision variables
x = [model.addVar(lb=0, ub=weeks_data[t]['capacity'], name=f"x_{t+1}") for t in range(n_weeks)]
s = [model.addVar(lb=0, name=f"s_{t+1}") for t in range(n_weeks)]

# Binary variables for fixed setup cost
y = [model.addVar(vtype=GRB.BINARY, name=f"y_{t+1}") for t in range(n_weeks)]

# Binary variable for week 2 micro-clean trigger (1 if x[1] > 30)
z_micro = model.addVar(vtype=GRB.BINARY, name="z_microclean")

# Binary variable for week 2 push threshold (1 if x[1] > 35)
z_push = model.addVar(vtype=GRB.BINARY, name="z_push")

# Objective: production cost + storage cost + fixed setup costs + micro-clean fee
obj = gp.quicksum(weeks_data[t]['cost'] * x[t] for t in range(n_weeks)) + \
      gp.quicksum(storage_cost * s[t] for t in range(n_weeks)) + \
      gp.quicksum(fixed_setup_cost * y[t] for t in range(n_weeks)) + \
      week2_microclean_fee * z_micro

model.setObjective(obj, GRB.MINIMIZE)

# Constraints: inventory balance
for t in range(n_weeks):
    if t == 0:
        model.addConstr(x[t] - s[t] == weeks_data[t]['demand'], f"balance_week_{t+1}")
    else:
        model.addConstr(s[t-1] + x[t] - s[t] == weeks_data[t]['demand'], f"balance_week_{t+1}")

# Fixed setup cost constraints: x[t] <= capacity * y[t]
for t in range(n_weeks):
    model.addConstr(x[t] <= weeks_data[t]['capacity'] * y[t], f"setup_{t+1}")

# Week 2 micro-clean logic: if x[1] > 30, then z_micro = 1
M1 = weeks_data[1]['capacity']  # 40
model.addConstr(x[1] - week2_microclean_threshold <= M1 * z_micro, "microclean_trigger")
model.addConstr(week2_microclean_threshold - x[1] <= M1 * (1 - z_micro), "microclean_no_trigger")

# Week 2 push threshold logic: if x[1] > 35, then z_push = 1
M2 = weeks_data[1]['capacity']  # 40
model.addConstr(x[1] - week2_push_threshold <= M2 * z_push, "push_trigger")
model.addConstr(week2_push_threshold - x[1] <= M2 * (1 - z_push), "push_no_trigger")

# Week 3 capacity reduction if week 2 production exceeds push threshold
# Original week 3 capacity is 45, reduced by week3_capacity_loss (20) if z_push = 1
model.addConstr(x[2] <= weeks_data[2]['capacity'] - week3_capacity_loss * z_push, "week3_capacity_reduction")

# Optimize
model.optimize()

# Print results
print(f"Status: {model.status}")
for t in range(n_weeks):
    print(f"Week {t+1}: Produce {x[t].X:.1f}, Inventory {s[t].X:.1f}")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
