import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        value = float(row["Value"].strip())
        params[name] = value

# Extract parameters
m1_liquid = params["machine_1_time_per_liquid_lot"]
m2_liquid = params["machine_2_time_per_liquid_lot"]
m1_solid = params["machine_1_time_per_solid_lot"]
m2_solid = params["machine_2_time_per_solid_lot"]

init_liquid = params["initial_liquid_inventory"]
init_solid = params["initial_solid_inventory"]

m1_avail_base = params["machine_1_available_time"] * 60  # convert hours to minutes
m2_avail_base = params["machine_2_available_time"] * 60

demand_liquid = params["forecast_liquid_demand"]
demand_solid = params["forecast_solid_demand"]

extended_extra_minutes = params["extended_extra_minutes"]
labor_hours_per_extended = params["labor_hours_per_machine_extended"]
labor_budget_hours = params["labor_budget_hours"]
extended_penalty = params["extended_mode_penalty"]
priority_reserve = params["priority_reserve_lots"]
excess_credit = params["excess_reserve_credit"]

# Create model
model = gp.Model("Fertilizer_Resilience")
model.setParam('OutputFlag', 0)

# Decision variables
x_l = model.addVar(lb=0, name="liquid_produced")
x_s = model.addVar(lb=0, name="solid_produced")

# Extended mode binary variables
e1 = model.addVar(vtype=GRB.BINARY, name="extend_machine1")
e2 = model.addVar(vtype=GRB.BINARY, name="extend_machine2")

# Ending inventories
end_liquid = init_liquid + x_l - demand_liquid
end_solid = init_solid + x_s - demand_solid

# Auxiliary variables for resilience score components
# For liquid
liquid_priority = model.addVar(lb=0, ub=priority_reserve, name="liquid_priority")
liquid_excess = model.addVar(lb=0, name="liquid_excess")
# For solid
solid_priority = model.addVar(lb=0, ub=priority_reserve, name="solid_priority")
solid_excess = model.addVar(lb=0, name="solid_excess")

# Constraints linking ending inventory to priority/excess bands
model.addConstr(liquid_priority + liquid_excess == end_liquid, "liquid_band_split")
model.addConstr(solid_priority + solid_excess == end_solid, "solid_band_split")

# Machine time constraints with extended mode
model.addConstr(m1_liquid * x_l + m1_solid * x_s <= m1_avail_base + extended_extra_minutes * e1, "Machine1_Capacity")
model.addConstr(m2_liquid * x_l + m2_solid * x_s <= m2_avail_base + extended_extra_minutes * e2, "Machine2_Capacity")

# Labor budget constraint
model.addConstr(labor_hours_per_extended * e1 + labor_hours_per_extended * e2 <= labor_budget_hours, "Labor_Budget")

# Demand satisfaction (ending inventory >= 0)
model.addConstr(end_liquid >= 0, "Liquid_Demand")
model.addConstr(end_solid >= 0, "Solid_Demand")

# Objective: maximize resilience score
# Score = priority_lots (count fully) + excess_lots * excess_credit - extended_penalty * (e1 + e2)
obj = (liquid_priority + solid_priority) + excess_credit * (liquid_excess + solid_excess) - extended_penalty * (e1 + e2)
model.setObjective(obj, GRB.MAXIMIZE)

# Optimize
model.optimize()

# Get objective value
obj_val = model.objVal

print(f"FINAL_OBJ_VALUE: {obj_val:.2f}")
