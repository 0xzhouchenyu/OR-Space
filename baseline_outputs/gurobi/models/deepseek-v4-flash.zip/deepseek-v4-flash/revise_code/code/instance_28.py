import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

initial_fund = params['initial_fund']  # 300000
annual_rate = params['annual_profit_rate'] / 100  # 0.20
inv_limit_y1 = params['investment_limit_year1']  # 150000
return_rate_y1y2 = params['return_rate_year1_to_year2'] / 100  # 1.50
inv_limit_y2 = params['investment_limit_year2']  # 200000
return_rate_y2y3 = params['return_rate_year2_to_year3'] / 100  # 1.60
inv_limit_y3 = params['investment_limit_year3']  # 100000
profit_rate_y3 = params['profit_rate_year3'] / 100  # 0.40
fee_y1 = params['fee_year1']  # 10000
fee_y2 = params['fee_year2']  # 12000
fee_y3 = params['fee_year3']  # 5000

# Create model
model = gp.Model("Investment_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
a1 = model.addVar(lb=0, name="a1")  # annual investment year 1
a2 = model.addVar(lb=0, name="a2")  # annual investment year 2
a3 = model.addVar(lb=0, name="a3")  # annual investment year 3

b1 = model.addVar(lb=0, ub=inv_limit_y1, name="b1")  # 2-year investment year 1
c2 = model.addVar(lb=0, ub=inv_limit_y2, name="c2")  # 2-year investment year 2
d3 = model.addVar(lb=0, ub=inv_limit_y3, name="d3")  # special 1-year investment year 3

# Binary variables for fixed fees
y1 = model.addVar(vtype=GRB.BINARY, name="y1")  # fee for b1
y2 = model.addVar(vtype=GRB.BINARY, name="y2")  # fee for c2
y3 = model.addVar(vtype=GRB.BINARY, name="y3")  # fee for d3

# Linking constraints: if investment > 0, binary must be 1
M1 = inv_limit_y1
M2 = inv_limit_y2
M3 = inv_limit_y3

model.addConstr(b1 <= M1 * y1, "link_b1_y1")
model.addConstr(c2 <= M2 * y2, "link_c2_y2")
model.addConstr(d3 <= M3 * y3, "link_d3_y3")

# Budget constraint Year 1
model.addConstr(a1 + b1 <= initial_fund, "Year1_budget")

# Budget constraint Year 2
# Available: leftover from year 1 + a1*(1+annual_rate) - fees paid in year 1
# Fees in year 1: fee_y1 * y1
model.addConstr(a2 + c2 <= (initial_fund - a1 - b1) + a1 * (1 + annual_rate) - fee_y1 * y1, "Year2_budget")

# Budget constraint Year 3
# Available: cash from year 2 + a2*(1+annual_rate) + b1*return_rate_y1y2 - fees paid in year 2
# Cash from year 2 = (initial_fund - a1 - b1) + a1*(1+annual_rate) - fee_y1*y1 - a2 - c2
cash_year2 = (initial_fund - a1 - b1) + a1 * (1 + annual_rate) - fee_y1 * y1 - a2 - c2
model.addConstr(a3 + d3 <= cash_year2 + a2 * (1 + annual_rate) + b1 * return_rate_y1y2 - fee_y2 * y2, "Year3_budget")

# Cash leftover at end of year 3
cash_year3 = cash_year2 + a2 * (1 + annual_rate) + b1 * return_rate_y1y2 - fee_y2 * y2 - a3 - d3

# Total net at end of year 3
total_end = cash_year3 + a3 * (1 + annual_rate) + c2 * return_rate_y2y3 + d3 * (1 + profit_rate_y3) - fee_y3 * y3

model.setObjective(total_end, GRB.MAXIMIZE)

model.optimize()

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
