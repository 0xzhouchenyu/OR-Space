import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read property data
properties = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_mult = params['scen_1_risky_multiplier']
scen_2_mult = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = int(params['max_risky_properties'])

# Create model
model = gp.Model("RealEstateInvestment")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}  # buy property (binary)
y = {}  # fraction of property allocated to risky tenants (continuous, 0 to per_property_risky_cap)
z = {}  # whether property has any risky tenants (binary)

for p in properties:
    name = p['name']
    x[name] = model.addVar(vtype=GRB.BINARY, name=f"buy_{name}")
    y[name] = model.addVar(lb=0.0, ub=per_property_risky_cap, vtype=GRB.CONTINUOUS, name=f"risky_frac_{name}")
    z[name] = model.addVar(vtype=GRB.BINARY, name=f"has_risky_{name}")

# Objective: maximize expected annual income
# Income = (1 - y) * base_income (long-term) + y * base_income * (scen_1_prob * scen_1_mult + scen_2_prob * scen_2_mult) (risky)
# But risky income only applies if property is bought. If not bought, income is 0.
# We'll use linearization: income = base_income * x - base_income * y * x + base_income * y * x * expected_mult
# Actually simpler: income = base_income * (1 - y) * x + base_income * y * x * expected_risky_mult
# = base_income * x - base_income * y * x + base_income * y * x * expected_risky_mult
# = base_income * x + base_income * y * x * (expected_risky_mult - 1)
# Since y * x is bilinear, we need to linearize. Let w = y * x (continuous, 0 to per_property_risky_cap)
# Then income = base_income * x + base_income * w * (expected_risky_mult - 1)

expected_risky_mult = scen_1_prob * scen_1_mult + scen_2_prob * scen_2_mult

w = {}
for p in properties:
    name = p['name']
    w[name] = model.addVar(lb=0.0, ub=per_property_risky_cap, vtype=GRB.CONTINUOUS, name=f"w_{name}")
    # w = y * x, so w <= y, w <= x * per_property_risky_cap, w >= y - (1-x)*per_property_risky_cap, w >= 0
    model.addConstr(w[name] <= y[name], name=f"w_le_y_{name}")
    model.addConstr(w[name] <= per_property_risky_cap * x[name], name=f"w_le_x_{name}")
    model.addConstr(w[name] >= y[name] - per_property_risky_cap * (1 - x[name]), name=f"w_ge_y_{name}")

# Objective
obj = gp.LinExpr()
for p in properties:
    name = p['name']
    obj += p['income'] * x[name] + p['income'] * (expected_risky_mult - 1) * w[name]
model.setObjective(obj, GRB.MAXIMIZE)

# Budget constraint
model.addConstr(gp.quicksum(p['cost'] * x[p['name']] for p in properties) <= budget, name="budget")

# Property 4 excludes Property 3
model.addConstr(x['Property_4'] + x['Property_3'] <= 1, name="exclusion")

# Risky exposure only on purchased properties: y <= x (since y <= per_property_risky_cap * x already via w constraints, but need explicit)
# Actually y can be >0 only if x=1. Use: y <= x (since y is bounded by 0.8, but x is binary, so y <= x * per_property_risky_cap is not enough)
# We need y <= x (since if x=0, y must be 0). But y's upper bound is 0.8, so y <= x * 0.8 is not sufficient.
# Use: y <= x (since y is continuous up to 0.8, but if x=0, y must be 0)
model.addConstrs((y[p['name']] <= x[p['name']] for p in properties), name="risky_only_if_bought")

# Link z to y: z = 1 if y > 0, else 0
M = per_property_risky_cap + 0.001
for p in properties:
    name = p['name']
    model.addConstr(y[name] <= M * z[name], name=f"z_upper_{name}")
    model.addConstr(z[name] <= M * y[name] + 1e-5, name=f"z_lower_{name}")  # if y=0, z=0; if y>0, z=1
    # Actually simpler: z >= y / M, but we need binary. Use:
    # z >= y / per_property_risky_cap (since y <= per_property_risky_cap)
    model.addConstr(z[name] >= y[name] / per_property_risky_cap, name=f"z_ge_y_{name}")

# Total risky budget: sum of cost of properties with any risky tenants <= total_risky_budget
model.addConstr(gp.quicksum(p['cost'] * z[p['name']] for p in properties) <= total_risky_budget, name="total_risky_budget")

# Max number of properties with risky tenants
model.addConstr(gp.quicksum(z[p['name']] for p in properties) <= max_risky_properties, name="max_risky_properties")

# Solve
model.optimize()

# Print results
for p in properties:
    name = p['name']
    print(f"{name}: {int(round(x[name].X))}")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
