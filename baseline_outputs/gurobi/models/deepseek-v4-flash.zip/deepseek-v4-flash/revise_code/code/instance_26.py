import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Get data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            params[name] = value
    
    # Extract parameters
    shift_duration = int(params['shift_duration'])
    full_time_cost = float(params['full_time_cost'])
    part_time_cost = float(params['part_time_cost'])
    part_time_cap = int(params['part_time_cap_per_period'])
    min_full_time = int(params['min_full_time_per_period'])
    
    # Read staffing requirements
    requirements = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            req = int(row['Required_Salespeople'].strip())
            requirements.append(req)
    
    n = 6  # number of periods
    
    # Create model
    model = gp.Model("StaffingOptimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i] = number of full-time staff starting at period i
    x = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="full_time_start")
    
    # y[j] = number of part-time staff assigned to period j
    y = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="part_time_period")
    
    # Objective: minimize total labor cost
    total_cost = full_time_cost * gp.quicksum(x[i] for i in range(n)) + \
                 part_time_cost * gp.quicksum(y[j] for j in range(n))
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Constraints
    # 1. Coverage constraint: full-time present + part-time >= requirement
    for j in range(n):
        # Full-time present in period j: those starting at j and those starting at (j-1) mod n
        full_time_present = x[j] + x[(j - 1) % n]
        model.addConstr(full_time_present + y[j] >= requirements[j], f"coverage_{j}")
    
    # 2. Part-time cap per period
    for j in range(n):
        model.addConstr(y[j] <= part_time_cap, f"part_time_cap_{j}")
    
    # 3. Minimum full-time presence per period
    for j in range(n):
        full_time_present = x[j] + x[(j - 1) % n]
        model.addConstr(full_time_present >= min_full_time, f"min_full_time_{j}")
    
    # Solve
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    
    # Print solution details (optional, but useful for verification)
    for i in range(n):
        print(f"Full-time starts at period {i}: {int(x[i].X)}")
    for j in range(n):
        print(f"Part-time in period {j}: {int(y[j].X)}")
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
