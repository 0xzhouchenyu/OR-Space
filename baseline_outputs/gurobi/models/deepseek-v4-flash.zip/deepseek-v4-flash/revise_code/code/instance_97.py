import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Get data directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    materials = []
    sulfur_content = {}
    purchase_price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            mat = row['Material'].strip()
            materials.append(mat)
            # Handle possible space in column names
            sulfur_key = None
            price_key = None
            for key in row:
                if 'Sulfur' in key:
                    sulfur_key = key
                if 'Purchase_Price' in key:
                    price_key = key
            sulfur_content[mat] = float(row[sulfur_key].strip())
            purchase_price[mat] = float(row[price_key].strip())
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            # Handle possible space in column names
            val_key = None
            for key in row:
                if 'Value' in key:
                    val_key = key
                    break
            val = float(row[val_key].strip())
            params[param_name] = val
    
    # Extract parameters
    max_sulfur_A_premium = params['max_sulfur_content_A_premium']
    max_sulfur_A_standard = params['max_sulfur_content_A_standard']
    max_sulfur_B_premium = params['max_sulfur_content_B_premium']
    max_sulfur_B_standard = params['max_sulfur_content_B_standard']
    
    price_A_premium = params['selling_price_A_premium']
    price_A_standard = params['selling_price_A_standard']
    price_B_premium = params['selling_price_B_premium']
    price_B_standard = params['selling_price_B_standard']
    
    max_supply_D = params['max_supply_D']
    demand_A = params['market_demand_A']
    demand_B = params['market_demand_B']
    min_premium_A = params['min_premium_share_A']
    max_premium_A = params['max_premium_share_A']
    min_premium_B = params['min_premium_share_B']
    max_premium_B = params['max_premium_share_B']
    
    # Create model
    model = gp.Model("Mixing_Problem_Revised")
    model.setParam('OutputFlag', 0)
    
    # Streams: (product, tier) pairs
    streams = [('A', 'Premium'), ('A', 'Standard'), ('B', 'Premium'), ('B', 'Standard')]
    
    # Decision variables: x[m, product, tier] = tons of material m used in stream (product, tier)
    x = {}
    for m in materials:
        for prod, tier in streams:
            x[m, prod, tier] = model.addVar(lb=0, name=f"x_{m}_{prod}_{tier}")
    
    # Total amount of each stream
    total_stream = {}
    for prod, tier in streams:
        total_stream[prod, tier] = gp.quicksum(x[m, prod, tier] for m in materials)
    
    # Total amount of each product family
    total_A = total_stream['A', 'Premium'] + total_stream['A', 'Standard']
    total_B = total_stream['B', 'Premium'] + total_stream['B', 'Standard']
    
    # Objective: maximize profit
    revenue = (price_A_premium * total_stream['A', 'Premium'] +
               price_A_standard * total_stream['A', 'Standard'] +
               price_B_premium * total_stream['B', 'Premium'] +
               price_B_standard * total_stream['B', 'Standard'])
    
    cost = gp.quicksum(purchase_price[m] * (x[m, 'A', 'Premium'] + x[m, 'A', 'Standard'] +
                                            x[m, 'B', 'Premium'] + x[m, 'B', 'Standard'])
                       for m in materials)
    
    model.setObjective(revenue - cost, GRB.MAXIMIZE)
    
    # Sulfur content constraints for each stream
    # Premium A: sum(sulfur[m]*x[m,A,Premium]) <= max_sulfur_A_premium * total_stream[A,Premium]
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'A', 'Premium'] for m in materials) <= 
        max_sulfur_A_premium * total_stream['A', 'Premium'],
        "Sulfur_A_Premium"
    )
    
    # Standard A
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'A', 'Standard'] for m in materials) <= 
        max_sulfur_A_standard * total_stream['A', 'Standard'],
        "Sulfur_A_Standard"
    )
    
    # Premium B
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'B', 'Premium'] for m in materials) <= 
        max_sulfur_B_premium * total_stream['B', 'Premium'],
        "Sulfur_B_Premium"
    )
    
    # Standard B
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'B', 'Standard'] for m in materials) <= 
        max_sulfur_B_standard * total_stream['B', 'Standard'],
        "Sulfur_B_Standard"
    )
    
    # Supply limit for material D
    model.addConstr(
        x['D', 'A', 'Premium'] + x['D', 'A', 'Standard'] + 
        x['D', 'B', 'Premium'] + x['D', 'B', 'Standard'] <= max_supply_D,
        "Supply_D"
    )
    
    # Market demand constraints (product family level)
    model.addConstr(total_A <= demand_A, "Demand_A")
    model.addConstr(total_B <= demand_B, "Demand_B")
    
    # Premium share constraints for product A
    model.addConstr(total_stream['A', 'Premium'] >= min_premium_A, "Min_Premium_A")
    model.addConstr(total_stream['A', 'Premium'] <= max_premium_A, "Max_Premium_A")
    
    # Premium share constraints for product B
    model.addConstr(total_stream['B', 'Premium'] >= min_premium_B, "Min_Premium_B")
    model.addConstr(total_stream['B', 'Premium'] <= max_premium_B, "Max_Premium_B")
    
    # Solve
    model.optimize()
    
    # Print solution details
    print(f"Status: {model.status}")
    
    if model.status == GRB.OPTIMAL:
        for m in materials:
            for prod, tier in streams:
                v = x[m, prod, tier].X
                if v > 1e-6:
                    print(f"  x[{m},{prod},{tier}] = {v:.4f}")
        
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
