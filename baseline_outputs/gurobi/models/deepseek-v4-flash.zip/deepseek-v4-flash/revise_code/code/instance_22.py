import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    t1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    t2 = pd.read_csv(os.path.join(data_dir, 'table_2.csv'))
    t3 = pd.read_csv(os.path.join(data_dir, 'table_3.csv'))
    gp_params = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Merge product data
    df = t1.merge(t2, on='Product').merge(t3, on='Product')
    
    # Parse general parameters
    prod_days = float(gp_params[gp_params['Parameter_Name'] == 'production_days']['Value'].iloc[0])
    a1_watch_threshold = float(gp_params[gp_params['Parameter_Name'] == 'a1_watch_threshold']['Value'].iloc[0])
    a1_deep_service_threshold = float(gp_params[gp_params['Parameter_Name'] == 'a1_deep_service_threshold']['Value'].iloc[0])
    maintenance_penalty_watch = float(gp_params[gp_params['Parameter_Name'] == 'maintenance_penalty_watch']['Value'].iloc[0])
    maintenance_penalty_deep = float(gp_params[gp_params['Parameter_Name'] == 'maintenance_penalty_deep']['Value'].iloc[0])
    a1_quality_release_fee = float(gp_params[gp_params['Parameter_Name'] == 'a1_quality_release_fee']['Value'].iloc[0])
    a1_deep_service_fee = float(gp_params[gp_params['Parameter_Name'] == 'a1_deep_service_fee']['Value'].iloc[0])
    a1_priority_price_lift = float(gp_params[gp_params['Parameter_Name'] == 'a1_priority_price_lift']['Value'].iloc[0])
    
    # Create model
    model = gp.Model("Production_Planning_Revised")
    model.setParam('OutputFlag', 0)
    
    products = df['Product'].tolist()
    
    # Variables
    x = {}  # production quantity
    y = {}  # activation binary
    for _, row in df.iterrows():
        p = row['Product']
        x[p] = model.addVar(lb=0, ub=row['Maximum_Demand'], name=f"x_{p}")
        y[p] = model.addVar(vtype=GRB.BINARY, name=f"y_{p}")
    
    # A1-specific variables for the revised logic
    # z_watch: 1 if A1 production > a1_watch_threshold
    z_watch = model.addVar(vtype=GRB.BINARY, name="z_watch")
    # z_deep: 1 if A1 production > a1_deep_service_threshold
    z_deep = model.addVar(vtype=GRB.BINARY, name="z_deep")
    # x_priority: A1 units above watch threshold that get priority price lift
    x_priority = model.addVar(lb=0, name="x_priority")
    
    # Objective: maximize profit
    profit_terms = []
    for _, row in df.iterrows():
        p = row['Product']
        base_revenue = row['Selling_Price'] * x[p]
        prod_cost = row['Production_Cost'] * x[p]
        activation_cost = row['Activation_Cost'] * y[p]
        profit_terms.append(base_revenue - prod_cost - activation_cost)
    
    # Add A1 priority price lift for units above watch threshold
    profit_terms.append(a1_priority_price_lift * x_priority)
    
    # Subtract quality release fee if watch threshold crossed
    profit_terms.append(-a1_quality_release_fee * z_watch)
    
    # Subtract deep service fee if deep threshold crossed
    profit_terms.append(-a1_deep_service_fee * z_deep)
    
    model.setObjective(gp.quicksum(profit_terms), GRB.MAXIMIZE)
    
    # Constraints
    # All products must be activated (original requirement)
    for p in products:
        model.addConstr(y[p] == 1, name=f"activate_{p}")
    
    # Demand and minimum batch constraints
    for _, row in df.iterrows():
        p = row['Product']
        model.addConstr(x[p] <= row['Maximum_Demand'] * y[p], name=f"demand_{p}")
        model.addConstr(x[p] >= row['Minimum_Batch'] * y[p], name=f"minbatch_{p}")
    
    # Production days constraint (original)
    days_used = gp.quicksum(x[row['Product']] / row['Production_Quota'] for _, row in df.iterrows())
    # Subtract maintenance penalty days if thresholds crossed
    penalty_days = maintenance_penalty_watch * z_watch + maintenance_penalty_deep * z_deep
    model.addConstr(days_used <= prod_days - penalty_days, name="production_days")
    
    # A1 threshold logic
    # z_watch = 1 if x['A1'] > a1_watch_threshold
    M1 = df[df['Product'] == 'A1']['Maximum_Demand'].iloc[0]
    model.addConstr(x['A1'] <= a1_watch_threshold + M1 * z_watch, name="watch_upper")
    model.addConstr(x['A1'] >= a1_watch_threshold * z_watch + 1e-6 * (1 - z_watch), name="watch_lower")
    
    # z_deep = 1 if x['A1'] > a1_deep_service_threshold
    M2 = df[df['Product'] == 'A1']['Maximum_Demand'].iloc[0]
    model.addConstr(x['A1'] <= a1_deep_service_threshold + M2 * z_deep, name="deep_upper")
    model.addConstr(x['A1'] >= a1_deep_service_threshold * z_deep + 1e-6 * (1 - z_deep), name="deep_lower")
    
    # z_deep can only be 1 if z_watch is 1 (deep implies watch)
    model.addConstr(z_deep <= z_watch, name="deep_implies_watch")
    
    # x_priority: units above watch threshold that get price lift
    # x_priority = max(0, x['A1'] - a1_watch_threshold) when z_watch=1, else 0
    model.addConstr(x_priority <= x['A1'] - a1_watch_threshold * z_watch, name="priority_upper")
    model.addConstr(x_priority <= M1 * z_watch, name="priority_bound")
    model.addConstr(x_priority >= x['A1'] - a1_watch_threshold - M1 * (1 - z_watch), name="priority_lower")
    model.addConstr(x_priority >= 0, name="priority_nonneg")
    
    # Optimize
    model.optimize()
    
    if model.Status == GRB.OPTIMAL:
        obj_val = model.ObjVal
    else:
        obj_val = model.objVal
    
    print(f"FINAL_OBJ_VALUE: {round(obj_val, 4)}")

if __name__ == "__main__":
    solve()
