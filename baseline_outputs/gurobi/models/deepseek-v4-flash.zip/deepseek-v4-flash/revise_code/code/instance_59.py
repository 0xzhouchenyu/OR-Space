import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    data = {}
    
    # Load table_1_7.csv
    filepath = os.path.join(base_dir, 'table_1_7.csv')
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        rows = []
        for row in reader:
            rows.append(row)
    data['table'] = rows
    
    # Load general_parameters.csv
    filepath = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            if row:
                params[row[0]] = row[1]
    data['params'] = params
    
    return data

def main():
    data = load_data()
    params = data['params']
    
    # Create model
    model = gp.Model("CandyFactory")
    model.setParam('OutputFlag', 0)
    
    # Raw materials: 0=A, 1=B, 2=C
    # Brands: 0=A, 1=B, 2=C
    raw_materials = ['A', 'B', 'C']
    brands = ['A', 'B', 'C']
    
    # Decision variables: x[i][j] = kg of raw material i used in brand j
    x = {}
    for i in range(3):
        for j in range(3):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    # Total production of each brand
    y = {}
    for j in range(3):
        y[j] = model.addVar(lb=0, name=f"y_{j}")
    
    # Binary variables for setup costs
    z = {}
    for j in range(3):
        z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{j}")
    
    # Binary variable for shared wrapper coordination
    w = model.addVar(vtype=GRB.BINARY, name="shared_wrapper")
    
    # Link total production to raw material usage
    for j in range(3):
        model.addConstr(y[j] == gp.quicksum(x[i, j] for i in range(3)), f"total_prod_{j}")
    
    # Raw material costs
    raw_cost = [2.00, 1.50, 1.00]
    # Processing fees per brand
    proc_fee = [0.50, 0.40, 0.30]
    # Selling prices per brand
    sell_price = [3.40, 2.85, 2.25]
    # Monthly limits for raw materials
    limits = [2000, 2500, 1200]
    # Setup costs
    setup_cost = [300, 500, 200]
    # Shared wrapper fee
    shared_wrapper_fee = 300
    
    # Objective: maximize profit
    revenue = gp.quicksum(sell_price[j] * y[j] for j in range(3))
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in range(3))
    setup_cost_total = gp.quicksum(setup_cost[j] * z[j] for j in range(3))
    shared_wrapper_cost = shared_wrapper_fee * w
    
    model.setObjective(revenue - material_cost - processing_cost - setup_cost_total - shared_wrapper_cost, GRB.MAXIMIZE)
    
    # Raw material supply constraints
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= limits[i], f"raw_limit_{i}")
    
    # Composition constraints (percentage constraints)
    # Raw material A (i=0): >=60% in brand A (j=0), >=15% in brand B (j=1)
    model.addConstr(x[0, 0] >= 0.60 * y[0], "rmA_brandA_min")
    model.addConstr(x[0, 1] >= 0.15 * y[1], "rmA_brandB_min")
    
    # Raw material C (i=2): <=20% in brand A (j=0), <=60% in brand B (j=1), <=50% in brand C (j=2)
    model.addConstr(x[2, 0] <= 0.20 * y[0], "rmC_brandA_max")
    model.addConstr(x[2, 1] <= 0.60 * y[1], "rmC_brandB_max")
    model.addConstr(x[2, 2] <= 0.50 * y[2], "rmC_brandC_max")
    
    # Setup cost constraints: if y[j] > 0 then z[j] = 1
    M = 10000  # Big M
    for j in range(3):
        model.addConstr(y[j] <= M * z[j], f"setup_link_{j}")
    
    # Shared wrapper constraint: if both brand A and B are produced, w = 1
    model.addConstr(w >= z[0] + z[1] - 1, "shared_wrapper_trigger")
    model.addConstr(w <= z[0], "shared_wrapper_upper1")
    model.addConstr(w <= z[1], "shared_wrapper_upper2")
    
    # Optimize
    model.optimize()
    
    # Print results
    print(f"Status: {model.status}")
    for j in range(3):
        print(f"Brand {brands[j]} production: {y[j].x:.2f} kg")
    for i in range(3):
        for j in range(3):
            if x[i, j].x > 0.01:
                print(f"  RM {raw_materials[i]} in Brand {brands[j]}: {x[i, j].x:.2f}")
    
    obj = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj:.1f}")

if __name__ == "__main__":
    main()
