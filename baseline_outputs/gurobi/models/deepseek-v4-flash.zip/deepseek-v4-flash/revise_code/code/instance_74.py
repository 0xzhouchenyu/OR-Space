import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv")) as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    
    # Read precedences
    precedences = []
    with open(os.path.join(data_dir, "table_1.csv")) as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row["Predecessor"].strip(), row["Successor"].strip()))
    
    activities = ["A", "B", "C", "D", "E", "F", "G"]
    dur = {a: int(params[f"activity_{a}_duration"]) for a in activities}
    work_cost = int(params["work_cost_per_day"])
    machine_cost = int(params["machine_rental_cost_per_day"])
    
    # Overtime parameters for activity E
    e_overtime_reduction = int(params["activity_E_overtime_reduction"])
    e_overtime_cost = int(params["activity_E_overtime_cost"])
    e_followup_review_cost = int(params["activity_E_followup_review_cost"])
    
    # Create model
    model = gp.Model("Project_Cost_Minimization")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    S = {a: model.addVar(lb=0, name=f"S_{a}") for a in activities}
    T = model.addVar(lb=0, name="T")
    
    # Binary variable for overtime on activity E
    y = model.addVar(vtype=GRB.BINARY, name="overtime_E")
    
    # Effective duration of activity E
    dur_E_eff = dur["E"] - e_overtime_reduction * y
    
    # Objective: work cost + machine rental cost + overtime cost + follow-up review cost
    # Machine rental period: from start of A to end of B (S_B + dur_B - S_A)
    # But note: if overtime is used, E duration changes, but machine rental period is independent
    obj = (work_cost * T 
           + machine_cost * (S["B"] + dur["B"] - S["A"]) 
           + e_overtime_cost * y 
           + e_followup_review_cost * y)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Precedence constraints
    for pred, succ in precedences:
        if pred == "E":
            model.addConstr(S[succ] >= S[pred] + dur_E_eff)
        else:
            model.addConstr(S[succ] >= S[pred] + dur[pred])
    
    # Project completion constraints
    model.addConstr(T >= S["C"] + dur["C"])
    model.addConstr(T >= S["B"] + dur["B"])
    
    # Optimize
    model.optimize()
    
    # Print result
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
