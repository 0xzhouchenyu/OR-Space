import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'table_1.csv')
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    machine_avail = params['machine_time_available']  # hours
    craftsman_regular_avail = params['craftsman_regular_time_available']  # hours
    craftsman_overtime_avail = params['craftsman_overtime_available']  # hours
    machine_cost = params['machine_time_cost']  # GBP per hour
    craftsman_cost = params['craftsman_time_cost']  # GBP per hour
    craftsman_overtime_cost = params['craftsman_overtime_cost']  # GBP per hour
    rev_X = params['revenue_product_X']  # GBP per batch
    rev_Y = params['revenue_product_Y']  # GBP per batch
    min_X = params['min_batches_product_X']  # batches
    y_qa_threshold = params['product_Y_QA_threshold']  # batches
    y_qa_fee = params['product_Y_QA_fee']  # GBP
    
    # Create model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    X = model.addVar(lb=0, name="X")
    Y = model.addVar(lb=0, name="Y")
    
    # Craftsman hours split into regular and overtime
    craftsman_regular = model.addVar(lb=0, ub=craftsman_regular_avail, name="Craftsman_Regular")
    craftsman_overtime = model.addVar(lb=0, ub=craftsman_overtime_avail, name="Craftsman_Overtime")
    
    # Binary variable for QA fee (1 if Y > threshold)
    z = model.addVar(vtype=GRB.BINARY, name="QA_Fee_Indicator")
    
    # Machine hours constraint
    machine_hours = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0
    model.addConstr(machine_hours <= machine_avail, "Machine_Time_Constraint")
    
    # Craftsman hours constraint (total craftsman time = regular + overtime)
    craftsman_hours = (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0
    model.addConstr(craftsman_hours == craftsman_regular + craftsman_overtime, "Craftsman_Time_Split")
    
    # Regular and overtime bounds are already set via variable ub
    
    # Minimum production of X
    model.addConstr(X >= min_X, "Min_Production_X")
    
    # QA fee logic: if Y > threshold, z = 1; else z = 0
    M = 1000  # Big M
    model.addConstr(Y <= y_qa_threshold + M * z, "QA_Threshold_Upper")
    model.addConstr(Y >= y_qa_threshold + 1e-6 - M * (1 - z), "QA_Threshold_Lower")
    
    # Objective: maximize profit
    revenue = rev_X * X + rev_Y * Y
    machine_cost_total = machine_cost * machine_hours
    craftsman_cost_total = craftsman_cost * craftsman_regular + craftsman_overtime_cost * craftsman_overtime
    qa_cost = y_qa_fee * z
    
    profit = revenue - machine_cost_total - craftsman_cost_total - qa_cost
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    obj_val = model.objVal
    
    print(f"FINAL_OBJ_VALUE: {obj_val:.2f}")

if __name__ == "__main__":
    main()
