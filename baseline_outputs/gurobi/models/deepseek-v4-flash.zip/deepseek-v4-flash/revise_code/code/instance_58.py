import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Extract parameters
    profits = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons'],
    }
    total_area = params['total_farm_area']
    min_a_to_p = params['min_apples_to_pears_ratio']
    min_a_to_l = params['min_apples_to_lemons_ratio']
    o_to_l = params['oranges_to_lemons_ratio']
    max_types = int(params['max_fruit_types'])
    
    water_per_acre = {
        ('apples', 'spring'): params['water_per_acre_apples_spring'],
        ('apples', 'autumn'): params['water_per_acre_apples_autumn'],
        ('pears', 'spring'): params['water_per_acre_pears_spring'],
        ('pears', 'autumn'): params['water_per_acre_pears_autumn'],
        ('oranges', 'spring'): params['water_per_acre_oranges_spring'],
        ('oranges', 'autumn'): params['water_per_acre_oranges_autumn'],
        ('lemons', 'spring'): params['water_per_acre_lemons_spring'],
        ('lemons', 'autumn'): params['water_per_acre_lemons_autumn'],
    }
    water_cap_spring = params['water_cap_spring']
    water_cap_autumn = params['water_cap_autumn']
    total_water_budget = params['total_water_budget']
    min_annual_water = params['min_annual_water_per_fruit']
    diversification_reward = params['diversification_reward']

    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']

    # Create model
    model = gp.Model("farm_revised")
    model.setParam('OutputFlag', 0)

    # Decision variables: acres for each fruit in each season
    x = {}
    for f in fruits:
        for s in seasons:
            x[f, s] = model.addVar(lb=0, name=f"x_{f}_{s}")

    # Binary variables: whether a fruit is grown (annual total > 0)
    y = {}
    for f in fruits:
        y[f] = model.addVar(vtype=GRB.BINARY, name=f"y_{f}")

    # Binary variable for diversification reward (at least 2 fruits)
    z = model.addVar(vtype=GRB.BINARY, name="diversification")

    # Objective: maximize profit + diversification reward
    profit_expr = gp.quicksum(profits[f] * (x[f, 'spring'] + x[f, 'autumn']) for f in fruits)
    model.setObjective(profit_expr + diversification_reward * z, GRB.MAXIMIZE)

    # Seasonal land constraints
    for s in seasons:
        model.addConstr(gp.quicksum(x[f, s] for f in fruits) <= total_area, f"land_{s}")

    # Annual mix constraints (summed over both seasons)
    total_apples = x['apples', 'spring'] + x['apples', 'autumn']
    total_pears = x['pears', 'spring'] + x['pears', 'autumn']
    total_oranges = x['oranges', 'spring'] + x['oranges', 'autumn']
    total_lemons = x['lemons', 'spring'] + x['lemons', 'autumn']

    model.addConstr(total_apples >= min_a_to_p * total_pears, "apples_pears_ratio")
    model.addConstr(total_apples >= min_a_to_l * total_lemons, "apples_lemons_ratio")
    model.addConstr(total_oranges == o_to_l * total_lemons, "oranges_lemons_ratio")

    # Seasonal water constraints
    spring_water = gp.quicksum(water_per_acre[f, 'spring'] * x[f, 'spring'] for f in fruits)
    autumn_water = gp.quicksum(water_per_acre[f, 'autumn'] * x[f, 'autumn'] for f in fruits)
    model.addConstr(spring_water <= water_cap_spring, "water_spring")
    model.addConstr(autumn_water <= water_cap_autumn, "water_autumn")
    model.addConstr(spring_water + autumn_water <= total_water_budget, "total_water")

    # Link binary y to annual acreage (big-M formulation)
    M = total_area * 2  # maximum possible acres for any fruit
    for f in fruits:
        total_fruit = x[f, 'spring'] + x[f, 'autumn']
        model.addConstr(total_fruit <= M * y[f], f"link_y_{f}")
        # If y[f]=0, then total_fruit must be 0 (already enforced by <= M*y)
        # But we also need: if total_fruit > 0 then y[f]=1
        model.addConstr(total_fruit >= 1e-6 * y[f], f"link_y_pos_{f}")  # small epsilon

    # Minimum annual water per fruit that is grown
    annual_water_fruit = {}
    for f in fruits:
        annual_water_fruit[f] = gp.quicksum(water_per_acre[f, s] * x[f, s] for s in seasons)
        model.addConstr(annual_water_fruit[f] >= min_annual_water * y[f], f"min_water_{f}")

    # Max fruit types constraint
    model.addConstr(gp.quicksum(y[f] for f in fruits) <= max_types, "max_types")

    # Diversification reward: at least 2 fruits grown
    model.addConstr(gp.quicksum(y[f] for f in fruits) >= 2 * z, "diversification_link")

    # Optimize
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No feasible solution found")

if __name__ == "__main__":
    solve()
