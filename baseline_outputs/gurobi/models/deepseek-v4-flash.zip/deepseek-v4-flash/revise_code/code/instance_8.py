import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read table_1.csv
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    workers = []
    tasks = []
    cost = {}
    fixed_cost = {}
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        tasks = header[1:-1]  # A, B, C, D (exclude Fixed_Cost)
        
        for row in reader:
            worker = row[0].strip()
            workers.append(worker)
            for j, task in enumerate(tasks):
                cost[(worker, task)] = int(row[j + 1])
            fixed_cost[worker] = int(row[-1])
    
    # Read general_parameters.csv for handoff costs
    param_file = os.path.join(data_dir, 'general_parameters.csv')
    handoff_cost_III_V = 0
    pair_fee_II_V = 0
    
    with open(param_file, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            if row[0].strip() == 'shared_temp_handoff_cost':
                handoff_cost_III_V = int(row[1])
            elif row[0].strip() == 'worker_II_V_pair_fee':
                pair_fee_II_V = int(row[1])
    
    # Create model
    model = gp.Model("RevisedAssignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[w, t] = 1 if worker w assigned to task t
    x = {}
    for w in workers:
        for t in tasks:
            x[(w, t)] = model.addVar(vtype=GRB.BINARY, name=f"x_{w}_{t}")
    
    # y[w] = 1 if worker w is selected (assigned to any task)
    y = {}
    for w in workers:
        y[w] = model.addVar(vtype=GRB.BINARY, name=f"y_{w}")
    
    # z_III_V = 1 if both workers III and V are selected
    z_III_V = model.addVar(vtype=GRB.BINARY, name="z_III_V")
    
    # z_II_V = 1 if both workers II and V are selected
    z_II_V = model.addVar(vtype=GRB.BINARY, name="z_II_V")
    
    # Objective: minimize total time + fixed costs + handoff costs
    obj = gp.LinExpr()
    # Task assignment costs
    for w in workers:
        for t in tasks:
            obj += cost[(w, t)] * x[(w, t)]
    # Fixed costs for selected workers
    for w in workers:
        obj += fixed_cost[w] * y[w]
    # Handoff cost for III and V together
    obj += handoff_cost_III_V * z_III_V
    # Pair fee for II and V together
    obj += pair_fee_II_V * z_II_V
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    # Each task assigned to exactly one worker
    for t in tasks:
        model.addConstr(gp.quicksum(x[(w, t)] for w in workers) == 1, f"task_{t}")
    
    # Each worker assigned to at most one task
    for w in workers:
        model.addConstr(gp.quicksum(x[(w, t)] for t in tasks) <= 1, f"worker_{w}")
    
    # Link x and y: y[w] = 1 if worker w is assigned any task
    for w in workers:
        model.addConstr(y[w] == gp.quicksum(x[(w, t)] for t in tasks), f"link_{w}")
    
    # Exactly 4 workers selected (since 4 tasks)
    model.addConstr(gp.quicksum(y[w] for w in workers) == 4, "four_workers")
    
    # z_III_V = 1 if both III and V are selected
    model.addConstr(z_III_V >= y["III"] + y["V"] - 1, "III_V_and")
    model.addConstr(z_III_V <= y["III"], "III_V_ub1")
    model.addConstr(z_III_V <= y["V"], "III_V_ub2")
    
    # z_II_V = 1 if both II and V are selected
    model.addConstr(z_II_V >= y["II"] + y["V"] - 1, "II_V_and")
    model.addConstr(z_II_V <= y["II"], "II_V_ub1")
    model.addConstr(z_II_V <= y["V"], "II_V_ub2")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
