import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    
    # Read product segments and profits
    products = []
    segments = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row["Product"]
            if p not in segments:
                segments[p] = []
                products.append(p)
            rng = row["Sales_Volume_Range"]
            profit = float(row["Profit"])
            if rng.startswith("Above_"):
                lower = float(rng.split("_")[1])
                upper = None
            else:
                parts = rng.split("_")
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({"lower": lower, "upper": upper, "profit": profit})
    
    # Create model
    model = gp.Model("Maximize_Profit")
    model.setParam('OutputFlag', 0)
    
    M = 10000  # Big-M constant
    
    # Decision variables
    x = {}
    p_var = {}
    y = {}
    
    for prod in products:
        pname = prod.split("_")[1]
        x[prod] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{pname}")
        p_var[prod] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"p_{pname}")
        y[prod] = []
        for i in range(len(segments[prod])):
            yi = model.addVar(vtype=GRB.BINARY, name=f"y_{pname}_{i}")
            y[prod].append(yi)
    
    # Overtime variables
    overtime_hours = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=params["overtime_cap_hours"], name="overtime_hours")
    overtime_cost = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="overtime_cost")
    second_review_burden = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="second_review_burden")
    z_second_review = model.addVar(vtype=GRB.BINARY, name="z_second_review")
    
    # Objective: maximize profit from products minus overtime costs and second review burden
    model.setObjective(
        gp.quicksum(p_var[prod] for prod in products) - overtime_cost - second_review_burden,
        GRB.MAXIMIZE
    )
    
    # Product segment constraints
    for prod in products:
        segs = segments[prod]
        # Mutual exclusivity: at most one segment active
        model.addConstr(gp.quicksum(y[prod]) <= 1)
        
        for i, seg in enumerate(segs):
            lo = seg["lower"]
            hi = seg["upper"]
            profit = seg["profit"]
            
            # If y[i]=1, x must be in [lo+1, hi] (or [lo+1, inf] for last segment)
            if lo == 0:
                model.addConstr(x[prod] >= 1 - M * (1 - y[prod][i]))
            else:
                model.addConstr(x[prod] >= (lo + 1) - M * (1 - y[prod][i]))
            
            if hi is not None:
                model.addConstr(x[prod] <= hi + M * (1 - y[prod][i]))
            
            # Profit bound
            model.addConstr(p_var[prod] <= profit * x[prod] + M * (1 - y[prod][i]))
        
        # If no segment active (production=0), force x=0 and profit=0
        model.addConstr(x[prod] <= M * gp.quicksum(y[prod]))
        model.addConstr(p_var[prod] <= M * gp.quicksum(y[prod]))
    
    # Resource constraints (regular labor time is 700, overtime is additional)
    model.addConstr(
        params["technical_prep_time_A"] * x["Product_A"] +
        params["technical_prep_time_B"] * x["Product_B"] +
        params["technical_prep_time_C"] * x["Product_C"] <= params["available_technical_prep_time"]
    )
    
    model.addConstr(
        params["labor_time_A"] * x["Product_A"] +
        params["labor_time_B"] * x["Product_B"] +
        params["labor_time_C"] * x["Product_C"] <= params["available_labor_time"] + overtime_hours
    )
    
    model.addConstr(
        params["materials_A"] * x["Product_A"] +
        params["materials_B"] * x["Product_B"] +
        params["materials_C"] * x["Product_C"] <= params["available_materials"]
    )
    
    # Packaging constraint
    model.addConstr(
        params["pack_units_A"] * x["Product_A"] +
        params["pack_units_B"] * x["Product_B"] +
        params["pack_units_C"] * x["Product_C"] <= params["packaging_cap_units"]
    )
    
    # Overtime cost
    model.addConstr(overtime_cost == params["overtime_cost_per_hour"] * overtime_hours)
    
    # Second review burden: if overtime > 100 hours, add 10-unit burden
    threshold = params["overtime_second_review_threshold"]
    fee = params["overtime_second_review_fee"]
    
    model.addConstr(overtime_hours <= threshold + M * z_second_review)
    model.addConstr(overtime_hours >= threshold + 1 - M * (1 - z_second_review))
    model.addConstr(second_review_burden == fee * z_second_review)
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj = model.objVal
    if obj is not None:
        print(f"FINAL_OBJ_VALUE: {round(obj, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
