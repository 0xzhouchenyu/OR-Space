import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Get data paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    
    # Read data
    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    # Parse parameters
    params = {}
    for _, row in df_params.iterrows():
        params[row['Parameter_Name']] = row['Value']
    
    # Supplier 1 parameters
    L1 = float(params['raw_pipe_length_supplier1'])
    max_patterns1 = int(params['max_cutting_patterns_supplier1'])
    max_cuts1 = int(params['max_cuts_per_pipe_supplier1'])
    max_leftover1 = float(params['max_leftover_length_supplier1'])
    min_length1 = L1 - max_leftover1
    cost1 = float(params['purchase_cost_per_pipe_supplier1'])
    
    # Supplier 2 parameters
    L2 = float(params['raw_pipe_length_supplier2'])
    max_patterns2 = int(params['max_cutting_patterns_supplier2'])
    max_cuts2 = int(params['max_cuts_per_pipe_supplier2'])
    max_leftover2 = float(params['max_leftover_length_supplier2'])
    min_length2 = L2 - max_leftover2
    cost2 = float(params['purchase_cost_per_pipe_supplier2'])
    
    # Discount parameters for supplier 1
    discount_tier1_qty = int(params['discount_tier1_supplier1_max_qty'])
    fixed_discount = float(params['fixed_discount_tier2_supplier1'])
    bigM = int(params['bigM_discount'])
    
    # Cost rates for pattern ranking
    cost_rates1 = [
        float(params['most_frequent_pattern_cost_rate_supplier1']),
        float(params['second_frequent_pattern_cost_rate_supplier1']),
        float(params['third_frequent_pattern_cost_rate_supplier1'])
    ]
    cost_rates2 = [
        float(params['most_frequent_pattern_cost_rate_supplier2']),
        float(params['second_frequent_pattern_cost_rate_supplier2']),
        float(params['third_frequent_pattern_cost_rate_supplier2'])
    ]
    
    # Item data
    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)
    
    # Generate patterns for supplier 1
    patterns1 = []
    def generate_patterns1(current_pattern, current_length, current_cuts, item_idx):
        if item_idx == n_items:
            if current_length >= min_length1 and current_length <= L1 and current_cuts > 0:
                patterns1.append(tuple(current_pattern))
            return
        max_qty = min(
            int((L1 - current_length) // lengths[item_idx]),
            max_cuts1 - current_cuts
        )
        for q in range(max_qty + 1):
            generate_patterns1(
                current_pattern + [q],
                current_length + q * lengths[item_idx],
                current_cuts + q,
                item_idx + 1
            )
    generate_patterns1([], 0, 0, 0)
    
    # Generate patterns for supplier 2
    patterns2 = []
    def generate_patterns2(current_pattern, current_length, current_cuts, item_idx):
        if item_idx == n_items:
            if current_length >= min_length2 and current_length <= L2 and current_cuts > 0:
                patterns2.append(tuple(current_pattern))
            return
        max_qty = min(
            int((L2 - current_length) // lengths[item_idx]),
            max_cuts2 - current_cuts
        )
        for q in range(max_qty + 1):
            generate_patterns2(
                current_pattern + [q],
                current_length + q * lengths[item_idx],
                current_cuts + q,
                item_idx + 1
            )
    generate_patterns2([], 0, 0, 0)
    
    # Create model
    model = gp.Model("Pipe_Cutting_Two_Suppliers")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # y1[p] = number of pipes from supplier 1 using pattern p
    y1 = model.addVars(len(patterns1), vtype=GRB.INTEGER, lb=0, name="y1")
    # y2[p] = number of pipes from supplier 2 using pattern p
    y2 = model.addVars(len(patterns2), vtype=GRB.INTEGER, lb=0, name="y2")
    
    # z1[p] = 1 if pattern p is used for supplier 1
    z1 = model.addVars(len(patterns1), vtype=GRB.BINARY, name="z1")
    # z2[p] = 1 if pattern p is used for supplier 2
    z2 = model.addVars(len(patterns2), vtype=GRB.BINARY, name="z2")
    
    # Ranking variables for supplier 1
    u1 = model.addVars(range(1, max_patterns1 + 1), vtype=GRB.BINARY, name="u1")
    # Ranking variables for supplier 2
    u2 = model.addVars(range(1, max_patterns2 + 1), vtype=GRB.BINARY, name="u2")
    
    # Discount activation variable for supplier 1
    d = model.addVar(vtype=GRB.BINARY, name="discount_activation")
    
    # Total pipes from each supplier
    total_pipes1 = model.addVar(vtype=GRB.INTEGER, lb=0, name="total_pipes1")
    total_pipes2 = model.addVar(vtype=GRB.INTEGER, lb=0, name="total_pipes2")
    
    # Objective: minimize total cost
    # Purchase cost + pattern ranking costs - discount
    purchase_cost = cost1 * total_pipes1 + cost2 * total_pipes2
    
    # Pattern ranking costs for supplier 1
    pattern_rank_cost1 = gp.quicksum(cost_rates1[k-1] * u1[k] for k in range(1, max_patterns1 + 1) if k-1 < len(cost_rates1))
    
    # Pattern ranking costs for supplier 2
    pattern_rank_cost2 = gp.quicksum(cost_rates2[k-1] * u2[k] for k in range(1, max_patterns2 + 1) if k-1 < len(cost_rates2))
    
    model.setObjective(purchase_cost + pattern_rank_cost1 + pattern_rank_cost2 - fixed_discount * d, GRB.MINIMIZE)
    
    # Constraints
    
    # Total pipes calculation
    model.addConstr(total_pipes1 == gp.quicksum(y1[p] for p in range(len(patterns1))), "total_pipes1_def")
    model.addConstr(total_pipes2 == gp.quicksum(y2[p] for p in range(len(patterns2))), "total_pipes2_def")
    
    # Demand satisfaction (combined from both suppliers)
    for i in range(n_items):
        model.addConstr(
            gp.quicksum(patterns1[p][i] * y1[p] for p in range(len(patterns1))) +
            gp.quicksum(patterns2[p][i] * y2[p] for p in range(len(patterns2))) >= demands[i],
            f"demand_{i}"
        )
    
    # Big-M constraints linking y and z for supplier 1
    M1 = sum(demands) * 2  # Safe upper bound
    for p in range(len(patterns1)):
        model.addConstr(y1[p] <= M1 * z1[p], f"link_y1_z1_{p}")
    
    # Big-M constraints linking y and z for supplier 2
    for p in range(len(patterns2)):
        model.addConstr(y2[p] <= M1 * z2[p], f"link_y2_z2_{p}")
    
    # Number of used patterns equals number of ranking slots used for supplier 1
    model.addConstr(
        gp.quicksum(z1[p] for p in range(len(patterns1))) == gp.quicksum(u1[k] for k in range(1, max_patterns1 + 1)),
        "pattern_count_supplier1"
    )
    
    # Number of used patterns equals number of ranking slots used for supplier 2
    model.addConstr(
        gp.quicksum(z2[p] for p in range(len(patterns2))) == gp.quicksum(u2[k] for k in range(1, max_patterns2 + 1)),
        "pattern_count_supplier2"
    )
    
    # Ranking ordering constraints for supplier 1
    for k in range(1, max_patterns1):
        model.addConstr(u1[k] >= u1[k+1], f"ranking_order_s1_{k}")
    
    # Ranking ordering constraints for supplier 2
    for k in range(1, max_patterns2):
        model.addConstr(u2[k] >= u2[k+1], f"ranking_order_s2_{k}")
    
    # Max patterns constraints
    model.addConstr(gp.quicksum(z1[p] for p in range(len(patterns1))) <= max_patterns1, "max_patterns_s1")
    model.addConstr(gp.quicksum(z2[p] for p in range(len(patterns2))) <= max_patterns2, "max_patterns_s2")
    
    # Discount tier constraint for supplier 1
    model.addConstr(total_pipes1 <= discount_tier1_qty + bigM * (1 - d), "discount_tier1_upper")
    model.addConstr(total_pipes1 >= discount_tier1_qty + 1 - bigM * d, "discount_tier1_lower")
    
    # Optimize
    model.optimize()
    
    # Print result
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
