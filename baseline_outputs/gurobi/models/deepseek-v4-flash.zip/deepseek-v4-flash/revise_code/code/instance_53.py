import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read costs from table_1.csv
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row['Child'].strip()
            costs[child] = {
                'budget': float(row['Cost_budget'].strip()),
                'balanced': float(row['Cost_balanced'].strip()),
                'premium': float(row['Cost_premium'].strip())
            }
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children = int(params['max_children'])
    min_children = int(params['min_children'])
    fairness_penalty = float(params['fairness_penalty'])
    max_total_cost = float(params['max_total_cost'])
    min_children_per_mode = int(params['min_children_per_mode'])
    
    children = list(costs.keys())
    modes = ['budget', 'balanced', 'premium']
    
    # Create model
    model = gp.Model("ZhangFamilyTrip")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}  # x[child] = 1 if child is selected
    for child in children:
        x[child] = model.addVar(vtype=GRB.BINARY, name=f"x_{child}")
    
    y = {}  # y[mode] = 1 if mode is selected
    for mode in modes:
        y[mode] = model.addVar(vtype=GRB.BINARY, name=f"y_{mode}")
    
    # Auxiliary variables for fairness calculation
    max_cost = model.addVar(vtype=GRB.CONTINUOUS, name="max_cost")
    min_cost = model.addVar(vtype=GRB.CONTINUOUS, name="min_cost")
    cost_spread = model.addVar(vtype=GRB.CONTINUOUS, name="cost_spread")
    
    # Total cost variable (actual spend)
    total_cost = model.addVar(vtype=GRB.CONTINUOUS, name="total_cost")
    
    # Objective: minimize total_cost + fairness_penalty * cost_spread
    model.setObjective(total_cost + fairness_penalty * cost_spread, GRB.MINIMIZE)
    
    # Constraint: Ginny must go
    model.addConstr(x['Ginny'] == 1, "Ginny_must_go")
    
    # Constraint: at most max_children
    model.addConstr(gp.quicksum(x[child] for child in children) <= max_children, "Max_children")
    
    # Constraint: at least min_children
    model.addConstr(gp.quicksum(x[child] for child in children) >= min_children, "Min_children")
    
    # If Harry is taken, Fred cannot be taken
    model.addConstr(x['Harry'] + x['Fred'] <= 1, "Harry_no_Fred")
    
    # If Harry is taken, George cannot be taken
    model.addConstr(x['Harry'] + x['George'] <= 1, "Harry_no_George")
    
    # If George is taken, Fred must also be taken
    model.addConstr(x['George'] <= x['Fred'], "George_requires_Fred")
    
    # If George is taken, Hermione must also be taken
    model.addConstr(x['George'] <= x['Hermione'], "George_requires_Hermione")
    
    # Exactly one mode must be selected
    model.addConstr(gp.quicksum(y[mode] for mode in modes) == 1, "One_mode")
    
    # Mode-dependent constraints on number of children
    # For balanced and premium modes, need at least min_children_per_mode children
    for mode in ['balanced', 'premium']:
        model.addConstr(gp.quicksum(x[child] for child in children) >= min_children_per_mode * y[mode], 
                       f"Min_children_{mode}")
    
    # Link total cost to mode and selected children
    # total_cost = sum over children of (cost_budget * y_budget + cost_balanced * y_balanced + cost_premium * y_premium) * x_child
    # Linearize: for each child, create auxiliary variable for cost contribution
    child_cost = {}
    for child in children:
        child_cost[child] = model.addVar(vtype=GRB.CONTINUOUS, name=f"child_cost_{child}")
        # child_cost = x_child * (cost_budget * y_budget + cost_balanced * y_balanced + cost_premium * y_premium)
        # Linearize using big-M approach
        max_possible_cost = max(costs[child][mode] for mode in modes)
        # child_cost <= costs[child][mode] * y_mode + max_possible_cost * (1 - y_mode) for each mode
        # Actually, we need: child_cost = sum_mode costs[child][mode] * (x_child AND y_mode)
        # Use auxiliary variables z[child][mode] = x_child AND y_mode
        z = {}
        for mode in modes:
            z[(child, mode)] = model.addVar(vtype=GRB.BINARY, name=f"z_{child}_{mode}")
            model.addConstr(z[(child, mode)] <= x[child], f"z_{child}_{mode}_le_x")
            model.addConstr(z[(child, mode)] <= y[mode], f"z_{child}_{mode}_le_y")
            model.addConstr(z[(child, mode)] >= x[child] + y[mode] - 1, f"z_{child}_{mode}_ge")
        
        model.addConstr(child_cost[child] == gp.quicksum(costs[child][mode] * z[(child, mode)] for mode in modes),
                       f"child_cost_eq_{child}")
    
    model.addConstr(total_cost == gp.quicksum(child_cost[child] for child in children), "Total_cost_eq")
    
    # Max total cost constraint
    model.addConstr(total_cost <= max_total_cost, "Max_total_cost")
    
    # Fairness: max_cost and min_cost
    # max_cost >= child_cost[child] for all selected children
    for child in children:
        model.addConstr(max_cost >= child_cost[child], f"max_cost_{child}")
        model.addConstr(min_cost <= child_cost[child] + max_total_cost * (1 - x[child]), f"min_cost_{child}")
    
    # If no children selected (shouldn't happen due to min constraints), set min_cost to 0
    # But we have at least 3 children, so this is fine
    
    # cost_spread = max_cost - min_cost
    model.addConstr(cost_spread == max_cost - min_cost, "cost_spread_eq")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    
    # Print exactly one line
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
