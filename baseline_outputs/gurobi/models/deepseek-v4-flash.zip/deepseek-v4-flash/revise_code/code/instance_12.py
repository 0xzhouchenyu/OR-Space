import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load container data
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    
    fixed_setup_cost = params['fixed_setup_cost']
    energy_cost_per_kwh = params['energy_cost_per_kwh']
    max_total_energy = params['max_total_energy_kwh']
    eco_capacity_share = params['eco_capacity_share']
    eco_overhead_cost = params['eco_overhead_cost']
    regular_energy_intensity = params['regular_energy_intensity_kwh_per_unit']
    eco_energy_intensity = params['eco_energy_intensity_kwh_per_unit']
    
    n = len(containers)
    
    # Create model
    model = gp.Model("PlasticContainers")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # y[i] = 1 if container type i is produced in regular mode
    y = {}
    for i in range(n):
        y[i] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}")
    
    # z[i] = 1 if container type i is produced in eco mode
    z = {}
    for i in range(n):
        z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{i}")
    
    # x_reg[i][j] = units of type i produced in regular mode to fulfill demand of type j
    # x_eco[i][j] = units of type i produced in eco mode to fulfill demand of type j
    x_reg = {}
    x_eco = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x_reg[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_reg_{i}_{j}")
                x_eco[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_eco_{i}_{j}")
    
    # Objective: minimize total cost
    # Variable production costs
    var_cost = gp.quicksum(
        containers[i]['cost'] * (x_reg[i, j] + x_eco[i, j])
        for i in range(n) for j in range(n) if (i, j) in x_reg
    )
    
    # Fixed setup costs for regular mode
    setup_cost = fixed_setup_cost * gp.quicksum(y[i] for i in range(n))
    
    # Eco overhead costs
    eco_cost = eco_overhead_cost * gp.quicksum(z[i] for i in range(n))
    
    # Energy costs
    energy_cost = energy_cost_per_kwh * gp.quicksum(
        regular_energy_intensity * x_reg[i, j] + eco_energy_intensity * x_eco[i, j]
        for i in range(n) for j in range(n) if (i, j) in x_reg
    )
    
    model.setObjective(var_cost + setup_cost + eco_cost + energy_cost, GRB.MINIMIZE)
    
    # Demand constraints: for each type j, total supplied >= demand[j]
    for j in range(n):
        model.addConstr(
            gp.quicksum(x_reg[i, j] + x_eco[i, j] for i in range(n) if (i, j) in x_reg) >= containers[j]['demand'],
            name=f"demand_{j}"
        )
    
    # Linking constraints for regular mode
    M = sum(c['demand'] for c in containers)
    for i in range(n):
        total_reg_i = gp.quicksum(x_reg[i, j] for j in range(n) if (i, j) in x_reg)
        model.addConstr(total_reg_i <= M * y[i], name=f"setup_reg_{i}")
    
    # Linking constraints for eco mode
    for i in range(n):
        total_eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(total_eco_i <= M * z[i], name=f"setup_eco_{i}")
    
    # Eco capacity share constraint: eco production <= eco_capacity_share * total production for each type
    for i in range(n):
        total_i = gp.quicksum(x_reg[i, j] + x_eco[i, j] for j in range(n) if (i, j) in x_reg)
        eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(eco_i <= eco_capacity_share * total_i, name=f"eco_share_{i}")
    
    # Total energy constraint
    total_energy = gp.quicksum(
        regular_energy_intensity * x_reg[i, j] + eco_energy_intensity * x_eco[i, j]
        for i in range(n) for j in range(n) if (i, j) in x_reg
    )
    model.addConstr(total_energy <= max_total_energy, name="max_energy")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    
    # Print solution details (optional, but keep for consistency)
    for i in range(n):
        total_reg = sum(x_reg[i, j].X for j in range(n) if (i, j) in x_reg)
        total_eco = sum(x_eco[i, j].X for j in range(n) if (i, j) in x_eco)
        total_prod = total_reg + total_eco
        if total_prod > 0:
            print(f"Container type {containers[i]['code']}: produce {total_prod:.0f} (reg={total_reg:.0f}, eco={total_eco:.0f}), "
                  f"setup_reg={'Yes' if y[i].X > 0.5 else 'No'}, setup_eco={'Yes' if z[i].X > 0.5 else 'No'}")
    
    print(f"FINAL_OBJ_VALUE: {obj_val:.2f}")

if __name__ == "__main__":
    main()
