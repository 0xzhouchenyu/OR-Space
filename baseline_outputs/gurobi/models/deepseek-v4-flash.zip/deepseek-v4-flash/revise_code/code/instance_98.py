import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Extract parameters
    available_steel = params['available_steel']
    available_aluminum = params['available_aluminum']
    available_labor = params['available_labor']
    overtime_pay = params['overtime_pay']
    max_overtime = params['max_overtime']
    overtime_review_threshold = params['overtime_review_threshold']
    overtime_review_fee = params['overtime_review_fee']
    line_audit_threshold = params['product_A_line_audit_threshold']
    line_audit_fee = params['product_A_line_audit_fee']
    
    # Create model
    model = gp.Model("Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_A = model.addVar(lb=0, name="x_A")
    x_B = model.addVar(lb=0, name="x_B")
    
    # Overtime variable (continuous)
    overtime = model.addVar(lb=0, ub=max_overtime, name="overtime")
    
    # Binary variable for overtime review fee (1 if overtime > threshold)
    z_overtime = model.addVar(vtype=GRB.BINARY, name="z_overtime")
    
    # Binary variable for line audit fee (1 if x_A > threshold)
    z_audit = model.addVar(vtype=GRB.BINARY, name="z_audit")
    
    # Big-M values
    M_overtime = max_overtime + 1
    M_audit = 100  # sufficiently large for production of A
    
    # Update model to add variables
    model.update()
    
    # Objective: maximize profit - setup costs - overtime costs - review fees - audit fees
    profit_A = 5000
    profit_B = 11000
    setup_A = 15000
    setup_B = 20000
    
    # Setup costs are incurred if product is produced (positive quantity)
    # We need binary variables for setup
    y_A = model.addVar(vtype=GRB.BINARY, name="y_A")
    y_B = model.addVar(vtype=GRB.BINARY, name="y_B")
    model.update()
    
    # Big-M for setup
    M_setup = 100  # large enough
    
    # Setup constraints: if x > 0 then y = 1
    model.addConstr(x_A <= M_setup * y_A, "setup_A_constr")
    model.addConstr(x_B <= M_setup * y_B, "setup_B_constr")
    
    # Objective
    obj = (profit_A * x_A + profit_B * x_B 
           - setup_A * y_A - setup_B * y_B
           - overtime_pay * overtime 
           - overtime_review_fee * z_overtime 
           - line_audit_fee * z_audit)
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Resource constraints
    # Steel: 6*A + 12*B <= 200
    model.addConstr(6 * x_A + 12 * x_B <= available_steel, "steel")
    
    # Aluminum: 8*A + 20*B <= 300
    model.addConstr(8 * x_A + 20 * x_B <= available_aluminum, "aluminum")
    
    # Labor: 11*A + 24*B <= 300 + overtime
    model.addConstr(11 * x_A + 24 * x_B <= available_labor + overtime, "labor")
    
    # Overtime review fee trigger: if overtime > 20 then z_overtime = 1
    model.addConstr(overtime <= overtime_review_threshold + M_overtime * z_overtime, "overtime_review_1")
    model.addConstr(overtime >= overtime_review_threshold + 0.001 - M_overtime * (1 - z_overtime), "overtime_review_2")
    
    # Line audit fee trigger: if x_A > 29 then z_audit = 1
    model.addConstr(x_A <= line_audit_threshold + M_audit * z_audit, "line_audit_1")
    model.addConstr(x_A >= line_audit_threshold + 0.001 - M_audit * (1 - z_audit), "line_audit_2")
    
    # Optimize
    model.optimize()
    
    # Get results
    obj_val = model.objVal
    
    # Print results
    print(f"A: {x_A.X}")
    print(f"B: {x_B.X}")
    print(f"Overtime: {overtime.X}")
    print(f"Overtime review fee triggered: {z_overtime.X}")
    print(f"Line audit fee triggered: {z_audit.X}")
    print(f"Setup A: {y_A.X}, Setup B: {y_B.X}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
