import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_df = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    demand_df = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    
    param_dict = dict(zip(params_df["Parameter_Name"], params_df["Value"]))
    demand = dict(zip(demand_df["stage"], demand_df["tool_requirement"]))
    
    # Extract parameters
    n = int(param_dict["n"])
    cost_new = float(param_dict["cost_new_tool"])
    cost_slow = float(param_dict["cost_slow_repair"])
    cost_fast = float(param_dict["cost_fast_repair"])
    dur_slow = int(param_dict["slow_repair_duration"])
    dur_fast = int(param_dict["fast_repair_duration"])
    max_fast = int(param_dict["max_fast_stage"])
    max_slow = int(param_dict["max_slow_stage"])
    em_buy = float(param_dict["emission_buy"])
    em_fast = float(param_dict["emission_fast_repair"])
    em_slow = float(param_dict["emission_slow_repair"])
    carbon_budget = float(param_dict["carbon_budget"])
    penalty_shortage = float(param_dict["penalty_shortage"])
    
    stages = list(range(1, n + 1))
    
    # Create model
    model = gp.Model("Tool_Repair_Problem")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = model.addVars(stages, vtype=GRB.INTEGER, lb=0, name="buy")
    fast = model.addVars(stages, vtype=GRB.INTEGER, lb=0, name="fast")
    slow = model.addVars(stages, vtype=GRB.INTEGER, lb=0, name="slow")
    clean = model.addVars(range(0, n+1), vtype=GRB.INTEGER, lb=0, name="clean")
    dirty = model.addVars(range(0, n+1), vtype=GRB.INTEGER, lb=0, name="dirty")
    shortage = model.addVars(stages, vtype=GRB.INTEGER, lb=0, name="shortage")
    
    # Prebuy at stage 0 (initial clean stock)
    prebuy = model.addVar(vtype=GRB.INTEGER, lb=0, name="prebuy")
    
    # Initial conditions
    model.addConstr(clean[0] == prebuy, "initial_clean")
    model.addConstr(dirty[0] == 0, "initial_dirty")
    
    # Flow balance constraints
    for i in stages:
        # Tools returning from repair
        fast_return = fast[i - dur_fast] if i - dur_fast >= 1 else 0
        slow_return = slow[i - dur_slow] if i - dur_slow >= 1 else 0
        
        # Clean balance: available = previous clean + new purchases + returned repairs
        # Used = demand - shortage + ending clean
        model.addConstr(
            clean[i-1] + buy[i] + fast_return + slow_return == 
            demand[i] - shortage[i] + clean[i],
            f"clean_balance_{i}"
        )
        
        # Dirty balance: used tools + previous dirty = sent to repair + ending dirty
        model.addConstr(
            (demand[i] - shortage[i]) + dirty[i-1] == fast[i] + slow[i] + dirty[i],
            f"dirty_balance_{i}"
        )
        
        # Repair capacity constraints
        model.addConstr(fast[i] <= max_fast, f"max_fast_{i}")
        model.addConstr(slow[i] <= max_slow, f"max_slow_{i}")
        
        # Shortage cannot exceed demand
        model.addConstr(shortage[i] <= demand[i], f"shortage_limit_{i}")
    
    # Carbon budget constraint
    carbon_usage = (
        em_buy * (prebuy + gp.quicksum(buy[i] for i in stages)) +
        em_fast * gp.quicksum(fast[i] for i in stages) +
        em_slow * gp.quicksum(slow[i] for i in stages)
    )
    model.addConstr(carbon_usage <= carbon_budget, "carbon_budget")
    
    # Objective: minimize total cost
    total_cost = (
        cost_new * (prebuy + gp.quicksum(buy[i] for i in stages)) +
        cost_fast * gp.quicksum(fast[i] for i in stages) +
        cost_slow * gp.quicksum(slow[i] for i in stages) +
        penalty_shortage * gp.quicksum(shortage[i] for i in stages)
    )
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Print result
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
