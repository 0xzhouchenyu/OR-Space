import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params_file = os.path.join(data_dir, 'general_parameters.csv')

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
cow_price = params['cow_selling_price']
sheep_price = params['sheep_selling_price']
chicken_price = params['chicken_selling_price']
cow_feed = params['cow_feed_cost']
sheep_feed = params['sheep_feed_cost']
chicken_feed = params['chicken_feed_cost']
cow_manure = params['cow_manure_production']
sheep_manure = params['sheep_manure_production']
chicken_manure = params['chicken_manure_production']
max_manure = params['max_manure_capacity']
max_chickens = params['max_chickens']
min_cows = params['min_cows']
min_sheep = params['min_sheep']
max_total = params['max_total_animals']

# New parameters for expanded mode
premium_capacity_mult = params['premium_capacity_multiplier']
premium_manure_mult = params['premium_manure_multiplier']
expansion_cost = params['expansion_cost']
premium_feed_mult = params['premium_feed_multiplier']
base_land_cow = params['base_land_usage_cow']
base_land_sheep = params['base_land_usage_sheep']
base_land_chicken = params['base_land_usage_chicken']
base_land_capacity = params['base_land_capacity']
expansion_land_increase = params['expansion_land_increase']

# Create model
model = gp.Model("FarmProfit")
model.setParam('OutputFlag', 0)

# Decision variables
cows = model.addVar(lb=min_cows, vtype=GRB.INTEGER, name="cows")
sheep = model.addVar(lb=min_sheep, vtype=GRB.INTEGER, name="sheep")
chickens = model.addVar(lb=0, ub=max_chickens, vtype=GRB.INTEGER, name="chickens")
expanded = model.addVar(vtype=GRB.BINARY, name="expanded")

# Premium animals (only if expanded mode is active)
premium_cows = model.addVar(lb=0, vtype=GRB.INTEGER, name="premium_cows")
premium_sheep = model.addVar(lb=0, vtype=GRB.INTEGER, name="premium_sheep")
premium_chickens = model.addVar(lb=0, vtype=GRB.INTEGER, name="premium_chickens")

# Regular animals (non-premium)
regular_cows = model.addVar(lb=0, vtype=GRB.INTEGER, name="regular_cows")
regular_sheep = model.addVar(lb=0, vtype=GRB.INTEGER, name="regular_sheep")
regular_chickens = model.addVar(lb=0, vtype=GRB.INTEGER, name="regular_chickens")

# Link regular + premium = total
model.addConstr(regular_cows + premium_cows == cows, "cow_split")
model.addConstr(regular_sheep + premium_sheep == sheep, "sheep_split")
model.addConstr(regular_chickens + premium_chickens == chickens, "chicken_split")

# Premium animals only allowed when expanded mode is active
model.addConstr(premium_cows <= expanded * 1000, "premium_cows_only_expanded")
model.addConstr(premium_sheep <= expanded * 1000, "premium_sheep_only_expanded")
model.addConstr(premium_chickens <= expanded * 1000, "premium_chickens_only_expanded")

# Manure capacity constraint (depends on mode)
# Regular mode: max_manure; Expanded mode: max_manure * premium_manure_mult
model.addConstr(
    cow_manure * cows + sheep_manure * sheep + chicken_manure * chickens <=
    max_manure * (1 + (premium_manure_mult - 1) * expanded),
    "manure_capacity"
)

# Total animals constraint (depends on mode)
model.addConstr(
    cows + sheep + chickens <= max_total * (1 + (premium_capacity_mult - 1) * expanded),
    "total_animals"
)

# Land capacity constraint
model.addConstr(
    base_land_cow * cows + base_land_sheep * sheep + base_land_chicken * chickens <=
    base_land_capacity + expansion_land_increase * expanded,
    "land_capacity"
)

# Objective: maximize profit
# Revenue from all animals
revenue = cow_price * cows + sheep_price * sheep + chicken_price * chickens

# Feed costs: regular animals use normal feed, premium animals use multiplied feed
feed_cost = (cow_feed * regular_cows + sheep_feed * regular_sheep + chicken_feed * regular_chickens +
             cow_feed * premium_feed_mult * premium_cows +
             sheep_feed * premium_feed_mult * premium_sheep +
             chicken_feed * premium_feed_mult * premium_chickens)

# Expansion cost (only if expanded mode is active)
fixed_cost = expansion_cost * expanded

profit = revenue - feed_cost - fixed_cost
model.setObjective(profit, GRB.MAXIMIZE)

# Solve
model.optimize()

# Print results
print(f"FINAL_OBJ_VALUE: {model.objVal}")
