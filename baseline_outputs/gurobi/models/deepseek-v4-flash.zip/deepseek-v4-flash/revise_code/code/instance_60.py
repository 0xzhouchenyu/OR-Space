import os
import re
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Get data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read parameters
    num_customers = 7
    max_route_length = 1000
    route_cost_day = 20
    
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'num_customers':
                num_customers = int(row['Value'])
            elif row['Parameter_Name'] == 'max_route_length_day':
                max_route_length = int(row['Value'])
            elif row['Parameter_Name'] == 'route_cost_day':
                route_cost_day = int(row['Value'])
    
    # Read distance matrix
    D = [[0] * num_customers for _ in range(num_customers)]
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:
            nums = re.findall(r'\d+', line)
            if not nums:
                continue
            row_idx = int(nums[0]) - 1
            for j, val in enumerate(nums[1:]):
                col_idx = row_idx + 1 + j
                if col_idx < num_customers:
                    D[row_idx][col_idx] = int(val)
                    D[col_idx][row_idx] = int(val)
    
    # Create model
    model = gp.Model("TSP_Two_Day")
    model.setParam('OutputFlag', 0)
    
    # Sets
    N = list(range(num_customers))  # All locations (0 = depot)
    C = list(range(1, num_customers))  # Customers only
    days = [0, 1]  # Day 0 and Day 1
    
    # Decision variables
    # y[i,d] = 1 if customer i is assigned to day d
    y = {}
    for i in C:
        for d in days:
            y[i, d] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{d}")
    
    # x[i,j,d] = 1 if travel from i to j on day d
    x = {}
    for i in N:
        for j in N:
            if i != j:
                for d in days:
                    x[i, j, d] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}_{d}")
    
    # u[i,d] = position of customer i in tour on day d (for subtour elimination)
    u = {}
    for i in C:
        for d in days:
            u[i, d] = model.addVar(lb=1, ub=num_customers-1, vtype=GRB.CONTINUOUS, name=f"u_{i}_{d}")
    
    # z[d] = 1 if day d is used (has at least one customer)
    z = {}
    for d in days:
        z[d] = model.addVar(vtype=GRB.BINARY, name=f"z_{d}")
    
    # Objective: minimize travel distance + fixed route costs
    obj = gp.quicksum(D[i][j] * x[i, j, d] for i in N for j in N if i != j for d in days)
    obj += gp.quicksum(route_cost_day * z[d] for d in days)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    
    # Each customer assigned to exactly one day
    for i in C:
        model.addConstr(gp.quicksum(y[i, d] for d in days) == 1, name=f"assign_{i}")
    
    # Link y and z: if any customer assigned to day d, then z[d] = 1
    for d in days:
        model.addConstr(gp.quicksum(y[i, d] for i in C) <= len(C) * z[d], name=f"z_link_{d}")
        model.addConstr(gp.quicksum(y[i, d] for i in C) >= z[d], name=f"z_link_lb_{d}")
    
    # Flow conservation for each day
    for d in days:
        # Each node on day d must have exactly one outgoing arc if it's used
        for i in N:
            # Outgoing from i
            model.addConstr(
                gp.quicksum(x[i, j, d] for j in N if j != i) == 
                (1 if i == 0 else y[i, d]),
                name=f"out_{i}_{d}"
            )
            # Incoming to i
            model.addConstr(
                gp.quicksum(x[j, i, d] for j in N if j != i) == 
                (1 if i == 0 else y[i, d]),
                name=f"in_{i}_{d}"
            )
    
    # Subtour elimination (MTZ formulation)
    for d in days:
        for i in C:
            for j in C:
                if i != j:
                    model.addConstr(
                        u[i, d] - u[j, d] + (num_customers - 1) * x[i, j, d] <= num_customers - 2,
                        name=f"mtz_{i}_{j}_{d}"
                    )
    
    # Maximum route length constraint per day
    for d in days:
        model.addConstr(
            gp.quicksum(D[i][j] * x[i, j, d] for i in N for j in N if i != j) <= max_route_length * z[d],
            name=f"max_length_{d}"
        )
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    solve()
