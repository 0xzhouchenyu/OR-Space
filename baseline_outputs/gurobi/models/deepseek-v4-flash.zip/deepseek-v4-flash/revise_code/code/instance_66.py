import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read table_1.csv
toys = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            "type": row["Toy_Type"],
            "labor": float(row["Manufacturing_Labor_Hours"]),
            "inspection": float(row["Inspection_Hours"]),
            "profit": float(row["Profit_Per_Unit"])
        })

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

# Extract parameters
labor_period1 = params["available_labor_hours_period1"]
labor_period2 = params["available_labor_hours_period2"]
inspection_period1 = params["available_inspection_hours_period1"]
inspection_period2 = params["available_inspection_hours_period2"]

max_demand = {
    "High-End": [params["max_demand_high_end_period1"], params["max_demand_high_end_period2"]],
    "Mid-Range": [params["max_demand_mid_range_period1"], params["max_demand_mid_range_period2"]],
    "Low-End": [params["max_demand_low_end_period1"], params["max_demand_low_end_period2"]]
}

overtime_cap = params["overtime_labor_cap"]
overtime_cost = params["overtime_labor_cost"]
fatigue_threshold = params["period1_overtime_fatigue_threshold"]
recovery_loss = params["period2_labor_recovery_loss"]
review_threshold = params["overtime_review_threshold"]
review_fee = params["seasonal_safety_review_fee"]

# Create model
model = gp.Model("ToyProduction_TwoPeriod")
model.setParam("OutputFlag", 0)

# Decision variables
# Production quantities per toy type per period
x = {}
for toy in toys:
    for p in range(2):
        x[(toy["type"], p)] = model.addVar(lb=0, name=f"x_{toy['type']}_p{p}")

# Overtime hours per period
ot = {}
for p in range(2):
    ot[p] = model.addVar(lb=0, ub=overtime_cap, name=f"ot_p{p}")

# Binary variable for safety review fee
z = model.addVar(vtype=GRB.BINARY, name="safety_review")

# Objective: maximize profit - overtime costs - safety review fee
profit_expr = gp.quicksum(toy["profit"] * x[(toy["type"], p)] for toy in toys for p in range(2))
overtime_cost_expr = gp.quicksum(overtime_cost * ot[p] for p in range(2))
review_cost_expr = review_fee * z

model.setObjective(profit_expr - overtime_cost_expr - review_cost_expr, GRB.MAXIMIZE)

# Constraints

# Period 1 labor: regular + overtime
model.addConstr(
    gp.quicksum(toy["labor"] * x[(toy["type"], 0)] for toy in toys) <= labor_period1 + ot[0],
    "Labor_Period1"
)

# Period 2 labor: regular (reduced by fatigue) + overtime
# Effective period 2 regular labor = labor_period2 - recovery_loss if ot[0] > fatigue_threshold
# Use big-M formulation
M = labor_period2 + recovery_loss + 1000
y = model.addVar(vtype=GRB.BINARY, name="fatigue_trigger")
model.addConstr(ot[0] <= fatigue_threshold + M * y, "Fatigue_trigger_1")
model.addConstr(ot[0] >= fatigue_threshold + 1e-5 - M * (1 - y), "Fatigue_trigger_2")

effective_labor_p2 = labor_period2 - recovery_loss * y
model.addConstr(
    gp.quicksum(toy["labor"] * x[(toy["type"], 1)] for toy in toys) <= effective_labor_p2 + ot[1],
    "Labor_Period2"
)

# Inspection constraints per period
model.addConstr(
    gp.quicksum(toy["inspection"] * x[(toy["type"], 0)] for toy in toys) <= inspection_period1,
    "Inspection_Period1"
)
model.addConstr(
    gp.quicksum(toy["inspection"] * x[(toy["type"], 1)] for toy in toys) <= inspection_period2,
    "Inspection_Period2"
)

# Demand constraints per period
for toy in toys:
    for p in range(2):
        model.addConstr(x[(toy["type"], p)] <= max_demand[toy["type"]][p], f"Demand_{toy['type']}_p{p}")

# Overtime cap per period (already in variable bounds)
# Total overtime cap across both periods
model.addConstr(ot[0] + ot[1] <= overtime_cap, "Total_Overtime_Cap")

# Safety review fee trigger: if total overtime > review_threshold, then z=1
model.addConstr(ot[0] + ot[1] <= review_threshold + M * (1 - z), "Review_trigger_1")
model.addConstr(ot[0] + ot[1] >= review_threshold + 1e-5 - M * z, "Review_trigger_2")

# Optimize
model.optimize()

# Get objective value
obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
