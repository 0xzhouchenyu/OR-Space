import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load demand data
    demand = {}
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        quarters = [int(h) for h in header[1:]]
        for row in reader:
            product = row[0].strip()
            for j, q in enumerate(quarters):
                demand[(product, q)] = int(row[j+1])
    
    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    
    products = ['I', 'II', 'III']
    quarters = [1, 2, 3, 4]
    
    init_inv = params['initial_inventory']
    end_inv_req = params['end_inventory_requirement']
    hours_per_quarter = params['production_hours_per_quarter']
    hours_per_unit = {'I': params['product_I_hours_per_unit'],
                      'II': params['product_II_hours_per_unit'],
                      'III': params['product_III_hours_per_unit']}
    delay_penalty = {'I': params['delay_penalty_product_I'],
                     'II': params['delay_penalty_product_II'],
                     'III': params['delay_penalty_product_III']}
    inv_cost = params['inventory_cost_per_unit']
    
    # New peak parameters
    normal_hours_cap = {}
    peak_hours_cap = {}
    peak_cost = {}
    for t in quarters:
        normal_hours_cap[t] = params[f'normal_hours_cap_fraction_q{t}'] * hours_per_quarter
        peak_hours_cap[t] = params[f'peak_hours_cap_q{t}']
        peak_cost[t] = params[f'peak_cost_per_hour_q{t}']
    
    # Create model
    model = gp.Model("ProductionScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: normal and peak production quantities
    x_norm = {(p, t): model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_norm_{p}_{t}") 
              for p in products for t in quarters}
    x_peak = {(p, t): model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_peak_{p}_{t}") 
              for p in products for t in quarters}
    
    # Product I cannot be produced in Q2 (neither normal nor peak)
    model.addConstr(x_norm[('I', 2)] == 0, name="no_prod_I_norm_q2")
    model.addConstr(x_peak[('I', 2)] == 0, name="no_prod_I_peak_q2")
    
    # Inventory variables
    inv = {(p, t): model.addVar(lb=-GRB.INFINITY, name=f"inv_{p}_{t}") 
           for p in products for t in quarters}
    inv_pos = {(p, t): model.addVar(lb=0, name=f"inv_pos_{p}_{t}") 
               for p in products for t in quarters}
    inv_neg = {(p, t): model.addVar(lb=0, name=f"inv_neg_{p}_{t}") 
               for p in products for t in quarters}
    
    # Inventory balance constraints
    for p in products:
        # Quarter 1
        model.addConstr(inv[(p, 1)] == init_inv + x_norm[(p, 1)] + x_peak[(p, 1)] - demand[(p, 1)],
                        name=f"inv_bal_{p}_q1")
        # Quarters 2-4
        for t in range(2, 5):
            model.addConstr(inv[(p, t)] == inv[(p, t-1)] + x_norm[(p, t)] + x_peak[(p, t)] - demand[(p, t)],
                            name=f"inv_bal_{p}_q{t}")
    
    # Split inventory into positive and negative parts
    for p in products:
        for t in quarters:
            model.addConstr(inv[(p, t)] == inv_pos[(p, t)] - inv_neg[(p, t)],
                            name=f"inv_split_{p}_q{t}")
    
    # End of Q4: inventory must be at least end_inv_req
    for p in products:
        model.addConstr(inv[(p, 4)] >= end_inv_req, name=f"end_inv_{p}")
    
    # Production hours constraints per quarter
    for t in quarters:
        # Normal hours constraint
        model.addConstr(
            gp.quicksum(hours_per_unit[p] * x_norm[(p, t)] for p in products) <= normal_hours_cap[t],
            name=f"normal_hours_q{t}"
        )
        # Peak hours constraint
        model.addConstr(
            gp.quicksum(hours_per_unit[p] * x_peak[(p, t)] for p in products) <= peak_hours_cap[t],
            name=f"peak_hours_q{t}"
        )
    
    # Objective: minimize delay penalties + inventory holding costs + peak costs
    obj = gp.quicksum(
        delay_penalty[p] * inv_neg[(p, t)] + inv_cost * inv_pos[(p, t)]
        for p in products for t in quarters
    )
    # Add peak production costs
    for t in quarters:
        obj += peak_cost[t] * gp.quicksum(
            hours_per_unit[p] * x_peak[(p, t)] for p in products
        )
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
