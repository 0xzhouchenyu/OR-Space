import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    
    df = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)
    
    # Extract parameters
    budget = float(params[params['Parameter_Name'] == 'budget']['Value'].iloc[0])
    food_intake = float(params[params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
    weekday_budget_share = float(params[params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
    max_prep_weekday = float(params[params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
    max_prep_weekend = float(params[params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
    weekend_protein_ban = int(params[params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
    veg_balance_penalty = float(params[params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])
    
    # Fill missing fiber content with 0
    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)
    
    foods = df['Food'].tolist()
    types = df.set_index('Food')['Type'].to_dict()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()
    
    # Identify food categories
    proteins = [f for f in foods if types[f] == 'protein']
    vegetables = [f for f in foods if types[f] == 'vegetable']
    
    # Create model
    model = gp.Model("Revised_Dinner_Planning")
    model.setParam('OutputFlag', 0)
    
    # Variables: amounts in 100g units for weekday and weekend
    x_wd = model.addVars(foods, name="x_wd", lb=0)
    x_we = model.addVars(foods, name="x_we", lb=0)
    
    # Binary variables for selection (shared across both meals)
    y = model.addVars(foods, vtype=GRB.BINARY, name="y")
    
    # Binary variables for protein label usage
    z = model.addVars(proteins, vtype=GRB.BINARY, name="z")
    
    # Objective: maximize fiber minus penalty for vegetable imbalance
    # Total fiber from both meals
    fiber_obj = gp.quicksum(fiber[f] * (x_wd[f] + x_we[f]) for f in foods)
    
    # Vegetable balance penalty: |total_veg_wd - total_veg_we| * penalty
    total_veg_wd = gp.quicksum(x_wd[f] for f in vegetables)
    total_veg_we = gp.quicksum(x_we[f] for f in vegetables)
    veg_diff = model.addVar(name="veg_diff", lb=0)
    model.addConstr(veg_diff >= total_veg_wd - total_veg_we)
    model.addConstr(veg_diff >= total_veg_we - total_veg_wd)
    
    model.setObjective(fiber_obj - veg_balance_penalty * veg_diff, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Total food intake per dinner (in 100g units)
    intake_100g = food_intake / 100.0
    model.addConstr(gp.quicksum(x_wd[f] for f in foods) == intake_100g, "weekday_intake")
    model.addConstr(gp.quicksum(x_we[f] for f in foods) == intake_100g, "weekend_intake")
    
    # 2. Budget constraints
    weekday_budget = budget * weekday_budget_share
    weekend_budget = budget * (1 - weekday_budget_share)
    model.addConstr(gp.quicksum(price[f] * x_wd[f] for f in foods) <= weekday_budget, "weekday_budget")
    model.addConstr(gp.quicksum(price[f] * x_we[f] for f in foods) <= weekend_budget, "weekend_budget")
    
    # 3. Prep time constraints
    model.addConstr(gp.quicksum(prep_time[f] * x_wd[f] for f in foods) <= max_prep_weekday, "weekday_prep")
    model.addConstr(gp.quicksum(prep_time[f] * x_we[f] for f in foods) <= max_prep_weekend, "weekend_prep")
    
    # 4. Exactly one protein source (shared across both meals)
    model.addConstr(gp.quicksum(y[f] for f in proteins) == 1, "one_protein")
    
    # 5. At least two kinds of vegetables (shared across both meals)
    model.addConstr(gp.quicksum(y[f] for f in vegetables) >= 2, "min_vegetables")
    
    # 6. Weekend protein ban (if flag is 1, no protein in weekend meal)
    if weekend_protein_ban == 1:
        model.addConstr(gp.quicksum(x_we[f] for f in proteins) == 0, "weekend_protein_ban")
    
    # 7. Linking constraints: if a food is selected (y=1), it must appear in at least one meal
    M = intake_100g  # big M
    for f in foods:
        model.addConstr(x_wd[f] + x_we[f] >= 0.1 * y[f], f"min_amount_{f}")
        model.addConstr(x_wd[f] + x_we[f] <= M * y[f], f"max_amount_{f}")
    
    # 8. Protein label constraint: z[f] = 1 if protein f appears in at least one meal
    for f in proteins:
        model.addConstr(z[f] >= y[f], f"label_indicator_{f}")
        model.addConstr(z[f] <= gp.quicksum([x_wd[f], x_we[f]]) * 100, f"label_upper_{f}")  # if amount > 0, z can be 1
        model.addConstr(z[f] <= 1, f"label_binary_{f}")
    
    # 9. Avoid using a protein label on paper unless that protein appears in at least one meal
    # This is enforced by the linking above: if y[f]=1, then z[f] must be 1 (since amount > 0)
    # If y[f]=0, z[f] can be 0 or 1, but we need to ensure we don't label a protein that doesn't appear
    # Actually, the requirement is: don't use a protein label unless it appears in at least one meal
    # So if z[f]=1, then the protein must appear in at least one meal
    for f in proteins:
        model.addConstr(z[f] <= gp.quicksum([x_wd[f], x_we[f]]) * 100, f"label_requires_amount_{f}")
    
    # Solve
    model.optimize()
    
    if model.Status == GRB.OPTIMAL:
        obj_val = round(model.ObjVal, 4)
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No feasible solution found")

if __name__ == '__main__':
    solve()
