import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = params['min_manager_experience']
    manager_bonus = params['manager_bonus_per_candidate']
    
    # Create model
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: binary for each candidate in each role
    x_manager = {}
    x_specialist = {}
    for c in candidates:
        x_manager[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"manager_{c['name']}")
        x_specialist[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"specialist_{c['name']}")
    
    # Auxiliary variable: whether candidate is hired (in any role)
    x_hired = {}
    for c in candidates:
        x_hired[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"hired_{c['name']}")
    
    # Objective: minimize total salary + manager bonus
    total_salary = gp.quicksum(c['salary'] * (x_manager[c['name']] + x_specialist[c['name']]) for c in candidates)
    total_bonus = gp.quicksum(manager_bonus * x_manager[c['name']] for c in candidates)
    model.setObjective(total_salary + total_bonus, GRB.MINIMIZE)
    
    # Constraint: each candidate can be in at most one role
    for c in candidates:
        model.addConstr(x_manager[c['name']] + x_specialist[c['name']] <= 1)
    
    # Constraint: link hired variable to role variables
    for c in candidates:
        model.addConstr(x_hired[c['name']] == x_manager[c['name']] + x_specialist[c['name']])
    
    # Constraint 1: max employees
    model.addConstr(gp.quicksum(x_hired[c['name']] for c in candidates) <= max_employees)
    
    # Constraint 2: budget (base salaries only, excluding manager bonus)
    model.addConstr(total_salary <= budget_limit)
    
    # Constraint 3: at least one with Master's or Doctoral degree
    advanced_candidates = [c for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(x_hired[c['name']] for c in advanced_candidates) >= min_advanced)
    
    # Constraint 4: minimum total work experience
    model.addConstr(gp.quicksum(c['experience'] * x_hired[c['name']] for c in candidates) >= min_experience)
    
    # Constraint 5: at most one from pair A and E
    model.addConstr(x_hired['A'] + x_hired['E'] <= max_equivalent)
    
    # Constraint 6: minimum employees
    model.addConstr(gp.quicksum(x_hired[c['name']] for c in candidates) >= min_employees)
    
    # Constraint 7: minimum managers
    model.addConstr(gp.quicksum(x_manager[c['name']] for c in candidates) >= min_managers)
    
    # Constraint 8: maximum managers
    model.addConstr(gp.quicksum(x_manager[c['name']] for c in candidates) <= max_managers)
    
    # Constraint 9: minimum total experience for managers
    model.addConstr(gp.quicksum(c['experience'] * x_manager[c['name']] for c in candidates) >= min_manager_experience)
    
    # Solve
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    
    # Print selected candidates
    for c in candidates:
        if x_manager[c['name']].x > 0.5:
            print(f"Selected as Manager: {c['name']} (Salary: {c['salary']})")
        elif x_specialist[c['name']].x > 0.5:
            print(f"Selected as Specialist: {c['name']} (Salary: {c['salary']})")
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == '__main__':
    main()
