import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load the bandwidth table
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        
        bandwidth = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                bandwidth[(row_node, col_node)] = bw
    
    # Define cost for each directed edge (100 - bandwidth)
    cost = {}
    for (i, j), bw in bandwidth.items():
        if bw > 0:
            cost[(i, j)] = 100 - bw
    
    # Create model
    model = gp.Model("MinCostPath")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i,j] = 1 if edge (i,j) is used, 0 otherwise
    x = {}
    for (i, j) in cost.keys():
        x[(i, j)] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
    
    # Flow conservation constraints
    source = 'A'
    intermediate = 'C'
    target = 'E'
    
    # For each node, flow balance
    all_nodes = nodes
    for v in all_nodes:
        inflow = gp.quicksum(x[(u, v)] for u in all_nodes if (u, v) in x)
        outflow = gp.quicksum(x[(v, w)] for w in all_nodes if (v, w) in x)
        
        if v == source:
            model.addConstr(outflow - inflow == 1, name=f"flow_source_{v}")
        elif v == target:
            model.addConstr(outflow - inflow == -1, name=f"flow_target_{v}")
        else:
            model.addConstr(outflow - inflow == 0, name=f"flow_balance_{v}")
    
    # Must pass through node C (ensure at least one edge into C and one out of C)
    # This is automatically enforced by flow conservation if C is on the path,
    # but we need to ensure C is actually used (not bypassed)
    # Add constraint that C has flow through it
    inflow_C = gp.quicksum(x[(u, 'C')] for u in all_nodes if (u, 'C') in x)
    outflow_C = gp.quicksum(x[('C', w)] for w in all_nodes if ('C', w) in x)
    model.addConstr(inflow_C == 1, name="enter_C")
    model.addConstr(outflow_C == 1, name="leave_C")
    
    # No loops: ensure no subtours using Miller-Tucker-Zemlin constraints
    # Assign position variables u[i] for each node
    u = {}
    for v in all_nodes:
        u[v] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"u_{v}")
    
    M = len(all_nodes)
    for (i, j) in x.keys():
        if i != j:
            model.addConstr(u[i] - u[j] + M * x[(i, j)] <= M - 1, name=f"subtour_{i}_{j}")
    
    # Objective: minimize total cost
    model.setObjective(gp.quicksum(cost[(i, j)] * x[(i, j)] for (i, j) in x.keys()), GRB.MINIMIZE)
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == '__main__':
    main()
