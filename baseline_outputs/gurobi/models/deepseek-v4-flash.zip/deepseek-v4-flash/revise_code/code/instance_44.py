import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

m = int(params['m'])  # production points
n = int(params['n'])  # demand points
p = int(params['p'])  # marshaling stations

a = {i: params[f'a_{i}'] for i in range(1, m+1)}  # production capacities
b = {j: params[f'b_{j}'] for j in range(1, n+1)}  # demands
f_cost = {k: params[f'f_{k}'] for k in range(1, p+1)}  # fixed costs
q = {k: params[f'q_{k}'] for k in range(1, p+1)}  # max total transshipment capacity
qexp = {k: params[f'qexp_{k}'] for k in range(1, p+1)}  # max express capacity
alpha = {j: params[f'alpha_{j}'] for j in range(1, n+1)}  # minimum express fraction
eps = params['eps']  # minimum strictly positive express flow
M = params['M']  # Big-M

# Load transportation costs from production to marshaling stations
cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row['i'])
        k = int(row['k'])
        cR_ik[(i, k)] = float(row['cR_ik'])
        cE_ik[(i, k)] = float(row['cE_ik'])

# Load transportation costs from marshaling stations to demand points
cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, 'table_2.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row['k'])
        j = int(row['j'])
        cR_kj[(k, j)] = float(row['cR_kj'])
        cE_kj[(k, j)] = float(row['cE_kj'])

# Create the optimization model
prob = gp.Model("Transportation_Problem")
prob.setParam('OutputFlag', 0)

# Decision variables
# Regular flow from production i to station k
xR = {}
for i in range(1, m+1):
    for k in range(1, p+1):
        xR[(i, k)] = prob.addVar(lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS, name=f"xR_{i}_{k}")

# Express flow from production i to station k
xE = {}
for i in range(1, m+1):
    for k in range(1, p+1):
        xE[(i, k)] = prob.addVar(lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS, name=f"xE_{i}_{k}")

# Regular flow from station k to demand j
yR = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        yR[(k, j)] = prob.addVar(lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS, name=f"yR_{k}_{j}")

# Express flow from station k to demand j
yE = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        yE[(k, j)] = prob.addVar(lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS, name=f"yE_{k}_{j}")

# Binary variable for station usage
z = {}
for k in range(1, p+1):
    z[k] = prob.addVar(vtype=GRB.BINARY, name=f"z_{k}")

# Binary variable to indicate if express flow from station k to demand j is active (>= eps)
w = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        w[(k, j)] = prob.addVar(vtype=GRB.BINARY, name=f"w_{k}_{j}")

# Objective: minimize total transportation cost + fixed costs
obj = gp.LinExpr()
for i in range(1, m+1):
    for k in range(1, p+1):
        obj += cR_ik[(i, k)] * xR[(i, k)] + cE_ik[(i, k)] * xE[(i, k)]
for k in range(1, p+1):
    for j in range(1, n+1):
        obj += cR_kj[(k, j)] * yR[(k, j)] + cE_kj[(k, j)] * yE[(k, j)]
for k in range(1, p+1):
    obj += f_cost[k] * z[k]

prob.setObjective(obj, GRB.MINIMIZE)

# Constraints

# 1. Supply constraints: total shipped from production point i <= a_i
for i in range(1, m+1):
    prob.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for k in range(1, p+1)) <= a[i],
        name=f"Supply_{i}"
    )

# 2. Demand constraints: total received at demand point j >= b_j
for j in range(1, n+1):
    prob.addConstr(
        gp.quicksum(yR[(k, j)] + yE[(k, j)] for k in range(1, p+1)) >= b[j],
        name=f"Demand_{j}"
    )

# 3. Flow conservation at marshaling stations (separate for regular and express)
for k in range(1, p+1):
    # Regular flow balance
    prob.addConstr(
        gp.quicksum(xR[(i, k)] for i in range(1, m+1)) == gp.quicksum(yR[(k, j)] for j in range(1, n+1)),
        name=f"FlowBalanceRegular_{k}"
    )
    # Express flow balance
    prob.addConstr(
        gp.quicksum(xE[(i, k)] for i in range(1, m+1)) == gp.quicksum(yE[(k, j)] for j in range(1, n+1)),
        name=f"FlowBalanceExpress_{k}"
    )

# 4. Total capacity constraints at marshaling stations (linked with z_k)
for k in range(1, p+1):
    prob.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for i in range(1, m+1)) <= q[k] * z[k],
        name=f"TotalCapacity_{k}"
    )

# 5. Express capacity constraints at marshaling stations
for k in range(1, p+1):
    prob.addConstr(
        gp.quicksum(xE[(i, k)] for i in range(1, m+1)) <= qexp[k],
        name=f"ExpressCapacity_{k}"
    )

# 6. Link express flow to binary indicator w_kj (using Big-M)
for k in range(1, p+1):
    for j in range(1, n+1):
        prob.addConstr(
            yE[(k, j)] >= eps * w[(k, j)],
            name=f"ExpressIndicatorLower_{k}_{j}"
        )
        prob.addConstr(
            yE[(k, j)] <= M * w[(k, j)],
            name=f"ExpressIndicatorUpper_{k}_{j}"
        )

# 7. Diversified express share constraint for demand points with more than one open station
for j in range(1, n+1):
    # Total express flow to demand j
    total_express_j = gp.quicksum(yE[(k, j)] for k in range(1, p+1))
    # Total flow to demand j
    total_flow_j = gp.quicksum(yR[(k, j)] + yE[(k, j)] for k in range(1, p+1))
    # Number of stations serving demand j (with express flow >= eps)
    num_stations_j = gp.quicksum(w[(k, j)] for k in range(1, p+1))
    # If more than one station serves demand j, then express fraction >= alpha_j
    # Use indicator: if num_stations_j >= 2, then total_express_j >= alpha_j * total_flow_j
    # We model this as: total_express_j >= alpha_j * total_flow_j - M * (2 - num_stations_j)
    prob.addConstr(
        total_express_j >= alpha[j] * total_flow_j - M * (2 - num_stations_j),
        name=f"DiversifiedExpress_{j}"
    )

# Solve
prob.optimize()

# Print solution details
for k in range(1, p+1):
    print(f"Station {k} used: {z[k].X}")
for i in range(1, m+1):
    for k in range(1, p+1):
        if xR[(i,k)].X > 0:
            print(f"xR[{i},{k}] = {xR[(i,k)].X}")
        if xE[(i,k)].X > 0:
            print(f"xE[{i},{k}] = {xE[(i,k)].X}")
for k in range(1, p+1):
    for j in range(1, n+1):
        if yR[(k,j)].X > 0:
            print(f"yR[{k},{j}] = {yR[(k,j)].X}")
        if yE[(k,j)].X > 0:
            print(f"yE[{k},{j}] = {yE[(k,j)].X}")

obj_val = prob.ObjVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
