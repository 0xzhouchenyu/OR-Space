import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Determine paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load distances
distances = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        yard = row["Coal_Yard"].strip()
        area = int(row["Residential_Area"].strip())
        dist = float(row["Distance_km"].strip())
        distances[(yard, area)] = dist

# Load parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        value = float(row["Value"].strip())
        params[name] = value

# Extract parameters
min_supply_A = params["min_coal_yard_A"]
min_supply_B = params["min_coal_yard_B_adjusted"]
demand_1 = params["residential_area_1_demand"]
demand_2 = params["residential_area_2_demand"]
demand_3 = params["residential_area_3_demand"]
min_share_A3 = params["min_share_area3_from_A"]
staging_threshold = params["area3_A_staging_threshold"]
excess_cost = params["area3_A_excess_staging_cost"]

demand = {1: demand_1, 2: demand_2, 3: demand_3}
min_supply = {"A": min_supply_A, "B": min_supply_B}

coal_yards = ["A", "B"]
areas = [1, 2, 3]

# Create model
model = gp.Model("Coal_Distribution_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}
for yard in coal_yards:
    for area in areas:
        if (yard, area) in distances:
            x[(yard, area)] = model.addVar(lb=0, name=f"x_{yard}_{area}")

# Special variables for A->Area3 split
x_A3_normal = model.addVar(lb=0, ub=staging_threshold, name="x_A3_normal")
x_A3_excess = model.addVar(lb=0, name="x_A3_excess")

# Objective: minimize transportation cost + excess handling cost
obj = gp.LinExpr()
for (yard, area), var in x.items():
    obj += distances[(yard, area)] * var
# Add excess handling cost for A->Area3 above threshold
obj += excess_cost * x_A3_excess
model.setObjective(obj, GRB.MINIMIZE)

# Constraints

# Link A->Area3 split variables to total A->Area3
model.addConstr(x_A3_normal + x_A3_excess == x[("A", 3)], "A3_split")

# Supply constraints
model.addConstr(gp.quicksum(x[("A", area)] for area in areas) >= min_supply["A"], "Min_Supply_A")
model.addConstr(gp.quicksum(x[("B", area)] for area in areas if ("B", area) in x) >= min_supply["B"], "Min_Supply_B")

# Demand constraints
for area in areas:
    vars_list = []
    for yard in coal_yards:
        if (yard, area) in x:
            vars_list.append(x[(yard, area)])
    model.addConstr(gp.quicksum(vars_list) == demand[area], f"Demand_{area}")

# Minimum share constraint: at least 70% of Area 3 demand from A
model.addConstr(x[("A", 3)] >= min_share_A3 * demand[3], "Min_Share_A3")

# Optimize
model.optimize()

# Get objective value
obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
