import os
import sys
import csv

import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    """Load a CSV file and return list of dictionaries."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, 'data', filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return [row for row in reader]

def load_demand():
    """Load demand data from table_1.csv."""
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        month = row['Month']
        product = row['Product']
        units = int(row['Market_Demand_Units'])
        demand[(month, product)] = units
    return demand

def load_parameters():
    """Load general parameters."""
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = float(row['Value'])
        params[name] = value
    return params

def main():
    demand_data = load_demand()
    params = load_parameters()
    
    # Planning months: July to December
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']
    
    # Production costs (June-December rates)
    cost_I = params['product_I_cost_jun_to_dec']
    cost_II = params['product_II_cost_jun_to_dec']
    prod_cost = {'Product_I': cost_I, 'Product_II': cost_II}
    
    # Product volumes for warehouse
    vol_I = params['product_I_volume']
    vol_II = params['product_II_volume']
    volume = {'Product_I': vol_I, 'Product_II': vol_II}
    
    # Warehouse parameters
    warehouse_cap = params['warehouse_capacity']
    own_cost = params['own_warehouse_cost']
    
    # Machine hours parameters
    mach_I = params['product_I_machine_hours']
    mach_II = params['product_II_machine_hours']
    machine_hours = {'Product_I': mach_I, 'Product_II': mach_II}
    machine_cap = params['machine_hours_capacity_monthly']
    
    # Electricity parameters
    grid_cost = params['grid_electricity_cost']
    gen_cost = params['generator_electricity_cost']
    power_I = params['product_I_power_kwh']
    power_II = params['product_II_power_kwh']
    power_kwh = {'Product_I': power_I, 'Product_II': power_II}
    
    # Grid quotas per month
    grid_quota = {
        'July': params['grid_quota_july'],
        'August': params['grid_quota_august'],
        'September': params['grid_quota_september'],
        'October': params['grid_quota_october'],
        'November': params['grid_quota_november'],
        'December': params['grid_quota_december']
    }
    
    # Generator limits per month
    gen_max = {
        'July': params['generator_max_july'],
        'August': params['generator_max_august'],
        'September': params['generator_max_september'],
        'October': params['generator_max_october'],
        'November': params['generator_max_november'],
        'December': params['generator_max_december']
    }
    
    # Demand for planning months
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]
    
    # Create model
    model = gp.Model("Production_Planning_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Production quantities
    x = model.addVars(months, products, name="prod", lb=0)
    
    # Inventory at end of month
    inv = model.addVars(months, products, name="inv", lb=0)
    
    # Own warehouse usage (cubic meters)
    own_wh = model.addVars(months, name="own_wh", lb=0)
    
    # Grid electricity usage (kWh)
    grid_elec = model.addVars(months, name="grid_elec", lb=0)
    
    # Generator electricity usage (kWh)
    gen_elec = model.addVars(months, name="gen_elec", lb=0)
    
    # Objective: minimize production cost + inventory holding cost + electricity costs
    obj = gp.quicksum(prod_cost[p] * x[m, p] for m in months for p in products)
    obj += gp.quicksum(own_cost * own_wh[m] for m in months)
    obj += gp.quicksum(grid_cost * grid_elec[m] + gen_cost * gen_elec[m] for m in months)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    for i, m in enumerate(months):
        # Inventory balance
        for p in products:
            if i == 0:
                model.addConstr(inv[m, p] == x[m, p] - demand[(m, p)])
            else:
                prev_m = months[i - 1]
                model.addConstr(inv[m, p] == inv[prev_m, p] + x[m, p] - demand[(m, p)])
        
        # Machine hours capacity
        model.addConstr(
            gp.quicksum(machine_hours[p] * x[m, p] for p in products) <= machine_cap
        )
        
        # Warehouse capacity (own warehouse only, no external)
        total_vol = gp.quicksum(volume[p] * inv[m, p] for p in products)
        model.addConstr(own_wh[m] >= total_vol)
        model.addConstr(own_wh[m] <= warehouse_cap)
        
        # Electricity balance: production consumption = grid + generator
        elec_needed = gp.quicksum(power_kwh[p] * x[m, p] for p in products)
        model.addConstr(elec_needed == grid_elec[m] + gen_elec[m])
        
        # Grid quota
        model.addConstr(grid_elec[m] <= grid_quota[m])
        
        # Generator limit
        model.addConstr(gen_elec[m] <= gen_max[m])
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    
    # Debug output (optional, but keep for verification)
    for m in months:
        for p in products:
            print(f"{m} {p}: produce={x[m,p].x:.0f}, inv={inv[m,p].x:.0f}, demand={demand[(m,p)]}")
        print(f"  Own WH: {own_wh[m].x:.0f}")
        print(f"  Grid: {grid_elec[m].x:.0f}, Gen: {gen_elec[m].x:.0f}")
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
