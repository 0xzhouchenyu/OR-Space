import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = row['Value'].strip()

num_students = int(params['num_students'])
num_buses = int(params['num_buses'])
bus_capacity = int(params['bus_capacity'])
num_minibuses = int(params['num_minibuses'])
minibus_capacity = int(params['minibus_capacity'])
num_drivers = int(params['num_drivers'])
bus_rental_cost = float(params['bus_rental_cost'])
minibus_rental_cost = float(params['minibus_rental_cost'])

# Create model
model = gp.Model("SchoolTrip")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, lb=0, ub=num_buses, name="buses")
y = model.addVar(vtype=GRB.INTEGER, lb=0, ub=num_minibuses, name="minibuses")

# Objective: minimize total rental cost
model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

# Constraints
# Must transport all students
model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, "StudentCapacity")

# Total vehicles (drivers) constraint
model.addConstr(x + y <= num_drivers, "DriverLimit")

# Safety policy: at least two buses per minibus (if any minibus is used)
# For every minibus rented, at least two buses must be rented
model.addConstr(x >= 2 * y, "SafetyRatio")

# At least one minibus must be rented
model.addConstr(y >= 1, "MinMinibus")

# Optimize
model.optimize()

# Output result
obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
