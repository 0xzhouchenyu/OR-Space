import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load car lengths
car_lengths = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row["i"])
        length = float(row["lambda_i"])
        car_lengths[i] = length

# Load parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        value = float(row["Value"])
        params[name] = value

num_cars = int(params["num_cars"])
max_length_one_side = params["max_length_one_side"]

car_ids = list(range(1, num_cars + 1))
lengths = [car_lengths[i] for i in car_ids]

# Create model
model = gp.Model("ParkingMinStreetLength")
model.setParam('OutputFlag', 0)

# Decision variables: x[i] = 1 if car i is on the usable side, 0 otherwise
x = model.addVars(car_ids, vtype=GRB.BINARY, name="x")

# Objective: minimize total length used on the single usable side
total_used = gp.quicksum(lengths[i-1] * x[i] for i in car_ids)
model.setObjective(total_used, GRB.MINIMIZE)

# Constraint: total length on the usable side cannot exceed max_length_one_side
model.addConstr(total_used <= max_length_one_side, "max_side_length")

# Optimize
model.optimize()

# Get objective value
obj_val = model.objVal

print(f"FINAL_OBJ_VALUE: {obj_val}")
