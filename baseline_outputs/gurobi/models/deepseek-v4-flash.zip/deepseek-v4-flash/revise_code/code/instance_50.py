import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = params['fixed_order_cost']
    august_bulk_threshold = int(params['august_bulk_order_threshold'])
    august_bulk_fee = params['august_bulk_receiving_fee']
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = {m: model.addVar(lb=0, name=f"buy_{m}") for m in months}
    sell = {m: model.addVar(lb=0, name=f"sell_{m}") for m in months}
    stock = {m: model.addVar(lb=0, ub=warehouse_capacity, name=f"stock_{m}") for m in months}
    
    # Binary variables for fixed order cost (1 if any purchase in month m)
    z = {m: model.addVar(vtype=GRB.BINARY, name=f"z_{m}") for m in months}
    
    # Binary variable for August bulk receiving fee (1 if August purchase > 300)
    y = model.addVar(vtype=GRB.BINARY, name="august_bulk_flag")
    
    # Big-M values
    M_buy = warehouse_capacity + initial_stock  # maximum possible purchase
    M_august = 1000  # sufficiently large for August
    
    # Objective: maximize total profit (revenue - cost - fixed costs - August bulk fee)
    obj = gp.quicksum(sell_price[m] * sell[m] - buy_price[m] * buy[m] for m in months)
    obj -= fixed_order_cost * gp.quicksum(z[m] for m in months)
    obj -= august_bulk_fee * y
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Stock balance constraints
    for i, m in enumerate(months):
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_stock = stock[months[i-1]]
        
        # Stock balance: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], f"balance_{m}")
        
        # After buying, before selling, warehouse constraint:
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, f"warehouse_after_buy_{m}")
        
        # Fixed order cost activation: buy[m] <= M_buy * z[m]
        model.addConstr(buy[m] <= M_buy * z[m], f"fixed_cost_activation_{m}")
        
        # If z[m] = 0 then buy[m] must be 0 (already enforced by constraint above)
    
    # August bulk receiving fee logic
    # If buy[8] > 300 then y = 1; if buy[8] <= 300 then y = 0
    model.addConstr(buy[8] - august_bulk_threshold <= M_august * y, "august_bulk_upper")
    model.addConstr(august_bulk_threshold - buy[8] <= M_august * (1 - y), "august_bulk_lower")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
