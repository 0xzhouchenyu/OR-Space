import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    total_space = params['mall_total_space']
    rent_pct = params['rent_percentage'] / 100.0
    common_area_factor = params['common_area_factor']
    gm_third_concession = params['general_merchandise_third_store_concession']
    catering_third_threshold = int(params['catering_third_store_security_threshold'])
    catering_third_cost = params['catering_third_store_security_cost']
    
    # Read store data
    stores = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            code = int(row['Code'].strip())
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            stores.append({
                'code': code,
                'name': row['Store_Type'].strip(),
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits
            })
    
    # Create model
    model = gp.Model('Mall_Optimization')
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of stores of each type
    x = {}
    for i, s in enumerate(stores):
        for n in range(s['min'], s['max'] + 1):
            x[(i, n)] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{n}")
    
    # Auxiliary variables for total number of stores per type
    y = {}
    for i, s in enumerate(stores):
        y[i] = model.addVar(vtype=GRB.INTEGER, lb=s['min'], ub=s['max'], name=f"y_{i}")
    
    # Link y_i to the binary choices
    for i, s in enumerate(stores):
        model.addConstr(y[i] == gp.quicksum(n * x[(i, n)] for n in range(s['min'], s['max'] + 1)))
        model.addConstr(gp.quicksum(x[(i, n)] for n in range(s['min'], s['max'] + 1)) == 1)
    
    # Space constraint (with common area factor)
    model.addConstr(gp.quicksum(y[i] * stores[i]['area'] for i in range(len(stores))) * common_area_factor <= total_space)
    
    # Profit calculation
    total_profit = gp.LinExpr()
    for i, s in enumerate(stores):
        for n in range(s['min'], s['max'] + 1):
            if n in s['profits']:
                total_profit += n * s['profits'][n] * x[(i, n)]
    
    # Rent income before adjustments
    rent_income = rent_pct * total_profit
    
    # Adjustments
    # General Merchandise third store concession (if exactly 3 stores)
    gm_index = 2  # General_Merchandise is index 2 (0-based)
    model.addConstr(y[gm_index] >= 3 * x[(gm_index, 3)])
    rent_income -= gm_third_concession * x[(gm_index, 3)]
    
    # Catering third store security cost
    catering_index = 4  # Catering is index 4 (0-based)
    # If y[catering_index] >= 3, we incur the cost
    z_catering_third = model.addVar(vtype=GRB.BINARY, name="z_catering_third")
    model.addConstr(y[catering_index] >= 3 * z_catering_third)
    model.addConstr(y[catering_index] <= 2 + z_catering_third)  # if y>=3 then z=1, else z=0
    rent_income -= catering_third_cost * z_catering_third
    
    # Set objective
    model.setObjective(rent_income, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    main()
