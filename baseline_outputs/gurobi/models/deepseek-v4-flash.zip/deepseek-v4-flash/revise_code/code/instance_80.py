import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
def load_csv(filename):
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

# Load general parameters
params_rows = load_csv('general_parameters.csv')
params = {}
for row in params_rows:
    name = row['Parameter_Name']
    value = row['Value']
    try:
        if '.' in value:
            params[name] = float(value)
        else:
            params[name] = int(value)
    except ValueError:
        params[name] = value

# Load task-method data
task_methods = load_csv('table_1.csv')
tm_data = {}
for row in task_methods:
    key = (row['Task'], row['Method'])
    tm_data[key] = {
        'Effective_Hours': float(row['Effective_Hours']),
        'Fixed_Cost': float(row['Fixed_Cost'])
    }

# Extract parameters
skilled_wage = params['skilled_worker_weekly_wage']  # 110
laborer_wage = params['laborer_weekly_wage']  # 80
skilled_hours = params['skilled_worker_weekly_hours']  # 42
laborer_hours = params['laborer_weekly_hours']  # 36
max_skilled = params['max_skilled_workers']  # 430
max_laborers = params['max_laborers']  # 800
min_skilled_task3_B = params['min_skilled_workers_task3_methodB']  # 20
skilled_hiring_ratio = params['skilled_worker_hiring_ratio']  # 0.6

# Task-level skill share bounds
min_share = {
    'Task_1': params['min_skilled_share_task1'],  # 0.30
    'Task_2': params['min_skilled_share_task2'],  # 0.10
    'Task_3': params['min_skilled_share_task3']   # 0.20
}
max_share = {
    'Task_1': params['max_skilled_share_task1'],  # 0.70
    'Task_2': params['max_skilled_share_task2'],  # 0.50
    'Task_3': params['max_skilled_share_task3']   # 0.60
}

tasks = ['Task_1', 'Task_2', 'Task_3']
methods = ['Method_A', 'Method_B']

# Create model
model = gp.Model("WorkerAllocation")
model.setParam('OutputFlag', 0)

# Decision variables
y = {}
s = {}
l = {}
for t in tasks:
    for m in methods:
        y[t, m] = model.addVar(vtype=GRB.BINARY, name=f"y_{t}_{m}")
        s[t, m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"s_{t}_{m}")
        l[t, m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"l_{t}_{m}")

total_skilled = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_skilled")
total_laborers = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_laborers")

# Objective: minimize total weekly cost
obj = skilled_wage * total_skilled + laborer_wage * total_laborers
for t in tasks:
    for m in methods:
        obj += tm_data[t, m]['Fixed_Cost'] * y[t, m]
model.setObjective(obj, GRB.MINIMIZE)

# Constraints

# Total workers definition
model.addConstr(total_skilled == gp.quicksum(s[t, m] for t in tasks for m in methods), "TotalSkilledDef")
model.addConstr(total_laborers == gp.quicksum(l[t, m] for t in tasks for m in methods), "TotalLaborersDef")

# Exactly one method per task
for t in tasks:
    model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1, f"OneMethod_{t}")

# Hours requirement and linking constraints
M_big = 10000
for t in tasks:
    for m in methods:
        req_hours = tm_data[t, m]['Effective_Hours']
        # Hours constraint
        model.addConstr(skilled_hours * s[t, m] + laborer_hours * l[t, m] >= req_hours * y[t, m],
                        f"Hours_{t}_{m}")
        # Linking: if y=0, then s and l must be 0
        model.addConstr(s[t, m] <= M_big * y[t, m], f"LinkS_{t}_{m}")
        model.addConstr(l[t, m] <= M_big * y[t, m], f"LinkL_{t}_{m}")

# Max constraints
model.addConstr(total_skilled <= max_skilled, "MaxSkilled")
model.addConstr(total_laborers <= max_laborers, "MaxLaborers")

# Overall hiring ratio: skilled <= 0.6 * laborers
model.addConstr(total_skilled <= skilled_hiring_ratio * total_laborers, "SkilledRatio")

# Exclusion rule: Task 1 Method B excludes Task 3 Method A
model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1, "ExclusionRule")

# Minimum skilled workers for Task 3 if Method B is chosen
model.addConstr(s['Task_3', 'Method_B'] >= min_skilled_task3_B * y['Task_3', 'Method_B'], "MinSkilledTask3B")

# Task-level skill-balance bands
# For each task, the skilled share = sum(s[t,m]) / (sum(s[t,m]) + sum(l[t,m])) must be between min and max
for t in tasks:
    total_task_workers = gp.quicksum(s[t, m] + l[t, m] for m in methods)
    total_task_skilled = gp.quicksum(s[t, m] for m in methods)
    # min_share[t] <= total_task_skilled / total_task_workers <= max_share[t]
    # Rewrite as: total_task_skilled >= min_share[t] * total_task_workers
    # and total_task_skilled <= max_share[t] * total_task_workers
    model.addConstr(total_task_skilled >= min_share[t] * total_task_workers, f"MinShare_{t}")
    model.addConstr(total_task_skilled <= max_share[t] * total_task_workers, f"MaxShare_{t}")

# Optimize
model.optimize()

# Get results
obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
