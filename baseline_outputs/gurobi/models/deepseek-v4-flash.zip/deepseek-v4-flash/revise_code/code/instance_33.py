import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        value_str = row['Value'].strip()
        if value_str:
            try:
                params[param_name] = float(value_str)
            except ValueError:
                params[param_name] = value_str

# Read items and values
items = []
values = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        items.append(row['Item'].strip())
        values.append(int(row['Value'].strip()))

n = len(items)
total_value = sum(values)

# Extract parameters
num_diamonds = int(params['num_diamonds'])
value_per_diamond = int(params['value_per_diamond'])
son1_min_share = params['son1_min_share']
high_value_threshold = params['high_value_threshold']
max_high_value_items_per_son = int(params['max_high_value_items_per_son'])
deferred_diamonds_per_son = int(params['deferred_diamonds_per_son'])
immediate_tax_weight = params['immediate_tax_weight']
total_tax_weight = params['total_tax_weight']

# Identify diamond indices and high-value item indices
diamond_indices = [i for i, item in enumerate(items) if 'Diamond' in item]
high_value_indices = [i for i, val in enumerate(values) if val > high_value_threshold]

# Identify Jack Russell dog indices
jr_indices = [i for i, item in enumerate(items) if 'Jack Russell' in item]

# Create model
model = gp.Model("Inheritance_Split_Revised")
model.setParam('OutputFlag', 0)

# Decision variables:
# x[i] = 1 if item i goes to son 1 immediately, 0 otherwise
# y[i] = 1 if item i is deferred to son 1, 0 otherwise
# For son 2: immediate = 1-x[i]-y[i] (if not deferred), deferred = y[i] (but we need separate tracking)
# Better approach: use binary variables for each son and each item for immediate/deferred

# Let's use:
# a[i] = 1 if item i goes to son 1 immediately
# b[i] = 1 if item i goes to son 2 immediately
# d[i] = 1 if item i is deferred (to either son)
# Then for each item: a[i] + b[i] + d[i] = 1

a = model.addVars(n, vtype=GRB.BINARY, name="son1_immediate")
b = model.addVars(n, vtype=GRB.BINARY, name="son2_immediate")
d = model.addVars(n, vtype=GRB.BINARY, name="deferred")

# Each item must be assigned to exactly one category
model.addConstrs((a[i] + b[i] + d[i] == 1 for i in range(n)), "assignment")

# Jack Russell dogs must not be separated (both go to same son, immediate or deferred together)
if len(jr_indices) == 2:
    i1, i2 = jr_indices
    # Both must have same immediate assignment or both deferred
    model.addConstr(a[i1] + d[i1] == a[i2] + d[i2], "jr_same_son")
    model.addConstr(b[i1] + d[i1] == b[i2] + d[i2], "jr_same_son2")

# Son 1 minimum share (total ownership: immediate + deferred)
total_son1 = gp.quicksum(values[i] * (a[i] + d[i]) for i in range(n))
model.addConstr(total_son1 >= son1_min_share * total_value, "son1_min_share")

# High-value items concentration limit (immediate + deferred per son)
high_value_son1 = gp.quicksum(a[i] + d[i] for i in high_value_indices)
high_value_son2 = gp.quicksum(b[i] + d[i] for i in high_value_indices)
model.addConstr(high_value_son1 <= max_high_value_items_per_son, "high_value_son1")
model.addConstr(high_value_son2 <= max_high_value_items_per_son, "high_value_son2")

# Deferred diamonds limit per son
deferred_diamonds_son1 = gp.quicksum(d[i] for i in diamond_indices)
deferred_diamonds_son2 = gp.quicksum(d[i] for i in diamond_indices)  # same total deferred diamonds
# Actually deferred diamonds go to one son or the other - need to track which son gets deferred diamonds
# Let's add variables for deferred to son1 and deferred to son2
# We already have d[i] for deferred, but we need to know which son gets the deferred item
# Revise: use d1[i] for deferred to son1, d2[i] for deferred to son2
# Then a[i] + b[i] + d1[i] + d2[i] = 1

# Let's redo with clearer variables
model2 = gp.Model("Inheritance_Split_Revised")
model2.setParam('OutputFlag', 0)

# x[i] = 1 if item i goes to son 1 immediately
# y[i] = 1 if item i goes to son 2 immediately
# z[i] = 1 if item i is deferred to son 1
# w[i] = 1 if item i is deferred to son 2
x = model2.addVars(n, vtype=GRB.BINARY, name="son1_immediate")
y = model2.addVars(n, vtype=GRB.BINARY, name="son2_immediate")
z = model2.addVars(n, vtype=GRB.BINARY, name="son1_deferred")
w = model2.addVars(n, vtype=GRB.BINARY, name="son2_deferred")

# Each item assigned exactly once
model2.addConstrs((x[i] + y[i] + z[i] + w[i] == 1 for i in range(n)), "assignment")

# Jack Russell dogs must not be separated
if len(jr_indices) == 2:
    i1, i2 = jr_indices
    # Both must go to same son (immediate or deferred together)
    model2.addConstr(x[i1] + z[i1] == x[i2] + z[i2], "jr_son1")
    model2.addConstr(y[i1] + w[i1] == y[i2] + w[i2], "jr_son2")

# Son 1 minimum share (total ownership: immediate + deferred)
total_son1 = gp.quicksum(values[i] * (x[i] + z[i]) for i in range(n))
model2.addConstr(total_son1 >= son1_min_share * total_value, "son1_min_share")

# High-value items concentration limit (immediate + deferred per son)
high_value_son1 = gp.quicksum(x[i] + z[i] for i in high_value_indices)
high_value_son2 = gp.quicksum(y[i] + w[i] for i in high_value_indices)
model2.addConstr(high_value_son1 <= max_high_value_items_per_son, "high_value_son1")
model2.addConstr(high_value_son2 <= max_high_value_items_per_son, "high_value_son2")

# Deferred diamonds limit per son
deferred_diamonds_son1 = gp.quicksum(z[i] for i in diamond_indices)
deferred_diamonds_son2 = gp.quicksum(w[i] for i in diamond_indices)
model2.addConstr(deferred_diamonds_son1 <= deferred_diamonds_per_son, "deferred_diamonds_son1")
model2.addConstr(deferred_diamonds_son2 <= deferred_diamonds_per_son, "deferred_diamonds_son2")

# Objective: minimize weighted sum of imbalances
# Immediate value imbalance
immediate_son1 = gp.quicksum(values[i] * x[i] for i in range(n))
immediate_son2 = gp.quicksum(values[i] * y[i] for i in range(n))
immediate_diff = gp.Var(lb=0, vtype=GRB.CONTINUOUS, name="immediate_diff")
model2.addConstr(immediate_diff >= immediate_son1 - immediate_son2)
model2.addConstr(immediate_diff >= immediate_son2 - immediate_son1)

# Total value imbalance (including deferred)
total_son1 = gp.quicksum(values[i] * (x[i] + z[i]) for i in range(n))
total_son2 = gp.quicksum(values[i] * (y[i] + w[i]) for i in range(n))
total_diff = gp.Var(lb=0, vtype=GRB.CONTINUOUS, name="total_diff")
model2.addConstr(total_diff >= total_son1 - total_son2)
model2.addConstr(total_diff >= total_son2 - total_son1)

# Objective
obj = immediate_tax_weight * immediate_diff + total_tax_weight * total_diff
model2.setObjective(obj, GRB.MINIMIZE)

# Solve
model2.optimize()

# Get objective value
obj_val = model2.objVal

print(f"FINAL_OBJ_VALUE: {obj_val}")
