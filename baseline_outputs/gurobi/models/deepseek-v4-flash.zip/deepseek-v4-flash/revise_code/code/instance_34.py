import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load goods data
goods = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        goods[row["Goods_Type"].strip()] = {
            "quantity": int(row["Quantity"].strip()),
            "weight": float(row["Weight_per_Unit"].strip())
        }

# Load parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

max_cap = params["max_container_capacity"]
min_load = params["min_container_load"]
min_d_per_container = int(params["min_d_goods_per_container"])
min_c_per_a = int(params["min_c_per_a"])

goods_types = list(goods.keys())
quantities = {g: goods[g]["quantity"] for g in goods_types}
weights = {g: goods[g]["weight"] for g in goods_types}

# Revised: E containers have reduced capacity of 45 tons
e_reduced_cap = 45.0

# Upper bound on containers: generous estimate
# D: 90 units, min 10 per container -> max 9 containers from D constraint
# Total weight: 120*0.5 + 90*1 + 300*0.4 + 90*0.6 + 120*0.65 = 60 + 90 + 120 + 54 + 78 = 402 tons
# With min load 18, max containers = floor(402/18) = 22, but capacity limits more
# Use 20 as generous upper bound
max_containers = 20
N = range(max_containers)

# Create model
model = gp.Model("ContainerMinimization")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}
for g in goods_types:
    x[g] = model.addVars(N, vtype=GRB.INTEGER, lb=0, name=f"x_{g}")
y = model.addVars(N, vtype=GRB.BINARY, name="y")
z = model.addVars(N, vtype=GRB.BINARY, name="z")  # indicator for A in container
e_flag = model.addVars(N, vtype=GRB.BINARY, name="e_flag")  # indicator for E in container

# Objective: minimize number of containers used
model.setObjective(gp.quicksum(y[j] for j in N), GRB.MINIMIZE)

# All goods must be transported
for g in goods_types:
    model.addConstr(gp.quicksum(x[g][j] for j in N) == quantities[g], name=f"demand_{g}")

# Container capacity constraint (standard)
for j in N:
    model.addConstr(gp.quicksum(weights[g] * x[g][j] for g in goods_types) <= max_cap * y[j], name=f"max_cap_{j}")

# Reduced capacity for containers with E goods
M_cap = max_cap  # big M
for j in N:
    model.addConstr(gp.quicksum(weights[g] * x[g][j] for g in goods_types) <= max_cap * y[j] - (max_cap - e_reduced_cap) * e_flag[j], name=f"e_cap_{j}")
    model.addConstr(x['E'][j] <= quantities['E'] * e_flag[j], name=f"e_indicator_{j}")
    model.addConstr(e_flag[j] <= y[j], name=f"e_only_if_used_{j}")

# Minimum load constraint
for j in N:
    model.addConstr(gp.quicksum(weights[g] * x[g][j] for g in goods_types) >= min_load * y[j], name=f"min_load_{j}")

# Minimum D goods per container (if container is used)
for j in N:
    model.addConstr(x['D'][j] >= min_d_per_container * y[j], name=f"min_D_{j}")

# If A goods are loaded, at least 1 C good must be loaded
M_A = quantities['A']
for j in N:
    model.addConstr(x['A'][j] <= M_A * z[j], name=f"A_indicator_{j}")
    model.addConstr(x['C'][j] >= min_c_per_a * z[j], name=f"C_if_A_{j}")

# Symmetry breaking
for j in range(len(N) - 1):
    model.addConstr(y[j] >= y[j+1], name=f"symmetry_{j}")

# Solve
model.optimize()

# Get objective value
if model.status == GRB.OPTIMAL or model.status == GRB.SUBOPTIMAL:
    obj_val = int(model.objVal)
else:
    obj_val = -1  # Infeasible or error

print(f"FINAL_OBJ_VALUE: {obj_val}")
