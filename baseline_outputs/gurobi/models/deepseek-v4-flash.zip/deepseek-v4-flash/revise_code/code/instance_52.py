import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    
    n = len(shifts)  # number of periods (6)
    required = [s['required'] for s in shifts]
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    shift_duration = int(params['shift_duration'])
    driver_rest_gap = int(params['driver_rest_gap'])
    crew_rest_gap = int(params['crew_rest_gap'])
    max_night_driver_fraction = params['max_night_driver_fraction']
    max_night_crew_fraction = params['max_night_crew_fraction']
    max_overtime_shifts = int(params['max_overtime_shifts'])
    overtime_cost_factor = params['overtime_cost_factor']
    
    # Each time period is 4 hours, shift_duration is 8 hours = 2 periods
    periods_per_shift = shift_duration // 4  # = 2
    
    # Late-night periods (0-indexed): periods 4 and 5 (22:00-2:00 and 2:00-6:00)
    night_periods = [4, 5]
    
    # Create model
    model = gp.Model("BusScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Regular driver starts at each period
    x_driver = [model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_driver_{i+1}") for i in range(n)]
    # Regular crew starts at each period
    x_crew = [model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_crew_{i+1}") for i in range(n)]
    # Overtime driver starts at each period
    y_driver = [model.addVar(vtype=GRB.INTEGER, lb=0, name=f"y_driver_{i+1}") for i in range(n)]
    # Overtime crew starts at each period
    y_crew = [model.addVar(vtype=GRB.INTEGER, lb=0, name=f"y_crew_{i+1}") for i in range(n)]
    
    # Objective: minimize regular drivers + regular crew + 1.5 * (overtime drivers + overtime crew)
    obj = gp.quicksum(x_driver) + gp.quicksum(x_crew) + overtime_cost_factor * (gp.quicksum(y_driver) + gp.quicksum(y_crew))
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Coverage constraints: for each period j, total drivers (regular + overtime) covering j >= required[j]
    for j in range(n):
        driver_covering = []
        crew_covering = []
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                driver_covering.append(x_driver[i] + y_driver[i])
                crew_covering.append(x_crew[i] + y_crew[i])
        model.addConstr(gp.quicksum(driver_covering) >= required[j], f"Driver_demand_{j+1}")
        model.addConstr(gp.quicksum(crew_covering) >= required[j], f"Crew_demand_{j+1}")
    
    # Night shift fraction constraints
    # Total regular + overtime starts for drivers
    total_driver_starts = gp.quicksum(x_driver) + gp.quicksum(y_driver)
    total_crew_starts = gp.quicksum(x_crew) + gp.quicksum(y_crew)
    
    # Night starts for drivers and crew
    night_driver_starts = gp.quicksum(x_driver[i] + y_driver[i] for i in night_periods)
    night_crew_starts = gp.quicksum(x_crew[i] + y_crew[i] for i in night_periods)
    
    # Driver night fraction constraint: night_driver_starts <= max_night_driver_fraction * total_driver_starts
    model.addConstr(night_driver_starts <= max_night_driver_fraction * total_driver_starts, "Driver_night_fraction")
    
    # Crew night fraction constraint: night_crew_starts <= max_night_crew_fraction * total_crew_starts
    model.addConstr(night_crew_starts <= max_night_crew_fraction * total_crew_starts, "Crew_night_fraction")
    
    # Rest gap constraints: for each late-night period, ensure enough rest gap
    # For drivers: in each late-night period, the number of drivers starting in that period 
    # must be <= total_driver_starts / (driver_rest_gap + 1) approximately
    # More precisely: for each night period p, the number of drivers starting at p 
    # should be at most total_driver_starts / (driver_rest_gap + 1)
    # This is a proxy for ensuring rest gap
    for p in night_periods:
        model.addConstr(x_driver[p] + y_driver[p] <= (1.0 / (driver_rest_gap + 1)) * total_driver_starts, 
                       f"Driver_rest_gap_period_{p+1}")
        model.addConstr(x_crew[p] + y_crew[p] <= (1.0 / (crew_rest_gap + 1)) * total_crew_starts, 
                       f"Crew_rest_gap_period_{p+1}")
    
    # Overtime cap: total overtime shifts across both groups <= max_overtime_shifts
    model.addConstr(gp.quicksum(y_driver) + gp.quicksum(y_crew) <= max_overtime_shifts, "Overtime_cap")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    
    # Print solution details
    for i in range(n):
        print(f"Regular drivers starting at period {i+1}: {int(x_driver[i].X)}")
        print(f"Regular crew starting at period {i+1}: {int(x_crew[i].X)}")
        print(f"Overtime drivers starting at period {i+1}: {int(y_driver[i].X)}")
        print(f"Overtime crew starting at period {i+1}: {int(y_crew[i].X)}")
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
