import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load monthly data
months = []
purchasing_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        month = int(row['Month'])
        months.append(month)
        purchasing_prices[month] = float(row['Purchasing_Price_Yuan'])
        selling_prices[month] = float(row['Selling_Price_Yuan'])

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

warehouse_capacity = int(params['warehouse_capacity'])
initial_stock = int(params['initial_stock'])
fixed_ordering_cost = int(params['fixed_ordering_cost'])
month2_bulk_threshold = int(params['month2_bulk_receiving_threshold'])
month2_bulk_fee = int(params['month2_bulk_receiving_fee'])

# Create model
model = gp.Model("Maximize_Profit")
model.setParam('OutputFlag', 0)

# Decision variables
x = {m: model.addVar(lb=0, name=f"purchase_{m}") for m in months}
s = {m: model.addVar(lb=0, name=f"sell_{m}") for m in months}
inv = {m: model.addVar(lb=0, name=f"inventory_{m}") for m in months}

# Binary variables for fixed ordering cost
y = {m: model.addVar(vtype=GRB.BINARY, name=f"order_binary_{m}") for m in months}

# Binary variable for February bulk receiving fee
z = model.addVar(vtype=GRB.BINARY, name="feb_bulk_fee")

# Big M for constraints
M = 10000  # Large enough

# Objective: maximize profit
profit = gp.quicksum(selling_prices[m] * s[m] - purchasing_prices[m] * x[m] for m in months)
profit -= fixed_ordering_cost * gp.quicksum(y[m] for m in months)
profit -= month2_bulk_fee * z
model.setObjective(profit, GRB.MAXIMIZE)

# Constraints
for m in months:
    # Inventory balance
    if m == months[0]:
        prev_inv = initial_stock
    else:
        prev_inv = inv[m - 1]
    
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], f"inventory_balance_{m}")
    
    # Warehouse capacity after purchase
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, f"warehouse_after_purchase_{m}")
    
    # End-of-month inventory capacity
    model.addConstr(inv[m] <= warehouse_capacity, f"warehouse_end_{m}")
    
    # Sell limit
    model.addConstr(s[m] <= prev_inv + x[m], f"sell_limit_{m}")
    
    # Fixed ordering cost: if x[m] > 0 then y[m] = 1
    model.addConstr(x[m] <= M * y[m], f"order_indicator_{m}")

# February bulk receiving fee constraint
# If February purchase > 300, then z = 1
model.addConstr(x[2] <= month2_bulk_threshold + M * z, "feb_bulk_threshold")
model.addConstr(x[2] >= month2_bulk_threshold + 1 - M * (1 - z), "feb_bulk_trigger")

# Solve
model.optimize()

# Get results
obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
