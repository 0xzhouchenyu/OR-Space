import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Get the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv")) as f:
    for row in csv.DictReader(f):
        params[row["Parameter_Name"].strip()] = float(row["Value"])

# Read product data
products = {}
with open(os.path.join(data_dir, "table_1.csv")) as f:
    for row in csv.DictReader(f):
        products[row["Product"].strip()] = {
            "a_hrs": float(row["Workshop_A_Hours"]),
            "b_hrs": float(row["Workshop_B_Hours"]),
            "insp_cost": float(row["Inspection_Sales_Cost"])
        }

# Extract parameters
a_avail = params["workshop_a_available_hours"]
a_cost = params["workshop_a_hourly_cost"]
b_avail = params["workshop_b_available_hours"]
b_cost = params["workshop_b_hourly_cost"]
insp_limit = params["inspection_sales_cost_limit"]
microwave_min = params["microwave_minimum_sales"]
water_heater_min = params["water_heater_minimum_sales"]
overtime_limit = params["workshop_a_overtime_limit"]
setup_hours = params["setup_hours_A"]
tech_pool = params["tech_pool_hours"]
tech_rate_m = params["tech_rate_m"]
tech_rate_w = params["tech_rate_w"]
green_bonus_m = params["green_bonus_m"]
green_bonus_w = params["green_bonus_w"]
bigM = params["bigM"]

# Product data
m = products["Microwave_Oven"]
w = products["Water_Heater"]

# Create model
model = gp.Model("production_revised")
model.setParam('OutputFlag', 0)

# Decision variables
x1 = model.addVar(lb=microwave_min, name="microwave")  # microwave production
x2 = model.addVar(lb=water_heater_min, name="water_heater")  # water heater production

# Binary variables for activation (whether product uses Workshop A)
y1 = model.addVar(vtype=GRB.BINARY, name="activate_microwave")
y2 = model.addVar(vtype=GRB.BINARY, name="activate_water_heater")

# Objective: maximize profit = revenue + green bonus - costs
# Revenue is based on workshop costs + inspection costs (as in original heuristic)
# Green bonus is added for certified output
revenue_m = m["a_hrs"] * a_cost + m["b_hrs"] * b_cost + m["insp_cost"]
revenue_w = w["a_hrs"] * a_cost + w["b_hrs"] * b_cost + w["insp_cost"]

# Objective: maximize (revenue + green bonus) * production
model.setObjective(
    (revenue_m + green_bonus_m) * x1 + (revenue_w + green_bonus_w) * x2,
    GRB.MAXIMIZE
)

# Constraints

# 1. Workshop A hours: production hours + setup hours (if activated) <= available + overtime
model.addConstr(
    m["a_hrs"] * x1 + w["a_hrs"] * x2 + setup_hours * y1 + setup_hours * y2 <= a_avail + overtime_limit,
    "workshop_A_capacity"
)

# 2. Workshop B hours: production hours <= available (no overtime mentioned for B)
model.addConstr(
    m["b_hrs"] * x1 + w["b_hrs"] * x2 <= b_avail,
    "workshop_B_capacity"
)

# 3. Inspection and sales cost limit
model.addConstr(
    m["insp_cost"] * x1 + w["insp_cost"] * x2 <= insp_limit,
    "inspection_cost"
)

# 4. Technician pool constraint
model.addConstr(
    tech_rate_m * x1 + tech_rate_w * x2 <= tech_pool,
    "tech_pool"
)

# 5. Activation linking constraints: if product > 0, then activation = 1
model.addConstr(x1 <= bigM * y1, "activate_microwave_link")
model.addConstr(x2 <= bigM * y2, "activate_water_heater_link")

# 6. If product is at minimum, it still needs activation (since it uses Workshop A)
model.addConstr(y1 >= 1, "microwave_always_active")  # microwave always uses Workshop A
model.addConstr(y2 >= 1, "water_heater_always_active")  # water heater always uses Workshop A

# Optimize
model.optimize()

# Print result
print(f"FINAL_OBJ_VALUE: {model.objVal}")
