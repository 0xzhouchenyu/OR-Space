import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load demand forecast
demand = {}
with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for i, row in enumerate(reader):
        demand[i] = float(row['Demand_Forecast'])

T = len(demand)  # 6 months

# Load general parameters
params = {}
with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

W0 = int(params['initial_workforce'])
I0 = params['initial_inventory']
sp = params['sales_price']
rmc = params['raw_material_cost']
oc = params['outsourcing_cost']
hc = params['inventory_holding_cost']
bc = params['backorder_cost']
lr = params['labor_requirement']
rh = params['regular_labor_hours']
rw = params['regular_wage']
otl = params['overtime_hours_limit']
ow = params['overtime_wage']
hire_cost = params['hiring_cost']
fire_cost = params['firing_cost']
term_inv = params['terminal_inventory']
term_bo = params['terminal_backorders']
contract_min = int(params['contract_min_units'])
contract_bigM = int(params['contract_bigM'])

# Create model
model = gp.Model("FoldableTableProduction_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
W = model.addVars(T, lb=0, name="W")  # workforce
H = model.addVars(T, lb=0, name="H")  # hired
F = model.addVars(T, lb=0, name="F")  # fired
P = model.addVars(T, lb=0, name="P")  # in-house production
OT_total = model.addVars(T, lb=0, name="OT")  # total overtime hours
O = model.addVars(T, lb=0, name="O")  # outsourced units
Inv = model.addVars(T, lb=0, name="Inv")  # inventory
B = model.addVars(T, lb=0, name="B")  # backorders

# Additional variables for contract constraints (April = index 3, May = 4, June = 5)
# Binary indicators: 1 if contract is satisfied by regular-time production
y = model.addVars([3, 4, 5], vtype=GRB.BINARY, name="y")
# Regular-time production (in-house production from regular hours only)
P_reg = model.addVars([3, 4, 5], lb=0, name="P_reg")
# Auxiliary variable for contract-qualified production
Q = model.addVars([3, 4, 5], lb=0, name="Q")

# Constraints
for t in range(T):
    # Workforce balance
    if t == 0:
        model.addConstr(W[t] == W0 + H[t] - F[t])
    else:
        model.addConstr(W[t] == W[t-1] + H[t] - F[t])
    
    # Production limited by total labor hours (regular + overtime)
    model.addConstr(P[t] * lr <= W[t] * rh + OT_total[t])
    
    # Overtime limit
    model.addConstr(OT_total[t] <= W[t] * otl)
    
    # Inventory balance: Inv[t] - B[t] = (Inv[t-1] - B[t-1]) + P[t] + O[t] - demand[t]
    prev_inv = I0 if t == 0 else Inv[t-1]
    prev_b = 0 if t == 0 else B[t-1]
    model.addConstr(Inv[t] - B[t] == prev_inv - prev_b + P[t] + O[t] - demand[t])

# Terminal conditions
model.addConstr(Inv[T-1] >= term_inv)
model.addConstr(B[T-1] <= term_bo)

# Contract constraints for April, May, June (indices 3, 4, 5)
for t in [3, 4, 5]:
    # Regular-time production capacity
    model.addConstr(P_reg[t] <= W[t] * rh / lr)
    # Regular-time production cannot exceed total production
    model.addConstr(P_reg[t] <= P[t])
    # Total production from regular hours is at most regular capacity
    model.addConstr(P[t] * lr >= W[t] * rh * y[t])  # if y=1, at least regular capacity used
    # If y=1, then P_reg[t] = W[t] * rh / lr (full regular capacity used for contract)
    model.addConstr(P_reg[t] >= W[t] * rh / lr - contract_bigM * (1 - y[t]))
    model.addConstr(P_reg[t] <= W[t] * rh / lr + contract_bigM * (1 - y[t]))
    
    # Contract-qualified production Q[t] is min(P_reg[t], demand[t] + B[t-1] - Inv[t-1] + B[t] - Inv[t]? 
    # Actually: monthly requirement = demand[t] + B[t-1] - B[t] (net demand after backlog change)
    # But we need to ensure Q[t] >= contract_min when y[t]=1
    # Q[t] is the amount that counts toward contract (regular-time production applied to current month's requirement)
    # Net requirement for month t: demand[t] + (B[t-1] if t>0 else 0) - B[t]
    net_req = demand[t] + (B[t-1] if t > 0 else 0) - B[t]
    
    # Q[t] cannot exceed regular-time production
    model.addConstr(Q[t] <= P_reg[t])
    # Q[t] cannot exceed net requirement (demand + incoming backlog - outgoing backlog)
    model.addConstr(Q[t] <= net_req + contract_bigM * (1 - y[t]))
    model.addConstr(Q[t] >= net_req - contract_bigM * (1 - y[t]))
    
    # Contract minimum: if y[t]=1, then Q[t] >= contract_min
    model.addConstr(Q[t] >= contract_min * y[t])
    
    # Also ensure that if y[t]=0, then Q[t] = 0 (no contract qualification)
    model.addConstr(Q[t] <= contract_bigM * y[t])

# Objective: maximize net profit
total_demand = sum(demand[t] for t in range(T))
revenue = sp * total_demand

material_cost = gp.quicksum(rmc * P[t] for t in range(T))
outsource_cost = gp.quicksum(oc * O[t] for t in range(T))
holding_cost = gp.quicksum(hc * Inv[t] for t in range(T))
backorder_cost_total = gp.quicksum(bc * B[t] for t in range(T))
regular_labor_cost = gp.quicksum(rw * rh * W[t] for t in range(T))
overtime_cost = gp.quicksum(ow * OT_total[t] for t in range(T))
hiring_cost_total = gp.quicksum(hire_cost * H[t] for t in range(T))
firing_cost_total = gp.quicksum(fire_cost * F[t] for t in range(T))

total_cost = (material_cost + outsource_cost + holding_cost + backorder_cost_total +
              regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total)

model.setObjective(revenue - total_cost, GRB.MAXIMIZE)

# Solve
model.optimize()

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
