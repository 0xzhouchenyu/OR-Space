import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load parameters
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    df = pd.read_csv(data_path)
    
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = row['Value']
    
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = int(params['raw_bar_length'])
    setup_cost = float(params['setup_cost_per_pattern'])
    max_patterns = int(params['max_distinct_patterns'])
    
    # Lengths of the three types of steel bars
    len1 = 3
    len2 = 4
    len3 = 5
    
    # Generate all valid cutting patterns
    patterns = []
    for x in range(L // len1 + 1):
        for y in range(L // len2 + 1):
            for z in range(L // len3 + 1):
                if len1 * x + len2 * y + len3 * z <= L:
                    if x > 0 or y > 0 or z > 0:
                        patterns.append((x, y, z))
    
    n_patterns = len(patterns)
    
    # Create model
    model = gp.Model("CuttingStock")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of times each pattern is used
    x = model.addVars(n_patterns, vtype=GRB.INTEGER, lb=0, name="Pattern")
    
    # Binary variables: whether each pattern is used
    y = model.addVars(n_patterns, vtype=GRB.BINARY, name="PatternUsed")
    
    # Big M for linking constraints
    M = max(q3, q4, q5) * 2  # Sufficiently large
    
    # Link x and y variables
    for i in range(n_patterns):
        model.addConstr(x[i] <= M * y[i], name=f"Link_{i}")
    
    # Constraint: max distinct patterns
    model.addConstr(gp.quicksum(y[i] for i in range(n_patterns)) <= max_patterns, 
                    name="MaxPatterns")
    
    # Constraints: satisfy demand
    model.addConstr(gp.quicksum(patterns[i][0] * x[i] for i in range(n_patterns)) >= q3, 
                    name="Demand3m")
    model.addConstr(gp.quicksum(patterns[i][1] * x[i] for i in range(n_patterns)) >= q4, 
                    name="Demand4m")
    model.addConstr(gp.quicksum(patterns[i][2] * x[i] for i in range(n_patterns)) >= q5, 
                    name="Demand5m")
    
    # Objective: minimize total waste including setup costs
    # Waste = (raw material used) - (required product length) + (setup costs)
    raw_material_used = gp.quicksum(L * x[i] for i in range(n_patterns))
    required_length = len1 * q3 + len2 * q4 + len3 * q5
    setup_costs = gp.quicksum(setup_cost * y[i] for i in range(n_patterns))
    
    model.setObjective(raw_material_used - required_length + setup_costs, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    solve()
