import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                "name": row["Candidate"].strip(),
                "salary": int(row["Salary"].strip()),
                "skill": int(row["Skill_Level"].strip()),
                "pm_exp": int(row["Project_Management_Experience"].strip())
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    budget = params["company_budget"]
    max_employees = int(params["max_employees"])
    min_skill = params["min_skill_level"]
    min_pm_exp = params["min_project_experience"]
    max_gj = int(params["max_one_candidate_g_j"])
    lead_premium = params["lead_premium"]
    min_leads = int(params["min_leads"])
    mentor_bonus = params["mentor_bonus"]
    max_pairs = int(params["max_pairs"])
    
    # Create model
    model = gp.Model("HiringOptimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    hire = {}
    lead = {}
    engineer = {}
    for c in candidates:
        name = c["name"]
        hire[name] = model.addVar(vtype=GRB.BINARY, name=f"hire_{name}")
        lead[name] = model.addVar(vtype=GRB.BINARY, name=f"lead_{name}")
        engineer[name] = model.addVar(vtype=GRB.BINARY, name=f"engineer_{name}")
    
    # Mentorship pairs variable (integer)
    pairs = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_pairs, name="mentorship_pairs")
    
    # Constraints
    
    # Each hired candidate must have exactly one role
    for c in candidates:
        name = c["name"]
        model.addConstr(lead[name] + engineer[name] == hire[name], f"role_assignment_{name}")
    
    # Budget constraint (net cost = salaries + lead_premium - mentor_bonus * pairs)
    total_salary = gp.quicksum(c["salary"] * hire[c["name"]] for c in candidates)
    total_lead_premium = gp.quicksum(lead_premium * lead[c["name"]] for c in candidates)
    model.addConstr(total_salary + total_lead_premium - mentor_bonus * pairs <= budget, "Budget")
    
    # Max employees
    model.addConstr(gp.quicksum(hire[c["name"]] for c in candidates) <= max_employees, "MaxEmployees")
    
    # Min skill level
    model.addConstr(gp.quicksum(c["skill"] * hire[c["name"]] for c in candidates) >= min_skill, "MinSkill")
    
    # Min project management experience
    model.addConstr(gp.quicksum(c["pm_exp"] * hire[c["name"]] for c in candidates) >= min_pm_exp, "MinPMExp")
    
    # At most one of G and J
    model.addConstr(hire["G"] + hire["J"] <= max_gj, "MaxOneGJ")
    
    # Minimum leads
    model.addConstr(gp.quicksum(lead[c["name"]] for c in candidates) >= min_leads, "MinLeads")
    
    # Mentorship pairs constraints
    total_leads = gp.quicksum(lead[c["name"]] for c in candidates)
    total_engineers = gp.quicksum(engineer[c["name"]] for c in candidates)
    model.addConstr(pairs <= total_leads, "PairsLeads")
    model.addConstr(pairs <= total_engineers, "PairsEngineers")
    model.addConstr(pairs <= max_pairs, "PairsMax")
    
    # Objective: minimize net cost (salaries + lead_premium - mentor_bonus * pairs)
    obj = total_salary + total_lead_premium - mentor_bonus * pairs
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
