import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    students = []
    with open(os.path.join(base, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            s = {
                "Student_ID": int(row["Student_ID"]),
                "Wage_CNY_per_hour": float(row["Wage_CNY_per_hour"]),
            }
            for d in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]:
                s[d] = float(row[d])
            students.append(s)
    
    params = {}
    with open(os.path.join(base, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"]
            val = row["Value"]
            try:
                params[name] = int(val)
            except ValueError:
                try:
                    params[name] = float(val)
                except ValueError:
                    params[name] = val
    return students, params

def main():
    students, params = load_data()
    
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    student_ids = [s["Student_ID"] for s in students]
    grad_students = {5, 6}
    
    hours_per_day = 14
    min_undergrad = params["min_undergrad_hours"]
    min_grad = params["min_grad_hours"]
    max_shifts = params["max_shifts_per_student"]
    max_students_day = params["max_students_per_day"]
    daily_open_fee = params["daily_open_fee_cny"]
    min_grad_weekly = params["min_grad_weekly_coverage_hours"]
    
    wage = {s["Student_ID"]: s["Wage_CNY_per_hour"] for s in students}
    avail = {(s["Student_ID"], d): s[d] for s in students for d in days}
    
    # Create model
    model = gp.Model("Lab_Scheduling")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    x = {}  # hours worked by student i on day d
    y = {}  # binary: 1 if student i works on day d
    z = {}  # binary: same as y (for clarity, we'll use y directly in objective)
    
    for i in student_ids:
        for d in days:
            x[i, d] = model.addVar(lb=0, ub=avail[i, d], vtype=GRB.CONTINUOUS, name=f"x_{i}_{d}")
            y[i, d] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{d}")
    
    # Objective: minimize total wages + fixed daily open fees
    obj = gp.quicksum(wage[i] * x[i, d] for i in student_ids for d in days)
    obj += gp.quicksum(daily_open_fee * y[i, d] for i in student_ids for d in days)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraint 1: Exactly 14 hours coverage per day
    for d in days:
        model.addConstr(gp.quicksum(x[i, d] for i in student_ids) == hours_per_day, f"coverage_{d}")
    
    # Constraint 2: Link x and y (if x > 0 then y = 1)
    for i in student_ids:
        for d in days:
            model.addConstr(x[i, d] <= avail[i, d] * y[i, d], f"link_{i}_{d}")
    
    # Constraint 3: Max shifts per student per week
    for i in student_ids:
        model.addConstr(gp.quicksum(y[i, d] for d in days) <= max_shifts, f"max_shifts_{i}")
    
    # Constraint 4: Max students per day
    for d in days:
        model.addConstr(gp.quicksum(y[i, d] for i in student_ids) <= max_students_day, f"max_students_{d}")
    
    # Constraint 5: Minimum weekly hours per student
    for i in student_ids:
        min_h = min_grad if i in grad_students else min_undergrad
        model.addConstr(gp.quicksum(x[i, d] for d in days) >= min_h, f"min_hours_{i}")
    
    # Constraint 6: Minimum total graduate hours per week
    model.addConstr(
        gp.quicksum(x[i, d] for i in grad_students for d in days) >= min_grad_weekly,
        "min_grad_weekly"
    )
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
