import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Get the data directory path
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load warehouse data
warehouses_data = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        warehouses_data.append(row)

warehouses = []
supply = {}
for row in warehouses_data:
    name = row['Warehouse']
    warehouses.append(name)
    supply[name] = int(row['Empty_Containers'])

# Load port data
ports_data = []
with open(os.path.join(data_dir, 'table_2.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        ports_data.append(row)

ports = []
demand = {}
for row in ports_data:
    name = row['Port']
    ports.append(name)
    demand[name] = int(row['Container_Demand'])

# Load distance data
distance_data = []
with open(os.path.join(data_dir, 'table_3.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        distance_data.append(row)

distance = {}
for row in distance_data:
    wh = row['Warehouse']
    for port in ports:
        distance[(wh, port)] = float(row[port])

# Load general parameters
params_data = []
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params_data.append(row)

params = {}
for row in params_data:
    params[row['Parameter_Name']] = float(row['Value'])

cost_per_km = params['cost_per_km']
truck_capacity = params['truck_capacity']
adriatic_pool_shortage_trigger = params['adriatic_pool_shortage_trigger']
adriatic_pool_recovery_fee = params['adriatic_pool_recovery_fee']

# Load shortage penalty data
shortage_data = []
with open(os.path.join(data_dir, 'shortage_penalty.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        shortage_data.append(row)

shortage_charge = {}
grace_containers = {}
recovery_fee = {}
for row in shortage_data:
    port = row['Port']
    shortage_charge[port] = float(row['Shortage_Charge'])
    grace_containers[port] = float(row['Grace_Containers'])
    recovery_fee[port] = float(row['Recovery_Fee'])

# Adriatic ports
adriatic_ports = ['Venice', 'Ancona', 'Bari']

# Create model
model = gp.Model("Container_Transportation_Revised")
model.setParam('OutputFlag', 0)

# Decision variables: number of containers shipped from warehouse i to port j
x = {}
for i in warehouses:
    for j in ports:
        x[(i, j)] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{i}_{j}")

# Shortage variables for each port
shortage = {}
for j in ports:
    shortage[j] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"shortage_{j}")

# Binary variables for recovery desk at each port (1 if shortage > grace_containers)
recovery_open = {}
for j in ports:
    recovery_open[j] = model.addVar(vtype=GRB.BINARY, name=f"recovery_open_{j}")

# Binary variable for Adriatic regional recovery desk
adriatic_recovery_open = model.addVar(vtype=GRB.BINARY, name="adriatic_recovery_open")

# Variable for total Adriatic shortage
adriatic_total_shortage = model.addVar(lb=0, vtype=GRB.INTEGER, name="adriatic_total_shortage")

# Objective: minimize total cost
# Transport cost: cost_per_km * distance * number of containers
transport_cost = gp.quicksum(x[(i, j)] * distance[(i, j)] * cost_per_km for i in warehouses for j in ports)

# Shortage disruption cost: shortage_charge * shortage for each port
shortage_cost = gp.quicksum(shortage_charge[j] * shortage[j] for j in ports)

# Recovery desk fixed costs for individual ports
recovery_cost = gp.quicksum(recovery_fee[j] * recovery_open[j] for j in ports)

# Adriatic regional recovery desk fixed cost
adriatic_recovery_cost = adriatic_pool_recovery_fee * adriatic_recovery_open

model.setObjective(transport_cost + shortage_cost + recovery_cost + adriatic_recovery_cost, GRB.MINIMIZE)

# Supply constraints: total containers shipped from each warehouse <= supply
for i in warehouses:
    model.addConstr(gp.quicksum(x[(i, j)] for j in ports) <= supply[i], f"supply_{i}")

# Demand constraints: containers shipped to port + shortage = demand
for j in ports:
    model.addConstr(gp.quicksum(x[(i, j)] for i in warehouses) + shortage[j] == demand[j], f"demand_{j}")

# Recovery desk opening constraints: if shortage > grace_containers, recovery must open
# Use big-M formulation
M = 100  # Large enough (max shortage is demand, max demand is 33)
for j in ports:
    model.addConstr(shortage[j] <= grace_containers[j] + M * recovery_open[j], f"recovery_trigger_{j}")
    model.addConstr(shortage[j] >= grace_containers[j] + 1 - M * (1 - recovery_open[j]), f"recovery_trigger_lb_{j}")

# Adriatic total shortage
model.addConstr(adriatic_total_shortage == gp.quicksum(shortage[j] for j in adriatic_ports), "adriatic_total")

# Adriatic regional recovery desk: opens if total shortage > trigger
model.addConstr(adriatic_total_shortage <= adriatic_pool_shortage_trigger + M * adriatic_recovery_open, "adriatic_trigger")
model.addConstr(adriatic_total_shortage >= adriatic_pool_shortage_trigger + 1 - M * (1 - adriatic_recovery_open), "adriatic_trigger_lb")

# Optimize
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
