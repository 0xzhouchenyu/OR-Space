import csv
import os
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def solve():
    # Read orders
    table_1_path = get_data_path("table_1.csv")
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
    
    # Read parameters
    params_path = get_data_path("general_parameters.csv")
    params = {}
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    std_widths = [params['standard_width_1'], params['standard_width_2']]
    pattern_setup_penalty = params['pattern_setup_penalty']
    wide_roll_threshold = params['wide_roll_threshold_width']
    wide_roll_extra_penalty = params['wide_roll_extra_setup_penalty']
    
    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    n_orders = len(widths)
    
    # Generate all possible cutting patterns for each standard width
    patterns_by_std_width = {}
    for idx, sw in enumerate(std_widths):
        patterns = []
        def build_pattern(index, current_pattern, current_sum):
            if index == n_orders:
                if any(c > 0 for c in current_pattern):
                    patterns.append(tuple(current_pattern))
                return
            
            max_count = int((sw - current_sum + 1e-7) // widths[index])
            for count in range(max_count + 1):
                build_pattern(index + 1, current_pattern + [count], current_sum + count * widths[index])
        
        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {'sw': sw, 'patterns': patterns}
    
    # Build optimization model
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: how many times each pattern is used on each standard width
    x_vars = {}
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            var_name = f"x_{idx}_{i}"
            x_vars[(idx, i)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=var_name)
    
    # Binary variables to indicate if a pattern is used (for setup penalties)
    y_vars = {}
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            var_name = f"y_{idx}_{i}"
            y_vars[(idx, i)] = model.addVar(vtype=GRB.BINARY, name=var_name)
    
    # Objective: minimize total area used + pattern setup penalties + wide roll extra penalties
    total_area = gp.quicksum(
        data['sw'] * x_vars[(idx, i)]
        for idx, data in patterns_by_std_width.items()
        for i, p in enumerate(data['patterns'])
    )
    
    setup_penalty = pattern_setup_penalty * gp.quicksum(y_vars.values())
    
    # Extra penalty for patterns used on wide rolls (width >= 2 meters)
    extra_wide_penalty = 0
    for idx, data in patterns_by_std_width.items():
        if data['sw'] >= wide_roll_threshold - 1e-7:
            extra_wide_penalty += wide_roll_extra_penalty * gp.quicksum(
                y_vars[(idx, i)] for i in range(len(data['patterns']))
            )
    
    model.setObjective(total_area + setup_penalty + extra_wide_penalty, GRB.MINIMIZE)
    
    # Constraints: satisfy length requirements for each order width
    for j in range(n_orders):
        model.addConstr(
            gp.quicksum(
                p[j] * x_vars[(idx, i)]
                for idx, data in patterns_by_std_width.items()
                for i, p in enumerate(data['patterns'])
            ) >= lengths[j],
            name=f"demand_{j}"
        )
    
    # Linking constraints: y = 1 if x > 0, y = 0 if x = 0
    bigM = 1e6
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            model.addConstr(
                x_vars[(idx, i)] <= bigM * y_vars[(idx, i)],
                name=f"link_{idx}_{i}_upper"
            )
            model.addConstr(
                y_vars[(idx, i)] <= x_vars[(idx, i)] + bigM * (1 - y_vars[(idx, i)]),
                name=f"link_{idx}_{i}_lower"
            )
    
    # Optimize
    model.optimize()
    
    # Calculate objective value
    total_area_used = sum(
        data['sw'] * x_vars[(idx, i)].X
        for idx, data in patterns_by_std_width.items()
        for i, p in enumerate(data['patterns'])
    )
    
    total_setup_penalty = pattern_setup_penalty * sum(y_vars.values())
    
    total_extra_wide = 0
    for idx, data in patterns_by_std_width.items():
        if data['sw'] >= wide_roll_threshold - 1e-7:
            total_extra_wide += wide_roll_extra_penalty * sum(
                y_vars[(idx, i)].X for i in range(len(data['patterns']))
            )
    
    total_required_area = sum(w * l for w, l in zip(widths, lengths))
    waste = total_area_used - total_required_area + total_setup_penalty + total_extra_wide
    
    print(f"FINAL_OBJ_VALUE: {round(waste, 4)}")

if __name__ == "__main__":
    solve()
