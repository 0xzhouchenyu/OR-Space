import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params_file = os.path.join(data_dir, 'general_parameters.csv')

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
shirts_inventory = int(params['shirts_inventory'])
pants_inventory = int(params['pants_inventory'])
price_a = params['package_a_price']
price_b = params['package_b_price']
price_c = params['package_c_price']
shirts_a = int(params['package_a_shirts'])
pants_a = int(params['package_a_pants'])
shirts_b = int(params['package_b_shirts'])
pants_b = int(params['package_b_pants'])
shirts_c = int(params['package_c_shirts'])
pants_c = int(params['package_c_pants'])
min_a = int(params['min_campaign_batch_a'])
min_b = int(params['min_campaign_batch_b'])
min_c = int(params['min_campaign_batch_c'])
activation_a = params['activation_cost_a']
activation_b = params['activation_cost_b']
activation_c = params['activation_cost_c']
labor_a = params['labor_hours_per_A']
labor_b = params['labor_hours_per_B']
labor_c = params['labor_hours_per_C']
labor_total = params['labor_hours_total']
bigM_a = int(params['bigM_a'])
bigM_b = int(params['bigM_b'])
bigM_c = int(params['bigM_c'])
review_threshold_b = int(params['package_b_review_threshold'])
review_charge_b = params['package_b_review_charge']
review_threshold_c = int(params['package_c_review_threshold'])
review_charge_c = params['package_c_review_charge']

# Create model
model = gp.Model("Maximize_Revenue")
model.setParam('OutputFlag', 0)

# Decision variables
x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_A")
x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_B")
x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_C")

y_a = model.addVar(vtype=GRB.BINARY, name="Activate_A")
y_b = model.addVar(vtype=GRB.BINARY, name="Activate_B")
y_c = model.addVar(vtype=GRB.BINARY, name="Activate_C")

z_b = model.addVar(vtype=GRB.BINARY, name="Review_Charge_B")
z_c = model.addVar(vtype=GRB.BINARY, name="Review_Charge_C")

# Objective: maximize revenue minus activation costs minus review charges
revenue = price_a * x_a + price_b * x_b + price_c * x_c
activation_costs = activation_a * y_a + activation_b * y_b + activation_c * y_c
review_costs = review_charge_b * z_b + review_charge_c * z_c
model.setObjective(revenue - activation_costs - review_costs, GRB.MAXIMIZE)

# Constraints
# Inventory constraints
model.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inventory, "Shirts_Inventory")
model.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inventory, "Pants_Inventory")

# Labor constraint
model.addConstr(labor_a * x_a + labor_b * x_b + labor_c * x_c <= labor_total, "Labor_Hours")

# Minimum sales constraints (only if campaign is activated)
model.addConstr(x_a >= min_a * y_a, "Min_A")
model.addConstr(x_b >= min_b * y_b, "Min_B")
model.addConstr(x_c >= min_c * y_c, "Min_C")

# Big-M linking constraints (if not activated, x must be 0)
model.addConstr(x_a <= bigM_a * y_a, "BigM_A")
model.addConstr(x_b <= bigM_b * y_b, "BigM_B")
model.addConstr(x_c <= bigM_c * y_c, "BigM_C")

# Review charge constraints for Package B
model.addConstr(x_b <= review_threshold_b + bigM_b * z_b, "Review_B_Upper")
model.addConstr(x_b >= review_threshold_b + 1 - bigM_b * (1 - z_b), "Review_B_Lower")

# Review charge constraints for Package C
model.addConstr(x_c <= review_threshold_c + bigM_c * z_c, "Review_C_Upper")
model.addConstr(x_c >= review_threshold_c + 1 - bigM_c * (1 - z_c), "Review_C_Lower")

# Optimize
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"FINAL_OBJ_VALUE: {model.status}")
