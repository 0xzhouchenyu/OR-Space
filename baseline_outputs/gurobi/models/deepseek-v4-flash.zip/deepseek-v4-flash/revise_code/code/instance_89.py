import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
profit_A = params['profit_per_kg_product_A']
profit_B = params['profit_per_kg_product_B']
max_hours_w1 = params['max_production_hours_week_1']
max_hours_w2 = params['max_production_hours_week_2']
hours_A = params['hours_per_kg_product_A']
hours_B = params['hours_per_kg_product_B']
min_ratio = params['min_output_ratio_product_B_to_A']
storage_ratio = params['storage_space_ratio_product_A_to_B']
max_storage_A_w1 = params['max_storage_product_A_equiv_week_1']
max_storage_A_w2 = params['max_storage_product_A_equiv_week_2']
init_inv_A = params['initial_inventory_A']
init_inv_B = params['initial_inventory_B']
storage_cost_A = params['storage_cost_per_kg_A']
storage_cost_B = params['storage_cost_per_kg_B']
promo_bonus_A = params['promo_profit_bonus_A']
promo_bonus_B = params['promo_profit_bonus_B']
max_promo_A = int(params['max_promotions_product_A'])
max_promo_B = int(params['max_promotions_product_B'])

# Create model
model = gp.Model("Two_Week_Production_Planning")
model.setParam('OutputFlag', 0)

# Decision variables
# Production
prod_A_w1 = model.addVar(lb=0, name="prod_A_w1")
prod_A_w2 = model.addVar(lb=0, name="prod_A_w2")
prod_B_w1 = model.addVar(lb=0, name="prod_B_w1")
prod_B_w2 = model.addVar(lb=0, name="prod_B_w2")

# Sales
sell_A_w1 = model.addVar(lb=0, name="sell_A_w1")
sell_A_w2 = model.addVar(lb=0, name="sell_A_w2")
sell_B_w1 = model.addVar(lb=0, name="sell_B_w1")
sell_B_w2 = model.addVar(lb=0, name="sell_B_w2")

# Inventory at end of week 1 (carry-over to week 2)
inv_A_w1 = model.addVar(lb=0, name="inv_A_w1")
inv_B_w1 = model.addVar(lb=0, name="inv_B_w1")

# Promotion binary variables
promo_A_w1 = model.addVar(vtype=GRB.BINARY, name="promo_A_w1")
promo_A_w2 = model.addVar(vtype=GRB.BINARY, name="promo_A_w2")
promo_B_w1 = model.addVar(vtype=GRB.BINARY, name="promo_B_w1")
promo_B_w2 = model.addVar(vtype=GRB.BINARY, name="promo_B_w2")

# Objective: maximize total profit over two weeks
# Week 1 profit: sales revenue + promotion bonus - storage cost for inventory carried
# Week 2 profit: sales revenue + promotion bonus (no storage cost after week 2)
obj = (profit_A * sell_A_w1 + promo_bonus_A * sell_A_w1 * promo_A_w1 +
       profit_B * sell_B_w1 + promo_bonus_B * sell_B_w1 * promo_B_w1 -
       storage_cost_A * inv_A_w1 - storage_cost_B * inv_B_w1 +
       profit_A * sell_A_w2 + promo_bonus_A * sell_A_w2 * promo_A_w2 +
       profit_B * sell_B_w2 + promo_bonus_B * sell_B_w2 * promo_B_w2)

# Linearize promotion bonus terms using auxiliary variables
bonus_A_w1 = model.addVar(lb=0, name="bonus_A_w1")
bonus_A_w2 = model.addVar(lb=0, name="bonus_A_w2")
bonus_B_w1 = model.addVar(lb=0, name="bonus_B_w1")
bonus_B_w2 = model.addVar(lb=0, name="bonus_B_w2")

# Big-M for linearization (max possible sales is bounded by production + inventory)
M = 1000  # sufficiently large

# Week 1 A bonus
model.addConstr(bonus_A_w1 <= promo_bonus_A * sell_A_w1)
model.addConstr(bonus_A_w1 <= promo_bonus_A * M * promo_A_w1)
model.addConstr(bonus_A_w1 >= promo_bonus_A * sell_A_w1 - promo_bonus_A * M * (1 - promo_A_w1))

# Week 2 A bonus
model.addConstr(bonus_A_w2 <= promo_bonus_A * sell_A_w2)
model.addConstr(bonus_A_w2 <= promo_bonus_A * M * promo_A_w2)
model.addConstr(bonus_A_w2 >= promo_bonus_A * sell_A_w2 - promo_bonus_A * M * (1 - promo_A_w2))

# Week 1 B bonus
model.addConstr(bonus_B_w1 <= promo_bonus_B * sell_B_w1)
model.addConstr(bonus_B_w1 <= promo_bonus_B * M * promo_B_w1)
model.addConstr(bonus_B_w1 >= promo_bonus_B * sell_B_w1 - promo_bonus_B * M * (1 - promo_B_w1))

# Week 2 B bonus
model.addConstr(bonus_B_w2 <= promo_bonus_B * sell_B_w2)
model.addConstr(bonus_B_w2 <= promo_bonus_B * M * promo_B_w2)
model.addConstr(bonus_B_w2 >= promo_bonus_B * sell_B_w2 - promo_bonus_B * M * (1 - promo_B_w2))

# Objective with linearized bonuses
model.setObjective(
    profit_A * sell_A_w1 + profit_B * sell_B_w1 +
    profit_A * sell_A_w2 + profit_B * sell_B_w2 +
    bonus_A_w1 + bonus_B_w1 + bonus_A_w2 + bonus_B_w2 -
    storage_cost_A * inv_A_w1 - storage_cost_B * inv_B_w1,
    GRB.MAXIMIZE
)

# Constraints

# Week 1 production hours
model.addConstr(hours_A * prod_A_w1 + hours_B * prod_B_w1 <= max_hours_w1, "hours_w1")

# Week 2 production hours
model.addConstr(hours_A * prod_A_w2 + hours_B * prod_B_w2 <= max_hours_w2, "hours_w2")

# Market demand ratio each week (production ratio)
model.addConstr(prod_B_w1 >= min_ratio * prod_A_w1, "ratio_w1")
model.addConstr(prod_B_w2 >= min_ratio * prod_A_w2, "ratio_w2")

# Storage capacity week 1 (end of week 1 inventory)
model.addConstr(storage_ratio * inv_A_w1 + inv_B_w1 <= max_storage_A_w1 * storage_ratio, "storage_w1")

# Storage capacity week 2 (production + incoming inventory - sales <= capacity)
# Week 2 storage is for what remains after week 2 sales (no carry-over beyond week 2)
# But constraint says storage capacity applies week by week, so at end of week 2 we have no inventory
# Actually we need to ensure that during week 2, the storage doesn't exceed capacity.
# The inventory at start of week 2 is inv_A_w1, inv_B_w1.
# During week 2, we produce and sell. The maximum storage used during week 2 is
# the maximum of (incoming inventory) and (incoming + production - sales).
# Since we can sell before storing, the peak storage is max(inv, inv+prod-sell).
# A conservative approach: ensure that at any point, storage doesn't exceed capacity.
# We'll enforce that the inventory after production (before sales) doesn't exceed capacity,
# and also the final inventory (after sales) doesn't exceed capacity.
# For simplicity and correctness, we enforce that the inventory at the start of week 2
# plus production in week 2 does not exceed storage capacity (since we can sell immediately).
# Actually, the standard approach: storage capacity limits the amount that can be stored
# at any time. We'll enforce that the inventory at the end of week 1 (carry-over) plus
# production in week 2 must be <= capacity, because we can sell before storing.
# But to be safe, we enforce that the maximum of (inv_w1, inv_w1 + prod_w2 - sell_w2) <= capacity.
# Since sell_w2 can be up to inv_w1 + prod_w2, the maximum is inv_w1 + prod_w2.
# So we enforce: storage_ratio * (inv_A_w1 + prod_A_w2) + (inv_B_w1 + prod_B_w2) <= max_storage_A_w2 * storage_ratio
model.addConstr(storage_ratio * (inv_A_w1 + prod_A_w2) + (inv_B_w1 + prod_B_w2) <= max_storage_A_w2 * storage_ratio, "storage_w2_peak")

# Also ensure final inventory after week 2 sales is zero (no carry-over beyond week 2)
model.addConstr(inv_A_w1 + prod_A_w2 - sell_A_w2 == 0, "final_inv_A")
model.addConstr(inv_B_w1 + prod_B_w2 - sell_B_w2 == 0, "final_inv_B")

# Inventory balance week 1
model.addConstr(init_inv_A + prod_A_w1 - sell_A_w1 == inv_A_w1, "balance_A_w1")
model.addConstr(init_inv_B + prod_B_w1 - sell_B_w1 == inv_B_w1, "balance_B_w1")

# Sales cannot exceed available inventory (including production)
model.addConstr(sell_A_w1 <= init_inv_A + prod_A_w1, "sell_A_w1_limit")
model.addConstr(sell_B_w1 <= init_inv_B + prod_B_w1, "sell_B_w1_limit")
model.addConstr(sell_A_w2 <= inv_A_w1 + prod_A_w2, "sell_A_w2_limit")
model.addConstr(sell_B_w2 <= inv_B_w1 + prod_B_w2, "sell_B_w2_limit")

# Promotion limits
model.addConstr(promo_A_w1 + promo_A_w2 <= max_promo_A, "max_promo_A")
model.addConstr(promo_B_w1 + promo_B_w2 <= max_promo_B, "max_promo_B")

# Solve
model.optimize()

# Output result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal:.3f}")
else:
    print(f"FINAL_OBJ_VALUE: 0.000")
