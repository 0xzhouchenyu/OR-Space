import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_restaurant_data(filepath):
    """Load restaurant data from CSV file."""
    restaurants = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'standard_staff_hours': float(row['Standard_Staff_Hours'].strip()),
                'premium_staff_hours': float(row['Premium_Staff_Hours'].strip())
            })
    return restaurants

def load_general_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    return params

def main():
    # Determine data directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load data
    restaurants = load_restaurant_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    budget = params['investment_budget']
    premium_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']
    
    # Create model
    model = gp.Model("Restaurant_Investment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = {}
    premium = {}
    for r in restaurants:
        name = r['name']
        buy[name] = model.addVar(vtype=GRB.BINARY, name=f"buy_{name}")
        premium[name] = model.addVar(vtype=GRB.BINARY, name=f"premium_{name}")
    
    # Objective: maximize total annual revenue
    # Standard revenue = base revenue; Premium revenue = base * (1 + uplift)
    obj_expr = gp.LinExpr()
    for r in restaurants:
        name = r['name']
        base_rev = r['revenue']
        # If bought and premium: revenue = base * (1 + uplift)
        # If bought and not premium: revenue = base
        # If not bought: revenue = 0
        # Revenue = base * buy + base * uplift * premium
        obj_expr += base_rev * buy[name] + base_rev * premium_uplift * premium[name]
    
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Constraint 1: Premium only if bought
    for r in restaurants:
        name = r['name']
        model.addConstr(premium[name] <= buy[name], f"premium_only_if_bought_{name}")
    
    # Constraint 2: Budget constraint (purchase cost + premium upgrade cost)
    budget_expr = gp.LinExpr()
    for r in restaurants:
        name = r['name']
        budget_expr += r['cost'] * buy[name] + premium_upgrade_cost * premium[name]
    model.addConstr(budget_expr <= budget, "Budget_Constraint")
    
    # Constraint 3: Staff hours constraint
    staff_expr = gp.LinExpr()
    for r in restaurants:
        name = r['name']
        # Standard staff hours if bought but not premium
        # Premium staff hours if bought and premium
        # Staff = standard * (buy - premium) + premium * premium
        # = standard * buy + (premium - standard) * premium
        staff_expr += r['standard_staff_hours'] * buy[name] + \
                     (r['premium_staff_hours'] - r['standard_staff_hours']) * premium[name]
    model.addConstr(staff_expr <= staff_hours_cap, "Staff_Hours_Constraint")
    
    # Constraint 4: If Restaurant D is purchased, Restaurant A cannot be purchased
    names = [r['name'] for r in restaurants]
    if 'Restaurant_D' in names and 'Restaurant_A' in names:
        model.addConstr(buy['Restaurant_D'] + buy['Restaurant_A'] <= 1, "D_A_Exclusion_Constraint")
    
    # Optimize
    model.optimize()
    
    # Get objective value
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
