import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load toy data
toys = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            'type': row['Toy_Type'].strip(),
            'profit': float(row['Profit_Per_Unit']),
            'wood': float(row['Wood_Required_Per_Unit']),
            'steel': float(row['Steel_Required_Per_Unit']),
        })

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'])

available_wood = params['available_wood']
available_steel = params['available_steel']
profit_premium_bonus = params['profit_premium_bonus']
premium_steel_factor = params['premium_steel_factor']
premium_shift_capacity = params['premium_shift_capacity']

# Create model
model = gp.Model("HausToys_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
# Standard shift production quantities
x_std = {}
# Premium shift production quantities
x_prem = {}
# Binary: whether a toy type is produced on standard shift
y_std = {}
# Binary: whether a toy type is produced on premium shift
y_prem = {}

M = 1000  # Big M

for t in toys:
    toy_type = t['type']
    x_std[toy_type] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_std_{toy_type}")
    x_prem[toy_type] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_prem_{toy_type}")
    y_std[toy_type] = model.addVar(vtype=GRB.BINARY, name=f"y_std_{toy_type}")
    y_prem[toy_type] = model.addVar(vtype=GRB.BINARY, name=f"y_prem_{toy_type}")

# Objective: maximize profit
obj = gp.LinExpr()
for t in toys:
    toy_type = t['type']
    obj += t['profit'] * x_std[toy_type]
    obj += (t['profit'] + profit_premium_bonus) * x_prem[toy_type]
model.setObjective(obj, GRB.MAXIMIZE)

# Resource constraints
# Wood constraint (wood consumption is same for both shifts)
model.addConstr(
    gp.quicksum(t['wood'] * (x_std[t['type']] + x_prem[t['type']]) for t in toys) <= available_wood,
    "Wood_Constraint"
)

# Steel constraint (premium shift uses more steel)
model.addConstr(
    gp.quicksum(t['steel'] * x_std[t['type']] + premium_steel_factor * t['steel'] * x_prem[t['type']] for t in toys) <= available_steel,
    "Steel_Constraint"
)

# Premium shift capacity constraint
model.addConstr(
    gp.quicksum(x_prem[t['type']] for t in toys) <= premium_shift_capacity,
    "Premium_Capacity"
)

# Linking constraints: production only if shift is active
for t in toys:
    toy_type = t['type']
    model.addConstr(x_std[toy_type] <= M * y_std[toy_type], f"Link_Std_{toy_type}")
    model.addConstr(x_prem[toy_type] <= M * y_prem[toy_type], f"Link_Prem_{toy_type}")

# Each toy type can only be produced on one shift (if produced at all)
for t in toys:
    toy_type = t['type']
    model.addConstr(y_std[toy_type] + y_prem[toy_type] <= 1, f"One_Shift_{toy_type}")

# Truck-train exclusion: if trucks produced (any shift), no trains (any shift)
model.addConstr(
    y_std['truck'] + y_prem['truck'] + y_std['train'] + y_prem['train'] <= 1,
    "Truck_Train_Exclusion"
)

# Boat-airplane dependency: if boats produced (any shift), airplanes must be produced (any shift)
model.addConstr(
    y_std['boat'] + y_prem['boat'] <= y_std['airplane'] + y_prem['airplane'],
    "Boat_Airplane_Dependency"
)

# Boat-train limit: total boats <= total trains (summed across shifts)
model.addConstr(
    x_std['boat'] + x_prem['boat'] <= x_std['train'] + x_prem['train'],
    "Boat_Train_Limit"
)

# Optimize
model.optimize()

# Print results
print(f"Status: {model.status}")
for t in toys:
    toy_type = t['type']
    x_std_val = x_std[toy_type].X
    x_prem_val = x_prem[toy_type].X
    y_std_val = y_std[toy_type].X
    y_prem_val = y_prem[toy_type].X
    print(f"{toy_type}: std={x_std_val:.2f} (y_std={y_std_val}), prem={x_prem_val:.2f} (y_prem={y_prem_val})")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
