import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load parameters
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    df = pd.read_csv(csv_path)
    params = dict(zip(df['Parameter_Name'], df['Value']))
    
    commodities = ['steel', 'engine', 'electronics', 'plastic']
    
    # Create model
    model = gp.Model("Maximize_GDP")
    model.setParam('OutputFlag', 0)
    
    # Production variables
    x = {}
    for c in commodities:
        ub = float('inf')
        limit_key = f"{c}_production_limit"
        if limit_key in params:
            ub = params[limit_key]
        x[c] = model.addVar(lb=0, ub=ub, name=f"x_{c}")
    
    # Import variables for each commodity
    imp = {}
    for c in commodities:
        imp[c] = model.addVar(lb=0, ub=params['import_quota'], name=f"imp_{c}")
    
    # Overtime labor variable
    overtime = model.addVar(lb=0, ub=params['overtime_cap'], name="overtime")
    
    # Domestic consumption of each commodity
    consumed = {}
    for c in commodities:
        consumed[c] = gp.LpConstraintExpr()
        expr = gp.LinExpr()
        for c_prime in commodities:
            req_key = f"{c_prime}_{c}_requirement"
            if req_key in params:
                expr += params[req_key] * x[c_prime]
        consumed[c] = expr
    
    # Net export = Production + Imports - Domestic Consumption
    net_export = {}
    for c in commodities:
        net_export[c] = x[c] + imp[c] - consumed[c]
    
    # Objective: GDP = Export revenue - Import costs - Overtime costs - Finished import costs
    # Export revenue
    export_revenue = gp.LinExpr()
    for c in commodities:
        export_revenue += params[f"{c}_price"] * net_export[c]
    
    # Import costs for intermediate goods (original import costs)
    intermediate_import_cost = gp.LinExpr()
    for c in commodities:
        intermediate_import_cost += params.get(f"{c}_import_cost", 0) * x[c]
    
    # Overtime cost
    overtime_cost = params['overtime_wage'] * overtime
    
    # Finished import cost (import_premium_ratio * world price)
    finished_import_cost = gp.LinExpr()
    for c in commodities:
        finished_import_cost += params['import_premium_ratio'] * params[f"{c}_price"] * imp[c]
    
    # GDP = Export revenue - all costs
    gdp = export_revenue - intermediate_import_cost - overtime_cost - finished_import_cost
    model.setObjective(gdp, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Net export >= 0 for each commodity (domestic production + imports must satisfy domestic demand)
    for c in commodities:
        model.addConstr(net_export[c] >= 0, f"Domestic_Demand_{c}")
    
    # 2. Labor constraint: regular labor + overtime
    regular_labor = gp.LinExpr()
    for c in commodities:
        regular_labor += params.get(f"{c}_labor_requirement", 0) * x[c]
    
    model.addConstr(regular_labor <= params['labor_force'] + overtime, "Labor_Limit")
    
    # 3. Overtime is already bounded by variable bounds
    
    # 4. Import quotas are already bounded by variable bounds
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        return model.objVal
    else:
        return None

if __name__ == '__main__':
    result = solve()
    if result is not None:
        print(f"FINAL_OBJ_VALUE: {round(result, 3)}")
    else:
        print("FINAL_OBJ_VALUE: None")
