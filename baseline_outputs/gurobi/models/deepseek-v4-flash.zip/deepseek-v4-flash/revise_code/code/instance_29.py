import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    demand_df = pd.read_csv(os.path.join(data_dir, "table_4_3.csv"))
    supply_df = pd.read_csv(os.path.join(data_dir, "table_4_4.csv"))
    params_df = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    
    # Parse parameters
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])
    
    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem
        
    # Parse supply
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = float(row['Number_of_People'])
        suit = [int(x) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }
        
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]
    
    # Create model
    model = gp.Model("DualMatch")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of people of type i assigned to city j, specialty k
    x = {}
    for i in types:
        for j in cities:
            for k in specs:
                x[i, j, k] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}_{k}")
    
    # Variable for number of dual matches
    dual_match = model.addVar(vtype=GRB.INTEGER, lb=0, name="dual_match")
    
    # Objective: maximize dual matches
    model.setObjective(dual_match, GRB.MAXIMIZE)
    
    # Constraint 1: Supply constraints
    for i in types:
        model.addConstr(
            gp.quicksum(x[i, j, k] for j in cities for k in specs) <= supply[i]['num'],
            name=f"supply_{i}"
        )
    
    # Constraint 2: Demand constraints (Priority 1 - hard)
    for j in cities:
        for k in specs:
            model.addConstr(
                gp.quicksum(x[i, j, k] for i in types) >= demand[(j, k)],
                name=f"demand_{j}_{k}"
            )
    
    # Constraint 3: Suitability constraints
    for i in types:
        for j in cities:
            for k in specs:
                if k not in supply[i]['suit']:
                    model.addConstr(x[i, j, k] == 0, name=f"suit_{i}_{j}_{k}")
    
    # Constraint 4: Priority 2 - at least p2_target placed in preferred specialty (hard)
    pref_spec_expr = gp.quicksum(
        x[i, j, supply[i]['pref_spec']] for i in types for j in cities
    )
    model.addConstr(pref_spec_expr >= p2_target, name="priority2")
    
    # Constraint 5: Dual match definition
    dual_match_expr = gp.quicksum(
        x[i, supply[i]['pref_city'], supply[i]['pref_spec']] 
        for i in types 
        if supply[i]['pref_city'] in cities and supply[i]['pref_spec'] in specs
    )
    model.addConstr(dual_match == dual_match_expr, name="dual_match_def")
    
    # Optimize
    model.optimize()
    
    # Get result
    if model.status == GRB.OPTIMAL:
        obj_val = int(round(model.objVal))
    else:
        obj_val = 0
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == '__main__':
    solve()
