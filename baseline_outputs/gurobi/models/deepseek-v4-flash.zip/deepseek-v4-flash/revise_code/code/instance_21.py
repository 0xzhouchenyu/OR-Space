import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Parse general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    
    cost_a = float(params["cost_supplier_a"])
    cost_b = float(params["cost_supplier_b"])
    cost_c = float(params["cost_supplier_c"])
    size_a = int(params["order_size_supplier_a"])
    size_b = int(params["order_size_supplier_b"])
    size_c = int(params["order_size_supplier_c"])
    min_tables = int(params["min_tables_required"])
    max_tables = int(params["max_tables_allowed"])
    min_b_if_a = int(params["min_tables_supplier_b_if_a"])
    b_requires_c = int(params["supplier_b_requires_c"])
    max_free_orders_c = int(params["max_free_orders_c"])
    penalty_per_extra_order_c = float(params["penalty_per_extra_order_c"])
    bc_shared_inbound_trigger = int(params["supplier_bc_shared_inbound_trigger"])
    bc_shared_inbound_fee = float(params["supplier_bc_shared_inbound_fee"])
    
    M = 1000  # Big-M
    
    # Create model
    model = gp.Model("Restaurant_Tables_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of orders from each supplier (integer >= 0)
    x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_a")
    x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_b")
    x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_c")
    
    # Binary variables for conditional constraints
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")  # 1 if ordering from A
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")  # 1 if ordering from B
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")  # 1 if ordering from C
    
    # Binary variable for shared inbound desk (B and C both used)
    z_bc = model.addVar(vtype=GRB.BINARY, name="z_bc")
    
    # Integer variable for extra orders from C beyond free limit
    extra_orders_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="extra_orders_c")
    
    # Objective: minimize total cost
    # Cost from tables + penalty for extra C orders + shared inbound fee
    obj = (cost_a * size_a * x_a + cost_b * size_b * x_b + cost_c * size_c * x_c 
           + penalty_per_extra_order_c * extra_orders_c 
           + bc_shared_inbound_fee * z_bc)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Total tables constraints
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c >= min_tables)
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c <= max_tables)
    
    # Link binary variables to order variables
    model.addConstr(x_a <= M * y_a)
    model.addConstr(x_a >= y_a)
    model.addConstr(x_b <= M * y_b)
    model.addConstr(x_b >= y_b)
    model.addConstr(x_c <= M * y_c)
    model.addConstr(x_c >= y_c)
    
    # If ordering from A, then tables from B >= 30
    model.addConstr(size_b * x_b >= min_b_if_a * y_a)
    
    # If ordering from B, must order from C
    if b_requires_c:
        model.addConstr(x_c >= y_b)
    
    # Supplier C comfort band: first max_free_orders_c orders free, rest penalized
    model.addConstr(x_c <= max_free_orders_c + extra_orders_c)
    model.addConstr(extra_orders_c >= 0)
    
    # Shared inbound desk: if both B and C are used, incur one-time fee
    if bc_shared_inbound_trigger:
        model.addConstr(z_bc >= y_b + y_c - 1)
        model.addConstr(z_bc <= y_b)
        model.addConstr(z_bc <= y_c)
    
    # Optimize
    model.optimize()
    
    # Get results
    obj_val = model.objVal
    print(f"Orders from A: {int(x_a.X)}, Tables: {int(x_a.X * size_a)}")
    print(f"Orders from B: {int(x_b.X)}, Tables: {int(x_b.X * size_b)}")
    print(f"Orders from C: {int(x_c.X)}, Tables: {int(x_c.X * size_c)}")
    print(f"Extra orders from C (penalized): {int(extra_orders_c.X)}")
    print(f"Shared inbound fee applied: {int(z_bc.X)}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
