import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    # Configure file paths
    current_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(current_dir, 'data', 'table_1.csv')
    params_path = os.path.join(current_dir, 'data', 'general_parameters.csv')
    
    # Load data files
    df = pd.read_csv(table_1_path)
    params_df = pd.read_csv(params_path)
    
    # Create parameter dictionary for easier lookup
    params = dict(zip(params_df['Parameter_Name'], params_df['Value']))
    
    # Extract numerical parameters
    total_budget = float(params['budget'])
    intake_per_dinner = float(params['food_intake']) / 100.0  # Convert to 100g units
    weekday_share = float(params['weekday_budget_share'])
    max_prep_weekday = float(params['max_prep_time_weekday'])
    max_prep_weekend = float(params['max_prep_time_weekend'])
    protein_ban_flag = int(params['weekend_protein_ban'])
    veg_penalty_rate = float(params['veg_balance_penalty'])
    
    # Process food characteristics from Table 1
    # Replace missing fiber values with 0
    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)
    
    foods = df['Food'].tolist()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()
    types = df.set_index('Food')['Type'].to_dict()
    
    # Categorize foods
    proteins = [f for f in foods if types[f] == 'protein']
    vegetables = [f for f in foods if types[f] == 'vegetable']
    
    # Initialize the Gurobi model
    model = gp.Model("Mary_Dinner_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    days = ['weekday', 'weekend']
    # x: Amount of food f (in 100g units) eaten on specific day
    x = model.addVars(foods, days, lb=0, vtype=GRB.CONTINUOUS, name="x")
    # y: Binary indicator if food f is included in dinner on specific day
    y = model.addVars(foods, days, vtype=GRB.BINARY, name="y")
    
    # "Front-office choices" (shopping logic)
    # z_p: Protein selection for the entire week (on paper)
    z_p = model.addVars(proteins, vtype=GRB.BINARY, name="z_p")
    # z_v: Vegetable selection for the entire week
    z_v = model.addVars(vegetables, vtype=GRB.BINARY, name="z_v")
    
    # diff: Absolute differences in vegetable intake between the two dinners
    diff = model.addVars(vegetables, lb=0, vtype=GRB.CONTINUOUS, name="diff")
    
    # Objective: Maximize total fiber intake across both nights minus the penalty for vegetable deviations
    total_fiber = gp.quicksum(fiber[f] * x[f, d] for f in foods for d in days)
    total_penalty = veg_penalty_rate * gp.quicksum(diff[v] for v in vegetables)
    model.setObjective(total_fiber - total_penalty, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Food intake requirement (500g per dinner)
    for d in days:
        model.addConstr(gp.quicksum(x[f, d] for f in foods) == intake_per_dinner)
    
    # 2. Budget limits (Total and scenario-specific shares)
    model.addConstr(gp.quicksum(price[f] * x[f, 'weekday'] for f in foods) <= total_budget * weekday_share)
    model.addConstr(gp.quicksum(price[f] * x[f, 'weekend'] for f in foods) <= total_budget * (1 - weekday_share))
    model.addConstr(gp.quicksum(price[f] * x[f, d] for f in foods for d in days) <= total_budget)
    
    # 3. Preparation time limits
    model.addConstr(gp.quicksum(prep_time[f] * x[f, 'weekday'] for f in foods) <= max_prep_weekday)
    model.addConstr(gp.quicksum(prep_time[f] * x[f, 'weekend'] for f in foods) <= max_prep_weekend)
    
    # 4. Linking amounts (x) to selection indicators (y) with minimum 10g inclusion rule
    for f in foods:
        for d in days:
            model.addConstr(x[f, d] >= 0.1 * y[f, d])
            model.addConstr(x[f, d] <= intake_per_dinner * y[f, d])
            
    # 5. Shopping Logic and Protein Requirements
    # Pick exactly one protein source for the week (on paper)
    model.addConstr(gp.quicksum(z_p[p] for p in proteins) == 1)
    
    for p in proteins:
        # Weekday meal must use the selected protein source
        model.addConstr(y[p, 'weekday'] == z_p[p])
        # Weekend meal uses the selected protein ONLY IF it is not banned
        if protein_ban_flag == 1:
            model.addConstr(y[p, 'weekend'] == 0)
        else:
            model.addConstr(y[p, 'weekend'] == z_p[p])
            
    # Ensure exactly one protein is used on weekday
    model.addConstr(gp.quicksum(y[p, 'weekday'] for p in proteins) == 1)
    # Weekend protein count depends on the ban flag
    if protein_ban_flag == 1:
        model.addConstr(gp.quicksum(y[p, 'weekend'] for p in proteins) == 0)
    else:
        model.addConstr(gp.quicksum(y[p, 'weekend'] for p in proteins) == 1)
            
    # 6. Vegetable Selection Logic
    # Shared shopping logic: selection for weekday must match selection for weekend
    for v in vegetables:
        model.addConstr(y[v, 'weekday'] == z_v[v])
        model.addConstr(y[v, 'weekend'] == z_v[v])
    
    # At least two kinds of vegetables must be chosen
    model.addConstr(gp.quicksum(z_v[v] for v in vegetables) >= 2)
    
    # 7. Vegetable Swings Penalty Logic
    # Calculate absolute difference for vegetable amounts between nights
    for v in vegetables:
        model.addConstr(diff[v] >= x[v, 'weekday'] - x[v, 'weekend'])
        model.addConstr(diff[v] >= x[v, 'weekend'] - x[v, 'weekday'])
    
    # Solve the model
    model.optimize()
    
    # Return the optimal objective value
    if model.status == GRB.OPTIMAL:
        return model.objVal
    else:
        return None

if __name__ == '__main__':
    final_objective = solve()
    if final_objective is not None:
        print(f"FINAL_OBJ_VALUE: {final_objective}")
