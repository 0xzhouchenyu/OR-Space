import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data from general_parameters.csv
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params_file = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(params_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Extraction of numerical parameters
    product_units = params['product_units']
    max_total_pollution = params['max_total_pollution']
    min_truck_trips_global = params['min_truck_trips']
    
    # Vehicle attributes
    vehicles = ['truck', 'van', 'motorcycle', 'electric_vehicle']
    pollutions = {
        'truck': params['truck_pollution'],
        'van': params['van_pollution'],
        'motorcycle': params['motorcycle_pollution'],
        'electric_vehicle': params['electric_vehicle_pollution']
    }
    capacities = {
        'truck': params['truck_capacity'],
        'van': params['van_capacity'],
        'motorcycle': params['motorcycle_capacity'],
        'electric_vehicle': params['electric_vehicle_capacity']
    }
    
    # Organization of delivery locations and time horizon
    sps = ['sp1', 'sp2', 'sp3']
    days = ['d1', 'd2', 'd3']
    
    # Sales point specific share and service constraints
    sp_shares = {
        'sp1': params['sales_point_share_sp1'],
        'sp2': params['sales_point_share_sp2'],
        'sp3': params['sales_point_share_sp3']
    }
    
    min_truck_share_sp = {
        'sp1': params['min_truck_share_sp1'],
        'sp2': params['min_truck_share_sp2'],
        'sp3': params['min_truck_share_sp3']
    }
    
    # Mode family binary constraint bounds (Big-M)
    m_truck = params['M_truck_sp_day']
    m_ev = params['M_ev_sp_day']
    m_van = params['M_van_sp_day']
    m_moto = params['M_moto_sp_day']

    # Initialize Gurobi Optimization Model
    model = gp.Model("Transportation_Pollution_Minimization")
    model.setParam('OutputFlag', 0)

    # Decision Variables
    # x: number of trips for each (sales point, day, vehicle type)
    x = model.addVars(sps, days, vehicles, vtype=GRB.INTEGER, lb=0, name="trips")
    # y: binary choice of vehicle family for each (sales point, day)
    y = model.addVars(sps, days, vtype=GRB.BINARY, name="mode_family")

    # Objective Function: Minimize Total Pollution
    model.setObjective(
        gp.quicksum(x[s, d, v] * pollutions[v] for s in sps for d in days for v in vehicles),
        GRB.MINIMIZE
    )

    # Constraints
    
    # 1. Demand Management: Each sales point must receive its committed share of products
    for s in sps:
        model.addConstr(
            gp.quicksum(x[s, d, v] * capacities[v] for d in days for v in vehicles) >= product_units * sp_shares[s],
            name=f"Demand_{s}"
        )

    # 2. Environmental Constraint: Total pollution must not exceed the maximum allowed limit
    model.addConstr(
        gp.quicksum(x[s, d, v] * pollutions[v] for s in sps for d in days for v in vehicles) <= max_total_pollution,
        name="Pollution_Ceiling"
    )

    # 3. Operating Commitment: Global minimum total truck trips required
    model.addConstr(
        gp.quicksum(x[s, d, 'truck'] for s in sps for d in days) >= min_truck_trips_global,
        name="Global_Min_Truck_Trips"
    )

    # 4. Service Discipline: Sales-point truck share promises
    for s in sps:
        model.addConstr(
            gp.quicksum(x[s, d, 'truck'] for d in days) >= 
            min_truck_share_sp[s] * gp.quicksum(x[s, d, v] for d in days for v in vehicles),
            name=f"Truck_Share_Promise_{s}"
        )

    # 5. Gate Rule: Service family discipline per destination and day
    # Crossing the "business line" gate: either {Truck, EV} or {Van, Motorcycle}
    for s in sps:
        for d in days:
            # Family: Truck or Electric Vehicle (y = 1)
            model.addConstr(x[s, d, 'truck'] <= m_truck * y[s, d], name=f"Family_Limit_Truck_{s}_{d}")
            model.addConstr(x[s, d, 'electric_vehicle'] <= m_ev * y[s, d], name=f"Family_Limit_EV_{s}_{d}")
            # Family: Van or Motorcycle (y = 0)
            model.addConstr(x[s, d, 'van'] <= m_van * (1 - y[s, d]), name=f"Family_Limit_Van_{s}_{d}")
            model.addConstr(x[s, d, 'motorcycle'] <= m_moto * (1 - y[s, d]), name=f"Family_Limit_Moto_{s}_{d}")

    # Solve the optimization problem
    model.optimize()

    # Output the optimal objective value
    if model.status == GRB.OPTIMAL or model.SolCount > 0:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
