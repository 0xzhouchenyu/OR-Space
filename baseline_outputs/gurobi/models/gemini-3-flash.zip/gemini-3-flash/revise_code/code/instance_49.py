import pandas as pd
import gurobipy as gp
from gurobipy import GRB
import os

def solve():
    # Get absolute paths to data files
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, 'data')
    
    # Load data from CSV files
    table_1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    table_2 = pd.read_csv(os.path.join(data_dir, 'table_2.csv'))
    params = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))

    # Helper function to parse parameters from general_parameters.csv
    def get_param(name, default_value):
        try:
            val = params.loc[params['Parameter_Name'] == name, 'Value'].values[0]
            if str(val).strip().lower() == 'true': return True
            if str(val).strip().lower() == 'false': return False
            if str(val).strip().lower() == 'unlimited': return 999999
            return val
        except (IndexError, KeyError):
            return default_value

    # Parse business rules and cost parameters
    min_contract_types = int(get_param('min_contract_types', 2))
    max_contract_types = int(get_param('max_contract_types', 3))
    mutual_exclusion = get_param('mutual_exclusion_1_and_4', True)
    max_parallel = int(get_param('monthly_max_parallel_contracts', 3))
    min_area = float(get_param('min_area_per_contract_units', 2))
    activation_fee = float(get_param('activation_fee_per_contract', 2500))
    onboarding_loss = float(get_param('onboarding_loss_units', 1))
    expedited_fee = float(get_param('expedited_onboarding_fee', 1800))

    # Convert table data to dictionaries (area converted to units of 100 sqm)
    demands = {int(row.iloc[0]): float(row.iloc[1]) / 100.0 for _, row in table_1.iterrows()}
    costs = {int(row.iloc[0]): float(row.iloc[1]) for _, row in table_2.iterrows()}
    
    months = sorted(demands.keys())
    max_month = max(months)
    contract_lengths = sorted(costs.keys())

    # Initialize Gurobi model
    model = gp.Model("Warehouse_Rental_Optimization")
    model.setParam('OutputFlag', 0)

    # Variables
    # x_keys: (start_month i, contract_length j, contract_instance s)
    # Allowing up to max_parallel instances per month and length combination
    x_keys = [
        (i, j, s) 
        for i in months 
        for j in contract_lengths 
        if i + j - 1 <= max_month 
        for s in range(max_parallel)
    ]
    
    a = model.addVars(x_keys, vtype=GRB.INTEGER, lb=0, name="area")
    z = model.addVars(x_keys, vtype=GRB.BINARY, name="active")
    e = model.addVars(x_keys, vtype=GRB.BINARY, name="expedited")
    y = model.addVars(contract_lengths, vtype=GRB.BINARY, name="type_used")

    # Objective Function
    rental_costs = gp.quicksum(a[k] * costs[k[1]] for k in x_keys)
    activation_costs = gp.quicksum(z[k] * activation_fee for k in x_keys)
    expedited_costs = gp.quicksum(e[k] * expedited_fee for k in x_keys)
    model.setObjective(rental_costs + activation_costs + expedited_costs, GRB.MINIMIZE)

    # Constraints
    
    # 1. Demand Satisfaction
    for m in months:
        # Usable area calculation: 
        # For the starting month of a contract, usable area = rented area - onboarding loss (if not expedited)
        # For all subsequent active months, usable area = rented area
        usable_area_expr = gp.quicksum(
            a[k] - (onboarding_loss * (z[k] - e[k]) if k[0] == m else 0)
            for k in x_keys 
            if k[0] <= m <= k[0] + k[1] - 1
        )
        model.addConstr(usable_area_expr == demands[m], name=f"Demand_{m}")

    # 2. Minimum Area, Expediting rules, and Logic Linking
    max_demand_sum = sum(demands.values())
    for k in x_keys:
        model.addConstr(a[k] >= min_area * z[k], name=f"MinArea_{k}")
        model.addConstr(a[k] <= max_demand_sum * z[k], name=f"MaxArea_{k}")
        model.addConstr(e[k] <= z[k], name=f"ExpediteLink_{k}")

    # 3. Monthly Parallel Contract Limit
    for m in months:
        model.addConstr(
            gp.quicksum(z[k] for k in x_keys if k[0] <= m <= k[0] + k[1] - 1) <= max_parallel,
            name=f"MaxParallel_{m}"
        )

    # 4. Distinct Contract Length Limits
    for length in contract_lengths:
        contracts_of_length = [k for k in x_keys if k[1] == length]
        model.addConstr(gp.quicksum(z[k] for k in contracts_of_length) >= y[length], name=f"UseLen_LB_{length}")
        model.addConstr(gp.quicksum(z[k] for k in contracts_of_length) <= 100 * y[length], name=f"UseLen_UB_{length}")

    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) >= min_contract_types, name="MinTypes")
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) <= max_contract_types, name="MaxTypes")

    # 5. Mutual Exclusion: Length 1 and Length 4 cannot coexist
    if mutual_exclusion:
        if 1 in y and 4 in y:
            model.addConstr(y[1] + y[4] <= 1, name="MutualExclusion")

    # Solve
    model.optimize()

    # Output Objective Value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    solve()
```
