import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    # Adjusted to the root directory where the script and data directory are located
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            # Try to convert to number
            try:
                if '.' in value:
                    params[name] = float(value)
                else:
                    params[name] = int(value)
            except ValueError:
                params[name] = value
    return params

def solve():
    params = load_parameters()
    
    # Initialize Model
    model = gp.Model("ToyOptimization")
    model.setParam('OutputFlag', 0)

    # Decision variables (number of toys)
    x_robot = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_robot")
    x_car = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_car")
    x_blocks = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_blocks")
    x_doll = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_doll")
    
    # Binary variables to track whether each item type is produced
    y_robot = model.addVar(vtype=GRB.BINARY, name="y_robot")
    y_car = model.addVar(vtype=GRB.BINARY, name="y_car")
    y_blocks = model.addVar(vtype=GRB.BINARY, name="y_blocks")
    y_doll = model.addVar(vtype=GRB.BINARY, name="y_doll")

    # Objective: Maximize Profit
    model.setObjective(
        params['profit_per_robot'] * x_robot +
        params['profit_per_model_car'] * x_car +
        params['profit_per_building_blocks'] * x_blocks +
        params['profit_per_doll'] * x_doll,
        GRB.MAXIMIZE
    )

    # Resource Constraints
    # 1. Plastic usage constraint
    model.addConstr(
        params['plastic_per_robot'] * x_robot +
        params['plastic_per_model_car'] * x_car +
        params['plastic_per_building_blocks'] * x_blocks +
        params['plastic_per_doll'] * x_doll <= params['plastic_available'],
        "Plastic_Limit"
    )
    
    # 2. Electronics usage constraint
    model.addConstr(
        params['electronics_per_robot'] * x_robot +
        params['electronics_per_model_car'] * x_car +
        params['electronics_per_building_blocks'] * x_blocks +
        params['electronics_per_doll'] * x_doll <= params['electronic_components_available'],
        "Electronics_Limit"
    )

    # Linking variables: x_i > 0 <=> y_i = 1
    # We use a sufficiently large Big M (2000 is safe given the resource constraints)
    M = 2000
    model.addConstr(x_robot <= M * y_robot)
    model.addConstr(y_robot <= x_robot)
    
    model.addConstr(x_car <= M * y_car)
    model.addConstr(y_car <= x_car)
    
    model.addConstr(x_blocks <= M * y_blocks)
    model.addConstr(y_blocks <= x_blocks)
    
    model.addConstr(x_doll <= M * y_doll)
    model.addConstr(y_doll <= x_doll)

    # Business Logic Rules
    # 1. Robot and Doll Exclusion: If robots are manufactured, dolls cannot be
    if params.get('robots_and_dolls_exclusion') == 1:
        model.addConstr(y_robot + y_doll <= 1, "Robot_Doll_Exclusion")
    
    # 2. Model Car and Building Blocks Dependency: Cars only if Blocks are produced
    if params.get('model_cars_and_building_blocks_dependency') == 1:
        model.addConstr(y_car <= y_blocks, "Car_Blocks_Dependency")
    
    # 3. Doll quantity cap based on Model Car quantity
    if params.get('dolls_less_than_or_equal_model_cars') == 1:
        model.addConstr(x_doll <= x_car, "Doll_Limit_By_Cars")

    # 4. REVISION: Molding-Line Exclusion rule
    # Model cars and building blocks cannot be produced together in this period
    model.addConstr(y_car + y_blocks <= 1, "Car_Blocks_Exclusion_Rule")

    # Solve the model
    model.optimize()

    # Output the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Fallback if no solution found (should not happen for this problem)
        print("FINAL_OBJ_VALUE: 0.0")

if __name__ == "__main__":
    solve()
