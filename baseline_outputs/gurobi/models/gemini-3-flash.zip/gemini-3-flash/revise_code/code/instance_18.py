import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_textile_factory():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Extract parameters
    weekly_production_time = params['weekly_production_time']
    fabric_production_rate = params['fabric_production_rate']
    min_curtain_fabric_sales = params['min_curtain_fabric_sales']
    min_clothing_fabric_sales = params['min_clothing_fabric_sales']
    day_shift_regular_capacity = params['day_shift_regular_capacity']
    night_shift_regular_capacity = params['night_shift_regular_capacity']
    day_overtime_limit = params['day_overtime_limit']
    night_overtime_limit = params['night_overtime_limit']
    day_overtime_penalty = params['day_overtime_penalty']
    night_overtime_penalty = params['night_overtime_penalty']
    day_min_utilization_ratio = params['day_min_utilization_ratio']
    night_min_utilization_ratio = params['night_min_utilization_ratio']

    # Convert sales requirements to hours
    min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
    min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

    # Create Gurobi model
    model = gp.Model("Textile_Factory_Optimization")
    model.setParam('OutputFlag', 0)

    # Decision variables
    day_reg = model.addVar(lb=0, ub=day_shift_regular_capacity, name="day_reg")
    night_reg = model.addVar(lb=0, ub=night_shift_regular_capacity, name="night_reg")
    day_overtime_hours = model.addVar(lb=0, ub=day_overtime_limit, name="day_overtime_hours")
    night_overtime_hours = model.addVar(lb=0, ub=night_overtime_limit, name="night_overtime_hours")
    x_clothing = model.addVar(lb=min_clothing_hours, name="clothing_hours")
    x_curtain = model.addVar(lb=min_curtain_hours, name="curtain_hours")

    # Objective: minimize overtime penalty costs
    model.setObjective(
        day_overtime_hours * day_overtime_penalty + 
        night_overtime_hours * night_overtime_penalty, 
        GRB.MINIMIZE
    )

    # Constraints
    # 1. Total regular hours must equal the set weekly production time
    model.addConstr(day_reg + night_reg == weekly_production_time, "Total_Regular_Hours")

    # 2. Utilization expectations for each shift
    model.addConstr(day_reg >= day_min_utilization_ratio * (day_reg + night_reg), "Day_Utilization")
    model.addConstr(night_reg >= night_min_utilization_ratio * (day_reg + night_reg), "Night_Utilization")

    # 3. Total production hours balance
    model.addConstr(
        x_clothing + x_curtain == day_reg + night_reg + day_overtime_hours + night_overtime_hours, 
        "Production_Time_Balance"
    )

    # Solve
    model.optimize()

    # Print results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_textile_factory()
