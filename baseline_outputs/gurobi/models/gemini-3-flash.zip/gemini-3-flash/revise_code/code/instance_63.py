import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

# Extract parameters
produce_to_transport = params['produce_to_transport']
horse_poll_per_trip = params['horse_pollution_per_trip']
bike_poll_per_trip = params['bicycle_pollution_per_trip']
cart_poll_per_trip = params['handcart_pollution_per_trip']
max_total_pollution = params['max_total_pollution']
min_horse_trips = params['min_horse_trips']
horse_cap = params['horse_capacity_per_trip']
bike_cap = params['bicycle_capacity_per_trip']
cart_cap = params['handcart_capacity_per_trip']
min_total_produce = params['min_total_produce']

horse_cost_per_trip = params['horse_cost_per_trip']
bike_cost_per_trip = params['bicycle_cost_per_trip']
cart_cost_per_trip = params['handcart_cost_per_trip']
horse_fixed_cost = params['horse_fixed_cost']
bike_fixed_cost = params['bicycle_fixed_cost']
cart_fixed_cost = params['handcart_fixed_cost']
pollution_penalty_per_unit = params['pollution_penalty_per_unit']
pollution_permit_threshold = params['horse_pollution_permit_threshold']
pollution_permit_fee = params['horse_pollution_permit_fee']

# Model
model = gp.Model("FarmTransport")
model.setParam('OutputFlag', 0)

# Decision variables
x_horse = model.addVar(vtype=GRB.INTEGER, lb=min_horse_trips, name="horse_trips")
x_bike = model.addVar(vtype=GRB.INTEGER, lb=0, name="bike_trips")
x_cart = model.addVar(vtype=GRB.INTEGER, lb=0, name="cart_trips")

# Binary variables for vehicle selection and permit fee
y_bike = model.addVar(vtype=GRB.BINARY, name="use_bike")
y_cart = model.addVar(vtype=GRB.BINARY, name="use_cart")
z_permit = model.addVar(vtype=GRB.BINARY, name="pay_permit_fee")

# Big-M constant
M = 2000

# Constraints
# 1. Minimum produce requirement
model.addConstr(horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_total_produce)

# 2. Maximum pollution constraint
total_pollution = horse_poll_per_trip * x_horse + bike_poll_per_trip * x_bike + cart_poll_per_trip * x_cart
model.addConstr(total_pollution <= max_total_pollution)

# 3. Choose only one of bicycle or handcart
model.addConstr(y_bike + y_cart <= 1)
model.addConstr(x_bike <= M * y_bike)
model.addConstr(x_cart <= M * y_cart)

# 4. Pollution permit fee logic
model.addConstr(total_pollution <= pollution_permit_threshold + M * z_permit)

# Objective: Minimize total cost
# Total Cost = Variable Costs + Fixed Costs + Pollution Penalty + Permit Fee
variable_costs = horse_cost_per_trip * x_horse + bike_cost_per_trip * x_bike + cart_cost_per_trip * x_cart
fixed_costs = horse_fixed_cost + bike_fixed_cost * y_bike + cart_fixed_cost * y_cart
pollution_costs = pollution_penalty_per_unit * total_pollution + pollution_permit_fee * z_permit

model.setObjective(variable_costs + fixed_costs + pollution_costs, GRB.MINIMIZE)

# Solve
model.optimize()

# Output the result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
