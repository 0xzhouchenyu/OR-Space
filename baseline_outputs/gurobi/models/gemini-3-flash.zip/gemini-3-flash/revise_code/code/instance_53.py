import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define paths to data files
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_file = os.path.join(data_dir, "general_parameters.csv")
    table_file = os.path.join(data_dir, "table_1.csv")

    # Load general parameters from general_parameters.csv
    params = {}
    with open(params_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()

    # Load mode-specific costs for each child from table_1.csv
    child_costs = {}
    with open(table_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row['Child'].strip()
            child_costs[child] = {
                'budget': float(row['Cost_budget'].strip()),
                'balanced': float(row['Cost_balanced'].strip()),
                'premium': float(row['Cost_premium'].strip())
            }

    children = list(child_costs.keys())
    modes = ['budget', 'balanced', 'premium']

    # Initialize the Gurobi model
    model = gp.Model("ZhangFamilyTripRevised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x: whether a child joins the trip
    x = model.addVars(children, vtype=GRB.BINARY, name="take_child")
    # y: which pace mode is selected for the whole family
    y = model.addVars(modes, vtype=GRB.BINARY, name="pace_mode")
    # z: link variable where z[c, m] = x[c] * y[m]
    z = model.addVars(children, modes, vtype=GRB.BINARY, name="child_mode_link")
    # Spread variables
    c_max = model.addVar(lb=0.0, name="max_child_cost")
    c_min = model.addVar(lb=0.0, name="min_child_cost")

    # Exactly one family-wide pace mode must be selected
    model.addConstr(y.sum() == 1, name="OneModeOnly")

    # Linearize the relationship z[c, m] = x[c] * y[m]
    for c in children:
        for m in modes:
            model.addConstr(z[c, m] <= x[c])
            model.addConstr(z[c, m] <= y[m])
            model.addConstr(z[c, m] >= x[c] + y[m] - 1)

    # Constraint: Ginny is mandatory as the youngest child
    if int(params.get('mandatory_ginny', 1)) == 1:
        model.addConstr(x['Ginny'] == 1, name="GinnyMandatory")

    # Logical constraints between children
    if int(params.get('harry_no_fred', 0)) == 1:
        model.addConstr(x['Harry'] + x['Fred'] <= 1, name="HarryNoFred")
    if int(params.get('harry_no_george', 0)) == 1:
        model.addConstr(x['Harry'] + x['George'] <= 1, name="HarryNoGeorge")
    if int(params.get('george_requires_fred', 0)) == 1:
        model.addConstr(x['George'] <= x['Fred'], name="GeorgeReqFred")
    if int(params.get('george_requires_hermione', 0)) == 1:
        model.addConstr(x['George'] <= x['Hermione'], name="GeorgeReqHermione")

    # Total party size constraints
    num_selected = x.sum()
    max_children = int(params.get('max_children', 4))
    min_children = int(params.get('min_children', 3))
    min_children_per_mode = int(params.get('min_children_per_mode', 3))

    # Absolute limit on number of children
    model.addConstr(num_selected <= max_children, name="MaxChildrenLimit")
    
    # Mode-dependent floor for group size
    model.addConstr(num_selected >= y['budget'] * min_children + 
                                   (y['balanced'] + y['premium']) * min_children_per_mode, 
                    name="MinChildrenModeDependent")

    # Monetary cost calculations and budget limit
    total_spend = gp.quicksum(child_costs[c][m] * z[c, m] for c in children for m in modes)
    max_total_cost = float(params.get('max_total_cost', 5000))
    model.addConstr(total_spend <= max_total_cost, name="BudgetCap")

    # Fairness constraints (capturing max and min costs among selected children under the chosen mode)
    # Use a large constant M for Big-M formulation on the minimum cost floor
    M = 10000.0
    for c in children:
        for m in modes:
            cost = child_costs[c][m]
            # c_max must be >= every selected child's mode-specific cost
            model.addConstr(c_max >= cost * z[c, m])
            # c_min must be <= every selected child's mode-specific cost
            model.addConstr(c_min <= cost * z[c, m] + M * (1 - z[c, m]))

    # Objective Function: Minimize (Total Spend + Fairness Penalty * Cost Spread)
    fairness_penalty = float(params.get('fairness_penalty', 0.1))
    model.setObjective(total_spend + fairness_penalty * (c_max - c_min), GRB.MINIMIZE)

    # Solve the optimization problem
    model.optimize()

    # Output results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # In case no solution is found given the constraints
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
