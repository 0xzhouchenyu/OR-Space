import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_production_optimization():
    # Define file paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    table1_path = os.path.join(data_dir, 'table_1.csv')

    # Load general parameters from general_parameters.csv
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            param_value = float(row['Value'].strip())
            params[param_name] = param_value

    # Load device-specific data from table_1.csv
    devices = []
    devices_data = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            d_name = row['Device'].strip()
            devices.append(d_name)
            devices_data[d_name] = {
                'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
                'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
                'capacity': float(row['Max_Processing_Capacity_Units'].strip()),
                # Map device-specific parameters from general_parameters.csv
                'energy_per_unit': params[f'energy_per_unit_{d_name}'],
                'startup_energy': params[f'startup_energy_{d_name}']
            }

    # Initialize Gurobi model
    model = gp.Model("MinCostProductionRevised")
    model.setParam('OutputFlag', 0)

    # Time periods
    periods = ['peak', 'offpeak']

    # Decision variables
    # x[i, t]: number of units produced on device i in period t (continuous)
    x = model.addVars(devices, periods, lb=0, vtype=GRB.CONTINUOUS, name="x")
    # y[i, t]: binary variable indicating if device i starts up in period t
    y = model.addVars(devices, periods, vtype=GRB.BINARY, name="y")
    # z[i]: binary variable indicating if device i is used at all (preparation cost indicator)
    z = model.addVars(devices, vtype=GRB.BINARY, name="z")

    # Objective Function Components
    # 1. Preparation Completion Costs (once per device if used)
    prep_costs_total = gp.quicksum(devices_data[i]['prep_cost'] * z[i] for i in devices)
    
    # 2. Variable Production Costs (per unit)
    prod_costs_total = gp.quicksum(devices_data[i]['unit_cost'] * x[i, t] for i in devices for t in periods)
    
    # 3. Startup Monetary Costs (per device per period)
    startup_monetary_total = gp.quicksum(params['startup_cost'] * y[i, t] for i in devices for t in periods)
    
    # 4. Electricity Costs (energy consumption per unit and energy consumption for startups)
    energy_peak = gp.quicksum(x[i, 'peak'] * devices_data[i]['energy_per_unit'] + 
                             y[i, 'peak'] * devices_data[i]['startup_energy'] for i in devices)
    energy_offpeak = gp.quicksum(x[i, 'offpeak'] * devices_data[i]['energy_per_unit'] + 
                                y[i, 'offpeak'] * devices_data[i]['startup_energy'] for i in devices)
    
    electricity_costs_total = (energy_peak * params['energy_price_peak'] + 
                               energy_offpeak * params['energy_price_offpeak'])

    # Objective: Minimize total monetary cost
    model.setObjective(prep_costs_total + prod_costs_total + startup_monetary_total + electricity_costs_total, GRB.MINIMIZE)

    # Constraints
    # 1. Total production must equal required units
    model.addConstr(x.sum() == params['required_units'], name="TotalRequiredProduction")

    # 2. Daily capacity and linking indicators
    for i in devices:
        # Total daily production on device i cannot exceed its capacity
        model.addConstr(gp.quicksum(x[i, t] for t in periods) <= devices_data[i]['capacity'] * z[i], name=f"DailyCap_{i}")
        for t in periods:
            # Production in period t on device i requires a startup in that period
            model.addConstr(x[i, t] <= devices_data[i]['capacity'] * y[i, t], name=f"StartupIndicator_{i}_{t}")
            # A startup in period t on device i implies the device is prepared for the day
            model.addConstr(y[i, t] <= z[i], name=f"PrepIndicatorLink_{i}_{t}")

    # 3. Energy budget constraints
    model.addConstr(energy_peak <= params['energy_budget_peak'], name="PeakEnergyBudget")
    model.addConstr(energy_offpeak <= params['energy_budget_offpeak'], name="OffpeakEnergyBudget")

    # 4. Startup monetary budget constraint
    model.addConstr(startup_monetary_total <= params['startup_budget'], name="StartupBudgetLimit")

    # Solve the model
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # If not optimal, print the status code for diagnostics
        print(f"Solver terminated with status {model.status}")

if __name__ == "__main__":
    solve_production_optimization()
