import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Define the data directory path
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Extract parameter values
    profit_corn = params['profit_per_acre_corn']
    profit_wheat = params['profit_per_acre_wheat']
    profit_soybeans = params['profit_per_acre_soybeans']
    profit_sorghum = params['profit_per_acre_sorghum']
    total_area = params['total_farm_area']
    corn_wheat_ratio = params['corn_wheat_ratio']
    soybeans_sorghum_ratio = params['soybeans_sorghum_ratio']
    wheat_sorghum_ratio = params['wheat_sorghum_ratio']
    
    # Create the Gurobi model
    model = gp.Model("Farm_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables for acreage
    corn = model.addVar(lb=0, name="corn")
    wheat = model.addVar(lb=0, name="wheat")
    soybeans = model.addVar(lb=0, name="soybeans")
    sorghum = model.addVar(lb=0, name="sorghum")
    
    # Binary variable for mutual exclusion between corn and soybeans
    # y = 1 if corn program is chosen, y = 0 if soybean program is chosen
    y = model.addVar(vtype=GRB.BINARY, name="program_choice")
    
    # Objective: maximize profit
    model.setObjective(
        profit_corn * corn + profit_wheat * wheat + profit_soybeans * soybeans + profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )
    
    # Constraints
    # 1. Total area constraint
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")
    
    # 2. Corn-Wheat ratio: corn >= 2 * wheat
    model.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio")
    
    # 3. Soybeans-Sorghum ratio: soybeans >= 0.5 * sorghum
    model.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio")
    
    # 4. Wheat-Sorghum ratio: wheat = 3 * sorghum
    model.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_ratio")
    
    # 5. Minimum corn requirement: corn >= 20
    model.addConstr(corn >= 20, "min_corn")
    
    # 6. Mutual exclusion between corn and soybeans
    # If y=1, corn can be planted (up to total_area), soybeans must be 0
    # If y=0, soybeans can be planted (up to total_area), corn must be 0
    model.addConstr(corn <= total_area * y, "corn_exclusion")
    model.addConstr(soybeans <= total_area * (1 - y), "soybeans_exclusion")
    
    # Solve the model
    model.optimize()
    
    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
