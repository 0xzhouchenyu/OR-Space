import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_investment_optimization():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Extract parameters
    initial_fund = params['initial_fund']
    annual_rate = params['annual_profit_rate'] / 100
    inv_limit_y1 = params['investment_limit_year1']
    return_rate_y1y2 = params['return_rate_year1_to_year2'] / 100
    inv_limit_y2 = params['investment_limit_year2']
    return_rate_y2y3 = params['return_rate_year2_to_year3'] / 100
    inv_limit_y3 = params['investment_limit_year3']
    profit_rate_y3 = params['profit_rate_year3'] / 100
    fee_y1 = params['fee_year1']
    fee_y2 = params['fee_year2']
    fee_y3 = params['fee_year3']

    # Create model
    model = gp.Model("Investment_Optimization")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # a1, a2, a3: annual investments at beginning of year 1, 2, 3
    a1 = model.addVar(lb=0, name="a1")
    a2 = model.addVar(lb=0, name="a2")
    a3 = model.addVar(lb=0, name="a3")

    # b1: special investment at beginning of year 1 (returns end of year 2)
    b1 = model.addVar(lb=0, ub=inv_limit_y1, name="b1")
    # c2: special investment at beginning of year 2 (returns end of year 3)
    c2 = model.addVar(lb=0, ub=inv_limit_y2, name="c2")
    # d3: special investment at beginning of year 3 (returns end of year 3)
    d3 = model.addVar(lb=0, ub=inv_limit_y3, name="d3")

    # Binary variables for fixed management fees
    y1 = model.addVar(vtype=GRB.BINARY, name="y1")
    y2 = model.addVar(vtype=GRB.BINARY, name="y2")
    y3 = model.addVar(vtype=GRB.BINARY, name="y3")

    # Constraints for special investment usage and fees
    model.addConstr(b1 <= inv_limit_y1 * y1, "y1_usage")
    model.addConstr(c2 <= inv_limit_y2 * y2, "y2_usage")
    model.addConstr(d3 <= inv_limit_y3 * y3, "y3_usage")

    # Budget constraint at beginning of Year 1
    cash1 = initial_fund - a1 - b1 - fee_y1 * y1
    model.addConstr(cash1 >= 0, "Year1_budget")

    # Budget constraint at beginning of Year 2
    # Available: cash from year 1 + return from a1
    available2 = cash1 + a1 * (1 + annual_rate)
    cash2 = available2 - a2 - c2 - fee_y2 * y2
    model.addConstr(cash2 >= 0, "Year2_budget")

    # Budget constraint at beginning of Year 3
    # Available: cash from year 2 + return from a2 + return from b1
    available3 = cash2 + a2 * (1 + annual_rate) + b1 * return_rate_y1y2
    cash3 = available3 - a3 - d3 - fee_y3 * y3
    model.addConstr(cash3 >= 0, "Year3_budget")

    # Objective: total funds at end of year 3
    # End of year 3: cash leftover from year 3 + return from a3 + return from c2 + return from d3
    total_end = cash3 + a3 * (1 + annual_rate) + c2 * return_rate_y2y3 + d3 * (1 + profit_rate_y3)
    model.setObjective(total_end, GRB.MAXIMIZE)

    # Solve
    model.optimize()

    # Output result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_investment_optimization()
