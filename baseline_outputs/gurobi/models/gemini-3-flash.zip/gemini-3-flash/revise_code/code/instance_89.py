import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    if not os.path.exists(filepath):
        return params
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Model definition
    model = gp.Model("Maximize_Profit_Rolling_Commitment")
    model.setParam('OutputFlag', 0)

    # Time periods and products
    weeks = [1, 2]
    products = ['A', 'B']

    # Decision variables
    # p: Production, s: Sales, inv: Inventory at end of week, 
    # z: Promotion binary flag, sp: Linearized sales under promotion
    p = model.addVars(products, weeks, lb=0.0, name="production")
    s = model.addVars(products, weeks, lb=0.0, name="sales")
    inv = model.addVars(products, weeks, lb=0.0, name="inventory")
    z = model.addVars(products, weeks, vtype=GRB.BINARY, name="promotion")
    sp = model.addVars(products, weeks, lb=0.0, name="promo_sales")

    # Initial inventory constants
    initial_inventory = {
        'A': params.get('initial_inventory_A', 0.0),
        'B': params.get('initial_inventory_B', 0.0)
    }

    # Parameters extraction
    hours_A = params.get('hours_per_kg_product_A', 6.0)
    hours_B = params.get('hours_per_kg_product_B', 3.0)
    min_ratio = params.get('min_output_ratio_product_B_to_A', 3.0)
    storage_ratio = params.get('storage_space_ratio_product_A_to_B', 4.0)
    
    profit_A = params.get('profit_per_kg_product_A', 30.0)
    profit_B = params.get('profit_per_kg_product_B', 10.0)
    bonus_A = params.get('promo_profit_bonus_A', 2.0)
    bonus_B = params.get('promo_profit_bonus_B', 1.0)
    cost_A = params.get('storage_cost_per_kg_A', 1.0)
    cost_B = params.get('storage_cost_per_kg_B', 1.0)

    # Big-M for promotion linearization
    # Max possible sales of B per week is 40/3 ~ 13.33. M=1000 is safe.
    M = 1000.0

    # Constraints per week
    for t in weeks:
        # 1. Mass balance: Inventory(t) = Inventory(t-1) + Production(t) - Sales(t)
        for prod in products:
            prev_inv = initial_inventory[prod] if t == 1 else inv[prod, t-1]
            model.addConstr(inv[prod, t] == prev_inv + p[prod, t] - s[prod, t], name=f"balance_{prod}_{t}")

        # 2. Production time constraint
        max_h = params.get(f'max_production_hours_week_{t}', 40.0)
        model.addConstr(hours_A * p['A', t] + hours_B * p['B', t] <= max_h, name=f"hours_{t}")

        # 3. Market Demand: Sales of B >= 3 * Sales of A
        model.addConstr(s['B', t] >= min_ratio * s['A', t], name=f"demand_ratio_{t}")

        # 4. Storage capacity constraint
        # Total storage capacity in kg of A equivalents. Total Space = Capacity * storage_ratio
        max_storage_A_equiv = params.get(f'max_storage_product_A_equiv_week_{t}', 4.0)
        total_space = max_storage_A_equiv * storage_ratio
        model.addConstr(storage_ratio * inv['A', t] + inv['B', t] <= total_space, name=f"storage_{t}")

        # 5. Promotion sales linearization (sp = sales if z=1, else 0)
        for prod in products:
            model.addConstr(sp[prod, t] <= s[prod, t], name=f"sp_limit_s_{prod}_{t}")
            model.addConstr(sp[prod, t] <= M * z[prod, t], name=f"sp_limit_z_{prod}_{t}")

    # 6. Global promotion limits (total number of promotion weeks per product)
    model.addConstr(gp.quicksum(z['A', t] for t in weeks) <= params.get('max_promotions_product_A', 1.0), name="max_promo_A")
    model.addConstr(gp.quicksum(z['B', t] for t in weeks) <= params.get('max_promotions_product_B', 1.0), name="max_promo_B")

    # Objective function: Maximize total profit over two weeks
    # Note: Cost of inventory is specifically described as end-of-week-1 to week-2
    # In a finite horizon model, last-period inventory has no carry-over cost context.
    total_sales_profit = gp.quicksum(
        profit_A * s['A', t] + profit_B * s['B', t] +
        bonus_A * sp['A', t] + bonus_B * sp['B', t]
        for t in weeks
    )
    # Applying holding cost for inventory held at end of week 1
    total_holding_cost = cost_A * inv['A', 1] + cost_B * inv['B', 1]
    
    model.setObjective(total_sales_profit - total_holding_cost, GRB.MAXIMIZE)

    # Solve the problem
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
