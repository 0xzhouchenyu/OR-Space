import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries with cleaned keys and values."""
    data = []
    if not os.path.exists(filepath):
        return data
    with open(filepath, 'r', newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data

def main():
    # Set data file paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params_file = os.path.join(data_dir, 'general_parameters.csv')
    products_file = os.path.join(data_dir, 'table_1.csv')

    # Load data from CSVs
    params_data = load_csv_data(params_file)
    products_data = load_csv_data(products_file)

    # Parse general parameters into a dictionary
    params = {row['Parameter_Name']: float(row['Value']) for row in params_data}
    
    # Parse product-specific data into a dictionary
    prod_info = {}
    for row in products_data:
        p_name = row['Product']
        prod_info[p_name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'var_cost': float(row['Variable_cost_per_pack']),
            'capacity': float(row['Production_capacity']) if row['Production_capacity'].strip() else None
        }

    # Initialize Gurobi model
    model = gp.Model("HealthyPetFoodsOptimization")
    model.setParam('OutputFlag', 0)

    # Decision Variables
    # x_m: Number of Meaties packs produced
    # x_y: Number of Yummies packs produced
    x_m = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Meaties")
    x_y = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Yummies")
    
    # line_active: 1 if the co-packing line is utilized, 0 otherwise
    line_active = model.addVar(vtype=GRB.BINARY, name="LineActive")
    
    # rebate_active: 1 if the retailer rebate thresholds are met, 0 otherwise
    rebate_active = model.addVar(vtype=GRB.BINARY, name="RebateActive")

    # Profit calculations per pack
    # Profit = Price - Variable Cost - (Grains * Grain Price) - (Meat * Meat Price)
    m = prod_info['Meaties']
    y = prod_info['Yummies']
    
    profit_m = m['price'] - m['var_cost'] - (m['grains'] * params['price_per_lb_grains'] + m['meat'] * params['price_per_lb_meat'])
    profit_y = y['price'] - y['var_cost'] - (y['grains'] * params['price_per_lb_grains'] + y['meat'] * params['price_per_lb_meat'])

    # Objective: Maximize total net profit
    model.setObjective(
        profit_m * x_m + 
        profit_y * x_y - 
        params['line_fixed_cost'] * line_active + 
        params['retailer_rebate_fixed'] * rebate_active,
        GRB.MAXIMIZE
    )

    # Constraints
    
    # 1. Ingredient availability (Grains and Meat)
    model.addConstr(m['grains'] * x_m + y['grains'] * x_y <= params['max_grains'], "GrainsLimit")
    model.addConstr(m['meat'] * x_m + y['meat'] * x_y <= params['max_meat'], "MeatLimit")

    # 2. Co-packing line capacity and usage
    # Total monthly throughput limit on shared co-packing line when active
    model.addConstr(x_m + x_y <= params['line_capacity_packs'] * line_active, "SharedLineCapacity")
    
    # 3. Minimum production requirements if the line is active
    # Minimum combined production (batch size)
    model.addConstr(x_m + x_y >= params['min_batch_packs'] * line_active, "MinBatch")
    
    # Contractual minimum monthly Yummies production
    model.addConstr(x_y >= params['min_yummies'] * line_active, "MinYummies")

    # 4. Product-specific production capacity (Meaties)
    if m['capacity'] is not None:
        model.addConstr(x_m <= m['capacity'] * line_active, "MeatiesCapacity")
        
    # 5. Retailer Rebate Logic (AND gate mechanism)
    # Both Yummies and Meaties must reach their respective thresholds to earn the allowance
    model.addConstr(x_y >= params['retailer_rebate_yummies_threshold'] * rebate_active, "RebateYThreshold")
    model.addConstr(x_m >= params['retailer_rebate_min_meaties'] * rebate_active, "RebateMThreshold")

    # Solve the optimization problem
    model.optimize()

    # Output result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case no solution is found (problem structure ensures 0 is a possible profit)
        print("FINAL_OBJ_VALUE: 0.0")

if __name__ == "__main__":
    main()
