import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define the path to the data file
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    
    # Read parameters from the CSV file
    df = pd.read_csv(data_path)
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = row['Value']
        
    # Extract specific parameter values
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = float(params['raw_bar_length'])
    setup_cost_per_pattern = float(params['setup_cost_per_pattern'])
    max_distinct_patterns = int(params['max_distinct_patterns'])
    
    # Lengths of the required steel bars
    len1, len2, len3 = 3, 4, 5
    
    # Generate all valid cutting patterns (x, y, z) such that len1*x + len2*y + len3*z <= L
    patterns = []
    for x in range(int(L // len1) + 1):
        for y in range(int(L // len2) + 1):
            for z in range(int(L // len3) + 1):
                if len1 * x + len2 * y + len3 * z <= L:
                    if x > 0 or y > 0 or z > 0:
                        patterns.append((x, y, z))
                        
    # Initialize the Gurobi optimization model
    model = gp.Model("CuttingStockRevised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables:
    # n_patterns[i]: number of times pattern i is used (Integer)
    # used_pattern[i]: binary variable, 1 if pattern i is used, 0 otherwise
    n_patterns = model.addVars(len(patterns), vtype=GRB.INTEGER, lb=0, name="n_patterns")
    used_pattern = model.addVars(len(patterns), vtype=GRB.BINARY, name="used_pattern")
    
    # Constraints: satisfy the demand for each type of steel bar
    model.addConstr(gp.quicksum(patterns[i][0] * n_patterns[i] for i in range(len(patterns))) >= q3, "Demand_3m")
    model.addConstr(gp.quicksum(patterns[i][1] * n_patterns[i] for i in range(len(patterns))) >= q4, "Demand_4m")
    model.addConstr(gp.quicksum(patterns[i][2] * n_patterns[i] for i in range(len(patterns))) >= q5, "Demand_5m")
    
    # Constraint: link n_patterns and used_pattern (Big-M constraint)
    # M is a large constant representing the maximum possible number of raw bars.
    M = q3 + q4 + q5
    for i in range(len(patterns)):
        model.addConstr(n_patterns[i] <= M * used_pattern[i], f"Link_{i}")
        
    # Constraint: limit the number of distinct patterns used
    model.addConstr(gp.quicksum(used_pattern[i] for i in range(len(patterns))) <= max_distinct_patterns, "MaxDistinctPatterns")
    
    # Objective: minimize total waste
    # Total waste = (Total length of raw bars used) - (Total length of required pieces) + (Total setup cost)
    # Note: Overproduced pieces are also considered waste in this formulation.
    total_raw_length = gp.quicksum(L * n_patterns[i] for i in range(len(patterns)))
    total_required_length = len1 * q3 + len2 * q4 + len3 * q5
    total_setup_cost = gp.quicksum(setup_cost_per_pattern * used_pattern[i] for i in range(len(patterns)))
    
    model.setObjective(total_raw_length - total_required_length + total_setup_cost, GRB.MINIMIZE)
    
    # Solve the optimization problem
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimal solution not found.")

if __name__ == "__main__":
    solve()
