import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    # Load the bandwidth table
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    nodes = []
    bandwidth = {}
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # Strip whitespace from headers
        nodes = [h.strip() for h in header[1:]]
        
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                bandwidth[(row_node, col_node)] = bw
    
    # Define source, intermediate, and target nodes
    source = 'A'
    intermediate = 'C'
    target = 'E'
    
    # Define costs: 100 - bandwidth (only for bandwidth > 0)
    costs = {}
    edges = []
    for (u, v), bw in bandwidth.items():
        if bw > 0 and u != v:
            costs[(u, v)] = 100 - bw
            edges.append((u, v))
            
    # Create Gurobi model
    model = gp.Model("routing_cost_minimization")
    model.setParam('OutputFlag', 0)
    
    # Variables: x[u, v] = 1 if link (u, v) is used in the path
    x = model.addVars(edges, vtype=GRB.BINARY, name="x")
    
    # Variables: u[i] for MTZ constraints to ensure a simple path (no cycles)
    u_vars = model.addVars(nodes, vtype=GRB.CONTINUOUS, lb=1, ub=len(nodes), name="u")
    
    # Objective: Minimize total routing cost
    model.setObjective(gp.quicksum(costs[e] * x[e] for e in edges), GRB.MINIMIZE)
    
    # Constraints:
    # 1. Flow conservation
    for node in nodes:
        outflow = gp.quicksum(x[node, j] for j in nodes if (node, j) in edges)
        inflow = gp.quicksum(x[j, node] for j in nodes if (j, node) in edges)
        if node == source:
            model.addConstr(outflow - inflow == 1, name=f"flow_source_{node}")
        elif node == target:
            model.addConstr(outflow - inflow == -1, name=f"flow_target_{node}")
        else:
            model.addConstr(outflow - inflow == 0, name=f"flow_intermediate_{node}")
            
    # 2. Visit node C (intermediate node)
    # Since it's a simple path from A to E, visiting C means exactly one edge enters and one edge leaves C.
    model.addConstr(gp.quicksum(x[i, intermediate] for i in nodes if (i, intermediate) in edges) == 1, name="visit_C")
    
    # 3. Simple path constraints (each node visited at most once)
    for node in nodes:
        model.addConstr(gp.quicksum(x[node, j] for j in nodes if (node, j) in edges) <= 1, name=f"limit_out_{node}")
        model.addConstr(gp.quicksum(x[j, node] for j in nodes if (j, node) in edges) <= 1, name=f"limit_in_{node}")
        
    # 4. MTZ constraints to prevent cycles
    n = len(nodes)
    for (i, j) in edges:
        if j != source:
            model.addConstr(u_vars[i] - u_vars[j] + n * x[i, j] <= n - 1, name=f"mtz_{i}_{j}")
            
    # Solve the model
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()
