import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    # Define data paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    demand_path = os.path.join(data_dir, "table_4_3.csv")
    supply_path = os.path.join(data_dir, "table_4_4.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Load data
    demand_df = pd.read_csv(demand_path)
    supply_df = pd.read_csv(supply_path)
    params_df = pd.read_csv(params_path)

    # Parse parameters
    p2_target = int(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])

    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split()[0]
        spec = int(row['Specialty'])
        dem = int(row['Demand'])
        demand[(city, spec)] = dem

    # Parse supply and preferences
    supply = {}
    suitable = {}
    pref_spec = {}
    pref_city = {}
    types = []
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        types.append(t)
        supply[t] = int(row['Number_of_People'])
        suitable[t] = [int(s) for s in str(row['Suitable_Specialty']).split(',')]
        pref_spec[t] = int(row['Preferred_Specialty'])
        pref_city[t] = row['Preferred_City']

    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]

    # Create optimization model
    model = gp.Model("StaffingOptimization")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[i, j, k] is the number of people of type i assigned to city j and specialty k
    x = model.addVars(types, cities, specs, vtype=GRB.INTEGER, name="x")

    # Constraints
    # 1. Supply constraint: Total people of type i assigned cannot exceed supply
    model.addConstrs((x.sum(i, '*', '*') <= supply[i] for i in types), name="supply")

    # 2. Demand constraint: Full demand for each specialty in each city must be met
    # Using == to reflect "filling required positions" as per the revised policy
    model.addConstrs((x.sum('*', j, k) == demand[(j, k)] for j in cities for k in specs), name="demand")

    # 3. Suitability constraint: People can only be assigned to specialties they are suitable for
    for i in types:
        for j in cities:
            for k in specs:
                if k not in suitable[i]:
                    model.addConstr(x[i, j, k] == 0)

    # 4. Priority 2 constraint: At least p2_target people must meet their preferred specialty
    model.addConstr(
        gp.quicksum(x[i, j, pref_spec[i]] for i in types for j in cities) >= p2_target,
        name="priority2"
    )

    # Objective: Maximize the number of recruits who satisfy both preferred specialty and preferred city
    model.setObjective(
        gp.quicksum(x[i, pref_city[i], pref_spec[i]] for i in types),
        GRB.MAXIMIZE
    )

    # Solve the model
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {int(model.objVal)}")
    else:
        # If no optimal solution is found (e.g., infeasible), print 0 or handle accordingly
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    solve()
