import csv
import math
import os
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define data paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Read orders
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
    
    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    total_required_area = sum(o['width'] * o['length'] for o in orders)

    # Read general parameters
    std_widths = []
    params = {}
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = float(row['Value'])
            params[name] = val
            if name.startswith('standard_width_'):
                std_widths.append(val)
    
    setup_penalty = params['pattern_setup_penalty']
    wide_threshold = params['wide_roll_threshold_width']
    wide_penalty = params['wide_roll_extra_setup_penalty']

    # Generate all possible cutting patterns for each standard width
    def get_patterns(sw, order_widths):
        patterns = []
        def build_pattern(index, current_pattern, current_sum):
            if index == len(order_widths):
                if any(c > 0 for c in current_pattern):
                    patterns.append(list(current_pattern))
                return
            
            max_count = int(math.floor((sw - current_sum + 1e-7) / order_widths[index]))
            for count in range(max_count + 1):
                build_pattern(index + 1, current_pattern + [count], current_sum + count * order_widths[index])
        
        build_pattern(0, [], 0.0)
        return patterns

    patterns_by_sw = [get_patterns(sw, widths) for sw in std_widths]
    
    # Calculate penalties for each standard width
    # Penalty = setup_penalty + (wide_penalty if sw >= wide_threshold)
    penalties = [setup_penalty + (wide_penalty if sw >= wide_threshold - 1e-7 else 0) for sw in std_widths]

    # Initialize Gurobi model
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)

    # Variables
    x = {} # Length of standard width s cut with pattern i
    y = {} # Binary variable: 1 if pattern i on standard width s is used
    
    for s, sw in enumerate(std_widths):
        for i, p in enumerate(patterns_by_sw[s]):
            x[s, i] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{s}_{i}")
            y[s, i] = model.addVar(vtype=GRB.BINARY, name=f"y_{s}_{i}")

    # Objective: Minimize total waste area
    # Waste = (Total Area Used - Total Required Area) + Total Penalties
    total_area_used = gp.quicksum(std_widths[s] * x[s, i] for s in range(len(std_widths)) for i in range(len(patterns_by_sw[s])))
    total_penalties = gp.quicksum(penalties[s] * y[s, i] for s in range(len(std_widths)) for i in range(len(patterns_by_sw[s])))
    
    model.setObjective(total_area_used + total_penalties - total_required_area, GRB.MINIMIZE)

    # Constraints: Satisfy length requirements for each order
    for j in range(len(widths)):
        model.addConstr(gp.quicksum(patterns_by_sw[s][i][j] * x[s, i] 
                                    for s in range(len(std_widths)) 
                                    for i in range(len(patterns_by_sw[s]))) >= lengths[j])

    # Big-M constraint to link x and y
    # Max length of any order is 3000, so 10000 is a safe upper bound for x
    M = 10000
    for s in range(len(std_widths)):
        for i in range(len(patterns_by_sw[s])):
            model.addConstr(x[s, i] <= M * y[s, i])

    # Solve the model
    model.optimize()

    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.ObjVal, 4)}")

if __name__ == "__main__":
    solve()
