import csv
import os
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, 'data', filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return [row for row in reader]

def main():
    # Load data
    params_rows = load_csv('general_parameters.csv')
    params = {row['Parameter_Name']: float(row['Value']) for row in params_rows}
    
    demand_rows = load_csv('table_1.csv')
    demand_data = {}
    for row in demand_rows:
        demand_data[(row['Month'], row['Product'])] = int(row['Market_Demand_Units'])
    
    # Planning months and products
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']
    
    # Model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    prod = model.addVars(months, products, lb=0, name="prod")
    inv = model.addVars(months, products, lb=0, name="inv")
    grid = model.addVars(months, lb=0, name="grid")
    gen = model.addVars(months, lb=0, name="gen")
    
    # Parameters mapping
    prod_cost = {
        'Product_I': params['product_I_cost_jun_to_dec'],
        'Product_II': params['product_II_cost_jun_to_dec']
    }
    machine_hours = {
        'Product_I': params['product_I_machine_hours'],
        'Product_II': params['product_II_machine_hours']
    }
    power_kwh = {
        'Product_I': params['product_I_power_kwh'],
        'Product_II': params['product_II_power_kwh']
    }
    volume = {
        'Product_I': params['product_I_volume'],
        'Product_II': params['product_II_volume']
    }
    
    # Constraints
    for i, m in enumerate(months):
        # Inventory balance
        for p in products:
            prev_inv = 0 if i == 0 else inv[months[i-1], p]
            model.addConstr(inv[m, p] == prev_inv + prod[m, p] - demand_data[(m, p)])
            
        # Machine hours capacity
        model.addConstr(gp.quicksum(machine_hours[p] * prod[m, p] for p in products) <= params['machine_hours_capacity_monthly'])
        
        # Electricity balance and limits
        model.addConstr(gp.quicksum(power_kwh[p] * prod[m, p] for p in products) == grid[m] + gen[m])
        
        grid_quota_key = f"grid_quota_{m.lower()}"
        gen_max_key = f"generator_max_{m.lower()}"
        model.addConstr(grid[m] <= params[grid_quota_key])
        model.addConstr(gen[m] <= params[gen_max_key])
        
        # Warehouse capacity
        model.addConstr(gp.quicksum(volume[p] * inv[m, p] for p in products) <= params['warehouse_capacity'])
        
    # Objective
    production_cost = gp.quicksum(prod_cost[p] * prod[m, p] for m in months for p in products)
    inventory_cost = gp.quicksum(params['own_warehouse_cost'] * volume[p] * inv[m, p] for m in months for p in products)
    electricity_cost = gp.quicksum(params['grid_electricity_cost'] * grid[m] + params['generator_electricity_cost'] * gen[m] for m in months)
    
    model.setObjective(production_cost + inventory_cost + electricity_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
