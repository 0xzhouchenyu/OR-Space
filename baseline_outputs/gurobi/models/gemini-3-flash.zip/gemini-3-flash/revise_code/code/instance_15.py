import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    params = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    
    param_dict = dict(zip(params['Parameter_Name'], params['Value']))
    demand = dict(zip(table_1['stage'], table_1['tool_requirement']))
    
    return param_dict, demand

def solve():
    param_dict, demand = load_data()
    
    n = int(param_dict['n'])
    cost_new = float(param_dict['cost_new_tool'])
    cost_slow = float(param_dict['cost_slow_repair'])
    cost_fast = float(param_dict['cost_fast_repair'])
    dur_slow = int(param_dict['slow_repair_duration'])
    dur_fast = int(param_dict['fast_repair_duration'])
    
    max_fast = float(param_dict['max_fast_stage'])
    max_slow = float(param_dict['max_slow_stage'])
    emission_buy = float(param_dict['emission_buy'])
    emission_fast = float(param_dict['emission_fast_repair'])
    emission_slow = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_shortage = float(param_dict['penalty_shortage'])
    
    model = gp.Model("Tool_Repair_Problem_Revised")
    model.setParam('OutputFlag', 0)
    
    stages = list(range(1, n + 1))
    
    # Variables
    x = model.addVars(stages, vtype=GRB.INTEGER, lb=0, name="buy")
    y = model.addVars(stages, vtype=GRB.INTEGER, lb=0, ub=max_fast, name="fast")
    z = model.addVars(stages, vtype=GRB.INTEGER, lb=0, ub=max_slow, name="slow")
    s = model.addVars(stages, vtype=GRB.INTEGER, lb=0, name="shortage")
    c = model.addVars([0] + stages, vtype=GRB.INTEGER, lb=0, name="clean")
    d = model.addVars([0] + stages, vtype=GRB.INTEGER, lb=0, name="dirty")
    
    # Initial conditions
    model.addConstr(d[0] == 0, name="initial_dirty")
    # c[0] is the prebuy_clean at stage 0
    
    # Constraints for each stage
    for t in stages:
        # Shortage cannot exceed demand
        model.addConstr(s[t] <= demand[t], name=f"shortage_limit_{t}")
        
        # Tools used in stage t
        u_t = demand[t] - s[t]
        
        # Repaired tools becoming ready at the start of stage t
        y_ready = y[t - dur_fast - 1] if t - dur_fast - 1 >= 1 else 0
        z_ready = z[t - dur_slow - 1] if t - dur_slow - 1 >= 1 else 0
        
        # Clean tool balance: Available clean tools must cover usage
        model.addConstr(c[t] == c[t-1] + x[t] + y_ready + z_ready - u_t, name=f"clean_balance_{t}")
        
        # Dirty tool balance: Tools used become dirty and can be sent for repair
        model.addConstr(d[t] == d[t-1] + u_t - y[t] - z[t], name=f"dirty_balance_{t}")
        
    # Carbon budget constraint
    total_emissions = (
        emission_buy * (c[0] + gp.quicksum(x[t] for t in stages)) +
        emission_fast * gp.quicksum(y[t] for t in stages) +
        emission_slow * gp.quicksum(z[t] for t in stages)
    )
    model.addConstr(total_emissions <= carbon_budget, name="carbon_budget")
    
    # Objective function: Minimize total cost
    total_cost = (
        cost_new * (c[0] + gp.quicksum(x[t] for t in stages)) +
        cost_fast * gp.quicksum(y[t] for t in stages) +
        cost_slow * gp.quicksum(z[t] for t in stages) +
        penalty_shortage * gp.quicksum(s[t] for t in stages)
    )
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
