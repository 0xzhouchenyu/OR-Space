import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_optimization():
    # File paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(script_dir, "data", "table_1.csv")
    general_params_path = os.path.join(script_dir, "data", "general_parameters.csv")

    # Load monthly data
    months = []
    purchasing_prices = {}
    selling_prices = {}
    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            month = int(row['Month'])
            months.append(month)
            purchasing_prices[month] = float(row['Purchasing_Price_Yuan'])
            selling_prices[month] = float(row['Selling_Price_Yuan'])

    # Load general parameters
    params = {}
    with open(general_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    warehouse_capacity = params['warehouse_capacity']
    initial_stock = params['initial_stock']
    fixed_ordering_cost = params['fixed_ordering_cost']
    month2_bulk_receiving_threshold = params['month2_bulk_receiving_threshold']
    month2_bulk_receiving_fee = params['month2_bulk_receiving_fee']

    # Create the Gurobi model
    model = gp.Model("Maximize_Profit")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[m] = units purchased at the beginning of month m
    # s[m] = units sold during month m
    # inv[m] = inventory at the end of month m
    # y[m] = binary variable, 1 if any units are purchased in month m
    # z2 = binary variable, 1 if Month 2 purchase exceeds the bulk threshold
    x = model.addVars(months, lb=0, vtype=GRB.CONTINUOUS, name="purchase")
    s = model.addVars(months, lb=0, vtype=GRB.CONTINUOUS, name="sell")
    inv = model.addVars(months, lb=0, vtype=GRB.CONTINUOUS, name="inventory")
    y = model.addVars(months, vtype=GRB.BINARY, name="order_indicator")
    z2 = model.addVar(vtype=GRB.BINARY, name="month2_bulk_indicator")

    # Objective: maximize total profit
    # Profit = sum(selling revenue - purchasing cost - fixed ordering cost) - month 2 bulk fee
    revenue = gp.quicksum(selling_prices[m] * s[m] for m in months)
    purchase_cost = gp.quicksum(purchasing_prices[m] * x[m] for m in months)
    fixed_costs = gp.quicksum(fixed_ordering_cost * y[m] for m in months)
    bulk_fee = month2_bulk_receiving_fee * z2
    
    model.setObjective(revenue - purchase_cost - fixed_costs - bulk_fee, GRB.MAXIMIZE)

    # Constraints
    for m in months:
        # Inventory balance: inv[m] = inv[m-1] + x[m] - s[m]
        prev_inv = initial_stock if m == months[0] else inv[m-1]
        model.addConstr(inv[m] == prev_inv + x[m] - s[m], name=f"inventory_balance_{m}")

        # Warehouse capacity constraint: inventory after purchasing (before selling) <= warehouse_capacity
        model.addConstr(prev_inv + x[m] <= warehouse_capacity, name=f"capacity_after_purchase_{m}")

        # End-of-month inventory cannot exceed warehouse capacity (implied by above, but added for completeness)
        model.addConstr(inv[m] <= warehouse_capacity, name=f"capacity_end_of_month_{m}")

        # Fixed ordering cost activation
        # If x[m] > 0, then y[m] must be 1. Max purchase is limited by warehouse capacity.
        model.addConstr(x[m] <= warehouse_capacity * y[m], name=f"fixed_cost_activation_{m}")

    # Month 2 bulk receiving fee activation
    # If x[2] > month2_bulk_receiving_threshold, then z2 must be 1.
    # Month 2 is the second element in the months list (index 2 in our data)
    model.addConstr(x[2] <= month2_bulk_receiving_threshold + (warehouse_capacity - month2_bulk_receiving_threshold) * z2, name="month2_bulk_fee_activation")

    # Solve the model
    model.optimize()

    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimization was not optimal.")

if __name__ == "__main__":
    solve_optimization()
