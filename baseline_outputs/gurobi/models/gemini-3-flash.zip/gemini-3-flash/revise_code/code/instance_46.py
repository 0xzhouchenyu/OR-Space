import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    students = []
    with open(os.path.join(base, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            s = {'Student_ID': int(row['Student_ID']),
                 'Wage_CNY_per_hour': float(row['Wage_CNY_per_hour'])}
            for d in ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']:
                s[d] = float(row[d])
            students.append(s)
    
    params = {}
    with open(os.path.join(base, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = row['Value']
            try:
                params[name] = int(val)
            except ValueError:
                try:
                    params[name] = float(val)
                except ValueError:
                    params[name] = val
    
    return students, params

def main():
    students, params = load_data()
    
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    student_ids = [s['Student_ID'] for s in students]
    
    # 8:00 AM to 10:00 PM is 14 hours
    hours_per_day = 14
    
    # Parameters from CSV
    min_undergrad = params['min_undergrad_hours']
    min_grad = params['min_grad_hours']
    max_shifts = params['max_shifts_per_student']
    max_students_day = params['max_students_per_day']
    daily_open_fee = params['daily_open_fee_cny']
    min_grad_coverage = params['min_grad_weekly_coverage_hours']
    
    # Student classifications
    grad_students = [5, 6]
    undergrad_students = [1, 2, 3, 4]
    
    # Data dictionaries
    wage = {s['Student_ID']: s['Wage_CNY_per_hour'] for s in students}
    avail = {(s['Student_ID'], d): s[d] for s in students for d in days}
    
    # Optimization Model
    model = gp.Model("Lab_Scheduling")
    model.setParam('OutputFlag', 0)
    
    # Variables
    x = model.addVars(student_ids, days, lb=0, vtype=GRB.CONTINUOUS, name="x")
    y = model.addVars(student_ids, days, vtype=GRB.BINARY, name="y")
    
    # Objective: minimize total wages + fixed daily fees
    model.setObjective(
        gp.quicksum(wage[i] * x[i, d] + daily_open_fee * y[i, d] for i in student_ids for d in days),
        GRB.MINIMIZE
    )
    
    # Constraints
    
    # 1. Coverage: exactly 14 hours per day
    for d in days:
        model.addConstr(gp.quicksum(x[i, d] for i in student_ids) == hours_per_day)
    
    # 2. Availability and linking x and y
    for i in student_ids:
        for d in days:
            model.addConstr(x[i, d] <= avail[i, d] * y[i, d])
    
    # 3. Max shifts per student per week
    for i in student_ids:
        model.addConstr(gp.quicksum(y[i, d] for d in days) <= max_shifts)
    
    # 4. Max students per day
    for d in days:
        model.addConstr(gp.quicksum(y[i, d] for i in student_ids) <= max_students_day)
    
    # 5. Minimum weekly hours for each undergraduate
    for i in undergrad_students:
        model.addConstr(gp.quicksum(x[i, d] for d in days) >= min_undergrad)
        
    # 6. Minimum weekly hours for each graduate student
    for i in grad_students:
        model.addConstr(gp.quicksum(x[i, d] for d in days) >= min_grad)
        
    # 7. Minimum total weekly coverage by graduate students
    model.addConstr(gp.quicksum(x[i, d] for i in grad_students for d in days) >= min_grad_coverage)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
