import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from a CSV file into a dictionary."""
    params = {}
    if not os.path.exists(filepath):
        return params
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve_optimization():
    # File paths for data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_file = os.path.join(base_dir, "data", "general_parameters.csv")
    
    # Load parameters from the CSV
    params = load_general_parameters(data_file)
    
    # Initialize the Gurobi model
    model = gp.Model("Furniture_Factory_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables: Regular production quantities
    x_table_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="table_reg")
    x_chair_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="chair_reg")
    x_bookshelf_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="bookshelf_reg")
    
    # Decision Variables: Rush production quantities
    x_table_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="table_rush")
    x_chair_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="chair_rush")
    x_bookshelf_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="bookshelf_rush")
    
    # Profit calculation for each item type
    # Regular profits
    p_table_reg = params['sell_price_table'] - params['manufacturing_cost_table']
    p_chair_reg = params['sell_price_chair'] - params['manufacturing_cost_chair']
    p_bookshelf_reg = params['sell_price_bookshelf'] - params['manufacturing_cost_bookshelf']
    
    # Rush profits (Regular profit + bonus)
    p_table_rush = p_table_reg + params['rush_profit_bonus_table']
    p_chair_rush = p_chair_reg + params['rush_profit_bonus_chair']
    p_bookshelf_rush = p_bookshelf_reg + params['rush_profit_bonus_bookshelf']
    
    # Objective Function: Maximize total profit from regular and rush items
    model.setObjective(
        p_table_reg * x_table_reg + p_chair_reg * x_chair_reg + p_bookshelf_reg * x_bookshelf_reg +
        p_table_rush * x_table_rush + p_chair_rush * x_chair_rush + p_bookshelf_rush * x_bookshelf_rush,
        GRB.MAXIMIZE
    )
    
    # Constraints
    
    # 1. Shared Warehouse Space Constraint
    model.addConstr(
        params['warehouse_space_table'] * (x_table_reg + x_table_rush) +
        params['warehouse_space_chair'] * (x_chair_reg + x_chair_rush) +
        params['warehouse_space_bookshelf'] * (x_bookshelf_reg + x_bookshelf_rush) <= params['max_warehouse_space'],
        "Warehouse_Space"
    )
    
    # 2. Minimum production requirements for tables and bookshelves
    model.addConstr(x_table_reg + x_table_rush >= params['min_tables'], "Min_Tables")
    model.addConstr(x_bookshelf_reg + x_bookshelf_rush >= params['min_bookshelves'], "Min_Bookshelves")
    
    # 3. Maximum total items allowed for production
    model.addConstr(
        x_table_reg + x_table_rush + x_chair_reg + x_chair_rush + x_bookshelf_reg + x_bookshelf_rush <= params['max_total_items'],
        "Max_Total_Items"
    )
    
    # 4. Labor hours constraint for regular production
    model.addConstr(
        params['labor_hours_table'] * x_table_reg +
        params['labor_hours_chair'] * x_chair_reg +
        params['labor_hours_bookshelf'] * x_bookshelf_reg <= params['max_labor_hours_month_regular'],
        "Labor_Regular"
    )
    
    # 5. Labor hours constraint for rush production
    model.addConstr(
        params['labor_hours_table'] * x_table_rush +
        params['labor_hours_chair'] * x_chair_rush +
        params['labor_hours_bookshelf'] * x_bookshelf_rush <= params['max_labor_hours_month_rush'],
        "Labor_Rush"
    )
    
    # 6. Maximum total number of rush items
    model.addConstr(
        x_table_rush + x_chair_rush + x_bookshelf_rush <= params['max_rush_items_month'],
        "Max_Rush_Items"
    )
    
    # Solve the optimization model
    model.optimize()
    
    # Final Objective Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_optimization()
