import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_farm_optimization():
    # Load parameters from general_parameters.csv
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Create the optimization model
    model = gp.Model("FarmProfitMaximization")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # binary variable for expansion mode
    is_expanded = model.addVar(vtype=GRB.BINARY, name="is_expanded")
    
    # integer variables for regular mode
    c_r = model.addVar(vtype=GRB.INTEGER, name="cows_regular")
    s_r = model.addVar(vtype=GRB.INTEGER, name="sheep_regular")
    ch_r = model.addVar(vtype=GRB.INTEGER, name="chickens_regular")
    
    # integer variables for expanded (premium) mode
    c_e = model.addVar(vtype=GRB.INTEGER, name="cows_premium")
    s_e = model.addVar(vtype=GRB.INTEGER, name="sheep_premium")
    ch_e = model.addVar(vtype=GRB.INTEGER, name="chickens_premium")

    # Mode-specific constraints (forcing variables to 0 if their mode is not selected)
    # The Big M logic is built into these constraints by using the mode limits
    
    # Regular mode constraints
    model.addConstr(c_r + s_r + ch_r <= params['max_total_animals'] * (1 - is_expanded))
    model.addConstr(params['cow_manure_production'] * c_r + 
                    params['sheep_manure_production'] * s_r + 
                    params['chicken_manure_production'] * ch_r <= params['max_manure_capacity'] * (1 - is_expanded))
    model.addConstr(params['base_land_usage_cow'] * c_r + 
                    params['base_land_usage_sheep'] * s_r + 
                    params['base_land_usage_chicken'] * ch_r <= params['base_land_capacity'] * (1 - is_expanded))

    # Expanded (Premium) mode constraints
    # Capacity multipliers apply to the limits when expanded mode is active
    exp_total_limit = params['max_total_animals'] * params['premium_capacity_multiplier']
    exp_manure_limit = params['max_manure_capacity'] * params['premium_manure_multiplier']
    exp_land_limit = params['base_land_capacity'] + params['expansion_land_increase']
    
    model.addConstr(c_e + s_e + ch_e <= exp_total_limit * is_expanded)
    model.addConstr(params['cow_manure_production'] * c_e + 
                    params['sheep_manure_production'] * s_e + 
                    params['chicken_manure_production'] * ch_e <= exp_manure_limit * is_expanded)
    model.addConstr(params['base_land_usage_cow'] * c_e + 
                    params['base_land_usage_sheep'] * s_e + 
                    params['base_land_usage_chicken'] * ch_e <= exp_land_limit * is_expanded)

    # General constraints (must be met regardless of mode)
    model.addConstr(c_r + c_e >= params['min_cows'])
    model.addConstr(s_r + s_e >= params['min_sheep'])
    model.addConstr(ch_r + ch_e <= params['max_chickens'])

    # Objective function: Maximize profit
    # Revenue
    rev = (params['cow_selling_price'] * (c_r + c_e) + 
           params['sheep_selling_price'] * (s_r + s_e) + 
           params['chicken_selling_price'] * (ch_r + ch_e))
    
    # Feed costs (regular vs premium)
    feed_r = (params['cow_feed_cost'] * c_r + 
              params['sheep_feed_cost'] * s_r + 
              params['chicken_feed_cost'] * ch_r)
    
    feed_e = (params['cow_feed_cost'] * params['premium_feed_multiplier'] * c_e + 
              params['sheep_feed_cost'] * params['premium_feed_multiplier'] * s_e + 
              params['chicken_feed_cost'] * params['premium_feed_multiplier'] * ch_e)
    
    # Fixed expansion cost
    fixed_cost = params['expansion_cost'] * is_expanded

    model.setObjective(rev - feed_r - feed_e - fixed_cost, GRB.MAXIMIZE)

    # Solve the model
    model.optimize()

    # Output the result
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("Optimization was not successful.")

if __name__ == "__main__":
    solve_farm_optimization()
