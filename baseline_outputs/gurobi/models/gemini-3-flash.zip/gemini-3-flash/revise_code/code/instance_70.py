import gurobipy as gp
from gurobipy import GRB
import csv
import os

def solve():
    # Set data file paths relative to the current script location
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, 'data')
    dist_file = os.path.join(data_dir, 'table_1.csv')
    param_file = os.path.join(data_dir, 'general_parameters.csv')

    # Load general parameters into a dictionary
    params = {}
    if os.path.exists(param_file):
        with open(param_file, 'r') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header row
            for row in reader:
                if len(row) == 2:
                    params[row[0].strip()] = row[1].strip()

    # Load the distance matrix from CSV
    city_labels = []
    dist_matrix = []
    if os.path.exists(dist_file):
        with open(dist_file, 'r') as f:
            reader = csv.reader(f)
            header = next(reader)
            # Labels: ['1', '2', '3', '4', ...]
            city_labels = [h.strip() for h in header[1:]]
            for row in reader:
                # Store distance values (skipping the city name in first column)
                dist_matrix.append([float(x) for x in row[1:]])
    
    n = len(city_labels)
    # Map city labels to integer indices (0 to n-1)
    city_to_idx = {label: i for i, label in enumerate(city_labels)}

    # Initialize the Gurobi optimization model
    model = gp.Model("TSP_Revised")
    model.setParam('OutputFlag', 0)  # Suppress Gurobi log output

    # Decision variables: x[i,j] is 1 if leg i to j is traveled, 0 otherwise
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")
    # u[i] auxiliary variables for MTZ subtour elimination
    u = model.addVars(n, vtype=GRB.CONTINUOUS, lb=1, ub=n, name="u")

    # Objective Function: Minimize total distance + inspection costs
    # Base travel distance from the cost matrix
    base_dist = gp.quicksum(dist_matrix[i][j] * x[i, j] for i in range(n) for j in range(n))
    
    # Inspection stop cost (specific leg penalty)
    inspection_penalty = 0
    if ('inspection_arc_from' in params and 
        'inspection_arc_to' in params and 
        'inspection_stop_cost' in params):
        idx_from = city_to_idx[params['inspection_arc_from']]
        idx_to = city_to_idx[params['inspection_arc_to']]
        cost = float(params['inspection_stop_cost'])
        inspection_penalty = cost * x[idx_from, idx_to]
            
    model.setObjective(base_dist + inspection_penalty, GRB.MINIMIZE)

    # Constraint 1: Each city must be left exactly once
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(n) if i != j) == 1)
        # Cannot travel from a city to itself
        model.addConstr(x[i, i] == 0)

    # Constraint 2: Each city must be entered exactly once
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(n) if i != j) == 1)

    # Constraint 3: Subtour elimination (MTZ formulation)
    start_city = params.get('start_city', city_labels[0])
    start_idx = city_to_idx[start_city]
    other_cities = [i for i in range(n) if i != start_idx]
    for i in other_cities:
        for j in other_cities:
            if i != j:
                model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1)

    # Constraint 4: Fixed path sequence (Must end at end_city and return to start_city)
    if 'start_city' in params and 'end_city' in params:
        s_idx = city_to_idx[params['start_city']]
        e_idx = city_to_idx[params['end_city']]
        # Fix the return leg to the starting city from the specified end city
        model.addConstr(x[e_idx, s_idx] == 1)

    # Constraint 5: Leg prohibition (e.g., direct 1-to-3)
    if 'prohibited_from' in params and 'prohibited_to' in params:
        p_from = city_to_idx[params['prohibited_from']]
        p_to = city_to_idx[params['prohibited_to']]
        model.addConstr(x[p_from, p_to] == 0)

    # Solve the model
    model.optimize()

    # Print the final result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
