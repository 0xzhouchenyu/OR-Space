import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Get the directory of the current script
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Define file paths
    table1_path = os.path.join(current_dir, "data", "table_1.csv")
    gen_params_path = os.path.join(current_dir, "data", "general_parameters.csv")
    
    # Load demand data
    demand = {}
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        quarters = [int(h) for h in header[1:]]
        for row in reader:
            if not row:
                continue
            product = row[0].strip()
            for j, q in enumerate(quarters):
                demand[(product, q)] = int(row[j+1])
    
    # Load general parameters
    params = {}
    with open(gen_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'])
            params[name] = value
            
    products = ['I', 'II', 'III']
    
    # Extract specific parameters from the dictionary
    init_inv = params.get('initial_inventory', 0)
    end_inv_req = params.get('end_inventory_requirement', 0)
    hours_per_quarter = params.get('production_hours_per_quarter', 0)
    
    hours_per_unit = {
        'I': params.get('product_I_hours_per_unit', 0),
        'II': params.get('product_II_hours_per_unit', 0),
        'III': params.get('product_III_hours_per_unit', 0)
    }
    
    delay_penalty = {
        'I': params.get('delay_penalty_product_I', 0),
        'II': params.get('delay_penalty_product_II', 0),
        'III': params.get('delay_penalty_product_III', 0)
    }
    
    inventory_cost = params.get('inventory_cost_per_unit', 0)
    
    # Revised quarter-specific data
    normal_hours_cap_fraction = {q: params.get(f'normal_hours_cap_fraction_q{q}', 1.0) for q in quarters}
    peak_hours_cap = {q: params.get(f'peak_hours_cap_q{q}', 0) for q in quarters}
    peak_cost_per_hour = {q: params.get(f'peak_cost_per_hour_q{q}', 0) for q in quarters}

    # Gurobi optimization model
    model = gp.Model("ProductionSchedulingRevised")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    # x: units of each product produced in each quarter
    x = model.addVars(products, quarters, vtype=GRB.INTEGER, lb=0, name="x")
    # inv_pos: Surplus inventory at end of quarter
    inv_pos = model.addVars(products, quarters, lb=0, vtype=GRB.CONTINUOUS, name="inv_pos")
    # inv_neg: Delayed delivery (backlog) at end of quarter
    inv_neg = model.addVars(products, quarters, lb=0, vtype=GRB.CONTINUOUS, name="inv_neg")
    # normal_h: Normal production hours used in each quarter
    normal_h = model.addVars(quarters, lb=0, vtype=GRB.CONTINUOUS, name="normal_h")
    # peak_h: Peak production hours used in each quarter
    peak_h = model.addVars(quarters, lb=0, vtype=GRB.CONTINUOUS, name="peak_h")

    # Constraints
    # 1. Product I cannot be produced in Q2 (based on data packet value)
    if 'product_I_no_production_q2' in params:
        model.addConstr(x['I', 2] <= params['product_I_no_production_q2'], name="no_prod_I_Q2")
    
    # 2. Inventory balance and requirements
    for p in products:
        for t in quarters:
            # Net inventory balance equation
            prev_balance = init_inv if t == 1 else (inv_pos[p, t-1] - inv_neg[p, t-1])
            model.addConstr(inv_pos[p, t] - inv_neg[p, t] == prev_balance + x[p, t] - demand[(p, t)], name=f"bal_{p}_{t}")
            
        # 3. Required inventory at the end of the year (Q4)
        model.addConstr(inv_pos[p, 4] - inv_neg[p, 4] >= end_inv_req, name=f"end_req_{p}")
        
    # 4. Production hours split into normal and peak bands
    for t in quarters:
        total_hours_used = gp.quicksum(hours_per_unit[p] * x[p, t] for p in products)
        model.addConstr(total_hours_used == normal_h[t] + peak_h[t], name=f"hr_split_{t}")
        
        # Constraints on capacity for each band
        model.addConstr(normal_h[t] <= hours_per_quarter * normal_hours_cap_fraction[t], name=f"normal_cap_{t}")
        model.addConstr(peak_h[t] <= peak_hours_cap[t], name=f"peak_cap_{t}")

    # Objective Function: Minimize (inventory holding costs + delay penalties + peak hours costs)
    total_inventory_cost = gp.quicksum(inventory_cost * inv_pos[p, t] for p in products for t in quarters)
    total_delay_penalty = gp.quicksum(delay_penalty[p] * inv_neg[p, t] for p in products for t in quarters)
    total_peak_hour_cost = gp.quicksum(peak_cost_per_hour[t] * peak_h[t] for t in quarters)
    
    model.setObjective(total_inventory_cost + total_delay_penalty + total_peak_hour_cost, GRB.MINIMIZE)
    
    # Solve model
    model.optimize()
    
    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("OPTIMIZATION_FAILED")

if __name__ == "__main__":
    solve()
