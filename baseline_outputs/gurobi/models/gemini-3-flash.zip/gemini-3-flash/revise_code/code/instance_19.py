import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_parameters(file_path):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    if not os.path.exists(file_path):
        return params
    with open(file_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            try:
                if '.' in value_str:
                    value = float(value_str)
                else:
                    value = int(value_str)
            except ValueError:
                value = value_str
            params[name] = value
    return params

def solve_furniture_order():
    # File paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    # Load parameters
    params = load_parameters(params_path)
    
    # Extract values for readability
    cost_A = params['cost_per_chair_A']
    cost_B = params['cost_per_chair_B']
    cost_C = params['cost_per_chair_C']
    q_A = params['chairs_per_order_A']
    q_B = params['chairs_per_order_B']
    q_C = params['chairs_per_order_C']
    min_total = params['min_total_chairs']
    max_total = params['max_total_chairs']
    min_B_if_A = params['min_chairs_B_if_A']
    dep_B_C = params.get('dependency_B_C', 0)
    fee_A_reg = params['fixed_fee_A_regular']
    fee_A_exp = params['fixed_fee_A_express']
    fee_B_reg = params['fixed_fee_B_regular']
    fee_B_exp = params['fixed_fee_B_express']
    fee_C_reg = params['fixed_fee_C_regular']
    fee_C_exp = params['fixed_fee_C_express']
    budget = params['weekly_order_budget']

    # Initialize model
    model = gp.Model("FurnitureOrderOptimization")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # Number of orders from each manufacturer
    x_A = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_A")
    x_B = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_B")
    x_C = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_C")

    # Channel choice indicators (binary)
    y_A_reg = model.addVar(vtype=GRB.BINARY, name="y_A_regular")
    y_A_exp = model.addVar(vtype=GRB.BINARY, name="y_A_express")
    y_B_reg = model.addVar(vtype=GRB.BINARY, name="y_B_regular")
    y_B_exp = model.addVar(vtype=GRB.BINARY, name="y_B_express")
    y_C_reg = model.addVar(vtype=GRB.BINARY, name="y_C_regular")
    y_C_exp = model.addVar(vtype=GRB.BINARY, name="y_C_express")

    # Aggregate indicators for whether any channel is used per manufacturer
    z_A = y_A_reg + y_A_exp
    z_B = y_B_reg + y_B_exp
    z_C = y_C_reg + y_C_exp

    # Objective: Minimize total cost (variable chair costs + fixed fees)
    chair_cost = (cost_A * q_A * x_A) + (cost_B * q_B * x_B) + (cost_C * q_C * x_C)
    fixed_fees = (fee_A_reg * y_A_reg + fee_A_exp * y_A_exp +
                  fee_B_reg * y_B_reg + fee_B_exp * y_B_exp +
                  fee_C_reg * y_C_reg + fee_C_exp * y_C_exp)
    model.setObjective(chair_cost + fixed_fees, GRB.MINIMIZE)

    # Constraints
    # 1. Total chairs requirements
    model.addConstr(q_A * x_A + q_B * x_B + q_C * x_C >= min_total, "MinTotalChairs")
    model.addConstr(q_A * x_A + q_B * x_B + q_C * x_C <= max_total, "MaxTotalChairs")

    # 2. Linking orders to selected channels
    M = max_total + 1
    model.addConstr(x_A <= M * z_A, "LinkA_Upper")
    model.addConstr(x_A >= z_A, "LinkA_Lower")
    model.addConstr(x_B <= M * z_B, "LinkB_Upper")
    model.addConstr(x_B >= z_B, "LinkB_Lower")
    model.addConstr(x_C <= M * z_C, "LinkC_Upper")
    model.addConstr(x_C >= z_C, "LinkC_Lower")

    # 3. Channel selection constraints (at most one channel per manufacturer)
    model.addConstr(y_A_reg + y_A_exp <= 1, "OneChannelA")
    model.addConstr(y_B_reg + y_B_exp <= 1, "OneChannelB")
    model.addConstr(y_C_reg + y_C_exp <= 1, "OneChannelC")

    # 4. Weekly order budget (limit on total active manufacturer-channel pairs)
    model.addConstr(z_A + z_B + z_C <= budget, "WeeklyOrderBudget")

    # 5. Dependency: Minimum chairs from B if A is used
    model.addConstr(q_B * x_B >= min_B_if_A * z_A, "MinBIfA")

    # 6. Dependency: If B is used, C must be used
    if dep_B_C == 1:
        model.addConstr(z_B <= z_C, "DependencyBC")

    # Solve the problem
    model.optimize()

    # Final output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_furniture_order()
