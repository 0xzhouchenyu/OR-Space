import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Define file paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read shift requirements from table_1_2.csv
    shifts_data = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts_data.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    
    n = len(shifts_data)
    required = [s['required'] for s in shifts_data]
    
    # Read general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
            
    shift_duration = int(params['shift_duration'])
    max_night_driver_fraction = params['max_night_driver_fraction']
    max_night_crew_fraction = params['max_night_crew_fraction']
    max_overtime_shifts = int(params['max_overtime_shifts'])
    overtime_cost_factor = params['overtime_cost_factor']
    
    # Each time period is 4 hours, shift_duration is 8 hours = 2 periods
    periods_per_shift = shift_duration // 4
    
    # Initialize Gurobi model
    model = gp.Model("WorkforcePlanning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: 
    # d[i] = regular drivers starting at period i
    # c[i] = regular crew starting at period i
    # od[i] = overtime drivers starting at period i
    # oc[i] = overtime crew starting at period i
    d = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="d")
    c = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="c")
    od = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="od")
    oc = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="oc")
    
    # Objective: minimize total cost (regular + overtime_cost_factor * overtime)
    model.setObjective(
        gp.quicksum(d[i] + c[i] for i in range(n)) + 
        overtime_cost_factor * gp.quicksum(od[i] + oc[i] for i in range(n)),
        GRB.MINIMIZE
    )
    
    # Constraints:
    # 1. Coverage for each period j (Drivers and Crew independently)
    for j in range(n):
        # A worker starting at period i covers periods i and (i+1)%n
        # So period j is covered by workers starting at (j-1)%n and j
        model.addConstr(d[j] + d[(j-1)%n] + od[j] + od[(j-1)%n] >= required[j], name=f"Driver_Coverage_{j}")
        model.addConstr(c[j] + c[(j-1)%n] + oc[j] + oc[(j-1)%n] >= required[j], name=f"Crew_Coverage_{j}")
        
    # 2. Late-night fraction constraints (Periods 5 and 6 are late-night)
    # Indices for periods 5 and 6 are 4 and 5 (0-indexed)
    total_driver_starts = gp.quicksum(d[i] + od[i] for i in range(n))
    night_driver_starts = d[4] + od[4] + d[5] + od[5]
    model.addConstr(night_driver_starts <= max_night_driver_fraction * total_driver_starts, name="Driver_Night_Fraction")
    
    total_crew_starts = gp.quicksum(c[i] + oc[i] for i in range(n))
    night_crew_starts = c[4] + oc[4] + c[5] + oc[5]
    model.addConstr(night_crew_starts <= max_night_crew_fraction * total_crew_starts, name="Crew_Night_Fraction")
    
    # 3. Maximum total overtime shifts
    model.addConstr(gp.quicksum(od[i] + oc[i] for i in range(n)) <= max_overtime_shifts, name="Max_Overtime")
    
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
