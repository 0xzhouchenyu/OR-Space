import gurobipy as gp
from gurobipy import GRB
import os
import csv
from itertools import product

def solve():
    # Set base directory for data access as the script's root directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load general parameters from the revised CSV file
    params = {}
    params_path = os.path.join(base_dir, 'data', 'general_parameters.csv')
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Load reliability data from the table_1.csv file
    # Format: reliability[number_of_spares] = [R1, R2, R3]
    reliability = {}
    reliability_path = os.path.join(base_dir, 'data', 'table_1.csv')
    with open(reliability_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            n = int(row['Number_of_Spares'])
            r1 = float(row['Component_1_Reliability'])
            r2 = float(row['Component_2_Reliability'])
            r3 = float(row['Component_3_Reliability'])
            reliability[n] = [r1, r2, r3]
            
    # Unit price and weight vectors for component 1, 2, and 3
    prices = [
        params['unit_price_component_1'], 
        params['unit_price_component_2'], 
        params['unit_price_component_3']
    ]
    weights = [
        params['unit_weight_component_1'], 
        params['unit_weight_component_2'], 
        params['unit_weight_component_3']
    ]
    
    # Pre-calculating the effective logistics limits for Scenario A and B
    # Since one package must serve both missions, it must fit within the minimum of both missions' limits.
    max_budget = min(params['total_budget_scenario_A'], params['total_budget_scenario_B'])
    max_weight = min(params['weight_limit_scenario_A'], params['weight_limit_scenario_B'])
    
    # Initialize the Gurobi optimization model
    model = gp.Model("SparePartsExpectedReliability")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Valid choices for spare counts: s_i is an integer from {0, 1, 2, 3, 4, 5}
    n_options = range(6)
    
    # Define decision variables: binary variable z[s1, s2, s3] equals 1 if 
    # component 1 has s1 spares, component 2 has s2, and component 3 has s3.
    z = model.addVars(n_options, n_options, n_options, vtype=GRB.BINARY, name="z")
    
    # Constraint: Choose exactly one spare-part configuration (s1, s2, s3)
    model.addConstr(z.sum() == 1, name="OneConfigurationOnly")
    
    # Cost constraint: total spare-part cost must be <= effective budget limit
    model.addConstr(
        gp.quicksum(z[s1, s2, s3] * (s1 * prices[0] + s2 * prices[1] + s3 * prices[2])
                    for s1, s2, s3 in product(n_options, repeat=3)) <= max_budget, 
        name="JointBudgetConstraint"
    )
    
    # Weight constraint: total spare-part weight must be <= effective weight limit
    model.addConstr(
        gp.quicksum(z[s1, s2, s3] * (s1 * weights[0] + s2 * weights[1] + s3 * weights[2])
                    for s1, s2, s3 in product(n_options, repeat=3)) <= max_weight, 
        name="JointWeightConstraint"
    )
    
    # Objective: Maximize expected system reliability.
    # ExpectedReliability = 0.5 * SysRel_A + 0.5 * SysRel_B
    # Since the configuration and the reliability table are mission-independent:
    # SysRel_A = SysRel_B = R1(s1) * R2(s2) * R3(s3)
    # ExpectedReliability = 0.5 * (R1*R2*R3) + 0.5 * (R1*R2*R3) = R1(s1) * R2(s2) * R3(s3)
    model.setObjective(
        gp.quicksum(z[s1, s2, s3] * reliability[s1][0] * reliability[s2][1] * reliability[s3][2]
                    for s1, s2, s3 in product(n_options, repeat=3)),
        GRB.MAXIMIZE
    )
    
    # Solve the optimization problem
    model.optimize()
    
    # Output the optimal objective value exactly as requested
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
