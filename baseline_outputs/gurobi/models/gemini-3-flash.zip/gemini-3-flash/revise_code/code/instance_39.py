import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Helper function to load general parameters from the provided CSV file
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            try:
                # Most values are numeric, some might be ratios
                value = float(row['Value'].strip())
            except ValueError:
                value = row['Value'].strip()
            params[name] = value
    return params

def solve():
    # Identify the correct data file path
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_file = os.path.join(script_dir, "data", "general_parameters.csv")
    
    # Load parameters from CSV
    params = load_general_parameters(data_file)
    
    # Define problem sets
    methods = ['motorcycle', 'small_truck', 'large_truck']
    periods = ['peak', 'offpeak']
    
    # Extract constants for clarity
    pollution_per_trip = {
        'motorcycle': params['motorcycle_pollution'],
        'small_truck': params['small_truck_pollution'],
        'large_truck': params['large_truck_pollution']
    }
    capacity_per_trip = {
        'motorcycle': params['motorcycle_capacity'],
        'small_truck': params['small_truck_capacity'],
        'large_truck': params['large_truck_capacity']
    }
    
    # Create the optimization model
    model = gp.Model("Transport_Pollution_Minimization")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    # x[m, p]: number of trips for method m in period p (Integer)
    x = model.addVars(methods, periods, vtype=GRB.INTEGER, lb=0, name="trips")
    # y[m]: binary indicator if method m is chosen for the day
    y = model.addVars(methods, vtype=GRB.BINARY, name="method_active")
    # l[p]: units of leased capacity in period p (Continuous)
    l = model.addVars(periods, vtype=GRB.CONTINUOUS, lb=0, name="leased_units")
    # z: binary indicator if any leasing is used during the day
    z = model.addVar(vtype=GRB.BINARY, name="leasing_used")
    
    # Objective Function: Minimize total pollution
    owned_pollution = gp.quicksum(x[m, p] * pollution_per_trip[m] for m in methods for p in periods)
    leased_pollution = gp.quicksum(l[p] * params['leasing_pollution_per_unit'] for p in periods) + z * params['leasing_fixed_pollution']
    model.setObjective(owned_pollution + leased_pollution, GRB.MINIMIZE)
    
    # Constraints
    # 1. Choose at most two out of the three owned transportation methods globally
    model.addConstr(gp.quicksum(y[m] for m in methods) <= 2, name="two_methods_constraint")
    
    # 2. Link method usage to trip count (If method is not chosen, trips must be zero)
    # The total number of trips is bounded by max_total_trips (20), which serves as a valid Big-M.
    for m in methods:
        model.addConstr(gp.quicksum(x[m, p] for p in periods) <= params['max_total_trips'] * y[m], name=f"activate_{m}")
        
    # 3. Road restrictions on motorcycle trips (maximum 8 trips over the day)
    model.addConstr(gp.quicksum(x['motorcycle', p] for p in periods) <= params['max_motorcycle_trips'], name="motorcycle_limit")
    
    # 4. Global restriction on the total number of trips (all methods, all periods)
    model.addConstr(gp.quicksum(x[m, p] for m in methods for p in periods) <= params['max_total_trips'], name="total_trips_limit")
    
    # 5. Demand fulfillment for peak period
    model.addConstr(gp.quicksum(x[m, 'peak'] * capacity_per_trip[m] for m in methods) + l['peak'] >= params['demand_peak_units'], name="peak_demand")
    
    # 6. Demand fulfillment for off-peak period
    model.addConstr(gp.quicksum(x[m, 'offpeak'] * capacity_per_trip[m] for m in methods) + l['offpeak'] >= params['demand_offpeak_units'], name="offpeak_demand")
    
    # 7. Leasing peak window restriction (leasing can only cover a fraction of peak demand)
    model.addConstr(l['peak'] <= params['max_leasing_fraction_peak'] * params['demand_peak_units'], name="peak_leasing_limit")
    
    # 8. Day-wide leasing capacity limit
    model.addConstr(gp.quicksum(l[p] for p in periods) <= params['leasing_capacity'], name="total_leasing_limit")
    
    # 9. Leasing activation logic (Linking l to binary z)
    # Using the provided bigM_leasing and epsilon parameters
    model.addConstr(gp.quicksum(l[p] for p in periods) <= params['bigM_leasing'] * z, name="leasing_gate_upper")
    model.addConstr(gp.quicksum(l[p] for p in periods) >= params['epsilon'] * z, name="leasing_gate_lower")
    
    # Optimize the model
    model.optimize()
    
    # Print the objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
