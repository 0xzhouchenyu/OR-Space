import pandas as pd
import gurobipy as gp
from gurobipy import GRB
import os

def solve():
    # Define data paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_path = os.path.join(data_dir, "table_3_3.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    
    # Load data
    df = pd.read_csv(table_path)
    params_df = pd.read_csv(params_path)
    
    # Extract parameters
    sales_goal = float(params_df.loc[params_df['Parameter_Name'] == 'monthly_sales_goal', 'Value'].values[0])
    pt_ft_ratio = float(params_df.loc[params_df['Parameter_Name'] == 'pt_ft_overtime_ratio', 'Value'].values[0])
    
    # Extract clerk data
    ft_row = df[df['Role'] == 'Full-time'].iloc[0]
    pt_row = df[df['Role'] == 'Part-time'].iloc[0]
    
    # Determine number of clerks (default to 5 FT and 4 PT if not in CSV)
    num_ft = 5
    num_pt = 4
    for col in df.columns:
        if any(kw in col.lower() for kw in ['num', 'clerks', 'employees', 'count', '人员', '数量']):
            num_ft = float(ft_row[col])
            num_pt = float(pt_row[col])
            break
            
    # Calculate normal sales from full employment of all sales clerks
    ft_sales_per_hour = float(ft_row['Sales_Volume_Pairs_Per_Hour'])
    pt_sales_per_hour = float(pt_row['Sales_Volume_Pairs_Per_Hour'])
    ft_hours_per_month = float(ft_row['Monthly_Working_Hours'])
    pt_hours_per_month = float(pt_row['Monthly_Working_Hours'])
    
    normal_sales_ft = num_ft * ft_hours_per_month * ft_sales_per_hour
    normal_sales_pt = num_pt * pt_hours_per_month * pt_sales_per_hour
    total_normal_sales = normal_sales_ft + normal_sales_pt
    
    # Shortfall to be covered by overtime
    overtime_needed_sales = sales_goal - total_normal_sales
    
    # Setup Gurobi Model
    model = gp.Model("Minimize_Overtime")
    model.setParam('OutputFlag', 0)
    
    # Variables for total overtime hours assigned to each group
    y_ft = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="y_ft")
    y_pt = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="y_pt")
    
    # Objective: Minimize total overtime hours
    model.setObjective(y_ft + y_pt, GRB.MINIMIZE)
    
    # Constraint: Achieve monthly sales goal
    model.addConstr(y_ft * ft_sales_per_hour + y_pt * pt_sales_per_hour >= overtime_needed_sales, "Sales_Goal")
    
    # Constraint: Part-time overtime hours must be at least 50% of full-time overtime hours
    model.addConstr(y_pt >= pt_ft_ratio * y_ft, "Coverage_Ratio")
    
    # Solve
    model.optimize()
    
    # Output the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == '__main__':
    solve()
