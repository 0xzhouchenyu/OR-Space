import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_fertilizer_optimization():
    # Data file paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Load general parameters
    params = {}
    if os.path.exists(params_path):
        with open(params_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                name = row['Parameter_Name'].strip()
                value = float(row['Value'].strip())
                params[name] = value

    # Extract parameters
    m1_liquid_time = params.get('machine_1_time_per_liquid_lot', 50)
    m2_liquid_time = params.get('machine_2_time_per_liquid_lot', 30)
    m1_solid_time = params.get('machine_1_time_per_solid_lot', 24)
    m2_solid_time = params.get('machine_2_time_per_solid_lot', 33)
    
    init_liquid = params.get('initial_liquid_inventory', 30)
    init_solid = params.get('initial_solid_inventory', 90)
    
    m1_base_avail = params.get('machine_1_available_time', 40) * 60  # Convert hours to minutes
    m2_base_avail = params.get('machine_2_available_time', 35) * 60  # Convert hours to minutes
    
    demand_liquid = params.get('forecast_liquid_demand', 75)
    demand_solid = params.get('forecast_solid_demand', 95)
    
    ext_extra_min = params.get('extended_extra_minutes', 600)
    labor_per_ext = params.get('labor_hours_per_machine_extended', 8)
    labor_budget = params.get('labor_budget_hours', 10)
    ext_penalty = params.get('extended_mode_penalty', 0.5)
    
    prio_lots = params.get('priority_reserve_lots', 10)
    exce_credit = params.get('excess_reserve_credit', 0.35)

    # Initialize Gurobi Model
    model = gp.Model("Fertilizer_Production_Resilience")
    model.setParam('OutputFlag', 0)

    # Decision Variables
    # Production lots
    x_l = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="x_liquid")
    x_s = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="x_solid")
    
    # Extended mode binary variables
    ext_1 = model.addVar(vtype=GRB.BINARY, name="ext_1")
    ext_2 = model.addVar(vtype=GRB.BINARY, name="ext_2")
    
    # Ending inventory and bands
    end_l = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="end_liquid")
    end_s = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="end_solid")
    
    prio_l = model.addVar(lb=0, ub=prio_lots, vtype=GRB.CONTINUOUS, name="prio_liquid")
    exce_l = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="exce_liquid")
    
    prio_s = model.addVar(lb=0, ub=prio_lots, vtype=GRB.CONTINUOUS, name="prio_solid")
    exce_s = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="exce_solid")

    # Constraints
    # Ending inventory calculation
    model.addConstr(end_l == init_liquid + x_l - demand_l, "Liquid_Inventory_Balance")
    model.addConstr(end_s == init_solid + x_s - demand_s, "Solid_Inventory_Balance")
    
    # Inventory bands
    model.addConstr(prio_l + exce_l == end_l, "Liquid_Inventory_Bands")
    model.addConstr(prio_s + exce_s == end_s, "Solid_Inventory_Bands")
    
    # Machine capacity constraints
    model.addConstr(m1_liquid_time * x_l + m1_solid_time * x_s <= m1_base_avail + ext_extra_min * ext_1, "Machine_1_Capacity")
    model.addConstr(m2_liquid_time * x_l + m2_solid_time * x_s <= m2_base_avail + ext_extra_min * ext_2, "Machine_2_Capacity")
    
    # Labor budget for extended mode
    model.addConstr(labor_per_ext * (ext_1 + ext_2) <= labor_budget, "Labor_Budget")

    # Objective Function: Maximize Resilience Score
    # Score = (prio_l + exce_credit * exce_l) + (prio_s + exce_credit * exce_s) - ext_penalty * (ext_1 + ext_2)
    model.setObjective(
        prio_l + exce_credit * exce_l + prio_s + exce_credit * exce_s - ext_penalty * (ext_1 + ext_2),
        GRB.MAXIMIZE
    )

    # Solve the model
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimization was not optimal.")

if __name__ == "__main__":
    solve_fertilizer_optimization()
