import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    """Load a CSV file and return headers and rows."""
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = [row for row in reader if row]
    return headers, rows

def load_general_parameters():
    """Load general parameters into a dictionary."""
    _, rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row[0].strip()
        try:
            value = float(row[1].strip())
        except ValueError:
            value = row[1].strip()
        params[name] = value
    return params

def load_crop_data():
    """Load crop data from table_1.csv."""
    headers, rows = load_csv('table_1.csv')
    crops = [h.strip() for h in headers[1:]]
    data = {}
    for row in rows:
        item = row[0].strip()
        values = [float(v.strip()) for v in row[1:]]
        data[item] = dict(zip(crops, values))
    return crops, data

def main():
    # Load data
    params = load_general_parameters()
    crops, crop_data = load_crop_data()
    
    # Extract parameters
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']
    
    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = params['max_chickens']
    max_dairy_cows = params['max_dairy_cows']
    
    # Revised biosecurity/chicken parameters
    fixed_cost_chicken_setup = params['fixed_cost_chicken_setup']
    min_chickens_if_coop_open = params['min_chickens_if_coop_open']
    second_biosecurity_threshold = params['second_biosecurity_threshold']
    second_biosecurity_cost = params['second_biosecurity_cost']
    biosecurity_training_aw_days = params['biosecurity_training_aw_days']
    biosecurity_training_ss_days = params['biosecurity_training_ss_days']
    
    # Crop data dictionaries
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']
    
    # Create Gurobi model
    model = gp.Model("Farm_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Crop areas (hectares)
    x = model.addVars(crops, lb=0, name="x")
    
    # Animal counts (treated as continuous based on original implementation context)
    y_dairy = model.addVar(lb=0, ub=max_dairy_cows, name="y_dairy")
    y_chicken = model.addVar(lb=0, ub=max_chickens, name="y_chicken")
    
    # Surplus labor for external work (person-days)
    surplus_aw = model.addVar(lb=0, name="surplus_aw")
    surplus_ss = model.addVar(lb=0, name="surplus_ss")
    
    # Binary variables for biosecurity/coop gates
    is_coop_open = model.addVar(vtype=GRB.BINARY, name="is_coop_open")
    is_large_flock = model.addVar(vtype=GRB.BINARY, name="is_large_flock")
    
    # Objective Function: Maximize annual net income
    # Income = Crop profits + Dairy profits + Chicken profits + External work earnings - Fixed Biosecurity costs
    total_crop_income = gp.quicksum(crop_income[c] * x[c] for c in crops)
    total_dairy_income = income_dairy * y_dairy
    total_chicken_income = income_chicken * y_chicken
    total_external_income = ext_rate_aw * surplus_aw + ext_rate_ss * surplus_ss
    total_fixed_costs = (fixed_cost_chicken_setup * is_coop_open) + (second_biosecurity_cost * is_large_flock)
    
    model.setObjective(total_crop_income + total_dairy_income + total_chicken_income + total_external_income - total_fixed_costs, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Land constraint
    model.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, "Land")
    
    # 2. Funds constraint (Investment per unit vs available funds)
    model.addConstr(inv_dairy * y_dairy + inv_chicken * y_chicken <= funds_available, "Funds")
    
    # 3. Labor Autumn/Winter balance
    # Training days are consumed if the coop is open at all
    model.addConstr(gp.quicksum(crop_aw[c] * x[c] for c in crops) + \
                    labor_aw_dairy * y_dairy + \
                    labor_aw_chicken * y_chicken + \
                    biosecurity_training_aw_days * is_coop_open + \
                    surplus_aw <= labor_aw, "Labor_AW")
    
    # 4. Labor Spring/Summer balance
    model.addConstr(gp.quicksum(crop_ss[c] * x[c] for c in crops) + \
                    labor_ss_dairy * y_dairy + \
                    labor_ss_chicken * y_chicken + \
                    biosecurity_training_ss_days * is_coop_open + \
                    surplus_ss <= labor_ss, "Labor_SS")
    
    # 5. Chicken Coop Opening Gating
    # Coop must be open to raise chickens, and raising chickens requires a minimum flock
    model.addConstr(y_chicken <= max_chickens * is_coop_open, "Chicken_Max_Gate")
    model.addConstr(y_chicken >= min_chickens_if_coop_open * is_coop_open, "Chicken_Min_Gate")
    
    # 6. Second Biosecurity Gating
    # Crossing the second review level (threshold) triggers the additional bill
    model.addConstr(y_chicken <= second_biosecurity_threshold + (max_chickens - second_biosecurity_threshold) * is_large_flock, "Second_Bio_Gate")
    
    # Solve
    model.optimize()
    
    # Output results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
