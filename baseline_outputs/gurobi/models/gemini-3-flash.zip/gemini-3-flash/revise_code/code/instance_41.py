import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_investment_problem():
    # Define data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    # Load general parameters
    initial_capital = 0.0
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'].strip() == 'initial_capital':
                initial_capital = float(row['Value'].strip())

    # Load liquidity policy
    min_year3_reserve = 0.0
    reserve_shortfall_penalty = 0.0
    with open(os.path.join(data_dir, 'liquidity_policy.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'].strip() == 'min_year3_reserve':
                min_year3_reserve = float(row['Value'].strip())
            if row['Parameter_Name'].strip() == 'reserve_shortfall_penalty':
                reserve_shortfall_penalty = float(row['Value'].strip())

    # Load project data
    projects = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            pid = int(row['Project_ID'])
            projects[pid] = {
                'rate': float(row['Interest_Rate']),
                'capacity': row['Investment_Capacity']
            }

    def get_cap(cap_str):
        if cap_str.strip().lower() == 'unlimited':
            return GRB.INFINITY
        return float(cap_str.replace(',', ''))

    rate1 = projects[1]['rate']
    rate2 = projects[2]['rate']
    rate3 = projects[3]['rate']
    rate4 = projects[4]['rate']
    cap2 = get_cap(projects[2]['capacity'])
    cap3 = get_cap(projects[3]['capacity'])
    cap4 = get_cap(projects[4]['capacity'])

    # Create Gurobi model
    model = gp.Model("Investment_Maximization")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x1_t: amount invested in Project 1 at beginning of Year t
    x1_1 = model.addVar(lb=0, name="x1_1")
    x1_2 = model.addVar(lb=0, name="x1_2")
    x1_3 = model.addVar(lb=0, name="x1_3")
    # x2, x3, x4: investments in Projects 2, 3, 4
    x2 = model.addVar(lb=0, ub=cap2, name="x2")
    x3 = model.addVar(lb=0, ub=cap3, name="x3")
    x4 = model.addVar(lb=0, ub=cap4, name="x4")
    # c_t: cash carried over from Year t to Year t+1
    c1 = model.addVar(lb=0, name="c1")
    c2 = model.addVar(lb=0, name="c2")
    # R: liquidity cushion held at beginning of Year 3
    R = model.addVar(lb=0, name="R")
    # S: shortfall in the required reserve
    S = model.addVar(lb=0, name="S")

    # Constraints
    # Year 1 budget: initial capital used for x1_1, x2, or carried over
    model.addConstr(x1_1 + x2 + c1 == initial_capital, "Year1_Budget")

    # Year 2 budget: proceeds from x1_1 and carried cash c1 used for x1_2, x3, or carried over
    model.addConstr(x1_2 + x3 + c2 == rate1 * x1_1 + c1, "Year2_Budget")

    # Year 3 budget: proceeds from x1_2, x2, x3 and carried cash c2 used for x1_3, x4, or held as reserve R
    model.addConstr(x1_3 + x4 + R == rate1 * x1_2 + rate2 * x2 + rate3 * x3 + c2, "Year3_Budget")

    # Shortfall calculation
    model.addConstr(S >= min_year3_reserve - R, "Shortfall_Constraint")

    # Objective: Maximize terminal wealth at end of Year 3 minus shortfall penalty
    # Terminal wealth = proceeds from Year 3 investments (x1_3, x4) + uninvested cash R
    terminal_wealth = rate1 * x1_3 + rate4 * x4 + R
    penalty = reserve_shortfall_penalty * S
    model.setObjective(terminal_wealth - penalty, GRB.MAXIMIZE)

    # Solve
    model.optimize()

    # Output result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_investment_problem()
