import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Define data directory and file paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    general_params_path = os.path.join(data_dir, 'general_parameters.csv')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    
    # Read general parameters
    params = {}
    with open(general_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
            
    full_time_cost = float(params['full_time_cost'])
    part_time_cost = float(params['part_time_cost'])
    part_time_cap = int(params['part_time_cap_per_period'])
    min_full_time = int(params['min_full_time_per_period'])
    
    # Map time periods to indices 0-5
    period_map = {
        '2:00-6:00': 0,
        '6:00-10:00': 1,
        '10:00-14:00': 2,
        '14:00-18:00': 3,
        '18:00-22:00': 4,
        '22:00-2:00': 5
    }
    
    # Read staffing requirements
    req_values = [0] * 6
    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row['Time_Period'].strip()
            req = int(row['Required_Salespeople'].strip())
            if period in period_map:
                req_values[period_map[period]] = req
                
    # Initialize Gurobi model
    model = gp.Model("ConvenienceStoreStaffing")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i]: Number of full-time staff starting at the beginning of period i
    # y[j]: Number of part-time staff working in period j
    x = model.addVars(6, vtype=GRB.INTEGER, lb=0, name="x")
    y = model.addVars(6, vtype=GRB.INTEGER, lb=0, name="y")
    
    # Objective: Minimize total daily labor cost
    model.setObjective(
        gp.quicksum(x[i] * full_time_cost for i in range(6)) +
        gp.quicksum(y[j] * part_time_cost for j in range(6)),
        GRB.MINIMIZE
    )
    
    # Constraints
    for j in range(6):
        # Full-time staff present in period j are those who started in period j and period (j-1) mod 6
        ft_present = x[j] + x[(j - 1) % 6]
        
        # 1. Total staffing requirement (FT + PT)
        model.addConstr(ft_present + y[j] >= req_values[j], name=f"total_req_{j}")
        
        # 2. Minimum full-time staff per period
        model.addConstr(ft_present >= min_full_time, name=f"min_ft_{j}")
        
        # 3. Maximum part-time staff per period
        model.addConstr(y[j] <= part_time_cap, name=f"max_pt_{j}")
        
    # Solve the optimization problem
    model.optimize()
    
    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimal solution not found.")

if __name__ == "__main__":
    main()
