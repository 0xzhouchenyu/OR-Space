import gurobipy as gp
from gurobipy import GRB
import csv
import os

def solve():
    # Data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    # Load car data
    cars = {}
    car_data_path = os.path.join(data_dir, 'table_1.csv')
    if not os.path.exists(car_data_path):
        return
    with open(car_data_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cars[int(row['i'])] = float(row['lambda_i'])

    # Load parameters
    params = {}
    param_data_path = os.path.join(data_dir, 'general_parameters.csv')
    if not os.path.exists(param_data_path):
        return
    with open(param_data_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    max_length_one_side = params['max_length_one_side']
    available_party_side_count = int(params['available_party_side_count'])
    num_cars = int(params['num_cars'])

    # Model
    model = gp.Model("ParkingMinStreetLengthRevised")
    model.setParam('OutputFlag', 0)

    # Sides (assuming 2 sides based on the original problem context)
    sides = [1, 2]
    car_ids = list(cars.keys())

    # Decision Variables
    # x[i, s] = 1 if car i is parked on side s, 0 otherwise
    x = model.addVars(car_ids, sides, vtype=GRB.BINARY, name="x")
    # y[s] = 1 if side s is used for party cars, 0 otherwise
    y = model.addVars(sides, vtype=GRB.BINARY, name="y")
    # T = maximum length occupied on any side of the street
    T = model.addVar(lb=0, name="T")

    # Constraints
    # 1. Each car must be parked on exactly one side
    for i in car_ids:
        model.addConstr(gp.quicksum(x[i, s] for s in sides) == 1, name=f"park_car_{i}")

    # 2. If a car is on side s, that side must be marked as used
    for i in car_ids:
        for s in sides:
            model.addConstr(x[i, s] <= y[s], name=f"side_usage_{i}_{s}")

    # 3. The number of sides used cannot exceed the available_party_side_count
    model.addConstr(gp.quicksum(y[s] for s in sides) <= available_party_side_count, name="max_sides")

    # 4. The total length of cars on each side must respect the max_length_one_side limit
    for s in sides:
        model.addConstr(gp.quicksum(cars[i] * x[i, s] for i in car_ids) <= max_length_one_side * y[s], name=f"max_length_side_{s}")

    # 5. T must be greater than or equal to the total length occupied on each side
    for s in sides:
        model.addConstr(T >= gp.quicksum(cars[i] * x[i, s] for i in car_ids), name=f"obj_helper_side_{s}")

    # Objective: Minimize the maximum length occupied on any side
    model.setObjective(T, GRB.MINIMIZE)

    # Solve the optimization problem
    model.optimize()

    # Output the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
