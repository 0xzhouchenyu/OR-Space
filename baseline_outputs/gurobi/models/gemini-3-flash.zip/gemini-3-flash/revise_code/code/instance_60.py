import os
import csv
import re
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define data directory path based on standard layout
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Initial default parameters
    num_locations = 7
    max_route_length_day = 1000.0
    route_cost_day = 20.0
    
    # Read general parameters from CSV
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    if os.path.exists(params_path):
        with open(params_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                param_name = row['Parameter_Name']
                if param_name == 'num_customers':
                    num_locations = int(row['Value'])
                elif param_name == 'max_route_length_day':
                    max_route_length_day = float(row['Value'])
                elif param_name == 'route_cost_day':
                    route_cost_day = float(row['Value'])

    # Read symmetric distance matrix from table_1.csv
    # Depot is Location 1 (Index 0), Customers are 2-7 (Indices 1-6)
    D = [[0.0] * num_locations for _ in range(num_locations)]
    table_path = os.path.join(data_dir, 'table_1.csv')
    if os.path.exists(table_path):
        with open(table_path, 'r') as f:
            lines = f.readlines()
            for line in lines[1:]:
                # Use regex to find all integers in each row
                nums = re.findall(r'\d+', line)
                if not nums:
                    continue
                # The first number in a data row is the location index
                row_idx = int(nums[0]) - 1
                # Remaining numbers are the upper triangular distances
                for j, val in enumerate(nums[1:]):
                    col_idx = row_idx + 1 + j
                    if col_idx < num_locations:
                        dist = float(val)
                        D[row_idx][col_idx] = dist
                        D[col_idx][row_idx] = dist

    # Create Gurobi optimization model
    model = gp.Model("TSP_TwoDays")
    model.setParam('OutputFlag', 0)
    
    # Days are consecutive (Day 1, Day 2)
    days = [0, 1]
    # Indices 1 to num_locations-1 are customers
    customers = list(range(1, num_locations))
    # All nodes including depot (Index 0)
    nodes = list(range(num_locations))
    
    # Decision Variables
    # x[i, j, d] is 1 if traveling from node i to j on day d
    x = model.addVars(nodes, nodes, days, vtype=GRB.BINARY, name="x")
    # y[i, d] is 1 if customer i is visited on day d
    y = model.addVars(customers, days, vtype=GRB.BINARY, name="y")
    # z[d] is 1 if day d is active (used for a route)
    z = model.addVars(days, vtype=GRB.BINARY, name="z")
    # u[i, d] are MTZ variables for subtour elimination on each day
    u = model.addVars(customers, days, lb=1.0, ub=float(num_locations - 1), name="u")
    
    # Objective: Minimize (total distance traveled across both days) + (fixed setup costs per active day)
    total_distance = gp.quicksum(D[i][j] * x[i, j, d] for i in nodes for j in nodes for d in days if i != j)
    total_setup_cost = gp.quicksum(route_cost_day * z[d] for d in days)
    model.setObjective(total_distance + total_setup_cost, GRB.MINIMIZE)
    
    # Constraints
    # 1. Every customer must be visited exactly once across the two-day planning horizon
    for i in customers:
        model.addConstr(gp.quicksum(y[i, d] for d in days) == 1, name=f"visit_once_{i}")
        
    for d in days:
        # 2. Flow balance for customers: visit in must equal visit out
        for i in customers:
            model.addConstr(gp.quicksum(x[i, j, d] for j in nodes if i != j) == y[i, d], name=f"out_flow_{i}_{d}")
            model.addConstr(gp.quicksum(x[j, i, d] for j in nodes if i != j) == y[i, d], name=f"in_flow_{i}_{d}")
            # Day activation link
            model.addConstr(y[i, d] <= z[d], name=f"activate_day_{i}_{d}")
            
        # 3. Depot constraints: Start and finish at location 1 (Index 0) if day is active
        model.addConstr(gp.quicksum(x[0, j, d] for j in customers) == z[d], name=f"depot_out_{d}")
        model.addConstr(gp.quicksum(x[j, 0, d] for j in customers) == z[d], name=f"depot_in_{d}")
        
        # 4. Miller-Tucker-Zemlin (MTZ) Subtour Elimination
        # Prevents disconnected loops by requiring a consistent node sequence back to the depot
        for i in customers:
            for j in customers:
                if i != j:
                    model.addConstr(u[i, d] - u[j, d] + num_locations * x[i, j, d] <= num_locations - 1, name=f"mtz_{i}_{j}_{d}")
                    
        # 5. Workload Guardrail: Maximum travel distance per service day
        model.addConstr(gp.quicksum(D[i][j] * x[i, j, d] for i in nodes for j in nodes if i != j) <= max_route_length_day, name=f"max_dist_{d}")
        
    # Solve the problem
    model.optimize()
    
    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Fallback in case of unexpected solver state
        if hasattr(model, 'objVal'):
            print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
