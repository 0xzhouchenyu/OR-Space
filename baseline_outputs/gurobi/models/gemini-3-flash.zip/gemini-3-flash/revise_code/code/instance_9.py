import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Data paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    toy_data_path = os.path.join(data_dir, "table_1.csv")
    param_data_path = os.path.join(data_dir, "general_parameters.csv")

    # Load toy data from table_1.csv
    toys = {}
    if os.path.exists(toy_data_path):
        with open(toy_data_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                toy_type = row['Toy_Type'].strip()
                toys[toy_type] = {
                    'profit': float(row['Profit_Per_Unit']),
                    'wood': float(row['Wood_Required_Per_Unit']),
                    'steel': float(row['Steel_Required_Per_Unit'])
                }

    # Load general parameters from general_parameters.csv
    params = {}
    if os.path.exists(param_data_path):
        with open(param_data_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                params[row['Parameter_Name'].strip()] = float(row['Value'])

    # Initialize Gurobi model
    model = gp.Model("HausToysOptimization")
    model.setParam('OutputFlag', 0)

    # All toy types
    toy_types = list(toys.keys())
    
    # Big M value for linking constraints (based on total resources, 1000 is safe)
    M = 1000

    # Decision variables
    # Quantities of each toy type on Standard and Premium shifts
    x_std = model.addVars(toy_types, lb=0, vtype=GRB.CONTINUOUS, name="x_std")
    x_prem = model.addVars(toy_types, lb=0, vtype=GRB.CONTINUOUS, name="x_prem")
    
    # Binary indicators for which shift (if any) is used for each toy type
    z_std = model.addVars(toy_types, vtype=GRB.BINARY, name="z_std")
    z_prem = model.addVars(toy_types, vtype=GRB.BINARY, name="z_prem")
    
    # Binary indicator if the toy is manufactured at all (any shift)
    y = model.addVars(toy_types, vtype=GRB.BINARY, name="y")

    # Shift Arrangement Constraints
    for t in toy_types:
        # Link shift choice to the manufacturing indicator
        model.addConstr(y[t] == z_std[t] + z_prem[t], name=f"Manufacturing_Link_{t}")
        # Each toy must run entirely on one shift or none
        model.addConstr(z_std[t] + z_prem[t] <= 1, name=f"Single_Shift_Choice_{t}")
        # Linking production quantities to shift indicators
        model.addConstr(x_std[t] <= M * z_std[t], name=f"Standard_Quantity_Limit_{t}")
        model.addConstr(x_prem[t] <= M * z_prem[t], name=f"Premium_Quantity_Limit_{t}")

    # Resource constraints: Wood
    available_wood = params['available_wood']
    model.addConstr(
        gp.quicksum(toys[t]['wood'] * (x_std[t] + x_prem[t]) for t in toy_types) <= available_wood,
        name="Wood_Resource_Constraint"
    )

    # Resource constraints: Steel (Standard vs Premium)
    available_steel = params['available_steel']
    steel_factor = params['premium_steel_factor']
    model.addConstr(
        gp.quicksum(toys[t]['steel'] * x_std[t] + (toys[t]['steel'] * steel_factor) * x_prem[t] for t in toy_types) <= available_steel,
        name="Steel_Resource_Constraint"
    )

    # Premium shift total volume capacity
    prem_capacity = params['premium_shift_capacity']
    model.addConstr(
        gp.quicksum(x_prem[t] for t in toy_types) <= prem_capacity,
        name="Premium_Volume_Constraint"
    )

    # Business/Logical Constraints from descriptors
    # 1. Truck-Train exclusion (any shift)
    if 'truck' in toys and 'train' in toys:
        model.addConstr(y['truck'] + y['train'] <= 1, name="Truck_Train_Exclusion")

    # 2. Boat-Airplane dependency (any shift)
    if 'boat' in toys and 'airplane' in toys:
        model.addConstr(y['boat'] <= y['airplane'], name="Boat_Airplane_Dependency")

    # 3. Boat-Train quantity limit (across shifts)
    if 'boat' in toys and 'train' in toys:
        model.addConstr(x_std['boat'] + x_prem['boat'] <= x_std['train'] + x_prem['train'], name="Boat_Train_Limit")

    # Objective: Maximize Total Profit
    # Premium shift units earn profit_premium_bonus extra per unit
    bonus = params['profit_premium_bonus']
    objective = gp.quicksum(
        toys[t]['profit'] * x_std[t] + (toys[t]['profit'] + bonus) * x_prem[t]
        for t in toy_types
    )
    model.setObjective(objective, GRB.MAXIMIZE)

    # Solve optimization problem
    model.optimize()

    # Final result output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
