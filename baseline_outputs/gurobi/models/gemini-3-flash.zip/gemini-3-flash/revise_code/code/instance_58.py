import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            params[name] = row['Value'].strip()
    return params

def solve():
    # File paths
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_file = os.path.join(current_dir, 'data', 'general_parameters.csv')
    
    # Load data
    params = load_parameters(data_file)

    # Problem parameters
    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']

    profits = {f: float(params[f'profit_per_acre_{f}']) for f in fruits}
    
    water_per_acre = {}
    for f in fruits:
        for s in seasons:
            water_per_acre[(f, s)] = float(params[f'water_per_acre_{f}_{s}'])

    total_farm_area = float(params['total_farm_area'])
    min_a_to_p = float(params['min_apples_to_pears_ratio'])
    min_a_to_l = float(params['min_apples_to_lemons_ratio'])
    o_to_l = float(params['oranges_to_lemons_ratio'])
    max_fruit_types = int(float(params['max_fruit_types']))
    
    water_cap_spring = float(params['water_cap_spring'])
    water_cap_autumn = float(params['water_cap_autumn'])
    total_water_budget = float(params['total_water_budget'])
    min_annual_water_per_fruit = float(params['min_annual_water_per_fruit'])
    diversification_reward = float(params['diversification_reward'])

    # Create Gurobi Model
    model = gp.Model("FruitFarmOptimization")
    model.setParam('OutputFlag', 0)

    # Variables
    # x[f, s] is acreage of fruit f in season s
    x = model.addVars(fruits, seasons, lb=0, vtype=GRB.CONTINUOUS, name="acres")
    
    # is_grown[f] is binary: 1 if fruit f is counted as one of the chosen types
    is_grown = model.addVars(fruits, vtype=GRB.BINARY, name="is_grown")
    
    # has_diversification is binary: 1 if at least two fruits are grown
    has_diversification = model.addVar(vtype=GRB.BINARY, name="has_diversification")

    # Objective: Total profit + diversification reward
    total_profit = gp.quicksum(x[f, s] * profits[f] for f in fruits for s in seasons)
    objective = total_profit + diversification_reward * has_diversification
    model.setObjective(objective, GRB.MAXIMIZE)

    # Constraints
    
    # 1. Seasonal land use
    for s in seasons:
        model.addConstr(gp.quicksum(x[f, s] for f in fruits) <= total_farm_area)

    # 2. Annual acreage calculations and ratio constraints
    annual_acres = {f: gp.quicksum(x[f, s] for s in seasons) for f in fruits}
    model.addConstr(annual_acres['apples'] >= min_a_to_p * annual_acres['pears'])
    model.addConstr(annual_acres['apples'] >= min_a_to_l * annual_acres['lemons'])
    model.addConstr(annual_acres['oranges'] == o_to_l * annual_acres['lemons'])

    # 3. Maximum number of fruit types
    model.addConstr(gp.quicksum(is_grown[f] for f in fruits) <= max_fruit_types)

    # 4. Seasonal and Annual Water Governance
    spring_water = gp.quicksum(x[f, 'spring'] * water_per_acre[(f, 'spring')] for f in fruits)
    autumn_water = gp.quicksum(x[f, 'autumn'] * water_per_acre[(f, 'autumn')] for f in fruits)
    model.addConstr(spring_water <= water_cap_spring)
    model.addConstr(autumn_water <= water_cap_autumn)
    
    annual_water = {f: gp.quicksum(x[f, s] * water_per_acre[(f, s)] for s in seasons) for f in fruits}
    model.addConstr(gp.quicksum(annual_water[f] for f in fruits) <= total_water_budget)

    # 5. Linkage between acreage/water and is_grown (threshold requirement)
    # Using total_water_budget as a safe Big-M
    M = total_water_budget
    for f in fruits:
        # If is_grown[f] = 1, must use at least min_annual_water_per_fruit
        model.addConstr(annual_water[f] >= min_annual_water_per_fruit * is_grown[f])
        # If a fruit uses any water/land, is_grown[f] must be 1
        model.addConstr(annual_water[f] <= M * is_grown[f])

    # 6. Diversification reward linkage (earned if sum(is_grown) >= 2)
    # Because max_fruit_types is 2, 2 * has_diversification <= sum(is_grown) works.
    model.addConstr(2 * has_diversification <= gp.quicksum(is_grown[f] for f in fruits))

    # Solve
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    solve()

```
