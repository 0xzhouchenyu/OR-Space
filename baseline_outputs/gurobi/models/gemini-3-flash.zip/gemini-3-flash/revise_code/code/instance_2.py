import gurobipy as gp
from gurobipy import GRB
import os
import csv

# Load parameters from the CSV file
def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

# Define data directory and file path
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params_file = os.path.join(data_dir, 'general_parameters.csv')

# Load numerical values from the data packet
params = load_parameters(params_file)

a1 = int(params['a1'])
a2 = int(params['a2'])
training_capacity = params['training_capacity_per_jet']
training_duration = int(params['training_duration'])
dual_use_efficiency = params['dual_use_training_efficiency']
intensity_cap = params['training_intensity_cap']
combat_jet_min_year2 = params['combat_jet_min_year2']
combat_weight = params['combat_weight']
training_weight = params['training_weight']

# Initialize the Gurobi model
model = gp.Model("FighterJetReadiness")
model.setParam('OutputFlag', 0)

# Decision Variables: Number of jets in each posture for each year
# T[t]: Training-only jets in year t
# C[t]: Combat-only jets in year t
# M[t]: Mixed-posture jets in year t
T = model.addVars(range(1, training_duration + 1), vtype=GRB.INTEGER, name="T")
C = model.addVars(range(1, training_duration + 1), vtype=GRB.INTEGER, name="C")
M = model.addVars(range(1, training_duration + 1), vtype=GRB.INTEGER, name="M")

# Fleet size constraints
# Year 1 total jets available
model.addConstr(T[1] + C[1] + M[1] == a1, "TotalJetsYear1")
# Year 2 total jets available (Year 1 production + Year 2 production)
model.addConstr(T[2] + C[2] + M[2] == a1 + a2, "TotalJetsYear2")

# Training intensity cap constraints
# The training pipeline (T + M) cannot exceed the intensity cap of the fleet in either year
model.addConstr(T[1] + M[1] <= intensity_cap * a1, "IntensityCapYear1")
model.addConstr(T[2] + M[2] <= intensity_cap * (a1 + a2), "IntensityCapYear2")

# Year 2 combat line minimum requirement
# Combat availability includes both combat-only (C) and mixed-posture (M) jets
model.addConstr(C[2] + M[2] >= combat_jet_min_year2, "MinCombatYear2")

# Pilot availability constraint for Year 2
# Each trained pilot can operate one combat jet in subsequent years.
# Pilots trained in Year 1 (P1) are available for combat jets in Year 2.
# Training yield: Training-only jets yield 100%, Mixed-posture jets yield dual_use_training_efficiency.
P1 = training_capacity * (T[1] + dual_use_efficiency * M[1])
model.addConstr(C[2] + M[2] <= P1, "PilotAvailabilityYear2")

# Objective Function
# Maximize: combat_weight * (Year 2 combat jets) + training_weight * (Total pilots trained)
# Total pilots trained = Pilots trained in Year 1 + Pilots trained in Year 2
P2 = training_capacity * (T[2] + dual_use_efficiency * M[2])
total_pilots = P1 + P2
combat_jets_year2 = C[2] + M[2]

model.setObjective(combat_weight * combat_jets_year2 + training_weight * total_pilots, GRB.MAXIMIZE)

# Solve the optimization problem
model.optimize()

# Output the optimal objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # Fallback in case of infeasibility or other issues
    print("FINAL_OBJ_VALUE: 0.0")
