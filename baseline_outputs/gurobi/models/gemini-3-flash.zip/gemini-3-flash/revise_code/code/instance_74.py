import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # File paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params_file = os.path.join(data_dir, 'general_parameters.csv')
    precedence_file = os.path.join(data_dir, 'table_1.csv')

    # Read parameters
    params = {}
    with open(params_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Read precedences
    precedences = []
    with open(precedence_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))

    # Activities and durations
    activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    dur = {a: params[f'activity_{a}_duration'] for a in activities}
    
    work_cost = params['work_cost_per_day']
    machine_cost = params['machine_rental_cost_per_day']
    
    # Overtime parameters for E
    e_reduction = params['activity_E_overtime_reduction']
    e_overtime_cost = params['activity_E_overtime_cost']
    e_followup_trigger = params['activity_E_followup_review_trigger']
    e_followup_cost = params['activity_E_followup_review_cost']
    
    # Model
    model = gp.Model("Project_Cost_Minimization")
    model.setParam('OutputFlag', 0)
    
    # Variables
    S = {a: model.addVar(lb=0, name=f"S_{a}") for a in activities}
    T = model.addVar(lb=0, name="T")
    x_E = model.addVar(vtype=GRB.BINARY, name="x_E")
    
    # Durations considering overtime
    # Only E can be accelerated
    def get_dur(a):
        if a == 'E':
            return dur['E'] - e_reduction * x_E
        else:
            return dur[a]
    
    # Constraints
    for pred, succ in precedences:
        model.addConstr(S[succ] >= S[pred] + get_dur(pred))
        
    for a in activities:
        model.addConstr(T >= S[a] + get_dur(a))
        
    # Objective
    # machine_cost * (S['B'] + dur['B'] - S['A'])
    # Note: dur['B'] is constant
    overtime_total_cost = (e_overtime_cost + e_followup_trigger * e_followup_cost) * x_E
    model.setObjective(work_cost * T + machine_cost * (S['B'] + dur['B'] - S['A']) + overtime_total_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
