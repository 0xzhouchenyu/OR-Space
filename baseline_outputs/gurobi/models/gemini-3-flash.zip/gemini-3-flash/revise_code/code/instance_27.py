import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Define paths to data files
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    table1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')

    # Load table_1.csv data
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    products = ['Product_I', 'Product_II', 'Product_III']

    if os.path.exists(table1_path):
        with open(table1_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                e = row['Equipment'].strip()
                if not e:
                    continue
                equipment.append(e)
                proc_times[e] = {}
                for p in products:
                    val = row.get(p, "").strip()
                    proc_times[e][p] = float(val) if val else None
                eff_hours[e] = float(row['Effective_Machine_Hours'])
                op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'])

    # Load general_parameters.csv data
    raw_costs = {}
    prices = {}
    labor_coeffs = {}
    shared_labor_hours = 0
    b2_activation_fee = 0

    if os.path.exists(params_path):
        with open(params_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                name = row['Parameter_Name'].strip()
                val_str = row['Value'].strip()
                if not val_str:
                    continue
                val = float(val_str)
                if 'raw_material_cost_product_' in name:
                    p_suffix = name.split('_')[-1]
                    raw_costs[f"Product_{p_suffix}"] = val
                elif 'unit_price_product_' in name:
                    p_suffix = name.split('_')[-1]
                    prices[f"Product_{p_suffix}"] = val
                elif 'labor_coeff_' in name:
                    e_name = name.replace('labor_coeff_', '')
                    labor_coeffs[e_name] = val
                elif name == 'shared_labor_hours':
                    shared_labor_hours = val
                elif name == 'b2_activation_fee':
                    b2_activation_fee = val

    # Initialize Gurobi model
    model = gp.Model("Factory_Production_Optimization")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[e, p]: number of units of product p processed on equipment e
    x = {}
    for e in equipment:
        for p in products:
            if proc_times[e][p] is not None:
                x[e, p] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")

    # Binary variable for B2 activation
    z_b2 = model.addVar(vtype=GRB.BINARY, name="z_b2")

    # Group equipment by process type
    a_equip = [e for e in equipment if e.startswith('A')]
    b_equip = [e for e in equipment if e.startswith('B')]

    # Flow balance constraints: Total units of product p through Process A must equal Process B
    for p in products:
        a_sum = gp.quicksum(x[e, p] for e in a_equip if (e, p) in x)
        b_sum = gp.quicksum(x[e, p] for e in b_equip if (e, p) in x)
        model.addConstr(a_sum == b_sum, name=f"balance_{p}")

    # Equipment capacity constraints (incorporating activation for B2)
    for e in equipment:
        machine_hours_used = gp.quicksum(x[e, p] * proc_times[e][p] for p in products if (e, p) in x)
        if e == 'B2':
            model.addConstr(machine_hours_used <= eff_hours[e] * z_b2, name=f"capacity_{e}")
        else:
            model.addConstr(machine_hours_used <= eff_hours[e], name=f"capacity_{e}")

    # Shared labor pool constraint
    total_labor_used = gp.quicksum(
        labor_coeffs[e] * gp.quicksum(x[e, p] * proc_times[e][p] for p in products if (e, p) in x)
        for e in equipment if e in labor_coeffs
    )
    model.addConstr(total_labor_used <= shared_labor_hours, name="labor_pool_limit")

    # Objective: Maximize Profit
    # total_prod[p] is the amount of product p completed (passing through both processes)
    total_prod = {p: gp.quicksum(x[e, p] for e in a_equip if (e, p) in x) for p in products}
    
    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)
    raw_material_cost = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)
    
    # Operating cost is linearly proportional to machine hours used based on full capacity cost
    operating_cost = gp.quicksum(
        op_costs[e] * (gp.quicksum(x[e, p] * proc_times[e][p] for p in products if (e, p) in x) / eff_hours[e])
        for e in equipment
    )
    
    # One-time activation fee for B2
    activation_fee = b2_activation_fee * z_b2
    
    model.setObjective(revenue - raw_material_cost - operating_cost - activation_fee, GRB.MAXIMIZE)

    # Optimize the model
    model.optimize()

    # Output results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Provide a default result if no optimal solution found (fallback)
        print(f"FINAL_OBJ_VALUE: 0.0")

if __name__ == "__main__":
    main()
