import gurobipy as gp
from gurobipy import GRB
import os
import csv

def solve():
    # File paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    gen_params_path = os.path.join(data_dir, 'general_parameters.csv')
    table_1_path = os.path.join(data_dir, 'table_1.csv')

    # Read general parameters
    params = {}
    with open(gen_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']

    n = int(params['n'])
    premium_multiplier = float(params['premium_cost_multiplier'])
    min_premium_share = float(params['min_premium_share'])

    # Read table_1.csv
    # d[i][j] is the transportation volume from factory i to destination location j
    # c[p][j] is the unit transportation cost from location p to destination location j
    d = []
    c = []
    factories = []
    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            factories.append(row['Factory'])
            d_row = []
            c_row = []
            for j in range(1, n + 1):
                d_row.append(float(row[f'Transportation_volume_to_Location_{j}']))
                c_row.append(float(row[f'Transportation_cost_to_Location_{j}']))
            d.append(d_row)
            c.append(c_row)

    # Calculate outbound volumes for each factory
    V = [sum(d[i]) for i in range(n)]

    # Calculate standard and premium unit costs for each factory-location pairing
    # c_std[i][p] = (sum_j d[i][j] * c[p][j]) / V[i]
    c_std = [[0.0 for p in range(n)] for i in range(n)]
    for i in range(n):
        for p in range(n):
            if V[i] > 0:
                c_std[i][p] = sum(d[i][j] * c[p][j] for j in range(n)) / V[i]
            else:
                c_std[i][p] = 0.0

    c_prem = [[premium_multiplier * c_std[i][p] for p in range(n)] for i in range(n)]

    # Optimization model
    model = gp.Model("Factory_Assignment_Optimization")
    model.setParam('OutputFlag', 0)

    # Decision Variables
    # x[i,p] = 1 if factory i is assigned to location p
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")
    # y[i,p] = 1 if premium service is activated for factory i at location p
    y = model.addVars(n, n, vtype=GRB.BINARY, name="y")
    # v_std[i,p] = volume of factory i handled at location p using standard service
    v_std = model.addVars(n, n, lb=0.0, name="v_std")
    # v_prem[i,p] = volume of factory i handled at location p using premium service
    v_prem = model.addVars(n, n, lb=0.0, name="v_prem")

    # Constraints
    # 1. Each factory must be assigned to exactly one location
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, p] for p in range(n)) == 1)

    # 2. Each location can host at most one factory
    for p in range(n):
        model.addConstr(gp.quicksum(x[i, p] for i in range(n)) <= 1)

    # 3. Volume and service mode constraints
    for i in range(n):
        for p in range(n):
            # Total volume from factory i must equal its outbound volume if assigned to location p
            model.addConstr(v_std[i, p] + v_prem[i, p] == V[i] * x[i, p])
            
            # Premium service can only be activated if the factory is assigned to that location
            model.addConstr(y[i, p] <= x[i, p])
            
            # If premium service is activated, it must cover at least min_premium_share of the volume
            model.addConstr(v_prem[i, p] >= min_premium_share * V[i] * y[i, p])
            
            # Premium volume is only possible if premium service is activated
            model.addConstr(v_prem[i, p] <= V[i] * y[i, p])

    # Objective: Minimize total transportation and handling cost
    obj = gp.quicksum(c_std[i][p] * v_std[i, p] + c_prem[i][p] * v_prem[i, p]
                      for i in range(n) for p in range(n))
    model.setObjective(obj, GRB.MINIMIZE)

    # Solve the model
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
