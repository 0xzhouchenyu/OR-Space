import gurobipy as gp
from gurobipy import GRB
import csv
import os

def solve():
    # Paths to data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    table1_path = os.path.join(base_dir, "data", "table_1.csv")

    # Load general parameters
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = row['Value']
            try:
                if '.' in val:
                    params[name] = float(val)
                else:
                    params[name] = int(val)
            except ValueError:
                params[name] = val

    # Load task and method data
    task_methods = []
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            task_methods.append({
                'Task': row['Task'],
                'Method': row['Method'],
                'Effective_Hours': float(row['Effective_Hours']),
                'Fixed_Cost': float(row['Fixed_Cost'])
            })

    # Model initialization
    model = gp.Model("WorkerAllocation")
    model.setParam('OutputFlag', 0)

    # Sets
    tasks = sorted(list(set(tm['Task'] for tm in task_methods)))
    methods = sorted(list(set(tm['Method'] for tm in task_methods)))

    # Variables
    # y[t, m] is binary, 1 if method m is chosen for task t
    y = model.addVars(tasks, methods, vtype=GRB.BINARY, name="y")
    # s[t, m] is continuous, number of skilled workers for task t, method m
    s = model.addVars(tasks, methods, lb=0.0, vtype=GRB.CONTINUOUS, name="s")
    # l[t, m] is continuous, number of laborers for task t, method m
    l = model.addVars(tasks, methods, lb=0.0, vtype=GRB.CONTINUOUS, name="l")

    # Objective: Minimize total weekly cost (wages + fixed costs)
    skilled_wage = params['skilled_worker_weekly_wage']
    laborer_wage = params['laborer_weekly_wage']
    
    total_wages = gp.quicksum((skilled_wage * s[t, m] + laborer_wage * l[t, m]) 
                              for t in tasks for m in methods)
    total_fixed_cost = gp.quicksum(tm['Fixed_Cost'] * y[tm['Task'], tm['Method']] 
                                   for tm in task_methods)
    
    model.setObjective(total_wages + total_fixed_cost, GRB.MINIMIZE)

    # Constraints
    # 1. Exactly one method must be chosen for each task
    for t in tasks:
        model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1, name=f"one_method_{t}")

    # 2. Hours requirement and linking workforce to chosen method
    skilled_hours = params['skilled_worker_weekly_hours']
    laborer_hours = params['laborer_weekly_hours']
    M = 10000 # Big-M for linking continuous worker variables to binary selection
    for tm in task_methods:
        t, m = tm['Task'], tm['Method']
        # Total effective hours must meet task-method requirement
        model.addConstr(skilled_hours * s[t, m] + laborer_hours * l[t, m] >= tm['Effective_Hours'] * y[t, m], name=f"hours_{t}_{m}")
        # Skilled workers and laborers can only be assigned if the method is chosen
        model.addConstr(s[t, m] <= M * y[t, m], name=f"link_s_{t}_{m}")
        model.addConstr(l[t, m] <= M * y[t, m], name=f"link_l_{t}_{m}")

    # 3. Overall staffing capacity and hiring ratio
    total_skilled = gp.quicksum(s[t, m] for t in tasks for m in methods)
    total_laborers = gp.quicksum(l[t, m] for t in tasks for m in methods)
    
    model.addConstr(total_skilled <= params['max_skilled_workers'], name="max_skilled")
    model.addConstr(total_laborers <= params['max_laborers'], name="max_laborers")
    # Skilled workers cannot exceed 60% of laborers
    model.addConstr(total_skilled <= params['skilled_worker_hiring_ratio'] * total_laborers, name="skilled_hiring_ratio")

    # 4. Exclusion Rule: Task 1 Method B and Task 3 Method A are mutually exclusive
    if params.get('exclusion_rule_task1_task3', 0) == 1:
        model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1, name="exclusion_rule")

    # 5. Task 3 Method B special constraint: minimum 20 skilled workers
    model.addConstr(s['Task_3', 'Method_B'] >= params['min_skilled_workers_task3_methodB'] * y['Task_3', 'Method_B'], name="min_s_task3_MB")

    # 6. Task-level skill-balance bands (minimum and maximum skilled share per task)
    task_bands = {
        'Task_1': (params['min_skilled_share_task1'], params['max_skilled_share_task1']),
        'Task_2': (params['min_skilled_share_task2'], params['max_skilled_share_task2']),
        'Task_3': (params['min_skilled_share_task3'], params['max_skilled_share_task3'])
    }

    for t in tasks:
        min_share, max_share = task_bands[t]
        s_task = gp.quicksum(s[t, m] for m in methods)
        l_task = gp.quicksum(l[t, m] for m in methods)
        # Skilled Share = s_task / (s_task + l_task)
        # s_task / (s_task + l_task) >= min_share  =>  s_task * (1 - min_share) >= l_task * min_share
        model.addConstr(s_task * (1 - min_share) >= l_task * min_share, name=f"min_share_band_{t}")
        # s_task / (s_task + l_task) <= max_share  =>  s_task * (1 - max_share) <= l_task * max_share
        model.addConstr(s_task * (1 - max_share) <= l_task * max_share, name=f"max_share_band_{t}")

    # Solve optimization problem
    model.optimize()

    # Output result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
