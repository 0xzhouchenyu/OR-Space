import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
min_A = params['min_raw_material_A']
min_B = params['min_raw_material_B']
min_C = params['min_raw_material_C']

cap_A_a = params['warehouse_A_truck_capacity_A']
cap_A_b = params['warehouse_A_truck_capacity_B']
cap_A_c = params['warehouse_A_truck_capacity_C']
cost_A = params['warehouse_A_truck_cost']
fixed_A = params['warehouse_A_fixed_cost']

cap_B_a = params['warehouse_B_truck_capacity_A']
cap_B_b = params['warehouse_B_truck_capacity_B']
cap_B_c = params['warehouse_B_truck_capacity_C']
cost_B = params['warehouse_B_truck_cost']
fixed_B = params['warehouse_B_fixed_cost']

threshold_B = params['warehouse_B_overflow_threshold_trucks']
overflow_cost_B = params['warehouse_B_overflow_coordination_cost']

dual_fee = params['dual_warehouse_reconciliation_fee']

# Create the optimization model
model = gp.Model("MinFreightCostRevised")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_A")
y = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_B")
u_a = model.addVar(vtype=GRB.BINARY, name="use_warehouse_A")
u_b = model.addVar(vtype=GRB.BINARY, name="use_warehouse_B")
v_b = model.addVar(vtype=GRB.BINARY, name="overflow_warehouse_B")
w_ab = model.addVar(vtype=GRB.BINARY, name="dual_warehouse_used")

# Big M for constraints
M = 1000

# Objective: minimize total freight cost
model.setObjective(
    cost_A * x + cost_B * y + 
    fixed_A * u_a + fixed_B * u_b + 
    overflow_cost_B * v_b + 
    dual_fee * w_ab, 
    GRB.MINIMIZE
)

# Constraints: meet minimum raw material requirements
model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# Constraints for binary indicators
model.addConstr(x <= M * u_a, "Link_x_ua")
model.addConstr(y <= M * u_b, "Link_y_ub")

# Constraint for Warehouse B overflow (y > threshold_B)
model.addConstr(y - threshold_B <= M * v_b, "Link_y_vb")

# Constraint for dual warehouse reconciliation (u_a=1 AND u_b=1)
model.addConstr(w_ab >= u_a + u_b - 1, "Link_ua_ub_wab")

# Solve
model.optimize()

# Output results
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("Optimal solution not found.")
