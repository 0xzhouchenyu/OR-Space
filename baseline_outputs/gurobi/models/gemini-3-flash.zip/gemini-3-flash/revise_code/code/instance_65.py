import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_optimization():
    # Define the data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
        for row in csv.DictReader(f):
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    # Load product-specific data
    products = {}
    with open(os.path.join(data_dir, 'table_1.csv')) as f:
        for row in csv.DictReader(f):
            products[row['Product'].strip()] = {
                'a_hrs': float(row['Workshop_A_Hours']),
                'b_hrs': float(row['Workshop_B_Hours']),
                'insp_cost': float(row['Inspection_Sales_Cost'])
            }

    # Extract product data for convenience
    m = products['Microwave_Oven']
    w = products['Water_Heater']

    # Create the Gurobi model
    model = gp.Model("production_optimization")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x1, x2: units of microwave ovens and water heaters
    # y1, y2: binary indicators for whether each product uses Workshop A
    x1 = model.addVar(lb=params['microwave_minimum_sales'], vtype=GRB.CONTINUOUS, name="microwave")
    x2 = model.addVar(lb=params['water_heater_minimum_sales'], vtype=GRB.CONTINUOUS, name="water_heater")
    y1 = model.addVar(vtype=GRB.BINARY, name="y1")
    y2 = model.addVar(vtype=GRB.BINARY, name="y2")

    # Objective function
    # The original heuristic maximized: (a_hrs * a_cost + b_hrs * b_cost + insp_cost) * units
    # The revision adds: green_bonus * units AND setup_hours_A * a_cost * indicator
    rev_m = m['a_hrs'] * params['workshop_a_hourly_cost'] + m['b_hrs'] * params['workshop_b_hourly_cost'] + m['insp_cost']
    rev_w = w['a_hrs'] * params['workshop_a_hourly_cost'] + w['b_hrs'] * params['workshop_b_hourly_cost'] + w['insp_cost']
    
    setup_value = params['setup_hours_A'] * params['workshop_a_hourly_cost']

    objective = (rev_m + params['green_bonus_m']) * x1 + \
                (rev_w + params['green_bonus_w']) * x2 + \
                setup_value * y1 + \
                setup_value * y2

    model.setObjective(objective, GRB.MAXIMIZE)

    # Constraints
    # 1. Workshop A capacity: productive hours + setup hours <= available + overtime
    model.addConstr(m['a_hrs'] * x1 + params['setup_hours_A'] * y1 + 
                    w['a_hrs'] * x2 + params['setup_hours_A'] * y2 <= 
                    params['workshop_a_available_hours'] + params['workshop_a_overtime_limit'], 
                    "workshop_a_capacity")

    # 2. Workshop B utilization: productive hours >= available (as per heuristic)
    model.addConstr(m['b_hrs'] * x1 + w['b_hrs'] * x2 >= params['workshop_b_available_hours'], 
                    "workshop_b_utilization")

    # 3. Inspection and sales cost limit
    model.addConstr(m['insp_cost'] * x1 + w['insp_cost'] * x2 <= params['inspection_sales_cost_limit'], 
                    "inspection_cost_limit")

    # 4. Technician pool constraint
    model.addConstr(params['tech_rate_m'] * x1 + params['tech_rate_w'] * x2 <= params['tech_pool_hours'], 
                    "tech_pool_limit")

    # 5. Linking constraints: x <= bigM * y
    model.addConstr(x1 <= params['bigM'] * y1, "linking_m")
    model.addConstr(x2 <= params['bigM'] * y2, "linking_w")

    # Solve the model
    model.optimize()

    # Print the objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_optimization()
