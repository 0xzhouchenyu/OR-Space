import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # File paths
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    table1_path = os.path.join(base_dir, 'table_1.csv')
    
    # Load general parameters
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    # Load food item data
    items = []
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })
            
    # Configuration
    min_veg_per_meal = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_calories = params['min_daily_calories']
    max_calories = params['max_daily_calories']
    max_sodium = params['max_daily_sodium']
    
    max_units = int(total_weight_limit // 100)
    max_meal_units = 3  # Each meal is exactly 300g (3 units of 100g)
    
    # Model definition
    model = gp.Model("MaryMealPlanning")
    model.setParam('OutputFlag', 0)
    
    n = len(items)
    
    # Decision Variables
    # Total units purchased per item
    purchase_units = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="purchase")
    # Units assigned to each meal
    lunch_units = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="lunch")
    dinner_units = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="dinner")
    # Selection indicator
    select_item = model.addVars(n, vtype=GRB.BINARY, name="select")
    
    # Vegetable indicators for meal coverage
    veg_indices = [i for i in range(n) if items[i]['type'] == 'Vegetable']
    lunch_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg")
    dinner_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg")
    
    # Objective: Maximize total protein intake from lunch and dinner
    model.setObjective(gp.quicksum(items[i]['protein'] * (lunch_units[i] + dinner_units[i]) for i in range(n)), GRB.MAXIMIZE)
    
    # Constraints
    # 1. Budget Constraint (Total purchased amount)
    model.addConstr(gp.quicksum(items[i]['cost'] * purchase_units[i] for i in range(n)) <= max_budget)
    
    # 2. Total Weight Limit (Total purchased amount)
    model.addConstr(gp.quicksum(100 * purchase_units[i] for i in range(n)) <= total_weight_limit)
    
    # 3. Allocation linkage (Cannot eat more than purchased)
    for i in range(n):
        model.addConstr(purchase_units[i] >= lunch_units[i] + dinner_units[i])
        
    # 4. Item Selection linkage (Big-M constraints)
    for i in range(n):
        model.addConstr(purchase_units[i] <= max_units * select_item[i])
        model.addConstr(lunch_units[i] <= max_meal_units * select_item[i])
        model.addConstr(dinner_units[i] <= max_meal_units * select_item[i])
        
    # 5. Fixed meal weight (Exactly 300g = 3 units per meal)
    model.addConstr(gp.quicksum(lunch_units[i] for i in range(n)) == max_meal_units)
    model.addConstr(gp.quicksum(dinner_units[i] for i in range(n)) == max_meal_units)
    
    # 6. Vegetable usage indicators and variety constraints
    for i in veg_indices:
        # If units > 0, indicator must be 1. If units = 0, indicator must be 0.
        model.addConstr(lunch_units[i] >= lunch_veg_selected[i])
        model.addConstr(lunch_units[i] <= max_meal_units * lunch_veg_selected[i])
        model.addConstr(dinner_units[i] >= dinner_veg_selected[i])
        model.addConstr(dinner_units[i] <= max_meal_units * dinner_veg_selected[i])
        
    model.addConstr(gp.quicksum(lunch_veg_selected[i] for i in veg_indices) >= min_veg_per_meal)
    model.addConstr(gp.quicksum(dinner_veg_selected[i] for i in veg_indices) >= min_veg_per_meal)
    
    # 7. Daily Calorie Bounds (Sum of lunch and dinner intake)
    total_calories = gp.quicksum(items[i]['calories'] * (lunch_units[i] + dinner_units[i]) for i in range(n))
    model.addConstr(total_calories >= min_calories)
    model.addConstr(total_calories <= max_calories)
    
    # 8. Daily Sodium Bounds (Sum of lunch and dinner intake)
    total_sodium = gp.quicksum(items[i]['sodium'] * (lunch_units[i] + dinner_units[i]) for i in range(n))
    model.addConstr(total_sodium <= max_sodium)
    
    # Optimization
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
