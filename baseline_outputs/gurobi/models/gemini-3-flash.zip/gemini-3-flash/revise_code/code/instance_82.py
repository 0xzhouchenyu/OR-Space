import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_mall_leasing():
    # Define paths to data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    general_params_path = os.path.join(data_dir, 'general_parameters.csv')
    table_1_path = os.path.join(data_dir, 'table_1.csv')

    # Read general parameters
    params = {}
    with open(general_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    mall_total_space = params['mall_total_space']
    rent_percentage = params['rent_percentage'] / 100.0
    common_area_factor = params['common_area_factor']
    gm_concession = params['general_merchandise_third_store_concession']
    catering_security_threshold = int(params['catering_third_store_security_threshold'])
    catering_security_cost = params['catering_third_store_security_cost']

    # Read store data
    stores = []
    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            store_type = row['Store_Type'].strip()
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            
            stores.append({
                'name': store_type,
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits
            })

    # Initialize Gurobi model
    model = gp.Model("Mall_Leasing_Optimization")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[i, k] is 1 if store type i has exactly k shops
    x = {}
    for i, store in enumerate(stores):
        for k in range(store['min'], store['max'] + 1):
            x[i, k] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{k}")

    # Constraint: Each store type must have exactly one number of shops selected
    for i, store in enumerate(stores):
        model.addConstr(gp.quicksum(x[i, k] for k in range(store['min'], store['max'] + 1)) == 1)

    # Constraint: Total area used (including common area factor) must not exceed mall space
    total_area_expr = gp.quicksum(
        k * store['area'] * common_area_factor * x[i, k]
        for i, store in enumerate(stores)
        for k in range(store['min'], store['max'] + 1)
    )
    model.addConstr(total_area_expr <= mall_total_space)

    # Objective: Maximize total rental income
    # Rent = (Total Profit * rent_percentage) - Concessions - Costs
    
    # Base rental income from profits
    base_rent_expr = gp.quicksum(
        k * store['profits'].get(k, 0) * rent_percentage * x[i, k]
        for i, store in enumerate(stores)
        for k in range(store['min'], store['max'] + 1)
        if k > 0
    )

    # Concessions and costs
    extra_costs_expr = 0
    for i, store in enumerate(stores):
        if store['name'] == 'General_Merchandise' and 3 in range(store['min'], store['max'] + 1):
            extra_costs_expr += gm_concession * x[i, 3]
        if store['name'] == 'Catering' and 3 in range(store['min'], store['max'] + 1):
            # Cost applies if number of catering stores > threshold (2)
            extra_costs_expr += catering_security_cost * x[i, 3]

    model.setObjective(base_rent_expr - extra_costs_expr, GRB.MAXIMIZE)

    # Solve the model
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_mall_leasing()
