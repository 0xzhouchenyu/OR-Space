import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    # File paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    params_file = os.path.join(data_dir, 'general_parameters.csv')
    table_file = os.path.join(data_dir, 'table_1.csv')

    # Load general parameters
    params = {}
    with open(params_file, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if row[1]:
                params[row[0]] = float(row[1])

    # Load processing times
    processing_times = []
    with open(table_file, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            # Row format: Product_Name, Machine_1, Machine_2, Machine_3
            times = [int(val) for val in row[1:]]
            processing_times.append(times)

    n_products = len(processing_times)
    n_machines = len(processing_times[0])

    # Model parameters
    W = [params['time_window_1'], params['time_window_2'], params['time_window_3']]
    OW = [params['overtime_window_1'], params['overtime_window_2'], params['overtime_window_3']]
    P = params['overtime_penalty_per_unit']
    M_const = [params['M_1'], params['M_2'], params['M_3']]
    T1 = params['machine1_overtime_review_threshold']
    F1 = params['machine1_overtime_review_fee']

    # Initialize Gurobi model
    model = gp.Model("FlowShop_Overtime")
    model.setParam('OutputFlag', 0)

    # Variables
    # x[i, k] = 1 if product i is in position k
    x = model.addVars(n_products, n_products, vtype=GRB.BINARY, name="x")
    # c[k, j] = completion time of product in position k on machine j
    c = model.addVars(n_products, n_machines, lb=0, name="c")
    # ot[j] = overtime usage on machine j
    ot = model.addVars(n_machines, lb=0, name="ot")
    # b1 = machine 1 review fee binary
    b1 = model.addVar(vtype=GRB.BINARY, name="b1")

    # Sequencing Constraints
    for i in range(n_products):
        model.addConstr(gp.quicksum(x[i, k] for k in range(n_products)) == 1)
    for k in range(n_products):
        model.addConstr(gp.quicksum(x[i, k] for i in range(n_products)) == 1)

    # Completion Time constraints
    for k in range(n_products):
        for j in range(n_machines):
            # Processing time of job at position k on machine j
            p_pos_kj = gp.quicksum(processing_times[i][j] * x[i, k] for i in range(n_products))
            
            # Flow shop timing: same job sequentially on machines
            if j > 0:
                model.addConstr(c[k, j] >= c[k, j-1] + p_pos_kj)
            
            # Flow shop timing: machine sequentially processes jobs
            if k > 0:
                model.addConstr(c[k, j] >= c[k-1, j] + p_pos_kj)
            else:
                # First job on machine j
                if j == 0:
                    model.addConstr(c[k, j] == p_pos_kj)
                else:
                    # c[0, j] depends on c[0, j-1]
                    model.addConstr(c[k, j] >= c[k, j-1] + p_pos_kj)

    # Overtime Calculation: duration = end time of last job - start time of first job
    for j in range(n_machines):
        p_pos_0j = gp.quicksum(processing_times[i][j] * x[i, 0] for i in range(n_products))
        start_j = c[0, j] - p_pos_0j
        duration_j = c[n_products-1, j] - start_j
        
        # Overtime usage
        model.addConstr(ot[j] >= duration_j - W[j])
        model.addConstr(ot[j] <= OW[j])

    # Machine 1 Review Fee logic: ot[0] > T1 implies b1 = 1
    model.addConstr(ot[0] <= T1 + M_const[0] * b1)

    # Objective: Minimize Makespan + Overtime Penalty + Review Burden
    # Makespan is completion time of the last job on the last machine
    makespan = c[n_products-1, n_machines-1]
    overtime_penalties = gp.quicksum(P * ot[j] for j in range(n_machines))
    objective = makespan + overtime_penalties + F1 * b1
    
    model.setObjective(objective, GRB.MINIMIZE)

    # Solve
    model.optimize()

    # Output result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # If infeasible, attempt to print status for debugging (though not requested)
        pass

if __name__ == "__main__":
    main()
