import gurobipy as gp
from gurobipy import GRB
import os
import csv

def solve():
    # Paths to data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table1_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")

    # Read table_1.csv for material properties
    materials = []
    sulfur_content = {}
    purchase_price = {}
    with open(table1_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            mat = row['Material'].strip()
            materials.append(mat)
            
            # Sulfur Content (handling potential spaces in column names)
            s_val = None
            for key in row:
                if 'Sulfur_Content_Percentage' in key:
                    s_val = float(row[key].strip())
            sulfur_content[mat] = s_val
            
            # Purchase Price (handling potential spaces in column names)
            p_val = None
            for key in row:
                if 'Purchase_Price' in key:
                    p_val = float(row[key].strip())
            purchase_price[mat] = p_val

    # Read general_parameters.csv for constraints and prices
    params = {}
    with open(params_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = None
            for key in row:
                if 'Value' in key:
                    val = float(row[key].strip())
            params[name] = val

    # Initialize Gurobi Model
    model = gp.Model("Blending_Optimization")
    model.setParam('OutputFlag', 0)

    # Define product families and tiers
    families = ['A', 'B']
    tiers = ['premium', 'standard']

    # Decision Variables: x[material, family, tier] = tons of material used in specific product stream
    x = model.addVars(materials, families, tiers, lb=0, name="x")

    # Helper expressions for totals
    total_p_t = { (p, t): gp.quicksum(x[m, p, t] for m in materials) for p in families for t in tiers }
    total_p = { p: gp.quicksum(x[m, p, t] for m in materials for t in tiers) for p in families }

    # Objective Function: Maximize Profit = Total Revenue - Total Cost
    revenue = gp.quicksum(params[f'selling_price_{p}_{t}'] * total_p_t[p, t] for p in families for t in tiers)
    cost = gp.quicksum(purchase_price[m] * x[m, p, t] for m in materials for p in families for t in tiers)
    model.setObjective(revenue - cost, GRB.MAXIMIZE)

    # Constraints
    # 1. Sulfur Content Compliance for each product stream
    for p in families:
        for t in tiers:
            # sum(sulfur[m] * x[m,p,t]) <= max_sulfur[p,t] * sum(x[m,p,t])
            model.addConstr(
                gp.quicksum((sulfur_content[m] - params[f'max_sulfur_content_{p}_{t}']) * x[m, p, t] for m in materials) <= 0,
                name=f"Sulfur_{p}_{t}"
            )

    # 2. Supply Limit for Material D
    model.addConstr(
        gp.quicksum(x['D', p, t] for p in families for t in tiers) <= params['max_supply_D'],
        name="Supply_D"
    )

    # 3. Market Demand (Family level: premium + standard)
    for p in families:
        model.addConstr(total_p[p] <= params[f'market_demand_{p}'], name=f"Demand_{p}")

    # 4. Premium Share Constraints (Family level)
    for p in families:
        model.addConstr(total_p_t[p, 'premium'] >= params[f'min_premium_share_{p}'], name=f"MinPremium_{p}")
        model.addConstr(total_p_t[p, 'premium'] <= params[f'max_premium_share_{p}'], name=f"MaxPremium_{p}")

    # Solve the optimization problem
    model.optimize()

    # Output the final objective value
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # In case of infeasibility or other issues, though the problem context implies feasibility
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
