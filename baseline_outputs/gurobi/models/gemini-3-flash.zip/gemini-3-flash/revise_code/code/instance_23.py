import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Define paths to data files
    current_dir = os.path.dirname(os.path.abspath(__file__))
    table1_path = os.path.join(current_dir, "data", "table_1.csv")
    params_path = os.path.join(current_dir, "data", "general_parameters.csv")
    
    # Read product data from table_1.csv
    products = []
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'name': row['Product Name'].strip(),
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            })
    
    # Read general parameters from general_parameters.csv
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    # Product name mapping from table_1.csv to suffixes in general_parameters.csv
    prod_map = {
        'Shirt': 'shirts',
        'Short-sleeve': 'short_sleeves',
        'Casual Cloth': 'casual_clothes'
    }
    
    # Create Gurobi optimization model
    model = gp.Model("Hongdou_Clothing_Production")
    model.setParam('OutputFlag', 0)
    
    n = len(products)
    
    # Variables
    # x_reg[i]: quantity of product i for the regular segment
    # x_promo[i]: quantity of product i for the promotional segment
    x_reg = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="x_reg")
    x_promo = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="x_promo")
    
    # y_reg[i]: binary indicator if product i is active in regular segment
    # y_promo[i]: binary indicator if product i is active in promotional segment
    y_reg = model.addVars(n, vtype=GRB.BINARY, name="y_reg")
    y_promo = model.addVars(n, vtype=GRB.BINARY, name="y_promo")
    
    # z[i]: binary indicator if the equipment for product i is activated (line is "open")
    z = model.addVars(n, vtype=GRB.BINARY, name="z")
    
    # Global Resource Constraints
    model.addConstr(
        gp.quicksum(products[i]['labor'] * (x_reg[i] + x_promo[i]) for i in range(n)) <= params['available_labor'],
        name="labor_limit"
    )
    model.addConstr(
        gp.quicksum(products[i]['material'] * (x_reg[i] + x_promo[i]) for i in range(n)) <= params['available_material'],
        name="material_limit"
    )
    
    # Promotional Segment Limits
    model.addConstr(
        gp.quicksum(products[i]['labor'] * x_promo[i] for i in range(n)) <= params['segment_promo_labor_cap'],
        name="promo_labor_limit"
    )
    model.addConstr(
        gp.quicksum(products[i]['material'] * x_promo[i] for i in range(n)) <= params['segment_promo_material_cap'],
        name="promo_material_limit"
    )
    
    # Product-specific Constraints (Min Batch, Max Production, and Fixed Cost Activation)
    for i in range(n):
        p_name = products[i]['name']
        p_key = prod_map[p_name]
        
        min_batch = params[f"min_batch_{p_key}"]
        max_prod = params[f"max_prod_{p_key}"]
        
        # Regular segment: gate logic (either 0 or >= min_batch)
        model.addConstr(x_reg[i] >= min_batch * y_reg[i], name=f"min_batch_reg_{p_key}")
        model.addConstr(x_reg[i] <= max_prod * y_reg[i], name=f"max_prod_reg_{p_key}")
        
        # Promotional segment: gate logic (either 0 or >= min_batch)
        model.addConstr(x_promo[i] >= min_batch * y_promo[i], name=f"min_batch_promo_{p_key}")
        model.addConstr(x_promo[i] <= max_prod * y_promo[i], name=f"max_prod_promo_{p_key}")
        
        # Total production per product line cannot exceed global max_prod
        model.addConstr(x_reg[i] + x_promo[i] <= max_prod * z[i], name=f"activation_{p_key}")
        
        # Link segment indicators to the main product activation variable z[i]
        # (Fixed cost is paid once if either segment is used)
        model.addConstr(z[i] >= y_reg[i], name=f"link_z_reg_{p_key}")
        model.addConstr(z[i] >= y_promo[i], name=f"link_z_promo_{p_key}")
    
    # Objective: Maximize Profit
    # Profit = Revenue - Variable Costs - Fixed Costs
    reg_discount = params['segment_regular_discount']
    promo_discount = params['segment_promo_discount']
    
    obj = gp.quicksum(
        ((products[i]['price'] * reg_discount - products[i]['var_cost']) * x_reg[i] +
         (products[i]['price'] * promo_discount - products[i]['var_cost']) * x_promo[i] -
         params[f"fixed_cost_{prod_map[products[i]['name']]}"] * z[i])
        for i in range(n)
    )
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Output the optimal objective value
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
