import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_feed_data(filepath):
    feeds = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            feed = {
                'Feed': int(row['Feed']),
                'Protein_g': float(row['Protein_g']),
                'Minerals_g': float(row['Minerals_g']),
                'Vitamins_mg': float(row['Vitamins_mg']),
                'Price_Y_per_kg': float(row['Price_Y_per_kg']),
            }
            feeds.append(feed)
    return feeds

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

def solve_optimization():
    # Construct paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    feeds_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    # Load data
    feeds = load_feed_data(feeds_path)
    params = load_general_parameters(params_path)
    
    min_protein = params['min_protein_requirement']
    min_minerals = params['min_minerals_requirement']
    min_vitamins = params['min_vitamins_requirement']
    
    # Create Gurobi model
    model = gp.Model("MinimizeFeedCost")
    model.setParam('OutputFlag', 0)
    
    # Feed IDs
    feed_ids = [f['Feed'] for f in feeds]
    
    # Decision variables: amount of each feed (kg), non-negative
    x = model.addVars(feed_ids, lb=0, vtype=GRB.CONTINUOUS, name="x")
    
    # Binary variables for mutual exclusion between Feed 4 and Feed 5
    y4 = model.addVar(vtype=GRB.BINARY, name="y4")
    y5 = model.addVar(vtype=GRB.BINARY, name="y5")
    
    # Objective: minimize total cost
    model.setObjective(gp.quicksum(f['Price_Y_per_kg'] * x[f['Feed']] for f in feeds), GRB.MINIMIZE)
    
    # Nutritional Constraints
    model.addConstr(gp.quicksum(f['Protein_g'] * x[f['Feed']] for f in feeds) >= min_protein, "ProteinRequirement")
    model.addConstr(gp.quicksum(f['Minerals_g'] * x[f['Feed']] for f in feeds) >= min_minerals, "MineralsRequirement")
    model.addConstr(gp.quicksum(f['Vitamins_mg'] * x[f['Feed']] for f in feeds) >= min_vitamins, "VitaminsRequirement")
    
    # Mutual Exclusion Constraints (Big-M approach)
    # M is chosen to be larger than any possible feed amount (700kg is a safe upper bound based on requirements)
    M = 10000
    if 4 in feed_ids:
        model.addConstr(x[4] <= M * y4, "Exclusion_Feed4_Indicator")
    if 5 in feed_ids:
        model.addConstr(x[5] <= M * y5, "Exclusion_Feed5_Indicator")
    
    model.addConstr(y4 + y5 <= 1, "MutualExclusion_4_5")
    
    # Solve
    model.optimize()
    
    # Print result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve_optimization()
