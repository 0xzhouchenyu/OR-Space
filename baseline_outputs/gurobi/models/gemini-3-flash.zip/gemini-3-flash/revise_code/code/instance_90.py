import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve_optimization():
    # File paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_file = os.path.join(base_dir, 'data', 'general_parameters.csv')
    
    # Load data
    params = load_general_parameters(data_file)
    
    # Inventory and labor limits
    shirts_inv = params['shirts_inventory']
    pants_inv = params['pants_inventory']
    labor_inv = params['labor_hours_total']
    
    # Package parameters
    price_a = params['package_a_price']
    price_b = params['package_b_price']
    price_c = params['package_c_price']
    
    shirts_a = params['package_a_shirts']
    shirts_b = params['package_b_shirts']
    shirts_c = params['package_c_shirts']
    
    pants_a = params['package_a_pants']
    pants_b = params['package_b_pants']
    pants_c = params['package_c_pants']
    
    labor_a = params['labor_hours_per_A']
    labor_b = params['labor_hours_per_B']
    labor_c = params['labor_hours_per_C']
    
    # Campaign and threshold parameters
    min_a = params['min_campaign_batch_a']
    min_b = params['min_campaign_batch_b']
    min_c = params['min_campaign_batch_c']
    
    act_cost_a = params['activation_cost_a']
    act_cost_b = params['activation_cost_b']
    act_cost_c = params['activation_cost_c']
    
    bigM_a = params['bigM_a']
    bigM_b = params['bigM_b']
    bigM_c = params['bigM_c']
    
    thresh_b = params['package_b_review_threshold']
    charge_b = params['package_b_review_charge']
    thresh_c = params['package_c_review_threshold']
    charge_c = params['package_c_review_charge']
    
    # Create the model
    model = gp.Model("Inventory_Promotion_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    # Quantities sold
    x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_a")
    x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_b")
    x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_c")
    
    # Campaign activation binaries
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")
    
    # Threshold review charge binaries
    z_b = model.addVar(vtype=GRB.BINARY, name="z_b")
    z_c = model.addVar(vtype=GRB.BINARY, name="z_c")
    
    # Objective Function: Maximize (Revenue - Activation Costs - Review Charges)
    revenue = (price_a * x_a) + (price_b * x_b) + (price_c * x_c)
    activation_costs = (act_cost_a * y_a) + (act_cost_b * y_b) + (act_cost_c * y_c)
    review_charges = (charge_b * z_b) + (charge_c * z_c)
    model.setObjective(revenue - activation_costs - review_charges, GRB.MAXIMIZE)
    
    # Inventory Constraints
    model.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inv, "Shirts_Inventory")
    model.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inv, "Pants_Inventory")
    
    # Labor Constraint
    model.addConstr(labor_a * x_a + labor_b * x_b + labor_c * x_c <= labor_inv, "Labor_Constraint")
    
    # Campaign Launch Links (Linking x to y with big M and minimum requirements)
    model.addConstr(x_a <= bigM_a * y_a, "Link_A_Upper")
    model.addConstr(x_a >= min_a * y_a, "Link_A_Lower")
    
    model.addConstr(x_b <= bigM_b * y_b, "Link_B_Upper")
    model.addConstr(x_b >= min_b * y_b, "Link_B_Lower")
    
    model.addConstr(x_c <= bigM_c * y_c, "Link_C_Upper")
    model.addConstr(x_c >= min_c * y_c, "Link_C_Lower")
    
    # Review Charge "Gate" Constraints (Linking x to z via threshold)
    # If x_b > thresh_b, then z_b must be 1.
    model.addConstr(x_b <= thresh_b + (bigM_b - thresh_b) * z_b, "Threshold_B")
    
    # If x_c > thresh_c, then z_c must be 1.
    model.addConstr(x_c <= thresh_c + (bigM_c - thresh_c) * z_c, "Threshold_C")
    
    # Solve
    model.optimize()
    
    # Output the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_optimization()
