import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    # Define paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')

    # Read CSVs
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    # Parse Parameters
    def get_param(name):
        return df_params.loc[df_params['Parameter_Name'] == name, 'Value'].values[0]

    min_profit_limit = float(get_param('min_weekly_profit'))
    min_a = float(get_param('min_type_a_production'))
    insp_a_M = float(get_param('insp_a_M'))
    insp_b_M = float(get_param('insp_b_M'))
    insp_a_E = float(get_param('insp_a_E'))
    insp_b_E = float(get_param('insp_b_E'))
    cap_ext = float(get_param('cap_ext'))
    cost_insp_M = float(get_param('cost_insp_M'))
    cost_insp_E = float(get_param('cost_insp_E'))
    cost_ext = float(get_param('cost_ext'))
    mode_fee_M = float(get_param('mode_fee_M'))
    mode_fee_E = float(get_param('mode_fee_E'))
    risk_penalty_M = float(get_param('risk_penalty_M'))
    cost_insp_weight = float(get_param('cost_insp_weight'))
    planning_horizon = int(float(get_param('planning_horizon_weeks')))
    idle_tolerance = float(get_param('idle_tolerance'))

    # Parse Table 1
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]

    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])

    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])

    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp = float(row_cap['Inspection_hours_per_unit'])

    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])
    cost_asm = float(row_cost['Assembly_hours_per_unit'])

    # Initialize Gurobi model
    model = gp.Model("Motorcycle_Planning")
    model.setParam('OutputFlag', 0)

    weeks = range(planning_horizon)

    # Decision Variables
    x_A = model.addVars(weeks, vtype=GRB.INTEGER, lb=min_a, name="x_A")
    x_B = model.addVars(weeks, vtype=GRB.INTEGER, lb=0, name="x_B")
    y_M = model.addVars(weeks, vtype=GRB.BINARY, name="y_M")
    y_E = model.addVars(weeks, vtype=GRB.BINARY, name="y_E")
    I = model.addVars(weeks, vtype=GRB.CONTINUOUS, lb=0, ub=cap_insp, name="I")
    E = model.addVars(weeks, vtype=GRB.CONTINUOUS, lb=0, ub=cap_ext, name="E")
    profit = model.addVars(weeks, vtype=GRB.CONTINUOUS, lb=-GRB.INFINITY, name="profit")

    # Constraints for each week
    for w in weeks:
        # Exactly one inspection protocol per week
        model.addConstr(y_M[w] + y_E[w] == 1)
        
        # Weekly Production Capacity Constraints
        model.addConstr(mfg_a * x_A[w] + mfg_b * x_B[w] <= cap_mfg)
        model.addConstr(asm_a * x_A[w] + asm_b * x_B[w] <= cap_asm)
        
        # Accounting & Protocol Specific Constraints
        rev_w = price_a * x_A[w] + price_b * x_B[w]
        prod_cost_w = (mfg_a * cost_mfg + asm_a * cost_asm) * x_A[w] + (mfg_b * cost_mfg + asm_b * cost_asm) * x_B[w]
        
        # Manual Mode Indicator
        model.addGenConstrIndicator(y_M[w], True, I[w] == insp_a_M * x_A[w] + insp_b_M * x_B[w])
        model.addGenConstrIndicator(y_M[w], True, E[w] == 0)
        model.addGenConstrIndicator(y_M[w], True, profit[w] == rev_w - prod_cost_w - (cost_insp_M * I[w] + mode_fee_M))
        
        # Enhanced Mode Indicator
        model.addGenConstrIndicator(y_E[w], True, I[w] + E[w] == insp_a_E * x_A[w] + insp_b_E * x_B[w])
        model.addGenConstrIndicator(y_E[w], True, profit[w] == rev_w - prod_cost_w - (cost_insp_E * I[w] + cost_ext * E[w] + mode_fee_E))
        
        # Weekly Profit Minimum Requirement
        model.addConstr(profit[w] >= min_profit_limit)

    # First Priority: Minimize Total Weighted Idle Time + Total Risk Penalty
    # Weighted Idle Cost = CostMfg * IdleMfg + CostAsm * IdleAsm + WeightInsp * IdleInsp
    idle_mfg_total = gp.quicksum(cost_mfg * (cap_mfg - (mfg_a * x_A[w] + mfg_b * x_B[w])) for w in weeks)
    idle_asm_total = gp.quicksum(cost_asm * (cap_asm - (asm_a * x_A[w] + asm_b * x_B[w])) for w in weeks)
    idle_insp_total = gp.quicksum(cost_insp_weight * (cap_insp - I[w]) for w in weeks)
    total_risk_penalty = gp.quicksum(risk_penalty_M * y_M[w] for w in weeks)
    
    obj1 = idle_mfg_total + idle_asm_total + idle_insp_total + total_risk_penalty
    
    model.setObjective(obj1, GRB.MINIMIZE)
    model.optimize()
    
    min_obj1_val = model.objVal

    # Second Priority: Maximize Total Production Profit over Tied Plans
    # Ensure Objective 1 is held within tolerance
    model.addConstr(obj1 <= min_obj1_val + idle_tolerance)
    
    total_two_week_profit = gp.quicksum(profit[w] for w in weeks)
    model.setObjective(total_two_week_profit, GRB.MAXIMIZE)
    model.optimize()

    # Output the optimal objective value (Total Two-Week Profit)
    print(f"FINAL_OBJ_VALUE: {round(model.objVal, 4)}")

if __name__ == '__main__':
    solve()
