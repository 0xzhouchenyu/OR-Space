import gurobipy as gp
from gurobipy import GRB
import os
import csv

def solve():
    # Directory configuration
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv (monthly prices)
    months = []
    purchase_prices = {}
    selling_prices = {}
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            purchase_prices[m] = float(row['Purchase_Price_yuan_per_dan'])
            selling_prices[m] = float(row['Selling_Price_yuan_per_dan'])

    # Load general_parameters.csv (static business parameters)
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    # Create the Gurobi optimization model
    model = gp.Model("Grain_Trading_Optimization")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Decision variables for each month
    buy_reg = model.addVars(months, name="buy_reg", lb=0)
    buy_fast = model.addVars(months, name="buy_fast", lb=0, ub=params['buy_fast_capacity'])
    sell = model.addVars(months, name="sell", lb=0)
    stock = model.addVars(months, name="stock", lb=0, ub=params['warehouse_capacity'])
    cash = model.addVars(months, name="cash", lb=0) # Liquid funds at month-end
    credit = model.addVars(months, name="credit", lb=0, ub=params['credit_limit']) # Credit line usage at month-end

    # Extract general parameters
    initial_stock = params['initial_stock']
    initial_funds = params['initial_funds']
    interest_rate = params['monthly_interest_rate']
    premium = params['fast_purchase_premium_ratio']
    
    # Inventory requirements dictionary
    min_inv = {
        1: params['min_inventory_month_1'],
        2: params['min_inventory_month_2'],
        3: params['min_inventory_month_3']
    }

    # Quarterly Constraints
    for m in months:
        # State at start of current month m
        if m == 1:
            prev_stock = initial_stock
            prev_net = initial_funds # Net cash position at month 0 (initial funds)
        else:
            prev_stock = stock[m-1]
            prev_net = cash[m-1] - credit[m-1] # Net cash position at end of previous month
        
        # 1. Inventory Balance Constraint
        # New purchases (regular and fast) arrive in the same month.
        model.addConstr(stock[m] == prev_stock - sell[m] + buy_reg[m] + buy_fast[m], name=f"stock_bal_{m}")
        
        # 2. Sales Limit Constraint
        # Grain bought in month m can only be sold in next month (m+1) or later.
        # Thus, current month's sales cannot exceed previous month's ending stock.
        model.addConstr(sell[m] <= prev_stock, name=f"sell_limit_{m}")
        
        # 3. Minimum Inventory Constraint (Risk Control Policy)
        model.addConstr(stock[m] >= min_inv[m], name=f"min_inv_{m}")
        
        # 4. Financial Balance Constraint
        # NetBalance_m = NetBalance_{m-1} + Revenue_m - PurchaseCost_m - Interest_m
        # Interest is charged on end-of-month credit usage: Interest_m = credit_m * interest_rate
        # NetBalance_m = cash_m - credit_m
        # Combining these:
        # cash_m - credit_m = prev_net + Revenue_m - PurchaseCost_m - (credit_m * interest_rate)
        # Rearranging: cash_m - (1 - interest_rate) * credit_m = prev_net + Revenue_m - PurchaseCost_m
        
        revenue = sell[m] * selling_prices[m]
        purchase_cost = (buy_reg[m] * purchase_prices[m] + 
                         buy_fast[m] * purchase_prices[m] * (1 + premium))
        
        model.addConstr(cash[m] - (1 - interest_rate) * credit[m] == prev_net + revenue - purchase_cost, 
                        name=f"fin_bal_{m}")

    # 5. Final Inventory Constraint (End-of-Quarter requirement)
    # The requirement asks for at least end_of_quarter_inventory by March end.
    model.addConstr(stock[months[-1]] >= params['end_of_quarter_inventory'], name="final_inv_target")

    # Commercial Objective
    # Maximize total profit over three months: Final Net Balance - Initial Net Balance
    # Objective = (Final Cash - Final Debt) - Initial Funds
    model.setObjective((cash[months[-1]] - credit[months[-1]]) - initial_funds, GRB.MAXIMIZE)

    # Execute the optimization
    model.optimize()

    # Reporting the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Fallback if no solution found (should not happen with given constraints)
        print("FINAL_OBJ_VALUE: 0.0")

if __name__ == "__main__":
    solve()
