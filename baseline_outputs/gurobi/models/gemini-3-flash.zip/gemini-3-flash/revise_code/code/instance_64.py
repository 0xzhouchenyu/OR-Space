import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Define directories
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load candidate data from table_1.csv
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            })
    
    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Extract parameters
    budget = params['company_budget']
    max_employees = int(params['max_employees'])
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_gj = int(params['max_one_candidate_g_j'])
    lead_premium = params['lead_premium']
    min_leads = int(params['min_leads'])
    mentor_bonus = params['mentor_bonus']
    max_pairs = int(params['max_pairs'])
    
    # Create optimization model
    model = gp.Model("HiringOptimizationRevised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[c, role] is binary: candidate c is hired in role 'Lead' or 'Engineer'
    roles = ['Lead', 'Engineer']
    x = model.addVars([c['name'] for c in candidates], roles, vtype=GRB.BINARY, name="x")
    
    # y[c] is binary: candidate c is hired (redundant but useful for constraints)
    y = model.addVars([c['name'] for c in candidates], vtype=GRB.BINARY, name="y")
    
    # n_pairs is the number of mentorship pairs counted
    n_pairs = model.addVar(vtype=GRB.INTEGER, name="n_pairs")
    
    # Constraints
    # 1. Each hired candidate must have exactly one role
    for c in candidates:
        model.addConstr(y[c['name']] == gp.quicksum(x[c['name'], r] for r in roles), name=f"RoleAssignment_{c['name']}")
    
    # 2. Team size constraint
    model.addConstr(gp.quicksum(y[c['name']] for c in candidates) <= max_employees, name="MaxEmployees")
    
    # 3. Minimum skill level constraint
    model.addConstr(gp.quicksum(c['skill'] * y[c['name']] for c in candidates) >= min_skill, name="MinSkill")
    
    # 4. Minimum project management experience constraint
    model.addConstr(gp.quicksum(c['pm_exp'] * y[c['name']] for c in candidates) >= min_pm_exp, name="MinPMExp")
    
    # 5. Hiring conflict constraint (G and J)
    model.addConstr(y['G'] + y['J'] <= max_gj, name="MaxOneGJ")
    
    # 6. Minimum number of Leads
    n_leads = gp.quicksum(x[c['name'], 'Lead'] for c in candidates)
    model.addConstr(n_leads >= min_leads, name="MinLeads")
    
    # 7. Mentorship pairs logic
    n_engineers = gp.quicksum(x[c['name'], 'Engineer'] for c in candidates)
    model.addConstr(n_pairs <= n_leads, name="PairsLeadsLimit")
    model.addConstr(n_pairs <= n_engineers, name="PairsEngineersLimit")
    model.addConstr(n_pairs <= max_pairs, name="PairsMaxLimit")
    
    # Objective: Minimize net hiring cost
    # Net cost = Base Salaries + Lead Premiums - Mentor Bonus
    base_salaries = gp.quicksum(c['salary'] * y[c['name']] for c in candidates)
    lead_premiums = gp.quicksum(lead_premium * x[c['name'], 'Lead'] for c in candidates)
    bonus_total = mentor_bonus * n_pairs
    net_cost = base_salaries + lead_premiums - bonus_total
    
    model.setObjective(net_cost, GRB.MINIMIZE)
    
    # 8. Budget constraint (on net hiring cost)
    model.addConstr(net_cost <= budget, name="Budget")
    
    # Solve
    model.optimize()
    
    # Print results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
