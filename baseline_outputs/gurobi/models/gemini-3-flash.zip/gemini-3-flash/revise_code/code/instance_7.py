import gurobipy as gp
from gurobipy import GRB
import os
import csv

def solve():
    # Define paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")

    # Load supply from table_1.csv
    supply = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            supply[row['Warehouse']] = int(row['Empty_Containers'])

    # Load demand from table_2.csv
    demand = {}
    with open(os.path.join(data_dir, 'table_2.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand[row['Port']] = int(row['Container_Demand'])

    # Load distances from table_3.csv
    distances = {}
    with open(os.path.join(data_dir, 'table_3.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Warehouse']
            for p in demand.keys():
                distances[w, p] = float(row[p])

    # Load general parameters from general_parameters.csv
    gen_params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            gen_params[row['Parameter_Name']] = float(row['Value'])

    # Load shortage penalties from shortage_penalty.csv
    shortage_charge = {}
    grace_containers = {}
    recovery_fee = {}
    with open(os.path.join(data_dir, 'shortage_penalty.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row['Port']
            shortage_charge[p] = float(row['Shortage_Charge'])
            grace_containers[p] = int(row['Grace_Containers'])
            recovery_fee[p] = float(row['Recovery_Fee'])

    # Model initialization
    model = gp.Model("Container_Transportation_Optimization")
    model.setParam('OutputFlag', 0)

    # Variables
    warehouses = list(supply.keys())
    ports = list(demand.keys())
    
    # x[w, p] is number of containers sent from warehouse w to port p
    x = model.addVars(warehouses, ports, vtype=GRB.INTEGER, name="x")
    # s[p] is the shortage at port p
    s = model.addVars(ports, vtype=GRB.INTEGER, name="s")
    # y[p] binary variable: 1 if port p shortage > grace_containers[p]
    y = model.addVars(ports, vtype=GRB.BINARY, name="y")
    # z binary variable: 1 if combined Adriatic shortage > adriatic_pool_shortage_trigger
    z = model.addVar(vtype=GRB.BINARY, name="z")

    # Objective function components
    # 1. Transport cost (cost_per_km is per container per km)
    cost_per_km = gen_params['cost_per_km']
    transport_cost = gp.quicksum(x[w, p] * distances[w, p] * cost_per_km for w in warehouses for p in ports)
    
    # 2. Port-specific shortage costs: disruption charge + local recovery fee if above grace band
    port_shortage_costs = gp.quicksum(s[p] * shortage_charge[p] + y[p] * recovery_fee[p] for p in ports)
    
    # 3. Adriatic regional recovery fee
    adriatic_ports = ['Venice', 'Ancona', 'Bari']
    adriatic_recovery_fee = z * gen_params['adriatic_pool_recovery_fee']
    
    # Total objective
    model.setObjective(transport_cost + port_shortage_costs + adriatic_recovery_fee, GRB.MINIMIZE)

    # Constraints
    # Supply constraint: do not exceed warehouse capacity
    for w in warehouses:
        model.addConstr(gp.quicksum(x[w, p] for p in ports) <= supply[w], name=f"Supply_{w}")

    # Demand/Shortage relation
    for p in ports:
        model.addConstr(gp.quicksum(x[w, p] for w in warehouses) + s[p] == demand[p], name=f"Demand_{p}")
        
        # Local recovery desk constraint: y[p] = 1 if s[p] > grace_containers[p]
        # s[p] - grace_containers[p] <= M * y[p] (M = demand[p])
        model.addConstr(s[p] - grace_containers[p] <= demand[p] * y[p], name=f"Port_Recovery_{p}")

    # Adriatic pool recovery desk constraint: z = 1 if sum(s_adriatic) > trigger
    adriatic_shortage = gp.quicksum(s[p] for p in adriatic_ports)
    trigger = gen_params['adriatic_pool_shortage_trigger']
    m_adriatic = sum(demand[p] for p in adriatic_ports)
    model.addConstr(adriatic_shortage - trigger <= m_adriatic * z, name="Adriatic_Recovery")

    # Solve the model
    model.optimize()

    # Output results
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
