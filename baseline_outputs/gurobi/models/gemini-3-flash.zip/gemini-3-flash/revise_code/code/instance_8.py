import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Define data directory and file paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    # Read general_parameters.csv
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
            
    # Read table_1.csv
    workers = []
    tasks = ['A', 'B', 'C', 'D']
    time_cost = {}
    fixed_cost = {}
    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Worker'].strip()
            workers.append(w)
            fixed_cost[w] = float(row['Fixed_Cost'])
            for t in tasks:
                time_cost[(w, t)] = float(row[t])
                
    # Create the optimization model
    model = gp.Model("Assignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[w, t] = 1 if worker w is assigned to task t
    x = model.addVars(workers, tasks, vtype=GRB.BINARY, name="x")
    # y[w] = 1 if worker w is selected for any task
    y = model.addVars(workers, vtype=GRB.BINARY, name="y")
    # z_III_V = 1 if both Worker III and Worker V are selected
    z_III_V = model.addVar(vtype=GRB.BINARY, name="z_III_V")
    # z_II_V = 1 if both Worker II and Worker V are selected
    z_II_V = model.addVar(vtype=GRB.BINARY, name="z_II_V")
    
    # Constraints
    # Each task must be assigned to exactly one worker
    for t in tasks:
        model.addConstr(gp.quicksum(x[w, t] for w in workers) == 1)
        
    # Each worker can be assigned to at most one task, and y[w] tracks usage
    for w in workers:
        model.addConstr(gp.quicksum(x[w, t] for t in tasks) == y[w])
        
    # Exactly 4 workers must be assigned (implied by 4 tasks, but explicit for clarity)
    model.addConstr(gp.quicksum(y[w] for w in workers) == 4)
    
    # Pairing penalty logic for Workers III and V
    model.addConstr(z_III_V >= y['III'] + y['V'] - 1)
    
    # Pairing penalty logic for Workers II and V
    model.addConstr(z_II_V >= y['II'] + y['V'] - 1)
    
    # Objective: minimize total cost (time + fixed costs + pairing penalties)
    obj = gp.quicksum(time_cost[w, t] * x[w, t] for w in workers for t in tasks) \
          + gp.quicksum(fixed_cost[w] * y[w] for w in workers) \
          + params['shared_temp_handoff_cost'] * z_III_V \
          + params['worker_II_V_pair_fee'] * z_II_V
          
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
