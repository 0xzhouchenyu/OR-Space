import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_beverage_production():
    # Define data directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')

    # Load table_1.csv
    weeks_data = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks_data.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })

    # Load general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    # Extract parameters
    storage_cost = params['storage_cost_per_thousand_boxes']
    week2_push_threshold = params['week2_push_threshold']
    week3_capacity_loss = params['week3_capacity_loss_after_week2_push']
    week2_microclean_threshold = params['week2_microclean_threshold']
    week2_microclean_fee = params['week2_microclean_fee']
    
    n_weeks = len(weeks_data)

    # Create Gurobi model
    model = gp.Model("Beverage_Production_Planning")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[t] = production in week t (in thousand boxes)
    # s[t] = inventory at end of week t (in thousand boxes)
    x = model.addVars(n_weeks, lb=0, name="x")
    s = model.addVars(n_weeks, lb=0, name="s")
    
    # Binary variables for Week 2 logic
    y_clean = model.addVar(vtype=GRB.BINARY, name="y_clean")
    y_push = model.addVar(vtype=GRB.BINARY, name="y_push")

    # Objective: minimize total production cost + storage cost + micro-clean fee
    # Note: fixed_setup_cost is in CSV but not mentioned in the brief's objective description
    production_cost_expr = gp.quicksum(weeks_data[t]['cost'] * x[t] for t in range(n_weeks))
    storage_cost_expr = gp.quicksum(storage_cost * s[t] for t in range(n_weeks))
    microclean_cost_expr = week2_microclean_fee * y_clean
    
    model.setObjective(production_cost_expr + storage_cost_expr + microclean_cost_expr, GRB.MINIMIZE)

    # Constraints: inventory balance
    for t in range(n_weeks):
        demand_t = weeks_data[t]['demand']
        if t == 0:
            model.addConstr(x[t] - s[t] == demand_t, name=f"balance_week_{t+1}")
        else:
            model.addConstr(s[t-1] + x[t] - s[t] == demand_t, name=f"balance_week_{t+1}")

    # Constraints: capacity
    for t in range(n_weeks):
        cap_t = weeks_data[t]['capacity']
        if t == 0: # Week 1
            model.addConstr(x[t] <= cap_t, name=f"capacity_week_{t+1}")
        elif t == 1: # Week 2
            model.addConstr(x[t] <= cap_t, name=f"capacity_week_{t+1}")
            # Logic for micro-clean fee (x2 > 30)
            model.addConstr(x[t] <= week2_microclean_threshold + (cap_t - week2_microclean_threshold) * y_clean, name="microclean_logic")
            # Logic for Week 3 capacity loss (x2 > 35)
            model.addConstr(x[t] <= week2_push_threshold + (cap_t - week2_push_threshold) * y_push, name="push_logic")
        elif t == 2: # Week 3
            model.addConstr(x[t] <= cap_t - week3_capacity_loss * y_push, name=f"capacity_week_{t+1}")
        else: # Week 4
            model.addConstr(x[t] <= cap_t, name=f"capacity_week_{t+1}")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimal solution not found.")

if __name__ == "__main__":
    solve_beverage_production()
