import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Set the directory for the data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
            
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
            
    # Unit conversions and parameter assignments
    # 200,000 m3 = 20 units of 10,000 m3
    max_storage_cap = float(params['max_storage_capacity']) / 10000.0  
    storage_cost_a = float(params['storage_cost_a'])
    storage_cost_b = float(params['storage_cost_b'])
    safety_level = float(params['safety_inventory_level_10k_m3'])
    terminal_value = float(params['terminal_inventory_value_per_10k_m3'])
    penalty_rate = float(params['over_purchase_penalty_cost_per_10k_m3'])
    
    # Model Setup
    model = gp.Model("Timber_Profit_Maximization")
    model.setParam('OutputFlag', 0)
    
    n = len(quarters)
    # x[i, j]: Amount purchased in quarter i and sold in quarter j (i <= j)
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
            
    # s[i]: Amount purchased in quarter i and held beyond Autumn (terminal inventory)
    s = {}
    for i in range(n):
        s[i] = model.addVar(lb=0, name=f"s_{i}")
        
    # i_excess: Helper variable to calculate penalty on terminal inventory above safety level
    i_excess = model.addVar(lb=0, name="i_excess")
    
    # Objective Components
    # 1. Total Sales Revenue
    revenue = gp.quicksum(sale_price[quarters[j]] * x[i, j] 
                          for i in range(n) for j in range(i, n))
    
    # 2. Total Purchase Cost
    purchase_cost = gp.quicksum(purchase_price[quarters[i]] * (gp.quicksum(x[i, j] for j in range(i, n)) + s[i]) 
                                for i in range(n))
    
    # 3. Storage Costs for timber sold within the season
    # Cost = (a + b * u) where u is quarters stored
    storage_cost_sold = gp.quicksum((storage_cost_a + storage_cost_b * (j - i)) * x[i, j]
                                    for i in range(n) for j in range(i + 1, n))
    
    # 4. Storage Costs for timber carried as terminal inventory
    # Timber s[i] is held from quarter i until the start of the next cycle
    # Boundaries crossed: Winter (3), Spring (2), Summer (1), Autumn (0) to end of Autumn
    storage_cost_terminal = gp.quicksum((storage_cost_a + storage_cost_b * (4 - i)) * s[i]
                                        for i in range(n))
    
    # 5. Terminal Inventory Credit
    total_terminal_inv = gp.quicksum(s[i] for i in range(n))
    terminal_inv_credit = terminal_value * total_terminal_inv
    
    # 6. Over-purchase Penalty
    penalty = penalty_rate * i_excess
    
    # Objective function
    model.setObjective(revenue + terminal_inv_credit - purchase_cost - storage_cost_sold - storage_cost_terminal - penalty, GRB.MAXIMIZE)
    
    # Constraints
    # 1. Quarterly Sales Constraints
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(j + 1)) <= max_sales[quarters[j]])
        
    # 2. Quarterly Purchase Ceiling Constraints
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(i, n)) + s[i] <= max_purchase[quarters[i]])
        
    # 3. Physical Storage Capacity Constraints (End of Winter, Spring, Summer)
    for t in range(n - 1): # t=0 (W), 1 (Sp), 2 (Su)
        # Inventory at end of t = timber bought now/previously that will be sold in t+1 or later, or held as terminal
        inv_end_of_quarter = gp.quicksum(x[i, j] for i in range(t + 1) for j in range(t + 1, n)) + \
                             gp.quicksum(s[i] for i in range(t + 1))
        model.addConstr(inv_end_of_quarter <= max_storage_cap)
        
    # 4. Year-end Resilience/Safety Requirement
    model.addConstr(total_terminal_inv >= safety_level)
    
    # 5. Excess Inventory Logic
    model.addConstr(i_excess >= total_terminal_inv - safety_level)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # If no solution found with hard safety requirement, try without it or check feasibility
        pass

if __name__ == "__main__":
    solve()
