import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # File paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    table1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')

    # Load processing costs from table_1.csv
    costs = {}
    parts = []
    machines = []
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p) for p in header[1:]]
        for row in reader:
            m = row[0].strip()
            machines.append(m)
            for i, p in enumerate(parts):
                costs[m, p] = float(row[i+1])

    # Load general parameters from general_parameters.csv
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    # Model initialization
    model = gp.Model("MachineAssignment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[m, p] = 1 if part p is assigned to machine m
    x = model.addVars(machines, parts, vtype=GRB.BINARY, name="x")
    # y[m] = 1 if machine m is used (any part assigned to it)
    y = model.addVars(machines, vtype=GRB.BINARY, name="y")
    # z[m] = 1 if machine m processes more than the threshold number of parts
    z = model.addVars(machines, vtype=GRB.BINARY, name="z")

    # Objective function: minimize processing costs + setup costs + overtime penalties
    setup_costs = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    overtime_penalty = params['overtime_penalty']
    
    obj = gp.quicksum(costs[m, p] * x[m, p] for m in machines for p in parts) + \
          gp.quicksum(setup_costs[m] * y[m] for m in machines) + \
          gp.quicksum(overtime_penalty * z[m] for m in machines)
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    # 1. Each part must be assigned to exactly one machine
    for p in parts:
        model.addConstr(gp.quicksum(x[m, p] for m in machines) == 1)

    # 2. Linking y to x: if any part is on machine m, y[m] must be 1
    for m in machines:
        for p in parts:
            model.addConstr(x[m, p] <= y[m])

    # 3. Constraint 2: Part 1 and 2 logic
    # If part 1 on A, part 2 on B or C; if part 1 on B or C, part 2 on A.
    # This is equivalent to: x[A, 1] + x[A, 2] = 1
    model.addConstr(x['A', 1] + x['A', 2] == 1)

    # 4. Constraint 3: Fixed assignments
    model.addConstr(x['A', 3] == 1)
    model.addConstr(x['B', 4] == 1)
    model.addConstr(x['C', 5] == 1)

    # 5. Constraint 4: Machine C limit
    max_C = int(params['max_parts_on_C'])
    model.addConstr(gp.quicksum(x['C', p] for p in parts) <= max_C)

    # 6. Constraint 5: Overtime penalty logic
    # If sum(x[m, p]) > threshold, then z[m] = 1
    threshold = int(params['overtime_threshold'])
    num_parts = len(parts)
    for m in machines:
        model.addConstr(gp.quicksum(x[m, p] for p in parts) <= threshold + (num_parts - threshold) * z[m])

    # Solve the optimization problem
    model.optimize()

    # Output the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
