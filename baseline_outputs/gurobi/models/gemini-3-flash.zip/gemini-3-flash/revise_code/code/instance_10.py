import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_coverage_data(data_dir):
    """Load the coverage data from table_1.csv."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            # The covered areas are in the second column onwards, but they might be split across columns
            # because the CSV has commas within the coverage list
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    
    return areas, coverage

def load_general_parameters(data_dir):
    """Load general parameters from general_parameters.csv."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    return params

def main():
    # Setup data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load data
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    # Extract parameters
    small_cost = float(params['small_cost'])
    large_cost = float(params['large_cost'])
    small_cap_areas = int(params['small_cap_areas'])
    max_large_stores = int(params['max_large_stores'])
    minimum_neighborhood_counters = int(params['minimum_neighborhood_counters'])
    small_store_counter_credit = float(params['small_store_counter_credit'])
    
    # Create Gurobi model
    model = gp.Model("MinChainStores")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_S[j] = 1 if a Small-format store is built at area j
    x_S = model.addVars(areas, vtype=GRB.BINARY, name="x_S")
    # x_L[j] = 1 if a Large-format store is built at area j
    x_L = model.addVars(areas, vtype=GRB.BINARY, name="x_L")
    
    # y_S[i, j] = 1 if area i is served by a Small-format store at area j
    y_S_keys = []
    for j in areas:
        for i in coverage.get(j, set()):
            if i in areas:
                y_S_keys.append((i, j))
    y_S = model.addVars(y_S_keys, vtype=GRB.BINARY, name="y_S")
    
    # Objective: Minimize total cost
    model.setObjective(
        gp.quicksum(small_cost * x_S[j] for j in areas) +
        gp.quicksum(large_cost * x_L[j] for j in areas),
        GRB.MINIMIZE
    )
    
    # Constraints
    
    # 1. Coverage: Each area i must be covered by at least one store
    for i in areas:
        # Area i is covered if it's served by some Small store j OR if it's in the radius of some Large store j
        model.addConstr(
            gp.quicksum(y_S[i, j] for j in areas if (i, j) in y_S) +
            gp.quicksum(x_L[j] for j in areas if i in coverage.get(j, set())) >= 1,
            name=f"Cover_{i}"
        )
        
    # 2. Small store capacity: A Small store at j can serve at most small_cap_areas
    for j in areas:
        model.addConstr(
            gp.quicksum(y_S[i, j] for i in coverage.get(j, set()) if (i, j) in y_S) <= small_cap_areas * x_S[j],
            name=f"SmallCap_{j}"
        )
        
    # 3. One store type per location
    for j in areas:
        model.addConstr(x_S[j] + x_L[j] <= 1, name=f"OneType_{j}")
        
    # 4. Maximum number of Large stores allowed
    model.addConstr(
        gp.quicksum(x_L[j] for j in areas) <= max_large_stores,
        name="MaxLarge"
    )
    
    # 5. Minimum number of neighborhood counters (Small stores)
    model.addConstr(
        gp.quicksum(x_S[j] * small_store_counter_credit for j in areas) >= minimum_neighborhood_counters,
        name="MinCounters"
    )
    
    # 6. Linking y_S and x_S (redundant but ensures consistency)
    for (i, j) in y_S_keys:
        model.addConstr(y_S[i, j] <= x_S[j], name=f"yS_xS_{i}_{j}")
        
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
