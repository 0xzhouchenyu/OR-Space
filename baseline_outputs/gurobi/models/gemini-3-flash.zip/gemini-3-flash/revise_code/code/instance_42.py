import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve():
    # File path
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    params = load_parameters(params_path)

    # Parameters
    a = params['a']
    m_off = params['m_offpeak']
    b = params['b']
    n_off = params['n_offpeak']
    k = params['k']
    d = params['d']
    c_off = params['c_offpeak']
    c_peak = params['c_peak']
    cap_off = params['cap_offpeak']
    cap_peak = params['cap_peak']
    m_peak = params['m_peak']
    n_peak = params['n_peak']
    f_off = params['f_offpeak']
    f_peak = params['f_peak']
    threshold = params['offpeak_cooldown_batch_threshold']
    fee = params['offpeak_cooldown_fee']

    # Model
    model = gp.Model("SteelFurnace")
    model.setParam('OutputFlag', 0)

    # Variables
    furnaces = [1, 2]
    methods = [1, 2]
    periods = ['offpeak', 'peak']
    
    # x[furnace, method, period] - number of batches
    x = model.addVars(furnaces, methods, periods, vtype=GRB.INTEGER, name="x")
    # y[furnace, period] - binary, 1 if furnace is used in period
    y = model.addVars(furnaces, periods, vtype=GRB.BINARY, name="y")
    # z[furnace] - binary, 1 if furnace exceeds off-peak batch threshold
    z = model.addVars(furnaces, vtype=GRB.BINARY, name="z")

    # Objective: Minimize total cost (fuel + fixed activation + cooldown fees)
    fuel_cost = gp.quicksum(
        (m_off if p == 'offpeak' else m_peak) * x[i, 1, p] +
        (n_off if p == 'offpeak' else n_peak) * x[i, 2, p]
        for i in furnaces for p in periods
    )
    fixed_cost = gp.quicksum(f_off * y[i, 'offpeak'] + f_peak * y[i, 'peak'] for i in furnaces)
    cooldown_cost = gp.quicksum(fee * z[i] for i in furnaces)
    
    model.setObjective(fuel_cost + fixed_cost + cooldown_cost, GRB.MINIMIZE)

    # Constraints
    # 1. Minimum production requirement
    model.addConstr(gp.quicksum(k * x[i, j, p] for i in furnaces for j in methods for p in periods) >= d)

    # 2. Furnace-Period Time & Fixed Cost Activation
    for i in furnaces:
        # Off-peak time constraint for furnace i
        model.addConstr(a * x[i, 1, 'offpeak'] + b * x[i, 2, 'offpeak'] <= c_off * y[i, 'offpeak'])
        # Peak time constraint for furnace i
        model.addConstr(a * x[i, 1, 'peak'] + b * x[i, 2, 'peak'] <= c_peak * y[i, 'peak'])

    # 3. Plant-Period Time Constraints
    # Total off-peak time across all furnaces
    model.addConstr(gp.quicksum(a * x[i, 1, 'offpeak'] + b * x[i, 2, 'offpeak'] for i in furnaces) <= cap_off)
    # Total peak time across all furnaces
    model.addConstr(gp.quicksum(a * x[i, 1, 'peak'] + b * x[i, 2, 'peak'] for i in furnaces) <= cap_peak)

    # 4. Cooldown Threshold Rule
    # If total off-peak batches in furnace i > threshold, z[i] must be 1
    for i in furnaces:
        # Max possible batches in off-peak is c_off / min(a,b) = 12 / 2 = 6. M=10 is sufficient.
        model.addConstr(x[i, 1, 'offpeak'] + x[i, 2, 'offpeak'] <= threshold + 10 * z[i])

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
