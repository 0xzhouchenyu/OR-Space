import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Define data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children_per_day = int(params['max_children_trip'])
    min_children_per_day = int(params['min_children_trip'])
    max_distinct_children = int(params['max_distinct_children_trip'])
    total_cost_budget = int(params['total_cost_budget'])
    bonus_saving = int(params['bonus_saving'])
    min_bob_days = int(params['min_bob_days'])
    
    # Read table_1 for children and costs
    children = []
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Child'].strip()
            cost = int(row['Cost'].strip())
            children.append(name)
            costs[name] = cost
            
    days = [1, 2]
    
    # Create the optimization model
    model = gp.Model("FamilyTrip")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[c, d] = 1 if child c attends on day d
    x = model.addVars(children, days, vtype=GRB.BINARY, name="x")
    # y[c] = 1 if child c attends at least one day
    y = model.addVars(children, vtype=GRB.BINARY, name="y")
    # z[c] = 1 if child c attends both days
    z = model.addVars(children, vtype=GRB.BINARY, name="z")
    
    # Objective: minimize total cost minus total bonus savings
    total_daily_cost = gp.quicksum(costs[c] * x[c, d] for c in children for d in days)
    total_bonus_saving = gp.quicksum(bonus_saving * z[c] for c in children)
    net_cost = total_daily_cost - total_bonus_saving
    model.setObjective(net_cost, GRB.MINIMIZE)
    
    # Constraints
    
    # 1. Headcount per day
    for d in days:
        model.addConstr(gp.quicksum(x[c, d] for c in children) >= min_children_per_day)
        model.addConstr(gp.quicksum(x[c, d] for c in children) <= max_children_per_day)
        
    # 2. Distinct children tracking and limit
    for c in children:
        for d in days:
            model.addConstr(y[c] >= x[c, d])
    model.addConstr(gp.quicksum(y[c] for c in children) <= max_distinct_children)
    
    # 3. Bonus tracking (attending both days)
    for c in children:
        model.addConstr(z[c] <= x[c, 1])
        model.addConstr(z[c] <= x[c, 2])
        # z[c] >= x[c, 1] + x[c, 2] - 1 is not strictly needed for minimization but good for completeness
        model.addConstr(z[c] >= x[c, 1] + x[c, 2] - 1)
        
    # 4. Bob's minimum attendance
    model.addConstr(gp.quicksum(x['Bob', d] for d in days) >= min_bob_days)
    
    # 5. Total cost budget
    model.addConstr(net_cost <= total_cost_budget)
    
    # 6. Relationship constraints (per day)
    for d in days:
        # Alice and Diana cannot both be taken
        model.addConstr(x['Alice', d] + x['Diana', d] <= 1)
        # Bob and Charlie cannot both be taken
        model.addConstr(x['Bob', d] + x['Charlie', d] <= 1)
        # Charlie must be accompanied by Diana
        model.addConstr(x['Charlie', d] <= x['Diana', d])
        # Diana must be accompanied by Ella
        model.addConstr(x['Diana', d] <= x['Ella', d])
        
    # 7. Availability constraints
    # Charlie can participate only on day 2
    model.addConstr(x['Charlie', 1] == 0)
    # Diana can participate only on day 2
    model.addConstr(x['Diana', 1] == 0)
    # Alice can participate only on day 1
    model.addConstr(x['Alice', 2] == 0)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
