import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_production_planning():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load demand forecast
    demand = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            demand[i] = float(row['Demand_Forecast'])
    
    T = len(demand)  # 6 months (January to June)
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
            
    # Parameter Extraction
    W0 = params['initial_workforce']
    I0 = params['initial_inventory']
    sp = params['sales_price']
    rmc = params['raw_material_cost']
    oc = params['outsourcing_cost']
    hc = params['inventory_holding_cost']
    bc = params['backorder_cost']
    lr = params['labor_requirement']
    rh = params['regular_labor_hours']
    rw = params['regular_wage']
    otl = params['overtime_hours_limit']
    ow = params['overtime_wage']
    hire_cost = params['hiring_cost']
    fire_cost = params['firing_cost']
    term_inv = params['terminal_inventory']
    term_bo = params['terminal_backorders']
    contract_min_units = params['contract_min_units']
    contract_bigM = params['contract_bigM']
    
    # Model Setup
    model = gp.Model("FoldableTableProductionOptimization")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    W = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="Workforce")
    H = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="Hired")
    F = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="Fired")
    Preg = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="Production_Regular")
    Pot = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="Production_Overtime")
    O = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="Outsourced")
    Inv = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="Inventory")
    B = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="Backorders")
    
    # Auxiliary variables for contract (April-June: index 3, 4, 5)
    # The requirement is Q_t = min(Preg_t, demand_t + B_t-1) >= contract_min_units
    Q = model.addVars(range(3, 6), lb=0, vtype=GRB.CONTINUOUS, name="Contract_Qualifying")
    z = model.addVars(range(3, 6), vtype=GRB.BINARY, name="Indicator_z")
    
    # Constraints
    for t in range(T):
        # Workforce balance logic
        if t == 0:
            model.addConstr(W[t] == W0 + H[t] - F[t], name=f"Workforce_Flow_{t}")
        else:
            model.addConstr(W[t] == W[t-1] + H[t] - F[t], name=f"Workforce_Flow_{t}")
        
        # Labor capacity constraints
        # Regular production limited by regular hours
        model.addConstr(Preg[t] * lr <= W[t] * rh, name=f"Regular_Labor_Capacity_{t}")
        # Overtime production limited by overtime hours limit
        model.addConstr(Pot[t] * lr <= W[t] * otl, name=f"Overtime_Labor_Capacity_{t}")
        
        # Inventory balance: Inv[t] - B[t] = Inv[t-1] - B[t-1] + Production + Outsourcing - Demand
        prev_inv = I0 if t == 0 else Inv[t-1]
        prev_b = 0 if t == 0 else B[t-1]
        model.addConstr(Inv[t] - B[t] == prev_inv - prev_b + Preg[t] + Pot[t] + O[t] - demand[t], name=f"Inventory_Flow_{t}")
        
        # Mid-horizon contract floor logic (April, May, June)
        if t in range(3, 6):
            # Qualifying quantity definition: Q[t] = min(Preg[t], demand[t] + B[t-1])
            # Linearization using big-M and binary indicators:
            model.addConstr(Q[t] <= Preg[t], name=f"Contract_Min_Bound_P_{t}")
            model.addConstr(Q[t] <= demand[t] + B[t-1], name=f"Contract_Min_Bound_D_{t}")
            model.addConstr(Q[t] >= Preg[t] - contract_bigM * (1 - z[t]), name=f"Contract_Linearize_1_{t}")
            model.addConstr(Q[t] >= demand[t] + B[t-1] - contract_bigM * z[t], name=f"Contract_Linearize_2_{t}")
            # The actual floor requirement
            model.addConstr(Q[t] >= contract_min_units, name=f"Contract_Floor_Constraint_{t}")
            
    # Terminal constraints
    model.addConstr(Inv[T-1] >= term_inv, name="Final_Stock_Requirement")
    model.addConstr(B[T-1] <= term_bo, name="Final_Backlog_Requirement")
    
    # Objective Function: Maximize Total Net Profit
    # Revenue = Price * total demand (since terminal backorders = 0, all demand is met)
    total_revenue = sp * sum(demand.values())
    
    # Component Costs
    material_cost = gp.quicksum(rmc * (Preg[t] + Pot[t]) for t in range(T))
    outsource_cost = gp.quicksum(oc * O[t] for t in range(T))
    holding_cost = gp.quicksum(hc * Inv[t] for t in range(T))
    backorder_cost_total = gp.quicksum(bc * B[t] for t in range(T))
    regular_labor_cost = gp.quicksum(rw * rh * W[t] for t in range(T))
    overtime_labor_cost = gp.quicksum(ow * (Pot[t] * lr) for t in range(T))
    hiring_cost_total = gp.quicksum(hire_cost * H[t] for t in range(T))
    firing_cost_total = gp.quicksum(fire_cost * F[t] for t in range(T))
    
    total_operating_cost = (material_cost + outsource_cost + holding_cost + backorder_cost_total +
                            regular_labor_cost + overtime_labor_cost + hiring_cost_total + firing_cost_total)
    
    model.setObjective(total_revenue - total_operating_cost, GRB.MAXIMIZE)
    
    # Execution
    model.optimize()
    
    # Final Result Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Fallback if the solver failed to reach optimality
        print(f"FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    solve_production_planning()

```
