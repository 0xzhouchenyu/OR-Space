import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def solve():
    # File paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    table1_path = os.path.join(data_dir, 'table_1.csv')

    # Load general parameters
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if row:
                params[row[0]] = row[1]

    # Extract relevant parameters
    truck_capacity = float(params['truck_capacity'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])
    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])
    
    # Handle depot coordinates format
    depot_coords_str = params['depot_coordinates'].strip('()"')
    if ',' in depot_coords_str:
        depot_x, depot_y = map(float, depot_coords_str.split(','))
    else:
        depot_x, depot_y = map(float, depot_coords_str.split())

    # Load customer data from table_1.csv
    customers = []
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            customers.append({
                'id': int(row['Customer_ID']),
                'x': float(row['Coordinates_X']),
                'y': float(row['Coordinates_Y']),
                'demand': float(row['Demand']),
                'tw_start': float(row['Time_Window_Start']),
                'tw_end': float(row['Time_Window_End']),
                'svc': float(row['Service_Duration']),
                'outsource_cost': float(row['Outsource_Cost']),
                'mandatory_external': int(row['Mandatory_External'])
            })

    # Prepare node indices: node 0 is the depot, others are customer IDs
    customer_ids = [c['id'] for c in customers]
    nodes = [0] + customer_ids
    
    # Dictionaries for node data
    coords = {0: (depot_x, depot_y)}
    demands = {0: 0}
    tw_start = {0: depot_tw_start}
    tw_end = {0: depot_tw_end}
    svc = {0: 0}
    outsource_cost = {}
    mandatory_external = {}
    
    for c in customers:
        idx = c['id']
        coords[idx] = (c['x'], c['y'])
        demands[idx] = c['demand']
        tw_start[idx] = c['tw_start']
        tw_end[idx] = c['tw_end']
        svc[idx] = c['svc']
        outsource_cost[idx] = c['outsource_cost']
        mandatory_external[idx] = c['mandatory_external']

    # Precalculate Euclidean distances between all nodes
    dist = {}
    for i in nodes:
        for j in nodes:
            dist[i, j] = math.sqrt((coords[i][0] - coords[j][0])**2 + (coords[i][1] - coords[j][1])**2)

    # Initialize Gurobi model
    model = gp.Model("VRPHTW_Revised")
    model.setParam('OutputFlag', 0)

    # Variables
    # x[i,j] = 1 if an in-house truck travels from node i to node j
    x = model.addVars(nodes, nodes, vtype=GRB.BINARY, name="x")
    # y[i] = 1 if customer i is outsourced
    y = model.addVars(customer_ids, vtype=GRB.BINARY, name="y")
    # t[i] = start time of service at node i
    t = model.addVars(nodes, lb=0, name="t")
    # u[i] = cumulative load on truck after servicing customer i
    u = model.addVars(customer_ids, lb=0, ub=truck_capacity, name="u")

    # Objective: Minimize Total In-house Travel Distance + Total Outsourcing Cost
    travel_cost = gp.quicksum(dist[i, j] * x[i, j] for i in nodes for j in nodes if i != j)
    total_outsource_cost = gp.quicksum(outsource_cost[i] * y[i] for i in customer_ids)
    model.setObjective(travel_cost + total_outsource_cost, GRB.MINIMIZE)

    # Constraints
    # 1. Outsourcing and node visit consistency
    for i in customer_ids:
        # Mandatory outsourcing rule
        if mandatory_external[i] == 1:
            model.addConstr(y[i] == 1)
        # Every customer must either be part of a truck route or outsourced
        model.addConstr(gp.quicksum(x[j, i] for j in nodes if j != i) == 1 - y[i])
        model.addConstr(gp.quicksum(x[i, j] for j in nodes if j != i) == 1 - y[i])

    # 2. In-house fleet constraints
    model.addConstr(gp.quicksum(x[0, j] for j in customer_ids) <= inhouse_truck_limit)
    model.addConstr(gp.quicksum(x[0, j] for j in customer_ids) == gp.quicksum(x[i, 0] for i in customer_ids))

    # 3. Time Windows and hard delivery deadlines
    M_time = 2000  # Large enough constant for Big-M time constraints
    model.addConstr(t[0] == depot_tw_start) # Start from depot at depot opening time
    for i in nodes:
        model.addConstr(t[i] >= tw_start[i])
        model.addConstr(t[i] <= tw_end[i])
    
    for i in nodes:
        for j in customer_ids:
            if i != j:
                # Travel from i to customer j
                model.addConstr(t[i] + svc[i] + dist[i, j] <= t[j] + M_time * (1 - x[i, j]))
        if i != 0:
            # Travel from customer i back to depot
            model.addConstr(t[i] + svc[i] + dist[i, 0] <= depot_tw_end + M_time * (1 - x[i, 0]))

    # 4. Capacity Constraints and Subtour Elimination (MTZ)
    for i in customer_ids:
        model.addConstr(u[i] >= demands[i])
        for j in customer_ids:
            if i != j:
                model.addConstr(u[j] >= u[i] + demands[j] - truck_capacity * (1 - x[i, j]))

    # No self-loops
    for i in nodes:
        model.addConstr(x[i, i] == 0)

    # Optimize
    model.optimize()

    # Output final objective value
    if model.SolCount > 0:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
