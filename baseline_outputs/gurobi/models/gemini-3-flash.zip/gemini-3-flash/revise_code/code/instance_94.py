import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define data directory and load parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = {}
    
    # Load parameters from general_parameters.csv
    file_path = os.path.join(data_dir, 'general_parameters.csv')
    with open(file_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Create a Gurobi optimization model
    model = gp.Model("Oil_Blending_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables for crude oil blending
    # a1, b1: Crude A and B used to produce Gasoline Type I
    # a2, b2: Crude A and B used to produce Gasoline Type II
    a1 = model.addVar(lb=0, name="a1")
    a2 = model.addVar(lb=0, name="a2")
    b1 = model.addVar(lb=0, name="b1")
    b2 = model.addVar(lb=0, name="b2")

    # Tiered market purchase variables for crude A
    p1 = model.addVar(lb=0, ub=500, name="purchase_tier1") # First 500t
    p2 = model.addVar(lb=0, ub=500, name="purchase_tier2") # Next 500t
    p3 = model.addVar(lb=0, ub=500, name="purchase_tier3") # Remaining up to 500t (total 1500)
    
    # Binary variables to enforce the tiered purchase blocks
    y1 = model.addVar(vtype=GRB.BINARY, name="y1") # 1 if first tier is full
    y2 = model.addVar(vtype=GRB.BINARY, name="y2") # 1 if second tier is full
    
    # Binary variables for commercial thresholds
    z_II = model.addVar(vtype=GRB.BINARY, name="z_II") # 1 if Type II price lift is triggered
    z_rebate = model.addVar(vtype=GRB.BINARY, name="z_rebate") # 1 if bulk rebate is triggered

    # Linearization variable for Type II revenue lift (x2 * z_II)
    xII_lift = model.addVar(lb=0, name="xII_lift")

    # Define aggregate terms
    total_output_I = a1 + b1
    total_output_II = a2 + b2
    total_output_gasoline = total_output_I + total_output_II
    total_A_purchased = p1 + p2 + p3

    # 1. Blending proportion requirements (minimum crude A share)
    model.addConstr(a1 >= (params['min_proportion_crude_A_type_I'] / 100.0) * total_output_I)
    model.addConstr(a2 >= (params['min_proportion_crude_A_type_II'] / 100.0) * total_output_II)

    # 2. Crude oil supply constraints (inventory + purchases)
    model.addConstr(a1 + a2 <= params['inventory_crude_A'] + total_A_purchased)
    model.addConstr(b1 + b2 <= params['inventory_crude_B'])
    
    # Maximum market purchase constraint
    model.addConstr(total_A_purchased <= params['max_purchase_crude_A'])

    # 3. Tiered purchasing ordering constraints
    # y1=1 implies p1=500 and allows p2>0. y2=1 implies p2=500 and allows p3>0.
    model.addConstr(p1 >= 500 * y1)
    model.addConstr(p2 <= 500 * y1)
    model.addConstr(p2 >= 500 * y2)
    model.addConstr(p3 <= 500 * y2)

    # 4. Plant capacity and throughput constraints
    model.addConstr(total_output_gasoline <= params['processing_capacity'])
    model.addConstr(total_output_gasoline >= params['min_total_gasoline_output'])

    # 5. Type II revenue lift logic
    # The lift is only received if Type II output reaches the contract threshold
    model.addConstr(total_output_II >= params['type_II_contract_threshold'] * z_II)
    # Linearizing xII_lift = total_output_II if z_II == 1, else 0
    model.addConstr(xII_lift <= total_output_II)
    model.addConstr(xII_lift <= params['processing_capacity'] * z_II)
    model.addConstr(xII_lift >= total_output_II - params['processing_capacity'] * (1 - z_II))

    # 6. Bulk purchase rebate logic
    # The fixed rebate is received if total crude A purchase reaches the rebate threshold
    model.addConstr(total_A_purchased >= params['bulk_purchase_rebate_threshold'] * z_rebate)

    # 7. Objective Function: Maximize Profit
    # Profit = Revenue (incl. lift) - Purchase Costs - Processing Costs + Bulk Rebate
    revenue = (params['selling_price_type_I'] * total_output_I + 
               params['selling_price_type_II'] * total_output_II + 
               params['type_II_price_lift'] * xII_lift)
    
    purchase_cost = (params['market_price_crude_A_tier_1'] * p1 + 
                     params['market_price_crude_A_tier_2'] * p2 + 
                     params['market_price_crude_A_tier_3'] * p3)
    
    processing_cost = params['processing_cost_per_ton'] * total_output_gasoline
    
    rebate = params['bulk_purchase_rebate'] * z_rebate

    model.setObjective(revenue - purchase_cost - processing_cost + rebate, GRB.MAXIMIZE)

    # Solve the problem
    model.optimize()

    # Output the optimal objective value
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # If no feasible solution is found (should not happen with these parameters)
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
