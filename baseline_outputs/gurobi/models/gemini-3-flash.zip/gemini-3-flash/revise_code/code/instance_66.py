import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    # Read toy-specific data (Manufacturing Labor, Inspection Hours, Profit)
    toys = []
    try:
        with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                toys.append({
                    'type': row['Toy_Type'],
                    'labor': float(row['Manufacturing_Labor_Hours']),
                    'inspection': float(row['Inspection_Hours']),
                    'profit': float(row['Profit_Per_Unit'])
                })
    except FileNotFoundError:
        return

    # Read general parameters
    params = {}
    try:
        with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                params[row['Parameter_Name']] = float(row['Value'])
    except FileNotFoundError:
        return

    # Gurobi Model
    model = gp.Model("ToyProduction")
    model.setParam('OutputFlag', 0)

    periods = [1, 2]

    # Decision Variables
    # x[toy, period]: quantity produced and sold (assuming production meets demand per period)
    x = {}
    for toy in toys:
        for p in periods:
            x[toy['type'], p] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{toy['type']}_{p}")

    # Overtime variables
    ot1 = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="overtime_period1")
    ot2 = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="overtime_period2")

    # Binary variables for triggers
    # y_fatigue: 1 if period 1 overtime > threshold
    y_fatigue = model.addVar(vtype=GRB.BINARY, name="y_fatigue")
    # y_safety: 1 if total overtime > threshold
    y_safety = model.addVar(vtype=GRB.BINARY, name="y_safety")

    # Objective: Maximize Profit - Overtime Cost - Safety Review Fee
    total_revenue = gp.quicksum(toy['profit'] * x[toy['type'], p] for toy in toys for p in periods)
    overtime_cost = (ot1 + ot2) * params['overtime_labor_cost']
    safety_review_fee = y_safety * params['seasonal_safety_review_fee']
    
    model.setObjective(total_revenue - overtime_cost - safety_review_fee, GRB.MAXIMIZE)

    # Constraints

    # 1. Period 1 Labor Constraint
    # Sum(labor_hours * quantity) <= available_labor_p1 + overtime_p1
    model.addConstr(
        gp.quicksum(toy['labor'] * x[toy['type'], 1] for toy in toys) <= 
        params['available_labor_hours_period1'] + ot1,
        "Labor_P1"
    )

    # 2. Period 2 Labor Constraint (with fatigue recovery loss)
    # Sum(labor_hours * quantity) <= (available_labor_p2 - recovery_loss * y_fatigue) + overtime_p2
    model.addConstr(
        gp.quicksum(toy['labor'] * x[toy['type'], 2] for toy in toys) <= 
        (params['available_labor_hours_period2'] - y_fatigue * params['period2_labor_recovery_loss']) + ot2,
        "Labor_P2"
    )

    # 3. Overtime Capacity
    # ot1 + ot2 <= overtime_labor_cap
    model.addConstr(ot1 + ot2 <= params['overtime_labor_cap'], "Total_Overtime_Cap")

    # 4. Period 1 Inspection
    model.addConstr(
        gp.quicksum(toy['inspection'] * x[toy['type'], 1] for toy in toys) <= 
        params['available_inspection_hours_period1'],
        "Inspection_P1"
    )

    # 5. Period 2 Inspection
    model.addConstr(
        gp.quicksum(toy['inspection'] * x[toy['type'], 2] for toy in toys) <= 
        params['available_inspection_hours_period2'],
        "Inspection_P2"
    )

    # 6. Demand Constraints
    for toy in toys:
        t_name = toy['type'].lower().replace('-', '_')
        model.addConstr(x[toy['type'], 1] <= params[f'max_demand_{t_name}_period1'], f"Demand_{t_name}_P1")
        model.addConstr(x[toy['type'], 2] <= params[f'max_demand_{t_name}_period2'], f"Demand_{t_name}_P2")

    # 7. Fatigue Trigger (Linearizing: ot1 > threshold => y_fatigue = 1)
    # Using Big M where M is the maximum possible value of ot1 (the overtime_labor_cap)
    M_fatigue = params['overtime_labor_cap']
    model.addConstr(
        ot1 <= params['period1_overtime_fatigue_threshold'] + (M_fatigue - params['period1_overtime_fatigue_threshold']) * y_fatigue,
        "Fatigue_Trigger"
    )

    # 8. Safety Review Trigger (Linearizing: ot1 + ot2 > threshold => y_safety = 1)
    # Using Big M where M is the overtime_labor_cap
    M_safety = params['overtime_labor_cap']
    model.addConstr(
        ot1 + ot2 <= params['overtime_review_threshold'] + (M_safety - params['overtime_review_threshold']) * y_safety,
        "Safety_Trigger"
    )

    # Solve the model
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimization was not successful.")

if __name__ == "__main__":
    solve()
