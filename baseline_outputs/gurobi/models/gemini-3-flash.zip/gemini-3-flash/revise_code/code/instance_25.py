import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    W = params['initial_investment']
    r1 = params['return_rate_option_1']
    r2 = params['return_rate_option_2']
    T = int(params['planning_horizon'])
    min_reserve_year1 = params['min_reserve_year1']
    min_reserve_year2 = params['min_reserve_year2']
    max_option2_start = params['max_option2_start']
    late_settlement_rate = params['option2_year0_late_settlement_rate']
    
    # Multipliers
    m1 = 1 + r1
    m2 = 1 + r2
    
    # Create model
    model = gp.Model("Investment_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_t_i: amount invested in Option i at year t
    # s_t: cash held at year t
    x0_1 = model.addVar(lb=0, name="x0_1")
    x0_2 = model.addVar(lb=0, ub=max_option2_start, name="x0_2")
    s0 = model.addVar(lb=0, name="s0")
    
    x1_1 = model.addVar(lb=0, name="x1_1")
    x1_2 = model.addVar(lb=0, ub=max_option2_start, name="x1_2")
    s1 = model.addVar(lb=min_reserve_year1, name="s1")
    
    x2_1 = model.addVar(lb=0, name="x2_1")
    s2 = model.addVar(lb=min_reserve_year2, name="s2")
    
    # Year 0 Budget
    model.addConstr(x0_1 + x0_2 + s0 == W, "year0_budget")
    
    # Year 1 Budget
    # Available: returns from x0_1 + cash s0
    model.addConstr(x1_1 + x1_2 + s1 == x0_1 * m1 + s0, "year1_budget")
    
    # Year 2 Budget
    # Available: returns from x1_1 + cash s1
    # Note: x0_2 proceeds are late and not available for reinvestment at Year 2
    model.addConstr(x2_1 + s2 == x1_1 * m1 + s1, "year2_budget")
    
    # Objective: Maximize wealth at the end of Year 3
    # Wealth = returns from x2_1 + returns from x1_2 + late returns from x0_2 + cash s2
    # Late settlement deduction applies to x0_2 proceeds
    late_x0_2_proceeds = x0_2 * m2 * (1 - late_settlement_rate)
    wealth_year3 = x2_1 * m1 + x1_2 * m2 + late_x0_2_proceeds + s2
    
    model.setObjective(wealth_year3, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
