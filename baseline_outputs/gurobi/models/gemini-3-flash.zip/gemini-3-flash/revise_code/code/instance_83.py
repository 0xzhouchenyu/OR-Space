import os
import csv
import glob
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read general parameters
peaks = {}
qualities = {}
waiter_work_hours = 8
waiter_cost_per_shift = 1
waiter_budget = 30

with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        val_str = row['Value'].strip()
        try:
            val = float(val_str)
        except ValueError:
            continue
            
        if name == 'waiter_work_hours':
            waiter_work_hours = int(val)
        elif name == 'waiter_cost_per_shift':
            waiter_cost_per_shift = val
        elif name == 'waiter_budget':
            waiter_budget = val
        elif name.startswith('peak_'):
            idx = int(name.split('_')[1])
            peaks[idx] = int(val)
        elif name.startswith('quality_'):
            idx = int(name.split('_')[1])
            qualities[idx] = val

# Read all table_*.csv files to find max demand per period across all cases
table_files = glob.glob(os.path.join(data_dir, 'table_*.csv'))
max_demands = {}
num_periods = 0

for file in table_files:
    with open(file, 'r') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            d = int(row['Minimum_Number_of_Waiters_Needed'].strip())
            if i not in max_demands or d > max_demands[i]:
                max_demands[i] = d
            num_periods = max(num_periods, i + 1)

# Calculate periods per tour
# Each period is 24 / num_periods hours
hours_per_period = 24 / num_periods
periods_per_tour = int(waiter_work_hours / hours_per_period)

# Identify compliant tours
# A tour starting at period i covers periods [i, i+1, ..., i+periods_per_tour-1] (mod num_periods)
# A tour is compliant if it has exactly one peak and one off-peak window
compliant_tours = []
for i in range(num_periods):
    tour_periods = [(i + j) % num_periods for j in range(periods_per_tour)]
    num_peaks = sum(peaks[p] for p in tour_periods)
    num_off_peaks = sum(1 - peaks[p] for p in tour_periods)
    # Requirement: "one peak window and one off-peak window"
    if num_peaks == 1 and num_off_peaks == 1:
        compliant_tours.append(i)

# Build model
model = gp.Model("Restaurant_Waiters")
model.setParam('OutputFlag', 0)

# Decision variables: x[i] is the number of waiters starting a tour at period i
x = model.addVars(compliant_tours, vtype=GRB.INTEGER, lb=0, name="x")

# Constraints: Coverage >= max_demands for each period
for j in range(num_periods):
    # Waiters working in period j are those whose tour includes j
    waiters_in_period_j = gp.quicksum(x[i] for i in compliant_tours if any((i + k) % num_periods == j for k in range(periods_per_tour)))
    model.addConstr(waiters_in_period_j >= max_demands[j], name=f"Demand_Period_{j}")

# Constraint: Budget
total_cost = gp.quicksum(x[i] for i in compliant_tours) * waiter_cost_per_shift
model.addConstr(total_cost <= waiter_budget, name="Budget")

# Objective: Maximize service quality score
# Score = sum over all periods j: (waiters in period j * quality weight for period j)
service_quality_score = gp.quicksum(
    gp.quicksum(x[i] for i in compliant_tours if any((i + k) % num_periods == j for k in range(periods_per_tour))) * qualities[j]
    for j in range(num_periods)
)
model.setObjective(service_quality_score, GRB.MAXIMIZE)

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    # Format the objective value to remove trailing zeros if it's an integer
    obj_val = model.objVal
    if obj_val == int(obj_val):
        print(f"FINAL_OBJ_VALUE: {int(obj_val)}")
    else:
        print(f"FINAL_OBJ_VALUE: {obj_val}")
