import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define data directory paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load data from CSV files
    t1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    t2 = pd.read_csv(os.path.join(data_dir, 'table_2.csv'))
    t3 = pd.read_csv(os.path.join(data_dir, 'table_3.csv'))
    gp_df = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Merge product data into a single DataFrame
    df = t1.merge(t2, on='Product').merge(t3, on='Product')
    
    # Parse general parameters into a dictionary
    params = dict(zip(gp_df['Parameter_Name'], gp_df['Value']))
    
    # Create Gurobi Model
    model = gp.Model("Production_Planning_Revised")
    model.setParam('OutputFlag', 0)
    
    # List of products
    products = df['Product'].tolist()
    
    # Decision Variables
    # x[p] is total units of product p produced
    x = model.addVars(products, lb=0, name="x")
    # y[p] is a binary variable indicating if product p is produced
    y = model.addVars(products, vtype=GRB.BINARY, name="y")
    
    # Business requirement: All three products must be produced at commercially meaningful batch sizes
    for p in products:
        model.addConstr(y[p] == 1)
        
    # Revision for Product A1: Quality release and deep service thresholds
    # Binary variable for clearing a1_watch_threshold (3000)
    z1 = model.addVar(vtype=GRB.BINARY, name="z1")
    # Binary variable for clearing a1_deep_service_threshold (3600)
    z2 = model.addVar(vtype=GRB.BINARY, name="z2")
    
    # Segmentation of Product A1 volume for uplift calculation and threshold enforcement
    x1_seg1 = model.addVar(lb=0, name="x1_seg1") # Volume [0, 3000]
    x1_seg2 = model.addVar(lb=0, name="x1_seg2") # Volume (3000, 3600]
    x1_seg3 = model.addVar(lb=0, name="x1_seg3") # Volume (3600, Maximum_Demand]
    
    # Get A1 data for demand limit
    a1_data = df[df['Product'] == 'A1'].iloc[0]
    
    # Connect total A1 volume to segments
    model.addConstr(x['A1'] == x1_seg1 + x1_seg2 + x1_seg3)
    
    # Seg1 covers up to a1_watch_threshold (3000)
    model.addConstr(x1_seg1 <= params['a1_watch_threshold'])
    # If A1 crosses the watch threshold, x1_seg1 must be fully filled at 3000
    model.addConstr(x1_seg1 >= params['a1_watch_threshold'] * z1)
    
    # Seg2 covers volume between watch (3000) and deep service (3600)
    model.addConstr(x1_seg2 <= (params['a1_deep_service_threshold'] - params['a1_watch_threshold']) * z1)
    # If A1 crosses the deep service threshold, x1_seg2 must be fully filled at 600
    model.addConstr(x1_seg2 >= (params['a1_deep_service_threshold'] - params['a1_watch_threshold']) * z2)
    
    # Seg3 covers volume above deep service (3600)
    model.addConstr(x1_seg3 <= (a1_data['Maximum_Demand'] - params['a1_deep_service_threshold']) * z2)
    
    # Logic constraint: Cannot clear deep threshold without clearing watch threshold
    model.addConstr(z2 <= z1)
    
    # Generic constraints for all products based on Max Demand and Min Batch
    for _, row in df.iterrows():
        p = row['Product']
        model.addConstr(x[p] <= row['Maximum_Demand'] * y[p])
        model.addConstr(x[p] >= row['Minimum_Batch'] * y[p])
        
    # Production Days Constraint: Total production days + penalties must be within production_days limit
    # x/Quota gives production days. Penalty days are lost when thresholds are cleared.
    model.addConstr(
        gp.quicksum(x[row['Product']] / row['Production_Quota'] for _, row in df.iterrows()) <= 
        params['production_days'] - params['maintenance_penalty_watch'] * z1 - params['maintenance_penalty_deep'] * z2
    )
    
    # Objective Function: Maximize Profit
    # Profit = Sum((Selling_Price - Cost) * Production - Activation_Cost)
    # Plus priority uplift for A1 units above watch level (3000)
    # Minus fees for clearing thresholds
    
    basic_profit = gp.quicksum(
        (row['Selling_Price'] - row['Production_Cost']) * x[row['Product']] - row['Activation_Cost'] * y[row['Product']]
        for _, row in df.iterrows()
    )
    
    a1_revision_impact = (
        params['a1_priority_price_lift'] * (x1_seg2 + x1_seg3) 
        - params['a1_quality_release_fee'] * z1 
        - params['a1_deep_service_fee'] * z2
    )
    
    model.setObjective(basic_profit + a1_revision_impact, GRB.MAXIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Output the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of no solution, we might check infeasibility, but this problem has feasible regions
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
