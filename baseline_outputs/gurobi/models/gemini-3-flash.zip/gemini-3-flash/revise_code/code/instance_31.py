import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define the directory where the data files are located
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load processing parameters, capacities, costs, and prices from table_1.csv
    proc_time = {}
    capacity = {}
    cost_rate = {}
    raw_cost = {}
    price = {}
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            if equip == 'Raw_Material_Cost':
                raw_cost = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            elif equip == 'Unit_Price':
                price = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            else:
                for prod, col in [('I', 'Product_I'), ('II', 'Product_II'), ('III', 'Product_III')]:
                    val = row[col].strip()
                    if val != '-' and val != '':
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row['Effective_Machine_Hours'])
                cost_rate[equip] = float(row['Processing_Cost_per_Machine_Hour'])
    
    # Load fixed setup costs from setup_costs.csv
    setup_costs = {}
    setup_costs_path = os.path.join(data_dir, 'setup_costs.csv')
    if os.path.exists(setup_costs_path):
        with open(setup_costs_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                setup_costs[row['Equipment'].strip()] = float(row['Fixed_Setup_Cost'])
            
    # Load production rules and joint calibration details from general_parameters.csv
    stage_A_equip = {}
    stage_B_equip = {}
    joint_fee = 0
    joint_calibration_active = False
    general_params_path = os.path.join(data_dir, 'general_parameters.csv')
    with open(general_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            if 'stage_A_equipment' in name:
                parts = name.split('_')
                if len(parts) > 1:
                    prod = parts[1]
                    stage_A_equip[prod] = [e.strip() for e in row['Value'].replace(' or ', ',').split(',')]
            elif 'stage_B_equipment' in name:
                parts = name.split('_')
                if len(parts) > 1:
                    prod = parts[1]
                    stage_B_equip[prod] = [e.strip() for e in row['Value'].replace(' or ', ',').split(',')]
            elif name == 'A2_B2_joint_calibration_trigger' and row['Value'] == '1':
                joint_calibration_active = True
            elif name == 'A2_B2_joint_calibration_fee':
                joint_fee = float(row['Value'])
    
    # Initialize optimization model using Gurobi
    model = gp.Model("Factory_Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    products = ['I', 'II', 'III']
    equipments = list(capacity.keys())
    
    x = {} # Units of product processed per equipment
    for p in products:
        if p in stage_A_equip:
            for e in stage_A_equip[p]:
                if (e, p) in proc_time:
                    x[(e, p)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")
        if p in stage_B_equip:
            for e in stage_B_equip[p]:
                if (e, p) in proc_time:
                    x[(e, p)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")
    
    y = {e: model.addVar(vtype=GRB.BINARY, name=f"y_{e}") for e in equipments} # Equipment activation
    q = {p: model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"q_{p}") for p in products} # Total output per product
    z_joint = model.addVar(vtype=GRB.BINARY, name="z_joint") # Joint A2-B2 calibration hurdle
    
    # Constraints
    for p in products:
        # Flow conservation: Stage A total == Stage B total == Total Production q[p]
        if p in stage_A_equip:
            model.addConstr(gp.quicksum(x[(e, p)] for e in stage_A_equip[p] if (e, p) in x) == q[p])
        else:
            model.addConstr(q[p] == 0)
            
        if p in stage_B_equip:
            model.addConstr(gp.quicksum(x[(e, p)] for e in stage_B_equip[p] if (e, p) in x) == q[p])
        else:
            model.addConstr(q[p] == 0)
        
    for e in equipments:
        # Machine capacity limits and linking usage x with activation y
        model.addConstr(gp.quicksum(proc_time[(e, p)] * x[(e, p)] for p in products if (e, p) in x) <= capacity[e] * y[e])
        
    # Joint Calibration Hurdle Logic
    if joint_calibration_active and 'A2' in y and 'B2' in y:
        model.addConstr(z_joint >= y['A2'] + y['B2'] - 1)
    else:
        model.addConstr(z_joint == 0)
        
    # Objective Components
    revenue = gp.quicksum(price[p] * q[p] for p in products)
    raw_mat_cost_total = gp.quicksum(raw_cost[p] * q[p] for p in products)
    proc_cost_total = gp.quicksum(cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x)
    setup_cost_total = gp.quicksum(setup_costs[e] * y[e] for e in equipments if e in setup_costs)
    joint_calibration_charge = joint_fee * z_joint
    
    # Maximize total profit
    model.setObjective(revenue - raw_mat_cost_total - proc_cost_total - setup_cost_total - joint_calibration_charge, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    # Output the results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
