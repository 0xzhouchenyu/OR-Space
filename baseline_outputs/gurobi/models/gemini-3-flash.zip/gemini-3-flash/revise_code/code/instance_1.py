import gurobipy as gp
from gurobipy import GRB
import os
import csv

def solve():
    # Get the current directory of the script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, 'data', 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            try:
                if '.' in val:
                    params[name] = float(val)
                else:
                    params[name] = int(val)
            except ValueError:
                params[name] = val

    # Load table_1 (demand)
    demand_I = {}
    demand_II = {}
    with open(os.path.join(base_dir, 'data', 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = int(row['Week'].strip())
            demand_I[w] = int(row['I'].strip())
            demand_II[w] = int(row['II'].strip())

    # Parameters
    T = 8
    S0 = params['skilled_worker_count']
    rate_I = params['food_I_production_rate']
    rate_II = params['food_II_production_rate']
    normal_hours = params['worker_weekly_hours']
    train_cap = params['training_capacity']
    wage_skilled = params['skilled_worker_weekly_wage']
    wage_trainee_during = params['trainee_weekly_wage_during_training']
    wage_trainee_after = params['trainee_weekly_wage_after_training']
    ot_hours = params['skilled_worker_overtime_hours']
    ot_wage = params['skilled_worker_overtime_wage']
    comp_I = params['compensation_fee_food_I']
    comp_II = params['compensation_fee_food_II']
    goal = params['new_worker_training_goal']

    model = gp.Model("FactoryTraining")
    model.setParam('OutputFlag', 0)

    # Decision Variables
    # n_train[t]: number of trainers starting a 2-week course in week t (s in 1..7)
    n_train = model.addVars(range(1, 8), vtype=GRB.INTEGER, lb=0, name="n_train")
    # n_ot[t]: number of skilled workers assigned to overtime in week t
    n_ot = model.addVars(range(1, 9), vtype=GRB.INTEGER, lb=0, name="n_ot")
    # z_I[t], z_II[t]: binary indicators for food type production in week t
    z_I = model.addVars(range(1, 9), vtype=GRB.BINARY, name="z_I")
    z_II = model.addVars(range(1, 9), vtype=GRB.BINARY, name="z_II")
    # prod_I[t], prod_II[t]: production quantities
    prod_I = model.addVars(range(1, 9), vtype=GRB.CONTINUOUS, lb=0, name="prod_I")
    prod_II = model.addVars(range(1, 9), vtype=GRB.CONTINUOUS, lb=0, name="prod_II")
    # backlog_I[t], backlog_II[t]: delayed delivery quantities
    backlog_I = model.addVars(range(0, 9), vtype=GRB.CONTINUOUS, lb=0, name="backlog_I")
    backlog_II = model.addVars(range(0, 9), vtype=GRB.CONTINUOUS, lb=0, name="backlog_II")

    # Initial backlog
    model.addConstr(backlog_I[0] == 0)
    model.addConstr(backlog_II[0] == 0)

    # Busy trainers definition for each week
    busy_trainers = {}
    for t in range(1, 9):
        if t == 1:
            busy_trainers[t] = n_train[1]
        elif t == 8:
            busy_trainers[t] = n_train[7]
        else:
            busy_trainers[t] = n_train[t] + n_train[t-1]

    # Graduated workers available definition for each week
    grad_workers = {}
    for t in range(1, 9):
        if t <= 2:
            grad_workers[t] = 0
        else:
            grad_workers[t] = sum(train_cap * n_train[s] for s in range(1, t-1))

    # Constraints for each week
    for t in range(1, 9):
        # Workforce availability constraint
        model.addConstr(n_ot[t] + busy_trainers[t] <= S0, name=f"workforce_avail_{t}")
        
        # Total production hours
        h_skilled_normal = (S0 - busy_trainers[t] - n_ot[t]) * normal_hours
        h_skilled_ot = n_ot[t] * ot_hours
        h_grad = grad_workers[t] * normal_hours
        total_h = h_skilled_normal + h_skilled_ot + h_grad
        
        # Mutual exclusion and production capacity
        M = 10000000 # Sufficiently large constant
        model.addConstr(prod_I[t] <= rate_I * total_h, name=f"cap_I_{t}")
        model.addConstr(prod_I[t] <= M * z_I[t], name=f"bin_I_{t}")
        model.addConstr(prod_II[t] <= rate_II * total_h, name=f"cap_II_{t}")
        model.addConstr(prod_II[t] <= M * z_II[t], name=f"bin_II_{t}")
        model.addConstr(z_I[t] + z_II[t] <= 1, name=f"mutual_exclusion_{t}")
        
        # Production cannot exceed current total demand (no inventory, only backlog)
        model.addConstr(prod_I[t] <= backlog_I[t-1] + demand_I[t], name=f"prod_limit_I_{t}")
        model.addConstr(prod_II[t] <= backlog_II[t-1] + demand_II[t], name=f"prod_limit_II_{t}")
        
        # Backlog balance
        model.addConstr(backlog_I[t] == backlog_I[t-1] + demand_I[t] - prod_I[t], name=f"balance_I_{t}")
        model.addConstr(backlog_II[t] == backlog_II[t-1] + demand_II[t] - prod_II[t], name=f"balance_II_{t}")

    # Training goal constraint: at least goal workers graduated by end of week 8
    model.addConstr(sum(train_cap * n_train[s] for s in range(1, 8)) >= goal, name="training_goal")

    # Objective: minimize total cost
    # 1. Skilled worker wages (regular + overtime)
    skilled_wage = gp.quicksum(n_ot[t] * ot_wage + (S0 - n_ot[t]) * wage_skilled for t in range(1, 9))
    # 2. Trainees' wages during training
    trainee_during_wage = gp.quicksum(train_cap * busy_trainers[t] * wage_trainee_during for t in range(1, 9))
    # 3. Trainees' wages after training (graduated workers)
    trainee_after_wage = gp.quicksum(grad_workers[t] * wage_trainee_after for t in range(1, 9))
    # 4. Backlog compensation fees
    backlog_cost = gp.quicksum(comp_I * backlog_I[t] + comp_II * backlog_II[t] for t in range(1, 9))
    
    model.setObjective(skilled_wage + trainee_during_wage + trainee_after_wage + backlog_cost, GRB.MINIMIZE)

    # Solve model
    model.optimize()

    # Output objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
