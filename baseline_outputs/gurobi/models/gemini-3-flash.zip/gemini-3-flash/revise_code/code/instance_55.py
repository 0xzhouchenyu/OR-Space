import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_courses(filepath):
    courses = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            categories = [c.strip() for c in row['Category'].split(';')]
            courses[course] = categories
    return courses

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            params[name] = value
    return params

def match_prerequisite_course(prereq_key, course_list):
    key_lower = prereq_key.lower().replace('_', ' ')
    for course in course_list:
        if course.lower() == key_lower:
            return course
    return None

def solve():
    # Data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    courses_file = os.path.join(data_dir, 'table_1.csv')
    params_file = os.path.join(data_dir, 'general_parameters.csv')

    # Load data
    courses = load_courses(courses_file)
    raw_params = load_parameters(params_file)

    course_list = list(courses.keys())
    all_categories = set(cat for cats in courses.values() for cat in cats)
    
    min_required = int(raw_params['min_courses_required'])
    foundation_course = raw_params['mandatory_foundation_for_cs_counting']
    cs_category = raw_params['cs_category_name']

    # Build prerequisite mapping
    prerequisites = {}
    for name, value in raw_params.items():
        if name.startswith('prerequisite_'):
            course_key = name[len('prerequisite_'):]
            course_name = match_prerequisite_course(course_key, course_list)
            if course_name:
                if course_name not in prerequisites:
                    prerequisites[course_name] = []
                prerequisites[course_name].append(value.strip())

    # Create optimization model
    model = gp.Model("CourseSelection")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[i] = 1 if course i is taken
    x = model.addVars(course_list, vtype=GRB.BINARY, name="x")
    
    # y[i, c] = 1 if course i is counted toward category c
    course_category_pairs = [(course, cat) for course, cats in courses.items() for cat in cats]
    y = model.addVars(course_category_pairs, vtype=GRB.BINARY, name="y")

    # Objective: minimize total number of courses taken
    model.setObjective(x.sum(), GRB.MINIMIZE)

    # Constraint: at least min_required courses in each category
    for cat in all_categories:
        model.addConstr(gp.quicksum(y[course, cat] for course in course_list if (course, cat) in course_category_pairs) >= min_required, name=f"Min_{cat}")

    # Constraint: a course can be assigned to at most one category and only if it is taken
    for course in course_list:
        model.addConstr(gp.quicksum(y[course, cat] for cat in all_categories if (course, cat) in course_category_pairs) <= x[course], name=f"Distinct_{course}")

    # Prerequisite constraints: if you take a course, you must take its prerequisites
    for course, prereqs in prerequisites.items():
        for prereq in prereqs:
            if prereq in x:
                model.addConstr(x[course] <= x[prereq], name=f"Prereq_{course}_{prereq}")

    # CS Foundation Rule: foundation must be completed before any course is counted toward CS
    # This implies the foundation course itself cannot be counted toward the CS requirement
    # and if any course is counted toward CS, the foundation course must be taken.
    courses_in_cs = [course for course, cats in courses.items() if cs_category in cats]
    for course in courses_in_cs:
        if course == foundation_course:
            model.addConstr(y[course, cs_category] == 0, name="CS_Foundation_NoCount")
        else:
            # If course is counted toward CS, foundation must be taken
            model.addConstr(y[course, cs_category] <= x[foundation_course], name=f"CS_Foundation_Req_{course}")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
