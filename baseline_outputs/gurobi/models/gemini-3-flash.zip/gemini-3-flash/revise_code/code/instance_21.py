import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Set data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Parse general parameters
    params = {}
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    # Parameter Extraction
    cost_a = params['cost_supplier_a']
    cost_b = params['cost_supplier_b']
    cost_c = params['cost_supplier_c']
    size_a = int(params['order_size_supplier_a'])
    size_b = int(params['order_size_supplier_b'])
    size_c = int(params['order_size_supplier_c'])
    min_tables = int(params['min_tables_required'])
    max_tables = int(params['max_tables_allowed'])
    min_b_if_a = int(params['min_tables_supplier_b_if_a'])
    b_requires_c = int(params['supplier_b_requires_c'])
    max_free_c = int(params['max_free_orders_c'])
    penalty_rate_c = params['penalty_per_extra_order_c']
    bc_fee_trigger = int(params['supplier_bc_shared_inbound_trigger'])
    bc_fee = params['supplier_bc_shared_inbound_fee']
    
    # Big-M value
    M = 1000
    
    # Initialize Gurobi model
    model = gp.Model("Restaurant_Tables")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    x_a = model.addVar(vtype=GRB.INTEGER, name="orders_a", lb=0)
    x_b = model.addVar(vtype=GRB.INTEGER, name="orders_b", lb=0)
    x_c = model.addVar(vtype=GRB.INTEGER, name="orders_c", lb=0)
    
    y_a = model.addVar(vtype=GRB.BINARY, name="use_a")
    y_b = model.addVar(vtype=GRB.BINARY, name="use_b")
    y_c = model.addVar(vtype=GRB.BINARY, name="use_c")
    
    extra_orders_c = model.addVar(vtype=GRB.INTEGER, name="extra_orders_c", lb=0)
    y_bc = model.addVar(vtype=GRB.BINARY, name="use_b_and_c")
    
    # Objective Function
    # Total Cost = Unit Table Cost + Penalty for C + Shared Fee for BC
    base_cost = (cost_a * size_a * x_a) + (cost_b * size_b * x_b) + (cost_c * size_c * x_c)
    penalty_cost = penalty_rate_c * extra_orders_c
    shared_bc_cost = bc_fee * y_bc if bc_fee_trigger else 0
    
    model.setObjective(base_cost + penalty_cost + shared_bc_cost, GRB.MINIMIZE)
    
    # Constraints
    # 1. Total tables capacity
    total_tables = size_a * x_a + size_b * x_b + size_c * x_c
    model.addConstr(total_tables >= min_tables, "min_total_tables")
    model.addConstr(total_tables <= max_tables, "max_total_tables")
    
    # 2. Link binary variables to order variables
    model.addConstr(x_a <= M * y_a)
    model.addConstr(x_a >= y_a)
    model.addConstr(x_b <= M * y_b)
    model.addConstr(x_b >= y_b)
    model.addConstr(x_c <= M * y_c)
    model.addConstr(x_c >= y_c)
    
    # 3. If ordering from A, then tables from B must be at least min_b_if_a
    model.addConstr(size_b * x_b >= min_b_if_a * y_a, "min_b_if_a")
    
    # 4. If ordering from B, must order from C (at least one order)
    if b_requires_c:
        model.addConstr(y_c >= y_b, "b_requires_c")
        
    # 5. Penalty for extra orders from Supplier C
    model.addConstr(extra_orders_c >= x_c - max_free_c, "extra_orders_c_limit")
    
    # 6. Shared inbound fee for Supplier B and Supplier C
    if bc_fee_trigger:
        # y_bc is 1 if both y_b and y_c are 1
        model.addConstr(y_bc >= y_b + y_c - 1, "trigger_bc_fee")
        
    # Solve the model
    model.optimize()
    
    # Output objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
