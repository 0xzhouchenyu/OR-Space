import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        val = row['Value'].strip()
        if val:
            params[name] = val

# Read items and values
items = []
values = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        items.append(row['Item'].strip())
        values.append(int(row['Value'].strip()))

n = len(items)
total_value = sum(values)

# Extract parameter values
son1_min_share = float(params['son1_min_share'])
hv_threshold = float(params['high_value_threshold'])
max_hv = int(params['max_high_value_items_per_son'])
max_def_diamonds = int(params['deferred_diamonds_per_son'])
imm_weight = float(params['immediate_tax_weight'])
tot_weight = float(params['total_tax_weight'])

# Identify special item groups
jr_indices = [i for i, item in enumerate(items) if 'Jack Russell' in item]
diamond_indices = [i for i, item in enumerate(items) if 'Diamond' in item]
hv_indices = [i for i, v in enumerate(values) if v >= hv_threshold]

# Create the optimization model
model = gp.Model("Inheritance_Split")
model.setParam('OutputFlag', 0)

# Decision variables: x[i, s, t] = 1 if item i goes to son s (0 or 1) with transfer type t (0=Imm, 1=Def)
x = model.addVars(n, 2, 2, vtype=GRB.BINARY, name="x")

# Intermediate variables for values
v_imm = model.addVars(2, lb=0, name="v_imm")
v_tot = model.addVars(2, lb=0, name="v_tot")

for s in range(2):
    model.addConstr(v_imm[s] == gp.quicksum(values[i] * x[i, s, 0] for i in range(n)))
    model.addConstr(v_tot[s] == gp.quicksum(values[i] * x[i, s, t] for i in range(n) for t in range(2)))

# Absolute difference variables
diff_imm = model.addVar(lb=0, name="diff_imm")
diff_tot = model.addVar(lb=0, name="diff_tot")

model.addConstr(diff_imm >= v_imm[0] - v_imm[1])
model.addConstr(diff_imm >= v_imm[1] - v_imm[0])
model.addConstr(diff_tot >= v_tot[0] - v_tot[1])
model.addConstr(diff_tot >= v_tot[1] - v_tot[0])

# Constraints
# 1. Each item assigned exactly once
for i in range(n):
    model.addConstr(x.sum(i, '*', '*') == 1)

# 2. Jack Russell racing dogs must not be separated (same son, same transfer type)
if len(jr_indices) >= 2:
    for s in range(2):
        for t in range(2):
            model.addConstr(x[jr_indices[0], s, t] == x[jr_indices[1], s, t])

# 3. Son 1 minimum share of total ownership
model.addConstr(v_tot[0] >= son1_min_share * total_value)

# 4. High-value item concentration limit per son
for s in range(2):
    model.addConstr(gp.quicksum(x[i, s, t] for i in hv_indices for t in range(2)) <= max_hv)

# 5. Deferred diamonds limit per son
for s in range(2):
    model.addConstr(gp.quicksum(x[i, s, 1] for i in diamond_indices) <= max_def_diamonds)

# Objective: minimize weighted imbalance
model.setObjective(imm_weight * diff_imm + tot_weight * diff_tot, GRB.MINIMIZE)

# Solve
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
