import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Define paths to data files
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table1_path = os.path.join(base_dir, 'table_1.csv')
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    
    # Load table_1.csv
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Extract parameters for easier access
    machine_avail = params['machine_time_available']
    craftsman_reg_avail = params['craftsman_regular_time_available']
    craftsman_over_avail = params['craftsman_overtime_available']
    machine_cost_rate = params['machine_time_cost']
    craftsman_reg_cost_rate = params['craftsman_time_cost']
    craftsman_over_cost_rate = params['craftsman_overtime_cost']
    rev_X = params['revenue_product_X']
    rev_Y = params['revenue_product_Y']
    min_X = params['min_batches_product_X']
    y_qa_threshold = params['product_Y_QA_threshold']
    y_qa_fee = params['product_Y_QA_fee']
    
    # Create Gurobi model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    X = model.addVar(lb=min_X, vtype=GRB.CONTINUOUS, name="X")
    Y = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Y")
    
    # Auxiliary variables for craftsman time split
    craftsman_reg_used = model.addVar(lb=0, ub=craftsman_reg_avail, vtype=GRB.CONTINUOUS, name="craftsman_reg_used")
    craftsman_over_used = model.addVar(lb=0, ub=craftsman_over_avail, vtype=GRB.CONTINUOUS, name="craftsman_over_used")
    
    # Binary variable for Product Y QA tier
    y_over_threshold = model.addVar(vtype=GRB.BINARY, name="y_over_threshold")
    
    # Expressions for resource usage
    machine_hours_used = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0
    craftsman_hours_used = (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0
    
    # Constraints
    # 1. Machine time availability
    model.addConstr(machine_hours_used <= machine_avail, name="Machine_Time_Constraint")
    
    # 2. Craftsman time split and availability
    model.addConstr(craftsman_hours_used == craftsman_reg_used + craftsman_over_used, name="Craftsman_Time_Constraint")
    
    # 3. Product Y QA threshold logic
    # Large M for the indicator constraint
    M = 1000 
    model.addConstr(Y <= y_qa_threshold + M * y_over_threshold, name="Product_Y_QA_Threshold_Constraint")
    
    # Objective: Maximize Profit = Revenue - Costs
    # Costs include machine time, regular craftsman time, overtime craftsman time, and the one-time QA fee
    revenue = rev_X * X + rev_Y * Y
    machine_cost = machine_cost_rate * machine_hours_used
    craftsman_cost = craftsman_reg_cost_rate * craftsman_reg_used + craftsman_over_cost_rate * craftsman_over_used
    qa_cost = y_qa_fee * y_over_threshold
    
    profit = revenue - machine_cost - craftsman_cost - qa_cost
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimization was not optimal.")

if __name__ == "__main__":
    main()
