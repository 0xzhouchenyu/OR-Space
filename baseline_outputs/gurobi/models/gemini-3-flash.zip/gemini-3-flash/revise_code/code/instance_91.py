import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            
            # Handle ratio values like "5:2"
            if ':' in value_str:
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = float(value_str)
                    if value == int(value):
                        value = int(value)
                except ValueError:
                    value = value_str
                params[name] = value
    return params

def main():
    # File path setup
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    params = load_parameters(params_path)
    
    # Extract parameters
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_minutes = params['machine_working_time'] * 60
    
    ratio_A, ratio_B = params['production_ratio_A_to_B']
    
    max_ot_hours = params['max_overtime_hours']
    ot_penalty_per_hour = params['overtime_penalty_per_hour']
    ot_threshold_hours = params['overtime_review_threshold_hours']
    ot_review_fee = params['overtime_review_fee']
    
    a_senior_threshold = params['product_A_senior_batch_threshold']
    a_senior_fee = params['product_A_senior_batch_fee']
    
    # Initialize Model
    model = gp.Model("Product_Mix_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    A = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_A")
    B = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_B")
    OT_hours = model.addVar(lb=0, ub=max_ot_hours, vtype=GRB.CONTINUOUS, name="OT_hours")
    
    # Binary variables for "gates"
    OT_gate = model.addVar(vtype=GRB.BINARY, name="OT_gate")
    A_gate = model.addVar(vtype=GRB.BINARY, name="A_gate")
    
    # Objective Function: Maximize Profit
    # Profit = (Revenue) - (OT Penalty) - (OT Review Fee) - (Senior Batch Fee)
    model.setObjective(
        profit_A * A + profit_B * B - 
        ot_penalty_per_hour * OT_hours - 
        ot_review_fee * OT_gate - 
        a_senior_fee * A_gate,
        GRB.MAXIMIZE
    )
    
    # Constraints
    
    # 1. Machine working time (including overtime)
    model.addConstr(assembly_time_A * A + assembly_time_B * B <= machine_working_time_minutes + 60 * OT_hours, "Machine_Time")
    
    # 2. Production ratio: B >= (ratio_B/ratio_A) * A  =>  ratio_B * A - ratio_A * B <= 0
    model.addConstr(ratio_B * A - ratio_A * B <= 0, "Production_Ratio")
    
    # 3. Overtime Review Gate: OT_hours > threshold triggers fee
    # OT_hours <= threshold + (max_ot - threshold) * OT_gate
    model.addConstr(OT_hours <= ot_threshold_hours + (max_ot_hours - ot_threshold_hours) * OT_gate, "OT_Gate_Constraint")
    
    # 4. Product A Senior Batch Gate: A > threshold triggers fee
    # Big M for A: Max possible A is (30+15)*60 / 12 = 225. M = 1000 is safe.
    M_A = 1000
    model.addConstr(A <= a_senior_threshold + M_A * A_gate, "A_Gate_Constraint")
    
    # Solve
    model.optimize()
    
    # Output result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
