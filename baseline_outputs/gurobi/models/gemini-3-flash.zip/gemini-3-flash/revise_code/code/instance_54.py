import gurobipy as gp
from gurobipy import GRB
import csv
import os

def solve_production_optimization():
    # Define paths to data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table1_path = os.path.join(base_dir, "data", "table_1.csv")
    gen_params_path = os.path.join(base_dir, "data", "general_parameters.csv")

    # Initialize data structures
    products = []
    equipment = []
    processing_times = {}
    effective_hours = {}
    base_profit = {}
    min_prod = {}
    overtime_hours_cap = 0.0
    overtime_cost_multiplier = 0.0

    # Load table_1.csv
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: Equipment_Code, I, II, III, Effective_Monthly_Equipment_Hours
        products = [p.strip() for p in header[1:-1]]
        
        for row in reader:
            if not row or not row[0]:
                continue
            if row[0].startswith('Unit_Product_Profit'):
                for i, p in enumerate(products):
                    base_profit[p] = float(row[i+1])
            else:
                e = row[0].strip()
                equipment.append(e)
                effective_hours[e] = float(row[-1])
                for i, p in enumerate(products):
                    processing_times[(e, p)] = float(row[i+1])

    # Load general_parameters.csv
    with open(gen_params_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            if not row:
                continue
            name, val = row[0].strip(), float(row[1])
            if name == 'overtime_hours_cap':
                overtime_hours_cap = val
            elif name == 'overtime_cost_multiplier':
                overtime_cost_multiplier = val
            elif name == 'min_prod_I':
                min_prod['I'] = val
            elif name == 'min_prod_II':
                min_prod['II'] = val
            elif name == 'min_prod_III':
                min_prod['III'] = val

    # Create Gurobi model
    model = gp.Model("Factory_Production_Optimization")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x_reg = model.addVars(products, lb=0, name="x_reg")
    x_ot = model.addVars(products, lb=0, name="x_ot")

    # Objective: Minimize total production cost
    # Regular cost = base_profit, Overtime cost = multiplier * base_profit
    model.setObjective(
        gp.quicksum(base_profit[p] * x_reg[p] + (overtime_cost_multiplier * base_profit[p]) * x_ot[p] for p in products),
        GRB.MINIMIZE
    )

    # Constraints: Equipment capacity
    # Both regular and overtime production share the same equipment hours
    for e in equipment:
        model.addConstr(
            gp.quicksum(processing_times[(e, p)] * (x_reg[p] + x_ot[p]) for p in products) <= effective_hours[e],
            name=f"Equipment_{e}_Capacity"
        )

    # Constraints: Overtime hours cap
    # Total equipment hours consumed by all overtime work across all products
    model.addConstr(
        gp.quicksum(
            gp.quicksum(processing_times[(e, p)] for e in equipment) * x_ot[p]
            for p in products
        ) <= overtime_hours_cap,
        name="Overtime_Hours_Cap"
    )

    # Constraints: Minimum production levels
    for p in products:
        model.addConstr(
            x_reg[p] + x_ot[p] >= min_prod[p],
            name=f"Min_Production_{p}"
        )

    # Solve the model
    model.optimize()

    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_production_optimization()
