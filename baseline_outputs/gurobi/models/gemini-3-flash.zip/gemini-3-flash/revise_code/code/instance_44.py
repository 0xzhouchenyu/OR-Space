import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_transportation_problem():
    # Load data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    # Extract general parameters
    m = int(params['m'])
    n = int(params['n'])
    p = int(params['p'])
    eps = params['eps']
    M_val = params['M']

    a = {i: params[f'a_{i}'] for i in range(1, m + 1)}
    b = {j: params[f'b_{j}'] for j in range(1, n + 1)}
    f_cost = {k: params[f'f_{k}'] for k in range(1, p + 1)}
    q = {k: params[f'q_{k}'] for k in range(1, p + 1)}
    qexp = {k: params[f'qexp_{k}'] for k in range(1, p + 1)}
    alpha = {j: params[f'alpha_{j}'] for j in range(1, n + 1)}

    # Load transportation costs (Production to Marshaling)
    cR_ik = {}
    cE_ik = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            i, k = int(row['i']), int(row['k'])
            cR_ik[(i, k)] = float(row['cR_ik'])
            cE_ik[(i, k)] = float(row['cE_ik'])

    # Load transportation costs (Marshaling to Demand)
    cR_kj = {}
    cE_kj = {}
    with open(os.path.join(data_dir, 'table_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            k, j = int(row['k']), int(row['j'])
            cR_kj[(k, j)] = float(row['cR_kj'])
            cE_kj[(k, j)] = float(row['cE_kj'])

    # Create the optimization model
    model = gp.Model("Transportation_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    xR = model.addVars(range(1, m + 1), range(1, p + 1), lb=0, vtype=GRB.CONTINUOUS, name="xR")
    xE = model.addVars(range(1, m + 1), range(1, p + 1), lb=0, vtype=GRB.CONTINUOUS, name="xE")
    yR = model.addVars(range(1, p + 1), range(1, n + 1), lb=0, vtype=GRB.CONTINUOUS, name="yR")
    yE = model.addVars(range(1, p + 1), range(1, n + 1), lb=0, vtype=GRB.CONTINUOUS, name="yE")
    z = model.addVars(range(1, p + 1), vtype=GRB.BINARY, name="z")
    u = model.addVars(range(1, p + 1), range(1, n + 1), vtype=GRB.BINARY, name="u")
    S = model.addVar(vtype=GRB.BINARY, name="S")

    # Objective Function: Minimize total variable and fixed costs
    total_cost = (
        gp.quicksum(cR_ik[i, k] * xR[i, k] + cE_ik[i, k] * xE[i, k] for i in range(1, m + 1) for k in range(1, p + 1)) +
        gp.quicksum(cR_kj[k, j] * yR[k, j] + cE_kj[k, j] * yE[k, j] for k in range(1, p + 1) for j in range(1, n + 1)) +
        gp.quicksum(f_cost[k] * z[k] for k in range(1, p + 1))
    )
    model.setObjective(total_cost, GRB.MINIMIZE)

    # Constraints
    # 1. Supply constraints
    for i in range(1, m + 1):
        model.addConstr(gp.quicksum(xR[i, k] + xE[i, k] for k in range(1, p + 1)) <= a[i])

    # 2. Demand requirements
    for j in range(1, n + 1):
        model.addConstr(gp.quicksum(yR[k, j] + yE[k, j] for k in range(1, p + 1)) >= b[j])

    # 3. Flow conservation at marshaling stations (Regular and Express kept separate)
    for k in range(1, p + 1):
        model.addConstr(gp.quicksum(xR[i, k] for i in range(1, m + 1)) == gp.quicksum(yR[k, j] for j in range(1, n + 1)))
        model.addConstr(gp.quicksum(xE[i, k] for i in range(1, m + 1)) == gp.quicksum(yE[k, j] for j in range(1, n + 1)))

    # 4. Total and Express capacities at stations
    for k in range(1, p + 1):
        model.addConstr(gp.quicksum(xR[i, k] + xE[i, k] for i in range(1, m + 1)) <= q[k] * z[k])
        model.addConstr(gp.quicksum(xE[i, k] for i in range(1, m + 1)) <= qexp[k] * z[k])

    # 5. Link express flow and its binary activation indicator
    for k in range(1, p + 1):
        for j in range(1, n + 1):
            model.addConstr(yE[k, j] >= eps * u[k, j])
            model.addConstr(yE[k, j] <= M_val * u[k, j])
            model.addConstr(u[k, j] <= z[k])

    # 6. Diversification logic for multiple open stations
    # Determine if more than one station is open (sum(z_k) > 1)
    model.addConstr(gp.quicksum(z[k] for k in range(1, p + 1)) >= 2 * S)
    model.addConstr(gp.quicksum(z[k] for k in range(1, p + 1)) <= 1 + (p - 1) * S)

    for j in range(1, n + 1):
        # Requirement: Express service must be from at least two station links if S=1
        model.addConstr(gp.quicksum(u[k, j] for k in range(1, p + 1)) >= 2 * S)
        # Requirement: Total express share into demand point j must be at least alpha_j * b_j if S=1
        model.addConstr(gp.quicksum(yE[k, j] for k in range(1, p + 1)) >= alpha[j] * b[j] * S)

    # Solve
    model.optimize()

    # Output Objective Value
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("Model did not solve optimally.")

if __name__ == "__main__":
    solve_transportation_problem()
