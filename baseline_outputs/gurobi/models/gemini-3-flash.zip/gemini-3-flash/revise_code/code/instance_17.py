import gurobipy as gp
from gurobipy import GRB
import os
import csv

def solve():
    # Set up data paths
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(curr_dir, 'data')
    
    # Load general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Load table_1.csv
    parts = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
    
    n_parts = len(parts)
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    max_sorties_limit = min(max_sorties_A, max_sorties_B)
    
    max_heavy_limit = int(params['max_heavy_bombs'])
    max_light_limit = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts_required = int(params['min_parts_destroyed'])
    
    # Precalculate all possible combinations of (heavy, light) bombs for a single part
    V = [(h, l) for h in range(max_sorties_limit + 1) for l in range(max_sorties_limit + 1) if h + l <= max_sorties_limit]
    
    def get_fuel(dist, bomb_type, fleet_overhead):
        if bomb_type == 'heavy':
            eff = params['fuel_efficiency_heavy_bomb']
        else:
            eff = params['fuel_efficiency_light_bomb']
        eff_empty = params['fuel_efficiency_empty']
        # Fuel = (dist / eff_bomb) + (dist / eff_empty) + takeoff_landing + fleet_overhead
        return (dist / eff) + (dist / eff_empty) + params['fuel_takeoff_landing'] + fleet_overhead

    # Build the optimization model
    model = gp.Model("BombingMissionOptimization")
    model.setParam('OutputFlag', 0)
    
    # z[i, j] = 1 if part i is assigned combination V[j] (h, l)
    z = model.addVars(n_parts, len(V), vtype=GRB.BINARY, name="z")
    
    # Each part must have exactly one bomb allocation configuration
    for i in range(n_parts):
        model.addConstr(gp.quicksum(z[i, j] for j in range(len(V))) == 1)
        
    # Stockpile and mission limits
    model.addConstr(gp.quicksum(V[j][0] * z[i, j] for i in range(n_parts) for j in range(len(V))) <= max_heavy_limit)
    model.addConstr(gp.quicksum(V[j][1] * z[i, j] for i in range(n_parts) for j in range(len(V))) <= max_light_limit)
    
    # Combined sortie limit (must hold for both fleets)
    model.addConstr(gp.quicksum((V[j][0] + V[j][1]) * z[i, j] for i in range(n_parts) for j in range(len(V))) <= max_sorties_A)
    model.addConstr(gp.quicksum((V[j][0] + V[j][1]) * z[i, j] for i in range(n_parts) for j in range(len(V))) <= max_sorties_B)
    
    # Fuel constraints for both potential aircraft types
    model.addConstr(gp.quicksum(
        (V[j][0] * get_fuel(parts[i]['distance'], 'heavy', params['sortie_fuel_overhead_A']) +
         V[j][1] * get_fuel(parts[i]['distance'], 'light', params['sortie_fuel_overhead_A'])) * z[i, j]
        for i in range(n_parts) for j in range(len(V))
    ) <= fuel_limit)
    
    model.addConstr(gp.quicksum(
        (V[j][0] * get_fuel(parts[i]['distance'], 'heavy', params['sortie_fuel_overhead_B']) +
         V[j][1] * get_fuel(parts[i]['distance'], 'light', params['sortie_fuel_overhead_B'])) * z[i, j]
        for i in range(n_parts) for j in range(len(V))
    ) <= fuel_limit)
    
    # Destruction probability p[i][j] for each part i under configuration j
    part_config_probs = []
    for i in range(n_parts):
        p_iv = []
        for j in range(len(V)):
            h, l = V[j]
            p = 1.0 - (1.0 - parts[i]['p_heavy'])**h * (1.0 - parts[i]['p_light'])**l
            p_iv.append(p)
        part_config_probs.append(p_iv)
        
    # Linearize the success probability of destroying at least min_parts_required
    # y[i, k] is the probability exactly k parts are destroyed after considering parts 0 to i
    y = model.addVars(n_parts, n_parts + 1, lb=0, ub=1, name="y")
    # Auxiliary variables to linearize products of binary z[i, j] and continuous y[i-1, k]
    w = model.addVars(n_parts, len(V), n_parts + 1, lb=0, ub=1, name="w")
    
    for i in range(n_parts):
        for j in range(len(V)):
            for k in range(n_parts + 1):
                if i == 0:
                    # Base case: first part
                    if k == 0:
                        model.addConstr(w[i, j, k] == z[i, j])
                    else:
                        model.addConstr(w[i, j, k] == 0)
                else:
                    # Linearize w[i, j, k] = z[i, j] * y[i-1, k]
                    model.addConstr(w[i, j, k] <= z[i, j])
                    model.addConstr(w[i, j, k] <= y[i-1, k])
                    model.addConstr(w[i, j, k] >= y[i-1, k] - (1 - z[i, j]))
        
        for k in range(n_parts + 1):
            if k == 0:
                # Exactly 0 parts destroyed among first i+1
                model.addConstr(y[i, k] == gp.quicksum((1 - part_config_probs[i][j]) * w[i, j, k] for j in range(len(V))))
            else:
                # Exactly k parts destroyed among first i+1
                model.addConstr(y[i, k] == gp.quicksum(
                    part_config_probs[i][j] * w[i, j, k-1] + (1 - part_config_probs[i][j]) * w[i, j, k]
                    for j in range(len(V))
                ))
                
    # Maximize the probability that at least min_parts_required are destroyed
    # Since success probability is independent of fleet scenario for the same plan, the weights sum to 1.
    model.setObjective(gp.quicksum(y[n_parts - 1, k] for k in range(min_parts_required, n_parts + 1)), GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal:.4f}")
    else:
        print("FINAL_OBJ_VALUE: 0.0000")

if __name__ == "__main__":
    solve()
