import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def solve():
    # File paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    table_path = os.path.join(base_dir, "data", "table_1.csv")

    # Load general parameters
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if row:
                params[row[0]] = float(row[1])

    T = int(params.get('planning_horizon_T', 15))
    energy_cost_v1 = params.get('energy_cost_v1', 1.0)
    energy_cost_v2 = params.get('energy_cost_v2', 1.2)
    energy_cost_v3 = params.get('energy_cost_v3', 1.5)
    peak_multiplier = params.get('peak_energy_multiplier', 2.0)
    peak_energy_cap = params.get('peak_energy_cap', 30.0)
    makespan_weight = params.get('makespan_weight', 1.0)
    energy_weight = params.get('energy_weight', 0.5)

    base_costs = [energy_cost_v1, energy_cost_v2, energy_cost_v3]
    peak_periods = {6, 7, 8}

    # Load batch processing times and round them up
    batches = []
    durations = []
    with open(table_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if row:
                batches.append(row[0])
                # Round up the times for Vat 1, Vat 2, Vat 3
                durations.append([
                    math.ceil(float(row[1])),
                    math.ceil(float(row[2])),
                    math.ceil(float(row[3]))
                ])

    num_batches = len(batches)
    num_vats = 3

    # Initialize Gurobi model
    model = gp.Model("DyeingPlantScheduling")
    model.setParam('OutputFlag', 0)

    # Variables
    # is_start[b][v][t] is 1 if batch b starts on vat v at time t
    is_start = {}
    for b in range(num_batches):
        for v in range(num_vats):
            p_bv = durations[b][v]
            # Valid start times t are from 1 up to T - p_bv + 1
            for t in range(1, T - p_bv + 2):
                is_start[b, v, t] = model.addVar(vtype=GRB.BINARY, name=f"start_{b}_{v}_{t}")

    # x[b][v][t] is 1 if batch b is being processed on vat v at time t
    x = {}
    for b in range(num_batches):
        for v in range(num_vats):
            for t in range(1, T + 1):
                x[b, v, t] = model.addVar(vtype=GRB.BINARY, name=f"x_{b}_{v}_{t}")

    # Makespan variable
    makespan = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="makespan")

    # Constraints
    # 1. Each batch starts exactly once on each vat
    for b in range(num_batches):
        for v in range(num_vats):
            p_bv = durations[b][v]
            model.addConstr(gp.quicksum(is_start[b, v, t] for t in range(1, T - p_bv + 2)) == 1)

    # 2. Link start variables to active variables x
    for b in range(num_batches):
        for v in range(num_vats):
            p_bv = durations[b][v]
            for t in range(1, T + 1):
                # x[b,v,t] is active if batch b started at any k such that k <= t <= k + p_bv - 1
                # which is equivalent to t - p_bv + 1 <= k <= t
                possible_k = [k for k in range(max(1, t - p_bv + 1), min(t, T - p_bv + 1) + 1)]
                if possible_k:
                    model.addConstr(x[b, v, t] == gp.quicksum(is_start[b, v, k] for k in possible_k))
                else:
                    model.addConstr(x[b, v, t] == 0)

    # 3. No vat handles more than one batch at any time
    for v in range(num_vats):
        for t in range(1, T + 1):
            model.addConstr(gp.quicksum(x[b, v, t] for b in range(num_batches)) <= 1)

    # 4. Sequential routing and handoff convention
    # s[b,v] = sum(t * is_start[b,v,t])
    # Handoff: s[b, v+1] >= s[b, v] + durations[b][v] - 1
    for b in range(num_batches):
        s = {}
        for v in range(num_vats):
            p_bv = durations[b][v]
            s[v] = gp.quicksum(t * is_start[b, v, t] for t in range(1, T - p_bv + 2))
        
        # Route: Vat 1 -> Vat 2 -> Vat 3
        model.addConstr(s[1] >= s[0] + durations[b][0] - 1)
        model.addConstr(s[2] >= s[1] + durations[b][1] - 1)

    # 5. Vat 2 maintenance during periods 4 and 5
    for b in range(num_batches):
        model.addConstr(x[b, 1, 4] == 0)
        model.addConstr(x[b, 1, 5] == 0)

    # 6. Peak energy cap
    peak_energy_usage = gp.quicksum(
        x[b, v, t] * base_costs[v] * peak_multiplier
        for b in range(num_batches)
        for v in range(num_vats)
        for t in peak_periods
    )
    model.addConstr(peak_energy_usage <= peak_energy_cap)

    # 7. Makespan definition
    for b in range(num_batches):
        p_b2 = durations[b][2]
        s_b2 = gp.quicksum(t * is_start[b, 2, t] for t in range(1, T - p_b2 + 2))
        model.addConstr(makespan >= s_b2 + p_b2 - 1)

    # Objective: minimize weighted sum of makespan and total energy cost
    total_energy_cost = gp.quicksum(
        x[b, v, t] * base_costs[v] * (peak_multiplier if t in peak_periods else 1.0)
        for b in range(num_batches)
        for v in range(num_vats)
        for t in range(1, T + 1)
    )

    model.setObjective(makespan_weight * makespan + energy_weight * total_energy_cost, GRB.MINIMIZE)

    # Solve
    model.optimize()

    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
