import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Setup data directories
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load container data from table_1.csv
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    # Assign parameter values based on exact names in data/brief
    fixed_setup_cost = params['fixed_setup_cost']
    energy_cost_per_kwh = params['energy_cost_per_kwh']
    max_total_energy_kwh = params['max_total_energy_kwh']
    eco_capacity_share = params['eco_capacity_share']
    eco_overhead_cost = params['eco_overhead_cost']
    regular_energy_intensity = params['regular_energy_intensity_kwh_per_unit']
    eco_energy_intensity = params['eco_energy_intensity_kwh_per_unit']

    n = len(containers)
    # Big M: upper bound for total production of any container type
    M = sum(c['demand'] for c in containers)

    # Initialize Gurobi model
    model = gp.Model("RedStarPlasticContainers")
    model.setParam('OutputFlag', 0)

    # Decision Variables
    # x_reg[i, j]: Units of type i produced in Regular mode to satisfy demand of type j
    # x_eco[i, j]: Units of type i produced in Eco mode to satisfy demand of type j
    x_reg = {}
    x_eco = {}
    for i in range(n):
        for j in range(n):
            # Substitution rule: Container i can satisfy demand j if volume[i] >= volume[j]
            if containers[i]['volume'] >= containers[j]['volume']:
                x_reg[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_reg_{i}_{j}")
                x_eco[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_eco_{i}_{j}")

    # Binary variables for setups
    y = model.addVars(n, vtype=GRB.BINARY, name="y")           # General setup for container type i
    z_eco = model.addVars(n, vtype=GRB.BINARY, name="z_eco")   # Eco mode activation for container type i

    # Objective: Minimize total cost (production + energy + fixed setup + eco overhead)
    # Variable cost per unit = production_cost + (energy_intensity * energy_cost_per_kwh)
    cost_reg = gp.quicksum((containers[i]['cost'] + regular_energy_intensity * energy_cost_per_kwh) * x_reg[i, j] 
                           for (i, j) in x_reg)
    cost_eco = gp.quicksum((containers[i]['cost'] + eco_energy_intensity * energy_cost_per_kwh) * x_eco[i, j] 
                           for (i, j) in x_eco)
    fixed_costs = gp.quicksum(fixed_setup_cost * y[i] + eco_overhead_cost * z_eco[i] for i in range(n))
    
    model.setObjective(cost_reg + cost_eco + fixed_costs, GRB.MINIMIZE)

    # Constraints
    # 1. Demand Satisfaction: For each type j, total production across all modes and valid substitutes >= demand
    for j in range(n):
        model.addConstr(gp.quicksum(x_reg[i, j] + x_eco[i, j] for i in range(n) if (i, j) in x_reg) >= containers[j]['demand'], 
                        name=f"demand_fulfillment_{j}")

    # 2. General Setup Linking: If any production (Regular or Eco) occurs for type i, y[i] must be 1
    for i in range(n):
        total_prod_i = gp.quicksum(x_reg[i, j] + x_eco[i, j] for j in range(n) if (i, j) in x_reg)
        model.addConstr(total_prod_i <= M * y[i], name=f"general_setup_{i}")

    # 3. Eco Activation Linking: If Eco production occurs for type i, z_eco[i] must be 1
    for i in range(n):
        eco_prod_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(eco_prod_i <= M * z_eco[i], name=f"eco_activation_{i}")
        # Logic link: Eco activation implies general setup
        model.addConstr(z_eco[i] <= y[i], name=f"eco_y_link_{i}")

    # 4. Eco Capacity Share: Eco production for type i is limited to a share of total production for type i
    for i in range(n):
        total_prod_i = gp.quicksum(x_reg[i, j] + x_eco[i, j] for j in range(n) if (i, j) in x_reg)
        eco_prod_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(eco_prod_i <= eco_capacity_share * total_prod_i, name=f"eco_share_limit_{i}")

    # 5. Global Energy Limit: Total energy consumption across all types and modes must stay within max_total_energy_kwh
    total_energy_used = gp.quicksum(regular_energy_intensity * x_reg[i, j] + eco_energy_intensity * x_eco[i, j] 
                                    for (i, j) in x_reg)
    model.addConstr(total_energy_used <= max_total_energy_kwh, name="energy_directive_limit")

    # Solve the problem
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Fallback if no solution is found (though the problem should be feasible)
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
