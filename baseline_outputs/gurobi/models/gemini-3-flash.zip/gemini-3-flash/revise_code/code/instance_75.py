import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve_optimization():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Extract parameters
    a_p1 = params['product_a_process_1_time']
    a_p2 = params['product_a_process_2_time']
    b_p1 = params['product_b_process_1_time']
    b_p2 = params['product_b_process_2_time']
    T1 = params['available_time_process_1']
    T2 = params['available_time_process_2']
    T1_h = params['available_time_process_1_high']
    T2_h = params['available_time_process_2_high']
    c_per_b = params['byproduct_c_per_unit_b']
    max_c_s = params['max_byproduct_c_sales']
    thresh_c = params['threshold_c']
    bigM = params['bigM_disposal']
    cost_c_low = params['disposal_cost_per_unit_c']
    cost_c_high = params['disposal_cost_per_unit_c_high']
    prof_a = params['profit_per_unit_a']
    prof_b = params['profit_per_unit_b']
    prof_c = params['profit_per_unit_c']

    # Create the Gurobi model
    model = gp.Model("MaxProfitRevised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    xA = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="xA")
    xB = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="xB")
    cSold = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="cSold")
    cDisposed_low = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="cDisposed_low")
    cDisposed_high = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="cDisposed_high")
    h1 = model.addVar(vtype=GRB.BINARY, name="h1")
    h2 = model.addVar(vtype=GRB.BINARY, name="h2")

    # Objective: maximize total profit
    model.setObjective(
        prof_a * xA + prof_b * xB + prof_c * cSold - (cost_c_low * cDisposed_low + cost_c_high * cDisposed_high),
        GRB.MAXIMIZE
    )

    # Constraints
    # Process 1 time constraint with high-throughput option
    model.addConstr(a_p1 * xA + b_p1 * xB <= T1 + (T1_h - T1) * h1, "Process1Time")

    # Process 2 time constraint with high-throughput option
    model.addConstr(a_p2 * xA + b_p2 * xB <= T2 + (T2_h - T2) * h2, "Process2Time")

    # At most one reaction stage may use the high-throughput setting
    model.addConstr(h1 + h2 <= 1, "HighThroughputLimit")

    # By-product C balance: total C produced = C sold + C disposed (low + high)
    model.addConstr(cSold + cDisposed_low + cDisposed_high == c_per_b * xB, "ByproductBalance")

    # Maximum C that can be sold
    model.addConstr(cSold <= max_c_s, "MaxCSales")

    # Disposal threshold for C
    model.addConstr(cDisposed_low <= thresh_c, "MaxCDisposalLow")
    
    # Upper bound on high disposal (using provided bigM)
    model.addConstr(cDisposed_high <= bigM, "MaxCDisposalHigh")

    # Solve
    model.optimize()

    # Output results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_optimization()
