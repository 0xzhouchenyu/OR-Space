import os
import csv
from gurobipy import gp, GRB

def main():
    # Define base and data directories
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = params['fixed_order_cost']
    august_bulk_order_threshold = params['august_bulk_order_threshold']
    august_bulk_receiving_fee = params['august_bulk_receiving_fee']
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create Gurobi model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = model.addVars(months, lb=0, vtype=GRB.CONTINUOUS, name="buy")
    sell = model.addVars(months, lb=0, vtype=GRB.CONTINUOUS, name="sell")
    stock = model.addVars(months, lb=0, ub=warehouse_capacity, vtype=GRB.CONTINUOUS, name="stock")
    is_buying = model.addVars(months, vtype=GRB.BINARY, name="is_buying")
    august_bulk_active = model.addVar(vtype=GRB.BINARY, name="august_bulk_active")
    
    # Objective: maximize total profit (revenue - purchase cost - fixed order costs - August bulk fee)
    revenue = gp.quicksum(sell_price[m] * sell[m] for m in months)
    purchase_cost = gp.quicksum(buy_price[m] * buy[m] for m in months)
    fixed_costs = gp.quicksum(fixed_order_cost * is_buying[m] for m in months)
    august_fee = august_bulk_receiving_fee * august_bulk_active
    
    model.setObjective(revenue - purchase_cost - fixed_costs - august_fee, GRB.MAXIMIZE)
    
    # Constraints
    for i, m in enumerate(months):
        prev_stock = initial_stock if i == 0 else stock[months[i-1]]
        
        # Stock balance: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], name=f"balance_{m}")
        
        # Warehouse capacity constraint (after buying, before selling)
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, name=f"warehouse_after_buy_{m}")
        
        # Fixed order cost logic: buy[m] > 0 implies is_buying[m] = 1
        # Since buy[m] is limited by warehouse_capacity, we can use it as M
        model.addConstr(buy[m] <= warehouse_capacity * is_buying[m], name=f"is_buying_logic_{m}")
        
        # August specific bulk receiving fee logic
        if m == 8:
            # buy[8] > threshold implies august_bulk_active = 1
            model.addConstr(buy[m] <= august_bulk_order_threshold + (warehouse_capacity - august_bulk_order_threshold) * august_bulk_active, name="august_bulk_logic")
            
    # Solve the model
    model.optimize()
    
    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
