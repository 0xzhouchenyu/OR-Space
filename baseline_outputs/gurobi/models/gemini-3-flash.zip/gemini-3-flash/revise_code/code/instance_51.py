import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_demand(filepath):
    """Load nurse demand per time period from CSV."""
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand

def load_parameters(filepath):
    """Load general parameters from CSV."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    return params

def solve_nurse_scheduling():
    # File paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    demand_file = os.path.join(data_dir, 'table_1.csv')
    params_file = os.path.join(data_dir, 'general_parameters.csv')

    # Load data
    demand = load_demand(demand_file)
    params = load_parameters(params_file)

    # Extract parameters
    shift_duration = int(params['shift_duration'])
    regular_pay = float(params['regular_nurse_pay'])
    contract_pay = float(params['contract_nurse_pay'])
    outsourced_regular_start_index = int(params['outsourced_regular_start_index'])
    banned_contract_start_index = int(params['banned_contract_start_index'])
    max_total_contract_starts = int(params['max_total_contract_starts'])
    min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])
    daytime_period_indices = [int(idx) for idx in params['daytime_period_indices'].split(';')]

    num_periods = len(demand)
    
    # Initialize Gurobi model
    model = gp.Model("NurseScheduling")
    model.setParam('OutputFlag', 0)

    # Decision variables: regular (x) and contract (y) nurses starting at each shift
    x = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="x")
    y = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="y")

    # Objective: minimize total cost
    # Each nurse works shift_duration hours
    cost_per_regular = regular_pay * shift_duration
    cost_per_contract = contract_pay * shift_duration
    model.setObjective(gp.quicksum(cost_per_regular * x[j] + cost_per_contract * y[j] for j in range(num_periods)), GRB.MINIMIZE)

    # Coverage constraints: for each time period i, sum of nurses from shifts that cover period i >= demand[i]
    # Shift j covers periods j and (j+1) % num_periods (since duration is 8h and each period is 4h)
    for i in range(num_periods):
        # Period i is covered by shift i and shift (i-1) % num_periods
        model.addConstr(x[i] + y[i] + x[(i - 1) % num_periods] + y[(i - 1) % num_periods] >= demand[i], name=f"Demand_period_{i}")

    # Revision: Regular nurses cannot start at outsourced_regular_start_index
    model.addConstr(x[outsourced_regular_start_index] == 0, name="Outsourced_Regular_Start")

    # Revision: Contract nurses cannot start at banned_contract_start_index
    model.addConstr(y[banned_contract_start_index] == 0, name="Banned_Contract_Start")

    # Revision: Total contract starts are capped
    model.addConstr(gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts, name="Max_Contract_Starts")

    # Revision: Minimum regular nurses coverage for daytime periods
    for i in daytime_period_indices:
        # Regular nurses covering period i are from shift i and shift (i-1) % num_periods
        model.addConstr(x[i] + x[(i - 1) % num_periods] >= min_regular_daytime_coverage, name=f"Min_Regular_Daytime_{i}")

    # Solve the model
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_nurse_scheduling()
