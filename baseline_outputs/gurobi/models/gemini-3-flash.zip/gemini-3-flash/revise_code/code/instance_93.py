import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            params[name] = val
    
    # Extract parameters
    a1_yield = float(params['product_A1_yield'])
    a1_time = float(params['product_A1_time'])
    a2_yield = float(params['product_A2_yield'])
    a2_time = float(params['product_A2_time'])
    a3_yield = float(params['product_A3_yield'])
    a3_time = float(params['product_A3_time'])
    
    profit_a1 = float(params['profit_per_kg_A1'])
    profit_a2 = float(params['profit_per_kg_A2'])
    profit_a3 = float(params['profit_per_kg_A3'])
    
    milk_supply = float(params['daily_milk_supply'])
    labor_hours = float(params['daily_labor_hours'])
    
    cap_a_shared = float(params['cap_A_shared'])
    min_a2_kg = float(params['min_A2_kg'])
    min_a3_kg = float(params['min_A3_kg'])
    
    cleaning_loss = float(params['type_A_cleaning_loss_if_A3'])
    bonus_threshold = float(params['cold_chain_bonus_threshold_kg'])
    bonus_value = float(params['cold_chain_bonus_yuan'])
    
    # Create Gurobi model
    model = gp.Model("Dairy_Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: barrels of milk for each product
    x1 = model.addVar(lb=0, name="x1")
    x2 = model.addVar(lb=0, name="x2")
    x3 = model.addVar(lb=0, name="x3")
    
    # Binary variable for cold-chain bonus
    y_bonus = model.addVar(vtype=GRB.BINARY, name="y_bonus")
    
    # Objective: Maximize total profit
    # Profit = (kg produced * profit per kg) + bonus
    total_profit = (x1 * a1_yield * profit_a1) + \
                   (x2 * a2_yield * profit_a2) + \
                   (x3 * a3_yield * profit_a3) + \
                   (y_bonus * bonus_value)
    model.setObjective(total_profit, GRB.MAXIMIZE)
    
    # Constraints
    # 1. Milk supply constraint
    model.addConstr(x1 + x2 + x3 <= milk_supply, "Milk_Supply")
    
    # 2. Labor hours constraint
    model.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours, "Labor_Hours")
    
    # 3. Type A shared capacity constraint
    # Since min_a3_kg > 0, A3 is always produced, so cleaning loss always applies.
    model.addConstr(a1_yield * x1 + a3_yield * x3 <= cap_a_shared - cleaning_loss, "Type_A_Shared_Capacity")
    
    # 4. Minimum production requirements
    model.addConstr(a2_yield * x2 >= min_a2_kg, "Min_A2_Production")
    model.addConstr(a3_yield * x3 >= min_a3_kg, "Min_A3_Production")
    
    # 5. Cold-chain bonus threshold logic
    # y_bonus can only be 1 if A3 production reaches the threshold
    model.addConstr(a3_yield * x3 >= bonus_threshold * y_bonus, "Cold_Chain_Bonus_Threshold")
    
    # Solve the model
    model.optimize()
    
    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimization was not successful.")

if __name__ == "__main__":
    main()
