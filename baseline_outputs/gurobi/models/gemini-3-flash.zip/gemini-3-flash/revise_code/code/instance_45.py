import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define directories
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Read general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if row:
                params[row[0]] = float(row[1])

    # Read product segments and profits from table_1.csv
    segments = {}
    products_list = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row['Product']
            if p not in segments:
                segments[p] = []
                products_list.append(p)
            rng = row['Sales_Volume_Range']
            profit = float(row['Profit'])
            if rng.startswith('Above_'):
                lower = float(rng.split('_')[1])
                upper = None
            else:
                parts = rng.split('_')
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({'lower': lower, 'upper': upper, 'profit': profit})

    # Initialize Gurobi model
    model = gp.Model("Maximize_Profit")
    model.setParam('OutputFlag', 0)

    # Decision Variables
    x_total = {}
    total_profit_from_products = gp.LinExpr()
    
    # Process each product (Product_A, Product_B, Product_C)
    for prod in products_list:
        p_code = prod.split('_')[1]  # Extract 'A', 'B', or 'C'
        y_vars = []
        x_vars = []
        for i, seg in enumerate(segments[prod]):
            # Binary indicator for segment i
            y = model.addVar(vtype=GRB.BINARY, name=f"y_{p_code}_{i}")
            # Quantity variable for segment i
            x = model.addVar(vtype=GRB.INTEGER, name=f"x_{p_code}_{i}")
            
            lo = seg['lower']
            hi = seg['upper']
            
            # Constraints to link binary y and quantity x
            # Lower bound (inclusive if lo=0, else x > lo implies x >= lo+1)
            if lo == 0:
                model.addConstr(x >= 1 * y)
            else:
                model.addConstr(x >= (lo + 1) * y)
            
            # Upper bound (inclusive)
            if hi is not None:
                model.addConstr(x <= hi * y)
            else:
                # Use a large enough M based on capacity calculations
                model.addConstr(x <= 1000 * y)
            
            y_vars.append(y)
            x_vars.append(x)
            # All-units profit for this segment
            total_profit_from_products += x * seg['profit']
        
        # Product can only be in one segment (or zero if x=0)
        model.addConstr(gp.lpSum(y_vars) <= 1)
        x_total[p_code] = gp.lpSum(x_vars)

    # Overtime and Review Burden variables
    ot = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=params['overtime_cap_hours'], name="overtime")
    z_review = model.addVar(vtype=GRB.BINARY, name="z_review")

    # Resource Constraints
    # 1. Technical Preparation Time
    model.addConstr(
        gp.lpSum(params[f'technical_prep_time_{p}'] * x_total[p] for p in ['A', 'B', 'C']) 
        <= params['available_technical_prep_time']
    )
    
    # 2. Labor Time (Regular + Overtime)
    model.addConstr(
        gp.lpSum(params[f'labor_time_{p}'] * x_total[p] for p in ['A', 'B', 'C']) 
        <= params['available_labor_time'] + ot
    )
    
    # 3. Materials
    model.addConstr(
        gp.lpSum(params[f'materials_{p}'] * x_total[p] for p in ['A', 'B', 'C']) 
        <= params['available_materials']
    )
    
    # 4. Packaging Capacity
    model.addConstr(
        gp.lpSum(params[f'pack_units_{p}'] * x_total[p] for p in ['A', 'B', 'C']) 
        <= params['packaging_cap_units']
    )
    
    # 5. Second Overtime Review Fee Logic
    # If overtime > 100, z_review must be 1.
    model.addConstr(
        ot <= params['overtime_second_review_threshold'] + 
        (params['overtime_cap_hours'] - params['overtime_second_review_threshold']) * z_review
    )

    # Objective Function
    # Maximize: Total Sales Profit - Overtime Costs - One-time Review Fee
    objective = (
        total_profit_from_products 
        - (ot * params['overtime_cost_per_hour']) 
        - (z_review * params['overtime_second_review_fee'])
    )
    model.setObjective(objective, GRB.MAXIMIZE)

    # Solve the model
    model.optimize()

    # Output result
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.ObjVal, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
__name__ == "__main__":
    solve()
