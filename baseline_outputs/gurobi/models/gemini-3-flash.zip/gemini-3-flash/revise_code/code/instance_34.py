import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_goods_data(filepath):
    goods = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            goods[row['Goods_Type'].strip()] = {
                'quantity': int(row['Quantity'].strip()),
                'weight': float(row['Weight_per_Unit'].strip())
            }
    return goods

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
goods = load_goods_data(os.path.join(data_dir, 'table_1.csv'))
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

max_cap = params['max_container_capacity']
min_load = params['min_container_load']
min_d_per_container = int(params['min_d_goods_per_container'])
min_c_per_a = int(params['min_c_per_a'])

goods_types = list(goods.keys())
quantities = {g: goods[g]['quantity'] for g in goods_types}
weights = {g: goods[g]['weight'] for g in goods_types}

# Upper bound on number of containers
# Total D is 90, and each used container must have at least 10 D goods.
# Therefore, the maximum number of containers is 90 / 10 = 9.
max_containers = 9
N = range(max_containers)

# Create model
model = gp.Model("ContainerMinimization")
model.setParam('OutputFlag', 0)

# Decision variables
# x[g, j] = number of units of goods type g in container j
x = model.addVars(goods_types, N, vtype=GRB.INTEGER, name="x", lb=0)
# y[j] = 1 if container j is used
y = model.addVars(N, vtype=GRB.BINARY, name="y")
# e[j] = 1 if good E is in container j
e = model.addVars(N, vtype=GRB.BINARY, name="e")
# a[j] = 1 if good A is in container j
a = model.addVars(N, vtype=GRB.BINARY, name="a")

# Objective: minimize number of containers
model.setObjective(gp.quicksum(y[j] for j in N), GRB.MINIMIZE)

# Constraints

# 1. All goods must be transported
for g in goods_types:
    model.addConstr(gp.quicksum(x[g, j] for j in N) == quantities[g], name=f"demand_{g}")

# 2. Container capacity and fragility constraint for Goods E
# If E is present (e[j]=1), capacity is 45. Otherwise, capacity is 60.
for j in N:
    model.addConstr(gp.quicksum(weights[g] * x[g, j] for g in goods_types) <= max_cap * y[j] - 15 * e[j], name=f"cap_{j}")
    # Link e[j] to x['E', j]
    model.addConstr(x['E', j] <= quantities['E'] * e[j], name=f"e_indicator_{j}")
    model.addConstr(e[j] <= y[j], name=f"e_usage_{j}")

# 3. Minimum load constraint
for j in N:
    model.addConstr(gp.quicksum(weights[g] * x[g, j] for g in goods_types) >= min_load * y[j], name=f"min_load_{j}")

# 4. Minimum D goods per container (if container is used)
for j in N:
    model.addConstr(x['D', j] >= min_d_per_container * y[j], name=f"min_D_{j}")

# 5. If A goods are loaded, at least 1 C good must be loaded
for j in N:
    model.addConstr(x['A', j] <= quantities['A'] * a[j], name=f"a_indicator_{j}")
    model.addConstr(x['C', j] >= min_c_per_a * a[j], name=f"c_if_a_{j}")
    model.addConstr(a[j] <= y[j], name=f"a_usage_{j}")

# 6. Symmetry breaking
for j in range(max_containers - 1):
    model.addConstr(y[j] >= y[j+1], name=f"symmetry_{j}")

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {int(model.objVal)}")
else:
    print("No optimal solution found.")
