import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table1_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")

    # Read property data
    properties = []
    if not os.path.exists(table1_path):
        return
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            properties.append({
                'name': row['Property'],
                'income': float(row['Annual_Income']),
                'cost': float(row['Cost'])
            })

    # Read general parameters
    params = {}
    if not os.path.exists(params_path):
        return
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    # Model
    model = gp.Model("RealEstateInvestment")
    model.setParam('OutputFlag', 0)

    # Variables
    prop_names = [p['name'] for p in properties]
    # x[p] is 1 if property p is purchased
    x = model.addVars(prop_names, vtype=GRB.BINARY, name="x")
    # y[p] is 1 if property p has any risky tenants
    y = model.addVars(prop_names, vtype=GRB.BINARY, name="y")
    # r[p] is the fraction of property p allocated to risky tenants
    r = model.addVars(prop_names, vtype=GRB.CONTINUOUS, lb=0, ub=1, name="r")

    # Expected Risky Multiplier
    # E = scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier
    exp_risky_mult = (params['scen_1_prob'] * params['scen_1_risky_multiplier'] + 
                      params['scen_2_prob'] * params['scen_2_risky_multiplier'])

    # Objective: Maximize total expected income
    # Income_p = Income_p_base * ( (1-r_p) + r_p * exp_risky_mult ) if x_p=1 else 0
    # Income_p = Income_p_base * ( x_p + r_p * (exp_risky_mult - 1) )
    model.setObjective(gp.quicksum(p['income'] * (x[p['name']] + (exp_risky_mult - 1) * r[p['name']]) 
                                  for p in properties), GRB.MAXIMIZE)

    # Constraints
    # 1. Total budget constraint
    model.addConstr(gp.quicksum(x[p['name']] * p['cost'] for p in properties) <= params['budget'])

    # 2. Property 4 excludes Property 3 constraint
    if params.get('property_4_excludes_property_3', 0) == 1:
        if 'Property_4' in prop_names and 'Property_3' in prop_names:
            model.addConstr(x['Property_4'] + x['Property_3'] <= 1)

    # 3. Risky space constraints
    for p in properties:
        name = p['name']
        # Risky space is allowed only on properties actually bought
        model.addConstr(y[name] <= x[name])
        # Each individual property has its own per_property_risky_cap
        # Also, r[p] can only be > 0 if the gate y[p] is 1
        model.addConstr(r[name] <= params['per_property_risky_cap'] * y[name])

    # 4. Total risky budget (gate-based)
    # Total acquisition cost of properties that host any risky tenants must stay within total_risky_budget
    model.addConstr(gp.quicksum(y[p['name']] * p['cost'] for p in properties) <= params['total_risky_budget'])

    # 5. Maximum number of properties that may have any risky tenants
    model.addConstr(gp.quicksum(y[p['name']] for p in properties) <= params['max_risky_properties'])

    # Solve
    model.optimize()

    # Print result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
