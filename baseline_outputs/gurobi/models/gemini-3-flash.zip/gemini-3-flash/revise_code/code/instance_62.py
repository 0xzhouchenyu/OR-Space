import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    # Determine data directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load general parameters
    params = {}
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    with open(params_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    # Load restaurant data
    restaurants = []
    table_path = os.path.join(data_dir, 'table_1.csv')
    with open(table_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'std_hours': float(row['Standard_Staff_Hours'].strip()),
                'prem_hours': float(row['Premium_Staff_Hours'].strip())
            })
    return params, restaurants

def solve():
    params, restaurants = load_data()
    
    budget = params['investment_budget']
    uplift = params['premium_revenue_uplift']
    upgrade_cost = params['premium_upgrade_cost']
    staff_cap = params['staff_hours_cap']
    
    # Create the optimization model
    model = gp.Model("Restaurant_Investment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_std[r] = 1 if restaurant r is operated in Standard mode
    # x_prem[r] = 1 if restaurant r is operated in Premium mode
    x_std = {}
    x_prem = {}
    for r in restaurants:
        name = r['name']
        x_std[name] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}_std")
        x_prem[name] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}_prem")
        
    # Objective: Maximize total annual revenue
    # Standard revenue: r['revenue']
    # Premium revenue: r['revenue'] * (1 + uplift)
    model.setObjective(
        gp.quicksum(r['revenue'] * x_std[r['name']] + 
                    r['revenue'] * (1 + uplift) * x_prem[r['name']] 
                    for r in restaurants),
        GRB.MAXIMIZE
    )
    
    # Constraints
    
    # 1. Each restaurant can be Standard, Premium, or not purchased at all
    for r in restaurants:
        name = r['name']
        model.addConstr(x_std[name] + x_prem[name] <= 1, name=f"Mode_Selection_{name}")
        
    # 2. Budget constraint: Acquisition cost + Premium upgrade cost
    # Standard cost: r['cost']
    # Premium cost: r['cost'] + upgrade_cost
    model.addConstr(
        gp.quicksum(r['cost'] * x_std[r['name']] + 
                    (r['cost'] + upgrade_cost) * x_prem[r['name']] 
                    for r in restaurants) <= budget,
        name="Budget_Constraint"
    )
    
    # 3. Staffing constraint: Total staff hours across all acquired restaurants
    # Standard hours: r['std_hours']
    # Premium hours: r['prem_hours']
    model.addConstr(
        gp.quicksum(r['std_hours'] * x_std[r['name']] + 
                    r['prem_hours'] * x_prem[r['name']] 
                    for r in restaurants) <= staff_cap,
        name="Staffing_Constraint"
    )
    
    # 4. Exclusion constraint: If Restaurant D is purchased, Restaurant A cannot be purchased
    # (x_A_std + x_A_prem) + (x_D_std + x_D_prem) <= 1
    names = [r['name'] for r in restaurants]
    if 'Restaurant_A' in names and 'Restaurant_D' in names:
        model.addConstr(
            (x_std['Restaurant_A'] + x_prem['Restaurant_A']) + 
            (x_std['Restaurant_D'] + x_prem['Restaurant_D']) <= 1,
            name="D_A_Exclusion_Constraint"
        )
        
    # Solve the model
    model.optimize()
    
    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case no solution is found, though the problem structure suggests one exists
        print("FINAL_OBJ_VALUE: 0.0")

if __name__ == "__main__":
    solve()
