import gurobipy as gp
from gurobipy import GRB
import os
import csv

def solve():
    # Paths to data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    path_table = os.path.join(base_dir, "data", "table_1_7.csv")
    path_gen = os.path.join(base_dir, "data", "general_parameters.csv")
    
    # Load table_1_7.csv for raw material costs, limits, processing fees, and selling prices
    try:
        with open(path_table, 'r') as f:
            reader = list(csv.reader(f))
            rm_costs = {
                'A': float(reader[1][4]),
                'B': float(reader[2][4]),
                'C': float(reader[3][4])
            }
            rm_limits = {
                'A': float(reader[1][5]),
                'B': float(reader[2][5]),
                'C': float(reader[3][5])
            }
            proc_fees = {
                'A': float(reader[4][1]),
                'B': float(reader[4][2]),
                'C': float(reader[4][3])
            }
            sell_prices = {
                'A': float(reader[5][1]),
                'B': float(reader[5][2]),
                'C': float(reader[5][3])
            }
    except (FileNotFoundError, IndexError, ValueError) as e:
        return

    # Load general_parameters.csv for setup costs and the shared wrapper fee
    gen_params = {}
    try:
        with open(path_gen, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                gen_params[row['Parameter_Name']] = float(row['Value'])
    except (FileNotFoundError, ValueError) as e:
        return
        
    setup_costs = {
        'A': gen_params.get('SetupCost_A', 0.0),
        'B': gen_params.get('SetupCost_B', 0.0),
        'C': gen_params.get('SetupCost_C', 0.0)
    }
    shared_trigger = gen_params.get('BrandAB_SharedWrapper_Trigger', 0.0)
    shared_fee_val = gen_params.get('BrandAB_SharedWrapper_Fee', 0.0)
    shared_fee = shared_fee_val if shared_trigger == 1.0 else 0.0

    # Initialize model
    model = gp.Model("CandyFactoryOptimization")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    brands = ['A', 'B', 'C']
    materials = ['A', 'B', 'C']
    
    # x[i, j] = kilograms of raw material i used in brand j
    x = model.addVars(materials, brands, lb=0, vtype=GRB.CONTINUOUS, name="x")
    # y[j] = total kilograms of brand j produced
    y = model.addVars(brands, lb=0, vtype=GRB.CONTINUOUS, name="y")
    # z[j] = 1 if brand j is produced, 0 otherwise
    z = model.addVars(brands, vtype=GRB.BINARY, name="z")
    # shared_ab = 1 if both brand A and B are produced
    shared_ab = model.addVar(vtype=GRB.BINARY, name="shared_ab")
    
    # Constraints
    # Total production per brand
    for j in brands:
        model.addConstr(y[j] == gp.quicksum(x[i, j] for i in materials), name=f"total_prod_{j}")
        
    # Raw material usage limits
    for i in materials:
        model.addConstr(gp.quicksum(x[i, j] for j in brands) <= rm_limits[i], name=f"limit_{i}")
        
    # Composition constraints
    # Brand A: RM A >= 60%, RM C <= 20%
    model.addConstr(x['A', 'A'] >= 0.60 * y['A'], name="comp_A_A")
    model.addConstr(x['C', 'A'] <= 0.20 * y['A'], name="comp_A_C")
    
    # Brand B: RM A >= 15%, RM C <= 60%
    model.addConstr(x['A', 'B'] >= 0.15 * y['B'], name="comp_B_A")
    model.addConstr(x['C', 'B'] <= 0.60 * y['B'], name="comp_B_C")
    
    # Brand C: RM C <= 50%
    model.addConstr(x['C', 'C'] <= 0.50 * y['C'], name="comp_C_C")
    
    # Setup cost binary linking (BigM = total material capacity)
    bigM = sum(rm_limits.values())
    for j in brands:
        model.addConstr(y[j] <= bigM * z[j], name=f"setup_link_{j}")
        
    # Shared wrapper fee linking for Brand A and B
    model.addConstr(shared_ab >= z['A'] + z['B'] - 1, name="shared_wrapper_link")
    
    # Objective: Maximize Profit
    # Profit = Revenue - Raw Material Cost - Processing Fee - Fixed Setup Cost - Shared Fee
    revenue = gp.quicksum(sell_prices[j] * y[j] for j in brands)
    raw_material_cost = gp.quicksum(rm_costs[i] * x[i, j] for i in materials for j in brands)
    processing_cost = gp.quicksum(proc_fees[j] * y[j] for j in brands)
    setup_total = gp.quicksum(setup_costs[j] * z[j] for j in brands)
    shared_cost = shared_fee * shared_ab
    
    model.setObjective(revenue - raw_material_cost - processing_cost - setup_total - shared_cost, GRB.MAXIMIZE)
    
    # Solve the optimization problem
    model.optimize()
    
    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
