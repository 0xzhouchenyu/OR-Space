import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    return params

def solve_optimization():
    # Load data
    # The script is executed from the root directory, and data is in the 'data' subdirectory.
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = load_parameters(data_path)

    # Extract parameters
    num_students = int(params['num_students'])
    num_buses = int(params['num_buses'])
    bus_capacity = int(params['bus_capacity'])
    num_minibuses = int(params['num_minibuses'])
    minibus_capacity = int(params['minibus_capacity'])
    num_drivers = int(params['num_drivers'])
    bus_rental_cost = float(params['bus_rental_cost'])
    minibus_rental_cost = float(params['minibus_rental_cost'])

    # Create the optimization model
    model = gp.Model("SchoolTrip")
    
    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x: number of buses, y: number of minibuses
    # Constraints: 
    # - x must be between 0 and num_buses
    # - y must be between 1 and num_minibuses (at least one minibus required)
    x = model.addVar(vtype=GRB.INTEGER, name="buses", lb=0, ub=num_buses)
    y = model.addVar(vtype=GRB.INTEGER, name="minibuses", lb=1, ub=num_minibuses)

    # Objective: minimize total rental cost
    model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

    # Constraints
    # 1. Must transport all students
    model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, "StudentCapacity")

    # 2. Total vehicles (drivers) constraint
    model.addConstr(x + y <= num_drivers, "DriverLimit")

    # 3. Safety policy: for every minibus rented, at least two buses must be rented
    model.addConstr(x >= 2 * y, "SafetyPolicy")

    # Solve the model
    model.optimize()

    # Output the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_optimization()
