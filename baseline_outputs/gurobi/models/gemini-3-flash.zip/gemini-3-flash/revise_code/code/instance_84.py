import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Define paths to data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Extract parameters
    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = params['min_manager_experience']
    manager_bonus = params['manager_bonus_per_candidate']

    # Create optimization model
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0)

    # Roles
    roles = ['Manager', 'Specialist']
    candidate_names = [c['name'] for c in candidates]

    # Decision variables: binary for each candidate and role
    # x[c, r] = 1 if candidate c is hired for role r, 0 otherwise
    x = model.addVars(candidate_names, roles, vtype=GRB.BINARY, name="x")

    # Helper variable: y[c] = 1 if candidate c is hired for any role
    y = model.addVars(candidate_names, vtype=GRB.BINARY, name="y")

    # Objective: minimize total salary (base salary + manager bonuses)
    # Staffing value = sum(base_salary * hired) + sum(manager_bonus * manager_role)
    model.setObjective(
        gp.quicksum(c['salary'] * y[c['name']] for c in candidates) +
        gp.quicksum(manager_bonus * x[c['name'], 'Manager'] for c in candidates),
        GRB.MINIMIZE
    )

    # Constraints
    # 1. Each hired candidate may serve in exactly one role
    for c in candidates:
        model.addConstr(x[c['name'], 'Manager'] + x[c['name'], 'Specialist'] == y[c['name']])

    # 2. Total employees headcount limits
    model.addConstr(gp.quicksum(y[c['name']] for c in candidates) <= max_employees)
    model.addConstr(gp.quicksum(y[c['name']] for c in candidates) >= min_employees)

    # 3. Budget limit for base salaries (excluding manager bonus)
    model.addConstr(gp.quicksum(c['salary'] * y[c['name']] for c in candidates) <= budget_limit)

    # 4. At least one candidate with Master's or Doctoral degree
    advanced_candidates = [c['name'] for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(y[name] for name in advanced_candidates) >= min_advanced)

    # 5. Minimum total work experience of selected candidates
    model.addConstr(gp.quicksum(c['experience'] * y[c['name']] for c in candidates) >= min_experience)

    # 6. At most one candidate from pair A and E
    model.addConstr(y['A'] + y['E'] <= max_equivalent)

    # 7. Manager headcount limits
    model.addConstr(gp.quicksum(x[c['name'], 'Manager'] for c in candidates) >= min_managers)
    model.addConstr(gp.quicksum(x[c['name'], 'Manager'] for c in candidates) <= max_managers)

    # 8. Minimum total work experience of hired managers
    model.addConstr(gp.quicksum(c['experience'] * x[c['name'], 'Manager'] for c in candidates) >= min_manager_experience)

    # Solve
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
