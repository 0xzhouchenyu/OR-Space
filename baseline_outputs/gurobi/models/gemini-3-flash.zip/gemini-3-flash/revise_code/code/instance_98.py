import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Define data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
            
    # Read product data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
            
    # Create Gurobi model
    model = gp.Model("Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[p] is the quantity of product p produced
    x = {}
    # y[p] is a binary variable: 1 if product p is produced, 0 otherwise
    y = {}
    for p in products:
        name = p['Product']
        x[name] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{name}")
        y[name] = model.addVar(vtype=GRB.BINARY, name=f"y_{name}")
        
    # Overtime hours
    ot = model.addVar(lb=0, ub=params['max_overtime'], vtype=GRB.CONTINUOUS, name="overtime")
    
    # Binary variable for overtime review fee (if overtime > threshold)
    z_ot = model.addVar(vtype=GRB.BINARY, name="z_ot")
    
    # Binary variable for Product A line audit fee (if x_A > threshold)
    z_A = model.addVar(vtype=GRB.BINARY, name="z_A")
    
    # Big M for setup and threshold constraints
    # Max possible x_A is limited by labor: (300 + 30) / 11 = 30
    # Max possible x_B is limited by labor: (300 + 30) / 24 = 13.75
    M_A = 40
    M_B = 20
    
    # Constraints
    # Steel constraint
    model.addConstr(gp.quicksum(float(p['Steel_Required_kg']) * x[p['Product']] for p in products) <= params['available_steel'], "Steel")
    
    # Aluminum constraint
    model.addConstr(gp.quicksum(float(p['Aluminum_Required_kg']) * x[p['Product']] for p in products) <= params['available_aluminum'], "Aluminum")
    
    # Labor constraint (including overtime)
    model.addConstr(gp.quicksum(float(p['Labor_Required_hours']) * x[p['Product']] for p in products) <= params['available_labor'] + ot, "Labor")
    
    # Setup cost constraints
    model.addConstr(x['A'] <= M_A * y['A'], "Setup_A")
    model.addConstr(x['B'] <= M_B * y['B'], "Setup_B")
    
    # Overtime review fee trigger: if ot > threshold, z_ot must be 1
    model.addConstr(ot <= params['overtime_review_threshold'] + (params['max_overtime'] - params['overtime_review_threshold']) * z_ot, "OT_Review_Trigger")
    
    # Product A line audit fee trigger: if x_A > threshold, z_A must be 1
    model.addConstr(x['A'] <= params['product_A_line_audit_threshold'] + (M_A - params['product_A_line_audit_threshold']) * z_A, "Line_Audit_Trigger")
    
    # Objective function: Maximize Profit
    # Profit = (Sum of product profits) - (Setup costs) - (Overtime pay) - (Overtime review fee) - (Line audit fee)
    total_profit = gp.quicksum(float(p['Profit_yuan']) * x[p['Product']] for p in products)
    total_setup_cost = gp.quicksum(float(p['Setup_Cost_yuan']) * y[p['Product']] for p in products)
    total_overtime_cost = params['overtime_pay'] * ot + params['overtime_review_fee'] * z_ot
    total_audit_cost = params['product_A_line_audit_fee'] * z_A
    
    model.setObjective(total_profit - total_setup_cost - total_overtime_cost - total_audit_cost, GRB.MAXIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Print the objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimization was not optimal.")

if __name__ == "__main__":
    main()
