import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_csv_data(filepath):
    """Loads CSV file and returns a list of dictionaries."""
    data = []
    if not os.path.exists(filepath):
        return data
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

def main():
    # Define file paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    table1_path = os.path.join(data_dir, 'table_1.csv')

    # Load data from CSV files
    params_data = load_csv_data(params_path)
    table1_data = load_csv_data(table1_path)

    # Parse parameters from general_parameters.csv
    params = {row['Parameter_Name']: float(row['Value']) for row in params_data}
    
    # Parse table_1.csv
    # Row 0: Process I
    a_I = float(table1_data[0]['Model_A_hours_per_unit'])
    b_I = float(table1_data[0]['Model_B_hours_per_unit'])
    # Row 1: Process II
    a_II = float(table1_data[1]['Model_A_hours_per_unit'])
    b_II = float(table1_data[1]['Model_B_hours_per_unit'])
    cap_II_regular = float(table1_data[1]['Maximum_Weekly_Processing_Capacity'])
    # Row 2: Profit information
    profit_A = float(table1_data[2]['Model_A_hours_per_unit'])
    profit_B = float(table1_data[2]['Model_B_hours_per_unit'])

    # Parse general parameters
    min_profit = params['min_weekly_profit']
    min_A = params['min_model_A_units']
    min_B = params['min_model_B_units']
    proc_I_exact_hours = params['process_I_hours']
    max_ot_II = params['process_II_max_overtime']
    red_A = params['model_A_overtime_profit_reduction']
    red_B = params['model_B_overtime_profit_reduction']

    # Initialize the Gurobi model
    model = gp.Model("Microcomputer_Production_Optimization")
    model.setParam('OutputFlag', 0)

    # Variables
    # We split production into regular and overtime components based on Process II usage
    xA_r = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA_regular")
    xA_o = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA_overtime")
    xB_r = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB_regular")
    xB_o = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB_overtime")

    total_A = xA_r + xA_o
    total_B = xB_r + xB_o

    # Objective: Maximize market share (total units of A and B)
    model.setObjective(total_A + total_B, GRB.MAXIMIZE)

    # Constraints
    # 1. Process I must use an exact amount of processing hours
    model.addConstr(a_I * total_A + b_I * total_B == proc_I_exact_hours, name="Process_I_Exact")

    # 2. Process II regular weekly capacity
    model.addConstr(a_II * xA_r + b_II * xB_r <= cap_II_regular, name="Process_II_Regular_Cap")

    # 3. Process II maximum allowable overtime
    model.addConstr(a_II * xA_o + b_II * xB_o <= max_ot_II, name="Process_II_Overtime_Cap")

    # 4. Minimum production requirements for model A
    model.addConstr(total_A >= min_A, name="Min_Model_A")

    # 5. Minimum production requirements for model B
    model.addConstr(total_B >= min_B, name="Min_Model_B")

    # 6. Minimum total weekly profit threshold
    # Profit calculation: Base profit minus any reduction due to overtime units in Process II
    total_profit = (profit_A * total_A + profit_B * total_B - 
                    red_A * xA_o - red_B * xB_o)
    model.addConstr(total_profit >= min_profit, name="Min_Profit_Threshold")

    # Solve the optimization problem
    model.optimize()

    # Output the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
