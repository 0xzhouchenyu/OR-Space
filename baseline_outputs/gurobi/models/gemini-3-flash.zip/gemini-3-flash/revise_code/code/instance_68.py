import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_coal_distribution():
    # Get data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    # Load distances from table_1.csv
    distances = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            yard = row['Coal_Yard'].strip()
            area = int(row['Residential_Area'].strip())
            dist = float(row['Distance_km'].strip())
            distances[(yard, area)] = dist

    # Load parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val

    # Define yards and areas
    yards = ['A', 'B']
    areas = [1, 2, 3]

    # Define demand and min supply
    demand = {
        1: params['residential_area_1_demand'],
        2: params['residential_area_2_demand'],
        3: params['residential_area_3_demand']
    }
    min_supply = {
        'A': params['min_coal_yard_A'],
        'B': params['min_coal_yard_B_adjusted']
    }

    # Create Gurobi model
    model = gp.Model("Coal_Distribution")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {}
    x_A3_base = None
    x_A3_excess = None

    for (yard, area) in distances:
        if yard == 'A' and area == 3:
            # Special handling for A-to-Area-3 staging limit
            x_A3_base = model.addVar(lb=0, ub=params['area3_A_staging_threshold'], name="x_A3_base")
            x_A3_excess = model.addVar(lb=0, name="x_A3_excess")
            x[(yard, area)] = x_A3_base + x_A3_excess
        else:
            x[(yard, area)] = model.addVar(lb=0, name=f"x_{yard}_{area}")

    # Objective: minimize total transportation cost
    obj = gp.LinExpr()
    for (yard, area), dist in distances.items():
        if yard == 'A' and area == 3:
            # First 40 tons use normal lane; tonnage above 40 tons carries extra handling cost
            obj += dist * x_A3_base + (dist + params['area3_A_excess_staging_cost']) * x_A3_excess
        else:
            obj += dist * x[(yard, area)]
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints:
    # 1. Each residential area must receive exactly its demand
    for area in areas:
        model.addConstr(gp.quicksum(x[(yard, area)] for yard in yards if (yard, area) in distances) == demand[area], name=f"Demand_{area}")

    # 2. Each coal yard must supply at least its minimum requirement
    for yard in yards:
        model.addConstr(gp.quicksum(x[(yard, area)] for area in areas if (yard, area) in distances) >= min_supply[yard], name=f"Min_Supply_{yard}")

    # 3. Minimum share of residential area 3 demand that must be supplied by coal yard A
    if ('A', 3) in distances:
        model.addConstr(x[('A', 3)] >= params['min_share_area3_from_A'] * demand[3], name="Min_Share_Area3_A")

    # Solve
    model.optimize()

    # Print objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_coal_distribution()
