import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    # Read data
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    df = pd.read_csv(csv_path)
    params = dict(zip(df['Parameter_Name'], df['Value']))

    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # Create model
    model = gp.Model("Maximize_GDP")
    model.setParam('OutputFlag', 0)

    # Variables
    # x: Production levels
    # m: Imports of finished commodities
    # e: Exports of finished commodities
    x = model.addVars(commodities, lb=0, name="x")
    m = model.addVars(commodities, lb=0, ub=params['import_quota'], name="m")
    e = model.addVars(commodities, lb=0, name="e")
    
    # Overtime labor variable
    L_ot = model.addVar(lb=0, ub=params['overtime_cap'], name="L_ot")

    # Apply production upper bounds if they exist in params
    for c in commodities:
        for suffix in ['_production_limit', '_limit', '_capacity']:
            key = f"{c}{suffix}"
            if key in params:
                x[c].ub = params[key]

    # Material Balance Constraints:
    # Production + Imports = Domestic Consumption + Exports
    # Domestic consumption of commodity c = sum over all c' of (c'_c_requirement * x[c'])
    for c in commodities:
        consumed = gp.quicksum(
            params.get(f"{c_prime}_{c}_requirement", 0.0) * x[c_prime]
            for c_prime in commodities
        )
        model.addConstr(x[c] + m[c] == consumed + e[c], name=f"Material_Balance_{c}")

    # Labor Constraint:
    # Total labor used <= labor_force + overtime_cap
    total_labor_used = gp.quicksum(
        params.get(f"{c}_labor_requirement", 0.0) * x[c] for c in commodities
    )
    model.addConstr(total_labor_used <= params['labor_force'] + L_ot, name="Labor_Limit")

    # Objective: Maximize GDP
    # GDP = (Export Revenue) - (Import Costs of finished goods) - (Import Costs of intermediate goods) - (Overtime Labor Costs)
    
    export_revenue = gp.quicksum(params[f"{c}_price"] * e[c] for c in commodities)
    
    # Finished goods imports cost world price * import_premium_ratio
    import_finished_cost = gp.quicksum(
        params[f"{c}_price"] * params['import_premium_ratio'] * m[c] 
        for c in commodities
    )
    
    # Intermediate goods imports cost (other imported goods required for production)
    import_intermediate_cost = gp.quicksum(
        params.get(f"{c}_import_cost", 0.0) * x[c] for c in commodities
    )
    
    # Overtime labor cost
    overtime_cost = params['overtime_wage'] * L_ot
    
    gdp = export_revenue - import_finished_cost - import_intermediate_cost - overtime_cost
    model.setObjective(gdp, GRB.MAXIMIZE)

    # Solve the model
    model.optimize()

    if model.status == GRB.OPTIMAL:
        return model.objVal
    else:
        return None

if __name__ == '__main__':
    result = solve()
    if result is not None:
        print(f"FINAL_OBJ_VALUE: {result}")
    else:
        print("FINAL_OBJ_VALUE: None")

```
