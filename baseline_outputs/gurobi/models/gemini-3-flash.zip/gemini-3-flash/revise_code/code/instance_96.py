import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # File paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")

    # Load data
    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    params = dict(zip(df_params['Parameter_Name'], df_params['Value']))

    # Customer requirements
    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)

    # Supplier 1 parameters
    raw_pipe_length_s1 = float(params['raw_pipe_length_supplier1'])
    max_patterns_s1 = int(params['max_cutting_patterns_supplier1'])
    max_cuts_s1 = int(params['max_cuts_per_pipe_supplier1'])
    max_leftover_s1 = float(params['max_leftover_length_supplier1'])
    purchase_cost_s1 = float(params['purchase_cost_per_pipe_supplier1'])
    
    # Supplier 2 parameters
    raw_pipe_length_s2 = float(params['raw_pipe_length_supplier2'])
    max_patterns_s2 = int(params['max_cutting_patterns_supplier2'])
    max_cuts_s2 = int(params['max_cuts_per_pipe_supplier2'])
    max_leftover_s2 = float(params['max_leftover_length_supplier2'])
    purchase_cost_s2 = float(params['purchase_cost_per_pipe_supplier2'])

    # Supplier 1 discount terms
    discount_qty_s1 = float(params['discount_tier1_supplier1_max_qty'])
    fixed_discount_s1 = float(params['fixed_discount_tier2_supplier1'])
    bigM_discount = float(params['bigM_discount'])

    # Ranking-based cost rates
    def get_cost_rates(s_idx):
        rates = []
        rank_prefixes = ['most', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth']
        for prefix in rank_prefixes:
            key = f"{prefix}_frequent_pattern_cost_rate_supplier{s_idx}"
            if key in params:
                rates.append(float(params[key]))
        return rates

    rates_s1 = get_cost_rates(1)
    rates_s2 = get_cost_rates(2)

    # Function to generate all feasible cutting patterns for a supplier
    def generate_patterns(raw_length, max_cuts, max_leftover):
        min_length = raw_length - max_leftover
        feasible_patterns = []
        def backtrack(idx, current_len, current_cuts, current_pattern):
            if idx == n_items:
                if current_len >= min_length and current_len <= raw_length and 0 < current_cuts <= max_cuts:
                    feasible_patterns.append(list(current_pattern))
                return
            
            max_qty = min(int((raw_length - current_len) // lengths[idx]), max_cuts - current_cuts)
            for q in range(max_qty + 1):
                current_pattern.append(q)
                backtrack(idx + 1, current_len + q * lengths[idx], current_cuts + q, current_pattern)
                current_pattern.pop()
        
        backtrack(0, 0, 0, [])
        return feasible_patterns

    pats_s1 = generate_patterns(raw_pipe_length_s1, max_cuts_s1, max_leftover_s1)
    pats_s2 = generate_patterns(raw_pipe_length_s2, max_cuts_s2, max_leftover_s2)

    # Optimization model
    model = gp.Model("Pipe_Cutting_Optimization")
    model.setParam('OutputFlag', 0)

    # Big M for logic constraints (total items needed is a safe bound)
    M_pipes = sum(demands)

    # Variables for Supplier 1
    y1 = model.addVars(len(pats_s1), vtype=GRB.INTEGER, lb=0, name="y1") # Num pipes per pattern
    z1 = model.addVars(len(pats_s1), vtype=GRB.BINARY, name="z1")        # Is pattern used?
    u1 = model.addVars(max_patterns_s1, vtype=GRB.BINARY, name="u1")    # Is rank k used?
    x1 = model.addVars(len(pats_s1), max_patterns_s1, vtype=GRB.BINARY, name="x1") # Pattern p is rank k?
    w1 = model.addVars(len(pats_s1), max_patterns_s1, vtype=GRB.INTEGER, lb=0, name="w1") # Assignment helper

    # Variables for Supplier 2
    y2 = model.addVars(len(pats_s2), vtype=GRB.INTEGER, lb=0, name="y2")
    z2 = model.addVars(len(pats_s2), vtype=GRB.BINARY, name="z2")
    u2 = model.addVars(max_patterns_s2, vtype=GRB.BINARY, name="u2")
    x2 = model.addVars(len(pats_s2), max_patterns_s2, vtype=GRB.BINARY, name="x2")
    w2 = model.addVars(len(pats_s2), max_patterns_s2, vtype=GRB.INTEGER, lb=0, name="w2")

    # Discount binary
    d1 = model.addVar(vtype=GRB.BINARY, name="discount_active_s1")

    # Objective Function
    # 1. Base purchase costs
    base_cost = gp.quicksum(y1[p] * purchase_cost_s1 for p in range(len(pats_s1))) + \
                gp.quicksum(y2[p] * purchase_cost_s2 for p in range(len(pats_s2)))
    
    # 2. Ranking-based pattern overhead costs
    extra_cost = gp.quicksum(w1[p, k] * rates_s1[k] for p in range(len(pats_s1)) for k in range(min(max_patterns_s1, len(rates_s1)))) + \
                 gp.quicksum(w2[p, k] * rates_s2[k] for p in range(len(pats_s2)) for k in range(min(max_patterns_s2, len(rates_s2))))
    
    # 3. Fixed discount for Supplier 1
    total_cost = base_cost + extra_cost - d1 * fixed_discount_s1
    model.setObjective(total_cost, GRB.MINIMIZE)

    # Constraints
    # Demand satisfaction
    for i in range(n_items):
        model.addConstr(
            gp.quicksum(pats_s1[p][i] * y1[p] for p in range(len(pats_s1))) +
            gp.quicksum(pats_s2[p][i] * y2[p] for p in range(len(pats_s2))) >= demands[i]
        )

    # Supplier 1 internal logic
    for p in range(len(pats_s1)):
        model.addConstr(y1[p] <= M_pipes * z1[p])
        model.addConstr(gp.quicksum(x1[p, k] for k in range(max_patterns_s1)) == z1[p])
        model.addConstr(gp.quicksum(w1[p, k] for k in range(max_patterns_s1)) == y1[p])
        for k in range(max_patterns_s1):
            model.addConstr(w1[p, k] <= M_pipes * x1[p, k])
            
    for k in range(max_patterns_s1):
        model.addConstr(gp.quicksum(x1[p, k] for p in range(len(pats_s1))) == u1[k])
        if k < max_patterns_s1 - 1:
            model.addConstr(u1[k] >= u1[k+1])
    model.addConstr(gp.quicksum(z1[p] for p in range(len(pats_s1))) <= max_patterns_s1)

    # Supplier 2 internal logic
    for p in range(len(pats_s2)):
        model.addConstr(y2[p] <= M_pipes * z2[p])
        model.addConstr(gp.quicksum(x2[p, k] for k in range(max_patterns_s2)) == z2[p])
        model.addConstr(gp.quicksum(w2[p, k] for k in range(max_patterns_s2)) == y2[p])
        for k in range(max_patterns_s2):
            model.addConstr(w2[p, k] <= M_pipes * x2[p, k])
            
    for k in range(max_patterns_s2):
        model.addConstr(gp.quicksum(x2[p, k] for p in range(len(pats_s2))) == u2[k])
        if k < max_patterns_s2 - 1:
            model.addConstr(u2[k] >= u2[k+1])
    model.addConstr(gp.quicksum(z2[p] for p in range(len(pats_s2))) <= max_patterns_s2)

    # Discount logic for Supplier 1
    total_y1 = gp.quicksum(y1[p] for p in range(len(pats_s1)))
    model.addConstr(total_y1 <= discount_qty_s1 + bigM_discount * d1)
    model.addConstr(total_y1 >= (discount_qty_s1 + 1) - bigM_discount * (1 - d1))

    # Solve model
    model.optimize()

    # Output results
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
