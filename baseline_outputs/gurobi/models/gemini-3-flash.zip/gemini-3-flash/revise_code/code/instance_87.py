import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Define data directory and load parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Extract parameters
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    
    base_a = params['base_fleet_type_a']
    base_b = params['base_fleet_type_b']
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    
    threshold_b = params['type_b_recovery_threshold']
    fee_b = params['type_b_recovery_fee']
    
    threshold_total = params['total_fleet_surge_threshold']
    fee_total = params['total_fleet_surge_fee']
    
    # Create the optimization model
    model = gp.Model("TruckRental")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeA_trucks")
    y = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeB_trucks")
    
    # Penalty variables for exceeding base fleet
    p_a = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="PenaltyA")
    p_b = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="PenaltyB")
    
    # Binary variables for fixed recovery fees
    z_b = model.addVar(vtype=GRB.BINARY, name="TypeB_Recovery_Gate")
    z_total = model.addVar(vtype=GRB.BINARY, name="Total_Fleet_Surge_Gate")
    
    # Objective: minimize total cost
    # Total Cost = Rental + Penalty + Fixed Recovery Fees
    model.setObjective(
        cost_a * x + cost_b * y + 
        penalty_a * p_a + penalty_b * p_b + 
        fee_b * z_b + fee_total * z_total, 
        GRB.MINIMIZE
    )
    
    # Constraints
    # 1. Cargo requirements
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedRequirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedRequirement")
    
    # 2. Penalty calculations (p = max(0, count - base))
    model.addConstr(p_a >= x - base_a, "PenaltyA_Constraint")
    model.addConstr(p_b >= y - base_b, "PenaltyB_Constraint")
    
    # 3. Fixed fee gates (Big M formulation)
    # If count > threshold, then binary variable must be 1
    M = 10000  # Large constant
    model.addConstr(y - threshold_b <= M * z_b, "TypeB_Recovery_Gate_Constraint")
    model.addConstr((x + y) - threshold_total <= M * z_total, "Total_Fleet_Surge_Gate_Constraint")
    
    # Solve the model
    model.optimize()
    
    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("Optimization was not successful.")

if __name__ == "__main__":
    main()
