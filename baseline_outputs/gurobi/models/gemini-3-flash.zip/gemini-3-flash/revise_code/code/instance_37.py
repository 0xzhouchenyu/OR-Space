import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_microcomputer_production():
    # Data directory path
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'table_1.csv')
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        rows = list(reader)
    
    # Parse data from tables
    a_I = float(rows[0][1])
    b_I = float(rows[0][2])
    # cap_I from table_1 or general_parameters - they match. Using general_parameters as source.
    cap_I = params['process_I_hours']
    
    a_II = float(rows[1][1])
    b_II = float(rows[1][2])
    cap_II = params['process_II_hours']
    
    profit_A = float(rows[2][1])
    profit_B = float(rows[2][2])
    
    # Define model
    model = gp.Model("Microcomputer_Production_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision Variables
    # Weekly production/sales units
    x_A1 = model.addVar(lb=0, name="x_A1")
    x_B1 = model.addVar(lb=0, name="x_B1")
    x_A2 = model.addVar(lb=0, name="x_A2")
    x_B2 = model.addVar(lb=0, name="x_B2")
    
    # Overtime hours per week per process
    ot_I1 = model.addVar(lb=0, ub=params['max_overtime_I_per_week'], name="ot_I1")
    ot_I2 = model.addVar(lb=0, ub=params['max_overtime_I_per_week'], name="ot_I2")
    ot_II1 = model.addVar(lb=0, ub=params['max_overtime_II_per_week'], name="ot_II1")
    ot_II2 = model.addVar(lb=0, ub=params['max_overtime_II_per_week'], name="ot_II2")
    
    # Regular hours used per week per process (used for utilization constraints)
    reg_I1 = model.addVar(lb=0, ub=cap_I, name="reg_I1")
    reg_I2 = model.addVar(lb=0, ub=cap_I, name="reg_I2")
    reg_II1 = model.addVar(lb=0, ub=cap_II, name="reg_II1")
    reg_II2 = model.addVar(lb=0, ub=cap_II, name="reg_II2")
    
    # Fatigue threshold indicators
    z_I1 = model.addVar(vtype=GRB.BINARY, name="z_I1")
    z_II1 = model.addVar(vtype=GRB.BINARY, name="z_II1")
    
    # Objective Function: Total net profit after overtime spending over 2 weeks
    total_revenue = profit_A * (x_A1 + x_A2) + profit_B * (x_B1 + x_B2)
    total_ot_cost = (params['overtime_premium_I'] * (ot_I1 + ot_I2) + 
                    params['overtime_premium_II'] * (ot_II1 + ot_II2))
    net_profit = total_revenue - total_ot_cost
    model.setObjective(net_profit, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Total net profit constraint
    model.addConstr(net_profit >= params['min_weekly_profit'], "Min_Net_Profit")
    
    # 2. Total production requirements over two weeks
    model.addConstr(x_A1 + x_A2 >= params['min_model_A_units'], "Total_Min_A")
    model.addConstr(x_B1 + x_B2 >= params['min_model_B_units'], "Total_Min_B")
    
    # 3. Weekly delivery requirements
    model.addConstr(x_A1 >= params['week1_min_model_A_units'], "Week1_Min_A")
    model.addConstr(x_B1 >= params['week1_min_model_B_units'], "Week1_Min_B")
    model.addConstr(x_A2 >= params['week2_min_model_A_units'], "Week2_Min_A")
    model.addConstr(x_B2 >= params['week2_min_model_B_units'], "Week2_Min_B")
    
    # 4. Week 1 Processing Capacity & Regular vs Overtime split
    model.addConstr(a_I * x_A1 + b_I * x_B1 == reg_I1 + ot_I1, "Process_I_Split_W1")
    model.addConstr(a_II * x_A1 + b_II * x_B1 == reg_II1 + ot_II1, "Process_II_Split_W1")
    
    # 5. Week 1 Overtime Fatigue Threshold Logic
    model.addConstr(ot_I1 <= params['week1_overtime_fatigue_threshold_I'] + 
                    (params['max_overtime_I_per_week'] - params['week1_overtime_fatigue_threshold_I']) * z_I1, "Fatigue_I_Logic")
    model.addConstr(ot_II1 <= params['week1_overtime_fatigue_threshold_II'] + 
                    (params['max_overtime_II_per_week'] - params['week1_overtime_fatigue_threshold_II']) * z_II1, "Fatigue_II_Logic")
    
    # 6. Week 2 Processing Capacity & Regular vs Overtime split (with recovery loss)
    model.addConstr(reg_I2 <= cap_I - params['week2_recovery_loss_I'] * z_I1, "Reg_Cap_I_W2")
    model.addConstr(reg_II2 <= cap_II - params['week2_recovery_loss_II'] * z_II1, "Reg_Cap_II_W2")
    
    model.addConstr(a_I * x_A2 + b_I * x_B2 == reg_I2 + ot_I2, "Process_I_Split_W2")
    model.addConstr(a_II * x_A2 + b_II * x_B2 == reg_II2 + ot_II2, "Process_II_Split_W2")
    
    # 7. Average utilization constraints (based on total standard regular hours)
    model.addConstr((reg_I1 + reg_I2) >= params['min_avg_utilization_I'] * (2 * cap_I), "Utilization_I")
    model.addConstr((reg_II1 + reg_II2) >= params['min_avg_utilization_II'] * (2 * cap_II), "Utilization_II")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Model did not converge to an optimal solution.")

if __name__ == "__main__":
    solve_microcomputer_production()
