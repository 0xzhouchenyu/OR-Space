import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_problem():
    # Define file paths using os.path.join for cross-platform compatibility
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    table1_path = os.path.join(data_dir, 'table_1.csv')
    gen_params_path = os.path.join(data_dir, 'general_parameters.csv')

    # Read production rates and workshop capacities from table_1.csv
    workshops = []
    capacities = {}
    rates = {}  # Store production rates as rates[(workshop, component_id)]
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())

    # Read all general parameters including shift limits and penalties
    params = {}
    with open(gen_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val_str = row['Value'].strip()
            if val_str:
                params[name] = float(val_str)

    # Initialize Gurobi model
    model = gp.Model("Maximize_Completed_Products_Revised")
    model.setParam('OutputFlag', 0)  # Suppress Gurobi standard output

    # Decision sets
    components = [1, 2, 3]
    shifts = ['day', 'night']
    types = ['regular', 'overtime']

    # Decision variables
    # x[workshop, component, shift, type]: allocation of hours
    x = {}
    for w in workshops:
        for c in components:
            for s in shifts:
                for t in types:
                    x[w, c, s, t] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{w}_{c}_{s}_{t}")

    # y[workshop, shift]: binary indicator if a workshop is active during a shift
    y = {}
    for w in workshops:
        for s in shifts:
            y[w, s] = model.addVar(vtype=GRB.BINARY, name=f"y_{w}_{s}")

    # z: number of completed products (bottlenecked by component production)
    z = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="z")
    
    # z_shortage: shortfall of completed products below the baseline target
    z_shortage = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="z_shortage")

    # Define objective components
    # Night penalty applies only to regular-time night shift hours
    night_reg_penalty = gp.quicksum(x[w, c, 'night', 'regular'] for w in workshops for c in components) * params['penalty_night_hour']
    # Overtime penalty applies to all overtime hours in any shift
    overtime_penalty = gp.quicksum(x[w, c, s, 'overtime'] for w in workshops for s in shifts for c in components) * params['penalty_overtime_hour']
    # Shortage penalty applies per unit shortfall from the target z_target
    shortage_penalty = z_shortage * params['penalty_shortage_per_unit']
    
    # Objective: maximize completed products net of penalties
    model.setObjective(z - night_reg_penalty - overtime_penalty - shortage_penalty, GRB.MAXIMIZE)

    # Constraints
    # 1. Completed products calculation: z is the minimum of production across all three components
    for c in components:
        model.addConstr(gp.quicksum(x[w, c, s, t] * rates[(w, c)] for w in workshops for s in shifts for t in types) >= z, name=f"Comp_{c}_Production_Balance")

    # 2. Total workshop capacity across all shifts and time types (from table_1.csv)
    for w in workshops:
        model.addConstr(gp.quicksum(x[w, c, s, t] for c in components for s in shifts for t in types) <= capacities[w], name=f"Workshop_Overall_Cap_{w}")

    # 3. Regular time capacity per shift (from general_parameters.csv)
    for w in workshops:
        for s in shifts:
            model.addConstr(gp.quicksum(x[w, c, s, 'regular'] for c in components) <= params[f"regular_hours_limit_{s}_{w}"], name=f"Reg_Shift_Cap_{w}_{s}")

    # 4. Overtime capacity per shift (from general_parameters.csv)
    for w in workshops:
        for s in shifts:
            model.addConstr(gp.quicksum(x[w, c, s, 'overtime'] for c in components) <= params[f"overtime_capacity_{s}_{w}"], name=f"OT_Shift_Cap_{w}_{s}")

    # 5. Link workshop shift hours to binary active indicator (Big-M formulation)
    for w in workshops:
        for s in shifts:
            model.addConstr(gp.quicksum(x[w, c, s, t] for c in components for t in types) <= params[f"bigM_shift_{w}"] * y[w, s], name=f"Shift_Activity_BigM_{w}_{s}")

    # 6. Limit on the number of active workshops per shift (limited supervision)
    for s in shifts:
        model.addConstr(gp.quicksum(y[w, s] for w in workshops) <= 2, name=f"Max_Active_Workshops_{s}")

    # 7. Shortage penalty definition: z_shortage = max(0, z_target - z)
    model.addConstr(z_shortage >= params['z_target'] - z, name="Shortage_Calculation")

    # Solve optimization problem
    model.optimize()

    # Output the results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_problem()
