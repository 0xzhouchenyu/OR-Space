import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_car_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    cars = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            i = int(row['i'])
            length = float(row['lambda_i'])
            cars[i] = length
    return cars

def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'])
            params[name] = value
    return params

def main():
    # Locate data directory relative to this script
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    cars = load_car_data(data_dir)
    params = load_parameters(data_dir)

    num_cars = int(params['num_cars'])
    max_length_one_side = params['max_length_one_side']
    # available_party_side_count is 1, confirming only one side is usable

    car_ids = list(cars.keys())
    lengths = cars

    # Build optimization model
    m = gp.Model("DanzigParking")
    m.setParam('OutputFlag', 0)

    # Binary variable: 1 if car i parks on the single available side
    x = m.addVars(car_ids, vtype=GRB.BINARY, name="x")

    # All cars must be parked on the available side
    m.addConstr(x.sum() == num_cars, name="all_assigned")

    # Total length occupied on that side
    side_length = gp.quicksum(lengths[i] * x[i] for i in car_ids)

    # Respect the maximum length limit for the single side
    m.addConstr(side_length <= max_length_one_side, name="max_side")

    # Objective: minimize the total street length occupied (the side length)
    m.setObjective(side_length, GRB.MINIMIZE)

    m.optimize()

    # Output the optimal objective value
    print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    main()
