import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        value = row["Value"].strip()
        if value:
            params[name] = float(value) if '.' in value or 'e' in value.lower() else int(value)
        else:
            params[name] = row["Context_Description"].strip()  # for condition text

# Read items
items = []
values = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        items.append(row["Item"].strip())
        values.append(int(row["Value"].strip()))

n = len(items)
total_value = sum(values)

# Extract parameters
son1_min_share = params["son1_min_share"]
high_value_threshold = params["high_value_threshold"]
max_high_value_items_per_son = params["max_high_value_items_per_son"]
deferred_diamonds_per_son = params["deferred_diamonds_per_son"]
immediate_tax_weight = params["immediate_tax_weight"]
total_tax_weight = params["total_tax_weight"]

# Identify special items
diamond_indices = [i for i, item in enumerate(items) if "Diamond" in item]
jr_indices = [i for i, item in enumerate(items) if "Jack Russell" in item]
high_value_indices = [i for i, v in enumerate(values) if v > high_value_threshold]

# Model
model = gp.Model("Inheritance_Revised")
model.setParam("OutputFlag", 0)

# Variables
x = model.addVars(n, vtype=GRB.BINARY, name="x")  # 1 if son1, 0 if son2
d = model.addVars(diamond_indices, vtype=GRB.BINARY, name="d")  # 1 if deferred
y = model.addVars(diamond_indices, vtype=GRB.BINARY, name="y")  # x[i] * d[i] linearization

# Linearization constraints for y = x * d
for i in diamond_indices:
    model.addConstr(y[i] <= x[i])
    model.addConstr(y[i] <= d[i])
    model.addConstr(y[i] >= x[i] + d[i] - 1)

# Jack Russell dogs must not be separated
if len(jr_indices) == 2:
    model.addConstr(x[jr_indices[0]] == x[jr_indices[1]])

# Son1 minimum total share
model.addConstr(gp.quicksum(values[i] * x[i] for i in range(n)) >= son1_min_share * total_value)

# High-value items concentration limit
if high_value_indices:
    model.addConstr(gp.quicksum(x[i] for i in high_value_indices) <= max_high_value_items_per_son)
    model.addConstr(gp.quicksum(1 - x[i] for i in high_value_indices) <= max_high_value_items_per_son)

# Deferred diamonds per son
model.addConstr(gp.quicksum(y[i] for i in diamond_indices) <= deferred_diamonds_per_son)
model.addConstr(gp.quicksum(d[i] - y[i] for i in diamond_indices) <= deferred_diamonds_per_son)

# Immediate values
imm_son1 = gp.quicksum(values[i] * x[i] for i in range(n) if i not in diamond_indices) + \
           gp.quicksum(values[i] * (x[i] - y[i]) for i in diamond_indices)
imm_son2 = gp.quicksum(values[i] * (1 - x[i]) for i in range(n) if i not in diamond_indices) + \
           gp.quicksum(values[i] * (1 - x[i] - d[i] + y[i]) for i in diamond_indices)

# Total values
total_son1 = gp.quicksum(values[i] * x[i] for i in range(n))
total_son2 = total_value - total_son1

# Absolute differences
diff_imm = model.addVar(lb=0, name="diff_imm")
diff_total = model.addVar(lb=0, name="diff_total")

model.addConstr(diff_imm >= imm_son1 - imm_son2)
model.addConstr(diff_imm >= imm_son2 - imm_son1)
model.addConstr(diff_total >= total_son1 - total_son2)
model.addConstr(diff_total >= total_son2 - total_son1)

# Objective
model.setObjective(immediate_tax_weight * diff_imm + total_tax_weight * diff_total, GRB.MINIMIZE)

# Solve
model.optimize()

# Output
print(f"FINAL_OBJ_VALUE: {model.objVal}")
