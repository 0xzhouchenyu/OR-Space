import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def solve():
    # Paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')

    # Read general parameters
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            if len(row) >= 4:
                params[row[0]] = row[1]

    num_customers = int(params['num_customers'])
    max_trucks = int(params['max_trucks'])  # legacy, not used as limit
    truck_capacity = float(params['truck_capacity'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])

    # Depot coordinates
    depot_str = params['depot_coordinates'].strip('()')
    if ',' in depot_str:
        depot_x, depot_y = map(float, depot_str.split(','))
    else:
        depot_x, depot_y = map(float, depot_str.split())

    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])

    # Read customer data
    customers = []
    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            customers.append({
                'id': int(row['Customer_ID']),
                'x': float(row['Coordinates_X']),
                'y': float(row['Coordinates_Y']),
                'demand': float(row['Demand']),
                'tw_start': float(row['Time_Window_Start']),
                'tw_end': float(row['Time_Window_End']),
                'service': float(row['Service_Duration']),
                'outsource_cost': float(row['Outsource_Cost']),
                'mandatory_external': int(row['Mandatory_External'])
            })

    # Build node lists
    # Node 0: depot
    coords = [(depot_x, depot_y)]
    demands = [0.0]
    tw_starts = [depot_tw_start]
    tw_ends = [depot_tw_end]
    services = [0.0]
    outsource_costs = [0.0]  # depot not outsourced
    mandatory_external = [0]  # depot not external

    # Map original customer ID to new index
    cust_index = {}
    for i, c in enumerate(customers, start=1):
        cust_index[c['id']] = i
        coords.append((c['x'], c['y']))
        demands.append(c['demand'])
        tw_starts.append(c['tw_start'])
        tw_ends.append(c['tw_end'])
        services.append(c['service'])
        outsource_costs.append(c['outsource_cost'])
        mandatory_external.append(c['mandatory_external'])

    n = len(coords)  # includes depot
    N = list(range(1, n))  # customer nodes
    N_optional = [i for i in N if mandatory_external[i] == 0]
    N_mandatory = [i for i in N if mandatory_external[i] == 1]

    # Precompute distances
    dist = {}
    for i in range(n):
        for j in range(n):
            if i != j:
                dist[i, j] = calculate_distance(coords[i], coords[j])

    # Determine feasible arcs for routing (only among depot and optional customers)
    V_routing = [0] + N_optional
    A = []
    for i in V_routing:
        for j in V_routing:
            if i == j:
                continue
            # Time feasibility
            if i == 0 and j != 0:
                if tw_starts[0] + dist[0, j] > tw_ends[j]:
                    continue
            elif i != 0 and j == 0:
                if tw_starts[i] + services[i] + dist[i, 0] > tw_ends[0]:
                    continue
            else:  # both customers
                if tw_starts[i] + services[i] + dist[i, j] > tw_ends[j]:
                    continue
            A.append((i, j))

    # Model
    m = gp.Model("VRPHTW_Outsource")
    m.setParam('OutputFlag', 0)
    m.setParam('TimeLimit', 300)

    # Variables
    x = m.addVars(A, vtype=GRB.BINARY, name="x")
    y = m.addVars(N_optional, vtype=GRB.BINARY, name="y")  # 1 if served in-house
    t = m.addVars(V_routing, lb=0.0, name="t")
    u = m.addVars(V_routing, lb=0.0, ub=truck_capacity, name="u")

    # Fix depot time and load
    t[0].lb = tw_starts[0]
    t[0].ub = tw_ends[0]
    u[0].lb = 0
    u[0].ub = 0

    # Objective: minimize travel distance + outsourcing costs
    travel_cost = gp.quicksum(dist[i, j] * x[i, j] for i, j in A)
    outsource_cost = gp.quicksum(outsource_costs[i] * (1 - y[i]) for i in N_optional)
    # Mandatory external customers are always outsourced, add their costs
    mandatory_outsource_cost = sum(outsource_costs[i] for i in N_mandatory)
    m.setObjective(travel_cost + outsource_cost + mandatory_outsource_cost, GRB.MINIMIZE)

    # Fleet size limit
    m.addConstr(gp.quicksum(x[0, j] for j in N_optional if (0, j) in A) <= inhouse_truck_limit, "fleet_limit")
    # Flow conservation for depot (optional but good)
    m.addConstr(gp.quicksum(x[0, j] for j in N_optional if (0, j) in A) ==
                gp.quicksum(x[i, 0] for i in N_optional if (i, 0) in A), "depot_flow")

    # For each optional customer: in-degree and out-degree equal to y[i]
    for i in N_optional:
        in_arcs = [j for j in V_routing if (j, i) in A]
        out_arcs = [j for j in V_routing if (i, j) in A]
        m.addConstr(gp.quicksum(x[j, i] for j in in_arcs) == y[i], f"in_{i}")
        m.addConstr(gp.quicksum(x[i, j] for j in out_arcs) == y[i], f"out_{i}")

    # Time window constraints for optional customers (only when visited)
    M_time = tw_ends[0] + max(services) + max(dist.values())
    for i in N_optional:
        m.addConstr(t[i] >= tw_starts[i] - M_time * (1 - y[i]), f"tw_start_{i}")
        m.addConstr(t[i] <= tw_ends[i] + M_time * (1 - y[i]), f"tw_end_{i}")

    # Time propagation on arcs
    for i, j in A:
        if j != 0:
            m.addConstr(t[i] + services[i] + dist[i, j] - t[j] <= M_time * (1 - x[i, j]), f"time_{i}_{j}")

    # Capacity constraints
    for i in N_optional:
        m.addConstr(u[i] >= demands[i] * y[i], f"demand_lb_{i}")
        m.addConstr(u[i] <= truck_capacity * y[i], f"demand_ub_{i}")

    for i, j in A:
        if j != 0:
            m.addConstr(u[i] + demands[j] - u[j] <= truck_capacity * (1 - x[i, j]), f"cap_{i}_{j}")

    # Optimize
    m.optimize()

    # Output
    if m.status in [GRB.OPTIMAL, GRB.TIME_LIMIT]:
        if m.solCount > 0:
            obj = m.objVal
            print(f"FINAL_OBJ_VALUE: {obj:.2f}")
        else:
            print("FINAL_OBJ_VALUE: None")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
