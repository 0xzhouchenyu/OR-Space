import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table1_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    
    # Load data
    df = pd.read_csv(table1_path)
    params = pd.read_csv(params_path)
    
    # Extract parameters
    budget_total = float(params[params['Parameter_Name'] == 'budget']['Value'].iloc[0])
    food_intake_g = float(params[params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
    weekday_budget_share = float(params[params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
    max_prep_time_weekday = float(params[params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
    max_prep_time_weekend = float(params[params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
    weekend_protein_ban = int(params[params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
    veg_balance_penalty = float(params[params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])
    
    # Fill missing fiber with 0
    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)
    
    foods = df['Food'].tolist()
    types = df.set_index('Food')['Type'].to_dict()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()
    
    proteins = [f for f in foods if types[f] == 'protein']
    vegetables = [f for f in foods if types[f] == 'vegetable']
    
    # Convert food intake to 100g units
    total_intake_units = food_intake_g / 100.0  # 5.0
    
    # Budget per meal
    budget_weekday = budget_total * weekday_budget_share
    budget_weekend = budget_total * (1 - weekday_budget_share)
    
    # Prep time limits
    prep_limits = {
        'weekday': max_prep_time_weekday,
        'weekend': max_prep_time_weekend
    }
    
    # Model
    m = gp.Model("MealPlanning")
    m.setParam('OutputFlag', 0)
    
    # Variables
    meals = ['weekday', 'weekend']
    x = m.addVars(meals, foods, lb=0, name="x")  # amount in 100g
    y = m.addVars(foods, vtype=GRB.BINARY, name="y")  # selection
    
    # Deviation variables for vegetable balance
    dev_pos = m.addVar(lb=0, name="dev_pos")
    dev_neg = m.addVar(lb=0, name="dev_neg")
    
    # Objective: maximize fiber minus penalty
    total_fiber = gp.quicksum(fiber[f] * x[meal, f] for meal in meals for f in foods)
    penalty = veg_balance_penalty * (dev_pos + dev_neg)
    m.setObjective(total_fiber - penalty, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Total food intake per meal
    for meal in meals:
        m.addConstr(gp.quicksum(x[meal, f] for f in foods) == total_intake_units,
                    name=f"intake_{meal}")
    
    # 2. Budget per meal
    m.addConstr(gp.quicksum(price[f] * x['weekday', f] for f in foods) <= budget_weekday,
                name="budget_weekday")
    m.addConstr(gp.quicksum(price[f] * x['weekend', f] for f in foods) <= budget_weekend,
                name="budget_weekend")
    
    # 3. Prep time per meal
    for meal in meals:
        m.addConstr(gp.quicksum(prep_time[f] * x[meal, f] for f in foods) <= prep_limits[meal],
                    name=f"prep_{meal}")
    
    # 4. Exactly one protein selected
    m.addConstr(gp.quicksum(y[f] for f in proteins) == 1, name="one_protein")
    
    # 5. At least two vegetables selected
    m.addConstr(gp.quicksum(y[f] for f in vegetables) >= 2, name="min_veg")
    
    # 6. Linking constraints
    M = total_intake_units  # 5.0, max possible amount in a meal
    min_usage = 0.1  # 10g minimum if selected
    for f in foods:
        # If not selected, no usage in any meal
        m.addConstr(x['weekday', f] <= M * y[f], name=f"link_wd_{f}")
        m.addConstr(x['weekend', f] <= M * y[f], name=f"link_we_{f}")
        # If selected, must appear in at least one meal (sum >= min_usage)
        m.addConstr(x['weekday', f] + x['weekend', f] >= min_usage * y[f],
                    name=f"min_use_{f}")
    
    # 7. Weekend protein ban (if flag is 1)
    if weekend_protein_ban == 1:
        for f in proteins:
            m.addConstr(x['weekend', f] == 0, name=f"ban_we_{f}")
    
    # 8. Vegetable balance deviation
    veg_weekday = gp.quicksum(x['weekday', f] for f in vegetables)
    veg_weekend = gp.quicksum(x['weekend', f] for f in vegetables)
    m.addConstr(veg_weekday - veg_weekend == dev_pos - dev_neg, name="veg_balance")
    
    # Solve
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        obj_val = m.objVal
    else:
        obj_val = None  # Infeasible or unbounded; but we expect optimal
    
    return round(obj_val, 4)

if __name__ == '__main__':
    result = solve()
    print(f"FINAL_OBJ_VALUE: {result}")
