import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths to data files
base_dir = os.path.dirname(os.path.abspath(__file__))
general_params_path = os.path.join(base_dir, "data", "general_parameters.csv")
table1_path = os.path.join(base_dir, "data", "table_1.csv")

# Read general parameters
params = {}
with open(general_params_path, newline='') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'])

# Read product data
products = {}
with open(table1_path, newline='') as f:
    reader = csv.DictReader(f)
    for row in reader:
        products[row['Product'].strip()] = {
            'a_hrs': float(row['Workshop_A_Hours']),
            'b_hrs': float(row['Workshop_B_Hours']),
            'insp_cost': float(row['Inspection_Sales_Cost'])
        }

m = products['Microwave_Oven']
w = products['Water_Heater']

# Extract parameters
workshop_a_avail = params['workshop_a_available_hours']
workshop_a_overtime = params['workshop_a_overtime_limit']
workshop_a_cost = params['workshop_a_hourly_cost']
workshop_b_avail = params['workshop_b_available_hours']
workshop_b_cost = params['workshop_b_hourly_cost']
insp_limit = params['inspection_sales_cost_limit']
min_m = params['microwave_minimum_sales']
min_w = params['water_heater_minimum_sales']
setup_A = params['setup_hours_A']
tech_pool = params['tech_pool_hours']
tech_rate_m = params['tech_rate_m']
tech_rate_w = params['tech_rate_w']
green_bonus_m = params['green_bonus_m']
green_bonus_w = params['green_bonus_w']
bigM = params['bigM']

# Objective coefficients: original cost sum + green bonus
obj_m = (m['a_hrs'] * workshop_a_cost +
         m['b_hrs'] * workshop_b_cost +
         m['insp_cost'] +
         green_bonus_m)
obj_w = (w['a_hrs'] * workshop_a_cost +
         w['b_hrs'] * workshop_b_cost +
         w['insp_cost'] +
         green_bonus_w)

# Build model
model = gp.Model("production_revised")
model.setParam('OutputFlag', 0)

# Decision variables
x_m = model.addVar(lb=min_m, name="microwave")
x_w = model.addVar(lb=min_w, name="water_heater")
y_m = model.addVar(vtype=GRB.BINARY, name="setup_m")
y_w = model.addVar(vtype=GRB.BINARY, name="setup_w")

# Objective: maximize total value (costs + green bonus)
model.setObjective(obj_m * x_m + obj_w * x_w, GRB.MAXIMIZE)

# Constraints
# Workshop A capacity (regular + overtime) including fixed setup hours per activated product
model.addConstr(
    m['a_hrs'] * x_m + w['a_hrs'] * x_w + setup_A * y_m + setup_A * y_w
    <= workshop_a_avail + workshop_a_overtime,
    name="workshop_A_capacity"
)

# Workshop B minimum utilisation (from original requirements)
model.addConstr(
    m['b_hrs'] * x_m + w['b_hrs'] * x_w >= workshop_b_avail,
    name="workshop_B_min"
)

# Inspection and sales cost limit
model.addConstr(
    m['insp_cost'] * x_m + w['insp_cost'] * x_w <= insp_limit,
    name="inspection_limit"
)

# Shared technician pool
model.addConstr(
    tech_rate_m * x_m + tech_rate_w * x_w <= tech_pool,
    name="tech_pool"
)

# Setup activation (big-M linking)
model.addConstr(x_m <= bigM * y_m, name="link_m")
model.addConstr(x_w <= bigM * y_w, name="link_w")

# Solve
model.optimize()

# Output
print(f"FINAL_OBJ_VALUE: {model.objVal}")
