import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths to data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    general_params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    table1_path = os.path.join(base_dir, "data", "table_1.csv")

    # Read general parameters
    params = {}
    with open(general_params_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            params[row[0].strip()] = row[1].strip()

    start_city = params['start_city']
    end_city = params['end_city']
    prohibited_from = params['prohibited_from']
    prohibited_to = params['prohibited_to']
    inspection_from = params['inspection_arc_from']
    inspection_to = params['inspection_arc_to']
    inspection_cost = float(params['inspection_stop_cost'])

    # Read distance matrix
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        city_labels = header[1:]  # ['1','2','3','4']
        dist = []
        cities = []
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])

    n = len(cities)
    # Map city label to index
    city_to_idx = {city: i for i, city in enumerate(cities)}

    start = city_to_idx[start_city]
    end = city_to_idx[end_city]
    prob_from = city_to_idx[prohibited_from]
    prob_to = city_to_idx[prohibited_to]
    insp_from = city_to_idx[inspection_from]
    insp_to = city_to_idx[inspection_to]

    # Create model
    model = gp.Model("TSP_Path")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[i,j] for i != j
    x = {}
    for i in range(n):
        for j in range(n):
            if i != j:
                x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")

    # MTZ variables: u[i] for i != start
    u = {}
    for i in range(n):
        if i != start:
            u[i] = model.addVar(lb=1, ub=n-1, vtype=GRB.CONTINUOUS, name=f"u_{i}")

    # Objective: minimize total distance + inspection cost if arc (2,3) used
    obj = gp.quicksum(dist[i][j] * x[i, j] for i in range(n) for j in range(n) if i != j)
    obj += inspection_cost * x[insp_from, insp_to]
    model.setObjective(obj, GRB.MINIMIZE)

    # Flow constraints
    # Start node: exactly one outgoing, no incoming
    model.addConstr(gp.quicksum(x[start, j] for j in range(n) if j != start) == 1, "start_out")
    model.addConstr(gp.quicksum(x[i, start] for i in range(n) if i != start) == 0, "start_in")

    # End node: exactly one incoming, no outgoing
    model.addConstr(gp.quicksum(x[i, end] for i in range(n) if i != end) == 1, "end_in")
    model.addConstr(gp.quicksum(x[end, j] for j in range(n) if j != end) == 0, "end_out")

    # Intermediate nodes: one in, one out
    for k in range(n):
        if k != start and k != end:
            model.addConstr(gp.quicksum(x[i, k] for i in range(n) if i != k) == 1, f"in_{k}")
            model.addConstr(gp.quicksum(x[k, j] for j in range(n) if j != k) == 1, f"out_{k}")

    # Prohibited arc
    model.addConstr(x[prob_from, prob_to] == 0, "prohibit")

    # MTZ subtour elimination for path
    # u[start] is fixed to 0 implicitly (not defined)
    for i in range(n):
        if i == start:
            continue
        for j in range(n):
            if j == start or i == j:
                continue
            model.addConstr(u[i] - u[j] + (n-1) * x[i, j] <= n-2, f"mtz_{i}_{j}")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # Fallback in case of infeasibility (should not happen)
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
