import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'name': row['Product Name'].strip(),
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            })
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    available_labor = params['available_labor']
    available_material = params['available_material']
    fixed_costs = [
        params['fixed_cost_shirts'],
        params['fixed_cost_short_sleeves'],
        params['fixed_cost_casual_clothes']
    ]
    segment_regular_discount = params['segment_regular_discount']
    segment_promo_discount = params['segment_promo_discount']
    promo_labor_cap = params['segment_promo_labor_cap']
    promo_material_cap = params['segment_promo_material_cap']
    min_batch = [
        params['min_batch_shirts'],
        params['min_batch_short_sleeves'],
        params['min_batch_casual_clothes']
    ]
    max_prod = [
        params['max_prod_shirts'],
        params['max_prod_short_sleeves'],
        params['max_prod_casual_clothes']
    ]
    
    n = len(products)
    segments = ['regular', 'promo']
    discounts = {
        'regular': segment_regular_discount,
        'promo': segment_promo_discount
    }
    
    m = gp.Model("clothing")
    m.setParam('OutputFlag', 0)
    
    # Variables
    x = {}   # production quantity per product and segment
    z = {}   # segment activation binary
    y = {}   # product line activation binary
    for i in range(n):
        y[i] = m.addVar(vtype=GRB.BINARY, name=f"y_{i}")
        for s in segments:
            x[i, s] = m.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{i}_{s}")
            z[i, s] = m.addVar(vtype=GRB.BINARY, name=f"z_{i}_{s}")
    
    # Total resource constraints
    m.addConstr(gp.quicksum(products[i]['labor'] * (x[i, 'regular'] + x[i, 'promo']) for i in range(n)) <= available_labor, "total_labor")
    m.addConstr(gp.quicksum(products[i]['material'] * (x[i, 'regular'] + x[i, 'promo']) for i in range(n)) <= available_material, "total_material")
    
    # Promotional segment caps
    m.addConstr(gp.quicksum(products[i]['labor'] * x[i, 'promo'] for i in range(n)) <= promo_labor_cap, "promo_labor")
    m.addConstr(gp.quicksum(products[i]['material'] * x[i, 'promo'] for i in range(n)) <= promo_material_cap, "promo_material")
    
    # Per-product constraints
    for i in range(n):
        # Total production cannot exceed maximum
        m.addConstr(x[i, 'regular'] + x[i, 'promo'] <= max_prod[i], f"max_total_{i}")
        for s in segments:
            # Big-M: if segment is used, quantity <= max_prod
            m.addConstr(x[i, s] <= max_prod[i] * z[i, s], f"bigM_{i}_{s}")
            # Minimum batch size per segment
            m.addConstr(x[i, s] >= min_batch[i] * z[i, s], f"min_batch_{i}_{s}")
        # Link product activation to segment activation
        for s in segments:
            m.addConstr(y[i] >= z[i, s], f"link_y_{i}_{s}")
        m.addConstr(y[i] <= gp.quicksum(z[i, s] for s in segments), f"link_y_sum_{i}")
    
    # Objective: maximize profit
    revenue = gp.quicksum(
        (products[i]['price'] * discounts[s] - products[i]['var_cost']) * x[i, s]
        for i in range(n) for s in segments
    )
    fixed_cost_total = gp.quicksum(fixed_costs[i] * y[i] for i in range(n))
    m.setObjective(revenue - fixed_cost_total, GRB.MAXIMIZE)
    
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
