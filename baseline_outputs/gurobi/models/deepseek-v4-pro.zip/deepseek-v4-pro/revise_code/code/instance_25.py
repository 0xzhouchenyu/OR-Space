import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    W = params['initial_investment']
    r1 = params['return_rate_option_1']
    r2 = params['return_rate_option_2']
    min_res1 = params['min_reserve_year1']
    min_res2 = params['min_reserve_year2']
    max_x2 = params['max_option2_start']
    late_rate = params['option2_year0_late_settlement_rate']
    
    m = gp.Model("Investment")
    m.setParam('OutputFlag', 0)
    
    x0_1 = m.addVar(lb=0, name="x0_1")
    x0_2 = m.addVar(lb=0, name="x0_2")
    x1_1 = m.addVar(lb=0, name="x1_1")
    x1_2 = m.addVar(lb=0, name="x1_2")
    x2_1 = m.addVar(lb=0, name="x2_1")
    
    # Year 0 budget
    m.addConstr(x0_1 + x0_2 <= W, "year0_budget")
    # Per-start exposure ceiling for two-year product
    m.addConstr(x0_2 <= max_x2, "max_x0_2")
    m.addConstr(x1_2 <= max_x2, "max_x1_2")
    
    # Year 1: available cash = initial + return from x0_1 - x0_2 (x0_2 locked)
    C1_start = W + r1 * x0_1 - x0_2
    m.addConstr(x1_1 + x1_2 <= C1_start - min_res1, "year1_budget")
    
    # Year 2: available cash = C1_start - x1_2 + return from x1_1
    # x0_2 proceeds settle after year-2 cut-off, so not available here
    C2_start = C1_start - x1_2 + r1 * x1_1
    m.addConstr(x2_1 <= C2_start - min_res2, "year2_budget")
    
    # Final wealth at end of year 3
    # = C2_start - x2_1 (reserve) + return from x2_1 + return from x1_2 + late-settled x0_2
    # simplified to linear expression:
    final_wealth = (W 
                    + r1 * (x0_1 + x1_1 + x2_1) 
                    + r2 * x1_2 
                    + ((1 + r2) * (1 - late_rate) - 1) * x0_2)
    m.setObjective(final_wealth, GRB.MAXIMIZE)
    
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
