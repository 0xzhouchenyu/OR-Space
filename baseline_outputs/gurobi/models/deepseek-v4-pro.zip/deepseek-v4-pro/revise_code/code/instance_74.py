import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine data directory relative to this script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()

    # Read precedence relations
    precedences = []
    with open(os.path.join(data_dir, "table_1.csv"), newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))

    # Extract data
    activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    dur = {}
    for a in activities:
        dur[a] = int(float(params[f'activity_{a}_duration']))

    work_cost_per_day = float(params['work_cost_per_day'])
    machine_rental_cost_per_day = float(params['machine_rental_cost_per_day'])
    overtime_reduction = int(float(params['activity_E_overtime_reduction']))
    overtime_cost = float(params['activity_E_overtime_cost'])
    followup_review_cost = float(params['activity_E_followup_review_cost'])

    # Build model
    m = gp.Model("Project_Cost_Minimization")
    m.setParam('OutputFlag', 0)

    # Decision variables
    S = {a: m.addVar(lb=0, name=f"S_{a}") for a in activities}
    T = m.addVar(lb=0, name="T")
    y = m.addVar(vtype=GRB.BINARY, name="y")   # 1 if activity E is accelerated

    # Duration of E depends on overtime decision
    dur_E = dur['E'] - overtime_reduction * y

    # Precedence constraints
    for pred, succ in precedences:
        if pred == 'E':
            m.addConstr(S[succ] >= S[pred] + dur_E, name=f"prec_{pred}_{succ}")
        else:
            m.addConstr(S[succ] >= S[pred] + dur[pred], name=f"prec_{pred}_{succ}")

    # Project makespan
    m.addConstr(T >= S['C'] + dur['C'], name="makespan_C")
    m.addConstr(T >= S['B'] + dur['B'], name="makespan_B")

    # Machine rental period: from start of A to end of B
    machine_rental_duration = S['B'] + dur['B'] - S['A']

    # Total cost
    total_cost = (work_cost_per_day * T +
                  machine_rental_cost_per_day * machine_rental_duration +
                  (overtime_cost + followup_review_cost) * y)

    m.setObjective(total_cost, GRB.MINIMIZE)

    # Solve
    m.optimize()

    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print("No optimal solution found")

if __name__ == "__main__":
    main()
