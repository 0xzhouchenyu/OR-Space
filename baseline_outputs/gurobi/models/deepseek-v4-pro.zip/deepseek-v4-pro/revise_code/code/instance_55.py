import os
import csv
import gurobipy as gp
from gurobipy import GRB

def match_prerequisite_course(prereq_key, course_list):
    """Match a prerequisite key (like 'computer_simulation') to actual course name"""
    key_lower = prereq_key.lower().replace('_', ' ')
    for course in course_list:
        if course.lower() == key_lower:
            return course
    return None

def main():
    # Paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Load courses
    courses = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            categories = [c.strip() for c in row['Category'].split(';')]
            courses[course] = categories

    # Load parameters
    params = {}
    prereq_raw = {}
    mandatory_foundation_cs = None
    cs_category_name = None
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if name == 'min_courses_required':
                params['min_courses_required'] = int(value)
            elif name == 'mandatory_foundation_for_cs_counting':
                mandatory_foundation_cs = value
            elif name == 'cs_category_name':
                cs_category_name = value
            elif name.startswith('prerequisite_'):
                course_key = name[len('prerequisite_'):]
                prereq_raw[course_key] = value

    min_required = params['min_courses_required']

    # Build prerequisite mapping: course -> list of prerequisite course names
    course_list = list(courses.keys())
    prerequisites = {}
    for prereq_key, prereq_value in prereq_raw.items():
        course_name = match_prerequisite_course(prereq_key, course_list)
        if course_name:
            prereq_course = prereq_value.strip()
            # Ensure the prerequisite course exists in the list
            if prereq_course in course_list:
                if course_name not in prerequisites:
                    prerequisites[course_name] = []
                prerequisites[course_name].append(prereq_course)

    # All categories
    all_categories = set()
    for cats in courses.values():
        for c in cats:
            all_categories.add(c)

    # Create model
    model = gp.Model("CourseSelection")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[course] = 1 if course is taken
    x = {}
    for course in course_list:
        x[course] = model.addVar(vtype=GRB.BINARY, name=f"x_{course.replace(' ', '_')}")

    # Assignment variables: y[course, category] = 1 if course is used to satisfy category minimum
    y = {}
    for course, cats in courses.items():
        for cat in cats:
            y[course, cat] = model.addVar(vtype=GRB.BINARY, name=f"y_{course.replace(' ', '_')}_{cat.replace(' ', '_')}")

    # Objective: minimize total courses taken
    model.setObjective(gp.quicksum(x[course] for course in course_list), GRB.MINIMIZE)

    # Constraint: at least min_required distinct courses counted in each category
    for cat in all_categories:
        courses_in_cat = [course for course, cats in courses.items() if cat in cats]
        model.addConstr(
            gp.quicksum(y[course, cat] for course in courses_in_cat) >= min_required,
            name=f"Min_{cat.replace(' ', '_')}"
        )

    # Each course can be assigned to at most one category for counting
    for course in course_list:
        model.addConstr(
            gp.quicksum(y[course, cat] for cat in courses[course]) <= 1,
            name=f"OneCat_{course.replace(' ', '_')}"
        )

    # Assignment implies course is taken
    for course, cats in courses.items():
        for cat in cats:
            model.addConstr(y[course, cat] <= x[course], name=f"AssignImpliesTake_{course.replace(' ', '_')}_{cat.replace(' ', '_')}")

    # Prerequisite constraints: if a course is taken, its prerequisites must be taken
    for course, prereqs in prerequisites.items():
        for prereq in prereqs:
            if prereq in x:  # ensure prerequisite is a valid course
                model.addConstr(x[course] <= x[prereq], name=f"Prereq_{course.replace(' ', '_')}_{prereq.replace(' ', '_')}")

    # Mandatory foundation for CS counting: if any course is counted towards CS, Computer Programming must be taken
    if mandatory_foundation_cs and cs_category_name:
        # Find the course name for the mandatory foundation (should be exactly as in course list)
        foundation_course = mandatory_foundation_cs.strip()
        if foundation_course in x:
            for course in course_list:
                if cs_category_name in courses[course]:
                    # y[course, CS] <= x[foundation]
                    model.addConstr(
                        y[course, cs_category_name] <= x[foundation_course],
                        name=f"CSFoundation_{course.replace(' ', '_')}"
                    )

    # Optimize
    model.optimize()

    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of infeasibility or other status, print something
        print(f"FINAL_OBJ_VALUE: {model.objVal if model.status == GRB.OPTIMAL else 'N/A'}")

if __name__ == "__main__":
    main()
