import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add src to path for utils import
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'src'))
from utils import load_coverage_data, load_general_parameters

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load data
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    # Parameters
    small_cost = int(params['small_cost'])
    large_cost = int(params['large_cost'])
    small_cap = int(params['small_cap_areas'])
    max_large = int(params['max_large_stores'])
    min_small = int(params['minimum_neighborhood_counters'])
    # small_store_counter_credit is 1, implicitly used as each small counts as 1
    
    # Precompute coverage lists
    area_list = sorted(areas)
    coverage_dict = {j: coverage[j] for j in area_list}
    
    # Model
    m = gp.Model("StoreLocation")
    m.setParam('OutputFlag', 0)
    
    # Variables
    y = m.addVars(area_list, vtype=GRB.BINARY, name="Large")  # Large store at j
    z = m.addVars(area_list, vtype=GRB.BINARY, name="Small")  # Small store at j
    
    # Assignment variables: w[j,i] = 1 if small store at j covers area i
    w = {}
    for j in area_list:
        for i in coverage_dict[j]:
            w[j, i] = m.addVar(vtype=GRB.BINARY, name=f"w_{j}_{i}")
    
    # Constraints
    
    # 1. Coverage: each area i must be covered by at least one store (Large or assigned Small)
    for i in area_list:
        cover_expr = gp.quicksum(y[j] for j in area_list if i in coverage_dict[j]) + \
                     gp.quicksum(w[j, i] for j in area_list if i in coverage_dict[j])
        m.addConstr(cover_expr >= 1, name=f"Cover_{i}")
    
    # 2. Small store capacity: can serve at most small_cap areas
    for j in area_list:
        m.addConstr(gp.quicksum(w[j, i] for i in coverage_dict[j]) <= small_cap * z[j],
                    name=f"SmallCap_{j}")
    
    # 3. Assignment only if Small store opened
    for j in area_list:
        for i in coverage_dict[j]:
            m.addConstr(w[j, i] <= z[j], name=f"Assign_{j}_{i}")
    
    # 4. Maximum Large stores
    m.addConstr(gp.quicksum(y[j] for j in area_list) <= max_large, name="MaxLarge")
    
    # 5. Minimum Small stores (neighborhood counters)
    m.addConstr(gp.quicksum(z[j] for j in area_list) >= min_small, name="MinSmall")
    
    # 6. At most one store type per area
    for j in area_list:
        m.addConstr(y[j] + z[j] <= 1, name=f"OneStore_{j}")
    
    # Objective: minimize total cost
    obj = gp.quicksum(large_cost * y[j] + small_cost * z[j] for j in area_list)
    m.setObjective(obj, GRB.MINIMIZE)
    
    # Solve
    m.optimize()
    
    # Output
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {int(m.objVal)}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
