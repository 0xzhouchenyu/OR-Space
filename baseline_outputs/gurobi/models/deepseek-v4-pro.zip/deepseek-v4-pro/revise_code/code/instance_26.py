import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine data directory relative to this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            value = row["Value"].strip()
            params[name] = value
    
    full_time_cost = float(params["full_time_cost"])
    part_time_cost = float(params["part_time_cost"])
    part_time_cap = int(params["part_time_cap_per_period"])
    min_full_time = int(params["min_full_time_per_period"])
    
    # Read staffing requirements
    requirements = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row["Time_Period"].strip()
            req = int(row["Required_Salespeople"].strip())
            requirements[period] = req
    
    # Periods in order: 0: 2-6, 1: 6-10, 2: 10-14, 3: 14-18, 4: 18-22, 5: 22-2
    periods = list(requirements.keys())
    req = [requirements[p] for p in periods]
    n = len(periods)  # 6
    
    # Create model
    model = gp.Model("Staffing")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Full-time starts in period i
    x = model.addVars(n, vtype=GRB.INTEGER, name="x", lb=0)
    # Part-time assignments in period j
    y = model.addVars(n, vtype=GRB.INTEGER, name="y", lb=0)
    
    # Objective: minimize total cost
    model.setObjective(
        gp.quicksum(full_time_cost * x[i] for i in range(n)) +
        gp.quicksum(part_time_cost * y[j] for j in range(n)),
        GRB.MINIMIZE
    )
    
    # Constraints
    for j in range(n):
        # Full-time present in period j: starts in j and (j-1) mod n
        ft_present = x[j] + x[(j - 1) % n]
        
        # Coverage: ft_present + part-time >= required
        model.addConstr(ft_present + y[j] >= req[j], name=f"cover_{j}")
        
        # Part-time cap
        model.addConstr(y[j] <= part_time_cap, name=f"pt_cap_{j}")
        
        # Minimum full-time presence
        model.addConstr(ft_present >= min_full_time, name=f"min_ft_{j}")
    
    # Solve
    model.optimize()
    
    # Check optimality
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # In case of infeasibility or other issues, print a message (though not required)
        print("Model did not solve to optimality. Status:", model.status)

if __name__ == "__main__":
    main()
