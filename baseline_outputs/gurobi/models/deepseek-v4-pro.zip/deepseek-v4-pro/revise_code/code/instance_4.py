import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Paths
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, 'data')
param_file = os.path.join(data_dir, 'general_parameters.csv')

# Load parameters
p = load_parameters(param_file)

# Extract all needed parameters
cow_price = p['cow_selling_price']
sheep_price = p['sheep_selling_price']
chicken_price = p['chicken_selling_price']
cow_feed = p['cow_feed_cost']
sheep_feed = p['sheep_feed_cost']
chicken_feed = p['chicken_feed_cost']
cow_manure = p['cow_manure_production']
sheep_manure = p['sheep_manure_production']
chicken_manure = p['chicken_manure_production']
max_manure = p['max_manure_capacity']
max_chickens = p['max_chickens']
min_cows = p['min_cows']
min_sheep = p['min_sheep']
max_total = p['max_total_animals']

premium_cap_mult = p['premium_capacity_multiplier']
premium_manure_mult = p['premium_manure_multiplier']
expansion_cost = p['expansion_cost']
premium_feed_mult = p['premium_feed_multiplier']

base_land_cow = p['base_land_usage_cow']
base_land_sheep = p['base_land_usage_sheep']
base_land_chicken = p['base_land_usage_chicken']
base_land_cap = p['base_land_capacity']
expansion_land = p['expansion_land_increase']

# Model
m = gp.Model("FarmProfit")
m.setParam('OutputFlag', 0)

# Decision variables
cows = m.addVar(lb=min_cows, vtype=GRB.INTEGER, name="cows")
sheep = m.addVar(lb=min_sheep, vtype=GRB.INTEGER, name="sheep")
chickens = m.addVar(lb=0, ub=max_chickens, vtype=GRB.INTEGER, name="chickens")
expand = m.addVar(vtype=GRB.BINARY, name="expand")

# Linearization variables for x_i * expand
w_cows = m.addVar(lb=0, name="w_cows")
w_sheep = m.addVar(lb=0, name="w_sheep")
w_chickens = m.addVar(lb=0, name="w_chickens")

# Big-M values (upper bounds on animals)
M_cows = max_total * premium_cap_mult  # 150
M_sheep = max_total * premium_cap_mult
M_chickens = max_chickens  # 50

# Linearization constraints: w_i = x_i * expand
# w_i <= x_i
m.addConstr(w_cows <= cows)
m.addConstr(w_sheep <= sheep)
m.addConstr(w_chickens <= chickens)

# w_i <= M_i * expand
m.addConstr(w_cows <= M_cows * expand)
m.addConstr(w_sheep <= M_sheep * expand)
m.addConstr(w_chickens <= M_chickens * expand)

# w_i >= x_i - M_i * (1 - expand)
m.addConstr(w_cows >= cows - M_cows * (1 - expand))
m.addConstr(w_sheep >= sheep - M_sheep * (1 - expand))
m.addConstr(w_chickens >= chickens - M_chickens * (1 - expand))

# Total animals constraint (mode-dependent RHS)
m.addConstr(cows + sheep + chickens <= max_total * (1 + (premium_cap_mult - 1) * expand))

# Manure capacity constraint
m.addConstr(cow_manure * cows + sheep_manure * sheep + chicken_manure * chickens <=
            max_manure * (1 + (premium_manure_mult - 1) * expand))

# Land constraint
m.addConstr(base_land_cow * cows + base_land_sheep * sheep + base_land_chicken * chickens <=
            base_land_cap + expansion_land * expand)

# Objective: base profit - extra feed cost when expanded - expansion cost
base_profit = (cow_price - cow_feed) * cows + (sheep_price - sheep_feed) * sheep + (chicken_price - chicken_feed) * chickens
extra_feed_cost = (premium_feed_mult - 1) * (cow_feed * w_cows + sheep_feed * w_sheep + chicken_feed * w_chickens)
m.setObjective(base_profit - extra_feed_cost - expansion_cost * expand, GRB.MAXIMIZE)

# Solve
m.optimize()

# Output
if m.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {m.objVal}")
else:
    print("FINAL_OBJ_VALUE: 0")
