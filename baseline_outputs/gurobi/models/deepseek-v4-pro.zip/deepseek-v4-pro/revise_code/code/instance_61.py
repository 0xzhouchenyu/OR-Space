import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read device data
devices = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            'name': row['Device'].strip(),
            'prep_cost': float(row['Prep_Completion_Cost_Yuan']),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit']),
            'max_cap': float(row['Max_Processing_Capacity_Units'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'])

required_units = params['required_units']
energy_budget_peak = params['energy_budget_peak']
energy_budget_offpeak = params['energy_budget_offpeak']
startup_budget = params['startup_budget']
startup_cost = params['startup_cost']
energy_price_peak = params['energy_price_peak']
energy_price_offpeak = params['energy_price_offpeak']

# Attach energy parameters to devices
for dev in devices:
    name = dev['name']
    dev['energy_per_unit'] = params[f'energy_per_unit_{name}']
    dev['startup_energy'] = params[f'startup_energy_{name}']

# Create model
model = gp.Model("MinCostProductionRevised")
model.setParam('OutputFlag', 0)

n = len(devices)
periods = ['peak', 'offpeak']

# Decision variables
x = {}  # units produced on device i in period p
y = {}  # 1 if device i is started in period p
z = {}  # 1 if device i is used at all

for i in range(n):
    z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{devices[i]['name']}")
    for p in periods:
        x[i, p] = model.addVar(lb=0, ub=devices[i]['max_cap'], vtype=GRB.CONTINUOUS,
                               name=f"x_{devices[i]['name']}_{p}")
        y[i, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{devices[i]['name']}_{p}")

# Constraints
# Total production must meet required units
model.addConstr(gp.quicksum(x[i, p] for i in range(n) for p in periods) == required_units,
                "TotalProduction")

# Device total capacity (across both periods)
for i in range(n):
    model.addConstr(gp.quicksum(x[i, p] for p in periods) <= devices[i]['max_cap'],
                    f"Cap_{devices[i]['name']}")

# Link production to startup indicator
for i in range(n):
    for p in periods:
        model.addConstr(x[i, p] <= devices[i]['max_cap'] * y[i, p],
                        f"Link_{devices[i]['name']}_{p}")

# Link device usage to period startups
for i in range(n):
    for p in periods:
        model.addConstr(z[i] >= y[i, p], f"ZLink_{devices[i]['name']}_{p}")

# Energy budgets
peak_energy_expr = gp.quicksum(
    devices[i]['startup_energy'] * y[i, 'peak'] +
    devices[i]['energy_per_unit'] * x[i, 'peak']
    for i in range(n)
)
model.addConstr(peak_energy_expr <= energy_budget_peak, "EnergyBudgetPeak")

offpeak_energy_expr = gp.quicksum(
    devices[i]['startup_energy'] * y[i, 'offpeak'] +
    devices[i]['energy_per_unit'] * x[i, 'offpeak']
    for i in range(n)
)
model.addConstr(offpeak_energy_expr <= energy_budget_offpeak, "EnergyBudgetOffpeak")

# Startup monetary budget
startup_cost_expr = gp.quicksum(startup_cost * y[i, p] for i in range(n) for p in periods)
model.addConstr(startup_cost_expr <= startup_budget, "StartupBudget")

# Objective: minimize total cost
obj = gp.quicksum(devices[i]['prep_cost'] * z[i] for i in range(n))
obj += gp.quicksum(devices[i]['unit_cost'] * (x[i, 'peak'] + x[i, 'offpeak']) for i in range(n))
obj += energy_price_peak * peak_energy_expr
obj += energy_price_offpeak * offpeak_energy_expr
obj += startup_cost_expr

model.setObjective(obj, GRB.MINIMIZE)

# Solve
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found")
