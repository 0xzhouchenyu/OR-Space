import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine data directory relative to this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    
    max_children = int(params["max_children_trip"])
    min_children = int(params["min_children_trip"])
    max_distinct = int(params["max_distinct_children_trip"])
    total_budget = int(params["total_cost_budget"])
    bonus_saving = int(params["bonus_saving"])
    min_bob_days = int(params["min_bob_days"])
    
    # Read children and costs from table_1.csv
    children = []
    costs = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Child"].strip()
            cost = int(row["Cost"].strip())
            children.append(name)
            costs[name] = cost
    
    days = [1, 2]
    
    # Create Gurobi model
    model = gp.Model("FamilyTripTwoDay")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    x = {}  # x[child, day] binary
    for child in children:
        for d in days:
            x[child, d] = model.addVar(vtype=GRB.BINARY, name=f"x_{child}_{d}")
    
    b = {}  # bonus indicator: child attends both days
    for child in children:
        b[child] = model.addVar(vtype=GRB.BINARY, name=f"b_{child}")
    
    y = {}  # distinct indicator: child attends at least one day
    for child in children:
        y[child] = model.addVar(vtype=GRB.BINARY, name=f"y_{child}")
    
    # Objective: minimize total two-day cost minus bonus savings
    total_cost_expr = gp.quicksum(costs[child] * x[child, d] for child in children for d in days)
    bonus_term = bonus_saving * gp.quicksum(b[child] for child in children)
    model.setObjective(total_cost_expr - bonus_term, GRB.MINIMIZE)
    
    # Daily min/max headcount
    for d in days:
        model.addConstr(gp.quicksum(x[child, d] for child in children) >= min_children,
                        name=f"MinDay{d}")
        model.addConstr(gp.quicksum(x[child, d] for child in children) <= max_children,
                        name=f"MaxDay{d}")
    
    # Relationship constraints per day
    for d in days:
        # Alice and Diana cannot be together
        model.addConstr(x["Alice", d] + x["Diana", d] <= 1, name=f"AliceDianaConflict_{d}")
        # Bob and Charlie cannot be together
        model.addConstr(x["Bob", d] + x["Charlie", d] <= 1, name=f"BobCharlieConflict_{d}")
        # Charlie requires Diana
        model.addConstr(x["Charlie", d] <= x["Diana", d], name=f"CharlieReqDiana_{d}")
        # Diana requires Ella
        model.addConstr(x["Diana", d] <= x["Ella", d], name=f"DianaReqElla_{d}")
    
    # Availability constraints
    model.addConstr(x["Charlie", 1] == 0, name="CharlieOnlyDay2")
    model.addConstr(x["Diana", 1] == 0, name="DianaOnlyDay2")
    model.addConstr(x["Alice", 2] == 0, name="AliceOnlyDay1")
    
    # Bob minimum days
    model.addConstr(x["Bob", 1] + x["Bob", 2] >= min_bob_days, name="BobMinDays")
    
    # Distinct children across both days
    for child in children:
        model.addConstr(y[child] >= x[child, 1], name=f"Distinct1_{child}")
        model.addConstr(y[child] >= x[child, 2], name=f"Distinct2_{child}")
        model.addConstr(y[child] <= x[child, 1] + x[child, 2], name=f"DistinctSum_{child}")
    model.addConstr(gp.quicksum(y[child] for child in children) <= max_distinct,
                    name="MaxDistinct")
    
    # Bonus indicator: b[child] = 1 iff x[child,1] = 1 and x[child,2] = 1
    for child in children:
        model.addConstr(b[child] <= x[child, 1], name=f"Bonus1_{child}")
        model.addConstr(b[child] <= x[child, 2], name=f"Bonus2_{child}")
        model.addConstr(b[child] >= x[child, 1] + x[child, 2] - 1, name=f"BonusForce_{child}")
    
    # Total cost budget (net cost after savings)
    model.addConstr(total_cost_expr - bonus_term <= total_budget, name="Budget")
    
    # Solve
    model.optimize()
    
    # Output final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of infeasibility or other status, print a default or the actual status
        print(f"FINAL_OBJ_VALUE: {model.objVal if model.status == GRB.OPTIMAL else 'INFEASIBLE'}")

if __name__ == "__main__":
    main()
