import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Determine data directory relative to this script
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general parameters
    num_customers = 7
    max_route_length_day = 1000
    route_cost_day = 20
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'num_customers':
                num_customers = int(row['Value'])
            elif row['Parameter_Name'] == 'max_route_length_day':
                max_route_length_day = float(row['Value'])
            elif row['Parameter_Name'] == 'route_cost_day':
                route_cost_day = float(row['Value'])
    
    # Read distance matrix (symmetric, upper triangular provided)
    D = [[0] * num_customers for _ in range(num_customers)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            if not row:
                continue
            i = int(row[0]) - 1  # 0-indexed location
            for j, val in enumerate(row[1:]):
                if val.strip() not in ('', '-'):
                    D[i][j] = int(val)
                    D[j][i] = int(val)
    
    # Sets
    V = range(num_customers)          # 0..6, 0 is depot (location 1)
    depot = 0
    customers = range(1, num_customers)  # 1..6
    days = [0, 1]                     # two service days
    
    # Model
    m = gp.Model("TSP_2Day")
    m.setParam('OutputFlag', 0)
    
    # Variables
    x = {}   # x[i,j,d] : edge (i,j) used on day d
    for d in days:
        for i in V:
            for j in V:
                if i != j:
                    x[i, j, d] = m.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}_{d}")
    
    y = {}   # y[i,d] : customer i visited on day d
    for d in days:
        for i in customers:
            y[i, d] = m.addVar(vtype=GRB.BINARY, name=f"y_{i}_{d}")
    
    z = {}   # z[d] : day d is used
    for d in days:
        z[d] = m.addVar(vtype=GRB.BINARY, name=f"z_{d}")
    
    u = {}   # u[i,d] : MTZ position variable for customer i on day d
    for d in days:
        for i in customers:
            u[i, d] = m.addVar(lb=0, ub=len(customers), vtype=GRB.CONTINUOUS, name=f"u_{i}_{d}")
    
    # Constraints
    
    # 1. Each customer served exactly once across the two days
    for i in customers:
        m.addConstr(gp.quicksum(y[i, d] for d in days) == 1, f"assign_{i}")
    
    # 2. A customer can only be visited on a day that is used
    for d in days:
        for i in customers:
            m.addConstr(y[i, d] <= z[d], f"link_yz_{i}_{d}")
    
    # 3. Flow conservation at the depot
    for d in days:
        m.addConstr(gp.quicksum(x[depot, j, d] for j in V if j != depot) == z[d], f"flow_out_depot_{d}")
        m.addConstr(gp.quicksum(x[i, depot, d] for i in V if i != depot) == z[d], f"flow_in_depot_{d}")
    
    # 4. Flow conservation at customer nodes
    for d in days:
        for i in customers:
            m.addConstr(gp.quicksum(x[i, j, d] for j in V if j != i) == y[i, d], f"flow_out_{i}_{d}")
            m.addConstr(gp.quicksum(x[j, i, d] for j in V if j != i) == y[i, d], f"flow_in_{i}_{d}")
    
    # 5. Subtour elimination (MTZ) – only active when both customers are visited
    n_cust = len(customers)  # 6
    for d in days:
        for i in customers:
            for j in customers:
                if i != j:
                    m.addConstr(
                        u[i, d] - u[j, d] + n_cust * x[i, j, d] <= n_cust - 1 + n_cust * (2 - y[i, d] - y[j, d]),
                        f"mtz_{i}_{j}_{d}"
                    )
    
    # 6. u variables are zero when customer is not visited on the day
    for d in days:
        for i in customers:
            m.addConstr(u[i, d] <= n_cust * y[i, d], f"u_bound_y_{i}_{d}")
    
    # 7. Daily route length must respect the maximum allowed
    for d in days:
        m.addConstr(
            gp.quicksum(D[i][j] * x[i, j, d] for i in V for j in V if i != j) <= max_route_length_day,
            f"max_route_length_{d}"
        )
    
    # Objective: total travel distance + fixed costs for each day used
    obj = gp.quicksum(D[i][j] * x[i, j, d] for d in days for i in V for j in V if i != j) + \
          gp.quicksum(route_cost_day * z[d] for d in days)
    m.setObjective(obj, GRB.MINIMIZE)
    
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
