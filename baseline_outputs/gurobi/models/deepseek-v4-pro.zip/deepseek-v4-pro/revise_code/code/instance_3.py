import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load demand forecast
demand = {}
with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for i, row in enumerate(reader):
        demand[i] = float(row['Demand_Forecast'])

T = len(demand)  # 6 months

# Load general parameters
params = {}
with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

W0 = int(params['initial_workforce'])
I0 = params['initial_inventory']
sp = params['sales_price']
rmc = params['raw_material_cost']
oc = params['outsourcing_cost']
hc = params['inventory_holding_cost']
bc = params['backorder_cost']
lr = params['labor_requirement']
rh = params['regular_labor_hours']
rw = params['regular_wage']
otl = params['overtime_hours_limit']
ow = params['overtime_wage']
hire_cost = params['hiring_cost']
fire_cost = params['firing_cost']
term_inv = params['terminal_inventory']
term_bo = params['terminal_backorders']
contract_min = params['contract_min_units']
bigM = params['contract_bigM']

# Model
m = gp.Model("FoldableTableProduction")
m.setParam('OutputFlag', 0)

# Decision variables
W = m.addVars(T, lb=0, name="W")          # workforce
H = m.addVars(T, lb=0, name="H")          # hired
F = m.addVars(T, lb=0, name="F")          # fired
P_reg = m.addVars(T, lb=0, name="P_reg")  # regular-time production
P_ot = m.addVars(T, lb=0, name="P_ot")    # overtime production
OT_total = m.addVars(T, lb=0, name="OT_total")  # total overtime hours
O = m.addVars(T, lb=0, name="O")          # outsourced units
Inv = m.addVars(T, lb=0, name="Inv")      # inventory
B = m.addVars(T, lb=0, name="B")          # backorders
x = m.addVars(T, lb=0, name="x")          # regular production used to meet demand
z = m.addVars(T, vtype=GRB.BINARY, name="z")  # contract indicator

# Fix binary indicators: 1 for April (3), May (4), June (5); 0 otherwise
contract_months = [3, 4, 5]
for t in range(T):
    if t in contract_months:
        m.addConstr(z[t] == 1)
    else:
        m.addConstr(z[t] == 0)

# Constraints
for t in range(T):
    # Workforce balance
    if t == 0:
        m.addConstr(W[t] == W0 + H[t] - F[t])
    else:
        m.addConstr(W[t] == W[t-1] + H[t] - F[t])
    
    # Regular production capacity
    m.addConstr(P_reg[t] * lr <= W[t] * rh)
    # Overtime production capacity
    m.addConstr(P_ot[t] * lr <= OT_total[t])
    # Overtime hours limit
    m.addConstr(OT_total[t] <= W[t] * otl)
    
    # Inventory balance
    prev_inv = I0 if t == 0 else Inv[t-1]
    prev_b = 0 if t == 0 else B[t-1]
    m.addConstr(Inv[t] - B[t] == prev_inv - prev_b + P_reg[t] + P_ot[t] + O[t] - demand[t])
    
    # x[t] cannot exceed regular production
    m.addConstr(x[t] <= P_reg[t])
    # x[t] cannot exceed satisfied demand in month t
    m.addConstr(x[t] <= demand[t] + prev_b - B[t])
    # Regular production not sold must go to inventory
    m.addConstr(Inv[t] >= P_reg[t] - x[t])
    
    # Contract minimum via big-M (active only when z[t]=1)
    m.addConstr(x[t] >= contract_min - bigM * (1 - z[t]))

# Terminal conditions
m.addConstr(Inv[T-1] >= term_inv)
m.addConstr(B[T-1] <= term_bo)

# Objective: maximize net profit
total_demand = sum(demand[t] for t in range(T))
revenue = sp * total_demand

material_cost = rmc * gp.quicksum(P_reg[t] + P_ot[t] for t in range(T))
outsource_cost = oc * gp.quicksum(O[t] for t in range(T))
holding_cost = hc * gp.quicksum(Inv[t] for t in range(T))
backorder_cost = bc * gp.quicksum(B[t] for t in range(T))
regular_labor_cost = rw * rh * gp.quicksum(W[t] for t in range(T))
overtime_cost = ow * gp.quicksum(OT_total[t] for t in range(T))
hiring_cost_total = hire_cost * gp.quicksum(H[t] for t in range(T))
firing_cost_total = fire_cost * gp.quicksum(F[t] for t in range(T))

total_cost = (material_cost + outsource_cost + holding_cost + backorder_cost +
              regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total)

m.setObjective(revenue - total_cost, GRB.MAXIMIZE)

# Solve
m.optimize()

# Output
if m.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {m.objVal}")
else:
    print("No optimal solution found.")
