import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Path to data file
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_file = os.path.join(data_dir, "general_parameters.csv")

    # Read parameters
    params = {}
    with open(params_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    profit_corn = params['profit_per_acre_corn']
    profit_wheat = params['profit_per_acre_wheat']
    profit_soybeans = params['profit_per_acre_soybeans']
    profit_sorghum = params['profit_per_acre_sorghum']
    total_area = params['total_farm_area']
    corn_wheat_ratio = params['corn_wheat_ratio']
    soybeans_sorghum_ratio = params['soybeans_sorghum_ratio']
    wheat_sorghum_ratio = params['wheat_sorghum_ratio']

    # Create model
    model = gp.Model("Farm_Optimization_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    corn = model.addVar(lb=0, name="corn")
    wheat = model.addVar(lb=0, name="wheat")
    soybeans = model.addVar(lb=0, name="soybeans")
    sorghum = model.addVar(lb=0, name="sorghum")

    # Binary variable for mutual exclusion: 1 if corn is planted, 0 if soybeans is planted
    y = model.addVar(vtype=GRB.BINARY, name="high_input_crop")

    # Objective: maximize profit
    model.setObjective(
        profit_corn * corn + profit_wheat * wheat +
        profit_soybeans * soybeans + profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )

    # Total area constraint
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")

    # Original ratio constraints
    model.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio")
    model.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio")
    model.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_ratio")

    # Mutual exclusion: corn and soybeans cannot both be planted
    # Use total_area as big M
    M = total_area
    model.addConstr(corn <= M * y, "corn_if_y")
    model.addConstr(soybeans <= M * (1 - y), "soy_if_not_y")

    # Minimum corn acreage (only enforced if corn is chosen, i.e., y=1)
    model.addConstr(corn >= 20 * y, "min_corn")

    # Solve
    model.optimize()

    # Retrieve objective value
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # Fallback (should not happen)
        obj_val = 0.0

    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
