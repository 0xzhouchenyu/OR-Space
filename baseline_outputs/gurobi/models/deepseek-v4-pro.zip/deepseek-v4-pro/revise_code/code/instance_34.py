import os
import csv
import gurobipy as gp
from gurobipy import GRB

# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load goods data
goods = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        g = row["Goods_Type"].strip()
        goods[g] = {
            "quantity": int(row["Quantity"].strip()),
            "weight": float(row["Weight_per_Unit"].strip()),
        }

# Load parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

max_cap = params["max_container_capacity"]          # 60
min_load = params["min_container_load"]             # 18
min_d_per_container = int(params["min_d_goods_per_container"])  # 10
min_c_per_a = int(params["min_c_per_a"])            # 1

goods_types = list(goods.keys())
quantities = {g: goods[g]["quantity"] for g in goods_types}
weights = {g: goods[g]["weight"] for g in goods_types}

# ----------------------------------------------------------------------
# 2. Upper bound on number of containers
# ----------------------------------------------------------------------
# The tightest bound comes from D: we need at least 10 D per container,
# and we have 90 D, so at most 9 containers can be used.
max_containers = quantities["D"] // min_d_per_container  # 9
# Add a small safety margin (the model will choose the minimum)
N = range(max_containers + 1)  # 0..9, but we can also use 0..9
# Actually we need at most 9 containers, but we can set N = 9 (0..8) or 10 (0..9).
# Let's use 0..9 (10 containers) to be safe.
N = range(max_containers + 1)  # 0..9 inclusive -> 10 containers max

# ----------------------------------------------------------------------
# 3. Build model
# ----------------------------------------------------------------------
m = gp.Model("ContainerMinimization")
m.setParam("OutputFlag", 0)

# Decision variables
x = m.addVars(goods_types, N, vtype=GRB.INTEGER, name="x", lb=0)
y = m.addVars(N, vtype=GRB.BINARY, name="y")

# Indicator for E presence (fragile)
e = m.addVars(N, vtype=GRB.BINARY, name="e")
# Indicator for A presence (C requirement)
a = m.addVars(N, vtype=GRB.BINARY, name="a")

# Objective: minimize number of containers used
m.setObjective(gp.quicksum(y[j] for j in N), GRB.MINIMIZE)

# ----------------------------------------------------------------------
# 4. Constraints
# ----------------------------------------------------------------------

# (a) All goods must be transported
for g in goods_types:
    m.addConstr(gp.quicksum(x[g, j] for j in N) == quantities[g], name=f"demand_{g}")

# (b) Container capacity: if E present -> 45, else -> 60
for j in N:
    # Total weight in container j
    total_w = gp.quicksum(weights[g] * x[g, j] for g in goods_types)
    # Capacity depends on e[j]
    m.addConstr(total_w <= max_cap * y[j] - (max_cap - 45) * e[j],
                name=f"cap_{j}")

# (c) Minimum load if container used
for j in N:
    total_w = gp.quicksum(weights[g] * x[g, j] for g in goods_types)
    m.addConstr(total_w >= min_load * y[j], name=f"minload_{j}")

# (d) Minimum D goods per container
for j in N:
    m.addConstr(x["D", j] >= min_d_per_container * y[j], name=f"minD_{j}")

# (e) If A present, then at least min_c_per_a of C must be present
M_A = quantities["A"]  # 120
for j in N:
    # Link a[j] with x_A
    m.addConstr(x["A", j] <= M_A * a[j], name=f"A_ind_{j}")
    m.addConstr(a[j] <= x["A", j], name=f"A_force_{j}")
    # C requirement
    m.addConstr(x["C", j] >= min_c_per_a * a[j], name=f"C_if_A_{j}")

# (f) Link e[j] with x_E
M_E = quantities["E"]  # 120
for j in N:
    m.addConstr(x["E", j] <= M_E * e[j], name=f"E_ind_{j}")
    m.addConstr(e[j] <= x["E", j], name=f"E_force_{j}")

# (g) Symmetry breaking: use containers in order
for j in range(len(N) - 1):
    m.addConstr(y[j] >= y[j + 1], name=f"sym_{j}")

# ----------------------------------------------------------------------
# 5. Solve
# ----------------------------------------------------------------------
m.optimize()

# ----------------------------------------------------------------------
# 6. Output
# ----------------------------------------------------------------------
if m.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {int(m.objVal)}")
else:
    # In case of infeasibility or other status, print a fallback
    print(f"FINAL_OBJ_VALUE: {m.objVal if m.status == GRB.OPTIMAL else 'infeasible'}")
