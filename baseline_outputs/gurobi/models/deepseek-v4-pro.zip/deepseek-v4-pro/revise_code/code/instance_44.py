import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

m = int(params["m"])
n = int(params["n"])
p = int(params["p"])

a = {i: params[f"a_{i}"] for i in range(1, m+1)}
b = {j: params[f"b_{j}"] for j in range(1, n+1)}
f_cost = {k: params[f"f_{k}"] for k in range(1, p+1)}
q = {k: params[f"q_{k}"] for k in range(1, p+1)}
qexp = {k: params[f"qexp_{k}"] for k in range(1, p+1)}
alpha = {j: params[f"alpha_{j}"] for j in range(1, n+1)}
eps = params["eps"]
M = params["M"]

# Load table_1 (production to station)
cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row["i"])
        k = int(row["k"])
        cR_ik[(i, k)] = float(row["cR_ik"])
        cE_ik[(i, k)] = float(row["cE_ik"])

# Load table_2 (station to demand)
cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, "table_2.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row["k"])
        j = int(row["j"])
        cR_kj[(k, j)] = float(row["cR_kj"])
        cE_kj[(k, j)] = float(row["cE_kj"])

# Create model
model = gp.Model("Transportation_Revised")
model.setParam("OutputFlag", 0)

# Variables
xR = model.addVars([(i, k) for i in range(1, m+1) for k in range(1, p+1)],
                   lb=0, vtype=GRB.CONTINUOUS, name="xR")
xE = model.addVars([(i, k) for i in range(1, m+1) for k in range(1, p+1)],
                   lb=0, vtype=GRB.CONTINUOUS, name="xE")
yR = model.addVars([(k, j) for k in range(1, p+1) for j in range(1, n+1)],
                   lb=0, vtype=GRB.CONTINUOUS, name="yR")
yE = model.addVars([(k, j) for k in range(1, p+1) for j in range(1, n+1)],
                   lb=0, vtype=GRB.CONTINUOUS, name="yE")
z = model.addVars(range(1, p+1), vtype=GRB.BINARY, name="z")
v = model.addVars([(k, j) for k in range(1, p+1) for j in range(1, n+1)],
                  vtype=GRB.BINARY, name="v")
u = model.addVars([(k, j) for k in range(1, p+1) for j in range(1, n+1)],
                  vtype=GRB.BINARY, name="u")
w = model.addVars(range(1, n+1), vtype=GRB.BINARY, name="w")

# Objective
obj = gp.quicksum(cR_ik[i, k] * xR[i, k] + cE_ik[i, k] * xE[i, k]
                  for i in range(1, m+1) for k in range(1, p+1))
obj += gp.quicksum(cR_kj[k, j] * yR[k, j] + cE_kj[k, j] * yE[k, j]
                   for k in range(1, p+1) for j in range(1, n+1))
obj += gp.quicksum(f_cost[k] * z[k] for k in range(1, p+1))
model.setObjective(obj, GRB.MINIMIZE)

# Supply constraints
for i in range(1, m+1):
    model.addConstr(
        gp.quicksum(xR[i, k] + xE[i, k] for k in range(1, p+1)) <= a[i],
        name=f"Supply_{i}"
    )

# Demand constraints
for j in range(1, n+1):
    model.addConstr(
        gp.quicksum(yR[k, j] + yE[k, j] for k in range(1, p+1)) >= b[j],
        name=f"Demand_{j}"
    )

# Flow conservation at stations
for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xR[i, k] + xE[i, k] for i in range(1, m+1)) ==
        gp.quicksum(yR[k, j] + yE[k, j] for j in range(1, n+1)),
        name=f"FlowBalance_{k}"
    )

# Total capacity at stations
for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xR[i, k] + xE[i, k] for i in range(1, m+1)) <= q[k] * z[k],
        name=f"TotalCapacity_{k}"
    )

# Express capacity at stations
for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xE[i, k] for i in range(1, m+1)) <= qexp[k],
        name=f"ExpressCapacity_{k}"
    )

# Link v_kj: station-demand link is open if any flow
for k in range(1, p+1):
    for j in range(1, n+1):
        model.addConstr(
            yR[k, j] + yE[k, j] <= M * v[k, j],
            name=f"LinkOpen_{k}_{j}"
        )
        # v_kj can only be 1 if station k is used
        model.addConstr(v[k, j] <= z[k], name=f"LinkStation_{k}_{j}")

# Link u_kj: express flow active indicator
for k in range(1, p+1):
    for j in range(1, n+1):
        model.addConstr(
            yE[k, j] >= eps * u[k, j],
            name=f"ExpressActiveLB_{k}_{j}"
        )
        model.addConstr(
            yE[k, j] <= M * u[k, j],
            name=f"ExpressActiveUB_{k}_{j}"
        )
        model.addConstr(u[k, j] <= z[k], name=f"ExpressStation_{k}_{j}")

# w_j = 1 iff demand j is served by at least two stations
for j in range(1, n+1):
    model.addConstr(
        gp.quicksum(v[k, j] for k in range(1, p+1)) <= 1 + p * w[j],
        name=f"MultiLink_UB_{j}"
    )
    model.addConstr(
        gp.quicksum(v[k, j] for k in range(1, p+1)) >= 2 * w[j],
        name=f"MultiLink_LB_{j}"
    )

# Diversification constraints
for j in range(1, n+1):
    # At least two express-active links if w_j = 1
    model.addConstr(
        gp.quicksum(u[k, j] for k in range(1, p+1)) >= 2 * w[j],
        name=f"DiversifyLinks_{j}"
    )
    # Total express flow to j at least alpha_j * b_j if w_j = 1
    model.addConstr(
        gp.quicksum(yE[k, j] for k in range(1, p+1)) >= alpha[j] * b[j] * w[j],
        name=f"DiversifyExpress_{j}"
    )

# Solve
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: infeasible")
