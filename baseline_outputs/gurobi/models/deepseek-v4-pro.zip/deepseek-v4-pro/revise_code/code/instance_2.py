import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    param_file = os.path.join(data_dir, 'general_parameters.csv')

    # Load parameters
    params = load_parameters(param_file)
    a1 = int(params['a1'])
    a2 = int(params['a2'])
    training_capacity_per_jet = params['training_capacity_per_jet']
    dual_use_training_efficiency = params['dual_use_training_efficiency']
    training_intensity_cap = params['training_intensity_cap']
    combat_jet_min_year2 = int(params['combat_jet_min_year2'])
    combat_weight = params['combat_weight']
    training_weight = params['training_weight']

    # Fleet sizes
    fleet_year1 = a1
    fleet_year2 = a1 + a2

    # Create model
    model = gp.Model("fighter_jet_allocation")
    model.setParam('OutputFlag', 0)

    # Decision variables (integer)
    T1 = model.addVar(vtype=GRB.INTEGER, name="T1")
    C1 = model.addVar(vtype=GRB.INTEGER, name="C1")
    M1 = model.addVar(vtype=GRB.INTEGER, name="M1")
    T2 = model.addVar(vtype=GRB.INTEGER, name="T2")
    C2 = model.addVar(vtype=GRB.INTEGER, name="C2")
    M2 = model.addVar(vtype=GRB.INTEGER, name="M2")

    # Constraints
    # Year 1 total fleet
    model.addConstr(T1 + C1 + M1 <= fleet_year1, name="fleet_year1")
    # Year 2 total fleet
    model.addConstr(T2 + C2 + M2 <= fleet_year2, name="fleet_year2")

    # Training intensity caps
    model.addConstr(T1 + M1 <= training_intensity_cap * fleet_year1, name="train_cap_year1")
    model.addConstr(T2 + M2 <= training_intensity_cap * fleet_year2, name="train_cap_year2")

    # Combat minimum year 2 (mixed jets count as combat)
    model.addConstr(C2 + M2 >= combat_jet_min_year2, name="combat_min_year2")

    # Objective: combat_weight * (combat jets year2) + training_weight * (trained pilots)
    # Trained pilots = sum over years of (training_capacity_per_jet * T + dual_use_training_efficiency * training_capacity_per_jet * M)
    trained_pilots = training_capacity_per_jet * (T1 + T2) + dual_use_training_efficiency * training_capacity_per_jet * (M1 + M2)
    combat_jets_year2 = C2 + M2
    objective = combat_weight * combat_jets_year2 + training_weight * trained_pilots

    model.setObjective(objective, GRB.MAXIMIZE)

    # Solve
    model.optimize()

    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
