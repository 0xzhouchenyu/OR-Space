import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters from CSV
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

# Extract parameters
min_A_I = params['min_proportion_crude_A_type_I'] / 100.0
min_A_II = params['min_proportion_crude_A_type_II'] / 100.0
price_I = params['selling_price_type_I']
price_II = params['selling_price_type_II']
inv_A = params['inventory_crude_A']
inv_B = params['inventory_crude_B']
max_purchase_A = params['max_purchase_crude_A']
cost_tier1 = params['market_price_crude_A_tier_1']
cost_tier2 = params['market_price_crude_A_tier_2']
cost_tier3 = params['market_price_crude_A_tier_3']
proc_cap = params['processing_capacity']
min_output = params['min_total_gasoline_output']
proc_cost = params['processing_cost_per_ton']
threshold_II = params['type_II_contract_threshold']
lift_II = params['type_II_price_lift']
rebate_threshold = params['bulk_purchase_rebate_threshold']
rebate_amount = params['bulk_purchase_rebate']

# Create model
model = gp.Model("Oil_Blending_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
a1 = model.addVar(lb=0, name="crude_A_in_I")
a2 = model.addVar(lb=0, name="crude_A_in_II")
b1 = model.addVar(lb=0, name="crude_B_in_I")
b2 = model.addVar(lb=0, name="crude_B_in_II")

p1 = model.addVar(lb=0, ub=500, name="purchase_tier1")
p2 = model.addVar(lb=0, ub=500, name="purchase_tier2")
p3 = model.addVar(lb=0, ub=500, name="purchase_tier3")

y1 = model.addVar(vtype=GRB.BINARY, name="y1")
y2 = model.addVar(vtype=GRB.BINARY, name="y2")

z_lift = model.addVar(vtype=GRB.BINARY, name="z_lift")
z_rebate = model.addVar(vtype=GRB.BINARY, name="z_rebate")

# Auxiliary variable for linearization of lift revenue
w = model.addVar(lb=0, name="w")

# Total amounts
total_A_purchased = p1 + p2 + p3
total_type_I = a1 + b1
total_type_II = a2 + b2
total_gasoline = total_type_I + total_type_II

# Tiered purchase constraints
model.addConstr(p1 <= 500)
model.addConstr(p2 <= 500 * y1)
model.addConstr(p3 <= 500 * y2)
model.addConstr(p1 >= 500 * y1)
model.addConstr(p2 >= 500 * y2)

# Supply constraints
model.addConstr(a1 + a2 <= inv_A + total_A_purchased)
model.addConstr(b1 + b2 <= inv_B)

# Quality constraints (minimum proportion of crude A)
model.addConstr(a1 >= min_A_I * (a1 + b1))
model.addConstr(a2 >= min_A_II * (a2 + b2))

# Throughput window
model.addConstr(total_gasoline <= proc_cap)
model.addConstr(total_gasoline >= min_output)

# Type II price lift linearization
M_lift = proc_cap  # upper bound on total_type_II
model.addConstr(total_type_II >= threshold_II * z_lift)
model.addConstr(w <= total_type_II)
model.addConstr(w <= M_lift * z_lift)
model.addConstr(w >= total_type_II - M_lift * (1 - z_lift))

# Bulk purchase rebate
model.addConstr(total_A_purchased >= rebate_threshold * z_rebate)

# Revenue and cost
revenue = price_I * total_type_I + price_II * total_type_II + lift_II * w
cost = (cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3 +
        proc_cost * total_gasoline - rebate_amount * z_rebate)

# Objective
model.setObjective(revenue - cost, GRB.MAXIMIZE)

# Solve
model.optimize()

# Output
print(f"FINAL_OBJ_VALUE: {model.objVal}")
