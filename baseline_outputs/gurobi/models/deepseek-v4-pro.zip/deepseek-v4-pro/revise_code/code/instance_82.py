import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    total_space = float(params['mall_total_space'])
    rent_pct = float(params['rent_percentage']) / 100.0
    common_area_factor = float(params['common_area_factor'])
    gm_concession = float(params['general_merchandise_third_store_concession'])
    cat_security_cost = float(params['catering_third_store_security_cost'])
    # cat_threshold = int(params['catering_third_store_security_threshold'])  # not needed, max is 3
    
    # Read store data
    stores = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Store_Type'].strip()
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            stores.append({
                'name': name,
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits
            })
    
    # Create model
    model = gp.Model('mall_leasing')
    model.setParam('OutputFlag', 0)
    
    # Decision variables: for each store type, binary for each possible count
    y = {}  # y[i, k] = 1 if store type i has k stores
    x = {}  # x[i] = number of stores of type i (integer, but expressed via binaries)
    profit_expr = gp.LinExpr()
    area_expr = gp.LinExpr()
    
    for i, s in enumerate(stores):
        # Determine possible counts
        possible_counts = []
        for k in range(s['min'], s['max'] + 1):
            if k == 0:
                possible_counts.append((k, 0.0))  # profit 0
            elif k in s['profits']:
                possible_counts.append((k, s['profits'][k]))
        # If no possible counts (should not happen), skip
        if not possible_counts:
            continue
        
        # Create binary variables for each possible count
        for (k, _) in possible_counts:
            y[i, k] = model.addVar(vtype=GRB.BINARY, name=f"y_{s['name']}_{k}")
        
        # Constraint: exactly one count chosen
        model.addConstr(gp.quicksum(y[i, k] for (k, _) in possible_counts) == 1,
                        name=f"count_{s['name']}")
        
        # x[i] = sum(k * y[i,k])
        x[i] = gp.quicksum(k * y[i, k] for (k, _) in possible_counts)
        
        # Profit contribution: sum(k * profit_per_store * y[i,k])
        profit_expr.add(gp.quicksum(k * profit * y[i, k] for (k, profit) in possible_counts))
        
        # Area contribution: x[i] * area * common_area_factor
        area_expr.add(x[i] * s['area'] * common_area_factor)
    
    # Space constraint
    model.addConstr(area_expr <= total_space, name='space')
    
    # Total profit
    total_profit = profit_expr
    
    # Base rent
    base_rent = rent_pct * total_profit
    
    # Concessions / costs
    # Find indices for General_Merchandise and Catering
    gm_idx = None
    cat_idx = None
    for i, s in enumerate(stores):
        if s['name'] == 'General_Merchandise':
            gm_idx = i
        elif s['name'] == 'Catering':
            cat_idx = i
    
    obj = base_rent
    if gm_idx is not None and (gm_idx, 3) in y:
        obj -= gm_concession * y[gm_idx, 3]
    if cat_idx is not None and (cat_idx, 3) in y:
        obj -= cat_security_cost * y[cat_idx, 3]
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()
