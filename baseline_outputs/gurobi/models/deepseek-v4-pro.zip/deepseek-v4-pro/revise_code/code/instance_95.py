import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load table_1.csv
weeks_data = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Week'].strip().lower() == 'total':
            continue
        weeks_data.append({
            'week': int(row['Week']),
            'demand': float(row['Demand_1000_boxes']),
            'capacity': float(row['Production_Capacity_1000_boxes']),
            'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
        })

# Load general_parameters.csv
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'])

storage_cost = params['storage_cost_per_thousand_boxes']
fixed_setup_cost = params['fixed_setup_cost']
week2_push_threshold = params['week2_push_threshold']
week3_capacity_loss = params['week3_capacity_loss_after_week2_push']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']

n_weeks = len(weeks_data)

# Model
m = gp.Model("Beverage_Production_Planning")
m.setParam('OutputFlag', 0)

# Decision variables
x = m.addVars(n_weeks, lb=0, name="x")          # production
s = m.addVars(n_weeks, lb=0, name="s")          # end-of-week inventory
y = m.addVars(n_weeks, vtype=GRB.BINARY, name="y")  # setup indicator

# Week 2 special binary variables
z_mc = m.addVar(vtype=GRB.BINARY, name="z_mc")      # 1 if x[1] > microclean threshold
z_push = m.addVar(vtype=GRB.BINARY, name="z_push")  # 1 if x[1] > push threshold

# Big-M and epsilon
M_mc = weeks_data[1]['capacity']   # 40
M_push = weeks_data[1]['capacity'] # 40
eps = 1e-4

# Inventory balance constraints (initial inventory = 0)
m.addConstr(x[0] - s[0] == weeks_data[0]['demand'], name="balance_1")
for t in range(1, n_weeks):
    m.addConstr(s[t-1] + x[t] - s[t] == weeks_data[t]['demand'], name=f"balance_{t+1}")

# Production capacity and setup linking
for t in range(n_weeks):
    m.addConstr(x[t] <= weeks_data[t]['capacity'] * y[t], name=f"cap_{t+1}")

# Week 2 micro-clean trigger
m.addConstr(x[1] <= week2_microclean_threshold + M_mc * z_mc, name="mc_upper")
m.addConstr(x[1] >= week2_microclean_threshold + eps - M_mc * (1 - z_mc), name="mc_lower")

# Week 2 push threshold (affects week 3 capacity)
m.addConstr(x[1] <= week2_push_threshold + M_push * z_push, name="push_upper")
m.addConstr(x[1] >= week2_push_threshold + eps - M_push * (1 - z_push), name="push_lower")

# Week 3 capacity reduction if push is triggered
m.addConstr(x[2] <= weeks_data[2]['capacity'] - week3_capacity_loss * z_push, name="week3_cap_loss")

# Objective: production cost + storage cost + setup cost + micro-clean fee
obj = gp.quicksum(weeks_data[t]['cost'] * x[t] for t in range(n_weeks)) + \
      gp.quicksum(storage_cost * s[t] for t in range(n_weeks)) + \
      gp.quicksum(fixed_setup_cost * y[t] for t in range(n_weeks)) + \
      week2_microclean_fee * z_mc

m.setObjective(obj, GRB.MINIMIZE)

# Solve
m.optimize()

# Output
print(f"FINAL_OBJ_VALUE: {m.objVal}")
