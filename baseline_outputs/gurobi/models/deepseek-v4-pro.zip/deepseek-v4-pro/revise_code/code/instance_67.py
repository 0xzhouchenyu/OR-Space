import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_demand(filepath):
    demand = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            month = row['Month']
            product = row['Product']
            units = int(row['Market_Demand_Units'])
            demand[(month, product)] = units
    return demand

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            value = float(row['Value'])
            params[name] = value
    return params

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    demand_file = os.path.join(base_dir, 'data', 'table_1.csv')
    param_file = os.path.join(base_dir, 'data', 'general_parameters.csv')
    
    # Load data
    demand_data = load_demand(demand_file)
    params = load_parameters(param_file)
    
    # Planning months
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']
    
    # Extract parameters
    cost_I = params['product_I_cost_jun_to_dec']  # 4.5
    cost_II = params['product_II_cost_jun_to_dec']  # 7
    prod_cost = {'Product_I': cost_I, 'Product_II': cost_II}
    
    machine_hours = {
        'Product_I': params['product_I_machine_hours'],  # 0.8
        'Product_II': params['product_II_machine_hours']  # 1.6
    }
    machine_cap = params['machine_hours_capacity_monthly']  # 120000
    
    power = {
        'Product_I': params['product_I_power_kwh'],  # 2
        'Product_II': params['product_II_power_kwh']  # 3
    }
    
    grid_quota = {
        'July': params['grid_quota_july'],
        'August': params['grid_quota_august'],
        'September': params['grid_quota_september'],
        'October': params['grid_quota_october'],
        'November': params['grid_quota_november'],
        'December': params['grid_quota_december']
    }
    
    gen_max = {
        'July': params['generator_max_july'],
        'August': params['generator_max_august'],
        'September': params['generator_max_september'],
        'October': params['generator_max_october'],
        'November': params['generator_max_november'],
        'December': params['generator_max_december']
    }
    
    grid_cost = params['grid_electricity_cost']  # 0.6
    gen_cost = params['generator_electricity_cost']  # 0.9
    
    volume = {
        'Product_I': params['product_I_volume'],  # 0.2
        'Product_II': params['product_II_volume']  # 0.4
    }
    warehouse_cap = params['warehouse_capacity']  # 30000
    own_wh_cost = params['own_warehouse_cost']  # 1
    
    initial_inv = params['initial_inventory_july']  # 0
    
    # Demand for planning months
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]
    
    # Model
    model = gp.Model("Revised_Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(months, products, name="prod", lb=0.0)
    inv = model.addVars(months, products, name="inv", lb=0.0)
    grid = model.addVars(months, name="grid", lb=0.0)
    gen = model.addVars(months, name="gen", lb=0.0)
    
    # Objective
    obj = gp.quicksum(prod_cost[p] * x[m, p] for m in months for p in products)
    obj += gp.quicksum(own_wh_cost * gp.quicksum(volume[p] * inv[m, p] for p in products) for m in months)
    obj += gp.quicksum(grid_cost * grid[m] + gen_cost * gen[m] for m in months)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    for i, m in enumerate(months):
        # Inventory balance
        for p in products:
            if i == 0:
                model.addConstr(inv[m, p] == initial_inv + x[m, p] - demand[(m, p)],
                                name=f"inv_balance_{m}_{p}")
            else:
                prev_m = months[i-1]
                model.addConstr(inv[m, p] == inv[prev_m, p] + x[m, p] - demand[(m, p)],
                                name=f"inv_balance_{m}_{p}")
        
        # Machine hours capacity
        model.addConstr(gp.quicksum(machine_hours[p] * x[m, p] for p in products) <= machine_cap,
                        name=f"machine_cap_{m}")
        
        # Electricity balance
        model.addConstr(gp.quicksum(power[p] * x[m, p] for p in products) == grid[m] + gen[m],
                        name=f"elec_balance_{m}")
        
        # Grid quota
        model.addConstr(grid[m] <= grid_quota[m], name=f"grid_quota_{m}")
        
        # Generator limit
        model.addConstr(gen[m] <= gen_max[m], name=f"gen_limit_{m}")
        
        # Warehouse capacity
        model.addConstr(gp.quicksum(volume[p] * inv[m, p] for p in products) <= warehouse_cap,
                        name=f"warehouse_cap_{m}")
    
    # Solve
    model.optimize()
    
    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Model did not solve to optimality. Status:", model.status)

if __name__ == "__main__":
    main()
