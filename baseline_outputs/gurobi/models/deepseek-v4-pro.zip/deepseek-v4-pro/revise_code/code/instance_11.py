import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Read data
    df1 = pd.read_csv(table1_path)
    df_params = pd.read_csv(params_path)

    # Parse table_1.csv
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]

    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    # Original inspection hours per unit are not used directly; new ones from params
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])

    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])

    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp_inhouse = float(row_cap['Inspection_hours_per_unit'])  # 40

    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])      # 12
    cost_asm = float(row_cost['Assembly_hours_per_unit'])           # 8
    # cost_insp_original = float(row_cost['Inspection_hours_per_unit']) # 10, not used directly

    # Parse general_parameters.csv
    def get_param(name):
        return float(df_params[df_params['Parameter_Name'] == name]['Value'].iloc[0])

    min_weekly_profit = get_param('min_weekly_profit')
    min_type_a = get_param('min_type_a_production')
    # idle_time_minimization_weights = 'proportional_to_hourly_cost' (not a number)
    insp_a_M = get_param('insp_a_M')
    insp_b_M = get_param('insp_b_M')
    insp_a_E = get_param('insp_a_E')
    insp_b_E = get_param('insp_b_E')
    cap_ext = get_param('cap_ext')
    cost_insp_M = get_param('cost_insp_M')
    cost_insp_E = get_param('cost_insp_E')
    cost_ext = get_param('cost_ext')
    mode_fee_M = get_param('mode_fee_M')
    mode_fee_E = get_param('mode_fee_E')
    risk_penalty_M = get_param('risk_penalty_M')
    cost_insp_weight = get_param('cost_insp_weight')
    planning_horizon_weeks = int(get_param('planning_horizon_weeks'))
    idle_tolerance = get_param('idle_tolerance')

    W = planning_horizon_weeks  # 2

    # Bounds for production
    max_xA = int(cap_mfg // mfg_a)  # 120/20 = 6
    max_xB = int(cap_asm // asm_b)  # 80/7 = 11

    # Big M for linearization
    M_delta = max_xA + 2 * max_xB + 1  # 6 + 22 = 28, use 30

    # ---------- Stage 1: Minimize idle cost + risk penalty ----------
    m1 = gp.Model("Stage1")
    m1.setParam('OutputFlag', 0)

    # Variables
    xA = m1.addVars(W, lb=min_type_a, ub=max_xA, vtype=GRB.INTEGER, name="xA")
    xB = m1.addVars(W, lb=0, ub=max_xB, vtype=GRB.INTEGER, name="xB")
    mode = m1.addVars(W, vtype=GRB.BINARY, name="mode")  # 1 = Manual, 0 = Enhanced

    # Inspection requirement linearization
    delta = m1.addVars(W, lb=0, ub=M_delta, vtype=GRB.CONTINUOUS, name="delta")
    insp_req = m1.addVars(W, lb=0, vtype=GRB.CONTINUOUS, name="insp_req")

    # In-house and external inspection hours
    in_house_M = m1.addVars(W, lb=0, ub=cap_insp_inhouse, vtype=GRB.CONTINUOUS, name="in_house_M")
    in_house_E = m1.addVars(W, lb=0, ub=cap_insp_inhouse, vtype=GRB.CONTINUOUS, name="in_house_E")
    ext = m1.addVars(W, lb=0, ub=cap_ext, vtype=GRB.CONTINUOUS, name="ext")

    # Idle times
    idle_mfg = m1.addVars(W, lb=0, vtype=GRB.CONTINUOUS, name="idle_mfg")
    idle_asm = m1.addVars(W, lb=0, vtype=GRB.CONTINUOUS, name="idle_asm")
    idle_insp = m1.addVars(W, lb=0, vtype=GRB.CONTINUOUS, name="idle_insp")

    # Profit (needed for constraint)
    profit = m1.addVars(W, lb=-GRB.INFINITY, vtype=GRB.CONTINUOUS, name="profit")

    for w in range(W):
        # Manufacturing capacity
        m1.addConstr(20 * xA[w] == cap_mfg - idle_mfg[w])
        # Assembly capacity
        m1.addConstr(5 * xA[w] + 7 * xB[w] == cap_asm - idle_asm[w])

        # Inspection requirement: insp_req = 2*xA + 4*xB + delta, delta = (xA + 2*xB)*mode
        m1.addConstr(insp_req[w] == 2 * xA[w] + 4 * xB[w] + delta[w])
        m1.addConstr(delta[w] <= xA[w] + 2 * xB[w])
        m1.addConstr(delta[w] <= M_delta * mode[w])
        m1.addConstr(delta[w] >= xA[w] + 2 * xB[w] - M_delta * (1 - mode[w]))

        # Inspection capacity and allocation
        m1.addConstr(in_house_M[w] <= cap_insp_inhouse * mode[w])
        m1.addConstr(in_house_E[w] <= cap_insp_inhouse * (1 - mode[w]))
        m1.addConstr(ext[w] <= cap_ext * (1 - mode[w]))
        m1.addConstr(in_house_M[w] + in_house_E[w] + ext[w] == insp_req[w])

        # Idle inspection: in-house capacity minus used in-house hours
        m1.addConstr(idle_insp[w] == cap_insp_inhouse - (in_house_M[w] + in_house_E[w]))

        # Profit calculation
        revenue = price_a * xA[w] + price_b * xB[w]
        mfg_cost = mfg_a * cost_mfg * xA[w] + mfg_b * cost_mfg * xB[w]  # mfg_b=0
        asm_cost = (asm_a * xA[w] + asm_b * xB[w]) * cost_asm
        insp_cost = (cost_insp_M * in_house_M[w] + cost_insp_E * in_house_E[w] +
                     cost_ext * ext[w] +
                     mode_fee_M * mode[w] + mode_fee_E * (1 - mode[w]) +
                     risk_penalty_M * mode[w])
        m1.addConstr(profit[w] == revenue - mfg_cost - asm_cost - insp_cost)

        # Minimum weekly profit
        m1.addConstr(profit[w] >= min_weekly_profit)

    # Objective 1: minimize idle cost + risk penalty
    idle_cost = gp.quicksum(
        cost_mfg * idle_mfg[w] + cost_asm * idle_asm[w] + cost_insp_weight * idle_insp[w]
        for w in range(W)
    )
    risk_cost = gp.quicksum(risk_penalty_M * mode[w] for w in range(W))
    obj1 = idle_cost + risk_cost
    m1.setObjective(obj1, GRB.MINIMIZE)

    m1.optimize()

    if m1.status != GRB.OPTIMAL:
        raise RuntimeError("Stage 1 optimization failed")

    min_obj1 = m1.objVal

    # ---------- Stage 2: Maximize total profit ----------
    m2 = gp.Model("Stage2")
    m2.setParam('OutputFlag', 0)

    # Same variables
    xA2 = m2.addVars(W, lb=min_type_a, ub=max_xA, vtype=GRB.INTEGER, name="xA2")
    xB2 = m2.addVars(W, lb=0, ub=max_xB, vtype=GRB.INTEGER, name="xB2")
    mode2 = m2.addVars(W, vtype=GRB.BINARY, name="mode2")
    delta2 = m2.addVars(W, lb=0, ub=M_delta, vtype=GRB.CONTINUOUS, name="delta2")
    insp_req2 = m2.addVars(W, lb=0, vtype=GRB.CONTINUOUS, name="insp_req2")
    in_house_M2 = m2.addVars(W, lb=0, ub=cap_insp_inhouse, vtype=GRB.CONTINUOUS, name="in_house_M2")
    in_house_E2 = m2.addVars(W, lb=0, ub=cap_insp_inhouse, vtype=GRB.CONTINUOUS, name="in_house_E2")
    ext2 = m2.addVars(W, lb=0, ub=cap_ext, vtype=GRB.CONTINUOUS, name="ext2")
    idle_mfg2 = m2.addVars(W, lb=0, vtype=GRB.CONTINUOUS, name="idle_mfg2")
    idle_asm2 = m2.addVars(W, lb=0, vtype=GRB.CONTINUOUS, name="idle_asm2")
    idle_insp2 = m2.addVars(W, lb=0, vtype=GRB.CONTINUOUS, name="idle_insp2")
    profit2 = m2.addVars(W, lb=-GRB.INFINITY, vtype=GRB.CONTINUOUS, name="profit2")

    for w in range(W):
        m2.addConstr(20 * xA2[w] == cap_mfg - idle_mfg2[w])
        m2.addConstr(5 * xA2[w] + 7 * xB2[w] == cap_asm - idle_asm2[w])

        m2.addConstr(insp_req2[w] == 2 * xA2[w] + 4 * xB2[w] + delta2[w])
        m2.addConstr(delta2[w] <= xA2[w] + 2 * xB2[w])
        m2.addConstr(delta2[w] <= M_delta * mode2[w])
        m2.addConstr(delta2[w] >= xA2[w] + 2 * xB2[w] - M_delta * (1 - mode2[w]))

        m2.addConstr(in_house_M2[w] <= cap_insp_inhouse * mode2[w])
        m2.addConstr(in_house_E2[w] <= cap_insp_inhouse * (1 - mode2[w]))
        m2.addConstr(ext2[w] <= cap_ext * (1 - mode2[w]))
        m2.addConstr(in_house_M2[w] + in_house_E2[w] + ext2[w] == insp_req2[w])

        m2.addConstr(idle_insp2[w] == cap_insp_inhouse - (in_house_M2[w] + in_house_E2[w]))

        revenue2 = price_a * xA2[w] + price_b * xB2[w]
        mfg_cost2 = mfg_a * cost_mfg * xA2[w] + mfg_b * cost_mfg * xB2[w]
        asm_cost2 = (asm_a * xA2[w] + asm_b * xB2[w]) * cost_asm
        insp_cost2 = (cost_insp_M * in_house_M2[w] + cost_insp_E * in_house_E2[w] +
                      cost_ext * ext2[w] +
                      mode_fee_M * mode2[w] + mode_fee_E * (1 - mode2[w]) +
                      risk_penalty_M * mode2[w])
        m2.addConstr(profit2[w] == revenue2 - mfg_cost2 - asm_cost2 - insp_cost2)
        m2.addConstr(profit2[w] >= min_weekly_profit)

    # First objective constraint
    idle_cost2 = gp.quicksum(
        cost_mfg * idle_mfg2[w] + cost_asm * idle_asm2[w] + cost_insp_weight * idle_insp2[w]
        for w in range(W)
    )
    risk_cost2 = gp.quicksum(risk_penalty_M * mode2[w] for w in range(W))
    obj1_expr = idle_cost2 + risk_cost2
    m2.addConstr(obj1_expr <= min_obj1 + idle_tolerance)

    # Objective 2: maximize total profit
    total_profit = gp.quicksum(profit2[w] for w in range(W))
    m2.setObjective(total_profit, GRB.MAXIMIZE)

    m2.optimize()

    if m2.status != GRB.OPTIMAL:
        raise RuntimeError("Stage 2 optimization failed")

    final_obj = m2.objVal
    print(f"FINAL_OBJ_VALUE: {round(final_obj, 4)}")

if __name__ == '__main__':
    solve()
