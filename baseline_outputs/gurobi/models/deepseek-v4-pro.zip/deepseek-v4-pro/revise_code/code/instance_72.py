import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read property data
properties = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_risky_multiplier = params['scen_1_risky_multiplier']
scen_2_risky_multiplier = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = int(params['max_risky_properties'])

# Expected multiplier for risky portion
E_mult = scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier
boost = E_mult - 1.0

# Create model
m = gp.Model("RealEstate")
m.setParam('OutputFlag', 0)

# Decision variables
x = {}  # purchase binary
y = {}  # has any risky binary
z = {}  # risky fraction (continuous)
for p in properties:
    name = p['name']
    x[name] = m.addVar(vtype=GRB.BINARY, name=f"x_{name}")
    y[name] = m.addVar(vtype=GRB.BINARY, name=f"y_{name}")
    z[name] = m.addVar(lb=0, ub=per_property_risky_cap, name=f"z_{name}")

# Budget constraint
m.addConstr(gp.quicksum(p['cost'] * x[p['name']] for p in properties) <= budget, "Budget")

# Exclusion constraint
m.addConstr(x['Property_4'] + x['Property_3'] <= 1, "Exclusion")

# Risky allocation constraints
for p in properties:
    name = p['name']
    # Risky fraction only if purchased
    m.addConstr(z[name] <= per_property_risky_cap * x[name], f"Risky_if_purchased_{name}")
    # Link risky indicator y to z
    m.addConstr(z[name] <= per_property_risky_cap * y[name], f"Risky_indicator_{name}")
    # y requires purchase
    m.addConstr(y[name] <= x[name], f"Risky_requires_purchase_{name}")

# Total risky exposure (cost of properties with any risky)
m.addConstr(gp.quicksum(p['cost'] * y[p['name']] for p in properties) <= total_risky_budget, "TotalRiskyBudget")

# Maximum number of properties with risky tenants
m.addConstr(gp.quicksum(y[p['name']] for p in properties) <= max_risky_properties, "MaxRiskyProperties")

# Objective: maximize expected annual income
obj = gp.quicksum(p['income'] * (x[p['name']] + boost * z[p['name']]) for p in properties)
m.setObjective(obj, GRB.MAXIMIZE)

# Solve
m.optimize()

# Output
print(f"FINAL_OBJ_VALUE: {m.objVal}")
