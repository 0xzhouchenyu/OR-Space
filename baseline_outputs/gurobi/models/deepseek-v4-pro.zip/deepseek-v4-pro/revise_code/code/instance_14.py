import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load items
    items = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })
    
    # Load parameters
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_daily_calories = params['min_daily_calories']
    max_daily_calories = params['max_daily_calories']
    max_daily_sodium = params['max_daily_sodium']
    
    # Derived constants
    max_units = int(total_weight_limit // 100)   # 8
    max_meal_units = 3                           # 300g per meal / 100g per unit
    
    # Item indices
    item_idx = list(range(len(items)))
    veg_idx = [i for i in item_idx if items[i]['type'] == 'Vegetable']
    
    # Model
    m = gp.Model("meal_planning")
    m.setParam('OutputFlag', 0)
    
    # Variables
    purchase = m.addVars(item_idx, vtype=GRB.INTEGER, name="purchase", lb=0)
    lunch = m.addVars(item_idx, vtype=GRB.INTEGER, name="lunch", lb=0)
    dinner = m.addVars(item_idx, vtype=GRB.INTEGER, name="dinner", lb=0)
    select_item = m.addVars(item_idx, vtype=GRB.BINARY, name="select")
    lunch_veg = m.addVars(veg_idx, vtype=GRB.BINARY, name="lunch_veg")
    dinner_veg = m.addVars(veg_idx, vtype=GRB.BINARY, name="dinner_veg")
    
    # Budget constraint
    m.addConstr(
        gp.quicksum(items[i]['cost'] * purchase[i] for i in item_idx) <= max_budget,
        name="budget"
    )
    
    # Total weight constraint
    m.addConstr(
        100 * gp.quicksum(purchase[i] for i in item_idx) <= total_weight_limit,
        name="total_weight"
    )
    
    # Per-meal exact weight (300g = 3 units)
    m.addConstr(
        gp.quicksum(lunch[i] for i in item_idx) == 3,
        name="lunch_weight"
    )
    m.addConstr(
        gp.quicksum(dinner[i] for i in item_idx) == 3,
        name="dinner_weight"
    )
    
    # Purchase covers assigned units
    for i in item_idx:
        m.addConstr(
            purchase[i] >= lunch[i] + dinner[i],
            name=f"purchase_cover_{i}"
        )
    
    # Big-M linking of select_item
    for i in item_idx:
        m.addConstr(purchase[i] <= max_units * select_item[i], name=f"bigM_purchase_{i}")
        m.addConstr(lunch[i] <= max_meal_units * select_item[i], name=f"bigM_lunch_{i}")
        m.addConstr(dinner[i] <= max_meal_units * select_item[i], name=f"bigM_dinner_{i}")
    
    # Vegetable coverage per meal
    for i in veg_idx:
        m.addConstr(lunch[i] >= lunch_veg[i], name=f"lunch_veg_lb_{i}")
        m.addConstr(lunch[i] <= max_meal_units * lunch_veg[i], name=f"lunch_veg_ub_{i}")
        m.addConstr(dinner[i] >= dinner_veg[i], name=f"dinner_veg_lb_{i}")
        m.addConstr(dinner[i] <= max_meal_units * dinner_veg[i], name=f"dinner_veg_ub_{i}")
    
    m.addConstr(
        gp.quicksum(lunch_veg[i] for i in veg_idx) >= min_veg_types,
        name="min_veg_lunch"
    )
    m.addConstr(
        gp.quicksum(dinner_veg[i] for i in veg_idx) >= min_veg_types,
        name="min_veg_dinner"
    )
    
    # Calorie bounds (only from assigned units)
    total_calories = gp.quicksum(
        items[i]['calories'] * (lunch[i] + dinner[i]) for i in item_idx
    )
    m.addConstr(total_calories >= min_daily_calories, name="min_calories")
    m.addConstr(total_calories <= max_daily_calories, name="max_calories")
    
    # Sodium bound (only from assigned units)
    total_sodium = gp.quicksum(
        items[i]['sodium'] * (lunch[i] + dinner[i]) for i in item_idx
    )
    m.addConstr(total_sodium <= max_daily_sodium, name="max_sodium")
    
    # Objective: maximize total protein from assigned units
    total_protein = gp.quicksum(
        items[i]['protein'] * (lunch[i] + dinner[i]) for i in item_idx
    )
    m.setObjective(total_protein, GRB.MAXIMIZE)
    
    # Solve
    m.optimize()
    
    # Output
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        # In case of infeasibility or other status, print 0 or handle gracefully
        print(f"FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
