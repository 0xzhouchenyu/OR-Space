import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = [row for row in reader]
    return headers, rows

def load_general_parameters(filename='general_parameters.csv'):
    headers, rows = load_csv(filename)
    params = {}
    for row in rows:
        name = row[0].strip()
        try:
            value = float(row[1].strip())
        except ValueError:
            value = row[1].strip()
        params[name] = value
    return params

def load_crop_data(filename='table_1.csv'):
    headers, rows = load_csv(filename)
    crops = [h.strip() for h in headers[1:]]
    data = {}
    for row in rows:
        item = row[0].strip()
        values = [float(v.strip()) for v in row[1:]]
        data[item] = dict(zip(crops, values))
    return crops, data

def main():
    # Load data
    params = load_general_parameters()
    crops, crop_data = load_crop_data()

    # Extract parameters
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']

    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = int(params['max_chickens'])
    max_dairy_cows = int(params['max_dairy_cows'])

    # New biosecurity parameters
    fixed_setup = params['fixed_cost_chicken_setup']
    min_chickens_open = int(params['min_chickens_if_coop_open'])
    second_threshold = int(params['second_biosecurity_threshold'])
    second_cost = params['second_biosecurity_cost']
    train_aw = params['biosecurity_training_aw_days']
    train_ss = params['biosecurity_training_ss_days']

    # Crop data
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']

    # Create model
    m = gp.Model("Farm_Revised")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # Crop areas (continuous)
    x = {}
    for c in crops:
        x[c] = m.addVar(lb=0, name=f"x_{c}")

    # Dairy cows (integer)
    dairy = m.addVar(lb=0, ub=max_dairy_cows, vtype=GRB.INTEGER, name="dairy")

    # Chickens (integer)
    chickens = m.addVar(lb=0, ub=max_chickens, vtype=GRB.INTEGER, name="chickens")

    # Binary: coop open
    z_open = m.addVar(vtype=GRB.BINARY, name="z_open")

    # Binary: second biosecurity level triggered
    z_second = m.addVar(vtype=GRB.BINARY, name="z_second")

    # Surplus labor for external work
    surplus_aw = m.addVar(lb=0, name="surplus_aw")
    surplus_ss = m.addVar(lb=0, name="surplus_ss")

    # Objective: maximize net income
    obj = gp.quicksum(crop_income[c] * x[c] for c in crops) \
          + income_dairy * dairy \
          + income_chicken * chickens \
          - fixed_setup * z_open \
          - second_cost * z_second \
          + ext_rate_aw * surplus_aw \
          + ext_rate_ss * surplus_ss
    m.setObjective(obj, GRB.MAXIMIZE)

    # Land constraint
    m.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * dairy <= land_area, "Land")

    # Funds constraint (only investment, not operating costs)
    m.addConstr(inv_dairy * dairy + inv_chicken * chickens <= funds_available, "Funds")

    # Labor autumn/winter
    m.addConstr(gp.quicksum(crop_aw[c] * x[c] for c in crops)
                + labor_aw_dairy * dairy
                + labor_aw_chicken * chickens
                + train_aw * z_open
                + surplus_aw == labor_aw, "Labor_AW")

    # Labor spring/summer
    m.addConstr(gp.quicksum(crop_ss[c] * x[c] for c in crops)
                + labor_ss_dairy * dairy
                + labor_ss_chicken * chickens
                + train_ss * z_open
                + surplus_ss == labor_ss, "Labor_SS")

    # Coop open implies minimum flock size, and zero if closed
    m.addConstr(chickens >= min_chickens_open * z_open, "MinFlock")
    m.addConstr(chickens <= max_chickens * z_open, "MaxFlock")

    # Second biosecurity threshold logic
    # If chickens > second_threshold, z_second must be 1
    # chickens <= second_threshold + (max_chickens - second_threshold) * z_second
    m.addConstr(chickens <= second_threshold + (max_chickens - second_threshold) * z_second, "SecondUpper")
    # chickens >= (second_threshold + 1) * z_second
    m.addConstr(chickens >= (second_threshold + 1) * z_second, "SecondLower")

    # Optimize
    m.optimize()

    if m.status == GRB.OPTIMAL:
        obj_val = m.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # In case of infeasibility or other issues, print 0 as fallback
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
