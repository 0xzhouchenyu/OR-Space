import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table1_path = os.path.join(base_dir, 'data', 'table_1.csv')
    params_path = os.path.join(base_dir, 'data', 'general_parameters.csv')

    # Read orders
    orders = []
    with open(table1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    total_required_area = sum(w * l for w, l in zip(widths, lengths))

    # Read general parameters
    std_widths = []
    pattern_setup_penalty = 0.0
    wide_roll_threshold = 0.0
    wide_roll_extra_penalty = 0.0
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            value = float(row['Value'])
            if name.startswith('standard_width'):
                std_widths.append(value)
            elif name == 'pattern_setup_penalty':
                pattern_setup_penalty = value
            elif name == 'wide_roll_threshold_width':
                wide_roll_threshold = value
            elif name == 'wide_roll_extra_setup_penalty':
                wide_roll_extra_penalty = value

    # Generate all feasible cutting patterns for each standard width
    patterns_by_std = []  # list of dicts: {'width': W, 'patterns': [ [counts], ... ]}
    for W in std_widths:
        patterns = []
        def build(idx, current_counts, current_sum):
            if idx == len(widths):
                if any(c > 0 for c in current_counts):
                    patterns.append(current_counts.copy())
                return
            max_count = int((W - current_sum) // widths[idx])
            for c in range(max_count + 1):
                current_counts.append(c)
                build(idx + 1, current_counts, current_sum + c * widths[idx])
                current_counts.pop()
        build(0, [], 0.0)
        patterns_by_std.append({'width': W, 'patterns': patterns})

    # Create optimization model
    m = gp.Model("CuttingStock")
    m.setParam('OutputFlag', 0)

    # Variables
    x = {}  # (w_idx, p_idx) -> continuous length used
    y = {}  # (w_idx, p_idx) -> binary indicator for pattern usage

    M = sum(lengths)  # safe big-M

    for w_idx, data in enumerate(patterns_by_std):
        for p_idx in range(len(data['patterns'])):
            x[w_idx, p_idx] = m.addVar(lb=0, name=f"x_{w_idx}_{p_idx}")
            y[w_idx, p_idx] = m.addVar(vtype=GRB.BINARY, name=f"y_{w_idx}_{p_idx}")

    # Objective: minimize total area used + penalties
    total_area_used = gp.quicksum(
        data['width'] * x[w_idx, p_idx]
        for w_idx, data in enumerate(patterns_by_std)
        for p_idx in range(len(data['patterns']))
    )
    penalty_expr = gp.quicksum(
        (pattern_setup_penalty + (wide_roll_extra_penalty if data['width'] >= wide_roll_threshold else 0)) * y[w_idx, p_idx]
        for w_idx, data in enumerate(patterns_by_std)
        for p_idx in range(len(data['patterns']))
    )
    m.setObjective(total_area_used + penalty_expr, GRB.MINIMIZE)

    # Demand constraints
    for j in range(len(widths)):
        m.addConstr(
            gp.quicksum(
                data['patterns'][p_idx][j] * x[w_idx, p_idx]
                for w_idx, data in enumerate(patterns_by_std)
                for p_idx in range(len(data['patterns']))
            ) >= lengths[j],
            name=f"demand_{j}"
        )

    # Linking constraints
    for w_idx, data in enumerate(patterns_by_std):
        for p_idx in range(len(data['patterns'])):
            m.addConstr(x[w_idx, p_idx] <= M * y[w_idx, p_idx], name=f"link_{w_idx}_{p_idx}")

    # Solve
    m.optimize()

    if m.status == GRB.OPTIMAL:
        waste = m.objVal - total_required_area
        print(f"FINAL_OBJ_VALUE: {round(waste, 4)}")
    else:
        print("Model did not solve to optimality.")

if __name__ == "__main__":
    main()
