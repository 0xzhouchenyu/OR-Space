import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            name = row[0].strip()
            value = row[1].strip()
            # Convert to appropriate type
            if name in ('overtime_hours_cap', 'min_prod_I', 'min_prod_II', 'min_prod_III'):
                params[name] = float(value)
            elif name == 'overtime_cost_multiplier':
                params[name] = float(value)
    return params

def load_table_1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    equipment_names = []
    products = []
    processing_times = {}
    effective_hours = {}
    base_profit = {}

    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: Equipment_Code, I, II, III, Effective_Monthly_Equipment_Hours
        products = header[1:-1]  # ['I', 'II', 'III']

        for row in reader:
            if row[0].startswith('Unit_Product_Profit'):
                for j, prod in enumerate(products):
                    base_profit[prod] = float(row[j + 1])
            else:
                equip = row[0].strip()
                equipment_names.append(equip)
                effective_hours[equip] = float(row[-1])
                for j, prod in enumerate(products):
                    processing_times[(equip, prod)] = float(row[j + 1])

    return products, equipment_names, processing_times, effective_hours, base_profit

def main():
    # Determine data directory relative to this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')

    # Load data
    params = load_general_parameters(data_dir)
    products, equipment_names, processing_times, effective_hours, base_profit = load_table_1(data_dir)

    overtime_hours_cap = params['overtime_hours_cap']
    overtime_cost_multiplier = params['overtime_cost_multiplier']
    min_prod = {
        'I': params['min_prod_I'],
        'II': params['min_prod_II'],
        'III': params['min_prod_III']
    }

    # Regular cost = base profit, overtime cost = multiplier * base profit
    regular_cost = {p: base_profit[p] for p in products}
    overtime_cost = {p: overtime_cost_multiplier * base_profit[p] for p in products}

    # Create model
    model = gp.Model("Factory_Production_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables: regular and overtime production for each product
    x_reg = model.addVars(products, lb=0, name="x_reg")
    x_ot = model.addVars(products, lb=0, name="x_ot")

    # Objective: minimize total cost
    total_cost = gp.quicksum(regular_cost[p] * x_reg[p] + overtime_cost[p] * x_ot[p] for p in products)
    model.setObjective(total_cost, GRB.MINIMIZE)

    # Equipment capacity constraints
    for e in equipment_names:
        model.addConstr(
            gp.quicksum(processing_times[(e, p)] * (x_reg[p] + x_ot[p]) for p in products) <= effective_hours[e],
            name=f"Capacity_{e}"
        )

    # Plant-wide overtime cap: total equipment hours consumed by overtime work
    total_overtime_hours = gp.quicksum(
        processing_times[(e, p)] * x_ot[p] for e in equipment_names for p in products
    )
    model.addConstr(total_overtime_hours <= overtime_hours_cap, name="Overtime_Cap")

    # Minimum production commitments
    for p in products:
        model.addConstr(x_reg[p] + x_ot[p] >= min_prod[p], name=f"Min_Prod_{p}")

    # Solve
    model.optimize()

    # Output result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of infeasibility or other issues, print something
        print(f"FINAL_OBJ_VALUE: {model.objVal if model.status == GRB.OPTIMAL else 'N/A'}")

if __name__ == "__main__":
    main()
