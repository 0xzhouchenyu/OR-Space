import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def solve():
    # Load data
    table_path = get_data_path("table_3_3.csv")
    params_path = get_data_path("general_parameters.csv")
    
    df = pd.read_csv(table_path)
    params_df = pd.read_csv(params_path)
    
    # Extract parameters
    sales_goal = float(params_df.loc[params_df['Parameter_Name'] == 'monthly_sales_goal', 'Value'].values[0])
    ratio = float(params_df.loc[params_df['Parameter_Name'] == 'pt_ft_overtime_ratio', 'Value'].values[0])
    
    # Extract clerk data
    ft_row = df[df['Role'] == 'Full-time'].iloc[0]
    pt_row = df[df['Role'] == 'Part-time'].iloc[0]
    
    # Determine number of clerks (default to classic textbook values if not in CSV)
    num_ft = 5
    num_pt = 4
    for col in df.columns:
        col_lower = col.lower()
        if any(kw in col_lower for kw in ['num', 'clerks', 'employees', 'count', '人员', '数量']):
            num_ft = float(ft_row[col])
            num_pt = float(pt_row[col])
            break
    
    # Normal sales from full employment
    ft_hours = ft_row['Monthly_Working_Hours']
    pt_hours = pt_row['Monthly_Working_Hours']
    ft_sales_rate = ft_row['Sales_Volume_Pairs_Per_Hour']
    pt_sales_rate = pt_row['Sales_Volume_Pairs_Per_Hour']
    
    normal_sales_ft = num_ft * ft_hours * ft_sales_rate
    normal_sales_pt = num_pt * pt_hours * pt_sales_rate
    total_normal_sales = normal_sales_ft + normal_sales_pt
    
    # Create model
    model = gp.Model("Minimize_Overtime")
    model.setParam('OutputFlag', 0)
    
    # Variables: overtime hours
    y_ft = model.addVar(lb=0, name="y_ft")
    y_pt = model.addVar(lb=0, name="y_pt")
    
    # Objective: minimize total overtime hours
    model.setObjective(y_ft + y_pt, GRB.MINIMIZE)
    
    # Constraint: achieve monthly sales goal
    model.addConstr(
        y_ft * ft_sales_rate + y_pt * pt_sales_rate >= sales_goal - total_normal_sales,
        name="SalesGoal"
    )
    
    # New constraint: part-time overtime >= ratio * full-time overtime
    model.addConstr(
        y_pt >= ratio * y_ft,
        name="CoverageRatio"
    )
    
    # Solve
    model.optimize()
    
    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 4)}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == '__main__':
    solve()
