import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read table_1.csv for mode-dependent costs
    costs = {}
    children = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row["Child"].strip()
            children.append(child)
            costs[child] = {
                "budget": float(row["Cost_budget"]),
                "balanced": float(row["Cost_balanced"]),
                "premium": float(row["Cost_premium"])
            }
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    
    # Extract parameters
    max_children = int(params["max_children"])
    min_children = int(params["min_children"])
    fairness_penalty = float(params["fairness_penalty"])
    max_total_cost = float(params["max_total_cost"])
    min_children_per_mode = int(params["min_children_per_mode"])
    
    # Compatibility flags (1 means active)
    harry_no_fred = int(params.get("harry_no_fred", 0))
    harry_no_george = int(params.get("harry_no_george", 0))
    george_requires_fred = int(params.get("george_requires_fred", 0))
    george_requires_hermione = int(params.get("george_requires_hermione", 0))
    
    modes = ["budget", "balanced", "premium"]
    M = 2000  # big-M, larger than any child cost
    
    # Create model
    model = gp.Model("ZhangFamilyTrip")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    x = {child: model.addVar(vtype=GRB.BINARY, name=f"x_{child}") for child in children}
    y = {mode: model.addVar(vtype=GRB.BINARY, name=f"y_{mode}") for mode in modes}
    z = {(child, mode): model.addVar(vtype=GRB.BINARY, name=f"z_{child}_{mode}") for child in children for mode in modes}
    c = {child: model.addVar(lb=0, name=f"c_{child}") for child in children}
    max_cost = model.addVar(lb=0, name="max_cost")
    min_cost = model.addVar(lb=0, name="min_cost")
    
    # Exactly one pace mode
    model.addConstr(gp.quicksum(y[mode] for mode in modes) == 1, "one_mode")
    
    # Link z, x, y
    for child in children:
        model.addConstr(gp.quicksum(z[child, mode] for mode in modes) == x[child], f"sum_z_{child}")
        for mode in modes:
            model.addConstr(z[child, mode] <= y[mode], f"z_le_y_{child}_{mode}")
            model.addConstr(z[child, mode] <= x[child], f"z_le_x_{child}_{mode}")
            model.addConstr(z[child, mode] >= x[child] + y[mode] - 1, f"z_ge_x_y_{child}_{mode}")
    
    # Child cost under selected mode
    for child in children:
        model.addConstr(c[child] == gp.quicksum(costs[child][mode] * z[child, mode] for mode in modes), f"cost_def_{child}")
    
    # Total actual spend
    total_cost = gp.quicksum(c[child] for child in children)
    model.addConstr(total_cost <= max_total_cost, "max_total_cost")
    
    # Max and min cost among selected children
    for child in children:
        model.addConstr(max_cost >= c[child], f"max_ge_{child}")
        model.addConstr(min_cost <= c[child] + M * (1 - x[child]), f"min_le_{child}")
    
    # Group size limits
    model.addConstr(gp.quicksum(x[child] for child in children) >= min_children, "min_children")
    model.addConstr(gp.quicksum(x[child] for child in children) <= max_children, "max_children")
    
    # Higher mode requires larger group if min_children_per_mode > min_children
    if min_children_per_mode > min_children:
        model.addConstr(
            gp.quicksum(x[child] for child in children) >= 
            min_children + (min_children_per_mode - min_children) * (y["balanced"] + y["premium"]),
            "mode_min_children"
        )
    # else no extra constraint needed (both equal 3)
    
    # Ginny mandatory
    model.addConstr(x["Ginny"] == 1, "Ginny_must_go")
    
    # Compatibility constraints
    if harry_no_fred:
        model.addConstr(x["Harry"] + x["Fred"] <= 1, "Harry_no_Fred")
    if harry_no_george:
        model.addConstr(x["Harry"] + x["George"] <= 1, "Harry_no_George")
    if george_requires_fred:
        model.addConstr(x["George"] <= x["Fred"], "George_requires_Fred")
    if george_requires_hermione:
        model.addConstr(x["George"] <= x["Hermione"], "George_requires_Hermione")
    
    # Objective: total actual spend + fairness penalty * (max - min)
    obj = total_cost + fairness_penalty * (max_cost - min_cost)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of infeasibility or other issues, print a default
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
