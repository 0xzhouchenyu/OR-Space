import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Path to data file
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    # Read bandwidth table
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        bandwidth = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                if bw > 0:
                    bandwidth[(row_node, col_node)] = bw
    
    # Create model
    m = gp.Model()
    m.setParam('OutputFlag', 0)
    
    # Binary variables for each directed edge with positive bandwidth
    x = m.addVars(bandwidth.keys(), vtype=GRB.BINARY, name='x')
    
    # Node potential variables for MTZ subtour elimination
    u = m.addVars(nodes, vtype=GRB.INTEGER, lb=1, ub=len(nodes), name='u')
    
    # Objective: minimize total routing cost = sum(100 - bandwidth) * x_ij
    cost_expr = sum((100 - bw) * x[i, j] for (i, j), bw in bandwidth.items())
    m.setObjective(cost_expr, GRB.MINIMIZE)
    
    # Source node A: out-degree = 1, in-degree = 0
    m.addConstr(sum(x['A', j] for j in nodes if ('A', j) in bandwidth) == 1, name='A_out')
    m.addConstr(sum(x[i, 'A'] for i in nodes if (i, 'A') in bandwidth) == 0, name='A_in')
    
    # Sink node E: in-degree = 1, out-degree = 0
    m.addConstr(sum(x[i, 'E'] for i in nodes if (i, 'E') in bandwidth) == 1, name='E_in')
    m.addConstr(sum(x['E', j] for j in nodes if ('E', j) in bandwidth) == 0, name='E_out')
    
    # Service node C must be visited exactly once (in and out)
    m.addConstr(sum(x[i, 'C'] for i in nodes if (i, 'C') in bandwidth) == 1, name='C_in')
    m.addConstr(sum(x['C', j] for j in nodes if ('C', j) in bandwidth) == 1, name='C_out')
    
    # Flow conservation for other nodes (B, D)
    other_nodes = [n for n in nodes if n not in ['A', 'E', 'C']]
    for n in other_nodes:
        in_edges = [i for i in nodes if (i, n) in bandwidth]
        out_edges = [j for j in nodes if (n, j) in bandwidth]
        m.addConstr(sum(x[i, n] for i in in_edges) == sum(x[n, j] for j in out_edges),
                    name=f'flow_{n}')
        # Optional: limit visits to at most one (redundant with MTZ but safe)
        m.addConstr(sum(x[i, n] for i in in_edges) <= 1, name=f'indegree_{n}')
    
    # MTZ subtour elimination constraints
    M = len(nodes)
    m.addConstr(u['A'] == 1, name='u_A')
    for (i, j) in bandwidth.keys():
        if i != j:
            m.addConstr(u[j] >= u[i] + 1 - M * (1 - x[i, j]), name=f'MTZ_{i}_{j}')
    
    # Solve
    m.optimize()
    
    # Output result
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()
