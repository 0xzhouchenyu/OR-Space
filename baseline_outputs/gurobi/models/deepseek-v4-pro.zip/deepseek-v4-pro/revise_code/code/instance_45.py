import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])

    # Read product segments and profits
    products = []
    segments = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row["Product"]
            if p not in segments:
                segments[p] = []
                products.append(p)
            rng = row["Sales_Volume_Range"]
            profit = float(row["Profit"])
            if rng.startswith("Above_"):
                lower = float(rng.split("_")[1])
                upper = None
            else:
                parts = rng.split("_")
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({"lower": lower, "upper": upper, "profit": profit})

    # Model
    model = gp.Model("Maximize_Profit")
    model.setParam("OutputFlag", 0)

    M = 10000  # Big M

    # Variables
    x = {}      # production quantity per product
    p_var = {}  # profit contribution per product
    y = {}      # binary segment indicators

    for prod in products:
        pname = prod.split("_")[1]  # A, B, C
        x[prod] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{pname}")
        p_var[prod] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"p_{pname}")
        y[prod] = []
        for i in range(len(segments[prod])):
            yi = model.addVar(vtype=GRB.BINARY, name=f"y_{pname}_{i}")
            y[prod].append(yi)

    # Overtime and second review variables
    overtime = model.addVar(lb=0, ub=params["overtime_cap_hours"], vtype=GRB.CONTINUOUS, name="overtime")
    z = model.addVar(vtype=GRB.BINARY, name="z_second_review")

    # Constraints
    # Segment mutual exclusivity and bounds
    for prod in products:
        segs = segments[prod]
        model.addConstr(gp.quicksum(y[prod]) <= 1, name=f"seg_excl_{prod}")

        for i, seg in enumerate(segs):
            lo = seg["lower"]
            hi = seg["upper"]
            profit = seg["profit"]

            # Lower bound: if lo == 0 then x >= 1 (since 0 means no production, handled by no segment)
            if lo == 0:
                model.addConstr(x[prod] >= 1 - M * (1 - y[prod][i]), name=f"lb_{prod}_{i}")
            else:
                model.addConstr(x[prod] >= (lo + 1) - M * (1 - y[prod][i]), name=f"lb_{prod}_{i}")

            # Upper bound (if not the last open segment)
            if hi is not None:
                model.addConstr(x[prod] <= hi + M * (1 - y[prod][i]), name=f"ub_{prod}_{i}")

            # Profit bound (maximization will push to this bound)
            model.addConstr(p_var[prod] <= profit * x[prod] + M * (1 - y[prod][i]), name=f"profit_{prod}_{i}")

        # If no segment active, force x=0 and profit=0
        model.addConstr(x[prod] <= M * gp.quicksum(y[prod]), name=f"force_x_zero_{prod}")
        model.addConstr(p_var[prod] <= M * gp.quicksum(y[prod]), name=f"force_p_zero_{prod}")

    # Resource constraints
    # Technical preparation time
    model.addConstr(
        gp.quicksum(params[f"technical_prep_time_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params["available_technical_prep_time"],
        name="tech_prep"
    )

    # Materials
    model.addConstr(
        gp.quicksum(params[f"materials_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params["available_materials"],
        name="materials"
    )

    # Packaging
    model.addConstr(
        gp.quicksum(params[f"pack_units_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params["packaging_cap_units"],
        name="packaging"
    )

    # Labor: regular + overtime
    total_labor = gp.quicksum(params[f"labor_time_{prod.split('_')[1]}"] * x[prod] for prod in products)
    model.addConstr(total_labor <= params["available_labor_time"] + params["overtime_cap_hours"], name="labor_total")
    model.addConstr(overtime >= total_labor - params["available_labor_time"], name="overtime_def")
    # overtime upper bound already set in variable definition

    # Second review tier: if overtime > 100, z = 1, fee = 10
    threshold = params["overtime_second_review_threshold"]
    fee = params["overtime_second_review_fee"]
    # overtime <= threshold + (overtime_cap_hours - threshold) * z
    model.addConstr(overtime <= threshold + (params["overtime_cap_hours"] - threshold) * z, name="review_z_ub")
    # If overtime > threshold, force z = 1
    epsilon = 1e-4
    model.addConstr(overtime >= threshold + epsilon - params["overtime_cap_hours"] * (1 - z), name="review_z_lb")

    # Objective: maximize total segment profit - overtime cost - second review fee
    obj = gp.quicksum(p_var[prod] for prod in products) \
          - params["overtime_cost_per_hour"] * overtime \
          - fee * z

    model.setObjective(obj, GRB.MAXIMIZE)

    # Solve
    model.optimize()

    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
