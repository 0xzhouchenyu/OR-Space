import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    # Script is executed from the workspace root directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    filepath = os.path.join(data_dir, "general_parameters.csv")
    
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            # Convert to number if possible
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass
            params[name] = value
    return params

def solve():
    params = load_parameters()
    
    # Extract parameters
    profit_robot = params['profit_per_robot']
    profit_car = params['profit_per_model_car']
    profit_blocks = params['profit_per_building_blocks']
    profit_doll = params['profit_per_doll']
    
    plastic_avail = params['plastic_available']
    plastic_robot = params['plastic_per_robot']
    plastic_car = params['plastic_per_model_car']
    plastic_blocks = params['plastic_per_building_blocks']
    plastic_doll = params['plastic_per_doll']
    
    elec_avail = params['electronic_components_available']
    elec_robot = params['electronics_per_robot']
    elec_car = params['electronics_per_model_car']
    elec_blocks = params['electronics_per_building_blocks']
    elec_doll = params['electronics_per_doll']
    
    # Big M for logical constraints (safe upper bound)
    M = 10000
    
    # Create model
    model = gp.Model("ToyManufacturing")
    model.setParam('OutputFlag', 0)
    
    # Decision variables (integer)
    x_robot = model.addVar(vtype=GRB.INTEGER, name="robots", lb=0)
    x_car = model.addVar(vtype=GRB.INTEGER, name="model_cars", lb=0)
    x_blocks = model.addVar(vtype=GRB.INTEGER, name="building_blocks", lb=0)
    x_doll = model.addVar(vtype=GRB.INTEGER, name="dolls", lb=0)
    
    # Binary variables for logical conditions
    y_robot = model.addVar(vtype=GRB.BINARY, name="y_robot")
    y_car = model.addVar(vtype=GRB.BINARY, name="y_car")
    y_blocks = model.addVar(vtype=GRB.BINARY, name="y_blocks")
    y_doll = model.addVar(vtype=GRB.BINARY, name="y_doll")
    
    # Objective: maximize profit
    model.setObjective(
        profit_robot * x_robot +
        profit_car * x_car +
        profit_blocks * x_blocks +
        profit_doll * x_doll,
        GRB.MAXIMIZE
    )
    
    # Resource constraints
    model.addConstr(
        plastic_robot * x_robot + plastic_car * x_car +
        plastic_blocks * x_blocks + plastic_doll * x_doll <= plastic_avail,
        "Plastic"
    )
    model.addConstr(
        elec_robot * x_robot + elec_car * x_car +
        elec_blocks * x_blocks + elec_doll * x_doll <= elec_avail,
        "Electronics"
    )
    
    # Link binary variables to production quantities (big-M)
    model.addConstr(x_robot <= M * y_robot, "Link_robot")
    model.addConstr(x_car <= M * y_car, "Link_car")
    model.addConstr(x_blocks <= M * y_blocks, "Link_blocks")
    model.addConstr(x_doll <= M * y_doll, "Link_doll")
    
    # Force binary to 0 when production is 0
    model.addConstr(y_robot <= x_robot, "Binary_Link_Robot")
    model.addConstr(y_car <= x_car, "Binary_Link_Car")
    model.addConstr(y_blocks <= x_blocks, "Binary_Link_Blocks")
    model.addConstr(y_doll <= x_doll, "Binary_Link_Doll")
    
    # Original business rules
    # 1. Robots and dolls exclusion
    model.addConstr(y_robot + y_doll <= 1, "Robot_Doll_Exclusion")
    
    # 2. If model cars are manufactured, building blocks must also be manufactured
    model.addConstr(y_car <= y_blocks, "Car_Blocks_Dependency")
    
    # 3. Dolls cannot exceed model cars
    model.addConstr(x_doll <= x_car, "Dolls_leq_Cars")
    
    # NEW mutual exclusion: model cars and building blocks cannot both be produced
    model.addConstr(y_car + y_blocks <= 1, "Car_Blocks_Mutex")
    
    # Solve
    model.optimize()
    
    # Output final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of infeasibility or other status, print 0 or handle
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    solve()
