import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Read table_1.csv
toys = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            "type": row["Toy_Type"],
            "labor": float(row["Manufacturing_Labor_Hours"]),
            "inspection": float(row["Inspection_Hours"]),
            "profit": float(row["Profit_Per_Unit"])
        })

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

# Extract parameters
labor_reg_p1 = params["available_labor_hours_period1"]
labor_reg_p2 = params["available_labor_hours_period2"]
inspection_p1 = params["available_inspection_hours_period1"]
inspection_p2 = params["available_inspection_hours_period2"]

demand = {
    ("High-End", 1): params["max_demand_high_end_period1"],
    ("Mid-Range", 1): params["max_demand_mid_range_period1"],
    ("Low-End", 1): params["max_demand_low_end_period1"],
    ("High-End", 2): params["max_demand_high_end_period2"],
    ("Mid-Range", 2): params["max_demand_mid_range_period2"],
    ("Low-End", 2): params["max_demand_low_end_period2"],
}

overtime_cap = params["overtime_labor_cap"]
overtime_cost_per_hour = params["overtime_labor_cost"]
fatigue_threshold = params["period1_overtime_fatigue_threshold"]
recovery_loss = params["period2_labor_recovery_loss"]
review_threshold = params["overtime_review_threshold"]
review_fee = params["seasonal_safety_review_fee"]

# Model
m = gp.Model("ToyProductionTwoPeriod")
m.setParam("OutputFlag", 0)

# Decision variables: production units per toy per period
x = {}
for toy in toys:
    for p in [1, 2]:
        x[toy["type"], p] = m.addVar(lb=0, name=f"x_{toy['type']}_p{p}")

# Overtime hours per period
overtime1 = m.addVar(lb=0, name="overtime1")
overtime2 = m.addVar(lb=0, name="overtime2")

# Binary variables for conditional constraints
y_fatigue = m.addVar(vtype=GRB.BINARY, name="fatigue_trigger")
z_review = m.addVar(vtype=GRB.BINARY, name="review_trigger")

# Objective: profit minus overtime cost minus possible review fee
profit_expr = gp.quicksum(toy["profit"] * x[toy["type"], p] for toy in toys for p in [1, 2])
overtime_cost = overtime_cost_per_hour * (overtime1 + overtime2)
review_cost = review_fee * z_review
m.setObjective(profit_expr - overtime_cost - review_cost, GRB.MAXIMIZE)

# Constraints

# Labor hours per period
# Period 1: regular labor + overtime1
m.addConstr(
    gp.quicksum(toy["labor"] * x[toy["type"], 1] for toy in toys) <= labor_reg_p1 + overtime1,
    "labor_p1"
)

# Period 2: regular labor (possibly reduced) + overtime2
# labor_reg_p2_effective = labor_reg_p2 - recovery_loss * y_fatigue
m.addConstr(
    gp.quicksum(toy["labor"] * x[toy["type"], 2] for toy in toys) <= labor_reg_p2 - recovery_loss * y_fatigue + overtime2,
    "labor_p2"
)

# Inspection hours per period
m.addConstr(
    gp.quicksum(toy["inspection"] * x[toy["type"], 1] for toy in toys) <= inspection_p1,
    "inspection_p1"
)
m.addConstr(
    gp.quicksum(toy["inspection"] * x[toy["type"], 2] for toy in toys) <= inspection_p2,
    "inspection_p2"
)

# Demand constraints
for toy in toys:
    for p in [1, 2]:
        m.addConstr(x[toy["type"], p] <= demand[toy["type"], p], f"demand_{toy['type']}_p{p}")

# Total overtime cap
m.addConstr(overtime1 + overtime2 <= overtime_cap, "overtime_cap")

# Fatigue carryover: if overtime1 > fatigue_threshold, then y_fatigue = 1
# Use indicator constraints with a small tolerance
eps = 1e-4
m.addGenConstrIndicator(y_fatigue, True, overtime1 >= fatigue_threshold + eps)
m.addGenConstrIndicator(y_fatigue, False, overtime1 <= fatigue_threshold)

# Safety review: if total overtime > review_threshold, then z_review = 1
total_overtime = overtime1 + overtime2
m.addGenConstrIndicator(z_review, True, total_overtime >= review_threshold + eps)
m.addGenConstrIndicator(z_review, False, total_overtime <= review_threshold)

# Solve
m.optimize()

# Output
if m.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {m.objVal}")
else:
    print("No optimal solution found.")
