import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_processing_times(filepath):
    """Load processing times from CSV file.
    Returns a list of lists: processing_times[i][j] = time for product i on machine j.
    """
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # Skip header
        for row in reader:
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times

def load_general_parameters(filepath):
    """Load general parameters from CSV file.
    Returns a dictionary of parameter_name -> value.
    """
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            name = row[0]
            value = row[1]
            # Try to convert to float if possible
            try:
                value = float(value)
            except ValueError:
                pass
            params[name] = value
    return params

def main():
    # Paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table1_path = os.path.join(data_dir, "table_1.csv")
    general_path = os.path.join(data_dir, "general_parameters.csv")
    
    # Load data
    p = load_processing_times(table1_path)  # p[i][j]
    params = load_general_parameters(general_path)
    
    n = len(p)          # number of products
    m = len(p[0])       # number of machines
    
    # Parameters from general_parameters.csv
    W = [params['time_window_1'], params['time_window_2'], params['time_window_3']]
    Omax = [params['overtime_window_1'], params['overtime_window_2'], params['overtime_window_3']]
    penalty = params['overtime_penalty_per_unit']
    M1_threshold = params['machine1_overtime_review_threshold']
    M1_review_fee = params['machine1_overtime_review_fee']
    BigM = params['M_1']  # Use same big M for all, value 20
    
    # Create model
    model = gp.Model("flow_shop_overtime")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i,p] = 1 if job i is at position p
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")
    
    # PT[p,j] = processing time of job at position p on machine j
    PT = model.addVars(n, m, lb=0, name="PT")
    
    # S[p,j] = start time of job at position p on machine j
    S = model.addVars(n, m, lb=0, name="S")
    
    # C[p,j] = completion time of job at position p on machine j
    C = model.addVars(n, m, lb=0, name="C")
    
    # Busy[j] = total busy time of machine j
    Busy = model.addVars(m, lb=0, name="Busy")
    
    # O[j] = overtime on machine j
    O = model.addVars(m, lb=0, name="O")
    
    # U = overtime on machine 1 beyond the 1-second free allowance
    U = model.addVar(lb=0, name="U")
    
    # z = 1 if O[0] > 1
    z = model.addVar(vtype=GRB.BINARY, name="z")
    
    # Constraints
    
    # Assignment constraints
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, p] for p in range(n)) == 1, name=f"assign_job_{i}")
    for p in range(n):
        model.addConstr(gp.quicksum(x[i, p] for i in range(n)) == 1, name=f"assign_pos_{p}")
    
    # Processing time of job at each position
    for p in range(n):
        for j in range(m):
            model.addConstr(PT[p, j] == gp.quicksum(x[i, p] * p[i][j] for i in range(n)),
                            name=f"PT_{p}_{j}")
    
    # Start and completion times for position 0
    model.addConstr(S[0, 0] == 0, name="start_0_0")
    model.addConstr(C[0, 0] == S[0, 0] + PT[0, 0], name="comp_0_0")
    for j in range(1, m):
        model.addConstr(S[0, j] == C[0, j-1], name=f"start_0_{j}")
        model.addConstr(C[0, j] == S[0, j] + PT[0, j], name=f"comp_0_{j}")
    
    # For positions p > 0
    for p in range(1, n):
        # Machine 0
        model.addConstr(S[p, 0] == C[p-1, 0], name=f"start_{p}_0")
        model.addConstr(C[p, 0] == S[p, 0] + PT[p, 0], name=f"comp_{p}_0")
        # Machines j > 0
        for j in range(1, m):
            # S[p,j] = max(C[p-1,j], C[p,j-1])
            model.addGenConstrMax(S[p, j], [C[p-1, j], C[p, j-1]], name=f"max_start_{p}_{j}")
            model.addConstr(C[p, j] == S[p, j] + PT[p, j], name=f"comp_{p}_{j}")
    
    # Busy time for each machine
    # start_j = S[0,j] (for j=0 it's 0, for j>0 it's C[0,j-1])
    # C_max_j = C[n-1,j]
    for j in range(m):
        model.addConstr(Busy[j] == C[n-1, j] - S[0, j], name=f"busy_{j}")
    
    # Overtime O[j] = max(0, Busy[j] - W[j])
    for j in range(m):
        model.addGenConstrMax(O[j], [0, Busy[j] - W[j]], name=f"overtime_{j}")
        model.addConstr(O[j] <= Omax[j], name=f"max_overtime_{j}")
    
    # Machine 1 special: U = max(0, O[0] - 1)
    model.addGenConstrMax(U, [0, O[0] - M1_threshold], name="U_m1")
    
    # z = 1 if O[0] > 1
    # O[0] <= 1 + BigM * z
    model.addConstr(O[0] <= M1_threshold + BigM * z, name="z_upper")
    # O[0] >= 1 + epsilon - BigM * (1 - z)
    epsilon = 1e-4
    model.addConstr(O[0] >= M1_threshold + epsilon - BigM * (1 - z), name="z_lower")
    
    # Objective: minimize total cost
    cost_expr = (penalty * U +
                 M1_review_fee * z +
                 penalty * O[1] +
                 penalty * O[2])
    model.setObjective(cost_expr, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Check status
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # If infeasible or other, print something
        print(f"FINAL_OBJ_VALUE: {model.status}")

if __name__ == "__main__":
    main()
