import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters from CSV
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
param_file = os.path.join(data_dir, "general_parameters.csv")

params = {}
with open(param_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        val = float(row['Value'].strip())
        params[name] = val

# Extract required parameters
min_A = params['min_raw_material_A']
min_B = params['min_raw_material_B']
min_C = params['min_raw_material_C']

cap_A_a = params['warehouse_A_truck_capacity_A']
cap_A_b = params['warehouse_A_truck_capacity_B']
cap_A_c = params['warehouse_A_truck_capacity_C']
cost_A = params['warehouse_A_truck_cost']

cap_B_a = params['warehouse_B_truck_capacity_A']
cap_B_b = params['warehouse_B_truck_capacity_B']
cap_B_c = params['warehouse_B_truck_capacity_C']
cost_B = params['warehouse_B_truck_cost']

fixed_A = params['warehouse_A_fixed_cost']
fixed_B = params['warehouse_B_fixed_cost']
overflow_threshold = params['warehouse_B_overflow_threshold_trucks']
overflow_cost = params['warehouse_B_overflow_coordination_cost']
recon_fee = params['dual_warehouse_reconciliation_fee']

# Big-M: safe upper bounds for trucks
# From constraints: max x ~ 60, max y ~ 60. Use 1000 as safe big-M.
M = 1000

# Create model
model = gp.Model("MinFreightCost_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, name="trucks_from_A", lb=0)
y = model.addVar(vtype=GRB.INTEGER, name="trucks_from_B", lb=0)

# Binary indicator variables
z_A = model.addVar(vtype=GRB.BINARY, name="use_A")
z_B = model.addVar(vtype=GRB.BINARY, name="use_B")
z_overflow = model.addVar(vtype=GRB.BINARY, name="overflow_B")
z_both = model.addVar(vtype=GRB.BINARY, name="both_used")

# Constraints: material requirements
model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# Link x and z_A
model.addConstr(x <= M * z_A, "link_x_A")
# Link y and z_B
model.addConstr(y <= M * z_B, "link_y_B")

# Overflow: if y > threshold, z_overflow must be 1
model.addConstr(y - overflow_threshold <= M * z_overflow, "link_overflow")

# Both warehouses used: z_both = 1 iff z_A = 1 and z_B = 1
model.addConstr(z_both >= z_A + z_B - 1, "both_lower")
model.addConstr(z_both <= z_A, "both_upper_A")
model.addConstr(z_both <= z_B, "both_upper_B")

# Objective: minimize total cost
total_cost = (cost_A * x + cost_B * y +
              fixed_A * z_A + fixed_B * z_B +
              overflow_cost * z_overflow +
              recon_fee * z_both)
model.setObjective(total_cost, GRB.MINIMIZE)

# Solve
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of infeasibility or other issues, print a fallback
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
