import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_general_parameters

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
sell_price_table = params['sell_price_table']
sell_price_chair = params['sell_price_chair']
sell_price_bookshelf = params['sell_price_bookshelf']

cost_table = params['manufacturing_cost_table']
cost_chair = params['manufacturing_cost_chair']
cost_bookshelf = params['manufacturing_cost_bookshelf']

space_table = params['warehouse_space_table']
space_chair = params['warehouse_space_chair']
space_bookshelf = params['warehouse_space_bookshelf']

max_warehouse = params['max_warehouse_space']
min_tables = params['min_tables']
min_bookshelves = params['min_bookshelves']
max_total = params['max_total_items']

labor_table = params['labor_hours_table']
labor_chair = params['labor_hours_chair']
labor_bookshelf = params['labor_hours_bookshelf']

max_labor_regular = params['max_labor_hours_month_regular']
max_labor_rush = params['max_labor_hours_month_rush']
max_rush_items = params['max_rush_items_month']

bonus_table = params['rush_profit_bonus_table']
bonus_chair = params['rush_profit_bonus_chair']
bonus_bookshelf = params['rush_profit_bonus_bookshelf']

# Base profit per item
profit_table = sell_price_table - cost_table          # 80
profit_chair = sell_price_chair - cost_chair          # 30
profit_bookshelf = sell_price_bookshelf - cost_bookshelf  # 60

# Create model
model = gp.Model("Furniture_Production_Revised")
model.setParam('OutputFlag', 0)

# Decision variables: regular and rush quantities for each product
reg_tables = model.addVar(vtype=GRB.INTEGER, name="reg_tables")
reg_chairs = model.addVar(vtype=GRB.INTEGER, name="reg_chairs")
reg_bookshelves = model.addVar(vtype=GRB.INTEGER, name="reg_bookshelves")

rush_tables = model.addVar(vtype=GRB.INTEGER, name="rush_tables")
rush_chairs = model.addVar(vtype=GRB.INTEGER, name="rush_chairs")
rush_bookshelves = model.addVar(vtype=GRB.INTEGER, name="rush_bookshelves")

# Objective: maximize total profit (base profit on all units + rush bonus on rush units)
model.setObjective(
    profit_table * (reg_tables + rush_tables) +
    profit_chair * (reg_chairs + rush_chairs) +
    profit_bookshelf * (reg_bookshelves + rush_bookshelves) +
    bonus_table * rush_tables +
    bonus_chair * rush_chairs +
    bonus_bookshelf * rush_bookshelves,
    GRB.MAXIMIZE
)

# Constraints

# 1. Warehouse space (all units share the same space)
model.addConstr(
    space_table * (reg_tables + rush_tables) +
    space_chair * (reg_chairs + rush_chairs) +
    space_bookshelf * (reg_bookshelves + rush_bookshelves) <= max_warehouse,
    "Warehouse_Space"
)

# 2. Minimum production requirements (total across regular and rush)
model.addConstr(reg_tables + rush_tables >= min_tables, "Min_Tables")
model.addConstr(reg_bookshelves + rush_bookshelves >= min_bookshelves, "Min_Bookshelves")

# 3. Maximum total items (all units)
model.addConstr(
    reg_tables + rush_tables + reg_chairs + rush_chairs + reg_bookshelves + rush_bookshelves <= max_total,
    "Max_Total_Items"
)

# 4. Labor hours: regular labor for regular units, rush labor for rush units
model.addConstr(
    labor_table * reg_tables + labor_chair * reg_chairs + labor_bookshelf * reg_bookshelves <= max_labor_regular,
    "Regular_Labor"
)
model.addConstr(
    labor_table * rush_tables + labor_chair * rush_chairs + labor_bookshelf * rush_bookshelves <= max_labor_rush,
    "Rush_Labor"
)

# 5. Rush capacity: total rush items
model.addConstr(
    rush_tables + rush_chairs + rush_bookshelves <= max_rush_items,
    "Max_Rush_Items"
)

# Solve
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
