import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    budget = params['company_budget']
    max_employees = int(params['max_employees'])
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_gj = int(params['max_one_candidate_g_j'])
    lead_premium = params['lead_premium']
    min_leads = int(params['min_leads'])
    mentor_bonus = params['mentor_bonus']
    max_pairs = int(params['max_pairs'])
    
    # Create model
    m = gp.Model("HiringOptimization")
    m.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}   # hire
    L = {}   # lead
    E = {}   # engineer
    for c in candidates:
        name = c['name']
        x[name] = m.addVar(vtype=GRB.BINARY, name=f"x_{name}")
        L[name] = m.addVar(vtype=GRB.BINARY, name=f"L_{name}")
        E[name] = m.addVar(vtype=GRB.BINARY, name=f"E_{name}")
    
    # Role assignment: each hired candidate gets exactly one role
    for c in candidates:
        name = c['name']
        m.addConstr(L[name] + E[name] == x[name], name=f"role_{name}")
    
    # Mentorship pair variables p[i,j] = L[i] * E[j]
    p = {}
    for c1 in candidates:
        for c2 in candidates:
            p[c1['name'], c2['name']] = m.addVar(vtype=GRB.BINARY, name=f"p_{c1['name']}_{c2['name']}")
            # Linearization constraints
            m.addConstr(p[c1['name'], c2['name']] <= L[c1['name']], name=f"p_le_{c1['name']}_{c2['name']}")
            m.addConstr(p[c1['name'], c2['name']] <= E[c2['name']], name=f"p_ee_{c1['name']}_{c2['name']}")
            m.addConstr(p[c1['name'], c2['name']] >= L[c1['name']] + E[c2['name']] - 1, name=f"p_lb_{c1['name']}_{c2['name']}")
    
    # Total mentorship pairs variable
    P = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_pairs, name="P")
    total_pairs = gp.quicksum(p[c1['name'], c2['name']] for c1 in candidates for c2 in candidates)
    m.addConstr(P <= total_pairs, name="P_limit")
    
    # Objective: minimize net cost = base salaries + lead premiums - mentorship bonus
    base_salary_cost = gp.quicksum(c['salary'] * x[c['name']] for c in candidates)
    lead_cost = lead_premium * gp.quicksum(L[c['name']] for c in candidates)
    mentorship_credit = mentor_bonus * P
    net_cost = base_salary_cost + lead_cost - mentorship_credit
    m.setObjective(net_cost, GRB.MINIMIZE)
    
    # Budget constraint (net cost)
    m.addConstr(net_cost <= budget, name="Budget")
    
    # Max employees
    m.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, name="MaxEmployees")
    
    # Min skill level
    m.addConstr(gp.quicksum(c['skill'] * x[c['name']] for c in candidates) >= min_skill, name="MinSkill")
    
    # Min project management experience
    m.addConstr(gp.quicksum(c['pm_exp'] * x[c['name']] for c in candidates) >= min_pm_exp, name="MinPMExp")
    
    # At most one of G and J
    m.addConstr(x['G'] + x['J'] <= max_gj, name="MaxOneGJ")
    
    # Minimum number of leads
    m.addConstr(gp.quicksum(L[c['name']] for c in candidates) >= min_leads, name="MinLeads")
    
    # Solve
    m.optimize()
    
    # Output
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        # In case of infeasibility or other, still print something
        print(f"FINAL_OBJ_VALUE: {m.objVal if m.status == GRB.OPTIMAL else 'N/A'}")

if __name__ == "__main__":
    main()
