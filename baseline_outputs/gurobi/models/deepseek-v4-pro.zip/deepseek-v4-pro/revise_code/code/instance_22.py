import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load general parameters
    gp_df = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    prod_days = float(gp_df[gp_df['Parameter_Name'] == 'production_days']['Value'].iloc[0])
    a1_watch_threshold = float(gp_df[gp_df['Parameter_Name'] == 'a1_watch_threshold']['Value'].iloc[0])
    a1_deep_service_threshold = float(gp_df[gp_df['Parameter_Name'] == 'a1_deep_service_threshold']['Value'].iloc[0])
    maint_penalty_watch = float(gp_df[gp_df['Parameter_Name'] == 'maintenance_penalty_watch']['Value'].iloc[0])
    maint_penalty_deep = float(gp_df[gp_df['Parameter_Name'] == 'maintenance_penalty_deep']['Value'].iloc[0])
    a1_quality_release_fee = float(gp_df[gp_df['Parameter_Name'] == 'a1_quality_release_fee']['Value'].iloc[0])
    a1_deep_service_fee = float(gp_df[gp_df['Parameter_Name'] == 'a1_deep_service_fee']['Value'].iloc[0])
    a1_priority_price_lift = float(gp_df[gp_df['Parameter_Name'] == 'a1_priority_price_lift']['Value'].iloc[0])
    
    # Load product data
    t1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    t2 = pd.read_csv(os.path.join(data_dir, "table_2.csv"))
    t3 = pd.read_csv(os.path.join(data_dir, "table_3.csv"))
    df = t1.merge(t2, on='Product').merge(t3, on='Product')
    
    # Model
    m = gp.Model("Production_Planning_Revised")
    m.setParam('OutputFlag', 0)
    
    products = df['Product'].tolist()
    a1 = 'A1'
    
    # Variables
    x = m.addVars(products, lb=0, name="x")
    y = m.addVars(products, vtype=GRB.BINARY, name="y")
    z1 = m.addVar(vtype=GRB.BINARY, name="z1")   # A1 exceeds watch threshold
    z2 = m.addVar(vtype=GRB.BINARY, name="z2")   # A1 exceeds deep service threshold
    u = m.addVar(lb=0, name="u")                 # A1 units above watch threshold
    
    # Objective
    profit = gp.quicksum(
        (df.loc[df['Product'] == p, 'Selling_Price'].iloc[0] - df.loc[df['Product'] == p, 'Production_Cost'].iloc[0]) * x[p]
        - df.loc[df['Product'] == p, 'Activation_Cost'].iloc[0] * y[p]
        for p in products
    )
    profit += a1_priority_price_lift * u
    profit -= a1_quality_release_fee * z1
    profit -= a1_deep_service_fee * z2
    m.setObjective(profit, GRB.MAXIMIZE)
    
    # All products must be produced
    for p in products:
        m.addConstr(y[p] == 1, name=f"produce_{p}")
    
    # Min batch and max demand
    for _, row in df.iterrows():
        p = row['Product']
        m.addConstr(x[p] >= row['Minimum_Batch'] * y[p], name=f"min_batch_{p}")
        m.addConstr(x[p] <= row['Maximum_Demand'] * y[p], name=f"max_demand_{p}")
    
    # A1 threshold logic
    M_big = df.loc[df['Product'] == a1, 'Maximum_Demand'].iloc[0]  # 5300
    M_u = M_big - a1_watch_threshold                               # 2300
    
    # z1 = 1  <=>  x_A1 >= a1_watch_threshold
    m.addConstr(x[a1] <= a1_watch_threshold + (M_big - a1_watch_threshold) * z1, name="A1_watch_upper")
    m.addConstr(x[a1] >= a1_watch_threshold * z1, name="A1_watch_lower")
    
    # z2 = 1  <=>  x_A1 >= a1_deep_service_threshold
    m.addConstr(x[a1] <= a1_deep_service_threshold + (M_big - a1_deep_service_threshold) * z2, name="A1_deep_upper")
    m.addConstr(x[a1] >= a1_deep_service_threshold * z2, name="A1_deep_lower")
    
    # z2 implies z1
    m.addConstr(z2 <= z1, name="z2_implies_z1")
    
    # u = max(0, x_A1 - a1_watch_threshold)  (active only when z1=1)
    m.addConstr(u >= x[a1] - a1_watch_threshold, name="u_ge_excess")
    m.addConstr(u <= x[a1] - a1_watch_threshold + M_u * (1 - z1), name="u_le_excess_when_z1")
    m.addConstr(u <= M_u * z1, name="u_zero_when_not_z1")
    
    # Production days constraint (lost days for maintenance penalties)
    m.addConstr(
        gp.quicksum(x[p] / df.loc[df['Product'] == p, 'Production_Quota'].iloc[0] for p in products)
        + maint_penalty_watch * z1
        + maint_penalty_deep * z2
        <= prod_days,
        name="production_days"
    )
    
    # Solve
    m.optimize()
    
    # Output
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        # Fallback in case of non-optimal status
        print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    main()
