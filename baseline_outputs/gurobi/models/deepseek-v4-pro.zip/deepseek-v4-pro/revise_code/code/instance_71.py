import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base, 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    
    n = int(params.get('n', 2))
    premium_cost_multiplier = float(params.get('premium_cost_multiplier', 1.5))
    min_premium_share = float(params.get('min_premium_share', 0.4))
    
    # Read table_1.csv
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    # If n is not provided or mismatched, use number of rows
    if n != len(rows):
        n = len(rows)
    
    # Parse d_ij and c_pq
    # d[i][j] = volume from factory i to location j
    # c[p][j] = unit cost from location p to location j
    d = []
    c = []
    for i, row in enumerate(rows):
        d_row = []
        c_row = []
        for j in range(n):
            d_row.append(float(row[f'Transportation_volume_to_Location_{j+1}']))
            c_row.append(float(row[f'Transportation_cost_to_Location_{j+1}']))
        d.append(d_row)
        c.append(c_row)
    
    # Compute outbound volumes
    outbound = [sum(d[i]) for i in range(n)]
    
    # Compute c_std and c_prem for each factory i and location p
    c_std = [[0.0]*n for _ in range(n)]
    c_prem = [[0.0]*n for _ in range(n)]
    for i in range(n):
        for p in range(n):
            if outbound[i] > 0:
                # c_std_ip = (sum_j d_ij * c_pj) / outbound_i
                cost_sum = sum(d[i][j] * c[p][j] for j in range(n))
                c_std[i][p] = cost_sum / outbound[i]
            else:
                c_std[i][p] = 0.0
            c_prem[i][p] = premium_cost_multiplier * c_std[i][p]
    
    # Build MIP model
    model = gp.Model('factory_assignment')
    model.setParam('OutputFlag', 0)
    
    # Sets
    factories = range(n)
    locations = range(n)
    
    # Variables
    x = model.addVars(factories, locations, vtype=GRB.BINARY, name='x')
    y = model.addVars(factories, locations, vtype=GRB.BINARY, name='y')
    v_std = model.addVars(factories, locations, lb=0.0, name='v_std')
    v_prem = model.addVars(factories, locations, lb=0.0, name='v_prem')
    
    # Constraints
    # Each factory assigned to exactly one location
    for i in factories:
        model.addConstr(gp.quicksum(x[i, p] for p in locations) == 1, name=f'assign_factory_{i}')
    
    # Each location gets at most one factory
    for p in locations:
        model.addConstr(gp.quicksum(x[i, p] for i in factories) <= 1, name=f'assign_location_{p}')
    
    # Volume balance: total volume equals outbound if assigned
    for i in factories:
        for p in locations:
            model.addConstr(v_std[i, p] + v_prem[i, p] == outbound[i] * x[i, p],
                            name=f'volume_balance_{i}_{p}')
    
    # Premium volume can only exist if premium mode selected
    for i in factories:
        for p in locations:
            model.addConstr(v_prem[i, p] <= outbound[i] * y[i, p],
                            name=f'prem_ub_{i}_{p}')
    
    # Minimum premium share if premium selected
    for i in factories:
        for p in locations:
            model.addConstr(v_prem[i, p] >= min_premium_share * outbound[i] * y[i, p],
                            name=f'prem_lb_{i}_{p}')
    
    # Premium mode only if assigned
    for i in factories:
        for p in locations:
            model.addConstr(y[i, p] <= x[i, p], name=f'prem_if_assigned_{i}_{p}')
    
    # Objective: minimize total handling + transportation cost
    obj = gp.quicksum(c_std[i][p] * v_std[i, p] + c_prem[i][p] * v_prem[i, p]
                      for i in factories for p in locations)
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Model did not solve to optimality. Status:", model.status)

if __name__ == '__main__':
    main()
