import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Ensure src is in path to import utils
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'src'))
from utils import load_general_parameters

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
shirts_inv = params['shirts_inventory']
pants_inv = params['pants_inventory']
price_a = params['package_a_price']
price_b = params['package_b_price']
price_c = params['package_c_price']
shirts_a = params['package_a_shirts']
pants_a = params['package_a_pants']
shirts_b = params['package_b_shirts']
pants_b = params['package_b_pants']
shirts_c = params['package_c_shirts']
pants_c = params['package_c_pants']
min_a = params['min_campaign_batch_a']
min_b = params['min_campaign_batch_b']
min_c = params['min_campaign_batch_c']
act_a = params['activation_cost_a']
act_b = params['activation_cost_b']
act_c = params['activation_cost_c']
labor_a = params['labor_hours_per_A']
labor_b = params['labor_hours_per_B']
labor_c = params['labor_hours_per_C']
labor_total = params['labor_hours_total']
bigM_a = params['bigM_a']
bigM_b = params['bigM_b']
bigM_c = params['bigM_c']
b_thresh = params['package_b_review_threshold']
b_charge = params['package_b_review_charge']
c_thresh = params['package_c_review_threshold']
c_charge = params['package_c_review_charge']

# Create model
m = gp.Model("Maximize_Profit")
m.setParam('OutputFlag', 0)

# Decision variables
x_a = m.addVar(vtype=GRB.INTEGER, name="Package_A", lb=0)
x_b = m.addVar(vtype=GRB.INTEGER, name="Package_B", lb=0)
x_c = m.addVar(vtype=GRB.INTEGER, name="Package_C", lb=0)

y_a = m.addVar(vtype=GRB.BINARY, name="Launch_A")
y_b = m.addVar(vtype=GRB.BINARY, name="Launch_B")
y_c = m.addVar(vtype=GRB.BINARY, name="Launch_C")

z_b = m.addVar(vtype=GRB.BINARY, name="Review_B")
z_c = m.addVar(vtype=GRB.BINARY, name="Review_C")

# Objective: maximize revenue - activation costs - review charges
m.setObjective(
    price_a * x_a + price_b * x_b + price_c * x_c
    - act_a * y_a - act_b * y_b - act_c * y_c
    - b_charge * z_b - c_charge * z_c,
    GRB.MAXIMIZE
)

# Inventory constraints
m.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inv, "Shirts_Inv")
m.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inv, "Pants_Inv")

# Labor constraint
m.addConstr(labor_a * x_a + labor_b * x_b + labor_c * x_c <= labor_total, "Labor")

# Campaign activation: if launched, must meet minimum batch; else zero
m.addConstr(x_a >= min_a * y_a, "MinA")
m.addConstr(x_a <= bigM_a * y_a, "BigM_A")
m.addConstr(x_b >= min_b * y_b, "MinB")
m.addConstr(x_b <= bigM_b * y_b, "BigM_B")
m.addConstr(x_c >= min_c * y_c, "MinC")
m.addConstr(x_c <= bigM_c * y_c, "BigM_C")

# Review charge triggers (gate: one-time fee if threshold exceeded)
# Package B: if x_b > 45 then z_b = 1
m.addConstr(x_b <= b_thresh + bigM_b * z_b, "B_Thresh_Upper")
m.addConstr(x_b >= (b_thresh + 1) - bigM_b * (1 - z_b), "B_Thresh_Lower")

# Package C: if x_c > 27 then z_c = 1
m.addConstr(x_c <= c_thresh + bigM_c * z_c, "C_Thresh_Upper")
m.addConstr(x_c >= (c_thresh + 1) - bigM_c * (1 - z_c), "C_Thresh_Lower")

# Solve
m.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {m.objVal}")
