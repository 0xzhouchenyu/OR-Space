import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    table1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    param_dict = dict(zip(params["Parameter_Name"], params["Value"]))
    demand = dict(zip(table1["stage"], table1["tool_requirement"]))
    return param_dict, demand

def solve():
    param_dict, demand = load_data()
    
    n = int(param_dict["n"])
    cost_new = float(param_dict["cost_new_tool"])
    cost_slow = float(param_dict["cost_slow_repair"])
    cost_fast = float(param_dict["cost_fast_repair"])
    dur_slow = int(param_dict["slow_repair_duration"])
    dur_fast = int(param_dict["fast_repair_duration"])
    max_fast = int(param_dict["max_fast_stage"])
    max_slow = int(param_dict["max_slow_stage"])
    emission_buy = float(param_dict["emission_buy"])
    emission_fast = float(param_dict["emission_fast_repair"])
    emission_slow = float(param_dict["emission_slow_repair"])
    carbon_budget = float(param_dict["carbon_budget"])
    penalty_shortage = float(param_dict["penalty_shortage"])
    
    stages = list(range(1, n + 1))
    
    m = gp.Model("ToolRepair")
    m.setParam("OutputFlag", 0)
    
    # Variables
    c = m.addVars(range(0, n + 1), vtype=GRB.INTEGER, name="c", lb=0)
    d = m.addVars(range(0, n + 1), vtype=GRB.INTEGER, name="d", lb=0)
    x = m.addVars(stages, vtype=GRB.INTEGER, name="x", lb=0)
    y = m.addVars(stages, vtype=GRB.INTEGER, name="y", lb=0)
    z = m.addVars(stages, vtype=GRB.INTEGER, name="z", lb=0)
    s = m.addVars(stages, vtype=GRB.INTEGER, name="s", lb=0)
    
    # Initial conditions
    m.addConstr(d[0] == 0, name="init_dirty_zero")
    # c[0] is free (prebuy clean tools)
    
    # Precompute return mappings
    fast_ready = {}
    slow_ready = {}
    for t in stages:
        if t - dur_fast >= 1:
            fast_ready[t] = y[t - dur_fast]
        else:
            fast_ready[t] = 0
        if t - dur_slow >= 1:
            slow_ready[t] = z[t - dur_slow]
        else:
            slow_ready[t] = 0
    
    for t in stages:
        # Clean tool balance
        m.addConstr(
            c[t - 1] + x[t] + fast_ready[t] + slow_ready[t] + s[t] == demand[t] + c[t],
            name=f"clean_balance_{t}"
        )
        # Dirty tool balance
        m.addConstr(
            d[t - 1] + demand[t] == y[t] + z[t] + d[t] + s[t],
            name=f"dirty_balance_{t}"
        )
        # Repair capacity
        m.addConstr(y[t] <= max_fast, name=f"fast_cap_{t}")
        m.addConstr(z[t] <= max_slow, name=f"slow_cap_{t}")
        # Shortage cannot exceed demand
        m.addConstr(s[t] <= demand[t], name=f"shortage_limit_{t}")
    
    # Carbon constraint
    total_buy = c[0] + gp.quicksum(x[t] for t in stages)
    total_fast = gp.quicksum(y[t] for t in stages)
    total_slow = gp.quicksum(z[t] for t in stages)
    m.addConstr(
        emission_buy * total_buy + emission_fast * total_fast + emission_slow * total_slow <= carbon_budget,
        name="carbon_budget"
    )
    
    # Objective
    obj = (cost_new * total_buy +
           cost_fast * total_fast +
           cost_slow * total_slow +
           penalty_shortage * gp.quicksum(s[t] for t in stages))
    m.setObjective(obj, GRB.MINIMIZE)
    
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        # If infeasible or other status, still print something for clarity
        print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    solve()
