import gurobipy as gp
from gurobipy import GRB
import os
import csv

# Paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params['fixed_ordering_cost']
month2_threshold = params['month2_bulk_receiving_threshold']
month2_fee = params['month2_bulk_receiving_fee']

# Load monthly data
months = []
purchasing_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        m = int(row['Month'])
        months.append(m)
        purchasing_prices[m] = float(row['Purchasing_Price_Yuan'])
        selling_prices[m] = float(row['Selling_Price_Yuan'])

# Model
model = gp.Model("Maximize_Profit")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVars(months, lb=0, name="purchase")
s = model.addVars(months, lb=0, name="sell")
inv = model.addVars(months, lb=0, name="inventory")
y = model.addVars(months, vtype=GRB.BINARY, name="order_fixed")
z = model.addVar(vtype=GRB.BINARY, name="bulk_month2")

# Big M: maximum possible purchase in a month is warehouse_capacity
M = warehouse_capacity

# Constraints
for i, m in enumerate(months):
    if m == months[0]:
        prev_inv = initial_stock
    else:
        prev_inv = inv[months[i-1]]
    
    # Inventory balance
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], name=f"inv_balance_{m}")
    
    # Warehouse capacity after purchase
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, name=f"warehouse_after_purchase_{m}")
    
    # End-of-month inventory capacity
    model.addConstr(inv[m] <= warehouse_capacity, name=f"warehouse_end_{m}")
    
    # Sell limit
    model.addConstr(s[m] <= prev_inv + x[m], name=f"sell_limit_{m}")
    
    # Fixed ordering cost indicator
    model.addConstr(x[m] <= M * y[m], name=f"fixed_cost_indicator_{m}")

# Month 2 bulk receiving indicator
model.addConstr(x[2] <= month2_threshold + M * z, name="bulk_indicator")

# Objective: maximize profit
revenue = gp.quicksum(selling_prices[m] * s[m] for m in months)
purchase_cost = gp.quicksum(purchasing_prices[m] * x[m] for m in months)
fixed_costs = gp.quicksum(fixed_ordering_cost * y[m] for m in months)
bulk_cost = month2_fee * z

model.setObjective(revenue - purchase_cost - fixed_costs - bulk_cost, GRB.MAXIMIZE)

# Solve
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
