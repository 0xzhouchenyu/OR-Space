import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

def load_csv(filename):
    with open(filename, 'r') as f:
        return list(csv.DictReader(f))

# Load general parameters
params = {}
for row in load_csv(os.path.join(data_dir, 'general_parameters.csv')):
    params[row['Parameter_Name']] = float(row['Value'])
cost_per_km = params['cost_per_km']
adriatic_trigger = params['adriatic_pool_shortage_trigger']
adriatic_fee = params['adriatic_pool_recovery_fee']

# Load warehouses
warehouses = []
supply = {}
for row in load_csv(os.path.join(data_dir, 'table_1.csv')):
    wh = row['Warehouse']
    warehouses.append(wh)
    supply[wh] = int(row['Empty_Containers'])

# Load ports
ports = []
demand = {}
for row in load_csv(os.path.join(data_dir, 'table_2.csv')):
    port = row['Port']
    ports.append(port)
    demand[port] = int(row['Container_Demand'])

# Load distances
dist = {}
for row in load_csv(os.path.join(data_dir, 'table_3.csv')):
    wh = row['Warehouse']
    for port in ports:
        dist[(wh, port)] = float(row[port])

# Load shortage penalties
shortage_charge = {}
grace = {}
recovery_fee = {}
for row in load_csv(os.path.join(data_dir, 'shortage_penalty.csv')):
    port = row['Port']
    shortage_charge[port] = float(row['Shortage_Charge'])
    grace[port] = int(row['Grace_Containers'])
    recovery_fee[port] = float(row['Recovery_Fee'])

# Adriatic ports
adriatic_ports = ['Venice', 'Ancona', 'Bari']

# Model
m = gp.Model('ContainerTransport')
m.setParam('OutputFlag', 0)

# Decision variables
x = m.addVars(warehouses, ports, vtype=GRB.INTEGER, name='x')
s = m.addVars(ports, vtype=GRB.INTEGER, name='s')
y = m.addVars(ports, vtype=GRB.BINARY, name='y')
z = m.addVar(vtype=GRB.BINARY, name='z')

# Supply constraints
for i in warehouses:
    m.addConstr(gp.quicksum(x[i, j] for j in ports) <= supply[i])

# Demand constraints
for j in ports:
    m.addConstr(gp.quicksum(x[i, j] for i in warehouses) + s[j] == demand[j])

# Local recovery desk constraints
for j in ports:
    M_j = demand[j]
    m.addConstr(s[j] - grace[j] <= M_j * y[j])
    m.addConstr(s[j] - grace[j] >= 1 - M_j * (1 - y[j]))

# Adriatic regional recovery desk
S_A = gp.quicksum(s[j] for j in adriatic_ports)
M_A = sum(demand[j] for j in adriatic_ports)
m.addConstr(S_A - adriatic_trigger <= M_A * z)
m.addConstr(S_A - adriatic_trigger >= 1 - M_A * (1 - z))

# Objective
transport_cost = gp.quicksum(x[i, j] * dist[i, j] * cost_per_km for i in warehouses for j in ports)
shortage_cost = gp.quicksum(s[j] * shortage_charge[j] for j in ports)
local_recovery_cost = gp.quicksum(y[j] * recovery_fee[j] for j in ports)
adriatic_recovery_cost = z * adriatic_fee

m.setObjective(transport_cost + shortage_cost + local_recovery_cost + adriatic_recovery_cost, GRB.MINIMIZE)

m.optimize()

print(f"FINAL_OBJ_VALUE: {m.objVal}")
