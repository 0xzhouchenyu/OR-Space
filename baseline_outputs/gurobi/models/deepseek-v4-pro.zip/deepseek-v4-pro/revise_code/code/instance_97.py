import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    # Determine data directory relative to this script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Read raw material data
    materials = []
    sulfur_content = {}
    purchase_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Clean keys
            clean_row = {k.strip(): v.strip() for k, v in row.items()}
            mat = clean_row['Material']
            materials.append(mat)
            sulfur_content[mat] = float(clean_row['Sulfur_Content_Percentage'])
            purchase_price[mat] = float(clean_row['Purchase_Price_Thousand_Yuan_Per_Ton'])

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            clean_row = {k.strip(): v.strip() for k, v in row.items()}
            param_name = clean_row['Parameter_Name']
            params[param_name] = float(clean_row['Value'])

    # Extract parameters
    max_sulfur = {
        'A_premium': params['max_sulfur_content_A_premium'],
        'A_standard': params['max_sulfur_content_A_standard'],
        'B_premium': params['max_sulfur_content_B_premium'],
        'B_standard': params['max_sulfur_content_B_standard']
    }
    selling_price = {
        'A_premium': params['selling_price_A_premium'],
        'A_standard': params['selling_price_A_standard'],
        'B_premium': params['selling_price_B_premium'],
        'B_standard': params['selling_price_B_standard']
    }
    max_supply_D = params['max_supply_D']
    demand_A = params['market_demand_A']
    demand_B = params['market_demand_B']
    min_prem_A = params['min_premium_share_A']
    max_prem_A = params['max_premium_share_A']
    min_prem_B = params['min_premium_share_B']
    max_prem_B = params['max_premium_share_B']

    # Product streams
    products = ['A_premium', 'A_standard', 'B_premium', 'B_standard']
    A_products = ['A_premium', 'A_standard']
    B_products = ['B_premium', 'B_standard']

    # Create model
    model = gp.Model("Blending_Optimization")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[m, p] = tons of material m used in product p
    x = {}
    for m in materials:
        for p in products:
            x[m, p] = model.addVar(lb=0, name=f"x_{m}_{p}")

    # Total amount of each product
    total = {}
    for p in products:
        total[p] = gp.quicksum(x[m, p] for m in materials)

    # Objective: maximize profit = revenue - cost
    revenue = gp.quicksum(selling_price[p] * total[p] for p in products)
    cost = gp.quicksum(purchase_price[m] * gp.quicksum(x[m, p] for p in products) for m in materials)
    model.setObjective(revenue - cost, GRB.MAXIMIZE)

    # Sulfur constraints for each product stream
    for p in products:
        model.addConstr(
            gp.quicksum(sulfur_content[m] * x[m, p] for m in materials) <= max_sulfur[p] * total[p],
            name=f"Sulfur_{p}"
        )

    # Supply limit for material D
    model.addConstr(
        gp.quicksum(x['D', p] for p in products) <= max_supply_D,
        name="Supply_D"
    )

    # Market demand constraints (family level)
    model.addConstr(
        gp.quicksum(total[p] for p in A_products) <= demand_A,
        name="Demand_A"
    )
    model.addConstr(
        gp.quicksum(total[p] for p in B_products) <= demand_B,
        name="Demand_B"
    )

    # Premium share constraints for A
    model.addConstr(total['A_premium'] >= min_prem_A, name="MinPrem_A")
    model.addConstr(total['A_premium'] <= max_prem_A, name="MaxPrem_A")

    # Premium share constraints for B
    model.addConstr(total['B_premium'] >= min_prem_B, name="MinPrem_B")
    model.addConstr(total['B_premium'] <= max_prem_B, name="MaxPrem_B")

    # Solve
    model.optimize()

    # Output final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of infeasibility or other status, print 0 or handle accordingly
        print(f"FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
