import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Read parameters
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(data_path)
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = row['Value']
    
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = int(params['raw_bar_length'])
    setup_cost = float(params['setup_cost_per_pattern'])
    max_patterns = int(params['max_distinct_patterns'])
    
    # Lengths
    len1, len2, len3 = 3, 4, 5
    total_required_length = len1 * q3 + len2 * q4 + len3 * q5
    
    # Generate all valid cutting patterns (a,b,c) for lengths 3,4,5 with total <= L
    patterns = []
    for a in range(L // len1 + 1):
        for b in range(L // len2 + 1):
            for c in range(L // len3 + 1):
                if len1 * a + len2 * b + len3 * c <= L:
                    if a > 0 or b > 0 or c > 0:
                        patterns.append((a, b, c))
    
    # Upper bound on number of bars needed (worst case: one piece per bar)
    M = q3 + q4 + q5
    
    # Create model
    model = gp.Model("CuttingStock")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    n = len(patterns)
    use = model.addVars(n, vtype=GRB.BINARY, name="use")
    count = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="count")
    
    # Constraints: demand satisfaction
    model.addConstr(gp.quicksum(patterns[i][0] * count[i] for i in range(n)) >= q3, "demand_3m")
    model.addConstr(gp.quicksum(patterns[i][1] * count[i] for i in range(n)) >= q4, "demand_4m")
    model.addConstr(gp.quicksum(patterns[i][2] * count[i] for i in range(n)) >= q5, "demand_5m")
    
    # Limit on number of distinct patterns
    model.addConstr(gp.quicksum(use[i] for i in range(n)) <= max_patterns, "max_patterns")
    
    # Link count and use variables
    for i in range(n):
        model.addConstr(count[i] <= M * use[i], f"link_{i}")
    
    # Objective: minimize total waste = (total raw length used) - (total required length) + setup cost * number of patterns used
    total_raw_used = gp.quicksum(L * count[i] for i in range(n))
    total_setup_waste = setup_cost * gp.quicksum(use[i] for i in range(n))
    model.setObjective(total_raw_used - total_required_length + total_setup_waste, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Output
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # In case of infeasibility or other issues, print a default message (should not happen)
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    solve()
