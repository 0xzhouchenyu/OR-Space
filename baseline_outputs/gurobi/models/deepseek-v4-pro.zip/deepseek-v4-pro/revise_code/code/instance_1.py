import os
import csv
import gurobipy as gp
from gurobipy import GRB

# =============================================================================
# Data loading utilities (self-contained)
# =============================================================================
def load_csv(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return [row for row in reader]

def load_parameters():
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name'].strip()
        val = row['Value'].strip()
        try:
            if '.' in val:
                params[name] = float(val)
            else:
                params[name] = int(val)
        except ValueError:
            params[name] = val
    return params

def load_demand():
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        week = int(row['Week'].strip())
        demand[week] = {
            'I': int(row['I'].strip()),
            'II': int(row['II'].strip())
        }
    return demand

# =============================================================================
# Problem data
# =============================================================================
params = load_parameters()
demand = load_demand()

T = 8
weeks = range(1, T + 1)
train_weeks = range(1, T)  # 1..7

S0 = params['skilled_worker_count']                 # 50
rate_I = params['food_I_production_rate']           # 10
rate_II = params['food_II_production_rate']         # 6
normal_hours = params['worker_weekly_hours']        # 40
overtime_hours = params['skilled_worker_overtime_hours']  # 60
train_cap = params['training_capacity']             # 3
train_period = params['training_period']            # 2
wage_skilled = params['skilled_worker_weekly_wage'] # 360
wage_trainee_during = params['trainee_weekly_wage_during_training']  # 120
wage_trainee_after = params['trainee_weekly_wage_after_training']    # 240
wage_overtime = params['skilled_worker_overtime_wage']  # 540
comp_I = params['compensation_fee_food_I']          # 0.5
comp_II = params['compensation_fee_food_II']        # 0.6
new_worker_goal = params['new_worker_training_goal']  # 50

# =============================================================================
# Model
# =============================================================================
model = gp.Model("factory_training_revised")
model.setParam('OutputFlag', 0)

# --- Decision variables ---
# Trainers starting in week s (s = 1..7)
n_train = {s: model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_train_{s}") for s in train_weeks}

# Weekly variables
n_ot = {}          # number of skilled workers on overtime
h_I_s, h_II_s = {}, {}     # normal skilled hours
h_I_ot, h_II_ot = {}, {}   # overtime skilled hours
h_I_g, h_II_g = {}, {}     # graduate hours
backlog_I, backlog_II = {}, {}
z_I, z_II = {}, {}         # binary: 1 if week is dedicated to that food

for t in weeks:
    n_ot[t] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_ot_{t}")
    h_I_s[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"h_I_s_{t}")
    h_II_s[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"h_II_s_{t}")
    h_I_ot[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"h_I_ot_{t}")
    h_II_ot[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"h_II_ot_{t}")
    h_I_g[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"h_I_g_{t}")
    h_II_g[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"h_II_g_{t}")
    backlog_I[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"backlog_I_{t}")
    backlog_II[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"backlog_II_{t}")
    z_I[t] = model.addVar(vtype=GRB.BINARY, name=f"z_I_{t}")
    z_II[t] = model.addVar(vtype=GRB.BINARY, name=f"z_II_{t}")

# --- Helper expressions ---
# Number of skilled workers busy training in week t
def busy_trainers(t):
    return gp.quicksum(n_train[s] for s in train_weeks if s <= t <= s + train_period - 1)

# Number of graduated trainees available in week t
def graduates(t):
    return gp.quicksum(train_cap * n_train[s] for s in train_weeks if s + train_period <= t)

# Big-M for mutual exclusion (maximum possible hours per food type per week)
M = 10000

# --- Constraints ---
for t in weeks:
    busy_t = busy_trainers(t)
    avail_t = S0 - busy_t
    grads_t = graduates(t)

    # Skilled workers cannot be negative
    model.addConstr(avail_t >= 0, f"skilled_avail_{t}")

    # Overtime workers limited by available skilled workers
    model.addConstr(n_ot[t] <= avail_t, f"ot_limit_{t}")

    # Normal skilled hours
    model.addConstr(h_I_s[t] + h_II_s[t] <= (avail_t - n_ot[t]) * normal_hours,
                    f"normal_hours_{t}")

    # Overtime hours
    model.addConstr(h_I_ot[t] + h_II_ot[t] <= n_ot[t] * overtime_hours,
                    f"ot_hours_{t}")

    # Graduate hours
    model.addConstr(h_I_g[t] + h_II_g[t] <= grads_t * normal_hours,
                    f"grad_hours_{t}")

    # Mutual exclusion: at most one food type per week
    model.addConstr(z_I[t] + z_II[t] <= 1, f"exclusive_{t}")

    # Link production hours to the chosen food type
    model.addConstr(h_I_s[t] <= M * z_I[t], f"link_I_s_{t}")
    model.addConstr(h_I_ot[t] <= M * z_I[t], f"link_I_ot_{t}")
    model.addConstr(h_I_g[t] <= M * z_I[t], f"link_I_g_{t}")
    model.addConstr(h_II_s[t] <= M * z_II[t], f"link_II_s_{t}")
    model.addConstr(h_II_ot[t] <= M * z_II[t], f"link_II_ot_{t}")
    model.addConstr(h_II_g[t] <= M * z_II[t], f"link_II_g_{t}")

    # Production quantities
    prod_I = (h_I_s[t] + h_I_ot[t] + h_I_g[t]) * rate_I
    prod_II = (h_II_s[t] + h_II_ot[t] + h_II_g[t]) * rate_II

    # Backlog balance
    prev_bI = backlog_I[t-1] if t > 1 else 0
    prev_bII = backlog_II[t-1] if t > 1 else 0
    model.addConstr(backlog_I[t] >= prev_bI + demand[t]['I'] - prod_I,
                    f"backlog_I_{t}")
    model.addConstr(backlog_II[t] >= prev_bII + demand[t]['II'] - prod_II,
                    f"backlog_II_{t}")

# Training goal: at least 50 new workers trained by end of week 8
total_trained = gp.quicksum(train_cap * n_train[s] for s in train_weeks)
model.addConstr(total_trained >= new_worker_goal, "training_goal")

# --- Objective ---
total_cost = gp.quicksum(
    (S0 - n_ot[t]) * wage_skilled + n_ot[t] * wage_overtime
    for t in weeks
)
total_cost += gp.quicksum(
    n_train[s] * train_cap * wage_trainee_during * train_period
    for s in train_weeks
)
total_cost += gp.quicksum(
    graduates(t) * wage_trainee_after
    for t in weeks
)
total_cost += gp.quicksum(
    backlog_I[t] * comp_I + backlog_II[t] * comp_II
    for t in weeks
)

model.setObjective(total_cost, GRB.MINIMIZE)

# --- Solve ---
model.optimize()

# --- Output ---
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: infeasible")
