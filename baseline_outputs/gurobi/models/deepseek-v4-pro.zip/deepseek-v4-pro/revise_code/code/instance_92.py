import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    return params

# Path to data file
data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
params = load_parameters(data_path)

# Extract parameters
num_students = int(params['num_students'])
num_buses = int(params['num_buses'])
bus_capacity = int(params['bus_capacity'])
num_minibuses = int(params['num_minibuses'])
minibus_capacity = int(params['minibus_capacity'])
num_drivers = int(params['num_drivers'])
bus_rental_cost = float(params['bus_rental_cost'])
minibus_rental_cost = float(params['minibus_rental_cost'])

# Create model
model = gp.Model("SchoolTrip")
model.setParam('OutputFlag', 0)

# Decision variables
buses = model.addVar(vtype=GRB.INTEGER, lb=0, ub=num_buses, name="buses")
minibuses = model.addVar(vtype=GRB.INTEGER, lb=0, ub=num_minibuses, name="minibuses")

# Objective: minimize total rental cost
model.setObjective(bus_rental_cost * buses + minibus_rental_cost * minibuses, GRB.MINIMIZE)

# Constraints
# 1. Capacity: must transport all students
model.addConstr(bus_capacity * buses + minibus_capacity * minibuses >= num_students, "StudentCapacity")

# 2. Driver limit: total vehicles cannot exceed available drivers
model.addConstr(buses + minibuses <= num_drivers, "DriverLimit")

# 3. Safety policy: at least two buses per minibus
model.addConstr(buses >= 2 * minibuses, "SafetyRatio")

# 4. Minimum one minibus
model.addConstr(minibuses >= 1, "MinMinibus")

# Solve
model.optimize()

# Output
obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
