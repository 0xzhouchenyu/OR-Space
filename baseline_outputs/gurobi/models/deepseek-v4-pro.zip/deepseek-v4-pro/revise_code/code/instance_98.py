import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths to data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    general_params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    table1_path = os.path.join(base_dir, "data", "table_1.csv")

    # Read general parameters
    params = {}
    with open(general_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    # Read product data
    products = []
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)

    # Extract parameters
    avail_steel = params['available_steel']
    avail_aluminum = params['available_aluminum']
    avail_labor = params['available_labor']
    overtime_pay = params['overtime_pay']
    max_overtime = params['max_overtime']
    overtime_review_threshold = params['overtime_review_threshold']
    overtime_review_fee = params['overtime_review_fee']
    line_audit_threshold = params['product_A_line_audit_threshold']
    line_audit_fee = params['product_A_line_audit_fee']

    # Product data
    prod_data = {}
    for p in products:
        name = p['Product']
        prod_data[name] = {
            'steel': float(p['Steel_Required_kg']),
            'aluminum': float(p['Aluminum_Required_kg']),
            'labor': float(p['Labor_Required_hours']),
            'profit': float(p['Profit_yuan']),
            'setup': float(p['Setup_Cost_yuan'])
        }

    # Upper bounds for x_A and x_B based on resources
    # Steel: 6 x_A + 12 x_B <= 200 => x_A <= 200/6 ≈ 33.33, x_B <= 200/12 ≈ 16.67
    # Aluminum: 8 x_A + 20 x_B <= 300 => x_A <= 37.5, x_B <= 15
    # Labor (with max overtime): 11 x_A + 24 x_B <= 330 => x_A <= 30, x_B <= 13.75
    M_A = min(200/6, 300/8, (avail_labor + max_overtime)/11)  # 30.0
    M_B = min(200/12, 300/20, (avail_labor + max_overtime)/24)  # 13.75

    # Create model
    m = gp.Model("Production_Optimization_Revised")
    m.setParam('OutputFlag', 0)

    # Decision variables
    x_A = m.addVar(lb=0, name="x_A")
    x_B = m.addVar(lb=0, name="x_B")
    overtime = m.addVar(lb=0, ub=max_overtime, name="overtime")

    # Binary variables
    y_A = m.addVar(vtype=GRB.BINARY, name="setup_A")
    y_B = m.addVar(vtype=GRB.BINARY, name="setup_B")
    z_overtime_review = m.addVar(vtype=GRB.BINARY, name="overtime_review")
    w_line_audit = m.addVar(vtype=GRB.BINARY, name="line_audit_A")

    # Objective: maximize profit - overtime cost - review fee - line audit fee - setup costs
    profit = prod_data['A']['profit'] * x_A + prod_data['B']['profit'] * x_B
    overtime_cost = overtime_pay * overtime
    review_cost = overtime_review_fee * z_overtime_review
    audit_cost = line_audit_fee * w_line_audit
    setup_cost = prod_data['A']['setup'] * y_A + prod_data['B']['setup'] * y_B

    m.setObjective(profit - overtime_cost - review_cost - audit_cost - setup_cost, GRB.MAXIMIZE)

    # Resource constraints
    m.addConstr(prod_data['A']['steel'] * x_A + prod_data['B']['steel'] * x_B <= avail_steel, "Steel")
    m.addConstr(prod_data['A']['aluminum'] * x_A + prod_data['B']['aluminum'] * x_B <= avail_aluminum, "Aluminum")
    # Labor: total labor = regular + overtime
    m.addConstr(prod_data['A']['labor'] * x_A + prod_data['B']['labor'] * x_B <= avail_labor + overtime, "Labor")

    # Setup constraints: if x > 0 then y = 1
    m.addConstr(x_A <= M_A * y_A, "Setup_A_link")
    m.addConstr(x_B <= M_B * y_B, "Setup_B_link")

    # Overtime review fee trigger: if overtime > threshold (20) then z = 1
    # Use big-M with M = max_overtime (30)
    eps = 1e-5
    M_ot = max_overtime
    m.addConstr(overtime <= overtime_review_threshold + M_ot * z_overtime_review, "OT_review_upper")
    m.addConstr(overtime >= overtime_review_threshold + eps - M_ot * (1 - z_overtime_review), "OT_review_lower")

    # Line audit fee trigger: if x_A > threshold (29) then w = 1
    M_audit = M_A  # 30
    m.addConstr(x_A <= line_audit_threshold + M_audit * w_line_audit, "Audit_upper")
    m.addConstr(x_A >= line_audit_threshold + eps - M_audit * (1 - w_line_audit), "Audit_lower")

    # Solve
    m.optimize()

    # Output
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        # In case of infeasibility or other status, print something
        print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    main()
