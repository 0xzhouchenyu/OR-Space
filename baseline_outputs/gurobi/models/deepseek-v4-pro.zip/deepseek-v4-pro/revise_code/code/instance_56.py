import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load monthly prices
months = []
purchase_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        m = int(row["Month"])
        months.append(m)
        purchase_prices[m] = float(row["Purchase_Price_yuan_per_dan"])
        selling_prices[m] = float(row["Selling_Price_yuan_per_dan"])

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

warehouse_capacity = params["warehouse_capacity"]
initial_stock = params["initial_stock"]
initial_funds = params["initial_funds"]
end_of_quarter_inventory = params["end_of_quarter_inventory"]
buy_fast_capacity = params["buy_fast_capacity"]
fast_purchase_premium_ratio = params["fast_purchase_premium_ratio"]
credit_limit = params["credit_limit"]
monthly_interest_rate = params["monthly_interest_rate"]
min_inventory = {
    1: params["min_inventory_month_1"],
    2: params["min_inventory_month_2"],
    3: params["min_inventory_month_3"],
}

# Create model
model = gp.Model("Grain_Trading_Revised")
model.setParam("OutputFlag", 0)

# Decision variables
buy_regular = model.addVars(months, lb=0, name="buy_regular")
buy_fast = model.addVars(months, lb=0, name="buy_fast")
sell = model.addVars(months, lb=0, name="sell")
stock = model.addVars(months, lb=0, name="stock")
funds = model.addVars(months, lb=-GRB.INFINITY, name="funds")
credit_used = model.addVars(months, lb=0, name="credit_used")
interest = model.addVars(months, lb=0, name="interest")

# Constraints
for m in months:
    prev_stock = initial_stock if m == 1 else stock[m - 1]
    prev_funds = initial_funds if m == 1 else funds[m - 1]

    # Stock balance
    model.addConstr(
        stock[m] == prev_stock - sell[m] + buy_regular[m] + buy_fast[m],
        name=f"stock_balance_{m}",
    )

    # Sales cannot exceed previous stock
    model.addConstr(sell[m] <= prev_stock, name=f"sell_limit_{m}")

    # Warehouse capacity
    model.addConstr(stock[m] <= warehouse_capacity, name=f"warehouse_{m}")

    # Minimum inventory requirement
    model.addConstr(stock[m] >= min_inventory[m], name=f"min_inventory_{m}")

    # Fast purchase capacity
    model.addConstr(buy_fast[m] <= buy_fast_capacity, name=f"fast_capacity_{m}")

    # Interest definition
    model.addConstr(
        interest[m] == monthly_interest_rate * credit_used[m],
        name=f"interest_def_{m}",
    )

    # Funds balance (equity)
    model.addConstr(
        funds[m]
        == prev_funds
        + sell[m] * selling_prices[m]
        - buy_regular[m] * purchase_prices[m]
        - buy_fast[m] * purchase_prices[m] * (1 + fast_purchase_premium_ratio)
        - interest[m],
        name=f"funds_balance_{m}",
    )

    # Cash non-negativity: cash = funds + credit_used >= 0
    model.addConstr(
        funds[m] + credit_used[m] >= 0, name=f"cash_nonneg_{m}"
    )

    # Credit limit
    model.addConstr(credit_used[m] <= credit_limit, name=f"credit_limit_{m}")

# End-of-quarter inventory requirement (redundant with min_inventory[3] but kept for clarity)
model.addConstr(stock[3] >= end_of_quarter_inventory, name="end_inventory")

# Objective: (funds_3 - initial_funds) - total interest paid
total_interest = gp.quicksum(interest[m] for m in months)
model.setObjective(funds[3] - initial_funds - total_interest, GRB.MAXIMIZE)

# Solve
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")  # will print whatever is available
