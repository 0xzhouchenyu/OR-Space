import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    demand_df = pd.read_csv(os.path.join(base_dir, 'data', 'table_4_3.csv'))
    supply_df = pd.read_csv(os.path.join(base_dir, 'data', 'table_4_4.csv'))
    params_df = pd.read_csv(os.path.join(base_dir, 'data', 'general_parameters.csv'))
    
    # Parse parameters
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])
    
    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]  # "Donghai City" -> "Donghai"
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem
        
    # Parse supply
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = float(row['Number_of_People'])
        suit = [int(x) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }
        
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]
    
    # Create model
    m = gp.Model("staffing")
    m.setParam('OutputFlag', 0)
    
    # Decision variables
    x = m.addVars(types, cities, specs, lb=0, vtype=GRB.INTEGER, name="x")
    
    # Constraints
    # 1. Supply limits
    for i in types:
        m.addConstr(gp.quicksum(x[i, j, k] for j in cities for k in specs) <= supply[i]['num'], name=f"supply_{i}")
        
    # 2. Demand satisfaction (Priority 1)
    for j in cities:
        for k in specs:
            m.addConstr(gp.quicksum(x[i, j, k] for i in types) >= demand[(j, k)], name=f"demand_{j}_{k}")
            
    # 3. Suitability
    for i in types:
        for j in cities:
            for k in specs:
                if k not in supply[i]['suit']:
                    m.addConstr(x[i, j, k] == 0, name=f"suit_{i}_{j}_{k}")
                    
    # 4. Priority 2: at least p2_target people in preferred specialty
    pref_spec_sum = gp.quicksum(x[i, j, supply[i]['pref_spec']] for i in types for j in cities)
    m.addConstr(pref_spec_sum >= p2_target, name="priority2")
    
    # Objective: maximize dual matches (preferred specialty AND preferred city)
    dual_match_sum = gp.quicksum(x[i, supply[i]['pref_city'], supply[i]['pref_spec']] for i in types)
    m.setObjective(dual_match_sum, GRB.MAXIMIZE)
    
    # Solve
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        obj_val = m.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print("Model not optimal, status:", m.status)

if __name__ == '__main__':
    solve()
