import os
import csv
import gurobipy as gp
from gurobipy import GRB
from itertools import combinations

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Path to data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

    # Extract parameters
    pollution = {
        'motorcycle': params['motorcycle_pollution'],
        'small_truck': params['small_truck_pollution'],
        'large_truck': params['large_truck_pollution']
    }
    capacity = {
        'motorcycle': params['motorcycle_capacity'],
        'small_truck': params['small_truck_capacity'],
        'large_truck': params['large_truck_capacity']
    }
    max_motorcycle_trips = int(params['max_motorcycle_trips'])
    max_total_trips = int(params['max_total_trips'])
    demand_peak = params['demand_peak_units']
    demand_offpeak = params['demand_offpeak_units']
    leasing_capacity = params['leasing_capacity']
    leasing_pollution_per_unit = params['leasing_pollution_per_unit']
    leasing_fixed_pollution = params['leasing_fixed_pollution']
    max_leasing_fraction_peak = params['max_leasing_fraction_peak']
    bigM_leasing = params['bigM_leasing']
    epsilon = params['epsilon']

    methods = ['motorcycle', 'small_truck', 'large_truck']
    best_obj = float('inf')
    best_combo = None

    for combo in combinations(methods, 2):
        # Create model
        m = gp.Model(f"Transport_{'_'.join(combo)}")
        m.setParam('OutputFlag', 0)

        # Decision variables: trips per period for each owned method
        trips_peak = {}
        trips_offpeak = {}
        for v in combo:
            trips_peak[v] = m.addVar(lb=0, vtype=GRB.INTEGER, name=f"trips_peak_{v}")
            trips_offpeak[v] = m.addVar(lb=0, vtype=GRB.INTEGER, name=f"trips_offpeak_{v}")

        # Leasing variables
        leasing_peak = m.addVar(lb=0, name="leasing_peak")
        leasing_offpeak = m.addVar(lb=0, name="leasing_offpeak")
        leasing_used = m.addVar(vtype=GRB.BINARY, name="leasing_used")

        # Total leasing
        total_leasing = leasing_peak + leasing_offpeak

        # Objective: minimize total pollution
        owned_pollution = gp.quicksum(
            pollution[v] * (trips_peak[v] + trips_offpeak[v]) for v in combo
        )
        leasing_var_pollution = leasing_pollution_per_unit * total_leasing
        leasing_fixed = leasing_fixed_pollution * leasing_used
        m.setObjective(owned_pollution + leasing_var_pollution + leasing_fixed, GRB.MINIMIZE)

        # Demand constraints
        m.addConstr(
            gp.quicksum(capacity[v] * trips_peak[v] for v in combo) + leasing_peak >= demand_peak,
            "demand_peak"
        )
        m.addConstr(
            gp.quicksum(capacity[v] * trips_offpeak[v] for v in combo) + leasing_offpeak >= demand_offpeak,
            "demand_offpeak"
        )

        # Total trips limit
        m.addConstr(
            gp.quicksum(trips_peak[v] + trips_offpeak[v] for v in combo) <= max_total_trips,
            "max_total_trips"
        )

        # Motorcycle limit if selected
        if 'motorcycle' in combo:
            m.addConstr(
                trips_peak['motorcycle'] + trips_offpeak['motorcycle'] <= max_motorcycle_trips,
                "max_motorcycle"
            )

        # Leasing peak fraction
        m.addConstr(leasing_peak <= max_leasing_fraction_peak * demand_peak, "leasing_peak_frac")

        # Total leasing capacity
        m.addConstr(total_leasing <= leasing_capacity, "leasing_capacity")

        # Leasing activation (gate)
        m.addConstr(total_leasing <= bigM_leasing * leasing_used, "bigM_leasing")
        m.addConstr(total_leasing >= epsilon * leasing_used, "epsilon_leasing")

        # Solve
        m.optimize()

        if m.status == GRB.OPTIMAL:
            obj_val = m.objVal
            if obj_val < best_obj:
                best_obj = obj_val
                best_combo = combo

    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {best_obj}")

if __name__ == "__main__":
    main()
