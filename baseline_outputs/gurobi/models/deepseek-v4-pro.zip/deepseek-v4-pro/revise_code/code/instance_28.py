import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

initial_fund = params["initial_fund"]                     # 300000
annual_rate = params["annual_profit_rate"] / 100          # 0.20
inv_limit_y1 = params["investment_limit_year1"]           # 150000
return_rate_y1y2 = params["return_rate_year1_to_year2"] / 100  # 1.50
inv_limit_y2 = params["investment_limit_year2"]           # 200000
return_rate_y2y3 = params["return_rate_year2_to_year3"] / 100  # 1.60
inv_limit_y3 = params["investment_limit_year3"]           # 100000
profit_rate_y3 = params["profit_rate_year3"] / 100        # 0.40
fee1 = params["fee_year1"]                                # 10000
fee2 = params["fee_year2"]                                # 12000
fee3 = params["fee_year3"]                                # 5000

# Create model
model = gp.Model("Investment_Optimization_Revised")
model.setParam("OutputFlag", 0)

# Decision variables
a1 = model.addVar(lb=0, name="a1")
a2 = model.addVar(lb=0, name="a2")
a3 = model.addVar(lb=0, name="a3")

b1 = model.addVar(lb=0, ub=inv_limit_y1, name="b1")
c2 = model.addVar(lb=0, ub=inv_limit_y2, name="c2")
d3 = model.addVar(lb=0, ub=inv_limit_y3, name="d3")

# Binary variables for fixed management fees
y1 = model.addVar(vtype=GRB.BINARY, name="y1")
y2 = model.addVar(vtype=GRB.BINARY, name="y2")
y3 = model.addVar(vtype=GRB.BINARY, name="y3")

# Linking constraints: special investment > 0 implies binary = 1
model.addConstr(b1 <= inv_limit_y1 * y1, name="link_y1")
model.addConstr(c2 <= inv_limit_y2 * y2, name="link_y2")
model.addConstr(d3 <= inv_limit_y3 * y3, name="link_y3")

# Budget constraints (fees paid at start of year if special investment used)
# Year 1: a1 + b1 + fee1*y1 <= initial_fund
model.addConstr(a1 + b1 + fee1 * y1 <= initial_fund, name="Year1_budget")

# Year 2: available = initial_fund - b1 - fee1*y1 + 0.2*a1
# a2 + c2 + fee2*y2 <= available
model.addConstr(
    a2 + c2 + fee2 * y2 <= initial_fund - b1 - fee1 * y1 + annual_rate * a1,
    name="Year2_budget"
)

# Year 3: available = initial_fund + 0.2*a1 + 0.2*a2 + 0.5*b1 - c2 - fee1*y1 - fee2*y2
# a3 + d3 + fee3*y3 <= available
model.addConstr(
    a3 + d3 + fee3 * y3 <= initial_fund
    + annual_rate * a1
    + annual_rate * a2
    + (return_rate_y1y2 - 1) * b1
    - c2
    - fee1 * y1
    - fee2 * y2,
    name="Year3_budget"
)

# Objective: total net cash at end of year 3
total_end = (
    initial_fund
    + annual_rate * a1
    + annual_rate * a2
    + annual_rate * a3
    + (return_rate_y1y2 - 1) * b1
    + (return_rate_y2y3 - 1) * c2
    + profit_rate_y3 * d3
    - fee1 * y1
    - fee2 * y2
    - fee3 * y3
)
model.setObjective(total_end, GRB.MAXIMIZE)

# Solve
model.optimize()

# Output
print(f"FINAL_OBJ_VALUE: {model.objVal}")
