import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_reliability_table(filepath):
    reliability = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            n = int(row['Number_of_Spares'])
            r1 = float(row['Component_1_Reliability'])
            r2 = float(row['Component_2_Reliability'])
            r3 = float(row['Component_3_Reliability'])
            reliability[n] = [r1, r2, r3]
    return reliability

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    table_path = os.path.join(base_dir, "data", "table_1.csv")
    
    # Load data
    params = load_general_parameters(params_path)
    reliability = load_reliability_table(table_path)
    
    # Parameters
    prices = [params['unit_price_component_1'],
              params['unit_price_component_2'],
              params['unit_price_component_3']]
    weights = [params['unit_weight_component_1'],
               params['unit_weight_component_2'],
               params['unit_weight_component_3']]
    budget_A = params['total_budget_scenario_A']
    budget_B = params['total_budget_scenario_B']
    weight_A = params['weight_limit_scenario_A']
    weight_B = params['weight_limit_scenario_B']
    
    # Effective limits (must satisfy both scenarios)
    max_cost = min(budget_A, budget_B)
    max_weight = min(weight_A, weight_B)
    
    # Spare counts range
    max_spares = max(reliability.keys())  # 5
    components = range(3)
    spares = range(max_spares + 1)
    
    # Precompute log reliabilities
    log_rel = {}
    for k in spares:
        log_rel[k] = [math.log(reliability[k][i]) for i in components]
    
    # Model
    model = gp.Model("spare_parts")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i,k] = 1 if component i has k spares
    x = {}
    for i in components:
        for k in spares:
            x[i, k] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{k}")
    
    # Each component gets exactly one spare count
    for i in components:
        model.addConstr(gp.quicksum(x[i, k] for k in spares) == 1)
    
    # Spare count for each component
    s = {}
    for i in components:
        s[i] = gp.quicksum(k * x[i, k] for k in spares)
    
    # Cost constraint
    total_cost = gp.quicksum(prices[i] * s[i] for i in components)
    model.addConstr(total_cost <= max_cost)
    
    # Weight constraint
    total_weight = gp.quicksum(weights[i] * s[i] for i in components)
    model.addConstr(total_weight <= max_weight)
    
    # Objective: maximize sum of log reliabilities
    obj = gp.quicksum(log_rel[k][i] * x[i, k] for i in components for k in spares)
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status != GRB.OPTIMAL:
        raise RuntimeError("No optimal solution found")
    
    # Retrieve solution
    chosen = [0, 0, 0]
    for i in components:
        for k in spares:
            if x[i, k].X > 0.5:
                chosen[i] = k
                break
    
    # Compute actual system reliability
    sys_rel = 1.0
    for i in components:
        sys_rel *= reliability[chosen[i]][i]
    
    # Expected reliability = 0.5*sys_rel + 0.5*sys_rel = sys_rel
    print(f"FINAL_OBJ_VALUE: {sys_rel}")

if __name__ == "__main__":
    main()
