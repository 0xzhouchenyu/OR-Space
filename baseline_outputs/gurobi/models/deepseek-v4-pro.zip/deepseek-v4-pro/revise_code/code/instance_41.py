import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Path to data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load initial capital
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Parameter_Name'].strip() == 'initial_capital':
            initial_capital = float(row['Value'].strip())

# Load liquidity policy
with open(os.path.join(data_dir, 'liquidity_policy.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Parameter_Name'].strip() == 'min_year3_reserve':
            min_reserve = float(row['Value'].strip())
        elif row['Parameter_Name'].strip() == 'reserve_shortfall_penalty':
            penalty = float(row['Value'].strip())

# Load project data
projects = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        pid = row['Project_ID'].strip()
        projects[pid] = {
            'availability_start': row['Availability_Start'].strip(),
            'availability_end': row['Availability_End'].strip(),
            'maturity_end': row['Maturity_End'].strip(),
            'interest_rate': float(row['Interest_Rate'].strip()),
            'capacity': row['Investment_Capacity'].strip()
        }

# Extract parameters for each project
r1 = projects['1']['interest_rate']          # 1.20
r2 = projects['2']['interest_rate']          # 1.50
cap2 = float(projects['2']['capacity'])      # 120000
r3 = projects['3']['interest_rate']          # 1.60
cap3 = float(projects['3']['capacity'])      # 150000
r4 = projects['4']['interest_rate']          # 1.40
cap4 = float(projects['4']['capacity'])      # 100000

# Create optimization model
m = gp.Model("Investment_Revised")
m.setParam('OutputFlag', 0)

# Decision variables
x1_1 = m.addVar(name="x1_1", lb=0)                     # Project 1, Year 1
x1_2 = m.addVar(name="x1_2", lb=0)                     # Project 1, Year 2
x1_3 = m.addVar(name="x1_3", lb=0)                     # Project 1, Year 3
x2   = m.addVar(name="x2", lb=0, ub=cap2)              # Project 2, Year 1
x3   = m.addVar(name="x3", lb=0, ub=cap3)              # Project 3, Year 2
x4   = m.addVar(name="x4", lb=0, ub=cap4)              # Project 4, Year 3
cash_held = m.addVar(name="cash_held", lb=0)           # Uninvested cash at beginning of Year 3
shortfall = m.addVar(name="shortfall", lb=0)           # Reserve shortfall

# Budget constraints
# Year 1: initial capital allocation
m.addConstr(x1_1 + x2 <= initial_capital, name="Year1_Budget")

# Year 2: proceeds from Project 1 (Year 1) are available
m.addConstr(x1_2 + x3 <= r1 * x1_1, name="Year2_Budget")

# Year 3: proceeds from Year 2 investments become available
# Available = Project 1 (Year 2) + Project 2 + Project 3
m.addConstr(x1_3 + x4 + cash_held == r1 * x1_2 + r2 * x2 + r3 * x3, name="Year3_Budget")

# Liquidity reserve shortfall definition
m.addConstr(shortfall >= min_reserve - cash_held, name="Shortfall_Def")

# Objective: maximize ending wealth minus penalty for reserve shortfall
ending_wealth = cash_held + r1 * x1_3 + r4 * x4
m.setObjective(ending_wealth - penalty * shortfall, GRB.MAXIMIZE)

# Solve
m.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {m.objVal}")
