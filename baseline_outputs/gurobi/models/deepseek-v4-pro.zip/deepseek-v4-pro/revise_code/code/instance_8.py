import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    table1_path = os.path.join(data_dir, 'table_1.csv')
    general_params_path = os.path.join(data_dir, 'general_parameters.csv')

    # Read table_1.csv
    workers = []
    tasks = []
    time = {}
    fixed_cost = {}

    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: Worker, A, B, C, D, Fixed_Cost
        tasks = header[1:5]  # ['A', 'B', 'C', 'D']
        for row in reader:
            w = row[0].strip()
            workers.append(w)
            for j, t in enumerate(tasks):
                time[(w, t)] = int(row[j + 1])
            fixed_cost[w] = int(row[5])  # Fixed_Cost column

    # Read general_parameters.csv
    handoff_cost = 0
    pair_fee = 0
    with open(general_params_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            param = row[0].strip()
            value = int(row[1])
            if param == 'shared_temp_handoff_cost':
                handoff_cost = value
            elif param == 'worker_II_V_pair_fee':
                pair_fee = value

    # Create model
    m = gp.Model("assignment_revised")
    m.setParam('OutputFlag', 0)

    # Decision variables
    x = {}
    for w in workers:
        for t in tasks:
            x[(w, t)] = m.addVar(vtype=GRB.BINARY, name=f"x_{w}_{t}")

    y = {}
    for w in workers:
        y[w] = m.addVar(vtype=GRB.BINARY, name=f"y_{w}")

    # Auxiliary binary variables for pair conditions
    z_III_V = m.addVar(vtype=GRB.BINARY, name="z_III_V")
    z_II_V = m.addVar(vtype=GRB.BINARY, name="z_II_V")

    # Constraints: each task exactly one worker
    for t in tasks:
        m.addConstr(gp.quicksum(x[(w, t)] for w in workers) == 1, name=f"task_{t}")

    # Link y and x: y[w] = sum_t x[w,t]
    for w in workers:
        m.addConstr(y[w] == gp.quicksum(x[(w, t)] for t in tasks), name=f"link_{w}")

    # Exactly 4 workers used
    m.addConstr(gp.quicksum(y[w] for w in workers) == 4, name="four_workers")

    # Linearization of z_III_V = y['III'] * y['V']
    m.addConstr(z_III_V >= y['III'] + y['V'] - 1, name="z_III_V_lb")
    m.addConstr(z_III_V <= y['III'], name="z_III_V_ub1")
    m.addConstr(z_III_V <= y['V'], name="z_III_V_ub2")

    # Linearization of z_II_V = y['II'] * y['V']
    m.addConstr(z_II_V >= y['II'] + y['V'] - 1, name="z_II_V_lb")
    m.addConstr(z_II_V <= y['II'], name="z_II_V_ub1")
    m.addConstr(z_II_V <= y['V'], name="z_II_V_ub2")

    # Objective
    obj = gp.quicksum(time[(w, t)] * x[(w, t)] for w in workers for t in tasks)
    obj += gp.quicksum(fixed_cost[w] * y[w] for w in workers)
    obj += handoff_cost * z_III_V
    obj += pair_fee * z_II_V

    m.setObjective(obj, GRB.MINIMIZE)

    # Solve
    m.optimize()

    # Output
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        # Fallback in case of infeasibility or other status
        print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    main()
