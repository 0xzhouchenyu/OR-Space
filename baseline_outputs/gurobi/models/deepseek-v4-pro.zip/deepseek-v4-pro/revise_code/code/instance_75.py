import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Allow import of the utility from the original src directory
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
from utils import load_parameters

# Load revised parameters
data_dir = os.path.join(os.path.dirname(__file__), 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract all required parameters
a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']
T1_normal = params['available_time_process_1']
T2_normal = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']
c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
bigM = params['bigM_disposal']
disp_cost_low = params['disposal_cost_per_unit_c']
disp_cost_high = params['disposal_cost_per_unit_c_high']
profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

# Create Gurobi model
m = gp.Model("MaxProfit")
m.setParam('OutputFlag', 0)

# Decision variables
xA = m.addVar(lb=0, name="xA")
xB = m.addVar(lb=0, name="xB")
cSold = m.addVar(lb=0, name="cSold")
cDispLow = m.addVar(lb=0, name="cDispLow")
cDispHigh = m.addVar(lb=0, name="cDispHigh")
y1 = m.addVar(vtype=GRB.BINARY, name="y1")   # 1 if process 1 uses high-throughput
y2 = m.addVar(vtype=GRB.BINARY, name="y2")   # 1 if process 2 uses high-throughput
z = m.addVar(vtype=GRB.BINARY, name="z")     # 1 if total disposal > threshold_c

# Objective: maximise total profit
m.setObjective(
    profit_a * xA +
    profit_b * xB +
    profit_c * cSold -
    (disp_cost_low * cDispLow + disp_cost_high * cDispHigh),
    GRB.MAXIMIZE
)

# Process time constraints with high-throughput option
m.addConstr(a_p1 * xA + b_p1 * xB <= T1_normal + (T1_high - T1_normal) * y1, "Proc1Time")
m.addConstr(a_p2 * xA + b_p2 * xB <= T2_normal + (T2_high - T2_normal) * y2, "Proc2Time")

# At most one process may use high-throughput mode
m.addConstr(y1 + y2 <= 1, "HighThroughputLimit")

# By-product C balance: produced = sold + disposed (low + high)
m.addConstr(cSold + cDispLow + cDispHigh == c_per_b * xB, "ByproductBalance")

# Sales limit for by-product C
m.addConstr(cSold <= max_c_sales, "MaxCSales")

# Tiered disposal cost logic
m.addConstr(cDispLow <= threshold_c, "DispLowCap")
m.addConstr(cDispLow >= threshold_c * z, "DispLowMinIfHigh")
m.addConstr(cDispHigh <= bigM * z, "DispHighOnlyIfZ")

# Solve
m.optimize()

# Output the required single line
print(f"FINAL_OBJ_VALUE: {m.objVal}")
