import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, "table_1.csv")
    products = {}
    with open(table1_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row["Item"].strip()
            products[item] = {
                "machine_time": float(row["Machine_Time_minutes"].strip()),
                "craftsman_time": float(row["Craftsman_Time_minutes"].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "general_parameters.csv")
    params = {}
    with open(params_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    # Extract parameters
    machine_avail = params["machine_time_available"]          # hours
    craftsman_regular_avail = params["craftsman_regular_time_available"]  # hours
    craftsman_overtime_avail = params["craftsman_overtime_available"]    # hours
    machine_cost_per_hour = params["machine_time_cost"]
    craftsman_regular_cost_per_hour = params["craftsman_time_cost"]
    craftsman_overtime_cost_per_hour = params["craftsman_overtime_cost"]
    rev_X = params["revenue_product_X"]
    rev_Y = params["revenue_product_Y"]
    min_X = params["min_batches_product_X"]
    Y_QA_threshold = params["product_Y_QA_threshold"]
    Y_QA_fee = params["product_Y_QA_fee"]
    
    # Time per batch in minutes
    mach_min_X = products["X"]["machine_time"]
    mach_min_Y = products["Y"]["machine_time"]
    craft_min_X = products["X"]["craftsman_time"]
    craft_min_Y = products["Y"]["craftsman_time"]
    
    # Create model
    m = gp.Model("Production_Planning_Revised")
    m.setParam("OutputFlag", 0)
    
    # Decision variables
    X = m.addVar(lb=min_X, name="X")                     # batches of X
    Y = m.addVar(lb=0, name="Y")                         # batches of Y
    reg_hrs = m.addVar(lb=0, ub=craftsman_regular_avail, name="reg_hrs")   # regular craftsman hours used
    ovt_hrs = m.addVar(lb=0, ub=craftsman_overtime_avail, name="ovt_hrs")  # overtime craftsman hours used
    z = m.addVar(vtype=GRB.BINARY, name="z")             # 1 if Y > QA threshold
    
    # Machine time constraint (hours)
    m.addConstr((mach_min_X * X + mach_min_Y * Y) / 60.0 <= machine_avail, "Machine_Time")
    
    # Craftsman time balance: total craftsman minutes converted to hours must equal sum of regular and overtime hours
    m.addConstr(reg_hrs + ovt_hrs == (craft_min_X * X + craft_min_Y * Y) / 60.0, "Craftsman_Balance")
    
    # QA tier constraint: Y <= threshold + M * z, with M large enough
    # Maximum possible Y from machine time: 40*60/19 ≈ 126.3, from craftsman: 35*60/29 ≈ 72.4, so 1000 is safe
    M = 1000
    m.addConstr(Y <= Y_QA_threshold + M * z, "QA_Tier")
    
    # Objective: maximize profit = revenue - costs
    revenue = rev_X * X + rev_Y * Y
    machine_cost = machine_cost_per_hour * (mach_min_X * X + mach_min_Y * Y) / 60.0
    craftsman_cost = craftsman_regular_cost_per_hour * reg_hrs + craftsman_overtime_cost_per_hour * ovt_hrs
    qa_cost = Y_QA_fee * z
    
    m.setObjective(revenue - machine_cost - craftsman_cost - qa_cost, GRB.MAXIMIZE)
    
    # Solve
    m.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {m.objVal:.2f}")

if __name__ == "__main__":
    main()
