import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_demand(filepath):
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    return params

def main():
    # Paths relative to this script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    demand = load_demand(os.path.join(data_dir, "table_1.csv"))
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    # Extract parameters
    shift_duration = int(params['shift_duration'])  # 8 hours
    regular_pay = float(params['regular_nurse_pay'])  # 10 yuan/hour
    contract_pay = float(params['contract_nurse_pay'])  # 15 yuan/hour
    outsourced_regular_start = int(params['outsourced_regular_start_index'])  # 2
    banned_contract_start = int(params['banned_contract_start_index'])  # 5
    max_contract_starts = int(params['max_total_contract_starts'])  # 20
    min_regular_daytime = int(params['min_regular_daytime_coverage'])  # 8
    daytime_indices = [int(i) for i in params['daytime_period_indices'].split(';')]  # [1,2,3,4]
    
    num_periods = len(demand)  # 6
    periods_per_shift = shift_duration // 4  # 2
    
    # Cost per nurse per shift
    cost_regular = regular_pay * shift_duration  # 80
    cost_contract = contract_pay * shift_duration  # 120
    
    # Create model
    model = gp.Model("NurseScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(num_periods, lb=0, vtype=GRB.INTEGER, name="regular")
    y = model.addVars(num_periods, lb=0, vtype=GRB.INTEGER, name="contract")
    
    # Constraints: regular nurses cannot start at outsourced shift (10:00, index 2)
    model.addConstr(x[outsourced_regular_start] == 0, name="no_regular_outsourced")
    
    # Contract nurses cannot start at banned shift (22:00, index 5)
    model.addConstr(y[banned_contract_start] == 0, name="no_contract_overnight")
    
    # Coverage constraints: for each period i, sum of nurses from shifts covering i >= demand[i]
    # Shift j covers periods j and (j+1) % num_periods
    for i in range(num_periods):
        # Shifts that cover period i: shift i (covers i and i+1) and shift (i-1) mod 6 (covers i-1 and i)
        covering_shifts = [i, (i - 1) % num_periods]
        model.addConstr(
            gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i],
            name=f"demand_period_{i}"
        )
    
    # Daytime regular coverage: for each daytime period, regular nurses on duty >= min_regular_daytime
    for i in daytime_indices:
        covering_shifts = [i, (i - 1) % num_periods]
        model.addConstr(
            gp.quicksum(x[j] for j in covering_shifts) >= min_regular_daytime,
            name=f"regular_daytime_period_{i}"
        )
    
    # Total contract starts cap
    model.addConstr(
        gp.quicksum(y[j] for j in range(num_periods)) <= max_contract_starts,
        name="max_contract_starts"
    )
    
    # Objective: minimize total cost
    model.setObjective(
        gp.quicksum(cost_regular * x[j] + cost_contract * y[j] for j in range(num_periods)),
        GRB.MINIMIZE
    )
    
    # Solve
    model.optimize()
    
    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of infeasibility or other issues, print a default message
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
