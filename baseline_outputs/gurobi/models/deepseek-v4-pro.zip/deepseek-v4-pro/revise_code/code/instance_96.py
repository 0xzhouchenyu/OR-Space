import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_paths():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    return table_1_path, params_path

def generate_patterns(raw_length, max_cuts, max_leftover, lengths):
    """Generate all feasible cutting patterns for a given raw pipe."""
    n = len(lengths)
    min_length = raw_length - max_leftover
    patterns = []

    def recurse(idx, current_counts, current_length, current_cuts):
        if idx == n:
            if current_cuts > 0 and current_length >= min_length and current_length <= raw_length:
                patterns.append(tuple(current_counts))
            return
        # maximum number of this item we can add
        max_qty = min(
            (raw_length - current_length) // lengths[idx],
            max_cuts - current_cuts
        )
        for q in range(max_qty + 1):
            recurse(idx + 1,
                    current_counts + [q],
                    current_length + q * lengths[idx],
                    current_cuts + q)

    recurse(0, [], 0, 0)
    return patterns

def solve():
    table_1_path, params_path = get_data_paths()

    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    params = {}
    for _, row in df_params.iterrows():
        params[row['Parameter_Name']] = row['Value']

    # Items
    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)

    # Supplier 1 parameters
    raw_len_s1 = float(params['raw_pipe_length_supplier1'])
    max_cuts_s1 = int(params['max_cuts_per_pipe_supplier1'])
    max_leftover_s1 = float(params['max_leftover_length_supplier1'])
    max_pat_s1 = int(params['max_cutting_patterns_supplier1'])
    cost_rates_s1 = [
        float(params['most_frequent_pattern_cost_rate_supplier1']),
        float(params['second_frequent_pattern_cost_rate_supplier1']),
        float(params['third_frequent_pattern_cost_rate_supplier1'])
    ]
    purchase_cost_s1 = float(params['purchase_cost_per_pipe_supplier1'])
    discount_tier1_max = int(params['discount_tier1_supplier1_max_qty'])
    fixed_discount = float(params['fixed_discount_tier2_supplier1'])
    bigM_discount = float(params['bigM_discount'])

    # Supplier 2 parameters
    raw_len_s2 = float(params['raw_pipe_length_supplier2'])
    max_cuts_s2 = int(params['max_cuts_per_pipe_supplier2'])
    max_leftover_s2 = float(params['max_leftover_length_supplier2'])
    max_pat_s2 = int(params['max_cutting_patterns_supplier2'])
    cost_rates_s2 = [
        float(params['most_frequent_pattern_cost_rate_supplier2']),
        float(params['second_frequent_pattern_cost_rate_supplier2']),
        float(params['third_frequent_pattern_cost_rate_supplier2'])
    ]
    purchase_cost_s2 = float(params['purchase_cost_per_pipe_supplier2'])

    # Generate patterns for each supplier
    patterns_s1 = generate_patterns(raw_len_s1, max_cuts_s1, max_leftover_s1, lengths)
    patterns_s2 = generate_patterns(raw_len_s2, max_cuts_s2, max_leftover_s2, lengths)

    # Big M for y <= M * z
    M = sum(demands)  # safe upper bound on number of pipes used

    # Model
    model = gp.Model("PipeCuttingTwoSuppliers")
    model.setParam('OutputFlag', 0)

    # Variables for supplier 1
    y1 = model.addVars(len(patterns_s1), lb=0, vtype=GRB.INTEGER, name="y1")
    z1 = model.addVars(len(patterns_s1), vtype=GRB.BINARY, name="z1")
    u1 = model.addVars(max_pat_s1, vtype=GRB.BINARY, name="u1")  # indices 0..max_pat_s1-1

    # Variables for supplier 2
    y2 = model.addVars(len(patterns_s2), lb=0, vtype=GRB.INTEGER, name="y2")
    z2 = model.addVars(len(patterns_s2), vtype=GRB.BINARY, name="z2")
    u2 = model.addVars(max_pat_s2, vtype=GRB.BINARY, name="u2")  # indices 0..max_pat_s2-1

    # Discount binary for supplier 1
    d = model.addVar(vtype=GRB.BINARY, name="discount_active")

    # Demand constraints
    for i in range(n_items):
        expr = gp.quicksum(patterns_s1[p][i] * y1[p] for p in range(len(patterns_s1))) \
               + gp.quicksum(patterns_s2[p][i] * y2[p] for p in range(len(patterns_s2)))
        model.addConstr(expr >= demands[i], name=f"demand_{i}")

    # Link y and z for supplier 1
    for p in range(len(patterns_s1)):
        model.addConstr(y1[p] <= M * z1[p], name=f"link_yz1_{p}")

    # Link y and z for supplier 2
    for p in range(len(patterns_s2)):
        model.addConstr(y2[p] <= M * z2[p], name=f"link_yz2_{p}")

    # Pattern count constraints per supplier
    model.addConstr(gp.quicksum(z1) <= max_pat_s1, name="max_pat_s1")
    model.addConstr(gp.quicksum(z2) <= max_pat_s2, name="max_pat_s2")

    # u variables: sum z = sum u, and ordering u_k >= u_{k+1}
    model.addConstr(gp.quicksum(z1) == gp.quicksum(u1[k] for k in range(max_pat_s1)), name="sum_z1_u1")
    for k in range(max_pat_s1 - 1):
        model.addConstr(u1[k] >= u1[k+1], name=f"order_u1_{k}")

    model.addConstr(gp.quicksum(z2) == gp.quicksum(u2[k] for k in range(max_pat_s2)), name="sum_z2_u2")
    for k in range(max_pat_s2 - 1):
        model.addConstr(u2[k] >= u2[k+1], name=f"order_u2_{k}")

    # Total pipes from supplier 1
    total_s1 = gp.quicksum(y1[p] for p in range(len(patterns_s1)))
    # Discount activation: d=1 if total_s1 > discount_tier1_max
    model.addConstr(total_s1 <= discount_tier1_max + bigM_discount * d, name="discount_upper")
    model.addConstr(total_s1 >= discount_tier1_max + 1 - bigM_discount * (1 - d), name="discount_lower")

    # Objective
    purchase_cost = purchase_cost_s1 * total_s1 + purchase_cost_s2 * gp.quicksum(y2[p] for p in range(len(patterns_s2)))
    extra_cost_s1 = gp.quicksum(cost_rates_s1[k] * u1[k] for k in range(max_pat_s1))
    extra_cost_s2 = gp.quicksum(cost_rates_s2[k] * u2[k] for k in range(max_pat_s2))
    discount_amount = fixed_discount * d

    model.setObjective(purchase_cost + extra_cost_s1 + extra_cost_s2 - discount_amount, GRB.MINIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
