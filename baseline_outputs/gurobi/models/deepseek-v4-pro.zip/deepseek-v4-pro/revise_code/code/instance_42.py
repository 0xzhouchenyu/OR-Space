import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Path to data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Extract parameters
    a = params['a']                             # hours per batch, method 1
    b = params['b']                             # hours per batch, method 2
    k = params['k']                             # tons per batch
    d = params['d']                             # minimum total production (tons)
    c_offpeak = params['c_offpeak']             # max off-peak hours per furnace
    c_peak = params['c_peak']                   # max peak hours per furnace
    cap_offpeak = params['cap_offpeak']         # plant-wide max off-peak hours
    cap_peak = params['cap_peak']               # plant-wide max peak hours
    m_offpeak = params['m_offpeak']             # cost per batch, method 1 off-peak
    n_offpeak = params['n_offpeak']             # cost per batch, method 2 off-peak
    m_peak = params['m_peak']                   # cost per batch, method 1 peak
    n_peak = params['n_peak']                   # cost per batch, method 2 peak
    f_offpeak = params['f_offpeak']             # fixed cost if furnace used off-peak
    f_peak = params['f_peak']                   # fixed cost if furnace used peak
    threshold = int(params['offpeak_cooldown_batch_threshold'])  # off-peak batch limit before cooldown
    cooldown_fee = params['offpeak_cooldown_fee']                # cooldown cost per furnace exceeding threshold

    # Create model
    model = gp.Model("SteelFurnace_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[i, j, p] = number of batches on furnace i (0,1) with method j (0: method1, 1: method2) in period p ('offpeak','peak')
    x = {}
    for i in range(2):
        for j in range(2):
            for p in ['offpeak', 'peak']:
                x[i, j, p] = model.addVar(vtype=GRB.INTEGER, name=f"x_{i}_{j}_{p}", lb=0)

    # y[i, p] = 1 if furnace i is used in period p
    y = {}
    for i in range(2):
        for p in ['offpeak', 'peak']:
            y[i, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{p}")

    # z[i] = 1 if furnace i exceeds off-peak cooldown threshold
    z = {}
    for i in range(2):
        z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{i}")

    # Objective: minimize total cost
    fuel_cost = gp.quicksum(
        (m_offpeak if p == 'offpeak' else m_peak) * x[i, 0, p] +
        (n_offpeak if p == 'offpeak' else n_peak) * x[i, 1, p]
        for i in range(2) for p in ['offpeak', 'peak']
    )
    fixed_cost = gp.quicksum(
        (f_offpeak if p == 'offpeak' else f_peak) * y[i, p]
        for i in range(2) for p in ['offpeak', 'peak']
    )
    cooldown_cost = gp.quicksum(cooldown_fee * z[i] for i in range(2))

    model.setObjective(fuel_cost + fixed_cost + cooldown_cost, GRB.MINIMIZE)

    # Constraints
    # 1. Time capacity per furnace per period
    for i in range(2):
        model.addConstr(a * x[i, 0, 'offpeak'] + b * x[i, 1, 'offpeak'] <= c_offpeak,
                        name=f"time_f{i}_offpeak")
        model.addConstr(a * x[i, 0, 'peak'] + b * x[i, 1, 'peak'] <= c_peak,
                        name=f"time_f{i}_peak")

    # 2. Plant-wide time caps per period
    model.addConstr(gp.quicksum(a * x[i, 0, 'offpeak'] + b * x[i, 1, 'offpeak'] for i in range(2)) <= cap_offpeak,
                    name="plant_offpeak")
    model.addConstr(gp.quicksum(a * x[i, 0, 'peak'] + b * x[i, 1, 'peak'] for i in range(2)) <= cap_peak,
                    name="plant_peak")

    # 3. Minimum production requirement
    model.addConstr(k * gp.quicksum(x[i, j, p] for i in range(2) for j in range(2) for p in ['offpeak', 'peak']) >= d,
                    name="min_production")

    # 4. Fixed activation overhead: link x and y
    M_act = 10  # safe upper bound on batches per furnace per period
    for i in range(2):
        for p in ['offpeak', 'peak']:
            model.addConstr(gp.quicksum(x[i, j, p] for j in range(2)) <= M_act * y[i, p],
                            name=f"activate_{i}_{p}")

    # 5. Refractory cooldown rule: if off-peak batches > threshold, incur fee
    M_c = 10  # upper bound on off-peak batches per furnace
    for i in range(2):
        off_i = gp.quicksum(x[i, j, 'offpeak'] for j in range(2))
        model.addConstr(off_i <= threshold + M_c * z[i], name=f"cooldown_ub_{i}")
        model.addConstr(off_i >= (threshold + 1) * z[i], name=f"cooldown_lb_{i}")

    # Solve
    model.optimize()

    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Fallback in case of unexpected status
        print(f"FINAL_OBJ_VALUE: {model.objVal if hasattr(model, 'objVal') else 'N/A'}")

if __name__ == "__main__":
    main()
