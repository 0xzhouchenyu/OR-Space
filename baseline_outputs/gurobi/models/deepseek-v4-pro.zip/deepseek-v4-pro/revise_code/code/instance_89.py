import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params


def main():
    # Path to data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Extract parameters
    profit_A = params['profit_per_kg_product_A']
    profit_B = params['profit_per_kg_product_B']
    hours_A = params['hours_per_kg_product_A']
    hours_B = params['hours_per_kg_product_B']
    max_hours_week1 = params['max_production_hours_week_1']
    max_hours_week2 = params['max_production_hours_week_2']
    min_ratio = params['min_output_ratio_product_B_to_A']
    storage_ratio = params['storage_space_ratio_product_A_to_B']
    max_storage_A_equiv_week1 = params['max_storage_product_A_equiv_week_1']
    max_storage_A_equiv_week2 = params['max_storage_product_A_equiv_week_2']
    init_inv_A = params['initial_inventory_A']
    init_inv_B = params['initial_inventory_B']
    storage_cost_A = params['storage_cost_per_kg_A']
    storage_cost_B = params['storage_cost_per_kg_B']
    promo_bonus_A = params['promo_profit_bonus_A']
    promo_bonus_B = params['promo_profit_bonus_B']
    max_promo_A = int(params['max_promotions_product_A'])
    max_promo_B = int(params['max_promotions_product_B'])

    weeks = [1, 2]
    products = ['A', 'B']

    max_hours = {1: max_hours_week1, 2: max_hours_week2}
    max_storage_A_equiv = {1: max_storage_A_equiv_week1, 2: max_storage_A_equiv_week2}
    init_inv = {'A': init_inv_A, 'B': init_inv_B}
    storage_cost = {'A': storage_cost_A, 'B': storage_cost_B}
    promo_bonus = {'A': promo_bonus_A, 'B': promo_bonus_B}
    max_promo = {'A': max_promo_A, 'B': max_promo_B}
    base_profit = {'A': profit_A, 'B': profit_B}
    hours = {'A': hours_A, 'B': hours_B}

    # Model
    m = gp.Model("LiquidProductsTwoWeek")
    m.setParam('OutputFlag', 0)

    # Decision variables
    prod = m.addVars(weeks, products, name="prod", lb=0)
    sales = m.addVars(weeks, products, name="sales", lb=0)
    inv_end = m.addVars(weeks, products, name="inv_end", lb=0)  # inventory at end of week t
    promo = m.addVars(weeks, products, name="promo", vtype=GRB.BINARY)

    # Constraints
    # Inventory balance
    for p in products:
        m.addConstr(inv_end[1, p] == init_inv[p] + prod[1, p] - sales[1, p], f"inv_bal_1_{p}")
        m.addConstr(inv_end[2, p] == inv_end[1, p] + prod[2, p] - sales[2, p], f"inv_bal_2_{p}")

    # Production hours
    for t in weeks:
        m.addConstr(hours['A'] * prod[t, 'A'] + hours['B'] * prod[t, 'B'] <= max_hours[t], f"prod_hours_{t}")

    # Market demand ratio on sales (output = sales)
    for t in weeks:
        m.addConstr(sales[t, 'B'] >= min_ratio * sales[t, 'A'], f"market_demand_{t}")

    # Storage capacity (space units: storage_ratio * inv_A + 1 * inv_B <= storage_ratio * max_storage_A_equiv)
    for t in weeks:
        m.addConstr(storage_ratio * inv_end[t, 'A'] + inv_end[t, 'B'] <= storage_ratio * max_storage_A_equiv[t], f"storage_{t}")

    # Promotion limits
    m.addConstr(gp.quicksum(promo[t, 'A'] for t in weeks) <= max_promo['A'], "max_promo_A")
    m.addConstr(gp.quicksum(promo[t, 'B'] for t in weeks) <= max_promo['B'], "max_promo_B")

    # Objective: profit from sales (base + promo bonus) minus holding cost on inventory carried from week 1 to week 2
    revenue = gp.quicksum(
        (base_profit[p] + promo_bonus[p] * promo[t, p]) * sales[t, p]
        for t in weeks for p in products
    )
    holding_cost = gp.quicksum(
        storage_cost[p] * inv_end[1, p] for p in products
    )
    m.setObjective(revenue - holding_cost, GRB.MAXIMIZE)

    m.optimize()

    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal:.3f}")
    else:
        print("No optimal solution found.")


if __name__ == "__main__":
    main()
