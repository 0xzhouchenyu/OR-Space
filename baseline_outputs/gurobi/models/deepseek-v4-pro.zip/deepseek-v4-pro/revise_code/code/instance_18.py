import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Determine data directory relative to this script
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Extract parameters
weekly_production_time = params["weekly_production_time"]           # 110 hours
fabric_production_rate = params["fabric_production_rate"]           # 1000 meters/hour
min_curtain_fabric_sales = params["min_curtain_fabric_sales"]       # 70000 meters
min_clothing_fabric_sales = params["min_clothing_fabric_sales"]     # 45000 meters
day_shift_regular_capacity = params["day_shift_regular_capacity"]   # 60 hours
night_shift_regular_capacity = params["night_shift_regular_capacity"] # 60 hours
day_overtime_limit = params["day_overtime_limit"]                   # 3 hours
night_overtime_limit = params["night_overtime_limit"]               # 3 hours
day_overtime_penalty = params["day_overtime_penalty"]               # 1.0 yuan/hour
night_overtime_penalty = params["night_overtime_penalty"]           # 1.5 yuan/hour
day_min_utilization_ratio = params["day_min_utilization_ratio"]     # 0.45
night_min_utilization_ratio = params["night_min_utilization_ratio"] # 0.45

# Convert sales requirements to production hours
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate  # 45 hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate    # 70 hours

# Create optimization model
model = gp.Model("Textile_Factory_Shift_Overtime")
model.setParam("OutputFlag", 0)

# Decision variables
cloth_hrs = model.addVar(lb=min_clothing_hours, name="clothing_hours")
curt_hrs = model.addVar(lb=min_curtain_hours, name="curtain_hours")
day_reg = model.addVar(lb=0, ub=day_shift_regular_capacity, name="day_regular")
night_reg = model.addVar(lb=0, ub=night_shift_regular_capacity, name="night_regular")
day_ot = model.addVar(lb=0, ub=day_overtime_limit, name="day_overtime")
night_ot = model.addVar(lb=0, ub=night_overtime_limit, name="night_overtime")

# Constraints
# Total production must equal total worked hours (regular + overtime)
model.addConstr(cloth_hrs + curt_hrs == day_reg + night_reg + day_ot + night_ot, "Total_Production")

# Fully utilize the weekly production time as total regular hours
model.addConstr(day_reg + night_reg == weekly_production_time, "Total_Regular")

# Minimum utilization ratios for each shift based on total regular hours
model.addConstr(day_reg >= day_min_utilization_ratio * (day_reg + night_reg), "Day_Min_Util")
model.addConstr(night_reg >= night_min_utilization_ratio * (day_reg + night_reg), "Night_Min_Util")

# Objective: minimize total overtime penalty cost
model.setObjective(day_ot * day_overtime_penalty + night_ot * night_overtime_penalty, GRB.MINIMIZE)

# Solve
model.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
