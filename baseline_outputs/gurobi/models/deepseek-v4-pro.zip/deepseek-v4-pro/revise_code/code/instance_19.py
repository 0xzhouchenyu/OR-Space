import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            try:
                value = int(value_str)
            except ValueError:
                try:
                    value = float(value_str)
                except ValueError:
                    value = value_str
            params[name] = value
    return params

# Paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
cost_A = params['cost_per_chair_A']
cost_B = params['cost_per_chair_B']
cost_C = params['cost_per_chair_C']
chairs_per_order_A = int(params['chairs_per_order_A'])
chairs_per_order_B = int(params['chairs_per_order_B'])
chairs_per_order_C = int(params['chairs_per_order_C'])
min_total = params['min_total_chairs']
max_total = params['max_total_chairs']
min_chairs_B_if_A = params['min_chairs_B_if_A']
dependency_B_C = int(params['dependency_B_C'])  # 1 if B requires C
fixed_fee_A_reg = params['fixed_fee_A_regular']
fixed_fee_A_exp = params['fixed_fee_A_express']
fixed_fee_B_reg = params['fixed_fee_B_regular']
fixed_fee_B_exp = params['fixed_fee_B_express']
fixed_fee_C_reg = params['fixed_fee_C_regular']
fixed_fee_C_exp = params['fixed_fee_C_express']
weekly_order_budget = int(params['weekly_order_budget'])

# Big M for linking orders to usage
max_orders_A = max_total // chairs_per_order_A + 1
max_orders_B = max_total // chairs_per_order_B + 1
max_orders_C = max_total // chairs_per_order_C + 1
M_A = max_orders_A
M_B = max_orders_B
M_C = max_orders_C

# Create model
model = gp.Model("FurnitureOrderRevised")
model.setParam('OutputFlag', 0)

# Decision variables: number of orders
x_A = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_A, name="orders_A")
x_B = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_B, name="orders_B")
x_C = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_C, name="orders_C")

# Binary variables for manufacturer usage (any mode)
y_A = model.addVar(vtype=GRB.BINARY, name="use_A")
y_B = model.addVar(vtype=GRB.BINARY, name="use_B")
y_C = model.addVar(vtype=GRB.BINARY, name="use_C")

# Binary variables for mode selection (regular or express)
y_A_reg = model.addVar(vtype=GRB.BINARY, name="A_regular")
y_A_exp = model.addVar(vtype=GRB.BINARY, name="A_express")
y_B_reg = model.addVar(vtype=GRB.BINARY, name="B_regular")
y_B_exp = model.addVar(vtype=GRB.BINARY, name="B_express")
y_C_reg = model.addVar(vtype=GRB.BINARY, name="C_regular")
y_C_exp = model.addVar(vtype=GRB.BINARY, name="C_express")

# Total chairs
chairs_A = chairs_per_order_A * x_A
chairs_B = chairs_per_order_B * x_B
chairs_C = chairs_per_order_C * x_C

# Objective: minimize total cost (chairs + fixed fees)
total_cost = (cost_A * chairs_A + cost_B * chairs_B + cost_C * chairs_C +
              fixed_fee_A_reg * y_A_reg + fixed_fee_A_exp * y_A_exp +
              fixed_fee_B_reg * y_B_reg + fixed_fee_B_exp * y_B_exp +
              fixed_fee_C_reg * y_C_reg + fixed_fee_C_exp * y_C_exp)
model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints

# Total chairs bounds
model.addConstr(chairs_A + chairs_B + chairs_C >= min_total, "MinChairs")
model.addConstr(chairs_A + chairs_B + chairs_C <= max_total, "MaxChairs")

# Link orders to usage: if y_i = 1 then x_i >= 1; if y_i = 0 then x_i = 0
model.addConstr(x_A <= M_A * y_A, "LinkA_ub")
model.addConstr(x_A >= y_A, "LinkA_lb")
model.addConstr(x_B <= M_B * y_B, "LinkB_ub")
model.addConstr(x_B >= y_B, "LinkB_lb")
model.addConstr(x_C <= M_C * y_C, "LinkC_ub")
model.addConstr(x_C >= y_C, "LinkC_lb")

# Mode selection: y_i = y_i_reg + y_i_exp, and at most one mode per manufacturer
model.addConstr(y_A == y_A_reg + y_A_exp, "ModeA_sum")
model.addConstr(y_B == y_B_reg + y_B_exp, "ModeB_sum")
model.addConstr(y_C == y_C_reg + y_C_exp, "ModeC_sum")
# The sum of two binaries automatically enforces at most one if we also have y_i binary,
# but to be safe we can add constraints y_i_reg + y_i_exp <= 1 (redundant given y_i binary and equality)
model.addConstr(y_A_reg + y_A_exp <= 1, "ModeA_exclusive")
model.addConstr(y_B_reg + y_B_exp <= 1, "ModeB_exclusive")
model.addConstr(y_C_reg + y_C_exp <= 1, "ModeC_exclusive")

# Weekly order budget: total active manufacturer-mode combinations <= budget
model.addConstr(y_A + y_B + y_C <= weekly_order_budget, "Budget")

# Dependency: if A is used, at least min_chairs_B_if_A chairs from B
model.addConstr(chairs_B >= min_chairs_B_if_A * y_A, "DepAB")

# Dependency: if B is used, C must be used (y_B <= y_C)
model.addConstr(y_B <= y_C, "DepBC")

# Solve
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of infeasibility or other status, print a default
    print(f"FINAL_OBJ_VALUE: {None}")
