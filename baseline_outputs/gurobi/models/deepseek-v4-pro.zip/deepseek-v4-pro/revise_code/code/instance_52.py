import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    n = len(shifts)  # 6 periods
    required = [s['required'] for s in shifts]
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    
    shift_duration = int(params['shift_duration'])  # 8 hours
    driver_rest_gap = int(params['driver_rest_gap'])  # 2
    crew_rest_gap = int(params['crew_rest_gap'])  # 1
    max_night_driver_fraction = float(params['max_night_driver_fraction'])  # 0.4
    max_night_crew_fraction = float(params['max_night_crew_fraction'])  # 0.5
    max_overtime_shifts = int(params['max_overtime_shifts'])  # 20
    overtime_cost_factor = float(params['overtime_cost_factor'])  # 1.5
    
    # Each time period is 4 hours, shift_duration is 8 hours = 2 periods
    periods_per_shift = shift_duration // 4  # = 2
    
    # Period indices: 0 to 5 corresponding to shifts 1..6
    # Night periods: 4 (22:00-2:00) and 5 (2:00-6:00)
    night_periods = [4, 5]
    
    # Feeding periods for rest gap constraints:
    # For drivers (rest_gap=2): feeding periods are 0 and 1
    # For crew (rest_gap=1): feeding periods are 1 and 2
    driver_feed_periods = [0, 1]
    crew_feed_periods = [1, 2]
    
    # Create model
    m = gp.Model("BusScheduling")
    m.setParam('OutputFlag', 0)
    
    # Decision variables: regular and overtime starts for drivers and crew
    # Drivers
    R_d = m.addVars(n, vtype=GRB.INTEGER, name="R_d", lb=0)
    O_d = m.addVars(n, vtype=GRB.INTEGER, name="O_d", lb=0)
    # Crew
    R_c = m.addVars(n, vtype=GRB.INTEGER, name="R_c", lb=0)
    O_c = m.addVars(n, vtype=GRB.INTEGER, name="O_c", lb=0)
    
    # Coverage constraints: for each period j, sum of shifts covering j >= required[j]
    for j in range(n):
        # Find starting periods that cover period j
        covering = []
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                covering.append(i)
        # Driver coverage
        m.addConstr(
            gp.quicksum(R_d[i] + O_d[i] for i in covering) >= required[j],
            f"DriverCoverage_{j}"
        )
        # Crew coverage
        m.addConstr(
            gp.quicksum(R_c[i] + O_c[i] for i in covering) >= required[j],
            f"CrewCoverage_{j}"
        )
    
    # Night fraction constraints
    # Drivers: night starts <= fraction * total starts
    total_driver_starts = gp.quicksum(R_d[i] + O_d[i] for i in range(n))
    night_driver_starts = gp.quicksum(R_d[i] + O_d[i] for i in night_periods)
    m.addConstr(
        night_driver_starts <= max_night_driver_fraction * total_driver_starts,
        "NightFractionDrivers"
    )
    # Crew
    total_crew_starts = gp.quicksum(R_c[i] + O_c[i] for i in range(n))
    night_crew_starts = gp.quicksum(R_c[i] + O_c[i] for i in night_periods)
    m.addConstr(
        night_crew_starts <= max_night_crew_fraction * total_crew_starts,
        "NightFractionCrew"
    )
    
    # Rest gap constraints (aggregate proxy)
    # Drivers: night_starts <= feed_starts - driver_rest_gap
    driver_feed_starts = gp.quicksum(R_d[i] + O_d[i] for i in driver_feed_periods)
    m.addConstr(
        night_driver_starts <= driver_feed_starts - driver_rest_gap,
        "RestGapDrivers"
    )
    # Crew: night_starts <= feed_starts - crew_rest_gap
    crew_feed_starts = gp.quicksum(R_c[i] + O_c[i] for i in crew_feed_periods)
    m.addConstr(
        night_crew_starts <= crew_feed_starts - crew_rest_gap,
        "RestGapCrew"
    )
    
    # Overtime limit: total overtime shifts (drivers + crew) <= max_overtime_shifts
    total_overtime = gp.quicksum(O_d[i] + O_c[i] for i in range(n))
    m.addConstr(total_overtime <= max_overtime_shifts, "OvertimeLimit")
    
    # Objective: minimize regular starts + overtime_cost_factor * overtime starts
    total_regular = gp.quicksum(R_d[i] + R_c[i] for i in range(n))
    total_overtime_cost = overtime_cost_factor * total_overtime
    m.setObjective(total_regular + total_overtime_cost, GRB.MINIMIZE)
    
    # Solve
    m.optimize()
    
    # Output
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        # In case of infeasibility or other issues, print a message (though problem should be feasible)
        print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    main()
