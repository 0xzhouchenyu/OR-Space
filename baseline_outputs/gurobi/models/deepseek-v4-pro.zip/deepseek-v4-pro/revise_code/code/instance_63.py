import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Extract parameters
produce = params["produce_to_transport"]
horse_poll = params["horse_pollution_per_trip"]
bike_poll = params["bicycle_pollution_per_trip"]
cart_poll = params["handcart_pollution_per_trip"]
max_poll = params["max_total_pollution"]
min_horse = params["min_horse_trips"]
horse_cap = params["horse_capacity_per_trip"]
bike_cap = params["bicycle_capacity_per_trip"]
cart_cap = params["handcart_capacity_per_trip"]
min_produce = params["min_total_produce"]

# Cost parameters
horse_cost_per_trip = params["horse_cost_per_trip"]
bike_cost_per_trip = params["bicycle_cost_per_trip"]
cart_cost_per_trip = params["handcart_cost_per_trip"]
horse_fixed = params["horse_fixed_cost"]
bike_fixed = params["bicycle_fixed_cost"]
cart_fixed = params["handcart_fixed_cost"]
pollution_penalty = params["pollution_penalty_per_unit"]
permit_threshold = params["horse_pollution_permit_threshold"]
permit_fee = params["horse_pollution_permit_fee"]

# Model
model = gp.Model("FarmTransport_Revised")
model.setParam("OutputFlag", 0)

# Decision variables
x_horse = model.addVar(vtype=GRB.INTEGER, name="horse_trips", lb=0)
x_bike = model.addVar(vtype=GRB.INTEGER, name="bike_trips", lb=0)
x_cart = model.addVar(vtype=GRB.INTEGER, name="cart_trips", lb=0)

# Binary variables for usage (to trigger fixed costs)
y_bike = model.addVar(vtype=GRB.BINARY, name="use_bike")
y_cart = model.addVar(vtype=GRB.BINARY, name="use_cart")

# Binary variable for permit fee (1 if total pollution > 600)
z_permit = model.addVar(vtype=GRB.BINARY, name="permit_fee")

# Big-M values
M_trips = 1000  # safe upper bound for trips
M_poll = 1000   # max pollution

# Constraints
# Minimum horse trips
model.addConstr(x_horse >= min_horse, name="min_horse")

# Maximum total pollution
model.addConstr(horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart <= max_poll, name="max_pollution")

# Minimum produce transported
model.addConstr(horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce, name="min_produce")

# Either bicycle or handcart, not both
model.addConstr(y_bike + y_cart <= 1, name="exclusive_choice")

# Link x_bike with y_bike (y_bike = 1 iff x_bike > 0)
model.addConstr(x_bike <= M_trips * y_bike, name="bike_upper")
model.addConstr(y_bike <= x_bike, name="bike_lower")

# Link x_cart with y_cart
model.addConstr(x_cart <= M_trips * y_cart, name="cart_upper")
model.addConstr(y_cart <= x_cart, name="cart_lower")

# Permit threshold: total pollution > 600 triggers fee
total_pollution = horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart
model.addConstr(total_pollution <= permit_threshold + M_poll * z_permit, name="permit_upper")
model.addConstr(total_pollution >= permit_threshold + 1 - M_poll * (1 - z_permit), name="permit_lower")

# Objective: minimize total cost
total_cost = (
    horse_cost_per_trip * x_horse
    + bike_cost_per_trip * x_bike
    + cart_cost_per_trip * x_cart
    + horse_fixed  # horse always used (min 8 trips)
    + bike_fixed * y_bike
    + cart_fixed * y_cart
    + pollution_penalty * total_pollution
    + permit_fee * z_permit
)
model.setObjective(total_cost, GRB.MINIMIZE)

# Solve
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of infeasibility or other issues, print a default
    print("FINAL_OBJ_VALUE: infeasible")
