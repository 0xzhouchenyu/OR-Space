import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load container data
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'])
            params[name] = value

    fixed_setup_cost = params['fixed_setup_cost']
    energy_cost_per_kwh = params['energy_cost_per_kwh']
    max_total_energy_kwh = params['max_total_energy_kwh']
    eco_capacity_share = params['eco_capacity_share']
    eco_overhead_cost = params['eco_overhead_cost']
    regular_energy_intensity = params['regular_energy_intensity_kwh_per_unit']
    eco_energy_intensity = params['eco_energy_intensity_kwh_per_unit']

    n = len(containers)
    M = sum(c['demand'] for c in containers)  # big M

    # Create model
    model = gp.Model("PlasticContainers_Revised")
    model.setParam('OutputFlag', 0)

    # Variables
    y = model.addVars(n, vtype=GRB.BINARY, name="y")  # setup for type i
    z = model.addVars(n, vtype=GRB.BINARY, name="z")  # eco mode activated for type i

    # x_regular[i,j] and x_eco[i,j] for eligible substitutions
    x_reg = {}
    x_eco = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x_reg[i, j] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_reg_{i}_{j}")
                x_eco[i, j] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_eco_{i}_{j}")

    # Objective: variable production cost + energy cost + fixed setup + eco overhead
    var_cost = gp.quicksum(
        containers[i]['cost'] * (x_reg[i, j] + x_eco[i, j])
        for (i, j) in x_reg
    )
    energy_cost = energy_cost_per_kwh * gp.quicksum(
        regular_energy_intensity * x_reg[i, j] + eco_energy_intensity * x_eco[i, j]
        for (i, j) in x_reg
    )
    setup_cost = gp.quicksum(fixed_setup_cost * y[i] for i in range(n))
    eco_overhead = gp.quicksum(eco_overhead_cost * z[i] for i in range(n))

    model.setObjective(var_cost + energy_cost + setup_cost + eco_overhead, GRB.MINIMIZE)

    # Demand constraints
    for j in range(n):
        model.addConstr(
            gp.quicksum(x_reg[i, j] + x_eco[i, j] for i in range(n) if (i, j) in x_reg) >= containers[j]['demand'],
            name=f"demand_{j}"
        )

    # Setup linking: total production of type i <= M * y[i]
    for i in range(n):
        total_i = gp.quicksum(x_reg[i, j] + x_eco[i, j] for j in range(n) if (i, j) in x_reg)
        model.addConstr(total_i <= M * y[i], name=f"setup_{i}")

    # Eco activation: if any eco production, z[i] = 1
    for i in range(n):
        eco_total_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(eco_total_i <= M * z[i], name=f"eco_act_{i}")
        # z[i] can be 1 only if y[i] is 1
        model.addConstr(z[i] <= y[i], name=f"eco_requires_setup_{i}")

    # Eco capacity share: eco production <= eco_capacity_share * total production
    for i in range(n):
        total_i = gp.quicksum(x_reg[i, j] + x_eco[i, j] for j in range(n) if (i, j) in x_reg)
        eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        # eco_i <= eco_capacity_share * total_i
        # equivalent to eco_i - eco_capacity_share * total_i <= 0
        model.addConstr(eco_i - eco_capacity_share * total_i <= 0, name=f"eco_share_{i}")

    # Total energy constraint
    total_energy = gp.quicksum(
        regular_energy_intensity * x_reg[i, j] + eco_energy_intensity * x_eco[i, j]
        for (i, j) in x_reg
    )
    model.addConstr(total_energy <= max_total_energy_kwh, name="energy_limit")

    # Optimize
    model.optimize()

    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Model did not solve to optimality. Status:", model.status)

if __name__ == "__main__":
    main()
