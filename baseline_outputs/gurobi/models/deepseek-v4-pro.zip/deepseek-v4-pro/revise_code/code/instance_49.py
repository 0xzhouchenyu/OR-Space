import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def solve():
    # Load data
    table1 = pd.read_csv(get_data_path("table_1.csv"))
    table2 = pd.read_csv(get_data_path("table_2.csv"))
    params = pd.read_csv(get_data_path("general_parameters.csv"))

    # Parse parameters
    param_dict = dict(zip(params["Parameter_Name"], params["Value"]))
    min_contract_types = int(param_dict["min_contract_types"])
    max_contract_types = int(param_dict["max_contract_types"])
    mutual_exclusion = str(param_dict["mutual_exclusion_1_and_4"]).strip().lower() == "true"
    monthly_max_parallel = int(param_dict["monthly_max_parallel_contracts"])
    min_area_per_contract = int(param_dict["min_area_per_contract_units"])
    activation_fee = float(param_dict["activation_fee_per_contract"])
    onboarding_loss = int(param_dict["onboarding_loss_units"])
    expedited_fee = float(param_dict["expedited_onboarding_fee"])

    # Demand in units of 100 sqm
    demands = {}
    for _, row in table1.iterrows():
        m = int(row["Month"])
        demands[m] = float(row["Required_area_㎡"]) / 100.0

    # Rental costs per 100 sqm for each contract length
    costs = {}
    for _, row in table2.iterrows():
        length = int(row["Contract_length_months"])
        costs[length] = float(row["Rental_fee_per_100㎡_yuan"])

    months = sorted(demands.keys())
    lengths = sorted(costs.keys())
    max_month = max(months)

    # Valid (start, length) pairs
    valid_pairs = [(i, j) for i in months for j in lengths if i + j - 1 <= max_month]

    # Big M for number of contracts
    M_n = monthly_max_parallel * len(months)  # 12

    # Create model
    model = gp.Model("WarehouseRental")
    model.setParam("OutputFlag", 0)

    # Variables
    n = model.addVars(valid_pairs, vtype=GRB.INTEGER, name="n", lb=0)
    e = model.addVars(valid_pairs, vtype=GRB.INTEGER, name="e", lb=0)
    A = model.addVars(valid_pairs, vtype=GRB.INTEGER, name="A", lb=0)
    y = model.addVars(lengths, vtype=GRB.BINARY, name="y")

    # Constraints

    # 1. Demand fulfillment
    for m in months:
        expr = gp.LinExpr()
        for (i, j) in valid_pairs:
            if i == m:
                # start month: usable area = A - (n - e) * loss
                expr += A[i, j] - (n[i, j] - e[i, j]) * onboarding_loss
            elif i < m <= i + j - 1:
                # later month: full area
                expr += A[i, j]
        model.addConstr(expr == demands[m], name=f"demand_month_{m}")

    # 2. Minimum area per contract
    for (i, j) in valid_pairs:
        model.addConstr(A[i, j] >= min_area_per_contract * n[i, j], name=f"min_area_{i}_{j}")

    # 3. Expedited contracts cannot exceed total contracts
    for (i, j) in valid_pairs:
        model.addConstr(e[i, j] <= n[i, j], name=f"exp_limit_{i}_{j}")

    # 4. Monthly maximum parallel contracts
    for m in months:
        active = gp.quicksum(n[i, j] for (i, j) in valid_pairs if i <= m <= i + j - 1)
        model.addConstr(active <= monthly_max_parallel, name=f"max_parallel_month_{m}")

    # 5. Link n to y (contract length used)
    for j in lengths:
        total_n_j = gp.quicksum(n[i, j] for i in months if (i, j) in valid_pairs)
        model.addConstr(total_n_j <= M_n * y[j], name=f"link_y_upper_{j}")
        model.addConstr(total_n_j >= y[j], name=f"link_y_lower_{j}")

    # 6. Contract type count limits
    model.addConstr(gp.quicksum(y[j] for j in lengths) >= min_contract_types, name="min_types")
    model.addConstr(gp.quicksum(y[j] for j in lengths) <= max_contract_types, name="max_types")

    # 7. Mutual exclusion 1-month and 4-month
    if mutual_exclusion and 1 in lengths and 4 in lengths:
        model.addConstr(y[1] + y[4] <= 1, name="mutual_exclusion")

    # Objective: minimize total cost
    total_cost = gp.LinExpr()
    for (i, j) in valid_pairs:
        total_cost += costs[j] * A[i, j]  # rental
        total_cost += activation_fee * n[i, j]  # activation
        total_cost += expedited_fee * e[i, j]  # expedited onboarding
    model.setObjective(total_cost, GRB.MINIMIZE)

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
