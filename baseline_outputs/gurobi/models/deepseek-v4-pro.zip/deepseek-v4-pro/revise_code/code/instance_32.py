import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    workshops = []
    capacities = {}
    rates = {}  # rates[(workshop, component)] = production rate
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    components = [1, 2, 3]
    shifts = ['day', 'night']
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            params[name] = float(row['Value'].strip())
    
    # Extract parameters
    regular_limits_day = {w: params[f'regular_hours_limit_day_{w}'] for w in workshops}
    regular_limits_night = {w: params[f'regular_hours_limit_night_{w}'] for w in workshops}
    overtime_cap_day = {w: params[f'overtime_capacity_day_{w}'] for w in workshops}
    overtime_cap_night = {w: params[f'overtime_capacity_night_{w}'] for w in workshops}
    penalty_night = params['penalty_night_hour']
    penalty_overtime = params['penalty_overtime_hour']
    penalty_shortage = params['penalty_shortage_per_unit']
    z_target = params['z_target']
    bigM = {w: params[f'bigM_shift_{w}'] for w in workshops}
    
    # Create model
    m = gp.Model("Maximize_Net_Products")
    m.setParam('OutputFlag', 0)
    
    # Decision variables: hours per workshop, component, shift, and type (regular/overtime)
    reg_day = {}
    reg_night = {}
    ot_day = {}
    ot_night = {}
    for w in workshops:
        for c in components:
            reg_day[w, c] = m.addVar(lb=0, name=f"reg_day_{w}_{c}")
            reg_night[w, c] = m.addVar(lb=0, name=f"reg_night_{w}_{c}")
            ot_day[w, c] = m.addVar(lb=0, name=f"ot_day_{w}_{c}")
            ot_night[w, c] = m.addVar(lb=0, name=f"ot_night_{w}_{c}")
    
    # z = number of completed products
    z = m.addVar(lb=0, name="z")
    # s = shortfall below target
    s = m.addVar(lb=0, name="shortfall")
    
    # Binary variables: workshop active in a shift
    y = {}
    for w in workshops:
        for shift in shifts:
            y[w, shift] = m.addVar(vtype=GRB.BINARY, name=f"y_{w}_{shift}")
    
    # Constraints
    
    # 1. Regular hours limits per shift
    for w in workshops:
        m.addConstr(gp.quicksum(reg_day[w, c] for c in components) <= regular_limits_day[w],
                    name=f"reg_day_limit_{w}")
        m.addConstr(gp.quicksum(reg_night[w, c] for c in components) <= regular_limits_night[w],
                    name=f"reg_night_limit_{w}")
    
    # 2. Overtime capacity per shift
    for w in workshops:
        m.addConstr(gp.quicksum(ot_day[w, c] for c in components) <= overtime_cap_day[w],
                    name=f"ot_day_limit_{w}")
        m.addConstr(gp.quicksum(ot_night[w, c] for c in components) <= overtime_cap_night[w],
                    name=f"ot_night_limit_{w}")
    
    # 3. Total capacity (original Production_Capacity_hours)
    for w in workshops:
        total_hours = gp.quicksum(reg_day[w, c] + reg_night[w, c] + ot_day[w, c] + ot_night[w, c]
                                  for c in components)
        m.addConstr(total_hours <= capacities[w], name=f"total_capacity_{w}")
    
    # 4. Link active indicator to shift hours (big-M)
    for w in workshops:
        day_hours = gp.quicksum(reg_day[w, c] + ot_day[w, c] for c in components)
        night_hours = gp.quicksum(reg_night[w, c] + ot_night[w, c] for c in components)
        m.addConstr(day_hours <= bigM[w] * y[w, 'day'], name=f"active_day_{w}")
        m.addConstr(night_hours <= bigM[w] * y[w, 'night'], name=f"active_night_{w}")
    
    # 5. At most two workshops active per shift
    for shift in shifts:
        m.addConstr(gp.quicksum(y[w, shift] for w in workshops) <= 2,
                    name=f"max_two_active_{shift}")
    
    # 6. z <= total production of each component
    for c in components:
        total_comp = gp.quicksum(
            rates[w, c] * (reg_day[w, c] + reg_night[w, c] + ot_day[w, c] + ot_night[w, c])
            for w in workshops
        )
        m.addConstr(z <= total_comp, name=f"min_component_{c}")
    
    # 7. Shortfall definition: s >= z_target - z
    m.addConstr(s >= z_target - z, name="shortfall_def")
    
    # Objective: maximize z minus penalties
    total_night_regular = gp.quicksum(reg_night[w, c] for w in workshops for c in components)
    total_overtime = gp.quicksum(ot_day[w, c] + ot_night[w, c] for w in workshops for c in components)
    
    m.setObjective(
        z - penalty_night * total_night_regular - penalty_overtime * total_overtime - penalty_shortage * s,
        GRB.MAXIMIZE
    )
    
    # Solve
    m.optimize()
    
    # Output
    print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    main()
