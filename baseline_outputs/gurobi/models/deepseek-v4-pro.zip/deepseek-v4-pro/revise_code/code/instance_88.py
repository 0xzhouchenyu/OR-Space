import os
import csv
import gurobipy as gp
from gurobipy import GRB

# ----------------------------------------------------------------------
# 1. Load parameters (same logic as original utils)
# ----------------------------------------------------------------------
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract all needed values
m1_liquid = params['machine_1_time_per_liquid_lot']   # 50
m2_liquid = params['machine_2_time_per_liquid_lot']   # 30
m1_solid  = params['machine_1_time_per_solid_lot']    # 24
m2_solid  = params['machine_2_time_per_solid_lot']    # 33

init_liquid = params['initial_liquid_inventory']      # 30
init_solid  = params['initial_solid_inventory']       # 90

m1_base_min = params['machine_1_available_time'] * 60  # 40 h -> 2400 min
m2_base_min = params['machine_2_available_time'] * 60  # 35 h -> 2100 min

demand_liquid = params['forecast_liquid_demand']      # 75
demand_solid  = params['forecast_solid_demand']       # 95

extended_extra_min = params['extended_extra_minutes'] # 600
labor_per_extended = params['labor_hours_per_machine_extended']  # 8 h
labor_budget       = params['labor_budget_hours']               # 10 h
ext_penalty        = params['extended_mode_penalty']            # 0.5
priority_reserve   = params['priority_reserve_lots']            # 10
excess_credit      = params['excess_reserve_credit']            # 0.35

# ----------------------------------------------------------------------
# 2. Build the model
# ----------------------------------------------------------------------
m = gp.Model("Fertilizer_Resilience")
m.setParam('OutputFlag', 0)

# Production variables (continuous, non-negative)
x_l = m.addVar(lb=0, name="x_liquid")
x_s = m.addVar(lb=0, name="x_solid")

# Extended-mode binary decisions
y1 = m.addVar(vtype=GRB.BINARY, name="extend_machine1")
y2 = m.addVar(vtype=GRB.BINARY, name="extend_machine2")

# Ending inventory
end_liquid = init_liquid + x_l - demand_liquid
end_solid  = init_solid  + x_s - demand_solid

# Auxiliary variables for the piecewise linear score
u_l = m.addVar(lb=0, ub=priority_reserve, name="u_liquid")
v_l = m.addVar(lb=0, name="v_liquid")
u_s = m.addVar(lb=0, ub=priority_reserve, name="u_solid")
v_s = m.addVar(lb=0, name="v_solid")

# Link ending inventory to the two segments
m.addConstr(end_liquid == u_l + v_l, "link_liquid")
m.addConstr(end_solid  == u_s + v_s, "link_solid")

# Machine capacity constraints (base + extended extra minutes)
m.addConstr(m1_liquid * x_l + m1_solid * x_s <= m1_base_min + extended_extra_min * y1,
            "machine1_capacity")
m.addConstr(m2_liquid * x_l + m2_solid * x_s <= m2_base_min + extended_extra_min * y2,
            "machine2_capacity")

# Shared skilled-labour budget
m.addConstr(labor_per_extended * y1 + labor_per_extended * y2 <= labor_budget,
            "labour_budget")

# Demand satisfaction (ending inventory must be non-negative)
m.addConstr(end_liquid >= 0, "demand_liquid")
m.addConstr(end_solid  >= 0, "demand_solid")

# Objective: resilience score
score = (u_l + excess_credit * v_l +
         u_s + excess_credit * v_s -
         ext_penalty * (y1 + y2))
m.setObjective(score, GRB.MAXIMIZE)

# ----------------------------------------------------------------------
# 3. Solve and output
# ----------------------------------------------------------------------
m.optimize()

if m.status == GRB.OPTIMAL:
    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")
else:
    # Fallback in case of infeasibility or other issues
    print(f"FINAL_OBJ_VALUE: {m.objVal:.4f}")
