import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_restaurant_data(filepath):
    restaurants = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'std_hours': float(row['Standard_Staff_Hours'].strip()),
                'prem_hours': float(row['Premium_Staff_Hours'].strip())
            })
    return restaurants

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Determine data directory relative to this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load data
    restaurants = load_restaurant_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    budget = params['investment_budget']
    premium_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']
    # restaurant_d_a_constraint presence indicates the constraint is active (value 1)
    
    # Create model
    m = gp.Model("Restaurant_Investment_Revised")
    m.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}  # purchase binary
    y = {}  # premium binary (only if purchased)
    for r in restaurants:
        name = r['name']
        x[name] = m.addVar(vtype=GRB.BINARY, name=f"buy_{name}")
        y[name] = m.addVar(vtype=GRB.BINARY, name=f"premium_{name}")
    
    # Constraints: premium implies purchase
    for r in restaurants:
        name = r['name']
        m.addConstr(y[name] <= x[name], name=f"prem_implies_buy_{name}")
    
    # Budget constraint: purchase cost + premium upgrade cost
    budget_expr = gp.quicksum(r['cost'] * x[r['name']] + premium_upgrade_cost * y[r['name']] for r in restaurants)
    m.addConstr(budget_expr <= budget, name="Budget")
    
    # Staff hours constraint: total premium staff hours
    staff_expr = gp.quicksum(r['prem_hours'] * y[r['name']] for r in restaurants)
    m.addConstr(staff_expr <= staff_hours_cap, name="Staff_Hours")
    
    # Exclusion constraint: if D purchased, A cannot be purchased (symmetric interpretation)
    if 'Restaurant_D' in x and 'Restaurant_A' in x:
        m.addConstr(x['Restaurant_D'] + x['Restaurant_A'] <= 1, name="D_A_Exclusion")
    
    # Objective: maximize total annual revenue
    # Revenue = base revenue if purchased + uplift if premium
    revenue_expr = gp.quicksum(
        r['revenue'] * x[r['name']] + r['revenue'] * premium_uplift * y[r['name']]
        for r in restaurants
    )
    m.setObjective(revenue_expr, GRB.MAXIMIZE)
    
    # Solve
    m.optimize()
    
    # Output final objective value
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        # In case of infeasibility or other, print 0 or handle, but we expect optimal
        print(f"FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
