import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_toy_data(filepath):
    toys = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                'type': row['Toy_Type'].strip(),
                'profit': float(row['Profit_Per_Unit']),
                'wood': float(row['Wood_Required_Per_Unit']),
                'steel': float(row['Steel_Required_Per_Unit']),
            })
    return toys

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load data
    toys = load_toy_data(os.path.join(data_dir, "table_1.csv"))
    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    available_wood = params['available_wood']
    available_steel = params['available_steel']
    profit_premium_bonus = params['profit_premium_bonus']
    premium_steel_factor = params['premium_steel_factor']
    premium_shift_capacity = params['premium_shift_capacity']
    
    # Prepare data structures
    toy_types = [t['type'] for t in toys]
    profit = {t['type']: t['profit'] for t in toys}
    wood = {t['type']: t['wood'] for t in toys}
    steel = {t['type']: t['steel'] for t in toys}
    
    # Big M (safe upper bound on production)
    M = 1000
    
    # Create Gurobi model
    m = gp.Model("HausToys_Revised")
    m.setParam('OutputFlag', 0)
    
    # Decision variables
    x_std = {}   # standard shift production quantity
    x_prem = {}  # premium shift production quantity
    y_std = {}   # 1 if produced on standard shift
    y_prem = {}  # 1 if produced on premium shift
    
    for t in toy_types:
        x_std[t] = m.addVar(lb=0, name=f"x_std_{t}")
        x_prem[t] = m.addVar(lb=0, name=f"x_prem_{t}")
        y_std[t] = m.addVar(vtype=GRB.BINARY, name=f"y_std_{t}")
        y_prem[t] = m.addVar(vtype=GRB.BINARY, name=f"y_prem_{t}")
    
    # Objective: maximize total profit (base profit on all units + premium bonus on premium units)
    total_profit = gp.quicksum(
        profit[t] * (x_std[t] + x_prem[t]) + profit_premium_bonus * x_prem[t]
        for t in toy_types
    )
    m.setObjective(total_profit, GRB.MAXIMIZE)
    
    # Wood constraint (same consumption for both shifts)
    m.addConstr(
        gp.quicksum(wood[t] * (x_std[t] + x_prem[t]) for t in toy_types) <= available_wood,
        "Wood"
    )
    
    # Steel constraint (premium shift uses more steel)
    m.addConstr(
        gp.quicksum(steel[t] * x_std[t] + (steel[t] * premium_steel_factor) * x_prem[t] for t in toy_types) <= available_steel,
        "Steel"
    )
    
    # Premium shift capacity
    m.addConstr(
        gp.quicksum(x_prem[t] for t in toy_types) <= premium_shift_capacity,
        "Premium_Capacity"
    )
    
    # Linking constraints and one-shift-per-toy rule
    for t in toy_types:
        m.addConstr(x_std[t] <= M * y_std[t], f"Link_std_{t}")
        m.addConstr(x_prem[t] <= M * y_prem[t], f"Link_prem_{t}")
        m.addConstr(y_std[t] + y_prem[t] <= 1, f"One_shift_{t}")
    
    # Truck-train exclusion: if any truck, no train (any shift)
    m.addConstr(
        y_std['truck'] + y_prem['truck'] + y_std['train'] + y_prem['train'] <= 1,
        "Truck_Train_Exclusion"
    )
    
    # Boat-airplane dependency: if any boat, then some airplane
    m.addConstr(
        y_std['boat'] + y_prem['boat'] <= y_std['airplane'] + y_prem['airplane'],
        "Boat_Airplane_Dependency"
    )
    
    # Boat-train limit: total boats <= total trains (summed across shifts)
    m.addConstr(
        x_std['boat'] + x_prem['boat'] <= x_std['train'] + x_prem['train'],
        "Boat_Train_Limit"
    )
    
    # Solve
    m.optimize()
    
    # Output
    if m.status == GRB.OPTIMAL:
        obj_val = m.objVal
    else:
        obj_val = 0  # fallback (should not happen with this data)
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
