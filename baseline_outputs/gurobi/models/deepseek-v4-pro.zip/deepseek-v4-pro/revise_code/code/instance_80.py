import os
import csv
import gurobipy as gp
from gurobipy import GRB

# =============================================================================
# Data loading utilities (self-contained)
# =============================================================================
def load_csv(filename):
    """Load a CSV file and return a list of dictionaries."""
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

def load_general_parameters(filename='general_parameters.csv'):
    """Load general parameters into a dictionary."""
    rows = load_csv(filename)
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = row['Value']
        # Try to convert to numeric
        try:
            if '.' in value:
                params[name] = float(value)
            else:
                params[name] = int(value)
        except ValueError:
            params[name] = value
    return params

def load_task_methods(filename='table_1.csv'):
    """Load task-method data."""
    rows = load_csv(filename)
    data = []
    for row in rows:
        data.append({
            'Task': row['Task'],
            'Method': row['Method'],
            'Effective_Hours': float(row['Effective_Hours']),
            'Fixed_Cost': float(row['Fixed_Cost'])
        })
    return data

# =============================================================================
# Load data
# =============================================================================
params = load_general_parameters()
task_methods = load_task_methods()

# Extract parameters
skilled_wage = params['skilled_worker_weekly_wage']          # 110
laborer_wage = params['laborer_weekly_wage']                 # 80
skilled_hours = params['skilled_worker_weekly_hours']        # 42
laborer_hours = params['laborer_weekly_hours']               # 36
max_skilled = params['max_skilled_workers']                  # 430
max_laborers = params['max_laborers']                        # 800
min_skilled_task3_B = params['min_skilled_workers_task3_methodB']  # 20
skilled_hiring_ratio = params['skilled_worker_hiring_ratio'] # 0.6

# Task-level skill share bounds
min_skilled_share = {
    'Task_1': params['min_skilled_share_task1'],
    'Task_2': params['min_skilled_share_task2'],
    'Task_3': params['min_skilled_share_task3']
}
max_skilled_share = {
    'Task_1': params['max_skilled_share_task1'],
    'Task_2': params['max_skilled_share_task2'],
    'Task_3': params['max_skilled_share_task3']
}

# Organize task-method data
tasks = ['Task_1', 'Task_2', 'Task_3']
methods = ['Method_A', 'Method_B']
tm_data = {}
for row in task_methods:
    key = (row['Task'], row['Method'])
    tm_data[key] = row

# =============================================================================
# Build optimization model
# =============================================================================
model = gp.Model("WorkerAllocation_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
# Binary: y[task, method] = 1 if method is chosen for task
y = {}
for t in tasks:
    for m in methods:
        y[t, m] = model.addVar(vtype=GRB.BINARY, name=f"y_{t}_{m}")

# Continuous: skilled workers assigned to (task, method)
s = {}
for t in tasks:
    for m in methods:
        s[t, m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"s_{t}_{m}")

# Continuous: laborers assigned to (task, method)
l = {}
for t in tasks:
    for m in methods:
        l[t, m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"l_{t}_{m}")

# Total skilled workers and laborers
total_skilled = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_skilled")
total_laborers = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_laborers")

# Objective: minimize total weekly cost (wages + fixed costs)
fixed_cost_expr = gp.quicksum(tm_data[t, m]['Fixed_Cost'] * y[t, m] for t in tasks for m in methods)
model.setObjective(skilled_wage * total_skilled + laborer_wage * total_laborers + fixed_cost_expr, GRB.MINIMIZE)

# Constraints
# Total skilled = sum of skilled workers across chosen methods
model.addConstr(total_skilled == gp.quicksum(s[t, m] for t in tasks for m in methods), "TotalSkilledDef")
model.addConstr(total_laborers == gp.quicksum(l[t, m] for t in tasks for m in methods), "TotalLaborersDef")

# Exactly one method per task
for t in tasks:
    model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1, f"OneMethod_{t}")

# Hours requirement and linking constraints
M_big = 10000  # Big-M
for t in tasks:
    for m in methods:
        req_hours = tm_data[t, m]['Effective_Hours']
        # Hours constraint: skilled_hours * s + laborer_hours * l >= req_hours * y
        model.addConstr(skilled_hours * s[t, m] + laborer_hours * l[t, m] >= req_hours * y[t, m],
                        f"Hours_{t}_{m}")
        # Linking: if y=0, then s and l must be 0
        model.addConstr(s[t, m] <= M_big * y[t, m], f"LinkS_{t}_{m}")
        model.addConstr(l[t, m] <= M_big * y[t, m], f"LinkL_{t}_{m}")

# Maximum workers
model.addConstr(total_skilled <= max_skilled, "MaxSkilled")
model.addConstr(total_laborers <= max_laborers, "MaxLaborers")

# Overall skilled-to-laborer ratio
model.addConstr(total_skilled <= skilled_hiring_ratio * total_laborers, "SkilledRatio")

# Exclusion rule: Task 1 using Method B excludes Task 3 using Method A
model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1, "ExclusionRule")

# Minimum skilled workers for Task 3 if Method B is chosen
model.addConstr(s['Task_3', 'Method_B'] >= min_skilled_task3_B * y['Task_3', 'Method_B'], "MinSkilledTask3B")

# Task-level skill share constraints
for t in tasks:
    # Total workers assigned to task t
    S_t = gp.quicksum(s[t, m] for m in methods)
    L_t = gp.quicksum(l[t, m] for m in methods)
    # Lower bound: S_t >= min_share * (S_t + L_t)  => (1 - min_share)*S_t - min_share*L_t >= 0
    min_s = min_skilled_share[t]
    model.addConstr((1 - min_s) * S_t - min_s * L_t >= 0, f"MinSkilledShare_{t}")
    # Upper bound: S_t <= max_share * (S_t + L_t)  => (1 - max_share)*S_t - max_share*L_t <= 0
    max_s = max_skilled_share[t]
    model.addConstr((1 - max_s) * S_t - max_s * L_t <= 0, f"MaxSkilledShare_{t}")

# =============================================================================
# Solve
# =============================================================================
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("Model did not solve to optimality. Status:", model.status)
