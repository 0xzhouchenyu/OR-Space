import os
import csv
import gurobipy as gp
from gurobipy import GRB
import math

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    parts = []
    with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return parts, params

def fuel_per_heavy_bomb(distance, params):
    eff_heavy = params['fuel_efficiency_heavy_bomb']
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    return distance / eff_heavy + distance / eff_empty + takeoff_landing

def fuel_per_light_bomb(distance, params):
    eff_light = params['fuel_efficiency_light_bomb']
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    return distance / eff_light + distance / eff_empty + takeoff_landing

def main():
    parts, params = load_data()
    n = len(parts)
    max_heavy = int(params['max_heavy_bombs'])
    max_light = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts = int(params['min_parts_destroyed'])
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    overhead_A = params['sortie_fuel_overhead_A']
    overhead_B = params['sortie_fuel_overhead_B']
    prob_A = params['scenario_prob_A']
    prob_B = params['scenario_prob_B']

    # Precompute fuel per bomb per part
    fuel_h = [fuel_per_heavy_bomb(p['distance'], params) for p in parts]
    fuel_l = [fuel_per_light_bomb(p['distance'], params) for p in parts]

    # Precompute log constants for exponential formulation
    ln_1m_ph = [math.log(1.0 - p['p_heavy']) for p in parts]
    ln_1m_pl = [math.log(1.0 - p['p_light']) for p in parts]

    model = gp.Model("RobustBombAllocation")
    model.setParam('OutputFlag', 0)
    model.setParam('NonConvex', 2)

    # Decision variables: number of heavy/light bombs per part
    x_h = model.addVars(n, vtype=GRB.INTEGER, lb=0, ub=10, name="x_h")
    x_l = model.addVars(n, vtype=GRB.INTEGER, lb=0, ub=10, name="x_l")

    # Total sorties
    S = model.addVar(vtype=GRB.INTEGER, lb=0, ub=10, name="total_sorties")
    model.addConstr(S == gp.quicksum(x_h[i] + x_l[i] for i in range(n)))

    # Bomb stockpile limits
    model.addConstr(gp.quicksum(x_h[i] for i in range(n)) <= max_heavy)
    model.addConstr(gp.quicksum(x_l[i] for i in range(n)) <= max_light)

    # Sortie limits (only B is binding, but both included)
    model.addConstr(S <= max_sorties_A)
    model.addConstr(S <= max_sorties_B)

    # Fuel constraints for both scenarios
    fuel_common = gp.quicksum(x_h[i] * fuel_h[i] + x_l[i] * fuel_l[i] for i in range(n))
    model.addConstr(fuel_common + S * overhead_A <= fuel_limit, name="fuel_A")
    model.addConstr(fuel_common + S * overhead_B <= fuel_limit, name="fuel_B")

    # Variables for destruction probabilities via exponential
    p = model.addVars(n, lb=0.0, ub=1.0, name="p")
    for i in range(n):
        E_i = model.addVar(lb=-10, ub=0, name=f"E_{i}")
        model.addConstr(E_i == x_h[i] * ln_1m_ph[i] + x_l[i] * ln_1m_pl[i])
        u_i = model.addVar(lb=0.0, ub=1.0, name=f"u_{i}")
        model.addGenConstrExp(E_i, u_i, name=f"exp_{i}")
        model.addConstr(p[i] == 1.0 - u_i)

    # Build objective: probability of at least min_parts destroyed (min_parts=2)
    # We use a QCQP formulation with auxiliary variables for all subsets
    parts_idx = list(range(n))
    # q_i = p_i, r_i = 1-p_i
    q = p  # just alias
    r = model.addVars(n, lb=0.0, ub=1.0, name="r")
    for i in range(n):
        model.addConstr(r[i] == 1.0 - p[i])

    # v_T = product of q_i for i in T
    v = {}
    v[frozenset()] = 1.0  # constant
    # We'll create variables for all non-empty subsets
    for size in range(1, n+1):
        for T in __import__('itertools').combinations(parts_idx, size):
            T_set = frozenset(T)
            v[T_set] = model.addVar(lb=0.0, ub=1.0, name=f"v_{set(T)}")
    # Recursive constraints: v_{T∪{i}} = v_T * q_i
    for T_set, var in v.items():
        if T_set == frozenset():
            continue
        # Find an element i in T_set and the subset without i
        T_list = list(T_set)
        i = T_list[-1]
        T_minus = frozenset(T_list[:-1])
        if T_minus == frozenset():
            # v_{i} = q_i * 1
            model.addConstr(var == q[i], name=f"v_{set(T_set)}_def")
        else:
            model.addConstr(var == v[T_minus] * q[i], name=f"v_{set(T_set)}_def")

    # w_U = product of r_i for i in U
    w = {}
    w[frozenset()] = 1.0
    for size in range(1, n+1):
        for U in __import__('itertools').combinations(parts_idx, size):
            U_set = frozenset(U)
            w[U_set] = model.addVar(lb=0.0, ub=1.0, name=f"w_{set(U)}")
    for U_set, var in w.items():
        if U_set == frozenset():
            continue
        U_list = list(U_set)
        i = U_list[-1]
        U_minus = frozenset(U_list[:-1])
        if U_minus == frozenset():
            model.addConstr(var == r[i], name=f"w_{set(U_set)}_def")
        else:
            model.addConstr(var == w[U_minus] * r[i], name=f"w_{set(U_set)}_def")

    # y_S = v_S * w_{complement} for each subset S (destroyed parts)
    y = {}
    for size in range(n+1):
        for S in __import__('itertools').combinations(parts_idx, size):
            S_set = frozenset(S)
            comp_set = frozenset(parts_idx) - S_set
            y[S_set] = model.addVar(lb=0.0, ub=1.0, name=f"y_{set(S)}")
            model.addConstr(y[S_set] == v[S_set] * w[comp_set], name=f"y_{set(S)}_def")

    # Objective: sum of y_S for |S| >= min_parts
    objective = gp.quicksum(y[frozenset(S)] for S in __import__('itertools').combinations(parts_idx, min_parts) 
                            for size in range(min_parts, n+1) if len(S) == size)  # actually just all S with size>=min_parts
    # Simpler:
    obj_expr = 0
    for S_set, var in y.items():
        if len(S_set) >= min_parts:
            obj_expr += var
    model.setObjective(obj_expr, GRB.MAXIMIZE)

    # The objective is the same regardless of scenario probabilities because the plan is fixed.
    # The expected success probability is exactly this value (since scenario probabilities sum to 1 and the plan is feasible in both).
    # So we just maximize the success probability.

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.6f}")
    else:
        print("Model not optimal, status:", model.status)

if __name__ == '__main__':
    main()
