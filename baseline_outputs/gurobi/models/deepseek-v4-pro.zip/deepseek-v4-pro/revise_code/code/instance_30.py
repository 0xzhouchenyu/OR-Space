import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load feed data
feeds = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        feeds.append({
            "Feed": int(row["Feed"]),
            "Protein_g": float(row["Protein_g"]),
            "Minerals_g": float(row["Minerals_g"]),
            "Vitamins_mg": float(row["Vitamins_mg"]),
            "Price_Y_per_kg": float(row["Price_Y_per_kg"]),
        })

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

min_protein = params["min_protein_requirement"]
min_minerals = params["min_minerals_requirement"]
min_vitamins = params["min_vitamins_requirement"]

# Create model
model = gp.Model("FeedBlend")
model.setParam("OutputFlag", 0)

# Decision variables: amount of each feed (kg)
x = {}
for f in feeds:
    x[f["Feed"]] = model.addVar(lb=0, name=f"x_{f['Feed']}")

# Binary variables for mutual exclusion of Feed 4 and Feed 5
y4 = model.addVar(vtype=GRB.BINARY, name="y4")
y5 = model.addVar(vtype=GRB.BINARY, name="y5")

# Big M for linking constraints
M = 1e5

# Link binary to continuous: if y=0 then x=0
model.addConstr(x[4] <= M * y4, "Link4")
model.addConstr(x[5] <= M * y5, "Link5")

# Mutual exclusion: at most one of Feed 4 and Feed 5 can be used
model.addConstr(y4 + y5 <= 1, "Exclusive_4_5")

# Nutrient constraints
model.addConstr(
    gp.quicksum(f["Protein_g"] * x[f["Feed"]] for f in feeds) >= min_protein,
    "Protein"
)
model.addConstr(
    gp.quicksum(f["Minerals_g"] * x[f["Feed"]] for f in feeds) >= min_minerals,
    "Minerals"
)
model.addConstr(
    gp.quicksum(f["Vitamins_mg"] * x[f["Feed"]] for f in feeds) >= min_vitamins,
    "Vitamins"
)

# Objective: minimize total cost
model.setObjective(
    gp.quicksum(f["Price_Y_per_kg"] * x[f["Feed"]] for f in feeds),
    GRB.MINIMIZE
)

# Solve
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of infeasibility or other issues, print a default message
    print("FINAL_OBJ_VALUE: infeasible")
