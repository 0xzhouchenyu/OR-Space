import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general_parameters.csv
    general_params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            value = row["Value"].strip()
            general_params[name] = float(value) if '.' in value else int(value)
    
    # Read table_1_7.csv
    table = []
    with open(os.path.join(base_dir, "table_1_7.csv"), "r") as f:
        reader = csv.reader(f)
        for row in reader:
            table.append(row)
    
    # Parse table
    raw_materials = ['A', 'B', 'C']
    brands = ['A', 'B', 'C']
    raw_cost = [0.0, 0.0, 0.0]
    limit = [0.0, 0.0, 0.0]
    proc_fee = [0.0, 0.0, 0.0]
    sell_price = [0.0, 0.0, 0.0]
    # composition bounds: default no constraint (lb=0, ub=1)
    comp_lb = {(i, j): 0.0 for i in range(3) for j in range(3)}
    comp_ub = {(i, j): 1.0 for i in range(3) for j in range(3)}
    
    header = table[0]
    for row in table[1:]:
        if not row:
            continue
        item = row[0].strip()
        if item in raw_materials:
            i = raw_materials.index(item)
            # columns 1,2,3 are for brands A,B,C
            for j in range(3):
                cell = row[1+j].strip()
                if cell.startswith('>='):
                    val = float(cell[2:].replace('%', '')) / 100.0
                    comp_lb[(i, j)] = val
                elif cell.startswith('<='):
                    val = float(cell[2:].replace('%', '')) / 100.0
                    comp_ub[(i, j)] = val
            # raw material cost and limit
            raw_cost[i] = float(row[4].strip())
            limit[i] = float(row[5].strip())
        elif 'Processing Fee' in item:
            for j in range(3):
                proc_fee[j] = float(row[1+j].strip())
        elif 'Selling Price' in item:
            for j in range(3):
                sell_price[j] = float(row[1+j].strip())
    
    return general_params, raw_cost, limit, proc_fee, sell_price, comp_lb, comp_ub

def main():
    general_params, raw_cost, limit, proc_fee, sell_price, comp_lb, comp_ub = load_data()
    
    setup_cost = [
        general_params["SetupCost_A"],
        general_params["SetupCost_B"],
        general_params["SetupCost_C"]
    ]
    shared_wrapper_fee = general_params["BrandAB_SharedWrapper_Fee"]
    
    # Big-M values: upper bounds on production of each brand
    # Brand A: RM A >= 60% => y0 <= limit_A / 0.6 = 2000/0.6 ≈ 3333.33
    # Brand B: RM C <= 60% => y1 <= limit_C / 0.6 = 1200/0.6 = 2000
    # Brand C: RM C <= 50% => y2 <= limit_C / 0.5 = 2400
    M = [0.0, 0.0, 0.0]
    # Brand A
    if comp_lb[(0, 0)] > 0:
        M[0] = limit[0] / comp_lb[(0, 0)]
    else:
        M[0] = sum(limit)
    # Brand B
    if comp_ub[(2, 1)] < 1:
        M[1] = limit[2] / comp_ub[(2, 1)]
    else:
        M[1] = sum(limit)
    # Brand C
    if comp_ub[(2, 2)] < 1:
        M[2] = limit[2] / comp_ub[(2, 2)]
    else:
        M[2] = sum(limit)
    # Also consider other constraints: for B, RM A >= 15% gives bound limit_A/0.15 = 13333, so not tighter.
    # For A, RM C <= 20% gives limit_C/0.2 = 6000, not tighter.
    # So M as above is fine.
    
    model = gp.Model("CandyFactory_Revised")
    model.setParam('OutputFlag', 0)
    
    # Variables
    # x[i,j] >= 0: amount of raw material i in brand j
    x = {}
    for i in range(3):
        for j in range(3):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    # y[j] = total production of brand j
    y = {}
    for j in range(3):
        y[j] = model.addVar(lb=0, name=f"y_{j}")
    
    # z[j] binary: 1 if brand j is produced
    z = {}
    for j in range(3):
        z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{j}")
    
    # w binary: 1 if both brand A and B are produced
    w = model.addVar(vtype=GRB.BINARY, name="w")
    
    model.update()
    
    # Constraints
    # y[j] = sum_i x[i,j]
    for j in range(3):
        model.addConstr(y[j] == gp.quicksum(x[i, j] for i in range(3)), name=f"total_{j}")
    
    # Raw material supply limits
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= limit[i], name=f"supply_{i}")
    
    # Composition constraints
    for i in range(3):
        for j in range(3):
            if comp_lb[(i, j)] > 0:
                model.addConstr(x[i, j] >= comp_lb[(i, j)] * y[j], name=f"comp_lb_{i}_{j}")
            if comp_ub[(i, j)] < 1:
                model.addConstr(x[i, j] <= comp_ub[(i, j)] * y[j], name=f"comp_ub_{i}_{j}")
    
    # Link production to binary setup variables
    for j in range(3):
        model.addConstr(y[j] <= M[j] * z[j], name=f"setup_link_{j}")
    
    # Shared wrapper logic: w = z[0] AND z[1]
    model.addConstr(w <= z[0], name="w_le_z0")
    model.addConstr(w <= z[1], name="w_le_z1")
    model.addConstr(w >= z[0] + z[1] - 1, name="w_ge_z0z1")
    
    # Objective: maximize profit
    revenue = gp.quicksum(sell_price[j] * y[j] for j in range(3))
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in range(3))
    setup_costs = gp.quicksum(setup_cost[j] * z[j] for j in range(3))
    wrapper_cost = shared_wrapper_fee * w
    
    model.setObjective(revenue - material_cost - processing_cost - setup_costs - wrapper_cost, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj:.1f}")
    else:
        print("FINAL_OBJ_VALUE: infeasible or error")

if __name__ == "__main__":
    main()
