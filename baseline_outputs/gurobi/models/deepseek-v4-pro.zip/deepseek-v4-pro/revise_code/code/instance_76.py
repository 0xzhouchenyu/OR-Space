import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
    
    # Read general_parameters.csv
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_storage = float(params['max_storage_capacity'])  # m3
    storage_cost_a = float(params['storage_cost_a'])      # yuan/m3
    storage_cost_b = float(params['storage_cost_b'])      # yuan/m3/quarter
    safety_inventory = float(params['safety_inventory_level_10k_m3'])  # 10k m3
    terminal_value = float(params['terminal_inventory_value_per_10k_m3'])  # 10k yuan/10k m3
    penalty_cost = float(params['over_purchase_penalty_cost_per_10k_m3'])  # 10k yuan/10k m3
    
    # Unit conversions: all volumes in 10k m3 (万m3), all money in 10k yuan (万元)
    max_storage_wm3 = max_storage / 10000.0          # 200000 m3 -> 20 万m3
    # storage costs: yuan/m3 -> 万元/万m3  (multiply by 10000/10000 = 1)
    storage_cost_a_w = storage_cost_a                # 70 万元/万m3
    storage_cost_b_w = storage_cost_b                # 100 万元/万m3/quarter
    
    n = len(quarters)  # 4
    
    model = gp.Model("Timber_Profit_Maximization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i,j] = amount bought in quarter i and sold in quarter j (万m3)
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    # y[i] = amount bought in quarter i and held as end-of-autumn inventory (万m3)
    y = {}
    for i in range(n):
        y[i] = model.addVar(lb=0, name=f"y_{i}")
    
    # excess = end-of-autumn inventory above safety level (万m3)
    excess = model.addVar(lb=0, name="excess")
    
    # Objective: maximize profit
    obj = gp.LinExpr()
    for i in range(n):
        for j in range(i, n):
            u = j - i  # quarters stored
            if u > 0:
                s_cost = storage_cost_a_w + storage_cost_b_w * u
            else:
                s_cost = 0
            profit_per_unit = sale_price[quarters[j]] - purchase_price[quarters[i]] - s_cost
            obj += profit_per_unit * x[i, j]
        
        # End-of-autumn inventory: stored for (4 - i) quarters
        u_end = 4 - i
        s_cost_end = storage_cost_a_w + storage_cost_b_w * u_end
        net_y = terminal_value - purchase_price[quarters[i]] - s_cost_end
        obj += net_y * y[i]
    
    obj -= penalty_cost * excess
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Sales constraints: total sold in quarter j ≤ max_sales[j]
    for j in range(n):
        model.addConstr(
            gp.quicksum(x[i, j] for i in range(j + 1)) <= max_sales[quarters[j]],
            name=f"sales_{j}"
        )
    
    # Purchase constraints: total bought in quarter i ≤ max_purchase[i]
    for i in range(n):
        model.addConstr(
            gp.quicksum(x[i, j] for j in range(i, n)) + y[i] <= max_purchase[quarters[i]],
            name=f"purchase_{i}"
        )
    
    # Storage constraints: at end of quarter t (t=0,1,2), stored volume ≤ max_storage
    for t in range(n - 1):
        stored = gp.quicksum(x[i, j] for i in range(t + 1) for j in range(t + 1, n)) + \
                 gp.quicksum(y[i] for i in range(t + 1))
        model.addConstr(stored <= max_storage_wm3, name=f"storage_{t}")
    
    # Excess definition: excess ≥ total end inventory - safety_inventory
    total_end_inv = gp.quicksum(y[i] for i in range(n))
    model.addConstr(excess >= total_end_inv - safety_inventory, name="excess_def")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")
    else:
        print("Model not optimal")

if __name__ == "__main__":
    main()
