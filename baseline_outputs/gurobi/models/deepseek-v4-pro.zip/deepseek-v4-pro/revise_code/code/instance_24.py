import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_file = os.path.join(data_dir, "general_parameters.csv")
    
    # Read parameters
    params = {}
    with open(params_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Extract parameters
    product_units = params['product_units']
    truck_pollution = params['truck_pollution']
    van_pollution = params['van_pollution']
    motorcycle_pollution = params['motorcycle_pollution']
    ev_pollution = params['electric_vehicle_pollution']
    max_total_pollution = params['max_total_pollution']
    min_truck_trips = params['min_truck_trips']
    truck_capacity = params['truck_capacity']
    van_capacity = params['van_capacity']
    motorcycle_capacity = params['motorcycle_capacity']
    ev_capacity = params['electric_vehicle_capacity']
    
    # Sales point shares
    share_sp1 = params['sales_point_share_sp1']
    share_sp2 = params['sales_point_share_sp2']
    share_sp3 = params['sales_point_share_sp3']
    demand = {
        1: product_units * share_sp1,
        2: product_units * share_sp2,
        3: product_units * share_sp3
    }
    
    # Minimum truck share per sales point
    min_truck_share = {
        1: params['min_truck_share_sp1'],
        2: params['min_truck_share_sp2'],
        3: params['min_truck_share_sp3']
    }
    
    # Big-M values
    M_truck = params['M_truck_sp_day']
    M_ev = params['M_ev_sp_day']
    M_van = params['M_van_sp_day']
    M_moto = params['M_moto_sp_day']
    
    # Sets
    sales_points = [1, 2, 3]
    days = [1, 2, 3]
    vehicles = ['T', 'V', 'M', 'E']
    
    # Capacity and pollution per vehicle
    capacity = {'T': truck_capacity, 'V': van_capacity, 'M': motorcycle_capacity, 'E': ev_capacity}
    pollution = {'T': truck_pollution, 'V': van_pollution, 'M': motorcycle_pollution, 'E': ev_pollution}
    
    # Create model
    m = gp.Model("Transportation_Revised")
    m.setParam('OutputFlag', 0)
    
    # Decision variables: trips per vehicle, sales point, day
    x = {}
    for s in sales_points:
        for d in days:
            for v in vehicles:
                x[s, d, v] = m.addVar(vtype=GRB.INTEGER, name=f"x_{s}_{d}_{v}", lb=0)
    
    # Binary variables for family choice per sales point-day
    y = {}
    for s in sales_points:
        for d in days:
            y[s, d] = m.addVar(vtype=GRB.BINARY, name=f"y_{s}_{d}")
    
    # Constraints
    
    # 1. Demand per sales point
    for s in sales_points:
        m.addConstr(
            gp.quicksum(capacity[v] * x[s, d, v] for d in days for v in vehicles) >= demand[s],
            name=f"demand_sp{s}"
        )
    
    # 2. Family choice: if y=1 -> truck/EV family, else van/motorcycle family
    for s in sales_points:
        for d in days:
            m.addConstr(x[s, d, 'T'] <= M_truck * y[s, d], name=f"fam_T_{s}_{d}")
            m.addConstr(x[s, d, 'E'] <= M_ev * y[s, d], name=f"fam_E_{s}_{d}")
            m.addConstr(x[s, d, 'V'] <= M_van * (1 - y[s, d]), name=f"fam_V_{s}_{d}")
            m.addConstr(x[s, d, 'M'] <= M_moto * (1 - y[s, d]), name=f"fam_M_{s}_{d}")
    
    # 3. Minimum truck share per sales point
    for s in sales_points:
        total_trips_sp = gp.quicksum(x[s, d, v] for d in days for v in vehicles)
        truck_trips_sp = gp.quicksum(x[s, d, 'T'] for d in days)
        m.addConstr(truck_trips_sp >= min_truck_share[s] * total_trips_sp, name=f"truck_share_sp{s}")
    
    # 4. Minimum total truck trips across all
    total_truck_trips = gp.quicksum(x[s, d, 'T'] for s in sales_points for d in days)
    m.addConstr(total_truck_trips >= min_truck_trips, name="min_total_truck")
    
    # 5. Total pollution limit
    total_pollution = gp.quicksum(pollution[v] * x[s, d, v] for s in sales_points for d in days for v in vehicles)
    m.addConstr(total_pollution <= max_total_pollution, name="max_pollution")
    
    # Objective: minimize total pollution
    m.setObjective(total_pollution, GRB.MINIMIZE)
    
    # Solve
    m.optimize()
    
    # Output
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        # In case of infeasibility or other, print something to indicate
        print(f"FINAL_OBJ_VALUE: {m.objVal if m.status == GRB.OPTIMAL else 'INFEASIBLE'}")

if __name__ == "__main__":
    main()
