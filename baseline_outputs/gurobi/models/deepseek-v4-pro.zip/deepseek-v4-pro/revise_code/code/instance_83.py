import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        value = row["Value"].strip()
        params[name] = float(value) if '.' in value else int(value)

# Read demand data
time_periods = []
min_waiters = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        time_periods.append(row["Time"].strip())
        min_waiters.append(int(row["Minimum_Number_of_Waiters_Needed"].strip()))

n = len(time_periods)  # 6

# Extract parameters
peak = [params[f"peak_{i}"] for i in range(n)]
quality = [params[f"quality_{i}"] for i in range(n)]
cost_per_shift = params["waiter_cost_per_shift"]
budget = params["waiter_budget"]

# Valid shift start periods: must cover one peak and one off-peak
valid_starts = []
for i in range(n):
    if peak[i] + peak[(i + 1) % n] == 1:
        valid_starts.append(i)

# Create model
model = gp.Model("Restaurant_Waiters_Revised")
model.setParam("OutputFlag", 0)

# Decision variables: number of waiters starting at each period
x = model.addVars(n, lb=0, vtype=GRB.INTEGER, name="x")

# Force invalid starts to zero
for i in range(n):
    if i not in valid_starts:
        x[i].UB = 0

# Demand constraints: coverage in each period >= min_waiters
for j in range(n):
    prev = (j - 1) % n
    model.addConstr(x[prev] + x[j] >= min_waiters[j], f"Demand_{j}")

# Budget constraint: total cost <= budget
model.addConstr(gp.quicksum(x[i] for i in range(n)) * cost_per_shift <= budget, "Budget")

# Objective: maximize service quality score
# Quality score = sum over periods of quality_j * (number of waiters working in period j)
quality_expr = gp.quicksum(
    quality[j] * (x[j] + x[(j - 1) % n]) for j in range(n)
)
model.setObjective(quality_expr, GRB.MAXIMIZE)

# Solve
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of infeasibility or other status, print a default
    print(f"FINAL_OBJ_VALUE: {model.objVal if hasattr(model, 'objVal') else 'INFEASIBLE'}")
