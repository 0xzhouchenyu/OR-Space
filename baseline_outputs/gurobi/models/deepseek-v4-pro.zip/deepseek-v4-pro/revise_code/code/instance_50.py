import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = params['fixed_order_cost']
    august_threshold = params['august_bulk_order_threshold']
    august_fee = params['august_bulk_receiving_fee']
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = {}
    sell = {}
    stock = {}
    for m in months:
        buy[m] = model.addVar(lb=0, name=f"buy_{m}")
        sell[m] = model.addVar(lb=0, name=f"sell_{m}")
        stock[m] = model.addVar(lb=0, ub=warehouse_capacity, name=f"stock_{m}")
    
    # Binary variables for fixed order cost
    y = {}
    for m in months:
        y[m] = model.addVar(vtype=GRB.BINARY, name=f"y_{m}")
    
    # Binary variable for August bulk receiving fee
    z = model.addVar(vtype=GRB.BINARY, name="z_august_bulk")
    
    # Big M (safe upper bound for monthly purchases)
    M = warehouse_capacity  # 500
    
    # Stock balance and warehouse capacity constraints
    for i, m in enumerate(months):
        prev_stock = initial_stock if i == 0 else stock[months[i-1]]
        # Stock balance: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], f"balance_{m}")
        # Warehouse capacity after buying
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, f"warehouse_after_buy_{m}")
    
    # Fixed order cost: y[m] = 1 if buy[m] > 0
    for m in months:
        model.addConstr(buy[m] <= M * y[m], f"fixed_order_{m}")
    
    # August bulk receiving fee: z = 1 if buy[8] > august_threshold
    epsilon = 1e-5
    model.addConstr(buy[8] <= august_threshold + M * z, "august_bulk_upper")
    model.addConstr(buy[8] >= august_threshold + epsilon - M * (1 - z), "august_bulk_lower")
    
    # Objective: maximize total revenue (sales - purchases) minus fixed costs and August bulk fee
    revenue = gp.quicksum(sell_price[m] * sell[m] - buy_price[m] * buy[m] for m in months)
    fixed_costs = gp.quicksum(fixed_order_cost * y[m] for m in months)
    august_cost = august_fee * z
    model.setObjective(revenue - fixed_costs - august_cost, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    # Output final objective value
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        obj_val = None  # Should not happen for this feasible problem
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
