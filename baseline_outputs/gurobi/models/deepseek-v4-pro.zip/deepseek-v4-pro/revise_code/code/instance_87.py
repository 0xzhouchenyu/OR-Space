import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Path to data file
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Extract parameters
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']

    base_A = params['base_fleet_type_a']
    base_B = params['base_fleet_type_b']
    pen_A = params['penalty_cost_type_a']
    pen_B = params['penalty_cost_type_b']
    thresh_B = params['type_b_recovery_threshold']
    fee_B = params['type_b_recovery_fee']
    thresh_total = params['total_fleet_surge_threshold']
    fee_total = params['total_fleet_surge_fee']

    # Upper bounds for x and y derived from capacity constraints
    x_ub = max(int(ref_req/rc_a) + 1, int(nonref_req/nc_a) + 1)  # 150
    y_ub = max(int(ref_req/rc_b) + 1, int(nonref_req/nc_b) + 1)  # 134

    # Big M values
    M_A = x_ub - base_A
    M_B = y_ub - base_B
    M_B_rec = y_ub - thresh_B
    M_T = x_ub + y_ub - thresh_total

    # Create model
    model = gp.Model("TruckRentalRevised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = model.addVar(vtype=GRB.INTEGER, name="TypeA", lb=0, ub=x_ub)
    y = model.addVar(vtype=GRB.INTEGER, name="TypeB", lb=0, ub=y_ub)

    # Excess penalty variables
    eA = model.addVar(vtype=GRB.INTEGER, name="ExcessA", lb=0)
    eB = model.addVar(vtype=GRB.INTEGER, name="ExcessB", lb=0)

    # Binary indicators
    zA = model.addVar(vtype=GRB.BINARY, name="ExceedBaseA")
    zB = model.addVar(vtype=GRB.BINARY, name="ExceedBaseB")
    zB_rec = model.addVar(vtype=GRB.BINARY, name="ExceedRecoveryB")
    zT = model.addVar(vtype=GRB.BINARY, name="ExceedTotalSurge")

    # Objective: minimize total per-km cost
    model.setObjective(
        cost_a * x + cost_b * y +
        pen_A * eA + pen_B * eB +
        fee_B * zB_rec + fee_total * zT,
        GRB.MINIMIZE
    )

    # Capacity constraints
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedReq")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedReq")

    # Base fleet excess for Type A
    model.addConstr(x <= base_A + M_A * zA, "LinkA_upper")
    model.addConstr(eA >= x - base_A, "ExcessA_def1")
    model.addConstr(eA <= M_A * zA, "ExcessA_def2")
    model.addConstr(eA <= x - base_A + M_A * (1 - zA), "ExcessA_def3")

    # Base fleet excess for Type B
    model.addConstr(y <= base_B + M_B * zB, "LinkB_upper")
    model.addConstr(eB >= y - base_B, "ExcessB_def1")
    model.addConstr(eB <= M_B * zB, "ExcessB_def2")
    model.addConstr(eB <= y - base_B + M_B * (1 - zB), "ExcessB_def3")

    # Type B recovery desk threshold
    model.addConstr(y <= thresh_B + M_B_rec * zB_rec, "LinkB_rec")

    # Total fleet surge threshold
    model.addConstr(x + y <= thresh_total + M_T * zT, "LinkTotalSurge")

    # Solve
    model.optimize()

    # Output
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
