import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, "table_1.csv")
    with open(table1_path, "r") as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    
    # Row 0: Process I, Row 1: Process II, Row 2: Profit_per_unit
    a_I = float(rows[0][1])   # Model A hours for Process I
    b_I = float(rows[0][2])   # Model B hours for Process I
    # cap_I = float(rows[0][3])  # not used, taken from general_parameters
    
    a_II = float(rows[1][1])  # Model A hours for Process II
    b_II = float(rows[1][2])  # Model B hours for Process II
    # cap_II = float(rows[1][3])
    
    profit_A = float(rows[2][1])
    profit_B = float(rows[2][2])
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "general_parameters.csv")
    params = {}
    with open(params_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    
    min_weekly_profit = params["min_weekly_profit"]
    min_model_A_units = params["min_model_A_units"]
    min_model_B_units = params["min_model_B_units"]
    week1_min_A = params["week1_min_model_A_units"]
    week1_min_B = params["week1_min_model_B_units"]
    week2_min_A = params["week2_min_model_A_units"]
    week2_min_B = params["week2_min_model_B_units"]
    
    proc_I_hours = params["process_I_hours"]
    proc_II_hours = params["process_II_hours"]
    max_ov_I = params["max_overtime_I_per_week"]
    max_ov_II = params["max_overtime_II_per_week"]
    ov_prem_I = params["overtime_premium_I"]
    ov_prem_II = params["overtime_premium_II"]
    min_util_I = params["min_avg_utilization_I"]
    min_util_II = params["min_avg_utilization_II"]
    fatigue_thresh_I = params["week1_overtime_fatigue_threshold_I"]
    fatigue_thresh_II = params["week1_overtime_fatigue_threshold_II"]
    recovery_loss_I = params["week2_recovery_loss_I"]
    recovery_loss_II = params["week2_recovery_loss_II"]
    
    # Create model
    m = gp.Model("Microcomputer_Production_2Week")
    m.setParam("OutputFlag", 0)
    
    # Decision variables
    x_A1 = m.addVar(lb=0, name="x_A1")
    x_B1 = m.addVar(lb=0, name="x_B1")
    x_A2 = m.addVar(lb=0, name="x_A2")
    x_B2 = m.addVar(lb=0, name="x_B2")
    
    # Regular and overtime hours for each process and week
    reg_I1 = m.addVar(lb=0, name="reg_I1")
    ov_I1  = m.addVar(lb=0, name="ov_I1")
    reg_II1 = m.addVar(lb=0, name="reg_II1")
    ov_II1  = m.addVar(lb=0, name="ov_II1")
    
    reg_I2 = m.addVar(lb=0, name="reg_I2")
    ov_I2  = m.addVar(lb=0, name="ov_I2")
    reg_II2 = m.addVar(lb=0, name="reg_II2")
    ov_II2  = m.addVar(lb=0, name="ov_II2")
    
    # Binary variables for recovery trigger
    z_I = m.addVar(vtype=GRB.BINARY, name="z_I")
    z_II = m.addVar(vtype=GRB.BINARY, name="z_II")
    
    # Total processing times
    total_I1 = a_I * x_A1 + b_I * x_B1
    total_II1 = a_II * x_A1 + b_II * x_B1
    total_I2 = a_I * x_A2 + b_I * x_B2
    total_II2 = a_II * x_A2 + b_II * x_B2
    
    # Time balance constraints
    m.addConstr(reg_I1 + ov_I1 == total_I1, name="balance_I1")
    m.addConstr(reg_II1 + ov_II1 == total_II1, name="balance_II1")
    m.addConstr(reg_I2 + ov_I2 == total_I2, name="balance_I2")
    m.addConstr(reg_II2 + ov_II2 == total_II2, name="balance_II2")
    
    # Regular capacity week 1
    m.addConstr(reg_I1 <= proc_I_hours, name="reg_cap_I1")
    m.addConstr(reg_II1 <= proc_II_hours, name="reg_cap_II1")
    
    # Overtime limits week 1
    m.addConstr(ov_I1 <= max_ov_I, name="max_ov_I1")
    m.addConstr(ov_II1 <= max_ov_II, name="max_ov_II1")
    
    # Week 2 regular capacity depends on recovery
    reg_cap_I2 = proc_I_hours - recovery_loss_I * z_I
    reg_cap_II2 = proc_II_hours - recovery_loss_II * z_II
    m.addConstr(reg_I2 <= reg_cap_I2, name="reg_cap_I2")
    m.addConstr(reg_II2 <= reg_cap_II2, name="reg_cap_II2")
    
    # Overtime limits week 2
    m.addConstr(ov_I2 <= max_ov_I, name="max_ov_I2")
    m.addConstr(ov_II2 <= max_ov_II, name="max_ov_II2")
    
    # Recovery trigger constraints (big-M)
    epsilon = 1e-5
    M_I = max_ov_I - fatigue_thresh_I  # 20
    M_II = max_ov_II - fatigue_thresh_II  # 12
    
    m.addConstr(ov_I1 >= fatigue_thresh_I + epsilon - M_I * (1 - z_I), name="trig_I_low")
    m.addConstr(ov_I1 <= fatigue_thresh_I + M_I * z_I, name="trig_I_up")
    m.addConstr(ov_II1 >= fatigue_thresh_II + epsilon - M_II * (1 - z_II), name="trig_II_low")
    m.addConstr(ov_II1 <= fatigue_thresh_II + M_II * z_II, name="trig_II_up")
    
    # Average utilization constraints
    total_reg_cap_I = 2 * proc_I_hours - recovery_loss_I * z_I
    total_reg_cap_II = 2 * proc_II_hours - recovery_loss_II * z_II
    m.addConstr(reg_I1 + reg_I2 >= min_util_I * total_reg_cap_I, name="util_I")
    m.addConstr(reg_II1 + reg_II2 >= min_util_II * total_reg_cap_II, name="util_II")
    
    # Weekly delivery promises
    m.addConstr(x_A1 >= week1_min_A, name="del_A1")
    m.addConstr(x_B1 >= week1_min_B, name="del_B1")
    m.addConstr(x_A2 >= week2_min_A, name="del_A2")
    m.addConstr(x_B2 >= week2_min_B, name="del_B2")
    
    # Total production minimums (redundant but included)
    m.addConstr(x_A1 + x_A2 >= min_model_A_units, name="total_A")
    m.addConstr(x_B1 + x_B2 >= min_model_B_units, name="total_B")
    
    # Financials
    revenue = profit_A * (x_A1 + x_A2) + profit_B * (x_B1 + x_B2)
    overtime_cost = ov_prem_I * (ov_I1 + ov_I2) + ov_prem_II * (ov_II1 + ov_II2)
    net_profit = revenue - overtime_cost
    
    m.setObjective(net_profit, GRB.MAXIMIZE)
    
    # Minimum net profit constraint
    m.addConstr(net_profit >= min_weekly_profit, name="min_net_profit")
    
    # Solve
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        obj_val = m.objVal
    elif m.status == GRB.INFEASIBLE:
        # In case of infeasibility, we still need to print something; print 0 or handle
        obj_val = 0  # fallback, but problem should be feasible
    else:
        obj_val = m.objVal  # might be suboptimal
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
