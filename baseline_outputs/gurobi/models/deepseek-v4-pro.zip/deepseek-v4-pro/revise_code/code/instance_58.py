import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    param_file = os.path.join(data_dir, 'general_parameters.csv')
    params = load_parameters(param_file)

    # Extract parameters
    profits = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons']
    }
    total_area = params['total_farm_area']
    min_a_to_p = params['min_apples_to_pears_ratio']
    min_a_to_l = params['min_apples_to_lemons_ratio']
    o_to_l = params['oranges_to_lemons_ratio']
    max_types = int(params['max_fruit_types'])

    water_spring = {
        'apples': params['water_per_acre_apples_spring'],
        'pears': params['water_per_acre_pears_spring'],
        'oranges': params['water_per_acre_oranges_spring'],
        'lemons': params['water_per_acre_lemons_spring']
    }
    water_autumn = {
        'apples': params['water_per_acre_apples_autumn'],
        'pears': params['water_per_acre_pears_autumn'],
        'oranges': params['water_per_acre_oranges_autumn'],
        'lemons': params['water_per_acre_lemons_autumn']
    }
    water_cap_spring = params['water_cap_spring']
    water_cap_autumn = params['water_cap_autumn']
    total_water_budget = params['total_water_budget']
    min_water_per_fruit = params['min_annual_water_per_fruit']
    diversification_reward = params['diversification_reward']

    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']
    water_coeff = {
        ('apples', 'spring'): water_spring['apples'],
        ('apples', 'autumn'): water_autumn['apples'],
        ('pears', 'spring'): water_spring['pears'],
        ('pears', 'autumn'): water_autumn['pears'],
        ('oranges', 'spring'): water_spring['oranges'],
        ('oranges', 'autumn'): water_autumn['oranges'],
        ('lemons', 'spring'): water_spring['lemons'],
        ('lemons', 'autumn'): water_autumn['lemons']
    }

    # Model
    m = gp.Model("farm_revised")
    m.setParam('OutputFlag', 0)

    # Variables: acres per fruit per season
    x = m.addVars(fruits, seasons, lb=0, name="x")
    # Binary: is fruit f grown?
    y = m.addVars(fruits, vtype=GRB.BINARY, name="y")
    # Binary: diversification reward
    d = m.addVar(vtype=GRB.BINARY, name="d")

    # Seasonal land constraints
    for s in seasons:
        m.addConstr(gp.quicksum(x[f, s] for f in fruits) <= total_area, name=f"land_{s}")

    # Annual acreage totals
    A = {f: gp.quicksum(x[f, s] for s in seasons) for f in fruits}

    # Annual mix ratios
    m.addConstr(A['apples'] >= min_a_to_p * A['pears'], name="ratio_apples_pears")
    m.addConstr(A['apples'] >= min_a_to_l * A['lemons'], name="ratio_apples_lemons")
    m.addConstr(A['oranges'] == o_to_l * A['lemons'], name="ratio_oranges_lemons")

    # Water usage per season and total
    water_spring_expr = gp.quicksum(water_coeff[f, 'spring'] * x[f, 'spring'] for f in fruits)
    water_autumn_expr = gp.quicksum(water_coeff[f, 'autumn'] * x[f, 'autumn'] for f in fruits)
    m.addConstr(water_spring_expr <= water_cap_spring, name="water_spring")
    m.addConstr(water_autumn_expr <= water_cap_autumn, name="water_autumn")

    total_water_expr = water_spring_expr + water_autumn_expr
    m.addConstr(total_water_expr <= total_water_budget, name="water_total")

    # Annual water per fruit
    W = {f: gp.quicksum(water_coeff[f, s] * x[f, s] for s in seasons) for f in fruits}

    # Link y to acreage and water
    M_area = 2 * total_area  # max possible annual acres for a fruit
    M_water = total_water_budget
    for f in fruits:
        m.addConstr(A[f] <= M_area * y[f], name=f"link_area_{f}")
        m.addConstr(W[f] >= min_water_per_fruit * y[f], name=f"min_water_{f}")
        m.addConstr(W[f] <= M_water * y[f], name=f"max_water_{f}")

    # Max fruit types
    m.addConstr(gp.quicksum(y[f] for f in fruits) <= max_types, name="max_types")

    # Diversification reward: d = 1 iff sum(y) >= 2
    sum_y = gp.quicksum(y[f] for f in fruits)
    m.addConstr(2 * d <= sum_y, name="div_lower1")
    m.addConstr(d >= sum_y - 1, name="div_lower2")

    # Objective: profit + diversification reward
    profit_expr = gp.quicksum(profits[f] * A[f] for f in fruits)
    m.setObjective(profit_expr + diversification_reward * d, GRB.MAXIMIZE)

    m.optimize()

    if m.status == GRB.OPTIMAL:
        obj_val = m.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # In case of infeasibility or other, print something
        print(f"FINAL_OBJ_VALUE: {m.status}")

if __name__ == "__main__":
    main()
