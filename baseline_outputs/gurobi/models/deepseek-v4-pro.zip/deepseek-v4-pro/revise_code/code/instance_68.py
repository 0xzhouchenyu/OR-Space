import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        value = float(row["Value"].strip())
        params[name] = value

# Load distances
distances = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        yard = row["Coal_Yard"].strip()
        area = int(row["Residential_Area"].strip())
        dist = float(row["Distance_km"].strip())
        distances[(yard, area)] = dist

# Extract parameters
min_supply_A = params["min_coal_yard_A"]
min_supply_B = params["min_coal_yard_B_adjusted"]
demand = {
    1: params["residential_area_1_demand"],
    2: params["residential_area_2_demand"],
    3: params["residential_area_3_demand"],
}
min_share_A3 = params["min_share_area3_from_A"]
staging_threshold = params["area3_A_staging_threshold"]
excess_cost = params["area3_A_excess_staging_cost"]

# Sets
yards = ["A", "B"]
areas = [1, 2, 3]

# Model
model = gp.Model("Coal_Distribution_Revised")
model.setParam("OutputFlag", 0)

# Variables
x = {}
# Regular variables for all routes present in distances
for (yard, area), dist in distances.items():
    if yard == "A" and area == 3:
        # Piecewise: normal up to threshold, excess above
        x["A", 3, "normal"] = model.addVar(lb=0, ub=staging_threshold, name="x_A_3_normal")
        x["A", 3, "excess"] = model.addVar(lb=0, name="x_A_3_excess")
    else:
        x[yard, area] = model.addVar(lb=0, name=f"x_{yard}_{area}")

# Objective
obj = gp.LinExpr()
for (yard, area), dist in distances.items():
    if yard == "A" and area == 3:
        obj += dist * x["A", 3, "normal"] + (dist + excess_cost) * x["A", 3, "excess"]
    else:
        obj += dist * x[yard, area]
model.setObjective(obj, GRB.MINIMIZE)

# Constraints
# Supply minimums
supply_A = gp.LinExpr()
supply_B = gp.LinExpr()
for area in areas:
    if area == 3:
        supply_A += x["A", 3, "normal"] + x["A", 3, "excess"]
    else:
        if ("A", area) in x:
            supply_A += x["A", area]
        if ("B", area) in x:
            supply_B += x["B", area]
model.addConstr(supply_A >= min_supply_A, "Min_Supply_A")
model.addConstr(supply_B >= min_supply_B, "Min_Supply_B")

# Demand constraints
for area in areas:
    flow = gp.LinExpr()
    if area == 3:
        flow += x["A", 3, "normal"] + x["A", 3, "excess"]
    else:
        if ("A", area) in x:
            flow += x["A", area]
        if ("B", area) in x:
            flow += x["B", area]
    model.addConstr(flow == demand[area], f"Demand_{area}")

# Minimum share of Area 3 from A (redundant but included per requirements)
flow_A3 = x["A", 3, "normal"] + x["A", 3, "excess"]
model.addConstr(flow_A3 >= min_share_A3 * demand[3], "MinShare_A3")

# Optimize
model.optimize()

# Output
print(f"FINAL_OBJ_VALUE: {model.objVal}")
