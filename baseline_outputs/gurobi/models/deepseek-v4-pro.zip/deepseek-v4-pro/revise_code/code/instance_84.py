import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                "name": row["Candidate"].strip(),
                "salary": int(row["Salary"].strip()),
                "qualification": row["Qualification"].strip(),
                "experience": int(row["Work_Experience"].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

    max_employees = int(params["max_employees"])
    budget_limit = params["budget_limit"]
    min_advanced = int(params["min_advanced_degree_candidates"])
    min_experience = params["min_work_experience"]
    max_equivalent = int(params["max_equivalent_candidates"])
    min_employees = int(params["min_employees"])
    min_managers = int(params["min_managers"])
    max_managers = int(params["max_managers"])
    min_manager_experience = params["min_manager_experience"]
    manager_bonus = params["manager_bonus_per_candidate"]

    # Create model
    model = gp.Model("Recruitment_Revised")
    model.setParam("OutputFlag", 0)

    # Decision variables
    # x[i] = 1 if candidate i is selected (any role)
    # m[i] = 1 if candidate i is selected as Manager
    # s[i] = 1 if candidate i is selected as Specialist
    x = {}
    m = {}
    s = {}
    for c in candidates:
        name = c["name"]
        x[name] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}")
        m[name] = model.addVar(vtype=GRB.BINARY, name=f"m_{name}")
        s[name] = model.addVar(vtype=GRB.BINARY, name=f"s_{name}")

    # Link variables: x = m + s, and at most one role per candidate
    for c in candidates:
        name = c["name"]
        model.addConstr(x[name] == m[name] + s[name], f"link_{name}")

    # Total selected headcount constraints
    model.addConstr(gp.quicksum(x[c["name"]] for c in candidates) <= max_employees, "max_employees")
    model.addConstr(gp.quicksum(x[c["name"]] for c in candidates) >= min_employees, "min_employees")

    # Budget constraint (base salaries only)
    model.addConstr(gp.quicksum(c["salary"] * x[c["name"]] for c in candidates) <= budget_limit, "budget")

    # Advanced degree constraint
    advanced = [c for c in candidates if c["qualification"] in ("Master's degree", "Doctoral degree")]
    model.addConstr(gp.quicksum(x[c["name"]] for c in advanced) >= min_advanced, "advanced_degree")

    # Total work experience constraint
    model.addConstr(gp.quicksum(c["experience"] * x[c["name"]] for c in candidates) >= min_experience, "min_experience")

    # Equivalent pair constraint (A and E)
    model.addConstr(x["A"] + x["E"] <= max_equivalent, "equivalent_pair")

    # Manager headcount constraints
    model.addConstr(gp.quicksum(m[c["name"]] for c in candidates) >= min_managers, "min_managers")
    model.addConstr(gp.quicksum(m[c["name"]] for c in candidates) <= max_managers, "max_managers")

    # Manager total experience constraint
    model.addConstr(gp.quicksum(c["experience"] * m[c["name"]] for c in candidates) >= min_manager_experience, "manager_experience")

    # Objective: minimize total cost = base salaries + manager bonuses
    total_base_salary = gp.quicksum(c["salary"] * x[c["name"]] for c in candidates)
    total_manager_bonus = manager_bonus * gp.quicksum(m[c["name"]] for c in candidates)
    model.setObjective(total_base_salary + total_manager_bonus, GRB.MINIMIZE)

    # Solve
    model.optimize()

    # Output only the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of infeasibility or other issues, print a default
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
