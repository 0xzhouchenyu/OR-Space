import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read table_1.csv
    table1_path = os.path.join(base_dir, 'table_1.csv')
    batches = []
    raw_times = []
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        num_vats = len(header) - 1  # exclude Batch column
        for row in reader:
            batch_id = int(row[0])
            times = [float(row[j+1]) for j in range(num_vats)]
            batches.append(batch_id)
            raw_times.append(times)
    
    # Read general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            params[row[0]] = float(row[1])
    
    return batches, raw_times, num_vats, params

def solve():
    batches, raw_times, num_vats, params = load_data()
    N = len(batches)          # number of batches
    M = num_vats              # number of vats (3)
    T = int(params['planning_horizon_T'])
    
    # Round up processing times to next integer
    p = [[int(math.ceil(raw_times[i][j])) for j in range(M)] for i in range(N)]
    
    # Energy cost parameters
    energy_cost = [params['energy_cost_v1'], params['energy_cost_v2'], params['energy_cost_v3']]
    peak_mult = params['peak_energy_multiplier']
    peak_cap = params['peak_energy_cap']
    makespan_weight = params['makespan_weight']
    energy_weight = params['energy_weight']
    
    # Precompute feasible start times for each batch and vat
    feasible_start = [[[] for _ in range(M)] for _ in range(N)]
    for i in range(N):
        for j in range(M):
            max_start = T - p[i][j] + 1
            if max_start >= 1:
                feasible_start[i][j] = list(range(1, max_start + 1))
            else:
                feasible_start[i][j] = []  # no feasible start (should not happen with T=15)
    
    # Precompute energy contribution for each (i,j,s)
    energy_contrib = [[{} for _ in range(M)] for _ in range(N)]
    peak_contrib = [[{} for _ in range(M)] for _ in range(N)]
    for i in range(N):
        for j in range(M):
            for s in feasible_start[i][j]:
                # total energy cost if batch i starts on vat j at time s
                total_energy = 0.0
                peak_energy = 0.0
                for t in range(s, s + p[i][j]):
                    if 1 <= t <= T:
                        base_cost = energy_cost[j]
                        if 6 <= t <= 8:
                            cost_t = base_cost * peak_mult
                            peak_energy += cost_t
                        else:
                            cost_t = base_cost
                        total_energy += cost_t
                energy_contrib[i][j][s] = total_energy
                peak_contrib[i][j][s] = peak_energy
    
    # Create model
    model = gp.Model("Dyeing_Scheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i,j,s] = 1 if batch i starts on vat j at time s
    x = {}
    for i in range(N):
        for j in range(M):
            for s in feasible_start[i][j]:
                x[i, j, s] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}_{s}")
    
    # Makespan variable
    Cmax = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="Cmax")
    
    # Total energy cost variable (can be expressed as linear combination, but we can define as expression)
    total_energy_cost = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="total_energy_cost")
    
    # Constraints
    # 1. Each batch must be processed exactly once on each vat
    for i in range(N):
        for j in range(M):
            model.addConstr(
                gp.quicksum(x[i, j, s] for s in feasible_start[i][j]) == 1,
                name=f"assign_{i}_{j}"
            )
    
    # 2. Precedence between vats (handoff convention)
    for i in range(N):
        for j in range(M - 1):
            # start on vat j+1 >= start on vat j + p[i][j] - 1
            model.addConstr(
                gp.quicksum(s * x[i, j+1, s] for s in feasible_start[i][j+1]) >=
                gp.quicksum(s * x[i, j, s] for s in feasible_start[i][j]) + p[i][j] - 1,
                name=f"prec_{i}_{j}"
            )
    
    # 3. No overlap on each vat
    for j in range(M):
        for t in range(1, T + 1):
            # sum over all batches and start times that cover period t
            covering = []
            for i in range(N):
                for s in feasible_start[i][j]:
                    if s <= t <= s + p[i][j] - 1:
                        covering.append(x[i, j, s])
            if covering:
                model.addConstr(
                    gp.quicksum(covering) <= 1,
                    name=f"no_overlap_{j}_{t}"
                )
    
    # 4. Maintenance on Vat 2 (index 1) during periods 4 and 5
    vat2_idx = 1
    for t in [4, 5]:
        covering = []
        for i in range(N):
            for s in feasible_start[i][vat2_idx]:
                if s <= t <= s + p[i][vat2_idx] - 1:
                    covering.append(x[i, vat2_idx, s])
        if covering:
            model.addConstr(
                gp.quicksum(covering) == 0,
                name=f"maint_vat2_t{t}"
            )
    
    # 5. Makespan definition (completion on Vat 3, index 2)
    vat3_idx = 2
    for i in range(N):
        model.addConstr(
            Cmax >= gp.quicksum(s * x[i, vat3_idx, s] for s in feasible_start[i][vat3_idx]) + p[i][vat3_idx] - 1,
            name=f"makespan_{i}"
        )
    
    # 6. Total energy cost
    model.addConstr(
        total_energy_cost == gp.quicksum(
            energy_contrib[i][j][s] * x[i, j, s]
            for i in range(N) for j in range(M) for s in feasible_start[i][j]
        ),
        name="total_energy_def"
    )
    
    # 7. Peak energy cap
    model.addConstr(
        gp.quicksum(
            peak_contrib[i][j][s] * x[i, j, s]
            for i in range(N) for j in range(M) for s in feasible_start[i][j]
        ) <= peak_cap,
        name="peak_cap"
    )
    
    # 8. Objective: weighted sum
    model.setObjective(
        makespan_weight * Cmax + energy_weight * total_energy_cost,
        GRB.MINIMIZE
    )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print("No optimal solution found.")
        # For debugging, you could print model status, but we'll just output something
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == '__main__':
    solve()
