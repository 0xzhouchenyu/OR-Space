import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Parse table_1.csv
    proc_time = {}   # (equipment, product) -> hours per unit
    capacity = {}    # equipment -> available machine hours
    cost_rate = {}   # equipment -> processing cost per machine hour
    raw_cost = {}    # product -> raw material cost per unit
    price = {}       # product -> unit price
    
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row["Equipment"].strip()
            if equip == "Raw_Material_Cost":
                raw_cost["I"] = float(row["Product_I"])
                raw_cost["II"] = float(row["Product_II"])
                raw_cost["III"] = float(row["Product_III"])
            elif equip == "Unit_Price":
                price["I"] = float(row["Product_I"])
                price["II"] = float(row["Product_II"])
                price["III"] = float(row["Product_III"])
            else:
                for prod, col in [("I", "Product_I"), ("II", "Product_II"), ("III", "Product_III")]:
                    val = row[col].strip()
                    if val != "-":
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row["Effective_Machine_Hours"])
                cost_rate[equip] = float(row["Processing_Cost_per_Machine_Hour"])
    
    # Parse setup_costs.csv
    setup_cost = {}
    with open(os.path.join(data_dir, "setup_costs.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row["Equipment"].strip()
            setup_cost[equip] = float(row["Fixed_Setup_Cost"])
    
    # Parse general_parameters.csv for equipment assignments and joint calibration
    stage_A_equip = {}
    stage_B_equip = {}
    joint_fee = 0.0
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            value = row["Value"].strip()
            if name == "product_I_stage_A_equipment":
                stage_A_equip["I"] = [e.strip() for e in value.split(" or ")]
            elif name == "product_I_stage_B_equipment":
                stage_B_equip["I"] = [e.strip() for e in value.split(" or ")]
            elif name == "product_II_stage_A_equipment":
                stage_A_equip["II"] = [e.strip() for e in value.split(" or ")]
            elif name == "product_II_stage_B_equipment":
                stage_B_equip["II"] = [e.strip() for e in value.split(" or ")]
            elif name == "product_III_stage_A_equipment":
                stage_A_equip["III"] = [e.strip() for e in value.split(" or ")]
            elif name == "product_III_stage_B_equipment":
                stage_B_equip["III"] = [e.strip() for e in value.split(" or ")]
            elif name == "A2_B2_joint_calibration_fee":
                joint_fee = float(value)
    
    # All equipment
    all_equip = ["A1", "A2", "B1", "B2", "B3"]
    
    # Model
    model = gp.Model("Factory_Production")
    model.setParam("OutputFlag", 0)
    
    # Decision variables: x[equip, prod] for allowed combinations
    x = {}
    for prod in ["I", "II", "III"]:
        for equip in stage_A_equip[prod]:
            x[(equip, prod)] = model.addVar(lb=0, name=f"x_{equip}_{prod}")
        for equip in stage_B_equip[prod]:
            # Avoid duplicate if same equipment appears in both stages (not the case here)
            if (equip, prod) not in x:
                x[(equip, prod)] = model.addVar(lb=0, name=f"x_{equip}_{prod}")
    
    # Total production per product
    total = {}
    for prod in ["I", "II", "III"]:
        total[prod] = gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod])
        # Flow conservation: stage A total == stage B total
        model.addConstr(
            gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod]) ==
            gp.quicksum(x[(e, prod)] for e in stage_B_equip[prod])
        )
    
    # Capacity constraints and setup linking
    y = {}
    for equip in all_equip:
        y[equip] = model.addVar(vtype=GRB.BINARY, name=f"y_{equip}")
        # Sum of processing hours on this equipment
        used_hours = gp.quicksum(
            proc_time[(equip, prod)] * x[(equip, prod)]
            for prod in ["I", "II", "III"] if (equip, prod) in x
        )
        if used_hours.size() > 0:
            model.addConstr(used_hours <= capacity[equip], name=f"cap_{equip}")
            model.addConstr(used_hours <= capacity[equip] * y[equip], name=f"link_{equip}")
        else:
            # Equipment not used at all, force y to 0
            model.addConstr(y[equip] == 0)
    
    # Joint calibration trigger
    z = model.addVar(vtype=GRB.BINARY, name="z_joint")
    model.addConstr(z >= y["A2"] + y["B2"] - 1, name="joint_trigger")
    
    # Objective components
    revenue = gp.quicksum(price[p] * total[p] for p in ["I", "II", "III"])
    raw_mat = gp.quicksum(raw_cost[p] * total[p] for p in ["I", "II", "III"])
    proc_cost = gp.quicksum(
        cost_rate[e] * proc_time[(e, p)] * x[(e, p)]
        for (e, p) in x
    )
    setup_total = gp.quicksum(setup_cost[e] * y[e] for e in all_equip)
    joint_penalty = joint_fee * z
    
    model.setObjective(revenue - raw_mat - proc_cost - setup_total - joint_penalty, GRB.MAXIMIZE)
    
    model.optimize()
    
    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
    else:
        print("FINAL_OBJ_VALUE: infeasible or error")

if __name__ == "__main__":
    main()
