import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    param_file = os.path.join(data_dir, "general_parameters.csv")

    # Read parameters
    params = {}
    with open(param_file, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = row["Value"].strip()
            params[name] = val

    # Extract all needed parameters
    a1_yield = float(params["product_A1_yield"])          # 3
    a1_time = float(params["product_A1_time"])            # 12
    a2_yield = float(params["product_A2_yield"])          # 4
    a2_time = float(params["product_A2_time"])            # 8
    a3_yield = float(params["product_A3_yield"])          # 2
    a3_time = float(params["product_A3_time"])            # 10
    profit_a1 = float(params["profit_per_kg_A1"])         # 24
    profit_a2 = float(params["profit_per_kg_A2"])         # 16
    profit_a3 = float(params["profit_per_kg_A3"])         # 30
    milk_supply = float(params["daily_milk_supply"])      # 50
    labor_hours = float(params["daily_labor_hours"])      # 480
    cap_A_shared = float(params["cap_A_shared"])          # 90
    min_A2_kg = float(params["min_A2_kg"])                # 40
    min_A3_kg = float(params["min_A3_kg"])                # 20
    cleaning_loss = float(params["type_A_cleaning_loss_if_A3"])  # 12
    bonus_threshold = float(params["cold_chain_bonus_threshold_kg"])  # 30
    bonus_yuan = float(params["cold_chain_bonus_yuan"])   # 300

    # Derived values
    profit_per_barrel_a1 = a1_yield * profit_a1   # 72
    profit_per_barrel_a2 = a2_yield * profit_a2   # 64
    profit_per_barrel_a3 = a3_yield * profit_a3   # 60
    min_A3_barrels = min_A3_kg / a3_yield         # 10
    max_A3_kg = milk_supply * a3_yield            # 100

    # Model
    m = gp.Model("Dairy_Production_Revised")
    m.setParam("OutputFlag", 0)

    # Decision variables (barrels of milk)
    x1 = m.addVar(lb=0, name="x1")
    x2 = m.addVar(lb=0, name="x2")
    x3 = m.addVar(lb=0, name="x3")

    # Binary variables
    y = m.addVar(vtype=GRB.BINARY, name="y")   # 1 if A3 is produced
    z = m.addVar(vtype=GRB.BINARY, name="z")   # 1 if cold-chain bonus applies

    # Objective: maximize profit
    m.setObjective(
        profit_per_barrel_a1 * x1 +
        profit_per_barrel_a2 * x2 +
        profit_per_barrel_a3 * x3 +
        bonus_yuan * z,
        GRB.MAXIMIZE
    )

    # Constraints
    # 1. Milk supply
    m.addConstr(x1 + x2 + x3 <= milk_supply, "Milk_Supply")

    # 2. Labor hours
    m.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours, "Labor")

    # 3. Shared Type A capacity (A1 and A3) with cleaning loss if A3 is produced
    m.addConstr(
        a1_yield * x1 + a3_yield * x3 <= cap_A_shared - cleaning_loss * y,
        "TypeA_Shared"
    )

    # 4. Minimum A2 production (kg)
    m.addConstr(a2_yield * x2 >= min_A2_kg, "Min_A2")

    # 5. Link y to x3: if y=0 then x3=0; if y=1 then x3 >= min_A3_barrels
    m.addConstr(x3 >= min_A3_barrels * y, "Min_A3_if_produced")
    m.addConstr(x3 <= milk_supply * y, "Max_A3_if_produced")

    # 6. Cold-chain bonus threshold: z=1 iff a3_yield*x3 >= bonus_threshold
    #    a3_yield*x3 >= bonus_threshold * z
    #    a3_yield*x3 <= bonus_threshold - 1e-5 + max_A3_kg * z
    m.addConstr(a3_yield * x3 >= bonus_threshold * z, "Bonus_Threshold_Lower")
    m.addConstr(a3_yield * x3 <= bonus_threshold - 1e-5 + max_A3_kg * z, "Bonus_Threshold_Upper")

    # 7. Logical: can only get bonus if A3 is produced (z <= y)
    m.addConstr(z <= y, "Bonus_requires_A3")

    # Solve
    m.optimize()

    # Output
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        # Fallback in case of infeasibility or other status
        print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    main()
