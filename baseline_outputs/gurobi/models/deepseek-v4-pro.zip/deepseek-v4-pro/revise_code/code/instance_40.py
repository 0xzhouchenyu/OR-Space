import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load parameters
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(csv_path)
    params = dict(zip(df['Parameter_Name'], df['Value']))

    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # Extract prices and costs
    price = {c: params[f"{c}_price"] for c in commodities}
    import_cost = {c: params[f"{c}_import_cost"] for c in commodities}
    labor_req = {c: params[f"{c}_labor_requirement"] for c in commodities}

    # Input-output coefficients: a[j][i] = amount of i needed to produce one unit of j
    a = {j: {} for j in commodities}
    for j in commodities:
        for i in commodities:
            key = f"{j}_{i}_requirement"
            if key in params:
                a[j][i] = params[key]
            else:
                a[j][i] = 0.0

    # Production limits
    prod_limits = {}
    for c in commodities:
        key = f"{c}_production_limit"
        if key in params:
            prod_limits[c] = params[key]

    # Labor parameters
    labor_force = params['labor_force']
    overtime_cap = params['overtime_cap']
    # overtime_wage is not used in GDP objective

    # Import parameters
    import_premium_ratio = params['import_premium_ratio']
    import_quota = params['import_quota']

    # Create model
    model = gp.Model("Maximize_GDP")
    model.setParam('OutputFlag', 0)

    # Variables
    x = {c: model.addVar(lb=0, name=f"x_{c}") for c in commodities}  # production
    m = {c: model.addVar(lb=0, ub=import_quota, name=f"m_{c}") for c in commodities}  # imports
    e = {c: model.addVar(lb=0, name=f"e_{c}") for c in commodities}  # exports
    overtime = model.addVar(lb=0, ub=overtime_cap, name="overtime")

    # Domestic consumption of each commodity
    d = {}
    for i in commodities:
        d[i] = gp.quicksum(a[j][i] * x[j] for j in commodities)

    # Balance constraints: production + imports = domestic consumption + exports
    for i in commodities:
        model.addConstr(x[i] + m[i] == d[i] + e[i], name=f"balance_{i}")

    # Labor constraint: regular + overtime
    total_labor = gp.quicksum(labor_req[c] * x[c] for c in commodities)
    model.addConstr(total_labor <= labor_force + overtime, name="labor_limit")

    # Production limits
    for c, limit in prod_limits.items():
        model.addConstr(x[c] <= limit, name=f"prod_limit_{c}")

    # Objective: GDP = export revenue - import cost (finished goods) - other import costs (inputs)
    export_revenue = gp.quicksum(price[c] * e[c] for c in commodities)
    import_finished_cost = gp.quicksum(import_premium_ratio * price[c] * m[c] for c in commodities)
    import_input_cost = gp.quicksum(import_cost[c] * x[c] for c in commodities)
    gdp = export_revenue - import_finished_cost - import_input_cost
    model.setObjective(gdp, GRB.MAXIMIZE)

    # Solve
    model.optimize()

    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
