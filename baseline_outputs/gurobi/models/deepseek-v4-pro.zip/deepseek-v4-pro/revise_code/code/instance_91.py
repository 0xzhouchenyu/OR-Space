import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            if ':' in value_str:
                # ratio like "5:2"
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params

def main():
    # Path to data file
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Extract parameters
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    time_A = params['assembly_time_A']      # minutes per unit
    time_B = params['assembly_time_B']      # minutes per unit
    machine_hours = params['machine_working_time']  # hours per week
    ratio_A, ratio_B = params['production_ratio_A_to_B']  # 5, 2
    max_overtime = params['max_overtime_hours']          # hours
    overtime_penalty = params['overtime_penalty_per_hour']  # GBP per hour
    overtime_threshold = params['overtime_review_threshold_hours']  # hours
    overtime_review_fee = params['overtime_review_fee']            # GBP
    senior_threshold = params['product_A_senior_batch_threshold']  # units
    senior_fee = params['product_A_senior_batch_fee']              # GBP

    # Convert machine working time to minutes
    machine_minutes = machine_hours * 60
    max_overtime_minutes = max_overtime * 60

    # Create model
    m = gp.Model("ProductMix_Revised")
    m.setParam('OutputFlag', 0)

    # Decision variables
    A = m.addVar(lb=0, name="Product_A")
    B = m.addVar(lb=0, name="Product_B")
    overtime = m.addVar(lb=0, ub=max_overtime, name="Overtime_hours")  # in hours

    # Binary indicators
    y = m.addVar(vtype=GRB.BINARY, name="OvertimeReviewFlag")
    z = m.addVar(vtype=GRB.BINARY, name="SeniorBatchFlag")

    # Constraints

    # 1. Machine time (in minutes)
    m.addConstr(time_A * A + time_B * B <= machine_minutes + overtime * 60, "MachineTime")

    # 2. Production ratio: B >= (ratio_B/ratio_A) * A  ->  ratio_B * A - ratio_A * B <= 0
    m.addConstr(ratio_B * A - ratio_A * B <= 0, "ProductionRatio")

    # 3. Overtime threshold indicator using indicator constraints
    # If y=1 then overtime >= threshold + epsilon; if y=0 then overtime <= threshold
    eps = 1e-5
    m.addGenConstrIndicator(y, True, overtime >= overtime_threshold + eps)
    m.addGenConstrIndicator(y, False, overtime <= overtime_threshold)

    # 4. Senior batch indicator: if z=1 then A >= threshold + eps; if z=0 then A <= threshold
    m.addGenConstrIndicator(z, True, A >= senior_threshold + eps)
    m.addGenConstrIndicator(z, False, A <= senior_threshold)

    # Objective: maximize profit minus costs
    revenue = profit_A * A + profit_B * B
    overtime_cost = overtime_penalty * overtime + overtime_review_fee * y
    senior_cost = senior_fee * z
    m.setObjective(revenue - overtime_cost - senior_cost, GRB.MAXIMIZE)

    # Solve
    m.optimize()

    # Output
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal:.1f}")
    else:
        # In case of infeasibility or other issues, print a default
        print(f"FINAL_OBJ_VALUE: {m.objVal:.1f}")

if __name__ == "__main__":
    main()
