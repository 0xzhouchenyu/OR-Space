import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load batch processing times
    table1_path = os.path.join(base_dir, "data", "table_1.csv")
    batches = []
    processing_times = []
    
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        
        for row in reader:
            batch_id = int(row[0])
            times = [float(row[j+1]) for j in range(1, len(row))]
            # Round up to the next full time unit
            rounded_times = [int(t) + (1 if t % 1 != 0 else 0) for t in times]
            batches.append(batch_id)
            processing_times.append(rounded_times)
    
    # Load general parameters
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    
    with open(params_path, 'r') as f:
        reader = csv.reader(f)
        for key, value in reader:
            if key == "planning_horizon_T":
                params[key] = int(value)
            elif key in ["energy_cost_v1", "energy_cost_v2", "energy_cost_v3",
                         "peak_energy_multiplier", "peak_energy_cap",
                         "makespan_weight", "energy_weight"]:
                params[key] = float(value)
    
    return batches, processing_times, params

def solve():
    batches, processing_times, params = load_data()
    n_batches = len(batches)
    n_vats = len(processing_times[0])
    T = params["planning_horizon_T"]
    
    # Create model
    model = gp.Model("FabricDyeingSchedule")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[b,v,t] = 1 if batch b starts on vat v at time t
    x = {}
    for b in range(n_batches):
        for v in range(n_vats):
            for t in range(T - processing_times[b][v] + 1):
                x[b, v, t] = model.addVar(vtype=GRB.BINARY, name=f"x_{b}_{v}_{t}")
    
    # y[v,t] = 1 if vat v is active at time t
    y = {}
    for v in range(n_vats):
        for t in range(T):
            y[v, t] = model.addVar(vtype=GRB.BINARY, name=f"y_{v}_{t}")
    
    # z[t] = completion time of last batch on Vat 3 (makespan)
    z = model.addVar(lb=0, ub=T, vtype=GRB.CONTINUOUS, name="z")
    
    # Add constraints
    
    # Each batch must start exactly once on each vat
    for b in range(n_batches):
        for v in range(n_vats):
            model.addConstr(gp.quicksum(x[b, v, t] for t in range(T - processing_times[b][v] + 1)) == 1,
                           name=f"BatchStartOnce_{b}_{v}")
    
    # Vat 2 maintenance constraint: no activity during periods 4-5
    for t in range(4, 6):  # Periods 4 and 5 (0-indexed)
        model.addConstr(y[1, t] == 0, name=f"MaintenanceVat2_{t}")
    
    # No overlapping jobs on the same vat
    for v in range(n_vats):
        for t in range(T):
            model.addConstr(
                y[v, t] <= gp.quicksum(x[b, v, t_start] 
                                      for b in range(n_batches) 
                                      for t_start in range(max(0, t - processing_times[b][v] + 1), t + 1)),
                name=f"NoOverlapVat_{v}_Time_{t}"
            )
    
    # Ensure that a job can only be processed on Vat v+1 after it has been processed on Vat v
    for b in range(n_batches):
        for v in range(n_vats - 1):
            for t1 in range(T - processing_times[b][v] + 1):
                for t2 in range(T - processing_times[b][v+1] + 1):
                    if t2 < t1 + processing_times[b][v]:
                        model.addConstr(x[b, v, t1] + x[b, v+1, t2] <= 1,
                                       name=f"SequentialProcessing_{b}_{v}_{t1}_{t2}")
    
    # Link y[v,t] to x[b,v,t]
    for v in range(n_vats):
        for t in range(T):
            model.addConstr(
                y[v, t] >= gp.quicksum(x[b, v, t_start] 
                                      for b in range(n_batches) 
                                      for t_start in range(max(0, t - processing_times[b][v] + 1), min(t + 1, T - processing_times[b][v] + 1))),
                name=f"YLink_{v}_{t}"
            )
    
    # Define makespan (completion time of last batch on Vat 3)
    for b in range(n_batches):
        for t in range(T - processing_times[b][2] + 1):
            model.addConstr(z >= t + processing_times[b][2], 
                           name=f"MakespanConstraint_{b}_{t}", 
                           rhs=x[b, 2, t])
    
    # Objective function
    energy_cost = 0
    for v in range(n_vats):
        for t in range(T):
            is_peak = 1 if 5 <= t <= 7 else 0  # Periods 6-8 are peak (0-indexed: 5-7)
            cost = params[f"energy_cost_v{v+1}"] * y[v, t]
            if is_peak:
                cost *= params["peak_energy_multiplier"]
            energy_cost += cost
    
    model.setObjective(
        params["makespan_weight"] * z + params["energy_weight"] * energy_cost,
        GRB.MINIMIZE
    )
    
    # Peak energy cap constraint
    peak_energy_usage = 0
    for v in range(n_vats):
        for t in range(5, 8):  # Periods 6-8 (0-indexed: 5-7)
            peak_energy_usage += params[f"energy_cost_v{v+1}"] * params["peak_energy_multiplier"] * y[v, t]
    
    model.addConstr(peak_energy_usage <= params["peak_energy_cap"], name="PeakEnergyCap")
    
    # Optimize model
    model.optimize()
    
    # Print solution
    if model.status == GRB.OPTIMAL:
        print(f"Optimal objective value: {model.objVal}")
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    solve()
