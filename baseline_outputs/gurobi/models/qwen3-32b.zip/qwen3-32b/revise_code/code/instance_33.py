import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read items and values from table_1.csv
items = []
values = []
item_indices = {}  # Map item names to indices
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for idx, row in enumerate(reader):
        item_name = row["Item"].strip()
        item_value = int(row["Value"].strip())
        items.append(item_name)
        values.append(item_value)
        item_indices[item_name] = idx

n = len(items)

# Read general parameters
general_params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row["Parameter_Name"].strip()
        if param_name in ["num_diamonds", "num_jack_russell_dogs", "max_high_value_items_per_son", "deferred_diamonds_per_son"]:
            general_params[param_name] = int(row["Value"])
        else:
            general_params[param_name] = float(row["Value"])

# Define high-value items (value >= high_value_threshold)
high_value_threshold = general_params["high_value_threshold"]
high_value_items = [i for i in range(n) if values[i] >= high_value_threshold]
num_high_value_items = len(high_value_items)

# Identify diamond items
diamond_items = [i for i, item in enumerate(items) if "Diamond" in item]
num_diamonds = general_params["num_diamonds"]

# Identify Jack Russell dogs
jr_items = [i for i, item in enumerate(items) if "Jack Russell" in item]

# Total value of all items
total_value = sum(values)

# Create the optimization model
model = gp.Model("Inheritance_Split")
model.setParam('OutputFlag', 0)  # Suppress output

# Binary variables: x[i] = 1 if item i goes to son 1, 0 if to son 2
x = model.addMVar(shape=n, vtype=GRB.BINARY, name="x")

# Binary variables: y[i] = 1 if item i is deferred, 0 if immediate
y = model.addMVar(shape=n, vtype=GRB.BINARY, name="y")

# Value assigned to son 1 (immediate + deferred)
value_son1_immediate = gp.quicksum(values[i] * x[i] * (1 - y[i]) for i in range(n))
value_son1_deferred = gp.quicksum(values[i] * x[i] * y[i] for i in range(n))
value_son1_total = value_son1_immediate + value_son1_deferred

# Value assigned to son 2 (immediate + deferred)
value_son2_immediate = gp.quicksum(values[i] * (1 - x[i]) * (1 - y[i]) for i in range(n))
value_son2_deferred = gp.quicksum(values[i] * (1 - x[i]) * y[i] for i in range(n))
value_son2_total = value_son2_immediate + value_son2_deferred

# Objective: minimize weighted difference in immediate and total values
immediate_diff = value_son1_immediate - value_son2_immediate
total_diff = value_son1_total - value_son2_total
immediate_tax_weight = general_params["immediate_tax_weight"]
total_tax_weight = general_params["total_tax_weight"]

# Use absolute values for differences
diff_immediate = model.addVar(lb=0, name="diff_immediate")
diff_total = model.addVar(lb=0, name="diff_total")

model.addConstr(diff_immediate >= immediate_diff)
model.addConstr(diff_immediate >= -immediate_diff)
model.addConstr(diff_total >= total_diff)
model.addConstr(diff_total >= -total_diff)

# Objective function
model.setObjective(immediate_tax_weight * diff_immediate + total_tax_weight * diff_total, GRB.MINIMIZE)

# Constraints

# Son 1 must receive at least son1_min_share of the total value
son1_min_share = general_params["son1_min_share"]
model.addConstr(value_son1_total >= son1_min_share * total_value)

# High-value concentration limit
max_high_value_items_per_son = general_params["max_high_value_items_per_son"]
high_value_count_son1 = gp.quicksum(x[i] for i in high_value_items)
high_value_count_son2 = gp.quicksum(1 - x[i] for i in high_value_items)
model.addConstr(high_value_count_son1 <= max_high_value_items_per_son)
model.addConstr(high_value_count_son2 <= max_high_value_items_per_son)

# Deferred diamonds per son
deferred_diamonds_per_son = general_params["deferred_diamonds_per_son"]
deferred_diamonds_son1 = gp.quicksum(y[i] for i in diamond_items if x[i] == 1)
deferred_diamonds_son2 = gp.quicksum(y[i] for i in diamond_items if x[i] == 0)
model.addConstr(deferred_diamonds_son1 <= deferred_diamonds_per_son)
model.addConstr(deferred_diamonds_son2 <= deferred_diamonds_per_son)

# Jack Russell racing dogs must not be separated
if len(jr_items) == 2:
    model.addConstr(x[jr_items[0]] == x[jr_items[1]])

# Optimize the model
model.optimize()

# Extract solution
obj_val = model.ObjVal

# Print final objective value
print(f"FINAL_OBJ_VALUE: {obj_val}")
