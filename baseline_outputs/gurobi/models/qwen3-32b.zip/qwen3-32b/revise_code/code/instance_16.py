import os
import gurobipy as gp
from gurobipy import GRB

def load_monthly_data(filepath):
    """Load monthly purchasing and selling price data."""
    months = []
    purchasing_prices = {}
    selling_prices = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            month = int(row['Month'])
            months.append(month)
            purchasing_prices[month] = float(row['Purchasing_Price_Yuan'])
            selling_prices[month] = float(row['Selling_Price_Yuan'])
    
    return months, purchasing_prices, selling_prices

def load_general_parameters(filepath):
    """Load general parameters."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

# Construct file paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")
general_params_path = os.path.join(data_dir, "general_parameters.csv")
monthly_data_path = os.path.join(data_dir, "table_1.csv")

# Load data
months, purchasing_prices, selling_prices = load_monthly_data(monthly_data_path)
params = load_general_parameters(general_params_path)

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params.get('fixed_ordering_cost', 0)
month2_threshold = params['month2_bulk_receiving_threshold']
month2_fee = params['month2_bulk_receiving_fee']

# Create the LP problem
model = gp.Model("Maximize_Profit")
model.setParam('OutputFlag', 0)  # Suppress output

# Decision variables
# x[m] = units purchased at the beginning of month m
x = {m: model.addVar(name=f"purchase_{m}", lb=0, vtype=GRB.CONTINUOUS) for m in months}
# s[m] = units sold during month m
s = {m: model.addVar(name=f"sell_{m}", lb=0, vtype=GRB.CONTINUOUS) for m in months}
# inv[m] = inventory at end of month m
inv = {m: model.addVar(name=f"inventory_{m}", lb=0, vtype=GRB.CONTINUOUS) for m in months}

# Binary variables for fixed ordering cost (1 if purchase > 0, 0 otherwise)
y = {m: model.addVar(name=f"order_flag_{m}", vtype=GRB.BINARY) for m in months}

# Binary variable for February bulk receiving fee
z = model.addVar(name="feb_bulk_flag", vtype=GRB.BINARY)

# Objective: maximize total profit
objective = gp.LinExpr()
for m in months:
    objective += selling_prices[m] * s[m] - purchasing_prices[m] * x[m] - fixed_ordering_cost * y[m]
objective -= month2_fee * z  # Subtract the February bulk receiving fee
model.setObjective(objective, GRB.MAXIMIZE)

# Constraints
for m in months:
    # Inventory balance constraint
    if m == months[0]:
        prev_inv = initial_stock
    else:
        prev_inv = inv[m - 1]
    
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], name=f"inventory_balance_{m}")
    
    # Warehouse capacity after purchase
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, name=f"warehouse_after_purchase_{m}")
    
    # End-of-month inventory constraint
    model.addConstr(inv[m] <= warehouse_capacity, name=f"warehouse_end_{m}")
    
    # Can't sell more than what's available
    model.addConstr(s[m] <= prev_inv + x[m], name=f"sell_limit_{m}")
    
    # Fixed ordering cost activation
    model.addConstr(x[m] <= warehouse_capacity * y[m], name=f"order_flag_upper_{m}")
    model.addConstr(x[m] >= 0.0001 * y[m], name=f"order_flag_lower_{m}")

# February bulk receiving constraint
model.addConstr(x[2] <= month2_threshold + (warehouse_capacity - month2_threshold) * z, name="feb_bulk_upper")
model.addConstr(x[2] >= month2_threshold * z + 0.0001 * (1 - z), name="feb_bulk_lower")

# Optimize the model
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: No optimal solution found")
