import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Set up paths to data files
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv")) as f:
    for row in csv.DictReader(f):
        params[row['Parameter_Name'].strip()] = float(row['Value'])

# Load product-specific data
products = {}
with open(os.path.join(data_dir, "table_1.csv")) as f:
    for row in csv.DictReader(f):
        products[row['Product'].strip()] = {
            'a_hrs': float(row['Workshop_A_Hours']),
            'b_hrs': float(row['Workshop_B_Hours']),
            'insp_cost': float(row['Inspection_Sales_Cost'])
        }

# Define model
model = gp.Model("production_optimization")
model.setParam('OutputFlag', 0)  # Suppress Gurobi output

# Decision variables
x_m = model.addVar(name="microwave", vtype=GRB.INTEGER, lb=params['microwave_minimum_sales'])  # Microwave units
x_w = model.addVar(name="water_heater", vtype=GRB.INTEGER, lb=params['water_heater_minimum_sales'])  # Water heater units

# Binary variables for activation of green certification (1 if product uses workshop A)
y_m = model.addVar(vtype=GRB.BINARY, name="activate_microwave")
y_w = model.addVar(vtype=GRB.BINARY, name="activate_water_heater")

# Objective function: maximize revenue minus costs + green bonuses
# Revenue is assumed to be fixed and not provided in the data
# We focus on minimizing total cost and maximizing green bonus
total_cost = (
    x_m * (products['Microwave_Oven']['a_hrs'] * params['workshop_a_hourly_cost'] + 
           products['Microwave_Oven']['b_hrs'] * params['workshop_b_hourly_cost'] + 
           products['Microwave_Oven']['insp_cost']) +
    x_w * (products['Water_Heater']['a_hrs'] * params['workshop_a_hourly_cost'] + 
           products['Water_Heater']['b_hrs'] * params['workshop_b_hourly_cost'] + 
           products['Water_Heater']['insp_cost'])
)

green_bonus = (
    y_m * x_m * params['green_bonus_m'] + 
    y_w * x_w * params['green_bonus_w']
)

model.setObjective(total_cost - green_bonus, GRB.MINIMIZE)

# Constraints

# Workshop A available hours including overtime
model.addConstr(
    x_m * products['Microwave_Oven']['a_hrs'] + 
    x_w * products['Water_Heater']['a_hrs'] <= 
    params['workshop_a_available_hours'] + params['workshop_a_overtime_limit'],
    name="workshop_a_capacity"
)

# Workshop B minimum utilization (interpreted as a constraint from original problem)
model.addConstr(
    x_m * products['Microwave_Oven']['b_hrs'] + 
    x_w * products['Water_Heater']['b_hrs'] >= 
    params['workshop_b_available_hours'],
    name="workshop_b_min_utilization"
)

# Inspection and sales cost limit
model.addConstr(
    x_m * products['Microwave_Oven']['insp_cost'] + 
    x_w * products['Water_Heater']['insp_cost'] <= 
    params['inspection_sales_cost_limit'],
    name="inspection_sales_cost_limit"
)

# Technician pool constraint
model.addConstr(
    x_m * params['tech_rate_m'] + 
    x_w * params['tech_rate_w'] <= 
    params['tech_pool_hours'],
    name="technician_pool"
)

# Setup hours for workshop A (if product uses workshop A)
model.addConstr(
    y_m * params['setup_hours_A'] <= 
    params['workshop_a_available_hours'] + params['workshop_a_overtime_limit'],
    name="setup_hours_microwave"
)
model.addConstr(
    y_w * params['setup_hours_A'] <= 
    params['workshop_a_available_hours'] + params['workshop_a_overtime_limit'],
    name="setup_hours_water_heater"
)

# Linking constraints between production and activation
model.addConstr(x_m <= y_m * params['bigM'], name="activation_microwave")
model.addConstr(x_w <= y_w * params['bigM'], name="activation_water_heater")

# Optimize the model
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
