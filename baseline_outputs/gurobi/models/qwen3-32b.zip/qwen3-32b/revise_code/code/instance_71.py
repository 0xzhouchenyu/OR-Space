import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    base = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base, 'data')
    
    # Read general parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {row['Parameter_Name']: float(row['Value']) for row in reader}
    
    n = int(params['n'])
    premium_cost_multiplier = params['premium_cost_multiplier']
    min_premium_share = params['min_premium_share']
    
    # Read transportation volume and cost data
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    d = []  # Transportation volume between factories
    c = []  # Unit transportation cost from location p to location q
    factory_names = []
    
    for row in rows:
        factory_names.append(row['Factory'])
        d.append([
            float(row[f'Transportation_volume_to_Location_{j+1}']) 
            for j in range(n)
        ])
        c.append([
            float(row[f'Transportation_cost_to_Location_{j+1}']) 
            for j in range(n)
        ])
    
    # Calculate outbound volumes for each factory
    outbound_volumes = [sum(d[i]) for i in range(n)]
    
    # Create Gurobi model
    model = gp.Model()
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = {}  # x[i,p] = 1 if factory i is assigned to location p
    y = {}  # y[i,p] = 1 if factory i at location p uses premium service
    v_std = {}  # Standard volume handled for factory i at location p
    v_prem = {}  # Premium volume handled for factory i at location p
    
    for i in range(n):
        for p in range(n):
            x[i, p] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{p}")
            y[i, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{p}")
            
            # Standard and premium volume variables
            v_std[i, p] = model.addVar(lb=0, ub=outbound_volumes[i], name=f"v_std_{i}_{p}")
            v_prem[i, p] = model.addVar(lb=0, ub=outbound_volumes[i], name=f"v_prem_{i}_{p}")
    
    # Constraints
    
    # 1. Each factory must be assigned to exactly one location
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, p] for p in range(n)) == 1, f"c_factory_assignment_{i}")
    
    # 2. No location should host more than one factory
    for p in range(n):
        model.addConstr(gp.quicksum(x[i, p] for i in range(n)) <= 1, f"c_location_capacity_{p}")
    
    # 3. Premium mode can only be selected if the factory is assigned to the location
    for i in range(n):
        for p in range(n):
            model.addConstr(y[i, p] <= x[i, p], f"c_premium_only_if_assigned_{i}_{p}")
    
    # 4. Total volume from a factory to its location equals its outbound volume
    for i in range(n):
        for p in range(n):
            model.addConstr(
                v_std[i, p] + v_prem[i, p] == outbound_volumes[i] * x[i, p],
                f"c_total_volume_{i}_{p}"
            )
    
    # 5. If premium is selected, at least min_premium_share of the volume must be in premium mode
    for i in range(n):
        for p in range(n):
            model.addConstr(
                v_prem[i, p] >= min_premium_share * outbound_volumes[i] * y[i, p],
                f"c_min_premium_share_{i}_{p}"
            )
    
    # Objective function: minimize total cost
    total_cost = 0
    
    for i in range(n):
        for p in range(n):
            # Calculate standard unit cost for factory i at location p
            if outbound_volumes[i] > 0:
                c_std_ip = sum(d[i][j] * c[p][q] for j in range(n) for q in range(n)) / outbound_volumes[i]
            else:
                c_std_ip = 0
            
            c_prem_ip = c_std_ip * premium_cost_multiplier
            
            # Add cost contribution from this factory-location pairing
            total_cost += v_std[i, p] * c_std_ip + v_prem[i, p] * c_prem_ip
    
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Optimize the model
    model.optimize()
    
    # Print the optimal objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

solve()
