import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read staffing requirements
    requirements = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row["Time_Period"].strip()
            req = int(row["Required_Salespeople"].strip())
            requirements[period] = req
    
    # Read general parameters
    general_params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row["Parameter_Name"].strip()
            value = row["Value"].strip()
            if param_name in ["full_time_cost", "part_time_cost", "part_time_cap_per_period", "min_full_time_per_period"]:
                value = float(value) if "." in value else int(value)
            general_params[param_name] = value
    
    n = 6  # Number of periods (0 to 5)
    req_values = [requirements[f"{p}:00-{(p+1)*4%24}:00"] for p in range(n)]
    shift_start_times = [2, 6, 10, 14, 18, 22]
    full_time_cost = general_params["full_time_cost"]
    part_time_cost = general_params["part_time_cost"]
    part_time_cap_per_period = general_params["part_time_cap_per_period"]
    min_full_time_per_period = general_params["min_full_time_per_period"]

    # Create model
    model = gp.Model("StaffingOptimization")

    # Decision variables
    x = model.addVars(n, vtype=GRB.INTEGER, name="x", lb=0)  # Full-time starts at each period
    y = model.addVars(n, vtype=GRB.INTEGER, name="y", lb=0, ub=part_time_cap_per_period)  # Part-time workers per period

    # Objective: minimize total daily labor cost
    model.setObjective(full_time_cost * gp.quicksum(x[i] for i in range(n)) + 
                       part_time_cost * gp.quicksum(y[j] for j in range(n)), GRB.MINIMIZE)

    # Constraints
    for j in range(n):
        # Coverage constraint: full-time staff from two overlapping shifts + part-time workers >= required salespeople
        model.addConstr(x[j] + x[(j - 1) % n] + y[j] >= req_values[j], f"coverage_{j}")
        
        # Minimum full-time staff present in each period
        model.addConstr(x[j] + x[(j - 1) % n] >= min_full_time_per_period, f"min_full_time_{j}")

    # Solve the model
    model.setParam('OutputFlag', 0)
    model.optimize()

    # Print solution details
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
