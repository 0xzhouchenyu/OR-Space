import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters from CSV file
def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Get the path to the data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
general_params_path = os.path.join(data_dir, "general_parameters.csv")

# Load parameters
params = load_parameters(general_params_path)

# Extract parameters
cow_price = params['cow_selling_price']
sheep_price = params['sheep_selling_price']
chicken_price = params['chicken_selling_price']
cow_feed = params['cow_feed_cost']
sheep_feed = params['sheep_feed_cost']
chicken_feed = params['chicken_feed_cost']
cow_manure = params['cow_manure_production']
sheep_manure = params['sheep_manure_production']
chicken_manure = params['chicken_manure_production']
max_manure = params['max_manure_capacity']
max_chickens = params['max_chickens']
min_cows = params['min_cows']
min_sheep = params['min_sheep']
max_total = params['max_total_animals']
premium_capacity_multiplier = params['premium_capacity_multiplier']
premium_manure_multiplier = params['premium_manure_multiplier']
expansion_cost = params['expansion_cost']
premium_feed_multiplier = params['premium_feed_multiplier']
base_land_usage_cow = params['base_land_usage_cow']
base_land_usage_sheep = params['base_land_usage_sheep']
base_land_usage_chicken = params['base_land_usage_chicken']
base_land_capacity = params['base_land_capacity']
expansion_land_increase = params['expansion_land_increase']

# Create optimization model
model = gp.Model("FarmProfit")

# Decision variables
cows = model.addVar(vtype=GRB.INTEGER, lb=min_cows, name="cows")
sheep = model.addVar(vtype=GRB.INTEGER, lb=min_sheep, name="sheep")
chickens = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_chickens, name="chickens")
expanded_mode = model.addVar(vtype=GRB.BINARY, name="expanded_mode")  # Binary variable for expanded mode

# Premium animal indicators (only valid if expanded mode is active)
premium_cows = model.addVar(vtype=GRB.INTEGER, lb=0, name="premium_cows")
premium_sheep = model.addVar(vtype=GRB.INTEGER, lb=0, name="premium_sheep")
premium_chickens = model.addVar(vtype=GRB.INTEGER, lb=0, name="premium_chickens")

# Ensure premium animals are only counted when expanded mode is active
M = 1000  # Big-M constant for constraints
model.addConstr(premium_cows <= cows)
model.addConstr(premium_cows <= M * expanded_mode)
model.addConstr(premium_sheep <= sheep)
model.addConstr(premium_sheep <= M * expanded_mode)
model.addConstr(premium_chickens <= chickens)
model.addConstr(premium_chickens <= M * expanded_mode)

# Objective function: maximize profit
profit_cows = (cow_price - cow_feed) * (cows - premium_cows) + (cow_price - cow_feed * premium_feed_multiplier) * premium_cows
profit_sheep = (sheep_price - sheep_feed) * (sheep - premium_sheep) + (sheep_price - sheep_feed * premium_feed_multiplier) * premium_sheep
profit_chickens = (chicken_price - chicken_feed) * (chickens - premium_chickens) + (chicken_price - chicken_feed * premium_feed_multiplier) * premium_chickens

model.setObjective(profit_cows + profit_sheep + profit_chickens - expansion_cost * expanded_mode, GRB.MAXIMIZE)

# Manure constraint (adjusted for expanded mode)
manure_cows = cow_manure * (cows - premium_cows) + cow_manure * premium_cows * premium_manure_multiplier
manure_sheep = sheep_manure * (sheep - premium_sheep) + sheep_manure * premium_sheep * premium_manure_multiplier
manure_chickens = chicken_manure * (chickens - premium_chickens) + chicken_manure * premium_chickens * premium_manure_multiplier

model.addConstr(manure_cows + manure_sheep + manure_chickens <= max_manure * (1 + (premium_manure_multiplier - 1) * expanded_mode))

# Land usage constraint (adjusted for expanded mode)
land_cows = base_land_usage_cow * (cows - premium_cows) + base_land_usage_cow * premium_cows * premium_capacity_multiplier
land_sheep = base_land_usage_sheep * (sheep - premium_sheep) + base_land_usage_sheep * premium_sheep * premium_capacity_multiplier
land_chickens = base_land_usage_chicken * (chickens - premium_chickens) + base_land_usage_chicken * premium_chickens * premium_capacity_multiplier

model.addConstr(land_cows + land_sheep + land_chickens <= base_land_capacity + expansion_land_increase * expanded_mode)

# Total animals constraint (adjusted for expanded mode)
total_animals = cows + sheep + chickens
model.addConstr(total_animals <= max_total * (1 + (premium_capacity_multiplier - 1) * expanded_mode))

# Optimize the model
model.setParam('OutputFlag', 0)
model.optimize()

# Print results
if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print("No optimal solution found.")
