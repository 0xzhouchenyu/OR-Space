import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    W = params['initial_investment']       # 100000
    r1 = params['return_rate_option_1']    # 0.7
    r2 = params['return_rate_option_2']    # 2.0
    T = int(params['planning_horizon'])    # 3
    min_r1 = params['min_reserve_year1']   # 10000
    min_r2 = params['min_reserve_year2']   # 15000
    max_opt2_start = params['max_option2_start']  # 30000
    late_settlement_rate = params['option2_year0_late_settlement_rate']  # 0.02
    
    model = gp.Model("Investment_Optimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x0_1 = model.addVar(name="x0_1", lb=0)  # Year 0 investment in Option 1 (1-year)
    x0_2 = model.addVar(name="x0_2", lb=0)  # Year 0 investment in Option 2 (2-year)
    x1_1 = model.addVar(name="x1_1", lb=0)  # Year 1 investment in Option 1 (1-year)
    x1_2 = model.addVar(name="x1_2", lb=0)  # Year 1 investment in Option 2 (2-year)
    x2_1 = model.addVar(name="x2_1", lb=0)  # Year 2 investment in Option 1 (1-year)
    
    # Year 0 budget constraint
    model.addConstr(x0_1 + x0_2 <= W, "year0_budget")
    
    # Year 1: money available = returns from x0_1 = x0_1 * (1 + r1)
    # After investing x1_1 and x1_2, we must maintain a minimum reserve
    model.addConstr(x0_1 * (1 + r1) - (x1_1 + x1_2) >= min_r1, "year1_reserve")
    
    # Year 2: money available = returns from x1_1 + returns from x0_2 (with late settlement rate)
    # After investing x2_1, we must maintain a minimum reserve
    model.addConstr(x1_1 * (1 + r1) + x0_2 * (1 + r2) * (1 - late_settlement_rate) - x2_1 >= min_r2, "year2_reserve")
    
    # Objective: maximize total wealth at year 3
    # Wealth at year 3 = returns from x2_1 (1-year investment from year 2) 
    #                 + returns from x1_2 (2-year investment from year 1)
    #                 + returns from x0_2 (2-year investment from year 0) after late settlement
    obj = (
        x2_1 * (1 + r1) +
        x1_2 * (1 + r2) +
        x0_2 * (1 + r2) * (1 - late_settlement_rate)
    )
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Additional constraints
    model.addConstr(x0_2 <= max_opt2_start, "max_opt2_start_year0")
    model.addConstr(x1_2 <= max_opt2_start, "max_opt2_start_year1")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        final_obj_value = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {final_obj_value}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
