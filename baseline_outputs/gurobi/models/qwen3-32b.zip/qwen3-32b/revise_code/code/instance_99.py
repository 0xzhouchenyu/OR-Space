import os
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    """Load a CSV file and return headers and rows."""
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    return rows

def load_general_parameters():
    """Load general parameters into a dictionary."""
    rows = load_csv("general_parameters.csv")
    params = {}
    for row in rows:
        params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_reliability_table():
    """Load reliability table. Returns dict: {num_spares: [r1, r2, r3]}"""
    rows = load_csv("table_1.csv")
    reliability = {}
    for row in rows:
        n_spares = int(row['Number_of_Spares'])
        r1 = float(row['Component_1_Reliability'])
        r2 = float(row['Component_2_Reliability'])
        r3 = float(row['Component_3_Reliability'])
        reliability[n_spares] = [r1, r2, r3]
    return reliability

def solve():
    # Load data
    params = load_general_parameters()
    reliability = load_reliability_table()
    
    # Extract parameters
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    budget_A = params['total_budget_scenario_A']
    budget_B = params['total_budget_scenario_B']
    weight_A = params['weight_limit_scenario_A']
    weight_B = params['weight_limit_scenario_B']
    
    # Get max number of spares
    max_spares = max(reliability.keys())
    
    # Create Gurobi model
    model = gp.Model("Reliability_Optimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: s_i is the number of spares for component i (i=1,2,3)
    s = []
    for i in range(3):
        s.append(model.addVar(vtype=GRB.INTEGER, name=f"s_{i+1}", lb=0, ub=max_spares))
    
    # Calculate total cost and weight
    total_cost = sum(s[i] * unit_price[i] for i in range(3))
    total_weight = sum(s[i] * unit_weight[i] for i in range(3))
    
    # Add constraints to satisfy both scenarios' budgets and weights
    model.addConstr(total_cost <= budget_A, "budget_A")
    model.addConstr(total_cost <= budget_B, "budget_B")
    model.addConstr(total_weight <= weight_A, "weight_A")
    model.addConstr(total_weight <= weight_B, "weight_B")
    
    # Component reliabilities based on spare counts
    r1 = model.addVars(max_spares + 1, name="r1")
    r2 = model.addVars(max_spares + 1, name="r2")
    r3 = model.addVars(max_spares + 1, name="r3")
    
    # Set reliability values for each possible number of spares
    for n in range(max_spares + 1):
        if n in reliability:
            r1[n].lb = reliability[n][0]
            r1[n].ub = reliability[n][0]
            r2[n].lb = reliability[n][1]
            r2[n].ub = reliability[n][1]
            r3[n].lb = reliability[n][2]
            r3[n].ub = reliability[n][2]
    
    # Link reliability variables to spare count variables using indicator constraints
    for i in range(3):
        for n in range(max_spares + 1):
            if i == 0:
                model.addGenConstrIndicator(s[0] == n, True, r1[n] == reliability[n][0])
            elif i == 1:
                model.addGenConstrIndicator(s[1] == n, True, r2[n] == reliability[n][1])
            else:
                model.addGenConstrIndicator(s[2] == n, True, r3[n] == reliability[n][2])
    
    # System reliability is the product of component reliabilities
    system_reliability = r1[s[0]] * r2[s[1]] * r3[s[2]]
    
    # Objective: maximize expected system reliability (average of scenario reliabilities)
    model.setObjective(system_reliability, GRB.MAXIMIZE)
    
    # Optimize the model
    model.optimize()
    
    # Print results
    if model.status == GRB.OPTIMAL:
        best_combo = [int(s[i].x) for i in range(3)]
        print(f"Optimal spare parts allocation: Component 1: {best_combo[0]}, Component 2: {best_combo[1]}, Component 3: {best_combo[2]}")
        
        total_cost_value = sum(best_combo[i] * unit_price[i] for i in range(3))
        total_weight_value = sum(best_combo[i] * unit_weight[i] for i in range(3))
        
        print(f"Total cost: {total_cost_value}")
        print(f"Total weight: {total_weight_value}")
        
        r1_value = reliability[best_combo[0]][0]
        r2_value = reliability[best_combo[1]][1]
        r3_value = reliability[best_combo[2]][2]
        print(f"Component reliabilities: {r1_value}, {r2_value}, {r3_value}")
        
        final_obj_value = r1_value * r2_value * r3_value
        print(f"FINAL_OBJ_VALUE: {final_obj_value}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    import csv
    solve()
