import os
import gurobipy as gp
from gurobipy import GRB
import pandas as pd

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    table_1 = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)

    param_dict = dict(zip(params['Parameter_Name'], params['Value']))
    demand = dict(zip(table_1['stage'], table_1['tool_requirement']))

    return param_dict, demand

def solve():
    param_dict, demand = load_data()

    n = int(param_dict['n'])
    cost_new = float(param_dict['cost_new_tool'])
    cost_fast = float(param_dict['cost_fast_repair'])
    cost_slow = float(param_dict['cost_slow_repair'])
    dur_fast = int(param_dict['fast_repair_duration'])
    dur_slow = int(param_dict['slow_repair_duration'])
    max_fast_stage = int(param_dict['max_fast_stage'])
    max_slow_stage = int(param_dict['max_slow_stage'])
    emission_buy = float(param_dict['emission_buy'])
    emission_fast = float(param_dict['emission_fast_repair'])
    emission_slow = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_shortage = float(param_dict['penalty_shortage'])

    stages = list(range(1, n + 1))
    model = gp.Model("Tool_Repair_Problem")

    # Decision variables
    x = model.addVars(stages, vtype=GRB.INTEGER, name="buy", lb=0)  # New tools bought at each stage
    y = model.addVars(stages, vtype=GRB.INTEGER, name="fast", lb=0, ub=max_fast_stage)  # Tools sent to fast repair
    z = model.addVars(stages, vtype=GRB.INTEGER, name="slow", lb=0, ub=max_slow_stage)  # Tools sent to slow repair
    c = model.addVars([0] + stages, vtype=GRB.INTEGER, name="clean", lb=0)  # Clean tools available at the start of each stage
    d = model.addVars([0] + stages, vtype=GRB.INTEGER, name="dirty", lb=0)  # Dirty tools waiting for repair after each stage
    s = model.addVars(stages, vtype=GRB.INTEGER, name="shortage", lb=0)  # Shortage in meeting tool requirements

    prebuy_clean = model.addVar(vtype=GRB.INTEGER, name="prebuy_clean", lb=0)  # Initial clean stock before stage 1
    c[0].lb = prebuy_clean.lb  # Ensure initial clean stock is non-negative
    model.addConstr(c[0] == prebuy_clean, name="initial_clean_stock")

    # Carbon emissions
    total_emissions = model.addVar(vtype=GRB.CONTINUOUS, name="total_emissions")
    model.addConstr(total_emissions == emission_buy * gp.quicksum(x[i] for i in stages) +
                    emission_fast * gp.quicksum(y[i] for i in stages) +
                    emission_slow * gp.quicksum(z[i] for i in stages), name="total_emissions_constr")
    model.addConstr(total_emissions <= carbon_budget, name="carbon_budget")

    # Flow constraints
    for i in stages:
        # Fast repair ready at stage i: y[i - dur_fast] if i >= dur_fast + 1
        fast_ready = y[i - dur_fast] if i - dur_fast >= 1 else 0
        # Slow repair ready at stage i: z[i - dur_slow] if i >= dur_slow + 1
        slow_ready = z[i - dur_slow] if i - dur_slow >= 1 else 0

        # Clean tools at stage i: previous clean tools + repaired tools - used tools + new purchases
        model.addConstr(
            c[i] == c[i-1] + fast_ready + slow_ready - (demand[i] - s[i]) + x[i],
            name=f"clean_tools_{i}"
        )

        # Dirty tools at stage i: previous dirty tools + used tools - repaired tools
        model.addConstr(
            d[i] == d[i-1] + (demand[i] - s[i]) - y[i] - z[i],
            name=f"dirty_tools_{i}"
        )

    # Objective function
    objective = (
        cost_new * gp.quicksum(x[i] for i in stages) +
        cost_fast * gp.quicksum(y[i] for i in stages) +
        cost_slow * gp.quicksum(z[i] for i in stages) +
        penalty_shortage * gp.quicksum(s[i] for i in stages)
    )
    model.setObjective(objective, GRB.MINIMIZE)

    # Solve the model
    model.setParam('OutputFlag', 0)
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
