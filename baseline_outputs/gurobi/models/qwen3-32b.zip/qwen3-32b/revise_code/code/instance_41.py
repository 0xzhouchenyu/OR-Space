import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
initial_capital = 0.0
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "initial_capital":
            initial_capital = float(row["Value"].strip())

# Load liquidity policy parameters
min_year3_reserve = 0.0
reserve_shortfall_penalty = 0.0
with open(os.path.join(data_dir, "liquidity_policy.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "min_year3_reserve":
            min_year3_reserve = float(row["Value"].strip())
        elif row["Parameter_Name"].strip() == "reserve_shortfall_penalty":
            reserve_shortfall_penalty = float(row["Value"].strip())

# Load project data
projects = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        projects.append(row)

# Create Gurobi model
model = gp.Model("Investment_Maximization")
model.setParam('OutputFlag', 0)  # Suppress output

# Decision variables
x1_1 = model.addVar(name="x1_1", lb=0)  # Project 1 at beginning of Year 1
x1_2 = model.addVar(name="x1_2", lb=0)  # Project 1 at beginning of Year 2
x1_3 = model.addVar(name="x1_3", lb=0)  # Project 1 at beginning of Year 3
x2 = model.addVar(name="x2", lb=0, ub=float(projects[1]["Investment_Capacity"]))  # Project 2 at beginning of Year 1
x3 = model.addVar(name="x3", lb=0, ub=float(projects[2]["Investment_Capacity"]))  # Project 3 at beginning of Year 2
x4 = model.addVar(name="x4", lb=0, ub=float(projects[3]["Investment_Capacity"]))  # Project 4 at beginning of Year 3

# Year 1 budget constraint: x1_1 + x2 <= initial_capital
model.addConstr(x1_1 + x2 <= initial_capital, "Year1_Budget")

# Year 2 budget constraint: available cash = proceeds from x1_1 (matured same year = end of year 1)
# x1_1 * 1.20 is available at beginning of Year 2
# x1_2 + x3 <= x1_1 * 1.20
model.addConstr(x1_2 + x3 <= x1_1 * 1.20, "Year2_Budget")

# Calculate available cash at beginning of Year 3
available_cash_y3 = x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60

# Amount invested in Year 3 projects
invested_y3 = x1_3 + x4

# Cash reserved at beginning of Year 3
cash_reserved_y3 = available_cash_y3 - invested_y3

# Shortfall from the minimum required reserve
shortfall_y3 = model.addVar(name="shortfall_y3", lb=0)
model.addConstr(shortfall_y3 >= min_year3_reserve - cash_reserved_y3, "Reserve_Shortfall")

# Objective: total money at end of Year 3 minus penalty for shortfall
# Returns from Year 3 investments + cash reserved at beginning of Year 3
# Minus penalty for any shortfall below the minimum reserve
objective = (
    x1_3 * 1.20 + x4 * 1.40 + cash_reserved_y3 
    - shortfall_y3 * reserve_shortfall_penalty
)
model.setObjective(objective, GRB.MAXIMIZE)

# Optimize the model
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
