import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters from CSV file
def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Define the path to the data file
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

# Load parameters
params = load_general_parameters(params_file)

# Extract parameters
m1_liquid = params['machine_1_time_per_liquid_lot']  # 50 min per lot
m2_liquid = params['machine_2_time_per_liquid_lot']  # 30 min per lot
m1_solid = params['machine_1_time_per_solid_lot']    # 24 min per lot
m2_solid = params['machine_2_time_per_solid_lot']    # 33 min per lot

init_liquid = params['initial_liquid_inventory']  # 30 lots
init_solid = params['initial_solid_inventory']    # 90 lots

m1_base_avail = params['machine_1_available_time'] * 60  # 40 hours -> 2400 minutes
m2_base_avail = params['machine_2_available_time'] * 60  # 35 hours -> 2100 minutes
extra_minutes = params['extended_extra_minutes']  # 600 minutes extra when using extended mode
labor_hours_per_extended = params['labor_hours_per_machine_extended']  # 8 hours per machine
labor_budget = params['labor_budget_hours']  # 10 hours total labor budget
extended_mode_penalty = params['extended_mode_penalty']  # 0.5 score deduction per extended machine
priority_reserve = params['priority_reserve_lots']  # 10 lots that count fully
excess_credit = params['excess_reserve_credit']  # 0.35 score per lot above priority band

demand_liquid = params['forecast_liquid_demand']  # 75 lots
demand_solid = params['forecast_solid_demand']    # 95 lots

# Create optimization model
model = gp.Model("Fertilizer_Production_Rev")

# Decision variables
x_liquid = model.addVar(name="x_liquid", lb=0)  # Lots of liquid fertilizer produced
x_solid = model.addVar(name="x_solid", lb=0)    # Lots of solid fertilizer produced

# Extended mode binary variables (1 if machine is run in extended mode, 0 otherwise)
ext_m1 = model.addVar(vtype=GRB.BINARY, name="ext_m1")
ext_m2 = model.addVar(vtype=GRB.BINARY, name="ext_m2")

# Calculate ending inventory
end_liquid = init_liquid + x_liquid - demand_liquid
end_solid = init_solid + x_solid - demand_solid

# Resilience score calculation
# For each product: first `priority_reserve` closing lots count fully, rest count at `excess_reserve_credit`
score_liquid = gp.min_(end_liquid, priority_reserve) + excess_credit * gp.max_(end_liquid - priority_reserve, 0)
score_solid = gp.min_(end_solid, priority_reserve) + excess_credit * gp.max_(end_solid - priority_reserve, 0)

# Total resilience score minus penalties for extended mode
total_score = score_liquid + score_solid - extended_mode_penalty * (ext_m1 + ext_m2)

# Set objective
model.setObjective(total_score, GRB.MAXIMIZE)

# Machine time constraints
# Base available time + extra time if extended mode is used
m1_total_time = m1_liquid * x_liquid + m1_solid * x_solid
m2_total_time = m2_liquid * x_liquid + m2_solid * x_solid

model.addConstr(m1_total_time <= m1_base_avail + extra_minutes * ext_m1, "Machine_1_Capacity")
model.addConstr(m2_total_time <= m2_base_avail + extra_minutes * ext_m2, "Machine_2_Capacity")

# Labor constraint for extended mode
model.addConstr(labor_hours_per_extended * (ext_m1 + ext_m2) <= labor_budget, "Labor_Budget")

# Demand satisfaction constraints
model.addConstr(end_liquid >= 0, "Liquid_Demand_Satisfaction")
model.addConstr(end_solid >= 0, "Solid_Demand_Satisfaction")

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal:.2f}")
