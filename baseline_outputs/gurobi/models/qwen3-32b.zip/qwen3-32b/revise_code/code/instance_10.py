import os
import gurobipy as gp
from gurobipy import GRB

def load_coverage_data(data_dir):
    """Load the coverage data from table_1.csv."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)  # skip header
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    
    return areas, coverage

def load_general_parameters(data_dir):
    """Load general parameters from general_parameters.csv."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load data
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    distance_limit = int(params.get('distance_limit', 800))
    small_cost = int(params.get('small_cost', 1))
    large_cost = int(params.get('large_cost', 2))
    small_cap_areas = int(params.get('small_cap_areas', 3))
    max_large_stores = int(params.get('max_large_stores', 1))
    min_small_stores = int(params.get('minimum_neighborhood_counters', 6))
    
    # Create model
    model = gp.Model("MinChainStoresRevised")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    small_store = model.addVars(areas, vtype=GRB.BINARY, name="Small_Store")
    large_store = model.addVars(areas, vtype=GRB.BINARY, name="Large_Store")
    
    # Objective: minimize total cost
    model.setObjective(
        small_cost * gp.quicksum(small_store[i] for i in areas) + 
        large_cost * gp.quicksum(large_store[i] for i in areas), 
        GRB.MINIMIZE
    )
    
    # Constraint: Each residential area must be covered by at least one store
    for area in areas:
        covering_stores = [j for j in areas if area in coverage[j]]
        small_coverage = gp.LinExpr()
        large_coverage = gp.LinExpr()
        
        for j in covering_stores:
            small_coverage += small_store[j]
            large_coverage += large_store[j]
            
        model.addConstr(small_coverage + large_coverage >= 1, f"Cover_{area}")
    
    # Constraint: Small stores can only cover up to small_cap_areas residential areas
    for j in areas:
        covered_by_j = coverage[j]
        model.addConstr(gp.quicksum(small_store[j] for _ in covered_by_j) <= small_cap_areas * small_store[j], 
                        f"Small_Capacity_{j}")
    
    # Constraint: Maximum number of large stores allowed
    model.addConstr(gp.quicksum(large_store[j] for j in areas) <= max_large_stores, "Max_Large")
    
    # Constraint: Minimum number of small stores required
    model.addConstr(gp.quicksum(small_store[j] for j in areas) >= min_small_stores, "Min_Small")
    
    # Optimize
    model.optimize()
    
    # Output results
    if model.status == GRB.OPTIMAL:
        final_obj_value = model.objVal
        print(f"FINAL_OBJ_VALUE: {final_obj_value}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
