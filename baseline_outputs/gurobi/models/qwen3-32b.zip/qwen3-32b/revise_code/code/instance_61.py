import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read device data from table_1.csv
devices = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            'name': row['Device'].strip(),
            'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
            'max_cap': float(row['Max_Processing_Capacity_Units'].strip())
        })

# Read general parameters
general_params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        general_params[param_name] = float(row['Value'].strip())

# Extract relevant parameters
required_units = general_params["required_units"]
energy_budget_peak = general_params["energy_budget_peak"]
energy_budget_offpeak = general_params["energy_budget_offpeak"]
startup_budget = general_params["startup_budget"]
energy_price_peak = general_params["energy_price_peak"]
energy_price_offpeak = general_params["energy_price_offpeak"]

# Energy per unit and startup energy by device
energy_per_unit = {
    "A": general_params.get("energy_per_unit_A", 0),
    "B": general_params.get("energy_per_unit_B", 0),
    "C": general_params.get("energy_per_unit_C", 0),
    "D": general_params.get("energy_per_unit_D", 0),
}

startup_energy = {
    "A": general_params.get("startup_energy_A", 0),
    "B": general_params.get("startup_energy_B", 0),
    "C": general_params.get("startup_energy_C", 0),
    "D": general_params.get("startup_energy_D", 0),
}

startup_cost_value = general_params["startup_cost"]

# Create the optimization model
model = gp.Model("MinCostProductionWithEnergyConstraints")
model.setParam('OutputFlag', 0)  # Suppress Gurobi output

# Decision variables
x = {}  # x[d]: number of units produced on device d
y = {}  # y[d]: binary variable indicating whether device d is used
z_peak = {}  # z_peak[d]: binary variable indicating if device d is used in peak period
z_offpeak = {}  # z_offpeak[d]: binary variable indicating if device d is used in off-peak period

for dev in devices:
    name = dev["name"]
    x[name] = model.addVar(lb=0, ub=dev["max_cap"], vtype=GRB.CONTINUOUS, name=f"x_{name}")
    y[name] = model.addVar(vtype=GRB.BINARY, name=f"y_{name}")
    z_peak[name] = model.addVar(vtype=GRB.BINARY, name=f"z_peak_{name}")
    z_offpeak[name] = model.addVar(vtype=GRB.BINARY, name=f"z_offpeak_{name}")

# Objective: minimize total cost
# Total cost = sum(prep_cost * y[d] + unit_cost * x[d]) + 
#             sum(startup_cost * (z_peak[d] + z_offpeak[d])) +
#             sum(energy_price_peak * energy_per_unit[d] * x[d] * z_peak[d] + 
#                 energy_price_offpeak * energy_per_unit[d] * x[d] * z_offpeak[d])

objective = gp.LinExpr()

# Fixed preparation costs
for dev in devices:
    name = dev["name"]
    objective += dev["prep_cost"] * y[name]

# Unit production costs
for dev in devices:
    name = dev["name"]
    objective += dev["unit_cost"] * x[name]

# Startup costs
for dev in devices:
    name = dev["name"]
    objective += startup_cost_value * (z_peak[name] + z_offpeak[name])

# Electricity costs
for dev in devices:
    name = dev["name"]
    objective += (
        energy_price_peak * energy_per_unit[name] * x[name] * z_peak[name]
        + energy_price_offpeak * energy_per_unit[name] * x[name] * z_offpeak[name]
    )

model.setObjective(objective, GRB.MINIMIZE)

# Constraints

# 1. Total production must equal required units
model.addConstr(gp.quicksum(x[dev["name"]] for dev in devices) == required_units, "TotalProduction")

# 2. Linking constraints: x[d] <= max_cap * y[d]
for dev in devices:
    name = dev["name"]
    model.addConstr(x[name] <= dev["max_cap"] * y[name], f"Link_{name}")

# 3. If a device is used, it must be used in at least one period
for dev in devices:
    name = dev["name"]
    model.addConstr(y[name] <= z_peak[name] + z_offpeak[name], f"UseInAtLeastOnePeriod_{name}")

# 4. Peak energy budget constraint
peak_energy_usage = gp.LinExpr()
for dev in devices:
    name = dev["name"]
    peak_energy_usage += energy_per_unit[name] * x[name] * z_peak[name]
model.addConstr(peak_energy_usage <= energy_budget_peak, "PeakEnergyBudget")

# 5. Off-peak energy budget constraint
offpeak_energy_usage = gp.LinExpr()
for dev in devices:
    name = dev["name"]
    offpeak_energy_usage += energy_per_unit[name] * x[name] * z_offpeak[name]
model.addConstr(offpeak_energy_usage <= energy_budget_offpeak, "OffpeakEnergyBudget")

# 6. Startup budget constraint
startup_cost_expr = gp.LinExpr()
for dev in devices:
    name = dev["name"]
    startup_cost_expr += startup_cost_value * (z_peak[name] + z_offpeak[name])
model.addConstr(startup_cost_expr <= startup_budget, "StartupBudget")

# Optimize the model
model.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
