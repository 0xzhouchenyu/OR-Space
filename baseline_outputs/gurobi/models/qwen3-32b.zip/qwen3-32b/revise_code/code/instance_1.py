import os
import sys
import gurobipy as gp
from gurobipy import GRB

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Custom utility functions to load data
def load_csv(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            rows.append(row)
    return rows

def load_parameters():
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name'].strip()
        val = row['Value'].strip()
        try:
            if '.' in val:
                params[name] = float(val)
            else:
                params[name] = int(val)
        except ValueError:
            params[name] = val
    return params

def load_demand():
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        week = int(row['Week'].strip())
        demand[week] = {
            'I': int(row['I'].strip()),
            'II': int(row['II'].strip())
        }
    return demand

# Load parameters and demand
params = load_parameters()
demand = load_demand()

T = 8  # weeks
weeks = range(1, T + 1)

# Parameters
S0 = params['skilled_worker_count']  # 50
rate_I = params['food_I_production_rate']  # 10 kg/h
rate_II = params['food_II_production_rate']  # 6 kg/h
normal_hours = params['worker_weekly_hours']  # 40
overtime_hours = params['skilled_worker_overtime_hours']  # 60
train_cap = params['training_capacity']  # 3 trainees per trainer
train_period = params['training_period']  # 2 weeks
wage_skilled = params['skilled_worker_weekly_wage']  # 360
wage_trainee_during = params['trainee_weekly_wage_during_training']  # 120
wage_trainee_after = params['trainee_weekly_wage_after_training']  # 240
wage_overtime = params['skilled_worker_overtime_wage']  # 540
comp_I = params['compensation_fee_food_I']  # 0.5
comp_II = params['compensation_fee_food_II']  # 0.6
new_worker_goal = params['new_worker_training_goal']  # 50

# Create model
model = gp.Model("factory_training")

# Decision variables
# n_train[t] = number of skilled workers assigned to training starting in week t
n_train = {}
for t in weeks:
    if t <= T - 1:  # Can start training in weeks 1..7 (need 2 weeks)
        n_train[t] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_train_{t}")

# Hours allocated to food I and II by skilled workers (normal and overtime)
# and by graduated trainees
h_I_s = {t: model.addVar(lb=0, name=f"hIs_{t}") for t in weeks}
h_II_s = {t: model.addVar(lb=0, name=f"hIIs_{t}") for t in weeks}
h_I_ot = {t: model.addVar(lb=0, name=f"hIot_{t}") for t in weeks}
h_II_ot = {t: model.addVar(lb=0, name=f"hIIot_{t}") for t in weeks}

# Graduated trainees hours
h_I_g = {t: model.addVar(lb=0, name=f"hIg_{t}") for t in weeks}
h_II_g = {t: model.addVar(lb=0, name=f"hIIg_{t}") for t in weeks}

# Number of skilled workers doing overtime in week t
n_overtime = {t: model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_ot_{t}") for t in weeks}

# Delayed delivery (backlog) for food I and II
backlog_I = {t: model.addVar(lb=0, name=f"bI_{t}") for t in weeks}
backlog_II = {t: model.addVar(lb=0, name=f"bII_{t}") for t in weeks}

# Binary variable indicating whether the factory produces Food I or Food II in week t
produce_I = {t: model.addVar(vtype=GRB.BINARY, name=f"produce_I_{t}") for t in weeks}
produce_II = {t: model.addVar(vtype=GRB.BINARY, name=f"produce_II_{t}") for t in weeks}

# Ensure only one product is produced per week
for t in weeks:
    model.addConstr(produce_I[t] + produce_II[t] <= 1, name=f"mutual_exclusion_{t}")

# Available skilled workers for production in week t
# = S0 - trainers busy in week t
def trainers_busy(t):
    """Number of skilled workers busy training in week t"""
    expr = 0
    for s in n_train:
        if s <= t <= s + train_period - 1:
            expr += n_train[s]
    return expr

# Graduated trainees available in week t
def graduates_available(t):
    """Number of graduated trainees available in week t"""
    expr = 0
    for s in n_train:
        if s + train_period <= t:  # available from week s+2
            expr += train_cap * n_train[s]
    return expr

# Constraints for each week
for t in weeks:
    busy_t = trainers_busy(t)
    avail_skilled_t = S0 - busy_t  # skilled workers available for production
    
    # Skilled workers available for production (non-overtime)
    # Some of these may do overtime
    # Normal skilled hours available = (avail_skilled_t - n_overtime[t]) * normal_hours
    # Overtime skilled hours available = n_overtime[t] * overtime_hours
    
    model.addConstr(n_overtime[t] <= avail_skilled_t, f"ot_limit_{t}")
    
    # Hours constraints for skilled normal workers
    model.addConstr(h_I_s[t] + h_II_s[t] <= (avail_skilled_t - n_overtime[t]) * normal_hours, f"skilled_normal_hours_{t}")
    
    # Hours constraints for overtime workers
    model.addConstr(h_I_ot[t] + h_II_ot[t] <= n_overtime[t] * overtime_hours, f"skilled_ot_hours_{t}")
    
    # Hours constraints for graduates (they work normal_hours at wage_trainee_after)
    grads_t = graduates_available(t)
    model.addConstr(h_I_g[t] + h_II_g[t] <= grads_t * normal_hours, f"grad_hours_{t}")
    
    # Production in week t
    prod_I_t = (h_I_s[t] + h_I_ot[t] + h_I_g[t]) * rate_I
    prod_II_t = (h_II_s[t] + h_II_ot[t] + h_II_g[t]) * rate_II
    
    # Backlog balance
    prev_bI = backlog_I[t-1] if t > 1 else 0
    prev_bII = backlog_II[t-1] if t > 1 else 0
    
    model.addConstr(backlog_I[t] >= prev_bI + demand[t]['I'] - prod_I_t, f"backlog_I_{t}")
    model.addConstr(backlog_II[t] >= prev_bII + demand[t]['II'] - prod_II_t, f"backlog_II_{t}")

# Ensure that all productive hours are used for the selected product
for t in weeks:
    model.addConstr(h_I_s[t] <= produce_I[t] * GRB.INFINITY, f"prod_I_only_I_s_{t}")
    model.addConstr(h_I_ot[t] <= produce_I[t] * GRB.INFINITY, f"prod_I_only_I_ot_{t}")
    model.addConstr(h_I_g[t] <= produce_I[t] * GRB.INFINITY, f"prod_I_only_I_g_{t}")
    model.addConstr(h_II_s[t] <= produce_II[t] * GRB.INFINITY, f"prod_II_only_II_s_{t}")
    model.addConstr(h_II_ot[t] <= produce_II[t] * GRB.INFINITY, f"prod_II_only_II_ot_{t}")
    model.addConstr(h_II_g[t] <= produce_II[t] * GRB.INFINITY, f"prod_II_only_II_g_{t}")

# Ensure enough skilled workers are available for training
for t in weeks:
    busy_t = trainers_busy(t)
    model.addConstr(S0 - busy_t >= 0, f"enough_skilled_{t}")

# Must train at least 50 new workers by end of week 8
total_trained = 0
for s in n_train:
    total_trained += train_cap * n_train[s]
model.addConstr(total_trained >= new_worker_goal, "training_goal")

# Objective function
# Cost components
# Skilled worker wages
cost_skilled = sum((avail_skilled_t - n_overtime[t]) * wage_skilled for t in weeks)
# Overtime wages
cost_overtime = sum(n_overtime[t] * wage_overtime for t in weeks)
# Trainer wages (same as skilled worker wages)
# Trainee wages during training
cost_trainee_during = 0
for s in n_train:
    cost_trainee_during += 2 * n_train[s] * wage_trainee_during  # 2 weeks of training
# Graduated trainee wages after training
cost_trainee_after = 0
for t in weeks:
    grads_t = graduates_available(t)
    cost_trainee_after += grads_t * wage_trainee_after
# Compensation fees
cost_compensation = 0
for t in weeks:
    cost_compensation += comp_I * backlog_I[t]
    cost_compensation += comp_II * backlog_II[t]

# Total objective
model.setObjective(cost_skilled + cost_overtime + cost_trainee_during + cost_trainee_after + cost_compensation, GRB.MINIMIZE)

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
