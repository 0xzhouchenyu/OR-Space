import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    budget = params['company_budget']
    max_employees = int(params['max_employees'])
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_gj = int(params['max_one_candidate_g_j'])
    lead_premium = params['lead_premium']
    min_leads = int(params['min_leads'])
    mentor_bonus = params['mentor_bonus']
    max_pairs = int(params['max_pairs'])
    
    # Create optimization model
    model = gp.Model("HiringOptimization")
    model.setParam('OutputFlag', 0)  # Suppress Gurobi output
    
    # Decision variables: binary for each candidate (hired or not)
    x = {}
    for c in candidates:
        x[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{c['name']}")
    
    # Decision variables: binary for each candidate being a Lead
    y = {}
    for c in candidates:
        y[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"y_{c['name']}")
    
    # Objective: minimize total net cost
    # Net cost = sum(salary + lead_premium * y_c) - mentor_bonus * number_of_pairs
    salary_cost = gp.LinExpr()
    for c in candidates:
        salary_cost += (c['salary'] + lead_premium * y[c['name']]) * x[c['name']]
    
    # To calculate the number of pairs, we need to count the minimum of leads and engineers
    num_leads = gp.LinExpr()
    num_engineers = gp.LinExpr()
    for c in candidates:
        num_leads += y[c['name']] * x[c['name']]
        num_engineers += (1 - y[c['name']]) * x[c['name']]
    
    # Number of pairs is the minimum of leads and engineers, capped at max_pairs
    z = model.addVar(vtype=GRB.INTEGER, name="z", lb=0, ub=max_pairs)
    
    # Add constraints to ensure z <= min(num_leads, num_engineers)
    model.addConstr(z <= num_leads)
    model.addConstr(z <= num_engineers)
    
    # Final objective
    model.setObjective(salary_cost - mentor_bonus * z, GRB.MINIMIZE)
    
    # Budget constraint
    model.addConstr(gp.quicksum((c['salary'] + lead_premium * y[c['name']]) * x[c['name']] for c in candidates) <= budget, "Budget")
    
    # Max employees constraint
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, "MaxEmployees")
    
    # Min skill level constraint
    model.addConstr(gp.quicksum(c['skill'] * x[c['name']] for c in candidates) >= min_skill, "MinSkill")
    
    # Min project management experience constraint
    model.addConstr(gp.quicksum(c['pm_exp'] * x[c['name']] for c in candidates) >= min_pm_exp, "MinPMExp")
    
    # At most one of G and J can be hired
    model.addConstr(x['G'] + x['J'] <= max_gj, "MaxOneGJ")
    
    # Minimum number of Leads
    model.addConstr(gp.quicksum(y[c['name']] * x[c['name']] for c in candidates) >= min_leads, "MinLeads")
    
    # Solve
    model.optimize()
    
    # Print results
    if model.status == GRB.OPTIMAL:
        print("Status: OPTIMAL")
        for c in candidates:
            if x[c['name']].x > 0.5:
                role = "Lead" if y[c['name']].x > 0.5 else "Engineer"
                print(f"Hire {c['name']} as {role}: Salary={c['salary']}, Skill={c['skill']}, PM_Exp={c['pm_exp']}")
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
