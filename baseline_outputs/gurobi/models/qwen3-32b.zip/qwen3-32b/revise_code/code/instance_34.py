import os
import gurobipy as gp
from gurobipy import GRB

def load_goods_data(filepath):
    goods = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            goods[row['Goods_Type'].strip()] = {
                'quantity': int(row['Quantity'].strip()),
                'weight': float(row['Weight_per_Unit'].strip())
            }
    return goods

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
goods_file = os.path.join(data_dir, "table_1.csv")
params_file = os.path.join(data_dir, "general_parameters.csv")

goods = load_goods_data(goods_file)
params = load_parameters(params_file)

max_container_capacity = params['max_container_capacity']
min_container_load = params['min_container_load']
min_d_per_container = int(params['min_d_goods_per_container'])
min_c_per_a = int(params['min_c_per_a'])

goods_types = list(goods.keys())
quantities = {g: goods[g]['quantity'] for g in goods_types}
weights = {g: goods[g]['weight'] for g in goods_types}

# Calculate upper bound on number of containers
# Based on the minimum D per container constraint
max_containers_upper_bound = (quantities['D'] // min_d_per_container) + 1
# We'll use a slightly higher upper bound to ensure feasibility
max_containers = max_containers_upper_bound + 2

# Create model
model = gp.Model("ContainerMinimization")

# Decision variables
# x[g][j] = number of units of goods type g in container j
x = {}
for g in goods_types:
    x[g] = {}
    for j in range(max_containers):
        x[g][j] = model.addVar(vtype=GRB.INTEGER, name=f"x_{g}_{j}", lb=0)

# y[j] = 1 if container j is used
y = {}
for j in range(max_containers):
    y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")

# z[j] = 1 if Goods E is loaded in container j
z = {}
for j in range(max_containers):
    z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{j}")

# Objective: minimize number of containers
model.setObjective(gp.quicksum(y[j] for j in range(max_containers)), GRB.MINIMIZE)

# All goods must be transported
for g in goods_types:
    model.addConstr(gp.quicksum(x[g][j] for j in range(max_containers)) == quantities[g], f"demand_{g}")

# Container capacity constraint
for j in range(max_containers):
    # If container j is not used, weight constraint is automatically satisfied
    model.addConstr(
        gp.quicksum(weights[g] * x[g][j] for g in goods_types) <= 
        (max_container_capacity - (max_container_capacity - 45) * z[j]) * y[j],
        f"cap_{j}"
    )

# Minimum load constraint
for j in range(max_containers):
    model.addConstr(
        gp.quicksum(weights[g] * x[g][j] for g in goods_types) >= 
        min_container_load * y[j],
        f"min_load_{j}"
    )

# Minimum D goods per container (if container is used)
for j in range(max_containers):
    model.addConstr(x['D'][j] >= min_d_per_container * y[j], f"min_D_{j}")

# If A goods are loaded, at least 1 C good must be loaded
M_A = quantities['A']
for j in range(max_containers):
    # Binary variable indicating if A is loaded in container j
    a_present = model.addVar(vtype=GRB.BINARY, name=f"a_present_{j}")
    
    # If A is loaded, a_present = 1
    model.addConstr(x['A'][j] <= M_A * a_present, f"A_indicator_{j}")
    
    # If A is loaded, at least 1 C must be loaded
    model.addConstr(x['C'][j] >= min_c_per_a * a_present, f"C_if_A_{j}")

# Link z[j] to presence of E in container j
for j in range(max_containers):
    model.addConstr(z[j] >= x['E'][j] / quantities['E'], f"z_lower_{j}")
    model.addConstr(z[j] <= x['E'][j], f"z_upper_{j}")

# Symmetry breaking constraints
for j in range(max_containers - 1):
    model.addConstr(y[j] >= y[j+1], f"symmetry_{j}")

# Set parameters
model.setParam('OutputFlag', 0)

# Solve
model.optimize()

# Extract and print results
obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
