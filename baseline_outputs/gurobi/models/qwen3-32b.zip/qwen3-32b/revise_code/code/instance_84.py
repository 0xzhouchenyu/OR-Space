import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = params['min_manager_experience']
    manager_bonus_per_candidate = params['manager_bonus_per_candidate']

    # Create optimization model
    model = gp.Model("Recruitment")

    # Decision variables: binary for each candidate (hired or not)
    x = {}
    for c in candidates:
        x[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{c['name']}")

    # Decision variables: binary for each candidate being a manager
    m = {}
    for c in candidates:
        m[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"m_{c['name']}")

    # Objective: minimize total salary + manager bonus
    obj = gp.LinExpr()
    for c in candidates:
        obj += c['salary'] * x[c['name']]
        obj += manager_bonus_per_candidate * m[c['name']]
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraint 1: max employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, "Max_Employees")

    # Constraint 2: budget (only base salary, excluding manager bonus)
    model.addConstr(gp.quicksum(c['salary'] * x[c['name']] for c in candidates) <= budget_limit, "Budget_Limit")

    # Constraint 3: at least one with Master's or Doctoral degree
    advanced_candidates = [c for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(x[c['name']] for c in advanced_candidates) >= min_advanced, "Min_Advanced_Degree")

    # Constraint 4: minimum total work experience
    model.addConstr(gp.quicksum(c['experience'] * x[c['name']] for c in candidates) >= min_experience, "Min_Work_Experience")

    # Constraint 5: at most one from pair A and E
    model.addConstr(x['A'] + x['E'] <= max_equivalent, "Max_Equivalent_Candidates")

    # Constraint 6: minimum employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) >= min_employees, "Min_Employees")

    # Constraint 7: minimum number of managers
    model.addConstr(gp.quicksum(m[c['name']] for c in candidates) >= min_managers, "Min_Managers")

    # Constraint 8: maximum number of managers
    model.addConstr(gp.quicksum(m[c['name']] for c in candidates) <= max_managers, "Max_Managers")

    # Constraint 9: only hired candidates can be managers
    for c in candidates:
        model.addConstr(m[c['name']] <= x[c['name']], f"Manager_Only_If_Hired_{c['name']}")

    # Constraint 10: minimum work experience for managers
    model.addConstr(gp.quicksum(c['experience'] * m[c['name']] for c in candidates) >= min_manager_experience, "Min_Manager_Experience")

    # Solve
    model.setParam('OutputFlag', 0)
    model.optimize()

    # Print selected candidates
    for c in candidates:
        if x[c['name']].x > 0.5:
            print(f"Selected: {c['name']} (Salary: {c['salary']}, Role: {'Manager' if m[c['name']].x > 0.5 else 'Specialist'})")

    # Print objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
