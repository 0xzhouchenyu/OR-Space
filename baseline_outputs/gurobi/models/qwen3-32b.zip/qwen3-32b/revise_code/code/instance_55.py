import os
import gurobipy as gp
from gurobipy import GRB

def load_courses(data_dir):
    """Load course data from table_1.csv"""
    filepath = os.path.join(data_dir, 'table_1.csv')
    courses = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            categories = [c.strip() for c in row['Category'].split(';')]
            courses[course] = categories
    return courses

def load_parameters(data_dir):
    """Load general parameters from general_parameters.csv"""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    prerequisites = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if name == 'min_courses_required':
                params['min_courses_required'] = int(value)
            elif name.startswith('prerequisite_'):
                # Extract the course name from the parameter name
                course_key = name[len('prerequisite_'):]
                prerequisites[course_key] = value
            elif name == 'mandatory_foundation_for_cs_counting':
                params['mandatory_foundation_for_cs_counting'] = value
            elif name == 'cs_category_name':
                params['cs_category_name'] = value
    return params, prerequisites

# Set up file paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load data
courses = load_courses(data_dir)
params, prereq_raw = load_parameters(data_dir)

min_required = params['min_courses_required']  # 2
cs_category = params['cs_category_name']
foundation_course = params['mandatory_foundation_for_cs_counting']

# Build prerequisite mapping: course -> list of prerequisites
course_list = list(courses.keys())
prerequisites = {}

for prereq_key, prereq_value in prereq_raw.items():
    course_name = prereq_key.replace('_', ' ')
    if course_name in course_list:
        if course_name not in prerequisites:
            prerequisites[course_name] = []
        prerequisites[course_name].append(prereq_value.strip())

# Get all categories
all_categories = set()
for cats in courses.values():
    for c in cats:
        all_categories.add(c)

# Create optimization model
model = gp.Model("RevisedCourseSelection")
model.setParam('OutputFlag', 0)  # Suppress output

# Decision variables: binary, whether to take each course
x = {course: model.addVar(vtype=GRB.BINARY, name=f"x_{course.replace(' ', '_')}") for course in course_list}

# Binary variables to indicate if a category is covered (at least min_required courses)
y = {category: model.addVar(vtype=GRB.BINARY, name=f"y_{category.replace(' ', '_')}") for category in all_categories}

# Objective: minimize total number of courses taken
model.setObjective(gp.quicksum(x[course] for course in course_list), GRB.MINIMIZE)

# Constraint: at least min_required courses in each category
for category in all_categories:
    courses_in_cat = [course for course, cats in courses.items() if category in cats]
    model.addConstr(gp.quicksum(x[course] for course in courses_in_cat) >= min_required * y[category], 
                    f"Min_{category.replace(' ', '_')}")

# Prerequisite constraints: if you take a course, you must take its prerequisites
for course, prereqs in prerequisites.items():
    for prereq in prereqs:
        # x[course] <= x[prereq]  (if you take course, you must take prereq)
        model.addConstr(x[course] <= x[prereq], 
                        f"Prereq_{course.replace(' ', '_')}_needs_{prereq.replace(' ', '_')}")

# Constraint: If any course is counted toward Computer Science, then Computer Programming must be taken
cs_courses = [course for course, cats in courses.items() if cs_category in cats]
model.addConstr(gp.quicksum(x[course] for course in cs_courses) <= len(cs_courses) * x[foundation_course],
                f"CS_Foundation_{foundation_course.replace(' ', '_')}")

# Optimize the model
model.optimize()

# Print selected courses
print("\nSelected courses:")
for course in course_list:
    if x[course].x > 0.5:
        print(f"  {course}: {courses[course]}")

# Output final objective value
final_obj_value = model.objVal
print(f"\nFINAL_OBJ_VALUE: {final_obj_value}")
