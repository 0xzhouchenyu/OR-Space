import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    parts = []
    with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
    
    # Load general_parameters.csv
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    return parts, params


def fuel_per_bomb(distance, params, bomb_type):
    """Calculate fuel consumption for a single sortie carrying a specific bomb type."""
    if bomb_type == "heavy":
        eff_bomb = params['fuel_efficiency_heavy_bomb']
    elif bomb_type == "light":
        eff_bomb = params['fuel_efficiency_light_bomb']
    else:
        raise ValueError("Invalid bomb type")

    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    
    fuel_outbound = distance / eff_bomb
    fuel_return = distance / eff_empty
    fuel_total = fuel_outbound + fuel_return + takeoff_landing
    
    return fuel_total


def prob_at_least_k(probs, k):
    """Compute the probability that at least k out of n independent events occur."""
    n = len(probs)
    dp = [0.0] * (n + 1)
    dp[0] = 1.0
    for i in range(n):
        new_dp = [0.0] * (n + 1)
        for j in range(i + 2):
            # Event i does not occur
            new_dp[j] += dp[j] * (1.0 - probs[i])
            # Event i occurs
            if j > 0:
                new_dp[j] += dp[j - 1] * probs[i]
        dp = new_dp
    return sum(dp[k:])


def main():
    parts, params = load_data()
    n_parts = len(parts)

    max_heavy = int(params['max_heavy_bombs'])
    max_light = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts = int(params['min_parts_destroyed'])
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    scenario_prob_A = params['scenario_prob_A']
    scenario_prob_B = params['scenario_prob_B']
    sortie_fuel_overhead_A = params['sortie_fuel_overhead_A']
    sortie_fuel_overhead_B = params['sortie_fuel_overhead_B']

    # Calculate fuel per heavy and light bomb for each part
    fuel_heavy = [fuel_per_bomb(part['distance'], params, "heavy") for part in parts]
    fuel_light = [fuel_per_bomb(part['distance'], params, "light") for part in parts]

    # Create Gurobi model
    model = gp.Model("BombAllocationOptimization")
    model.setParam('OutputFlag', 0)  # Suppress output

    # Decision variables: xh[i] = number of heavy bombs allocated to part i
    xh = model.addVars(n_parts, vtype=GRB.INTEGER, name="xh", lb=0, ub=max_heavy)
    # Decision variables: xl[i] = number of light bombs allocated to part i
    xl = model.addVars(n_parts, vtype=GRB.INTEGER, name="xl", lb=0, ub=max_light)

    # Total number of sorties used
    total_sorties = model.addVar(vtype=GRB.INTEGER, name="total_sorties")

    # Objective: maximize expected mission success probability
    p_destroy = model.addVars(n_parts, name="p_destroy")
    for i in range(n_parts):
        model.addConstr(p_destroy[i] == 1 - ((1 - parts[i]['p_heavy']) ** xh[i]) * ((1 - parts[i]['p_light']) ** xl[i]))

    # Compute the probability of destroying at least min_parts parts
    # We'll use a binary variable y[i] indicating whether part i is destroyed
    y = model.addVars(n_parts, vtype=GRB.BINARY, name="y")
    epsilon = 1e-6  # Small value to avoid division by zero
    for i in range(n_parts):
        model.addConstr(y[i] <= p_destroy[i] + epsilon)
        model.addConstr(y[i] >= p_destroy[i] - (1 - epsilon))

    # Count the number of destroyed parts
    num_destroyed = model.addVar(vtype=GRB.INTEGER, name="num_destroyed")
    model.addConstr(num_destroyed == gp.quicksum(y[i] for i in range(n_parts)))

    # Binary variable z indicating whether at least min_parts are destroyed
    z = model.addVar(vtype=GRB.BINARY, name="z")
    model.addConstr(z <= (num_destroyed >= min_parts).indicator())

    # Expected mission success probability
    obj = scenario_prob_A * z + scenario_prob_B * z
    model.setObjective(obj, GRB.MAXIMIZE)

    # Constraints on total number of bombs
    model.addConstr(gp.quicksum(xh[i] for i in range(n_parts)) <= max_heavy)
    model.addConstr(gp.quicksum(xl[i] for i in range(n_parts)) <= max_light)

    # Constraints on total number of sorties
    model.addConstr(total_sorties == gp.quicksum(xh[i] + xl[i] for i in range(n_parts)))
    model.addConstr(total_sorties <= max_sorties_A)
    model.addConstr(total_sorties <= max_sorties_B)

    # Fuel constraints for both scenarios
    fuel_used_A = model.addVar(name="fuel_used_A")
    fuel_used_B = model.addVar(name="fuel_used_B")

    for i in range(n_parts):
        fuel_used_A += xh[i] * (fuel_heavy[i] + sortie_fuel_overhead_A) + xl[i] * (fuel_light[i] + sortie_fuel_overhead_A)
        fuel_used_B += xh[i] * (fuel_heavy[i] + sortie_fuel_overhead_B) + xl[i] * (fuel_light[i] + sortie_fuel_overhead_B)

    model.addConstr(fuel_used_A <= fuel_limit)
    model.addConstr(fuel_used_B <= fuel_limit)

    # Optimize the model
    model.optimize()

    # Extract solution
    if model.status == GRB.OPTIMAL:
        best_obj = model.objVal
        print(f"FINAL_OBJ_VALUE: {best_obj:.4f}")
    else:
        print("No optimal solution found")


if __name__ == "__main__":
    main()
