import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = params['fixed_order_cost']
    august_threshold = int(params['august_bulk_order_threshold'])
    august_fee = params['august_bulk_receiving_fee']
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create Gurobi model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    buy = model.addVars(months, name="buy", lb=0)
    sell = model.addVars(months, name="sell", lb=0)
    stock = model.addVars(months, name="stock", lb=0, ub=warehouse_capacity)
    
    # Binary variable for fixed order cost (1 if any purchase is made in a month)
    has_purchase = model.addVars(months, vtype=GRB.BINARY, name="has_purchase")
    
    # Binary variable for August bulk receiving fee (1 if purchases > 300 units in August)
    august_bulk = model.addVar(vtype=GRB.BINARY, name="august_bulk")
    
    # Objective: maximize total profit (revenue - cost)
    revenue = gp.quicksum(sell_price[m] * sell[m] for m in months)
    cost = gp.quicksum(buy_price[m] * buy[m] for m in months)
    fixed_costs = fixed_order_cost * gp.quicksum(has_purchase)
    august_cost = august_fee * august_bulk
    
    model.setObjective(revenue - cost - fixed_costs - august_cost, GRB.MAXIMIZE)
    
    # Stock balance constraints
    for i, m in enumerate(months):
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_stock = stock[months[i-1]]
        
        # Stock balance constraint: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], f"balance_{m}")
        
        # After buying, before selling, warehouse constraint:
        # prev_stock + buy[m] <= warehouse_capacity
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, f"warehouse_after_buy_{m}")
        
        # Fixed cost activation: if buy[m] > 0, then has_purchase[m] = 1
        model.addConstr(buy[m] <= has_purchase[m] * warehouse_capacity, f"fixed_cost_activation_{m}")
        model.addConstr(buy[m] >= has_purchase[m] * 0.0001, f"fixed_cost_activation_lower_{m}")  # Small epsilon to avoid 0
        
    # August bulk receiving constraint
    model.addConstr(buy[8] <= august_threshold + (1 - august_bulk) * warehouse_capacity, "august_bulk_upper")
    model.addConstr(buy[8] >= august_threshold + 0.0001 * august_bulk, "august_bulk_lower")  # Small epsilon to avoid 0
    
    # Solve the model
    model.optimize()
    
    # Print solution details
    for m in months:
        print(f"Month {m}: Buy={buy[m].x:.1f} @ {buy_price[m]}, "
              f"Sell={sell[m].x:.1f} @ {sell_price[m]}, "
              f"Stock={stock[m].x:.1f}, HasPurchase={has_purchase[m].x:.0f}")
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
