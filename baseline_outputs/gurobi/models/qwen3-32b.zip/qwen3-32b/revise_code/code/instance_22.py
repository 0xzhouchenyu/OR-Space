import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load general parameters
    general_params = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    general_params_dict = {row['Parameter_Name']: row['Value'] for _, row in general_params.iterrows()}
    
    # Load product data from table_1
    table_1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    
    # Load activation costs from table_2
    table_2 = pd.read_csv(os.path.join(data_dir, "table_2.csv"))
    
    # Load minimum batch sizes from table_3
    table_3 = pd.read_csv(os.path.join(data_dir, "table_3.csv"))
    
    # Merge all product-related data
    df = table_1.merge(table_2, on='Product').merge(table_3, on='Product')
    
    # Extract production days
    prod_days = float(general_params_dict['production_days'])
    
    return df, prod_days, general_params_dict

def solve():
    df, prod_days, params = load_data()
    
    products = df['Product'].tolist()
    
    # Create model
    model = gp.Model("Production_Planning_Rev")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = model.addVars(products, name="x", lb=0)  # Production quantity
    y = model.addVars(products, vtype=GRB.BINARY, name="y")  # Activation indicator
    
    # Special variables for A1 thresholds
    a1_watch_threshold = int(params['a1_watch_threshold'])
    a1_deep_service_threshold = int(params['a1_deep_service_threshold'])
    
    # Binary indicators for crossing thresholds
    z1 = model.addVar(vtype=GRB.BINARY, name="z1")  # Crossed watch threshold
    z2 = model.addVar(vtype=GRB.BINARY, name="z2")  # Crossed deep service threshold
    
    # Additional variables for quantities above thresholds
    w1 = model.addVar(lb=0, name="w1")  # Quantity above watch threshold
    w2 = model.addVar(lb=0, name="w2")  # Quantity above deep service threshold
    
    # Objective function: maximize profit
    profit_expr = gp.LinExpr()
    
    for _, row in df.iterrows():
        p = row['Product']
        if p == 'A1':
            base_profit = (row['Selling_Price'] - row['Production_Cost']) * x[p]
            priority_lift = params['a1_priority_price_lift'] * w1
            activation_cost = row['Activation_Cost'] * y[p]
            quality_fee = params['a1_quality_release_fee'] * z1
            deep_service_fee = params['a1_deep_service_fee'] * z2
            profit_expr += base_profit + priority_lift - activation_cost - quality_fee - deep_service_fee
        else:
            profit_expr += (row['Selling_Price'] - row['Production_Cost']) * x[p] - row['Activation_Cost'] * y[p]
    
    model.setObjective(profit_expr, GRB.MAXIMIZE)
    
    # Constraints
    
    # All products must be activated (as per original code)
    for p in products:
        model.addConstr(y[p] == 1, f"Activate_{p}")
    
    # Production quantity bounds
    for _, row in df.iterrows():
        p = row['Product']
        model.addConstr(x[p] <= row['Maximum_Demand'] * y[p], f"MaxDemand_{p}")
        model.addConstr(x[p] >= row['Minimum_Batch'] * y[p], f"MinBatch_{p}")
    
    # Production days constraint
    total_days_used = gp.LinExpr()
    for _, row in df.iterrows():
        p = row['Product']
        total_days_used += x[p] / row['Production_Quota']
    
    maintenance_penalty_watch = float(params['maintenance_penalty_watch'])
    maintenance_penalty_deep = float(params['maintenance_penalty_deep'])
    
    model.addConstr(total_days_used - maintenance_penalty_watch*z1 - maintenance_penalty_deep*z2 <= prod_days, "ProductionDays")
    
    # Threshold constraints for A1
    model.addConstr(x['A1'] >= a1_watch_threshold - 1e5*(1-z1), "WatchThreshold_Lower")
    model.addConstr(x['A1'] <= a1_watch_threshold - 1 + 1e5*z1, "WatchThreshold_Upper")
    
    model.addConstr(x['A1'] >= a1_deep_service_threshold - 1e5*(1-z2), "DeepService_Lower")
    model.addConstr(x['A1'] <= a1_deep_service_threshold - 1 + 1e5*z2, "DeepService_Upper")
    
    # Quantity above thresholds
    model.addConstr(w1 >= x['A1'] - a1_watch_threshold, "AboveWatch")
    model.addConstr(w1 >= 0, "NonNegativeW1")
    
    model.addConstr(w2 >= x['A1'] - a1_deep_service_threshold, "AboveDeep")
    model.addConstr(w2 >= 0, "NonNegativeW2")
    
    # Solve the model
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        return model.objVal
    else:
        return None

if __name__ == "__main__":
    obj = solve()
    print(f"FINAL_OBJ_VALUE: {round(obj, 4)}")
