import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data


# Set up paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load warehouse data
table_1_path = os.path.join(data_dir, "table_1.csv")
warehouses_data = load_csv_data(table_1_path)
warehouses = [row["Warehouse"] for row in warehouses_data]
supply = {row["Warehouse"]: int(row["Empty_Containers"]) for row in warehouses_data}

# Load port demand data
table_2_path = os.path.join(data_dir, "table_2.csv")
ports_data = load_csv_data(table_2_path)
ports = [row["Port"] for row in ports_data]
demand = {row["Port"]: int(row["Container_Demand"]) for row in ports_data}

# Load distance data
table_3_path = os.path.join(data_dir, "table_3.csv")
distance_data = load_csv_data(table_3_path)
distance = {}
for row in distance_data:
    wh = row["Warehouse"]
    for port in ports:
        distance[(wh, port)] = float(row[port])

# Load general parameters
general_params_path = os.path.join(data_dir, "general_parameters.csv")
params_data = load_csv_data(general_params_path)
params = {row["Parameter_Name"]: float(row["Value"]) for row in params_data}
cost_per_km = params["cost_per_km"]
truck_capacity = params["truck_capacity"]
adriatic_pool_shortage_trigger = params["adriatic_pool_shortage_trigger"]
adriatic_pool_recovery_fee = params["adriatic_pool_recovery_fee"]

# Load shortage penalty data
shortage_penalty_path = os.path.join(data_dir, "shortage_penalty.csv")
shortage_penalty_data = load_csv_data(shortage_penalty_path)

# Process shortage penalties
shortage_charge = {}
grace_containers = {}
recovery_fee = {}

for row in shortage_penalty_data:
    port = row["Port"]
    shortage_charge[port] = float(row["Shortage_Charge"])
    grace_containers[port] = int(row["Grace_Containers"])
    recovery_fee[port] = float(row["Recovery_Fee"])

# Define the model
model = gp.Model("Container_Transportation_With_Penalties")
model.setParam('OutputFlag', 0)  # Suppress output

# Decision variables
x = {}  # x[i,j]: number of containers shipped from warehouse i to port j
s = {}  # s[j]: shortage at port j (unmet demand)

for i in warehouses:
    for j in ports:
        x[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}")

for j in ports:
    s[j] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"s_{j}")

# Update model
model.update()

# Objective function: minimize total cost (transport + shortage + recovery fees)
obj = 0

# Transport cost
for i in warehouses:
    for j in ports:
        obj += x[i, j] * distance[(i, j)] * cost_per_km

# Shortage charge
for j in ports:
    obj += s[j] * shortage_charge[j]

# Recovery fee for individual ports
for j in ports:
    r = model.addVar(vtype=GRB.BINARY, name=f"r_{j}")
    model.addConstr(s[j] - grace_containers[j] <= (1e6) * r[j])  # If s[j] > grace, r[j] = 1
    model.addConstr(s[j] - grace_containers[j] >= -1e6 * (1 - r[j]))  # If s[j] <= grace, r[j] = 0
    obj += r[j] * recovery_fee[j]

# Adriatic regional recovery desk
adriatic_ports = ["Venice", "Ancona", "Bari"]
s_adriatic = sum(s[j] for j in adriatic_ports)
y = model.addVar(vtype=GRB.BINARY, name="y")  # Regional recovery desk activation
model.addConstr(s_adriatic - grace_containers["Venice"] - grace_containers["Ancona"] - grace_containers["Bari"] <= (1e6) * y)
model.addConstr(s_adriatic - grace_containers["Venice"] - grace_containers["Ancona"] - grace_containers["Bari"] >= -1e6 * (1 - y))
obj += y * adriatic_pool_recovery_fee

model.setObjective(obj, GRB.MINIMIZE)

# Constraints
# Supply constraints
for i in warehouses:
    model.addConstr(gp.quicksum(x[i, j] for j in ports) <= supply[i])

# Demand constraints
for j in ports:
    model.addConstr(gp.quicksum(x[i, j] for i in warehouses) + s[j] == demand[j])

# Optimize
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
