import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_feed_data(filepath):
    feeds = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            feed = {
                'Feed': int(row['Feed']),
                'Protein_g': float(row['Protein_g']),
                'Minerals_g': float(row['Minerals_g']),
                'Vitamins_mg': float(row['Vitamins_mg']),
                'Price_Y_per_kg': float(row['Price_Y_per_kg']),
            }
            feeds.append(feed)
    return feeds


def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params


# Construct paths
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load data
feed_filepath = os.path.join(data_dir, "table_1.csv")
params_filepath = os.path.join(data_dir, "general_parameters.csv")

feeds = load_feed_data(feed_filepath)
params = load_general_parameters(params_filepath)

min_protein = params['min_protein_requirement']
min_minerals = params['min_minerals_requirement']
min_vitamins = params['min_vitamins_requirement']

# Create model
model = gp.Model("MinimizeFeedCost")
model.setParam('OutputFlag', 0)  # Suppress output

# Decision variables: amount of each feed (kg), non-negative
x = {}
for f in feeds:
    x[f['Feed']] = model.addVar(name=f"x_{f['Feed']}", lb=0, vtype=GRB.CONTINUOUS)

# Binary variables for mutual exclusion constraint between Feed 4 and Feed 5
y4 = model.addVar(vtype=GRB.BINARY, name="y4")
y5 = model.addVar(vtype=GRB.BINARY, name="y5")

# Objective: minimize total cost
model.setObjective(gp.quicksum(f['Price_Y_per_kg'] * x[f['Feed']] for f in feeds), GRB.MINIMIZE)

# Constraints
# Protein constraint
model.addConstr(gp.quicksum(f['Protein_g'] * x[f['Feed']] for f in feeds) >= min_protein, "ProteinRequirement")

# Minerals constraint
model.addConstr(gp.quicksum(f['Minerals_g'] * x[f['Feed']] for f in feeds) >= min_minerals, "MineralsRequirement")

# Vitamins constraint
model.addConstr(gp.quicksum(f['Vitamins_mg'] * x[f['Feed']] for f in feeds) >= min_vitamins, "VitaminsRequirement")

# Mutual exclusion constraint between Feed 4 and Feed 5
# If Feed 4 is used, then y4 = 1; if not used, y4 = 0
M = 1000  # Big-M value (chosen to be sufficiently large)
model.addConstr(x[4] <= M * y4, "Feed4BinaryConstraint")
model.addConstr(x[5] <= M * y5, "Feed5BinaryConstraint")
model.addConstr(y4 + y5 <= 1, "MutualExclusionConstraint")

# Optimize
model.optimize()

# Print results
obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
