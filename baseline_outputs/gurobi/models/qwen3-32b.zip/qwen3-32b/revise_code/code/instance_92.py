import os
import csv
from gurobipy import GRB, Model

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = row['Value'].strip()

num_students = int(params['num_students'])
num_buses = int(params['num_buses'])
bus_capacity = int(params['bus_capacity'])
num_minibuses = int(params['num_minibuses'])
minibus_capacity = int(params['minibus_capacity'])
num_drivers = int(params['num_drivers'])
bus_rental_cost = float(params['bus_rental_cost'])
minibus_rental_cost = float(params['minibus_rental_cost'])

# Create the optimization model
model = Model("SchoolTrip")
model.setParam('OutputFlag', 0)  # Suppress Gurobi output

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, name="buses", lb=0, ub=num_buses)
y = model.addVar(vtype=GRB.INTEGER, name="minibuses", lb=1, ub=num_minibuses)

# Objective: minimize total rental cost
model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

# Constraints
# Must transport all students
model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, "StudentCapacity")

# Total vehicles (drivers) constraint
model.addConstr(x + y <= num_drivers, "DriverLimit")

# At least two buses per minibus
model.addConstr(x >= 2 * y, "BusPerMinibus")

# Optimize
model.optimize()

# Output results
if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print("No optimal solution found.")
