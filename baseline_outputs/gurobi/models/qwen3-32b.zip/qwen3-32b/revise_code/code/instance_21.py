import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Parse general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row["Parameter_Name"].strip()
            value = float(row["Value"].strip())
            params[param_name] = value
    
    cost_a = params["cost_supplier_a"]       # 120 USD per table
    cost_b = params["cost_supplier_b"]       # 110 USD per table
    cost_c = params["cost_supplier_c"]       # 100 USD per table
    size_a = int(params["order_size_supplier_a"])  # 20 tables per order
    size_b = int(params["order_size_supplier_b"])  # 15 tables per order
    size_c = int(params["order_size_supplier_c"])  # 15 tables per order
    min_tables = int(params["min_tables_required"])  # 150
    max_tables = int(params["max_tables_allowed"])   # 600
    min_b_if_a = int(params["min_tables_supplier_b_if_a"])  # 30 tables from B if A is used
    b_requires_c = int(params["supplier_b_requires_c"])      # 1 (boolean)
    max_free_orders_c = int(params["max_free_orders_c"])
    penalty_per_extra_order_c = params["penalty_per_extra_order_c"]
    bc_shared_inbound_trigger = int(params["supplier_bc_shared_inbound_trigger"])
    bc_shared_inbound_fee = params["supplier_bc_shared_inbound_fee"]
    
    M = 1000  # Big-M
    
    model = gp.Model("Restaurant_Tables")
    model.setParam('OutputFlag', 0)  # Suppress Gurobi output
    
    # Decision variables: number of orders from each supplier (integer >= 0)
    x_a = model.addVar(vtype=GRB.INTEGER, name="orders_a")
    x_b = model.addVar(vtype=GRB.INTEGER, name="orders_b")
    x_c = model.addVar(vtype=GRB.INTEGER, name="orders_c")
    
    # Binary variables for conditional constraints
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")  # 1 if ordering from A
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")  # 1 if ordering from B
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")  # 1 if ordering from C
    z_bc = model.addVar(vtype=GRB.BINARY, name="z_bc")  # 1 if using both B and C
    
    # Objective: minimize total cost (cost per table * number of tables + penalties)
    obj = (
        cost_a * size_a * x_a +
        cost_b * size_b * x_b +
        cost_c * size_c * x_c +
        penalty_per_extra_order_c * gp.max_(x_c - max_free_orders_c, 0) +
        bc_shared_inbound_fee * z_bc
    )
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Total tables constraints
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c >= min_tables, "Min_Tables")
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c <= max_tables, "Max_Tables")
    
    # Link binary variables to order variables
    model.addConstr(x_a <= M * y_a, "Link_ya_upper")
    model.addConstr(x_a >= y_a, "Link_ya_lower")
    model.addConstr(x_b <= M * y_b, "Link_yb_upper")
    model.addConstr(x_b >= y_b, "Link_yb_lower")
    model.addConstr(x_c <= M * y_c, "Link_yc_upper")
    model.addConstr(x_c >= y_c, "Link_yc_lower")
    
    # If ordering from A, then tables from B >= 30
    model.addConstr(size_b * x_b >= min_b_if_a * y_a, "Min_B_if_A")
    
    # If ordering from B, must order from C
    if b_requires_c:
        model.addConstr(y_c >= y_b, "B_Requires_C")
    
    # Shared receiving desk constraint when using both B and C
    if bc_shared_inbound_trigger:
        model.addConstr(z_bc >= y_b + y_c - 1, "BC_Shared_Inbound")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
