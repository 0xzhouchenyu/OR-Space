import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read table_1.csv
toys = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            "type": row["Toy_Type"],
            "labor": float(row["Manufacturing_Labor_Hours"]),
            "inspection": float(row["Inspection_Hours"]),
            "profit": float(row["Profit_Per_Unit"])
        })

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

# Extract parameters
available_labor_period1 = params["available_labor_hours_period1"]
available_labor_period2 = params["available_labor_hours_period2"]
available_inspection_period1 = params["available_inspection_hours_period1"]
available_inspection_period2 = params["available_inspection_hours_period2"]

max_demand_period1 = {
    "High-End": params["max_demand_high_end_period1"],
    "Mid-Range": params["max_demand_mid_range_period1"],
    "Low-End": params["max_demand_low_end_period1"],
}

max_demand_period2 = {
    "High-End": params["max_demand_high_end_period2"],
    "Mid-Range": params["max_demand_mid_range_period2"],
    "Low-End": params["max_demand_low_end_period2"],
}

overtime_labor_cap = params["overtime_labor_cap"]
overtime_labor_cost = params["overtime_labor_cost"]
period1_overtime_fatigue_threshold = params["period1_overtime_fatigue_threshold"]
period2_labor_recovery_loss = params["period2_labor_recovery_loss"]
overtime_review_threshold = params["overtime_review_threshold"]
seasonal_safety_review_fee = params["seasonal_safety_review_fee"]

# Create model
model = gp.Model("RevisedToyProduction")
model.setParam('OutputFlag', 0)

# Decision variables
x_period1 = {toy["type"]: model.addVar(name=f"x_{toy['type']}_P1", lb=0, vtype=GRB.CONTINUOUS) for toy in toys}
x_period2 = {toy["type"]: model.addVar(name=f"x_{toy['type']}_P2", lb=0, vtype=GRB.CONTINUOUS) for toy in toys}

# Overtime labor in each period
overtime_period1 = model.addVar(name="Overtime_P1", lb=0, ub=overtime_labor_cap, vtype=GRB.CONTINUOUS)
overtime_period2 = model.addVar(name="Overtime_P2", lb=0, ub=overtime_labor_cap, vtype=GRB.CONTINUOUS)

# Total overtime
total_overtime = model.addVar(name="Total_Overtime", lb=0, vtype=GRB.CONTINUOUS)

# Safety review cost (binary variable to indicate if safety review is needed)
safety_review = model.addVar(name="Safety_Review", vtype=GRB.BINARY)

# Objective: maximize profit - overtime cost - safety review fee
profit_period1 = sum(toy["profit"] * x_period1[toy["type"]] for toy in toys)
profit_period2 = sum(toy["profit"] * x_period2[toy["type"]] for toy in toys)
overtime_cost = overtime_labor_cost * (overtime_period1 + overtime_period2)
safety_review_cost = seasonal_safety_review_fee * safety_review

model.setObjective(profit_period1 + profit_period2 - overtime_cost - safety_review_cost, GRB.MAXIMIZE)

# Constraints
# Labor hours with overtime in period 1
model.addConstr(
    gp.quicksum(toy["labor"] * x_period1[toy["type"]] for toy in toys) <= available_labor_period1 + overtime_period1,
    name="Labor_Hours_P1"
)

# Inspection hours in period 1
for toy in toys:
    model.addConstr(
        toy["inspection"] * x_period1[toy["type"]] <= available_inspection_period1,
        name=f"Inspection_Hours_P1_{toy['type']}"
    )

# Demand constraints in period 1
for toy in toys:
    model.addConstr(
        x_period1[toy["type"]] <= max_demand_period1[toy["type"]],
        name=f"Demand_P1_{toy['type']}"
    )

# Labor hours with overtime in period 2
model.addConstr(
    gp.quicksum(toy["labor"] * x_period2[toy["type"]] for toy in toys) <= available_labor_period2 + overtime_period2,
    name="Labor_Hours_P2"
)

# Inspection hours in period 2
for toy in toys:
    model.addConstr(
        toy["inspection"] * x_period2[toy["type"]] <= available_inspection_period2,
        name=f"Inspection_Hours_P2_{toy['type']}"
    )

# Demand constraints in period 2
for toy in toys:
    model.addConstr(
        x_period2[toy["type"]] <= max_demand_period2[toy["type"]],
        name=f"Demand_P2_{toy['type']}"
    )

# Total overtime constraint
model.addConstr(total_overtime == overtime_period1 + overtime_period2, name="Total_Overtime")

# Fatigue carryover constraint
fatigue_carryover = model.addVar(name="Fatigue_Carryover", vtype=GRB.BINARY)
model.addConstr((overtime_period1 >= period1_overtime_fatigue_threshold) >> (fatigue_carryover == 1), name="Fatigue_Carryover_Logic")
model.addConstr(available_labor_period2 <= available_labor_period2 - period2_labor_recovery_loss * fatigue_carryover, name="Period2_Labor_Reduction")

# Safety review constraint
model.addConstr((total_overtime >= overtime_review_threshold) >> (safety_review == 1), name="Safety_Review_Logic")

# Optimize the model
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
