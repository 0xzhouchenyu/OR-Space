import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read table_1.csv
    filepath_table1 = os.path.join(data_dir, "table_1.csv")
    
    workers = []
    tasks = []
    cost = {}
    fixed_cost = {}
    
    with open(filepath_table1, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        tasks = header[1:-1]  # ['A', 'B', 'C', 'D']
        
        for row in reader:
            worker = row[0].strip()
            workers.append(worker)
            for j, task in enumerate(tasks):
                cost[(worker, task)] = int(row[j + 1])
            fixed_cost[worker] = int(row[-1])
    
    # Read general_parameters.csv
    filepath_params = os.path.join(data_dir, "general_parameters.csv")
    
    params = {}
    with open(filepath_params, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Create the optimization model
    model = gp.Model("Assignment")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: x[i,j] = 1 if worker i is assigned to task j
    x = {}
    for w in workers:
        for t in tasks:
            x[(w, t)] = model.addVar(vtype=GRB.BINARY, name=f"x_{w}_{t}")
    
    # Binary variables for handoff charges
    y1 = model.addVar(vtype=GRB.BINARY, name="y1")  # 1 if both III and V are used
    y2 = model.addVar(vtype=GRB.BINARY, name="y2")  # 1 if both II and V are used
    
    # Objective: minimize total cost (assignment time + fixed costs + handoff charges)
    model.setObjective(
        gp.quicksum((cost[(w, t)] + fixed_cost[w]) * x[(w, t)] for w in workers for t in tasks) +
        params['shared_temp_handoff_cost'] * y1 +
        params['worker_II_V_pair_fee'] * y2,
        GRB.MINIMIZE
    )
    
    # Each task must be assigned to exactly one worker
    for t in tasks:
        model.addConstr(gp.quicksum(x[(w, t)] for w in workers) == 1)
    
    # Each worker can be assigned to at most one task
    for w in workers:
        model.addConstr(gp.quicksum(x[(w, t)] for t in tasks) <= 1)
    
    # Exactly 4 workers are assigned (enforced by 4 tasks each with exactly 1 worker)
    
    # Constraints for handoff charges
    # If both III and V are used, y1 = 1
    model.addConstr(gp.quicksum(x[("III", t)] for t in tasks) <= 2 - y1)
    model.addConstr(gp.quicksum(x[("V", t)] for t in tasks) <= 2 - y1)
    model.addConstr(gp.quicksum(x[("III", t)] for t in tasks) + gp.quicksum(x[("V", t)] for t in tasks) >= 2 * y1)
    
    # If both II and V are used, y2 = 1
    model.addConstr(gp.quicksum(x[("II", t)] for t in tasks) <= 2 - y2)
    model.addConstr(gp.quicksum(x[("V", t)] for t in tasks) <= 2 - y2)
    model.addConstr(gp.quicksum(x[("II", t)] for t in tasks) + gp.quicksum(x[("V", t)] for t in tasks) >= 2 * y2)
    
    # Optimize the model
    model.optimize()
    
    # Print solution details
    print("\nAssignment:")
    for w in workers:
        for t in tasks:
            if x[(w, t)].x > 0.5:
                print(f"  Worker {w} -> Task {t} (time: {cost[(w, t)]}, fixed cost: {fixed_cost[w]})")
    
    obj_val = model.objVal
    print(f"\nFINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
