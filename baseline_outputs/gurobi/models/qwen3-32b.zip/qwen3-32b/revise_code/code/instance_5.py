import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data files
    table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    
    df_foods = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    # Extract parameters
    budget = float(df_params[df_params['Parameter_Name'] == 'budget']['Value'].iloc[0])
    food_intake = float(df_params[df_params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
    weekday_budget_share = float(df_params[df_params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
    max_prep_time_weekday = float(df_params[df_params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
    max_prep_time_weekend = float(df_params[df_params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
    weekend_protein_ban = int(df_params[df_params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
    veg_balance_penalty = float(df_params[df_params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])
    
    # Fill missing fiber content with 0
    df_foods['Fiber_Content_per_100g'] = df_foods['Fiber_Content_per_100g'].fillna(0)
    
    foods = df_foods['Food'].tolist()
    types = df_foods.set_index('Food')['Type'].to_dict()
    fiber = df_foods.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df_foods.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df_foods.set_index('Food')['prep_time_per_100g'].to_dict()
    
    proteins = [f for f in foods if types[f] == 'protein']
    vegetables = [f for f in foods if types[f] == 'vegetable']
    
    # Create model
    model = gp.Model("Marys_Dinners_Optimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x_weekday = model.addVars(foods, name="x_weekday", lb=0, ub=food_intake/100.0, vtype=GRB.CONTINUOUS)
    x_weekend = model.addVars(foods, name="x_weekend", lb=0, ub=food_intake/100.0, vtype=GRB.CONTINUOUS)
    y_weekday = model.addVars(foods, name="y_weekday", vtype=GRB.BINARY)
    y_weekend = model.addVars(foods, name="y_weekend", vtype=GRB.BINARY)
    z_protein = model.addVars(proteins, name="z_protein", vtype=GRB.BINARY)
    
    # Objective: maximize total fiber - penalty for vegetable imbalance
    obj = (
        gp.quicksum(fiber[f] * x_weekday[f] for f in foods) +
        gp.quicksum(fiber[f] * x_weekend[f] for f in foods) -
        veg_balance_penalty * gp.abs_(gp.quicksum(x_weekday[v] for v in vegetables) - gp.quicksum(x_weekend[v] for v in vegetables))
    )
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints
    # Budget constraints
    model.addConstr(
        gp.quicksum(price[f] * x_weekday[f] for f in foods) <= weekday_budget_share * budget,
        "Budget_Weekday"
    )
    model.addConstr(
        gp.quicksum(price[f] * x_weekend[f] for f in foods) <= (1 - weekday_budget_share) * budget,
        "Budget_Weekend"
    )
    
    # Food intake constraints
    model.addConstr(
        gp.quicksum(x_weekday[f] for f in foods) == food_intake / 100.0,
        "Intake_Weekday"
    )
    model.addConstr(
        gp.quicksum(x_weekend[f] for f in foods) == food_intake / 100.0,
        "Intake_Weekend"
    )
    
    # Prep time constraints
    model.addConstr(
        gp.quicksum(prep_time[f] * x_weekday[f] for f in foods) <= max_prep_time_weekday,
        "Prep_Time_Weekday"
    )
    model.addConstr(
        gp.quicksum(prep_time[f] * x_weekend[f] for f in foods) <= max_prep_time_weekend,
        "Prep_Time_Weekend"
    )
    
    # Weekend protein ban constraint
    if weekend_protein_ban:
        model.addConstrs((x_weekend[p] == 0 for p in proteins), "No_Protein_Weekend")
    
    # Exactly one protein per meal
    model.addConstr(gp.quicksum(y_weekday[p] for p in proteins) == 1, "One_Protein_Weekday")
    model.addConstr(gp.quicksum(y_weekend[p] for p in proteins) == 1, "One_Protein_Weekend")
    
    # At least two kinds of vegetables per meal
    model.addConstr(gp.quicksum(y_weekday[v] for v in vegetables) >= 2, "Min_Vegetables_Weekday")
    model.addConstr(gp.quicksum(y_weekend[v] for v in vegetables) >= 2, "Min_Vegetables_Weekend")
    
    # Linking constraints between binary and continuous variables
    M = food_intake / 100.0
    for f in foods:
        model.addConstr(x_weekday[f] >= 0.1 * y_weekday[f], f"Link_Lower_Weekday_{f}")
        model.addConstr(x_weekday[f] <= M * y_weekday[f], f"Link_Upper_Weekday_{f}")
        model.addConstr(x_weekend[f] >= 0.1 * y_weekend[f], f"Link_Lower_Weekend_{f}")
        model.addConstr(x_weekend[f] <= M * y_weekend[f], f"Link_Upper_Weekend_{f}")
    
    # Protein usage constraint: a protein must appear in at least one of the meals
    for p in proteins:
        model.addConstr(z_protein[p] >= y_weekday[p], f"Protein_Used_Weekday_{p}")
        model.addConstr(z_protein[p] >= y_weekend[p], f"Protein_Used_Weekend_{p}")
    
    # Optimize the model
    model.optimize()
    
    # Return objective value
    return round(model.ObjVal, 4)

if __name__ == '__main__':
    print(f"FINAL_OBJ_VALUE: {solve()}")
