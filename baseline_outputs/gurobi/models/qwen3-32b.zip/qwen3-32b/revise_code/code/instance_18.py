import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Extract relevant parameters
fabric_production_rate = params["fabric_production_rate"]  # meters per hour
min_curtain_fabric_sales = params["min_curtain_fabric_sales"]  # meters
min_clothing_fabric_sales = params["min_clothing_fabric_sales"]  # meters

day_shift_regular_capacity = params["day_shift_regular_capacity"]  # hours
night_shift_regular_capacity = params["night_shift_regular_capacity"]  # hours
day_overtime_limit = params["day_overtime_limit"]  # hours
night_overtime_limit = params["night_overtime_limit"]  # hours
day_overtime_penalty = params["day_overtime_penalty"]  # yuan per hour
night_overtime_penalty = params["night_overtime_penalty"]  # yuan per hour
day_min_utilization_ratio = params["day_min_utilization_ratio"]
night_min_utilization_ratio = params["night_min_utilization_ratio"]

# Convert sales requirements to hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

# Create Gurobi model
model = gp.Model("Textile_Factory_Shift_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
# Regular hours for each fabric in each shift
x_day_clothing = model.addVar(name="day_clothing_regular", lb=0)
x_night_clothing = model.addVar(name="night_clothing_regular", lb=0)
x_day_curtain = model.addVar(name="day_curtain_regular", lb=0)
x_night_curtain = model.addVar(name="night_curtain_regular", lb=0)

# Overtime hours for each fabric in each shift
o_day_clothing = model.addVar(name="day_clothing_overtime", lb=0, ub=day_overtime_limit)
o_night_clothing = model.addVar(name="night_clothing_overtime", lb=0, ub=night_overtime_limit)
o_day_curtain = model.addVar(name="day_curtain_overtime", lb=0, ub=day_overtime_limit)
o_night_curtain = model.addVar(name="night_curtain_overtime", lb=0, ub=night_overtime_limit)

# Total regular hours in each shift
total_day_regular = x_day_clothing + x_day_curtain
total_night_regular = x_night_clothing + x_night_curtain

# Objective: minimize total overtime cost
model.setObjective(
    day_overtime_penalty * (o_day_clothing + o_day_curtain) +
    night_overtime_penalty * (o_night_clothing + o_night_curtain),
    GRB.MINIMIZE
)

# Constraints

# 1. Sales requirements
model.addConstr(
    (x_day_clothing + o_day_clothing + x_night_clothing + o_night_clothing) * fabric_production_rate >= min_clothing_fabric_sales,
    name="clothing_sales"
)
model.addConstr(
    (x_day_curtain + o_day_curtain + x_night_curtain + o_night_curtain) * fabric_production_rate >= min_curtain_fabric_sales,
    name="curtain_sales"
)

# 2. Shift capacity constraints
model.addConstr(total_day_regular <= day_shift_regular_capacity, name="day_regular_capacity")
model.addConstr(total_night_regular <= night_shift_regular_capacity, name="night_regular_capacity")

# 3. Utilization ratio constraints
model.addConstr(total_day_regular >= day_min_utilization_ratio * (total_day_regular + total_night_regular), name="day_utilization")
model.addConstr(total_night_regular >= night_min_utilization_ratio * (total_day_regular + total_night_regular), name="night_utilization")

# Optimize the model
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
