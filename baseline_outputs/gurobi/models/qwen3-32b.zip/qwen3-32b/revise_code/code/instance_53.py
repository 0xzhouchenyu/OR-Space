import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read costs from table_1.csv
    costs_budget = {}
    costs_balanced = {}
    costs_premium = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row["Child"].strip()
            costs_budget[child] = float(row["Cost_budget"].strip())
            costs_balanced[child] = float(row["Cost_balanced"].strip())
            costs_premium[child] = float(row["Cost_premium"].strip())
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    
    max_children = int(params["max_children"])
    min_children = int(params["min_children"])
    min_children_per_mode = int(params["min_children_per_mode"])
    fairness_penalty = float(params["fairness_penalty"])
    max_total_cost = float(params["max_total_cost"])
    
    children = list(costs_budget.keys())
    
    # Create Gurobi model
    model = gp.Model("ZhangFamilyTrip")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = {child: model.addVar(vtype=GRB.BINARY, name=f"x_{child}") for child in children}  # Child selection
    y = {
        "budget": model.addVar(vtype=GRB.BINARY, name="y_budget"),
        "balanced": model.addVar(vtype=GRB.BINARY, name="y_balanced"),
        "premium": model.addVar(vtype=GRB.BINARY, name="y_premium")
    }  # Mode selection
    
    # Enforce that exactly one mode is selected
    model.addConstr(y["budget"] + y["balanced"] + y["premium"] == 1, "One_Mode_Selected")
    
    # Ginny must go
    model.addConstr(x["Ginny"] == 1, "Ginny_must_go")
    
    # Group size constraints
    model.addConstr(gp.quicksum(x[child] for child in children) <= max_children, "Max_children")
    model.addConstr(gp.quicksum(x[child] for child in children) >= min_children, "Min_children")
    
    # Minimum children per mode constraints
    for mode in ["balanced", "premium"]:
        model.addConstr(
            gp.quicksum(x[child] for child in children) >= min_children_per_mode * y[mode],
            f"Min_Children_for_{mode}"
        )
    
    # Compatibility constraints
    model.addConstr(x["Harry"] + x["Fred"] <= 1, "Harry_no_Fred")
    model.addConstr(x["Harry"] + x["George"] <= 1, "Harry_no_George")
    model.addConstr(x["George"] <= x["Fred"], "George_requires_Fred")
    model.addConstr(x["George"] <= x["Hermione"], "George_requires_Hermione")
    
    # Calculate cost based on selected mode
    total_cost = 0
    for child in children:
        total_cost += (
            costs_budget[child] * x[child] * y["budget"]
            + costs_balanced[child] * x[child] * y["balanced"]
            + costs_premium[child] * x[child] * y["premium"]
        )
    
    # Calculate max and min child costs for the selected mode
    max_child_cost = 0
    min_child_cost = 0
    
    for child in children:
        # Max child cost
        max_child_cost += (
            costs_budget[child] * x[child] * y["budget"]
            + costs_balanced[child] * x[child] * y["balanced"]
            + costs_premium[child] * x[child] * y["premium"]
        )
        
        # Min child cost - we'll use a trick to get the minimum by subtracting from max
        min_child_cost += (
            costs_budget[child] * x[child] * y["budget"]
            + costs_balanced[child] * x[child] * y["balanced"]
            + costs_premium[child] * x[child] * y["premium"]
        )
    
    # We need to find the actual maximum and minimum child costs among those selected
    # This requires additional binary variables to identify max and min
    M = 2000  # Big-M value (larger than any possible cost difference)
    
    # Binary variable indicating if child i has the maximum cost
    z_max = {child: model.addVar(vtype=GRB.BINARY, name=f"z_max_{child}") for child in children}
    
    # Binary variable indicating if child i has the minimum cost
    z_min = {child: model.addVar(vtype=GRB.BINARY, name=f"z_min_{child}") for child in children}
    
    # Additional continuous variables for max and min costs
    max_cost = model.addVar(name="max_cost")
    min_cost = model.addVar(name="min_cost")
    
    # Constraints to determine max cost
    for child in children:
        for other in children:
            if child != other:
                # If child's cost > other's cost, then z_max[child] must be 1
                model.addConstr(
                    costs_budget[child] * x[child] * y["budget"]
                    + costs_balanced[child] * x[child] * y["balanced"]
                    + costs_premium[child] * x[child] * y["premium"]
                    - (costs_budget[other] * x[other] * y["budget"]
                       + costs_balanced[other] * x[other] * y["balanced"]
                       + costs_premium[other] * x[other] * y["premium"])
                    <= M * (1 - z_max[child])
                )
    
    # At least one child must have the maximum cost
    model.addConstr(gp.quicksum(z_max[child] for child in children) >= 1, "At_least_one_max")
    
    # Link max_cost to the actual maximum cost
    for child in children:
        model.addConstr(
            max_cost >= (
                costs_budget[child] * x[child] * y["budget"]
                + costs_balanced[child] * x[child] * y["balanced"]
                + costs_premium[child] * x[child] * y["premium"]
            ) - M * (1 - z_max[child]),
            f"Link_max_cost_{child}"
        )
    
    # Constraints to determine min cost
    for child in children:
        for other in children:
            if child != other:
                # If child's cost < other's cost, then z_min[child] must be 1
                model.addConstr(
                    (costs_budget[other] * x[other] * y["budget"]
                     + costs_balanced[other] * x[other] * y["balanced"]
                     + costs_premium[other] * x[other] * y["premium"])
                    - (costs_budget[child] * x[child] * y["budget"]
                       + costs_balanced[child] * x[child] * y["balanced"]
                       + costs_premium[child] * x[child] * y["premium"])
                    <= M * (1 - z_min[child])
                )
    
    # At least one child must have the minimum cost
    model.addConstr(gp.quicksum(z_min[child] for child in children) >= 1, "At_least_one_min")
    
    # Link min_cost to the actual minimum cost
    for child in children:
        model.addConstr(
            min_cost <= (
                costs_budget[child] * x[child] * y["budget"]
                + costs_balanced[child] * x[child] * y["balanced"]
                + costs_premium[child] * x[child] * y["premium"]
            ) + M * (1 - z_min[child]),
            f"Link_min_cost_{child}"
        )
    
    # Objective function: minimize total cost plus fairness penalty
    obj = total_cost + fairness_penalty * (max_cost - min_cost)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Budget constraint
    model.addConstr(total_cost <= max_total_cost, "Budget_Constraint")
    
    # Optimize the model
    model.optimize()
    
    # Print solution details
    if model.status == GRB.OPTIMAL:
        print("Optimal solution found:")
        selected_children = [child for child in children if x[child].x > 0.5]
        selected_mode = None
        for mode in ["budget", "balanced", "premium"]:
            if y[mode].x > 0.5:
                selected_mode = mode
                break
        
        print(f"Selected mode: {selected_mode}")
        print(f"Selected children: {selected_children}")
        print(f"Total cost: {total_cost.getValue()}")
        print(f"Fairness penalty: {fairness_penalty * (max_cost.x - min_cost.x)}")
        print(f"Final objective value: {obj.getValue()}")
        print(f"FINAL_OBJ_VALUE: {obj.getValue()}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
