import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load demand forecast
demand = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for i, row in enumerate(reader):
        demand[i] = float(row["Demand_Forecast"])

T = len(demand)  # 6 months

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

W0 = int(params["initial_workforce"])
I0 = params["initial_inventory"]
sp = params["sales_price"]
rmc = params["raw_material_cost"]
oc = params["outsourcing_cost"]
hc = params["inventory_holding_cost"]
bc = params["backorder_cost"]
lr = params["labor_requirement"]
rh = params["regular_labor_hours"]
rw = params["regular_wage"]
otl = params["overtime_hours_limit"]
ow = params["overtime_wage"]
hire_cost = params["hiring_cost"]
fire_cost = params["firing_cost"]
term_inv = params["terminal_inventory"]
term_bo = params["terminal_backorders"]
contract_min_units = params["contract_min_units"]
contract_bigM = params["contract_bigM"]

# Create model
model = gp.Model("FoldableTableProduction")
model.setParam('OutputFlag', 0)

# Decision variables
W = model.addVars(T, name="Workforce", lb=0)
H = model.addVars(T, name="Hired", lb=0)
F = model.addVars(T, name="Fired", lb=0)
P = model.addVars(T, name="InHouseProduction", lb=0)
OT_total = model.addVars(T, name="OvertimeTotal", lb=0)
O = model.addVars(T, name="Outsourced", lb=0)
Inv = model.addVars(T, name="Inventory", lb=0)
B = model.addVars(T, name="Backorders", lb=0)

# Binary indicators for contract months (April to June: t=3,4,5)
contract_months = [3, 4, 5]
y = model.addVars(contract_months, vtype=GRB.BINARY, name="ContractBinary")

# Workforce balance constraints
for t in range(T):
    if t == 0:
        model.addConstr(W[t] == W0 + H[t] - F[t], name=f"WorkforceBalance_{t}")
    else:
        model.addConstr(W[t] == W[t-1] + H[t] - F[t], name=f"WorkforceBalance_{t}")

# Production capacity constraints
for t in range(T):
    model.addConstr(P[t] * lr <= W[t] * rh + OT_total[t], name=f"ProductionCapacity_{t}")
    model.addConstr(OT_total[t] <= W[t] * otl, name=f"OvertimeLimit_{t}")

# Inventory and backorder balance constraints
for t in range(T):
    prev_inv = I0 if t == 0 else Inv[t-1]
    prev_b = 0 if t == 0 else B[t-1]
    model.addConstr(Inv[t] - B[t] == prev_inv - prev_b + P[t] + O[t] - demand[t], name=f"InventoryBalance_{t}")

# Terminal conditions
model.addConstr(Inv[T-1] >= term_inv, name="TerminalInventory")
model.addConstr(B[T-1] <= term_bo, name="TerminalBackorders")

# Contract constraints: April to June (t=3,4,5)
for t in contract_months:
    # Regular-time production is limited by regular labor hours only
    model.addConstr(P[t] * lr <= W[t] * rh, name=f"ContractRegularTimeOnly_{t}")
    
    # Minimum contract units must be satisfied by in-house production
    model.addConstr(P[t] >= contract_min_units - contract_bigM * (1 - y[t]), name=f"ContractMinUnits_{t}")
    
    # The contract-qualified quantity cannot exceed the month's total demand including backlog
    if t == 0:
        model.addConstr(P[t] <= demand[t] + contract_bigM * y[t], name=f"ContractMaxDemand_{t}")
    else:
        model.addConstr(P[t] <= demand[t] + B[t-1] + contract_bigM * y[t], name=f"ContractMaxDemand_{t}")

# Objective function
total_demand = sum(demand[t] for t in range(T))
revenue = sp * total_demand

material_cost = rmc * P.sum()
outsource_cost = oc * O.sum()
holding_cost = hc * Inv.sum()
backorder_cost_total = bc * B.sum()
regular_labor_cost = rw * rh * W.sum()
overtime_cost = ow * OT_total.sum()
hiring_cost_total = hire_cost * H.sum()
firing_cost_total = fire_cost * F.sum()

total_cost = (
    material_cost + outsource_cost + holding_cost + backorder_cost_total +
    regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total
)

model.setObjective(revenue - total_cost, GRB.MAXIMIZE)

# Optimize
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
