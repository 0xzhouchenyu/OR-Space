import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Get the data directory path
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    
    max_children_per_day = int(params["max_children_trip"])
    min_children_per_day = int(params["min_children_trip"])
    max_distinct_children = int(params["max_distinct_children_trip"])
    total_cost_budget = int(params["total_cost_budget"])
    bonus_saving = int(params["bonus_saving"])
    min_bob_days = int(params["min_bob_days"])
    
    # Read child costs and constraints
    children = []
    costs = {}
    availability = {}  # day 1 or day 2 or both
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Child"].strip()
            cost = int(row["Cost"].strip())
            constraint = row["Relationship_Constraint"].strip()
            
            children.append(name)
            costs[name] = cost
            
            if "Only available on day 1" in constraint:
                availability[name] = [1]
            elif "Only available on day 2" in constraint:
                availability[name] = [2]
            else:
                availability[name] = [1, 2]
    
    # Create model
    model = gp.Model("FamilyTripTwoDay")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: x[child][day] = 1 if child is selected on that day
    x = {}
    for child in children:
        for day in [1, 2]:
            if day in availability[child]:
                x[(child, day)] = model.addVar(vtype=GRB.BINARY, name=f"x_{child}_day{day}")
    
    # Objective: minimize total cost minus savings for children attending both days
    total_cost = 0
    for child in children:
        for day in [1, 2]:
            if day in availability[child]:
                total_cost += costs[child] * x[(child, day)]
    
    attend_both_days = {}
    for child in children:
        attend_both_days[child] = model.addVar(vtype=GRB.BINARY, name=f"attend_both_days_{child}")
        model.addConstr(attend_both_days[child] <= x.get((child, 1), 0))
        model.addConstr(attend_both_days[child] <= x.get((child, 2), 0))
        model.addConstr(attend_both_days[child] >= x.get((child, 1), 0) + x.get((child, 2), 0) - 1)
    
    objective = total_cost - bonus_saving * sum(attend_both_days.values())
    model.setObjective(objective, GRB.MINIMIZE)
    
    # Constraints
    
    # Daily attendance limits
    for day in [1, 2]:
        model.addConstr(sum(x[(child, day)] for child in children if day in availability[child]) >= min_children_per_day, 
                        f"MinChildren_day{day}")
        model.addConstr(sum(x[(child, day)] for child in children if day in availability[child]) <= max_children_per_day,
                        f"MaxChildren_day{day}")
    
    # Bob must be taken on at least min_bob_days
    model.addConstr(sum(x[("Bob", day)] for day in [1, 2] if day in availability["Bob"]) >= min_bob_days, "MinBobDays")
    
    # Alice and Diana cannot be together on the same day
    for day in [1, 2]:
        if day in availability["Alice"] and day in availability["Diana"]:
            model.addConstr(x[("Alice", day)] + x[("Diana", day)] <= 1, f"AliceDianaConflict_day{day}")
    
    # Bob and Charlie cannot be together on the same day
    for day in [1, 2]:
        if day in availability["Bob"] and day in availability["Charlie"]:
            model.addConstr(x[("Bob", day)] + x[("Charlie", day)] <= 1, f"BobCharlieConflict_day{day}")
    
    # Charlie must be accompanied by Diana on the same day
    for day in [1, 2]:
        if day in availability["Charlie"] and day in availability["Diana"]:
            model.addConstr(x[("Charlie", day)] <= x[("Diana", day)], f"CharlieRequiresDiana_day{day}")
    
    # Diana must be accompanied by Ella on the same day
    for day in [1, 2]:
        if day in availability["Diana"] and day in availability["Ella"]:
            model.addConstr(x[("Diana", day)] <= x[("Ella", day)], f"DianaRequiresElla_day{day}")
    
    # Max distinct children over both days
    total_attendance = {}
    for child in children:
        total_attendance[child] = model.addVar(vtype=GRB.BINARY, name=f"total_attendance_{child}")
        model.addConstr(total_attendance[child] <= x.get((child, 1), 0))
        model.addConstr(total_attendance[child] <= x.get((child, 2), 0))
        model.addConstr(total_attendance[child] >= x.get((child, 1), 0) + x.get((child, 2), 0) - 1)
    
    model.addConstr(sum(total_attendance.values()) <= max_distinct_children, "MaxDistinctChildren")
    
    # Total cost budget constraint
    model.addConstr(total_cost - bonus_saving * sum(attend_both_days.values()) <= total_cost_budget, "TotalCostBudget")
    
    # Optimize
    model.optimize()
    
    # Print solution details
    print("Status:", model.status)
    for child in children:
        for day in [1, 2]:
            if day in availability[child] and x[(child, day)].x > 0.5:
                print(f"  {child} on day {day}: selected")
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
