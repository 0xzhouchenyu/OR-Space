import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define data file paths
    current_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(current_dir, "data", "table_1.csv")
    params_path = os.path.join(current_dir, "data", "general_parameters.csv")

    # Load data
    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    # Extract parameters for Supplier 1
    raw_pipe_length_s1 = float(df_params[df_params['Parameter_Name'] == 'raw_pipe_length_supplier1']['Value'].values[0])
    max_cutting_patterns_s1 = int(df_params[df_params['Parameter_Name'] == 'max_cutting_patterns_supplier1']['Value'].values[0])
    max_cuts_per_pipe_s1 = int(df_params[df_params['Parameter_Name'] == 'max_cuts_per_pipe_supplier1']['Value'].values[0])
    max_leftover_length_s1 = float(df_params[df_params['Parameter_Name'] == 'max_leftover_length_supplier1']['Value'].values[0])
    min_length_s1 = raw_pipe_length_s1 - max_leftover_length_s1
    cost_rates_s1 = [
        float(df_params[df_params['Parameter_Name'] == 'most_frequent_pattern_cost_rate_supplier1']['Value'].values[0]),
        float(df_params[df_params['Parameter_Name'] == 'second_frequent_pattern_cost_rate_supplier1']['Value'].values[0]),
        float(df_params[df_params['Parameter_Name'] == 'third_frequent_pattern_cost_rate_supplier1']['Value'].values[0])
    ]
    purchase_cost_per_pipe_s1 = float(df_params[df_params['Parameter_Name'] == 'purchase_cost_per_pipe_supplier1']['Value'].values[0])
    discount_tier1_s1_max_qty = int(df_params[df_params['Parameter_Name'] == 'discount_tier1_supplier1_max_qty']['Value'].values[0])
    fixed_discount_tier2_s1 = float(df_params[df_params['Parameter_Name'] == 'fixed_discount_tier2_supplier1']['Value'].values[0])

    # Extract parameters for Supplier 2
    raw_pipe_length_s2 = float(df_params[df_params['Parameter_Name'] == 'raw_pipe_length_supplier2']['Value'].values[0])
    max_cutting_patterns_s2 = int(df_params[df_params['Parameter_Name'] == 'max_cutting_patterns_supplier2']['Value'].values[0])
    max_cuts_per_pipe_s2 = int(df_params[df_params['Parameter_Name'] == 'max_cuts_per_pipe_supplier2']['Value'].values[0])
    max_leftover_length_s2 = float(df_params[df_params['Parameter_Name'] == 'max_leftover_length_supplier2']['Value'].values[0])
    min_length_s2 = raw_pipe_length_s2 - max_leftover_length_s2
    cost_rates_s2 = [
        float(df_params[df_params['Parameter_Name'] == 'most_frequent_pattern_cost_rate_supplier2']['Value'].values[0]),
        float(df_params[df_params['Parameter_Name'] == 'second_frequent_pattern_cost_rate_supplier2']['Value'].values[0]),
        float(df_params[df_params['Parameter_Name'] == 'third_frequent_pattern_cost_rate_supplier2']['Value'].values[0])
    ]
    purchase_cost_per_pipe_s2 = float(df_params[df_params['Parameter_Name'] == 'purchase_cost_per_pipe_supplier2']['Value'].values[0])

    # Extract customer demand
    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)

    # Generate cutting patterns for each supplier
    def generate_patterns(raw_pipe_length, max_cuts, max_leftover, min_length):
        patterns = []
        n = len(lengths)

        def recursive_pattern(pattern, length, cuts, idx):
            if idx == n:
                if length >= min_length and length <= raw_pipe_length and cuts > 0:
                    patterns.append(tuple(pattern))
                return

            max_pieces = min(int((raw_pipe_length - length) // lengths[idx]), max_cuts - cuts)
            for q in range(max_pieces + 1):
                recursive_pattern(pattern + [q], length + q * lengths[idx], cuts + q, idx + 1)

        recursive_pattern([], 0, 0, 0)
        return patterns

    patterns_s1 = generate_patterns(raw_pipe_length_s1, max_cuts_per_pipe_s1, max_leftover_length_s1, min_length_s1)
    patterns_s2 = generate_patterns(raw_pipe_length_s2, max_cuts_per_pipe_s2, max_leftover_length_s2, min_length_s2)

    # Create Gurobi model
    model = gp.Model("Pipe_Cutting_Rev")
    model.setParam('OutputFlag', 0)

    # Decision variables
    y_s1 = model.addVars(len(patterns_s1), vtype=GRB.INTEGER, name="y_s1")
    z_s1 = model.addVars(len(patterns_s1), vtype=GRB.BINARY, name="z_s1")
    u_s1 = model.addVars(range(1, max_cutting_patterns_s1 + 1), vtype=GRB.BINARY, name="u_s1")

    y_s2 = model.addVars(len(patterns_s2), vtype=GRB.INTEGER, name="y_s2")
    z_s2 = model.addVars(len(patterns_s2), vtype=GRB.BINARY, name="z_s2")
    u_s2 = model.addVars(range(1, max_cutting_patterns_s2 + 1), vtype=GRB.BINARY, name="u_s2")

    # Binary variable to indicate whether the discount applies for Supplier 1
    delta_s1 = model.addVar(vtype=GRB.BINARY, name="delta_s1")

    # Total number of pipes used from each supplier
    total_pipes_s1 = model.addVar(vtype=GRB.INTEGER, name="total_pipes_s1")
    total_pipes_s2 = model.addVar(vtype=GRB.INTEGER, name="total_pipes_s2")

    # Link total pipes with pattern usage
    model.addConstr(total_pipes_s1 == gp.quicksum(y_s1[p] for p in range(len(patterns_s1))))
    model.addConstr(total_pipes_s2 == gp.quicksum(y_s2[p] for p in range(len(patterns_s2))))

    # Link pattern usage with binary indicators
    M = sum(demands)
    for p in range(len(patterns_s1)):
        model.addConstr(y_s1[p] <= M * z_s1[p])
    for p in range(len(patterns_s2)):
        model.addConstr(y_s2[p] <= M * z_s2[p])

    # Limit number of patterns per supplier
    model.addConstr(gp.quicksum(z_s1[p] for p in range(len(patterns_s1))) == gp.quicksum(u_s1[k] for k in range(1, max_cutting_patterns_s1 + 1)))
    model.addConstr(gp.quicksum(z_s2[p] for p in range(len(patterns_s2))) == gp.quicksum(u_s2[k] for k in range(1, max_cutting_patterns_s2 + 1)))

    # Pattern frequency ordering constraints for Supplier 1
    for k in range(1, max_cutting_patterns_s1):
        model.addConstr(u_s1[k] >= u_s1[k+1])

    # Pattern frequency ordering constraints for Supplier 2
    for k in range(1, max_cutting_patterns_s2):
        model.addConstr(u_s2[k] >= u_s2[k+1])

    # Demand satisfaction constraints
    for i in range(n_items):
        model.addConstr(
            gp.quicksum(patterns_s1[p][i] * y_s1[p] for p in range(len(patterns_s1))) +
            gp.quicksum(patterns_s2[p][i] * y_s2[p] for p in range(len(patterns_s2))) >= demands[i]
        )

    # Objective function components
    obj_purchase_cost = purchase_cost_per_pipe_s1 * total_pipes_s1 + purchase_cost_per_pipe_s2 * total_pipes_s2
    obj_fixed_discount_s1 = fixed_discount_tier2_s1 * delta_s1
    obj_pattern_cost_s1 = 0
    obj_pattern_cost_s2 = 0

    # Calculate pattern cost based on frequency ranking for Supplier 1
    freq_rank_s1 = model.addVars(len(patterns_s1), vtype=GRB.INTEGER, lb=0, ub=max_cutting_patterns_s1, name="freq_rank_s1")
    for p in range(len(patterns_s1)):
        for k in range(1, max_cutting_patterns_s1 + 1):
            model.addConstr(freq_rank_s1[p] <= (k + 1) * (1 - u_s1[k]))
            model.addConstr(freq_rank_s1[p] >= k * u_s1[k])

    for p in range(len(patterns_s1)):
        for k in range(1, max_cutting_patterns_s1 + 1):
            model.addConstr(freq_rank_s1[p] <= k + M * (1 - z_s1[p]))

    for k in range(1, max_cutting_patterns_s1 + 1):
        for p in range(len(patterns_s1)):
            model.addConstr(freq_rank_s1[p] >= k * z_s1[p] - M * (1 - u_s1[k]))

    for p in range(len(patterns_s1)):
        model.addConstr(freq_rank_s1[p] <= max_cutting_patterns_s1 + 1)

    for p in range(len(patterns_s1)):
        if k - 1 < len(cost_rates_s1):
            obj_pattern_cost_s1 += cost_rates_s1[freq_rank_s1[p].getAttr(GRB.Attr.LB) - 1] * y_s1[p]

    # Calculate pattern cost based on frequency ranking for Supplier 2
    freq_rank_s2 = model.addVars(len(patterns_s2), vtype=GRB.INTEGER, lb=0, ub=max_cutting_patterns_s2, name="freq_rank_s2")
    for p in range(len(patterns_s2)):
        for k in range(1, max_cutting_patterns_s2 + 1):
            model.addConstr(freq_rank_s2[p] <= (k + 1) * (1 - u_s2[k]))
            model.addConstr(freq_rank_s2[p] >= k * u_s2[k])

    for p in range(len(patterns_s2)):
        for k in range(1, max_cutting_patterns_s2 + 1):
            model.addConstr(freq_rank_s2[p] <= k + M * (1 - z_s2[p]))

    for k in range(1, max_cutting_patterns_s2 + 1):
        for p in range(len(patterns_s2)):
            model.addConstr(freq_rank_s2[p] >= k * z_s2[p] - M * (1 - u_s2[k]))

    for p in range(len(patterns_s2)):
        model.addConstr(freq_rank_s2[p] <= max_cutting_patterns_s2 + 1)

    for p in range(len(patterns_s2)):
        if k - 1 < len(cost_rates_s2):
            obj_pattern_cost_s2 += cost_rates_s2[freq_rank_s2[p].getAttr(GRB.Attr.LB) - 1] * y_s2[p]

    # Discount activation constraint for Supplier 1
    bigM = int(df_params[df_params['Parameter_Name'] == 'bigM_discount']['Value'].values[0])
    model.addConstr(total_pipes_s1 >= discount_tier1_s1_max_qty - bigM * (1 - delta_s1))
    model.addConstr(total_pipes_s1 <= discount_tier1_s1_max_qty + bigM * delta_s1)

    # Final objective function
    model.setObjective(obj_purchase_cost - obj_fixed_discount_s1 + obj_pattern_cost_s1 + obj_pattern_cost_s2, GRB.MINIMIZE)

    # Optimize the model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
