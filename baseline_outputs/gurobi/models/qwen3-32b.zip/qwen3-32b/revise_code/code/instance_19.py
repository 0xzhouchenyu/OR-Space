import os
import csv

# Import Gurobi
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            # Try to convert to numeric
            try:
                value = int(value_str)
            except ValueError:
                try:
                    value = float(value_str)
                except ValueError:
                    value = value_str
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
cost_A = params['cost_per_chair_A']       # 50 USD per chair
cost_B = params['cost_per_chair_B']       # 45 USD per chair
cost_C = params['cost_per_chair_C']       # 40 USD per chair
chairs_per_order_A = params['chairs_per_order_A']  # 15 chairs per order
chairs_per_order_B = params['chairs_per_order_B']  # 10 chairs per order
chairs_per_order_C = params['chairs_per_order_C']  # 10 chairs per order
min_total = params['min_total_chairs']    # 100
max_total = params['max_total_chairs']    # 500
min_chairs_B_if_A = params['min_chairs_B_if_A']  # 10 chairs from B if ordering from A
dependency_B_C = params['dependency_B_C']  # if B ordered, must also order C
fixed_fee_A_regular = params['fixed_fee_A_regular']
fixed_fee_A_express = params['fixed_fee_A_express']
fixed_fee_B_regular = params['fixed_fee_B_regular']
fixed_fee_B_express = params['fixed_fee_B_express']
fixed_fee_C_regular = params['fixed_fee_C_regular']
fixed_fee_C_express = params['fixed_fee_C_express']
weekly_order_budget = params['weekly_order_budget']

# Create the model
model = gp.Model("FurnitureOrder")

# Decision variables: number of orders from each manufacturer (integer, >= 0)
# We need upper bounds. Max total chairs is 500.
max_orders_A = max_total // int(chairs_per_order_A) + 1
max_orders_B = max_total // int(chairs_per_order_B) + 1
max_orders_C = max_total // int(chairs_per_order_C) + 1

x_A = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_A, name="orders_A")
x_B = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_B, name="orders_B")
x_C = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_C, name="orders_C")

# Binary variables to indicate if we use each manufacturer
y_A = model.addVar(vtype=GRB.BINARY, name="y_A")
y_B = model.addVar(vtype=GRB.BINARY, name="y_B")
y_C = model.addVar(vtype=GRB.BINARY, name="y_C")

# Binary variables to indicate if we use regular or express channel for each manufacturer
z_A_regular = model.addVar(vtype=GRB.BINARY, name="z_A_regular")
z_A_express = model.addVar(vtype=GRB.BINARY, name="z_A_express")
z_B_regular = model.addVar(vtype=GRB.BINARY, name="z_B_regular")
z_B_express = model.addVar(vtype=GRB.BINARY, name="z_B_express")
z_C_regular = model.addVar(vtype=GRB.BINARY, name="z_C_regular")
z_C_express = model.addVar(vtype=GRB.BINARY, name="z_C_express")

# Total chairs from each manufacturer
chairs_A = chairs_per_order_A * x_A
chairs_B = chairs_per_order_B * x_B
chairs_C = chairs_per_order_C * x_C

# Objective: minimize total cost
# Cost is per chair + fixed fees for selected channels
obj = (
    cost_A * chairs_A +
    cost_B * chairs_B +
    cost_C * chairs_C +
    fixed_fee_A_regular * z_A_regular +
    fixed_fee_A_express * z_A_express +
    fixed_fee_B_regular * z_B_regular +
    fixed_fee_B_express * z_B_express +
    fixed_fee_C_regular * z_C_regular +
    fixed_fee_C_express * z_C_express
)

model.setObjective(obj, GRB.MINIMIZE)

# Constraint: total chairs between min and max
model.addConstr(chairs_A + chairs_B + chairs_C >= min_total, "MinChairs")
model.addConstr(chairs_A + chairs_B + chairs_C <= max_total, "MaxChairs")

# Link y variables to x variables
M = max_total + 1

# If x > 0 then y = 1
model.addConstr(x_A <= M * y_A, "LinkA1")
model.addConstr(x_A >= y_A, "LinkA2")  # if y=1 then at least 1 order

model.addConstr(x_B <= M * y_B, "LinkB1")
model.addConstr(x_B >= y_B, "LinkB2")

model.addConstr(x_C <= M * y_C, "LinkC1")
model.addConstr(x_C >= y_C, "LinkC2")

# Dependency: if ordering from A, must order at least min_chairs_B_if_A chairs from B
model.addConstr(chairs_B >= min_chairs_B_if_A * y_A, "DepAB")

# Dependency: if ordering from B, must also order from C
model.addConstr(y_B <= y_C, "DepBC")

# For each manufacturer, choose either regular or express channel, not both
model.addConstr(z_A_regular + z_A_express == y_A, "ChannelChoiceA")
model.addConstr(z_B_regular + z_B_express == y_B, "ChannelChoiceB")
model.addConstr(z_C_regular + z_C_express == y_C, "ChannelChoiceC")

# Weekly order budget constraint: maximum number of active manufacturer-mode combinations
model.addConstr(
    z_A_regular + z_A_express +
    z_B_regular + z_B_express +
    z_C_regular + z_C_express <= weekly_order_budget,
    "WeeklyOrderBudget"
)

# Solve
model.setParam('OutputFlag', 0)
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
