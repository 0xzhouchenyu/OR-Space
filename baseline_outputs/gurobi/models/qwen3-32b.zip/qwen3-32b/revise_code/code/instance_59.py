import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load general parameters
    general_params = {}
    filepath = os.path.join(data_dir, "general_parameters.csv")
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row["Parameter_Name"]] = float(row["Value"])
    
    # Load table 1.7
    table_1_7 = []
    filepath = os.path.join(data_dir, "table_1_7.csv")
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            table_1_7.append(row)
    
    return general_params, table_1_7

def main():
    general_params, table_1_7 = load_data()
    
    # Extract relevant parameters from the data
    raw_materials = ['A', 'B', 'C']
    brands = ['A', 'B', 'C']
    
    # Raw material costs and monthly limits
    raw_cost = [2.00, 1.50, 1.00]
    limits = [2000, 2500, 1200]
    
    # Processing fees and selling prices
    proc_fee = [0.50, 0.40, 0.30]
    sell_price = [3.40, 2.85, 2.25]
    
    # Setup costs
    setup_cost = [
        general_params.get("SetupCost_A", 0),
        general_params.get("SetupCost_B", 0),
        general_params.get("SetupCost_C", 0)
    ]
    
    # Shared wrapper fee
    shared_wrapper_fee = general_params.get("BrandAB_SharedWrapper_Fee", 0)
    
    # Create model
    model = gp.Model("CandyFactory")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = {}  # Amount of raw material i used in brand j
    y = {}  # Total production of each brand
    z = {}  # Binary variable indicating if a brand is produced (1 if > 0, 0 otherwise)
    
    for i in range(3):  # Raw materials A, B, C
        for j in range(3):  # Brands A, B, C
            x[i, j] = model.addVar(lb=0, name=f"x_{raw_materials[i]}_{brands[j]}")
    
    for j in range(3):  # Brands A, B, C
        y[j] = model.addVar(lb=0, name=f"y_{brands[j]}")
        z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{brands[j]}")
    
    # Update model to integrate new variables
    model.update()
    
    # Link y and x
    for j in range(3):
        model.addConstr(y[j] == gp.quicksum(x[i, j] for i in range(3)))
    
    # Link z and y (if y > 0, then z = 1)
    for j in range(3):
        model.addConstr(y[j] <= 1e6 * z[j])  # Big-M constraint
    
    # Objective: maximize profit
    revenue = gp.quicksum(sell_price[j] * y[j] for j in range(3))
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in range(3))
    setup_cost_total = gp.quicksum(setup_cost[j] * z[j] for j in range(3))
    
    # Shared wrapper coordination cost for producing both A and B
    shared_wrapper = model.addVar(vtype=GRB.BINARY, name="shared_wrapper")
    model.addConstr(shared_wrapper >= z[0] + z[1] - 1)  # If both A and B are produced, shared_wrapper = 1
    wrapper_cost = shared_wrapper * shared_wrapper_fee
    
    model.setObjective(revenue - material_cost - processing_cost - setup_cost_total - wrapper_cost, GRB.MAXIMIZE)
    
    # Raw material supply constraints
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= limits[i])
    
    # Composition constraints
    # Raw material A (i=0): >=60% in brand A (j=0), >=15% in brand B (j=1)
    model.addConstr(x[0, 0] >= 0.60 * y[0])  # RM A >= 60% of Brand A
    model.addConstr(x[0, 1] >= 0.15 * y[1])  # RM A >= 15% of Brand B
    
    # Raw material C (i=2): <=20% in brand A (j=0), <=60% in brand B (j=1), <=50% in brand C (j=2)
    model.addConstr(x[2, 0] <= 0.20 * y[0])  # RM C <= 20% of Brand A
    model.addConstr(x[2, 1] <= 0.60 * y[1])  # RM C <= 60% of Brand B
    model.addConstr(x[2, 2] <= 0.50 * y[2])  # RM C <= 50% of Brand C
    
    # Optimize model
    model.optimize()
    
    # Print results
    if model.status == GRB.OPTIMAL:
        obj_value = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_value:.1f}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
