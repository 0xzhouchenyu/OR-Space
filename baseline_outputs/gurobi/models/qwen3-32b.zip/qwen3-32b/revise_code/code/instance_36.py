import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Read general parameters
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            for key, value in row.items():
                if key == "Parameter_Name":
                    continue
                params[key] = value

    num_customers = int(params['num_customers'])
    max_trucks = int(params['max_trucks'])
    truck_capacity = float(params['truck_capacity'])
    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])

    # Parse depot coordinates
    depot_str = params.get('depot_coordinates', '(40,50)').strip('()')
    if ',' in depot_str:
        depot_x, depot_y = map(float, depot_str.split(','))
    else:
        depot_x, depot_y = map(float, depot_str.split())

    coords = [(depot_x, depot_y)]
    demands_list = [0]
    tw_list = [(depot_tw_start, depot_tw_end)]
    svc_list = [0]
    outsource_cost = [0]
    is_mandatory_external = [0]

    # Read customer data
    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            customer_id = int(row['Customer_ID'])
            coords.append((float(row['Coordinates_X']), float(row['Coordinates_Y'])))
            demands_list.append(float(row['Demand']))
            tw_list.append((float(row['Time_Window_Start']), float(row['Time_Window_End'])))
            svc_list.append(float(row['Service_Duration']))
            outsource_cost.append(float(row['Outsource_Cost']))
            is_mandatory_external.append(int(row['Mandatory_External']))

    n = len(coords)  # Total number of nodes including the depot
    N = list(range(1, n))  # All customers
    V = list(range(n))   # All nodes (including depot)

    # Filter out mandatory external customers
    non_mandatory_customers = [i for i in N if is_mandatory_external[i] == 0]
    mandatory_customers = [i for i in N if is_mandatory_external[i] == 1]

    dist = {}
    for i in V:
        for j in V:
            dist[i, j] = calculate_distance(coords[i], coords[j])

    # Create Gurobi model
    model = gp.Model("VRPHTW_Revision")

    # Decision variables
    x = model.addVars([(i, j) for i in V for j in V if i != j and not (is_mandatory_external[i] or is_mandatory_external[j])], vtype=GRB.BINARY, name="x")
    t = model.addVars(V, lb=0, name="t")  # Time at each node
    y = model.addVars(non_mandatory_customers, vtype=GRB.BINARY, name="y")  # 1 if customer is served by in-house truck, 0 if outsourced

    # Objective: minimize total in-house travel distance plus outsourcing cost
    model.setObjective(
        gp.quicksum(dist[i, j] * x[i, j] for i, j in x.keys()) +
        gp.quicksum(outsource_cost[i] * (1 - y[i]) for i in non_mandatory_customers),
        GRB.MINIMIZE
    )

    # Constraints

    # Each non-mandatory customer must be either served by an in-house truck or outsourced
    for i in non_mandatory_customers:
        model.addConstr(y[i] + (1 - y[i]) == 1)

    # If a customer is outsourced, it cannot be part of any route
    for i in non_mandatory_customers:
        model.addConstr(gp.quicksum(x[i, j] for j in V if j != i) <= y[i])
        model.addConstr(gp.quicksum(x[j, i] for j in V if j != i) <= y[i])

    # Flow conservation for in-house customers
    for i in non_mandatory_customers:
        model.addConstr(gp.quicksum(x[j, i] for j in V if (j, i) in x and j != i) == y[i])
        model.addConstr(gp.quicksum(x[i, j] for j in V if (i, j) in x and j != i) == y[i])

    # Fleet size limit for in-house trucks
    model.addConstr(gp.quicksum(x[0, j] for j in non_mandatory_customers if (0, j) in x) <= inhouse_truck_limit)

    # Time window constraints
    for i in non_mandatory_customers:
        model.addConstr(t[i] >= tw_list[i][0])
        model.addConstr(t[i] <= tw_list[i][1])

    # Time continuity constraints
    M_val = tw_list[0][1] + max(svc_list)
    for i, j in x.keys():
        if j != 0:
            model.addConstr(t[i] + svc_list[i] + dist[i, j] - t[j] <= M_val * (1 - x[i, j]))

    # Capacity constraints
    for i, j in x.keys():
        if i != 0 and j != 0:
            model.addConstr(demands_list[i] + demands_list[j] <= truck_capacity + truck_capacity * (1 - x[i, j]))

    # Depot time window
    model.addConstr(t[0] >= tw_list[0][0])
    model.addConstr(t[0] <= tw_list[0][1])

    # Solve the model
    model.setParam('OutputFlag', 0)
    model.optimize()

    # Output the objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
