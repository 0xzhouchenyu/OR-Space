import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general_parameters.csv
    general_params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            value = float(row['Value'])
            general_params[param_name] = value
    
    # Read table_1.csv
    workshops = []
    capacities = {}
    rates = {}  # rates[(workshop, component)] = production rate
    
    filepath = os.path.join(data_dir, 'table_1.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    components = [1, 2, 3]
    shifts = ['day', 'night']
    
    # Create Gurobi model
    model = gp.Model("Maximize_Completed_Products_with_Shift_Constraints")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: hours each workshop allocates to each component in each shift (regular and overtime)
    regular_hours = {}
    overtime_hours = {}
    for w in workshops:
        for s in shifts:
            regular_hours[(w, s)] = model.addVar(name=f"regular_{w}_{s}", lb=0)
            overtime_hours[(w, s)] = model.addVar(name=f"overtime_{w}_{s}", lb=0)
    
    # Binary variables to indicate if a workshop is active in a shift
    active_shift = {}
    for w in workshops:
        for s in shifts:
            active_shift[(w, s)] = model.addVar(vtype=GRB.BINARY, name=f"active_{w}_{s}")
    
    # Total hours allocated by workshop to each component
    x = {}
    for w in workshops:
        for c in components:
            x[(w, c)] = model.addVar(name=f"x_{w}_{c}", lb=0)
    
    # z = number of completed products (min of total units per component)
    z = model.addVar(name="z", lb=0)
    
    # Objective function: maximize z - minimize penalties
    obj = z
    
    # Add penalty terms for night work and overtime
    for w in workshops:
        for s in shifts:
            reg_limit_name_day = f'regular_hours_limit_{s}_A'
            reg_limit_name_night = f'regular_hours_limit_{s}_B'
            ot_limit_name_day = f'overtime_capacity_{s}_A'
            ot_limit_name_night = f'overtime_capacity_{s}_B'
            
            # Get the correct parameter names for this workshop and shift
            reg_limit_param = f'regular_hours_limit_{s}_{w}'
            ot_limit_param = f'overtime_capacity_{s}_{w}'
            
            reg_limit = general_params[reg_limit_param]
            ot_limit = general_params[ot_limit_param]
            
            # Penalty for night work (regular time only)
            if s == 'night':
                obj -= general_params['penalty_night_hour'] * regular_hours[(w, s)]
            
            # Penalty for overtime
            obj -= general_params['penalty_overtime_hour'] * overtime_hours[(w, s)]
    
    # Shortage penalty
    obj -= general_params['penalty_shortage_per_unit'] * max(0, general_params['z_target'] - z)
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Regular and overtime hours within limits
    for w in workshops:
        for s in shifts:
            reg_limit_param = f'regular_hours_limit_{s}_{w}'
            ot_limit_param = f'overtime_capacity_{s}_{w}'
            
            reg_limit = general_params[reg_limit_param]
            ot_limit = general_params[ot_limit_param]
            
            # Regular hours constraint
            model.addConstr(regular_hours[(w, s)] <= reg_limit, name=f"regular_hours_limit_{w}_{s}")
            
            # Overtime hours constraint
            model.addConstr(overtime_hours[(w, s)] <= ot_limit, name=f"overtime_hours_limit_{w}_{s}")
    
    # 2. Linking active indicator to hours worked
    for w in workshops:
        for s in shifts:
            bigM_param = f'bigM_shift_{w}'
            bigM = general_params[bigM_param]
            
            # If active, then at least one hour must be worked (regular or overtime)
            model.addConstr(
                regular_hours[(w, s)] + overtime_hours[(w, s)] >= active_shift[(w, s)],
                name=f"link_active_to_hours_{w}_{s}"
            )
            
            # If not active, then no hours can be worked
            model.addConstr(
                regular_hours[(w, s)] <= bigM * active_shift[(w, s)],
                name=f"link_hours_to_active_reg_{w}_{s}"
            )
            model.addConstr(
                overtime_hours[(w, s)] <= bigM * active_shift[(w, s)],
                name=f"link_hours_to_active_ot_{w}_{s}"
            )
    
    # 3. No more than two workshops active in the same shift
    for s in shifts:
        model.addConstr(gp.quicksum(active_shift[(w, s)] for w in workshops) <= 2, name=f"max_workshops_active_{s}")
    
    # 4. Total hours allocated to each component by each workshop
    for w in workshops:
        model.addConstr(
            gp.quicksum(rates[(w, c)] * x[(w, c)] for c in components) ==
            gp.quicksum(rates[(w, c)] * x[(w, c)] for c in components),
            name=f"dummy_component_hours_{w}"
        )
        
        # This is just to ensure we have constraints for the x variables
        model.addConstr(
            x[(w, 1)] == regular_hours[(w, 'day')] + overtime_hours[(w, 'day')] +
            regular_hours[(w, 'night')] + overtime_hours[(w, 'night')],
            name=f"total_hours_{w}"
        )
    
    # 5. z <= total production of each component
    for c in components:
        model.addConstr(
            z <= gp.quicksum(rates[(w, c)] * x[(w, c)] for w in workshops),
            name=f"Min_component_{c}"
        )
    
    # Optimize the model
    model.optimize()
    
    # Print solution details
    if model.status == GRB.OPTIMAL:
        print(f"\nStatus: OPTIMAL")
        for w in workshops:
            for s in shifts:
                val_reg = regular_hours[(w, s)].x
                val_ot = overtime_hours[(w, s)].x
                if val_reg > 1e-6 or val_ot > 1e-6:
                    print(f"Workshop {w}, Shift {s}: {val_reg:.2f} regular hours, {val_ot:.2f} overtime hours")
        
        for w in workshops:
            for c in components:
                val = x[(w, c)].x
                if val > 1e-6:
                    print(f"Workshop {w}, Component {c}: {val:.2f} hours -> {rates[(w,c)] * val:.2f} units")
        
        for c in components:
            total = sum(rates[(w, c)] * x[(w, c)].x for w in workshops)
            print(f"Total Component {c}: {total:.2f} units")
        
        obj_val = model.objVal
        print(f"\nFINAL_OBJ_VALUE: {obj_val:.1f}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
