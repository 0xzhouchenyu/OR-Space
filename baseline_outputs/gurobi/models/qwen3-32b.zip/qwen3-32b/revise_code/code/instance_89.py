import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Define the model
def main():
    # Set up data paths
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, "data")
    general_params_path = os.path.join(data_dir, "general_parameters.csv")
    
    # Load parameters
    params = load_general_parameters(general_params_path)

    # Extract parameters
    profit_A = params['profit_per_kg_product_A']
    profit_B = params['profit_per_kg_product_B']
    max_hours_week1 = params['max_production_hours_week_1']
    max_hours_week2 = params['max_production_hours_week_2']
    hours_A = params['hours_per_kg_product_A']
    hours_B = params['hours_per_kg_product_B']
    min_ratio_B_to_A = params['min_output_ratio_product_B_to_A']
    storage_ratio_A_to_B = params['storage_space_ratio_product_A_to_B']
    max_storage_A_week1 = params['max_storage_product_A_equiv_week_1']
    max_storage_A_week2 = params['max_storage_product_A_equiv_week_2']
    initial_inventory_A = params['initial_inventory_A']
    initial_inventory_B = params['initial_inventory_B']
    storage_cost_A = params['storage_cost_per_kg_A']
    storage_cost_B = params['storage_cost_per_kg_B']
    promo_bonus_A = params['promo_profit_bonus_A']
    promo_bonus_B = params['promo_profit_bonus_B']
    max_promo_A = params['max_promotions_product_A']
    max_promo_B = params['max_promotions_product_B']

    # Create a new model
    model = gp.Model("Two_Week_Liquid_Products_Optimization")

    # Suppress output
    model.setParam('OutputFlag', 0)

    # Decision variables
    # Production quantities
    prod_A_week1 = model.addVar(name="prod_A_week1", lb=0)
    prod_B_week1 = model.addVar(name="prod_B_week1", lb=0)
    prod_A_week2 = model.addVar(name="prod_A_week2", lb=0)
    prod_B_week2 = model.addVar(name="prod_B_week2", lb=0)

    # Sales quantities (must be <= production + inventory)
    sales_A_week1 = model.addVar(name="sales_A_week1", lb=0)
    sales_B_week1 = model.addVar(name="sales_B_week1", lb=0)
    sales_A_week2 = model.addVar(name="sales_A_week2", lb=0)
    sales_B_week2 = model.addVar(name="sales_B_week2", lb=0)

    # Inventory at end of week 1
    inv_A_week1 = model.addVar(name="inv_A_week1", lb=0)
    inv_B_week1 = model.addVar(name="inv_B_week1", lb=0)

    # Promotion binary variables
    promo_A_week1 = model.addVar(vtype=GRB.BINARY, name="promo_A_week1")
    promo_A_week2 = model.addVar(vtype=GRB.BINARY, name="promo_A_week2")
    promo_B_week1 = model.addVar(vtype=GRB.BINARY, name="promo_B_week1")
    promo_B_week2 = model.addVar(vtype=GRB.BINARY, name="promo_B_week2")

    # Update model to integrate new variables
    model.update()

    # Objective function: maximize total profit minus storage costs
    obj = (
        (profit_A * sales_A_week1 + profit_B * sales_B_week1) +
        (profit_A * sales_A_week2 + profit_B * sales_B_week2) +
        (promo_bonus_A * sales_A_week1 * promo_A_week1 + promo_bonus_B * sales_B_week1 * promo_B_week1) +
        (promo_bonus_A * sales_A_week2 * promo_A_week2 + promo_bonus_B * sales_B_week2 * promo_B_week2) -
        (storage_cost_A * inv_A_week1 + storage_cost_B * inv_B_week1)
    )
    model.setObjective(obj, GRB.MAXIMIZE)

    # Constraints

    # Week 1 production time constraint
    model.addConstr(hours_A * prod_A_week1 + hours_B * prod_B_week1 <= max_hours_week1, "Production_Hours_Week1")

    # Week 2 production time constraint
    model.addConstr(hours_A * prod_A_week2 + hours_B * prod_B_week2 <= max_hours_week2, "Production_Hours_Week2")

    # Market demand ratio constraints
    model.addConstr(prod_B_week1 >= min_ratio_B_to_A * prod_A_week1, "Market_Demand_Week1")
    model.addConstr(prod_B_week2 >= min_ratio_B_to_A * prod_A_week2, "Market_Demand_Week2")

    # Storage capacity constraints
    model.addConstr(
        storage_ratio_A_to_B * prod_A_week1 + prod_B_week1 <= 
        max_storage_A_week1 * storage_ratio_A_to_B, 
        "Storage_Capacity_Week1"
    )
    model.addConstr(
        storage_ratio_A_to_B * prod_A_week2 + prod_B_week2 <= 
        max_storage_A_week2 * storage_ratio_A_to_B, 
        "Storage_Capacity_Week2"
    )

    # Inventory balance constraints
    model.addConstr(inv_A_week1 == initial_inventory_A + prod_A_week1 - sales_A_week1, "Inventory_Balance_A_Week1")
    model.addConstr(inv_B_week1 == initial_inventory_B + prod_B_week1 - sales_B_week1, "Inventory_Balance_B_Week1")

    # Sales cannot exceed available quantity (production + inventory)
    model.addConstr(sales_A_week1 <= prod_A_week1 + initial_inventory_A, "Sales_Limit_A_Week1")
    model.addConstr(sales_B_week1 <= prod_B_week1 + initial_inventory_B, "Sales_Limit_B_Week1")
    model.addConstr(sales_A_week2 <= prod_A_week2 + inv_A_week1, "Sales_Limit_A_Week2")
    model.addConstr(sales_B_week2 <= prod_B_week2 + inv_B_week1, "Sales_Limit_B_Week2")

    # Promotion limits
    model.addConstr(promo_A_week1 + promo_A_week2 <= max_promo_A, "Promotion_Limit_A")
    model.addConstr(promo_B_week1 + promo_B_week2 <= max_promo_B, "Promotion_Limit_B")

    # Solve the model
    model.optimize()

    # Output final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.3f}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
