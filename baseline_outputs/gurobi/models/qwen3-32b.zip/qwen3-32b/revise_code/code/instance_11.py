import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Read CSVs
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    # Parse Table 1
    row_a = df1[df1["Type"] == "Type_A"].iloc[0]
    row_b = df1[df1["Type"] == "Type_B"].iloc[0]
    row_cap = df1[df1["Type"] == "Max_weekly_capacity"].iloc[0]
    row_cost = df1[df1["Type"] == "Process_cost_Yuan_per_hour"].iloc[0]

    mfg_a = float(row_a["Manufacturing_hours_per_unit"])
    asm_a = float(row_a["Assembly_hours_per_unit"])
    price_a = float(row_a["Selling_Price_Yuan_per_unit"])

    mfg_b = float(row_b["Manufacturing_hours_per_unit"])
    asm_b = float(row_b["Assembly_hours_per_unit"])
    price_b = float(row_b["Selling_Price_Yuan_per_unit"])

    cap_mfg = float(row_cap["Manufacturing_hours_per_unit"])
    cap_asm = float(row_cap["Assembly_hours_per_unit"])
    cap_insp = float(row_cap["Inspection_hours_per_unit"])

    cost_mfg = float(row_cost["Manufacturing_hours_per_unit"])
    cost_asm = float(row_cost["Assembly_hours_per_unit"])

    # Parse Parameters
    min_profit = float(df_params[df_params["Parameter_Name"] == "min_weekly_profit"]["Value"].iloc[0])
    min_a = float(df_params[df_params["Parameter_Name"] == "min_type_a_production"]["Value"].iloc[0])
    insp_a_M = float(df_params[df_params["Parameter_Name"] == "insp_a_M"]["Value"].iloc[0])
    insp_b_M = float(df_params[df_params["Parameter_Name"] == "insp_b_M"]["Value"].iloc[0])
    insp_a_E = float(df_params[df_params["Parameter_Name"] == "insp_a_E"]["Value"].iloc[0])
    insp_b_E = float(df_params[df_params["Parameter_Name"] == "insp_b_E"]["Value"].iloc[0])
    cap_ext = float(df_params[df_params["Parameter_Name"] == "cap_ext"]["Value"].iloc[0])
    cost_insp_M = float(df_params[df_params["Parameter_Name"] == "cost_insp_M"]["Value"].iloc[0])
    cost_insp_E = float(df_params[df_params["Parameter_Name"] == "cost_insp_E"]["Value"].iloc[0])
    cost_ext = float(df_params[df_params["Parameter_Name"] == "cost_ext"]["Value"].iloc[0])
    mode_fee_M = float(df_params[df_params["Parameter_Name"] == "mode_fee_M"]["Value"].iloc[0])
    mode_fee_E = float(df_params[df_params["Parameter_Name"] == "mode_fee_E"]["Value"].iloc[0])
    risk_penalty_M = float(df_params[df_params["Parameter_Name"] == "risk_penalty_M"]["Value"].iloc[0])
    cost_insp_weight = float(df_params[df_params["Parameter_Name"] == "cost_insp_weight"]["Value"].iloc[0])
    planning_horizon_weeks = int(df_params[df_params["Parameter_Name"] == "planning_horizon_weeks"]["Value"].iloc[0])
    idle_tolerance = float(df_params[df_params["Parameter_Name"] == "idle_tolerance"]["Value"].iloc[0])

    # Calculate unit profits
    cost_a = mfg_a * cost_mfg + asm_a * cost_asm
    profit_a = price_a - cost_a

    cost_b = mfg_b * cost_mfg + asm_b * cost_asm
    profit_b = price_b - cost_b

    # Create model
    model = gp.Model("TwoWeekMotorcycleProduction")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x_A = model.addVars(planning_horizon_weeks, vtype=GRB.INTEGER, name="x_A", lb=min_a)
    x_B = model.addVars(planning_horizon_weeks, vtype=GRB.INTEGER, name="x_B", lb=0)
    y_M = model.addVars(planning_horizon_weeks, vtype=GRB.BINARY, name="y_M")  # Manual inspection mode
    y_E = model.addVars(planning_horizon_weeks, vtype=GRB.BINARY, name="y_E")  # Enhanced inspection mode
    z_ext = model.addVars(planning_horizon_weeks, vtype=GRB.CONTINUOUS, name="z_ext", lb=0)  # External inspection hours

    # Constraints: Only one inspection protocol per week
    for t in range(planning_horizon_weeks):
        model.addConstr(y_M[t] + y_E[t] <= 1, f"Single_Mode_{t}")
        model.addConstr(y_M[t] + y_E[t] >= 1, f"At_least_One_Mode_{t}")

    # Capacity constraints
    for t in range(planning_horizon_weeks):
        model.addConstr(mfg_a * x_A[t] + mfg_b * x_B[t] <= cap_mfg, f"Capacity_MFG_{t}")
        model.addConstr(asm_a * x_A[t] + asm_b * x_B[t] <= cap_asm, f"Capacity_ASM_{t}")

        # Inspection capacity constraint based on selected mode
        model.addConstr(
            insp_a_M * x_A[t] * y_M[t] + insp_b_M * x_B[t] * y_M[t] +
            insp_a_E * x_A[t] * y_E[t] + insp_b_E * x_B[t] * y_E[t] + z_ext[t] <= cap_insp,
            f"Capacity_INSP_{t}"
        )

        # External inspection capacity constraint (only for Enhanced mode)
        model.addConstr(z_ext[t] <= cap_ext * y_E[t], f"External_Capacity_{t}")

    # Profit constraint
    for t in range(planning_horizon_weeks):
        model.addConstr(profit_a * x_A[t] + profit_b * x_B[t] >= min_profit, f"Min_Profit_{t}")

    # Objective function: Minimize weighted idle time and risk penalty
    total_idle_cost = 0
    total_risk_penalty = 0
    total_fixed_mode_cost = 0

    for t in range(planning_horizon_weeks):
        # Idle time costs
        idle_mfg = cap_mfg - (mfg_a * x_A[t] + mfg_b * x_B[t])
        idle_asm = cap_asm - (asm_a * x_A[t] + asm_b * x_B[t])
        idle_insp = cap_insp - (
            insp_a_M * x_A[t] * y_M[t] + insp_b_M * x_B[t] * y_M[t] +
            insp_a_E * x_A[t] * y_E[t] + insp_b_E * x_B[t] * y_E[t] + z_ext[t]
        )
        
        total_idle_cost += cost_mfg * idle_mfg + cost_asm * idle_asm + cost_insp_weight * idle_insp
        
        # Risk penalty for Manual mode
        total_risk_penalty += risk_penalty_M * y_M[t]
        
        # Fixed weekly fee for inspection mode
        total_fixed_mode_cost += mode_fee_M * y_M[t] + mode_fee_E * y_E[t]

    # First priority: minimize idle time and risk penalty
    model.setObjective(total_idle_cost + total_risk_penalty + total_fixed_mode_cost, GRB.MINIMIZE)

    # Solve the first stage
    model.optimize()

    if model.status != GRB.OPTIMAL:
        raise Exception("First stage optimization did not find an optimal solution.")

    # Save the minimal idle time and risk penalty value
    min_obj_val = model.objVal

    # Second stage: Maximize profit while maintaining the same idle time and risk penalty
    model2 = gp.Model("TwoWeekMotorcycleProfitMaximization")
    model2.setParam('OutputFlag', 0)

    # Re-declare decision variables
    x_A2 = model2.addVars(planning_horizon_weeks, vtype=GRB.INTEGER, name="x_A", lb=min_a)
    x_B2 = model2.addVars(planning_horizon_weeks, vtype=GRB.INTEGER, name="x_B", lb=0)
    y_M2 = model2.addVars(planning_horizon_weeks, vtype=GRB.BINARY, name="y_M")
    y_E2 = model2.addVars(planning_horizon_weeks, vtype=GRB.BINARY, name="y_E")
    z_ext2 = model2.addVars(planning_horizon_weeks, vtype=GRB.CONTINUOUS, name="z_ext", lb=0)

    # Re-implement constraints
    for t in range(planning_horizon_weeks):
        model2.addConstr(y_M2[t] + y_E2[t] <= 1, f"Single_Mode2_{t}")
        model2.addConstr(y_M2[t] + y_E2[t] >= 1, f"At_least_One_Mode2_{t}")

        model2.addConstr(mfg_a * x_A2[t] + mfg_b * x_B2[t] <= cap_mfg, f"Capacity_MFG2_{t}")
        model2.addConstr(asm_a * x_A2[t] + asm_b * x_B2[t] <= cap_asm, f"Capacity_ASM2_{t}")

        model2.addConstr(
            insp_a_M * x_A2[t] * y_M2[t] + insp_b_M * x_B2[t] * y_M2[t] +
            insp_a_E * x_A2[t] * y_E2[t] + insp_b_E * x_B2[t] * y_E2[t] + z_ext2[t] <= cap_insp,
            f"Capacity_INSP2_{t}"
        )

        model2.addConstr(z_ext2[t] <= cap_ext * y_E2[t], f"External_Capacity2_{t}")

        model2.addConstr(profit_a * x_A2[t] + profit_b * x_B2[t] >= min_profit, f"Min_Profit2_{t}")

    # Recalculate objective components
    total_idle_cost2 = 0
    total_risk_penalty2 = 0
    total_fixed_mode_cost2 = 0

    for t in range(planning_horizon_weeks):
        idle_mfg2 = cap_mfg - (mfg_a * x_A2[t] + mfg_b * x_B2[t])
        idle_asm2 = cap_asm - (asm_a * x_A2[t] + asm_b * x_B2[t])
        idle_insp2 = cap_insp - (
            insp_a_M * x_A2[t] * y_M2[t] + insp_b_M * x_B2[t] * y_M2[t] +
            insp_a_E * x_A2[t] * y_E2[t] + insp_b_E * x_B2[t] * y_E2[t] + z_ext2[t]
        )
        
        total_idle_cost2 += cost_mfg * idle_mfg2 + cost_asm * idle_asm2 + cost_insp_weight * idle_insp2
        total_risk_penalty2 += risk_penalty_M * y_M2[t]
        total_fixed_mode_cost2 += mode_fee_M * y_M2[t] + mode_fee_E * y_E2[t]

    # Constraint to maintain the same idle time and risk penalty
    model2.addConstr(
        total_idle_cost2 + total_risk_penalty2 + total_fixed_mode_cost2 <= min_obj_val + idle_tolerance,
        "Maintain_Idle_Time"
    )

    # Objective: Maximize profit
    total_profit = 0
    for t in range(planning_horizon_weeks):
        total_profit += profit_a * x_A2[t] + profit_b * x_B2[t]

    model2.setObjective(total_profit, GRB.MAXIMIZE)

    # Solve the second stage
    model2.optimize()

    if model2.status != GRB.OPTIMAL:
        raise Exception("Second stage optimization did not find an optimal solution.")

    final_obj = model2.objVal
    print(f"FINAL_OBJ_VALUE: {round(final_obj, 4)}")

if __name__ == "__main__":
    solve()
