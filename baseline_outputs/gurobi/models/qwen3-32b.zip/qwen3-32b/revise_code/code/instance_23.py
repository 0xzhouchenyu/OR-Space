import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'name': row['Product Name'].strip(),
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            })
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    available_labor = params['available_labor']
    available_material = params['available_material']
    fixed_costs = [
        params['fixed_cost_shirts'],
        params['fixed_cost_short_sleeves'],
        params['fixed_cost_casual_clothes']
    ]
    segment_regular_discount = params['segment_regular_discount']
    segment_promo_discount = params['segment_promo_discount']
    promo_labor_cap = params['segment_promo_labor_cap']
    promo_material_cap = params['segment_promo_material_cap']
    min_batch = [
        params['min_batch_shirts'],
        params['min_batch_short_sleeves'],
        params['min_batch_casual_clothes']
    ]
    max_prod = [
        params['max_prod_shirts'],
        params['max_prod_short_sleeves'],
        params['max_prod_casual_clothes']
    ]
    
    n = len(products)
    
    # Create Gurobi model
    model = gp.Model("clothing_production")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x_reg = [model.addVar(vtype=GRB.INTEGER, name=f"x_reg_{i}", lb=0) for i in range(n)]  # Regular segment production
    x_promo = [model.addVar(vtype=GRB.INTEGER, name=f"x_promo_{i}", lb=0) for i in range(n)]  # Promotional segment production
    y = [model.addVar(vtype=GRB.BINARY, name=f"y_{i}") for i in range(n)]  # Equipment activation indicator
    
    # Update the model to include new variables
    model.update()
    
    # Objective function: maximize profit
    profit = 0
    for i in range(n):
        regular_profit = (products[i]['price'] * segment_regular_discount - products[i]['var_cost']) * x_reg[i]
        promo_profit = (products[i]['price'] * segment_promo_discount - products[i]['var_cost']) * x_promo[i]
        profit += regular_profit + promo_profit
    
    total_fixed = sum(fixed_cost * y[i] for i, fixed_cost in enumerate(fixed_costs))
    model.setObjective(profit - total_fixed, GRB.MAXIMIZE)
    
    # Constraints
    # Labor and material constraints
    model.addConstr(gp.quicksum(products[i]['labor'] * (x_reg[i] + x_promo[i]) for i in range(n)) <= available_labor, "total_labor")
    model.addConstr(gp.quicksum(products[i]['material'] * (x_reg[i] + x_promo[i]) for i in range(n)) <= available_material, "total_material")
    
    # Promotional segment resource constraints
    model.addConstr(gp.quicksum(products[i]['labor'] * x_promo[i] for i in range(n)) <= promo_labor_cap, "promo_labor")
    model.addConstr(gp.quicksum(products[i]['material'] * x_promo[i] for i in range(n)) <= promo_material_cap, "promo_material")
    
    # Minimum batch size constraints with equipment activation
    for i in range(n):
        min_batch_constr = x_reg[i] + x_promo[i] >= min_batch[i] * y[i]
        model.addConstr(min_batch_constr, f"min_batch_{i}")
        
        # Big-M constraint to ensure equipment is activated if any production occurs
        model.addConstr(x_reg[i] + x_promo[i] <= max_prod[i] * y[i], f"big_m_{i}")
    
    # Optimize the model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
