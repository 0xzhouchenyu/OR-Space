import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(data_path)
    
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = row['Value']
        
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = int(params['raw_bar_length'])
    setup_cost = float(params['setup_cost_per_pattern'])
    max_patterns = int(params['max_distinct_patterns'])
    
    # Lengths of the three types of steel bars
    len1 = 3
    len2 = 4
    len3 = 5
    
    # Generate all valid cutting patterns
    patterns = []
    for x in range(L // len1 + 1):
        for y in range(L // len2 + 1):
            for z in range(L // len3 + 1):
                if len1 * x + len2 * y + len3 * z <= L:
                    if x > 0 or y > 0 or z > 0:
                        patterns.append((x, y, z))
    
    # Create a Gurobi model
    model = gp.Model("CuttingStock")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: number of times each pattern is used
    num_patterns = len(patterns)
    vars = model.addVars(num_patterns, vtype=GRB.INTEGER, name="Pattern", lb=0)
    
    # Binary variable to indicate if a pattern is used (for counting distinct patterns)
    use_pattern = model.addVars(num_patterns, vtype=GRB.BINARY, name="UsePattern")
    
    # Link between pattern usage and whether it's used
    model.addConstrs(vars[i] <= 1000000 * use_pattern[i] for i in range(num_patterns))
    
    # Constraint: limit the number of distinct patterns
    model.addConstr(gp.quicksum(use_pattern[i] for i in range(num_patterns)) <= max_patterns)
    
    # Objective: minimize total waste (including setup cost)
    # Total waste = (Total length of raw bars used) - (Total length of required pieces) + Setup cost
    model.setObjective(
        gp.quicksum(L * vars[i] for i in range(num_patterns)) 
        - (len1 * q3 + len2 * q4 + len3 * q5) 
        + setup_cost * gp.quicksum(use_pattern[i] for i in range(num_patterns)),
        GRB.MINIMIZE
    )
    
    # Constraints: satisfy the demand for each type of steel bar
    model.addConstr(gp.quicksum(patterns[i][0] * vars[i] for i in range(num_patterns)) >= q3)
    model.addConstr(gp.quicksum(patterns[i][1] * vars[i] for i in range(num_patterns)) >= q4)
    model.addConstr(gp.quicksum(patterns[i][2] * vars[i] for i in range(num_patterns)) >= q5)
    
    # Solve the problem
    model.optimize()
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
