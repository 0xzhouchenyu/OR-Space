import os
import gurobipy as gp
from gurobipy import GRB
import csv

def load_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            
            # Handle ratio values like "5:2"
            if ':' in value_str:
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_file = os.path.join(data_dir, "general_parameters.csv")
    params = load_parameters(params_file)
    
    # Extract parameters
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_hours = params['machine_working_time']
    max_overtime_hours = params['max_overtime_hours']
    overtime_penalty_per_hour = params['overtime_penalty_per_hour']
    overtime_review_threshold_hours = params['overtime_review_threshold_hours']
    overtime_review_fee = params['overtime_review_fee']
    production_ratio_A_to_B = params['production_ratio_A_to_B']
    product_A_senior_batch_threshold = params['product_A_senior_batch_threshold']
    product_A_senior_batch_fee = params['product_A_senior_batch_fee']
    
    # Convert working time to minutes
    machine_working_time_minutes = machine_working_time_hours * 60
    max_overtime_minutes = max_overtime_hours * 60
    overtime_review_threshold_minutes = overtime_review_threshold_hours * 60
    
    # Create model
    model = gp.Model("Revised_Product_Mix")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    A = model.addVar(name="Product_A", lb=0, vtype=GRB.CONTINUOUS)
    B = model.addVar(name="Product_B", lb=0, vtype=GRB.CONTINUOUS)
    O = model.addVar(name="Overtime", lb=0, ub=max_overtime_minutes, vtype=GRB.CONTINUOUS)
    Y = model.addVar(name="Overtime_Review_Fee", vtype=GRB.BINARY)
    Z = model.addVar(name="Senior_Batch_Fee", vtype=GRB.BINARY)
    
    # Objective function: maximize total profit minus costs
    model.setObjective(
        profit_A * A + profit_B * B 
        - (overtime_penalty_per_hour / 60) * O 
        - overtime_review_fee * Y 
        - product_A_senior_batch_fee * Z,
        GRB.MAXIMIZE
    )
    
    # Constraint 1: Machine time including overtime
    model.addConstr(assembly_time_A * A + assembly_time_B * B <= machine_working_time_minutes + O, "Machine_Time")
    
    # Constraint 2: Production ratio constraint
    ratio_A, ratio_B = production_ratio_A_to_B
    model.addConstr(ratio_B * A - ratio_A * B <= 0, "Production_Ratio")
    
    # Constraint 3: Overtime review fee activation
    model.addConstr(O >= overtime_review_threshold_minutes * Y, "Overtime_Review_Trigger")
    
    # Constraint 4: Senior batch fee activation
    model.addConstr(A <= product_A_senior_batch_threshold + 1e6 * Z, "Senior_Batch_Trigger")
    model.addConstr(A >= product_A_senior_batch_threshold + 1e-6 * (1 - Z), "Senior_Batch_Trigger_Lower")
    
    # Optimize the model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal:.1f}")

if __name__ == "__main__":
    main()
