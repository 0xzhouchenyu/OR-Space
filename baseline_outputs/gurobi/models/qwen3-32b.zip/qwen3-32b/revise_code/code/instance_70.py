import os
import sys
import csv
from itertools import permutations
import gurobipy as gp
from gurobipy import GRB

def load_distance_matrix(filepath):
    """Load distance matrix from CSV file.
    
    Returns:
        cities: list of city labels
        dist: 2D list of distances (dist[i][j] = distance from city i to city j)
    """
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: ['City', '1', '2', '3', '4', ...]
        city_labels = header[1:]
        
        dist = []
        cities = []
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
    
    return cities, dist

def load_parameters(param_file):
    """Load general parameters from CSV file."""
    params = {}
    with open(param_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            for key, value in row.items():
                if key != "parameter":
                    params[key] = value
    return params

def solve_tsp():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Load distance matrix
    dist_file = os.path.join(data_dir, "table_1.csv")
    cities, dist = load_distance_matrix(dist_file)
    n = len(cities)
    
    # Load general parameters
    param_file = os.path.join(data_dir, "general_parameters.csv")
    params = load_parameters(param_file)
    
    start_city = int(params["start_city"]) - 1  # Convert to 0-based index
    end_city = int(params["end_city"]) - 1
    prohibited_from = int(params["prohibited_from"]) - 1
    prohibited_to = int(params["prohibited_to"]) - 1
    inspection_arc_from = int(params["inspection_arc_from"]) - 1
    inspection_arc_to = int(params["inspection_arc_to"]) - 1
    inspection_stop_cost = float(params["inspection_stop_cost"])
    
    # Create Gurobi model
    model = gp.Model("TSP")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = {}
    for i in range(n):
        for j in range(n):
            if i != j:
                x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
    
    # MTZ variables for subtour elimination
    u = {}
    for i in range(1, n):  # Skip the starting city for MTZ formulation
        u[i] = model.addVar(lb=1, ub=n-1, vtype=GRB.CONTINUOUS, name=f"u_{i}")
    
    # Objective function
    obj = gp.LinExpr()
    for i in range(n):
        for j in range(n):
            if i != j:
                cost = dist[i][j]
                # Add inspection stop cost if applicable
                if i == inspection_arc_from and j == inspection_arc_to:
                    cost += inspection_stop_cost
                obj += cost * x[i, j]
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    
    # Each city is left exactly once
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1)
    
    # Each city is entered exactly once
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(n) if i != j) == 1)
    
    # Prohibition constraint: cannot go directly from start_city to prohibited_to
    if prohibited_from == start_city and prohibited_to == end_city:
        model.addConstr(x[start_city, prohibited_to] == 0)
    
    # MTZ constraints for subtour elimination
    for i in range(1, n):
        for j in range(1, n):
            if i != j:
                model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1)
    
    # Solve the model
    model.optimize()
    
    # Extract solution
    if model.status == GRB.OPTIMAL:
        best_route = [start_city]
        current = start_city
        while True:
            next_city = None
            for j in range(n):
                if j != current and x[current, j].x > 0.5:
                    next_city = j
                    break
            if next_city is None or next_city == start_city:
                break
            best_route.append(next_city)
            current = next_city
        
        # Ensure we end at the specified end city
        if best_route[-1] != end_city:
            for j in range(n):
                if j != current and x[current, j].x > 0.5 and j == end_city:
                    best_route.append(j)
                    break
        
        # Print final objective value
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_tsp()
