import os
import csv

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    # Extracting parameters
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    base_fleet_a = params['base_fleet_type_a']
    base_fleet_b = params['base_fleet_type_b']
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    type_b_threshold = params['type_b_recovery_threshold']
    type_b_fee = params['type_b_recovery_fee']
    total_threshold = params['total_fleet_surge_threshold']
    total_fee = params['total_fleet_surge_fee']
    
    # Create the optimization model
    model = gp.Model("TruckRentalOptimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = model.addVar(vtype=gp.GRB.INTEGER, lb=0, name="TypeA_trucks")
    y = model.addVar(vtype=gp.GRB.INTEGER, lb=0, name="TypeB_trucks")
    
    # Surplus variables for penalties
    surplus_a = model.addVar(vtype=gp.GRB.CONTINUOUS, lb=0, name="Surplus_TypeA")
    surplus_b = model.addVar(vtype=gp.GRB.CONTINUOUS, lb=0, name="Surplus_TypeB")
    
    # Binary variables for fixed costs
    b1 = model.addVar(vtype=gp.GRB.BINARY, name="TypeB_Recovery_Fee")
    b2 = model.addVar(vtype=gp.GRB.BINARY, name="Total_Surge_Fee")
    
    # Objective function: minimize total cost
    model.setObjective(
        cost_a * x + cost_b * y + 
        penalty_a * surplus_a + penalty_b * surplus_b +
        type_b_fee * b1 + total_fee * b2,
        gp.GRB.MINIMIZE
    )
    
    # Constraints for cargo requirements
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "Refrigerated_Requirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigerated_Requirement")
    
    # Constraints for Type A and Type B fleet thresholds
    model.addConstr(x - base_fleet_a <= surplus_a, "TypeA_Penalty")
    model.addConstr(y - base_fleet_b <= surplus_b, "TypeB_Penalty")
    
    # Constraints for binary variable b1 (Type B recovery fee)
    model.addConstr(y - type_b_threshold <= (type_b_threshold + 1) * b1, "TypeB_Recovery_Fee_Trigger")
    
    # Constraints for binary variable b2 (Total surge fee)
    model.addConstr(x + y - total_threshold <= (total_threshold + 1) * b2, "Total_Surge_Fee_Trigger")
    
    # Optimize the model
    model.optimize()
    
    # Output results
    if model.status == gp.GRB.OPTIMAL:
        final_obj_value = model.objVal
        print(f"FINAL_OBJ_VALUE: {final_obj_value}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    import gurobipy as gp
    from gurobipy import GRB
    main()
