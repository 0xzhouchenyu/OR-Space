import os
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def load_distances(data_dir):
    """Load distance data from table_1.csv"""
    filepath = os.path.join(data_dir, 'table_1.csv')
    distances = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            yard = row['Coal_Yard'].strip()
            area = int(row['Residential_Area'].strip())
            dist = float(row['Distance_km'].strip())
            distances[(yard, area)] = dist
    return distances

def load_parameters(data_dir):
    """Load general parameters from general_parameters.csv"""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load parameters and distances
params = load_parameters(data_dir)
distances = load_distances(data_dir)

# Extract parameters
min_supply_A = params['min_coal_yard_A']
min_supply_B = params['min_coal_yard_B_adjusted']
demand_area1 = params['residential_area_1_demand']
demand_area2 = params['residential_area_2_demand']
demand_area3 = params['residential_area_3_demand']
min_share_A_to_area3 = params['min_share_area3_from_A']
staging_threshold_A_to_area3 = params['area3_A_staging_threshold']
excess_cost_A_to_area3 = params['area3_A_excess_staging_cost']

coal_yards = ['A', 'B']
areas = [1, 2, 3]

# Create the Gurobi model
model = gp.Model("Coal_Distribution_Rev")
model.setParam('OutputFlag', 0)  # Suppress output

# Decision variables: amount of coal shipped from yard i to area j
x = {}
for yard in coal_yards:
    for area in areas:
        x[(yard, area)] = model.addVar(name=f"x_{yard}_{area}", lb=0)

# Objective: minimize total transportation cost (distance * amount + extra handling cost for A->3 above threshold)
obj_expr = gp.LinExpr()

# Add normal transportation costs
for yard in coal_yards:
    for area in areas:
        if (yard, area) in distances:
            obj_expr += distances[(yard, area)] * x[(yard, area)]

# Add extra handling cost for A->3 above threshold
# We need a variable for the amount exceeding the threshold
x_A3 = x[('A', 3)]
excess_A3 = model.addVar(lb=0, name="excess_A3")
model.addConstr(excess_A3 >= x_A3 - staging_threshold_A_to_area3, "Excess_A3_Calculation")
obj_expr += excess_cost_A_to_area3 * excess_A3

model.setObjective(obj_expr, GRB.MINIMIZE)

# Constraints:
# 1. Each coal yard must supply at least its minimum requirement
model.addConstr(gp.quicksum(x[('A', area)] for area in areas) >= min_supply_A, "Min_Supply_A")
model.addConstr(gp.quicksum(x[('B', area)] for area in areas) >= min_supply_B, "Min_Supply_B")

# 2. Each residential area must receive exactly its demand
model.addConstr(gp.quicksum(x[(yard, 1)] for yard in coal_yards) == demand_area1, "Demand_Area1")
model.addConstr(gp.quicksum(x[(yard, 2)] for yard in coal_yards) == demand_area2, "Demand_Area2")
model.addConstr(gp.quicksum(x[(yard, 3)] for yard in coal_yards) == demand_area3, "Demand_Area3")

# 3. Minimum share of Area 3 demand from Coal Yard A
model.addConstr(x[('A', 3)] >= min_share_A_to_area3 * demand_area3, "Min_Share_A_to_Area3")

# Optimize the model
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
