import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            params[name] = val
    
    # Extract parameters
    a1_yield = float(params['product_A1_yield'])       # 3 kg per barrel
    a1_time = float(params['product_A1_time'])          # 12 hours per barrel
    a2_yield = float(params['product_A2_yield'])        # 4 kg per barrel
    a2_time = float(params['product_A2_time'])          # 8 hours per barrel
    a3_yield = float(params['product_A3_yield'])        # 2 kg per barrel
    a3_time = float(params['product_A3_time'])          # 10 hours per barrel
    profit_a1 = float(params['profit_per_kg_A1'])       # 24 yuan/kg
    profit_a2 = float(params['profit_per_kg_A2'])       # 16 yuan/kg
    profit_a3 = float(params['profit_per_kg_A3'])       # 30 yuan/kg
    milk_supply = float(params['daily_milk_supply'])     # 50 barrels
    labor_hours = float(params['daily_labor_hours'])     # 480 hours
    cap_A_shared = float(params['cap_A_shared'])         # 90 kg (shared Type A capacity)
    min_A2_kg = float(params['min_A2_kg'])               # 40 kg minimum A2 production
    min_A3_kg = float(params['min_A3_kg'])               # 20 kg minimum A3 production
    type_A_cleaning_loss_if_A3 = float(params['type_A_cleaning_loss_if_A3'])  # 12 kg cleaning loss if A3 is produced
    cold_chain_bonus_threshold_kg = float(params['cold_chain_bonus_threshold_kg'])  # 30 kg threshold for bonus
    cold_chain_bonus_yuan = float(params['cold_chain_bonus_yuan'])  # 300 yuan bonus
    
    # Create model
    model = gp.Model("Dairy_Production_Rev")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x1 = model.addVar(name="x1", lb=0)  # Barrels of milk for A1
    x2 = model.addVar(name="x2", lb=0)  # Barrels of milk for A2
    x3 = model.addVar(name="x3", lb=0)  # Barrels of milk for A3
    
    # Binary variable to indicate if A3 production meets the cold chain bonus threshold
    y = model.addVar(vtype=GRB.BINARY, name="y")
    
    # Objective: maximize total profit including potential cold-chain bonus
    model.setObjective(
        (a1_yield * profit_a1 * x1) + 
        (a2_yield * profit_a2 * x2) + 
        (a3_yield * profit_a3 * x3) + 
        (cold_chain_bonus_yuan * y),
        GRB.MAXIMIZE
    )
    
    # Constraints
    # Milk supply constraint
    model.addConstr(x1 + x2 + x3 <= milk_supply, "Milk_Supply")
    
    # Labor hours constraint
    model.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours, "Labor_Hours")
    
    # Shared Type A equipment capacity constraint
    model.addConstr(a1_yield * x1 + a3_yield * x3 <= cap_A_shared, "Type_A_Shared_Capacity")
    
    # Minimum A2 production constraint
    model.addConstr(a2_yield * x2 >= min_A2_kg, "Min_A2_Production")
    
    # Minimum A3 production constraint
    model.addConstr(a3_yield * x3 >= min_A3_kg, "Min_A3_Production")
    
    # Cleaning loss constraint - if A3 is produced, we need to subtract the cleaning loss from the shared capacity
    model.addConstr(a1_yield * x1 + a3_yield * x3 - type_A_cleaning_loss_if_A3 * y <= cap_A_shared, "Cleaning_Loss")
    
    # Cold chain bonus condition - if A3 production reaches threshold, then y = 1
    model.addConstr(a3_yield * x3 >= cold_chain_bonus_threshold_kg * y, "Cold_Chain_Bonus_Condition")
    
    # Optimize the model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
