import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    total_space = params['mall_total_space']
    rent_pct = params['rent_percentage'] / 100.0
    common_area_factor = params['common_area_factor']
    gm_third_store_concession = params['general_merchandise_third_store_concession']
    catering_threshold = int(params['catering_third_store_security_threshold'])
    catering_cost = params['catering_third_store_security_cost']
    
    # Read store data
    stores = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            stores.append({
                'name': row['Store_Type'].strip(),
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits  # per-store profit when n stores of this type
            })
    
    # Create Gurobi model
    model = gp.Model("ShoppingMallOptimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: number of stores for each type
    x = []
    for i, store in enumerate(stores):
        x_i = model.addVar(vtype=GRB.INTEGER, name=f"x_{i}", lb=store['min'], ub=store['max'])
        x.append(x_i)
    
    # Binary variable to indicate if a third Catering store is opened
    y_catering = model.addVar(vtype=GRB.BINARY, name="y_catering")
    
    # Binary variables to indicate if a third General Merchandise store is opened
    y_gm = model.addVar(vtype=GRB.BINARY, name="y_gm")
    
    # Add constraints
    # Space constraint (with common area factor)
    space_expr = 0
    for i, store in enumerate(stores):
        space_expr += x[i] * store['area']
    model.addConstr(space_expr * common_area_factor <= total_space, "SpaceConstraint")
    
    # Constraint for third Catering store
    model.addConstr(x[4] <= catering_threshold + (3 - catering_threshold) * y_catering, "CateringThirdStoreConstraint")
    
    # Constraint for third General Merchandise store
    model.addConstr(x[2] <= 2 + (3 - 2) * y_gm, "GeneralMerchandiseThirdStoreConstraint")
    
    # Objective function
    profit_expr = 0
    for i, store in enumerate(stores):
        # Use piecewise linear functions for the profit based on the number of stores
        profit_1 = store['profits'].get(1, 0)
        profit_2 = store['profits'].get(2, 0)
        profit_3 = store['profits'].get(3, 0)
        
        # We'll use binary variables to represent which profit level we're using
        y1 = model.addVar(vtype=GRB.BINARY, name=f"y1_{i}")
        y2 = model.addVar(vtype=GRB.BINARY, name=f"y2_{i}")
        y3 = model.addVar(vtype=GRB.BINARY, name=f"y3_{i}")
        
        # Ensure only one profit level is selected
        model.addConstr(y1 + y2 + y3 <= 1, f"OneProfitLevel_{i}")
        
        # Constraints to link the number of stores with the profit levels
        model.addConstr(x[i] >= 1 * y1, f"Min1_{i}")
        model.addConstr(x[i] >= 2 * y2, f"Min2_{i}")
        model.addConstr(x[i] >= 3 * y3, f"Min3_{i}")
        
        # Calculate profit contribution
        profit_expr += y1 * profit_1 + y2 * profit_2 + y3 * profit_3
    
    # Subtract the cost for the third Catering store
    profit_expr -= y_catering * catering_cost
    
    # Subtract the concession for the third General Merchandise store
    profit_expr -= y_gm * gm_third_store_concession
    
    # Total objective is rent income = profit * rent percentage
    model.setObjective(rent_pct * profit_expr, GRB.MAXIMIZE)
    
    # Optimize the model
    model.optimize()
    
    # Print results
    if model.status == GRB.OPTIMAL:
        print("Optimal solution found:")
        for i, store in enumerate(stores):
            print(f"  {store['name']}: {x[i].x} stores")
        print(f"Total rent (objective): {model.objVal}")
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()
