import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    table_2_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_2.csv")
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")

    table_1 = pd.read_csv(table_1_path)
    table_2 = pd.read_csv(table_2_path)
    params = pd.read_csv(params_path)

    # Parse parameters
    min_contract_types = int(params.loc[params['Parameter_Name'] == 'min_contract_types', 'Value'].values[0])
    max_contract_types = int(params.loc[params['Parameter_Name'] == 'max_contract_types', 'Value'].values[0])
    mutual_exclusion = str(params.loc[params['Parameter_Name'] == 'mutual_exclusion_1_and_4', 'Value'].values[0]).strip().lower() == 'true'
    monthly_max_parallel_contracts = int(params.loc[params['Parameter_Name'] == 'monthly_max_parallel_contracts', 'Value'].values[0])
    min_area_per_contract_units = int(params.loc[params['Parameter_Name'] == 'min_area_per_contract_units', 'Value'].values[0])
    activation_fee_per_contract = int(params.loc[params['Parameter_Name'] == 'activation_fee_per_contract', 'Value'].values[0])
    onboarding_loss_units = int(params.loc[params['Parameter_Name'] == 'onboarding_loss_units', 'Value'].values[0])
    expedited_onboarding_fee = int(params.loc[params['Parameter_Name'] == 'expedited_onboarding_fee', 'Value'].values[0])

    # Convert required area to units of 100 ㎡
    demands = {int(row['Month']): float(row['Required_area_㎡']) / 100.0 for _, row in table_1.iterrows()}
    costs = {int(row['Contract_length_months']): float(row['Rental_fee_per_100㎡_yuan']) for _, row in table_2.iterrows()}

    months = list(demands.keys())
    contract_lengths = list(costs.keys())
    max_month = max(months)

    # Initialize model
    model = gp.Model("Warehouse_Rental_Rev")
    model.setParam('OutputFlag', 0)  # Suppress output

    # Decision variables
    # x[i, j] = number of 100 sqm units rented starting at month i for j months
    x = model.addVars(
        [(i, j) for i in months for j in contract_lengths if i + j - 1 <= max_month],
        name="x",
        vtype=GRB.INTEGER,
        lb=0
    )

    # y[j] = 1 if contract length j is used, 0 otherwise
    y = model.addVars(contract_lengths, name="y", vtype=GRB.BINARY)

    # z[i, j] = 1 if the contract starting at month i with length j has expedited onboarding, 0 otherwise
    z = model.addVars(
        [(i, j) for i in months for j in contract_lengths if i + j - 1 <= max_month],
        name="z",
        vtype=GRB.BINARY
    )

    # Objective: Minimize total rental cost
    model.setObjective(
        gp.quicksum((costs[j] * x[i, j]) for (i, j) in x) +
        gp.quicksum(activation_fee_per_contract * x[i, j] for (i, j) in x) +
        gp.quicksum(expedited_onboarding_fee * z[i, j] for (i, j) in z),
        GRB.MINIMIZE
    )

    # Constraints
    # 1. Demand fulfillment for each month
    for m in months:
        lhs = 0
        for (i, j) in x:
            if i <= m and i + j - 1 >= m:
                if i == m:
                    # First month of the contract: apply onboarding loss unless expedited
                    lhs += (x[i, j] * (j - onboarding_loss_units if not z[i, j] else j))
                else:
                    # Not the first month: full area available
                    lhs += x[i, j] * j
        model.addConstr(lhs == demands[m], f"Demand_{m}")

    # 2. Link continuous variables x to binary variables y
    M = sum(demands.values())
    for j in contract_lengths:
        model.addConstr(gp.quicksum(x[i, j] for i in months if (i, j) in x) <= M * y[j], f"Link_y_upper_{j}")
        model.addConstr(gp.quicksum(x[i, j] for i in months if (i, j) in x) >= y[j], f"Link_y_lower_{j}")

    # 3. Contract types limits
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) >= min_contract_types, "Min_Contract_Types")
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) <= max_contract_types, "Max_Contract_Types")

    # 4. Mutual exclusion between 1-month and 4-month contracts
    if mutual_exclusion and 1 in y and 4 in y:
        model.addConstr(y[1] + y[4] <= 1, "Mutual_Exclusion_1_and_4")

    # 5. Minimum area per contract
    for (i, j) in x:
        model.addConstr(x[i, j] >= min_area_per_contract_units * y[j], f"Min_Area_Per_Contract_{i}_{j}")

    # 6. Maximum parallel contracts per month
    for m in months:
        active_contracts = 0
        for (i, j) in x:
            if i <= m and i + j - 1 >= m:
                active_contracts += 1
        model.addConstr(active_contracts <= monthly_max_parallel_contracts, f"Max_Parallel_Contracts_{m}")

    # Optimize the model
    model.optimize()

    # Output the objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
