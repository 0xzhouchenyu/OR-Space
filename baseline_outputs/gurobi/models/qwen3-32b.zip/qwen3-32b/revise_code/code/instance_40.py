import os
import gurobipy as gp
from gurobipy import GRB
import pandas as pd

def solve():
    # Read data
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(csv_path)
    params = dict(zip(df['Parameter_Name'], df['Value']))

    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # Create a new model
    model = gp.Model("Maximize_GDP")

    # Decision variables
    production = {}
    overtime_labor = 0.0
    imports = {}

    for c in commodities:
        # Production level of each commodity
        production[c] = model.addVar(name=f"production_{c}", lb=0, ub=params.get(f"{c}_production_limit", float('inf')))
        
        # Import quantity for each commodity
        imports[c] = model.addVar(name=f"imports_{c}", lb=0, ub=params["import_quota"])

    # Calculate domestic consumption of each commodity
    domestic_consumption = {}
    for c in commodities:
        consumed = 0
        for c_prime in commodities:
            req_key = f"{c_prime}_{c}_requirement"
            if req_key in params:
                consumed += params[req_key] * production[c_prime]
        domestic_consumption[c] = consumed

    # Net exports (Production - Domestic Consumption)
    net_exports = {c: production[c] - domestic_consumption[c] for c in commodities}

    # Objective function: GDP = Export revenue - Import costs
    gdp = 0
    
    # Export revenue
    for c in commodities:
        gdp += params[f"{c}_price"] * gp.max_(net_exports[c], 0)  # Only positive exports contribute to revenue
    
    # Import costs (imported goods + cost of imported finished commodities)
    for c in commodities:
        # Cost of other imported goods required for production
        import_cost_key = f"{c}_import_cost"
        if import_cost_key in params:
            gdp -= params[import_cost_key] * production[c]
        
        # Cost of importing finished commodities
        gdp -= params[f"{c}_price"] * params["import_premium_ratio"] * imports[c]

    # Labor cost
    labor_cost = 0
    total_labor = 0
    for c in commodities:
        labor_req_key = f"{c}_labor_requirement"
        if labor_req_key in params:
            total_labor += params[labor_req_key] * production[c]
    
    # Regular labor cost is implicit (assumed to be included in production cost)
    # Overtime labor cost
    overtime_labor = gp.max_(total_labor - params["labor_force"], 0)
    gdp -= overtime_labor * params["overtime_wage"]

    model.setObjective(gdp, GRB.MAXIMIZE)

    # Constraints
    # 1. Net export >= 0 or imports must cover any negative net export
    for c in commodities:
        model.addConstr(production[c] + imports[c] >= domestic_consumption[c], name=f"Domestic_Demand_{c}")

    # 2. Overtime labor constraint
    model.addConstr(overtime_labor <= params["overtime_cap"], name="Overtime_Limit")

    # Optimize the model
    model.setParam('OutputFlag', 0)
    model.optimize()

    if model.status == GRB.OPTIMAL:
        return model.ObjVal
    else:
        return None

if __name__ == '__main__':
    result = solve()
    if result is not None:
        print(f"FINAL_OBJ_VALUE: {round(result, 3)}")
    else:
        print("FINAL_OBJ_VALUE: None")
