import os
import csv

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Strip whitespace from keys and values
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data

def main():
    # Define paths to data files
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load data
    products_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    
    products = load_csv_data(products_path)
    params_raw = load_csv_data(params_path)
    
    # Parse general parameters
    params = {}
    for row in params_raw:
        params[row['Parameter_Name']] = float(row['Value'])
    
    max_grains = params['max_grains']
    price_grains = params['price_per_lb_grains']
    max_meat = params['max_meat']
    price_meat = params['price_per_lb_meat']
    line_fixed_cost = params['line_fixed_cost']
    line_capacity_packs = params['line_capacity_packs']
    min_batch_packs = params['min_batch_packs']
    min_yummies = params['min_yummies']
    retailer_rebate_yummies_threshold = params['retailer_rebate_yummies_threshold']
    retailer_rebate_min_meaties = params['retailer_rebate_min_meaties']
    retailer_rebate_fixed = params['retailer_rebate_fixed']
    
    # Parse product data
    product_data = {}
    for row in products:
        name = row['Product']
        product_data[name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'variable_cost': float(row['Variable_cost_per_pack']),
            'capacity': float(row['Production_capacity']) if row['Production_capacity'].strip() else None
        }
    
    m = product_data['Meaties']
    y = product_data['Yummies']
    
    # Calculate profit per pack (excluding fixed costs and rebates for now)
    profit_meaties = m['price'] - m['variable_cost'] - (m['grains'] * price_grains + m['meat'] * price_meat)
    profit_yummies = y['price'] - y['variable_cost'] - (y['grains'] * price_grains + y['meat'] * price_meat)
    
    # Create Gurobi model
    import gurobipy as gp
    from gurobipy import GRB
    
    model = gp.Model("HealthyPetFoods")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x_meaties = model.addVar(name="Meaties", lb=0, vtype=GRB.CONTINUOUS)
    x_yummies = model.addVar(name="Yummies", lb=0, vtype=GRB.CONTINUOUS)
    
    # Binary variable for whether the co-packing line is used
    use_line = model.addVar(vtype=GRB.BINARY, name="UseLine")
    
    # Binary variable for whether the rebate is earned
    earn_rebate = model.addVar(vtype=GRB.BINARY, name="EarnRebate")
    
    # Add constraints
    
    # Grains availability constraint
    model.addConstr(m['grains'] * x_meaties + y['grains'] * x_yummies <= max_grains, "GrainsConstraint")
    
    # Meat availability constraint
    model.addConstr(m['meat'] * x_meaties + y['meat'] * x_yummies <= max_meat, "MeatConstraint")
    
    # Production capacity for Meaties
    if m['capacity'] is not None:
        model.addConstr(x_meaties <= m['capacity'], "MeatiesCapacity")
    
    # Line usage constraints
    # If any production occurs, the line must be used
    model.addConstr((x_meaties + x_yummies) >= 1e-6 - (1 - use_line) * GRB.INFINITY, "MinBatchConstraint")
    
    # Total monthly throughput limit on the shared co-packing line when active
    model.addConstr(x_meaties + x_yummies <= line_capacity_packs * use_line, "LineCapacityConstraint")
    
    # Minimum combined production if line is active
    model.addConstr(x_meaties + x_yummies >= min_batch_packs * use_line, "MinBatchSizeConstraint")
    
    # Contractual minimum monthly Yummies production if line is active
    model.addConstr(x_yummies >= min_yummies * use_line, "MinYummiesConstraint")
    
    # Rebate eligibility constraints
    # Yummies threshold
    model.addConstr(x_yummies >= retailer_rebate_yummies_threshold * earn_rebate, "YummiesThresholdConstraint")
    
    # Meaties threshold
    model.addConstr(x_meaties >= retailer_rebate_min_meaties * earn_rebate, "MeatiesThresholdConstraint")
    
    # Objective function
    total_profit = profit_meaties * x_meaties + profit_yummies * x_yummies
    
    # Subtract fixed cost if line is used
    total_profit -= line_fixed_cost * use_line
    
    # Add rebate if eligible
    total_profit += retailer_rebate_fixed * earn_rebate
    
    model.setObjective(total_profit, GRB.MAXIMIZE)
    
    # Optimize the model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
