import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Extract parameters
produce_to_transport = params["produce_to_transport"]
horse_pollution_per_trip = params["horse_pollution_per_trip"]
bicycle_pollution_per_trip = params["bicycle_pollution_per_trip"]
handcart_pollution_per_trip = params["handcart_pollution_per_trip"]
max_total_pollution = params["max_total_pollution"]
min_horse_trips = params["min_horse_trips"]
horse_capacity_per_trip = params["horse_capacity_per_trip"]
bicycle_capacity_per_trip = params["bicycle_capacity_per_trip"]
handcart_capacity_per_trip = params["handcart_capacity_per_trip"]
min_total_produce = params["min_total_produce"]
horse_cost_per_trip = params["horse_cost_per_trip"]
bicycle_cost_per_trip = params["bicycle_cost_per_trip"]
handcart_cost_per_trip = params["handcart_cost_per_trip"]
horse_fixed_cost = params["horse_fixed_cost"]
bicycle_fixed_cost = params["bicycle_fixed_cost"]
handcart_fixed_cost = params["handcart_fixed_cost"]
pollution_penalty_per_unit = params["pollution_penalty_per_unit"]
horse_pollution_permit_threshold = params["horse_pollution_permit_threshold"]
horse_pollution_permit_fee = params["horse_pollution_permit_fee"]

# Create model
model = gp.Model("FarmTransport")
model.setParam('OutputFlag', 0)  # Suppress output

# Decision variables
x_horse = model.addVar(vtype=GRB.INTEGER, name="horse_trips", lb=0)
x_bike = model.addVar(vtype=GRB.INTEGER, name="bike_trips", lb=0)
x_cart = model.addVar(vtype=GRB.INTEGER, name="cart_trips", lb=0)

# Binary variable: y=1 means bicycle chosen, y=0 means handcart chosen
y = model.addVar(vtype=GRB.BINARY, name="choose_bike")

# Binary variable to indicate if pollution exceeds threshold (600 units)
z = model.addVar(vtype=GRB.BINARY, name="exceeds_pollution_threshold")

M = 10000  # Big-M value

# Objective function: minimize total cost
# Total cost includes:
# - Fixed costs for using each transportation method
# - Variable costs per trip
# - Pollution penalty per unit of pollution
# - One-time permit fee if pollution exceeds threshold
model.setObjective(
    horse_fixed_cost * gp.quicksum(1 for _ in range(1)) * (x_horse > 0) +
    bicycle_fixed_cost * y +
    handcart_fixed_cost * (1 - y) +
    horse_cost_per_trip * x_horse +
    bicycle_cost_per_trip * x_bike +
    handcart_cost_per_trip * x_cart +
    pollution_penalty_per_unit * (
        horse_pollution_per_trip * x_horse +
        bicycle_pollution_per_trip * x_bike +
        handcart_pollution_per_trip * x_cart
    ) +
    horse_pollution_permit_fee * z,
    GRB.MINIMIZE
)

# Constraints
# Must transport at least min_total_produce
model.addConstr(
    horse_capacity_per_trip * x_horse + 
    bicycle_capacity_per_trip * x_bike + 
    handcart_capacity_per_trip * x_cart >= min_total_produce,
    "MinProduce"
)

# Pollution constraint: total pollution must not exceed max_total_pollution
model.addConstr(
    horse_pollution_per_trip * x_horse + 
    bicycle_pollution_per_trip * x_bike + 
    handcart_pollution_per_trip * x_cart <= max_total_pollution,
    "MaxPollution"
)

# Minimum horse trips
model.addConstr(x_horse >= min_horse_trips, "MinHorseTrips")

# Either bicycle or handcart, not both
model.addConstr(x_bike <= M * y, "BikeChoice")
model.addConstr(x_cart <= M * (1 - y), "CartChoice")

# Pollution threshold constraint: if total pollution > 600, then z = 1
model.addConstr(
    horse_pollution_per_trip * x_horse + 
    bicycle_pollution_per_trip * x_bike + 
    handcart_pollution_per_trip * x_cart <= horse_pollution_permit_threshold + M * z,
    "PollutionThresholdUpper"
)
model.addConstr(
    horse_pollution_per_trip * x_horse + 
    bicycle_pollution_per_trip * x_bike + 
    handcart_pollution_per_trip * x_cart >= horse_pollution_permit_threshold + 1 - M * (1 - z),
    "PollutionThresholdLower"
)

# Optimize the model
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
