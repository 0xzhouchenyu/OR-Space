import os
import csv
from gurobipy import GRB, Model

def load_table1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in ['Product_I', 'Product_II', 'Product_III']:
                val = row[p].strip() if row[p].strip() else None
                proc_times[e][p] = float(val) if val else None
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())
    
    return equipment, proc_times, eff_hours, op_costs

def load_general_params(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    raw_costs = {}
    prices = {}
    labor_coeff = {}
    shared_labor_hours = 0
    b2_activation_fee = 0
    
    mapping_raw = {
        'raw_material_cost_product_I': 'Product_I',
        'raw_material_cost_product_II': 'Product_II',
        'raw_material_cost_product_III': 'Product_III',
    }
    mapping_price = {
        'unit_price_product_I': 'Product_I',
        'unit_price_product_II': 'Product_II',
        'unit_price_product_III': 'Product_III',
    }
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            if name in mapping_raw:
                raw_costs[mapping_raw[name]] = val
            if name in mapping_price:
                prices[mapping_price[name]] = val
            if name == 'shared_labor_hours':
                shared_labor_hours = val
            if name.startswith('labor_coeff_'):
                equip = name.split('_')[2]
                labor_coeff[equip] = val
            if name == 'b2_activation_fee':
                b2_activation_fee = val
    
    return raw_costs, prices, labor_coeff, shared_labor_hours, b2_activation_fee

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    equipment, proc_times, eff_hours, op_costs = load_table1(data_dir)
    raw_costs, prices, labor_coeff, shared_labor_hours, b2_activation_fee = load_general_params(data_dir)
    
    products = ['Product_I', 'Product_II', 'Product_III']
    A_equip = [e for e in equipment if e.startswith('A')]
    B_equip = [e for e in equipment if e.startswith('B')]
    
    model = Model("Factory_Production")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}  # x[e][p]: number of units of product p processed on equipment e
    y_B2 = model.addVar(vtype=GRB.BINARY, name="y_B2")  # Binary variable indicating whether B2 is used
    
    for e in equipment:
        x[e] = {}
        for p in products:
            if proc_times[e][p] is not None:
                x[e][p] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")
    
    # Capacity constraints: total processing time <= effective machine hours
    for e in equipment:
        model.addConstr(
            sum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None) <= eff_hours[e],
            f"capacity_{e}"
        )
    
    # Flow balance: for each product, total A-processed = total B-processed
    for p in products:
        a_sum = sum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
        b_sum = sum(x[e][p] for e in B_equip if proc_times[e][p] is not None)
        model.addConstr(a_sum == b_sum, f"balance_{p}")
    
    # Shared labor constraint
    labor_used = 0
    for e in equipment:
        if e in labor_coeff:
            labor_used += labor_coeff[e] * sum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None)
    model.addConstr(labor_used <= shared_labor_hours, "shared_labor")
    
    # B2 activation fee constraint
    for p in products:
        if proc_times["B2"][p] is not None:
            model.addConstr(x["B2"][p] <= 1000000 * y_B2, f"B2_usage_{p}")  # Big-M constraint to enforce binary trigger
    
    # Total production of each product
    total_prod = {p: sum(x[e][p] for e in A_equip if proc_times[e][p] is not None) for p in products}
    
    # Revenue
    revenue = sum(prices[p] * total_prod[p] for p in products)
    
    # Raw material costs
    raw_cost_total = sum(raw_costs[p] * total_prod[p] for p in products)
    
    # Operating costs: proportional to usage fraction
    operating_cost = sum(
        (op_costs[e] / eff_hours[e]) * sum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None)
        for e in equipment
    )
    
    # B2 activation fee
    activation_cost = b2_activation_fee * y_B2
    
    # Objective: maximize profit
    model.setObjective(revenue - raw_cost_total - operating_cost - activation_cost, GRB.MAXIMIZE)
    
    model.optimize()
    
    obj_val = model.ObjVal
    
    print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")

if __name__ == "__main__":
    main()
