import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load demand data from table_1.csv
    demand = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.reader(f)
        header = next(reader)
        quarters = [int(h) for h in header[1:]]
        for row in reader:
            product = row[0].strip()
            for j, q in enumerate(quarters):
                demand[(product, q)] = int(row[j+1])
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"])
    
    products = ["I", "II", "III"]
    quarters = [1, 2, 3, 4]
    
    init_inv = params["initial_inventory"]
    end_inv_req = params["end_inventory_requirement"]
    hours_per_quarter = params["production_hours_per_quarter"]
    hours_per_unit = {
        "I": params["product_I_hours_per_unit"],
        "II": params["product_II_hours_per_unit"],
        "III": params["product_III_hours_per_unit"]
    }
    delay_penalty = {
        "I": params["delay_penalty_product_I"],
        "II": params["delay_penalty_product_II"],
        "III": params["delay_penalty_product_III"]
    }
    inv_cost = params["inventory_cost_per_unit"]
    
    normal_hours_cap_fraction = {
        1: params["normal_hours_cap_fraction_q1"],
        2: params["normal_hours_cap_fraction_q2"],
        3: params["normal_hours_cap_fraction_q3"],
        4: params["normal_hours_cap_fraction_q4"]
    }
    
    peak_hours_cap = {
        1: params["peak_hours_cap_q1"],
        2: params["peak_hours_cap_q2"],
        3: params["peak_hours_cap_q3"],
        4: params["peak_hours_cap_q4"]
    }
    
    peak_cost_per_hour = {
        1: params["peak_cost_per_hour_q1"],
        2: params["peak_cost_per_hour_q2"],
        3: params["peak_cost_per_hour_q3"],
        4: params["peak_cost_per_hour_q4"]
    }
    
    # Create Gurobi model
    model = gp.Model("ProductionScheduling")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    # Production quantities (units produced per product and quarter)
    x = model.addVars(products, quarters, name="x", vtype=GRB.INTEGER, lb=0)
    
    # Product I cannot be produced in Q2
    x["I", 2].ub = 0
    
    # Inventory levels (can be positive or negative)
    inv = model.addVars(products, quarters, name="inv")
    
    # Split inventory into positive and negative parts for cost calculation
    inv_pos = model.addVars(products, quarters, name="inv_pos", vtype=GRB.CONTINUOUS, lb=0)
    inv_neg = model.addVars(products, quarters, name="inv_neg", vtype=GRB.CONTINUOUS, lb=0)
    
    # Hours used in normal and peak bands for each product and quarter
    normal_hours = model.addVars(products, quarters, name="normal_hours", vtype=GRB.CONTINUOUS, lb=0)
    peak_hours = model.addVars(products, quarters, name="peak_hours", vtype=GRB.CONTINUOUS, lb=0)
    
    # Total hours used by product and quarter
    total_hours = model.addVars(products, quarters, name="total_hours", vtype=GRB.CONTINUOUS, lb=0)
    
    # Inventory balance constraints
    for p in products:
        # Quarter 1
        model.addConstr(inv[p, 1] == init_inv + x[p, 1] - demand[p, 1], f"Inv_Balance_{p}_Q1")
        
        # Quarters 2-4
        for t in range(2, 5):
            model.addConstr(inv[p, t] == inv[p, t-1] + x[p, t] - demand[p, t], f"Inv_Balance_{p}_Q{t}")
    
    # Split inventory into positive and negative parts
    for p in products:
        for t in quarters:
            model.addConstr(inv[p, t] == inv_pos[p, t] - inv_neg[p, t], f"Inv_Split_{p}_Q{t}")
    
    # End of Q4: inventory must be at least end_inv_req
    for p in products:
        model.addConstr(inv[p, 4] >= end_inv_req, f"End_Inventory_{p}")
    
    # Total hours used by product and quarter
    for p in products:
        for t in quarters:
            model.addConstr(total_hours[p, t] == hours_per_unit[p] * x[p, t], f"Total_Hours_{p}_Q{t}")
    
    # Normal and peak hours allocation
    for t in quarters:
        normal_hours_total = sum(normal_hours[p, t] for p in products)
        peak_hours_total = sum(peak_hours[p, t] for p in products)
        
        # Normal hours cap is a fraction of the total available hours
        model.addConstr(normal_hours_total <= normal_hours_cap_fraction[t] * hours_per_quarter, f"Normal_Hours_Cap_Q{t}")
        
        # Peak hours have an absolute cap
        model.addConstr(peak_hours_total <= peak_hours_cap[t], f"Peak_Hours_Cap_Q{t}")
        
        # Total hours used equals normal + peak hours
        for p in products:
            model.addConstr(normal_hours[p, t] + peak_hours[p, t] == total_hours[p, t], f"Hours_Allocation_{p}_Q{t}")
    
    # Objective function: minimize delay penalties + inventory holding costs + peak hour costs
    obj = (
        gp.quicksum(delay_penalty[p] * inv_neg[p, t] for p in products for t in quarters) +
        gp.quicksum(inv_cost * inv_pos[p, t] for p in products for t in quarters) +
        gp.quicksum(peak_cost_per_hour[t] * peak_hours[p, t] for p in products for t in quarters)
    )
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Optimize the model
    model.optimize()
    
    # Output the objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
