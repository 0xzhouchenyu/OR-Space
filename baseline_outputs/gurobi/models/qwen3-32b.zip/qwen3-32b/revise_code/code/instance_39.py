import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add parent directory to path if needed
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(script_dir, "data")
params_file = os.path.join(data_dir, "general_parameters.csv")
params = load_general_parameters(params_file)

# Extract parameters
motorcycle_pollution = params['motorcycle_pollution']
small_truck_pollution = params['small_truck_pollution']
large_truck_pollution = params['large_truck_pollution']
max_motorcycle_trips = int(params['max_motorcycle_trips'])
motorcycle_capacity = params['motorcycle_capacity']
small_truck_capacity = params['small_truck_capacity']
large_truck_capacity = params['large_truck_capacity']
demand_peak_units = params['demand_peak_units']
demand_offpeak_units = params['demand_offpeak_units']
leasing_capacity = params['leasing_capacity']
leasing_pollution_per_unit = params['leasing_pollution_per_unit']
leasing_fixed_pollution = params['leasing_fixed_pollution']
max_leasing_fraction_peak = params['max_leasing_fraction_peak']
bigM_leasing = params['bigM_leasing']
epsilon = params['epsilon']
max_total_trips = int(params['max_total_trips'])

# Define transportation methods
methods = ['motorcycle', 'small_truck', 'large_truck']

# Generate all combinations of 2 out of the 3 methods
from itertools import combinations
method_combinations = list(combinations(methods, 2))

best_obj = float('inf')
best_solution = None
best_combo = None

for combo in method_combinations:
    # Create a new model
    model = gp.Model("Transport_Optimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: number of trips for each method (integer, non-negative)
    trips_peak = {m: model.addVar(vtype=GRB.INTEGER, lb=0, name=f"trips_peak_{m}") for m in combo}
    trips_offpeak = {m: model.addVar(vtype=GRB.INTEGER, lb=0, name=f"trips_offpeak_{m}") for m in combo}
    
    # Leasing variables
    leasing_peak = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=demand_peak_units * max_leasing_fraction_peak, name="leasing_peak")
    leasing_offpeak = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=demand_offpeak_units, name="leasing_offpeak")
    leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")
    
    # Total leasing
    total_leasing = leasing_peak + leasing_offpeak
    
    # Objective: minimize total pollution
    owned_pollution = (
        sum(motorcycle_pollution * (trips_peak['motorcycle'] + trips_offpeak['motorcycle']) for m in combo if m == 'motorcycle') +
        sum(small_truck_pollution * (trips_peak['small_truck'] + trips_offpeak['small_truck']) for m in combo if m == 'small_truck') +
        sum(large_truck_pollution * (trips_peak['large_truck'] + trips_offpeak['large_truck']) for m in combo if m == 'large_truck')
    )
    
    leasing_pollution = leasing_pollution_per_unit * total_leasing + leasing_fixed_pollution * leasing_used
    
    model.setObjective(owned_pollution + leasing_pollution, GRB.MINIMIZE)
    
    # Constraints
    
    # 1. Peak period demand constraint
    peak_capacity = sum(
        (trips_peak[m] * locals()[f"{m}_capacity"] for m in combo)
    )
    model.addConstr(peak_capacity + leasing_peak >= demand_peak_units, "peak_demand")
    
    # 2. Off-peak period demand constraint
    offpeak_capacity = sum(
        (trips_offpeak[m] * locals()[f"{m}_capacity"] for m in combo)
    )
    model.addConstr(offpeak_capacity + leasing_offpeak >= demand_offpeak_units, "offpeak_demand")
    
    # 3. Maximum total trips constraint
    total_trips = sum(trips_peak[m] + trips_offpeak[m] for m in combo)
    model.addConstr(total_trips <= max_total_trips, "total_trips_limit")
    
    # 4. Motorcycle trip limit
    if 'motorcycle' in combo:
        model.addConstr(trips_peak['motorcycle'] + trips_offpeak['motorcycle'] <= max_motorcycle_trips, "motorcycle_trip_limit")
    
    # 5. Leasing capacity constraint
    model.addConstr(total_leasing <= leasing_capacity, "leasing_capacity")
    
    # 6. Leasing activation constraints
    model.addConstr(total_leasing <= bigM_leasing * leasing_used, "leasing_activation_upper")
    model.addConstr(total_leasing >= epsilon * leasing_used, "leasing_activation_lower")
    
    # Optimize the model
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        if obj_val < best_obj:
            best_obj = obj_val
            best_solution = {
                'trips_peak': {m: trips_peak[m].x for m in combo},
                'trips_offpeak': {m: trips_offpeak[m].x for m in combo},
                'leasing_peak': leasing_peak.x,
                'leasing_offpeak': leasing_offpeak.x,
                'leasing_used': leasing_used.x
            }
            best_combo = combo

# Print final objective value
print(f"FINAL_OBJ_VALUE: {best_obj}")
