import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    product_units = params['product_units']
    truck_pollution = params['truck_pollution']
    van_pollution = params['van_pollution']
    motorcycle_pollution = params['motorcycle_pollution']
    ev_pollution = params['electric_vehicle_pollution']
    max_total_pollution = params['max_total_pollution']
    min_truck_trips = params['min_truck_trips']
    truck_capacity = params['truck_capacity']
    van_capacity = params['van_capacity']
    motorcycle_capacity = params['motorcycle_capacity']
    ev_capacity = params['electric_vehicle_capacity']
    sales_point_share_sp1 = params['sales_point_share_sp1']
    sales_point_share_sp2 = params['sales_point_share_sp2']
    sales_point_share_sp3 = params['sales_point_share_sp3']
    min_truck_share_sp1 = params['min_truck_share_sp1']
    min_truck_share_sp2 = params['min_truck_share_sp2']
    min_truck_share_sp3 = params['min_truck_share_sp3']
    M_truck_sp_day = params['M_truck_sp_day']
    M_ev_sp_day = params['M_ev_sp_day']
    M_van_sp_day = params['M_van_sp_day']
    M_moto_sp_day = params['M_moto_sp_day']
    
    # Calculate demand per sales point
    sp1_demand = product_units * sales_point_share_sp1
    sp2_demand = product_units * sales_point_share_sp2
    sp3_demand = product_units * sales_point_share_sp3
    
    # Create model
    model = gp.Model("Transportation_Pollution_Minimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Define sets
    sales_points = ['sp1', 'sp2', 'sp3']
    days = [1, 2, 3]
    vehicle_families = {
        'truck': {'pollution': truck_pollution, 'capacity': truck_capacity},
        'ev': {'pollution': ev_pollution, 'capacity': ev_capacity},
        'van': {'pollution': van_pollution, 'capacity': van_capacity},
        'moto': {'pollution': motorcycle_pollution, 'capacity': motorcycle_capacity}
    }
    
    # Decision variables: number of trips for each vehicle type at each sales point and day
    trips = {}
    for sp in sales_points:
        for d in days:
            for v in vehicle_families:
                trips[(sp, d, v)] = model.addVar(vtype=GRB.INTEGER, name=f"trips_{sp}_day{d}_{v}")
    
    # Binary variables to enforce the exclusive delivery family constraint
    is_truck_ev_family = {}
    for sp in sales_points:
        for d in days:
            is_truck_ev_family[(sp, d)] = model.addVar(vtype=GRB.BINARY, name=f"is_truck_ev_family_{sp}_day{d}")
    
    # Objective: minimize total pollution
    obj = gp.LinExpr(0)
    for sp in sales_points:
        for d in days:
            for v in vehicle_families:
                obj += vehicle_families[v]['pollution'] * trips[(sp, d, v)]
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraint: all products must be delivered for each sales point
    for sp in sales_points:
        expr = gp.LinExpr(0)
        for d in days:
            for v in vehicle_families:
                expr += vehicle_families[v]['capacity'] * trips[(sp, d, v)]
        model.addConstr(expr == eval(f'sp{sales_points.index(sp)+1}_demand'), name=f"Demand_{sp}")
    
    # Constraint: minimum total number of truck trips across all sales points and days
    total_truck_trips = gp.LinExpr(0)
    for sp in sales_points:
        for d in days:
            total_truck_trips += trips[(sp, d, 'truck')]
    model.addConstr(total_truck_trips >= min_truck_trips, name="Min_Truck_Trips")
    
    # Constraint: total pollution must not exceed maximum
    total_pollution = gp.LinExpr(0)
    for sp in sales_points:
        for d in days:
            for v in vehicle_families:
                total_pollution += vehicle_families[v]['pollution'] * trips[(sp, d, v)]
    model.addConstr(total_pollution <= max_total_pollution, name="Max_Pollution")
    
    # Constraint: on a given sales point-day, deliveries must come from either the truck/ev family or the van/moto family
    for sp in sales_points:
        for d in days:
            # If using truck/ev family, then no van/moto trips
            model.addConstr(trips[(sp, d, 'van')] <= (1 - is_truck_ev_family[(sp, d)]) * M_van_sp_day, 
                            name=f"Van_Moto_Exclusion_{sp}_day{d}_1")
            model.addConstr(trips[(sp, d, 'moto')] <= (1 - is_truck_ev_family[(sp, d)]) * M_moto_sp_day, 
                            name=f"Van_Moto_Exclusion_{sp}_day{d}_2")
            
            # If using van/moto family, then no truck/ev trips
            model.addConstr(trips[(sp, d, 'truck')] <= is_truck_ev_family[(sp, d)] * M_truck_sp_day, 
                            name=f"Truck_EV_Exclusion_{sp}_day{d}_1")
            model.addConstr(trips[(sp, d, 'ev')] <= is_truck_ev_family[(sp, d)] * M_ev_sp_day, 
                            name=f"Truck_EV_Exclusion_{sp}_day{d}_2")
    
    # Constraint: minimum fraction of trips that must be truck trips for each sales point
    for sp in sales_points:
        min_truck_share = eval(f'min_truck_share_{sp}')
        total_trips = gp.LinExpr(0)
        for d in days:
            for v in vehicle_families:
                total_trips += trips[(sp, d, v)]
        
        total_truck_trips = gp.LinExpr(0)
        for d in days:
            total_truck_trips += trips[(sp, d, 'truck')]
        
        model.addConstr(total_truck_trips >= min_truck_share * total_trips, name=f"Min_Truck_Share_{sp}")
    
    # Optimize the model
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
