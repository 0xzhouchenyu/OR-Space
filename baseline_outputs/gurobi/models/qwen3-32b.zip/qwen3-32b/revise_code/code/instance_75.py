import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters from CSV file
def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Main optimization script
if __name__ == "__main__":
    # Get the directory of the current script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Load general parameters
    general_params_path = os.path.join(data_dir, "general_parameters.csv")
    params = load_parameters(general_params_path)

    # Extract parameters
    a_p1 = params['product_a_process_1_time']
    a_p2 = params['product_a_process_2_time']
    b_p1 = params['product_b_process_1_time']
    b_p2 = params['product_b_process_2_time']
    T1_normal = params['available_time_process_1']
    T2_normal = params['available_time_process_2']
    T1_high = params['available_time_process_1_high']
    T2_high = params['available_time_process_2_high']
    c_per_b = params['byproduct_c_per_unit_b']
    max_c_sales = params['max_byproduct_c_sales']
    threshold_c = params['threshold_c']
    bigM_disposal = params['bigM_disposal']
    disposal_cost_base = params['disposal_cost_per_unit_c']
    disposal_cost_high = params['disposal_cost_per_unit_c_high']
    profit_a = params['profit_per_unit_a']
    profit_b = params['profit_per_unit_b']
    profit_c = params['profit_per_unit_c']

    # Create model
    model = gp.Model("MaxProfit")

    # Decision variables
    xA = model.addVar(name="xA", lb=0)  # units of product A
    xB = model.addVar(name="xB", lb=0)  # units of product B
    cSold = model.addVar(name="cSold", lb=0, ub=max_c_sales)  # units of by-product C sold
    cDisposed = model.addVar(name="cDisposed", lb=0, ub=bigM_disposal)  # units of by-product C disposed
    
    # Binary variable to indicate if process 1 is in high-throughput mode (1) or normal mode (0)
    y1 = model.addVar(vtype=GRB.BINARY, name="y1")
    # Binary variable to indicate if process 2 is in high-throughput mode (1) or normal mode (0)
    y2 = model.addVar(vtype=GRB.BINARY, name="y2")
    # At most one reaction stage may use the high-throughput setting
    model.addConstr(y1 + y2 <= 1, name="HighThroughputLimit")

    # Objective: maximize total profit
    # Profit from A + Profit from B + Profit from selling C - Cost of disposing C
    model.setObjective(
        profit_a * xA + profit_b * xB + profit_c * cSold 
        - (disposal_cost_base * threshold_c + disposal_cost_high * (cDisposed - threshold_c)), 
        GRB.MAXIMIZE
    )

    # Process 1 time constraint using high-throughput or normal mode
    model.addConstr(a_p1 * xA + b_p1 * xB <= T1_normal + (T1_high - T1_normal) * y1, name="Process1Time")

    # Process 2 time constraint using high-throughput or normal mode
    model.addConstr(a_p2 * xA + b_p2 * xB <= T2_normal + (T2_high - T2_normal) * y2, name="Process2Time")

    # By-product C balance: total C produced = C sold + C disposed
    model.addConstr(cSold + cDisposed == c_per_b * xB, name="ByproductBalance")

    # Constraint to handle the stepwise cost of disposal
    # If cDisposed <= threshold_c, then all disposal is at base cost
    # If cDisposed > threshold_c, then threshold_c units are at base cost and the rest at higher cost
    model.addConstr(cDisposed >= threshold_c + 1e-6, name="DisposalThresholdConstraint")  # To avoid division by zero

    # Solve the model
    model.setParam('OutputFlag', 0)
    model.optimize()

    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
