import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add parent directory to path if needed
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

# Load data
def load_table_1(data_dir):
    """Load the weekly demand, capacity, and cost data."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    weeks = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })
    return weeks

def load_general_parameters(data_dir):
    """Load general parameters."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

# Load data from files
data_dir = os.path.join(script_dir, "data")
weeks_data = load_table_1(data_dir)
params = load_general_parameters(data_dir)

storage_cost = params['storage_cost_per_thousand_boxes']
fixed_setup_cost = params['fixed_setup_cost']
week2_push_threshold = params['week2_push_threshold']
week3_capacity_loss_after_week2_push = params['week3_capacity_loss_after_week2_push']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']

n_weeks = len(weeks_data)

# Create a new model
model = gp.Model("Beverage_Production_Planning")

# Decision variables
# x[t] = production in week t (in thousand boxes)
x = model.addVars(n_weeks, name="x", lb=0, ub=[w['capacity'] for w in weeks_data])
# s[t] = inventory at end of week t (in thousand boxes)
s = model.addVars(n_weeks, name="s", lb=0)
# y[t] = binary variable indicating whether production occurs in week t
y = model.addVars(n_weeks, vtype=GRB.BINARY, name="y")
# z = binary variable indicating whether Week 2 production exceeds micro-clean threshold
z = model.addVar(vtype=GRB.BINARY, name="z_week2")
# w = binary variable indicating whether Week 2 production exceeds push threshold
w = model.addVar(vtype=GRB.BINARY, name="w_week2")

# Objective: minimize total cost
model.setObjective(
    gp.quicksum(weeks_data[t]['cost'] * x[t] for t in range(n_weeks)) +
    gp.quicksum(storage_cost * s[t] for t in range(n_weeks)) +
    gp.quicksum(fixed_setup_cost * y[t] for t in range(n_weeks)) +
    week2_microclean_fee * z +
    0 * w,  # No cost associated with w, but it affects capacity constraint
    GRB.MINIMIZE
)

# Constraints: inventory balance
# Assume initial inventory is 0
for t in range(n_weeks):
    if t == 0:
        model.addConstr(x[t] - s[t] == weeks_data[t]['demand'], f"balance_week_{t+1}")
    else:
        model.addConstr(s[t-1] + x[t] - s[t] == weeks_data[t]['demand'], f"balance_week_{t+1}")

# Production setup constraints
for t in range(n_weeks):
    model.addConstr(x[t] <= weeks_data[t]['capacity'] * y[t], f"setup_constr_week_{t+1}")
    model.addConstr(x[t] >= 0.001 * y[t], f"min_production_week_{t+1}")  # Small epsilon to ensure production if y[t]=1

# Week 2 micro-clean constraint
model.addConstr(x[1] <= week2_microclean_threshold + (weeks_data[1]['capacity'] - week2_microclean_threshold) * z, "microclean_constr_week2")
model.addConstr(x[1] >= week2_microclean_threshold * z + 0.001 * (1 - z), "microclean_constr_week2_lower")

# Week 2 push threshold constraint
model.addConstr(x[1] <= week2_push_threshold + (weeks_data[1]['capacity'] - week2_push_threshold) * w, "push_threshold_constr_week2")
model.addConstr(x[1] >= week2_push_threshold * w + 0.001 * (1 - w), "push_threshold_constr_week2_lower")

# Week 3 capacity reduction constraint if Week 2 production exceeds push threshold
model.addConstr(x[2] <= weeks_data[2]['capacity'] - week3_capacity_loss_after_week2_push * w, "capacity_reduction_week3")

# Optimize model
model.setParam('OutputFlag', 0)
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
