import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load container data
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    # Load general parameters
    fixed_setup_cost = None
    energy_cost_per_kwh = None
    max_total_energy_kwh = None
    eco_capacity_share = None
    eco_overhead_cost = None
    regular_energy_intensity = None
    eco_energy_intensity = None

    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'].strip() == 'fixed_setup_cost':
                fixed_setup_cost = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'energy_cost_per_kwh':
                energy_cost_per_kwh = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'max_total_energy_kwh':
                max_total_energy_kwh = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'eco_capacity_share':
                eco_capacity_share = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'eco_overhead_cost':
                eco_overhead_cost = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'regular_energy_intensity_kwh_per_unit':
                regular_energy_intensity = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'eco_energy_intensity_kwh_per_unit':
                eco_energy_intensity = float(row['Value'])

    n = len(containers)

    # Create the model
    model = gp.Model("PlasticContainers")

    # Binary setup variables for each mode (Regular and Eco) of each container type
    y_regular = {i: model.addVar(vtype=GRB.BINARY, name=f"y_regular_{i}") for i in range(n)}
    y_eco = {i: model.addVar(vtype=GRB.BINARY, name=f"y_eco_{i}") for i in range(n)}

    # x_regular[i][j] = units of type i produced in Regular mode to fulfill demand of type j
    x_regular = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x_regular[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_regular_{i}_{j}")

    # x_eco[i][j] = units of type i produced in Eco mode to fulfill demand of type j
    x_eco = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x_eco[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_eco_{i}_{j}")

    # Objective function components
    variable_production_cost = (
        gp.quicksum(containers[i]['cost'] * x_regular[i, j] for (i, j) in x_regular) +
        gp.quicksum(containers[i]['cost'] * x_eco[i, j] for (i, j) in x_eco)
    )

    fixed_setup_cost_regular = gp.quicksum(fixed_setup_cost * y_regular[i] for i in range(n))
    fixed_setup_cost_eco = gp.quicksum(fixed_setup_cost * y_eco[i] for i in range(n))

    eco_overhead_cost_total = gp.quicksum(eco_overhead_cost * y_eco[i] for i in range(n))

    energy_consumption_regular = (
        regular_energy_intensity * 
        gp.quicksum(x_regular[i, j] for (i, j) in x_regular)
    )
    energy_consumption_eco = (
        eco_energy_intensity * 
        gp.quicksum(x_eco[i, j] for (i, j) in x_eco)
    )
    total_energy_cost = energy_cost_per_kwh * (energy_consumption_regular + energy_consumption_eco)

    # Total objective
    model.setObjective(
        variable_production_cost + 
        fixed_setup_cost_regular + 
        fixed_setup_cost_eco + 
        eco_overhead_cost_total + 
        total_energy_cost,
        GRB.MINIMIZE
    )

    # Demand constraints: for each type j, total supplied >= demand[j]
    for j in range(n):
        model.addConstr(
            gp.quicksum(x_regular[i, j] for i in range(n) if (i, j) in x_regular) +
            gp.quicksum(x_eco[i, j] for i in range(n) if (i, j) in x_eco) >= containers[j]['demand'],
            f"demand_{j}"
        )

    # Linking constraints: if we produce in Regular mode, y_regular[i] must be 1
    M = sum(c['demand'] for c in containers)
    for i in range(n):
        total_produced_regular_i = gp.quicksum(x_regular[i, j] for j in range(n) if (i, j) in x_regular)
        model.addConstr(total_produced_regular_i <= M * y_regular[i], f"setup_regular_{i}")

    # Linking constraints: if we produce in Eco mode, y_eco[i] must be 1
    for i in range(n):
        total_produced_eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(total_produced_eco_i <= M * y_eco[i], f"setup_eco_{i}")

    # Capacity constraint: Eco production cannot exceed eco_capacity_share of total production
    for i in range(n):
        total_produced_regular_i = gp.quicksum(x_regular[i, j] for j in range(n) if (i, j) in x_regular)
        total_produced_eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(total_produced_eco_i <= eco_capacity_share * (total_produced_regular_i + total_produced_eco_i), f"capacity_share_{i}")

    # Energy consumption constraint
    model.addConstr(
        energy_consumption_regular + energy_consumption_eco <= max_total_energy_kwh,
        "total_energy"
    )

    # Optimize the model
    model.setParam('OutputFlag', 0)
    model.optimize()

    # Print solution details
    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
