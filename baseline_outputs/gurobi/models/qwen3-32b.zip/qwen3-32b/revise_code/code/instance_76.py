import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
    
    # Read general_parameters.csv
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_storage = float(params['max_storage_capacity']) / 10000.0  # Convert to 万m³
    storage_cost_a = float(params['storage_cost_a'])  # yuan/m³
    storage_cost_b = float(params['storage_cost_b'])  # yuan/m³/quarter
    safety_inventory_level = float(params['safety_inventory_level_10k_m3'])
    terminal_inventory_value = float(params['terminal_inventory_value_per_10k_m3'])
    over_purchase_penalty = float(params['over_purchase_penalty_cost_per_10k_m3'])
    
    n = len(quarters)
    
    # Create model
    model = gp.Model("Timber_Profit_Maximization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: x[i][j] = amount purchased in quarter i and sold in quarter j (万m³)
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(name=f"x_{i}_{j}", lb=0)
    
    # Objective function
    obj_expr = gp.LinExpr()
    
    for i in range(n):
        for j in range(i, n):
            u = j - i  # Storage time in quarters
            revenue = sale_price[quarters[j]]
            cost = purchase_price[quarters[i]]
            
            if u > 0:
                s_cost = (storage_cost_a + storage_cost_b * u) / 10000.0  # Convert to 万元/万m³
            else:
                s_cost = 0
            
            profit_contribution = (revenue - cost - s_cost) * x[i, j]
            obj_expr += profit_contribution
    
    # Terminal inventory value at the end of autumn
    terminal_inventory = sum(x[i, 3] for i in range(4)) - sum(x[i, 3] for i in range(4))
    for i in range(4):
        for j in range(4):
            if j == 3:
                continue
            terminal_inventory += x[i, j]
    
    # Only inventory remaining after all sales contributes to terminal inventory
    terminal_inventory = sum(x[i, 3] for i in range(4))  # Inventory not sold in Autumn
    for j in range(3):  # Subtract timber sold before Autumn
        terminal_inventory -= sum(x[i, j] for i in range(j+1))
    
    # Add terminal inventory value and penalty for excess inventory
    obj_expr += terminal_inventory_value * max(0, terminal_inventory - safety_inventory_level)
    obj_expr -= over_purchase_penalty * max(0, terminal_inventory - safety_inventory_level)
    
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Sales constraints: total sold in quarter j <= max_sales[j]
    for j in range(n):
        total_sold = sum(x[i, j] for i in range(j + 1))
        model.addConstr(total_sold <= max_sales[quarters[j]], name=f"sales_limit_{j}")
    
    # Purchase constraints: total purchased in quarter i <= max_purchase[i]
    for i in range(n):
        total_purchased = sum(x[i, j] for j in range(i, n))
        model.addConstr(total_purchased <= max_purchase[quarters[i]], name=f"purchase_limit_{i}")
    
    # Storage constraints: at end of each quarter, stored timber <= max_storage
    for t in range(n - 1):
        # After quarter t, stored = sum of x[i,j] where i <= t and j > t
        stored = sum(x[i, j] for i in range(t + 1) for j in range(t + 1, n))
        model.addConstr(stored <= max_storage, name=f"storage_limit_{t}")
    
    # Optimize model
    model.optimize()
    
    # Print results
    if model.status == GRB.OPTIMAL:
        final_obj_value = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {final_obj_value:.1f}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
