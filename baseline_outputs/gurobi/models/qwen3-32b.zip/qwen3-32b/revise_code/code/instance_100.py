import os
import csv
from gurobipy import GRB, Model

def main():
    # Load the bandwidth table
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        
        bandwidth = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                if bw > 0:
                    bandwidth[(row_node, col_node)] = bw
    
    # Define source, intermediate, and target nodes
    source = 'A'
    intermediate = 'C'
    target = 'E'
    
    # Create a Gurobi model
    model = Model("network_routing")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: x[i,j] = 1 if link (i,j) is used in the path
    x = {}
    for i, j in bandwidth:
        x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
    
    # Objective: minimize total routing cost
    model.setObjective(gp.quicksum((100 - bandwidth[(i, j)]) * x[i, j] for i, j in bandwidth), GRB.MINIMIZE)
    
    # Constraints to ensure flow conservation
    # Flow balance at source node A
    model.addConstr(gp.quicksum(x[source, j] for j in nodes if (source, j) in x) == 1, "flow_out_A")
    
    # Flow balance at target node E
    model.addConstr(gp.quicksum(x[i, target] for i in nodes if (i, target) in x) == 1, "flow_in_E")
    
    # Flow balance at intermediate node C
    model.addConstr(
        gp.quicksum(x[i, intermediate] for i in nodes if (i, intermediate) in x) == 1,
        "flow_in_C"
    )
    model.addConstr(
        gp.quicksum(x[intermediate, j] for j in nodes if (intermediate, j) in x) == 1,
        "flow_out_C"
    )
    
    # Flow balance at all other nodes (except A, C, E)
    for n in nodes:
        if n not in [source, intermediate, target]:
            model.addConstr(
                gp.quicksum(x[i, n] for i in nodes if (i, n) in x) ==
                gp.quicksum(x[n, j] for j in nodes if (n, j) in x),
                f"flow_balance_{n}"
            )
    
    # Constraint to ensure no loops (each node can be visited at most once)
    u = {}
    big_M = len(nodes) + 1  # Big-M value for subtour elimination constraint
    
    for n in nodes:
        u[n] = model.addVar(lb=0, ub=len(nodes), vtype=GRB.INTEGER, name=f"u_{n}")
    
    # Subtour elimination constraints using MTZ formulation
    for i, j in bandwidth:
        if i != j and i != target and j != source:
            model.addConstr(u[i] - u[j] + 1 <= big_M * (1 - x[i, j]), f"mtz_{i}_{j}")
    
    # Optimize the model
    model.optimize()
    
    # Extract the solution
    optimal_path = []
    for i, j in bandwidth:
        if x[i, j].x > 0.5:
            optimal_path.append((i, j))
    
    # Calculate the total routing cost
    total_cost = sum((100 - bandwidth[(i, j)]) for i, j in optimal_path)
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {total_cost}")

if __name__ == '__main__':
    main()
