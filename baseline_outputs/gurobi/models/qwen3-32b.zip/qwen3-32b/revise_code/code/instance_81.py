import os
import gurobipy as gp
from gurobipy import GRB

# Set up paths to data files
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def load_car_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    cars = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            i = int(row['i'])
            length = float(row['lambda_i'])
            cars[i] = length
    return cars

def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'])
            params[name] = value
    return params

# Load data
cars = load_car_data(data_dir)
params = load_parameters(data_dir)

num_cars = int(params['num_cars'])
max_length_one_side = params['max_length_one_side']
available_party_side_count = int(params['available_party_side_count'])

car_ids = list(cars.keys())
lengths = cars

# Create Gurobi model
model = gp.Model("PartyParkingOptimization")
model.setParam('OutputFlag', 0)  # Suppress output

# Decision variables: x_i = 1 if car i is parked on the available side, 0 otherwise
x = model.addVars(car_ids, vtype=GRB.BINARY, name="x")

# Objective: minimize the total length of the street occupied by party cars
total_parked_length = gp.quicksum(lengths[i] * x[i] for i in car_ids)
model.setObjective(total_parked_length, GRB.MINIMIZE)

# Constraint: total length of cars on the available side must not exceed the limit
model.addConstr(gp.quicksum(lengths[i] * x[i] for i in car_ids) <= max_length_one_side, "MaxSideLength")

# Optimize the model
model.optimize()

# Extract and print the objective value
if model.status == GRB.OPTIMAL:
    final_obj_value = model.objVal
    print(f"FINAL_OBJ_VALUE: {final_obj_value}")
else:
    print("No optimal solution found.")
