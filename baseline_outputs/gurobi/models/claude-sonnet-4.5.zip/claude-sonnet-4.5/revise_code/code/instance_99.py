import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    """Load a CSV file and return headers and rows."""
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    return rows

def load_general_parameters(filename='general_parameters.csv'):
    """Load general parameters into a dictionary."""
    rows = load_csv(filename)
    params = {}
    for row in rows:
        params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_reliability_table(filename='table_1.csv'):
    """Load reliability table. Returns dict: {num_spares: [r1, r2, r3]}"""
    rows = load_csv(filename)
    reliability = {}
    for row in rows:
        n_spares = int(row['Number_of_Spares'])
        r1 = float(row['Component_1_Reliability'])
        r2 = float(row['Component_2_Reliability'])
        r3 = float(row['Component_3_Reliability'])
        reliability[n_spares] = [r1, r2, r3]
    return reliability

def solve():
    # Load data
    params = load_general_parameters()
    reliability = load_reliability_table()
    
    # Extract parameters
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    
    total_budget_A = params['total_budget_scenario_A']
    total_budget_B = params['total_budget_scenario_B']
    weight_limit_A = params['weight_limit_scenario_A']
    weight_limit_B = params['weight_limit_scenario_B']
    
    # Get max number of spares
    max_spares = max(reliability.keys())
    
    # Create model
    model = gp.Model("spare_parts_optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of spares for each component
    s = model.addVars(3, vtype=GRB.INTEGER, lb=0, ub=max_spares, name="spares")
    
    # Binary variables for each component and spare count
    # x[i][k] = 1 if component i has k spares
    x = {}
    for i in range(3):
        for k in range(max_spares + 1):
            x[i, k] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{k}")
    
    # Link s and x variables
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, k] for k in range(max_spares + 1)) == 1, name=f"one_choice_{i}")
        model.addConstr(s[i] == gp.quicksum(k * x[i, k] for k in range(max_spares + 1)), name=f"spare_count_{i}")
    
    # Auxiliary variables for system reliability in each scenario
    # Since component reliabilities are the same in both scenarios, system reliability is the same
    # SysRel = R1 * R2 * R3
    # We use linearization via auxiliary variables
    
    # Component reliabilities
    r = model.addVars(3, lb=0, ub=1, name="reliability")
    for i in range(3):
        model.addConstr(r[i] == gp.quicksum(reliability[k][i] * x[i, k] for k in range(max_spares + 1)), 
                       name=f"reliability_{i}")
    
    # System reliability (product of component reliabilities)
    # Use auxiliary variables for products
    # r12 = r[0] * r[1]
    # sysrel = r12 * r[2]
    
    r12 = model.addVar(lb=0, ub=1, name="r12")
    sysrel = model.addVar(lb=0, ub=1, name="sysrel")
    
    # Linearize r12 = r[0] * r[1]
    # We'll use piecewise linear approximation or McCormick envelopes
    # For better accuracy, we can use Gurobi's built-in nonlinear capabilities
    # But since we have discrete choices, we can directly compute
    
    # Actually, let's use a different approach: enumerate all combinations
    # and use binary variables
    
    # Alternative: use auxiliary binary variables for each combination
    # y[k1, k2, k3] = 1 if (s1=k1, s2=k2, s3=k3)
    y = {}
    for k1 in range(max_spares + 1):
        for k2 in range(max_spares + 1):
            for k3 in range(max_spares + 1):
                y[k1, k2, k3] = model.addVar(vtype=GRB.BINARY, name=f"y_{k1}_{k2}_{k3}")
    
    # Exactly one combination is chosen
    model.addConstr(gp.quicksum(y[k1, k2, k3] 
                                for k1 in range(max_spares + 1) 
                                for k2 in range(max_spares + 1) 
                                for k3 in range(max_spares + 1)) == 1, 
                   name="one_combination")
    
    # Link y to s
    model.addConstr(s[0] == gp.quicksum(k1 * y[k1, k2, k3] 
                                        for k1 in range(max_spares + 1) 
                                        for k2 in range(max_spares + 1) 
                                        for k3 in range(max_spares + 1)), 
                   name="s0_link")
    model.addConstr(s[1] == gp.quicksum(k2 * y[k1, k2, k3] 
                                        for k1 in range(max_spares + 1) 
                                        for k2 in range(max_spares + 1) 
                                        for k3 in range(max_spares + 1)), 
                   name="s1_link")
    model.addConstr(s[2] == gp.quicksum(k3 * y[k1, k2, k3] 
                                        for k1 in range(max_spares + 1) 
                                        for k2 in range(max_spares + 1) 
                                        for k3 in range(max_spares + 1)), 
                   name="s2_link")
    
    # System reliability
    model.addConstr(sysrel == gp.quicksum(reliability[k1][0] * reliability[k2][1] * reliability[k3][2] * y[k1, k2, k3]
                                          for k1 in range(max_spares + 1) 
                                          for k2 in range(max_spares + 1) 
                                          for k3 in range(max_spares + 1)), 
                   name="system_reliability")
    
    # Budget constraints for both scenarios
    total_cost = gp.quicksum(s[i] * unit_price[i] for i in range(3))
    model.addConstr(total_cost <= total_budget_A, name="budget_A")
    model.addConstr(total_cost <= total_budget_B, name="budget_B")
    
    # Weight constraints for both scenarios
    total_weight = gp.quicksum(s[i] * unit_weight[i] for i in range(3))
    model.addConstr(total_weight <= weight_limit_A, name="weight_A")
    model.addConstr(total_weight <= weight_limit_B, name="weight_B")
    
    # Expected reliability (since both scenarios have same reliability, it's just sysrel)
    expected_reliability = 0.5 * sysrel + 0.5 * sysrel
    
    # Objective: maximize expected reliability
    model.setObjective(expected_reliability, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: 0")

if __name__ == '__main__':
    solve()
