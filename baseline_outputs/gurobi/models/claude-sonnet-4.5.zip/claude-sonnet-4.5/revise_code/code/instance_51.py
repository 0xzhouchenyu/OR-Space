import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data files
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def load_demand(filepath):
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    return params

demand = load_demand(os.path.join(data_dir, 'table_1.csv'))
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

shift_duration = int(params['shift_duration'])
regular_pay = float(params['regular_nurse_pay'])
contract_pay = float(params['contract_nurse_pay'])
outsourced_regular_start_index = int(params['outsourced_regular_start_index'])
banned_contract_start_index = int(params['banned_contract_start_index'])
max_total_contract_starts = int(params['max_total_contract_starts'])
min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])
daytime_period_indices = [int(x) for x in params['daytime_period_indices'].split(';')]

num_periods = len(demand)
periods_per_shift = shift_duration // 4

# Create model
model = gp.Model("NurseScheduling")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="regular")
y = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="contract")

# Objective: minimize total cost
total_cost = gp.quicksum((regular_pay * shift_duration) * x[j] + (contract_pay * shift_duration) * y[j] 
                         for j in range(num_periods))
model.setObjective(total_cost, GRB.MINIMIZE)

# Coverage constraints: each period must have enough total nurses
for i in range(num_periods):
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i], 
                   name=f"demand_{i}")

# Constraint: Regular nurses cannot start the outsourced shift
model.addConstr(x[outsourced_regular_start_index] == 0, name="outsourced_regular")

# Constraint: Contract nurses cannot start the banned shift (overnight 22:00)
model.addConstr(y[banned_contract_start_index] == 0, name="banned_contract")

# Constraint: Total contract starts capped
model.addConstr(gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts, 
               name="max_contract")

# Constraint: Minimum regular nurses during daytime periods
for i in daytime_period_indices:
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(gp.quicksum(x[j] for j in covering_shifts) >= min_regular_daytime_coverage,
                   name=f"min_regular_daytime_{i}")

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
