import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    params = load_parameters(data_path)
    
    W = params['initial_investment']
    r1 = params['return_rate_option_1']
    r2 = params['return_rate_option_2']
    T = int(params['planning_horizon'])
    min_reserve_year1 = params['min_reserve_year1']
    min_reserve_year2 = params['min_reserve_year2']
    max_option2_start = params['max_option2_start']
    option2_year0_late_settlement_rate = params['option2_year0_late_settlement_rate']
    
    model = gp.Model("Investment_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x0_1 = model.addVar(lb=0, name="x0_1")  # Option 1 at year 0
    x0_2 = model.addVar(lb=0, name="x0_2")  # Option 2 at year 0
    x1_1 = model.addVar(lb=0, name="x1_1")  # Option 1 at year 1
    x1_2 = model.addVar(lb=0, name="x1_2")  # Option 2 at year 1
    x2_1 = model.addVar(lb=0, name="x2_1")  # Option 1 at year 2
    
    # Cash reserves
    cash_year1 = model.addVar(lb=0, name="cash_year1")
    cash_year2 = model.addVar(lb=0, name="cash_year2")
    
    # Year 0 budget constraint
    model.addConstr(x0_1 + x0_2 <= W, "year0_budget")
    
    # Year 0 Option 2 exposure ceiling
    model.addConstr(x0_2 <= max_option2_start, "year0_option2_max")
    
    # Year 1: money available = returns from x0_1
    # x0_2 started at year 0, settles after year 2, not available at year 1
    model.addConstr(x1_1 + x1_2 + cash_year1 == x0_1 * (1 + r1), "year1_budget")
    
    # Year 1 minimum reserve
    model.addConstr(cash_year1 >= min_reserve_year1, "year1_reserve")
    
    # Year 1 Option 2 exposure ceiling
    model.addConstr(x1_2 <= max_option2_start, "year1_option2_max")
    
    # Year 2: money available = returns from x1_1 + cash carried from year 1
    # x0_2 settles after year 2 cut-off, so not available for year 2 investments
    # x1_2 started at year 1, settles at year 3, not available at year 2
    model.addConstr(x2_1 + cash_year2 == x1_1 * (1 + r1) + cash_year1, "year2_budget")
    
    # Year 2 minimum reserve
    model.addConstr(cash_year2 >= min_reserve_year2, "year2_reserve")
    
    # Year 3 (end): total wealth
    # x2_1 returns at year 3: x2_1 * (1 + r1)
    # x1_2 returns at year 3: x1_2 * (1 + r2)
    # x0_2 settles after year 2 cut-off, with late settlement rate deduction
    # Net proceeds from x0_2: x0_2 * (1 + r2) * (1 - option2_year0_late_settlement_rate)
    # Plus cash carried from year 2
    
    net_x0_2_proceeds = x0_2 * (1 + r2) * (1 - option2_year0_late_settlement_rate)
    
    total_wealth_year3 = x2_1 * (1 + r1) + x1_2 * (1 + r2) + net_x0_2_proceeds + cash_year2
    
    model.setObjective(total_wealth_year3, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
