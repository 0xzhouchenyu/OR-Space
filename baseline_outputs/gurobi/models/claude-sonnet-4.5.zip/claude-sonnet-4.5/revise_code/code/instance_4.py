import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
cow_price = params['cow_selling_price']
sheep_price = params['sheep_selling_price']
chicken_price = params['chicken_selling_price']
cow_feed = params['cow_feed_cost']
sheep_feed = params['sheep_feed_cost']
chicken_feed = params['chicken_feed_cost']
cow_manure = params['cow_manure_production']
sheep_manure = params['sheep_manure_production']
chicken_manure = params['chicken_manure_production']
max_manure = params['max_manure_capacity']
max_chickens = params['max_chickens']
min_cows = params['min_cows']
min_sheep = params['min_sheep']
max_total = params['max_total_animals']
premium_capacity_multiplier = params['premium_capacity_multiplier']
premium_manure_multiplier = params['premium_manure_multiplier']
expansion_cost = params['expansion_cost']
premium_feed_multiplier = params['premium_feed_multiplier']
base_land_usage_cow = params['base_land_usage_cow']
base_land_usage_sheep = params['base_land_usage_sheep']
base_land_usage_chicken = params['base_land_usage_chicken']
base_land_capacity = params['base_land_capacity']
expansion_land_increase = params['expansion_land_increase']

# Create model
model = gp.Model("FarmProfit")
model.setParam('OutputFlag', 0)

# Decision variables
# Regular animals
cows_regular = model.addVar(vtype=GRB.INTEGER, name="cows_regular", lb=0)
sheep_regular = model.addVar(vtype=GRB.INTEGER, name="sheep_regular", lb=0)
chickens_regular = model.addVar(vtype=GRB.INTEGER, name="chickens_regular", lb=0)

# Premium animals (only available in expanded mode)
cows_premium = model.addVar(vtype=GRB.INTEGER, name="cows_premium", lb=0)
sheep_premium = model.addVar(vtype=GRB.INTEGER, name="sheep_premium", lb=0)
chickens_premium = model.addVar(vtype=GRB.INTEGER, name="chickens_premium", lb=0)

# Binary variable for expanded mode
expanded = model.addVar(vtype=GRB.BINARY, name="expanded")

# Objective: maximize profit
# Regular animals profit
profit_regular = (
    (cow_price - cow_feed) * cows_regular +
    (sheep_price - sheep_feed) * sheep_regular +
    (chicken_price - chicken_feed) * chickens_regular
)

# Premium animals profit (higher feed cost)
profit_premium = (
    (cow_price - cow_feed * premium_feed_multiplier) * cows_premium +
    (sheep_price - sheep_feed * premium_feed_multiplier) * sheep_premium +
    (chicken_price - chicken_feed * premium_feed_multiplier) * chickens_premium
)

# Total profit minus expansion cost if expanded
total_profit = profit_regular + profit_premium - expansion_cost * expanded

model.setObjective(total_profit, GRB.MAXIMIZE)

# Constraints

# Minimum demand constraints (total animals)
model.addConstr(cows_regular + cows_premium >= min_cows, "min_cows")
model.addConstr(sheep_regular + sheep_premium >= min_sheep, "min_sheep")

# Maximum chickens constraint
model.addConstr(chickens_regular + chickens_premium <= max_chickens, "max_chickens")

# Total animals constraint (depends on mode)
total_animals = cows_regular + sheep_regular + chickens_regular + cows_premium + sheep_premium + chickens_premium
# In regular mode: <= max_total
# In expanded mode: <= max_total * premium_capacity_multiplier
model.addConstr(total_animals <= max_total + (max_total * premium_capacity_multiplier - max_total) * expanded, "max_animals")

# Manure capacity constraint (depends on mode)
total_manure = (
    cow_manure * (cows_regular + cows_premium) +
    sheep_manure * (sheep_regular + sheep_premium) +
    chicken_manure * (chickens_regular + chickens_premium)
)
# In regular mode: <= max_manure
# In expanded mode: <= max_manure * premium_manure_multiplier
model.addConstr(total_manure <= max_manure + (max_manure * premium_manure_multiplier - max_manure) * expanded, "max_manure")

# Land usage constraint (depends on mode)
total_land = (
    base_land_usage_cow * (cows_regular + cows_premium) +
    base_land_usage_sheep * (sheep_regular + sheep_premium) +
    base_land_usage_chicken * (chickens_regular + chickens_premium)
)
# In regular mode: <= base_land_capacity
# In expanded mode: <= base_land_capacity + expansion_land_increase
model.addConstr(total_land <= base_land_capacity + expansion_land_increase * expanded, "land_capacity")

# Premium animals only available when expanded mode is active
# Use big-M constraint: premium animals <= M * expanded
M = max_total * premium_capacity_multiplier  # Large enough upper bound
model.addConstr(cows_premium <= M * expanded, "premium_cows_gate")
model.addConstr(sheep_premium <= M * expanded, "premium_sheep_gate")
model.addConstr(chickens_premium <= M * expanded, "premium_chickens_gate")

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
