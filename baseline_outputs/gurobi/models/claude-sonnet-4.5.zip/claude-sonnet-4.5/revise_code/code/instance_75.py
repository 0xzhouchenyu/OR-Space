import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params


# Load data
data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
params = load_parameters(data_path)

# Extract parameters
a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']
T1_normal = params['available_time_process_1']
T2_normal = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']
c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
bigM_disposal = params['bigM_disposal']
disposal_cost_base = params['disposal_cost_per_unit_c']
disposal_cost_high = params['disposal_cost_per_unit_c_high']
profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

# Create model
model = gp.Model("RevisedMaxProfit")
model.setParam('OutputFlag', 0)

# Decision variables
xA = model.addVar(lb=0, name="xA")
xB = model.addVar(lb=0, name="xB")
cSold = model.addVar(lb=0, name="cSold")
cDisposed = model.addVar(lb=0, name="cDisposed")

# Binary variables for high-throughput mode selection (at most one)
h1 = model.addVar(vtype=GRB.BINARY, name="h1")  # 1 if process 1 uses high-throughput
h2 = model.addVar(vtype=GRB.BINARY, name="h2")  # 1 if process 2 uses high-throughput

# Binary variable for disposal threshold
z = model.addVar(vtype=GRB.BINARY, name="z")  # 1 if disposal exceeds threshold_c

# Continuous variables for disposal cost calculation
cDisposed_base = model.addVar(lb=0, name="cDisposed_base")  # disposal at base cost
cDisposed_excess = model.addVar(lb=0, name="cDisposed_excess")  # disposal at high cost

# Objective: maximize total profit
model.setObjective(
    profit_a * xA + profit_b * xB + profit_c * cSold 
    - disposal_cost_base * cDisposed_base 
    - disposal_cost_high * cDisposed_excess,
    GRB.MAXIMIZE
)

# Constraint: at most one process can use high-throughput mode
model.addConstr(h1 + h2 <= 1, "AtMostOneHighThroughput")

# Process 1 time constraint with mode selection
model.addConstr(
    a_p1 * xA + b_p1 * xB <= T1_normal + (T1_high - T1_normal) * h1,
    "Process1Time"
)

# Process 2 time constraint with mode selection
model.addConstr(
    a_p2 * xA + b_p2 * xB <= T2_normal + (T2_high - T2_normal) * h2,
    "Process2Time"
)

# By-product C balance
model.addConstr(cSold + cDisposed == c_per_b * xB, "ByproductBalance")

# Maximum C that can be sold
model.addConstr(cSold <= max_c_sales, "MaxCSales")

# Disposal cost structure with threshold
model.addConstr(cDisposed == cDisposed_base + cDisposed_excess, "DisposalSplit")
model.addConstr(cDisposed_base <= threshold_c, "BaseDisposalLimit")
model.addConstr(cDisposed_excess <= bigM_disposal * z, "ExcessDisposalActivation")
model.addConstr(cDisposed <= threshold_c + bigM_disposal * z, "ThresholdEnforcement")

# Solve
model.optimize()

# Output result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
