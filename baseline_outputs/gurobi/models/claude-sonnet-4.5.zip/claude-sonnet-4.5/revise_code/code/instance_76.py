import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Read data files
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
    
    # Read general_parameters.csv
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_storage = float(params['max_storage_capacity'])  # 200000 m³
    storage_cost_a = float(params['storage_cost_a'])      # 70 yuan/m³
    storage_cost_b = float(params['storage_cost_b'])      # 100 yuan/m³/quarter
    safety_inventory = float(params['safety_inventory_level_10k_m3'])  # 20 万m³
    terminal_value = float(params['terminal_inventory_value_per_10k_m3'])  # 455 万元/万m³
    over_purchase_penalty = float(params['over_purchase_penalty_cost_per_10k_m3'])  # 300 万元/万m³
    
    # Convert storage capacity to 万m³
    max_storage_wm3 = max_storage / 10000.0  # 20 万m³
    
    # Convert storage costs to 万元/万m³
    storage_cost_a_w = storage_cost_a * 10000.0 / 10000.0  # = 70 万元/万m³
    storage_cost_b_w = storage_cost_b * 10000.0 / 10000.0  # = 100 万元/万m³/quarter
    
    n = len(quarters)
    
    # Create Gurobi model
    model = gp.Model("Timber_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables:
    # x[i,j] = amount purchased in quarter i and sold in quarter j (万m³)
    # where j >= i and j <= 3 (must sell by autumn or hold as end inventory)
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    # End-of-autumn inventory variable (万m³)
    end_inventory = model.addVar(lb=0, name="end_inventory")
    
    # Auxiliary variable for excess inventory above safety level
    excess_inventory = model.addVar(lb=0, name="excess_inventory")
    
    model.update()
    
    # Objective: maximize profit
    # Profit = Revenue from sales - Purchase costs - Storage costs + Terminal inventory value - Over-purchase penalty
    
    profit_expr = 0
    
    # Sales revenue and purchase/storage costs
    for i in range(n):
        for j in range(i, n):
            u = j - i  # quarters stored
            revenue = sale_price[quarters[j]]
            cost = purchase_price[quarters[i]]
            if u > 0:
                s_cost = storage_cost_a_w + storage_cost_b_w * u
            else:
                s_cost = 0
            profit_expr += (revenue - cost - s_cost) * x[i, j]
    
    # Terminal inventory value (credited for end-of-autumn inventory)
    profit_expr += terminal_value * end_inventory
    
    # Over-purchase penalty (applied to excess above safety level)
    profit_expr -= over_purchase_penalty * excess_inventory
    
    model.setObjective(profit_expr, GRB.MAXIMIZE)
    
    # Constraints:
    
    # 1. Purchase constraints: total purchased in quarter i <= max_purchase[i]
    for i in range(n):
        total_purchased = gp.quicksum(x[i, j] for j in range(i, n))
        model.addConstr(total_purchased <= max_purchase[quarters[i]], name=f"purchase_limit_{i}")
    
    # 2. Sales constraints: total sold in quarter j <= max_sales[j]
    for j in range(n):
        total_sold = gp.quicksum(x[i, j] for i in range(j + 1))
        model.addConstr(total_sold <= max_sales[quarters[j]], name=f"sales_limit_{j}")
    
    # 3. Storage constraints: at end of each quarter (except autumn), stored timber <= max_storage
    for t in range(n - 1):
        # After quarter t, stored = sum of x[i,j] where i <= t and j > t
        stored = gp.quicksum(x[i, j] for i in range(t + 1) for j in range(t + 1, n))
        model.addConstr(stored <= max_storage_wm3, name=f"storage_limit_{t}")
    
    # 4. End-of-autumn inventory definition
    # End inventory = all timber purchased but not sold during the year
    # = sum of all purchases - sum of all sales
    total_purchased_all = gp.quicksum(x[i, j] for i in range(n) for j in range(i, n))
    total_sold_all = gp.quicksum(x[i, j] for i in range(n) for j in range(i, n))
    # Actually, x[i,j] represents timber bought in i and sold in j, so total_sold = total_purchased for the year
    # End inventory should be: timber bought but held beyond autumn
    # Since we must sell by autumn in the original problem, we need to redefine:
    # Let's add a variable for timber bought but held as end-of-autumn inventory
    
    # Redefine: x[i,j] for j < n means sold in quarter j
    # We need additional variables for timber bought in quarter i and held as end inventory
    
    # Let me reconsider the model structure:
    # x[i,j] = timber bought in quarter i and sold in quarter j (j in [i, n-1])
    # y[i] = timber bought in quarter i and held as end-of-autumn inventory
    
    # Recreate model with this structure
    model = gp.Model("Timber_Optimization")
    model.setParam('OutputFlag', 0)
    
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    y = {}
    for i in range(n):
        y[i] = model.addVar(lb=0, name=f"y_{i}")
    
    end_inventory = model.addVar(lb=0, name="end_inventory")
    excess_inventory = model.addVar(lb=0, name="excess_inventory")
    
    model.update()
    
    # Objective
    profit_expr = 0
    
    # Sales revenue and costs for x[i,j]
    for i in range(n):
        for j in range(i, n):
            u = j - i
            revenue = sale_price[quarters[j]]
            cost = purchase_price[quarters[i]]
            if u > 0:
                s_cost = storage_cost_a_w + storage_cost_b_w * u
            else:
                s_cost = 0
            profit_expr += (revenue - cost - s_cost) * x[i, j]
    
    # Costs for y[i] (held as end inventory)
    for i in range(n):
        u = n - 1 - i  # quarters from purchase to end of autumn
        cost = purchase_price[quarters[i]]
        if u > 0:
            s_cost = storage_cost_a_w + storage_cost_b_w * u
        else:
            s_cost = 0
        profit_expr += (-cost - s_cost) * y[i]
    
    # Terminal inventory value
    profit_expr += terminal_value * end_inventory
    
    # Over-purchase penalty
    profit_expr -= over_purchase_penalty * excess_inventory
    
    model.setObjective(profit_expr, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Purchase constraints
    for i in range(n):
        total_purchased = gp.quicksum(x[i, j] for j in range(i, n)) + y[i]
        model.addConstr(total_purchased <= max_purchase[quarters[i]], name=f"purchase_limit_{i}")
    
    # 2. Sales constraints
    for j in range(n):
        total_sold = gp.quicksum(x[i, j] for i in range(j + 1))
        model.addConstr(total_sold <= max_sales[quarters[j]], name=f"sales_limit_{j}")
    
    # 3. Storage constraints (during the year)
    for t in range(n - 1):
        stored = gp.quicksum(x[i, j] for i in range(t + 1) for j in range(t + 1, n))
        stored += gp.quicksum(y[i] for i in range(t + 1))
        model.addConstr(stored <= max_storage_wm3, name=f"storage_limit_{t}")
    
    # 4. End inventory definition
    model.addConstr(end_inventory == gp.quicksum(y[i] for i in range(n)), name="end_inventory_def")
    
    # 5. Excess inventory definition
    model.addConstr(excess_inventory >= end_inventory - safety_inventory, name="excess_inventory_def")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
