import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

a1 = int(params['a1'])
a2 = int(params['a2'])
training_capacity = params['training_capacity_per_jet']
dual_use_efficiency = params['dual_use_training_efficiency']
training_intensity_cap = params['training_intensity_cap']
combat_jet_min_year2 = params['combat_jet_min_year2']
combat_weight = params['combat_weight']
training_weight = params['training_weight']

model = gp.Model("fighter_jet_allocation")
model.setParam('OutputFlag', 0)

# Decision variables
# Year 1: training-only, dual-use, combat-only
t1 = model.addVar(vtype=GRB.INTEGER, name="training_only_year1")
d1 = model.addVar(vtype=GRB.INTEGER, name="dual_use_year1")
c1 = model.addVar(vtype=GRB.INTEGER, name="combat_only_year1")

# Year 2: training-only, dual-use, combat-only
t2 = model.addVar(vtype=GRB.INTEGER, name="training_only_year2")
d2 = model.addVar(vtype=GRB.INTEGER, name="dual_use_year2")
c2 = model.addVar(vtype=GRB.INTEGER, name="combat_only_year2")

# Constraints
# Year 1 fleet allocation
model.addConstr(t1 + d1 + c1 == a1, "year1_fleet")

# Year 2 fleet allocation (cumulative)
model.addConstr(t2 + d2 + c2 == a1 + a2, "year2_fleet")

# Training intensity cap for year 1
model.addConstr(t1 + d1 <= training_intensity_cap * a1, "training_cap_year1")

# Training intensity cap for year 2
model.addConstr(t2 + d2 <= training_intensity_cap * (a1 + a2), "training_cap_year2")

# Minimum combat jets in year 2 (dual-use contributes to combat availability)
model.addConstr(d2 + c2 >= combat_jet_min_year2, "min_combat_year2")

# Non-negativity
model.addConstr(t1 >= 0, "t1_nonneg")
model.addConstr(d1 >= 0, "d1_nonneg")
model.addConstr(c1 >= 0, "c1_nonneg")
model.addConstr(t2 >= 0, "t2_nonneg")
model.addConstr(d2 >= 0, "d2_nonneg")
model.addConstr(c2 >= 0, "c2_nonneg")

# Objective: maximize weighted sum of pilots trained and combat jets in year 2
# Pilots trained over 2 years:
# Year 1: t1 * training_capacity + d1 * training_capacity * dual_use_efficiency
# Year 2: t2 * training_capacity + d2 * training_capacity * dual_use_efficiency
# Combat jets in year 2: d2 + c2

pilots_year1 = t1 * training_capacity + d1 * training_capacity * dual_use_efficiency
pilots_year2 = t2 * training_capacity + d2 * training_capacity * dual_use_efficiency
total_pilots = pilots_year1 + pilots_year2

combat_jets_year2 = d2 + c2

objective = training_weight * total_pilots + combat_weight * combat_jets_year2

model.setObjective(objective, GRB.MAXIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
