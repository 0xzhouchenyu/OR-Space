import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB
from itertools import permutations

def load_processing_times(filepath):
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if len(row) >= 2 and row[1].strip() != '':
                try:
                    params[row[0].strip()] = float(row[1].strip())
                except ValueError:
                    params[row[0].strip()] = row[1].strip()
    return params

def compute_makespan_and_machine_usage(sequence, processing_times, n_machines):
    n_jobs = len(sequence)
    completion = [[0] * n_machines for _ in range(n_jobs)]
    
    for i in range(n_jobs):
        job = sequence[i]
        for j in range(n_machines):
            start_time = 0
            if i > 0:
                start_time = max(start_time, completion[i-1][j])
            if j > 0:
                start_time = max(start_time, completion[i][j-1])
            completion[i][j] = start_time + processing_times[job][j]
    
    # Compute total busy time on each machine (last completion time on each machine)
    machine_completion = []
    for j in range(n_machines):
        mc = max(completion[i][j] for i in range(n_jobs))
        machine_completion.append(mc)
    
    makespan = completion[n_jobs - 1][n_machines - 1]
    return makespan, machine_completion, completion

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    processing_times = load_processing_times(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    n_products = len(processing_times)
    n_machines = len(processing_times[0])
    
    # Extract parameters
    time_window = [params['time_window_1'], params['time_window_2'], params['time_window_3']]
    overtime_window = [params['overtime_window_1'], params['overtime_window_2'], params['overtime_window_3']]
    overtime_penalty_per_unit = params['overtime_penalty_per_unit']
    machine1_review_threshold = params['machine1_overtime_review_threshold']
    machine1_review_fee = params['machine1_overtime_review_fee']
    
    # We'll build a MIP model
    # Decision variables:
    # - perm: permutation of products (encoded via binary ranking variables)
    # - start[i][j]: start time of product i on machine j
    # - C[i][j]: completion time of product i on machine j
    # - makespan: total makespan
    # - overtime[j]: overtime used on machine j
    # - machine1_review: binary, 1 if machine 1 overtime > threshold
    
    # For flow shop with fixed sequence constraint (same order on all machines),
    # we enumerate all permutations and solve for each, picking the best objective
    
    best_obj = float('inf')
    best_sequence = None
    best_details = None
    
    for perm in permutations(range(n_products)):
        makespan, machine_completion, completion = compute_makespan_and_machine_usage(
            list(perm), processing_times, n_machines
        )
        
        # Machine completion times (when each machine finishes all its jobs)
        # For overtime calculation, we consider the total span on each machine
        # The machine is busy from 0 to machine_completion[j]
        # Overtime = max(0, machine_completion[j] - time_window[j])
        # But capped at overtime_window[j]
        
        # For machine 1 (index 0), we need special handling
        # machine_completion[0] is when machine 1 finishes all products
        
        overtime = []
        for j in range(n_machines):
            ot = max(0, machine_completion[j] - time_window[j])
            # Cap overtime at overtime_window
            ot = min(ot, overtime_window[j])
            overtime.append(ot)
        
        # Overtime penalty
        overtime_cost = sum(overtime[j] * overtime_penalty_per_unit for j in range(n_machines))
        
        # Machine 1 review fee
        # The first 1 second of Machine 1 overtime is covered by normal window
        # More than 1 second opens a 1.2-unit review burden
        machine1_ot = overtime[0]  # overtime on machine 1
        review_fee = 0
        if machine1_ot > machine1_review_threshold:
            review_fee = machine1_review_fee
        
        # Total objective: makespan + overtime_cost + review_fee
        total_obj = makespan + overtime_cost + review_fee
        
        if total_obj < best_obj:
            best_obj = total_obj
            best_sequence = perm
            best_details = {
                'makespan': makespan,
                'machine_completion': machine_completion,
                'overtime': overtime,
                'overtime_cost': overtime_cost,
                'review_fee': review_fee,
                'total_obj': total_obj
            }
    
    print(f"FINAL_OBJ_VALUE: {best_obj}")

if __name__ == "__main__":
    main()
