import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    df = pd.read_csv(data_path)
    
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = row['Value']
        
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = int(params['raw_bar_length'])
    setup_cost = float(params['setup_cost_per_pattern'])
    max_patterns = int(params['max_distinct_patterns'])
    
    # Lengths of the three types of steel bars
    len1 = 3
    len2 = 4
    len3 = 5
    
    # Generate all valid cutting patterns
    patterns = []
    for x in range(L // len1 + 1):
        for y in range(L // len2 + 1):
            for z in range(L // len3 + 1):
                if len1 * x + len2 * y + len3 * z <= L:
                    if x > 0 or y > 0 or z > 0:
                        patterns.append((x, y, z))
    
    # Create model
    model = gp.Model("CuttingStock")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of times each pattern is used
    pattern_vars = {}
    for i in range(len(patterns)):
        pattern_vars[i] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"Pattern_{i}")
    
    # Binary variables: whether each pattern is used at all
    pattern_used = {}
    for i in range(len(patterns)):
        pattern_used[i] = model.addVar(vtype=GRB.BINARY, name=f"Used_{i}")
    
    # Objective: minimize total waste
    # Total waste = (Total length of raw bars used) - (Total length of required pieces) + setup costs
    required_length = len1 * q3 + len2 * q4 + len3 * q5
    
    total_raw_length = gp.quicksum(L * pattern_vars[i] for i in range(len(patterns)))
    setup_waste = gp.quicksum(setup_cost * pattern_used[i] for i in range(len(patterns)))
    
    model.setObjective(total_raw_length - required_length + setup_waste, GRB.MINIMIZE)
    
    # Constraints: satisfy the demand for each type of steel bar
    model.addConstr(
        gp.quicksum(patterns[i][0] * pattern_vars[i] for i in range(len(patterns))) >= q3,
        name="Demand_3m"
    )
    model.addConstr(
        gp.quicksum(patterns[i][1] * pattern_vars[i] for i in range(len(patterns))) >= q4,
        name="Demand_4m"
    )
    model.addConstr(
        gp.quicksum(patterns[i][2] * pattern_vars[i] for i in range(len(patterns))) >= q5,
        name="Demand_5m"
    )
    
    # Link pattern_vars to pattern_used: if pattern_vars[i] > 0, then pattern_used[i] = 1
    M = q3 + q4 + q5  # Large enough constant
    for i in range(len(patterns)):
        model.addConstr(pattern_vars[i] <= M * pattern_used[i], name=f"Link_{i}")
    
    # Constraint: maximum number of distinct patterns
    model.addConstr(
        gp.quicksum(pattern_used[i] for i in range(len(patterns))) <= max_patterns,
        name="Max_patterns"
    )
    
    # Solve the problem
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    solve()
