import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Parse data files
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Parse table_1.csv
    proc_time = {}  # (equipment, product) -> hours per unit
    capacity = {}   # equipment -> available hours
    cost_rate = {}  # equipment -> cost per machine hour
    raw_cost = {}   # product -> raw material cost per unit
    price = {}      # product -> selling price per unit
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            if equip == 'Raw_Material_Cost':
                raw_cost['I'] = float(row['Product_I'])
                raw_cost['II'] = float(row['Product_II'])
                raw_cost['III'] = float(row['Product_III'])
            elif equip == 'Unit_Price':
                price['I'] = float(row['Product_I'])
                price['II'] = float(row['Product_II'])
                price['III'] = float(row['Product_III'])
            else:
                for prod, col in [('I', 'Product_I'), ('II', 'Product_II'), ('III', 'Product_III')]:
                    val = row[col].strip()
                    if val != '-':
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row['Effective_Machine_Hours'])
                cost_rate[equip] = float(row['Processing_Cost_per_Machine_Hour'])
    
    # Parse setup_costs.csv
    setup_cost = {}
    with open(os.path.join(data_dir, 'setup_costs.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            setup_cost[equip] = float(row['Fixed_Setup_Cost'])
    
    # Parse general_parameters.csv
    joint_calib_fee = 0
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param = row['Parameter_Name'].strip()
            if param == 'A2_B2_joint_calibration_fee':
                joint_calib_fee = float(row['Value'])
    
    # Equipment assignments
    stage_A_equip = {'I': ['A1', 'A2'], 'II': ['A1', 'A2'], 'III': ['A2']}
    stage_B_equip = {'I': ['B1', 'B2', 'B3'], 'II': ['B1'], 'III': ['B2']}
    
    # Create model
    model = gp.Model("Factory_Production")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[(equip, prod)] = units of product processed on equipment
    x = {}
    for prod in ['I', 'II', 'III']:
        for equip in stage_A_equip[prod]:
            x[(equip, prod)] = model.addVar(lb=0, name=f"x_{equip}_{prod}")
        for equip in stage_B_equip[prod]:
            x[(equip, prod)] = model.addVar(lb=0, name=f"x_{equip}_{prod}")
    
    # Binary variables: y[equip] = 1 if equipment is used
    y = {}
    for equip in ['A1', 'A2', 'B1', 'B2', 'B3']:
        y[equip] = model.addVar(vtype=GRB.BINARY, name=f"y_{equip}")
    
    # Binary variable: z = 1 if both A2 and B2 are used
    z = model.addVar(vtype=GRB.BINARY, name="z_A2_B2_joint")
    
    model.update()
    
    # Total production of each product
    total = {}
    for prod in ['I', 'II', 'III']:
        total[prod] = gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod])
    
    # Flow conservation: stage A total == stage B total
    for prod in ['I', 'II', 'III']:
        model.addConstr(
            gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod]) == 
            gp.quicksum(x[(e, prod)] for e in stage_B_equip[prod]),
            name=f"flow_{prod}"
        )
    
    # Capacity constraints
    for equip in ['A1', 'A2', 'B1', 'B2', 'B3']:
        relevant = [(equip, prod) for prod in ['I', 'II', 'III'] if (equip, prod) in x]
        if relevant:
            model.addConstr(
                gp.quicksum(proc_time[(equip, prod)] * x[(equip, prod)] for equip2, prod in relevant) <= capacity[equip],
                name=f"capacity_{equip}"
            )
    
    # Link binary variables to usage: if equipment is used, y[equip] = 1
    M = 1e6  # Big M
    for equip in ['A1', 'A2', 'B1', 'B2', 'B3']:
        relevant = [(equip, prod) for prod in ['I', 'II', 'III'] if (equip, prod) in x]
        if relevant:
            model.addConstr(
                gp.quicksum(x[(equip, prod)] for equip2, prod in relevant) <= M * y[equip],
                name=f"link_{equip}"
            )
    
    # Joint calibration constraint: z = 1 if and only if both A2 and B2 are used
    model.addConstr(z <= y['A2'], name="joint_A2")
    model.addConstr(z <= y['B2'], name="joint_B2")
    model.addConstr(z >= y['A2'] + y['B2'] - 1, name="joint_both")
    
    # Objective: profit = revenue - raw material - processing cost - setup costs - joint calibration fee
    revenue = gp.quicksum(price[p] * total[p] for p in ['I', 'II', 'III'])
    raw_mat = gp.quicksum(raw_cost[p] * total[p] for p in ['I', 'II', 'III'])
    proc_cost = gp.quicksum(cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x)
    setup_costs = gp.quicksum(setup_cost[equip] * y[equip] for equip in ['A1', 'A2', 'B1', 'B2', 'B3'])
    joint_calib_cost = joint_calib_fee * z
    
    model.setObjective(revenue - raw_mat - proc_cost - setup_costs - joint_calib_cost, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
