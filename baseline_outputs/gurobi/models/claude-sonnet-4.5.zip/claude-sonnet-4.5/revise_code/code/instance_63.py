import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

produce = params['produce_to_transport']
horse_poll = params['horse_pollution_per_trip']
bike_poll = params['bicycle_pollution_per_trip']
cart_poll = params['handcart_pollution_per_trip']
max_poll = params['max_total_pollution']
min_horse = params['min_horse_trips']
horse_cap = params['horse_capacity_per_trip']
bike_cap = params['bicycle_capacity_per_trip']
cart_cap = params['handcart_capacity_per_trip']
min_produce = params['min_total_produce']
horse_cost = params['horse_cost_per_trip']
bike_cost = params['bicycle_cost_per_trip']
cart_cost = params['handcart_cost_per_trip']
horse_fixed = params['horse_fixed_cost']
bike_fixed = params['bicycle_fixed_cost']
cart_fixed = params['handcart_fixed_cost']
pollution_penalty = params['pollution_penalty_per_unit']
pollution_threshold = params['horse_pollution_permit_threshold']
permit_fee = params['horse_pollution_permit_fee']

# Model
model = gp.Model("FarmTransport")
model.setParam('OutputFlag', 0)

# Decision variables
x_horse = model.addVar(vtype=GRB.INTEGER, lb=0, name="horse_trips")
x_bike = model.addVar(vtype=GRB.INTEGER, lb=0, name="bike_trips")
x_cart = model.addVar(vtype=GRB.INTEGER, lb=0, name="cart_trips")

# Binary variable: y=1 means bicycle chosen, y=0 means handcart chosen
y = model.addVar(vtype=GRB.BINARY, name="choose_bike")

# Binary variables for fixed costs
use_horse = model.addVar(vtype=GRB.BINARY, name="use_horse")
use_bike = model.addVar(vtype=GRB.BINARY, name="use_bike")
use_cart = model.addVar(vtype=GRB.BINARY, name="use_cart")

# Binary variable for pollution permit fee: z=1 if pollution > threshold
z = model.addVar(vtype=GRB.BINARY, name="exceed_pollution_threshold")

M = 10000  # Big-M

# Link trip variables to usage binaries
model.addConstr(x_horse <= M * use_horse, "link_horse")
model.addConstr(x_bike <= M * use_bike, "link_bike")
model.addConstr(x_cart <= M * use_cart, "link_cart")

# Must transport at least min_produce
model.addConstr(horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce, "min_produce_constraint")

# Total pollution
total_pollution = horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart

# Pollution constraint
model.addConstr(total_pollution <= max_poll, "max_pollution_constraint")

# Minimum horse trips
model.addConstr(x_horse >= min_horse, "min_horse_trips")

# Either bicycle or handcart, not both
model.addConstr(x_bike <= M * y, "bike_choice")
model.addConstr(x_cart <= M * (1 - y), "cart_choice")
model.addConstr(use_bike <= y, "use_bike_choice")
model.addConstr(use_cart <= 1 - y, "use_cart_choice")

# Pollution threshold constraint for permit fee
# If total_pollution > pollution_threshold, then z = 1
model.addConstr(total_pollution <= pollution_threshold + M * z, "pollution_threshold_upper")
model.addConstr(total_pollution >= pollution_threshold + 0.01 - M * (1 - z), "pollution_threshold_lower")

# Objective: minimize total cost
# Total cost = variable trip costs + fixed costs + pollution penalty + permit fee
variable_costs = horse_cost * x_horse + bike_cost * x_bike + cart_cost * x_cart
fixed_costs = horse_fixed * use_horse + bike_fixed * use_bike + cart_fixed * use_cart
pollution_costs = pollution_penalty * total_pollution
permit_costs = permit_fee * z

total_cost = variable_costs + fixed_costs + pollution_costs + permit_costs

model.setObjective(total_cost, GRB.MINIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
