import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

# Load data
table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'table_1.csv')
params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')

df = pd.read_csv(table_1_path)
params = pd.read_csv(params_path)

# Extract parameters
budget = float(params[params['Parameter_Name'] == 'budget']['Value'].iloc[0])
food_intake = float(params[params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
weekday_budget_share = float(params[params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
max_prep_time_weekday = float(params[params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
max_prep_time_weekend = float(params[params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
weekend_protein_ban = int(params[params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
veg_balance_penalty = float(params[params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])

# Fill missing fiber content with 0
df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)

foods = df['Food'].tolist()
types = df.set_index('Food')['Type'].to_dict()
fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
price = df.set_index('Food')['Price_per_100g'].to_dict()
prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()

proteins = [f for f in foods if types[f] == 'protein']
vegetables = [f for f in foods if types[f] == 'vegetable']

# Create model
model = gp.Model("Revised_Fiber_Maximization")
model.setParam('OutputFlag', 0)

# Decision variables
# x[f, s]: amount of food f in scenario s (in 100g units)
# y[f, s]: binary indicator if food f is used in scenario s
# z[f]: binary indicator if food f is purchased (shared shopping logic)
scenarios = ['weekday', 'weekend']
x = {}
y = {}
for f in foods:
    for s in scenarios:
        x[f, s] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f'x_{f}_{s}')
        y[f, s] = model.addVar(vtype=GRB.BINARY, name=f'y_{f}_{s}')

z = {}
for f in foods:
    z[f] = model.addVar(vtype=GRB.BINARY, name=f'z_{f}')

# Auxiliary variables for vegetable balance penalty
veg_dev_pos = {}
veg_dev_neg = {}
for v in vegetables:
    veg_dev_pos[v] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f'veg_dev_pos_{v}')
    veg_dev_neg[v] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f'veg_dev_neg_{v}')

model.update()

# Objective: maximize total fiber minus vegetable balance penalty
total_fiber = gp.quicksum(fiber[f] * x[f, s] for f in foods for s in scenarios)
penalty = veg_balance_penalty * gp.quicksum(veg_dev_pos[v] + veg_dev_neg[v] for v in vegetables)
model.setObjective(total_fiber - penalty, GRB.MAXIMIZE)

# Constraints

# Total food intake per scenario (converted to 100g units)
for s in scenarios:
    model.addConstr(gp.quicksum(x[f, s] for f in foods) == food_intake / 100.0, name=f'food_intake_{s}')

# Budget constraints
weekday_budget = budget * weekday_budget_share
weekend_budget = budget * (1 - weekday_budget_share)
model.addConstr(gp.quicksum(price[f] * x[f, 'weekday'] for f in foods) <= weekday_budget, name='budget_weekday')
model.addConstr(gp.quicksum(price[f] * x[f, 'weekend'] for f in foods) <= weekend_budget, name='budget_weekend')

# Prep time constraints
model.addConstr(gp.quicksum(prep_time[f] * x[f, 'weekday'] for f in foods) <= max_prep_time_weekday, name='prep_time_weekday')
model.addConstr(gp.quicksum(prep_time[f] * x[f, 'weekend'] for f in foods) <= max_prep_time_weekend, name='prep_time_weekend')

# Exactly one protein source per scenario
for s in scenarios:
    model.addConstr(gp.quicksum(y[f, s] for f in proteins) == 1, name=f'one_protein_{s}')

# At least two kinds of vegetables per scenario
for s in scenarios:
    model.addConstr(gp.quicksum(y[f, s] for f in vegetables) >= 2, name=f'min_vegetables_{s}')

# Linking constraints between x and y (minimum inclusion amount = 10g = 0.1 units of 100g)
M = food_intake / 100.0
for f in foods:
    for s in scenarios:
        model.addConstr(x[f, s] >= 0.1 * y[f, s], name=f'min_amount_{f}_{s}')
        model.addConstr(x[f, s] <= M * y[f, s], name=f'max_amount_{f}_{s}')

# Shared shopping logic: z[f] = 1 if food f is used in at least one scenario
for f in foods:
    model.addConstr(z[f] >= y[f, 'weekday'], name=f'shopping_weekday_{f}')
    model.addConstr(z[f] >= y[f, 'weekend'], name=f'shopping_weekend_{f}')
    model.addConstr(z[f] <= y[f, 'weekday'] + y[f, 'weekend'], name=f'shopping_both_{f}')

# Weekend protein ban
if weekend_protein_ban == 1:
    for p in proteins:
        model.addConstr(y[p, 'weekend'] == 0, name=f'ban_protein_weekend_{p}')

# Vegetable balance penalty constraints
for v in vegetables:
    model.addConstr(x[v, 'weekday'] - x[v, 'weekend'] == veg_dev_pos[v] - veg_dev_neg[v], name=f'veg_balance_{v}')

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {round(model.objVal, 4)}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
