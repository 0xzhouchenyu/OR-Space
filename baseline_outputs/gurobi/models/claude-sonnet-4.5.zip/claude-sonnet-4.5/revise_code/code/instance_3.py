import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.dirname(os.path.abspath(__file__))

# Load demand forecast
demand = {}
with open(os.path.join(base_dir, 'data', 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for i, row in enumerate(reader):
        demand[i] = float(row['Demand_Forecast'])

T = len(demand)  # 6 months

# Load general parameters
params = {}
with open(os.path.join(base_dir, 'data', 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

W0 = int(params['initial_workforce'])
I0 = params['initial_inventory']
sp = params['sales_price']
rmc = params['raw_material_cost']
oc = params['outsourcing_cost']
hc = params['inventory_holding_cost']
bc = params['backorder_cost']
lr = params['labor_requirement']
rh = params['regular_labor_hours']
rw = params['regular_wage']
otl = params['overtime_hours_limit']
ow = params['overtime_wage']
hire_cost = params['hiring_cost']
fire_cost = params['firing_cost']
term_inv = params['terminal_inventory']
term_bo = params['terminal_backorders']
contract_min = params['contract_min_units']
contract_bigM = params['contract_bigM']

# Create model
model = gp.Model("FoldableTableProduction")
model.setParam('OutputFlag', 0)

# Decision variables
W = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="W")  # workforce
H = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="H")  # hired
F = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="F")  # fired
P = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="P")  # in-house production
P_reg = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="P_reg")  # regular-time production
P_ot = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="P_ot")  # overtime production
OT_total = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="OT")  # total overtime hours
O = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="O")  # outsourced units
Inv = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="Inv")  # inventory
B = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="B")  # backorders

# Binary indicators for contract months (April=3, May=4, June=5)
z = model.addVars(T, vtype=GRB.BINARY, name="z")

# Auxiliary variable for contract-qualified production
Q = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="Q")  # contract-qualified production

# Constraints
for t in range(T):
    # Workforce balance
    if t == 0:
        model.addConstr(W[t] == W0 + H[t] - F[t])
    else:
        model.addConstr(W[t] == W[t-1] + H[t] - F[t])
    
    # Production split: total = regular + overtime
    model.addConstr(P[t] == P_reg[t] + P_ot[t])
    
    # Regular-time production limited by regular hours
    model.addConstr(P_reg[t] * lr <= W[t] * rh)
    
    # Overtime production limited by overtime hours
    model.addConstr(P_ot[t] * lr <= OT_total[t])
    
    # Overtime limit
    model.addConstr(OT_total[t] <= W[t] * otl)
    
    # Inventory balance: Inv[t] - B[t] = (Inv[t-1] - B[t-1]) + P[t] + O[t] - demand[t]
    prev_inv = I0 if t == 0 else Inv[t-1]
    prev_b = 0 if t == 0 else B[t-1]
    model.addConstr(Inv[t] - B[t] == prev_inv - prev_b + P[t] + O[t] - demand[t])

# Contract constraints for April (t=3), May (t=4), June (t=5)
for t in range(3, 6):
    # Net demand for month t = demand[t] + B[t-1]
    prev_b = 0 if t == 0 else B[t-1]
    net_demand = demand[t] + prev_b
    
    # Q[t] is the contract-qualified production
    # Q[t] <= P_reg[t] (cannot exceed regular-time production)
    model.addConstr(Q[t] <= P_reg[t])
    
    # Q[t] <= net_demand (cannot exceed what's needed)
    model.addConstr(Q[t] <= net_demand)
    
    # Binary indicator logic: if z[t] = 1, then Q[t] >= contract_min
    # Q[t] >= contract_min - contract_bigM * (1 - z[t])
    model.addConstr(Q[t] >= contract_min - contract_bigM * (1 - z[t]))
    
    # Q[t] <= contract_bigM * z[t]
    model.addConstr(Q[t] <= contract_bigM * z[t])
    
    # Force z[t] = 1 to satisfy contract
    model.addConstr(z[t] == 1)

# Terminal conditions
model.addConstr(Inv[T-1] >= term_inv)
model.addConstr(B[T-1] <= term_bo)

# Objective: maximize net profit
total_demand = sum(demand[t] for t in range(T))
revenue = sp * total_demand

material_cost = gp.quicksum(rmc * P[t] for t in range(T))
outsource_cost = gp.quicksum(oc * O[t] for t in range(T))
holding_cost = gp.quicksum(hc * Inv[t] for t in range(T))
backorder_cost_total = gp.quicksum(bc * B[t] for t in range(T))
regular_labor_cost = gp.quicksum(rw * rh * W[t] for t in range(T))
overtime_cost = gp.quicksum(ow * OT_total[t] for t in range(T))
hiring_cost_total = gp.quicksum(hire_cost * H[t] for t in range(T))
firing_cost_total = gp.quicksum(fire_cost * F[t] for t in range(T))

total_cost = (material_cost + outsource_cost + holding_cost + backorder_cost_total +
              regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total)

model.setObjective(revenue - total_cost, GRB.MAXIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
