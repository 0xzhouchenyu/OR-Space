import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

initial_fund = params['initial_fund']
annual_rate = params['annual_profit_rate'] / 100
inv_limit_y1 = params['investment_limit_year1']
return_rate_y1y2 = params['return_rate_year1_to_year2'] / 100
inv_limit_y2 = params['investment_limit_year2']
return_rate_y2y3 = params['return_rate_year2_to_year3'] / 100
inv_limit_y3 = params['investment_limit_year3']
profit_rate_y3 = params['profit_rate_year3'] / 100
fee_year1 = params['fee_year1']
fee_year2 = params['fee_year2']
fee_year3 = params['fee_year3']

# Create model
model = gp.Model("Investment_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
# Continuous: investment amounts
a1 = model.addVar(lb=0, name="a1")
a2 = model.addVar(lb=0, name="a2")
a3 = model.addVar(lb=0, name="a3")
b1 = model.addVar(lb=0, ub=inv_limit_y1, name="b1")
c2 = model.addVar(lb=0, ub=inv_limit_y2, name="c2")
d3 = model.addVar(lb=0, ub=inv_limit_y3, name="d3")

# Binary: whether special investment is used
use_b1 = model.addVar(vtype=GRB.BINARY, name="use_b1")
use_c2 = model.addVar(vtype=GRB.BINARY, name="use_c2")
use_d3 = model.addVar(vtype=GRB.BINARY, name="use_d3")

# Link binary variables to continuous variables
# If b1 > 0, then use_b1 = 1
model.addConstr(b1 <= inv_limit_y1 * use_b1, "link_b1")
# If c2 > 0, then use_c2 = 1
model.addConstr(c2 <= inv_limit_y2 * use_c2, "link_c2")
# If d3 > 0, then use_d3 = 1
model.addConstr(d3 <= inv_limit_y3 * use_d3, "link_d3")

# Budget constraint at beginning of Year 1
model.addConstr(a1 + b1 <= initial_fund, "Year1_budget")

# Budget constraint at beginning of Year 2
# Available: leftover cash + a1 return
# Leftover cash from year 1: initial_fund - a1 - b1
# Return from a1: a1 * (1 + annual_rate)
# Fee for b1 is paid at year 1 if used
model.addConstr(a2 + c2 <= (initial_fund - a1 - b1 - fee_year1 * use_b1) + a1 * (1 + annual_rate), "Year2_budget")

# Budget constraint at beginning of Year 3
# Available: leftover cash from year 2 + a2 return + b1 return
# Leftover cash from year 2: (initial_fund - a1 - b1 - fee_year1*use_b1) + a1*(1+annual_rate) - a2 - c2 - fee_year2*use_c2
# Return from a2: a2 * (1 + annual_rate)
# Return from b1: b1 * return_rate_y1y2
model.addConstr(
    a3 + d3 <= (initial_fund - a1 - b1 - fee_year1 * use_b1) + a1 * (1 + annual_rate) - a2 - c2 - fee_year2 * use_c2 + a2 * (1 + annual_rate) + b1 * return_rate_y1y2,
    "Year3_budget"
)

# Objective: total funds at end of year 3 (net of all fees)
# Cash leftover from year 3 + returns from a3, c2, d3
# Leftover cash from year 3: 
#   (initial_fund - a1 - b1 - fee_year1*use_b1) + a1*(1+annual_rate) - a2 - c2 - fee_year2*use_c2 + a2*(1+annual_rate) + b1*return_rate_y1y2 - a3 - d3 - fee_year3*use_d3
cash_year3 = (
    initial_fund - a1 - b1 - fee_year1 * use_b1 
    + a1 * (1 + annual_rate) 
    - a2 - c2 - fee_year2 * use_c2 
    + a2 * (1 + annual_rate) 
    + b1 * return_rate_y1y2 
    - a3 - d3 - fee_year3 * use_d3
)

total_end = cash_year3 + a3 * (1 + annual_rate) + c2 * return_rate_y2y3 + d3 * (1 + profit_rate_y3)

model.setObjective(total_end, GRB.MAXIMIZE)

# Solve
model.optimize()

# Print result
print(f"FINAL_OBJ_VALUE: {model.objVal}")
