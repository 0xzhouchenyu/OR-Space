import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data = {}
    
    # Load general_parameters.csv
    filepath = os.path.join(base_dir, 'data', 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data[row['Parameter_Name']] = float(row['Value'])
    
    # Load table_1_7.csv
    filepath = os.path.join(base_dir, 'data', 'table_1_7.csv')
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        rows = list(reader)
        data['table'] = rows
    
    return data

def main():
    data = load_data()
    
    # Extract parameters from general_parameters
    setup_cost_A = data['SetupCost_A']
    setup_cost_B = data['SetupCost_B']
    setup_cost_C = data['SetupCost_C']
    shared_wrapper_fee = data['BrandAB_SharedWrapper_Fee']
    
    # Extract parameters from table_1_7
    raw_cost = [2.00, 1.50, 1.00]
    limits = [2000, 2500, 1200]
    proc_fee = [0.50, 0.40, 0.30]
    sell_price = [3.40, 2.85, 2.25]
    
    # Create model
    model = gp.Model("CandyFactory_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i, j]: amount of raw material i in brand j (i, j = 0, 1, 2)
    x = {}
    for i in range(3):
        for j in range(3):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    # y[j]: binary variable indicating if brand j is produced
    y = {}
    for j in range(3):
        y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")
    
    # z: binary variable indicating if both brands A and B are produced
    z = model.addVar(vtype=GRB.BINARY, name="z_AB_both")
    
    # Total production of each brand
    prod = {}
    for j in range(3):
        prod[j] = gp.quicksum(x[i, j] for i in range(3))
    
    # Objective: maximize profit
    revenue = gp.quicksum(sell_price[j] * prod[j] for j in range(3))
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(proc_fee[j] * prod[j] for j in range(3))
    setup_costs = setup_cost_A * y[0] + setup_cost_B * y[1] + setup_cost_C * y[2]
    wrapper_cost = shared_wrapper_fee * z
    
    model.setObjective(revenue - material_cost - processing_cost - setup_costs - wrapper_cost, GRB.MAXIMIZE)
    
    # Raw material supply constraints
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= limits[i], name=f"supply_{i}")
    
    # Composition constraints
    # Raw material A (i=0): >=60% in brand A (j=0), >=15% in brand B (j=1)
    model.addConstr(x[0, 0] >= 0.60 * prod[0], name="comp_A_in_A")
    model.addConstr(x[0, 1] >= 0.15 * prod[1], name="comp_A_in_B")
    
    # Raw material C (i=2): <=20% in brand A, <=60% in brand B, <=50% in brand C
    model.addConstr(x[2, 0] <= 0.20 * prod[0], name="comp_C_in_A")
    model.addConstr(x[2, 1] <= 0.60 * prod[1], name="comp_C_in_B")
    model.addConstr(x[2, 2] <= 0.50 * prod[2], name="comp_C_in_C")
    
    # Big-M constraints to link production to binary variables
    M = 10000  # Large enough constant
    for j in range(3):
        model.addConstr(prod[j] <= M * y[j], name=f"link_prod_{j}")
    
    # Constraint for shared wrapper: z = 1 if and only if both y[0] and y[1] are 1
    model.addConstr(z >= y[0] + y[1] - 1, name="wrapper_lb")
    model.addConstr(z <= y[0], name="wrapper_ub1")
    model.addConstr(z <= y[1], name="wrapper_ub2")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_value = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_value:.1f}")
    else:
        print(f"FINAL_OBJ_VALUE: 0.0")

if __name__ == "__main__":
    main()
