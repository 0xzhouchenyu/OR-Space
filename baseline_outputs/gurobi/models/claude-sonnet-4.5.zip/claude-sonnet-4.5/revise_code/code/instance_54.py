import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Get script directory and data directory
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load table_1.csv
table_1_path = os.path.join(data_dir, "table_1.csv")
equipment_names = []
products = []
processing_times = {}
effective_hours = {}
base_profit = {}

with open(table_1_path, 'r') as f:
    reader = csv.reader(f)
    header = next(reader)
    products = header[1:-1]
    
    for row in reader:
        if row[0].startswith('Unit_Product_Profit'):
            for j, prod in enumerate(products):
                base_profit[prod] = float(row[j + 1])
        else:
            equip = row[0]
            equipment_names.append(equip)
            effective_hours[equip] = float(row[-1])
            for j, prod in enumerate(products):
                processing_times[(equip, prod)] = float(row[j + 1])

# Load general_parameters.csv
general_params_path = os.path.join(data_dir, "general_parameters.csv")
params = {}
with open(general_params_path, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

overtime_hours_cap = params['overtime_hours_cap']
overtime_cost_multiplier = params['overtime_cost_multiplier']
min_prod = {
    'I': params['min_prod_I'],
    'II': params['min_prod_II'],
    'III': params['min_prod_III']
}

# Compute costs
regular_cost = {p: base_profit[p] for p in products}
overtime_cost = {p: overtime_cost_multiplier * base_profit[p] for p in products}

# Create Gurobi model
model = gp.Model("Factory_Production_Optimization_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
x_reg = {p: model.addVar(lb=0, name=f"x_reg_{p}") for p in products}
x_ot = {p: model.addVar(lb=0, name=f"x_ot_{p}") for p in products}

# Objective: minimize total production cost
total_cost = gp.quicksum(regular_cost[p] * x_reg[p] + overtime_cost[p] * x_ot[p] for p in products)
model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints: equipment capacity (both regular and overtime share the same equipment hours)
for equip in equipment_names:
    model.addConstr(
        gp.quicksum(processing_times[(equip, p)] * (x_reg[p] + x_ot[p]) for p in products) <= effective_hours[equip],
        name=f"Equipment_{equip}_capacity"
    )

# Constraint: total overtime hours cap
total_overtime_hours = gp.quicksum(
    processing_times[(equip, p)] * x_ot[p]
    for equip in equipment_names
    for p in products
)
model.addConstr(total_overtime_hours <= overtime_hours_cap, name="Overtime_hours_cap")

# Constraints: minimum production requirements
for p in products:
    model.addConstr(x_reg[p] + x_ot[p] >= min_prod[p], name=f"Min_prod_{p}")

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
