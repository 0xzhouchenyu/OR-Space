import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    product_units = params['product_units']
    truck_pollution = params['truck_pollution']
    van_pollution = params['van_pollution']
    motorcycle_pollution = params['motorcycle_pollution']
    ev_pollution = params['electric_vehicle_pollution']
    max_total_pollution = params['max_total_pollution']
    min_truck_trips = params['min_truck_trips']
    truck_capacity = params['truck_capacity']
    van_capacity = params['van_capacity']
    motorcycle_capacity = params['motorcycle_capacity']
    ev_capacity = params['electric_vehicle_capacity']
    
    sales_point_share_sp1 = params['sales_point_share_sp1']
    sales_point_share_sp2 = params['sales_point_share_sp2']
    sales_point_share_sp3 = params['sales_point_share_sp3']
    
    min_truck_share_sp1 = params['min_truck_share_sp1']
    min_truck_share_sp2 = params['min_truck_share_sp2']
    min_truck_share_sp3 = params['min_truck_share_sp3']
    
    M_truck_sp_day = params['M_truck_sp_day']
    M_ev_sp_day = params['M_ev_sp_day']
    M_van_sp_day = params['M_van_sp_day']
    M_moto_sp_day = params['M_moto_sp_day']
    
    # Calculate demand per sales point
    demand_sp1 = product_units * sales_point_share_sp1
    demand_sp2 = product_units * sales_point_share_sp2
    demand_sp3 = product_units * sales_point_share_sp3
    
    sales_points = ['sp1', 'sp2', 'sp3']
    days = ['day1', 'day2', 'day3']
    vehicles = ['truck', 'van', 'motorcycle', 'ev']
    
    demand = {'sp1': demand_sp1, 'sp2': demand_sp2, 'sp3': demand_sp3}
    min_truck_share = {'sp1': min_truck_share_sp1, 'sp2': min_truck_share_sp2, 'sp3': min_truck_share_sp3}
    
    pollution = {'truck': truck_pollution, 'van': van_pollution, 'motorcycle': motorcycle_pollution, 'ev': ev_pollution}
    capacity = {'truck': truck_capacity, 'van': van_capacity, 'motorcycle': motorcycle_capacity, 'ev': ev_capacity}
    
    # Create model
    model = gp.Model("Transportation_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of trips for each vehicle, sales point, and day
    x = {}
    for sp in sales_points:
        for day in days:
            for v in vehicles:
                x[sp, day, v] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{sp}_{day}_{v}")
    
    # Binary variables for mode selection per sales point-day
    # y[sp, day, 'heavy'] = 1 if truck/ev family is used on that sp-day
    # y[sp, day, 'light'] = 1 if van/motorcycle family is used on that sp-day
    y = {}
    for sp in sales_points:
        for day in days:
            y[sp, day, 'heavy'] = model.addVar(vtype=GRB.BINARY, name=f"y_{sp}_{day}_heavy")
            y[sp, day, 'light'] = model.addVar(vtype=GRB.BINARY, name=f"y_{sp}_{day}_light")
    
    model.update()
    
    # Objective: minimize total pollution
    obj = gp.quicksum(pollution[v] * x[sp, day, v] 
                      for sp in sales_points 
                      for day in days 
                      for v in vehicles)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraint: each sales point must receive its demand across all days
    for sp in sales_points:
        model.addConstr(
            gp.quicksum(capacity[v] * x[sp, day, v] 
                       for day in days 
                       for v in vehicles) >= demand[sp],
            name=f"demand_{sp}"
        )
    
    # Constraint: total pollution must not exceed maximum
    model.addConstr(
        gp.quicksum(pollution[v] * x[sp, day, v] 
                   for sp in sales_points 
                   for day in days 
                   for v in vehicles) <= max_total_pollution,
        name="max_pollution"
    )
    
    # Constraint: minimum total truck trips across all sales points and days
    model.addConstr(
        gp.quicksum(x[sp, day, 'truck'] 
                   for sp in sales_points 
                   for day in days) >= min_truck_trips,
        name="min_truck_trips"
    )
    
    # Constraint: minimum truck share per sales point
    for sp in sales_points:
        total_trips = gp.quicksum(x[sp, day, v] 
                                 for day in days 
                                 for v in vehicles)
        truck_trips = gp.quicksum(x[sp, day, 'truck'] 
                                 for day in days)
        model.addConstr(truck_trips >= min_truck_share[sp] * total_trips, 
                       name=f"min_truck_share_{sp}")
    
    # Constraint: mode selection per sales point-day
    # On each sp-day, either heavy (truck/ev) or light (van/motorcycle) family is used
    for sp in sales_points:
        for day in days:
            # Exactly one family must be selected
            model.addConstr(y[sp, day, 'heavy'] + y[sp, day, 'light'] == 1, 
                           name=f"mode_select_{sp}_{day}")
            
            # If heavy family is selected, truck and ev can be used
            model.addConstr(x[sp, day, 'truck'] <= M_truck_sp_day * y[sp, day, 'heavy'], 
                           name=f"truck_mode_{sp}_{day}")
            model.addConstr(x[sp, day, 'ev'] <= M_ev_sp_day * y[sp, day, 'heavy'], 
                           name=f"ev_mode_{sp}_{day}")
            
            # If light family is selected, van and motorcycle can be used
            model.addConstr(x[sp, day, 'van'] <= M_van_sp_day * y[sp, day, 'light'], 
                           name=f"van_mode_{sp}_{day}")
            model.addConstr(x[sp, day, 'motorcycle'] <= M_moto_sp_day * y[sp, day, 'light'], 
                           name=f"moto_mode_{sp}_{day}")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
