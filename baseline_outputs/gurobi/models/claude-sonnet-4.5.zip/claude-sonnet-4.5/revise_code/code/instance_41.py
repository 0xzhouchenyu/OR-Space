import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load general parameters
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Parameter_Name'].strip() == 'initial_capital':
            initial_capital = float(row['Value'].strip())

# Load liquidity policy parameters
with open(os.path.join(data_dir, 'liquidity_policy.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Parameter_Name'].strip() == 'min_year3_reserve':
            min_year3_reserve = float(row['Value'].strip())
        elif row['Parameter_Name'].strip() == 'reserve_shortfall_penalty':
            reserve_shortfall_penalty = float(row['Value'].strip())

# Load project data
projects = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        projects.append(row)

# Create Gurobi model
model = gp.Model("Investment_Maximization_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
# x1_1: amount invested in Project 1 at beginning of Year 1
# x1_2: amount invested in Project 1 at beginning of Year 2
# x1_3: amount invested in Project 1 at beginning of Year 3
# x2: amount invested in Project 2 at beginning of Year 1
# x3: amount invested in Project 3 at beginning of Year 2
# x4: amount invested in Project 4 at beginning of Year 3
# reserve: amount held as reserve at beginning of Year 3 (not invested)
# shortfall: shortfall below min_year3_reserve

x1_1 = model.addVar(lb=0, name="x1_1")
x1_2 = model.addVar(lb=0, name="x1_2")
x1_3 = model.addVar(lb=0, name="x1_3")
x2 = model.addVar(lb=0, ub=120000, name="x2")
x3 = model.addVar(lb=0, ub=150000, name="x3")
x4 = model.addVar(lb=0, ub=100000, name="x4")
reserve = model.addVar(lb=0, name="reserve")
shortfall = model.addVar(lb=0, name="shortfall")

# Year 1 budget constraint
model.addConstr(x1_1 + x2 <= initial_capital, "Year1_Budget")

# Year 2 budget constraint
# Available at beginning of Year 2: x1_1 * 1.20 (Project 1 invested in Year 1 matures same year)
model.addConstr(x1_2 + x3 <= x1_1 * 1.20, "Year2_Budget")

# Year 3 budget constraint
# Available at beginning of Year 3: x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60
# This must be split into: reserve + x1_3 + x4
cash_at_year3_start = x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60
model.addConstr(reserve + x1_3 + x4 == cash_at_year3_start, "Year3_Budget")

# Shortfall constraint
# shortfall = max(0, min_year3_reserve - reserve)
model.addConstr(shortfall >= min_year3_reserve - reserve, "Shortfall_Definition")

# Objective: total money at end of Year 3 minus penalty for reserve shortfall
# At end of Year 3:
# - x1_3 matures: x1_3 * 1.20
# - x4 matures: x4 * 1.40
# - reserve remains as cash: reserve
# Penalty: shortfall * reserve_shortfall_penalty
total_end_year3 = x1_3 * 1.20 + x4 * 1.40 + reserve
objective = total_end_year3 - shortfall * reserve_shortfall_penalty

model.setObjective(objective, GRB.MAXIMIZE)

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
