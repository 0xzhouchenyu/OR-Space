import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
shirts_inventory = params['shirts_inventory']
pants_inventory = params['pants_inventory']
price_a = params['package_a_price']
price_b = params['package_b_price']
price_c = params['package_c_price']
shirts_a = params['package_a_shirts']
pants_a = params['package_a_pants']
shirts_b = params['package_b_shirts']
pants_b = params['package_b_pants']
shirts_c = params['package_c_shirts']
pants_c = params['package_c_pants']
min_a = params['min_campaign_batch_a']
min_b = params['min_campaign_batch_b']
min_c = params['min_campaign_batch_c']
activation_cost_a = params['activation_cost_a']
activation_cost_b = params['activation_cost_b']
activation_cost_c = params['activation_cost_c']
labor_hours_per_A = params['labor_hours_per_A']
labor_hours_per_B = params['labor_hours_per_B']
labor_hours_per_C = params['labor_hours_per_C']
labor_hours_total = params['labor_hours_total']
bigM_a = params['bigM_a']
bigM_b = params['bigM_b']
bigM_c = params['bigM_c']
package_b_review_threshold = params['package_b_review_threshold']
package_b_review_charge = params['package_b_review_charge']
package_c_review_threshold = params['package_c_review_threshold']
package_c_review_charge = params['package_c_review_charge']

# Create the model
model = gp.Model("Maximize_Revenue")
model.setParam('OutputFlag', 0)

# Decision variables
x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_A")
x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_B")
x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_C")

# Binary variables for campaign activation
y_a = model.addVar(vtype=GRB.BINARY, name="Activate_A")
y_b = model.addVar(vtype=GRB.BINARY, name="Activate_B")
y_c = model.addVar(vtype=GRB.BINARY, name="Activate_C")

# Binary variables for review charges (gate logic)
z_b = model.addVar(vtype=GRB.BINARY, name="Review_B")
z_c = model.addVar(vtype=GRB.BINARY, name="Review_C")

# Objective: maximize revenue minus costs
revenue = price_a * x_a + price_b * x_b + price_c * x_c
activation_costs = activation_cost_a * y_a + activation_cost_b * y_b + activation_cost_c * y_c
review_costs = package_b_review_charge * z_b + package_c_review_charge * z_c

model.setObjective(revenue - activation_costs - review_costs, GRB.MAXIMIZE)

# Constraints
# Inventory constraints
model.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inventory, "Shirts_Inventory")
model.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inventory, "Pants_Inventory")

# Labor constraint
model.addConstr(labor_hours_per_A * x_a + labor_hours_per_B * x_b + labor_hours_per_C * x_c <= labor_hours_total, "Labor_Hours")

# Minimum sales requirements (only if campaign is activated)
model.addConstr(x_a >= min_a * y_a, "Min_Package_A")
model.addConstr(x_b >= min_b * y_b, "Min_Package_B")
model.addConstr(x_c >= min_c * y_c, "Min_Package_C")

# Link x to y (if x > 0, then y = 1)
model.addConstr(x_a <= bigM_a * y_a, "Link_A")
model.addConstr(x_b <= bigM_b * y_b, "Link_B")
model.addConstr(x_c <= bigM_c * y_c, "Link_C")

# Review charge gate logic for Package B
# z_b = 1 if x_b > package_b_review_threshold, else z_b = 0
model.addConstr(x_b <= package_b_review_threshold + bigM_b * z_b, "Review_B_Upper")
model.addConstr(x_b >= package_b_review_threshold + 1 - bigM_b * (1 - z_b), "Review_B_Lower")

# Review charge gate logic for Package C
# z_c = 1 if x_c > package_c_review_threshold, else z_c = 0
model.addConstr(x_c <= package_c_review_threshold + bigM_c * z_c, "Review_C_Upper")
model.addConstr(x_c >= package_c_review_threshold + 1 - bigM_c * (1 - z_c), "Review_C_Lower")

# Solve
model.optimize()

# Output results
if model.status == GRB.OPTIMAL:
    objective_value = model.objVal
    print(f"FINAL_OBJ_VALUE: {objective_value}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
