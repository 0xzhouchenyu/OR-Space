import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
m1_liquid = params['machine_1_time_per_liquid_lot']
m2_liquid = params['machine_2_time_per_liquid_lot']
m1_solid = params['machine_1_time_per_solid_lot']
m2_solid = params['machine_2_time_per_solid_lot']

init_liquid = params['initial_liquid_inventory']
init_solid = params['initial_solid_inventory']

m1_base = params['machine_1_available_time'] * 60  # minutes
m2_base = params['machine_2_available_time'] * 60  # minutes

demand_liquid = params['forecast_liquid_demand']
demand_solid = params['forecast_solid_demand']

extended_extra_minutes = params['extended_extra_minutes']
labor_hours_per_machine_extended = params['labor_hours_per_machine_extended']
labor_budget_hours = params['labor_budget_hours']
extended_mode_penalty = params['extended_mode_penalty']
priority_reserve_lots = params['priority_reserve_lots']
excess_reserve_credit = params['excess_reserve_credit']

# Create model
model = gp.Model("Fertilizer_Production_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
x_l = model.addVar(lb=0, name="x_liquid")
x_s = model.addVar(lb=0, name="x_solid")

# Binary variables for extended mode
ext_m1 = model.addVar(vtype=GRB.BINARY, name="ext_m1")
ext_m2 = model.addVar(vtype=GRB.BINARY, name="ext_m2")

# Ending inventories
end_liquid = init_liquid + x_l - demand_liquid
end_solid = init_solid + x_s - demand_solid

# Priority reserve variables (min of ending inventory and priority_reserve_lots)
priority_liquid = model.addVar(lb=0, ub=priority_reserve_lots, name="priority_liquid")
priority_solid = model.addVar(lb=0, ub=priority_reserve_lots, name="priority_solid")

# Excess reserve variables (inventory above priority band)
excess_liquid = model.addVar(lb=0, name="excess_liquid")
excess_solid = model.addVar(lb=0, name="excess_solid")

# Constraints for priority and excess calculation
model.addConstr(priority_liquid <= end_liquid, "priority_liquid_upper")
model.addConstr(excess_liquid == end_liquid - priority_liquid, "excess_liquid_def")
model.addConstr(priority_solid <= end_solid, "priority_solid_upper")
model.addConstr(excess_solid == end_solid - priority_solid, "excess_solid_def")

# Machine capacity constraints with extended mode
m1_capacity = m1_base + ext_m1 * extended_extra_minutes
m2_capacity = m2_base + ext_m2 * extended_extra_minutes

model.addConstr(m1_liquid * x_l + m1_solid * x_s <= m1_capacity, "Machine_1_Capacity")
model.addConstr(m2_liquid * x_l + m2_solid * x_s <= m2_capacity, "Machine_2_Capacity")

# Labor budget constraint
model.addConstr(labor_hours_per_machine_extended * (ext_m1 + ext_m2) <= labor_budget_hours, "Labor_Budget")

# Demand satisfaction
model.addConstr(end_liquid >= 0, "Liquid_Demand_Satisfaction")
model.addConstr(end_solid >= 0, "Solid_Demand_Satisfaction")

# Objective: resilience score
# Priority reserves count fully, excess counts at excess_reserve_credit rate
# Subtract extended_mode_penalty for each extended machine
resilience_score = (priority_liquid + priority_solid + 
                   excess_reserve_credit * (excess_liquid + excess_solid) -
                   extended_mode_penalty * (ext_m1 + ext_m2))

model.setObjective(resilience_score, GRB.MAXIMIZE)

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val:.6f}")
else:
    print(f"FINAL_OBJ_VALUE: NO_SOLUTION")
