import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    params = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    
    param_dict = dict(zip(params['Parameter_Name'], params['Value']))
    demand = dict(zip(table_1['stage'], table_1['tool_requirement']))
    
    return param_dict, demand

def solve():
    param_dict, demand = load_data()
    
    n = int(param_dict['n'])
    cost_new = float(param_dict['cost_new_tool'])
    cost_slow = float(param_dict['cost_slow_repair'])
    cost_fast = float(param_dict['cost_fast_repair'])
    dur_slow = int(param_dict['slow_repair_duration'])
    dur_fast = int(param_dict['fast_repair_duration'])
    max_fast = float(param_dict['max_fast_stage'])
    max_slow = float(param_dict['max_slow_stage'])
    emission_buy = float(param_dict['emission_buy'])
    emission_fast = float(param_dict['emission_fast_repair'])
    emission_slow = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_shortage = float(param_dict['penalty_shortage'])
    
    model = gp.Model("Tool_Repair_Problem_Revised")
    model.setParam('OutputFlag', 0)
    
    stages = list(range(1, n + 1))
    
    # Decision variables
    x = model.addVars(stages, vtype=GRB.INTEGER, lb=0, name="buy")
    y = model.addVars(stages, vtype=GRB.INTEGER, lb=0, name="fast")
    z = model.addVars(stages, vtype=GRB.INTEGER, lb=0, name="slow")
    c = model.addVars([0] + stages, vtype=GRB.INTEGER, lb=0, name="clean")
    d = model.addVars([0] + stages, vtype=GRB.INTEGER, lb=0, name="dirty")
    s = model.addVars(stages, vtype=GRB.INTEGER, lb=0, name="shortage")
    prebuy_clean = model.addVar(vtype=GRB.INTEGER, lb=0, name="prebuy_clean")
    
    # Initial conditions
    model.addConstr(c[0] == prebuy_clean, name="init_clean")
    model.addConstr(d[0] == 0, name="init_dirty")
    
    # Flow balance constraints for each stage
    for i in stages:
        # Tools ready from fast repair
        fast_ready = y[i - dur_fast - 1] if i - dur_fast - 1 >= 1 else 0
        # Tools ready from slow repair
        slow_ready = z[i - dur_slow - 1] if i - dur_slow - 1 >= 1 else 0
        
        # Clean tool balance: clean[i-1] + new + repaired = used + clean[i]
        # used = demand[i] - shortage[i]
        model.addConstr(
            x[i] + c[i-1] + fast_ready + slow_ready == demand[i] - s[i] + c[i],
            name=f"clean_balance_{i}"
        )
        
        # Dirty tool balance: dirty[i-1] + used = sent_to_repair + dirty[i]
        model.addConstr(
            demand[i] - s[i] + d[i-1] == y[i] + z[i] + d[i],
            name=f"dirty_balance_{i}"
        )
    
    # Stage-wise repair capacity constraints
    for i in stages:
        model.addConstr(y[i] <= max_fast, name=f"max_fast_{i}")
        model.addConstr(z[i] <= max_slow, name=f"max_slow_{i}")
    
    # Carbon budget constraint
    total_emissions = (
        emission_buy * prebuy_clean +
        gp.quicksum(emission_buy * x[i] for i in stages) +
        gp.quicksum(emission_fast * y[i] for i in stages) +
        gp.quicksum(emission_slow * z[i] for i in stages)
    )
    model.addConstr(total_emissions <= carbon_budget, name="carbon_limit")
    
    # Objective: minimize total cost
    total_cost = (
        gp.quicksum(cost_new * x[i] for i in stages) +
        gp.quicksum(cost_fast * y[i] for i in stages) +
        gp.quicksum(cost_slow * z[i] for i in stages) +
        gp.quicksum(penalty_shortage * s[i] for i in stages)
    )
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    solve()
