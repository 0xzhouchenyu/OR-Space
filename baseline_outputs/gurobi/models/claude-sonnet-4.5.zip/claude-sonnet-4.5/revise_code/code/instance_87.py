import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    params = load_parameters(data_path)
    
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    base_a = params['base_fleet_type_a']
    base_b = params['base_fleet_type_b']
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    type_b_threshold = params['type_b_recovery_threshold']
    type_b_fee = params['type_b_recovery_fee']
    total_threshold = params['total_fleet_surge_threshold']
    total_fee = params['total_fleet_surge_fee']
    
    model = gp.Model("TruckRental")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeA_trucks")
    y = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeB_trucks")
    
    # Excess variables
    excess_a = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="excess_a")
    excess_b = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="excess_b")
    
    # Binary indicators for thresholds
    type_b_exceeds = model.addVar(vtype=GRB.BINARY, name="type_b_exceeds")
    total_exceeds = model.addVar(vtype=GRB.BINARY, name="total_exceeds")
    
    model.update()
    
    # Define excess constraints
    model.addConstr(excess_a >= x - base_a, "excess_a_def")
    model.addConstr(excess_b >= y - base_b, "excess_b_def")
    
    # Type B threshold constraint
    M1 = 10000
    model.addConstr(y <= type_b_threshold + M1 * type_b_exceeds, "type_b_threshold_upper")
    model.addConstr(y >= type_b_threshold + 1 - M1 * (1 - type_b_exceeds), "type_b_threshold_lower")
    
    # Total fleet threshold constraint
    M2 = 10000
    model.addConstr(x + y <= total_threshold + M2 * total_exceeds, "total_threshold_upper")
    model.addConstr(x + y >= total_threshold + 1 - M2 * (1 - total_exceeds), "total_threshold_lower")
    
    # Capacity constraints
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedRequirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedRequirement")
    
    # Objective function
    obj = (cost_a * x + cost_b * y + 
           penalty_a * excess_a + penalty_b * excess_b +
           type_b_fee * type_b_exceeds +
           total_fee * total_exceeds)
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
