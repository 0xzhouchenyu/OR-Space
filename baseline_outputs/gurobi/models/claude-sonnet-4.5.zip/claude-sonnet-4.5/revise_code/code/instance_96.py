import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    
    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    # Parse parameters
    params = {}
    for _, row in df_params.iterrows():
        params[row['Parameter_Name']] = row['Value']
    
    # Supplier 1 parameters
    raw_length_s1 = float(params['raw_pipe_length_supplier1'])
    max_patterns_s1 = int(params['max_cutting_patterns_supplier1'])
    max_cuts_s1 = int(params['max_cuts_per_pipe_supplier1'])
    max_leftover_s1 = float(params['max_leftover_length_supplier1'])
    purchase_cost_s1 = float(params['purchase_cost_per_pipe_supplier1'])
    
    # Supplier 2 parameters
    raw_length_s2 = float(params['raw_pipe_length_supplier2'])
    max_patterns_s2 = int(params['max_cutting_patterns_supplier2'])
    max_cuts_s2 = int(params['max_cuts_per_pipe_supplier2'])
    max_leftover_s2 = float(params['max_leftover_length_supplier2'])
    purchase_cost_s2 = float(params['purchase_cost_per_pipe_supplier2'])
    
    # Discount parameters
    discount_tier1_max = float(params['discount_tier1_supplier1_max_qty'])
    fixed_discount_tier2 = float(params['fixed_discount_tier2_supplier1'])
    bigM_discount = float(params['bigM_discount'])
    
    # Cost rates for supplier 1
    cost_rates_s1 = []
    for i, prefix in enumerate(['most', 'second', 'third', 'fourth', 'fifth']):
        key = f"{prefix}_frequent_pattern_cost_rate_supplier1"
        if key in params:
            cost_rates_s1.append(float(params[key]))
        else:
            break
    
    # Cost rates for supplier 2
    cost_rates_s2 = []
    for i, prefix in enumerate(['most', 'second', 'third', 'fourth', 'fifth']):
        key = f"{prefix}_frequent_pattern_cost_rate_supplier2"
        if key in params:
            cost_rates_s2.append(float(params[key]))
        else:
            break
    
    # Customer demands
    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)
    
    # Generate patterns for supplier 1
    patterns_s1 = []
    min_length_s1 = raw_length_s1 - max_leftover_s1
    
    def generate_patterns_s1(current_pattern, current_length, current_cuts, item_idx):
        if item_idx == n_items:
            if current_length >= min_length_s1 and current_length <= raw_length_s1 and current_cuts > 0:
                patterns_s1.append(tuple(current_pattern))
            return
        
        max_qty = min(
            int((raw_length_s1 - current_length) // lengths[item_idx]),
            max_cuts_s1 - current_cuts
        )
        
        for q in range(max_qty + 1):
            generate_patterns_s1(
                current_pattern + [q],
                current_length + q * lengths[item_idx],
                current_cuts + q,
                item_idx + 1
            )
    
    generate_patterns_s1([], 0, 0, 0)
    
    # Generate patterns for supplier 2
    patterns_s2 = []
    min_length_s2 = raw_length_s2 - max_leftover_s2
    
    def generate_patterns_s2(current_pattern, current_length, current_cuts, item_idx):
        if item_idx == n_items:
            if current_length >= min_length_s2 and current_length <= raw_length_s2 and current_cuts > 0:
                patterns_s2.append(tuple(current_pattern))
            return
        
        max_qty = min(
            int((raw_length_s2 - current_length) // lengths[item_idx]),
            max_cuts_s2 - current_cuts
        )
        
        for q in range(max_qty + 1):
            generate_patterns_s2(
                current_pattern + [q],
                current_length + q * lengths[item_idx],
                current_cuts + q,
                item_idx + 1
            )
    
    generate_patterns_s2([], 0, 0, 0)
    
    # Create model
    model = gp.Model("Pipe_Cutting_Two_Suppliers")
    model.setParam('OutputFlag', 0)
    
    # Variables for supplier 1
    y_s1 = model.addVars(len(patterns_s1), vtype=GRB.INTEGER, name="y_s1")
    z_s1 = model.addVars(len(patterns_s1), vtype=GRB.BINARY, name="z_s1")
    u_s1 = model.addVars(range(1, max_patterns_s1 + 1), vtype=GRB.BINARY, name="u_s1")
    
    # Variables for supplier 2
    y_s2 = model.addVars(len(patterns_s2), vtype=GRB.INTEGER, name="y_s2")
    z_s2 = model.addVars(len(patterns_s2), vtype=GRB.BINARY, name="z_s2")
    u_s2 = model.addVars(range(1, max_patterns_s2 + 1), vtype=GRB.BINARY, name="u_s2")
    
    # Discount tier binary variable
    tier2_active = model.addVar(vtype=GRB.BINARY, name="tier2_active")
    
    # Total pipes from each supplier
    total_pipes_s1 = gp.quicksum(y_s1[p] for p in range(len(patterns_s1)))
    total_pipes_s2 = gp.quicksum(y_s2[p] for p in range(len(patterns_s2)))
    
    # Objective: purchase cost + pattern ranking costs - discount
    purchase_cost = purchase_cost_s1 * total_pipes_s1 + purchase_cost_s2 * total_pipes_s2
    
    pattern_cost_s1 = gp.quicksum(cost_rates_s1[k-1] * u_s1[k] for k in range(1, min(max_patterns_s1, len(cost_rates_s1)) + 1))
    pattern_cost_s2 = gp.quicksum(cost_rates_s2[k-1] * u_s2[k] for k in range(1, min(max_patterns_s2, len(cost_rates_s2)) + 1))
    
    discount = fixed_discount_tier2 * tier2_active
    
    model.setObjective(purchase_cost + pattern_cost_s1 + pattern_cost_s2 - discount, GRB.MINIMIZE)
    
    # Demand constraints (combined from both suppliers)
    for i in range(n_items):
        model.addConstr(
            gp.quicksum(patterns_s1[p][i] * y_s1[p] for p in range(len(patterns_s1))) +
            gp.quicksum(patterns_s2[p][i] * y_s2[p] for p in range(len(patterns_s2))) >= demands[i],
            name=f"demand_{i}"
        )
    
    # Pattern activation constraints for supplier 1
    M = sum(demands)
    for p in range(len(patterns_s1)):
        model.addConstr(y_s1[p] <= M * z_s1[p], name=f"activate_s1_{p}")
    
    # Pattern activation constraints for supplier 2
    for p in range(len(patterns_s2)):
        model.addConstr(y_s2[p] <= M * z_s2[p], name=f"activate_s2_{p}")
    
    # Number of active patterns equals sum of u variables for supplier 1
    model.addConstr(
        gp.quicksum(z_s1[p] for p in range(len(patterns_s1))) == gp.quicksum(u_s1[k] for k in range(1, max_patterns_s1 + 1)),
        name="pattern_count_s1"
    )
    
    # Number of active patterns equals sum of u variables for supplier 2
    model.addConstr(
        gp.quicksum(z_s2[p] for p in range(len(patterns_s2))) == gp.quicksum(u_s2[k] for k in range(1, max_patterns_s2 + 1)),
        name="pattern_count_s2"
    )
    
    # Ordering constraints for u variables (supplier 1)
    for k in range(1, max_patterns_s1):
        model.addConstr(u_s1[k] >= u_s1[k+1], name=f"order_s1_{k}")
    
    # Ordering constraints for u variables (supplier 2)
    for k in range(1, max_patterns_s2):
        model.addConstr(u_s2[k] >= u_s2[k+1], name=f"order_s2_{k}")
    
    # Max patterns constraints
    model.addConstr(
        gp.quicksum(z_s1[p] for p in range(len(patterns_s1))) <= max_patterns_s1,
        name="max_patterns_s1"
    )
    
    model.addConstr(
        gp.quicksum(z_s2[p] for p in range(len(patterns_s2))) <= max_patterns_s2,
        name="max_patterns_s2"
    )
    
    # Discount tier constraints
    model.addConstr(total_pipes_s1 <= discount_tier1_max + bigM_discount * tier2_active, name="tier2_lower")
    model.addConstr(total_pipes_s1 >= discount_tier1_max + 1 - bigM_discount * (1 - tier2_active), name="tier2_upper")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    solve()
