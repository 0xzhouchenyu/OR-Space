import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load container data
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            params[param_name] = float(row['Value'])

    fixed_setup_cost = params['fixed_setup_cost']
    energy_cost_per_kwh = params['energy_cost_per_kwh']
    max_total_energy_kwh = params['max_total_energy_kwh']
    eco_capacity_share = params['eco_capacity_share']
    eco_overhead_cost = params['eco_overhead_cost']
    regular_energy_intensity = params['regular_energy_intensity_kwh_per_unit']
    eco_energy_intensity = params['eco_energy_intensity_kwh_per_unit']

    n = len(containers)
    
    # Create the model
    model = gp.Model("PlasticContainersRevised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # y_reg[i] = 1 if container type i is produced in regular mode
    y_reg = model.addVars(n, vtype=GRB.BINARY, name="y_reg")
    
    # y_eco[i] = 1 if container type i is produced in eco mode
    y_eco = model.addVars(n, vtype=GRB.BINARY, name="y_eco")
    
    # x_reg[i,j] = units of type i produced in regular mode to fulfill demand of type j
    x_reg = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x_reg[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_reg_{i}_{j}")
    
    # x_eco[i,j] = units of type i produced in eco mode to fulfill demand of type j
    x_eco = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x_eco[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_eco_{i}_{j}")

    model.update()

    # Objective: minimize total cost
    # Variable production costs
    variable_cost = gp.quicksum(
        containers[i]['cost'] * x_reg[i, j] 
        for (i, j) in x_reg
    ) + gp.quicksum(
        containers[i]['cost'] * x_eco[i, j] 
        for (i, j) in x_eco
    )
    
    # Fixed setup costs
    setup_cost = gp.quicksum(fixed_setup_cost * y_reg[i] for i in range(n)) + \
                 gp.quicksum(fixed_setup_cost * y_eco[i] for i in range(n))
    
    # Eco overhead costs
    eco_overhead = gp.quicksum(eco_overhead_cost * y_eco[i] for i in range(n))
    
    # Energy costs
    energy_cost = energy_cost_per_kwh * (
        regular_energy_intensity * gp.quicksum(x_reg[i, j] for (i, j) in x_reg) +
        eco_energy_intensity * gp.quicksum(x_eco[i, j] for (i, j) in x_eco)
    )
    
    total_cost = variable_cost + setup_cost + eco_overhead + energy_cost
    
    model.setObjective(total_cost, GRB.MINIMIZE)

    # Demand constraints: for each type j, total supplied >= demand[j]
    for j in range(n):
        model.addConstr(
            gp.quicksum(x_reg[i, j] for i in range(n) if (i, j) in x_reg) +
            gp.quicksum(x_eco[i, j] for i in range(n) if (i, j) in x_eco) 
            >= containers[j]['demand'],
            name=f"demand_{j}"
        )

    # Linking constraints for regular mode
    M = sum(c['demand'] for c in containers)
    for i in range(n):
        total_reg_i = gp.quicksum(x_reg[i, j] for j in range(n) if (i, j) in x_reg)
        model.addConstr(total_reg_i <= M * y_reg[i], name=f"setup_reg_{i}")

    # Linking constraints for eco mode
    for i in range(n):
        total_eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(total_eco_i <= M * y_eco[i], name=f"setup_eco_{i}")

    # Eco capacity constraints: eco production <= eco_capacity_share * total production
    for i in range(n):
        total_reg_i = gp.quicksum(x_reg[i, j] for j in range(n) if (i, j) in x_reg)
        total_eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(
            total_eco_i <= eco_capacity_share * (total_reg_i + total_eco_i),
            name=f"eco_capacity_{i}"
        )

    # Energy constraint: total energy consumption <= max_total_energy_kwh
    total_energy = (
        regular_energy_intensity * gp.quicksum(x_reg[i, j] for (i, j) in x_reg) +
        eco_energy_intensity * gp.quicksum(x_eco[i, j] for (i, j) in x_eco)
    )
    model.addConstr(total_energy <= max_total_energy_kwh, name="max_energy")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found (status: {model.status})")

if __name__ == "__main__":
    main()
