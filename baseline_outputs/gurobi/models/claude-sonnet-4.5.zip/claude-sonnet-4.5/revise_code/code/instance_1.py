import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
def load_parameters():
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            try:
                if '.' in val:
                    params[name] = float(val)
                else:
                    params[name] = int(val)
            except ValueError:
                params[name] = val
    return params

# Load demand
def load_demand():
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    demand = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            week = int(row['Week'].strip())
            demand[week] = {
                'I': int(row['I'].strip()),
                'II': int(row['II'].strip())
            }
    return demand

params = load_parameters()
demand = load_demand()

T = 8
weeks = range(1, T + 1)

# Parameters
S0 = params['skilled_worker_count']
rate_I = params['food_I_production_rate']
rate_II = params['food_II_production_rate']
normal_hours = params['worker_weekly_hours']
overtime_hours = params['skilled_worker_overtime_hours']
train_cap = params['training_capacity']
train_period = params['training_period']
wage_skilled = params['skilled_worker_weekly_wage']
wage_trainee_during = params['trainee_weekly_wage_during_training']
wage_trainee_after = params['trainee_weekly_wage_after_training']
wage_overtime = params['skilled_worker_overtime_wage']
comp_I = params['compensation_fee_food_I']
comp_II = params['compensation_fee_food_II']
new_worker_goal = params['new_worker_training_goal']

# Create model
model = gp.Model("factory_training_revised")
model.setParam('OutputFlag', 0)

# Decision variables
# n_train[t] = number of skilled workers assigned to training starting in week t
n_train = {}
for t in weeks:
    if t <= T - 1:
        n_train[t] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_train_{t}")

# Binary variables for which food type to produce in week t
# produce_I[t] = 1 if week t produces food I, 0 otherwise
# produce_II[t] = 1 if week t produces food II, 0 otherwise
produce_I = {t: model.addVar(vtype=GRB.BINARY, name=f"produce_I_{t}") for t in weeks}
produce_II = {t: model.addVar(vtype=GRB.BINARY, name=f"produce_II_{t}") for t in weeks}

# Hours allocated to food I and II by skilled workers (normal and overtime) and graduated trainees
h_I_s = {t: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"hIs_{t}") for t in weeks}
h_II_s = {t: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"hIIs_{t}") for t in weeks}
h_I_ot = {t: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"hIot_{t}") for t in weeks}
h_II_ot = {t: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"hIIot_{t}") for t in weeks}
h_I_g = {t: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"hIg_{t}") for t in weeks}
h_II_g = {t: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"hIIg_{t}") for t in weeks}

# Number of skilled workers doing overtime in week t
n_overtime = {t: model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_ot_{t}") for t in weeks}

# Backlog for food I and II
backlog_I = {t: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"bI_{t}") for t in weeks}
backlog_II = {t: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"bII_{t}") for t in weeks}

model.update()

# Constraints
# Mutual exclusion: can only produce one type of food per week (or idle)
for t in weeks:
    model.addConstr(produce_I[t] + produce_II[t] <= 1, f"mutual_exclusion_{t}")

# Helper functions
def trainers_busy(t):
    expr = gp.LinExpr()
    for s in n_train:
        if s <= t <= s + train_period - 1:
            expr += n_train[s]
    return expr

def graduates_available(t):
    expr = gp.LinExpr()
    for s in n_train:
        if s + train_period <= t:
            expr += train_cap * n_train[s]
    return expr

# Big M for constraints
M = 1e6

for t in weeks:
    busy_t = trainers_busy(t)
    avail_skilled_t = S0 - busy_t
    grads_t = graduates_available(t)
    
    # Ensure enough skilled workers available
    model.addConstr(avail_skilled_t >= 0, f"enough_skilled_{t}")
    
    # Overtime workers must be within available skilled workers
    model.addConstr(n_overtime[t] <= avail_skilled_t, f"ot_limit_{t}")
    
    # Hours constraints for skilled normal workers
    model.addConstr(h_I_s[t] + h_II_s[t] <= (avail_skilled_t - n_overtime[t]) * normal_hours, f"skilled_normal_hours_{t}")
    
    # Hours constraints for overtime workers
    model.addConstr(h_I_ot[t] + h_II_ot[t] <= n_overtime[t] * overtime_hours, f"skilled_ot_hours_{t}")
    
    # Hours constraints for graduates
    model.addConstr(h_I_g[t] + h_II_g[t] <= grads_t * normal_hours, f"grad_hours_{t}")
    
    # Mutual exclusion enforcement: if produce_I[t] = 0, then all Food I hours must be 0
    model.addConstr(h_I_s[t] <= M * produce_I[t], f"enforce_I_s_{t}")
    model.addConstr(h_I_ot[t] <= M * produce_I[t], f"enforce_I_ot_{t}")
    model.addConstr(h_I_g[t] <= M * produce_I[t], f"enforce_I_g_{t}")
    
    # If produce_II[t] = 0, then all Food II hours must be 0
    model.addConstr(h_II_s[t] <= M * produce_II[t], f"enforce_II_s_{t}")
    model.addConstr(h_II_ot[t] <= M * produce_II[t], f"enforce_II_ot_{t}")
    model.addConstr(h_II_g[t] <= M * produce_II[t], f"enforce_II_g_{t}")
    
    # Production in week t
    prod_I_t = (h_I_s[t] + h_I_ot[t] + h_I_g[t]) * rate_I
    prod_II_t = (h_II_s[t] + h_II_ot[t] + h_II_g[t]) * rate_II
    
    # Backlog balance
    prev_bI = backlog_I[t-1] if t > 1 else 0
    prev_bII = backlog_II[t-1] if t > 1 else 0
    
    model.addConstr(backlog_I[t] == prev_bI + demand[t]['I'] - prod_I_t, f"backlog_I_{t}")
    model.addConstr(backlog_II[t] == prev_bII + demand[t]['II'] - prod_II_t, f"backlog_II_{t}")

# Training goal constraint
total_trained = gp.LinExpr()
for s in n_train:
    if s + train_period <= T:
        total_trained += train_cap * n_train[s]
model.addConstr(total_trained >= new_worker_goal, "training_goal")

# Objective: minimize total cost
total_cost = gp.LinExpr()

# Wages
for t in weeks:
    busy_t = trainers_busy(t)
    avail_skilled_t = S0 - busy_t
    grads_t = graduates_available(t)
    
    # Skilled workers (trainers + normal + overtime)
    # Trainers get wage_skilled
    total_cost += busy_t * wage_skilled
    
    # Normal skilled workers get wage_skilled
    total_cost += (avail_skilled_t - n_overtime[t]) * wage_skilled
    
    # Overtime skilled workers get wage_overtime
    total_cost += n_overtime[t] * wage_overtime
    
    # Graduated trainees get wage_trainee_after
    total_cost += grads_t * wage_trainee_after

# Trainee wages during training
for s in n_train:
    num_trainees = train_cap * n_train[s]
    # Trainees in training during weeks s and s+1
    for w in range(s, min(s + train_period, T + 1)):
        total_cost += num_trainees * wage_trainee_during

# Compensation fees
for t in weeks:
    total_cost += backlog_I[t] * comp_I
    total_cost += backlog_II[t] * comp_II

model.setObjective(total_cost, GRB.MINIMIZE)

# Optimize
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: NO_SOLUTION")
