import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = [row for row in reader]
    return headers, rows

def load_general_parameters():
    headers, rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row[0].strip()
        try:
            value = float(row[1].strip())
        except ValueError:
            value = row[1].strip()
        params[name] = value
    return params

def load_crop_data():
    headers, rows = load_csv('table_1.csv')
    crops = [h.strip() for h in headers[1:]]
    data = {}
    for row in rows:
        item = row[0].strip()
        values = [float(v.strip()) for v in row[1:]]
        data[item] = dict(zip(crops, values))
    return crops, data

def main():
    params = load_general_parameters()
    crops, crop_data = load_crop_data()
    
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']
    
    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = params['max_chickens']
    max_dairy_cows = params['max_dairy_cows']
    
    fixed_cost_chicken_setup = params['fixed_cost_chicken_setup']
    min_chickens_if_coop_open = params['min_chickens_if_coop_open']
    second_biosecurity_threshold = params['second_biosecurity_threshold']
    second_biosecurity_cost = params['second_biosecurity_cost']
    biosecurity_training_aw_days = params['biosecurity_training_aw_days']
    biosecurity_training_ss_days = params['biosecurity_training_ss_days']
    
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']
    
    model = gp.Model("Farm_Optimization_Revised")
    model.setParam('OutputFlag', 0)
    
    x = {}
    for c in crops:
        x[c] = model.addVar(lb=0, name=f"x_{c}")
    
    y_dairy = model.addVar(lb=0, ub=max_dairy_cows, name="dairy_cows")
    y_chicken = model.addVar(lb=0, ub=max_chickens, name="chickens")
    
    surplus_aw = model.addVar(lb=0, name="surplus_aw")
    surplus_ss = model.addVar(lb=0, name="surplus_ss")
    
    coop_open = model.addVar(vtype=GRB.BINARY, name="coop_open")
    large_flock = model.addVar(vtype=GRB.BINARY, name="large_flock")
    
    crop_income_total = gp.quicksum(crop_income[c] * x[c] for c in crops)
    dairy_income = income_dairy * y_dairy
    chicken_income = income_chicken * y_chicken
    external_income = ext_rate_aw * surplus_aw + ext_rate_ss * surplus_ss
    chicken_fixed_cost = fixed_cost_chicken_setup * coop_open
    large_flock_cost = second_biosecurity_cost * large_flock
    
    objective = crop_income_total + dairy_income + chicken_income + external_income - chicken_fixed_cost - large_flock_cost
    model.setObjective(objective, GRB.MAXIMIZE)
    
    model.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, "Land")
    
    model.addConstr(inv_dairy * y_dairy + inv_chicken * y_chicken <= funds_available, "Funds")
    
    training_aw = biosecurity_training_aw_days * coop_open
    model.addConstr(
        gp.quicksum(crop_aw[c] * x[c] for c in crops) + 
        labor_aw_dairy * y_dairy + 
        labor_aw_chicken * y_chicken + 
        surplus_aw + 
        training_aw <= labor_aw, 
        "Labor_AW"
    )
    
    training_ss = biosecurity_training_ss_days * coop_open
    model.addConstr(
        gp.quicksum(crop_ss[c] * x[c] for c in crops) + 
        labor_ss_dairy * y_dairy + 
        labor_ss_chicken * y_chicken + 
        surplus_ss + 
        training_ss <= labor_ss, 
        "Labor_SS"
    )
    
    M = max_chickens
    model.addConstr(y_chicken <= M * coop_open, "Coop_Open_Upper")
    model.addConstr(y_chicken >= min_chickens_if_coop_open * coop_open, "Coop_Open_Lower")
    
    model.addConstr(y_chicken <= second_biosecurity_threshold + M * large_flock, "Large_Flock_Upper")
    model.addConstr(y_chicken >= second_biosecurity_threshold * large_flock, "Large_Flock_Lower")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
