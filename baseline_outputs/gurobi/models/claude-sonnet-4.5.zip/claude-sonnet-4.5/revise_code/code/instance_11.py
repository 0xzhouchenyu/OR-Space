import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    # Read CSVs
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    # Parse Table 1
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]
    
    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])
    
    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])
    
    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp = float(row_cap['Inspection_hours_per_unit'])
    
    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])
    cost_asm = float(row_cost['Assembly_hours_per_unit'])
    
    # Parse Parameters
    def get_param(name):
        return float(df_params[df_params['Parameter_Name'] == name]['Value'].iloc[0])
    
    min_profit = get_param('min_weekly_profit')
    min_a = get_param('min_type_a_production')
    
    insp_a_M = get_param('insp_a_M')
    insp_b_M = get_param('insp_b_M')
    insp_a_E = get_param('insp_a_E')
    insp_b_E = get_param('insp_b_E')
    
    cap_ext = get_param('cap_ext')
    
    cost_insp_M = get_param('cost_insp_M')
    cost_insp_E = get_param('cost_insp_E')
    cost_ext = get_param('cost_ext')
    
    mode_fee_M = get_param('mode_fee_M')
    mode_fee_E = get_param('mode_fee_E')
    
    risk_penalty_M = get_param('risk_penalty_M')
    cost_insp_weight = get_param('cost_insp_weight')
    
    planning_horizon = int(get_param('planning_horizon_weeks'))
    idle_tolerance = get_param('idle_tolerance')
    
    # Stage 1: Minimize weighted idle time + risk penalty
    m1 = gp.Model("Stage1")
    m1.setParam('OutputFlag', 0)
    
    # Variables for each week
    x_A = {}
    x_B = {}
    mode_M = {}
    mode_E = {}
    
    for w in range(planning_horizon):
        x_A[w] = m1.addVar(lb=min_a, vtype=GRB.INTEGER, name=f'x_A_{w}')
        x_B[w] = m1.addVar(lb=0, vtype=GRB.INTEGER, name=f'x_B_{w}')
        mode_M[w] = m1.addVar(vtype=GRB.BINARY, name=f'mode_M_{w}')
        mode_E[w] = m1.addVar(vtype=GRB.BINARY, name=f'mode_E_{w}')
    
    # Constraints for each week
    for w in range(planning_horizon):
        # One mode per week
        m1.addConstr(mode_M[w] + mode_E[w] == 1, name=f'one_mode_{w}')
        
        # Manufacturing capacity
        m1.addConstr(mfg_a * x_A[w] + mfg_b * x_B[w] <= cap_mfg, name=f'cap_mfg_{w}')
        
        # Assembly capacity
        m1.addConstr(asm_a * x_A[w] + asm_b * x_B[w] <= cap_asm, name=f'cap_asm_{w}')
        
        # Inspection capacity (in-house)
        m1.addConstr(
            insp_a_M * x_A[w] + insp_b_M * x_B[w] <= cap_insp + (cap_insp + 1000) * (1 - mode_M[w]),
            name=f'cap_insp_M_{w}'
        )
        m1.addConstr(
            insp_a_E * x_A[w] + insp_b_E * x_B[w] <= cap_insp + (cap_insp + 1000) * (1 - mode_E[w]),
            name=f'cap_insp_E_{w}'
        )
        
        # External inspection capacity (only for Enhanced mode)
        m1.addConstr(
            insp_a_E * x_A[w] + insp_b_E * x_B[w] <= cap_ext + (cap_ext + 1000) * (1 - mode_E[w]),
            name=f'cap_ext_{w}'
        )
        
        # Profit constraint
        # Profit = Revenue - Production Costs - Inspection Costs - Mode Fee
        revenue = price_a * x_A[w] + price_b * x_B[w]
        
        prod_cost = (mfg_a * cost_mfg + asm_a * cost_asm) * x_A[w] + \
                    (mfg_b * cost_mfg + asm_b * cost_asm) * x_B[w]
        
        insp_cost_M = cost_insp_M * (insp_a_M * x_A[w] + insp_b_M * x_B[w])
        insp_cost_E = cost_insp_E * (insp_a_E * x_A[w] + insp_b_E * x_B[w])
        
        profit_M = revenue - prod_cost - insp_cost_M - mode_fee_M
        profit_E = revenue - prod_cost - insp_cost_E - mode_fee_E
        
        m1.addConstr(profit_M >= min_profit - 100000 * (1 - mode_M[w]), name=f'profit_M_{w}')
        m1.addConstr(profit_E >= min_profit - 100000 * (1 - mode_E[w]), name=f'profit_E_{w}')
    
    # Objective: Minimize weighted idle time + risk penalty
    obj1 = 0
    for w in range(planning_horizon):
        # Idle time for manufacturing
        idle_mfg = cap_mfg - (mfg_a * x_A[w] + mfg_b * x_B[w])
        obj1 += cost_mfg * idle_mfg
        
        # Idle time for assembly
        idle_asm = cap_asm - (asm_a * x_A[w] + asm_b * x_B[w])
        obj1 += cost_asm * idle_asm
        
        # Idle time for inspection (in-house)
        idle_insp_M = cap_insp - (insp_a_M * x_A[w] + insp_b_M * x_B[w])
        idle_insp_E = cap_insp - (insp_a_E * x_A[w] + insp_b_E * x_B[w])
        
        # Use cost_insp_weight for inspection idle time
        obj1 += cost_insp_weight * (mode_M[w] * idle_insp_M + mode_E[w] * idle_insp_E)
        
        # Risk penalty for Manual mode
        obj1 += risk_penalty_M * mode_M[w]
    
    m1.setObjective(obj1, GRB.MINIMIZE)
    m1.optimize()
    
    min_stage1_obj = m1.objVal
    
    # Stage 2: Maximize total profit subject to stage 1 objective constraint
    m2 = gp.Model("Stage2")
    m2.setParam('OutputFlag', 0)
    
    # Variables for each week
    x_A2 = {}
    x_B2 = {}
    mode_M2 = {}
    mode_E2 = {}
    
    for w in range(planning_horizon):
        x_A2[w] = m2.addVar(lb=min_a, vtype=GRB.INTEGER, name=f'x_A_{w}')
        x_B2[w] = m2.addVar(lb=0, vtype=GRB.INTEGER, name=f'x_B_{w}')
        mode_M2[w] = m2.addVar(vtype=GRB.BINARY, name=f'mode_M_{w}')
        mode_E2[w] = m2.addVar(vtype=GRB.BINARY, name=f'mode_E_{w}')
    
    # Constraints for each week
    for w in range(planning_horizon):
        # One mode per week
        m2.addConstr(mode_M2[w] + mode_E2[w] == 1, name=f'one_mode_{w}')
        
        # Manufacturing capacity
        m2.addConstr(mfg_a * x_A2[w] + mfg_b * x_B2[w] <= cap_mfg, name=f'cap_mfg_{w}')
        
        # Assembly capacity
        m2.addConstr(asm_a * x_A2[w] + asm_b * x_B2[w] <= cap_asm, name=f'cap_asm_{w}')
        
        # Inspection capacity (in-house)
        m2.addConstr(
            insp_a_M * x_A2[w] + insp_b_M * x_B2[w] <= cap_insp + (cap_insp + 1000) * (1 - mode_M2[w]),
            name=f'cap_insp_M_{w}'
        )
        m2.addConstr(
            insp_a_E * x_A2[w] + insp_b_E * x_B2[w] <= cap_insp + (cap_insp + 1000) * (1 - mode_E2[w]),
            name=f'cap_insp_E_{w}'
        )
        
        # External inspection capacity (only for Enhanced mode)
        m2.addConstr(
            insp_a_E * x_A2[w] + insp_b_E * x_B2[w] <= cap_ext + (cap_ext + 1000) * (1 - mode_E2[w]),
            name=f'cap_ext_{w}'
        )
        
        # Profit constraint
        revenue = price_a * x_A2[w] + price_b * x_B2[w]
        prod_cost = (mfg_a * cost_mfg + asm_a * cost_asm) * x_A2[w] + \
                    (mfg_b * cost_mfg + asm_b * cost_asm) * x_B2[w]
        
        insp_cost_M = cost_insp_M * (insp_a_M * x_A2[w] + insp_b_M * x_B2[w])
        insp_cost_E = cost_insp_E * (insp_a_E * x_A2[w] + insp_b_E * x_B2[w])
        
        profit_M = revenue - prod_cost - insp_cost_M - mode_fee_M
        profit_E = revenue - prod_cost - insp_cost_E - mode_fee_E
        
        m2.addConstr(profit_M >= min_profit - 100000 * (1 - mode_M2[w]), name=f'profit_M_{w}')
        m2.addConstr(profit_E >= min_profit - 100000 * (1 - mode_E2[w]), name=f'profit_E_{w}')
    
    # Stage 1 objective constraint
    obj1_stage2 = 0
    for w in range(planning_horizon):
        idle_mfg = cap_mfg - (mfg_a * x_A2[w] + mfg_b * x_B2[w])
        obj1_stage2 += cost_mfg * idle_mfg
        
        idle_asm = cap_asm - (asm_a * x_A2[w] + asm_b * x_B2[w])
        obj1_stage2 += cost_asm * idle_asm
        
        idle_insp_M = cap_insp - (insp_a_M * x_A2[w] + insp_b_M * x_B2[w])
        idle_insp_E = cap_insp - (insp_a_E * x_A2[w] + insp_b_E * x_B2[w])
        
        obj1_stage2 += cost_insp_weight * (mode_M2[w] * idle_insp_M + mode_E2[w] * idle_insp_E)
        obj1_stage2 += risk_penalty_M * mode_M2[w]
    
    m2.addConstr(obj1_stage2 <= min_stage1_obj + idle_tolerance, name='stage1_constraint')
    
    # Objective: Maximize total two-week profit
    total_profit = 0
    for w in range(planning_horizon):
        revenue = price_a * x_A2[w] + price_b * x_B2[w]
        prod_cost = (mfg_a * cost_mfg + asm_a * cost_asm) * x_A2[w] + \
                    (mfg_b * cost_mfg + asm_b * cost_asm) * x_B2[w]
        
        insp_cost_M = cost_insp_M * (insp_a_M * x_A2[w] + insp_b_M * x_B2[w])
        insp_cost_E = cost_insp_E * (insp_a_E * x_A2[w] + insp_b_E * x_B2[w])
        
        profit_M = revenue - prod_cost - insp_cost_M - mode_fee_M
        profit_E = revenue - prod_cost - insp_cost_E - mode_fee_E
        
        # Total profit for week w
        total_profit += mode_M2[w] * profit_M + mode_E2[w] * profit_E
    
    m2.setObjective(total_profit, GRB.MAXIMIZE)
    m2.optimize()
    
    final_obj = m2.objVal
    print(f"FINAL_OBJ_VALUE: {final_obj}")

if __name__ == '__main__':
    solve()
