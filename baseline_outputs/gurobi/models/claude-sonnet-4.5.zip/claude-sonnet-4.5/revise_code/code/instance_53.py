import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read costs from table_1.csv
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row['Child'].strip()
            costs[child] = {
                'budget': float(row['Cost_budget'].strip()),
                'balanced': float(row['Cost_balanced'].strip()),
                'premium': float(row['Cost_premium'].strip())
            }
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children = int(params['max_children'])
    min_children = int(params['min_children'])
    fairness_penalty = float(params['fairness_penalty'])
    max_total_cost = float(params['max_total_cost'])
    min_children_per_mode = int(params['min_children_per_mode'])
    
    children = list(costs.keys())
    modes = ['budget', 'balanced', 'premium']
    
    # Create model
    model = gp.Model("ZhangFamilyTripRevised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[child]: binary, whether child is selected
    x = {child: model.addVar(vtype=GRB.BINARY, name=f"x_{child}") for child in children}
    
    # m[mode]: binary, whether mode is selected
    m = {mode: model.addVar(vtype=GRB.BINARY, name=f"m_{mode}") for mode in modes}
    
    # cost_var[child]: continuous, actual cost of child (depends on mode)
    cost_var = {child: model.addVar(vtype=GRB.CONTINUOUS, name=f"cost_{child}") for child in children}
    
    # max_cost and min_cost: continuous variables for fairness calculation
    max_cost = model.addVar(vtype=GRB.CONTINUOUS, name="max_cost")
    min_cost = model.addVar(vtype=GRB.CONTINUOUS, name="min_cost")
    
    model.update()
    
    # Constraint: exactly one mode must be selected
    model.addConstr(gp.quicksum(m[mode] for mode in modes) == 1, "one_mode")
    
    # Constraint: Ginny must go
    model.addConstr(x['Ginny'] == 1, "Ginny_must_go")
    
    # Constraint: at most max_children
    model.addConstr(gp.quicksum(x[child] for child in children) <= max_children, "Max_children")
    
    # Constraint: at least min_children
    model.addConstr(gp.quicksum(x[child] for child in children) >= min_children, "Min_children")
    
    # Constraint: If Harry is taken, Fred cannot be taken
    model.addConstr(x['Harry'] + x['Fred'] <= 1, "Harry_no_Fred")
    
    # Constraint: If Harry is taken, George cannot be taken
    model.addConstr(x['Harry'] + x['George'] <= 1, "Harry_no_George")
    
    # Constraint: If George is taken, Fred must also be taken
    model.addConstr(x['George'] <= x['Fred'], "George_requires_Fred")
    
    # Constraint: If George is taken, Hermione must also be taken
    model.addConstr(x['George'] <= x['Hermione'], "George_requires_Hermione")
    
    # Constraint: If balanced or premium mode is selected, at least min_children_per_mode children
    model.addConstr(
        gp.quicksum(x[child] for child in children) >= min_children_per_mode * (m['balanced'] + m['premium']),
        "Min_children_per_mode"
    )
    
    # Constraint: Link cost_var to mode selection
    # cost_var[child] = sum over modes of (costs[child][mode] * m[mode]) if x[child] == 1, else 0
    for child in children:
        for mode in modes:
            model.addConstr(
                cost_var[child] >= costs[child][mode] * m[mode] - (1 - x[child]) * 10000,
                f"cost_link_{child}_{mode}_lower"
            )
            model.addConstr(
                cost_var[child] <= costs[child][mode] * m[mode] + (1 - x[child]) * 10000,
                f"cost_link_{child}_{mode}_upper"
            )
    
    # Alternative simpler formulation for cost_var
    # cost_var[child] should equal the cost in the selected mode if child is selected, 0 otherwise
    for child in children:
        model.addConstr(
            cost_var[child] == gp.quicksum(costs[child][mode] * m[mode] for mode in modes) * x[child],
            f"cost_def_{child}"
        )
    
    # Constraint: Total cost <= max_total_cost
    model.addConstr(
        gp.quicksum(cost_var[child] for child in children) <= max_total_cost,
        "Max_total_cost"
    )
    
    # Constraint: max_cost >= cost_var[child] for all selected children
    for child in children:
        model.addConstr(max_cost >= cost_var[child], f"max_cost_{child}")
    
    # Constraint: min_cost <= cost_var[child] for all selected children
    # We need to ensure min_cost is only bounded by selected children
    # min_cost <= cost_var[child] + M * (1 - x[child])
    M = 10000
    for child in children:
        model.addConstr(min_cost <= cost_var[child] + M * (1 - x[child]), f"min_cost_{child}")
    
    # Objective: minimize total cost + fairness penalty * (max_cost - min_cost)
    total_cost = gp.quicksum(cost_var[child] for child in children)
    fairness_cost = fairness_penalty * (max_cost - min_cost)
    
    model.setObjective(total_cost + fairness_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Print result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
