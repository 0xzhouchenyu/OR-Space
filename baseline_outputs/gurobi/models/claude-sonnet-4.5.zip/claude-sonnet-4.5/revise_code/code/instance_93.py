import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            params[name] = val
    
    # Extract parameters
    a1_yield = float(params['product_A1_yield'])
    a1_time = float(params['product_A1_time'])
    a2_yield = float(params['product_A2_yield'])
    a2_time = float(params['product_A2_time'])
    a3_yield = float(params['product_A3_yield'])
    a3_time = float(params['product_A3_time'])
    
    profit_a1 = float(params['profit_per_kg_A1'])
    profit_a2 = float(params['profit_per_kg_A2'])
    profit_a3 = float(params['profit_per_kg_A3'])
    
    milk_supply = float(params['daily_milk_supply'])
    labor_hours = float(params['daily_labor_hours'])
    cap_A_shared = float(params['cap_A_shared'])
    min_A2_kg = float(params['min_A2_kg'])
    min_A3_kg = float(params['min_A3_kg'])
    type_A_cleaning_loss_if_A3 = float(params['type_A_cleaning_loss_if_A3'])
    cold_chain_bonus_threshold_kg = float(params['cold_chain_bonus_threshold_kg'])
    cold_chain_bonus_yuan = float(params['cold_chain_bonus_yuan'])
    
    # Create model
    model = gp.Model("Dairy_Production_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: barrels of milk for each product
    x1 = model.addVar(lb=0, name="x1")  # barrels for A1
    x2 = model.addVar(lb=0, name="x2")  # barrels for A2
    x3 = model.addVar(lb=0, name="x3")  # barrels for A3
    
    # Binary variable: whether A3 is produced
    y_A3 = model.addVar(vtype=GRB.BINARY, name="y_A3")
    
    # Binary variable: whether A3 reaches cold chain bonus threshold
    y_bonus = model.addVar(vtype=GRB.BINARY, name="y_bonus")
    
    model.update()
    
    # Objective: maximize profit including cold chain bonus
    profit_expr = (a1_yield * profit_a1 * x1 + 
                   a2_yield * profit_a2 * x2 + 
                   a3_yield * profit_a3 * x3 + 
                   cold_chain_bonus_yuan * y_bonus)
    model.setObjective(profit_expr, GRB.MAXIMIZE)
    
    # Constraints
    # 1. Milk supply
    model.addConstr(x1 + x2 + x3 <= milk_supply, "Milk_Supply")
    
    # 2. Labor hours
    model.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours, "Labor_Hours")
    
    # 3. Type A shared capacity with cleaning loss if A3 is produced
    # The cleaning loss removes capacity from the shared ceiling
    # So available capacity = cap_A_shared - type_A_cleaning_loss_if_A3 * y_A3
    model.addConstr(a1_yield * x1 + a3_yield * x3 <= cap_A_shared - type_A_cleaning_loss_if_A3 * y_A3, "Type_A_Shared_Capacity")
    
    # 4. Minimum A2 production
    model.addConstr(a2_yield * x2 >= min_A2_kg, "Min_A2")
    
    # 5. Minimum A3 production
    model.addConstr(a3_yield * x3 >= min_A3_kg, "Min_A3")
    
    # 6. Link y_A3 to x3: if x3 > 0, then y_A3 = 1
    # We need: x3 > 0 implies y_A3 = 1
    # This can be enforced with: x3 <= M * y_A3
    M_large = milk_supply  # upper bound on x3
    model.addConstr(x3 <= M_large * y_A3, "Link_A3_Production")
    
    # 7. Link y_bonus to A3 production: bonus paid only if A3 >= threshold
    # y_bonus = 1 if a3_yield * x3 >= cold_chain_bonus_threshold_kg
    # We model: a3_yield * x3 >= cold_chain_bonus_threshold_kg * y_bonus
    # and: y_bonus <= 1 if a3_yield * x3 >= cold_chain_bonus_threshold_kg
    # Using: a3_yield * x3 >= cold_chain_bonus_threshold_kg - M * (1 - y_bonus)
    model.addConstr(a3_yield * x3 >= cold_chain_bonus_threshold_kg * y_bonus, "Bonus_Threshold_Lower")
    
    # To ensure y_bonus can only be 1 if threshold is met:
    # a3_yield * x3 >= cold_chain_bonus_threshold_kg - M * (1 - y_bonus)
    # which simplifies to: a3_yield * x3 + M * y_bonus >= cold_chain_bonus_threshold_kg + M
    # But we need the reverse: if a3_yield * x3 < threshold, then y_bonus = 0
    # This is: y_bonus <= (a3_yield * x3) / cold_chain_bonus_threshold_kg
    # Or: cold_chain_bonus_threshold_kg * y_bonus <= a3_yield * x3
    # Already captured above
    
    # Additional constraint to prevent bonus without meeting threshold:
    # If y_bonus = 1, then a3_yield * x3 >= cold_chain_bonus_threshold_kg (already have this)
    # We also need: if a3_yield * x3 < cold_chain_bonus_threshold_kg, then y_bonus = 0
    # This is modeled as: a3_yield * x3 >= cold_chain_bonus_threshold_kg - M * (1 - y_bonus)
    epsilon = 0.01
    M_bonus = milk_supply * a3_yield
    model.addConstr(a3_yield * x3 >= cold_chain_bonus_threshold_kg - M_bonus * (1 - y_bonus), "Bonus_Threshold_Upper")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
