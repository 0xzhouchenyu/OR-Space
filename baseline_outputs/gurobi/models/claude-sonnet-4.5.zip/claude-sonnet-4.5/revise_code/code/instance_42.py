import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    a = params['a']
    b = params['b']
    k = params['k']
    d = params['d']
    m_offpeak = params['m_offpeak']
    n_offpeak = params['n_offpeak']
    m_peak = params['m_peak']
    n_peak = params['n_peak']
    c_offpeak = params['c_offpeak']
    c_peak = params['c_peak']
    cap_offpeak = params['cap_offpeak']
    cap_peak = params['cap_peak']
    f_offpeak = params['f_offpeak']
    f_peak = params['f_peak']
    offpeak_cooldown_batch_threshold = params['offpeak_cooldown_batch_threshold']
    offpeak_cooldown_fee = params['offpeak_cooldown_fee']
    
    model = gp.Model("SteelFurnaceRevised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i,j,p] = number of times furnace i uses method j in period p
    # i in {1,2}, j in {1,2}, p in {'offpeak', 'peak'}
    x = {}
    for i in [1, 2]:
        for j in [1, 2]:
            for p in ['offpeak', 'peak']:
                x[i, j, p] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{i}_{j}_{p}")
    
    # Binary variables for fixed activation costs
    # y[i,p] = 1 if furnace i is used in period p
    y = {}
    for i in [1, 2]:
        for p in ['offpeak', 'peak']:
            y[i, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{p}")
    
    # Binary variables for cooldown burden
    # z[i] = 1 if furnace i exceeds offpeak_cooldown_batch_threshold in off-peak
    z = {}
    for i in [1, 2]:
        z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{i}")
    
    model.update()
    
    # Objective: minimize total cost
    fuel_cost = gp.quicksum(
        m_offpeak * x[i, 1, 'offpeak'] + n_offpeak * x[i, 2, 'offpeak'] +
        m_peak * x[i, 1, 'peak'] + n_peak * x[i, 2, 'peak']
        for i in [1, 2]
    )
    
    activation_cost = gp.quicksum(
        f_offpeak * y[i, 'offpeak'] + f_peak * y[i, 'peak']
        for i in [1, 2]
    )
    
    cooldown_cost = gp.quicksum(offpeak_cooldown_fee * z[i] for i in [1, 2])
    
    model.setObjective(fuel_cost + activation_cost + cooldown_cost, GRB.MINIMIZE)
    
    # Constraints
    # Time constraints per furnace per period
    for i in [1, 2]:
        model.addConstr(a * x[i, 1, 'offpeak'] + b * x[i, 2, 'offpeak'] <= c_offpeak, 
                       name=f"Furnace{i}_Time_Offpeak")
        model.addConstr(a * x[i, 1, 'peak'] + b * x[i, 2, 'peak'] <= c_peak, 
                       name=f"Furnace{i}_Time_Peak")
    
    # Plant-wide time capacity constraints
    model.addConstr(
        gp.quicksum(a * x[i, 1, 'offpeak'] + b * x[i, 2, 'offpeak'] for i in [1, 2]) <= cap_offpeak,
        name="Plant_Capacity_Offpeak"
    )
    model.addConstr(
        gp.quicksum(a * x[i, 1, 'peak'] + b * x[i, 2, 'peak'] for i in [1, 2]) <= cap_peak,
        name="Plant_Capacity_Peak"
    )
    
    # Minimum production requirement
    model.addConstr(
        k * gp.quicksum(x[i, j, p] for i in [1, 2] for j in [1, 2] for p in ['offpeak', 'peak']) >= d,
        name="MinProduction"
    )
    
    # Activation constraints: y[i,p] = 1 if furnace i is used in period p
    M = 1000  # Big-M constant
    for i in [1, 2]:
        for p in ['offpeak', 'peak']:
            model.addConstr(x[i, 1, p] + x[i, 2, p] <= M * y[i, p], 
                           name=f"Activation_{i}_{p}_upper")
            model.addConstr(x[i, 1, p] + x[i, 2, p] >= 0.001 * y[i, p], 
                           name=f"Activation_{i}_{p}_lower")
    
    # Cooldown burden constraints: z[i] = 1 if total off-peak batches for furnace i > threshold
    for i in [1, 2]:
        total_offpeak_batches = x[i, 1, 'offpeak'] + x[i, 2, 'offpeak']
        model.addConstr(total_offpeak_batches <= offpeak_cooldown_batch_threshold + M * z[i],
                       name=f"Cooldown_{i}_upper")
        model.addConstr(total_offpeak_batches >= offpeak_cooldown_batch_threshold + 0.001 - M * (1 - z[i]),
                       name=f"Cooldown_{i}_lower")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
