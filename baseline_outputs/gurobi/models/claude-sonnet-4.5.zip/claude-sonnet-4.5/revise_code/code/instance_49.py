import pandas as pd
import gurobipy as gp
from gurobipy import GRB
import os

# Load data
data_path = os.path.dirname(os.path.abspath(__file__))
table_1 = pd.read_csv(os.path.join(data_path, 'data', 'table_1.csv'))
table_2 = pd.read_csv(os.path.join(data_path, 'data', 'table_2.csv'))
params = pd.read_csv(os.path.join(data_path, 'data', 'general_parameters.csv'))

# Parse parameters
min_contract_types = int(params.loc[params['Parameter_Name'] == 'min_contract_types', 'Value'].values[0])
max_contract_types = int(params.loc[params['Parameter_Name'] == 'max_contract_types', 'Value'].values[0])
mutual_exclusion = str(params.loc[params['Parameter_Name'] == 'mutual_exclusion_1_and_4', 'Value'].values[0]).strip().lower() == 'true'
monthly_max_parallel = int(params.loc[params['Parameter_Name'] == 'monthly_max_parallel_contracts', 'Value'].values[0])
min_area_per_contract = float(params.loc[params['Parameter_Name'] == 'min_area_per_contract_units', 'Value'].values[0])
activation_fee = float(params.loc[params['Parameter_Name'] == 'activation_fee_per_contract', 'Value'].values[0])
onboarding_loss = float(params.loc[params['Parameter_Name'] == 'onboarding_loss_units', 'Value'].values[0])
expedited_fee = float(params.loc[params['Parameter_Name'] == 'expedited_onboarding_fee', 'Value'].values[0])

# Convert required area to units of 100 ㎡
demands = {int(row['Month']): float(row['Required_area_㎡']) / 100.0 for _, row in table_1.iterrows()}
costs = {int(row['Contract_length_months']): float(row['Rental_fee_per_100㎡_yuan']) for _, row in table_2.iterrows()}

months = list(demands.keys())
max_month = max(months)
contract_lengths = list(costs.keys())

# Initialize model
model = gp.Model("Warehouse_Rental_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
# x[i, j] = number of 100 sqm units rented starting at month i for j months
x = {}
for i in months:
    for j in contract_lengths:
        if i + j - 1 <= max_month:
            x[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}")

# z[i, j] = binary: 1 if we sign at least one contract starting at month i for j months
z = {}
for i in months:
    for j in contract_lengths:
        if i + j - 1 <= max_month:
            z[i, j] = model.addVar(vtype=GRB.BINARY, name=f"z_{i}_{j}")

# e[i, j] = binary: 1 if we buy expedited onboarding for contracts starting at month i for j months
e = {}
for i in months:
    for j in contract_lengths:
        if i + j - 1 <= max_month:
            e[i, j] = model.addVar(vtype=GRB.BINARY, name=f"e_{i}_{j}")

# y[j] = binary: 1 if contract length j is used anywhere
y = {}
for j in contract_lengths:
    y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")

model.update()

# Objective: Minimize total cost
# Total cost = rental cost + activation fees + expedited onboarding fees
rental_cost = gp.quicksum(costs[j] * x[i, j] for (i, j) in x)
activation_cost = gp.quicksum(activation_fee * z[i, j] for (i, j) in z)
expedited_cost = gp.quicksum(expedited_fee * e[i, j] for (i, j) in e)

model.setObjective(rental_cost + activation_cost + expedited_cost, GRB.MINIMIZE)

# Constraints
# 1. Demand fulfillment for each month
for m in months:
    # For month m, sum all contracts that cover month m
    # For the start month of a contract (i == m), capacity is reduced by onboarding_loss unless expedited
    coverage = gp.LinExpr()
    for (i, j) in x:
        if i <= m <= i + j - 1:
            if i == m:  # Start month - onboarding loss applies
                coverage += x[i, j] - onboarding_loss * z[i, j] + onboarding_loss * e[i, j]
            else:  # Later months - full capacity
                coverage += x[i, j]
    model.addConstr(coverage == demands[m], name=f"demand_{m}")

# 2. Link x to z: if x[i,j] > 0, then z[i,j] = 1
M = sum(demands.values())
for (i, j) in x:
    model.addConstr(x[i, j] <= M * z[i, j], name=f"link_xz_{i}_{j}")

# 3. Minimum area per contract
for (i, j) in x:
    model.addConstr(x[i, j] >= min_area_per_contract * z[i, j], name=f"min_area_{i}_{j}")

# 4. Link z to y: if any contract of length j is used, y[j] = 1
for j in contract_lengths:
    for i in months:
        if (i, j) in z:
            model.addConstr(z[i, j] <= y[j], name=f"link_zy_{i}_{j}")

# 5. Contract type limits
model.addConstr(gp.quicksum(y[j] for j in contract_lengths) >= min_contract_types, name="min_types")
model.addConstr(gp.quicksum(y[j] for j in contract_lengths) <= max_contract_types, name="max_types")

# 6. Mutual exclusion between 1-month and 4-month contracts
if mutual_exclusion and 1 in y and 4 in y:
    model.addConstr(y[1] + y[4] <= 1, name="mutual_exclusion")

# 7. Maximum parallel contracts in any month
for m in months:
    active_contracts = gp.quicksum(z[i, j] for (i, j) in z if i <= m <= i + j - 1)
    model.addConstr(active_contracts <= monthly_max_parallel, name=f"max_parallel_{m}")

# 8. Expedited onboarding can only be bought if contract is signed
for (i, j) in e:
    model.addConstr(e[i, j] <= z[i, j], name=f"expedited_link_{i}_{j}")

# Solve
model.optimize()

# Output result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
