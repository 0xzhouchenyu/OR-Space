import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    budget = params['company_budget']
    max_employees = int(params['max_employees'])
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_gj = int(params['max_one_candidate_g_j'])
    lead_premium = params['lead_premium']
    min_leads = int(params['min_leads'])
    mentor_bonus = params['mentor_bonus']
    max_pairs = int(params['max_pairs'])
    
    # Create optimization model
    model = gp.Model("HiringOptimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[c['name']] = 1 if candidate c is hired
    x = {}
    for c in candidates:
        x[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{c['name']}")
    
    # y_lead[c['name']] = 1 if candidate c is hired as Lead
    y_lead = {}
    for c in candidates:
        y_lead[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"y_lead_{c['name']}")
    
    # y_eng[c['name']] = 1 if candidate c is hired as Engineer
    y_eng = {}
    for c in candidates:
        y_eng[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"y_eng_{c['name']}")
    
    # z = number of mentorship pairs counted (capped at max_pairs)
    z = model.addVar(vtype=GRB.INTEGER, name="z")
    
    model.update()
    
    # Objective: minimize total net cost
    # Total cost = sum of (base salary + lead_premium if Lead) - mentor_bonus * z
    total_cost = gp.quicksum(c['salary'] * x[c['name']] for c in candidates)
    lead_cost = gp.quicksum(lead_premium * y_lead[c['name']] for c in candidates)
    mentor_credit = mentor_bonus * z
    
    model.setObjective(total_cost + lead_cost - mentor_credit, GRB.MINIMIZE)
    
    # Constraint: Each hired candidate must be assigned exactly one role
    for c in candidates:
        model.addConstr(y_lead[c['name']] + y_eng[c['name']] == x[c['name']], 
                       name=f"role_assignment_{c['name']}")
    
    # Constraint: Max employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, 
                   name="MaxEmployees")
    
    # Constraint: Min skill level
    model.addConstr(gp.quicksum(c['skill'] * x[c['name']] for c in candidates) >= min_skill, 
                   name="MinSkill")
    
    # Constraint: Min project management experience
    model.addConstr(gp.quicksum(c['pm_exp'] * x[c['name']] for c in candidates) >= min_pm_exp, 
                   name="MinPMExp")
    
    # Constraint: At most one of G and J can be hired
    model.addConstr(x['G'] + x['J'] <= max_gj, name="MaxOneGJ")
    
    # Constraint: Min leads
    model.addConstr(gp.quicksum(y_lead[c['name']] for c in candidates) >= min_leads, 
                   name="MinLeads")
    
    # Constraint: Number of mentorship pairs is limited by both leads and engineers
    num_leads = gp.quicksum(y_lead[c['name']] for c in candidates)
    num_engineers = gp.quicksum(y_eng[c['name']] for c in candidates)
    
    model.addConstr(z <= num_leads, name="pairs_limited_by_leads")
    model.addConstr(z <= num_engineers, name="pairs_limited_by_engineers")
    model.addConstr(z <= max_pairs, name="pairs_capped")
    
    # Constraint: Budget constraint (net cost <= budget)
    model.addConstr(total_cost + lead_cost - mentor_credit <= budget, name="Budget")
    
    # Solve
    model.optimize()
    
    # Print results
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
