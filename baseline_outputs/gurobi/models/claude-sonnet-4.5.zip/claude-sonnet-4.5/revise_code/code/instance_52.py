import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    
    n = len(shifts)  # number of periods (6)
    required = [s['required'] for s in shifts]
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            value = row['Value']
            if param_name in ['shift_duration', 'driver_rest_gap', 'crew_rest_gap', 'max_overtime_shifts']:
                params[param_name] = int(value)
            else:
                params[param_name] = float(value)
    
    shift_duration = params['shift_duration']
    driver_rest_gap = params['driver_rest_gap']
    crew_rest_gap = params['crew_rest_gap']
    max_night_driver_fraction = params['max_night_driver_fraction']
    max_night_crew_fraction = params['max_night_crew_fraction']
    max_overtime_shifts = params['max_overtime_shifts']
    overtime_cost_factor = params['overtime_cost_factor']
    
    # Each time period is 4 hours, shift_duration is 8 hours = 2 periods
    periods_per_shift = shift_duration // 4  # = 2
    
    # Late-night periods are 5 and 6 (indices 4 and 5)
    late_night_periods = [4, 5]
    
    # Create model
    model = gp.Model("BusScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Regular shifts for drivers and crew
    x_driver = [model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_driver_{i+1}") for i in range(n)]
    x_crew = [model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_crew_{i+1}") for i in range(n)]
    
    # Overtime shifts for drivers and crew
    o_driver = [model.addVar(vtype=GRB.INTEGER, lb=0, name=f"o_driver_{i+1}") for i in range(n)]
    o_crew = [model.addVar(vtype=GRB.INTEGER, lb=0, name=f"o_crew_{i+1}") for i in range(n)]
    
    # Objective: minimize total cost (regular shifts + overtime_cost_factor * overtime shifts)
    total_regular = gp.quicksum(x_driver[i] + x_crew[i] for i in range(n))
    total_overtime = gp.quicksum(o_driver[i] + o_crew[i] for i in range(n))
    model.setObjective(total_regular + overtime_cost_factor * total_overtime, GRB.MINIMIZE)
    
    # Coverage constraints: for each period j, both drivers and crew must meet demand
    for j in range(n):
        # Which starting periods cover period j?
        # A worker starting at period i covers periods i, (i+1)%n, ..., (i+periods_per_shift-1)%n
        covering_indices = []
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                covering_indices.append(i)
        
        # Driver coverage
        model.addConstr(
            gp.quicksum(x_driver[i] + o_driver[i] for i in covering_indices) >= required[j],
            name=f"Driver_demand_period_{j+1}"
        )
        
        # Crew coverage
        model.addConstr(
            gp.quicksum(x_crew[i] + o_crew[i] for i in covering_indices) >= required[j],
            name=f"Crew_demand_period_{j+1}"
        )
    
    # Late-night fraction constraints
    # For drivers: (regular + overtime starts in late-night) <= max_night_driver_fraction * total driver starts
    total_driver_starts = gp.quicksum(x_driver[i] + o_driver[i] for i in range(n))
    late_night_driver_starts = gp.quicksum(x_driver[i] + o_driver[i] for i in late_night_periods)
    model.addConstr(
        late_night_driver_starts <= max_night_driver_fraction * total_driver_starts,
        name="Driver_late_night_fraction"
    )
    
    # For crew: (regular + overtime starts in late-night) <= max_night_crew_fraction * total crew starts
    total_crew_starts = gp.quicksum(x_crew[i] + o_crew[i] for i in range(n))
    late_night_crew_starts = gp.quicksum(x_crew[i] + o_crew[i] for i in late_night_periods)
    model.addConstr(
        late_night_crew_starts <= max_night_crew_fraction * total_crew_starts,
        name="Crew_late_night_fraction"
    )
    
    # Maximum overtime constraint
    model.addConstr(
        gp.quicksum(o_driver[i] + o_crew[i] for i in range(n)) <= max_overtime_shifts,
        name="Max_overtime"
    )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
