import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load distances
distances = {}
with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        yard = row['Coal_Yard'].strip()
        area = int(row['Residential_Area'].strip())
        dist = float(row['Distance_km'].strip())
        distances[(yard, area)] = dist

# Load parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
min_supply = {
    'A': params['min_coal_yard_A'],
    'B': params['min_coal_yard_B_adjusted']
}

demand = {
    1: params['residential_area_1_demand'],
    2: params['residential_area_2_demand'],
    3: params['residential_area_3_demand']
}

min_share_area3_from_A = params['min_share_area3_from_A']
area3_A_staging_threshold = params['area3_A_staging_threshold']
area3_A_excess_staging_cost = params['area3_A_excess_staging_cost']

coal_yards = ['A', 'B']
areas = [1, 2, 3]

# Create model
model = gp.Model("Coal_Distribution_Revised")
model.setParam('OutputFlag', 0)

# Decision variables: amount of coal shipped from yard i to area j
x = {}
for yard in coal_yards:
    for area in areas:
        if (yard, area) in distances:
            x[(yard, area)] = model.addVar(lb=0, name=f"x_{yard}_{area}")

# Variable for excess tonnage from A to Area 3 above threshold
excess_A_3 = model.addVar(lb=0, name="excess_A_3")

# Objective: minimize total transportation cost + excess staging cost
obj = gp.quicksum(distances[(yard, area)] * x[(yard, area)] 
                  for yard in coal_yards for area in areas if (yard, area) in distances)
obj += area3_A_excess_staging_cost * excess_A_3

model.setObjective(obj, GRB.MINIMIZE)

# Constraints:
# 1. Each coal yard must supply at least its minimum requirement
for yard in coal_yards:
    model.addConstr(
        gp.quicksum(x[(yard, area)] for area in areas if (yard, area) in distances) >= min_supply[yard],
        name=f"Min_Supply_{yard}"
    )

# 2. Each residential area must receive exactly its demand
for area in areas:
    model.addConstr(
        gp.quicksum(x[(yard, area)] for yard in coal_yards if (yard, area) in distances) == demand[area],
        name=f"Demand_{area}"
    )

# 3. Minimum share of area 3 demand from coal yard A
model.addConstr(
    x[('A', 3)] >= min_share_area3_from_A * demand[3],
    name="Min_Share_Area3_from_A"
)

# 4. Excess staging constraint for A to Area 3
model.addConstr(
    excess_A_3 >= x[('A', 3)] - area3_A_staging_threshold,
    name="Excess_Staging_A_3"
)

# Solve
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
