import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read general parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    total_space = params['mall_total_space']
    rent_pct = params['rent_percentage'] / 100.0
    common_area_factor = params['common_area_factor']
    catering_security_cost = params['catering_third_store_security_cost']
    catering_security_threshold = int(params['catering_third_store_security_threshold'])
    
    # Read store data
    stores = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            stores.append({
                'name': row['Store_Type'].strip(),
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits
            })
    
    # Create Gurobi model
    model = gp.Model("mall_optimization")
    model.setParam('OutputFlag', 0)
    
    n_stores = len(stores)
    
    # Decision variables: number of each store type
    # x[i] = number of stores of type i
    x = []
    for i, s in enumerate(stores):
        x.append(model.addVar(lb=s['min'], ub=s['max'], vtype=GRB.INTEGER, name=f"x_{i}"))
    
    # For each store type, we need to compute the total profit
    # Profit depends on the count: per-store profit * count for that count level
    # We use binary indicator variables for each possible count
    
    # y[i][k] = 1 if store type i has exactly k stores
    y = []
    for i, s in enumerate(stores):
        yi = {}
        for k in range(s['min'], s['max'] + 1):
            yi[k] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{k}")
        y.append(yi)
    
    # Constraints: exactly one count is selected for each store type
    for i, s in enumerate(stores):
        possible_counts = list(range(s['min'], s['max'] + 1))
        # Sum of indicators = 1
        model.addConstr(gp.quicksum(y[i][k] for k in possible_counts) == 1)
        # Link x[i] to indicators
        model.addConstr(x[i] == gp.quicksum(k * y[i][k] for k in possible_counts))
    
    # Space constraint with common_area_factor
    model.addConstr(
        gp.quicksum(x[i] * stores[i]['area'] * common_area_factor for i in range(n_stores)) <= total_space
    )
    
    # Catering is store index 4 (Code=5)
    catering_idx = 4
    
    # Binary variable: z_catering = 1 if catering has 3 stores
    # The security cost applies only if catering count > threshold (threshold=2)
    # i.e., if catering has 3 stores
    z_catering_third = model.addVar(vtype=GRB.BINARY, name="z_catering_third")
    
    # z_catering_third = y[catering_idx][3] (if 3 is a possible count)
    catering_store = stores[catering_idx]
    if 3 in y[catering_idx]:
        model.addConstr(z_catering_third == y[catering_idx][3])
    else:
        model.addConstr(z_catering_third == 0)
    
    # Compute total profit
    # For each store type, total profit = sum over k of y[i][k] * k * profit_per_store[k]
    total_profit_expr = gp.LinExpr()
    for i, s in enumerate(stores):
        for k in range(s['min'], s['max'] + 1):
            if k in s['profits']:
                # k stores * per_store_profit[k]
                total_profit_expr += y[i][k] * k * s['profits'][k]
    
    # Total rent income = rent_pct * total_profit - catering_security_cost * z_catering_third
    # (if third catering store is kept, extra security cost is subtracted)
    objective = rent_pct * total_profit_expr - catering_security_cost * z_catering_third
    
    model.setObjective(objective, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == '__main__':
    main()
