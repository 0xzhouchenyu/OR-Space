import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

m = int(params['m'])  # production points
n = int(params['n'])  # demand points
p = int(params['p'])  # marshaling stations

a = {i: params[f'a_{i}'] for i in range(1, m+1)}  # production capacities
b = {j: params[f'b_{j}'] for j in range(1, n+1)}  # demands
f_cost = {k: params[f'f_{k}'] for k in range(1, p+1)}  # fixed costs
q = {k: params[f'q_{k}'] for k in range(1, p+1)}  # max total transshipment capacity
qexp = {k: params[f'qexp_{k}'] for k in range(1, p+1)}  # max express transshipment capacity
alpha = {j: params[f'alpha_{j}'] for j in range(1, n+1)}  # minimum express fraction
eps = params['eps']  # minimum strictly positive express flow
M = params['M']  # Big-M upper bound

# Load transportation costs from production to marshaling stations
cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row['i'])
        k = int(row['k'])
        cR_ik[(i, k)] = float(row['cR_ik'])
        cE_ik[(i, k)] = float(row['cE_ik'])

# Load transportation costs from marshaling stations to demand points
cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, 'table_2.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row['k'])
        j = int(row['j'])
        cR_kj[(k, j)] = float(row['cR_kj'])
        cE_kj[(k, j)] = float(row['cE_kj'])

# Create the optimization model
model = gp.Model("Transportation_Problem_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
# xR_ik: regular amount shipped from production point i to marshaling station k
xR = {}
for i in range(1, m+1):
    for k in range(1, p+1):
        xR[(i, k)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"xR_{i}_{k}")

# xE_ik: express amount shipped from production point i to marshaling station k
xE = {}
for i in range(1, m+1):
    for k in range(1, p+1):
        xE[(i, k)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"xE_{i}_{k}")

# yR_kj: regular amount shipped from marshaling station k to demand point j
yR = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        yR[(k, j)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"yR_{k}_{j}")

# yE_kj: express amount shipped from marshaling station k to demand point j
yE = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        yE[(k, j)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"yE_{k}_{j}")

# z_k: binary variable indicating whether marshaling station k is used
z = {}
for k in range(1, p+1):
    z[k] = model.addVar(vtype=GRB.BINARY, name=f"z_{k}")

# w_kj: binary variable indicating whether express flow from station k to demand j is strictly positive
w = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        w[(k, j)] = model.addVar(vtype=GRB.BINARY, name=f"w_{k}_{j}")

model.update()

# Objective: minimize total transportation cost + fixed costs
obj = gp.quicksum(cR_ik[(i, k)] * xR[(i, k)] + cE_ik[(i, k)] * xE[(i, k)] 
                  for i in range(1, m+1) for k in range(1, p+1))
obj += gp.quicksum(cR_kj[(k, j)] * yR[(k, j)] + cE_kj[(k, j)] * yE[(k, j)] 
                   for k in range(1, p+1) for j in range(1, n+1))
obj += gp.quicksum(f_cost[k] * z[k] for k in range(1, p+1))

model.setObjective(obj, GRB.MINIMIZE)

# Constraints

# 1. Supply constraints: total shipped from production point i <= a_i
for i in range(1, m+1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for k in range(1, p+1)) <= a[i],
        name=f"Supply_{i}"
    )

# 2. Demand constraints: total received at demand point j >= b_j
for j in range(1, n+1):
    model.addConstr(
        gp.quicksum(yR[(k, j)] + yE[(k, j)] for k in range(1, p+1)) >= b[j],
        name=f"Demand_{j}"
    )

# 3. Flow conservation at marshaling stations (regular)
for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] for i in range(1, m+1)) == 
        gp.quicksum(yR[(k, j)] for j in range(1, n+1)),
        name=f"FlowBalanceR_{k}"
    )

# 4. Flow conservation at marshaling stations (express)
for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xE[(i, k)] for i in range(1, m+1)) == 
        gp.quicksum(yE[(k, j)] for j in range(1, n+1)),
        name=f"FlowBalanceE_{k}"
    )

# 5. Total capacity constraints at marshaling stations
for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for i in range(1, m+1)) <= q[k] * z[k],
        name=f"TotalCapacity_{k}"
    )

# 6. Express capacity constraints at marshaling stations
for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xE[(i, k)] for i in range(1, m+1)) <= qexp[k] * z[k],
        name=f"ExpressCapacity_{k}"
    )

# 7. Express source indicator constraints
for k in range(1, p+1):
    for j in range(1, n+1):
        model.addConstr(yE[(k, j)] >= eps * w[(k, j)], name=f"ExpressMin_{k}_{j}")
        model.addConstr(yE[(k, j)] <= M * w[(k, j)], name=f"ExpressMax_{k}_{j}")

# 8. Diversified express share constraints
for j in range(1, n+1):
    total_demand_j = gp.quicksum(yR[(k, j)] + yE[(k, j)] for k in range(1, p+1))
    total_express_j = gp.quicksum(yE[(k, j)] for k in range(1, p+1))
    num_express_sources = gp.quicksum(w[(k, j)] for k in range(1, p+1))
    
    # If at least 2 express sources, then express fraction >= alpha_j
    model.addConstr(
        total_express_j >= alpha[j] * total_demand_j - M * (2 - num_express_sources),
        name=f"ExpressFraction_{j}"
    )

# Solve
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
