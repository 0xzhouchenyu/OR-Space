import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    products = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params_raw = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Parse general parameters
    params = {}
    for row in params_raw:
        params[row['Parameter_Name']] = float(row['Value'])
    
    max_grains = params['max_grains']
    price_grains = params['price_per_lb_grains']
    max_meat = params['max_meat']
    price_meat = params['price_per_lb_meat']
    line_fixed_cost = params['line_fixed_cost']
    line_capacity_packs = params['line_capacity_packs']
    min_batch_packs = params['min_batch_packs']
    min_yummies = params['min_yummies']
    retailer_rebate_yummies_threshold = params['retailer_rebate_yummies_threshold']
    retailer_rebate_min_meaties = params['retailer_rebate_min_meaties']
    retailer_rebate_fixed = params['retailer_rebate_fixed']
    
    # Parse product data
    product_data = {}
    for row in products:
        name = row['Product']
        product_data[name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'variable_cost': float(row['Variable_cost_per_pack']),
            'capacity': float(row['Production_capacity']) if row['Production_capacity'].strip() else None
        }
    
    m = product_data['Meaties']
    y = product_data['Yummies']
    
    # Calculate profit per pack (excluding raw materials)
    profit_meaties = m['price'] - m['variable_cost'] - (m['grains'] * price_grains + m['meat'] * price_meat)
    profit_yummies = y['price'] - y['variable_cost'] - (y['grains'] * price_grains + y['meat'] * price_meat)
    
    # Create model
    model = gp.Model("HealthyPetFoods_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_meaties = model.addVar(lb=0, name="Meaties")
    x_yummies = model.addVar(lb=0, name="Yummies")
    line_active = model.addVar(vtype=GRB.BINARY, name="line_active")
    rebate_earned = model.addVar(vtype=GRB.BINARY, name="rebate_earned")
    
    # Objective: maximize profit
    # Profit = revenue from products - line fixed cost (if active) + rebate (if earned)
    model.setObjective(
        profit_meaties * x_meaties + profit_yummies * x_yummies 
        - line_fixed_cost * line_active 
        + retailer_rebate_fixed * rebate_earned,
        GRB.MAXIMIZE
    )
    
    # Constraints
    # Grains availability
    model.addConstr(m['grains'] * x_meaties + y['grains'] * x_yummies <= max_grains, "Grains_Constraint")
    
    # Meat availability
    model.addConstr(m['meat'] * x_meaties + y['meat'] * x_yummies <= max_meat, "Meat_Constraint")
    
    # Production capacity for Meaties
    if m['capacity'] is not None:
        model.addConstr(x_meaties <= m['capacity'], "Meaties_Capacity")
    
    # Line capacity (total throughput when active)
    model.addConstr(x_meaties + x_yummies <= line_capacity_packs * line_active, "Line_Capacity")
    
    # Minimum batch size if line is active
    model.addConstr(x_meaties + x_yummies >= min_batch_packs * line_active, "Min_Batch")
    
    # Minimum Yummies production if line is active
    model.addConstr(x_yummies >= min_yummies * line_active, "Min_Yummies")
    
    # Rebate eligibility: both thresholds must be met
    # rebate_earned = 1 only if x_yummies >= retailer_rebate_yummies_threshold AND x_meaties >= retailer_rebate_min_meaties
    # We use big-M constraints
    M = line_capacity_packs  # sufficiently large constant
    
    # Introduce auxiliary binary variables for each condition
    yummies_threshold_met = model.addVar(vtype=GRB.BINARY, name="yummies_threshold_met")
    meaties_threshold_met = model.addVar(vtype=GRB.BINARY, name="meaties_threshold_met")
    
    # yummies_threshold_met = 1 iff x_yummies >= retailer_rebate_yummies_threshold
    model.addConstr(x_yummies >= retailer_rebate_yummies_threshold - M * (1 - yummies_threshold_met), "Yummies_Threshold_Lower")
    model.addConstr(x_yummies <= retailer_rebate_yummies_threshold - 0.001 + M * yummies_threshold_met, "Yummies_Threshold_Upper")
    
    # meaties_threshold_met = 1 iff x_meaties >= retailer_rebate_min_meaties
    model.addConstr(x_meaties >= retailer_rebate_min_meaties - M * (1 - meaties_threshold_met), "Meaties_Threshold_Lower")
    model.addConstr(x_meaties <= retailer_rebate_min_meaties - 0.001 + M * meaties_threshold_met, "Meaties_Threshold_Upper")
    
    # rebate_earned = 1 only if both conditions are met
    model.addConstr(rebate_earned <= yummies_threshold_met, "Rebate_Requires_Yummies")
    model.addConstr(rebate_earned <= meaties_threshold_met, "Rebate_Requires_Meaties")
    model.addConstr(rebate_earned >= yummies_threshold_met + meaties_threshold_met - 1, "Rebate_Both_Required")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
