import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = params['min_manager_experience']
    manager_bonus_per_candidate = params['manager_bonus_per_candidate']

    # Create optimization model
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[c]: binary, whether candidate c is hired
    x = {}
    for c in candidates:
        x[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{c['name']}")

    # y[c]: binary, whether candidate c is hired as a manager
    y = {}
    for c in candidates:
        y[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"y_{c['name']}")

    # z[c]: binary, whether candidate c is hired as a specialist
    z = {}
    for c in candidates:
        z[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"z_{c['name']}")

    model.update()

    # Objective: minimize total salary + manager bonuses
    total_salary = gp.quicksum(c['salary'] * x[c['name']] for c in candidates)
    total_manager_bonus = gp.quicksum(manager_bonus_per_candidate * y[c['name']] for c in candidates)
    model.setObjective(total_salary + total_manager_bonus, GRB.MINIMIZE)

    # Constraint: Each hired candidate serves in exactly one role
    for c in candidates:
        model.addConstr(y[c['name']] + z[c['name']] == x[c['name']], 
                       name=f"role_assignment_{c['name']}")

    # Constraint: max employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, 
                   name="max_employees")

    # Constraint: min employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) >= min_employees, 
                   name="min_employees")

    # Constraint: budget (base salaries only, excluding manager bonus)
    model.addConstr(gp.quicksum(c['salary'] * x[c['name']] for c in candidates) <= budget_limit, 
                   name="budget")

    # Constraint: at least one with Master's or Doctoral degree
    advanced_candidates = [c for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(x[c['name']] for c in advanced_candidates) >= min_advanced, 
                   name="min_advanced_degree")

    # Constraint: minimum total work experience of all selected candidates
    model.addConstr(gp.quicksum(c['experience'] * x[c['name']] for c in candidates) >= min_experience, 
                   name="min_work_experience")

    # Constraint: at most one from pair A and E
    model.addConstr(x['A'] + x['E'] <= max_equivalent, 
                   name="max_equivalent")

    # Constraint: min managers
    model.addConstr(gp.quicksum(y[c['name']] for c in candidates) >= min_managers, 
                   name="min_managers")

    # Constraint: max managers
    model.addConstr(gp.quicksum(y[c['name']] for c in candidates) <= max_managers, 
                   name="max_managers")

    # Constraint: minimum total work experience of hired managers
    model.addConstr(gp.quicksum(c['experience'] * y[c['name']] for c in candidates) >= min_manager_experience, 
                   name="min_manager_experience")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == '__main__':
    main()
