import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load car data
def load_car_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    cars = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            i = int(row['i'])
            length = float(row['lambda_i'])
            cars[i] = length
    return cars

# Load parameters
def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'])
            params[name] = value
    return params

# Data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load data
cars = load_car_data(data_dir)
params = load_parameters(data_dir)

num_cars = int(params['num_cars'])
max_length_one_side = params['max_length_one_side']

car_ids = list(cars.keys())
lengths = cars

# Create model
model = gp.Model("ParkingRevisedProblem")
model.setParam('OutputFlag', 0)

# Decision variables: x[i] = 1 if car i is parked (on the single usable side), 0 otherwise
x = {}
for i in car_ids:
    x[i] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}")

# Objective: minimize total length occupied on the street
# Since all cars must be on one side, the objective is the length of that side
total_parked_length = gp.quicksum(lengths[i] * x[i] for i in car_ids)
model.setObjective(total_parked_length, GRB.MINIMIZE)

# Constraint: total length on the usable side must not exceed max_length_one_side
model.addConstr(total_parked_length <= max_length_one_side, "max_length_constraint")

# Optimize
model.optimize()

# Extract solution
if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"FINAL_OBJ_VALUE: No feasible solution")
