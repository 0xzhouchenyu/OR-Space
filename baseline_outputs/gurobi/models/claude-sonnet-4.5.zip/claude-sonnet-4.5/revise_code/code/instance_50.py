import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = params['fixed_order_cost']
    august_bulk_order_threshold = params['august_bulk_order_threshold']
    august_bulk_receiving_fee = params['august_bulk_receiving_fee']
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = {m: model.addVar(lb=0, name=f"buy_{m}") for m in months}
    sell = {m: model.addVar(lb=0, name=f"sell_{m}") for m in months}
    stock = {m: model.addVar(lb=0, ub=warehouse_capacity, name=f"stock_{m}") for m in months}
    
    # Binary variables for fixed order cost
    order_made = {m: model.addVar(vtype=GRB.BINARY, name=f"order_made_{m}") for m in months}
    
    # Binary variable for August bulk receiving fee
    august_bulk = model.addVar(vtype=GRB.BINARY, name="august_bulk")
    
    # Objective: maximize total profit (revenue - cost - fixed costs - august bulk fee)
    revenue = gp.quicksum(sell_price[m] * sell[m] for m in months)
    purchase_cost = gp.quicksum(buy_price[m] * buy[m] for m in months)
    fixed_costs = gp.quicksum(fixed_order_cost * order_made[m] for m in months)
    august_fee = august_bulk_receiving_fee * august_bulk
    
    model.setObjective(revenue - purchase_cost - fixed_costs - august_fee, GRB.MAXIMIZE)
    
    # Stock balance constraints
    for i, m in enumerate(months):
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_stock = stock[months[i-1]]
        
        # Stock balance: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], f"balance_{m}")
        
        # Warehouse constraint after buying
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, f"warehouse_after_buy_{m}")
    
    # Fixed order cost constraints
    M = warehouse_capacity  # Big M
    for m in months:
        # If buy[m] > 0, then order_made[m] = 1
        model.addConstr(buy[m] <= M * order_made[m], f"order_activation_{m}")
    
    # August bulk receiving fee constraint
    # If buy[8] > 300, then august_bulk = 1
    august_month = 8
    if august_month in months:
        # buy[8] > 300 => august_bulk = 1
        # buy[8] <= 300 + M * august_bulk
        # buy[8] >= 300.001 - M * (1 - august_bulk)
        # Simpler: buy[8] <= august_bulk_order_threshold + M * august_bulk
        M_august = warehouse_capacity
        model.addConstr(buy[august_month] <= august_bulk_order_threshold + M_august * august_bulk, 
                       f"august_bulk_activation")
    
    # Solve
    model.optimize()
    
    # Print solution
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
