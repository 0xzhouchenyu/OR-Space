import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read table_1.csv
toys = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            'type': row['Toy_Type'],
            'labor': float(row['Manufacturing_Labor_Hours']),
            'inspection': float(row['Inspection_Hours']),
            'profit': float(row['Profit_Per_Unit'])
        })

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Extract parameters
available_labor_p1 = params['available_labor_hours_period1']
available_labor_p2 = params['available_labor_hours_period2']
available_inspection_p1 = params['available_inspection_hours_period1']
available_inspection_p2 = params['available_inspection_hours_period2']

max_demand_p1 = {
    'High-End': params['max_demand_high_end_period1'],
    'Mid-Range': params['max_demand_mid_range_period1'],
    'Low-End': params['max_demand_low_end_period1']
}

max_demand_p2 = {
    'High-End': params['max_demand_high_end_period2'],
    'Mid-Range': params['max_demand_mid_range_period2'],
    'Low-End': params['max_demand_low_end_period2']
}

overtime_labor_cap = params['overtime_labor_cap']
overtime_labor_cost = params['overtime_labor_cost']
period1_overtime_fatigue_threshold = params['period1_overtime_fatigue_threshold']
period2_labor_recovery_loss = params['period2_labor_recovery_loss']
overtime_review_threshold = params['overtime_review_threshold']
seasonal_safety_review_fee = params['seasonal_safety_review_fee']

# Build optimization model
model = gp.Model("ToyProduction_TwoPeriod")
model.setParam('OutputFlag', 0)

# Decision variables
x_p1 = {}
x_p2 = {}
for toy in toys:
    x_p1[toy['type']] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_p1_{toy['type']}")
    x_p2[toy['type']] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_p2_{toy['type']}")

# Overtime variables
ot_p1 = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="overtime_p1")
ot_p2 = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="overtime_p2")

# Binary variable for fatigue trigger
fatigue_trigger = model.addVar(vtype=GRB.BINARY, name="fatigue_trigger")

# Binary variable for safety review trigger
safety_review_trigger = model.addVar(vtype=GRB.BINARY, name="safety_review_trigger")

# Objective: maximize profit - overtime costs - safety review fee
total_profit = gp.quicksum(toy['profit'] * (x_p1[toy['type']] + x_p2[toy['type']]) for toy in toys)
overtime_cost = overtime_labor_cost * (ot_p1 + ot_p2)
safety_review_cost = seasonal_safety_review_fee * safety_review_trigger

model.setObjective(total_profit - overtime_cost - safety_review_cost, GRB.MAXIMIZE)

# Constraints

# Period 1 labor hours (regular + overtime)
model.addConstr(
    gp.quicksum(toy['labor'] * x_p1[toy['type']] for toy in toys) <= available_labor_p1 + ot_p1,
    "Labor_P1"
)

# Period 2 labor hours (regular + overtime - recovery loss if fatigue triggered)
model.addConstr(
    gp.quicksum(toy['labor'] * x_p2[toy['type']] for toy in toys) <= 
    available_labor_p2 + ot_p2 - period2_labor_recovery_loss * fatigue_trigger,
    "Labor_P2"
)

# Period 1 inspection hours
model.addConstr(
    gp.quicksum(toy['inspection'] * x_p1[toy['type']] for toy in toys) <= available_inspection_p1,
    "Inspection_P1"
)

# Period 2 inspection hours
model.addConstr(
    gp.quicksum(toy['inspection'] * x_p2[toy['type']] for toy in toys) <= available_inspection_p2,
    "Inspection_P2"
)

# Demand constraints period 1
for toy in toys:
    model.addConstr(x_p1[toy['type']] <= max_demand_p1[toy['type']], f"Demand_P1_{toy['type']}")

# Demand constraints period 2
for toy in toys:
    model.addConstr(x_p2[toy['type']] <= max_demand_p2[toy['type']], f"Demand_P2_{toy['type']}")

# Total overtime cap
model.addConstr(ot_p1 + ot_p2 <= overtime_labor_cap, "Overtime_Cap")

# Fatigue trigger: if ot_p1 > period1_overtime_fatigue_threshold, then fatigue_trigger = 1
M_fatigue = overtime_labor_cap
model.addConstr(ot_p1 <= period1_overtime_fatigue_threshold + M_fatigue * fatigue_trigger, "Fatigue_Trigger")

# Safety review trigger: if ot_p1 + ot_p2 > overtime_review_threshold, then safety_review_trigger = 1
M_safety = overtime_labor_cap
model.addConstr(ot_p1 + ot_p2 <= overtime_review_threshold + M_safety * safety_review_trigger, "Safety_Review_Trigger")

# Solve
model.optimize()

# Print results
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
