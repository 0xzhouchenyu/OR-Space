import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            params[param_name] = value
    
    shift_duration = int(params['shift_duration'])
    full_time_cost = float(params['full_time_cost'])
    part_time_cost = float(params['part_time_cost'])
    part_time_cap_per_period = int(params['part_time_cap_per_period'])
    min_full_time_per_period = int(params['min_full_time_per_period'])
    
    # Read staffing requirements
    requirements = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row['Time_Period'].strip()
            req = int(row['Required_Salespeople'].strip())
            requirements[period] = req
    
    periods = list(requirements.keys())
    req_values = list(requirements.values())
    n = len(periods)  # 6 periods
    
    # Create model
    model = gp.Model("MinLaborCost")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i] = number of full-time salespeople starting shift at period i
    x = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="full_time")
    
    # y[j] = number of part-time salespeople working in period j
    y = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="part_time")
    
    # Objective: minimize total daily labor cost
    model.setObjective(
        full_time_cost * gp.quicksum(x[i] for i in range(n)) +
        part_time_cost * gp.quicksum(y[j] for j in range(n)),
        GRB.MINIMIZE
    )
    
    # Constraints
    for j in range(n):
        # Full-time staff present in period j: those who started in period j and period (j-1) mod n
        full_time_present = x[j] + x[(j - 1) % n]
        
        # Total staff in period j must meet requirement
        model.addConstr(
            full_time_present + y[j] >= req_values[j],
            name=f"demand_{j}"
        )
        
        # Part-time cap constraint
        model.addConstr(
            y[j] <= part_time_cap_per_period,
            name=f"pt_cap_{j}"
        )
        
        # Minimum full-time staff constraint
        model.addConstr(
            full_time_present >= min_full_time_per_period,
            name=f"min_ft_{j}"
        )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
