import pandas as pd
import os
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def solve():
    # Load data
    table_path = get_data_path('table_3_3.csv')
    params_path = get_data_path('general_parameters.csv')
    
    df = pd.read_csv(table_path)
    params_df = pd.read_csv(params_path)
    
    # Extract parameters
    sales_goal = float(params_df.loc[params_df['Parameter_Name'] == 'monthly_sales_goal', 'Value'].values[0])
    pt_ft_overtime_ratio = float(params_df.loc[params_df['Parameter_Name'] == 'pt_ft_overtime_ratio', 'Value'].values[0])
    
    # Extract clerk data
    ft_row = df[df['Role'] == 'Full-time'].iloc[0]
    pt_row = df[df['Role'] == 'Part-time'].iloc[0]
    
    # Number of clerks (default values from classic problem)
    num_ft = 5
    num_pt = 4
    
    # Calculate normal sales from full employment of all sales clerks
    normal_sales_ft = num_ft * ft_row['Monthly_Working_Hours'] * ft_row['Sales_Volume_Pairs_Per_Hour']
    normal_sales_pt = num_pt * pt_row['Monthly_Working_Hours'] * pt_row['Sales_Volume_Pairs_Per_Hour']
    total_normal_sales = normal_sales_ft + normal_sales_pt
    
    # Create model
    model = gp.Model("Minimize_Overtime_Revised")
    model.setParam('OutputFlag', 0)
    
    # Variables for overtime hours
    y_ft = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name='y_ft')
    y_pt = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name='y_pt')
    
    # Objective: Minimize total overtime hours
    model.setObjective(y_ft + y_pt, GRB.MINIMIZE)
    
    # Constraint: Achieve monthly sales goal
    model.addConstr(
        y_ft * ft_row['Sales_Volume_Pairs_Per_Hour'] + 
        y_pt * pt_row['Sales_Volume_Pairs_Per_Hour'] >= 
        sales_goal - total_normal_sales,
        name='sales_goal'
    )
    
    # Constraint: Part-time overtime must be at least 50% of full-time overtime
    model.addConstr(
        y_pt >= pt_ft_overtime_ratio * y_ft,
        name='pt_ft_overtime_ratio'
    )
    
    # Solve
    model.optimize()
    
    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 4)}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == '__main__':
    solve()
