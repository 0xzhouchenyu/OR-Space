import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load toy data
def load_toy_data(filepath):
    toys = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                'type': row['Toy_Type'].strip(),
                'profit': float(row['Profit_Per_Unit']),
                'wood': float(row['Wood_Required_Per_Unit']),
                'steel': float(row['Steel_Required_Per_Unit']),
            })
    return toys

# Load general parameters
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
toys = load_toy_data(os.path.join(data_dir, 'table_1.csv'))
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

available_wood = params['available_wood']
available_steel = params['available_steel']
profit_premium_bonus = params['profit_premium_bonus']
premium_steel_factor = params['premium_steel_factor']
premium_shift_capacity = params['premium_shift_capacity']

# Create model
model = gp.Model("HausToys_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
# x_standard[toy] = quantity produced on standard shift
# x_premium[toy] = quantity produced on premium shift
# y_standard[toy] = 1 if toy is produced on standard shift
# y_premium[toy] = 1 if toy is produced on premium shift
# y_any[toy] = 1 if toy is produced on any shift

x_standard = {}
x_premium = {}
y_standard = {}
y_premium = {}
y_any = {}

M = 10000

for t in toys:
    toy_type = t['type']
    x_standard[toy_type] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_standard_{toy_type}")
    x_premium[toy_type] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_premium_{toy_type}")
    y_standard[toy_type] = model.addVar(vtype=GRB.BINARY, name=f"y_standard_{toy_type}")
    y_premium[toy_type] = model.addVar(vtype=GRB.BINARY, name=f"y_premium_{toy_type}")
    y_any[toy_type] = model.addVar(vtype=GRB.BINARY, name=f"y_any_{toy_type}")

# Objective: maximize profit
obj = gp.LinExpr()
for t in toys:
    toy_type = t['type']
    profit_standard = t['profit']
    profit_premium = t['profit'] + profit_premium_bonus
    obj += profit_standard * x_standard[toy_type] + profit_premium * x_premium[toy_type]

model.setObjective(obj, GRB.MAXIMIZE)

# Resource constraints
wood_constraint = gp.LinExpr()
steel_constraint = gp.LinExpr()

for t in toys:
    toy_type = t['type']
    wood_constraint += t['wood'] * (x_standard[toy_type] + x_premium[toy_type])
    steel_constraint += t['steel'] * x_standard[toy_type] + t['steel'] * premium_steel_factor * x_premium[toy_type]

model.addConstr(wood_constraint <= available_wood, "Wood_Constraint")
model.addConstr(steel_constraint <= available_steel, "Steel_Constraint")

# Premium shift capacity constraint
premium_capacity_constraint = gp.LinExpr()
for t in toys:
    toy_type = t['type']
    premium_capacity_constraint += x_premium[toy_type]

model.addConstr(premium_capacity_constraint <= premium_shift_capacity, "Premium_Shift_Capacity")

# Each toy type must run entirely on one shift or the other (or not at all)
for t in toys:
    toy_type = t['type']
    # If produced, must be on exactly one shift
    model.addConstr(y_standard[toy_type] + y_premium[toy_type] <= 1, f"Single_Shift_{toy_type}")
    
    # Link y_any to shift binaries
    model.addConstr(y_any[toy_type] == y_standard[toy_type] + y_premium[toy_type], f"Any_Shift_{toy_type}")
    
    # Link quantities to binaries
    model.addConstr(x_standard[toy_type] <= M * y_standard[toy_type], f"Link_Standard_{toy_type}")
    model.addConstr(x_premium[toy_type] <= M * y_premium[toy_type], f"Link_Premium_{toy_type}")

# Truck-train exclusion: if trucks manufactured (any shift), no trains (any shift)
model.addConstr(y_any['truck'] + y_any['train'] <= 1, "Truck_Train_Exclusion")

# Boat-airplane dependency: if boats manufactured (any shift), airplanes must be too (any shift)
model.addConstr(y_any['boat'] <= y_any['airplane'], "Boat_Airplane_Dependency")

# Boat-train limit: total boats <= total trains (summed across shifts)
model.addConstr(x_standard['boat'] + x_premium['boat'] <= x_standard['train'] + x_premium['train'], "Boat_Train_Limit")

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
