import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load demand data
    demand = {}
    with open(os.path.join(base_dir, 'data', 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        quarters = [int(h) for h in header[1:]]
        for row in reader:
            product = row[0].strip()
            for j, q in enumerate(quarters):
                demand[(product, q)] = int(row[j+1])
    
    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, 'data', 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    
    products = ['I', 'II', 'III']
    quarters = [1, 2, 3, 4]
    
    init_inv = params['initial_inventory']
    end_inv_req = params['end_inventory_requirement']
    hours_per_quarter = params['production_hours_per_quarter']
    hours_per_unit = {
        'I': params['product_I_hours_per_unit'],
        'II': params['product_II_hours_per_unit'],
        'III': params['product_III_hours_per_unit']
    }
    delay_penalty = {
        'I': params['delay_penalty_product_I'],
        'II': params['delay_penalty_product_II'],
        'III': params['delay_penalty_product_III']
    }
    inv_cost = params['inventory_cost_per_unit']
    
    normal_hours_cap = {}
    peak_hours_cap = {}
    peak_cost_per_hour = {}
    for t in quarters:
        normal_hours_cap[t] = hours_per_quarter * params[f'normal_hours_cap_fraction_q{t}']
        peak_hours_cap[t] = params[f'peak_hours_cap_q{t}']
        peak_cost_per_hour[t] = params[f'peak_cost_per_hour_q{t}']
    
    model = gp.Model("ProductionScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: production quantities in normal and peak hours
    x_normal = {}
    x_peak = {}
    for p in products:
        for t in quarters:
            x_normal[(p, t)] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_normal_{p}_{t}")
            x_peak[(p, t)] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_peak_{p}_{t}")
    
    # Product I cannot be produced in Q2 (neither normal nor peak)
    x_normal[('I', 2)].ub = 0
    x_peak[('I', 2)].ub = 0
    
    # Inventory variables
    inv = {}
    inv_pos = {}
    inv_neg = {}
    for p in products:
        for t in quarters:
            inv[(p, t)] = model.addVar(lb=-GRB.INFINITY, name=f"inv_{p}_{t}")
            inv_pos[(p, t)] = model.addVar(lb=0, name=f"inv_pos_{p}_{t}")
            inv_neg[(p, t)] = model.addVar(lb=0, name=f"inv_neg_{p}_{t}")
    
    # Peak hours used per quarter
    peak_hours_used = {}
    for t in quarters:
        peak_hours_used[t] = model.addVar(lb=0, name=f"peak_hours_used_{t}")
    
    model.update()
    
    # Inventory balance constraints
    for p in products:
        # Quarter 1
        model.addConstr(inv[(p, 1)] == init_inv + x_normal[(p, 1)] + x_peak[(p, 1)] - demand[(p, 1)])
        # Quarters 2-4
        for t in range(2, 5):
            model.addConstr(inv[(p, t)] == inv[(p, t-1)] + x_normal[(p, t)] + x_peak[(p, t)] - demand[(p, t)])
    
    # Split inventory into positive and negative parts
    for p in products:
        for t in quarters:
            model.addConstr(inv[(p, t)] == inv_pos[(p, t)] - inv_neg[(p, t)])
    
    # End of Q4: inventory must be at least end_inv_req
    for p in products:
        model.addConstr(inv[(p, 4)] >= end_inv_req)
    
    # Normal hours constraint per quarter
    for t in quarters:
        model.addConstr(
            gp.quicksum(hours_per_unit[p] * x_normal[(p, t)] for p in products) <= normal_hours_cap[t]
        )
    
    # Peak hours constraint per quarter
    for t in quarters:
        model.addConstr(
            peak_hours_used[t] == gp.quicksum(hours_per_unit[p] * x_peak[(p, t)] for p in products)
        )
        model.addConstr(peak_hours_used[t] <= peak_hours_cap[t])
    
    # Objective: minimize delay penalties + inventory holding costs + peak hour costs
    obj = gp.quicksum(
        delay_penalty[p] * inv_neg[(p, t)] + inv_cost * inv_pos[(p, t)]
        for p in products for t in quarters
    ) + gp.quicksum(
        peak_cost_per_hour[t] * peak_hours_used[t]
        for t in quarters
    )
    
    model.setObjective(obj, GRB.MINIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
