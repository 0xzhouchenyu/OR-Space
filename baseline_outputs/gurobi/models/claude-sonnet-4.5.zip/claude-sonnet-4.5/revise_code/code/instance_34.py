import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load goods data
def load_goods_data(filepath):
    goods = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            goods[row['Goods_Type'].strip()] = {
                'quantity': int(row['Quantity'].strip()),
                'weight': float(row['Weight_per_Unit'].strip())
            }
    return goods

# Load parameters
def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
goods = load_goods_data(os.path.join(data_dir, 'table_1.csv'))
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

max_cap = params['max_container_capacity']
min_load = params['min_container_load']
min_d_per_container = int(params['min_d_goods_per_container'])
min_c_per_a = int(params['min_c_per_a'])
reduced_cap_with_e = 45

goods_types = list(goods.keys())
quantities = {g: goods[g]['quantity'] for g in goods_types}
weights = {g: goods[g]['weight'] for g in goods_types}

# Upper bound on number of containers
max_containers = 20

# Create model
model = gp.Model("ContainerMinimization")
model.setParam('OutputFlag', 0)

# Decision variables
# x[g, j] = number of units of goods type g in container j
x = {}
for g in goods_types:
    for j in range(max_containers):
        x[g, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{g}_{j}")

# y[j] = 1 if container j is used
y = {}
for j in range(max_containers):
    y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")

# e[j] = 1 if container j contains goods E
e = {}
for j in range(max_containers):
    e[j] = model.addVar(vtype=GRB.BINARY, name=f"e_{j}")

# z[j] = 1 if container j contains goods A
z = {}
for j in range(max_containers):
    z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{j}")

# Objective: minimize number of containers
model.setObjective(gp.quicksum(y[j] for j in range(max_containers)), GRB.MINIMIZE)

# All goods must be transported
for g in goods_types:
    model.addConstr(gp.quicksum(x[g, j] for j in range(max_containers)) == quantities[g], name=f"demand_{g}")

# Link e[j] to presence of goods E
M_E = quantities['E']
for j in range(max_containers):
    model.addConstr(x['E', j] <= M_E * e[j], name=f"E_indicator_upper_{j}")
    model.addConstr(x['E', j] >= e[j], name=f"E_indicator_lower_{j}")

# Container capacity constraint (depends on whether E is present)
for j in range(max_containers):
    total_weight = gp.quicksum(weights[g] * x[g, j] for g in goods_types)
    # If e[j] = 1, capacity is 45; if e[j] = 0, capacity is 60
    # total_weight <= 45 * e[j] + 60 * (1 - e[j]) = 60 - 15 * e[j]
    # But we also need to respect y[j]
    # total_weight <= (60 - 15 * e[j]) * y[j]
    # This is nonlinear, so we use two constraints:
    model.addConstr(total_weight <= max_cap * y[j], name=f"max_cap_normal_{j}")
    model.addConstr(total_weight <= reduced_cap_with_e + (max_cap - reduced_cap_with_e) * (1 - e[j]), name=f"max_cap_with_E_{j}")

# Minimum load constraint
for j in range(max_containers):
    model.addConstr(gp.quicksum(weights[g] * x[g, j] for g in goods_types) >= min_load * y[j], name=f"min_load_{j}")

# Minimum D goods per container (if container is used)
for j in range(max_containers):
    model.addConstr(x['D', j] >= min_d_per_container * y[j], name=f"min_D_{j}")

# If A goods are loaded, at least min_c_per_a C goods must be loaded
M_A = quantities['A']
for j in range(max_containers):
    model.addConstr(x['A', j] <= M_A * z[j], name=f"A_indicator_{j}")
    model.addConstr(x['C', j] >= min_c_per_a * z[j], name=f"C_if_A_{j}")

# Symmetry breaking
for j in range(max_containers - 1):
    model.addConstr(y[j] >= y[j+1], name=f"symmetry_{j}")

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
