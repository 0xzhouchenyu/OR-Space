import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_distance_matrix(filepath):
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        city_labels = header[1:]
        
        dist = []
        cities = []
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
    
    return cities, dist

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            params[row[0]] = row[1]
    return params

def solve_tsp():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    dist_file = os.path.join(data_dir, 'table_1.csv')
    params_file = os.path.join(data_dir, 'general_parameters.csv')
    
    cities, dist = load_distance_matrix(dist_file)
    params = load_general_parameters(params_file)
    
    # Parse parameters
    start_city = params['start_city']
    end_city = params['end_city']
    prohibited_from = params['prohibited_from']
    prohibited_to = params['prohibited_to']
    inspection_arc_from = params['inspection_arc_from']
    inspection_arc_to = params['inspection_arc_to']
    inspection_stop_cost = float(params['inspection_stop_cost'])
    
    # Map city labels to indices
    city_to_idx = {city: i for i, city in enumerate(cities)}
    start_idx = city_to_idx[start_city]
    end_idx = city_to_idx[end_city]
    prohibited_from_idx = city_to_idx[prohibited_from]
    prohibited_to_idx = city_to_idx[prohibited_to]
    inspection_from_idx = city_to_idx[inspection_arc_from]
    inspection_to_idx = city_to_idx[inspection_arc_to]
    
    n = len(cities)
    
    # Create model
    model = gp.Model("TSP_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    for i in range(n):
        for j in range(n):
            if i != j:
                x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
    
    # MTZ variables for subtour elimination
    u = {}
    for i in range(n):
        if i != start_idx:
            u[i] = model.addVar(vtype=GRB.CONTINUOUS, lb=1, ub=n-1, name=f"u_{i}")
    
    # Objective: minimize total distance with inspection cost
    obj = gp.LinExpr()
    for i in range(n):
        for j in range(n):
            if i != j:
                cost = dist[i][j]
                # Add inspection cost if this is the inspection arc
                if i == inspection_from_idx and j == inspection_to_idx:
                    cost += inspection_stop_cost
                obj += cost * x[i, j]
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    # Each city is left exactly once
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1, name=f"leave_{i}")
    
    # Each city is entered exactly once
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(n) if i != j) == 1, name=f"enter_{j}")
    
    # MTZ subtour elimination constraints
    for i in range(n):
        for j in range(n):
            if i != j and i != start_idx and j != start_idx:
                model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1, name=f"mtz_{i}_{j}")
    
    # Prohibited arc constraint: cannot go from prohibited_from to prohibited_to
    if (prohibited_from_idx, prohibited_to_idx) in x:
        model.addConstr(x[prohibited_from_idx, prohibited_to_idx] == 0, name="prohibited_arc")
    
    # Start at start_city constraint
    # The route must leave start_city first (this is implicit in TSP, but we ensure it's the "first" in ordering)
    # Since we're using MTZ with start_idx as depot, u values for other cities will be >= 1
    
    # End at end_city constraint
    # The last arc must enter end_city from some other city and then return to start
    # In a TSP, we visit all cities and return to start
    # To end at end_city before returning to start, we need to ensure the arc into start comes from end_city
    model.addConstr(x[end_idx, start_idx] == 1, name="end_at_end_city")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No solution found")

if __name__ == "__main__":
    solve_tsp()
