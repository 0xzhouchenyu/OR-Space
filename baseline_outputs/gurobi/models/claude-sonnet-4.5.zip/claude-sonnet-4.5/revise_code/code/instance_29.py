import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)

def solve():
    # Load data
    demand_df = pd.read_csv(get_data_path('table_4_3.csv'))
    supply_df = pd.read_csv(get_data_path('table_4_4.csv'))
    params_df = pd.read_csv(get_data_path('general_parameters.csv'))
    
    # Parse parameters
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])
    
    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem
    
    # Parse supply
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = float(row['Number_of_People'])
        suit = [int(x) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }
    
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]
    
    # Create model
    model = gp.Model("RevisedStaffing")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i,j,k] = number of people of type i assigned to city j with specialty k
    x = {}
    for i in types:
        for j in cities:
            for k in specs:
                x[i, j, k] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}_{k}")
    
    # Objective: Maximize number of people with both preferred specialty AND preferred city
    obj_expr = gp.LinExpr()
    for i in types:
        pref_spec = supply[i]['pref_spec']
        pref_city = supply[i]['pref_city']
        obj_expr += x[i, pref_city, pref_spec]
    
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Constraint 1: Supply constraint - cannot exceed available people of each type
    for i in types:
        model.addConstr(
            gp.quicksum(x[i, j, k] for j in cities for k in specs) <= supply[i]['num'],
            name=f"supply_{i}"
        )
    
    # Constraint 2: Demand constraint - must meet demand for each specialty in each city (Priority 1)
    for j in cities:
        for k in specs:
            model.addConstr(
                gp.quicksum(x[i, j, k] for i in types) >= demand[(j, k)],
                name=f"demand_{j}_{k}"
            )
    
    # Constraint 3: Suitability constraint - people can only be assigned to suitable specialties
    for i in types:
        for j in cities:
            for k in specs:
                if k not in supply[i]['suit']:
                    model.addConstr(x[i, j, k] == 0, name=f"suit_{i}_{j}_{k}")
    
    # Constraint 4: Priority 2 - at least p2_target people meet their preferred specialty
    pref_spec_expr = gp.LinExpr()
    for i in types:
        pref_spec = supply[i]['pref_spec']
        for j in cities:
            pref_spec_expr += x[i, j, pref_spec]
    
    model.addConstr(pref_spec_expr >= p2_target, name="priority_2")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {int(model.objVal)}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == '__main__':
    solve()
