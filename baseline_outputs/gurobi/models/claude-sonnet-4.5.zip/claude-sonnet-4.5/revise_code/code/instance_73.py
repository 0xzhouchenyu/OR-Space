import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Read general parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children = int(params['max_children_trip'])
    min_children = int(params['min_children_trip'])
    max_distinct_children = int(params['max_distinct_children_trip'])
    total_cost_budget = float(params['total_cost_budget'])
    bonus_saving = float(params['bonus_saving'])
    min_bob_days = int(params['min_bob_days'])
    
    # Read table_1 for children and costs
    children = []
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Child'].strip()
            cost = float(row['Cost'].strip())
            children.append(name)
            costs[name] = cost
    
    # Create the optimization model
    model = gp.Model("FamilyTripTwoDays")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[child, day] = 1 if child attends on day (1 or 2)
    x = {}
    for child in children:
        for day in [1, 2]:
            x[child, day] = model.addVar(vtype=GRB.BINARY, name=f"x_{child}_{day}")
    
    # y[child] = 1 if child attends both days (for bonus)
    y = {}
    for child in children:
        y[child] = model.addVar(vtype=GRB.BINARY, name=f"y_{child}")
    
    # z[child] = 1 if child attends at least one day (for distinct count)
    z = {}
    for child in children:
        z[child] = model.addVar(vtype=GRB.BINARY, name=f"z_{child}")
    
    model.update()
    
    # Objective: minimize total cost minus bonus savings
    total_cost = gp.quicksum(costs[child] * (x[child, 1] + x[child, 2]) for child in children)
    total_bonus = gp.quicksum(bonus_saving * y[child] for child in children)
    model.setObjective(total_cost - total_bonus, GRB.MINIMIZE)
    
    # Constraints: min and max children per day
    for day in [1, 2]:
        model.addConstr(gp.quicksum(x[child, day] for child in children) >= min_children, f"MinChildren_day{day}")
        model.addConstr(gp.quicksum(x[child, day] for child in children) <= max_children, f"MaxChildren_day{day}")
    
    # Constraint: total distinct children across both days
    model.addConstr(gp.quicksum(z[child] for child in children) <= max_distinct_children, "MaxDistinctChildren")
    
    # Link z[child] to x[child, day]: z[child] = 1 if child attends at least one day
    for child in children:
        model.addConstr(z[child] >= x[child, 1], f"z_link1_{child}")
        model.addConstr(z[child] >= x[child, 2], f"z_link2_{child}")
        model.addConstr(z[child] <= x[child, 1] + x[child, 2], f"z_link3_{child}")
    
    # Link y[child] to x[child, day]: y[child] = 1 if child attends both days
    for child in children:
        model.addConstr(y[child] <= x[child, 1], f"y_link1_{child}")
        model.addConstr(y[child] <= x[child, 2], f"y_link2_{child}")
        model.addConstr(y[child] >= x[child, 1] + x[child, 2] - 1, f"y_link3_{child}")
    
    # Constraint: total cost budget
    model.addConstr(total_cost - total_bonus <= total_cost_budget, "TotalCostBudget")
    
    # Constraint: Bob must attend at least min_bob_days days
    model.addConstr(x['Bob', 1] + x['Bob', 2] >= min_bob_days, "MinBobDays")
    
    # Relationship constraints for each day
    for day in [1, 2]:
        # Alice and Diana cannot both be taken on the same day
        model.addConstr(x['Alice', day] + x['Diana', day] <= 1, f"AliceDianaConflict_day{day}")
        
        # Bob and Charlie cannot both be taken on the same day
        model.addConstr(x['Bob', day] + x['Charlie', day] <= 1, f"BobCharlieConflict_day{day}")
        
        # Charlie must be accompanied by Diana on the same day
        model.addConstr(x['Charlie', day] <= x['Diana', day], f"CharlieRequiresDiana_day{day}")
        
        # Diana must be accompanied by Ella on the same day
        model.addConstr(x['Diana', day] <= x['Ella', day], f"DianaRequiresElla_day{day}")
    
    # Availability constraints
    # Charlie only available on day 2
    model.addConstr(x['Charlie', 1] == 0, "Charlie_day1_unavailable")
    
    # Diana only available on day 2
    model.addConstr(x['Diana', 1] == 0, "Diana_day1_unavailable")
    
    # Alice only available on day 1
    model.addConstr(x['Alice', 2] == 0, "Alice_day2_unavailable")
    
    # Solve
    model.optimize()
    
    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
