import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

# Extract parameters
fabric_production_rate = params['fabric_production_rate']
min_curtain_fabric_sales = params['min_curtain_fabric_sales']
min_clothing_fabric_sales = params['min_clothing_fabric_sales']
day_shift_regular_capacity = params['day_shift_regular_capacity']
night_shift_regular_capacity = params['night_shift_regular_capacity']
day_overtime_limit = params['day_overtime_limit']
night_overtime_limit = params['night_overtime_limit']
day_overtime_penalty = params['day_overtime_penalty']
night_overtime_penalty = params['night_overtime_penalty']
day_min_utilization_ratio = params['day_min_utilization_ratio']
night_min_utilization_ratio = params['night_min_utilization_ratio']

# Convert sales requirements to hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

# Create model
model = gp.Model("Textile_Factory_Two_Shifts")
model.setParam('OutputFlag', 0)

# Decision variables
# Regular hours for each fabric type in each shift
day_clothing_regular = model.addVar(lb=0, name="day_clothing_regular")
day_curtain_regular = model.addVar(lb=0, name="day_curtain_regular")
night_clothing_regular = model.addVar(lb=0, name="night_clothing_regular")
night_curtain_regular = model.addVar(lb=0, name="night_curtain_regular")

# Overtime hours for each fabric type in each shift
day_clothing_overtime = model.addVar(lb=0, name="day_clothing_overtime")
day_curtain_overtime = model.addVar(lb=0, name="day_curtain_overtime")
night_clothing_overtime = model.addVar(lb=0, name="night_clothing_overtime")
night_curtain_overtime = model.addVar(lb=0, name="night_curtain_overtime")

# Objective: minimize total overtime penalty
model.setObjective(
    day_overtime_penalty * (day_clothing_overtime + day_curtain_overtime) +
    night_overtime_penalty * (night_clothing_overtime + night_curtain_overtime),
    GRB.MINIMIZE
)

# Constraints

# 1. Meet minimum sales requirements
model.addConstr(
    day_clothing_regular + day_clothing_overtime + 
    night_clothing_regular + night_clothing_overtime >= min_clothing_hours,
    "min_clothing_requirement"
)

model.addConstr(
    day_curtain_regular + day_curtain_overtime + 
    night_curtain_regular + night_curtain_overtime >= min_curtain_hours,
    "min_curtain_requirement"
)

# 2. Regular hours capacity constraints
model.addConstr(
    day_clothing_regular + day_curtain_regular <= day_shift_regular_capacity,
    "day_regular_capacity"
)

model.addConstr(
    night_clothing_regular + night_curtain_regular <= night_shift_regular_capacity,
    "night_regular_capacity"
)

# 3. Overtime limits
model.addConstr(
    day_clothing_overtime + day_curtain_overtime <= day_overtime_limit,
    "day_overtime_limit"
)

model.addConstr(
    night_clothing_overtime + night_curtain_overtime <= night_overtime_limit,
    "night_overtime_limit"
)

# 4. Minimum utilization requirements
# Total regular hours available
total_regular_capacity = day_shift_regular_capacity + night_shift_regular_capacity

model.addConstr(
    day_clothing_regular + day_curtain_regular >= day_min_utilization_ratio * total_regular_capacity,
    "day_min_utilization"
)

model.addConstr(
    night_clothing_regular + night_curtain_regular >= night_min_utilization_ratio * total_regular_capacity,
    "night_min_utilization"
)

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
