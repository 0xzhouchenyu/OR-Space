import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_restaurant_data(filepath):
    """Load restaurant data from CSV file."""
    restaurants = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'standard_staff_hours': float(row['Standard_Staff_Hours'].strip()),
                'premium_staff_hours': float(row['Premium_Staff_Hours'].strip())
            })
    return restaurants

def load_general_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    return params

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
restaurants = load_restaurant_data(os.path.join(script_dir, 'data', 'table_1.csv'))
params = load_general_parameters(os.path.join(script_dir, 'data', 'general_parameters.csv'))

budget = params['investment_budget']
premium_revenue_uplift = params['premium_revenue_uplift']
premium_upgrade_cost = params['premium_upgrade_cost']
staff_hours_cap = params['staff_hours_cap']

# Create model
model = gp.Model("Restaurant_Investment_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
# x[r]: binary, whether to buy restaurant r
# y[r]: binary, whether to operate restaurant r in Premium mode (only if bought)
x = {}
y = {}
for r in restaurants:
    x[r['name']] = model.addVar(vtype=GRB.BINARY, name=f"buy_{r['name']}")
    y[r['name']] = model.addVar(vtype=GRB.BINARY, name=f"premium_{r['name']}")

# Objective: maximize total annual revenue
# Revenue = base revenue + (premium uplift * base revenue if premium)
revenue_expr = gp.LinExpr()
for r in restaurants:
    base_revenue = r['revenue']
    premium_revenue = base_revenue * premium_revenue_uplift
    # Total revenue for restaurant r = base_revenue * x[r] + premium_revenue * y[r]
    revenue_expr += base_revenue * x[r['name']] + premium_revenue * y[r['name']]

model.setObjective(revenue_expr, GRB.MAXIMIZE)

# Constraint: Budget (acquisition cost + premium upgrade cost)
budget_expr = gp.LinExpr()
for r in restaurants:
    budget_expr += r['cost'] * x[r['name']] + premium_upgrade_cost * y[r['name']]
model.addConstr(budget_expr <= budget, "Budget_Constraint")

# Constraint: Staff hours cap
staff_expr = gp.LinExpr()
for r in restaurants:
    # If bought and standard: standard_staff_hours * (x - y)
    # If bought and premium: premium_staff_hours * y
    # Total = standard_staff_hours * x + (premium_staff_hours - standard_staff_hours) * y
    staff_expr += r['standard_staff_hours'] * x[r['name']]
    staff_expr += (r['premium_staff_hours'] - r['standard_staff_hours']) * y[r['name']]
model.addConstr(staff_expr <= staff_hours_cap, "Staff_Hours_Constraint")

# Constraint: Can only operate in premium mode if restaurant is bought
for r in restaurants:
    model.addConstr(y[r['name']] <= x[r['name']], f"Premium_Requires_Buy_{r['name']}")

# Constraint: If Restaurant D is purchased, Restaurant A cannot be purchased
model.addConstr(x['Restaurant_D'] + x['Restaurant_A'] <= 1, "D_A_Exclusion_Constraint")

# Solve
model.optimize()

# Output result
if model.status == GRB.OPTIMAL:
    obj_value = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_value}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
