import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')

    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']

    num_customers = int(params['num_customers'])
    truck_capacity = float(params['truck_capacity'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])

    depot_str = params['depot_coordinates'].strip('"').strip('()')
    depot_x, depot_y = map(float, depot_str.split(','))

    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])

    coords = [(depot_x, depot_y)]
    demands_list = [0]
    tw_list = [(depot_tw_start, depot_tw_end)]
    svc_list = [0]
    outsource_cost = [0]
    mandatory_external = [0]

    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((float(row['Coordinates_X']), float(row['Coordinates_Y'])))
            demands_list.append(float(row['Demand']))
            tw_list.append((float(row['Time_Window_Start']), float(row['Time_Window_End'])))
            svc_list.append(float(row['Service_Duration']))
            outsource_cost.append(float(row['Outsource_Cost']))
            mandatory_external.append(int(row['Mandatory_External']))

    n = len(coords)
    N = list(range(1, n))
    V = list(range(n))

    dist = {}
    for i in V:
        for j in V:
            dist[i, j] = calculate_distance(coords[i], coords[j])

    A = []
    for i in V:
        for j in V:
            if i == j:
                continue
            if i != 0 and j != 0:
                if tw_list[i][0] + svc_list[i] + dist[i, j] > tw_list[j][1]:
                    continue
            if i == 0 and j != 0:
                if tw_list[0][0] + dist[0, j] > tw_list[j][1]:
                    continue
            if i != 0 and j == 0:
                if tw_list[i][0] + svc_list[i] + dist[i, 0] > tw_list[0][1]:
                    continue
            A.append((i, j))

    model = gp.Model("VRPHTW_Revised")
    model.setParam('OutputFlag', 0)

    x = model.addVars(A, vtype=GRB.BINARY, name="x")
    t = model.addVars(V, lb=0, name="t")
    y = model.addVars(N, vtype=GRB.BINARY, name="y")

    model.setObjective(
        gp.quicksum(dist[i, j] * x[i, j] for i, j in A) +
        gp.quicksum(outsource_cost[i] * y[i] for i in N),
        GRB.MINIMIZE
    )

    model.addConstr(gp.quicksum(x[0, j] for j in N if (0, j) in A) <= inhouse_truck_limit, name="fleet_limit")

    for i in N:
        if mandatory_external[i] == 1:
            model.addConstr(y[i] == 1, name=f"mandatory_external_{i}")
        else:
            model.addConstr(
                gp.quicksum(x[j, i] for j in V if (j, i) in A) + y[i] == 1,
                name=f"service_{i}"
            )
            model.addConstr(
                gp.quicksum(x[j, i] for j in V if (j, i) in A) ==
                gp.quicksum(x[i, j] for j in V if (i, j) in A),
                name=f"flow_{i}"
            )

    for i in V:
        model.addConstr(t[i] >= tw_list[i][0], name=f"tw_start_{i}")
        model.addConstr(t[i] <= tw_list[i][1], name=f"tw_end_{i}")

    M_val = tw_list[0][1] + max(svc_list)
    for i, j in A:
        if j != 0:
            model.addConstr(
                t[i] + svc_list[i] + dist[i, j] <= t[j] + M_val * (1 - x[i, j]),
                name=f"time_consistency_{i}_{j}"
            )

    K = list(range(inhouse_truck_limit))
    u = model.addVars(N, K, vtype=GRB.CONTINUOUS, lb=0, ub=truck_capacity, name="u")

    for k in K:
        for i in N:
            if mandatory_external[i] == 0:
                model.addConstr(
                    u[i, k] >= demands_list[i] * gp.quicksum(x[0, j] for j in N if (0, j) in A and j == i) -
                    truck_capacity * (1 - gp.quicksum(x[0, j] for j in N if (0, j) in A and j == i)),
                    name=f"load_init_{i}_{k}"
                )

    for k in K:
        for i, j in A:
            if i != 0 and j != 0 and mandatory_external[i] == 0 and mandatory_external[j] == 0:
                model.addConstr(
                    u[j, k] >= u[i, k] + demands_list[j] - truck_capacity * (1 - x[i, j]),
                    name=f"capacity_flow_{i}_{j}_{k}"
                )
                model.addConstr(
                    u[j, k] <= u[i, k] + demands_list[j] + truck_capacity * (1 - x[i, j]),
                    name=f"capacity_flow_ub_{i}_{j}_{k}"
                )

    for k in K:
        for i in N:
            if mandatory_external[i] == 0:
                model.addConstr(u[i, k] <= truck_capacity, name=f"capacity_limit_{i}_{k}")

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

solve()
