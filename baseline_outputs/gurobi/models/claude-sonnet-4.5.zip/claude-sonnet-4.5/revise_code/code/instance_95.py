import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

def load_table_1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    weeks = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })
    return weeks

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

weeks_data = load_table_1(data_dir)
params = load_general_parameters(data_dir)

storage_cost = params['storage_cost_per_thousand_boxes']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']
n_weeks = len(weeks_data)

# Create model
model = gp.Model("Beverage_Production_Planning_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
# x[t] = production in week t (in thousand boxes)
# s[t] = inventory at end of week t (in thousand boxes)
# y_microclean = binary variable: 1 if Week 2 production exceeds microclean threshold
x = model.addVars(n_weeks, lb=0, name="x")
s = model.addVars(n_weeks, lb=0, name="s")
y_microclean = model.addVar(vtype=GRB.BINARY, name="y_microclean")

# Set capacity constraints
for t in range(n_weeks):
    x[t].ub = weeks_data[t]['capacity']

# Objective: minimize total production cost + storage cost + microclean cost
obj = gp.quicksum(weeks_data[t]['cost'] * x[t] for t in range(n_weeks))
obj += gp.quicksum(storage_cost * s[t] for t in range(n_weeks))
obj += week2_microclean_fee * y_microclean

model.setObjective(obj, GRB.MINIMIZE)

# Inventory balance constraints
for t in range(n_weeks):
    if t == 0:
        model.addConstr(x[t] - s[t] == weeks_data[t]['demand'], f"balance_week_{t+1}")
    else:
        model.addConstr(s[t-1] + x[t] - s[t] == weeks_data[t]['demand'], f"balance_week_{t+1}")

# Week 2 microclean constraint
# If x[1] > week2_microclean_threshold, then y_microclean = 1
# x[1] <= week2_microclean_threshold + M * y_microclean
# x[1] >= week2_microclean_threshold + epsilon - M * (1 - y_microclean)
M = 1000  # Big-M value

# If y_microclean = 0, then x[1] <= week2_microclean_threshold
model.addConstr(x[1] <= week2_microclean_threshold + M * y_microclean, "microclean_trigger")

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
