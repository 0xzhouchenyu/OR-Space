import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load general parameters
    params_file = os.path.join(base_dir, 'data', 'general_parameters.csv')
    params = {}
    with open(params_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['parameter']] = float(row['value'])
    
    # Load batch processing times
    table_file = os.path.join(base_dir, 'data', 'table_1.csv')
    batches = []
    processing_times = []
    with open(table_file, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            batch_id = int(row[0])
            times = [math.ceil(float(row[j+1])) for j in range(3)]
            batches.append(batch_id)
            processing_times.append(times)
    
    return params, batches, processing_times

def solve():
    params, batches, processing_times = load_data()
    
    T = int(params['planning_horizon_T'])
    energy_costs = [params['energy_cost_v1'], params['energy_cost_v2'], params['energy_cost_v3']]
    peak_multiplier = params['peak_energy_multiplier']
    peak_cap = params['peak_energy_cap']
    makespan_weight = params['makespan_weight']
    energy_weight = params['energy_weight']
    
    num_batches = len(batches)
    num_vats = 3
    
    # Peak periods are 6, 7, 8 (1-indexed)
    peak_periods = [6, 7, 8]
    
    # Maintenance window on Vat 2 (index 1) during periods 4 and 5
    maintenance_vat = 1
    maintenance_periods = [4, 5]
    
    model = gp.Model("DyeingSchedule")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[b, v, t] = 1 if batch b starts on vat v at time t
    x = {}
    for b in range(num_batches):
        for v in range(num_vats):
            for t in range(1, T + 1):
                x[b, v, t] = model.addVar(vtype=GRB.BINARY, name=f"x_{b}_{v}_{t}")
    
    # y[v, t] = 1 if vat v is active at time t
    y = {}
    for v in range(num_vats):
        for t in range(1, T + 1):
            y[v, t] = model.addVar(vtype=GRB.BINARY, name=f"y_{v}_{t}")
    
    # makespan variable
    makespan = model.addVar(vtype=GRB.CONTINUOUS, name="makespan")
    
    model.update()
    
    # Constraint 1: Each batch starts exactly once on each vat
    for b in range(num_batches):
        for v in range(num_vats):
            model.addConstr(gp.quicksum(x[b, v, t] for t in range(1, T + 1)) == 1,
                          name=f"start_once_{b}_{v}")
    
    # Constraint 2: No overlapping batches on the same vat
    for v in range(num_vats):
        for t in range(1, T + 1):
            model.addConstr(
                gp.quicksum(x[b, v, tau] 
                           for b in range(num_batches) 
                           for tau in range(max(1, t - processing_times[b][v] + 1), t + 1)
                           if tau <= T) <= 1,
                name=f"no_overlap_{v}_{t}"
            )
    
    # Constraint 3: Sequential processing (batch must complete vat v before starting vat v+1)
    for b in range(num_batches):
        for v in range(num_vats - 1):
            # Completion time on vat v
            for t1 in range(1, T + 1):
                for t2 in range(1, T + 1):
                    # If batch b starts at t1 on vat v, it completes at t1 + processing_times[b][v] - 1
                    # If batch b starts at t2 on vat v+1, we need t2 >= t1 + processing_times[b][v] - 1
                    # Actually, with our convention: completion at period t means next vat can start at t
                    # So if starts at t1, completes at t1 + duration - 1, next can start at t1 + duration - 1
                    # Let's use: start_next >= start_prev + duration_prev
                    model.addConstr(
                        t2 * x[b, v + 1, t2] >= (t1 + processing_times[b][v]) * x[b, v, t1],
                        name=f"seq_{b}_{v}_{t1}_{t2}"
                    )
    
    # Constraint 4: Maintenance window on Vat 2
    for b in range(num_batches):
        for t_start in range(1, T + 1):
            duration = processing_times[b][maintenance_vat]
            # Check if this batch would occupy vat during maintenance
            for t_maint in maintenance_periods:
                if t_start <= t_maint <= t_start + duration - 1:
                    model.addConstr(x[b, maintenance_vat, t_start] == 0,
                                  name=f"maintenance_{b}_{t_start}")
                    break
    
    # Constraint 5: Link y to x (vat is active if any batch is being processed)
    for v in range(num_vats):
        for t in range(1, T + 1):
            # Vat v is active at time t if any batch b started at tau and is still running at t
            model.addConstr(
                y[v, t] >= gp.quicksum(x[b, v, tau]
                                      for b in range(num_batches)
                                      for tau in range(max(1, t - processing_times[b][v] + 1), t + 1)
                                      if tau <= T),
                name=f"active_lower_{v}_{t}"
            )
            model.addConstr(
                y[v, t] <= gp.quicksum(x[b, v, tau]
                                      for b in range(num_batches)
                                      for tau in range(max(1, t - processing_times[b][v] + 1), t + 1)
                                      if tau <= T),
                name=f"active_upper_{v}_{t}"
            )
    
    # Constraint 6: Makespan definition
    for b in range(num_batches):
        for t in range(1, T + 1):
            model.addConstr(
                makespan >= (t + processing_times[b][num_vats - 1] - 1) * x[b, num_vats - 1, t],
                name=f"makespan_{b}_{t}"
            )
    
    # Constraint 7: Peak energy cap
    peak_energy_usage = gp.quicksum(
        y[v, t] * energy_costs[v] * peak_multiplier
        for v in range(num_vats)
        for t in peak_periods
    )
    model.addConstr(peak_energy_usage <= peak_cap, name="peak_cap")
    
    # Objective: weighted sum of makespan and energy cost
    total_energy_cost = gp.quicksum(
        y[v, t] * energy_costs[v] * (peak_multiplier if t in peak_periods else 1.0)
        for v in range(num_vats)
        for t in range(1, T + 1)
    )
    
    objective = makespan_weight * makespan + energy_weight * total_energy_cost
    model.setObjective(objective, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == '__main__':
    solve()
