import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read table_1.csv
    workshops = []
    capacities = {}
    rates = {}
    
    filepath = os.path.join(data_dir, "table_1.csv")
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    components = [1, 2, 3]
    shifts = ['day', 'night']
    
    # Read general_parameters.csv
    params = {}
    filepath = os.path.join(data_dir, "general_parameters.csv")
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    
    # Extract parameters
    regular_hours_limit = {}
    overtime_capacity = {}
    bigM_shift = {}
    
    for w in workshops:
        for s in shifts:
            regular_hours_limit[(w, s)] = params[f'regular_hours_limit_{s}_{w}']
            overtime_capacity[(w, s)] = params[f'overtime_capacity_{s}_{w}']
        bigM_shift[w] = params[f'bigM_shift_{w}']
    
    penalty_night_hour = params['penalty_night_hour']
    penalty_overtime_hour = params['penalty_overtime_hour']
    penalty_shortage_per_unit = params['penalty_shortage_per_unit']
    z_target = params['z_target']
    
    # Create model
    model = gp.Model("Revised_Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_reg[(w, s, c)] = regular hours workshop w allocates to component c in shift s
    x_reg = {}
    for w in workshops:
        for s in shifts:
            for c in components:
                x_reg[(w, s, c)] = model.addVar(lb=0, name=f"x_reg_{w}_{s}_{c}")
    
    # x_ot[(w, s, c)] = overtime hours workshop w allocates to component c in shift s
    x_ot = {}
    for w in workshops:
        for s in shifts:
            for c in components:
                x_ot[(w, s, c)] = model.addVar(lb=0, name=f"x_ot_{w}_{s}_{c}")
    
    # y[(w, s)] = binary indicator: 1 if workshop w is active in shift s
    y = {}
    for w in workshops:
        for s in shifts:
            y[(w, s)] = model.addVar(vtype=GRB.BINARY, name=f"y_{w}_{s}")
    
    # z = number of completed products
    z = model.addVar(lb=0, name="z")
    
    # shortage = max(0, z_target - z)
    shortage = model.addVar(lb=0, name="shortage")
    
    model.update()
    
    # Objective: maximize z - penalties
    # Penalties: night hours (regular only), overtime hours, shortage
    night_penalty = gp.quicksum(
        penalty_night_hour * gp.quicksum(x_reg[(w, 'night', c)] for c in components)
        for w in workshops
    )
    
    overtime_penalty = gp.quicksum(
        penalty_overtime_hour * gp.quicksum(x_ot[(w, s, c)] for c in components)
        for w in workshops for s in shifts
    )
    
    shortage_penalty = penalty_shortage_per_unit * shortage
    
    model.setObjective(z - night_penalty - overtime_penalty - shortage_penalty, GRB.MAXIMIZE)
    
    # Constraints
    
    # 1. Regular hours capacity per workshop per shift
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x_reg[(w, s, c)] for c in components) <= regular_hours_limit[(w, s)],
                name=f"regular_capacity_{w}_{s}"
            )
    
    # 2. Overtime capacity per workshop per shift
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x_ot[(w, s, c)] for c in components) <= overtime_capacity[(w, s)],
                name=f"overtime_capacity_{w}_{s}"
            )
    
    # 3. Total hours per workshop across all shifts and components <= original capacity
    for w in workshops:
        model.addConstr(
            gp.quicksum(x_reg[(w, s, c)] + x_ot[(w, s, c)] for s in shifts for c in components) <= capacities[w],
            name=f"total_capacity_{w}"
        )
    
    # 4. Link y[(w, s)] to hours: if any hours used in shift s by workshop w, then y[(w, s)] = 1
    for w in workshops:
        for s in shifts:
            total_hours = gp.quicksum(x_reg[(w, s, c)] + x_ot[(w, s, c)] for c in components)
            model.addConstr(
                total_hours <= bigM_shift[w] * y[(w, s)],
                name=f"active_link_{w}_{s}"
            )
    
    # 5. At most 2 workshops active per shift
    for s in shifts:
        model.addConstr(
            gp.quicksum(y[(w, s)] for w in workshops) <= 2,
            name=f"max_workshops_{s}"
        )
    
    # 6. z <= total production of each component
    for c in components:
        total_production = gp.quicksum(
            rates[(w, c)] * (x_reg[(w, s, c)] + x_ot[(w, s, c)])
            for w in workshops for s in shifts
        )
        model.addConstr(
            z <= total_production,
            name=f"min_component_{c}"
        )
    
    # 7. Shortage constraint
    model.addConstr(shortage >= z_target - z, name="shortage_def")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.6f}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
