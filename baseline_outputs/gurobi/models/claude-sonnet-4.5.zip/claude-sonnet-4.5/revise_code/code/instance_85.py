import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'data', 'table_1.csv')
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'data', 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    machine_avail = params['machine_time_available']
    craftsman_regular_avail = params['craftsman_regular_time_available']
    craftsman_overtime_avail = params['craftsman_overtime_available']
    machine_cost = params['machine_time_cost']
    craftsman_cost = params['craftsman_time_cost']
    craftsman_overtime_cost = params['craftsman_overtime_cost']
    rev_X = params['revenue_product_X']
    rev_Y = params['revenue_product_Y']
    min_X = params['min_batches_product_X']
    product_Y_QA_threshold = params['product_Y_QA_threshold']
    product_Y_QA_fee = params['product_Y_QA_fee']
    
    # Create Gurobi model
    model = gp.Model("Production_Planning_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    X = model.addVar(lb=0, name="X")
    Y = model.addVar(lb=0, name="Y")
    
    # Binary variable for QA fee trigger
    qa_triggered = model.addVar(vtype=GRB.BINARY, name="qa_triggered")
    
    # Variables for craftsman time usage
    craftsman_regular_used = model.addVar(lb=0, name="craftsman_regular_used")
    craftsman_overtime_used = model.addVar(lb=0, name="craftsman_overtime_used")
    
    model.update()
    
    # Machine time constraint
    machine_hours_used = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0
    model.addConstr(machine_hours_used <= machine_avail, "Machine_Time_Constraint")
    
    # Craftsman time constraints
    craftsman_hours_needed = (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0
    model.addConstr(craftsman_regular_used + craftsman_overtime_used == craftsman_hours_needed, "Craftsman_Time_Balance")
    model.addConstr(craftsman_regular_used <= craftsman_regular_avail, "Craftsman_Regular_Limit")
    model.addConstr(craftsman_overtime_used <= craftsman_overtime_avail, "Craftsman_Overtime_Limit")
    
    # Minimum production of X
    model.addConstr(X >= min_X, "Min_Production_X")
    
    # QA fee trigger constraints
    # If Y > 60, then qa_triggered = 1
    M = 1000  # Big M (large enough upper bound)
    model.addConstr(Y <= product_Y_QA_threshold + M * qa_triggered, "QA_Trigger_Upper")
    model.addConstr(Y >= product_Y_QA_threshold + 0.0001 - M * (1 - qa_triggered), "QA_Trigger_Lower")
    
    # Objective: maximize revenue - costs
    revenue = rev_X * X + rev_Y * Y
    machine_cost_total = machine_cost * machine_hours_used
    craftsman_cost_total = craftsman_cost * craftsman_regular_used + craftsman_overtime_cost * craftsman_overtime_used
    qa_cost = product_Y_QA_fee * qa_triggered
    
    profit = revenue - machine_cost_total - craftsman_cost_total - qa_cost
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val:.2f}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
