import csv
import math
import os
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)

def solve():
    # Read orders
    table_1_path = get_data_path('table_1.csv')
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
    
    # Read parameters
    params_path = get_data_path('general_parameters.csv')
    std_widths = []
    pattern_setup_penalty = 0
    wide_roll_threshold_width = 0
    wide_roll_extra_setup_penalty = 0
    
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'standard_width_1':
                std_widths.append(float(row['Value']))
            elif row['Parameter_Name'] == 'standard_width_2':
                std_widths.append(float(row['Value']))
            elif row['Parameter_Name'] == 'pattern_setup_penalty':
                pattern_setup_penalty = float(row['Value'])
            elif row['Parameter_Name'] == 'wide_roll_threshold_width':
                wide_roll_threshold_width = float(row['Value'])
            elif row['Parameter_Name'] == 'wide_roll_extra_setup_penalty':
                wide_roll_extra_setup_penalty = float(row['Value'])
    
    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    
    total_required_area = sum(w * l for w, l in zip(widths, lengths))
    
    # Generate cutting patterns for each standard width
    patterns_by_std_width = {}
    for idx, sw in enumerate(std_widths):
        patterns = []
        def build_pattern(index, current_pattern, current_sum):
            if index == len(widths):
                if any(c > 0 for c in current_pattern):
                    patterns.append(current_pattern[:])
                return
            
            max_count = int(math.floor((sw - current_sum + 1e-7) / widths[index]))
            for count in range(max_count + 1):
                build_pattern(index + 1, current_pattern + [count], current_sum + count * widths[index])
        
        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {'sw': sw, 'patterns': patterns}
    
    # Create Gurobi model
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_vars[(idx, i)] = length of standard roll idx using pattern i
    x_vars = {}
    # y_vars[(idx, i)] = binary indicator if pattern i on standard roll idx is used
    y_vars = {}
    
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            x_vars[(idx, i)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{idx}_{i}")
            y_vars[(idx, i)] = model.addVar(vtype=GRB.BINARY, name=f"y_{idx}_{i}")
    
    model.update()
    
    # Objective: Minimize total waste
    # Waste = total area used + pattern setup penalties + wide roll extra penalties - total required area
    
    # Total area used by cutting patterns
    total_area_expr = gp.quicksum(
        data['sw'] * x_vars[(idx, i)]
        for idx, data in patterns_by_std_width.items()
        for i in range(len(data['patterns']))
    )
    
    # Pattern setup penalties
    pattern_setup_expr = gp.quicksum(
        pattern_setup_penalty * y_vars[(idx, i)]
        for idx, data in patterns_by_std_width.items()
        for i in range(len(data['patterns']))
    )
    
    # Wide roll extra setup penalties (only for standard widths >= threshold)
    wide_roll_extra_expr = gp.quicksum(
        wide_roll_extra_setup_penalty * y_vars[(idx, i)]
        for idx, data in patterns_by_std_width.items()
        if data['sw'] >= wide_roll_threshold_width
        for i in range(len(data['patterns']))
    )
    
    # Total waste = area used + setup penalties + wide roll penalties - required area
    waste_expr = total_area_expr + pattern_setup_expr + wide_roll_extra_expr - total_required_area
    
    model.setObjective(waste_expr, GRB.MINIMIZE)
    
    # Constraints: Satisfy length requirements for each order
    for j in range(len(widths)):
        model.addConstr(
            gp.quicksum(
                p[j] * x_vars[(idx, i)]
                for idx, data in patterns_by_std_width.items()
                for i, p in enumerate(data['patterns'])
            ) >= lengths[j],
            name=f"demand_{j}"
        )
    
    # Big-M constraints: Link x and y variables
    # If y[(idx, i)] = 0, then x[(idx, i)] = 0
    # If y[(idx, i)] = 1, then x[(idx, i)] can be any non-negative value
    M = sum(lengths)  # A sufficiently large number
    for idx, data in patterns_by_std_width.items():
        for i in range(len(data['patterns'])):
            model.addConstr(
                x_vars[(idx, i)] <= M * y_vars[(idx, i)],
                name=f"link_{idx}_{i}"
            )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        objective_value = model.objVal
        print(f"FINAL_OBJ_VALUE: {objective_value}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    solve()
