import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

# Get the data directory path
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load warehouse data
warehouses_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
warehouses = []
supply = {}
for row in warehouses_data:
    name = row['Warehouse']
    warehouses.append(name)
    supply[name] = int(row['Empty_Containers'])

# Load port data
ports_data = load_csv_data(os.path.join(data_dir, 'table_2.csv'))
ports = []
demand = {}
for row in ports_data:
    name = row['Port']
    ports.append(name)
    demand[name] = int(row['Container_Demand'])

# Load distance data
distance_data = load_csv_data(os.path.join(data_dir, 'table_3.csv'))
distance = {}
for row in distance_data:
    wh = row['Warehouse']
    for port in ports:
        distance[(wh, port)] = float(row[port])

# Load general parameters
params_data = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
params = {}
for row in params_data:
    params[row['Parameter_Name']] = float(row['Value'])

cost_per_km = params['cost_per_km']
truck_capacity = params['truck_capacity']
adriatic_pool_shortage_trigger = params['adriatic_pool_shortage_trigger']
adriatic_pool_recovery_fee = params['adriatic_pool_recovery_fee']

# Load shortage penalty data
shortage_data = load_csv_data(os.path.join(data_dir, 'shortage_penalty.csv'))
shortage_charge = {}
grace_containers = {}
recovery_fee = {}
for row in shortage_data:
    port = row['Port']
    shortage_charge[port] = float(row['Shortage_Charge'])
    grace_containers[port] = float(row['Grace_Containers'])
    recovery_fee[port] = float(row['Recovery_Fee'])

# Adriatic ports
adriatic_ports = ['Venice', 'Ancona', 'Bari']

# Create model
model = gp.Model("Container_Transportation_Revised")
model.setParam('OutputFlag', 0)

# Decision variables: number of containers from warehouse i to port j
x = {}
for i in warehouses:
    for j in ports:
        x[(i, j)] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}")

# Shortage variables for each port
shortage = {}
for j in ports:
    shortage[j] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"shortage_{j}")

# Binary variables for recovery desk activation at each port
recovery_desk = {}
for j in ports:
    recovery_desk[j] = model.addVar(vtype=GRB.BINARY, name=f"recovery_{j}")

# Binary variable for Adriatic regional recovery desk
adriatic_recovery = model.addVar(vtype=GRB.BINARY, name="adriatic_recovery")

model.update()

# Supply constraints
for i in warehouses:
    model.addConstr(gp.quicksum(x[(i, j)] for j in ports) <= supply[i], name=f"supply_{i}")

# Demand and shortage constraints
for j in ports:
    model.addConstr(gp.quicksum(x[(i, j)] for i in warehouses) + shortage[j] == demand[j], name=f"demand_{j}")

# Recovery desk activation constraints (local)
M = 1000  # Big M
for j in ports:
    # If shortage > grace_containers[j], then recovery_desk[j] must be 1
    model.addConstr(shortage[j] <= grace_containers[j] + M * recovery_desk[j], name=f"recovery_trigger_{j}")

# Adriatic regional recovery desk constraint
adriatic_shortage = gp.quicksum(shortage[j] for j in adriatic_ports)
model.addConstr(adriatic_shortage <= adriatic_pool_shortage_trigger + M * adriatic_recovery, name="adriatic_trigger")

# Objective function
# 1. Transportation cost
transport_cost = gp.quicksum(x[(i, j)] * distance[(i, j)] * cost_per_km for i in warehouses for j in ports)

# 2. Shortage charges (per container)
shortage_cost = gp.quicksum(shortage[j] * shortage_charge[j] for j in ports)

# 3. Local recovery desk fees
local_recovery_cost = gp.quicksum(recovery_desk[j] * recovery_fee[j] for j in ports)

# 4. Adriatic regional recovery desk fee
adriatic_recovery_cost = adriatic_recovery * adriatic_pool_recovery_fee

total_cost = transport_cost + shortage_cost + local_recovery_cost + adriatic_recovery_cost

model.setObjective(total_cost, GRB.MINIMIZE)

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
