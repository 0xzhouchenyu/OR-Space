import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    
    n = int(params['n'])
    premium_cost_multiplier = float(params['premium_cost_multiplier'])
    min_premium_share = float(params['min_premium_share'])
    
    # Read table_1.csv
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    # Parse d_ij (transportation volume from factory i to destination j)
    # and c_pq (unit transportation cost from location p to destination q)
    d = []
    c = []
    for row in rows:
        d_row = [float(row[f'Transportation_volume_to_Location_{j+1}']) for j in range(n)]
        c_row = [float(row[f'Transportation_cost_to_Location_{j+1}']) for j in range(n)]
        d.append(d_row)
        c.append(c_row)
    
    # Calculate outbound volume for each factory
    outbound_volume = [sum(d[i]) for i in range(n)]
    
    # Calculate c_std_ip: standard unit cost for factory i at location p
    c_std = []
    for i in range(n):
        c_std_row = []
        for p in range(n):
            if outbound_volume[i] > 0:
                cost = sum(d[i][j] * c[p][j] for j in range(n)) / outbound_volume[i]
            else:
                cost = 0
            c_std_row.append(cost)
        c_std.append(c_std_row)
    
    # Calculate c_prem_ip: premium unit cost
    c_prem = [[premium_cost_multiplier * c_std[i][p] for p in range(n)] for i in range(n)]
    
    # Create Gurobi model
    model = gp.Model("factory_assignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i,p] = 1 if factory i is assigned to location p
    x = {}
    for i in range(n):
        for p in range(n):
            x[i, p] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{p}")
    
    # y[i,p] = 1 if factory i uses premium handling at location p
    y = {}
    for i in range(n):
        for p in range(n):
            y[i, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{p}")
    
    # v_std[i,p] = standard volume handled for factory i at location p
    v_std = {}
    for i in range(n):
        for p in range(n):
            v_std[i, p] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"v_std_{i}_{p}")
    
    # v_prem[i,p] = premium volume handled for factory i at location p
    v_prem = {}
    for i in range(n):
        for p in range(n):
            v_prem[i, p] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"v_prem_{i}_{p}")
    
    model.update()
    
    # Constraints
    # Each factory assigned to exactly one location
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, p] for p in range(n)) == 1, name=f"factory_{i}_assigned")
    
    # Each location hosts at most one factory
    for p in range(n):
        model.addConstr(gp.quicksum(x[i, p] for i in range(n)) <= 1, name=f"location_{p}_capacity")
    
    # Volume can only be handled at assigned location
    for i in range(n):
        for p in range(n):
            model.addConstr(v_std[i, p] + v_prem[i, p] <= outbound_volume[i] * x[i, p], 
                          name=f"volume_at_assigned_{i}_{p}")
    
    # Total volume equals outbound volume at assigned location
    for i in range(n):
        model.addConstr(gp.quicksum(v_std[i, p] + v_prem[i, p] for p in range(n)) == outbound_volume[i],
                       name=f"total_volume_{i}")
    
    # Premium mode can only be used at assigned location
    for i in range(n):
        for p in range(n):
            model.addConstr(y[i, p] <= x[i, p], name=f"premium_only_at_assigned_{i}_{p}")
    
    # If premium is selected, minimum volume requirement
    for i in range(n):
        for p in range(n):
            model.addConstr(v_prem[i, p] >= min_premium_share * outbound_volume[i] * y[i, p],
                          name=f"min_premium_volume_{i}_{p}")
    
    # Premium volume can only exist if premium mode is selected
    for i in range(n):
        for p in range(n):
            model.addConstr(v_prem[i, p] <= outbound_volume[i] * y[i, p],
                          name=f"premium_volume_requires_mode_{i}_{p}")
    
    # Objective: minimize total cost
    total_cost = gp.quicksum(
        c_std[i][p] * v_std[i, p] + c_prem[i][p] * v_prem[i, p]
        for i in range(n) for p in range(n)
    )
    
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

solve()
