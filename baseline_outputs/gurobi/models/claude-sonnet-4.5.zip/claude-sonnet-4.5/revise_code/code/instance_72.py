import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read property data
properties = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_risky_multiplier = params['scen_1_risky_multiplier']
scen_2_risky_multiplier = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = params['max_risky_properties']

# Create optimization model
model = gp.Model("RealEstateInvestment")
model.setParam('OutputFlag', 0)

# Decision variables
# x[p]: binary, whether to purchase property p
x = {}
for p in properties:
    x[p['name']] = model.addVar(vtype=GRB.BINARY, name=p['name'])

# y[p]: binary, whether property p has any risky tenants
y = {}
for p in properties:
    y[p['name']] = model.addVar(vtype=GRB.BINARY, name=f"risky_{p['name']}")

# r[p]: continuous [0,1], fraction of property p allocated to risky tenants
r = {}
for p in properties:
    r[p['name']] = model.addVar(lb=0, ub=1, vtype=GRB.CONTINUOUS, name=f"risky_frac_{p['name']}")

model.update()

# Objective: maximize expected annual income
# Income = sum over properties of:
#   - (1 - r[p]) * income[p]  (dependable portion)
#   - r[p] * income[p] * (scen_1_prob * scen_1_multiplier + scen_2_prob * scen_2_multiplier)  (risky portion expected value)
expected_risky_multiplier = scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier

obj_expr = gp.LinExpr()
for p in properties:
    # Dependable income
    obj_expr += (1 - r[p['name']]) * p['income']
    # Risky income (expected value)
    obj_expr += r[p['name']] * p['income'] * expected_risky_multiplier

model.setObjective(obj_expr, GRB.MAXIMIZE)

# Constraint: Budget
budget_expr = gp.LinExpr()
for p in properties:
    budget_expr += p['cost'] * x[p['name']]
model.addConstr(budget_expr <= budget, "budget_constraint")

# Constraint: If Property 4 is purchased, Property 3 cannot be purchased
model.addConstr(x['Property_4'] + x['Property_3'] <= 1, "exclusion_constraint")

# Constraint: Risky allocation only on purchased properties
# r[p] <= x[p] (if not purchased, r must be 0)
for p in properties:
    model.addConstr(r[p['name']] <= x[p['name']], f"risky_only_if_purchased_{p['name']}")

# Constraint: Per-property risky cap
# r[p] <= per_property_risky_cap
for p in properties:
    model.addConstr(r[p['name']] <= per_property_risky_cap, f"per_property_risky_cap_{p['name']}")

# Constraint: y[p] = 1 if r[p] > 0 (property has risky tenants)
# r[p] <= y[p] (if r > 0, then y must be 1)
# y[p] <= x[p] (can only have risky if purchased)
for p in properties:
    model.addConstr(r[p['name']] <= y[p['name']], f"risky_indicator_{p['name']}")
    model.addConstr(y[p['name']] <= x[p['name']], f"risky_requires_purchase_{p['name']}")

# Constraint: Total risky budget
# Sum of costs of properties with risky tenants <= total_risky_budget
risky_budget_expr = gp.LinExpr()
for p in properties:
    risky_budget_expr += p['cost'] * y[p['name']]
model.addConstr(risky_budget_expr <= total_risky_budget, "total_risky_budget_constraint")

# Constraint: Maximum number of properties with risky tenants
risky_count_expr = gp.LinExpr()
for p in properties:
    risky_count_expr += y[p['name']]
model.addConstr(risky_count_expr <= max_risky_properties, "max_risky_properties_constraint")

# Solve
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
