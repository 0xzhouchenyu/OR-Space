import os
import csv
import gurobipy as gp
from gurobipy import GRB
from itertools import combinations

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
params = load_general_parameters(data_path)

# Extract parameters
motorcycle_pollution = params['motorcycle_pollution']
small_truck_pollution = params['small_truck_pollution']
large_truck_pollution = params['large_truck_pollution']
max_motorcycle_trips = int(params['max_motorcycle_trips'])
motorcycle_capacity = params['motorcycle_capacity']
small_truck_capacity = params['small_truck_capacity']
large_truck_capacity = params['large_truck_capacity']
max_total_trips = int(params['max_total_trips'])
demand_peak_units = params['demand_peak_units']
demand_offpeak_units = params['demand_offpeak_units']
leasing_capacity = params['leasing_capacity']
leasing_pollution_per_unit = params['leasing_pollution_per_unit']
leasing_fixed_pollution = params['leasing_fixed_pollution']
max_leasing_fraction_peak = params['max_leasing_fraction_peak']
bigM_leasing = params['bigM_leasing']
epsilon = params['epsilon']

methods = ['motorcycle', 'small_truck', 'large_truck']
periods = ['peak', 'offpeak']

pollution = {
    'motorcycle': motorcycle_pollution,
    'small_truck': small_truck_pollution,
    'large_truck': large_truck_pollution
}

capacity = {
    'motorcycle': motorcycle_capacity,
    'small_truck': small_truck_capacity,
    'large_truck': large_truck_capacity
}

demand = {
    'peak': demand_peak_units,
    'offpeak': demand_offpeak_units
}

best_obj = float('inf')
best_solution = None
best_combo = None

for combo in combinations(methods, 2):
    model = gp.Model(f"Transport_{'_'.join(combo)}")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of trips for each method in each period
    trips = {}
    for m in combo:
        for p in periods:
            trips[m, p] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"trips_{m}_{p}")
    
    # Leasing variables
    leasing_units = {}
    for p in periods:
        leasing_units[p] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"leasing_{p}")
    
    # Binary variable: whether leasing is used at all (day-wide)
    leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")
    
    # Objective: minimize total pollution
    owned_pollution = gp.quicksum(pollution[m] * trips[m, p] for m in combo for p in periods)
    leasing_pollution_variable = gp.quicksum(leasing_pollution_per_unit * leasing_units[p] for p in periods)
    leasing_pollution_fixed = leasing_fixed_pollution * leasing_used
    
    model.setObjective(owned_pollution + leasing_pollution_variable + leasing_pollution_fixed, GRB.MINIMIZE)
    
    # Constraint: meet demand in each period
    for p in periods:
        model.addConstr(
            gp.quicksum(capacity[m] * trips[m, p] for m in combo) + leasing_units[p] >= demand[p],
            name=f"demand_{p}"
        )
    
    # Constraint: maximum total trips across both periods
    model.addConstr(
        gp.quicksum(trips[m, p] for m in combo for p in periods) <= max_total_trips,
        name="max_total_trips"
    )
    
    # Constraint: motorcycle trips limit (across both periods)
    if 'motorcycle' in combo:
        model.addConstr(
            gp.quicksum(trips['motorcycle', p] for p in periods) <= max_motorcycle_trips,
            name="max_motorcycle_trips"
        )
    
    # Constraint: maximum leasing capacity (day-wide)
    model.addConstr(
        gp.quicksum(leasing_units[p] for p in periods) <= leasing_capacity,
        name="max_leasing_capacity"
    )
    
    # Constraint: maximum leasing fraction in peak period
    model.addConstr(
        leasing_units['peak'] <= max_leasing_fraction_peak * demand['peak'],
        name="max_leasing_fraction_peak"
    )
    
    # Constraint: link leasing_used to total leasing (big-M formulation)
    total_leasing = gp.quicksum(leasing_units[p] for p in periods)
    model.addConstr(total_leasing <= bigM_leasing * leasing_used, name="leasing_bigM_upper")
    model.addConstr(total_leasing >= epsilon * leasing_used, name="leasing_bigM_lower")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        if obj_val < best_obj:
            best_obj = obj_val
            best_solution = {
                'trips': {(m, p): trips[m, p].X for m in combo for p in periods},
                'leasing': {p: leasing_units[p].X for p in periods},
                'leasing_used': leasing_used.X
            }
            best_combo = combo

print(f"FINAL_OBJ_VALUE: {best_obj}")
