import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

# Extract parameters
min_A_I = params['min_proportion_crude_A_type_I'] / 100.0
min_A_II = params['min_proportion_crude_A_type_II'] / 100.0
price_I = params['selling_price_type_I']
price_II = params['selling_price_type_II']
inv_A = params['inventory_crude_A']
inv_B = params['inventory_crude_B']
max_purchase_A = params['max_purchase_crude_A']
cost_tier1 = params['market_price_crude_A_tier_1']
cost_tier2 = params['market_price_crude_A_tier_2']
cost_tier3 = params['market_price_crude_A_tier_3']
processing_capacity = params['processing_capacity']
min_total_gasoline_output = params['min_total_gasoline_output']
processing_cost_per_ton = params['processing_cost_per_ton']
type_II_contract_threshold = params['type_II_contract_threshold']
type_II_price_lift = params['type_II_price_lift']
bulk_purchase_rebate_threshold = params['bulk_purchase_rebate_threshold']
bulk_purchase_rebate = params['bulk_purchase_rebate']

# Create model
model = gp.Model("Oil_Blending_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
a1 = model.addVar(lb=0, name="crude_A_in_I")
a2 = model.addVar(lb=0, name="crude_A_in_II")
b1 = model.addVar(lb=0, name="crude_B_in_I")
b2 = model.addVar(lb=0, name="crude_B_in_II")

# Tiered purchase variables for crude A
p1 = model.addVar(lb=0, ub=500, name="purchase_tier1")
p2 = model.addVar(lb=0, ub=500, name="purchase_tier2")
p3 = model.addVar(lb=0, ub=500, name="purchase_tier3")

# Binary variables for tiered ordering
y1 = model.addVar(vtype=GRB.BINARY, name="y1")
y2 = model.addVar(vtype=GRB.BINARY, name="y2")

# Binary variable for Type II threshold
z_type_II = model.addVar(vtype=GRB.BINARY, name="z_type_II")

# Binary variable for bulk purchase rebate
z_bulk = model.addVar(vtype=GRB.BINARY, name="z_bulk")

model.update()

# Tiered ordering constraints
model.addConstr(p2 <= 500 * y1, "tier2_upper")
model.addConstr(p3 <= 500 * y2, "tier3_upper")
model.addConstr(p1 >= 500 * y1, "tier1_lower")
model.addConstr(p2 >= 500 * y2, "tier2_lower")

# Total crude A purchased
total_A_purchased = p1 + p2 + p3

# Supply constraints
model.addConstr(a1 + a2 <= inv_A + total_A_purchased, "crude_A_supply")
model.addConstr(b1 + b2 <= inv_B, "crude_B_supply")

# Blending constraints (minimum proportion of crude A)
model.addConstr(a1 >= min_A_I * (a1 + b1), "blend_I")
model.addConstr(a2 >= min_A_II * (a2 + b2), "blend_II")

# Total gasoline output
total_gasoline = a1 + b1 + a2 + b2
model.addConstr(total_gasoline >= min_total_gasoline_output, "min_output")
model.addConstr(total_gasoline <= processing_capacity, "max_output")

# Type II output
type_II_output = a2 + b2

# Type II threshold constraint
M_large = 10000
model.addConstr(type_II_output >= type_II_contract_threshold * z_type_II, "type_II_threshold_lower")
model.addConstr(type_II_output <= type_II_contract_threshold + M_large * (1 - z_type_II) + M_large * z_type_II, "type_II_threshold_upper")

# Bulk purchase threshold constraint
model.addConstr(total_A_purchased >= bulk_purchase_rebate_threshold * z_bulk, "bulk_threshold_lower")
model.addConstr(total_A_purchased <= bulk_purchase_rebate_threshold + M_large * (1 - z_bulk) + M_large * z_bulk, "bulk_threshold_upper")

# Objective function
revenue_I = price_I * (a1 + b1)
revenue_II_base = price_II * type_II_output
revenue_II_lift = type_II_price_lift * type_II_output * z_type_II
revenue = revenue_I + revenue_II_base + revenue_II_lift

purchase_cost = cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3
processing_cost = processing_cost_per_ton * total_gasoline
rebate = bulk_purchase_rebate * z_bulk

profit = revenue - purchase_cost - processing_cost + rebate

model.setObjective(profit, GRB.MAXIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
