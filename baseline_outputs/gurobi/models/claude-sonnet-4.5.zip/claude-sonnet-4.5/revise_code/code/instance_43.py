import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
min_A = params['min_raw_material_A']
min_B = params['min_raw_material_B']
min_C = params['min_raw_material_C']

cap_A_a = params['warehouse_A_truck_capacity_A']
cap_A_b = params['warehouse_A_truck_capacity_B']
cap_A_c = params['warehouse_A_truck_capacity_C']
cost_A = params['warehouse_A_truck_cost']

cap_B_a = params['warehouse_B_truck_capacity_A']
cap_B_b = params['warehouse_B_truck_capacity_B']
cap_B_c = params['warehouse_B_truck_capacity_C']
cost_B = params['warehouse_B_truck_cost']

fixed_cost_A = params['warehouse_A_fixed_cost']
fixed_cost_B = params['warehouse_B_fixed_cost']
overflow_threshold_B = params['warehouse_B_overflow_threshold_trucks']
overflow_cost_B = params['warehouse_B_overflow_coordination_cost']
dual_warehouse_fee = params['dual_warehouse_reconciliation_fee']

# Create the MIP model
model = gp.Model("MinFreightCost")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_A")
y = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_B")

# Binary indicators
use_A = model.addVar(vtype=GRB.BINARY, name="use_warehouse_A")
use_B = model.addVar(vtype=GRB.BINARY, name="use_warehouse_B")
overflow_B = model.addVar(vtype=GRB.BINARY, name="overflow_B")
use_both = model.addVar(vtype=GRB.BINARY, name="use_both_warehouses")

# Link trucks to binary indicators
M = 10000  # Big M for logical constraints
model.addConstr(x <= M * use_A, "link_A")
model.addConstr(y <= M * use_B, "link_B")
model.addConstr(x >= use_A, "force_use_A")
model.addConstr(y >= use_B, "force_use_B")

# Overflow constraint for warehouse B
model.addConstr(y <= overflow_threshold_B + M * overflow_B, "overflow_upper")
model.addConstr(y >= overflow_threshold_B + 1 - M * (1 - overflow_B), "overflow_lower")

# Dual warehouse usage
model.addConstr(use_both >= use_A + use_B - 1, "both_lower")
model.addConstr(use_both <= use_A, "both_upper_A")
model.addConstr(use_both <= use_B, "both_upper_B")

# Objective: minimize total cost
total_cost = (cost_A * x + fixed_cost_A * use_A +
              cost_B * y + fixed_cost_B * use_B +
              overflow_cost_B * overflow_B +
              dual_warehouse_fee * use_both)
model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints: meet minimum raw material requirements
model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# Solve
model.optimize()

# Output results
print(f"FINAL_OBJ_VALUE: {model.objVal}")
