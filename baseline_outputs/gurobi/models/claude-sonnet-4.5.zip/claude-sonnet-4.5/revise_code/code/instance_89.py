import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters
data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
params = {}
with open(data_path, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
profit_A = params['profit_per_kg_product_A']
profit_B = params['profit_per_kg_product_B']
max_hours_w1 = params['max_production_hours_week_1']
max_hours_w2 = params['max_production_hours_week_2']
hours_A = params['hours_per_kg_product_A']
hours_B = params['hours_per_kg_product_B']
min_ratio_B_to_A = params['min_output_ratio_product_B_to_A']
storage_ratio_A_to_B = params['storage_space_ratio_product_A_to_B']
max_storage_A_w1 = params['max_storage_product_A_equiv_week_1']
max_storage_A_w2 = params['max_storage_product_A_equiv_week_2']
initial_inv_A = params['initial_inventory_A']
initial_inv_B = params['initial_inventory_B']
storage_cost_A = params['storage_cost_per_kg_A']
storage_cost_B = params['storage_cost_per_kg_B']
promo_bonus_A = params['promo_profit_bonus_A']
promo_bonus_B = params['promo_profit_bonus_B']
max_promo_A = int(params['max_promotions_product_A'])
max_promo_B = int(params['max_promotions_product_B'])

# Create model
model = gp.Model("Revised_Liquid_Products")
model.setParam('OutputFlag', 0)

weeks = [1, 2]

# Decision variables
# Production in each week
prod_A = {w: model.addVar(lb=0, name=f"prod_A_w{w}") for w in weeks}
prod_B = {w: model.addVar(lb=0, name=f"prod_B_w{w}") for w in weeks}

# Sales in each week
sales_A = {w: model.addVar(lb=0, name=f"sales_A_w{w}") for w in weeks}
sales_B = {w: model.addVar(lb=0, name=f"sales_B_w{w}") for w in weeks}

# Inventory at end of each week
inv_A = {w: model.addVar(lb=0, name=f"inv_A_w{w}") for w in weeks}
inv_B = {w: model.addVar(lb=0, name=f"inv_B_w{w}") for w in weeks}

# Promotion binary variables
promo_A = {w: model.addVar(vtype=GRB.BINARY, name=f"promo_A_w{w}") for w in weeks}
promo_B = {w: model.addVar(vtype=GRB.BINARY, name=f"promo_B_w{w}") for w in weeks}

model.update()

# Objective: maximize profit from sales minus storage costs
objective = 0
for w in weeks:
    # Base profit from sales
    objective += profit_A * sales_A[w] + profit_B * sales_B[w]
    # Promotion bonus
    objective += promo_bonus_A * sales_A[w] * promo_A[w]
    objective += promo_bonus_B * sales_B[w] * promo_B[w]

# Storage costs only apply to inventory carried from week 1 to week 2
objective -= storage_cost_A * inv_A[1]
objective -= storage_cost_B * inv_B[1]

model.setObjective(objective, GRB.MAXIMIZE)

# Constraints

# Production time constraints
model.addConstr(hours_A * prod_A[1] + hours_B * prod_B[1] <= max_hours_w1, "prod_time_w1")
model.addConstr(hours_A * prod_A[2] + hours_B * prod_B[2] <= max_hours_w2, "prod_time_w2")

# Inventory balance constraints
# Week 1: initial_inv + production - sales = end_inventory
model.addConstr(initial_inv_A + prod_A[1] - sales_A[1] == inv_A[1], "inv_balance_A_w1")
model.addConstr(initial_inv_B + prod_B[1] - sales_B[1] == inv_B[1], "inv_balance_B_w1")

# Week 2: previous_inv + production - sales = end_inventory
model.addConstr(inv_A[1] + prod_A[2] - sales_A[2] == inv_A[2], "inv_balance_A_w2")
model.addConstr(inv_B[1] + prod_B[2] - sales_B[2] == inv_B[2], "inv_balance_B_w2")

# Market demand: sales of B >= 3 * sales of A in each week
model.addConstr(sales_B[1] >= min_ratio_B_to_A * sales_A[1], "demand_w1")
model.addConstr(sales_B[2] >= min_ratio_B_to_A * sales_A[2], "demand_w2")

# Storage capacity constraints (applied to end-of-week inventory)
# Storage space: storage_ratio_A_to_B * inv_A + inv_B <= max_storage_A * storage_ratio_A_to_B
max_storage_units_w1 = max_storage_A_w1 * storage_ratio_A_to_B
max_storage_units_w2 = max_storage_A_w2 * storage_ratio_A_to_B

model.addConstr(storage_ratio_A_to_B * inv_A[1] + inv_B[1] <= max_storage_units_w1, "storage_w1")
model.addConstr(storage_ratio_A_to_B * inv_A[2] + inv_B[2] <= max_storage_units_w2, "storage_w2")

# Promotion constraints
model.addConstr(promo_A[1] + promo_A[2] <= max_promo_A, "max_promo_A")
model.addConstr(promo_B[1] + promo_B[2] <= max_promo_B, "max_promo_B")

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal:.3f}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
