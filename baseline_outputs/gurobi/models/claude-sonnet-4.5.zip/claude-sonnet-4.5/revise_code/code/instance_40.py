import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

# Read data
csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
df = pd.read_csv(csv_path)
params = dict(zip(df['Parameter_Name'], df['Value']))

commodities = ['steel', 'engine', 'electronics', 'plastic']

# Create model
model = gp.Model("Maximize_GDP")
model.setParam('OutputFlag', 0)

# Decision variables
# Production levels for each commodity
x = {c: model.addVar(lb=0, name=f"x_{c}") for c in commodities}

# Apply production upper bounds if they exist
for c in commodities:
    for suffix in ['_production_limit', '_limit', '_capacity']:
        key = f"{c}{suffix}"
        if key in params:
            x[c].ub = params[key]

# Overtime labor used
overtime = model.addVar(lb=0, ub=params['overtime_cap'], name="overtime")

# Imports of finished commodities
imports_commodity = {c: model.addVar(lb=0, ub=params['import_quota'], name=f"import_{c}") for c in commodities}

model.update()

# Domestic consumption of each commodity by production processes
domestic_consumption = {}
for c in commodities:
    domestic_consumption[c] = gp.quicksum(
        params.get(f"{c_prime}_{c}_requirement", 0.0) * x[c_prime]
        for c_prime in commodities
    )

# Net availability = Production + Imports - Domestic Consumption
net_availability = {}
for c in commodities:
    net_availability[c] = x[c] + imports_commodity[c] - domestic_consumption[c]

# Export revenue: net_availability * world_price (only if positive, i.e., net export)
export_revenue = gp.quicksum(params[f"{c}_price"] * net_availability[c] for c in commodities)

# Import costs for production inputs (raw materials)
production_import_costs = gp.quicksum(params.get(f"{c}_import_cost", 0.0) * x[c] for c in commodities)

# Import costs for finished commodities
finished_import_costs = gp.quicksum(
    params['import_premium_ratio'] * params[f"{c}_price"] * imports_commodity[c]
    for c in commodities
)

# Overtime labor costs
overtime_costs = params['overtime_wage'] * overtime

# Objective: GDP = Export revenue - Production import costs - Finished commodity import costs - Overtime costs
gdp = export_revenue - production_import_costs - finished_import_costs - overtime_costs
model.setObjective(gdp, GRB.MAXIMIZE)

# Constraints:
# 1. Net availability >= 0 for each commodity (supply meets domestic demand)
for c in commodities:
    model.addConstr(net_availability[c] >= 0, f"Supply_Demand_{c}")

# 2. Labor constraint: regular + overtime
total_labor_used = gp.quicksum(
    params.get(f"{c}_labor_requirement", 0.0) * x[c] for c in commodities
)
model.addConstr(total_labor_used <= params['labor_force'] + overtime, "Labor_Limit")

# Solve the model
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {round(model.objVal, 3)}")
else:
    print("FINAL_OBJ_VALUE: None")
