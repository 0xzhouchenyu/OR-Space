import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'data', 'table_1.csv')
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    
    # Parse process data
    a_I = float(rows[0][1])  # Model A hours for Process I
    b_I = float(rows[0][2])  # Model B hours for Process I
    cap_I = float(rows[0][3])  # Max weekly capacity Process I
    
    a_II = float(rows[1][1])  # Model A hours for Process II
    b_II = float(rows[1][2])  # Model B hours for Process II
    cap_II = float(rows[1][3])  # Max weekly capacity Process II
    
    profit_A = float(rows[2][1])  # Profit per unit Model A
    profit_B = float(rows[2][2])  # Profit per unit Model B
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'data', 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    min_profit = params['min_weekly_profit']
    min_A = params['min_model_A_units']
    min_B = params['min_model_B_units']
    week1_min_A = params['week1_min_model_A_units']
    week1_min_B = params['week1_min_model_B_units']
    week2_min_A = params['week2_min_model_A_units']
    week2_min_B = params['week2_min_model_B_units']
    process_I_hours = params['process_I_hours']
    process_II_hours = params['process_II_hours']
    max_overtime_I = params['max_overtime_I_per_week']
    max_overtime_II = params['max_overtime_II_per_week']
    overtime_premium_I = params['overtime_premium_I']
    overtime_premium_II = params['overtime_premium_II']
    min_avg_util_I = params['min_avg_utilization_I']
    min_avg_util_II = params['min_avg_utilization_II']
    fatigue_threshold_I = params['week1_overtime_fatigue_threshold_I']
    fatigue_threshold_II = params['week1_overtime_fatigue_threshold_II']
    recovery_loss_I = params['week2_recovery_loss_I']
    recovery_loss_II = params['week2_recovery_loss_II']
    
    # Create Gurobi model
    model = gp.Model("Microcomputer_Production_TwoWeek")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Production quantities
    x_A_w1 = model.addVar(lb=0, name="x_A_w1")
    x_B_w1 = model.addVar(lb=0, name="x_B_w1")
    x_A_w2 = model.addVar(lb=0, name="x_A_w2")
    x_B_w2 = model.addVar(lb=0, name="x_B_w2")
    
    # Overtime hours
    ot_I_w1 = model.addVar(lb=0, name="ot_I_w1")
    ot_II_w1 = model.addVar(lb=0, name="ot_II_w1")
    ot_I_w2 = model.addVar(lb=0, name="ot_I_w2")
    ot_II_w2 = model.addVar(lb=0, name="ot_II_w2")
    
    # Binary variables for fatigue trigger
    fatigue_I = model.addVar(vtype=GRB.BINARY, name="fatigue_I")
    fatigue_II = model.addVar(vtype=GRB.BINARY, name="fatigue_II")
    
    # Objective: Maximize two-week profit minus overtime costs
    total_revenue = profit_A * (x_A_w1 + x_A_w2) + profit_B * (x_B_w1 + x_B_w2)
    total_overtime_cost = (overtime_premium_I * (ot_I_w1 + ot_I_w2) + 
                          overtime_premium_II * (ot_II_w1 + ot_II_w2))
    model.setObjective(total_revenue - total_overtime_cost, GRB.MAXIMIZE)
    
    # Constraints
    # Week 1 capacity constraints
    model.addConstr(a_I * x_A_w1 + b_I * x_B_w1 <= process_I_hours + ot_I_w1, "w1_cap_I")
    model.addConstr(a_II * x_A_w1 + b_II * x_B_w1 <= process_II_hours + ot_II_w1, "w1_cap_II")
    
    # Week 1 overtime limits
    model.addConstr(ot_I_w1 <= max_overtime_I, "w1_ot_limit_I")
    model.addConstr(ot_II_w1 <= max_overtime_II, "w1_ot_limit_II")
    
    # Week 1 minimum deliveries
    model.addConstr(x_A_w1 >= week1_min_A, "w1_min_A")
    model.addConstr(x_B_w1 >= week1_min_B, "w1_min_B")
    
    # Fatigue trigger constraints
    # If ot_I_w1 > fatigue_threshold_I, then fatigue_I = 1
    model.addConstr(ot_I_w1 <= fatigue_threshold_I + (max_overtime_I - fatigue_threshold_I) * fatigue_I, "fatigue_trigger_I")
    model.addConstr(ot_II_w1 <= fatigue_threshold_II + (max_overtime_II - fatigue_threshold_II) * fatigue_II, "fatigue_trigger_II")
    
    # Week 2 available regular hours (reduced if fatigue triggered)
    available_I_w2 = process_I_hours - recovery_loss_I * fatigue_I
    available_II_w2 = process_II_hours - recovery_loss_II * fatigue_II
    
    # Week 2 capacity constraints
    model.addConstr(a_I * x_A_w2 + b_I * x_B_w2 <= available_I_w2 + ot_I_w2, "w2_cap_I")
    model.addConstr(a_II * x_A_w2 + b_II * x_B_w2 <= available_II_w2 + ot_II_w2, "w2_cap_II")
    
    # Week 2 overtime limits
    model.addConstr(ot_I_w2 <= max_overtime_I, "w2_ot_limit_I")
    model.addConstr(ot_II_w2 <= max_overtime_II, "w2_ot_limit_II")
    
    # Week 2 minimum deliveries
    model.addConstr(x_A_w2 >= week2_min_A, "w2_min_A")
    model.addConstr(x_B_w2 >= week2_min_B, "w2_min_B")
    
    # Total production requirements
    model.addConstr(x_A_w1 + x_A_w2 >= min_A, "total_min_A")
    model.addConstr(x_B_w1 + x_B_w2 >= min_B, "total_min_B")
    
    # Minimum profit constraint (net profit after overtime costs)
    model.addConstr(total_revenue - total_overtime_cost >= min_profit, "min_profit")
    
    # Average utilization constraints
    # Process I: (hours used in w1 + hours used in w2) / (2 * process_I_hours) >= min_avg_util_I
    hours_used_I_w1 = a_I * x_A_w1 + b_I * x_B_w1
    hours_used_I_w2 = a_I * x_A_w2 + b_I * x_B_w2
    model.addConstr(hours_used_I_w1 + hours_used_I_w2 >= min_avg_util_I * 2 * process_I_hours, "avg_util_I")
    
    # Process II
    hours_used_II_w1 = a_II * x_A_w1 + b_II * x_B_w1
    hours_used_II_w2 = a_II * x_A_w2 + b_II * x_B_w2
    model.addConstr(hours_used_II_w1 + hours_used_II_w2 >= min_avg_util_II * 2 * process_II_hours, "avg_util_II")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
