import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            
            # Handle ratio values like "5:2"
            if ':' in value_str:
                params[name + '_raw'] = value_str
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params

def main():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    params = load_parameters(data_path)
    
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_hours = params['machine_working_time']
    machine_working_time_minutes = machine_working_time_hours * 60
    
    ratio_A = 5
    ratio_B = 2
    
    max_overtime_hours = params['max_overtime_hours']
    overtime_penalty_per_hour = params['overtime_penalty_per_hour']
    overtime_review_threshold_hours = params['overtime_review_threshold_hours']
    overtime_review_fee = params['overtime_review_fee']
    product_A_senior_batch_threshold = params['product_A_senior_batch_threshold']
    product_A_senior_batch_fee = params['product_A_senior_batch_fee']
    
    # Create model
    model = gp.Model("Product_Mix_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    A = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_A")
    B = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_B")
    
    # Overtime variable (continuous, non-negative)
    overtime = model.addVar(lb=0, ub=max_overtime_hours, vtype=GRB.CONTINUOUS, name="Overtime")
    
    # Binary indicator: 1 if overtime exceeds threshold
    overtime_exceeds_threshold = model.addVar(vtype=GRB.BINARY, name="Overtime_Exceeds_Threshold")
    
    # Binary indicator: 1 if Product A exceeds senior batch threshold
    A_exceeds_threshold = model.addVar(vtype=GRB.BINARY, name="A_Exceeds_Threshold")
    
    # Objective function: maximize profit minus costs
    # Revenue from products minus overtime penalty minus overtime review fee minus senior batch fee
    objective = (profit_A * A + profit_B * B 
                 - overtime_penalty_per_hour * overtime 
                 - overtime_review_fee * overtime_exceeds_threshold
                 - product_A_senior_batch_fee * A_exceeds_threshold)
    
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Constraint 1: Machine working time (including overtime)
    total_time_minutes = (machine_working_time_hours + overtime) * 60
    model.addConstr(assembly_time_A * A + assembly_time_B * B <= total_time_minutes, "Machine_Time")
    
    # Constraint 2: Production ratio - at least 2 units of B for every 5 units of A
    # B >= (2/5) * A  =>  2A - 5B <= 0
    model.addConstr(ratio_B * A - ratio_A * B <= 0, "Production_Ratio")
    
    # Constraint 3: Overtime review threshold indicator
    # If overtime > overtime_review_threshold_hours, then overtime_exceeds_threshold = 1
    M_overtime = max_overtime_hours
    model.addConstr(overtime <= overtime_review_threshold_hours + M_overtime * overtime_exceeds_threshold, "Overtime_Threshold_Upper")
    
    # Constraint 4: Product A senior batch threshold indicator
    # If A > product_A_senior_batch_threshold, then A_exceeds_threshold = 1
    M_A = 10000  # Large enough upper bound for A
    model.addConstr(A <= product_A_senior_batch_threshold + M_A * A_exceeds_threshold, "A_Threshold_Upper")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val:.1f}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
