import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load monthly data
def load_monthly_data(filepath):
    months = []
    purchasing_prices = {}
    selling_prices = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            month = int(row['Month'])
            months.append(month)
            purchasing_prices[month] = float(row['Purchasing_Price_Yuan'])
            selling_prices[month] = float(row['Selling_Price_Yuan'])
    
    return months, purchasing_prices, selling_prices

# Load general parameters
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

months, purchasing_prices, selling_prices = load_monthly_data(os.path.join(data_dir, 'table_1.csv'))
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params['fixed_ordering_cost']
month2_bulk_receiving_threshold = params['month2_bulk_receiving_threshold']
month2_bulk_receiving_fee = params['month2_bulk_receiving_fee']

# Create model
model = gp.Model("Maximize_Profit")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}  # units purchased at the beginning of month m
s = {}  # units sold during month m
inv = {}  # inventory at end of month m
y = {}  # binary: 1 if any purchase in month m, 0 otherwise
z = None  # binary: 1 if month 2 purchase exceeds threshold

for m in months:
    x[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"purchase_{m}")
    s[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"sell_{m}")
    inv[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"inventory_{m}")
    y[m] = model.addVar(vtype=GRB.BINARY, name=f"order_{m}")

# Binary variable for month 2 bulk receiving fee
z = model.addVar(vtype=GRB.BINARY, name="month2_bulk")

# Objective: maximize total profit
# Profit = selling revenue - purchasing cost - fixed ordering costs - month 2 bulk receiving fee
objective = gp.quicksum(selling_prices[m] * s[m] - purchasing_prices[m] * x[m] for m in months)
objective -= gp.quicksum(fixed_ordering_cost * y[m] for m in months)
objective -= month2_bulk_receiving_fee * z

model.setObjective(objective, GRB.MAXIMIZE)

# Constraints
M = 1e6  # Big-M for logical constraints

for m in months:
    # Inventory balance
    if m == months[0]:
        prev_inv = initial_stock
    else:
        prev_inv = inv[m - 1]
    
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], f"inventory_balance_{m}")
    
    # Warehouse capacity after purchase (before selling)
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, f"warehouse_after_purchase_{m}")
    
    # End-of-month inventory capacity
    model.addConstr(inv[m] <= warehouse_capacity, f"warehouse_end_{m}")
    
    # Can't sell more than available
    model.addConstr(s[m] <= prev_inv + x[m], f"sell_limit_{m}")
    
    # Link purchase to binary ordering variable
    model.addConstr(x[m] <= M * y[m], f"order_link_{m}")

# Month 2 bulk receiving constraint
# z = 1 if x[2] > month2_bulk_receiving_threshold, else z = 0
# x[2] > threshold implies z = 1
# x[2] <= threshold implies z can be 0
model.addConstr(x[2] <= month2_bulk_receiving_threshold + M * z, "month2_bulk_trigger")
# Force z = 1 if x[2] > threshold
model.addConstr(x[2] >= (month2_bulk_receiving_threshold + 0.001) * z, "month2_bulk_force")

# Solve
model.optimize()

# Print results
if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
