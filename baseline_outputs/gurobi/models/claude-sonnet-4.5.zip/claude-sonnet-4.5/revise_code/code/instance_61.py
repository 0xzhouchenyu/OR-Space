import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read device data
devices = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            'name': row['Device'].strip(),
            'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
            'max_cap': float(row['Max_Processing_Capacity_Units'].strip())
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[param_name] = value

required_units = params['required_units']
energy_budget_peak = params['energy_budget_peak']
energy_budget_offpeak = params['energy_budget_offpeak']
startup_budget = params['startup_budget']
startup_cost = params['startup_cost']
energy_price_peak = params['energy_price_peak']
energy_price_offpeak = params['energy_price_offpeak']

# Device-specific energy parameters
energy_per_unit = {}
startup_energy = {}
for dev in devices:
    dev_name = dev['name']
    energy_per_unit[dev_name] = params[f'energy_per_unit_{dev_name}']
    startup_energy[dev_name] = params[f'startup_energy_{dev_name}']

# Create the optimization model
model = gp.Model("MinCostProduction_Revised")
model.setParam('OutputFlag', 0)

n = len(devices)
periods = ['peak', 'offpeak']

# Decision variables
# x[i, p]: number of units produced on device i in period p (continuous)
x = {}
for i in range(n):
    for p in periods:
        x[i, p] = model.addVar(lb=0, ub=devices[i]['max_cap'], vtype=GRB.CONTINUOUS, 
                                name=f"x_{devices[i]['name']}_{p}")

# y[i, p]: binary variable indicating whether device i is used in period p
y = {}
for i in range(n):
    for p in periods:
        y[i, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{devices[i]['name']}_{p}")

# Objective: minimize total cost
# Total cost = prep_cost (if device used in any period) + unit_production_cost + startup_cost + energy_cost
# Prep cost is incurred once per device if used in any period
# Startup cost is incurred for each device-period combination
# Energy cost is period-specific

# Device usage indicator (used in any period)
z = {}
for i in range(n):
    z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{devices[i]['name']}")

model.update()

# Link z[i] to y[i, p]: z[i] = 1 if device i is used in any period
for i in range(n):
    model.addConstr(z[i] >= y[i, 'peak'], f"z_link_{devices[i]['name']}_peak")
    model.addConstr(z[i] >= y[i, 'offpeak'], f"z_link_{devices[i]['name']}_offpeak")

# Objective components
prep_costs = gp.quicksum(devices[i]['prep_cost'] * z[i] for i in range(n))

unit_production_costs = gp.quicksum(
    devices[i]['unit_cost'] * (x[i, 'peak'] + x[i, 'offpeak']) 
    for i in range(n)
)

startup_costs = gp.quicksum(
    startup_cost * y[i, p] 
    for i in range(n) for p in periods
)

energy_costs = gp.quicksum(
    energy_price_peak * energy_per_unit[devices[i]['name']] * x[i, 'peak']
    for i in range(n)
) + gp.quicksum(
    energy_price_offpeak * energy_per_unit[devices[i]['name']] * x[i, 'offpeak']
    for i in range(n)
)

model.setObjective(prep_costs + unit_production_costs + startup_costs + energy_costs, GRB.MINIMIZE)

# Constraint: total production must equal required units
model.addConstr(
    gp.quicksum(x[i, p] for i in range(n) for p in periods) == required_units,
    "TotalProduction"
)

# Linking constraints: x[i, p] <= max_cap * y[i, p]
for i in range(n):
    for p in periods:
        model.addConstr(
            x[i, p] <= devices[i]['max_cap'] * y[i, p],
            f"Link_{devices[i]['name']}_{p}"
        )

# Energy budget constraints for peak period
peak_energy_consumption = gp.quicksum(
    energy_per_unit[devices[i]['name']] * x[i, 'peak'] + startup_energy[devices[i]['name']] * y[i, 'peak']
    for i in range(n)
)
model.addConstr(peak_energy_consumption <= energy_budget_peak, "EnergyBudget_Peak")

# Energy budget constraints for off-peak period
offpeak_energy_consumption = gp.quicksum(
    energy_per_unit[devices[i]['name']] * x[i, 'offpeak'] + startup_energy[devices[i]['name']] * y[i, 'offpeak']
    for i in range(n)
)
model.addConstr(offpeak_energy_consumption <= energy_budget_offpeak, "EnergyBudget_OffPeak")

# Startup budget constraint
total_startup_cost = gp.quicksum(startup_cost * y[i, p] for i in range(n) for p in periods)
model.addConstr(total_startup_cost <= startup_budget, "StartupBudget")

# Solve
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
