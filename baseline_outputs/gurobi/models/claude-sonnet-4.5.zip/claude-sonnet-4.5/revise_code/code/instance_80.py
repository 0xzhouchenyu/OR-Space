import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data files
def load_csv(filename):
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

def load_general_parameters():
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = row['Value']
        try:
            if '.' in value:
                params[name] = float(value)
            else:
                params[name] = int(value)
        except ValueError:
            params[name] = value
    return params

def load_task_methods():
    rows = load_csv('table_1.csv')
    data = []
    for row in rows:
        data.append({
            'Task': row['Task'],
            'Method': row['Method'],
            'Effective_Hours': float(row['Effective_Hours']),
            'Fixed_Cost': float(row['Fixed_Cost'])
        })
    return data

# Load data
params = load_general_parameters()
task_methods = load_task_methods()

# Extract parameters
skilled_wage = params['skilled_worker_weekly_wage']
laborer_wage = params['laborer_weekly_wage']
skilled_hours = params['skilled_worker_weekly_hours']
laborer_hours = params['laborer_weekly_hours']
max_skilled = params['max_skilled_workers']
max_laborers = params['max_laborers']
min_skilled_task3_B = params['min_skilled_workers_task3_methodB']
skilled_hiring_ratio = params['skilled_worker_hiring_ratio']

min_skilled_share_task1 = params['min_skilled_share_task1']
max_skilled_share_task1 = params['max_skilled_share_task1']
min_skilled_share_task2 = params['min_skilled_share_task2']
max_skilled_share_task2 = params['max_skilled_share_task2']
min_skilled_share_task3 = params['min_skilled_share_task3']
max_skilled_share_task3 = params['max_skilled_share_task3']

# Organize task-method data
tasks = ['Task_1', 'Task_2', 'Task_3']
methods = ['Method_A', 'Method_B']

tm_data = {}
for row in task_methods:
    key = (row['Task'], row['Method'])
    tm_data[key] = row

# Create model
model = gp.Model("WorkerAllocation")
model.setParam('OutputFlag', 0)

# Decision variables
y = {}
for t in tasks:
    for m in methods:
        y[t, m] = model.addVar(vtype=GRB.BINARY, name=f"y_{t}_{m}")

s = {}
for t in tasks:
    for m in methods:
        s[t, m] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"s_{t}_{m}")

l = {}
for t in tasks:
    for m in methods:
        l[t, m] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"l_{t}_{m}")

total_skilled = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="total_skilled")
total_laborers = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="total_laborers")

# Objective: minimize total weekly cost
obj = skilled_wage * total_skilled + laborer_wage * total_laborers
for t in tasks:
    for m in methods:
        obj += tm_data[t, m]['Fixed_Cost'] * y[t, m]
model.setObjective(obj, GRB.MINIMIZE)

# Constraints
model.addConstr(total_skilled == gp.quicksum(s[t, m] for t in tasks for m in methods), "TotalSkilledDef")
model.addConstr(total_laborers == gp.quicksum(l[t, m] for t in tasks for m in methods), "TotalLaborersDef")

# Exactly one method per task
for t in tasks:
    model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1, f"OneMethod_{t}")

# Hours requirement
M_big = 10000
for t in tasks:
    for m in methods:
        req_hours = tm_data[t, m]['Effective_Hours']
        model.addConstr(skilled_hours * s[t, m] + laborer_hours * l[t, m] >= req_hours * y[t, m], f"Hours_{t}_{m}")
        model.addConstr(s[t, m] <= M_big * y[t, m], f"LinkS_{t}_{m}")
        model.addConstr(l[t, m] <= M_big * y[t, m], f"LinkL_{t}_{m}")

# Max constraints
model.addConstr(total_skilled <= max_skilled, "MaxSkilled")
model.addConstr(total_laborers <= max_laborers, "MaxLaborers")

# Skilled workers cannot exceed 60% of total laborers
model.addConstr(total_skilled <= skilled_hiring_ratio * total_laborers, "SkilledRatio")

# Exclusion rule
model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1, "ExclusionRule")

# Minimum skilled workers for Task 3 if Method B is chosen
model.addConstr(s['Task_3', 'Method_B'] >= min_skilled_task3_B * y['Task_3', 'Method_B'], "MinSkilledTask3B")

# Task-level skill-balance bands
# For each task, the skilled share must be between min and max bounds
# skilled_share = s[task] / (s[task] + l[task])
# min_share <= s[task] / (s[task] + l[task]) <= max_share
# Equivalent to:
# min_share * (s[task] + l[task]) <= s[task] <= max_share * (s[task] + l[task])
# min_share * s[task] + min_share * l[task] <= s[task] <= max_share * s[task] + max_share * l[task]
# min_share * l[task] <= s[task] * (1 - min_share)
# s[task] * (1 - max_share) <= max_share * l[task]

# Task 1
s_task1 = gp.quicksum(s['Task_1', m] for m in methods)
l_task1 = gp.quicksum(l['Task_1', m] for m in methods)
model.addConstr(s_task1 >= min_skilled_share_task1 * (s_task1 + l_task1), "MinSkillTask1")
model.addConstr(s_task1 <= max_skilled_share_task1 * (s_task1 + l_task1), "MaxSkillTask1")

# Task 2
s_task2 = gp.quicksum(s['Task_2', m] for m in methods)
l_task2 = gp.quicksum(l['Task_2', m] for m in methods)
model.addConstr(s_task2 >= min_skilled_share_task2 * (s_task2 + l_task2), "MinSkillTask2")
model.addConstr(s_task2 <= max_skilled_share_task2 * (s_task2 + l_task2), "MaxSkillTask2")

# Task 3
s_task3 = gp.quicksum(s['Task_3', m] for m in methods)
l_task3 = gp.quicksum(l['Task_3', m] for m in methods)
model.addConstr(s_task3 >= min_skilled_share_task3 * (s_task3 + l_task3), "MinSkillTask3")
model.addConstr(s_task3 <= max_skilled_share_task3 * (s_task3 + l_task3), "MaxSkillTask3")

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal:.6f}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found (status: {model.status})")
