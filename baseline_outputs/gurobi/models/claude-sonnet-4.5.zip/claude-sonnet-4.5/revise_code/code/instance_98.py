import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Read data files
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Create model
    model = gp.Model("Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    for p in products:
        x[p['Product']] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{p['Product']}")
    
    # Binary variable for whether each product is produced
    y = {}
    for p in products:
        y[p['Product']] = model.addVar(vtype=GRB.BINARY, name=f"y_{p['Product']}")
    
    # Overtime variable
    overtime = model.addVar(lb=0, ub=params['max_overtime'], vtype=GRB.CONTINUOUS, name="overtime")
    
    # Binary variable for overtime review fee
    overtime_review = model.addVar(vtype=GRB.BINARY, name="overtime_review")
    
    # Binary variable for Product A line audit fee
    product_A_line_audit = model.addVar(vtype=GRB.BINARY, name="product_A_line_audit")
    
    model.update()
    
    # Objective: maximize profit minus costs
    profit = gp.quicksum(float(p['Profit_yuan']) * x[p['Product']] for p in products)
    setup_costs = gp.quicksum(float(p['Setup_Cost_yuan']) * y[p['Product']] for p in products)
    overtime_cost = params['overtime_pay'] * overtime
    overtime_review_cost = params['overtime_review_fee'] * overtime_review
    product_A_line_audit_cost = params['product_A_line_audit_fee'] * product_A_line_audit
    
    model.setObjective(
        profit - setup_costs - overtime_cost - overtime_review_cost - product_A_line_audit_cost,
        GRB.MAXIMIZE
    )
    
    # Constraints
    # Steel constraint
    model.addConstr(
        gp.quicksum(float(p['Steel_Required_kg']) * x[p['Product']] for p in products) <= params['available_steel'],
        "Steel"
    )
    
    # Aluminum constraint
    model.addConstr(
        gp.quicksum(float(p['Aluminum_Required_kg']) * x[p['Product']] for p in products) <= params['available_aluminum'],
        "Aluminum"
    )
    
    # Labor constraint with overtime
    model.addConstr(
        gp.quicksum(float(p['Labor_Required_hours']) * x[p['Product']] for p in products) <= params['available_labor'] + overtime,
        "Labor"
    )
    
    # Link production to setup binary variables
    M = 1000  # Big M for logical constraints
    for p in products:
        model.addConstr(x[p['Product']] <= M * y[p['Product']], f"Setup_{p['Product']}")
    
    # Overtime review fee trigger
    # If overtime > overtime_review_threshold, then overtime_review = 1
    model.addConstr(
        overtime <= params['overtime_review_threshold'] + M * overtime_review,
        "Overtime_review_upper"
    )
    model.addConstr(
        overtime >= params['overtime_review_threshold'] + 0.001 - M * (1 - overtime_review),
        "Overtime_review_lower"
    )
    
    # Product A line audit fee trigger
    # If x['A'] > product_A_line_audit_threshold, then product_A_line_audit = 1
    model.addConstr(
        x['A'] <= params['product_A_line_audit_threshold'] + M * product_A_line_audit,
        "Product_A_audit_upper"
    )
    model.addConstr(
        x['A'] >= params['product_A_line_audit_threshold'] + 0.001 - M * (1 - product_A_line_audit),
        "Product_A_audit_lower"
    )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
