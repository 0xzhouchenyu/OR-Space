import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general_parameters.csv
    general_params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row['Parameter_Name']] = float(row['Value'])
    
    shared_temp_handoff_cost = general_params['shared_temp_handoff_cost']
    worker_II_V_pair_fee = general_params['worker_II_V_pair_fee']
    
    # Read table_1.csv
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    workers = []
    tasks = []
    cost = {}
    fixed_cost = {}
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        tasks = header[1:-1]  # ['A', 'B', 'C', 'D']
        
        for row in reader:
            worker = row[0].strip()
            workers.append(worker)
            fixed_cost[worker] = int(row[-1])
            for j, task in enumerate(tasks):
                cost[(worker, task)] = int(row[j + 1])
    
    # Create the optimization model
    model = gp.Model("Assignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i,j] = 1 if worker i is assigned to task j
    x = {}
    for w in workers:
        for t in tasks:
            x[(w, t)] = model.addVar(vtype=GRB.BINARY, name=f"x_{w}_{t}")
    
    # Binary variable: y[w] = 1 if worker w is used
    y = {}
    for w in workers:
        y[w] = model.addVar(vtype=GRB.BINARY, name=f"y_{w}")
    
    # Binary variable for III and V both used
    z_III_V = model.addVar(vtype=GRB.BINARY, name="z_III_V")
    
    # Binary variable for II and V both used
    z_II_V = model.addVar(vtype=GRB.BINARY, name="z_II_V")
    
    # Objective: minimize total cost (assignment costs + fixed costs + handoff penalties)
    obj = gp.LinExpr()
    
    # Assignment costs
    for w in workers:
        for t in tasks:
            obj += cost[(w, t)] * x[(w, t)]
    
    # Fixed costs
    for w in workers:
        obj += fixed_cost[w] * y[w]
    
    # Handoff cost for III and V
    obj += shared_temp_handoff_cost * z_III_V
    
    # Handoff cost for II and V
    obj += worker_II_V_pair_fee * z_II_V
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    
    # Each task must be assigned to exactly one worker
    for t in tasks:
        model.addConstr(gp.quicksum(x[(w, t)] for w in workers) == 1, name=f"task_{t}")
    
    # Each worker can be assigned to at most one task
    for w in workers:
        model.addConstr(gp.quicksum(x[(w, t)] for t in tasks) <= 1, name=f"worker_{w}")
    
    # Link y[w] to x: y[w] = 1 if worker w is assigned to any task
    for w in workers:
        model.addConstr(y[w] == gp.quicksum(x[(w, t)] for t in tasks), name=f"link_{w}")
    
    # z_III_V = 1 if both III and V are used
    model.addConstr(z_III_V >= y['III'] + y['V'] - 1, name="z_III_V_lb")
    model.addConstr(z_III_V <= y['III'], name="z_III_V_ub1")
    model.addConstr(z_III_V <= y['V'], name="z_III_V_ub2")
    
    # z_II_V = 1 if both II and V are used
    model.addConstr(z_II_V >= y['II'] + y['V'] - 1, name="z_II_V_lb")
    model.addConstr(z_II_V <= y['II'], name="z_II_V_ub1")
    model.addConstr(z_II_V <= y['V'], name="z_II_V_ub2")
    
    # Solve
    model.optimize()
    
    # Print solution
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
