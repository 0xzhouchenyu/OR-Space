import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read time periods and minimum waiters needed
time_periods = []
min_waiters = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        time_periods.append(row['Time'].strip())
        min_waiters.append(int(row['Minimum_Number_of_Waiters_Needed'].strip()))

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[param_name] = value

work_hours = int(params['waiter_work_hours'])
n = len(time_periods)  # 6 periods

# Extract peak indicators and quality weights
peak = [int(params[f'peak_{i}']) for i in range(n)]
quality = [params[f'quality_{i}'] for i in range(n)]
waiter_cost_per_shift = params['waiter_cost_per_shift']
waiter_budget = params['waiter_budget']

# Create model
model = gp.Model("Restaurant_Waiters_Revised")
model.setParam('OutputFlag', 0)

# Decision variables: x[i] = number of waiters starting at period i
x = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="x")

# Constraint: each waiter's shift must have one peak and one off-peak period
# A waiter starting at period i works periods i and (i+1) mod n
# So peak[i] + peak[(i+1) mod n] must equal 1
for i in range(n):
    next_period = (i + 1) % n
    if peak[i] + peak[next_period] != 1:
        # This shift is invalid (either 2 peaks or 2 off-peaks)
        model.addConstr(x[i] == 0, f"Invalid_shift_{i}")

# Constraint: coverage in each period must meet demand
for j in range(n):
    prev = (j - 1) % n
    # Waiters working in period j are those who started at period prev or period j
    model.addConstr(x[prev] + x[j] >= min_waiters[j], f"Coverage_{j}")

# Constraint: total cost must stay within budget
total_cost = gp.quicksum(x[i] * waiter_cost_per_shift for i in range(n))
model.addConstr(total_cost <= waiter_budget, "Budget")

# Objective: maximize service quality score
service_quality_score = gp.quicksum(
    quality[j] * (x[(j-1) % n] + x[j]) for j in range(n)
)
model.setObjective(service_quality_score, GRB.MAXIMIZE)

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
