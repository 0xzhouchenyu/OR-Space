import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    # Get data directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    materials = []
    sulfur_content = {}
    purchase_price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            mat = row['Material'].strip()
            materials.append(mat)
            sulfur_content[mat] = float(row[' Sulfur_Content_Percentage'].strip() if ' Sulfur_Content_Percentage' in row else row['Sulfur_Content_Percentage'].strip())
            for key in row:
                if 'Purchase_Price' in key:
                    purchase_price[mat] = float(row[key].strip())
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            val = float(row[' Value'].strip() if ' Value' in row else row['Value'].strip())
            params[param_name] = val
    
    max_sulfur_A_premium = params['max_sulfur_content_A_premium']
    max_sulfur_A_standard = params['max_sulfur_content_A_standard']
    max_sulfur_B_premium = params['max_sulfur_content_B_premium']
    max_sulfur_B_standard = params['max_sulfur_content_B_standard']
    
    selling_price_A_premium = params['selling_price_A_premium']
    selling_price_A_standard = params['selling_price_A_standard']
    selling_price_B_premium = params['selling_price_B_premium']
    selling_price_B_standard = params['selling_price_B_standard']
    
    max_supply_D = params['max_supply_D']
    market_demand_A = params['market_demand_A']
    market_demand_B = params['market_demand_B']
    
    min_premium_share_A = params['min_premium_share_A']
    max_premium_share_A = params['max_premium_share_A']
    min_premium_share_B = params['min_premium_share_B']
    max_premium_share_B = params['max_premium_share_B']
    
    # Product streams
    products = ['A_premium', 'A_standard', 'B_premium', 'B_standard']
    
    # Create model
    model = gp.Model("Revised_Mixing_Problem")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[m, p] = tons of material m used in product stream p
    x = {}
    for m in materials:
        for p in products:
            x[m, p] = model.addVar(lb=0, name=f"x_{m}_{p}")
    
    model.update()
    
    # Total amount of each product stream
    total_A_premium = gp.quicksum(x[m, 'A_premium'] for m in materials)
    total_A_standard = gp.quicksum(x[m, 'A_standard'] for m in materials)
    total_B_premium = gp.quicksum(x[m, 'B_premium'] for m in materials)
    total_B_standard = gp.quicksum(x[m, 'B_standard'] for m in materials)
    
    # Total A and B family production
    total_A = total_A_premium + total_A_standard
    total_B = total_B_premium + total_B_standard
    
    # Objective: Maximize profit (Revenue - Cost)
    revenue = (selling_price_A_premium * total_A_premium +
               selling_price_A_standard * total_A_standard +
               selling_price_B_premium * total_B_premium +
               selling_price_B_standard * total_B_standard)
    
    cost = gp.quicksum(purchase_price[m] * gp.quicksum(x[m, p] for p in products) for m in materials)
    
    model.setObjective(revenue - cost, GRB.MAXIMIZE)
    
    # Sulfur content constraints for each product stream
    # A_premium: sum(sulfur[m]*x[m,A_premium]) <= max_sulfur_A_premium * total_A_premium
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'A_premium'] for m in materials) 
        <= max_sulfur_A_premium * total_A_premium,
        name="Sulfur_A_premium"
    )
    
    # A_standard: sum(sulfur[m]*x[m,A_standard]) <= max_sulfur_A_standard * total_A_standard
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'A_standard'] for m in materials) 
        <= max_sulfur_A_standard * total_A_standard,
        name="Sulfur_A_standard"
    )
    
    # B_premium: sum(sulfur[m]*x[m,B_premium]) <= max_sulfur_B_premium * total_B_premium
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'B_premium'] for m in materials) 
        <= max_sulfur_B_premium * total_B_premium,
        name="Sulfur_B_premium"
    )
    
    # B_standard: sum(sulfur[m]*x[m,B_standard]) <= max_sulfur_B_standard * total_B_standard
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'B_standard'] for m in materials) 
        <= max_sulfur_B_standard * total_B_standard,
        name="Sulfur_B_standard"
    )
    
    # Supply limit for material D
    model.addConstr(
        gp.quicksum(x['D', p] for p in products) <= max_supply_D,
        name="Supply_D"
    )
    
    # Market demand constraints (family level)
    model.addConstr(total_A <= market_demand_A, name="Demand_A")
    model.addConstr(total_B <= market_demand_B, name="Demand_B")
    
    # Premium share constraints for A
    model.addConstr(total_A_premium >= min_premium_share_A, name="Min_Premium_A")
    model.addConstr(total_A_premium <= max_premium_share_A, name="Max_Premium_A")
    
    # Premium share constraints for B
    model.addConstr(total_B_premium >= min_premium_share_B, name="Min_Premium_B")
    model.addConstr(total_B_premium <= max_premium_share_B, name="Max_Premium_B")
    
    # Solve
    model.optimize()
    
    # Print result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
