import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Read product segments and profits
    products = ['Product_A', 'Product_B', 'Product_C']
    segments = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row['Product']
            if p not in segments:
                segments[p] = []
            rng = row['Sales_Volume_Range']
            profit = float(row['Profit'])
            if rng.startswith('Above_'):
                lower = float(rng.split('_')[1])
                upper = None
            else:
                parts = rng.split('_')
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({'lower': lower, 'upper': upper, 'profit': profit})
    
    model = gp.Model("Revised_Production_Plan")
    model.setParam('OutputFlag', 0)
    
    M = 10000
    
    # Decision variables
    x = {}
    p_var = {}
    y = {}
    
    for prod in products:
        pname = prod.split('_')[1]
        x[prod] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{pname}")
        p_var[prod] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"p_{pname}")
        y[prod] = []
        for i in range(len(segments[prod])):
            yi = model.addVar(vtype=GRB.BINARY, name=f"y_{pname}_{i}")
            y[prod].append(yi)
    
    # Overtime labor variable
    overtime = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=params['overtime_cap_hours'], name="overtime")
    
    # Binary variable for second review tier
    second_review = model.addVar(vtype=GRB.BINARY, name="second_review")
    
    model.update()
    
    # Objective: maximize total profit - overtime cost - second review fee
    obj_expr = gp.quicksum(p_var[prod] for prod in products)
    obj_expr -= params['overtime_cost_per_hour'] * overtime
    obj_expr -= params['overtime_second_review_fee'] * second_review
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Piecewise profit constraints
    for prod in products:
        segs = segments[prod]
        # At most one segment active
        model.addConstr(gp.quicksum(y[prod]) <= 1)
        
        for i, seg in enumerate(segs):
            lo = seg['lower']
            hi = seg['upper']
            profit = seg['profit']
            
            # If y[i]=1, x must be in the segment range
            if lo == 0:
                model.addConstr(x[prod] >= 1 - M * (1 - y[prod][i]))
            else:
                model.addConstr(x[prod] >= (lo + 1) - M * (1 - y[prod][i]))
            
            if hi is not None:
                model.addConstr(x[prod] <= hi + M * (1 - y[prod][i]))
            
            # Profit bound
            model.addConstr(p_var[prod] <= profit * x[prod] + M * (1 - y[prod][i]))
        
        # If no segment active, force x=0 and profit=0
        model.addConstr(x[prod] <= M * gp.quicksum(y[prod]))
        model.addConstr(p_var[prod] <= M * gp.quicksum(y[prod]))
    
    # Technical preparation time constraint
    model.addConstr(
        gp.quicksum(params[f"technical_prep_time_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params['available_technical_prep_time']
    )
    
    # Labor time constraint with overtime
    model.addConstr(
        gp.quicksum(params[f"labor_time_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params['available_labor_time'] + overtime
    )
    
    # Materials constraint
    model.addConstr(
        gp.quicksum(params[f"materials_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params['available_materials']
    )
    
    # Packaging constraint
    model.addConstr(
        gp.quicksum(params[f"pack_units_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params['packaging_cap_units']
    )
    
    # Second review tier constraint
    # If overtime > 100, then second_review = 1
    model.addConstr(overtime <= params['overtime_second_review_threshold'] + M * second_review)
    model.addConstr(overtime >= params['overtime_second_review_threshold'] + 0.001 - M * (1 - second_review))
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
