import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Read parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    profit_corn = params['profit_per_acre_corn']
    profit_wheat = params['profit_per_acre_wheat']
    profit_soybeans = params['profit_per_acre_soybeans']
    profit_sorghum = params['profit_per_acre_sorghum']
    total_area = params['total_farm_area']
    corn_wheat_ratio = params['corn_wheat_ratio']
    soybeans_sorghum_ratio = params['soybeans_sorghum_ratio']
    wheat_sorghum_ratio = params['wheat_sorghum_ratio']
    
    # Create model
    model = gp.Model("Farm_Optimization_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    corn = model.addVar(lb=0, name="corn")
    wheat = model.addVar(lb=0, name="wheat")
    soybeans = model.addVar(lb=0, name="soybeans")
    sorghum = model.addVar(lb=0, name="sorghum")
    
    # Binary variable: 1 if corn is planted, 0 if soybeans is planted
    plant_corn = model.addVar(vtype=GRB.BINARY, name="plant_corn")
    
    # Objective: maximize profit
    model.setObjective(
        profit_corn * corn + profit_wheat * wheat + profit_soybeans * soybeans + profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )
    
    # Constraints
    # Total area
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")
    
    # Corn >= 2 * wheat
    model.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio")
    
    # Soybeans >= 0.5 * sorghum
    model.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio")
    
    # Wheat = 3 * sorghum
    model.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_ratio")
    
    # NEW CONSTRAINT: Corn and soybeans are mutually exclusive
    # If plant_corn = 1, then corn >= 20 and soybeans = 0
    # If plant_corn = 0, then corn = 0 and soybeans can be positive
    
    # Minimum corn requirement: corn >= 20 acres
    model.addConstr(corn >= 20, "min_corn")
    
    # Mutual exclusion: corn and soybeans cannot both be planted
    # If plant_corn = 1: corn can be positive, soybeans must be 0
    # If plant_corn = 0: corn must be 0, soybeans can be positive
    
    M = total_area  # Big-M value
    
    # If plant_corn = 1, then soybeans = 0
    model.addConstr(soybeans <= M * (1 - plant_corn), "soybeans_if_not_corn")
    
    # If plant_corn = 0, then corn = 0 (but we have corn >= 20, so plant_corn must be 1)
    model.addConstr(corn <= M * plant_corn, "corn_if_plant_corn")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
