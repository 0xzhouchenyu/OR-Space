import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load the bandwidth table
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        
        bandwidth = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                bandwidth[(row_node, col_node)] = bw
    
    # Calculate costs: cost = 100 - bandwidth
    cost = {}
    edges = []
    for (i, j), bw in bandwidth.items():
        if bw > 0:
            cost[(i, j)] = 100 - bw
            edges.append((i, j))
    
    source = 'A'
    intermediate = 'C'
    target = 'E'
    
    # Create Gurobi model
    model = gp.Model("MinCostPath")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i,j] = 1 if edge (i,j) is used
    x = {}
    for (i, j) in edges:
        x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
    
    # Flow variables for two separate flows: A->C and C->E
    # Flow 1: from A to C
    f1 = {}
    for (i, j) in edges:
        f1[i, j] = model.addVar(vtype=GRB.BINARY, name=f"f1_{i}_{j}")
    
    # Flow 2: from C to E
    f2 = {}
    for (i, j) in edges:
        f2[i, j] = model.addVar(vtype=GRB.BINARY, name=f"f2_{i}_{j}")
    
    # Objective: minimize total cost
    obj = gp.quicksum(cost[i, j] * x[i, j] for (i, j) in edges)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints: x[i,j] = 1 if either flow uses it
    for (i, j) in edges:
        model.addConstr(x[i, j] >= f1[i, j], name=f"link1_{i}_{j}")
        model.addConstr(x[i, j] >= f2[i, j], name=f"link2_{i}_{j}")
        model.addConstr(x[i, j] <= f1[i, j] + f2[i, j], name=f"link3_{i}_{j}")
    
    # Flow conservation for flow 1 (A -> C)
    for node in nodes:
        outflow = gp.quicksum(f1.get((node, j), 0) for j in nodes if (node, j) in f1)
        inflow = gp.quicksum(f1.get((i, node), 0) for i in nodes if (i, node) in f1)
        
        if node == source:
            model.addConstr(outflow - inflow == 1, name=f"flow1_source_{node}")
        elif node == intermediate:
            model.addConstr(outflow - inflow == -1, name=f"flow1_sink_{node}")
        else:
            model.addConstr(outflow - inflow == 0, name=f"flow1_balance_{node}")
    
    # Flow conservation for flow 2 (C -> E)
    for node in nodes:
        outflow = gp.quicksum(f2.get((node, j), 0) for j in nodes if (node, j) in f2)
        inflow = gp.quicksum(f2.get((i, node), 0) for i in nodes if (i, node) in f2)
        
        if node == intermediate:
            model.addConstr(outflow - inflow == 1, name=f"flow2_source_{node}")
        elif node == target:
            model.addConstr(outflow - inflow == -1, name=f"flow2_sink_{node}")
        else:
            model.addConstr(outflow - inflow == 0, name=f"flow2_balance_{node}")
    
    # No loops: each node can be visited at most once (except C which is visited by both)
    # Node visit indicators
    v1 = {}
    v2 = {}
    for node in nodes:
        v1[node] = model.addVar(vtype=GRB.BINARY, name=f"v1_{node}")
        v2[node] = model.addVar(vtype=GRB.BINARY, name=f"v2_{node}")
    
    # Link visit to node visit
    for node in nodes:
        if node != source:
            inflow1 = gp.quicksum(f1.get((i, node), 0) for i in nodes if (i, node) in f1)
            model.addConstr(v1[node] >= inflow1, name=f"visit1_{node}")
        if node != intermediate:
            inflow2 = gp.quicksum(f2.get((i, node), 0) for i in nodes if (i, node) in f2)
            model.addConstr(v2[node] >= inflow2, name=f"visit2_{node}")
    
    # Force source and sink to be visited
    model.addConstr(v1[source] == 1, name="visit1_A")
    model.addConstr(v1[intermediate] == 1, name="visit1_C")
    model.addConstr(v2[intermediate] == 1, name="visit2_C")
    model.addConstr(v2[target] == 1, name="visit2_E")
    
    # No node can be visited by both flows (except C)
    for node in nodes:
        if node != intermediate:
            model.addConstr(v1[node] + v2[node] <= 1, name=f"no_overlap_{node}")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No solution found")

if __name__ == '__main__':
    main()
