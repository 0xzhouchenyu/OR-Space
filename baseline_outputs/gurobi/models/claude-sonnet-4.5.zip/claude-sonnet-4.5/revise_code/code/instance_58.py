import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']
    
    profits = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons'],
    }
    
    water_per_acre = {
        ('apples', 'spring'): params['water_per_acre_apples_spring'],
        ('apples', 'autumn'): params['water_per_acre_apples_autumn'],
        ('pears', 'spring'): params['water_per_acre_pears_spring'],
        ('pears', 'autumn'): params['water_per_acre_pears_autumn'],
        ('oranges', 'spring'): params['water_per_acre_oranges_spring'],
        ('oranges', 'autumn'): params['water_per_acre_oranges_autumn'],
        ('lemons', 'spring'): params['water_per_acre_lemons_spring'],
        ('lemons', 'autumn'): params['water_per_acre_lemons_autumn'],
    }
    
    total_area = params['total_farm_area']
    min_a_to_p = params['min_apples_to_pears_ratio']
    min_a_to_l = params['min_apples_to_lemons_ratio']
    o_to_l = params['oranges_to_lemons_ratio']
    max_types = int(params['max_fruit_types'])
    water_cap_spring = params['water_cap_spring']
    water_cap_autumn = params['water_cap_autumn']
    total_water_budget = params['total_water_budget']
    min_annual_water = params['min_annual_water_per_fruit']
    diversification_reward = params['diversification_reward']
    
    model = gp.Model("farm_seasonal")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: acres of each fruit in each season
    x = {}
    for f in fruits:
        for s in seasons:
            x[f, s] = model.addVar(lb=0, name=f"x_{f}_{s}")
    
    # Binary variable: whether fruit f is grown in the year (substantively)
    y = {}
    for f in fruits:
        y[f] = model.addVar(vtype=GRB.BINARY, name=f"y_{f}")
    
    # Binary variable: whether at least 2 fruits are grown
    diversified = model.addVar(vtype=GRB.BINARY, name="diversified")
    
    # Objective: total profit from both seasons + diversification reward
    profit_expr = gp.quicksum(profits[f] * x[f, s] for f in fruits for s in seasons)
    total_obj = profit_expr + diversification_reward * diversified
    model.setObjective(total_obj, GRB.MAXIMIZE)
    
    # Constraint: land capacity per season
    for s in seasons:
        model.addConstr(gp.quicksum(x[f, s] for f in fruits) <= total_area, name=f"land_{s}")
    
    # Constraint: water capacity per season
    model.addConstr(
        gp.quicksum(water_per_acre[f, 'spring'] * x[f, 'spring'] for f in fruits) <= water_cap_spring,
        name="water_spring"
    )
    model.addConstr(
        gp.quicksum(water_per_acre[f, 'autumn'] * x[f, 'autumn'] for f in fruits) <= water_cap_autumn,
        name="water_autumn"
    )
    
    # Constraint: total annual water budget
    model.addConstr(
        gp.quicksum(water_per_acre[f, s] * x[f, s] for f in fruits for s in seasons) <= total_water_budget,
        name="water_annual"
    )
    
    # Annual acreage per fruit
    annual_acres = {}
    for f in fruits:
        annual_acres[f] = gp.quicksum(x[f, s] for s in seasons)
    
    # Ratio constraints (annual basis)
    model.addConstr(annual_acres['apples'] >= min_a_to_p * annual_acres['pears'], name="ratio_apples_pears")
    model.addConstr(annual_acres['apples'] >= min_a_to_l * annual_acres['lemons'], name="ratio_apples_lemons")
    model.addConstr(annual_acres['oranges'] == o_to_l * annual_acres['lemons'], name="ratio_oranges_lemons")
    
    # Annual water usage per fruit
    annual_water = {}
    for f in fruits:
        annual_water[f] = gp.quicksum(water_per_acre[f, s] * x[f, s] for s in seasons)
    
    # Link y[f] to whether fruit f is substantively grown
    M = 1e6
    for f in fruits:
        model.addConstr(annual_water[f] >= min_annual_water * y[f], name=f"min_water_{f}")
        model.addConstr(annual_water[f] <= M * y[f], name=f"max_water_{f}")
    
    # Constraint: at most max_fruit_types fruits
    model.addConstr(gp.quicksum(y[f] for f in fruits) <= max_types, name="max_types")
    
    # Link diversified to whether at least 2 fruits are grown
    num_fruits_grown = gp.quicksum(y[f] for f in fruits)
    model.addConstr(diversified <= num_fruits_grown / 2, name="diversified_upper")
    model.addConstr(diversified >= (num_fruits_grown - 1) / max_types, name="diversified_lower")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_value = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_value}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

solve()
