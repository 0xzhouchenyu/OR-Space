import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load processing costs from table_1.csv
    cost = {}  # cost[(machine, part)] = value
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p) for p in header[1:]]
        for row in reader:
            machine = row[0].strip()
            for j, p in enumerate(parts):
                cost[(machine, p)] = float(row[j + 1])

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    d = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    max_C = int(params['max_parts_on_C'])
    overtime_threshold = int(params['overtime_threshold'])
    overtime_penalty = params['overtime_penalty']

    machines = ['A', 'B', 'C']

    # Create model
    model = gp.Model("MachineAssignment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[m, p] = 1 if part p is assigned to machine m
    x = {}
    for m in machines:
        for p in parts:
            x[(m, p)] = model.addVar(vtype=GRB.BINARY, name=f"x_{m}_{p}")

    # y[m] = 1 if machine m is used (any part assigned to it)
    y = {}
    for m in machines:
        y[m] = model.addVar(vtype=GRB.BINARY, name=f"y_{m}")

    # z[m] = 1 if machine m processes more than overtime_threshold parts
    z = {}
    for m in machines:
        z[m] = model.addVar(vtype=GRB.BINARY, name=f"z_{m}")

    # Objective: minimize processing costs + setup costs + overtime penalties
    obj = gp.quicksum(cost[(m, p)] * x[(m, p)] for m in machines for p in parts)
    obj += gp.quicksum(d[m] * y[m] for m in machines)
    obj += gp.quicksum(overtime_penalty * z[m] for m in machines)
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraint 1: Each part assigned to exactly one machine
    for p in parts:
        model.addConstr(gp.quicksum(x[(m, p)] for m in machines) == 1, name=f"assign_{p}")

    # Linking y to x: if any part on machine m, y[m] = 1
    for m in machines:
        for p in parts:
            model.addConstr(x[(m, p)] <= y[m], name=f"link_{m}_{p}")

    # Constraint 2: Parts 1 and 2 - if part1 on A then part2 on B or C, and vice versa
    # This means: x[A,1] + x[A,2] = 1 (exactly one of parts 1,2 is on A)
    model.addConstr(x[('A', 1)] + x[('A', 2)] == 1, name="parts_1_2")

    # Constraint 3: Fixed assignments
    model.addConstr(x[('A', 3)] == 1, name="part3_A")
    model.addConstr(x[('B', 4)] == 1, name="part4_B")
    model.addConstr(x[('C', 5)] == 1, name="part5_C")

    # Constraint 4: At most 3 parts on machine C
    model.addConstr(gp.quicksum(x[('C', p)] for p in parts) <= max_C, name="max_C")

    # Constraint 5: Overtime penalty - if machine m processes more than overtime_threshold parts
    # z[m] = 1 if sum of parts on machine m > overtime_threshold
    for m in machines:
        num_parts = gp.quicksum(x[(m, p)] for p in parts)
        # z[m] = 1 if num_parts > overtime_threshold
        # num_parts <= overtime_threshold + M * z[m]
        # num_parts >= overtime_threshold + 1 - M * (1 - z[m])
        # Simpler: num_parts - overtime_threshold <= M * z[m]
        #          num_parts - overtime_threshold >= 1 - M * (1 - z[m]) if z[m] = 1
        # We use: if num_parts > overtime_threshold then z[m] must be 1
        M = len(parts)
        model.addConstr(num_parts <= overtime_threshold + M * z[m], name=f"overtime_upper_{m}")
        model.addConstr(num_parts >= (overtime_threshold + 1) * z[m], name=f"overtime_lower_{m}")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == '__main__':
    main()
