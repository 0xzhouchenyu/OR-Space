import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_coverage_data(data_dir):
    """Load the coverage data from table_1.csv.
    
    Returns:
        areas: list of all area codes
        coverage: dict mapping each area to the set of areas it can cover
    """
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)  # skip header
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    
    return areas, coverage


def load_general_parameters(data_dir):
    """Load general parameters from general_parameters.csv."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            try:
                if '.' in value_str:
                    params[param_name] = float(value_str)
                else:
                    params[param_name] = int(value_str)
            except ValueError:
                params[param_name] = value_str
    
    return params


def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load data
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    small_cost = params.get('small_cost', 1)
    large_cost = params.get('large_cost', 2)
    small_cap_areas = params.get('small_cap_areas', 3)
    max_large_stores = params.get('max_large_stores', 1)
    minimum_neighborhood_counters = params.get('minimum_neighborhood_counters', 6)
    small_store_counter_credit = params.get('small_store_counter_credit', 1)
    
    # Create model
    model = gp.Model("ChainStores")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_small[j] = 1 if we build a small-format store in area j
    # x_large[j] = 1 if we build a large-format store in area j
    x_small = {}
    x_large = {}
    for j in areas:
        x_small[j] = model.addVar(vtype=GRB.BINARY, name=f"x_small_{j}")
        x_large[j] = model.addVar(vtype=GRB.BINARY, name=f"x_large_{j}")
    
    # Auxiliary variables: y[j][i] = 1 if small store at j covers area i
    # (needed to enforce the capacity constraint on small stores)
    y = {}
    for j in areas:
        for i in coverage[j]:
            y[j, i] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}_{i}")
    
    # Objective: minimize total cost
    obj = gp.quicksum(small_cost * x_small[j] + large_cost * x_large[j] for j in areas)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraint 1: Each area must be covered by at least one store
    for i in areas:
        covering_stores = [j for j in areas if i in coverage[j]]
        model.addConstr(
            gp.quicksum(y[j, i] for j in covering_stores if (j, i) in y) + 
            gp.quicksum(x_large[j] for j in covering_stores) >= 1,
            name=f"cover_{i}"
        )
    
    # Constraint 2: y[j][i] can only be 1 if x_small[j] = 1
    for j in areas:
        for i in coverage[j]:
            model.addConstr(y[j, i] <= x_small[j], name=f"link_{j}_{i}")
    
    # Constraint 3: Small store capacity - can serve at most small_cap_areas
    for j in areas:
        model.addConstr(
            gp.quicksum(y[j, i] for i in coverage[j]) <= small_cap_areas * x_small[j],
            name=f"small_cap_{j}"
        )
    
    # Constraint 4: At most one large store in the entire network
    model.addConstr(
        gp.quicksum(x_large[j] for j in areas) <= max_large_stores,
        name="max_large"
    )
    
    # Constraint 5: At most one type of store per location
    for j in areas:
        model.addConstr(x_small[j] + x_large[j] <= 1, name=f"one_type_{j}")
    
    # Constraint 6: Minimum neighborhood counters requirement
    model.addConstr(
        gp.quicksum(small_store_counter_credit * x_small[j] for j in areas) >= minimum_neighborhood_counters,
        name="min_counters"
    )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_value = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_value}")
    else:
        print(f"FINAL_OBJ_VALUE: No solution found")


if __name__ == "__main__":
    main()
