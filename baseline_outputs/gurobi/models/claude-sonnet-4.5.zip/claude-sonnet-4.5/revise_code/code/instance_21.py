import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Parse general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    cost_a = params['cost_supplier_a']
    cost_b = params['cost_supplier_b']
    cost_c = params['cost_supplier_c']
    size_a = int(params['order_size_supplier_a'])
    size_b = int(params['order_size_supplier_b'])
    size_c = int(params['order_size_supplier_c'])
    min_tables = int(params['min_tables_required'])
    max_tables = int(params['max_tables_allowed'])
    min_b_if_a = int(params['min_tables_supplier_b_if_a'])
    b_requires_c = int(params['supplier_b_requires_c'])
    max_free_orders_c = int(params['max_free_orders_c'])
    penalty_per_extra_order_c = params['penalty_per_extra_order_c']
    bc_shared_trigger = int(params['supplier_bc_shared_inbound_trigger'])
    bc_shared_fee = params['supplier_bc_shared_inbound_fee']
    
    # Create model
    model = gp.Model("Restaurant_Tables_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of orders from each supplier
    x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_a")
    x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_b")
    x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_c")
    
    # Binary variables for conditional constraints
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")
    
    # Binary variable for shared inbound desk (both B and C used)
    y_bc = model.addVar(vtype=GRB.BINARY, name="y_bc")
    
    # Variable for extra orders from C beyond free limit
    extra_orders_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="extra_orders_c")
    
    model.update()
    
    # Objective: minimize total cost
    obj = (cost_a * size_a * x_a + 
           cost_b * size_b * x_b + 
           cost_c * size_c * x_c + 
           penalty_per_extra_order_c * extra_orders_c)
    
    if bc_shared_trigger:
        obj += bc_shared_fee * y_bc
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Total tables constraints
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c >= min_tables, "min_tables")
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c <= max_tables, "max_tables")
    
    # Link binary variables to order variables
    M = 1000
    model.addConstr(x_a <= M * y_a, "link_a_upper")
    model.addConstr(x_a >= y_a, "link_a_lower")
    model.addConstr(x_b <= M * y_b, "link_b_upper")
    model.addConstr(x_b >= y_b, "link_b_lower")
    model.addConstr(x_c <= M * y_c, "link_c_upper")
    model.addConstr(x_c >= y_c, "link_c_lower")
    
    # If ordering from A, then tables from B >= 30
    model.addConstr(size_b * x_b >= min_b_if_a * y_a, "min_b_if_a")
    
    # If ordering from B, must order from C
    if b_requires_c:
        model.addConstr(y_c >= y_b, "b_requires_c")
    
    # Extra orders from C beyond free limit
    model.addConstr(extra_orders_c >= x_c - max_free_orders_c, "extra_orders_c")
    
    # Shared inbound desk: y_bc = 1 if both B and C are used
    if bc_shared_trigger:
        model.addConstr(y_bc >= y_b + y_c - 1, "bc_shared_lower")
        model.addConstr(y_bc <= y_b, "bc_shared_b")
        model.addConstr(y_bc <= y_c, "bc_shared_c")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
