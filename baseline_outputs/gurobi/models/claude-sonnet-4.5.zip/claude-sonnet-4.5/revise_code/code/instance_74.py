import os
import csv
import gurobipy as gp
from gurobipy import GRB

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

precedences = []
with open(os.path.join(data_dir, 'table_1.csv')) as f:
    reader = csv.DictReader(f)
    for row in reader:
        precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))

activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
dur = {a: int(params[f'activity_{a}_duration']) for a in activities}
work_cost = params['work_cost_per_day']
machine_cost = params['machine_rental_cost_per_day']
E_overtime_reduction = int(params['activity_E_overtime_reduction'])
E_overtime_cost = params['activity_E_overtime_cost']
E_followup_review_cost = params['activity_E_followup_review_cost']

model = gp.Model("Project_Cost_Minimization")
model.setParam('OutputFlag', 0)

S = {a: model.addVar(lb=0, name=f'S_{a}') for a in activities}
T = model.addVar(lb=0, name='T')
use_E_overtime = model.addVar(vtype=GRB.BINARY, name='use_E_overtime')

for pred, succ in precedences:
    model.addConstr(S[succ] >= S[pred] + dur[pred] - (E_overtime_reduction if pred == 'E' else 0) * use_E_overtime)

model.addConstr(T >= S['C'] + dur['C'])
model.addConstr(T >= S['B'] + dur['B'])

objective = (work_cost * T + 
             machine_cost * (S['B'] + dur['B'] - S['A']) + 
             E_overtime_cost * use_E_overtime + 
             E_followup_review_cost * use_E_overtime)

model.setObjective(objective, GRB.MINIMIZE)

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.objVal}")
