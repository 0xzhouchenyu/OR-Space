import gurobipy as gp
from gurobipy import GRB
import csv
import os
import math

def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load table_1.csv
    parts = []
    with open(os.path.join(base_dir, 'data', 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
    
    # Load general_parameters.csv
    params = {}
    with open(os.path.join(base_dir, 'data', 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    return parts, params

def fuel_per_bomb(distance, params, bomb_type, scenario):
    """Fuel for one trip carrying a bomb to target and returning empty, including scenario overhead."""
    if bomb_type == 'heavy':
        eff_loaded = params['fuel_efficiency_heavy_bomb']
    else:  # light
        eff_loaded = params['fuel_efficiency_light_bomb']
    
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    
    if scenario == 'A':
        overhead = params['sortie_fuel_overhead_A']
    else:  # B
        overhead = params['sortie_fuel_overhead_B']
    
    return distance / eff_loaded + distance / eff_empty + takeoff_landing + overhead

def prob_destroy_part(x_heavy, x_light, p_heavy, p_light):
    """Probability of destroying a part given x_heavy heavy bombs and x_light light bombs."""
    return 1.0 - (1.0 - p_heavy) ** x_heavy * (1.0 - p_light) ** x_light

def main():
    parts, params = load_data()
    
    max_heavy = int(params['max_heavy_bombs'])
    max_light = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts = int(params['min_parts_destroyed'])
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    scenario_prob_A = params['scenario_prob_A']
    scenario_prob_B = params['scenario_prob_B']
    
    n = len(parts)
    
    # Compute fuel consumption per bomb per part for each scenario
    fuel_heavy_A = [fuel_per_bomb(parts[i]['distance'], params, 'heavy', 'A') for i in range(n)]
    fuel_light_A = [fuel_per_bomb(parts[i]['distance'], params, 'light', 'A') for i in range(n)]
    fuel_heavy_B = [fuel_per_bomb(parts[i]['distance'], params, 'heavy', 'B') for i in range(n)]
    fuel_light_B = [fuel_per_bomb(parts[i]['distance'], params, 'light', 'B') for i in range(n)]
    
    # Create model
    model = gp.Model("BombAllocation")
    model.setParam('OutputFlag', 0)
    model.setParam('NonConvex', 2)
    
    # Decision variables: number of heavy and light bombs allocated to each part
    x_heavy = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="x_heavy")
    x_light = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="x_light")
    
    # Probability that each part is destroyed
    p_destroy = model.addVars(n, vtype=GRB.CONTINUOUS, lb=0, ub=1, name="p_destroy")
    
    # Binary variables for whether each part is destroyed
    z = model.addVars(n, vtype=GRB.BINARY, name="z")
    
    # Auxiliary variables for computing destruction probabilities
    # p_destroy[i] = 1 - (1 - p_heavy[i])^x_heavy[i] * (1 - p_light[i])^x_light[i]
    # We'll use a piecewise linear approximation or direct nonlinear constraint
    
    for i in range(n):
        p_heavy = parts[i]['p_heavy']
        p_light = parts[i]['p_light']
        
        # For small probabilities and integer variables, we can enumerate possibilities
        # or use log transformation: log(1 - p_destroy[i]) = x_heavy[i] * log(1 - p_heavy) + x_light[i] * log(1 - p_light)
        
        # Using general constraint for exponential
        # p_survive[i] = (1 - p_heavy)^x_heavy[i] * (1 - p_light)^x_light[i]
        # p_destroy[i] = 1 - p_survive[i]
        
        # We'll use a linearization approach with auxiliary variables
        # For practical purposes with small integers, we can use PWL or direct computation
        
        # Let's use a direct approach: enumerate possible values and use SOS or big-M
        # Given the problem size, we'll use a log-linear approximation
        
        if p_heavy > 0 and p_heavy < 1:
            log_survive_heavy = math.log(1 - p_heavy)
        else:
            log_survive_heavy = 0
            
        if p_light > 0 and p_light < 1:
            log_survive_light = math.log(1 - p_light)
        else:
            log_survive_light = 0
        
        # log(p_survive[i]) = x_heavy[i] * log(1 - p_heavy) + x_light[i] * log(1 - p_light)
        # p_survive[i] = exp(log_survive[i])
        # p_destroy[i] = 1 - p_survive[i]
        
        # For Gurobi, we can use general constraints
        # Create auxiliary variable for log of survival probability
        log_survive = model.addVar(lb=-GRB.INFINITY, name=f"log_survive_{i}")
        model.addConstr(log_survive == x_heavy[i] * log_survive_heavy + x_light[i] * log_survive_light)
        
        # p_survive = exp(log_survive)
        p_survive = model.addVar(lb=0, ub=1, name=f"p_survive_{i}")
        model.addGenConstrExp(log_survive, p_survive, name=f"exp_constr_{i}")
        
        # p_destroy = 1 - p_survive
        model.addConstr(p_destroy[i] == 1 - p_survive)
    
    # Constraints
    # 1. Bomb inventory limits
    model.addConstr(gp.quicksum(x_heavy[i] for i in range(n)) <= max_heavy, "heavy_limit")
    model.addConstr(gp.quicksum(x_light[i] for i in range(n)) <= max_light, "light_limit")
    
    # 2. Fuel limit for scenario A
    model.addConstr(
        gp.quicksum(x_heavy[i] * fuel_heavy_A[i] + x_light[i] * fuel_light_A[i] for i in range(n)) <= fuel_limit,
        "fuel_limit_A"
    )
    
    # 3. Fuel limit for scenario B
    model.addConstr(
        gp.quicksum(x_heavy[i] * fuel_heavy_B[i] + x_light[i] * fuel_light_B[i] for i in range(n)) <= fuel_limit,
        "fuel_limit_B"
    )
    
    # 4. Sortie limit for scenario A
    model.addConstr(
        gp.quicksum(x_heavy[i] + x_light[i] for i in range(n)) <= max_sorties_A,
        "sortie_limit_A"
    )
    
    # 5. Sortie limit for scenario B
    model.addConstr(
        gp.quicksum(x_heavy[i] + x_light[i] for i in range(n)) <= max_sorties_B,
        "sortie_limit_B"
    )
    
    # 6. Link z[i] to p_destroy[i] (z[i] = 1 if part i is destroyed in expectation)
    # For the objective, we need to compute P(at least k parts destroyed)
    # This is complex with continuous probabilities
    
    # We'll use a different approach: compute expected number of parts destroyed
    # and use indicator constraints or a more sophisticated method
    
    # Actually, we need to maximize the probability that at least min_parts are destroyed
    # This requires computing all combinations, which is exponential
    
    # For 4 parts and min_parts=2, we can enumerate:
    # P(at least 2) = sum over all subsets S with |S| >= 2 of P(exactly parts in S are destroyed)
    
    # Let's use binary variables y[S] for each subset S
    # But this is 2^4 = 16 subsets
    
    # Alternative: use inclusion-exclusion or dynamic programming linearization
    
    # For simplicity and given the problem size, we'll enumerate all 2^n scenarios
    # and use binary variables to select which scenario occurs
    
    # Create binary variables for each possible outcome (which parts are destroyed)
    outcomes = []
    for mask in range(2**n):
        outcome = [(mask >> i) & 1 for i in range(n)]
        outcomes.append(outcome)
    
    # Binary variable for each outcome
    y = model.addVars(len(outcomes), vtype=GRB.CONTINUOUS, lb=0, ub=1, name="y")
    
    # Probability of each outcome
    # P(outcome) = product over i of (p_destroy[i] if outcome[i]==1 else (1-p_destroy[i]))
    # This is nonlinear, so we'll use log transformation
    
    for idx, outcome in enumerate(outcomes):
        # log(P(outcome)) = sum over i of (outcome[i] * log(p_destroy[i]) + (1-outcome[i]) * log(1-p_destroy[i]))
        # We need to constrain y[idx] to equal this probability
        
        # Using auxiliary variables and general constraints
        log_prob = model.addVar(lb=-GRB.INFINITY, name=f"log_prob_{idx}")
        
        log_terms = []
        for i in range(n):
            if outcome[i] == 1:
                # log(p_destroy[i])
                log_p = model.addVar(lb=-GRB.INFINITY, name=f"log_p_destroy_{idx}_{i}")
                model.addGenConstrLog(p_destroy[i], log_p, name=f"log_p_destroy_constr_{idx}_{i}")
                log_terms.append(log_p)
            else:
                # log(1 - p_destroy[i])
                one_minus_p = model.addVar(lb=0, ub=1, name=f"one_minus_p_{idx}_{i}")
                model.addConstr(one_minus_p == 1 - p_destroy[i])
                log_one_minus_p = model.addVar(lb=-GRB.INFINITY, name=f"log_one_minus_p_{idx}_{i}")
                model.addGenConstrLog(one_minus_p, log_one_minus_p, name=f"log_one_minus_p_constr_{idx}_{i}")
                log_terms.append(log_one_minus_p)
        
        model.addConstr(log_prob == gp.quicksum(log_terms))
        model.addGenConstrExp(log_prob, y[idx], name=f"exp_prob_{idx}")
    
    # Objective: maximize expected probability of mission success
    # Mission success = at least min_parts destroyed
    obj_expr = gp.quicksum(
        y[idx] for idx, outcome in enumerate(outcomes) if sum(outcome) >= min_parts
    )
    
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.6f}")
    else:
        print(f"FINAL_OBJ_VALUE: 0.0")

if __name__ == '__main__':
    main()
