import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Read product data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'name': row['Product Name'].strip(),
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            })
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    available_labor = params['available_labor']
    available_material = params['available_material']
    fixed_costs = [
        params['fixed_cost_shirts'],
        params['fixed_cost_short_sleeves'],
        params['fixed_cost_casual_clothes']
    ]
    
    regular_discount = params['segment_regular_discount']
    promo_discount = params['segment_promo_discount']
    promo_labor_cap = params['segment_promo_labor_cap']
    promo_material_cap = params['segment_promo_material_cap']
    
    min_batch = [
        params['min_batch_shirts'],
        params['min_batch_short_sleeves'],
        params['min_batch_casual_clothes']
    ]
    
    max_prod = [
        params['max_prod_shirts'],
        params['max_prod_short_sleeves'],
        params['max_prod_casual_clothes']
    ]
    
    n = len(products)
    
    # Create model
    model = gp.Model("clothing_production_revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_reg[i] = units of product i in regular segment
    # x_promo[i] = units of product i in promotional segment
    # y[i] = binary, 1 if product i equipment is activated
    # z_reg[i] = binary, 1 if product i is present in regular segment (meets min batch)
    # z_promo[i] = binary, 1 if product i is present in promo segment (meets min batch)
    
    x_reg = [model.addVar(vtype=GRB.INTEGER, name=f"x_reg_{i}") for i in range(n)]
    x_promo = [model.addVar(vtype=GRB.INTEGER, name=f"x_promo_{i}") for i in range(n)]
    y = [model.addVar(vtype=GRB.BINARY, name=f"y_{i}") for i in range(n)]
    z_reg = [model.addVar(vtype=GRB.BINARY, name=f"z_reg_{i}") for i in range(n)]
    z_promo = [model.addVar(vtype=GRB.BINARY, name=f"z_promo_{i}") for i in range(n)]
    
    # Objective: maximize profit
    # Revenue from regular segment: sum_i (price_i * regular_discount * x_reg_i)
    # Revenue from promo segment: sum_i (price_i * promo_discount * x_promo_i)
    # Variable costs: sum_i (var_cost_i * (x_reg_i + x_promo_i))
    # Fixed costs: sum_i (fixed_cost_i * y_i)
    
    revenue_reg = gp.quicksum(
        products[i]['price'] * regular_discount * x_reg[i] for i in range(n)
    )
    revenue_promo = gp.quicksum(
        products[i]['price'] * promo_discount * x_promo[i] for i in range(n)
    )
    variable_costs = gp.quicksum(
        products[i]['var_cost'] * (x_reg[i] + x_promo[i]) for i in range(n)
    )
    fixed_costs_total = gp.quicksum(fixed_costs[i] * y[i] for i in range(n))
    
    profit = revenue_reg + revenue_promo - variable_costs - fixed_costs_total
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Constraints
    # 1. Labor constraint (total)
    model.addConstr(
        gp.quicksum(products[i]['labor'] * (x_reg[i] + x_promo[i]) for i in range(n)) <= available_labor,
        "total_labor"
    )
    
    # 2. Material constraint (total)
    model.addConstr(
        gp.quicksum(products[i]['material'] * (x_reg[i] + x_promo[i]) for i in range(n)) <= available_material,
        "total_material"
    )
    
    # 3. Promotional segment resource caps
    model.addConstr(
        gp.quicksum(products[i]['labor'] * x_promo[i] for i in range(n)) <= promo_labor_cap,
        "promo_labor"
    )
    
    model.addConstr(
        gp.quicksum(products[i]['material'] * x_promo[i] for i in range(n)) <= promo_material_cap,
        "promo_material"
    )
    
    # 4. Equipment activation: if any production, equipment must be on
    for i in range(n):
        model.addConstr(x_reg[i] + x_promo[i] <= max_prod[i] * y[i], f"equip_activation_{i}")
    
    # 5. Minimum batch constraint: total production >= min_batch if equipment is on
    for i in range(n):
        model.addConstr(x_reg[i] + x_promo[i] >= min_batch[i] * y[i], f"min_batch_{i}")
    
    # 6. Segment presence: product is present in segment only if meets minimum batch
    # For regular segment
    for i in range(n):
        # If z_reg[i] = 1, then x_reg[i] >= min_batch[i]
        model.addConstr(x_reg[i] >= min_batch[i] * z_reg[i], f"reg_presence_lower_{i}")
        # If x_reg[i] > 0, then z_reg[i] can be 1 (but only if >= min_batch)
        model.addConstr(x_reg[i] <= max_prod[i] * z_reg[i], f"reg_presence_upper_{i}")
    
    # For promotional segment
    for i in range(n):
        model.addConstr(x_promo[i] >= min_batch[i] * z_promo[i], f"promo_presence_lower_{i}")
        model.addConstr(x_promo[i] <= max_prod[i] * z_promo[i], f"promo_presence_upper_{i}")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
