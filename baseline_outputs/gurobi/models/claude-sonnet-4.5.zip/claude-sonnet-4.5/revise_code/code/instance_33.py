import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read items and values
items = []
values = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        items.append(row['Item'].strip())
        values.append(int(row['Value'].strip()))

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        value_str = row['Value'].strip()
        if value_str:
            try:
                params[param_name] = float(value_str)
            except:
                params[param_name] = value_str

n = len(items)
total_value = sum(values)

# Extract parameters
son1_min_share = params['son1_min_share']
high_value_threshold = params['high_value_threshold']
max_high_value_items_per_son = int(params['max_high_value_items_per_son'])
deferred_diamonds_per_son = int(params['deferred_diamonds_per_son'])
immediate_tax_weight = params['immediate_tax_weight']
total_tax_weight = params['total_tax_weight']

# Identify special items
jr_indices = [i for i, item in enumerate(items) if 'Jack Russell' in item]
diamond_indices = [i for i, item in enumerate(items) if 'Diamond' in item]
high_value_indices = [i for i in range(n) if values[i] > high_value_threshold]

# Create the optimization model
model = gp.Model("Inheritance_Split_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
# x[i] = 1 if item i goes to son 1 (immediate), 0 otherwise
x = model.addVars(n, vtype=GRB.BINARY, name="x")

# d[i] = 1 if item i is deferred for son 1, 0 otherwise
d = model.addVars(n, vtype=GRB.BINARY, name="d")

# y[i] = 1 if item i goes to son 2 (immediate), 0 otherwise
y = model.addVars(n, vtype=GRB.BINARY, name="y")

# e[i] = 1 if item i is deferred for son 2, 0 otherwise
e = model.addVars(n, vtype=GRB.BINARY, name="e")

# Variables for absolute differences
diff_immediate = model.addVar(lb=0, name="diff_immediate")
diff_total = model.addVar(lb=0, name="diff_total")

# Each item must be assigned to exactly one category (son1 immediate, son1 deferred, son2 immediate, son2 deferred)
for i in range(n):
    model.addConstr(x[i] + d[i] + y[i] + e[i] == 1, name=f"assign_{i}")

# Jack Russell racing dogs must not be separated (must go to same son, same transfer type)
if len(jr_indices) == 2:
    i1, i2 = jr_indices[0], jr_indices[1]
    model.addConstr(x[i1] == x[i2], name="jr_immediate_son1")
    model.addConstr(d[i1] == d[i2], name="jr_deferred_son1")
    model.addConstr(y[i1] == y[i2], name="jr_immediate_son2")
    model.addConstr(e[i1] == e[i2], name="jr_deferred_son2")

# Son 1 minimum share (total ownership: immediate + deferred)
value_son1_total = gp.quicksum(values[i] * (x[i] + d[i]) for i in range(n))
model.addConstr(value_son1_total >= son1_min_share * total_value, name="son1_min_share")

# High-value item concentration limits (per son, immediate + deferred)
high_value_son1 = gp.quicksum(x[i] + d[i] for i in high_value_indices)
high_value_son2 = gp.quicksum(y[i] + e[i] for i in high_value_indices)
model.addConstr(high_value_son1 <= max_high_value_items_per_son, name="max_high_value_son1")
model.addConstr(high_value_son2 <= max_high_value_items_per_son, name="max_high_value_son2")

# Deferred diamonds limit per son
deferred_diamonds_son1 = gp.quicksum(d[i] for i in diamond_indices)
deferred_diamonds_son2 = gp.quicksum(e[i] for i in diamond_indices)
model.addConstr(deferred_diamonds_son1 <= deferred_diamonds_per_son, name="deferred_diamonds_son1")
model.addConstr(deferred_diamonds_son2 <= deferred_diamonds_per_son, name="deferred_diamonds_son2")

# Immediate value calculations
value_son1_immediate = gp.quicksum(values[i] * x[i] for i in range(n))
value_son2_immediate = gp.quicksum(values[i] * y[i] for i in range(n))

# Total value calculations
value_son2_total = gp.quicksum(values[i] * (y[i] + e[i]) for i in range(n))

# Absolute difference constraints for immediate values
model.addConstr(diff_immediate >= value_son1_immediate - value_son2_immediate, name="abs_immediate_1")
model.addConstr(diff_immediate >= value_son2_immediate - value_son1_immediate, name="abs_immediate_2")

# Absolute difference constraints for total values
model.addConstr(diff_total >= value_son1_total - value_son2_total, name="abs_total_1")
model.addConstr(diff_total >= value_son2_total - value_son1_total, name="abs_total_2")

# Objective: minimize weighted sum of differences
objective = immediate_tax_weight * diff_immediate + total_tax_weight * diff_total
model.setObjective(objective, GRB.MINIMIZE)

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
