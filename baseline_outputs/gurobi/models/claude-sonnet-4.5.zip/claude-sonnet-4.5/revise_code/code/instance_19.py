import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params_file = os.path.join(data_dir, 'general_parameters.csv')

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value_str = row['Value'].strip()
        try:
            value = int(value_str)
        except ValueError:
            try:
                value = float(value_str)
            except ValueError:
                value = value_str
        params[name] = value

# Extract parameters
cost_A = params['cost_per_chair_A']
cost_B = params['cost_per_chair_B']
cost_C = params['cost_per_chair_C']
chairs_per_order_A = params['chairs_per_order_A']
chairs_per_order_B = params['chairs_per_order_B']
chairs_per_order_C = params['chairs_per_order_C']
min_total = params['min_total_chairs']
max_total = params['max_total_chairs']
min_chairs_B_if_A = params['min_chairs_B_if_A']
dependency_B_C = params['dependency_B_C']
fixed_fee_A_regular = params['fixed_fee_A_regular']
fixed_fee_A_express = params['fixed_fee_A_express']
fixed_fee_B_regular = params['fixed_fee_B_regular']
fixed_fee_B_express = params['fixed_fee_B_express']
fixed_fee_C_regular = params['fixed_fee_C_regular']
fixed_fee_C_express = params['fixed_fee_C_express']
weekly_order_budget = params['weekly_order_budget']

# Create model
model = gp.Model("FurnitureOrderRevised")
model.setParam('OutputFlag', 0)

# Upper bounds
max_orders_A = max_total // chairs_per_order_A + 1
max_orders_B = max_total // chairs_per_order_B + 1
max_orders_C = max_total // chairs_per_order_C + 1

# Decision variables: number of orders from each manufacturer in each channel
x_A_regular = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_A, name="x_A_regular")
x_A_express = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_A, name="x_A_express")
x_B_regular = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_B, name="x_B_regular")
x_B_express = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_B, name="x_B_express")
x_C_regular = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_C, name="x_C_regular")
x_C_express = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_C, name="x_C_express")

# Binary variables: which manufacturer-channel combinations are used
y_A_regular = model.addVar(vtype=GRB.BINARY, name="y_A_regular")
y_A_express = model.addVar(vtype=GRB.BINARY, name="y_A_express")
y_B_regular = model.addVar(vtype=GRB.BINARY, name="y_B_regular")
y_B_express = model.addVar(vtype=GRB.BINARY, name="y_B_express")
y_C_regular = model.addVar(vtype=GRB.BINARY, name="y_C_regular")
y_C_express = model.addVar(vtype=GRB.BINARY, name="y_C_express")

# Binary variables: whether manufacturer is used at all
y_A = model.addVar(vtype=GRB.BINARY, name="y_A")
y_B = model.addVar(vtype=GRB.BINARY, name="y_B")
y_C = model.addVar(vtype=GRB.BINARY, name="y_C")

# Total chairs from each manufacturer
chairs_A = chairs_per_order_A * (x_A_regular + x_A_express)
chairs_B = chairs_per_order_B * (x_B_regular + x_B_express)
chairs_C = chairs_per_order_C * (x_C_regular + x_C_express)

# Objective: minimize total cost (chair costs + fixed fees)
total_cost = (cost_A * chairs_A + cost_B * chairs_B + cost_C * chairs_C +
              fixed_fee_A_regular * y_A_regular + fixed_fee_A_express * y_A_express +
              fixed_fee_B_regular * y_B_regular + fixed_fee_B_express * y_B_express +
              fixed_fee_C_regular * y_C_regular + fixed_fee_C_express * y_C_express)

model.setObjective(total_cost, GRB.MINIMIZE)

# Constraint: total chairs between min and max
model.addConstr(chairs_A + chairs_B + chairs_C >= min_total, "MinChairs")
model.addConstr(chairs_A + chairs_B + chairs_C <= max_total, "MaxChairs")

# Big M
M = max_total + 1

# Link y_channel variables to x_channel variables
model.addConstr(x_A_regular <= M * y_A_regular, "LinkA_regular1")
model.addConstr(x_A_regular >= y_A_regular, "LinkA_regular2")
model.addConstr(x_A_express <= M * y_A_express, "LinkA_express1")
model.addConstr(x_A_express >= y_A_express, "LinkA_express2")

model.addConstr(x_B_regular <= M * y_B_regular, "LinkB_regular1")
model.addConstr(x_B_regular >= y_B_regular, "LinkB_regular2")
model.addConstr(x_B_express <= M * y_B_express, "LinkB_express1")
model.addConstr(x_B_express >= y_B_express, "LinkB_express2")

model.addConstr(x_C_regular <= M * y_C_regular, "LinkC_regular1")
model.addConstr(x_C_regular >= y_C_regular, "LinkC_regular2")
model.addConstr(x_C_express <= M * y_C_express, "LinkC_express1")
model.addConstr(x_C_express >= y_C_express, "LinkC_express2")

# Link y_manufacturer to y_channel: manufacturer is used if any channel is used
model.addConstr(y_A == y_A_regular + y_A_express, "ManufA")
model.addConstr(y_B == y_B_regular + y_B_express, "ManufB")
model.addConstr(y_C == y_C_regular + y_C_express, "ManufC")

# Constraint: for each manufacturer, use at most one channel (never both)
# This is already enforced by y_A == y_A_regular + y_A_express with binary variables

# Constraint: weekly order budget (max number of active manufacturer-mode combinations)
model.addConstr(y_A_regular + y_A_express + y_B_regular + y_B_express + y_C_regular + y_C_express <= weekly_order_budget, "WeeklyBudget")

# Original dependency: if ordering from A, must order at least min_chairs_B_if_A chairs from B
model.addConstr(chairs_B >= min_chairs_B_if_A * y_A, "DepAB")

# Original dependency: if ordering from B, must also order from C
model.addConstr(y_B <= y_C, "DepBC")

# Solve
model.optimize()

# Extract result
if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
