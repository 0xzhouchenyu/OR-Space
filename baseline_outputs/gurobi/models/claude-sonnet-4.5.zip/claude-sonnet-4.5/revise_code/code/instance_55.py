import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load courses
courses = {}
with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        course = row['Course'].strip()
        categories = [c.strip() for c in row['Category'].split(';')]
        courses[course] = categories

# Load parameters
params = {}
prerequisites = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = row['Value'].strip()
        if name == 'min_courses_required':
            params['min_courses_required'] = int(value)
        elif name == 'mandatory_foundation_for_cs_counting':
            params['mandatory_foundation'] = value
        elif name == 'cs_category_name':
            params['cs_category'] = value
        elif name.startswith('prerequisite_'):
            course_key = name[len('prerequisite_'):].replace('_', ' ')
            for course in courses.keys():
                if course.lower() == course_key.lower():
                    if course not in prerequisites:
                        prerequisites[course] = []
                    prerequisites[course].append(value)
                    break

min_required = params['min_courses_required']
mandatory_foundation = params['mandatory_foundation']
cs_category = params['cs_category']

# Get all categories
all_categories = set()
for cats in courses.values():
    for c in cats:
        all_categories.add(c)

course_list = list(courses.keys())

# Create model
model = gp.Model("CourseSelection")
model.setParam('OutputFlag', 0)

# Decision variables
x = {course: model.addVar(vtype=GRB.BINARY, name=f"x_{course}") for course in course_list}

# For each category, track which courses count toward that category
y = {(course, cat): model.addVar(vtype=GRB.BINARY, name=f"y_{course}_{cat}") 
     for course in course_list for cat in courses[course]}

# Binary variable: is CS category activated (does any course count toward CS)?
cs_activated = model.addVar(vtype=GRB.BINARY, name="cs_activated")

# Objective: minimize total courses taken
model.setObjective(gp.quicksum(x[course] for course in course_list), GRB.MINIMIZE)

# Constraint: y[course, cat] can only be 1 if x[course] is 1
for course in course_list:
    for cat in courses[course]:
        model.addConstr(y[course, cat] <= x[course], name=f"link_{course}_{cat}")

# Constraint: each course can count toward at most one category
for course in course_list:
    model.addConstr(gp.quicksum(y[course, cat] for cat in courses[course]) <= 1, 
                   name=f"single_count_{course}")

# Constraint: at least min_required distinct courses in each category
for category in all_categories:
    courses_in_cat = [course for course, cats in courses.items() if category in cats]
    model.addConstr(gp.quicksum(y[course, category] for course in courses_in_cat) >= min_required,
                   name=f"min_{category}")

# Constraint: prerequisite enforcement
for course, prereqs in prerequisites.items():
    for prereq in prereqs:
        model.addConstr(x[course] <= x[prereq], name=f"prereq_{course}_{prereq}")

# Constraint: CS activation tracking
# cs_activated = 1 if any course counts toward CS
for course in course_list:
    if cs_category in courses[course]:
        model.addConstr(cs_activated >= y[course, cs_category], 
                       name=f"cs_active_track_{course}")

# Constraint: if CS is activated, mandatory foundation must be taken
model.addConstr(x[mandatory_foundation] >= cs_activated, name="cs_foundation")

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"FINAL_OBJ_VALUE: No solution found")
