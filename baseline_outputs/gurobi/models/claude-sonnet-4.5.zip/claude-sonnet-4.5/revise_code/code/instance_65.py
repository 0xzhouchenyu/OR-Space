import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
    for row in csv.DictReader(f):
        params[row['Parameter_Name'].strip()] = float(row['Value'])

products = {}
with open(os.path.join(data_dir, 'table_1.csv')) as f:
    for row in csv.DictReader(f):
        products[row['Product'].strip()] = {
            'a_hrs': float(row['Workshop_A_Hours']),
            'b_hrs': float(row['Workshop_B_Hours']),
            'insp_cost': float(row['Inspection_Sales_Cost'])
        }

m = products['Microwave_Oven']
w = products['Water_Heater']

# Create model
model = gp.Model("production_revised")
model.setParam('OutputFlag', 0)

# Decision variables
x1 = model.addVar(lb=params['microwave_minimum_sales'], name="microwave")
x2 = model.addVar(lb=params['water_heater_minimum_sales'], name="water_heater")

# Binary variables for workshop A activation
y1 = model.addVar(vtype=GRB.BINARY, name="microwave_uses_A")
y2 = model.addVar(vtype=GRB.BINARY, name="water_heater_uses_A")

model.update()

# Objective: Maximize total revenue (production costs + inspection costs + green bonuses)
# Revenue per unit includes workshop costs, inspection costs, and green bonus
rev_m = (m['a_hrs'] * params['workshop_a_hourly_cost'] + 
         m['b_hrs'] * params['workshop_b_hourly_cost'] + 
         m['insp_cost'] + 
         params['green_bonus_m'])

rev_w = (w['a_hrs'] * params['workshop_a_hourly_cost'] + 
         w['b_hrs'] * params['workshop_b_hourly_cost'] + 
         w['insp_cost'] + 
         params['green_bonus_w'])

model.setObjective(rev_m * x1 + rev_w * x2, GRB.MAXIMIZE)

# Constraints

# Workshop A capacity (including setup hours and overtime)
# Setup hours consumed only if product uses workshop A
model.addConstr(
    m['a_hrs'] * x1 + w['a_hrs'] * x2 + 
    params['setup_hours_A'] * y1 + params['setup_hours_A'] * y2 
    <= params['workshop_a_available_hours'] + params['workshop_a_overtime_limit'],
    "workshop_a_capacity"
)

# Workshop B capacity
model.addConstr(
    m['b_hrs'] * x1 + w['b_hrs'] * x2 <= params['workshop_b_available_hours'],
    "workshop_b_capacity"
)

# Inspection and sales cost limit
model.addConstr(
    m['insp_cost'] * x1 + w['insp_cost'] * x2 <= params['inspection_sales_cost_limit'],
    "inspection_sales_cost"
)

# Technician pool constraint
model.addConstr(
    params['tech_rate_m'] * x1 + params['tech_rate_w'] * x2 <= params['tech_pool_hours'],
    "technician_pool"
)

# Activation constraints (big-M formulation)
# If a product uses workshop A (x > 0), then y must be 1
# Since minimum sales > 0, both products always use workshop A
bigM = params['bigM']

model.addConstr(x1 <= bigM * y1, "activate_microwave")
model.addConstr(x2 <= bigM * y2, "activate_water_heater")

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
