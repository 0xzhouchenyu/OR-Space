import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load monthly prices
months = []
purchase_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        m = int(row['Month'])
        months.append(m)
        purchase_prices[m] = float(row['Purchase_Price_yuan_per_dan'])
        selling_prices[m] = float(row['Selling_Price_yuan_per_dan'])

# Load general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
initial_funds = params['initial_funds']
end_inventory = params['end_of_quarter_inventory']
buy_fast_capacity = params['buy_fast_capacity']
fast_purchase_premium_ratio = params['fast_purchase_premium_ratio']
credit_limit = params['credit_limit']
monthly_interest_rate = params['monthly_interest_rate']
min_inventory = {
    1: params['min_inventory_month_1'],
    2: params['min_inventory_month_2'],
    3: params['min_inventory_month_3']
}

# Create Gurobi model
model = gp.Model("Grain_Trading_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
buy_regular = {m: model.addVar(lb=0, name=f"buy_regular_{m}") for m in months}
buy_fast = {m: model.addVar(lb=0, ub=buy_fast_capacity, name=f"buy_fast_{m}") for m in months}
sell = {m: model.addVar(lb=0, name=f"sell_{m}") for m in months}
stock = {m: model.addVar(lb=0, name=f"stock_{m}") for m in months}
funds = {m: model.addVar(lb=-GRB.INFINITY, name=f"funds_{m}") for m in months}
credit_used = {m: model.addVar(lb=0, ub=credit_limit, name=f"credit_used_{m}") for m in months}
interest_paid = {m: model.addVar(lb=0, name=f"interest_paid_{m}") for m in months}

# Objective: maximize (final funds - initial funds - total interest paid)
total_interest = gp.quicksum(interest_paid[m] for m in months)
model.setObjective(funds[months[-1]] - initial_funds - total_interest, GRB.MAXIMIZE)

# Constraints for each month
for m in months:
    prev_stock = initial_stock if m == 1 else stock[m - 1]
    prev_funds = initial_funds if m == 1 else funds[m - 1]
    prev_credit = 0 if m == 1 else credit_used[m - 1]
    
    # Total purchases in month m
    total_buy = buy_regular[m] + buy_fast[m]
    
    # Stock balance: closing stock = opening stock - sales + purchases
    model.addConstr(stock[m] == prev_stock - sell[m] + total_buy, f"stock_balance_{m}")
    
    # Can only sell what was in stock at the beginning of the month (before purchases)
    model.addConstr(sell[m] <= prev_stock, f"sell_limit_{m}")
    
    # Warehouse capacity
    model.addConstr(stock[m] <= warehouse_capacity, f"warehouse_{m}")
    
    # Minimum inventory requirement
    model.addConstr(stock[m] >= min_inventory[m], f"min_inventory_{m}")
    
    # Interest calculation: interest on credit used at end of month
    model.addConstr(interest_paid[m] == credit_used[m] * monthly_interest_rate, f"interest_{m}")
    
    # Funds balance:
    # Opening liquid funds + credit line = prev_funds + prev_credit
    # Sales revenue comes in: + sell[m] * selling_prices[m]
    # Regular purchase payment: - buy_regular[m] * purchase_prices[m]
    # Fast purchase payment: - buy_fast[m] * purchase_prices[m] * (1 + fast_purchase_premium_ratio)
    # Interest payment: - interest_paid[m]
    # Closing liquid funds + credit line = funds[m] + credit_used[m]
    
    sales_revenue = sell[m] * selling_prices[m]
    regular_cost = buy_regular[m] * purchase_prices[m]
    fast_cost = buy_fast[m] * purchase_prices[m] * (1 + fast_purchase_premium_ratio)
    
    model.addConstr(
        funds[m] + credit_used[m] == 
        prev_funds + prev_credit + sales_revenue - regular_cost - fast_cost - interest_paid[m],
        f"funds_balance_{m}"
    )

# End of quarter inventory requirement
model.addConstr(stock[months[-1]] >= end_inventory, f"end_inventory")

# Solve
model.optimize()

# Output results
if model.status == GRB.OPTIMAL:
    objective_value = model.objVal
    print(f"FINAL_OBJ_VALUE: {objective_value}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
