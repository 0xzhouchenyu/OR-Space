import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_table1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in ['Product_I', 'Product_II', 'Product_III']:
                val = row[p].strip() if row[p].strip() else None
                proc_times[e][p] = float(val) if val else None
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())
    
    return equipment, proc_times, eff_hours, op_costs

def load_general_params(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    
    raw_costs = {
        'Product_I': params['raw_material_cost_product_I'],
        'Product_II': params['raw_material_cost_product_II'],
        'Product_III': params['raw_material_cost_product_III'],
    }
    
    prices = {
        'Product_I': params['unit_price_product_I'],
        'Product_II': params['unit_price_product_II'],
        'Product_III': params['unit_price_product_III'],
    }
    
    shared_labor_hours = params['shared_labor_hours']
    
    labor_coeff = {
        'A1': params['labor_coeff_A1'],
        'A2': params['labor_coeff_A2'],
        'B1': params['labor_coeff_B1'],
        'B2': params['labor_coeff_B2'],
        'B3': params['labor_coeff_B3'],
    }
    
    b2_activation_fee = params['b2_activation_fee']
    
    return raw_costs, prices, shared_labor_hours, labor_coeff, b2_activation_fee

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    equipment, proc_times, eff_hours, op_costs = load_table1(data_dir)
    raw_costs, prices, shared_labor_hours, labor_coeff, b2_activation_fee = load_general_params(data_dir)
    
    products = ['Product_I', 'Product_II', 'Product_III']
    
    A_equip = [e for e in equipment if e.startswith('A')]
    B_equip = [e for e in equipment if e.startswith('B')]
    
    model = gp.Model("Factory_Production")
    model.setParam('OutputFlag', 0)
    
    # x[e, p] = number of units of product p processed on equipment e
    x = {}
    for e in equipment:
        for p in products:
            if proc_times[e][p] is not None:
                x[e, p] = model.addVar(lb=0, name=f"x_{e}_{p}")
    
    # Binary variable: is B2 used?
    use_B2 = model.addVar(vtype=GRB.BINARY, name="use_B2")
    
    model.update()
    
    # Capacity constraints: total processing time <= effective machine hours
    for e in equipment:
        model.addConstr(
            gp.quicksum(x[e, p] * proc_times[e][p] for p in products if proc_times[e][p] is not None) <= eff_hours[e],
            name=f"capacity_{e}"
        )
    
    # Flow balance: for each product, total A-processed = total B-processed
    for p in products:
        a_sum = gp.quicksum(x[e, p] for e in A_equip if (e, p) in x)
        b_sum = gp.quicksum(x[e, p] for e in B_equip if (e, p) in x)
        model.addConstr(a_sum == b_sum, name=f"balance_{p}")
    
    # Shared labor hours constraint
    labor_usage = gp.quicksum(
        labor_coeff[e] * x[e, p] * proc_times[e][p]
        for e in equipment
        for p in products
        if proc_times[e][p] is not None
    )
    model.addConstr(labor_usage <= shared_labor_hours, name="shared_labor")
    
    # B2 activation constraint: if any product uses B2, use_B2 must be 1
    # We need: if sum of x[B2, p] > 0, then use_B2 = 1
    # This can be enforced by: x[B2, p] <= M * use_B2 for all p
    M = 1e6  # Large enough constant
    for p in products:
        if ('B2', p) in x:
            model.addConstr(x['B2', p] <= M * use_B2, name=f"b2_activation_{p}")
    
    # Total production of each product
    total_prod = {}
    for p in products:
        total_prod[p] = gp.quicksum(x[e, p] for e in A_equip if (e, p) in x)
    
    # Revenue
    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)
    
    # Raw material costs
    raw_cost_total = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)
    
    # Operating costs: proportional to usage fraction
    operating_cost = gp.quicksum(
        op_costs[e] * gp.quicksum(x[e, p] * proc_times[e][p] for p in products if (e, p) in x) / eff_hours[e]
        for e in equipment
    )
    
    # B2 activation fee
    b2_fee = b2_activation_fee * use_B2
    
    # Objective: maximize profit
    profit = revenue - raw_cost_total - operating_cost - b2_fee
    model.setObjective(profit, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
