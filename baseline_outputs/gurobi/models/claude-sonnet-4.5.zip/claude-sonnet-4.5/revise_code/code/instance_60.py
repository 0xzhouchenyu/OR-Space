import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Read parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    num_customers = 7
    start_location = 1
    end_location = 1
    max_route_length_day = 1000
    route_cost_day = 20
    
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'num_customers':
                num_customers = int(row['Value'])
            elif row['Parameter_Name'] == 'start_location':
                start_location = int(row['Value'])
            elif row['Parameter_Name'] == 'end_location':
                end_location = int(row['Value'])
            elif row['Parameter_Name'] == 'max_route_length_day':
                max_route_length_day = float(row['Value'])
            elif row['Parameter_Name'] == 'route_cost_day':
                route_cost_day = float(row['Value'])
    
    # Read distance matrix
    D = [[0] * num_customers for _ in range(num_customers)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if not row or not row[0].strip():
                continue
            i = int(row[0]) - 1
            for j_idx, val in enumerate(row[1:]):
                if val.strip() and val.strip() != '-':
                    j = j_idx
                    D[i][j] = float(val)
                    D[j][i] = float(val)
    
    # Create model
    model = gp.Model("TSP_TwoDay")
    model.setParam('OutputFlag', 0)
    
    n = num_customers
    days = [1, 2]
    
    # Decision variables
    # x[i, j, d] = 1 if we travel from location i to j on day d
    x = {}
    for d in days:
        for i in range(n):
            for j in range(n):
                if i != j:
                    x[i, j, d] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}_{d}")
    
    # y[i, d] = 1 if customer i is assigned to day d
    y = {}
    for i in range(1, n):  # customers 1 to n-1 (location 0 is depot)
        for d in days:
            y[i, d] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{d}")
    
    # z[d] = 1 if day d is used (has at least one customer)
    z = {}
    for d in days:
        z[d] = model.addVar(vtype=GRB.BINARY, name=f"z_{d}")
    
    # u[i, d] = position in tour for MTZ subtour elimination
    u = {}
    for d in days:
        for i in range(1, n):
            u[i, d] = model.addVar(vtype=GRB.CONTINUOUS, lb=1, ub=n-1, name=f"u_{i}_{d}")
    
    model.update()
    
    # Objective: minimize total distance + fixed costs for used days
    obj = gp.quicksum(D[i][j] * x[i, j, d] for d in days for i in range(n) for j in range(n) if i != j)
    obj += gp.quicksum(route_cost_day * z[d] for d in days)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    # Each customer must be assigned to exactly one day
    for i in range(1, n):
        model.addConstr(gp.quicksum(y[i, d] for d in days) == 1, name=f"assign_{i}")
    
    # Flow conservation for each day
    for d in days:
        # Depot (location 0): outgoing - incoming = 0 if day is used
        model.addConstr(
            gp.quicksum(x[0, j, d] for j in range(1, n)) == 
            gp.quicksum(x[j, 0, d] for j in range(1, n)),
            name=f"depot_flow_{d}"
        )
        
        # Each customer: if assigned to day d, incoming = outgoing = 1
        for i in range(1, n):
            model.addConstr(
                gp.quicksum(x[j, i, d] for j in range(n) if j != i) == y[i, d],
                name=f"flow_in_{i}_{d}"
            )
            model.addConstr(
                gp.quicksum(x[i, j, d] for j in range(n) if j != i) == y[i, d],
                name=f"flow_out_{i}_{d}"
            )
    
    # Link z[d] to whether day d is used
    for d in days:
        model.addConstr(
            gp.quicksum(y[i, d] for i in range(1, n)) >= z[d],
            name=f"day_used_lb_{d}"
        )
        model.addConstr(
            gp.quicksum(y[i, d] for i in range(1, n)) <= (n-1) * z[d],
            name=f"day_used_ub_{d}"
        )
    
    # MTZ subtour elimination constraints
    for d in days:
        for i in range(1, n):
            for j in range(1, n):
                if i != j:
                    model.addConstr(
                        u[i, d] - u[j, d] + (n-1) * x[i, j, d] <= n - 2,
                        name=f"mtz_{i}_{j}_{d}"
                    )
    
    # Maximum route length per day
    for d in days:
        model.addConstr(
            gp.quicksum(D[i][j] * x[i, j, d] for i in range(n) for j in range(n) if i != j) <= max_route_length_day,
            name=f"max_length_{d}"
        )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    solve()
