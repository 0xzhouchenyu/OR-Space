import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load food items
    items = []
    with open(os.path.join(base_dir, 'data', 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })
    
    # Load parameters
    params = {}
    with open(os.path.join(base_dir, 'data', 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_daily_calories = params['min_daily_calories']
    max_daily_calories = params['max_daily_calories']
    max_daily_sodium = params['max_daily_sodium']
    
    max_units = int(total_weight_limit // 100)
    max_meal_units = 3  # 300g per meal / 100g per unit
    
    n_items = len(items)
    veg_indices = [i for i in range(n_items) if items[i]['type'] == 'Vegetable']
    
    # Create model
    model = gp.Model("meal_planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    purchase_units = model.addVars(n_items, vtype=GRB.INTEGER, lb=0, name="purchase")
    lunch_units = model.addVars(n_items, vtype=GRB.INTEGER, lb=0, name="lunch")
    dinner_units = model.addVars(n_items, vtype=GRB.INTEGER, lb=0, name="dinner")
    select_item = model.addVars(n_items, vtype=GRB.BINARY, name="select")
    lunch_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg")
    dinner_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg")
    
    # Objective: maximize total protein from lunch and dinner
    model.setObjective(
        gp.quicksum(items[i]['protein'] * (lunch_units[i] + dinner_units[i]) for i in range(n_items)),
        GRB.MAXIMIZE
    )
    
    # Constraints
    # 1. Purchase linkage: purchase_units[i] >= lunch_units[i] + dinner_units[i]
    for i in range(n_items):
        model.addConstr(purchase_units[i] >= lunch_units[i] + dinner_units[i])
    
    # 2. Total daily budget
    model.addConstr(
        gp.quicksum(items[i]['cost'] * purchase_units[i] for i in range(n_items)) <= max_budget
    )
    
    # 3. Total daily weight limit
    model.addConstr(
        gp.quicksum(100 * purchase_units[i] for i in range(n_items)) <= total_weight_limit
    )
    
    # 4. Per-meal weight balance (exactly 300g each)
    model.addConstr(
        gp.quicksum(100 * lunch_units[i] for i in range(n_items)) == 300
    )
    model.addConstr(
        gp.quicksum(100 * dinner_units[i] for i in range(n_items)) == 300
    )
    
    # 5. Daily calorie intake bounds
    total_calories = gp.quicksum(items[i]['calories'] * (lunch_units[i] + dinner_units[i]) for i in range(n_items))
    model.addConstr(total_calories >= min_daily_calories)
    model.addConstr(total_calories <= max_daily_calories)
    
    # 6. Daily sodium intake bound
    total_sodium = gp.quicksum(items[i]['sodium'] * (lunch_units[i] + dinner_units[i]) for i in range(n_items))
    model.addConstr(total_sodium <= max_daily_sodium)
    
    # 7. Purchase selection linkage
    for i in range(n_items):
        model.addConstr(purchase_units[i] <= max_units * select_item[i])
        model.addConstr(lunch_units[i] <= max_meal_units * select_item[i])
        model.addConstr(dinner_units[i] <= max_meal_units * select_item[i])
    
    # 8. Vegetable selection linkage for each meal
    for i in veg_indices:
        model.addConstr(lunch_units[i] >= lunch_veg_selected[i])
        model.addConstr(lunch_units[i] <= max_meal_units * lunch_veg_selected[i])
        model.addConstr(dinner_units[i] >= dinner_veg_selected[i])
        model.addConstr(dinner_units[i] <= max_meal_units * dinner_veg_selected[i])
    
    # 9. Minimum vegetable types per meal
    model.addConstr(gp.quicksum(lunch_veg_selected[i] for i in veg_indices) >= min_veg_types)
    model.addConstr(gp.quicksum(dinner_veg_selected[i] for i in veg_indices) >= min_veg_types)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found")

if __name__ == "__main__":
    main()
