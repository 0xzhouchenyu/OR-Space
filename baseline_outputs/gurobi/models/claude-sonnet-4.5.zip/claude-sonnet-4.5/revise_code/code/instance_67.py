import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return [row for row in reader]

def load_demand():
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        month = row['Month']
        product = row['Product']
        units = int(row['Market_Demand_Units'])
        demand[(month, product)] = units
    return demand

def load_parameters():
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = float(row['Value'])
        params[name] = value
    return params

def main():
    demand_data = load_demand()
    params = load_parameters()
    
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']
    
    # Production costs
    prod_cost = {
        'Product_I': params['product_I_cost_jun_to_dec'],
        'Product_II': params['product_II_cost_jun_to_dec']
    }
    
    # Volume per unit
    volume = {
        'Product_I': params['product_I_volume'],
        'Product_II': params['product_II_volume']
    }
    
    # Machine hours per unit
    machine_hours = {
        'Product_I': params['product_I_machine_hours'],
        'Product_II': params['product_II_machine_hours']
    }
    
    # Power per unit (kWh)
    power_kwh = {
        'Product_I': params['product_I_power_kwh'],
        'Product_II': params['product_II_power_kwh']
    }
    
    # Capacities
    warehouse_cap = params['warehouse_capacity']
    machine_hours_cap = params['machine_hours_capacity_monthly']
    own_cost = params['own_warehouse_cost']
    
    # Electricity costs
    grid_cost = params['grid_electricity_cost']
    gen_cost = params['generator_electricity_cost']
    
    # Monthly grid quotas
    grid_quota = {
        'July': params['grid_quota_july'],
        'August': params['grid_quota_august'],
        'September': params['grid_quota_september'],
        'October': params['grid_quota_october'],
        'November': params['grid_quota_november'],
        'December': params['grid_quota_december']
    }
    
    # Monthly generator limits
    gen_max = {
        'July': params['generator_max_july'],
        'August': params['generator_max_august'],
        'September': params['generator_max_september'],
        'October': params['generator_max_october'],
        'November': params['generator_max_november'],
        'December': params['generator_max_december']
    }
    
    # Demand
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]
    
    # Create model
    model = gp.Model("Production_Planning_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Production quantities
    x = model.addVars(months, products, lb=0, vtype=GRB.CONTINUOUS, name="prod")
    
    # Inventory at end of month
    inv = model.addVars(months, products, lb=0, vtype=GRB.CONTINUOUS, name="inv")
    
    # Warehouse usage (cubic meters)
    wh_usage = model.addVars(months, lb=0, vtype=GRB.CONTINUOUS, name="wh_usage")
    
    # Electricity from grid (kWh)
    grid_elec = model.addVars(months, lb=0, vtype=GRB.CONTINUOUS, name="grid_elec")
    
    # Electricity from generator (kWh)
    gen_elec = model.addVars(months, lb=0, vtype=GRB.CONTINUOUS, name="gen_elec")
    
    # Objective: minimize production cost + warehouse cost + electricity cost
    obj = gp.quicksum(prod_cost[p] * x[m, p] for m in months for p in products)
    obj += gp.quicksum(own_cost * wh_usage[m] for m in months)
    obj += gp.quicksum(grid_cost * grid_elec[m] + gen_cost * gen_elec[m] for m in months)
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    for i, m in enumerate(months):
        # Inventory balance
        for p in products:
            if i == 0:
                model.addConstr(inv[m, p] == 0 + x[m, p] - demand[(m, p)], name=f"inv_balance_{m}_{p}")
            else:
                prev_m = months[i - 1]
                model.addConstr(inv[m, p] == inv[prev_m, p] + x[m, p] - demand[(m, p)], name=f"inv_balance_{m}_{p}")
        
        # Machine hours capacity
        model.addConstr(
            gp.quicksum(machine_hours[p] * x[m, p] for p in products) <= machine_hours_cap,
            name=f"machine_cap_{m}"
        )
        
        # Warehouse capacity
        total_vol = gp.quicksum(volume[p] * inv[m, p] for p in products)
        model.addConstr(wh_usage[m] >= total_vol, name=f"wh_usage_{m}")
        model.addConstr(wh_usage[m] <= warehouse_cap, name=f"wh_cap_{m}")
        
        # Electricity requirement
        total_power = gp.quicksum(power_kwh[p] * x[m, p] for p in products)
        model.addConstr(
            grid_elec[m] + gen_elec[m] >= total_power,
            name=f"power_balance_{m}"
        )
        
        # Grid quota
        model.addConstr(grid_elec[m] <= grid_quota[m], name=f"grid_quota_{m}")
        
        # Generator limit
        model.addConstr(gen_elec[m] <= gen_max[m], name=f"gen_limit_{m}")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
    else:
        print(f"FINAL_OBJ_VALUE: NO_SOLUTION")

if __name__ == "__main__":
    main()
