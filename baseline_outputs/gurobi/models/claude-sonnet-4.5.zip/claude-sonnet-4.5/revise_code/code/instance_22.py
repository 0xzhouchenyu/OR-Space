import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

t1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
t2 = pd.read_csv(os.path.join(data_dir, 'table_2.csv'))
t3 = pd.read_csv(os.path.join(data_dir, 'table_3.csv'))
gp_df = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))

# Merge product data
df = t1.merge(t2, on='Product').merge(t3, on='Product')

# Parse general parameters
def get_param(name):
    return float(gp_df[gp_df['Parameter_Name'] == name]['Value'].iloc[0])

prod_days = get_param('production_days')
a1_watch_threshold = get_param('a1_watch_threshold')
a1_deep_service_threshold = get_param('a1_deep_service_threshold')
maintenance_penalty_watch = get_param('maintenance_penalty_watch')
maintenance_penalty_deep = get_param('maintenance_penalty_deep')
a1_quality_release_fee = get_param('a1_quality_release_fee')
a1_deep_service_fee = get_param('a1_deep_service_fee')
a1_priority_price_lift = get_param('a1_priority_price_lift')

# Create model
model = gp.Model("Production_Planning_Revised")
model.setParam('OutputFlag', 0)

# Variables
products = df['Product'].tolist()
x = {}
y = {}
for p in products:
    x[p] = model.addVar(lb=0, name=f"x_{p}")
    y[p] = model.addVar(vtype=GRB.BINARY, name=f"y_{p}")

# A1-specific variables for threshold crossing
z_watch = model.addVar(vtype=GRB.BINARY, name="z_watch")  # 1 if A1 > a1_watch_threshold
z_deep = model.addVar(vtype=GRB.BINARY, name="z_deep")    # 1 if A1 > a1_deep_service_threshold
x_A1_above_watch = model.addVar(lb=0, name="x_A1_above_watch")  # A1 units above watch threshold

model.update()

# Objective
base_profit = gp.quicksum([
    (row['Selling_Price'] - row['Production_Cost']) * x[row['Product']] - row['Activation_Cost'] * y[row['Product']] 
    for _, row in df.iterrows()
])

# Priority price lift for A1 units above watch threshold
priority_revenue = a1_priority_price_lift * x_A1_above_watch

# Fees when crossing thresholds
quality_release_cost = a1_quality_release_fee * z_watch
deep_service_cost = a1_deep_service_fee * z_deep

total_profit = base_profit + priority_revenue - quality_release_cost - deep_service_cost

model.setObjective(total_profit, GRB.MAXIMIZE)

# Constraints
# The company plans to produce all three types of products
for p in products:
    model.addConstr(y[p] == 1, name=f"produce_{p}")

# Demand and minimum batch constraints
for _, row in df.iterrows():
    p = row['Product']
    model.addConstr(x[p] <= row['Maximum_Demand'] * y[p], name=f"max_demand_{p}")
    model.addConstr(x[p] >= row['Minimum_Batch'] * y[p], name=f"min_batch_{p}")

# A1 threshold logic
M = 10000  # Big-M value

# z_watch = 1 if x['A1'] > a1_watch_threshold
model.addConstr(x['A1'] <= a1_watch_threshold + M * z_watch, name="watch_upper")
model.addConstr(x['A1'] >= a1_watch_threshold + 0.01 - M * (1 - z_watch), name="watch_lower")

# z_deep = 1 if x['A1'] > a1_deep_service_threshold
model.addConstr(x['A1'] <= a1_deep_service_threshold + M * z_deep, name="deep_upper")
model.addConstr(x['A1'] >= a1_deep_service_threshold + 0.01 - M * (1 - z_deep), name="deep_lower")

# x_A1_above_watch = max(0, x['A1'] - a1_watch_threshold) when z_watch = 1, else 0
model.addConstr(x_A1_above_watch <= x['A1'] - a1_watch_threshold, name="above_watch_def1")
model.addConstr(x_A1_above_watch <= M * z_watch, name="above_watch_def2")
model.addConstr(x_A1_above_watch >= x['A1'] - a1_watch_threshold - M * (1 - z_watch), name="above_watch_def3")

# z_deep implies z_watch (if deep threshold crossed, watch threshold is also crossed)
model.addConstr(z_deep <= z_watch, name="deep_implies_watch")

# Production days constraint with penalties
available_days = prod_days - maintenance_penalty_watch * z_watch - maintenance_penalty_deep * z_deep
production_time = gp.quicksum([x[row['Product']] / row['Production_Quota'] for _, row in df.iterrows()])
model.addConstr(production_time <= available_days, name="production_days")

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {round(model.objVal, 4)}")
else:
    print(f"FINAL_OBJ_VALUE: No optimal solution found")
