import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_general_parameters(filepath):
    params = {}
    with open(filepath, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row["Parameter_Name"].strip()
            val = row["Value"].strip()
            try:
                if "." in val:
                    params[key] = float(val)
                else:
                    params[key] = int(val)
            except ValueError:
                params[key] = val
    return params


def load_coverage_data(filepath):
    areas = []
    coverage = {}
    with open(filepath, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if not row or not row[0].strip():
                continue
            area = row[0].strip()
            covered_raw = ",".join(row[1:])
            covered = [x.strip() for x in covered_raw.split(",") if x.strip()]
            areas.append(area)
            coverage[area] = covered
    return areas, coverage


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    areas, coverage = load_coverage_data(os.path.join(data_dir, "table_1.csv"))

    small_cost = params["small_cost"]
    large_cost = params["large_cost"]
    small_cap = params["small_cap_areas"]
    max_large = params["max_large_stores"]
    min_counters = params["minimum_neighborhood_counters"]
    counter_credit = params["small_store_counter_credit"]

    model = gp.Model("revised_store_location")
    model.setParam("OutputFlag", 0)

    # Decision variables
    small = {j: model.addVar(vtype=GRB.BINARY, name=f"small_{j}") for j in areas}
    large = {j: model.addVar(vtype=GRB.BINARY, name=f"large_{j}") for j in areas}

    # Small-store assignment variables: directional, only if i is in j's physical coverage list
    y = {}
    for j in areas:
        for i in coverage[j]:
            y[(j, i)] = model.addVar(vtype=GRB.BINARY, name=f"assign_{j}_{i}")

    model.update()

    # At most one store type per area
    for j in areas:
        model.addConstr(small[j] + large[j] <= 1, name=f"one_type_{j}")

    # Small-store capacity and activation
    for j in areas:
        assign_vars = [y[(j, i)] for i in coverage[j]]
        if assign_vars:
            model.addConstr(gp.quicksum(assign_vars) <= small_cap * small[j], name=f"small_cap_{j}")
            for i in coverage[j]:
                model.addConstr(y[(j, i)] <= small[j], name=f"small_open_link_{j}_{i}")
        else:
            model.addConstr(small[j] == 0, name=f"no_small_{j}")

    # Coverage constraints:
    # each area must be covered by either
    # - a large store whose physical coverage includes it, or
    # - a small store explicitly assigned to serve it
    for i in areas:
        large_coverers = [large[j] for j in areas if i in coverage[j]]
        small_coverers = [y[(j, i)] for j in areas if (j, i) in y]
        model.addConstr(
            gp.quicksum(large_coverers) + gp.quicksum(small_coverers) >= 1,
            name=f"cover_{i}"
        )

    # Maximum number of large stores
    model.addConstr(gp.quicksum(large[j] for j in areas) <= max_large, name="max_large_stores")

    # Minimum neighborhood counters: only small stores count
    model.addConstr(
        gp.quicksum(counter_credit * small[j] for j in areas) >= min_counters,
        name="min_counters"
    )

    # Objective: minimize total cost
    model.setObjective(
        gp.quicksum(small_cost * small[j] + large_cost * large[j] for j in areas),
        GRB.MINIMIZE
    )

    model.optimize()

    obj = model.ObjVal
    if abs(obj - round(obj)) < 1e-9:
        obj_str = str(int(round(obj)))
    else:
        obj_str = str(obj)

    print(f"FINAL_OBJ_VALUE: {obj_str}")


if __name__ == "__main__":
    main()
