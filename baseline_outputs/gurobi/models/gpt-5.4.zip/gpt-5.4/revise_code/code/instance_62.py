import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_general_parameters(filepath):
    params = {}
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def load_restaurant_data(filepath):
    restaurants = []
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                "name": row["Restaurant"].strip(),
                "revenue": float(row["Annual_Revenue"].strip()),
                "cost": float(row["Cost"].strip()),
                "standard_staff_hours": float(row["Standard_Staff_Hours"].strip()),
                "premium_staff_hours": float(row["Premium_Staff_Hours"].strip()),
            })
    return restaurants


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    restaurants = load_restaurant_data(os.path.join(data_dir, "table_1.csv"))

    budget = params["investment_budget"]
    premium_revenue_uplift = params["premium_revenue_uplift"]
    premium_upgrade_cost = params["premium_upgrade_cost"]
    staff_hours_cap = params["staff_hours_cap"]

    model = gp.Model("restaurant_investment_revised")
    model.setParam("OutputFlag", 0)

    buy = {}
    premium = {}

    for r in restaurants:
        name = r["name"]
        buy[name] = model.addVar(vtype=GRB.BINARY, name=f"buy_{name}")
        premium[name] = model.addVar(vtype=GRB.BINARY, name=f"premium_{name}")

    model.update()

    # Premium mode only if restaurant is acquired
    for r in restaurants:
        name = r["name"]
        model.addConstr(premium[name] <= buy[name], name=f"premium_only_if_bought_{name}")

    # Budget covers acquisition plus premium upgrade costs
    model.addConstr(
        gp.quicksum(r["cost"] * buy[r["name"]] + premium_upgrade_cost * premium[r["name"]] for r in restaurants) <= budget,
        name="budget"
    )

    # Total staffing for acquired restaurants, depending on operating mode
    model.addConstr(
        gp.quicksum(
            r["standard_staff_hours"] * buy[r["name"]] +
            (r["premium_staff_hours"] - r["standard_staff_hours"]) * premium[r["name"]]
            for r in restaurants
        ) <= staff_hours_cap,
        name="staff_hours_cap"
    )

    # If Restaurant D is purchased, Restaurant A cannot be purchased
    names = {r["name"] for r in restaurants}
    if "Restaurant_D" in names and "Restaurant_A" in names:
        model.addConstr(buy["Restaurant_D"] + buy["Restaurant_A"] <= 1, name="D_A_exclusion")

    # Objective: maximize annual revenue with premium uplift if premium mode chosen
    model.setObjective(
        gp.quicksum(
            r["revenue"] * buy[r["name"]] +
            r["revenue"] * premium_revenue_uplift * premium[r["name"]]
            for r in restaurants
        ),
        GRB.MAXIMIZE
    )

    model.optimize()

    obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
