import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_processing_times(filepath):
    processing_times = []
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        machine_cols = [c for c in reader.fieldnames if c != "Product"]
        for row in reader:
            processing_times.append([float(row[c]) for c in machine_cols])
    return processing_times


def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"]
            val = row["Value"].strip()
            if val != "":
                params[name] = float(val)
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    processing_times = load_processing_times(os.path.join(data_dir, "table_1.csv"))
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

    n_jobs = len(processing_times)
    n_machines = len(processing_times[0])

    time_window = [
        params["time_window_1"],
        params["time_window_2"],
        params["time_window_3"],
    ]
    overtime_window = [
        params["overtime_window_1"],
        params["overtime_window_2"],
        params["overtime_window_3"],
    ]
    big_m = [
        params["M_1"],
        params["M_2"],
        params["M_3"],
    ]
    overtime_penalty = params["overtime_penalty_per_unit"]
    review_threshold = params["machine1_overtime_review_threshold"]
    review_fee = params["machine1_overtime_review_fee"]

    jobs = range(n_jobs)
    machines = range(n_machines)

    model = gp.Model("revised_flowshop_overtime")
    model.setParam("OutputFlag", 0)

    # Completion times
    C = model.addVars(jobs, machines, lb=0.0, vtype=GRB.CONTINUOUS, name="C")

    # Shared sequence order across all machines
    y = {}
    for i in jobs:
        for k in jobs:
            if i < k:
                y[i, k] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{k}")

    # Machine overtime usage
    overtime = model.addVars(machines, lb=0.0, vtype=GRB.CONTINUOUS, name="overtime")

    # Makespan
    makespan = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="makespan")

    # Machine 1 review trigger if overtime exceeds threshold
    review_trigger = model.addVar(vtype=GRB.BINARY, name="review_trigger_m1")

    model.update()

    # Flow constraints within each job
    for i in jobs:
        model.addConstr(C[i, 0] >= processing_times[i][0], name=f"first_machine_{i}")
        for j in range(1, n_machines):
            model.addConstr(
                C[i, j] >= C[i, j - 1] + processing_times[i][j],
                name=f"flow_{i}_{j}"
            )

    # Same sequence on all machines via pairwise disjunctive constraints
    for i in jobs:
        for k in jobs:
            if i < k:
                for j in machines:
                    p_kj = processing_times[k][j]
                    p_ij = processing_times[i][j]
                    Mj = big_m[j]

                    # if y[i,k] = 1, i precedes k
                    model.addConstr(
                        C[k, j] >= C[i, j] + p_kj - Mj * (1 - y[i, k]),
                        name=f"seq1_{i}_{k}_{j}"
                    )
                    # if y[i,k] = 0, k precedes i
                    model.addConstr(
                        C[i, j] >= C[k, j] + p_ij - Mj * y[i, k],
                        name=f"seq2_{i}_{k}_{j}"
                    )

    # Makespan
    for i in jobs:
        model.addConstr(makespan >= C[i, n_machines - 1], name=f"mk_{i}")

    # Overtime per machine based on latest completion on each machine
    for j in machines:
        latest_j = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"latest_{j}")
        for i in jobs:
            model.addConstr(latest_j >= C[i, j], name=f"latest_lb_{i}_{j}")
        model.addConstr(
            overtime[j] >= latest_j - time_window[j],
            name=f"ot_def_{j}"
        )
        model.addConstr(
            overtime[j] <= overtime_window[j],
            name=f"ot_cap_{j}"
        )

    # Machine 1 special review fee:
    # first 1 second covered; if overtime > 1, incur one-time fee 1.2
    max_ot1 = overtime_window[0]
    model.addConstr(
        overtime[0] <= review_threshold + (max_ot1 - review_threshold) * review_trigger,
        name="review_trigger_upper"
    )
    model.addConstr(
        overtime[0] >= review_threshold * review_trigger,
        name="review_trigger_lower"
    )

    # Objective: minimize total processing cycle + overtime penalties + machine1 review fee
    model.setObjective(
        makespan
        + overtime_penalty * gp.quicksum(overtime[j] for j in machines)
        + review_fee * review_trigger,
        GRB.MINIMIZE
    )

    model.optimize()

    obj_val = model.ObjVal
    if abs(obj_val - round(obj_val)) < 1e-9:
        obj_str = str(int(round(obj_val)))
    else:
        obj_str = str(obj_val)

    print(f"FINAL_OBJ_VALUE: {obj_str}")


if __name__ == "__main__":
    main()
