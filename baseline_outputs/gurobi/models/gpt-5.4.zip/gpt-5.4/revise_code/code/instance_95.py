import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(data_dir):
    params = {}
    filepath = os.path.join(data_dir, "general_parameters.csv")
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"])
    return params

def load_table_1(data_dir):
    weeks = []
    filepath = os.path.join(data_dir, "table_1.csv")
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["Week"].strip().lower() == "total":
                continue
            weeks.append({
                "week": int(row["Week"]),
                "demand": float(row["Demand_1000_boxes"]),
                "capacity": float(row["Production_Capacity_1000_boxes"]),
                "cost": float(row["Cost_per_1000_boxes_1000_yuan"]),
            })
    return weeks

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = load_general_parameters(data_dir)
    weeks = load_table_1(data_dir)

    n = len(weeks)
    storage_cost = params["storage_cost_per_thousand_boxes"]
    fixed_setup_cost = params["fixed_setup_cost"]
    week2_push_threshold = params["week2_push_threshold"]
    week3_capacity_loss_after_week2_push = params["week3_capacity_loss_after_week2_push"]
    week2_microclean_threshold = params["week2_microclean_threshold"]
    week2_microclean_fee = params["week2_microclean_fee"]

    m = gp.Model("revised_beverage_production")
    m.setParam("OutputFlag", 0)

    x = {}
    s = {}
    y = {}

    for t in range(n):
        cap = weeks[t]["capacity"]
        x[t] = m.addVar(lb=0.0, ub=cap, vtype=GRB.CONTINUOUS, name=f"x_{t+1}")
        s[t] = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"s_{t+1}")
        y[t] = m.addVar(vtype=GRB.BINARY, name=f"y_{t+1}")

    push2 = m.addVar(vtype=GRB.BINARY, name="push2")
    microclean2 = m.addVar(vtype=GRB.BINARY, name="microclean2")

    for t in range(n):
        cap = weeks[t]["capacity"]
        m.addConstr(x[t] <= cap * y[t], name=f"setup_link_{t+1}")

    for t in range(n):
        demand = weeks[t]["demand"]
        if t == 0:
            m.addConstr(x[t] - s[t] == demand, name=f"balance_{t+1}")
        else:
            m.addConstr(s[t-1] + x[t] - s[t] == demand, name=f"balance_{t+1}")

    # Week 2 push threshold logic:
    # if x2 > threshold then push2 = 1, and week 3 capacity is reduced
    # Implement with:
    # x2 <= threshold + (cap2 - threshold) * push2
    cap2 = weeks[1]["capacity"]
    m.addConstr(
        x[1] <= week2_push_threshold + (cap2 - week2_push_threshold) * push2,
        name="week2_push_trigger"
    )

    # Week 3 effective capacity
    cap3 = weeks[2]["capacity"]
    m.addConstr(
        x[2] <= cap3 - week3_capacity_loss_after_week2_push * push2,
        name="week3_reduced_capacity"
    )

    # Week 2 micro-clean trigger:
    # if x2 > threshold then microclean2 = 1
    m.addConstr(
        x[1] <= week2_microclean_threshold + (cap2 - week2_microclean_threshold) * microclean2,
        name="week2_microclean_trigger"
    )

    obj = gp.quicksum(weeks[t]["cost"] * x[t] for t in range(n))
    obj += gp.quicksum(storage_cost * s[t] for t in range(n))
    obj += gp.quicksum(fixed_setup_cost * y[t] for t in range(n))
    obj += week2_microclean_fee * microclean2

    m.setObjective(obj, GRB.MINIMIZE)
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == "__main__":
    main()
