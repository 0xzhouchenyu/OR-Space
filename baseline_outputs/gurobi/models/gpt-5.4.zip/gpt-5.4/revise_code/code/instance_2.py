import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    return params


base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")
params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

a1 = params["a1"]
a2 = params["a2"]
training_capacity_per_jet = params["training_capacity_per_jet"]
dual_use_eff = params["dual_use_training_efficiency"]
training_intensity_cap = params["training_intensity_cap"]
combat_jet_min_year2 = params["combat_jet_min_year2"]
combat_weight = params["combat_weight"]
training_weight = params["training_weight"]

m = gp.Model("revised_fighter_jet_planning")
m.setParam("OutputFlag", 0)

# Decision variables by year and posture
# t_y: training-only jets
# d_y: dual-use jets
# c_y: combat-only jets
t1 = m.addVar(lb=0.0, name="training_only_year1")
d1 = m.addVar(lb=0.0, name="dual_use_year1")
c1 = m.addVar(lb=0.0, name="combat_only_year1")

t2 = m.addVar(lb=0.0, name="training_only_year2")
d2 = m.addVar(lb=0.0, name="dual_use_year2")
c2 = m.addVar(lb=0.0, name="combat_only_year2")

# Effective pilots trained over the two years
trained_pilots = m.addVar(lb=0.0, name="trained_pilots")

# Fleet availability by year
m.addConstr(t1 + d1 + c1 == a1, name="fleet_balance_year1")
m.addConstr(t2 + d2 + c2 == a1 + a2, name="fleet_balance_year2")

# Training intensity cap applies to jets in training-only or dual-use modes
m.addConstr(t1 + d1 <= training_intensity_cap * a1, name="training_intensity_year1")
m.addConstr(t2 + d2 <= training_intensity_cap * (a1 + a2), name="training_intensity_year2")

# Year-2 minimum combat availability; dual-use contributes to combat availability
m.addConstr(c2 + d2 >= combat_jet_min_year2, name="combat_min_year2")

# Training production over both years; dual-use training is discounted
m.addConstr(
    trained_pilots
    == training_capacity_per_jet * (t1 + dual_use_eff * d1 + t2 + dual_use_eff * d2),
    name="trained_pilots_definition",
)

# Objective: weighted trained pilots + weighted year-2 combat jets
m.setObjective(
    training_weight * trained_pilots + combat_weight * (c2 + d2),
    GRB.MAXIMIZE,
)

m.optimize()

print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
