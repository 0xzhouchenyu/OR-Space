import os
import csv
import gurobipy as gp
from gurobipy import GRB


def read_general_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"]
            value = row["Value"]
            if value not in (None, "", "None"):
                try:
                    if "." in value or "e" in value.lower():
                        params[name] = float(value)
                    else:
                        params[name] = int(value)
                except Exception:
                    params[name] = value
            else:
                params[name] = None
    return params


def read_table(path):
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    return rows


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = read_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    rows = read_table(os.path.join(data_dir, "table_1.csv"))

    n = int(params["n"])
    premium_multiplier = float(params["premium_cost_multiplier"])
    min_premium_share = float(params["min_premium_share"])

    d = []
    c = []
    for row in rows:
        d_row = [float(row[f"Transportation_volume_to_Location_{j+1}"]) for j in range(n)]
        c_row = [float(row[f"Transportation_cost_to_Location_{j+1}"]) for j in range(n)]
        d.append(d_row)
        c.append(c_row)

    outbound = [sum(d[i][j] for j in range(n)) for i in range(n)]

    c_std = [[0.0 for _ in range(n)] for _ in range(n)]
    c_prem = [[0.0 for _ in range(n)] for _ in range(n)]

    for i in range(n):
        for p in range(n):
            if outbound[i] > 0:
                base_unit_cost = sum(d[i][j] * c[p][j] for j in range(n)) / outbound[i]
            else:
                base_unit_cost = 0.0
            c_std[i][p] = base_unit_cost
            c_prem[i][p] = premium_multiplier * base_unit_cost

    m = gp.Model("revised_factory_location_assignment")
    m.setParam("OutputFlag", 0)

    x = m.addVars(n, n, vtype=GRB.BINARY, name="x")
    y = m.addVars(n, n, vtype=GRB.BINARY, name="y")
    v_std = m.addVars(n, n, lb=0.0, vtype=GRB.CONTINUOUS, name="v_std")
    v_prem = m.addVars(n, n, lb=0.0, vtype=GRB.CONTINUOUS, name="v_prem")

    # Each factory assigned to exactly one location
    for i in range(n):
        m.addConstr(gp.quicksum(x[i, p] for p in range(n)) == 1, name=f"assign_factory_{i}")

    # Each location hosts at most one factory
    for p in range(n):
        m.addConstr(gp.quicksum(x[i, p] for i in range(n)) <= 1, name=f"capacity_location_{p}")

    # Premium can only be selected at assigned location
    for i in range(n):
        for p in range(n):
            m.addConstr(y[i, p] <= x[i, p], name=f"premium_only_if_assigned_{i}_{p}")

    # Volume split only at assigned location and equals outbound volume
    for i in range(n):
        M_i = outbound[i]
        for p in range(n):
            m.addConstr(v_std[i, p] + v_prem[i, p] == M_i * x[i, p], name=f"flow_balance_{i}_{p}")
            m.addConstr(v_prem[i, p] <= M_i * y[i, p], name=f"prem_upper_{i}_{p}")
            m.addConstr(v_prem[i, p] >= min_premium_share * M_i * y[i, p], name=f"prem_lower_{i}_{p}")
            m.addConstr(v_std[i, p] <= M_i * x[i, p], name=f"std_upper_{i}_{p}")

    obj = gp.quicksum(
        c_std[i][p] * v_std[i, p] + c_prem[i][p] * v_prem[i, p]
        for i in range(n) for p in range(n)
    )

    m.setObjective(obj, GRB.MINIMIZE)
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")


if __name__ == "__main__":
    main()
