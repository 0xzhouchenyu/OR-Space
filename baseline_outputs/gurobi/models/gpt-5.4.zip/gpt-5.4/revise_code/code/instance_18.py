import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def main():
    params = load_parameters()

    fabric_production_rate = params["fabric_production_rate"]
    min_curtain_fabric_sales = params["min_curtain_fabric_sales"]
    min_clothing_fabric_sales = params["min_clothing_fabric_sales"]

    day_shift_regular_capacity = params["day_shift_regular_capacity"]
    night_shift_regular_capacity = params["night_shift_regular_capacity"]
    day_overtime_limit = params["day_overtime_limit"]
    night_overtime_limit = params["night_overtime_limit"]
    day_overtime_penalty = params["day_overtime_penalty"]
    night_overtime_penalty = params["night_overtime_penalty"]
    day_min_utilization_ratio = params["day_min_utilization_ratio"]
    night_min_utilization_ratio = params["night_min_utilization_ratio"]

    min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
    min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

    model = gp.Model("textile_factory_revised")
    model.setParam("OutputFlag", 0)

    day_regular = model.addVar(lb=0.0, ub=day_shift_regular_capacity, vtype=GRB.CONTINUOUS, name="day_regular")
    night_regular = model.addVar(lb=0.0, ub=night_shift_regular_capacity, vtype=GRB.CONTINUOUS, name="night_regular")
    day_overtime = model.addVar(lb=0.0, ub=day_overtime_limit, vtype=GRB.CONTINUOUS, name="day_overtime")
    night_overtime = model.addVar(lb=0.0, ub=night_overtime_limit, vtype=GRB.CONTINUOUS, name="night_overtime")

    clothing_hours = model.addVar(lb=min_clothing_hours, vtype=GRB.CONTINUOUS, name="clothing_hours")
    curtain_hours = model.addVar(lb=min_curtain_hours, vtype=GRB.CONTINUOUS, name="curtain_hours")

    total_regular = day_regular + night_regular
    total_production = clothing_hours + curtain_hours

    model.addConstr(
        total_production == total_regular + day_overtime + night_overtime,
        name="production_balance"
    )

    model.addConstr(
        day_regular >= day_min_utilization_ratio * total_regular,
        name="day_min_utilization"
    )
    model.addConstr(
        night_regular >= night_min_utilization_ratio * total_regular,
        name="night_min_utilization"
    )

    model.setObjective(
        day_overtime_penalty * day_overtime + night_overtime_penalty * night_overtime,
        GRB.MINIMIZE
    )

    model.optimize()

    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
