import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        val = row["Value"].strip()
        if val == "":
            params[name] = row["Context_Description"].strip()
        else:
            try:
                if "." in val:
                    params[name] = float(val)
                else:
                    params[name] = int(val)
            except ValueError:
                params[name] = val

# Read items
items = []
values = []
with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        items.append(row["Item"].strip())
        values.append(float(row["Value"].strip()))

n = len(items)
total_value = sum(values)

# Parameters
son1_min_share = float(params["son1_min_share"])
high_value_threshold = float(params["high_value_threshold"])
max_high_value_items_per_son = int(params["max_high_value_items_per_son"])
deferred_diamonds_per_son = int(params["deferred_diamonds_per_son"])
immediate_tax_weight = float(params["immediate_tax_weight"])
total_tax_weight = float(params["total_tax_weight"])

diamond_idx = [i for i, name in enumerate(items) if "Diamond" in name]
jr_idx = [i for i, name in enumerate(items) if "Jack Russell" in name]
high_value_idx = [i for i, v in enumerate(values) if v > high_value_threshold]

# Model
m = gp.Model("revised_inheritance_split")
m.setParam("OutputFlag", 0)

# Decision variables
# owner[i] = 1 if item i ultimately belongs to son 1, else son 2
owner = m.addVars(n, vtype=GRB.BINARY, name="owner")

# immediate[i] = 1 if item i is transferred immediately, 0 if deferred
immediate = m.addVars(n, vtype=GRB.BINARY, name="immediate")

# For diamonds, deferred assignment indicators by son
deferred_s1 = m.addVars(diamond_idx, vtype=GRB.BINARY, name="deferred_s1")
deferred_s2 = m.addVars(diamond_idx, vtype=GRB.BINARY, name="deferred_s2")

# Expressions
total_son1 = gp.quicksum(values[i] * owner[i] for i in range(n))
total_son2 = total_value - total_son1

immediate_son1 = gp.quicksum(values[i] * owner[i] * immediate[i] for i in range(n))
immediate_son2 = gp.quicksum(values[i] * (1 - owner[i]) * immediate[i] for i in range(n))

# Linearize immediate owner conjunctions
z = m.addVars(n, vtype=GRB.BINARY, name="z")  # z[i] = owner[i] AND immediate[i]
for i in range(n):
    m.addConstr(z[i] <= owner[i])
    m.addConstr(z[i] <= immediate[i])
    m.addConstr(z[i] >= owner[i] + immediate[i] - 1)

immediate_son1 = gp.quicksum(values[i] * z[i] for i in range(n))
immediate_son2 = gp.quicksum(values[i] * (immediate[i] - z[i]) for i in range(n))

# Absolute difference variables
diff_total = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="diff_total")
diff_immediate = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="diff_immediate")

# Fairness constraints
m.addConstr(diff_total >= total_son1 - total_son2)
m.addConstr(diff_total >= total_son2 - total_son1)

m.addConstr(diff_immediate >= immediate_son1 - immediate_son2)
m.addConstr(diff_immediate >= immediate_son2 - immediate_son1)

# Son 1 minimum total ownership share
m.addConstr(total_son1 >= son1_min_share * total_value)

# Jack Russell dogs must not be separated (ultimate ownership)
if len(jr_idx) == 2:
    m.addConstr(owner[jr_idx[0]] == owner[jr_idx[1]])

# High-value concentration limits on total ownership
m.addConstr(gp.quicksum(owner[i] for i in high_value_idx) <= max_high_value_items_per_son)
m.addConstr(gp.quicksum(1 - owner[i] for i in high_value_idx) <= max_high_value_items_per_son)

# Deferred diamonds limited per son
for i in diamond_idx:
    m.addConstr(deferred_s1[i] <= owner[i])
    m.addConstr(deferred_s1[i] <= 1 - immediate[i])
    m.addConstr(deferred_s1[i] >= owner[i] - immediate[i])

    m.addConstr(deferred_s2[i] <= 1 - owner[i])
    m.addConstr(deferred_s2[i] <= 1 - immediate[i])
    m.addConstr(deferred_s2[i] >= (1 - owner[i]) - immediate[i])

m.addConstr(gp.quicksum(deferred_s1[i] for i in diamond_idx) <= deferred_diamonds_per_son)
m.addConstr(gp.quicksum(deferred_s2[i] for i in diamond_idx) <= deferred_diamonds_per_son)

# Objective
m.setObjective(immediate_tax_weight * diff_immediate + total_tax_weight * diff_total, GRB.MINIMIZE)

# Solve
m.optimize()

obj = m.ObjVal
if abs(obj - round(obj)) < 1e-9:
    obj_str = str(int(round(obj)))
else:
    obj_str = f"{obj:.10f}".rstrip("0").rstrip(".")

print(f"FINAL_OBJ_VALUE: {obj_str}")
