import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

min_A_I = params["min_proportion_crude_A_type_I"] / 100.0
min_A_II = params["min_proportion_crude_A_type_II"] / 100.0
price_I = params["selling_price_type_I"]
price_II = params["selling_price_type_II"]
inv_A = params["inventory_crude_A"]
inv_B = params["inventory_crude_B"]
max_purchase_A = params["max_purchase_crude_A"]
cost_t1 = params["market_price_crude_A_tier_1"]
cost_t2 = params["market_price_crude_A_tier_2"]
cost_t3 = params["market_price_crude_A_tier_3"]
processing_capacity = params["processing_capacity"]
min_total_output = params["min_total_gasoline_output"]
processing_cost_per_ton = params["processing_cost_per_ton"]
type_II_contract_threshold = params["type_II_contract_threshold"]
type_II_price_lift = params["type_II_price_lift"]
bulk_purchase_rebate_threshold = params["bulk_purchase_rebate_threshold"]
bulk_purchase_rebate = params["bulk_purchase_rebate"]

m = gp.Model("revised_oil_blending")
m.setParam("OutputFlag", 0)

# Production / blending variables
a1 = m.addVar(lb=0.0, name="crude_A_in_type_I")
b1 = m.addVar(lb=0.0, name="crude_B_in_type_I")
a2 = m.addVar(lb=0.0, name="crude_A_in_type_II")
b2 = m.addVar(lb=0.0, name="crude_B_in_type_II")

# Purchase variables by staged block
p1 = m.addVar(lb=0.0, ub=500.0, name="purchase_tier_1")
p2 = m.addVar(lb=0.0, ub=500.0, name="purchase_tier_2")
p3 = m.addVar(lb=0.0, ub=500.0, name="purchase_tier_3")

# Binary variables to enforce sequential tier purchases
y1 = m.addVar(vtype=GRB.BINARY, name="tier1_full")
y2 = m.addVar(vtype=GRB.BINARY, name="tier2_full")

# Binary variables for commercial thresholds
z_type2 = m.addVar(vtype=GRB.BINARY, name="type2_uplift_active")
z_rebate = m.addVar(vtype=GRB.BINARY, name="bulk_rebate_active")

# Basic expressions
total_purchase = p1 + p2 + p3
output_I = a1 + b1
output_II = a2 + b2
total_output = output_I + output_II

# Tier ordering constraints
m.addConstr(p2 <= 500.0 * y1, name="tier2_only_if_tier1_full")
m.addConstr(p1 >= 500.0 * y1, name="tier1_full_if_tier2_used")
m.addConstr(p3 <= 500.0 * y2, name="tier3_only_if_tier2_full")
m.addConstr(p2 >= 500.0 * y2, name="tier2_full_if_tier3_used")

# Purchase cap
m.addConstr(total_purchase <= max_purchase_A, name="max_purchase_A")

# Supply constraints
m.addConstr(a1 + a2 <= inv_A + total_purchase, name="crude_A_supply")
m.addConstr(b1 + b2 <= inv_B, name="crude_B_supply")

# Quality constraints
m.addConstr(a1 >= min_A_I * (a1 + b1), name="type_I_A_share")
m.addConstr(a2 >= min_A_II * (a2 + b2), name="type_II_A_share")

# Throughput window
m.addConstr(total_output <= processing_capacity, name="processing_capacity")
m.addConstr(total_output >= min_total_output, name="min_total_output")

# Type II uplift threshold activation
m.addConstr(output_II >= type_II_contract_threshold * z_type2, name="type2_threshold_lb")
m.addConstr(output_II <= processing_capacity * z_type2 + type_II_contract_threshold * (1 - z_type2), name="type2_threshold_ub")

# Bulk purchase rebate threshold activation
m.addConstr(total_purchase >= bulk_purchase_rebate_threshold * z_rebate, name="rebate_threshold_lb")
m.addConstr(total_purchase <= bulk_purchase_rebate_threshold + (max_purchase_A - bulk_purchase_rebate_threshold) * z_rebate, name="rebate_threshold_ub")

# Objective
revenue = (
    price_I * output_I
    + price_II * output_II
    + type_II_price_lift * output_II * z_type2
)
# Linearize uplift term since z_type2 is binary and output_II is continuous:
uplift_volume = m.addVar(lb=0.0, ub=processing_capacity, name="uplift_volume")
m.addConstr(uplift_volume <= output_II, name="uplift_vol_le_outputII")
m.addConstr(uplift_volume <= processing_capacity * z_type2, name="uplift_vol_le_bin")
m.addConstr(uplift_volume >= output_II - processing_capacity * (1 - z_type2), name="uplift_vol_ge_link")
m.addConstr(uplift_volume >= 0.0, name="uplift_vol_nonneg")

revenue = price_I * output_I + price_II * output_II + type_II_price_lift * uplift_volume
purchase_cost = cost_t1 * p1 + cost_t2 * p2 + cost_t3 * p3
processing_cost = processing_cost_per_ton * total_output
rebate = bulk_purchase_rebate * z_rebate

m.setObjective(revenue - purchase_cost - processing_cost + rebate, GRB.MAXIMIZE)

m.optimize()

obj = m.ObjVal if m.status == GRB.OPTIMAL else float("nan")
print(f"FINAL_OBJ_VALUE: {obj}")
