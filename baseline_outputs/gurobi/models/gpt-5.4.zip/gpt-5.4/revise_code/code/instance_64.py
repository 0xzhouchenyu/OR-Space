import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_candidates(data_dir):
    candidates = []
    with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                "name": row["Candidate"].strip(),
                "salary": float(row["Salary"].strip()),
                "skill": float(row["Skill_Level"].strip()),
                "pm_exp": float(row["Project_Management_Experience"].strip()),
            })
    return candidates


def load_params(data_dir):
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    candidates = load_candidates(data_dir)
    params = load_params(data_dir)

    budget = params["company_budget"]
    max_employees = int(params["max_employees"])
    min_skill = params["min_skill_level"]
    min_pm_exp = params["min_project_experience"]
    max_gj = int(params["max_one_candidate_g_j"])
    lead_premium = params["lead_premium"]
    min_leads = int(params["min_leads"])
    mentor_bonus = params["mentor_bonus"]
    max_pairs = int(params["max_pairs"])

    cand_names = [c["name"] for c in candidates]
    salary = {c["name"]: c["salary"] for c in candidates}
    skill = {c["name"]: c["skill"] for c in candidates}
    pm_exp = {c["name"]: c["pm_exp"] for c in candidates}

    model = gp.Model("revised_hiring_optimization")
    model.setParam("OutputFlag", 0)

    hire = model.addVars(cand_names, vtype=GRB.BINARY, name="hire")
    lead = model.addVars(cand_names, vtype=GRB.BINARY, name="lead")
    engineer = model.addVars(cand_names, vtype=GRB.BINARY, name="engineer")
    pairs = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_pairs, name="pairs")

    for c in cand_names:
        model.addConstr(lead[c] + engineer[c] == hire[c], name=f"role_assign_{c}")
        model.addConstr(lead[c] <= hire[c], name=f"lead_if_hired_{c}")
        model.addConstr(engineer[c] <= hire[c], name=f"eng_if_hired_{c}")

    model.addConstr(gp.quicksum(salary[c] * hire[c] for c in cand_names) +
                    lead_premium * gp.quicksum(lead[c] for c in cand_names) -
                    mentor_bonus * pairs <= budget, name="budget")

    model.addConstr(gp.quicksum(hire[c] for c in cand_names) <= max_employees, name="max_employees")
    model.addConstr(gp.quicksum(skill[c] * hire[c] for c in cand_names) >= min_skill, name="min_skill")
    model.addConstr(gp.quicksum(pm_exp[c] * hire[c] for c in cand_names) >= min_pm_exp, name="min_pm_exp")
    model.addConstr(gp.quicksum(lead[c] for c in cand_names) >= min_leads, name="min_leads")

    if "G" in cand_names and "J" in cand_names:
        model.addConstr(hire["G"] + hire["J"] <= max_gj, name="max_one_g_j")

    model.addConstr(pairs <= gp.quicksum(lead[c] for c in cand_names), name="pairs_leads")
    model.addConstr(pairs <= gp.quicksum(engineer[c] for c in cand_names), name="pairs_engineers")
    model.addConstr(pairs <= max_pairs, name="pairs_cap")

    model.setObjective(
        gp.quicksum(salary[c] * hire[c] for c in cand_names)
        + lead_premium * gp.quicksum(lead[c] for c in cand_names)
        - mentor_bonus * pairs,
        GRB.MINIMIZE
    )

    model.optimize()

    obj_val = model.ObjVal
    if abs(obj_val - round(obj_val)) < 1e-6:
        obj_str = str(int(round(obj_val)))
    else:
        obj_str = str(obj_val)

    print(f"FINAL_OBJ_VALUE: {obj_str}")


if __name__ == "__main__":
    main()
