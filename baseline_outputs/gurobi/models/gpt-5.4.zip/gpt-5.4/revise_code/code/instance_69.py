import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def read_parameters():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(data_path)
    params = {}
    for _, row in df.iterrows():
        params[str(row["Parameter_Name"])] = row["Value"]
    return params

def generate_patterns(raw_length, piece_lengths):
    patterns = []
    max_counts = [raw_length // l for l in piece_lengths]

    for x3 in range(max_counts[0] + 1):
        for x4 in range(max_counts[1] + 1):
            for x5 in range(max_counts[2] + 1):
                counts = (x3, x4, x5)
                used = sum(counts[i] * piece_lengths[i] for i in range(3))
                if 0 < used <= raw_length:
                    patterns.append(counts)
    return patterns

def solve():
    params = read_parameters()

    q3 = int(float(params["batch_3m_quantity"]))
    q4 = int(float(params["batch_4m_quantity"]))
    q5 = int(float(params["batch_5m_quantity"]))
    L = int(float(params["raw_bar_length"]))
    setup_cost = float(params["setup_cost_per_pattern"])
    max_distinct_patterns = int(float(params["max_distinct_patterns"]))

    piece_lengths = [3, 4, 5]
    demands = [q3, q4, q5]

    patterns = generate_patterns(L, piece_lengths)
    n = len(patterns)

    model = gp.Model("revised_cutting_stock")
    model.setParam("OutputFlag", 0)

    x = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="x")
    y = model.addVars(n, vtype=GRB.BINARY, name="y")

    for i, pat in enumerate(patterns):
        model.addConstr(x[i] <= sum(demands) * y[i], name=f"link_{i}")

    for j in range(3):
        model.addConstr(
            gp.quicksum(patterns[i][j] * x[i] for i in range(n)) >= demands[j],
            name=f"demand_{j}"
        )

    model.addConstr(gp.quicksum(y[i] for i in range(n)) <= max_distinct_patterns, name="max_patterns")

    trim_waste = gp.quicksum(
        (L - sum(piece_lengths[j] * patterns[i][j] for j in range(3))) * x[i]
        for i in range(n)
    )
    overproduction_waste = gp.quicksum(
        piece_lengths[j] * (
            gp.quicksum(patterns[i][j] * x[i] for i in range(n)) - demands[j]
        )
        for j in range(3)
    )
    setup_waste = setup_cost * gp.quicksum(y[i] for i in range(n))

    model.setObjective(trim_waste + overproduction_waste + setup_waste, GRB.MINIMIZE)

    model.optimize()

    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    solve()
