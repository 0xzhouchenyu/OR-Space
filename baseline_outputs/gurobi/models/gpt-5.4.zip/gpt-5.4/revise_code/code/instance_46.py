import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    students = []
    with open(os.path.join(base, "table_1.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            s = {
                "Student_ID": int(row["Student_ID"]),
                "Wage_CNY_per_hour": float(row["Wage_CNY_per_hour"]),
            }
            for d in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]:
                s[d] = float(row[d])
            students.append(s)

    params = {}
    with open(os.path.join(base, "general_parameters.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"]
            val = row["Value"]
            try:
                if "." in val:
                    params[name] = float(val)
                else:
                    params[name] = int(val)
            except ValueError:
                try:
                    params[name] = float(val)
                except ValueError:
                    params[name] = val

    return students, params

def time_diff_hours(start_str, end_str):
    def parse_time(t):
        t = t.strip()
        hm, ampm = t.split()
        h, m = map(int, hm.split(":"))
        ampm = ampm.upper()
        if ampm == "AM":
            if h == 12:
                h = 0
        elif ampm == "PM":
            if h != 12:
                h += 12
        return h + m / 60.0

    start = parse_time(start_str)
    end = parse_time(end_str)
    return end - start

def main():
    students, params = load_data()

    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    student_ids = [s["Student_ID"] for s in students]
    grad_students = {5, 6}
    undergrad_students = {1, 2, 3, 4}

    hours_per_day = time_diff_hours(params["lab_opening_time"], params["lab_closing_time"])
    min_undergrad = float(params["min_undergrad_hours"])
    min_grad = float(params["min_grad_hours"])
    max_shifts = int(params["max_shifts_per_student"])
    max_students_day = int(params["max_students_per_day"])
    daily_open_fee = float(params["daily_open_fee_cny"])
    min_grad_weekly_coverage = float(params["min_grad_weekly_coverage_hours"])

    wage = {s["Student_ID"]: float(s["Wage_CNY_per_hour"]) for s in students}
    avail = {(s["Student_ID"], d): float(s[d]) for s in students for d in days}

    model = gp.Model("lab_scheduling_revised")
    model.setParam("OutputFlag", 0)

    x = model.addVars(student_ids, days, vtype=GRB.CONTINUOUS, lb=0.0, name="x")
    y = model.addVars(student_ids, days, vtype=GRB.BINARY, name="y")
    z = model.addVars(student_ids, days, vtype=GRB.BINARY, name="z")

    model.setObjective(
        gp.quicksum(wage[i] * x[i, d] + daily_open_fee * z[i, d] for i in student_ids for d in days),
        GRB.MINIMIZE
    )

    for d in days:
        model.addConstr(gp.quicksum(x[i, d] for i in student_ids) == hours_per_day, name=f"coverage_{d}")

    for i in student_ids:
        for d in days:
            model.addConstr(x[i, d] <= avail[i, d] * y[i, d], name=f"avail_link_{i}_{d}")
            model.addConstr(z[i, d] == y[i, d], name=f"z_eq_y_{i}_{d}")

    for i in student_ids:
        model.addConstr(gp.quicksum(y[i, d] for d in days) <= max_shifts, name=f"max_shifts_{i}")

    for d in days:
        model.addConstr(gp.quicksum(y[i, d] for i in student_ids) <= max_students_day, name=f"max_students_day_{d}")

    for i in undergrad_students:
        model.addConstr(gp.quicksum(x[i, d] for d in days) >= min_undergrad, name=f"min_undergrad_{i}")

    for i in grad_students:
        model.addConstr(gp.quicksum(x[i, d] for d in days) >= min_grad, name=f"min_grad_{i}")

    model.addConstr(
        gp.quicksum(x[i, d] for i in grad_students for d in days) >= min_grad_weekly_coverage,
        name="min_grad_weekly_coverage"
    )

    model.optimize()

    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
