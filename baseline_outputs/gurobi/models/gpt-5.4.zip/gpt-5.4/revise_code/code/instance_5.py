import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")

    df = pd.read_csv(table_path)
    params_df = pd.read_csv(params_path)

    params = {row["Parameter_Name"]: float(row["Value"]) for _, row in params_df.iterrows()}

    total_budget = params["budget"]
    food_intake = params["food_intake"] / 100.0  # in 100g units per dinner
    weekday_budget_share = params["weekday_budget_share"]
    max_prep_time_weekday = params["max_prep_time_weekday"]
    max_prep_time_weekend = params["max_prep_time_weekend"]
    weekend_protein_ban = int(params["weekend_protein_ban"])
    veg_balance_penalty = params["veg_balance_penalty"]

    foods = df["Food"].tolist()
    food_type = df.set_index("Food")["Type"].to_dict()
    fiber = df.set_index("Food")["Fiber_Content_per_100g"].fillna(0).to_dict()
    price = df.set_index("Food")["Price_per_100g"].to_dict()
    prep = df.set_index("Food")["prep_time_per_100g"].to_dict()

    proteins = [f for f in foods if food_type[f] == "protein"]
    vegetables = [f for f in foods if food_type[f] == "vegetable"]
    meals = ["weekday", "weekend"]

    m = gp.Model("revised_meal_planning")
    m.setParam("OutputFlag", 0)

    x = m.addVars(meals, foods, lb=0.0, vtype=GRB.CONTINUOUS, name="x")
    y = m.addVars(meals, foods, vtype=GRB.BINARY, name="y")
    z = m.addVars(proteins, vtype=GRB.BINARY, name="z")
    d = m.addVars(vegetables, lb=0.0, vtype=GRB.CONTINUOUS, name="dev")

    # Objective: maximize total fiber across both meals minus vegetable balance penalties
    m.setObjective(
        gp.quicksum(fiber[f] * x[meal, f] for meal in meals for f in foods)
        - gp.quicksum(veg_balance_penalty * d[v] for v in vegetables),
        GRB.MAXIMIZE
    )

    # Total intake per dinner
    for meal in meals:
        m.addConstr(gp.quicksum(x[meal, f] for f in foods) == food_intake, name=f"intake_{meal}")

    # Budget constraints
    weekday_budget = weekday_budget_share * total_budget
    weekend_budget = total_budget - weekday_budget

    m.addConstr(
        gp.quicksum(price[f] * x["weekday", f] for f in foods) <= weekday_budget,
        name="weekday_budget"
    )
    m.addConstr(
        gp.quicksum(price[f] * x["weekend", f] for f in foods) <= weekend_budget,
        name="weekend_budget"
    )
    m.addConstr(
        gp.quicksum(price[f] * x[meal, f] for meal in meals for f in foods) <= total_budget,
        name="total_budget"
    )

    # Prep time constraints
    m.addConstr(
        gp.quicksum(prep[f] * x["weekday", f] for f in foods) <= max_prep_time_weekday,
        name="prep_weekday"
    )
    m.addConstr(
        gp.quicksum(prep[f] * x["weekend", f] for f in foods) <= max_prep_time_weekend,
        name="prep_weekend"
    )

    # Original meal composition constraints applied to each dinner
    for meal in meals:
        m.addConstr(gp.quicksum(y[meal, p] for p in proteins) == 1, name=f"one_protein_{meal}")
        m.addConstr(gp.quicksum(y[meal, v] for v in vegetables) >= 2, name=f"two_veggies_{meal}")

    # Weekend protein ban
    if weekend_protein_ban == 1:
        for p in proteins:
            m.addConstr(y["weekend", p] == 0, name=f"weekend_ban_{p}")

    # Linking constraints
    M = food_intake
    min_inclusion = 0.1  # 10g in 100g units
    for meal in meals:
        for f in foods:
            m.addConstr(x[meal, f] >= min_inclusion * y[meal, f], name=f"link_lb_{meal}_{f}")
            m.addConstr(x[meal, f] <= M * y[meal, f], name=f"link_ub_{meal}_{f}")

    # Shared shopping logic for protein labels:
    # do not use a protein label unless it appears in at least one meal,
    # and if selected on paper it can support either/both meals
    for p in proteins:
        m.addConstr(y["weekday", p] <= z[p], name=f"paper_weekday_{p}")
        m.addConstr(y["weekend", p] <= z[p], name=f"paper_weekend_{p}")
        m.addConstr(z[p] <= y["weekday", p] + y["weekend", p], name=f"paper_use_{p}")

    # Vegetable balance penalty via absolute deviations between weekday and weekend vegetable amounts
    for v in vegetables:
        m.addConstr(d[v] >= x["weekday", v] - x["weekend", v], name=f"dev_pos_{v}")
        m.addConstr(d[v] >= x["weekend", v] - x["weekday", v], name=f"dev_neg_{v}")

    m.optimize()

    obj_val = m.ObjVal if m.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
