import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_toy_data(filepath):
    toys = []
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                "type": row["Toy_Type"].strip(),
                "profit": float(row["Profit_Per_Unit"]),
                "wood": float(row["Wood_Required_Per_Unit"]),
                "steel": float(row["Steel_Required_Per_Unit"]),
            })
    return toys


def load_general_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"])
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    toys = load_toy_data(os.path.join(data_dir, "table_1.csv"))
    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

    available_wood = params["available_wood"]
    available_steel = params["available_steel"]
    profit_premium_bonus = params["profit_premium_bonus"]
    premium_steel_factor = params["premium_steel_factor"]
    premium_shift_capacity = params["premium_shift_capacity"]

    toy_names = [t["type"] for t in toys]
    profit = {t["type"]: t["profit"] for t in toys}
    wood = {t["type"]: t["wood"] for t in toys}
    steel = {t["type"]: t["steel"] for t in toys}

    # Tight upper bounds by resources and premium capacity
    ub_total = {}
    ub_premium = {}
    for t in toy_names:
        by_wood = available_wood / wood[t] if wood[t] > 0 else GRB.INFINITY
        by_steel_std = available_steel / steel[t] if steel[t] > 0 else GRB.INFINITY
        ub_total[t] = min(by_wood, by_steel_std)
        by_steel_prem = available_steel / (premium_steel_factor * steel[t]) if steel[t] > 0 else GRB.INFINITY
        ub_premium[t] = min(by_wood, by_steel_prem, premium_shift_capacity)

    m = gp.Model("HausToys_Revised")
    m.setParam("OutputFlag", 0)

    # Quantity variables by shift
    x_std = {t: m.addVar(lb=0.0, ub=ub_total[t], vtype=GRB.CONTINUOUS, name=f"x_std_{t}") for t in toy_names}
    x_pre = {t: m.addVar(lb=0.0, ub=ub_premium[t], vtype=GRB.CONTINUOUS, name=f"x_pre_{t}") for t in toy_names}

    # Shift selection / production indicators
    y_std = {t: m.addVar(vtype=GRB.BINARY, name=f"y_std_{t}") for t in toy_names}
    y_pre = {t: m.addVar(vtype=GRB.BINARY, name=f"y_pre_{t}") for t in toy_names}
    y_any = {t: m.addVar(vtype=GRB.BINARY, name=f"y_any_{t}") for t in toy_names}

    # Objective
    m.setObjective(
        gp.quicksum(profit[t] * x_std[t] + (profit[t] + profit_premium_bonus) * x_pre[t] for t in toy_names),
        GRB.MAXIMIZE
    )

    # Resource constraints
    m.addConstr(
        gp.quicksum(wood[t] * (x_std[t] + x_pre[t]) for t in toy_names) <= available_wood,
        name="wood_capacity"
    )
    m.addConstr(
        gp.quicksum(steel[t] * x_std[t] + premium_steel_factor * steel[t] * x_pre[t] for t in toy_names) <= available_steel,
        name="steel_capacity"
    )
    m.addConstr(
        gp.quicksum(x_pre[t] for t in toy_names) <= premium_shift_capacity,
        name="premium_shift_capacity"
    )

    # Linking and either-or shift choice for each toy type
    for t in toy_names:
        m.addConstr(x_std[t] <= ub_total[t] * y_std[t], name=f"link_std_{t}")
        m.addConstr(x_pre[t] <= ub_premium[t] * y_pre[t], name=f"link_pre_{t}")
        m.addConstr(y_std[t] + y_pre[t] == y_any[t], name=f"shift_choice_{t}")

    # Original logical constraints, now across shifts
    m.addConstr(y_any["truck"] + y_any["train"] <= 1, name="truck_train_exclusion")
    m.addConstr(y_any["boat"] <= y_any["airplane"], name="boat_airplane_dependency")
    m.addConstr(
        x_std["boat"] + x_pre["boat"] <= x_std["train"] + x_pre["train"],
        name="boat_train_limit"
    )

    m.optimize()

    obj = m.ObjVal if m.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj}")


if __name__ == "__main__":
    main()
