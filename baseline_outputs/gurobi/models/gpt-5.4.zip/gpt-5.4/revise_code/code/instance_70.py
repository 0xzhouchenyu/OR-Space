import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_distance_matrix(filepath):
    with open(filepath, "r", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        cities = header[1:]
        dist = []
        row_labels = []
        for row in reader:
            row_labels.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
    return cities, row_labels, dist


def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row["parameter"].strip()
            val = row["value"].strip()
            try:
                if "." in val:
                    params[key] = float(val)
                else:
                    params[key] = int(val)
            except ValueError:
                params[key] = val
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    dist_path = os.path.join(data_dir, "table_1.csv")
    param_path = os.path.join(data_dir, "general_parameters.csv")

    cities, row_labels, dist = load_distance_matrix(dist_path)
    params = load_parameters(param_path)

    if cities != row_labels:
        raise ValueError("City labels in header and rows do not match.")

    n = len(cities)
    city_to_idx = {city: i for i, city in enumerate(cities)}

    start_city = str(params["start_city"])
    end_city = str(params["end_city"])
    prohibited_from = str(params["prohibited_from"])
    prohibited_to = str(params["prohibited_to"])
    inspection_arc_from = str(params["inspection_arc_from"])
    inspection_arc_to = str(params["inspection_arc_to"])
    inspection_stop_cost = float(params["inspection_stop_cost"])

    s = city_to_idx[start_city]
    t = city_to_idx[end_city]
    p_from = city_to_idx[prohibited_from]
    p_to = city_to_idx[prohibited_to]
    insp_from = city_to_idx[inspection_arc_from]
    insp_to = city_to_idx[inspection_arc_to]

    model = gp.Model("revised_tsp_path")
    model.setParam("OutputFlag", 0)

    x = {}
    for i in range(n):
        for j in range(n):
            if i != j:
                x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")

    if n > 1:
        u = model.addVars(n, vtype=GRB.CONTINUOUS, lb=0.0, ub=n - 1, name="u")
    else:
        u = {}

    obj = gp.quicksum(dist[i][j] * x[i, j] for (i, j) in x)
    if (insp_from, insp_to) in x:
        obj += inspection_stop_cost * x[insp_from, insp_to]
    model.setObjective(obj, GRB.MINIMIZE)

    for i in range(n):
        out_expr = gp.quicksum(x[i, j] for j in range(n) if i != j)
        in_expr = gp.quicksum(x[j, i] for j in range(n) if i != j)

        if i == s:
            model.addConstr(out_expr == 1, name=f"start_out_{i}")
            model.addConstr(in_expr == 0, name=f"start_in_{i}")
        elif i == t:
            model.addConstr(out_expr == 0, name=f"end_out_{i}")
            model.addConstr(in_expr == 1, name=f"end_in_{i}")
        else:
            model.addConstr(out_expr == 1, name=f"out_{i}")
            model.addConstr(in_expr == 1, name=f"in_{i}")

    if (p_from, p_to) in x:
        model.addConstr(x[p_from, p_to] == 0, name="prohibited_arc")

    if n > 1:
        model.addConstr(u[s] == 0, name="order_start")
        for i in range(n):
            if i != s:
                model.addConstr(u[i] >= 1, name=f"u_lb_{i}")

        for i in range(n):
            for j in range(n):
                if i != j and i != t and j != s and (i, j) in x:
                    model.addConstr(
                        u[j] >= u[i] + 1 - n * (1 - x[i, j]),
                        name=f"mtz_{i}_{j}"
                    )

    model.optimize()

    if model.Status != GRB.OPTIMAL:
        raise RuntimeError(f"Optimization ended with status {model.Status}")

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")


if __name__ == "__main__":
    main()
