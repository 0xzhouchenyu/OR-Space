import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_table1(data_dir):
    filepath = os.path.join(data_dir, "table_1.csv")
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}

    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row["Equipment"].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in ["Product_I", "Product_II", "Product_III"]:
                val = row[p].strip() if row[p] is not None else ""
                proc_times[e][p] = float(val) if val != "" else None
            eff_hours[e] = float(row["Effective_Machine_Hours"].strip())
            op_costs[e] = float(row["Operating_Costs_Full_Capacity_Yuan"].strip())

    return equipment, proc_times, eff_hours, op_costs


def load_general_params(data_dir):
    filepath = os.path.join(data_dir, "general_parameters.csv")
    raw_costs = {}
    prices = {}
    labor_coeff = {}
    shared_labor_hours = None
    b2_activation_fee = None

    mapping_raw = {
        "raw_material_cost_product_I": "Product_I",
        "raw_material_cost_product_II": "Product_II",
        "raw_material_cost_product_III": "Product_III",
    }
    mapping_price = {
        "unit_price_product_I": "Product_I",
        "unit_price_product_II": "Product_II",
        "unit_price_product_III": "Product_III",
    }

    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = float(row["Value"].strip())

            if name in mapping_raw:
                raw_costs[mapping_raw[name]] = val
            elif name in mapping_price:
                prices[mapping_price[name]] = val
            elif name == "shared_labor_hours":
                shared_labor_hours = val
            elif name.startswith("labor_coeff_"):
                eq = name[len("labor_coeff_"):]
                labor_coeff[eq] = val
            elif name == "b2_activation_fee":
                b2_activation_fee = val

    return raw_costs, prices, shared_labor_hours, labor_coeff, b2_activation_fee


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    equipment, proc_times, eff_hours, op_costs = load_table1(data_dir)
    raw_costs, prices, shared_labor_hours, labor_coeff, b2_activation_fee = load_general_params(data_dir)

    products = ["Product_I", "Product_II", "Product_III"]
    A_equip = [e for e in equipment if e.startswith("A")]
    B_equip = [e for e in equipment if e.startswith("B")]

    model = gp.Model("Factory_Production_Revised")
    model.setParam("OutputFlag", 0)

    x = {}
    for e in equipment:
        for p in products:
            if proc_times[e][p] is not None:
                x[e, p] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")

    y_b2 = model.addVar(vtype=GRB.BINARY, name="y_B2")

    # Capacity constraints
    for e in equipment:
        expr = gp.quicksum(
            x[e, p] * proc_times[e][p]
            for p in products
            if proc_times[e][p] is not None
        )
        if e == "B2":
            model.addConstr(expr <= eff_hours[e] * y_b2, name=f"capacity_{e}")
        else:
            model.addConstr(expr <= eff_hours[e], name=f"capacity_{e}")

    # Flow balance for each product: A processed units = B processed units
    for p in products:
        a_sum = gp.quicksum(x[e, p] for e in A_equip if proc_times[e][p] is not None)
        b_sum = gp.quicksum(x[e, p] for e in B_equip if proc_times[e][p] is not None)
        model.addConstr(a_sum == b_sum, name=f"balance_{p}")

    # Shared labor constraint
    labor_use = gp.quicksum(
        labor_coeff[e] * gp.quicksum(
            x[e, p] * proc_times[e][p]
            for p in products
            if proc_times[e][p] is not None
        )
        for e in equipment
    )
    model.addConstr(labor_use <= shared_labor_hours, name="shared_labor")

    # Total production by product
    total_prod = {
        p: gp.quicksum(x[e, p] for e in A_equip if proc_times[e][p] is not None)
        for p in products
    }

    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)
    raw_material_cost = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)
    operating_cost = gp.quicksum(
        op_costs[e] * (
            gp.quicksum(
                x[e, p] * proc_times[e][p]
                for p in products
                if proc_times[e][p] is not None
            ) / eff_hours[e]
        )
        for e in equipment
    )
    activation_cost = b2_activation_fee * y_b2

    model.setObjective(revenue - raw_material_cost - operating_cost - activation_cost, GRB.MAXIMIZE)

    model.optimize()

    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
