import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(base_dir):
    params = {}
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def load_distances(base_dir):
    distances = {}
    filepath = os.path.join(base_dir, "data", "table_1.csv")
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            yard = row["Coal_Yard"].strip()
            area = int(row["Residential_Area"].strip())
            dist = float(row["Distance_km"].strip())
            distances[(yard, area)] = dist
    return distances

base_dir = os.path.dirname(os.path.abspath(__file__))
params = load_parameters(base_dir)
distances = load_distances(base_dir)

coal_yards = sorted(set(y for y, _ in distances.keys()))
areas = sorted(set(a for _, a in distances.keys()) | {1, 2, 3})

min_supply = {
    "A": params["min_coal_yard_A"],
    "B": params["min_coal_yard_B_adjusted"],
}

demand = {
    1: params["residential_area_1_demand"],
    2: params["residential_area_2_demand"],
    3: params["residential_area_3_demand"],
}

min_share_area3_from_A = params["min_share_area3_from_A"]
area3_A_staging_threshold = params["area3_A_staging_threshold"]
area3_A_excess_staging_cost = params["area3_A_excess_staging_cost"]

m = gp.Model("revised_coal_distribution")
m.setParam("OutputFlag", 0)

x = {}
for (yard, area), dist in distances.items():
    x[(yard, area)] = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{yard}_{area}")

excess_A3 = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="excess_A3")

transport_cost = gp.quicksum(distances[(yard, area)] * x[(yard, area)] for (yard, area) in x)
extra_handling_cost = area3_A_excess_staging_cost * excess_A3
m.setObjective(transport_cost + extra_handling_cost, GRB.MINIMIZE)

for yard in min_supply:
    m.addConstr(
        gp.quicksum(x[(yard, area)] for area in areas if (yard, area) in x) >= min_supply[yard],
        name=f"min_supply_{yard}"
    )

for area in areas:
    incoming = gp.quicksum(x[(yard, area)] for yard in coal_yards if (yard, area) in x)
    m.addConstr(incoming == demand[area], name=f"demand_{area}")

m.addConstr(
    x[("A", 3)] >= min_share_area3_from_A * demand[3],
    name="min_share_area3_from_A"
)

m.addConstr(
    excess_A3 >= x[("A", 3)] - area3_A_staging_threshold,
    name="excess_definition"
)

m.optimize()

obj_val = m.ObjVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
