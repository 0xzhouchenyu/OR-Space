import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB


def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params_df = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    demand_df = pd.read_csv(os.path.join(data_dir, "table_1.csv"))

    params = dict(zip(params_df["Parameter_Name"], params_df["Value"]))
    demand = dict(zip(demand_df["stage"], demand_df["tool_requirement"]))

    return params, demand


def main():
    params, demand = load_data()

    n = int(params["n"])
    cost_new = float(params["cost_new_tool"])
    cost_slow = float(params["cost_slow_repair"])
    cost_fast = float(params["cost_fast_repair"])
    dur_slow = int(params["slow_repair_duration"])
    dur_fast = int(params["fast_repair_duration"])
    max_fast_stage = float(params["max_fast_stage"])
    max_slow_stage = float(params["max_slow_stage"])
    emission_buy = float(params["emission_buy"])
    emission_fast = float(params["emission_fast_repair"])
    emission_slow = float(params["emission_slow_repair"])
    carbon_budget = float(params["carbon_budget"])
    penalty_shortage = float(params["penalty_shortage"])

    stages = list(range(1, n + 1))

    m = gp.Model("revised_tool_repair")
    m.setParam("OutputFlag", 0)

    prebuy_clean = m.addVar(vtype=GRB.INTEGER, lb=0, name="prebuy_clean")
    buy = m.addVars(stages, vtype=GRB.INTEGER, lb=0, name="buy")
    fast = m.addVars(stages, vtype=GRB.INTEGER, lb=0, name="fast")
    slow = m.addVars(stages, vtype=GRB.INTEGER, lb=0, name="slow")
    clean = m.addVars(range(0, n + 1), vtype=GRB.INTEGER, lb=0, name="clean")
    dirty = m.addVars(range(0, n + 1), vtype=GRB.INTEGER, lb=0, name="dirty")
    shortage = m.addVars(stages, vtype=GRB.INTEGER, lb=0, name="shortage")

    m.addConstr(clean[0] == prebuy_clean, name="initial_clean")
    m.addConstr(dirty[0] == 0, name="initial_dirty")

    for t in stages:
        fast_ready = fast[t - dur_fast] if t - dur_fast >= 1 else 0
        slow_ready = slow[t - dur_slow] if t - dur_slow >= 1 else 0

        m.addConstr(
            clean[t - 1] + buy[t] + fast_ready + slow_ready == (demand[t] - shortage[t]) + clean[t],
            name=f"clean_balance_{t}"
        )

        m.addConstr(
            dirty[t - 1] + (demand[t] - shortage[t]) == fast[t] + slow[t] + dirty[t],
            name=f"dirty_balance_{t}"
        )

        m.addConstr(fast[t] <= max_fast_stage, name=f"fast_cap_{t}")
        m.addConstr(slow[t] <= max_slow_stage, name=f"slow_cap_{t}")
        m.addConstr(shortage[t] <= demand[t], name=f"shortage_cap_{t}")

    m.addConstr(
        emission_buy * (prebuy_clean + gp.quicksum(buy[t] for t in stages))
        + emission_fast * gp.quicksum(fast[t] for t in stages)
        + emission_slow * gp.quicksum(slow[t] for t in stages)
        <= carbon_budget,
        name="carbon_budget"
    )

    m.setObjective(
        cost_new * (prebuy_clean + gp.quicksum(buy[t] for t in stages))
        + cost_fast * gp.quicksum(fast[t] for t in stages)
        + cost_slow * gp.quicksum(slow[t] for t in stages)
        + penalty_shortage * gp.quicksum(shortage[t] for t in stages),
        GRB.MINIMIZE
    )

    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")


if __name__ == "__main__":
    main()
