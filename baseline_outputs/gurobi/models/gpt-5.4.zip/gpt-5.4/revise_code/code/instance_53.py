import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(base_dir):
    params = {}
    path = os.path.join(base_dir, "data", "general_parameters.csv")
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = row["Value"].strip()
            try:
                if "." in val:
                    params[name] = float(val)
                else:
                    params[name] = int(val)
            except ValueError:
                params[name] = val
    return params


def load_costs(base_dir):
    costs = {}
    path = os.path.join(base_dir, "data", "table_1.csv")
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row["Child"].strip()
            costs[child] = {
                "budget": float(row["Cost_budget"]),
                "balanced": float(row["Cost_balanced"]),
                "premium": float(row["Cost_premium"]),
            }
    return costs


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    params = load_parameters(base_dir)
    costs = load_costs(base_dir)

    children = list(costs.keys())
    modes = ["budget", "balanced", "premium"]

    max_children = int(params["max_children"])
    min_children = int(params["min_children"])
    mandatory_ginny = int(params["mandatory_ginny"])
    fairness_penalty = float(params["fairness_penalty"])
    max_total_cost = float(params["max_total_cost"])
    min_children_per_mode = int(params["min_children_per_mode"])

    m = gp.Model("zhang_family_trip_revised")
    m.setParam("OutputFlag", 0)

    x = m.addVars(children, vtype=GRB.BINARY, name="x")
    y = m.addVars(modes, vtype=GRB.BINARY, name="mode")

    z = m.addVars(children, modes, vtype=GRB.BINARY, name="z")

    c = m.addVars(children, lb=0.0, vtype=GRB.CONTINUOUS, name="child_cost")
    cmax = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="cmax")
    cmin = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="cmin")
    spread = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="spread")

    total_spend = gp.quicksum(
        costs[child][mode] * z[child, mode] for child in children for mode in modes
    )

    m.setObjective(total_spend + fairness_penalty * spread, GRB.MINIMIZE)

    m.addConstr(gp.quicksum(y[mode] for mode in modes) == 1, name="one_mode")

    for child in children:
        m.addConstr(gp.quicksum(z[child, mode] for mode in modes) == x[child], name=f"link_x_z_{child}")
        for mode in modes:
            m.addConstr(z[child, mode] <= y[mode], name=f"z_le_mode_{child}_{mode}")

    for child in children:
        m.addConstr(
            c[child] == gp.quicksum(costs[child][mode] * z[child, mode] for mode in modes),
            name=f"define_c_{child}"
        )

    m.addConstr(x["Ginny"] == mandatory_ginny, name="ginny_must_go")

    m.addConstr(gp.quicksum(x[child] for child in children) <= max_children, name="max_children")
    m.addConstr(gp.quicksum(x[child] for child in children) >= min_children, name="min_children")

    m.addConstr(x["Harry"] + x["Fred"] <= 1, name="harry_no_fred")
    m.addConstr(x["Harry"] + x["George"] <= 1, name="harry_no_george")
    m.addConstr(x["George"] <= x["Fred"], name="george_requires_fred")
    m.addConstr(x["George"] <= x["Hermione"], name="george_requires_hermione")

    total_children = gp.quicksum(x[child] for child in children)
    m.addConstr(total_children >= min_children_per_mode * y["balanced"], name="balanced_min_group")
    m.addConstr(total_children >= min_children_per_mode * y["premium"], name="premium_min_group")

    m.addConstr(total_spend <= max_total_cost, name="max_total_cost")

    M = max(costs[child][mode] for child in children for mode in modes)

    for child in children:
        m.addConstr(cmax >= c[child], name=f"cmax_ge_{child}")
        m.addConstr(cmin <= c[child] + M * (1 - x[child]), name=f"cmin_le_active_{child}")
        m.addConstr(cmin >= c[child] - M * (1 - x[child]), name=f"cmin_ge_active_{child}")

    m.addConstr(spread == cmax - cmin, name="spread_def")

    m.optimize()

    obj_val = m.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
