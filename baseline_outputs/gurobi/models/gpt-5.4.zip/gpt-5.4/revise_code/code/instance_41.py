import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load general parameters
initial_capital = None
with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "initial_capital":
            initial_capital = float(row["Value"].strip())
            break

# Load liquidity policy
min_year3_reserve = None
reserve_shortfall_penalty = None
with open(os.path.join(data_dir, "liquidity_policy.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        val = float(row["Value"].strip())
        if name == "min_year3_reserve":
            min_year3_reserve = val
        elif name == "reserve_shortfall_penalty":
            reserve_shortfall_penalty = val

# Load project capacities/rates
projects = {}
with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        pid = int(row["Project_ID"])
        rate = float(row["Interest_Rate"])
        cap_raw = row["Investment_Capacity"].strip()
        cap = GRB.INFINITY if cap_raw.lower() == "unlimited" else float(cap_raw)
        projects[pid] = {"rate": rate, "cap": cap}

r1 = projects[1]["rate"]
r2 = projects[2]["rate"]
r3 = projects[3]["rate"]
r4 = projects[4]["rate"]
cap2 = projects[2]["cap"]
cap3 = projects[3]["cap"]
cap4 = projects[4]["cap"]

# Model
m = gp.Model("revised_investment_plan")
m.setParam("OutputFlag", 0)

# Decision variables
x1_1 = m.addVar(lb=0.0, name="x1_1")
x1_2 = m.addVar(lb=0.0, name="x1_2")
x1_3 = m.addVar(lb=0.0, name="x1_3")
x2 = m.addVar(lb=0.0, ub=cap2, name="x2")
x3 = m.addVar(lb=0.0, ub=cap3, name="x3")
x4 = m.addVar(lb=0.0, ub=cap4, name="x4")

# Beginning-of-Year-3 liquidity variables
reserve_y3 = m.addVar(lb=0.0, name="reserve_y3")
shortfall = m.addVar(lb=0.0, name="shortfall")

# Cash flow constraints
m.addConstr(x1_1 + x2 <= initial_capital, name="year1_budget")
m.addConstr(x1_2 + x3 <= r1 * x1_1, name="year2_budget")

available_y3 = r1 * x1_2 + r2 * x2 + r3 * x3
m.addConstr(x1_3 + x4 + reserve_y3 == available_y3, name="year3_cash_balance")

# Shortfall definition: shortfall >= required reserve - actual reserve
m.addConstr(shortfall >= min_year3_reserve - reserve_y3, name="reserve_shortfall_def")

# Objective: ending funds minus penalty
# End of Year 3 funds = matured Year 3 investments + carried reserve cash
obj = r1 * x1_3 + r4 * x4 + reserve_y3 - reserve_shortfall_penalty * shortfall
m.setObjective(obj, GRB.MAXIMIZE)

m.optimize()

final_obj = m.ObjVal
print(f"FINAL_OBJ_VALUE: {final_obj}")
