import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_general_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            value = row["Value"].strip()
            params[name] = value
    return params

def read_requirements(path):
    periods = []
    reqs = []
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            periods.append(row["Time_Period"].strip())
            reqs.append(int(row["Required_Salespeople"].strip()))
    return periods, reqs

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = read_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    periods, requirements = read_requirements(os.path.join(data_dir, "table_1.csv"))

    n = len(periods)

    full_time_cost = float(params["full_time_cost"])
    part_time_cost = float(params["part_time_cost"])
    part_time_cap_per_period = int(float(params["part_time_cap_per_period"]))
    min_full_time_per_period = int(float(params["min_full_time_per_period"]))

    model = gp.Model("revised_convenience_store_staffing")
    model.setParam("OutputFlag", 0)

    x = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="full_time_starts")
    y = model.addVars(n, vtype=GRB.INTEGER, lb=0, ub=part_time_cap_per_period, name="part_time_period")

    model.setObjective(
        gp.quicksum(full_time_cost * x[i] for i in range(n)) +
        gp.quicksum(part_time_cost * y[j] for j in range(n)),
        GRB.MINIMIZE
    )

    for j in range(n):
        full_time_present = x[j] + x[(j - 1) % n]
        model.addConstr(full_time_present + y[j] >= requirements[j], name=f"coverage_{j}")
        model.addConstr(full_time_present >= min_full_time_per_period, name=f"min_full_time_{j}")

    model.optimize()

    obj_val = model.ObjVal
    if abs(obj_val - round(obj_val)) < 1e-9:
        obj_str = str(int(round(obj_val)))
    else:
        obj_str = str(obj_val)

    print(f"FINAL_OBJ_VALUE: {obj_str}")

if __name__ == "__main__":
    main()
