import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB


def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")

    df_items = pd.read_csv(table_path)
    df_params = pd.read_csv(params_path)

    params = {}
    for _, row in df_params.iterrows():
        params[row["Parameter_Name"]] = row["Value"]

    lengths = df_items["Length"].astype(float).tolist()
    demands = df_items["Quantity"].astype(int).tolist()

    return lengths, demands, params


def get_float(params, key):
    return float(params[key])


def get_int(params, key):
    return int(float(params[key]))


def generate_patterns(raw_length, max_cuts, max_leftover, item_lengths):
    n = len(item_lengths)
    min_used_length = raw_length - max_leftover
    patterns = []

    def rec(idx, current_pattern, used_length, cuts):
        if idx == n:
            if cuts > 0 and used_length <= raw_length and used_length >= min_used_length:
                patterns.append(tuple(current_pattern))
            return

        max_qty_by_length = int((raw_length - used_length) // item_lengths[idx])
        max_qty_by_cuts = max_cuts - cuts
        max_qty = min(max_qty_by_length, max_qty_by_cuts)

        for q in range(max_qty + 1):
            current_pattern.append(q)
            rec(
                idx + 1,
                current_pattern,
                used_length + q * item_lengths[idx],
                cuts + q
            )
            current_pattern.pop()

    rec(0, [], 0.0, 0)
    return patterns


def build_and_solve():
    lengths, demands, params = load_data()
    n_items = len(lengths)

    suppliers = [1, 2]

    raw_len = {
        1: get_float(params, "raw_pipe_length_supplier1"),
        2: get_float(params, "raw_pipe_length_supplier2"),
    }
    max_patterns = {
        1: get_int(params, "max_cutting_patterns_supplier1"),
        2: get_int(params, "max_cutting_patterns_supplier2"),
    }
    max_cuts = {
        1: get_int(params, "max_cuts_per_pipe_supplier1"),
        2: get_int(params, "max_cuts_per_pipe_supplier2"),
    }
    max_leftover = {
        1: get_float(params, "max_leftover_length_supplier1"),
        2: get_float(params, "max_leftover_length_supplier2"),
    }
    purchase_cost = {
        1: get_float(params, "purchase_cost_per_pipe_supplier1"),
        2: get_float(params, "purchase_cost_per_pipe_supplier2"),
    }

    cost_rates = {
        1: [
            get_float(params, "most_frequent_pattern_cost_rate_supplier1"),
            get_float(params, "second_frequent_pattern_cost_rate_supplier1"),
            get_float(params, "third_frequent_pattern_cost_rate_supplier1"),
        ],
        2: [
            get_float(params, "most_frequent_pattern_cost_rate_supplier2"),
            get_float(params, "second_frequent_pattern_cost_rate_supplier2"),
            get_float(params, "third_frequent_pattern_cost_rate_supplier2"),
        ],
    }

    discount_threshold_s1 = get_int(params, "discount_tier1_supplier1_max_qty")
    fixed_discount_s1 = get_float(params, "fixed_discount_tier2_supplier1")
    bigM_discount = get_int(params, "bigM_discount")

    patterns = {}
    for s in suppliers:
        patterns[s] = generate_patterns(raw_len[s], max_cuts[s], max_leftover[s], lengths)

    model = gp.Model("revised_pipe_cutting")
    model.setParam("OutputFlag", 0)

    y = {}
    z = {}
    x = {}
    v = {}

    total_demand = sum(demands)
    M_usage = total_demand
    M_order = total_demand

    for s in suppliers:
        P = range(len(patterns[s]))
        R = range(1, max_patterns[s] + 1)

        for p in P:
            y[s, p] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"y_{s}_{p}")
            z[s, p] = model.addVar(vtype=GRB.BINARY, name=f"z_{s}_{p}")

        for p in P:
            for r in R:
                x[s, p, r] = model.addVar(vtype=GRB.BINARY, name=f"x_{s}_{p}_{r}")
                v[s, p, r] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"v_{s}_{p}_{r}")

    u_discount = model.addVar(vtype=GRB.BINARY, name="u_discount_s1")

    # Demand coverage across both suppliers
    for i in range(n_items):
        model.addConstr(
            gp.quicksum(patterns[s][p][i] * y[s, p] for s in suppliers for p in range(len(patterns[s])))
            >= demands[i],
            name=f"demand_{i}"
        )

    # Pattern activation and supplier-specific pattern limits
    for s in suppliers:
        P = range(len(patterns[s]))
        R = range(1, max_patterns[s] + 1)

        for p in P:
            model.addConstr(y[s, p] <= M_usage * z[s, p], name=f"activate_ub_{s}_{p}")
            model.addConstr(y[s, p] >= z[s, p], name=f"activate_lb_{s}_{p}")

            model.addConstr(gp.quicksum(x[s, p, r] for r in R) == z[s, p], name=f"assign_rank_if_used_{s}_{p}")

        for r in R:
            model.addConstr(gp.quicksum(x[s, p, r] for p in P) <= 1, name=f"one_pattern_per_rank_{s}_{r}")

        model.addConstr(gp.quicksum(z[s, p] for p in P) <= max_patterns[s], name=f"max_patterns_{s}")

        # Link rank-assigned usage variables
        for p in P:
            for r in R:
                model.addConstr(v[s, p, r] <= y[s, p], name=f"v_le_y_{s}_{p}_{r}")
                model.addConstr(v[s, p, r] <= M_usage * x[s, p, r], name=f"v_le_Mx_{s}_{p}_{r}")
                model.addConstr(v[s, p, r] >= y[s, p] - M_usage * (1 - x[s, p, r]), name=f"v_ge_link_{s}_{p}_{r}")

        # Nonincreasing frequency by rank
        for r in range(1, max_patterns[s]):
            usage_r = gp.quicksum(v[s, p, r] for p in P)
            usage_next = gp.quicksum(v[s, p, r + 1] for p in P)
            model.addConstr(usage_r >= usage_next, name=f"rank_order_{s}_{r}")

    # Discount logic for supplier 1
    total_s1 = gp.quicksum(y[1, p] for p in range(len(patterns[1])))
    model.addConstr(total_s1 >= (discount_threshold_s1 + 1) * u_discount, name="discount_lb")
    model.addConstr(total_s1 <= discount_threshold_s1 + bigM_discount * u_discount, name="discount_ub")

    # Objective
    purchase_term = gp.quicksum(
        purchase_cost[s] * gp.quicksum(y[s, p] for p in range(len(patterns[s])))
        for s in suppliers
    )

    pattern_charge_term = gp.quicksum(
        cost_rates[s][r - 1] * gp.quicksum(v[s, p, r] for p in range(len(patterns[s])))
        for s in suppliers
        for r in range(1, max_patterns[s] + 1)
    )

    model.setObjective(purchase_term + pattern_charge_term - fixed_discount_s1 * u_discount, GRB.MINIMIZE)

    model.optimize()

    obj = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj}")


if __name__ == "__main__":
    build_and_solve()
