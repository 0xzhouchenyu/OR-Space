import os
import csv
import re
import gurobipy as gp
from gurobipy import GRB


def parse_percentage(cell):
    if cell is None:
        return None, None
    s = str(cell).strip()
    if s == "":
        return None, None
    m = re.match(r'^(>=|<=)\s*([0-9]+(?:\.[0-9]+)?)%$', s)
    if not m:
        return None, None
    sense = m.group(1)
    value = float(m.group(2)) / 100.0
    return sense, value


def read_table_1_7(path):
    with open(path, "r", newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    brands = ["A", "B", "C"]
    raw_materials = []
    raw_cost = {}
    limits = {}
    composition = {}

    processing_fee = {}
    selling_price = {}

    for row in rows:
        item = row["Item"].strip()
        if item == "Processing Fee (Yuan/kg)":
            for b in brands:
                processing_fee[b] = float(row[b]) if row[b].strip() != "" else 0.0
        elif item == "Selling Price (Yuan/kg)":
            for b in brands:
                selling_price[b] = float(row[b]) if row[b].strip() != "" else 0.0
        else:
            raw_materials.append(item)
            raw_cost[item] = float(row["Raw Material Cost (Yuan/kg)"])
            limits[item] = float(row["Monthly Limit (kg)"])
            for b in brands:
                sense, val = parse_percentage(row[b])
                if sense is not None:
                    composition[(item, b)] = (sense, val)

    return brands, raw_materials, raw_cost, limits, composition, processing_fee, selling_price


def read_general_parameters(path):
    params = {}
    with open(path, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            value_str = row["Value"].strip()
            try:
                value = float(value_str)
            except ValueError:
                value = value_str
            params[name] = value
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_path = os.path.join(base_dir, "data", "table_1_7.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")

    brands, raw_materials, raw_cost, limits, composition, processing_fee, selling_price = read_table_1_7(table_path)
    params = read_general_parameters(params_path)

    setup_cost = {
        "A": float(params.get("SetupCost_A", 0.0)),
        "B": float(params.get("SetupCost_B", 0.0)),
        "C": float(params.get("SetupCost_C", 0.0)),
    }
    wrapper_trigger = float(params.get("BrandAB_SharedWrapper_Trigger", 0.0))
    wrapper_fee = float(params.get("BrandAB_SharedWrapper_Fee", 0.0))

    model = gp.Model("CandyFactoryRevised")
    model.setParam("OutputFlag", 0)

    x = model.addVars(raw_materials, brands, lb=0.0, vtype=GRB.CONTINUOUS, name="x")
    y = model.addVars(brands, lb=0.0, vtype=GRB.CONTINUOUS, name="y")
    z = model.addVars(brands, vtype=GRB.BINARY, name="z")
    w_ab = model.addVar(vtype=GRB.BINARY, name="w_ab")

    for b in brands:
        model.addConstr(y[b] == gp.quicksum(x[r, b] for r in raw_materials), name=f"mass_balance_{b}")

    for r in raw_materials:
        model.addConstr(gp.quicksum(x[r, b] for b in brands) <= limits[r], name=f"supply_{r}")

    for (r, b), (sense, val) in composition.items():
        if sense == ">=":
            model.addConstr(x[r, b] >= val * y[b], name=f"comp_lb_{r}_{b}")
        elif sense == "<=":
            model.addConstr(x[r, b] <= val * y[b], name=f"comp_ub_{r}_{b}")

    total_possible_production = sum(limits.values())
    for b in brands:
        model.addConstr(y[b] <= total_possible_production * z[b], name=f"activate_{b}")

    model.addConstr(w_ab <= z["A"], name="wab_le_a")
    model.addConstr(w_ab <= z["B"], name="wab_le_b")
    model.addConstr(w_ab >= z["A"] + z["B"] - 1, name="wab_ge_abminus1")

    revenue = gp.quicksum(selling_price[b] * y[b] for b in brands)
    material_cost = gp.quicksum(raw_cost[r] * x[r, b] for r in raw_materials for b in brands)
    proc_cost = gp.quicksum(processing_fee[b] * y[b] for b in brands)
    fixed_setup_cost = gp.quicksum(setup_cost[b] * z[b] for b in brands)
    shared_wrapper_cost = wrapper_trigger * wrapper_fee * w_ab

    model.setObjective(revenue - material_cost - proc_cost - fixed_setup_cost - shared_wrapper_cost, GRB.MAXIMIZE)

    model.optimize()

    obj = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj}")


if __name__ == "__main__":
    main()
