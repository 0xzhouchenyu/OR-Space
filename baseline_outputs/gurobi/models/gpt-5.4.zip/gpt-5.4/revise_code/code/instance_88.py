import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_general_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_general_parameters(data_path)

    m1_liquid = params["machine_1_time_per_liquid_lot"]
    m2_liquid = params["machine_2_time_per_liquid_lot"]
    m1_solid = params["machine_1_time_per_solid_lot"]
    m2_solid = params["machine_2_time_per_solid_lot"]

    init_liquid = params["initial_liquid_inventory"]
    init_solid = params["initial_solid_inventory"]

    m1_base = params["machine_1_available_time"] * 60.0
    m2_base = params["machine_2_available_time"] * 60.0

    demand_liquid = params["forecast_liquid_demand"]
    demand_solid = params["forecast_solid_demand"]

    extended_extra_minutes = params["extended_extra_minutes"]
    labor_hours_per_machine_extended = params["labor_hours_per_machine_extended"]
    labor_budget_hours = params["labor_budget_hours"]
    extended_mode_penalty = params["extended_mode_penalty"]
    priority_reserve_lots = params["priority_reserve_lots"]
    excess_reserve_credit = params["excess_reserve_credit"]

    model = gp.Model("revised_fertilizer_plan")
    model.setParam("OutputFlag", 0)

    x_liquid = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="x_liquid")
    x_solid = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="x_solid")

    y_ext_m1 = model.addVar(vtype=GRB.BINARY, name="y_ext_m1")
    y_ext_m2 = model.addVar(vtype=GRB.BINARY, name="y_ext_m2")

    end_liquid = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="end_liquid")
    end_solid = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="end_solid")

    pr_liquid = model.addVar(lb=0.0, ub=priority_reserve_lots, vtype=GRB.CONTINUOUS, name="pr_liquid")
    pr_solid = model.addVar(lb=0.0, ub=priority_reserve_lots, vtype=GRB.CONTINUOUS, name="pr_solid")

    ex_liquid = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="ex_liquid")
    ex_solid = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="ex_solid")

    model.addConstr(end_liquid == init_liquid + x_liquid - demand_liquid, name="end_balance_liquid")
    model.addConstr(end_solid == init_solid + x_solid - demand_solid, name="end_balance_solid")

    model.addConstr(pr_liquid + ex_liquid == end_liquid, name="reserve_split_liquid")
    model.addConstr(pr_solid + ex_solid == end_solid, name="reserve_split_solid")

    model.addConstr(
        m1_liquid * x_liquid + m1_solid * x_solid <= m1_base + extended_extra_minutes * y_ext_m1,
        name="machine_1_capacity",
    )
    model.addConstr(
        m2_liquid * x_liquid + m2_solid * x_solid <= m2_base + extended_extra_minutes * y_ext_m2,
        name="machine_2_capacity",
    )

    model.addConstr(
        labor_hours_per_machine_extended * (y_ext_m1 + y_ext_m2) <= labor_budget_hours,
        name="labor_budget",
    )

    obj = (
        pr_liquid
        + pr_solid
        + excess_reserve_credit * (ex_liquid + ex_solid)
        - extended_mode_penalty * (y_ext_m1 + y_ext_m2)
    )
    model.setObjective(obj, GRB.MAXIMIZE)

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")


if __name__ == "__main__":
    main()
