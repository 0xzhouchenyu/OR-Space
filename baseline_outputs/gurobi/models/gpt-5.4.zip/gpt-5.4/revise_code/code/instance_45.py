import os
import csv
import gurobipy as gp
from gurobipy import GRB


def parse_range(rng):
    if rng.startswith("Above_"):
        lower = int(rng.split("_")[1])
        upper = None
    else:
        a, b = rng.split("_")
        lower = int(a)
        upper = int(b)
    return lower, upper


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])

    products = []
    segments = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            prod = row["Product"]
            if prod not in segments:
                segments[prod] = []
                products.append(prod)
            lo, hi = parse_range(row["Sales_Volume_Range"])
            segments[prod].append({
                "lower": lo,
                "upper": hi,
                "profit": float(row["Profit"])
            })

    suffix = {p: p.split("_")[1] for p in products}

    # Tight upper bounds from resources
    prod_ub = {}
    for p in products:
        s = suffix[p]
        bounds = []

        tech = params[f"technical_prep_time_{s}"]
        labor = params[f"labor_time_{s}"]
        mat = params[f"materials_{s}"]
        pack = params[f"pack_units_{s}"]

        if tech > 0:
            bounds.append(params["available_technical_prep_time"] / tech)
        if labor > 0:
            bounds.append((params["available_labor_time"] + params["overtime_cap_hours"]) / labor)
        if mat > 0:
            bounds.append(params["available_materials"] / mat)
        if pack > 0:
            bounds.append(params["packaging_cap_units"] / pack)

        finite_seg_ubs = [seg["upper"] for seg in segments[p] if seg["upper"] is not None]
        if finite_seg_ubs:
            bounds.append(max(finite_seg_ubs))
        prod_ub[p] = int(max(0, int(min(bounds)))) if bounds else 0

    m = gp.Model("revised_factory_plan")
    m.setParam("OutputFlag", 0)

    x = {p: m.addVar(vtype=GRB.INTEGER, lb=0, ub=prod_ub[p], name=f"x_{suffix[p]}") for p in products}
    seg_active = {}
    seg_qty = {}

    for p in products:
        seg_active[p] = []
        seg_qty[p] = []
        for i, seg in enumerate(segments[p]):
            z = m.addVar(vtype=GRB.BINARY, name=f"z_{suffix[p]}_{i}")
            q = m.addVar(vtype=GRB.INTEGER, lb=0, name=f"q_{suffix[p]}_{i}")
            seg_active[p].append(z)
            seg_qty[p].append(q)

    overtime = m.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=params["overtime_cap_hours"], name="overtime_hours")
    second_review = m.addVar(vtype=GRB.BINARY, name="second_review")

    # Segment logic: exactly one active segment if product produced, otherwise none
    for p in products:
        m.addConstr(gp.quicksum(seg_qty[p]) == x[p], name=f"qty_link_{p}")
        m.addConstr(gp.quicksum(seg_active[p]) <= 1, name=f"one_segment_{p}")

        for i, seg in enumerate(segments[p]):
            z = seg_active[p][i]
            q = seg_qty[p][i]
            lo = seg["lower"]
            hi = seg["upper"]

            if lo == 0:
                m.addConstr(q >= 1 * z, name=f"seg_lb_{p}_{i}")
            else:
                m.addConstr(q >= (lo + 1) * z, name=f"seg_lb_{p}_{i}")

            if hi is not None:
                m.addConstr(q <= hi * z, name=f"seg_ub_{p}_{i}")
            else:
                m.addConstr(q <= prod_ub[p] * z, name=f"seg_ub_{p}_{i}")

    # Resource constraints
    m.addConstr(
        gp.quicksum(params[f"technical_prep_time_{suffix[p]}"] * x[p] for p in products)
        <= params["available_technical_prep_time"],
        name="technical_prep"
    )

    labor_used = gp.quicksum(params[f"labor_time_{suffix[p]}"] * x[p] for p in products)
    m.addConstr(
        labor_used <= params["available_labor_time"] + overtime,
        name="labor_with_overtime"
    )

    m.addConstr(
        gp.quicksum(params[f"materials_{suffix[p]}"] * x[p] for p in products)
        <= params["available_materials"],
        name="materials"
    )

    m.addConstr(
        gp.quicksum(params[f"pack_units_{suffix[p]}"] * x[p] for p in products)
        <= params["packaging_cap_units"],
        name="packaging"
    )

    # Second review fee trigger
    threshold = params["overtime_second_review_threshold"]
    cap = params["overtime_cap_hours"]
    m.addConstr(overtime <= threshold + (cap - threshold) * second_review, name="review_trigger_upper")
    m.addConstr(overtime >= threshold * second_review, name="review_trigger_lower")

    # Objective
    revenue = gp.quicksum(
        segments[p][i]["profit"] * seg_qty[p][i]
        for p in products
        for i in range(len(segments[p]))
    )
    overtime_cost = params["overtime_cost_per_hour"] * overtime
    review_fee = params["overtime_second_review_fee"] * second_review

    m.setObjective(revenue - overtime_cost - review_fee, GRB.MAXIMIZE)

    m.optimize()

    obj = m.ObjVal
    if abs(obj - round(obj)) < 1e-9:
        obj_str = str(int(round(obj)))
    else:
        obj_str = f"{obj:.10f}".rstrip("0").rstrip(".")

    print(f"FINAL_OBJ_VALUE: {obj_str}")


if __name__ == "__main__":
    main()
