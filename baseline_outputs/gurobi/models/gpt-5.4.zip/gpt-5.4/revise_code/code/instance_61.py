import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        value = float(row["Value"].strip())
        params[name] = value

# Read device data
devices = []
with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        d = row["Device"].strip()
        devices.append({
            "name": d,
            "prep_cost": float(row["Prep_Completion_Cost_Yuan"].strip()),
            "unit_cost": float(row["Unit_Production_Cost_Yuan_per_Unit"].strip()),
            "capacity": float(row["Max_Processing_Capacity_Units"].strip()),
            "energy_per_unit": params[f"energy_per_unit_{d}"],
            "startup_energy": params[f"startup_energy_{d}"],
        })

required_units = params["required_units"]
energy_budget_peak = params["energy_budget_peak"]
energy_budget_offpeak = params["energy_budget_offpeak"]
startup_cost = params["startup_cost"]
startup_budget = params["startup_budget"]
energy_price = {
    "peak": params["energy_price_peak"],
    "offpeak": params["energy_price_offpeak"],
}
periods = ["peak", "offpeak"]

# Build model
model = gp.Model("revised_min_cost_production")
model.setParam("OutputFlag", 0)

x = {}   # production units by device and period
z = {}   # startup/use indicator by device and period
y = {}   # device used at all

for dev in devices:
    i = dev["name"]
    y[i] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}")
    for p in periods:
        x[i, p] = model.addVar(lb=0.0, ub=dev["capacity"], vtype=GRB.CONTINUOUS, name=f"x_{i}_{p}")
        z[i, p] = model.addVar(vtype=GRB.BINARY, name=f"z_{i}_{p}")

# Objective
obj = gp.quicksum(
    dev["prep_cost"] * y[dev["name"]] +
    gp.quicksum(
        (dev["unit_cost"] + dev["energy_per_unit"] * energy_price[p]) * x[dev["name"], p]
        + startup_cost * z[dev["name"], p]
        for p in periods
    )
    for dev in devices
)
model.setObjective(obj, GRB.MINIMIZE)

# Demand fulfillment
model.addConstr(
    gp.quicksum(x[dev["name"], p] for dev in devices for p in periods) == required_units,
    name="required_units"
)

# Device capacity across both periods
for dev in devices:
    i = dev["name"]
    cap = dev["capacity"]
    model.addConstr(
        gp.quicksum(x[i, p] for p in periods) <= cap,
        name=f"capacity_{i}"
    )
    for p in periods:
        model.addConstr(
            x[i, p] <= cap * z[i, p],
            name=f"link_prod_start_{i}_{p}"
        )
        model.addConstr(
            z[i, p] <= y[i],
            name=f"link_start_device_{i}_{p}"
        )

# Energy budgets by period
model.addConstr(
    gp.quicksum(
        dev["energy_per_unit"] * x[dev["name"], "peak"] + dev["startup_energy"] * z[dev["name"], "peak"]
        for dev in devices
    ) <= energy_budget_peak,
    name="energy_budget_peak"
)

model.addConstr(
    gp.quicksum(
        dev["energy_per_unit"] * x[dev["name"], "offpeak"] + dev["startup_energy"] * z[dev["name"], "offpeak"]
        for dev in devices
    ) <= energy_budget_offpeak,
    name="energy_budget_offpeak"
)

# Startup monetary budget
model.addConstr(
    gp.quicksum(startup_cost * z[dev["name"], p] for dev in devices for p in periods) <= startup_budget,
    name="startup_budget"
)

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
