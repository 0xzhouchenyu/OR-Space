import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(base_dir, "data", "general_parameters.csv")

params = {}
with open(data_path, "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

produce_to_transport = params["produce_to_transport"]
horse_pollution_per_trip = params["horse_pollution_per_trip"]
bicycle_pollution_per_trip = params["bicycle_pollution_per_trip"]
handcart_pollution_per_trip = params["handcart_pollution_per_trip"]
max_total_pollution = params["max_total_pollution"]
min_horse_trips = params["min_horse_trips"]
horse_capacity_per_trip = params["horse_capacity_per_trip"]
bicycle_capacity_per_trip = params["bicycle_capacity_per_trip"]
handcart_capacity_per_trip = params["handcart_capacity_per_trip"]
min_total_produce = params["min_total_produce"]

horse_cost_per_trip = params["horse_cost_per_trip"]
bicycle_cost_per_trip = params["bicycle_cost_per_trip"]
handcart_cost_per_trip = params["handcart_cost_per_trip"]
horse_fixed_cost = params["horse_fixed_cost"]
bicycle_fixed_cost = params["bicycle_fixed_cost"]
handcart_fixed_cost = params["handcart_fixed_cost"]
pollution_penalty_per_unit = params["pollution_penalty_per_unit"]
horse_pollution_permit_threshold = params["horse_pollution_permit_threshold"]
horse_pollution_permit_fee = params["horse_pollution_permit_fee"]

m = gp.Model("FarmTransportRevised")
m.setParam("OutputFlag", 0)

max_horse_trips = int(math.floor(max_total_pollution / horse_pollution_per_trip))
max_bike_trips = int(math.ceil(min_total_produce / bicycle_capacity_per_trip))
max_cart_trips = int(math.ceil(min_total_produce / handcart_capacity_per_trip))

x_horse = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_horse_trips, name="horse_trips")
x_bike = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_bike_trips, name="bike_trips")
x_cart = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_cart_trips, name="cart_trips")

y_bike = m.addVar(vtype=GRB.BINARY, name="choose_bike")
use_horse = m.addVar(vtype=GRB.BINARY, name="use_horse")
use_bike = m.addVar(vtype=GRB.BINARY, name="use_bike")
use_cart = m.addVar(vtype=GRB.BINARY, name="use_cart")
permit_fee_trigger = m.addVar(vtype=GRB.BINARY, name="permit_fee_trigger")

total_pollution = m.addVar(vtype=GRB.CONTINUOUS, lb=0, name="total_pollution")

m.addConstr(
    horse_capacity_per_trip * x_horse +
    bicycle_capacity_per_trip * x_bike +
    handcart_capacity_per_trip * x_cart
    >= min_total_produce,
    name="min_produce"
)

m.addConstr(total_pollution == horse_pollution_per_trip * x_horse +
            bicycle_pollution_per_trip * x_bike +
            handcart_pollution_per_trip * x_cart,
            name="pollution_def")

m.addConstr(total_pollution <= max_total_pollution, name="max_pollution")
m.addConstr(x_horse >= min_horse_trips, name="min_horse_trips")

m.addConstr(x_bike <= max_bike_trips * y_bike, name="bike_or_cart_1")
m.addConstr(x_cart <= max_cart_trips * (1 - y_bike), name="bike_or_cart_2")

m.addConstr(x_horse <= max_horse_trips * use_horse, name="horse_use_link")
m.addConstr(x_bike <= max_bike_trips * use_bike, name="bike_use_link")
m.addConstr(x_cart <= max_cart_trips * use_cart, name="cart_use_link")

m.addConstr(use_bike >= y_bike, name="bike_use_if_chosen")
m.addConstr(use_cart >= 1 - y_bike, name="cart_use_if_chosen")

eps = 1e-6
m.addConstr(total_pollution <= horse_pollution_permit_threshold + (max_total_pollution - horse_pollution_permit_threshold) * permit_fee_trigger,
            name="permit_upper_trigger")
m.addConstr(total_pollution >= horse_pollution_permit_threshold + eps - horse_pollution_permit_threshold * (1 - permit_fee_trigger),
            name="permit_lower_trigger")

objective = (
    horse_cost_per_trip * x_horse +
    bicycle_cost_per_trip * x_bike +
    handcart_cost_per_trip * x_cart +
    horse_fixed_cost * use_horse +
    bicycle_fixed_cost * use_bike +
    handcart_fixed_cost * use_cart +
    pollution_penalty_per_unit * total_pollution +
    horse_pollution_permit_fee * permit_fee_trigger
)

m.setObjective(objective, GRB.MINIMIZE)
m.optimize()

obj_val = m.ObjVal
if abs(obj_val - round(obj_val)) < 1e-9:
    obj_str = str(int(round(obj_val)))
else:
    obj_str = str(obj_val)

print(f"FINAL_OBJ_VALUE: {obj_str}")
