import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            value_str = row["Value"].strip()
            if ":" in value_str:
                a, b = value_str.split(":")
                params[name] = (int(a), int(b))
                params[name + "_raw"] = value_str
            else:
                try:
                    params[name] = int(value_str)
                except ValueError:
                    try:
                        params[name] = float(value_str)
                    except ValueError:
                        params[name] = value_str
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_parameters(data_path)

    profit_A = params["profit_product_A"]
    profit_B = params["profit_product_B"]
    assembly_time_A = params["assembly_time_A"]
    assembly_time_B = params["assembly_time_B"]
    machine_working_time_minutes = params["machine_working_time"] * 60

    ratio_A, ratio_B = params["production_ratio_A_to_B"]

    max_overtime_minutes = params["max_overtime_hours"] * 60
    overtime_penalty_per_hour = params["overtime_penalty_per_hour"]
    overtime_review_threshold_minutes = params["overtime_review_threshold_hours"] * 60
    overtime_review_fee = params["overtime_review_fee"]

    product_A_senior_batch_threshold = params["product_A_senior_batch_threshold"]
    product_A_senior_batch_fee = params["product_A_senior_batch_fee"]

    m = gp.Model("revised_product_mix")
    m.setParam("OutputFlag", 0)

    A = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="Product_A")
    B = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="Product_B")
    overtime_minutes = m.addVar(lb=0.0, ub=max_overtime_minutes, vtype=GRB.CONTINUOUS, name="Overtime_Minutes")

    y_overtime_review = m.addVar(vtype=GRB.BINARY, name="Overtime_Review_Triggered")
    y_A_senior_fee = m.addVar(vtype=GRB.BINARY, name="A_Senior_Batch_Fee_Triggered")

    M_A = (machine_working_time_minutes + max_overtime_minutes) / assembly_time_A
    M_ot = max_overtime_minutes

    m.addConstr(
        assembly_time_A * A + assembly_time_B * B <= machine_working_time_minutes + overtime_minutes,
        name="Time_With_Overtime"
    )

    m.addConstr(
        ratio_B * A - ratio_A * B <= 0,
        name="Production_Ratio"
    )

    m.addConstr(
        overtime_minutes <= overtime_review_threshold_minutes + M_ot * y_overtime_review,
        name="OT_Review_Upper"
    )

    m.addConstr(
        overtime_minutes >= overtime_review_threshold_minutes * y_overtime_review,
        name="OT_Review_Lower"
    )

    m.addConstr(
        A <= product_A_senior_batch_threshold + M_A * y_A_senior_fee,
        name="A_Fee_Upper"
    )

    m.addConstr(
        A >= product_A_senior_batch_threshold * y_A_senior_fee,
        name="A_Fee_Lower"
    )

    objective = (
        profit_A * A
        + profit_B * B
        - overtime_penalty_per_hour * (overtime_minutes / 60.0)
        - overtime_review_fee * y_overtime_review
        - product_A_senior_batch_fee * y_A_senior_fee
    )

    m.setObjective(objective, GRB.MAXIMIZE)
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")


if __name__ == "__main__":
    main()
