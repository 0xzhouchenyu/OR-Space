import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_csv_dicts(filepath):
    with open(filepath, "r", newline="") as f:
        return list(csv.DictReader(f))

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    general_params = read_csv_dicts(os.path.join(data_dir, "general_parameters.csv"))
    product_rows = read_csv_dicts(os.path.join(data_dir, "table_1.csv"))

    params = {row["Parameter_Name"]: float(row["Value"]) for row in general_params}
    products = [row["Product"] for row in product_rows]

    steel_req = {row["Product"]: float(row["Steel_Required_kg"]) for row in product_rows}
    aluminum_req = {row["Product"]: float(row["Aluminum_Required_kg"]) for row in product_rows}
    labor_req = {row["Product"]: float(row["Labor_Required_hours"]) for row in product_rows}
    profit = {row["Product"]: float(row["Profit_yuan"]) for row in product_rows}
    setup_cost = {row["Product"]: float(row["Setup_Cost_yuan"]) for row in product_rows}

    available_steel = params["available_steel"]
    available_aluminum = params["available_aluminum"]
    available_labor = params["available_labor"]
    overtime_pay = params["overtime_pay"]
    max_overtime = params["max_overtime"]
    overtime_review_threshold = params["overtime_review_threshold"]
    overtime_review_fee = params["overtime_review_fee"]
    product_A_line_audit_threshold = params["product_A_line_audit_threshold"]
    product_A_line_audit_fee = params["product_A_line_audit_fee"]

    model = gp.Model("revised_production_optimization")
    model.setParam("OutputFlag", 0)

    x = {p: model.addVar(vtype=GRB.CONTINUOUS, lb=0.0, name=f"x_{p}") for p in products}
    y_setup = {p: model.addVar(vtype=GRB.BINARY, name=f"y_setup_{p}") for p in products}
    overtime = model.addVar(vtype=GRB.CONTINUOUS, lb=0.0, ub=max_overtime, name="overtime")
    y_overtime_review = model.addVar(vtype=GRB.BINARY, name="y_overtime_review")
    y_A_line_audit = model.addVar(vtype=GRB.BINARY, name="y_A_line_audit")

    # Tight big-M values from resource limits
    big_m = {}
    for p in products:
        bounds = []
        if steel_req[p] > 0:
            bounds.append(available_steel / steel_req[p])
        if aluminum_req[p] > 0:
            bounds.append(available_aluminum / aluminum_req[p])
        if labor_req[p] > 0:
            bounds.append((available_labor + max_overtime) / labor_req[p])
        big_m[p] = min(bounds) if bounds else 0.0

    # Resource constraints
    model.addConstr(gp.quicksum(steel_req[p] * x[p] for p in products) <= available_steel, name="steel")
    model.addConstr(gp.quicksum(aluminum_req[p] * x[p] for p in products) <= available_aluminum, name="aluminum")
    model.addConstr(gp.quicksum(labor_req[p] * x[p] for p in products) <= available_labor + overtime, name="labor_with_overtime")

    # Setup activation constraints
    for p in products:
        model.addConstr(x[p] <= big_m[p] * y_setup[p], name=f"setup_link_{p}")

    # Overtime review gate: fee applies only if overtime exceeds threshold
    model.addConstr(overtime <= overtime_review_threshold + (max_overtime - overtime_review_threshold) * y_overtime_review,
                    name="overtime_review_trigger")

    # Product A line audit gate: fee applies only if A production exceeds threshold
    if "A" in x:
        model.addConstr(
            x["A"] <= product_A_line_audit_threshold + (big_m["A"] - product_A_line_audit_threshold) * y_A_line_audit,
            name="A_line_audit_trigger"
        )

    # Objective: profit - setup costs - overtime variable cost - fixed review/audit fees
    obj = (
        gp.quicksum(profit[p] * x[p] - setup_cost[p] * y_setup[p] for p in products)
        - overtime_pay * overtime
        - overtime_review_fee * y_overtime_review
        - product_A_line_audit_fee * y_A_line_audit
    )
    model.setObjective(obj, GRB.MAXIMIZE)

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
