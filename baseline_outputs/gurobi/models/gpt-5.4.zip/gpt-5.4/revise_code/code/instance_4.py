import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_parameters(data_path)

    cow_price = params["cow_selling_price"]
    sheep_price = params["sheep_selling_price"]
    chicken_price = params["chicken_selling_price"]

    cow_feed = params["cow_feed_cost"]
    sheep_feed = params["sheep_feed_cost"]
    chicken_feed = params["chicken_feed_cost"]

    cow_manure = params["cow_manure_production"]
    sheep_manure = params["sheep_manure_production"]
    chicken_manure = params["chicken_manure_production"]

    max_manure = params["max_manure_capacity"]
    max_chickens = params["max_chickens"]
    min_cows = params["min_cows"]
    min_sheep = params["min_sheep"]
    max_total = params["max_total_animals"]

    premium_capacity_multiplier = params["premium_capacity_multiplier"]
    premium_manure_multiplier = params["premium_manure_multiplier"]
    expansion_cost = params["expansion_cost"]
    premium_feed_multiplier = params["premium_feed_multiplier"]

    land_cow = params["base_land_usage_cow"]
    land_sheep = params["base_land_usage_sheep"]
    land_chicken = params["base_land_usage_chicken"]
    base_land_capacity = params["base_land_capacity"]
    expansion_land_increase = params["expansion_land_increase"]

    m = gp.Model("revised_farm_profit")
    m.setParam("OutputFlag", 0)

    expanded = m.addVar(vtype=GRB.BINARY, name="expanded")

    cows_regular = m.addVar(vtype=GRB.INTEGER, lb=0, name="cows_regular")
    sheep_regular = m.addVar(vtype=GRB.INTEGER, lb=0, name="sheep_regular")
    chickens_regular = m.addVar(vtype=GRB.INTEGER, lb=0, name="chickens_regular")

    cows_premium = m.addVar(vtype=GRB.INTEGER, lb=0, name="cows_premium")
    sheep_premium = m.addVar(vtype=GRB.INTEGER, lb=0, name="sheep_premium")
    chickens_premium = m.addVar(vtype=GRB.INTEGER, lb=0, name="chickens_premium")

    total_cows = cows_regular + cows_premium
    total_sheep = sheep_regular + sheep_premium
    total_chickens = chickens_regular + chickens_premium
    total_animals = total_cows + total_sheep + total_chickens

    m.addConstr(total_cows >= min_cows, name="min_cows")
    m.addConstr(total_sheep >= min_sheep, name="min_sheep")
    m.addConstr(total_chickens <= max_chickens, name="max_chickens")

    m.addConstr(
        total_animals <= max_total + (premium_capacity_multiplier - 1.0) * max_total * expanded,
        name="capacity_animals"
    )

    m.addConstr(
        cow_manure * total_cows + sheep_manure * total_sheep + chicken_manure * total_chickens
        <= max_manure + (premium_manure_multiplier - 1.0) * max_manure * expanded,
        name="capacity_manure"
    )

    m.addConstr(
        land_cow * total_cows + land_sheep * total_sheep + land_chicken * total_chickens
        <= base_land_capacity + expansion_land_increase * expanded,
        name="capacity_land"
    )

    big_m_animals = int(max_total * premium_capacity_multiplier)
    m.addConstr(cows_premium <= big_m_animals * expanded, name="premium_cows_gate")
    m.addConstr(sheep_premium <= big_m_animals * expanded, name="premium_sheep_gate")
    m.addConstr(chickens_premium <= max_chickens * expanded, name="premium_chickens_gate")

    regular_profit = (
        (cow_price - cow_feed) * cows_regular +
        (sheep_price - sheep_feed) * sheep_regular +
        (chicken_price - chicken_feed) * chickens_regular
    )

    premium_profit = (
        (cow_price - premium_feed_multiplier * cow_feed) * cows_premium +
        (sheep_price - premium_feed_multiplier * sheep_feed) * sheep_premium +
        (chicken_price - premium_feed_multiplier * chicken_feed) * chickens_premium
    )

    m.setObjective(regular_profit + premium_profit - expansion_cost * expanded, GRB.MAXIMIZE)

    m.optimize()

    obj = m.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj}")


if __name__ == "__main__":
    main()
