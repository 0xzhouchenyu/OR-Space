import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_parameters():
    data_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "data",
        "general_parameters.csv"
    )
    params = {}
    with open(data_path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def main():
    params = read_parameters()

    profit_corn = params["profit_per_acre_corn"]
    profit_wheat = params["profit_per_acre_wheat"]
    profit_soybeans = params["profit_per_acre_soybeans"]
    profit_sorghum = params["profit_per_acre_sorghum"]
    total_area = params["total_farm_area"]
    corn_wheat_ratio = params["corn_wheat_ratio"]
    soybeans_sorghum_ratio = params["soybeans_sorghum_ratio"]
    wheat_sorghum_ratio = params["wheat_sorghum_ratio"]

    m = gp.Model("revised_farm_optimization")
    m.setParam("OutputFlag", 0)

    corn = m.addVar(lb=0.0, name="corn")
    wheat = m.addVar(lb=0.0, name="wheat")
    soybeans = m.addVar(lb=0.0, name="soybeans")
    sorghum = m.addVar(lb=0.0, name="sorghum")

    y_corn_program = m.addVar(vtype=GRB.BINARY, name="y_corn_program")
    y_soy_program = m.addVar(vtype=GRB.BINARY, name="y_soy_program")

    m.setObjective(
        profit_corn * corn +
        profit_wheat * wheat +
        profit_soybeans * soybeans +
        profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )

    m.addConstr(corn + wheat + soybeans + sorghum <= total_area, name="total_area")
    m.addConstr(corn >= corn_wheat_ratio * wheat, name="corn_wheat_ratio")
    m.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, name="soybeans_sorghum_ratio")
    m.addConstr(wheat == wheat_sorghum_ratio * sorghum, name="wheat_sorghum_ratio")

    m.addConstr(corn >= 20, name="min_corn")

    m.addConstr(y_corn_program + y_soy_program == 1, name="program_choice")
    m.addConstr(corn <= total_area * y_corn_program, name="corn_if_selected")
    m.addConstr(soybeans <= total_area * y_soy_program, name="soybeans_if_selected")

    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == "__main__":
    main()
