import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load monthly prices
months = []
purchase_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        m = int(row["Month"])
        months.append(m)
        purchase_prices[m] = float(row["Purchase_Price_yuan_per_dan"])
        selling_prices[m] = float(row["Selling_Price_yuan_per_dan"])

months.sort()

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

warehouse_capacity = params["warehouse_capacity"]
initial_stock = params["initial_stock"]
initial_funds = params["initial_funds"]
end_inventory = params["end_of_quarter_inventory"]
buy_fast_capacity = params["buy_fast_capacity"]
fast_purchase_premium_ratio = params["fast_purchase_premium_ratio"]
credit_limit = params["credit_limit"]
monthly_interest_rate = params["monthly_interest_rate"]

min_inventory = {}
for m in months:
    key = f"min_inventory_month_{m}"
    min_inventory[m] = params[key]

# Build model
model = gp.Model("Revised_Grain_Trading")
model.setParam("OutputFlag", 0)

buy_regular = model.addVars(months, lb=0.0, name="buy_regular")
buy_fast = model.addVars(months, lb=0.0, name="buy_fast")
sell = model.addVars(months, lb=0.0, name="sell")
stock = model.addVars(months, lb=0.0, name="stock")
funds = model.addVars(months, lb=0.0, name="funds")
credit_used = model.addVars(months, lb=0.0, ub=credit_limit, name="credit_used")
interest = model.addVars(months, lb=0.0, name="interest")

for m in months:
    prev_stock = initial_stock if m == months[0] else stock[m - 1]
    prev_funds_plus_credit = initial_funds if m == months[0] else (funds[m - 1] + credit_used[m - 1])

    regular_cost = buy_regular[m] * purchase_prices[m]
    fast_cost = buy_fast[m] * purchase_prices[m] * (1.0 + fast_purchase_premium_ratio)

    # Inventory balance
    model.addConstr(
        stock[m] == prev_stock - sell[m] + buy_regular[m] + buy_fast[m],
        name=f"stock_balance_{m}"
    )

    # Sales can only come from previous month's ending stock
    model.addConstr(sell[m] <= prev_stock, name=f"sell_limit_{m}")

    # Warehouse capacity and minimum inventory
    model.addConstr(stock[m] <= warehouse_capacity, name=f"warehouse_capacity_{m}")
    model.addConstr(stock[m] >= min_inventory[m], name=f"min_inventory_{m}")

    # Fast purchase capacity
    model.addConstr(buy_fast[m] <= buy_fast_capacity, name=f"fast_capacity_{m}")

    # Interest definition
    model.addConstr(
        interest[m] == monthly_interest_rate * credit_used[m],
        name=f"interest_def_{m}"
    )

    # Funds/credit flow balance:
    # end liquidity (funds + credit) = previous liquidity + sales - purchases - interest
    model.addConstr(
        funds[m] + credit_used[m] == prev_funds_plus_credit + sell[m] * selling_prices[m] - regular_cost - fast_cost - interest[m],
        name=f"liquidity_balance_{m}"
    )

# End-of-quarter inventory requirement
model.addConstr(stock[months[-1]] >= end_inventory, name="end_inventory_requirement")

# Objective: (funds_3 - initial_funds) - total interest
model.setObjective(
    funds[months[-1]] - initial_funds - gp.quicksum(interest[m] for m in months),
    GRB.MAXIMIZE
)

model.optimize()

obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
print(f"FINAL_OBJ_VALUE: {obj_val}")
