import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB


def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)


def read_orders():
    path = get_data_path("table_1.csv")
    orders = []
    with open(path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                "order_number": row["Order_Number"],
                "width": float(row["Width_meters"]),
                "length": float(row["Length_meters"]),
            })
    return orders


def read_parameters():
    path = get_data_path("general_parameters.csv")
    params = {}
    with open(path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    return params


def generate_patterns(order_widths, standard_width):
    patterns = []
    n = len(order_widths)

    def rec(i, current, used_width):
        if i == n:
            if any(v > 0 for v in current):
                patterns.append(tuple(current))
            return
        max_count = int(math.floor((standard_width - used_width + 1e-9) / order_widths[i]))
        for cnt in range(max_count + 1):
            current.append(cnt)
            rec(i + 1, current, used_width + cnt * order_widths[i])
            current.pop()

    rec(0, [], 0.0)
    return patterns


def main():
    orders = read_orders()
    params = read_parameters()

    widths = [o["width"] for o in orders]
    lengths = [o["length"] for o in orders]

    standard_widths = []
    for k, v in params.items():
        if k.startswith("standard_width_"):
            standard_widths.append(v)
    standard_widths.sort()

    pattern_setup_penalty = params["pattern_setup_penalty"]
    wide_roll_threshold_width = params["wide_roll_threshold_width"]
    wide_roll_extra_setup_penalty = params["wide_roll_extra_setup_penalty"]

    patterns_by_sw = {}
    for s_idx, sw in enumerate(standard_widths):
        patterns = generate_patterns(widths, sw)
        patterns_by_sw[s_idx] = {
            "standard_width": sw,
            "patterns": patterns
        }

    model = gp.Model("revised_paper_cutting")
    model.setParam("OutputFlag", 0)

    x = {}
    y = {}

    for s_idx, data in patterns_by_sw.items():
        sw = data["standard_width"]
        for p_idx, pattern in enumerate(data["patterns"]):
            x[s_idx, p_idx] = model.addVar(vtype=GRB.CONTINUOUS, lb=0.0, name=f"x_{s_idx}_{p_idx}")
            y[s_idx, p_idx] = model.addVar(vtype=GRB.BINARY, name=f"y_{s_idx}_{p_idx}")

    # Demand satisfaction by order length
    for j in range(len(orders)):
        model.addConstr(
            gp.quicksum(
                patterns_by_sw[s_idx]["patterns"][p_idx][j] * x[s_idx, p_idx]
                for s_idx in patterns_by_sw
                for p_idx in range(len(patterns_by_sw[s_idx]["patterns"]))
            ) >= lengths[j],
            name=f"demand_{j}"
        )

    # Link usage variable to whether a pattern is used
    # Tight big-M: no pattern needs more than max(length demand)
    big_m = max(lengths) if lengths else 0.0
    for s_idx, data in patterns_by_sw.items():
        for p_idx in range(len(data["patterns"])):
            model.addConstr(x[s_idx, p_idx] <= big_m * y[s_idx, p_idx], name=f"link_{s_idx}_{p_idx}")

    total_required_area = sum(widths[j] * lengths[j] for j in range(len(orders)))

    obj = gp.LinExpr()
    for s_idx, data in patterns_by_sw.items():
        sw = data["standard_width"]
        extra_penalty = wide_roll_extra_setup_penalty if sw >= wide_roll_threshold_width else 0.0
        setup_cost = pattern_setup_penalty + extra_penalty
        for p_idx in range(len(data["patterns"])):
            obj += sw * x[s_idx, p_idx]
            obj += setup_cost * y[s_idx, p_idx]

    # Minimize waste = total used area + setup-equivalent waste - required area
    model.setObjective(obj - total_required_area, GRB.MINIMIZE)

    model.optimize()

    final_obj = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {final_obj}")


if __name__ == "__main__":
    main()
