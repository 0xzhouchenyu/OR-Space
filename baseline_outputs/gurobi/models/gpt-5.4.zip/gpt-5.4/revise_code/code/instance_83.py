import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Read demand data
time_periods = []
demand = []
with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        time_periods.append(row["Time"].strip())
        demand.append(int(float(row["Minimum_Number_of_Waiters_Needed"])))

n = len(time_periods)

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"])

work_hours = int(params["waiter_work_hours"])
shift_periods = work_hours // 4
waiter_cost_per_shift = params["waiter_cost_per_shift"]
waiter_budget = params["waiter_budget"]

peak = [int(params[f"peak_{i}"]) for i in range(n)]
quality = [params[f"quality_{i}"] for i in range(n)]

# Feasible shift starts: each 8-hour shift covers two adjacent 4-hour periods,
# and must include exactly one peak period and one off-peak period.
feasible_starts = []
for i in range(n):
    j = (i + 1) % n
    if peak[i] + peak[j] == 1:
        feasible_starts.append(i)

# Build optimization model
model = gp.Model("revised_restaurant_waiter_scheduling")
model.setParam("OutputFlag", 0)

# First-stage decision variables: same schedule across all cases in the data pack
x = {i: model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}") for i in feasible_starts}

# Coverage constraints for each 4-hour period
for j in range(n):
    covering_starts = [i for i in feasible_starts if i == j or (i + 1) % n == j]
    model.addConstr(gp.quicksum(x[i] for i in covering_starts) >= demand[j], name=f"coverage_{j}")

# Budget constraint
model.addConstr(
    waiter_cost_per_shift * gp.quicksum(x[i] for i in feasible_starts) <= waiter_budget,
    name="budget"
)

# Objective: maximize service_quality_score
# Quality is earned from the staffed coverage in each period
service_quality = gp.quicksum(
    quality[j] * gp.quicksum(
        x[i] for i in feasible_starts if i == j or (i + 1) % n == j
    )
    for j in range(n)
)

model.setObjective(service_quality, GRB.MAXIMIZE)
model.optimize()

obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
if abs(obj_val - round(obj_val)) < 1e-9:
    obj_str = str(int(round(obj_val)))
else:
    obj_str = str(obj_val)

print(f"FINAL_OBJ_VALUE: {obj_str}")
