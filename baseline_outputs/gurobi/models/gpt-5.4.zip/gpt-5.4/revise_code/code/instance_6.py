import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_general_parameters(base_dir):
    params = {}
    path = os.path.join(base_dir, "data", "general_parameters.csv")
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"])
    return params


def load_demand(base_dir):
    demand = {}
    path = os.path.join(base_dir, "data", "table_1.csv")
    with open(path, "r", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        quarters = [int(x.strip()) for x in header[1:]]
        for row in reader:
            p = row[0].strip()
            for j, q in enumerate(quarters):
                demand[(p, q)] = float(row[j + 1])
    return demand, quarters


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    params = load_general_parameters(base_dir)
    demand, quarters = load_demand(base_dir)

    products = ["I", "II", "III"]

    init_inv = params["initial_inventory"]
    end_inv_req = params["end_inventory_requirement"]
    total_hours_per_quarter = params["production_hours_per_quarter"]
    inv_cost = params["inventory_cost_per_unit"]

    hours_per_unit = {
        "I": params["product_I_hours_per_unit"],
        "II": params["product_II_hours_per_unit"],
        "III": params["product_III_hours_per_unit"],
    }

    delay_penalty = {
        "I": params["delay_penalty_product_I"],
        "II": params["delay_penalty_product_II"],
        "III": params["delay_penalty_product_III"],
    }

    normal_hours_cap = {
        q: params[f"normal_hours_cap_fraction_q{q}"] * total_hours_per_quarter
        for q in quarters
    }

    peak_hours_cap = {
        q: params[f"peak_hours_cap_q{q}"]
        for q in quarters
    }

    peak_cost_per_hour = {
        q: params[f"peak_cost_per_hour_q{q}"]
        for q in quarters
    }

    m = gp.Model("revised_production_scheduling")
    m.setParam("OutputFlag", 0)

    # Production split by normal and peak hours
    x_norm = m.addVars(products, quarters, vtype=GRB.INTEGER, lb=0, name="x_norm")
    x_peak = m.addVars(products, quarters, vtype=GRB.INTEGER, lb=0, name="x_peak")

    # Inventory / backlog representation
    inv = m.addVars(products, quarters, vtype=GRB.CONTINUOUS, lb=-GRB.INFINITY, name="inv")
    inv_pos = m.addVars(products, quarters, vtype=GRB.CONTINUOUS, lb=0, name="inv_pos")
    inv_neg = m.addVars(products, quarters, vtype=GRB.CONTINUOUS, lb=0, name="inv_neg")

    # Hour usage
    normal_hours_used = m.addVars(quarters, vtype=GRB.CONTINUOUS, lb=0, name="normal_hours_used")
    peak_hours_used = m.addVars(quarters, vtype=GRB.CONTINUOUS, lb=0, name="peak_hours_used")

    # Product I cannot be produced in Q2 in either normal or peak hours
    x_norm["I", 2].ub = 0
    x_peak["I", 2].ub = 0

    # Inventory balance
    for p in products:
        m.addConstr(
            inv[p, 1] == init_inv + x_norm[p, 1] + x_peak[p, 1] - demand[p, 1],
            name=f"inv_balance_{p}_1"
        )
        for t in quarters[1:]:
            m.addConstr(
                inv[p, t] == inv[p, t - 1] + x_norm[p, t] + x_peak[p, t] - demand[p, t],
                name=f"inv_balance_{p}_{t}"
            )

    # Split inventory into positive and negative parts
    for p in products:
        for t in quarters:
            m.addConstr(inv[p, t] == inv_pos[p, t] - inv_neg[p, t], name=f"split_inv_{p}_{t}")

    # Ending inventory requirement
    for p in products:
        m.addConstr(inv[p, 4] >= end_inv_req, name=f"end_inventory_{p}")

    # Normal and peak hour accounting and caps
    for t in quarters:
        m.addConstr(
            normal_hours_used[t] == gp.quicksum(hours_per_unit[p] * x_norm[p, t] for p in products),
            name=f"normal_hours_def_{t}"
        )
        m.addConstr(
            peak_hours_used[t] == gp.quicksum(hours_per_unit[p] * x_peak[p, t] for p in products),
            name=f"peak_hours_def_{t}"
        )
        m.addConstr(normal_hours_used[t] <= normal_hours_cap[t], name=f"normal_cap_{t}")
        m.addConstr(peak_hours_used[t] <= peak_hours_cap[t], name=f"peak_cap_{t}")

    # Objective: inventory holding + delay penalties + peak-hour costs
    obj = (
        gp.quicksum(
            delay_penalty[p] * inv_neg[p, t] + inv_cost * inv_pos[p, t]
            for p in products for t in quarters
        )
        + gp.quicksum(
            peak_cost_per_hour[t] * peak_hours_used[t]
            for t in quarters
        )
    )

    m.setObjective(obj, GRB.MINIMIZE)
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")


if __name__ == "__main__":
    main()
