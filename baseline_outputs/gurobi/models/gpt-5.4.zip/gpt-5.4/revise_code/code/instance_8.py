import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_general_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            value_str = row["Value"].strip()
            try:
                value = float(value_str)
                if value.is_integer():
                    value = int(value)
            except ValueError:
                value = value_str
            params[name] = value
    return params

def read_worker_task_data(filepath):
    workers = []
    tasks = []
    cost = {}
    fixed_cost = {}

    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        tasks = [c for c in fieldnames if c not in ("Worker", "Fixed_Cost")]

        for row in reader:
            w = row["Worker"].strip()
            workers.append(w)
            fixed_cost[w] = float(row["Fixed_Cost"])
            if fixed_cost[w].is_integer():
                fixed_cost[w] = int(fixed_cost[w])
            for t in tasks:
                c = float(row[t])
                if c.is_integer():
                    c = int(c)
                cost[(w, t)] = c

    return workers, tasks, cost, fixed_cost

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = read_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    workers, tasks, assign_cost, fixed_cost = read_worker_task_data(os.path.join(data_dir, "table_1.csv"))

    shared_temp_handoff_cost = params.get("shared_temp_handoff_cost", 0)
    worker_II_V_pair_fee = params.get("worker_II_V_pair_fee", 0)

    model = gp.Model("revised_assignment")
    model.setParam("OutputFlag", 0)

    x = model.addVars(workers, tasks, vtype=GRB.BINARY, name="x")
    y = model.addVars(workers, vtype=GRB.BINARY, name="y")

    z_III_V = model.addVar(vtype=GRB.BINARY, name="z_III_V")
    z_II_V = model.addVar(vtype=GRB.BINARY, name="z_II_V")

    for t in tasks:
        model.addConstr(gp.quicksum(x[w, t] for w in workers) == 1, name=f"task_{t}")

    for w in workers:
        model.addConstr(gp.quicksum(x[w, t] for t in tasks) == y[w], name=f"worker_assign_{w}")

    model.addConstr(gp.quicksum(y[w] for w in workers) == len(tasks), name="select_four_workers")

    if "III" in workers and "V" in workers:
        model.addConstr(z_III_V <= y["III"], name="z_III_V_le_III")
        model.addConstr(z_III_V <= y["V"], name="z_III_V_le_V")
        model.addConstr(z_III_V >= y["III"] + y["V"] - 1, name="z_III_V_ge")
    else:
        model.addConstr(z_III_V == 0, name="z_III_V_zero")

    if "II" in workers and "V" in workers:
        model.addConstr(z_II_V <= y["II"], name="z_II_V_le_II")
        model.addConstr(z_II_V <= y["V"], name="z_II_V_le_V")
        model.addConstr(z_II_V >= y["II"] + y["V"] - 1, name="z_II_V_ge")
    else:
        model.addConstr(z_II_V == 0, name="z_II_V_zero")

    model.setObjective(
        gp.quicksum(assign_cost[w, t] * x[w, t] for w in workers for t in tasks)
        + gp.quicksum(fixed_cost[w] * y[w] for w in workers)
        + shared_temp_handoff_cost * z_III_V
        + worker_II_V_pair_fee * z_II_V,
        GRB.MINIMIZE
    )

    model.optimize()

    obj = model.ObjVal
    if abs(obj - round(obj)) < 1e-9:
        obj_str = str(int(round(obj)))
    else:
        obj_str = str(obj)

    print(f"FINAL_OBJ_VALUE: {obj_str}")

if __name__ == "__main__":
    main()
