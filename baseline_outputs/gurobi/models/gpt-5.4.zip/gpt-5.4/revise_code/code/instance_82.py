import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_general_parameters(base_dir):
    params = {}
    path = os.path.join(base_dir, "data", "general_parameters.csv")
    with open(path, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def read_store_data(base_dir):
    stores = []
    path = os.path.join(base_dir, "data", "table_1.csv")
    with open(path, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            profits = {}
            for k in [1, 2, 3]:
                col = "Profit_1_Store" if k == 1 else f"Profit_{k}_Stores"
                val = row.get(col, "").strip()
                if val and val != "-":
                    profits[k] = float(val)
            stores.append({
                "code": int(row["Code"].strip()),
                "name": row["Store_Type"].strip(),
                "area": float(row["Area_per_Shop_m2"].strip()),
                "min": int(row["Min"].strip()),
                "max": int(row["Max"].strip()),
                "profits": profits
            })
    return stores

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    params = read_general_parameters(base_dir)
    stores = read_store_data(base_dir)

    total_space = params["mall_total_space"]
    rent_pct = params["rent_percentage"] / 100.0
    common_area_factor = params["common_area_factor"]
    gm_third_concession = params["general_merchandise_third_store_concession"]
    catering_security_threshold = int(params["catering_third_store_security_threshold"])
    catering_third_security_cost = params["catering_third_store_security_cost"]

    model = gp.Model("mall_leasing_revised")
    model.setParam("OutputFlag", 0)

    y = {}
    x = {}

    for s in stores:
        feasible_levels = [0] if s["min"] == 0 else []
        for n in range(max(s["min"], 1), s["max"] + 1):
            if n in s["profits"]:
                feasible_levels.append(n)

        y[s["name"]] = {}
        for n in feasible_levels:
            y[s["name"]][n] = model.addVar(vtype=GRB.BINARY, name=f"y_{s['name']}_{n}")

        x[s["name"]] = model.addVar(vtype=GRB.INTEGER, lb=0, ub=s["max"], name=f"x_{s['name']}")

        model.addConstr(gp.quicksum(y[s["name"]][n] for n in feasible_levels) == 1,
                        name=f"choose_one_{s['name']}")
        model.addConstr(x[s["name"]] == gp.quicksum(n * y[s["name"]][n] for n in feasible_levels),
                        name=f"link_x_{s['name']}")

    model.addConstr(
        gp.quicksum(common_area_factor * s["area"] * x[s["name"]] for s in stores) <= total_space,
        name="total_effective_space"
    )

    rent_income_expr = gp.quicksum(
        rent_pct * n * s["profits"][n] * y[s["name"]][n]
        for s in stores
        for n in y[s["name"]]
        if n > 0
    )

    gm_name = "General_Merchandise"
    catering_name = "Catering"

    concession_expr = 0
    if gm_name in y and 3 in y[gm_name]:
        concession_expr += gm_third_concession * y[gm_name][3]

    security_expr = 0
    if catering_name in y and (catering_security_threshold + 1) in y[catering_name]:
        security_expr += catering_third_security_cost * y[catering_name][catering_security_threshold + 1]

    model.setObjective(rent_income_expr - concession_expr - security_expr, GRB.MAXIMIZE)

    model.optimize()

    obj_val = model.ObjVal if model.SolCount > 0 else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
