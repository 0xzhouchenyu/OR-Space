import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_bandwidth_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "table_1.csv")

    with open(filepath, "r", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]

        bandwidth = {}
        for row in reader:
            i = row[0].strip()
            for j, val in enumerate(row[1:]):
                k = nodes[j]
                bw = int(val.strip())
                bandwidth[(i, k)] = bw

    return nodes, bandwidth

def main():
    nodes, bandwidth = load_bandwidth_data()

    source = "A"
    service = "C"
    target = "E"

    arcs = []
    cost = {}
    for i in nodes:
        for j in nodes:
            if i != j and bandwidth.get((i, j), 0) > 0:
                arcs.append((i, j))
                cost[(i, j)] = 100 - bandwidth[(i, j)]

    m = gp.Model("routing_cost_via_C")
    m.setParam("OutputFlag", 0)

    x = m.addVars(arcs, vtype=GRB.BINARY, name="x")
    y = m.addVars(nodes, vtype=GRB.BINARY, name="y")

    m.setObjective(gp.quicksum(cost[a] * x[a] for a in arcs), GRB.MINIMIZE)

    # Source and target must be on the path
    m.addConstr(y[source] == 1, name="use_source")
    m.addConstr(y[service] == 1, name="use_service")
    m.addConstr(y[target] == 1, name="use_target")

    for n in nodes:
        in_expr = gp.quicksum(x[i, j] for (i, j) in arcs if j == n)
        out_expr = gp.quicksum(x[i, j] for (i, j) in arcs if i == n)

        if n == source:
            m.addConstr(out_expr - in_expr == 1, name=f"flow_{n}")
            m.addConstr(in_expr == 0, name=f"in_deg_{n}")
            m.addConstr(out_expr == 1, name=f"out_deg_{n}")
        elif n == target:
            m.addConstr(in_expr - out_expr == 1, name=f"flow_{n}")
            m.addConstr(in_expr == 1, name=f"in_deg_{n}")
            m.addConstr(out_expr == 0, name=f"out_deg_{n}")
        else:
            m.addConstr(in_expr == y[n], name=f"in_deg_{n}")
            m.addConstr(out_expr == y[n], name=f"out_deg_{n}")

    # Enforce service node C to be on the path
    m.addConstr(gp.quicksum(x[i, j] for (i, j) in arcs if j == service) == 1, name="service_in")
    m.addConstr(gp.quicksum(x[i, j] for (i, j) in arcs if i == service) == 1, name="service_out")

    # MTZ subtour elimination for a simple path
    u = m.addVars(nodes, lb=0, ub=len(nodes) - 1, vtype=GRB.CONTINUOUS, name="u")
    m.addConstr(u[source] == 0, name="order_source")
    for n in nodes:
        if n != source:
            m.addConstr(u[n] >= y[n], name=f"order_lb_{n}")
            m.addConstr(u[n] <= (len(nodes) - 1) * y[n], name=f"order_ub_{n}")

    M = len(nodes)
    for i, j in arcs:
        if i != source and j != source:
            m.addConstr(u[j] >= u[i] + 1 - M * (1 - x[i, j]), name=f"mtz_{i}_{j}")

    m.optimize()

    obj = m.ObjVal
    if abs(obj - round(obj)) < 1e-6:
        obj_str = str(int(round(obj)))
    else:
        obj_str = str(obj)

    print(f"FINAL_OBJ_VALUE: {obj_str}")

if __name__ == "__main__":
    main()
