import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_feed_data(filepath):
    feeds = []
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            feeds.append({
                "Feed": int(row["Feed"]),
                "Protein_g": float(row["Protein_g"]),
                "Minerals_g": float(row["Minerals_g"]),
                "Vitamins_mg": float(row["Vitamins_mg"]),
                "Price_Y_per_kg": float(row["Price_Y_per_kg"]),
            })
    return feeds


def load_general_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    return params


base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

feeds = load_feed_data(os.path.join(data_dir, "table_1.csv"))
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

min_protein = params["min_protein_requirement"]
min_minerals = params["min_minerals_requirement"]
min_vitamins = params["min_vitamins_requirement"]

feed_ids = [f["Feed"] for f in feeds]
feed_data = {f["Feed"]: f for f in feeds}

model = gp.Model("RevisedFeedMix")
model.setParam("OutputFlag", 0)

x = {i: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{i}") for i in feed_ids}

# Binary indicators for mutual exclusion between Feed 4 and Feed 5
y4 = model.addVar(vtype=GRB.BINARY, name="y_4_used")
y5 = model.addVar(vtype=GRB.BINARY, name="y_5_used")

model.setObjective(
    gp.quicksum(feed_data[i]["Price_Y_per_kg"] * x[i] for i in feed_ids),
    GRB.MINIMIZE
)

model.addConstr(
    gp.quicksum(feed_data[i]["Protein_g"] * x[i] for i in feed_ids) >= min_protein,
    name="ProteinRequirement"
)
model.addConstr(
    gp.quicksum(feed_data[i]["Minerals_g"] * x[i] for i in feed_ids) >= min_minerals,
    name="MineralsRequirement"
)
model.addConstr(
    gp.quicksum(feed_data[i]["Vitamins_mg"] * x[i] for i in feed_ids) >= min_vitamins,
    name="VitaminsRequirement"
)

# Big-M bounds for feed usage activation
# Safe upper bounds based on satisfying each requirement with a single feed
M4 = max(
    min_protein / feed_data[4]["Protein_g"] if feed_data[4]["Protein_g"] > 0 else 0,
    min_minerals / feed_data[4]["Minerals_g"] if feed_data[4]["Minerals_g"] > 0 else 0,
    min_vitamins / feed_data[4]["Vitamins_mg"] if feed_data[4]["Vitamins_mg"] > 0 else 0,
)
M5 = max(
    min_protein / feed_data[5]["Protein_g"] if feed_data[5]["Protein_g"] > 0 else 0,
    min_minerals / feed_data[5]["Minerals_g"] if feed_data[5]["Minerals_g"] > 0 else 0,
    min_vitamins / feed_data[5]["Vitamins_mg"] if feed_data[5]["Vitamins_mg"] > 0 else 0,
)

model.addConstr(x[4] <= M4 * y4, name="ActivateFeed4")
model.addConstr(x[5] <= M5 * y5, name="ActivateFeed5")
model.addConstr(y4 + y5 <= 1, name="MutualExclusion_4_5")

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
