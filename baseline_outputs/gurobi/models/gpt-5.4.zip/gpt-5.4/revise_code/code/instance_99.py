import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters():
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    return params

def load_reliability_table():
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    reliability = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            n = int(row["Number_of_Spares"])
            reliability[n] = (
                float(row["Component_1_Reliability"]),
                float(row["Component_2_Reliability"]),
                float(row["Component_3_Reliability"]),
            )
    return reliability

def main():
    params = load_general_parameters()
    reliability = load_reliability_table()

    spare_levels = sorted(reliability.keys())

    unit_price = {
        1: params["unit_price_component_1"],
        2: params["unit_price_component_2"],
        3: params["unit_price_component_3"],
    }
    unit_weight = {
        1: params["unit_weight_component_1"],
        2: params["unit_weight_component_2"],
        3: params["unit_weight_component_3"],
    }

    budget_A = params["total_budget_scenario_A"]
    budget_B = params["total_budget_scenario_B"]
    weight_A = params["weight_limit_scenario_A"]
    weight_B = params["weight_limit_scenario_B"]

    budget_limit = min(budget_A, budget_B)
    weight_limit = min(weight_A, weight_B)

    R = {
        1: {n: reliability[n][0] for n in spare_levels},
        2: {n: reliability[n][1] for n in spare_levels},
        3: {n: reliability[n][2] for n in spare_levels},
    }

    model = gp.Model("revised_spare_parts")
    model.setParam("OutputFlag", 0)

    x = {}
    for i in [1, 2, 3]:
        for n in spare_levels:
            x[i, n] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{n}")

    for i in [1, 2, 3]:
        model.addConstr(gp.quicksum(x[i, n] for n in spare_levels) == 1, name=f"choose_one_{i}")

    total_cost = gp.quicksum(unit_price[i] * n * x[i, n] for i in [1, 2, 3] for n in spare_levels)
    total_weight = gp.quicksum(unit_weight[i] * n * x[i, n] for i in [1, 2, 3] for n in spare_levels)

    model.addConstr(total_cost <= budget_A, name="budget_A")
    model.addConstr(total_cost <= budget_B, name="budget_B")
    model.addConstr(total_weight <= weight_A, name="weight_A")
    model.addConstr(total_weight <= weight_B, name="weight_B")

    y = {}
    for n1 in spare_levels:
        for n2 in spare_levels:
            for n3 in spare_levels:
                y[n1, n2, n3] = model.addVar(vtype=GRB.BINARY, name=f"y_{n1}_{n2}_{n3}")

    model.addConstr(gp.quicksum(y[n1, n2, n3] for n1 in spare_levels for n2 in spare_levels for n3 in spare_levels) == 1,
                    name="choose_triplet")

    for n1 in spare_levels:
        model.addConstr(
            gp.quicksum(y[n1, n2, n3] for n2 in spare_levels for n3 in spare_levels) == x[1, n1],
            name=f"link1_{n1}"
        )
    for n2 in spare_levels:
        model.addConstr(
            gp.quicksum(y[n1, n2, n3] for n1 in spare_levels for n3 in spare_levels) == x[2, n2],
            name=f"link2_{n2}"
        )
    for n3 in spare_levels:
        model.addConstr(
            gp.quicksum(y[n1, n2, n3] for n1 in spare_levels for n2 in spare_levels) == x[3, n3],
            name=f"link3_{n3}"
        )

    expected_reliability = gp.quicksum(
        (0.5 * R[1][n1] * R[2][n2] * R[3][n3] + 0.5 * R[1][n1] * R[2][n2] * R[3][n3]) * y[n1, n2, n3]
        for n1 in spare_levels for n2 in spare_levels for n3 in spare_levels
    )

    model.setObjective(expected_reliability, GRB.MAXIMIZE)
    model.optimize()

    obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
