import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

initial_fund = params["initial_fund"]
annual_rate = params["annual_profit_rate"] / 100.0
inv_limit_y1 = params["investment_limit_year1"]
return_rate_y1y2 = params["return_rate_year1_to_year2"] / 100.0
inv_limit_y2 = params["investment_limit_year2"]
return_rate_y2y3 = params["return_rate_year2_to_year3"] / 100.0
inv_limit_y3 = params["investment_limit_year3"]
profit_rate_y3 = params["profit_rate_year3"] / 100.0
fee_y1 = params["fee_year1"]
fee_y2 = params["fee_year2"]
fee_y3 = params["fee_year3"]

m = gp.Model("revised_investment_optimization")
m.setParam("OutputFlag", 0)

a1 = m.addVar(lb=0.0, name="a1")
a2 = m.addVar(lb=0.0, name="a2")
a3 = m.addVar(lb=0.0, name="a3")

b1 = m.addVar(lb=0.0, ub=inv_limit_y1, name="b1")
c2 = m.addVar(lb=0.0, ub=inv_limit_y2, name="c2")
d3 = m.addVar(lb=0.0, ub=inv_limit_y3, name="d3")

y1 = m.addVar(vtype=GRB.BINARY, name="y1")
y2 = m.addVar(vtype=GRB.BINARY, name="y2")
y3 = m.addVar(vtype=GRB.BINARY, name="y3")

m.addConstr(b1 <= inv_limit_y1 * y1, name="link_b1_y1")
m.addConstr(c2 <= inv_limit_y2 * y2, name="link_c2_y2")
m.addConstr(d3 <= inv_limit_y3 * y3, name="link_d3_y3")

m.addConstr(a1 + b1 + fee_y1 * y1 <= initial_fund, name="year1_budget")

funds_y2 = initial_fund - a1 - b1 - fee_y1 * y1 + a1 * (1.0 + annual_rate)
m.addConstr(a2 + c2 + fee_y2 * y2 <= funds_y2, name="year2_budget")

funds_y3 = funds_y2 - a2 - c2 - fee_y2 * y2 + a2 * (1.0 + annual_rate) + b1 * return_rate_y1y2
m.addConstr(a3 + d3 + fee_y3 * y3 <= funds_y3, name="year3_budget")

cash_end_y3 = funds_y3 - a3 - d3 - fee_y3 * y3
total_end_y3 = cash_end_y3 + a3 * (1.0 + annual_rate) + c2 * return_rate_y2y3 + d3 * (1.0 + profit_rate_y3)

m.setObjective(total_end_y3, GRB.MAXIMIZE)
m.optimize()

obj_val = m.ObjVal if m.status == GRB.OPTIMAL else float("nan")
print(f"FINAL_OBJ_VALUE: {obj_val}")
