import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def main():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = load_parameters(data_path)

    min_A = params["min_raw_material_A"]
    min_B = params["min_raw_material_B"]
    min_C = params["min_raw_material_C"]

    cap_A_a = params["warehouse_A_truck_capacity_A"]
    cap_A_b = params["warehouse_A_truck_capacity_B"]
    cap_A_c = params["warehouse_A_truck_capacity_C"]
    cost_A = params["warehouse_A_truck_cost"]

    cap_B_a = params["warehouse_B_truck_capacity_A"]
    cap_B_b = params["warehouse_B_truck_capacity_B"]
    cap_B_c = params["warehouse_B_truck_capacity_C"]
    cost_B = params["warehouse_B_truck_cost"]

    fixed_A = params["warehouse_A_fixed_cost"]
    fixed_B = params["warehouse_B_fixed_cost"]
    overflow_threshold_B = params["warehouse_B_overflow_threshold_trucks"]
    overflow_cost_B = params["warehouse_B_overflow_coordination_cost"]
    dual_trigger = params["dual_warehouse_reconciliation_trigger"]
    dual_fee = params["dual_warehouse_reconciliation_fee"]

    model = gp.Model("RevisedFreightOptimization")
    model.setParam("OutputFlag", 0)

    x = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_A")
    y = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_B")

    use_A = model.addVar(vtype=GRB.BINARY, name="use_A")
    use_B = model.addVar(vtype=GRB.BINARY, name="use_B")
    overflow_B = model.addVar(vtype=GRB.BINARY, name="overflow_B")
    both_used = model.addVar(vtype=GRB.BINARY, name="both_used")

    bigM_A = int(max(
        (min_A + cap_A_a - 1) // cap_A_a if cap_A_a > 0 else 0,
        (min_B + cap_A_b - 1) // cap_A_b if cap_A_b > 0 else 0,
        (min_C + cap_A_c - 1) // cap_A_c if cap_A_c > 0 else 0
    ))
    bigM_B = int(max(
        (min_A + cap_B_a - 1) // cap_B_a if cap_B_a > 0 else 0,
        (min_B + cap_B_b - 1) // cap_B_b if cap_B_b > 0 else 0,
        (min_C + cap_B_c - 1) // cap_B_c if cap_B_c > 0 else 0
    ))

    model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, name="RawMaterialA")
    model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, name="RawMaterialB")
    model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, name="RawMaterialC")

    model.addConstr(x <= bigM_A * use_A, name="LinkUseA_Upper")
    model.addConstr(x >= use_A, name="LinkUseA_Lower")
    model.addConstr(y <= bigM_B * use_B, name="LinkUseB_Upper")
    model.addConstr(y >= use_B, name="LinkUseB_Lower")

    model.addConstr(y <= overflow_threshold_B + bigM_B * overflow_B, name="OverflowB_Trigger_Upper")
    model.addConstr(y >= (overflow_threshold_B + 1) * overflow_B, name="OverflowB_Trigger_Lower")

    model.addConstr(both_used <= use_A, name="BothUsed_LeA")
    model.addConstr(both_used <= use_B, name="BothUsed_LeB")
    model.addConstr(both_used >= use_A + use_B - 1, name="BothUsed_GeSumMinus1")

    model.setObjective(
        cost_A * x
        + cost_B * y
        + fixed_A * use_A
        + fixed_B * use_B
        + overflow_cost_B * overflow_B
        + dual_trigger * dual_fee * both_used,
        GRB.MINIMIZE
    )

    model.optimize()

    obj = model.ObjVal
    if abs(obj - round(obj)) < 1e-9:
        obj_str = str(int(round(obj)))
    else:
        obj_str = str(obj)

    print(f"FINAL_OBJ_VALUE: {obj_str}")


if __name__ == "__main__":
    main()
