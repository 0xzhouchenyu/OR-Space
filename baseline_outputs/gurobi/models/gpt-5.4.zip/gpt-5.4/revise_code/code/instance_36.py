import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB


def euclidean(p1, p2):
    return math.hypot(p1[0] - p2[0], p1[1] - p2[1])


def parse_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = row["Value"]
    return params


def parse_depot_coordinates(coord_str):
    s = coord_str.strip().strip('"').strip()
    s = s.strip("()")
    x_str, y_str = [v.strip() for v in s.split(",")]
    return float(x_str), float(y_str)


def main():
    root = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(root, "data")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    cust_path = os.path.join(data_dir, "table_1.csv")

    params = parse_parameters(params_path)

    truck_capacity = float(params["truck_capacity"])
    depot = parse_depot_coordinates(params["depot_coordinates"])
    depot_tw_start = float(params["depot_time_window_start"])
    depot_tw_end = float(params["depot_time_window_end"])
    inhouse_truck_limit = int(float(params["inhouse_truck_limit"]))

    customers = {}
    with open(cust_path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cid = int(row["Customer_ID"])
            customers[cid] = {
                "coord": (float(row["Coordinates_X"]), float(row["Coordinates_Y"])),
                "demand": float(row["Demand"]),
                "tw_start": float(row["Time_Window_Start"]),
                "tw_end": float(row["Time_Window_End"]),
                "service": float(row["Service_Duration"]),
                "outsource_cost": float(row["Outsource_Cost"]),
                "mandatory_external": int(row["Mandatory_External"]),
            }

    nodes = [0] + sorted(customers.keys())
    coords = {0: depot}
    demand = {0: 0.0}
    tw_start = {0: depot_tw_start}
    tw_end = {0: depot_tw_end}
    service = {0: 0.0}
    outsource_cost = {0: 0.0}
    mandatory_external = {0: 0}

    for i, data in customers.items():
        coords[i] = data["coord"]
        demand[i] = data["demand"]
        tw_start[i] = data["tw_start"]
        tw_end[i] = data["tw_end"]
        service[i] = data["service"]
        outsource_cost[i] = data["outsource_cost"]
        mandatory_external[i] = data["mandatory_external"]

    C = sorted(customers.keys())
    C_internal_eligible = [i for i in C if mandatory_external[i] == 0]

    dist = {}
    for i in nodes:
        for j in nodes:
            if i != j:
                dist[i, j] = euclidean(coords[i], coords[j])

    arcs = []
    for i in nodes:
        for j in nodes:
            if i == j:
                continue
            if j != 0:
                earliest_depart_i = tw_start[i] + service[i]
                if i == 0:
                    earliest_depart_i = tw_start[0]
                if earliest_depart_i + dist[i, j] > tw_end[j]:
                    continue
            if i != 0 and j == 0:
                if tw_start[i] + service[i] + dist[i, 0] > tw_end[0]:
                    continue
            arcs.append((i, j))

    m = gp.Model("Revised_VRPHTW_Outsourcing")
    m.setParam("OutputFlag", 0)

    x = m.addVars(arcs, vtype=GRB.BINARY, name="x")
    y = m.addVars(C, vtype=GRB.BINARY, name="y")  # 1 if outsourced
    t = m.addVars(nodes, lb=0.0, ub=depot_tw_end, vtype=GRB.CONTINUOUS, name="t")
    u = m.addVars(C_internal_eligible, lb=0.0, ub=truck_capacity, vtype=GRB.CONTINUOUS, name="u")

    m.setObjective(
        gp.quicksum(dist[i, j] * x[i, j] for (i, j) in arcs) +
        gp.quicksum(outsource_cost[i] * y[i] for i in C),
        GRB.MINIMIZE
    )

    for i in C:
        if mandatory_external[i] == 1:
            m.addConstr(y[i] == 1, name=f"mandatory_outsource_{i}")

    for i in C:
        in_expr = gp.quicksum(x[j, i] for j in nodes if j != i and (j, i) in x)
        out_expr = gp.quicksum(x[i, j] for j in nodes if j != i and (i, j) in x)
        m.addConstr(in_expr == 1 - y[i], name=f"in_degree_{i}")
        m.addConstr(out_expr == 1 - y[i], name=f"out_degree_{i}")

    depot_out = gp.quicksum(x[0, j] for j in C if (0, j) in x)
    depot_in = gp.quicksum(x[i, 0] for i in C if (i, 0) in x)
    m.addConstr(depot_out == depot_in, name="depot_balance")
    m.addConstr(depot_out <= inhouse_truck_limit, name="truck_limit")

    for i in nodes:
        m.addConstr(t[i] >= tw_start[i], name=f"tw_lb_{i}")
        m.addConstr(t[i] <= tw_end[i], name=f"tw_ub_{i}")

    m.addConstr(t[0] == depot_tw_start, name="depot_start_time")

    M_time = depot_tw_end + max(service.values()) + max(dist.values())

    for (i, j) in arcs:
        if j != 0:
            depart_i = t[i] + service[i]
            if i == 0:
                m.addConstr(
                    t[j] >= dist[i, j] - M_time * (1 - x[i, j]),
                    name=f"time_{i}_{j}"
                )
            else:
                m.addConstr(
                    t[j] >= depart_i + dist[i, j] - M_time * (1 - x[i, j]),
                    name=f"time_{i}_{j}"
                )

    for i in C_internal_eligible:
        m.addConstr(u[i] >= demand[i] * (1 - y[i]), name=f"load_lb_{i}")
        m.addConstr(u[i] <= truck_capacity * (1 - y[i]), name=f"load_ub_{i}")

    for i in C_internal_eligible:
        for j in C_internal_eligible:
            if i != j and (i, j) in x:
                m.addConstr(
                    u[j] >= u[i] + demand[j] - truck_capacity * (1 - x[i, j]),
                    name=f"mtz_load_{i}_{j}"
                )

    for j in C_internal_eligible:
        if (0, j) in x:
            m.addConstr(
                u[j] >= demand[j] - truck_capacity * (1 - x[0, j]),
                name=f"start_load_{j}"
            )

    m.optimize()

    if m.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: nan")


if __name__ == "__main__":
    main()
