import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    filepath = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "data",
        "general_parameters.csv"
    )
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            value = row["Value"].strip()
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass
            params[name] = value
    return params

def main():
    p = load_parameters()

    profit_robot = p["profit_per_robot"]
    profit_car = p["profit_per_model_car"]
    profit_blocks = p["profit_per_building_blocks"]
    profit_doll = p["profit_per_doll"]

    plastic_available = p["plastic_available"]
    plastic_robot = p["plastic_per_robot"]
    plastic_car = p["plastic_per_model_car"]
    plastic_blocks = p["plastic_per_building_blocks"]
    plastic_doll = p["plastic_per_doll"]

    electronics_available = p["electronic_components_available"]
    electronics_robot = p["electronics_per_robot"]
    electronics_car = p["electronics_per_model_car"]
    electronics_blocks = p["electronics_per_building_blocks"]
    electronics_doll = p["electronics_per_doll"]

    model = gp.Model("toy_manufacturing_revised")
    model.setParam("OutputFlag", 0)

    x_robot = model.addVar(vtype=GRB.INTEGER, lb=0, name="robots")
    x_car = model.addVar(vtype=GRB.INTEGER, lb=0, name="model_cars")
    x_blocks = model.addVar(vtype=GRB.INTEGER, lb=0, name="building_blocks")
    x_doll = model.addVar(vtype=GRB.INTEGER, lb=0, name="dolls")

    y_robot = model.addVar(vtype=GRB.BINARY, name="y_robot")
    y_car = model.addVar(vtype=GRB.BINARY, name="y_car")
    y_blocks = model.addVar(vtype=GRB.BINARY, name="y_blocks")
    y_doll = model.addVar(vtype=GRB.BINARY, name="y_doll")

    ub_robot = min(plastic_available // plastic_robot, electronics_available // electronics_robot)
    ub_car = min(plastic_available // plastic_car, electronics_available // electronics_car)
    ub_blocks = min(plastic_available // plastic_blocks, electronics_available // electronics_blocks)
    ub_doll = min(plastic_available // plastic_doll, electronics_available // electronics_doll)

    model.setObjective(
        profit_robot * x_robot +
        profit_car * x_car +
        profit_blocks * x_blocks +
        profit_doll * x_doll,
        GRB.MAXIMIZE
    )

    model.addConstr(
        plastic_robot * x_robot +
        plastic_car * x_car +
        plastic_blocks * x_blocks +
        plastic_doll * x_doll
        <= plastic_available,
        name="plastic"
    )

    model.addConstr(
        electronics_robot * x_robot +
        electronics_car * x_car +
        electronics_blocks * x_blocks +
        electronics_doll * x_doll
        <= electronics_available,
        name="electronics"
    )

    model.addConstr(x_robot <= ub_robot * y_robot, name="link_robot_up")
    model.addConstr(x_car <= ub_car * y_car, name="link_car_up")
    model.addConstr(x_blocks <= ub_blocks * y_blocks, name="link_blocks_up")
    model.addConstr(x_doll <= ub_doll * y_doll, name="link_doll_up")

    model.addConstr(x_robot >= y_robot, name="link_robot_low")
    model.addConstr(x_car >= y_car, name="link_car_low")
    model.addConstr(x_blocks >= y_blocks, name="link_blocks_low")
    model.addConstr(x_doll >= y_doll, name="link_doll_low")

    model.addConstr(y_robot + y_doll <= 1, name="robots_dolls_exclusion")
    model.addConstr(y_car <= y_blocks, name="cars_require_blocks")
    model.addConstr(x_doll <= x_car, name="dolls_leq_cars")

    model.addConstr(y_car + y_blocks <= 1, name="cars_blocks_mutual_exclusion")

    model.optimize()

    obj = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj}")

if __name__ == "__main__":
    main()
