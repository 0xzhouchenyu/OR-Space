import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_general_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_general_parameters(data_path)

    sell_price_table = params["sell_price_table"]
    sell_price_chair = params["sell_price_chair"]
    sell_price_bookshelf = params["sell_price_bookshelf"]

    cost_table = params["manufacturing_cost_table"]
    cost_chair = params["manufacturing_cost_chair"]
    cost_bookshelf = params["manufacturing_cost_bookshelf"]

    space_table = params["warehouse_space_table"]
    space_chair = params["warehouse_space_chair"]
    space_bookshelf = params["warehouse_space_bookshelf"]

    max_warehouse = params["max_warehouse_space"]
    min_tables = params["min_tables"]
    min_bookshelves = params["min_bookshelves"]
    max_total = params["max_total_items"]

    labor_table = params["labor_hours_table"]
    labor_chair = params["labor_hours_chair"]
    labor_bookshelf = params["labor_hours_bookshelf"]

    max_labor_regular = params["max_labor_hours_month_regular"]
    max_labor_rush = params["max_labor_hours_month_rush"]
    max_rush_items = params["max_rush_items_month"]

    rush_bonus_table = params["rush_profit_bonus_table"]
    rush_bonus_chair = params["rush_profit_bonus_chair"]
    rush_bonus_bookshelf = params["rush_profit_bonus_bookshelf"]

    profit_table_regular = sell_price_table - cost_table
    profit_chair_regular = sell_price_chair - cost_chair
    profit_bookshelf_regular = sell_price_bookshelf - cost_bookshelf

    profit_table_rush = profit_table_regular + rush_bonus_table
    profit_chair_rush = profit_chair_regular + rush_bonus_chair
    profit_bookshelf_rush = profit_bookshelf_regular + rush_bonus_bookshelf

    model = gp.Model("Furniture_Production_Revised")
    model.setParam("OutputFlag", 0)

    table_regular = model.addVar(vtype=GRB.INTEGER, lb=0, name="table_regular")
    chair_regular = model.addVar(vtype=GRB.INTEGER, lb=0, name="chair_regular")
    bookshelf_regular = model.addVar(vtype=GRB.INTEGER, lb=0, name="bookshelf_regular")

    table_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="table_rush")
    chair_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="chair_rush")
    bookshelf_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="bookshelf_rush")

    model.setObjective(
        profit_table_regular * table_regular
        + profit_chair_regular * chair_regular
        + profit_bookshelf_regular * bookshelf_regular
        + profit_table_rush * table_rush
        + profit_chair_rush * chair_rush
        + profit_bookshelf_rush * bookshelf_rush,
        GRB.MAXIMIZE,
    )

    model.addConstr(
        space_table * (table_regular + table_rush)
        + space_chair * (chair_regular + chair_rush)
        + space_bookshelf * (bookshelf_regular + bookshelf_rush)
        <= max_warehouse,
        name="warehouse_space",
    )

    model.addConstr(
        (table_regular + table_rush) >= min_tables,
        name="min_tables",
    )

    model.addConstr(
        (bookshelf_regular + bookshelf_rush) >= min_bookshelves,
        name="min_bookshelves",
    )

    model.addConstr(
        table_regular + chair_regular + bookshelf_regular
        + table_rush + chair_rush + bookshelf_rush
        <= max_total,
        name="max_total_items",
    )

    model.addConstr(
        labor_table * table_regular
        + labor_chair * chair_regular
        + labor_bookshelf * bookshelf_regular
        <= max_labor_regular,
        name="regular_labor_cap",
    )

    model.addConstr(
        labor_table * table_rush
        + labor_chair * chair_rush
        + labor_bookshelf * bookshelf_rush
        <= max_labor_rush,
        name="rush_labor_cap",
    )

    model.addConstr(
        table_rush + chair_rush + bookshelf_rush <= max_rush_items,
        name="rush_item_cap",
    )

    model.optimize()

    obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
