import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    return params

def main():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = load_parameters(data_path)

    num_students = int(params["num_students"])
    num_buses = int(params["num_buses"])
    bus_capacity = int(params["bus_capacity"])
    num_minibuses = int(params["num_minibuses"])
    minibus_capacity = int(params["minibus_capacity"])
    num_drivers = int(params["num_drivers"])
    bus_rental_cost = float(params["bus_rental_cost"])
    minibus_rental_cost = float(params["minibus_rental_cost"])

    model = gp.Model("SchoolTripRevised")
    model.setParam("OutputFlag", 0)

    x = model.addVar(vtype=GRB.INTEGER, lb=0, ub=num_buses, name="buses")
    y = model.addVar(vtype=GRB.INTEGER, lb=0, ub=num_minibuses, name="minibuses")

    model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

    model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, name="StudentCapacity")
    model.addConstr(x + y <= num_drivers, name="DriverLimit")
    model.addConstr(x >= 2 * y, name="EscortPolicy")
    model.addConstr(y >= 1, name="MinOneMinibus")

    model.optimize()

    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        raise RuntimeError(f"Optimization failed with status {model.Status}")

if __name__ == "__main__":
    main()
