import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(data_path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = row["Value"].strip()
            if val.lower() == "unlimited":
                params[name] = float("inf")
            else:
                params[name] = float(val)
    return params

def main():
    p = load_parameters()

    a1_yield = p["product_A1_yield"]
    a1_time = p["product_A1_time"]
    a2_yield = p["product_A2_yield"]
    a2_time = p["product_A2_time"]
    a3_yield = p["product_A3_yield"]
    a3_time = p["product_A3_time"]

    profit_a1 = p["profit_per_kg_A1"]
    profit_a2 = p["profit_per_kg_A2"]
    profit_a3 = p["profit_per_kg_A3"]

    milk_supply = p["daily_milk_supply"]
    labor_hours = p["daily_labor_hours"]
    cap_A_shared = p["cap_A_shared"]
    min_A2_kg = p["min_A2_kg"]
    min_A3_kg = p["min_A3_kg"]
    cleaning_loss = p["type_A_cleaning_loss_if_A3"]
    bonus_threshold = p["cold_chain_bonus_threshold_kg"]
    bonus_yuan = p["cold_chain_bonus_yuan"]

    m = gp.Model("revised_dairy_production")
    m.setParam("OutputFlag", 0)

    x1 = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="barrels_A1")
    x2 = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="barrels_A2")
    x3 = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="barrels_A3")

    y3 = m.addVar(vtype=GRB.BINARY, name="produce_A3")
    z_bonus = m.addVar(vtype=GRB.BINARY, name="cold_chain_bonus")

    a3_max_barrels = min(milk_supply, labor_hours / a3_time, max(0.0, (cap_A_shared - cleaning_loss) / a3_yield))

    m.addConstr(x1 + x2 + x3 <= milk_supply, name="milk_supply")
    m.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours, name="labor_hours")

    m.addConstr(a2_yield * x2 >= min_A2_kg, name="min_A2")
    m.addConstr(a3_yield * x3 >= min_A3_kg, name="min_A3")

    m.addConstr(x3 <= a3_max_barrels * y3, name="activate_A3_upper")
    m.addConstr(a3_yield * x3 >= min_A3_kg * y3, name="activate_A3_lower")

    m.addConstr(a1_yield * x1 + a3_yield * x3 + cleaning_loss * y3 <= cap_A_shared, name="shared_type_A_capacity")

    m.addConstr(a3_yield * x3 >= bonus_threshold * z_bonus, name="bonus_threshold_lb")
    m.addConstr(z_bonus <= y3, name="bonus_only_if_A3")

    obj = (
        profit_a1 * a1_yield * x1
        + profit_a2 * a2_yield * x2
        + profit_a3 * a3_yield * x3
        + bonus_yuan * z_bonus
    )

    m.setObjective(obj, GRB.MAXIMIZE)
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == "__main__":
    main()
