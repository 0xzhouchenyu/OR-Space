import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB


def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)


def get_param(params_df, name, default=None):
    rows = params_df.loc[params_df["Parameter_Name"] == name, "Value"]
    if len(rows) == 0:
        if default is None:
            raise ValueError(f"Missing parameter: {name}")
        return default
    return float(rows.iloc[0])


def main():
    table_path = get_data_path("table_3_3.csv")
    params_path = get_data_path("general_parameters.csv")

    df = pd.read_csv(table_path)
    params_df = pd.read_csv(params_path)

    ft_row = df[df["Role"] == "Full-time"].iloc[0]
    pt_row = df[df["Role"] == "Part-time"].iloc[0]

    sales_goal = get_param(params_df, "monthly_sales_goal")
    pt_ft_ratio = get_param(params_df, "pt_ft_overtime_ratio", 0.0)

    # Default employee counts based on the original heuristic/context.
    num_ft = 5.0
    num_pt = 4.0
    for col in df.columns:
        col_lower = col.lower()
        if any(kw in col_lower for kw in ["num", "clerks", "employees", "count", "人员", "数量"]):
            num_ft = float(ft_row[col])
            num_pt = float(pt_row[col])
            break

    ft_hours = float(ft_row["Monthly_Working_Hours"])
    pt_hours = float(pt_row["Monthly_Working_Hours"])
    ft_sales_rate = float(ft_row["Sales_Volume_Pairs_Per_Hour"])
    pt_sales_rate = float(pt_row["Sales_Volume_Pairs_Per_Hour"])

    normal_sales = num_ft * ft_hours * ft_sales_rate + num_pt * pt_hours * pt_sales_rate

    model = gp.Model("revised_shoe_store_overtime")
    model.setParam("OutputFlag", 0)

    y_ft = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="full_time_overtime_hours")
    y_pt = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="part_time_overtime_hours")

    model.setObjective(y_ft + y_pt, GRB.MINIMIZE)

    model.addConstr(
        normal_sales + ft_sales_rate * y_ft + pt_sales_rate * y_pt >= sales_goal,
        name="sales_goal"
    )

    model.addConstr(
        y_pt >= pt_ft_ratio * y_ft,
        name="pt_ft_overtime_dependency"
    )

    model.optimize()

    obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
