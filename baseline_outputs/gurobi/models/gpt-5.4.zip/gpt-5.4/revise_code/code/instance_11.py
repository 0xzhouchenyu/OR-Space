import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")

    df_table = pd.read_csv(table_path)
    df_params = pd.read_csv(params_path)

    params = {}
    for _, row in df_params.iterrows():
        val = row["Value"]
        try:
            if str(val).strip().lower() in {"true", "false"}:
                params[row["Parameter_Name"]] = str(val).strip().lower() == "true"
            else:
                params[row["Parameter_Name"]] = float(val)
        except Exception:
            params[row["Parameter_Name"]] = val

    row_a = df_table[df_table["Type"] == "Type_A"].iloc[0]
    row_b = df_table[df_table["Type"] == "Type_B"].iloc[0]
    row_cap = df_table[df_table["Type"] == "Max_weekly_capacity"].iloc[0]
    row_cost = df_table[df_table["Type"] == "Process_cost_Yuan_per_hour"].iloc[0]

    mfg_a = float(row_a["Manufacturing_hours_per_unit"])
    asm_a = float(row_a["Assembly_hours_per_unit"])
    price_a = float(row_a["Selling_Price_Yuan_per_unit"])

    mfg_b = float(row_b["Manufacturing_hours_per_unit"])
    asm_b = float(row_b["Assembly_hours_per_unit"])
    price_b = float(row_b["Selling_Price_Yuan_per_unit"])

    cap_mfg = float(row_cap["Manufacturing_hours_per_unit"])
    cap_asm = float(row_cap["Assembly_hours_per_unit"])
    cap_insp = float(row_cap["Inspection_hours_per_unit"])

    cost_mfg = float(row_cost["Manufacturing_hours_per_unit"])
    cost_asm = float(row_cost["Assembly_hours_per_unit"])

    min_weekly_profit = float(params["min_weekly_profit"])
    min_type_a = float(params["min_type_a_production"])
    insp_a_M = float(params["insp_a_M"])
    insp_b_M = float(params["insp_b_M"])
    insp_a_E = float(params["insp_a_E"])
    insp_b_E = float(params["insp_b_E"])
    cap_ext = float(params["cap_ext"])
    cost_insp_M = float(params["cost_insp_M"])
    cost_insp_E = float(params["cost_insp_E"])
    cost_ext = float(params["cost_ext"])
    mode_fee_M = float(params["mode_fee_M"])
    mode_fee_E = float(params["mode_fee_E"])
    risk_penalty_M = float(params["risk_penalty_M"])
    cost_insp_weight = float(params["cost_insp_weight"])
    planning_horizon_weeks = int(round(float(params["planning_horizon_weeks"])))
    idle_tolerance = float(params["idle_tolerance"])

    weeks = range(planning_horizon_weeks)

    model1 = gp.Model("revised_motorcycle_plan_stage1")
    model1.setParam("OutputFlag", 0)

    xA = model1.addVars(weeks, vtype=GRB.INTEGER, lb=0, name="xA")
    xB = model1.addVars(weeks, vtype=GRB.INTEGER, lb=0, name="xB")
    yM = model1.addVars(weeks, vtype=GRB.BINARY, name="yM")
    yE = model1.addVars(weeks, vtype=GRB.BINARY, name="yE")
    ext = model1.addVars(weeks, lb=0, vtype=GRB.CONTINUOUS, name="ext")

    idle_expr = gp.LinExpr()
    risk_expr = gp.LinExpr()

    for t in weeks:
        model1.addConstr(yM[t] + yE[t] == 1, name=f"one_mode_{t}")

        model1.addConstr(xA[t] >= min_type_a, name=f"min_type_a_{t}")

        mfg_used = mfg_a * xA[t] + mfg_b * xB[t]
        asm_used = asm_a * xA[t] + asm_b * xB[t]

        model1.addConstr(mfg_used <= cap_mfg, name=f"mfg_cap_{t}")
        model1.addConstr(asm_used <= cap_asm, name=f"asm_cap_{t}")

        total_insp_manual = insp_a_M * xA[t] + insp_b_M * xB[t]
        total_insp_enhanced = insp_a_E * xA[t] + insp_b_E * xB[t]

        model1.addConstr(total_insp_manual <= cap_insp + cap_insp * (1 - yM[t]), name=f"insp_manual_cap_{t}")
        model1.addConstr(total_insp_enhanced - ext[t] <= cap_insp + (cap_insp + cap_ext) * (1 - yE[t]), name=f"insp_enhanced_inhouse_cap_{t}")
        model1.addConstr(ext[t] <= cap_ext * yE[t], name=f"ext_cap_{t}")
        model1.addConstr(ext[t] <= total_insp_enhanced, name=f"ext_use_limit_{t}")

        revenue = price_a * xA[t] + price_b * xB[t]

        cost_manual = (
            cost_mfg * mfg_a * xA[t]
            + cost_asm * asm_a * xA[t]
            + cost_asm * asm_b * xB[t]
            + cost_insp_M * total_insp_manual
            + mode_fee_M * yM[t]
            + risk_penalty_M * yM[t]
        )

        cost_enhanced = (
            cost_mfg * mfg_a * xA[t]
            + cost_asm * asm_a * xA[t]
            + cost_asm * asm_b * xB[t]
            + cost_insp_E * (total_insp_enhanced - ext[t])
            + cost_ext * ext[t]
            + mode_fee_E * yE[t]
        )

        weekly_profit = revenue - cost_manual * yM[t] - cost_enhanced * yE[t]
        # Replace nonlinear expression with linear equivalent:
        weekly_profit = (
            revenue
            - cost_mfg * mfg_a * xA[t]
            - cost_asm * asm_a * xA[t]
            - cost_asm * asm_b * xB[t]
            - cost_insp_M * total_insp_manual
            + (cost_insp_M * total_insp_manual) * (1 - yM[t])
        )

        # Build proper linear profit expression by mode selection:
        weekly_profit_expr = (
            revenue
            - cost_mfg * mfg_a * xA[t]
            - cost_asm * asm_a * xA[t]
            - cost_asm * asm_b * xB[t]
            - cost_insp_M * total_insp_manual
            - mode_fee_M * yM[t]
            - risk_penalty_M * yM[t]
            + (cost_insp_M * total_insp_manual - cost_insp_E * (total_insp_enhanced - ext[t]) - cost_ext * ext[t]) * yE[t]
            + mode_fee_M * yE[t]
            + risk_penalty_M * yE[t]
            - mode_fee_E * yE[t]
        )

        # To keep the model linear, use explicit mode-conditioned profit with big-M constraints.
        # Upper bounds from capacities:
        max_xA = int(cap_mfg // mfg_a)
        max_xB = int(min(cap_asm // asm_b if asm_b > 0 else 10**6, (cap_insp + cap_ext) // min(insp_b_E, insp_b_M)))
        profit_manual_expr = (
            revenue
            - cost_mfg * mfg_a * xA[t]
            - cost_asm * asm_a * xA[t]
            - cost_asm * asm_b * xB[t]
            - cost_insp_M * total_insp_manual
            - mode_fee_M
            - risk_penalty_M
        )
        profit_enhanced_expr = (
            revenue
            - cost_mfg * mfg_a * xA[t]
            - cost_asm * asm_a * xA[t]
            - cost_asm * asm_b * xB[t]
            - cost_insp_E * (total_insp_enhanced - ext[t])
            - cost_ext * ext[t]
            - mode_fee_E
        )

        profit_t = model1.addVar(lb=-GRB.INFINITY, vtype=GRB.CONTINUOUS, name=f"profit_{t}")
        M = 1e6
        model1.addConstr(profit_t - profit_manual_expr <= M * (1 - yM[t]), name=f"profit_manual_ub_{t}")
        model1.addConstr(profit_t - profit_manual_expr >= -M * (1 - yM[t]), name=f"profit_manual_lb_{t}")
        model1.addConstr(profit_t - profit_enhanced_expr <= M * (1 - yE[t]), name=f"profit_enhanced_ub_{t}")
        model1.addConstr(profit_t - profit_enhanced_expr >= -M * (1 - yE[t]), name=f"profit_enhanced_lb_{t}")
        model1.addConstr(profit_t >= min_weekly_profit, name=f"min_profit_{t}")

        inhouse_insp_used = total_insp_manual * yM[t] + (total_insp_enhanced - ext[t]) * yE[t]
        # Linearize in-house inspection used:
        insp_used_t = model1.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"insp_used_{t}")
        model1.addConstr(insp_used_t - total_insp_manual <= M * (1 - yM[t]), name=f"insp_used_manual_ub_{t}")
        model1.addConstr(insp_used_t - total_insp_manual >= -M * (1 - yM[t]), name=f"insp_used_manual_lb_{t}")
        model1.addConstr(insp_used_t - (total_insp_enhanced - ext[t]) <= M * (1 - yE[t]), name=f"insp_used_enh_ub_{t}")
        model1.addConstr(insp_used_t - (total_insp_enhanced - ext[t]) >= -M * (1 - yE[t]), name=f"insp_used_enh_lb_{t}")

        idle_expr += cost_mfg * (cap_mfg - mfg_used)
        idle_expr += cost_asm * (cap_asm - asm_used)
        idle_expr += cost_insp_weight * (cap_insp - insp_used_t)

        risk_expr += risk_penalty_M * yM[t]

    model1.setObjective(idle_expr + risk_expr, GRB.MINIMIZE)
    model1.optimize()

    stage1_obj = model1.ObjVal

    model2 = gp.Model("revised_motorcycle_plan_stage2")
    model2.setParam("OutputFlag", 0)

    xA2 = model2.addVars(weeks, vtype=GRB.INTEGER, lb=0, name="xA")
    xB2 = model2.addVars(weeks, vtype=GRB.INTEGER, lb=0, name="xB")
    yM2 = model2.addVars(weeks, vtype=GRB.BINARY, name="yM")
    yE2 = model2.addVars(weeks, vtype=GRB.BINARY, name="yE")
    ext2 = model2.addVars(weeks, lb=0, vtype=GRB.CONTINUOUS, name="ext")

    idle_risk_expr2 = gp.LinExpr()
    total_profit_expr2 = gp.LinExpr()

    for t in weeks:
        model2.addConstr(yM2[t] + yE2[t] == 1, name=f"one_mode_{t}")
        model2.addConstr(xA2[t] >= min_type_a, name=f"min_type_a_{t}")

        mfg_used2 = mfg_a * xA2[t] + mfg_b * xB2[t]
        asm_used2 = asm_a * xA2[t] + asm_b * xB2[t]

        model2.addConstr(mfg_used2 <= cap_mfg, name=f"mfg_cap_{t}")
        model2.addConstr(asm_used2 <= cap_asm, name=f"asm_cap_{t}")

        total_insp_manual2 = insp_a_M * xA2[t] + insp_b_M * xB2[t]
        total_insp_enhanced2 = insp_a_E * xA2[t] + insp_b_E * xB2[t]

        model2.addConstr(total_insp_manual2 <= cap_insp + cap_insp * (1 - yM2[t]), name=f"insp_manual_cap_{t}")
        model2.addConstr(total_insp_enhanced2 - ext2[t] <= cap_insp + (cap_insp + cap_ext) * (1 - yE2[t]), name=f"insp_enhanced_inhouse_cap_{t}")
        model2.addConstr(ext2[t] <= cap_ext * yE2[t], name=f"ext_cap_{t}")
        model2.addConstr(ext2[t] <= total_insp_enhanced2, name=f"ext_use_limit_{t}")

        revenue2 = price_a * xA2[t] + price_b * xB2[t]

        profit_manual_expr2 = (
            revenue2
            - cost_mfg * mfg_a * xA2[t]
            - cost_asm * asm_a * xA2[t]
            - cost_asm * asm_b * xB2[t]
            - cost_insp_M * total_insp_manual2
            - mode_fee_M
            - risk_penalty_M
        )
        profit_enhanced_expr2 = (
            revenue2
            - cost_mfg * mfg_a * xA2[t]
            - cost_asm * asm_a * xA2[t]
            - cost_asm * asm_b * xB2[t]
            - cost_insp_E * (total_insp_enhanced2 - ext2[t])
            - cost_ext * ext2[t]
            - mode_fee_E
        )

        profit_t2 = model2.addVar(lb=-GRB.INFINITY, vtype=GRB.CONTINUOUS, name=f"profit_{t}")
        M = 1e6
        model2.addConstr(profit_t2 - profit_manual_expr2 <= M * (1 - yM2[t]), name=f"profit_manual_ub_{t}")
        model2.addConstr(profit_t2 - profit_manual_expr2 >= -M * (1 - yM2[t]), name=f"profit_manual_lb_{t}")
        model2.addConstr(profit_t2 - profit_enhanced_expr2 <= M * (1 - yE2[t]), name=f"profit_enhanced_ub_{t}")
        model2.addConstr(profit_t2 - profit_enhanced_expr2 >= -M * (1 - yE2[t]), name=f"profit_enhanced_lb_{t}")
        model2.addConstr(profit_t2 >= min_weekly_profit, name=f"min_profit_{t}")

        insp_used_t2 = model2.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"insp_used_{t}")
        model2.addConstr(insp_used_t2 - total_insp_manual2 <= M * (1 - yM2[t]), name=f"insp_used_manual_ub_{t}")
        model2.addConstr(insp_used_t2 - total_insp_manual2 >= -M * (1 - yM2[t]), name=f"insp_used_manual_lb_{t}")
        model2.addConstr(insp_used_t2 - (total_insp_enhanced2 - ext2[t]) <= M * (1 - yE2[t]), name=f"insp_used_enh_ub_{t}")
        model2.addConstr(insp_used_t2 - (total_insp_enhanced2 - ext2[t]) >= -M * (1 - yE2[t]), name=f"insp_used_enh_lb_{t}")

        idle_risk_expr2 += cost_mfg * (cap_mfg - mfg_used2)
        idle_risk_expr2 += cost_asm * (cap_asm - asm_used2)
        idle_risk_expr2 += cost_insp_weight * (cap_insp - insp_used_t2)
        idle_risk_expr2 += risk_penalty_M * yM2[t]

        total_profit_expr2 += profit_t2

    model2.addConstr(idle_risk_expr2 <= stage1_obj + idle_tolerance, name="lexicographic_idle_risk")
    model2.setObjective(total_profit_expr2, GRB.MAXIMIZE)
    model2.optimize()

    print(f"FINAL_OBJ_VALUE: {model2.ObjVal}")

if __name__ == "__main__":
    solve()
