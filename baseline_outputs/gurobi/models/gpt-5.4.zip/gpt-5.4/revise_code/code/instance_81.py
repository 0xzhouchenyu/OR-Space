import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(base_dir):
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"])
    return params

def load_car_data(base_dir):
    filepath = os.path.join(base_dir, "data", "table_1.csv")
    cars = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cars[int(row["i"])] = float(row["lambda_i"])
    return cars

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    params = load_parameters(base_dir)
    cars = load_car_data(base_dir)

    num_cars = int(params["num_cars"])
    max_length_one_side = float(params["max_length_one_side"])
    available_party_side_count = int(params["available_party_side_count"])

    car_ids = sorted(cars.keys())
    if len(car_ids) != num_cars:
        raise ValueError("Mismatch between num_cars and car data.")

    total_length = sum(cars[i] for i in car_ids)

    model = gp.Model("RevisedParkingSingleSide")
    model.setParam("OutputFlag", 0)

    x = model.addVars(car_ids, vtype=GRB.BINARY, name="x")
    y = model.addVars(range(1, 3), vtype=GRB.BINARY, name="y")
    z = model.addVars(car_ids, range(1, 3), vtype=GRB.BINARY, name="z")

    # Exactly one street side can host party cars
    model.addConstr(gp.quicksum(y[s] for s in range(1, 3)) == available_party_side_count, name="one_available_side")

    # Every car must be parked on exactly one side, and only on an opened side
    for i in car_ids:
        model.addConstr(z[i, 1] + z[i, 2] == 1, name=f"assign_{i}")
        for s in range(1, 3):
            model.addConstr(z[i, s] <= y[s], name=f"open_link_{i}_{s}")

    # Link x to side 1 assignment for clarity/consistency with original heuristic context
    for i in car_ids:
        model.addConstr(x[i] == z[i, 1], name=f"x_link_{i}")

    # Side capacity constraints
    for s in range(1, 3):
        model.addConstr(
            gp.quicksum(cars[i] * z[i, s] for i in car_ids) <= max_length_one_side * y[s],
            name=f"capacity_side_{s}"
        )

    # Objective: total street length occupied by party cars across used side(s)
    # With one side available, this equals total occupied length on that side.
    model.setObjective(
        gp.quicksum(cars[i] * z[i, s] for i in car_ids for s in range(1, 3)),
        GRB.MINIMIZE
    )

    model.optimize()

    if model.Status != GRB.OPTIMAL:
        raise RuntimeError("No optimal solution found.")

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
