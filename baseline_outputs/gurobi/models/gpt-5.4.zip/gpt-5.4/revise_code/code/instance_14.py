import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_items(data_dir):
    items = []
    with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                "name": row["Item"].strip(),
                "protein": float(row["Protein_Content_per_100g"].strip()),
                "cost": float(row["Cost_per_100g"].strip()),
                "type": row["Type"].strip(),
                "calories": float(row["Calories_per_100g"].strip()),
                "sodium": float(row["Sodium_mg_per_100g"].strip()),
            })
    return items

def load_params(data_dir):
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    items = load_items(data_dir)
    params = load_params(data_dir)

    min_vegetable_types = int(params["min_vegetable_types"])
    max_budget = params["max_budget"]
    total_weight_limit = params["total_weight_limit"]
    min_daily_calories = params["min_daily_calories"]
    max_daily_calories = params["max_daily_calories"]
    max_daily_sodium = params["max_daily_sodium"]

    n = len(items)
    veg_indices = [i for i, item in enumerate(items) if item["type"] == "Vegetable"]

    max_units = int(math.floor(total_weight_limit / 100.0))
    max_meal_units = 3

    model = gp.Model("mary_lunch_dinner")
    model.setParam("OutputFlag", 0)

    purchase = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="purchase_units")
    lunch = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="lunch_units")
    dinner = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="dinner_units")
    select_item = model.addVars(n, vtype=GRB.BINARY, name="select_item")

    lunch_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg_selected")
    dinner_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg_selected")

    model.setObjective(
        gp.quicksum(items[i]["protein"] * (lunch[i] + dinner[i]) for i in range(n)),
        GRB.MAXIMIZE
    )

    model.addConstr(
        gp.quicksum(items[i]["cost"] * purchase[i] for i in range(n)) <= max_budget,
        name="budget"
    )

    model.addConstr(
        100 * gp.quicksum(purchase[i] for i in range(n)) <= total_weight_limit,
        name="daily_weight_limit"
    )

    for i in range(n):
        model.addConstr(purchase[i] >= lunch[i] + dinner[i], name=f"purchase_link_lb_{i}")
        model.addConstr(purchase[i] <= max_units * select_item[i], name=f"purchase_select_{i}")
        model.addConstr(lunch[i] <= max_meal_units * select_item[i], name=f"lunch_select_{i}")
        model.addConstr(dinner[i] <= max_meal_units * select_item[i], name=f"dinner_select_{i}")

    model.addConstr(
        100 * gp.quicksum(lunch[i] for i in range(n)) == 300,
        name="lunch_weight"
    )
    model.addConstr(
        100 * gp.quicksum(dinner[i] for i in range(n)) == 300,
        name="dinner_weight"
    )

    total_calories = gp.quicksum(items[i]["calories"] * (lunch[i] + dinner[i]) for i in range(n))
    model.addConstr(total_calories >= min_daily_calories, name="min_daily_calories")
    model.addConstr(total_calories <= max_daily_calories, name="max_daily_calories")

    total_sodium = gp.quicksum(items[i]["sodium"] * (lunch[i] + dinner[i]) for i in range(n))
    model.addConstr(total_sodium <= max_daily_sodium, name="max_daily_sodium")

    for i in veg_indices:
        model.addConstr(lunch[i] >= lunch_veg_selected[i], name=f"lunch_veg_lb_{i}")
        model.addConstr(dinner[i] >= dinner_veg_selected[i], name=f"dinner_veg_lb_{i}")
        model.addConstr(lunch[i] <= max_meal_units * lunch_veg_selected[i], name=f"lunch_veg_ub_{i}")
        model.addConstr(dinner[i] <= max_meal_units * dinner_veg_selected[i], name=f"dinner_veg_ub_{i}")

    model.addConstr(
        gp.quicksum(lunch_veg_selected[i] for i in veg_indices) >= min_vegetable_types,
        name="min_lunch_veg_types"
    )
    model.addConstr(
        gp.quicksum(dinner_veg_selected[i] for i in veg_indices) >= min_vegetable_types,
        name="min_dinner_veg_types"
    )

    model.optimize()

    obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
