import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def main():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    p = load_parameters(data_path)

    rc_a = p["refrigerated_capacity_type_a"]
    nc_a = p["non_refrigerated_capacity_type_a"]
    rc_b = p["refrigerated_capacity_type_b"]
    nc_b = p["non_refrigerated_capacity_type_b"]
    ref_req = p["refrigerated_cargo_requirement"]
    nonref_req = p["non_refrigerated_cargo_requirement"]

    cost_a = p["rental_cost_type_a"]
    cost_b = p["rental_cost_type_b"]

    base_a = p["base_fleet_type_a"]
    base_b = p["base_fleet_type_b"]
    penalty_a = p["penalty_cost_type_a"]
    penalty_b = p["penalty_cost_type_b"]

    type_b_threshold = p["type_b_recovery_threshold"]
    type_b_recovery_fee = p["type_b_recovery_fee"]

    total_fleet_threshold = p["total_fleet_surge_threshold"]
    total_fleet_fee = p["total_fleet_surge_fee"]

    m = gp.Model("revised_truck_rental")
    m.setParam("OutputFlag", 0)

    x = m.addVar(vtype=GRB.INTEGER, lb=0, name="TypeA_trucks")
    y = m.addVar(vtype=GRB.INTEGER, lb=0, name="TypeB_trucks")

    excess_a = m.addVar(vtype=GRB.CONTINUOUS, lb=0, name="ExcessA")
    excess_b = m.addVar(vtype=GRB.CONTINUOUS, lb=0, name="ExcessB")

    z_b_recovery = m.addVar(vtype=GRB.BINARY, name="TypeBRecoveryDesk")
    z_total_surge = m.addVar(vtype=GRB.BINARY, name="TotalFleetSurgeDesk")

    m.addConstr(rc_a * x + rc_b * y >= ref_req, name="RefrigeratedRequirement")
    m.addConstr(nc_a * x + nc_b * y >= nonref_req, name="NonRefrigeratedRequirement")

    m.addConstr(excess_a >= x - base_a, name="ExcessA_def")
    m.addConstr(excess_b >= y - base_b, name="ExcessB_def")

    big_m_b = 10000
    m.addConstr(y - type_b_threshold <= big_m_b * z_b_recovery, name="TypeBRecovery_trigger")

    big_m_total = 10000
    m.addConstr(x + y - total_fleet_threshold <= big_m_total * z_total_surge, name="TotalFleetSurge_trigger")

    m.setObjective(
        cost_a * x
        + cost_b * y
        + penalty_a * excess_a
        + penalty_b * excess_b
        + type_b_recovery_fee * z_b_recovery
        + total_fleet_fee * z_total_surge,
        GRB.MINIMIZE
    )

    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")


if __name__ == "__main__":
    main()
