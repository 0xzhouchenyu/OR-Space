import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def main():
    demand_df = pd.read_csv(get_data_path("table_4_3.csv"))
    supply_df = pd.read_csv(get_data_path("table_4_4.csv"))
    params_df = pd.read_csv(get_data_path("general_parameters.csv"))

    p2_target = float(
        params_df.loc[params_df["Parameter_Name"] == "priority_2_target", "Value"].iloc[0]
    )

    cities = ["Donghai", "Nanjiang"]
    specs = [1, 2, 3]
    types = sorted(supply_df["Type"].astype(int).tolist())

    demand = {}
    for _, row in demand_df.iterrows():
        city = str(row["Branch_Location"]).replace(" City", "").strip()
        spec = int(row["Specialty"])
        demand[(city, spec)] = float(row["Demand"])

    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row["Type"])
        suitable = [int(x.strip()) for x in str(row["Suitable_Specialty"]).split(",")]
        supply[t] = {
            "num": float(row["Number_of_People"]),
            "suit": suitable,
            "pref_spec": int(row["Preferred_Specialty"]),
            "pref_city": str(row["Preferred_City"]).strip(),
        }

    feasible_keys = []
    for i in types:
        for j in cities:
            for k in specs:
                if k in supply[i]["suit"]:
                    feasible_keys.append((i, j, k))

    model = gp.Model("revised_staffing")
    model.setParam("OutputFlag", 0)

    x = model.addVars(feasible_keys, vtype=GRB.INTEGER, lb=0, name="x")

    for i in types:
        model.addConstr(
            gp.quicksum(x[i, j, k] for (ii, j, k) in feasible_keys if ii == i) <= supply[i]["num"],
            name=f"supply_{i}"
        )

    for j in cities:
        for k in specs:
            model.addConstr(
                gp.quicksum(x[i, j, k] for (i, jj, kk) in feasible_keys if jj == j and kk == k) == demand[(j, k)],
                name=f"demand_{j}_{k}"
            )

    preferred_specialty_count = gp.quicksum(
        x[i, j, k]
        for (i, j, k) in feasible_keys
        if k == supply[i]["pref_spec"]
    )
    model.addConstr(
        preferred_specialty_count >= p2_target,
        name="priority2_min_preferred_specialty"
    )

    dual_match_count = gp.quicksum(
        x[i, j, k]
        for (i, j, k) in feasible_keys
        if j == supply[i]["pref_city"] and k == supply[i]["pref_spec"]
    )

    model.setObjective(dual_match_count, GRB.MAXIMIZE)
    model.optimize()

    obj_val = model.objVal
    if abs(obj_val - round(obj_val)) < 1e-6:
        obj_str = str(int(round(obj_val)))
    else:
        obj_str = str(obj_val)

    print(f"FINAL_OBJ_VALUE: {obj_str}")

if __name__ == "__main__":
    main()
