import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_table_1(path):
    proc_time = {}
    capacity = {}
    cost_rate = {}
    raw_cost = {}
    price = {}

    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row["Equipment"].strip()
            if equip == "Raw_Material_Cost":
                raw_cost = {
                    "I": float(row["Product_I"]),
                    "II": float(row["Product_II"]),
                    "III": float(row["Product_III"]),
                }
            elif equip == "Unit_Price":
                price = {
                    "I": float(row["Product_I"]),
                    "II": float(row["Product_II"]),
                    "III": float(row["Product_III"]),
                }
            else:
                for prod, col in [("I", "Product_I"), ("II", "Product_II"), ("III", "Product_III")]:
                    val = row[col].strip()
                    if val != "-":
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row["Effective_Machine_Hours"])
                cost_rate[equip] = float(row["Processing_Cost_per_Machine_Hour"])

    return proc_time, capacity, cost_rate, raw_cost, price

def read_general_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    return params

def read_setup_costs(path):
    setup_cost = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            setup_cost[row["Equipment"].strip()] = float(row["Fixed_Setup_Cost"])
    return setup_cost

def parse_equipment_options(s):
    return [part.strip() for part in s.split("or")]

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    table_1_path = os.path.join(data_dir, "table_1.csv")
    general_params_path = os.path.join(data_dir, "general_parameters.csv")
    setup_costs_path = os.path.join(data_dir, "setup_costs.csv")

    proc_time, capacity, cost_rate, raw_cost, price = read_table_1(table_1_path)
    params = read_general_parameters(general_params_path)
    setup_cost = read_setup_costs(setup_costs_path)

    products = ["I", "II", "III"]
    equipments = list(capacity.keys())

    stage_A_equip = {
        "I": parse_equipment_options(params["product_I_stage_A_equipment"]),
        "II": parse_equipment_options(params["product_II_stage_A_equipment"]),
        "III": parse_equipment_options(params["product_III_stage_A_equipment"]),
    }
    stage_B_equip = {
        "I": parse_equipment_options(params["product_I_stage_B_equipment"]),
        "II": parse_equipment_options(params["product_II_stage_B_equipment"]),
        "III": parse_equipment_options(params["product_III_stage_B_equipment"]),
    }

    joint_trigger = int(params.get("A2_B2_joint_calibration_trigger", "0"))
    joint_fee = float(params.get("A2_B2_joint_calibration_fee", "0"))

    model = gp.Model("Factory_Production_Revised")
    model.setParam("OutputFlag", 0)

    x = {}
    for p in products:
        for e in stage_A_equip[p]:
            x[(e, p)] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")
        for e in stage_B_equip[p]:
            if (e, p) not in x:
                x[(e, p)] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")

    y = {e: model.addVar(vtype=GRB.BINARY, name=f"y_{e}") for e in equipments}
    z_A2_B2 = model.addVar(vtype=GRB.BINARY, name="z_A2_B2")

    total = {}
    for p in products:
        total[p] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"total_{p}")

    model.update()

    for p in products:
        model.addConstr(
            total[p] == gp.quicksum(x[(e, p)] for e in stage_A_equip[p]),
            name=f"total_stageA_{p}"
        )
        model.addConstr(
            gp.quicksum(x[(e, p)] for e in stage_A_equip[p]) ==
            gp.quicksum(x[(e, p)] for e in stage_B_equip[p]),
            name=f"flow_{p}"
        )

    for e in equipments:
        relevant = [(ee, p) for (ee, p) in x if ee == e]
        if relevant:
            model.addConstr(
                gp.quicksum(proc_time[(e, p)] * x[(e, p)] for (_, p) in relevant) <= capacity[e] * y[e],
                name=f"cap_{e}"
            )

    if joint_trigger == 1:
        model.addConstr(z_A2_B2 <= y["A2"], name="joint_link_ub_A2")
        model.addConstr(z_A2_B2 <= y["B2"], name="joint_link_ub_B2")
        model.addConstr(z_A2_B2 >= y["A2"] + y["B2"] - 1, name="joint_link_lb")
    else:
        model.addConstr(z_A2_B2 == 0, name="joint_off")

    revenue = gp.quicksum(price[p] * total[p] for p in products)
    raw_material = gp.quicksum(raw_cost[p] * total[p] for p in products)
    variable_processing = gp.quicksum(
        cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x
    )
    fixed_setup = gp.quicksum(setup_cost[e] * y[e] for e in equipments)
    joint_calibration = joint_fee * z_A2_B2

    model.setObjective(
        revenue - raw_material - variable_processing - fixed_setup - joint_calibration,
        GRB.MAXIMIZE
    )

    model.optimize()

    obj = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj}")

if __name__ == "__main__":
    main()
