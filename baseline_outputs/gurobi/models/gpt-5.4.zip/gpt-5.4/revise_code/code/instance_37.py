import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    return params

def load_table_1(path):
    rows = []
    with open(path, "r", newline="") as f:
        reader = csv.reader(f)
        headers = next(reader)
        for row in reader:
            rows.append(row)

    data = {}
    data["a_I"] = float(rows[0][1])
    data["b_I"] = float(rows[0][2])
    data["cap_I"] = float(rows[0][3])

    data["a_II"] = float(rows[1][1])
    data["b_II"] = float(rows[1][2])
    data["cap_II"] = float(rows[1][3])

    data["profit_A"] = float(rows[2][1])
    data["profit_B"] = float(rows[2][2])
    return data

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    tbl = load_table_1(os.path.join(data_dir, "table_1.csv"))

    # Parameters
    profit_A = tbl["profit_A"]
    profit_B = tbl["profit_B"]

    a_I = tbl["a_I"]
    b_I = tbl["b_I"]
    a_II = tbl["a_II"]
    b_II = tbl["b_II"]

    reg_I = params["process_I_hours"]
    reg_II = params["process_II_hours"]

    min_profit = params["min_weekly_profit"]
    min_A_total = params["min_model_A_units"]
    min_B_total = params["min_model_B_units"]

    w1_min_A = params["week1_min_model_A_units"]
    w1_min_B = params["week1_min_model_B_units"]
    w2_min_A = params["week2_min_model_A_units"]
    w2_min_B = params["week2_min_model_B_units"]

    max_ot_I = params["max_overtime_I_per_week"]
    max_ot_II = params["max_overtime_II_per_week"]

    ot_cost_I = params["overtime_premium_I"]
    ot_cost_II = params["overtime_premium_II"]

    min_avg_util_I = params["min_avg_utilization_I"]
    min_avg_util_II = params["min_avg_utilization_II"]

    fatigue_thr_I = params["week1_overtime_fatigue_threshold_I"]
    fatigue_thr_II = params["week1_overtime_fatigue_threshold_II"]

    recovery_loss_I = params["week2_recovery_loss_I"]
    recovery_loss_II = params["week2_recovery_loss_II"]

    # Model
    model = gp.Model("Revised_Microcomputer_TwoWeek_Plan")
    model.setParam("OutputFlag", 0)

    # Decision variables
    xA1 = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA1")
    xB1 = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB1")
    xA2 = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA2")
    xB2 = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB2")

    otI1 = model.addVar(lb=0.0, ub=max_ot_I, vtype=GRB.CONTINUOUS, name="otI1")
    otII1 = model.addVar(lb=0.0, ub=max_ot_II, vtype=GRB.CONTINUOUS, name="otII1")
    otI2 = model.addVar(lb=0.0, ub=max_ot_I, vtype=GRB.CONTINUOUS, name="otI2")
    otII2 = model.addVar(lb=0.0, ub=max_ot_II, vtype=GRB.CONTINUOUS, name="otII2")

    yI = model.addVar(vtype=GRB.BINARY, name="fatigueI")
    yII = model.addVar(vtype=GRB.BINARY, name="fatigueII")

    regUseI1 = model.addVar(lb=0.0, ub=reg_I, vtype=GRB.CONTINUOUS, name="regUseI1")
    regUseI2 = model.addVar(lb=0.0, ub=reg_I, vtype=GRB.CONTINUOUS, name="regUseI2")
    regUseII1 = model.addVar(lb=0.0, ub=reg_II, vtype=GRB.CONTINUOUS, name="regUseII1")
    regUseII2 = model.addVar(lb=0.0, ub=reg_II, vtype=GRB.CONTINUOUS, name="regUseII2")

    # Process load expressions
    loadI1 = a_I * xA1 + b_I * xB1
    loadII1 = a_II * xA1 + b_II * xB1
    loadI2 = a_I * xA2 + b_I * xB2
    loadII2 = a_II * xA2 + b_II * xB2

    # Regular/overtime split
    model.addConstr(regUseI1 + otI1 == loadI1, name="split_I_week1")
    model.addConstr(regUseII1 + otII1 == loadII1, name="split_II_week1")
    model.addConstr(regUseI2 + otI2 == loadI2, name="split_I_week2")
    model.addConstr(regUseII2 + otII2 == loadII2, name="split_II_week2")

    # Week 1 regular capacity
    model.addConstr(regUseI1 <= reg_I, name="regcap_I_week1")
    model.addConstr(regUseII1 <= reg_II, name="regcap_II_week1")

    # Week 2 regular capacity with recovery rule
    model.addConstr(regUseI2 <= reg_I - recovery_loss_I * yI, name="regcap_I_week2")
    model.addConstr(regUseII2 <= reg_II - recovery_loss_II * yII, name="regcap_II_week2")

    # Trigger fatigue if week 1 overtime exceeds threshold
    eps = 1e-6
    model.addConstr(otI1 <= fatigue_thr_I + (max_ot_I - fatigue_thr_I) * yI, name="fatigue_trigger_I_upper")
    model.addConstr(otII1 <= fatigue_thr_II + (max_ot_II - fatigue_thr_II) * yII, name="fatigue_trigger_II_upper")
    model.addConstr(otI1 >= fatigue_thr_I + eps - max_ot_I * (1 - yI), name="fatigue_trigger_I_lower")
    model.addConstr(otII1 >= fatigue_thr_II + eps - max_ot_II * (1 - yII), name="fatigue_trigger_II_lower")

    # Weekly delivery promises
    model.addConstr(xA1 >= w1_min_A, name="week1_min_A")
    model.addConstr(xB1 >= w1_min_B, name="week1_min_B")
    model.addConstr(xA2 >= w2_min_A, name="week2_min_A")
    model.addConstr(xB2 >= w2_min_B, name="week2_min_B")

    # Fortnight totals
    model.addConstr(xA1 + xA2 >= min_A_total, name="total_min_A")
    model.addConstr(xB1 + xB2 >= min_B_total, name="total_min_B")

    # Minimum average utilization of regular hours over two weeks
    model.addConstr(regUseI1 + regUseI2 >= 2 * reg_I * min_avg_util_I, name="min_avg_util_I")
    model.addConstr(regUseII1 + regUseII2 >= 2 * reg_II * min_avg_util_II, name="min_avg_util_II")

    # Profit objective and minimum profit constraint
    total_revenue = profit_A * (xA1 + xA2) + profit_B * (xB1 + xB2)
    total_ot_cost = ot_cost_I * (otI1 + otI2) + ot_cost_II * (otII1 + otII2)
    net_profit = total_revenue - total_ot_cost

    model.addConstr(net_profit >= min_profit, name="min_net_profit")

    model.setObjective(net_profit, GRB.MAXIMIZE)

    model.optimize()

    obj = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj}")

if __name__ == "__main__":
    main()
