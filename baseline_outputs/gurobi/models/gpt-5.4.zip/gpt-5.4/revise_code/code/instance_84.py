import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def load_candidates(path):
    candidates = []
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                "name": row["Candidate"].strip(),
                "salary": float(row["Salary"].strip()),
                "qualification": row["Qualification"].strip(),
                "experience": float(row["Work_Experience"].strip())
            })
    return candidates

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    candidates = load_candidates(os.path.join(data_dir, "table_1.csv"))

    max_employees = int(params["max_employees"])
    budget_limit = params["budget_limit"]
    min_advanced = int(params["min_advanced_degree_candidates"])
    min_work_experience = params["min_work_experience"]
    max_equivalent = int(params["max_equivalent_candidates"])
    min_employees = int(params["min_employees"])
    min_managers = int(params["min_managers"])
    max_managers = int(params["max_managers"])
    min_manager_experience = params["min_manager_experience"]
    manager_bonus = params["manager_bonus_per_candidate"]

    names = [c["name"] for c in candidates]
    salary = {c["name"]: c["salary"] for c in candidates}
    experience = {c["name"]: c["experience"] for c in candidates}
    qualification = {c["name"]: c["qualification"] for c in candidates}

    advanced = [n for n in names if qualification[n] in {"Master's degree", "Doctoral degree"}]

    model = gp.Model("recruitment_revised")
    model.setParam("OutputFlag", 0)

    hire = model.addVars(names, vtype=GRB.BINARY, name="hire")
    manager = model.addVars(names, vtype=GRB.BINARY, name="manager")
    specialist = model.addVars(names, vtype=GRB.BINARY, name="specialist")

    model.setObjective(
        gp.quicksum(salary[n] * hire[n] for n in names) +
        manager_bonus * gp.quicksum(manager[n] for n in names),
        GRB.MINIMIZE
    )

    model.addConstr(gp.quicksum(hire[n] for n in names) <= max_employees, name="max_employees")
    model.addConstr(gp.quicksum(hire[n] for n in names) >= min_employees, name="min_employees")
    model.addConstr(gp.quicksum(salary[n] * hire[n] for n in names) <= budget_limit, name="budget_limit")
    model.addConstr(gp.quicksum(hire[n] for n in advanced) >= min_advanced, name="min_advanced_degree")
    model.addConstr(gp.quicksum(experience[n] * hire[n] for n in names) >= min_work_experience, name="min_total_experience")
    model.addConstr(hire["A"] + hire["E"] <= max_equivalent, name="equivalent_pair_A_E")

    for n in names:
        model.addConstr(manager[n] + specialist[n] == hire[n], name=f"role_assign_{n}")

    model.addConstr(gp.quicksum(manager[n] for n in names) >= min_managers, name="min_managers")
    model.addConstr(gp.quicksum(manager[n] for n in names) <= max_managers, name="max_managers")
    model.addConstr(gp.quicksum(experience[n] * manager[n] for n in names) >= min_manager_experience, name="min_manager_experience")

    model.optimize()

    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
