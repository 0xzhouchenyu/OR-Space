import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_table_1(data_dir):
    filepath = os.path.join(data_dir, "table_1.csv")
    equipment_names = []
    products = []
    processing_times = {}
    effective_hours = {}
    base_profit = {}

    with open(filepath, "r", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        products = header[1:-1]

        for row in reader:
            if not row or not row[0]:
                continue
            if row[0].startswith("Unit_Product_Profit"):
                for j, p in enumerate(products):
                    base_profit[p] = float(row[j + 1])
            else:
                e = row[0]
                equipment_names.append(e)
                effective_hours[e] = float(row[-1])
                for j, p in enumerate(products):
                    processing_times[(e, p)] = float(row[j + 1])

    return products, equipment_names, processing_times, effective_hours, base_profit

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, "general_parameters.csv")
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    return params

def main():
    root_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(root_dir, "data")

    products, equipment_names, processing_times, effective_hours, base_profit = load_table_1(data_dir)
    params = load_general_parameters(data_dir)

    overtime_hours_cap = params["overtime_hours_cap"]
    overtime_cost_multiplier = params["overtime_cost_multiplier"]
    min_prod = {
        "I": params["min_prod_I"],
        "II": params["min_prod_II"],
        "III": params["min_prod_III"],
    }

    regular_cost = {p: base_profit[p] for p in products}
    overtime_cost = {p: overtime_cost_multiplier * base_profit[p] for p in products}

    model = gp.Model("revised_factory_production")
    model.setParam("OutputFlag", 0)

    x_reg = model.addVars(products, lb=0.0, vtype=GRB.CONTINUOUS, name="x_reg")
    x_ot = model.addVars(products, lb=0.0, vtype=GRB.CONTINUOUS, name="x_ot")

    model.setObjective(
        gp.quicksum(regular_cost[p] * x_reg[p] + overtime_cost[p] * x_ot[p] for p in products),
        GRB.MINIMIZE
    )

    for e in equipment_names:
        model.addConstr(
            gp.quicksum(
                processing_times[(e, p)] * (x_reg[p] + x_ot[p]) for p in products
            ) <= effective_hours[e],
            name=f"equip_cap_{e}"
        )

    model.addConstr(
        gp.quicksum(
            processing_times[(e, p)] * x_ot[p]
            for e in equipment_names
            for p in products
        ) <= overtime_hours_cap,
        name="overtime_cap"
    )

    for p in products:
        model.addConstr(
            x_reg[p] + x_ot[p] >= min_prod[p],
            name=f"min_prod_{p}"
        )

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
