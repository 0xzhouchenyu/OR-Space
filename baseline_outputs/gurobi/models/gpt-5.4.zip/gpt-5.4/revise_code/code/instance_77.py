import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    cost = {}
    parts = []
    machines = []

    with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(x.strip()) for x in header[1:]]
        for row in reader:
            m = row[0].strip()
            machines.append(m)
            for j, p in enumerate(parts):
                cost[(m, p)] = float(row[j + 1])

    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"])

    return machines, parts, cost, params

def main():
    machines, parts, cost, params = load_data()

    setup_cost = {
        "A": params["d_A"],
        "B": params["d_B"],
        "C": params["d_C"],
    }
    max_parts_on_C = int(params["max_parts_on_C"])
    overtime_threshold = int(params["overtime_threshold"])
    overtime_penalty = params["overtime_penalty"]

    model = gp.Model("revised_machine_assignment")
    model.setParam("OutputFlag", 0)

    x = model.addVars(machines, parts, vtype=GRB.BINARY, name="x")
    y = model.addVars(machines, vtype=GRB.BINARY, name="y")
    z = model.addVars(machines, vtype=GRB.BINARY, name="z")  # overtime indicator

    model.setObjective(
        gp.quicksum(cost[m, p] * x[m, p] for m in machines for p in parts)
        + gp.quicksum(setup_cost[m] * y[m] for m in machines)
        + gp.quicksum(overtime_penalty * z[m] for m in machines),
        GRB.MINIMIZE
    )

    # Each part assigned to exactly one machine
    for p in parts:
        model.addConstr(gp.quicksum(x[m, p] for m in machines) == 1, name=f"assign_{p}")

    # Linking machine usage
    for m in machines:
        for p in parts:
            model.addConstr(x[m, p] <= y[m], name=f"link_{m}_{p}")

    # Requirement 2:
    # If part 1 on A, then part 2 on B or C; else if part 1 on B or C, then part 2 on A
    # Equivalent to exactly one of parts 1 and 2 being on A
    model.addConstr(x["A", 1] + x["A", 2] == 1, name="part1_part2_logic")

    # Fixed assignments
    model.addConstr(x["A", 3] == 1, name="fix_part3_A")
    model.addConstr(x["B", 4] == 1, name="fix_part4_B")
    model.addConstr(x["C", 5] == 1, name="fix_part5_C")

    # At most max parts on machine C
    model.addConstr(gp.quicksum(x["C", p] for p in parts) <= max_parts_on_C, name="max_C")

    # Overtime penalty if machine processes more than threshold parts
    # If z[m] = 0 => load <= threshold
    # If z[m] = 1 => load can exceed threshold
    big_m = len(parts)
    for m in machines:
        load_m = gp.quicksum(x[m, p] for p in parts)
        model.addConstr(load_m <= overtime_threshold + big_m * z[m], name=f"overtime_trigger_{m}")
        model.addConstr(z[m] <= y[m], name=f"overtime_used_only_if_machine_used_{m}")

    model.optimize()

    obj_val = model.ObjVal
    if abs(obj_val - round(obj_val)) < 1e-9:
        obj_str = str(int(round(obj_val)))
    else:
        obj_str = str(obj_val)

    print(f"FINAL_OBJ_VALUE: {obj_str}")

if __name__ == "__main__":
    main()
