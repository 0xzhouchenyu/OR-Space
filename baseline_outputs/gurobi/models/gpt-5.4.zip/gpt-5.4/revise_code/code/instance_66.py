import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load toy data
toys = []
with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            "type": row["Toy_Type"],
            "labor": float(row["Manufacturing_Labor_Hours"]),
            "inspection": float(row["Inspection_Hours"]),
            "profit": float(row["Profit_Per_Unit"]),
        })

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

periods = [1, 2]
toy_types = [t["type"] for t in toys]

labor_req = {t["type"]: t["labor"] for t in toys}
inspection_req = {t["type"]: t["inspection"] for t in toys}
profit_per_unit = {t["type"]: t["profit"] for t in toys}

available_labor = {
    1: params["available_labor_hours_period1"],
    2: params["available_labor_hours_period2"],
}
available_inspection = {
    1: params["available_inspection_hours_period1"],
    2: params["available_inspection_hours_period2"],
}
max_demand = {
    (toy, 1): params[f"max_demand_{toy.lower().replace('-', '_')}_period1"]
    for toy in toy_types
}
max_demand.update({
    (toy, 2): params[f"max_demand_{toy.lower().replace('-', '_')}_period2"]
    for toy in toy_types
})

overtime_labor_cap = params["overtime_labor_cap"]
overtime_labor_cost = params["overtime_labor_cost"]
period1_overtime_fatigue_threshold = params["period1_overtime_fatigue_threshold"]
period2_labor_recovery_loss = params["period2_labor_recovery_loss"]
overtime_review_threshold = params["overtime_review_threshold"]
seasonal_safety_review_fee = params["seasonal_safety_review_fee"]

# Build model
model = gp.Model("ToyProductionRevised")
model.setParam("OutputFlag", 0)

# Decision variables
x = model.addVars(toy_types, periods, lb=0.0, vtype=GRB.CONTINUOUS, name="x")
overtime = model.addVars(periods, lb=0.0, vtype=GRB.CONTINUOUS, name="overtime")

fatigue_trigger = model.addVar(vtype=GRB.BINARY, name="fatigue_trigger")
review_trigger = model.addVar(vtype=GRB.BINARY, name="review_trigger")

# Objective
production_profit = gp.quicksum(
    profit_per_unit[toy] * x[toy, p] for toy in toy_types for p in periods
)
overtime_cost = overtime_labor_cost * gp.quicksum(overtime[p] for p in periods)
review_cost = seasonal_safety_review_fee * review_trigger

model.setObjective(production_profit - overtime_cost - review_cost, GRB.MAXIMIZE)

# Demand constraints
for toy in toy_types:
    for p in periods:
        model.addConstr(x[toy, p] <= max_demand[(toy, p)], name=f"demand_{toy}_{p}")

# Inspection constraints
for p in periods:
    model.addConstr(
        gp.quicksum(inspection_req[toy] * x[toy, p] for toy in toy_types) <= available_inspection[p],
        name=f"inspection_{p}"
    )

# Overtime cap
model.addConstr(
    gp.quicksum(overtime[p] for p in periods) <= overtime_labor_cap,
    name="total_overtime_cap"
)

# Fatigue carryover logic:
# If period 1 overtime exceeds threshold, period 2 regular labor is reduced by recovery loss.
M_ot1 = overtime_labor_cap
model.addConstr(
    overtime[1] - period1_overtime_fatigue_threshold <= M_ot1 * fatigue_trigger,
    name="fatigue_trigger_upper"
)
model.addConstr(
    overtime[1] >= period1_overtime_fatigue_threshold * fatigue_trigger,
    name="fatigue_trigger_lower"
)

# Labor constraints with fatigue effect in period 2
model.addConstr(
    gp.quicksum(labor_req[toy] * x[toy, 1] for toy in toy_types) <= available_labor[1] + overtime[1],
    name="labor_1"
)
model.addConstr(
    gp.quicksum(labor_req[toy] * x[toy, 2] for toy in toy_types)
    <= available_labor[2] - period2_labor_recovery_loss * fatigue_trigger + overtime[2],
    name="labor_2"
)

# Safety review trigger if total overtime exceeds threshold
M_total_ot = overtime_labor_cap
total_ot = gp.quicksum(overtime[p] for p in periods)
model.addConstr(
    total_ot - overtime_review_threshold <= M_total_ot * review_trigger,
    name="review_trigger_upper"
)
model.addConstr(
    total_ot >= overtime_review_threshold * review_trigger,
    name="review_trigger_lower"
)

model.optimize()

obj_val = model.objVal if model.status == GRB.OPTIMAL else float("nan")
print(f"FINAL_OBJ_VALUE: {obj_val}")
