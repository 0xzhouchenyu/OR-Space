import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def load_product_table(path):
    products = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row["Item"].strip()
            products[item] = {
                "machine_time": float(row["Machine_Time_minutes"].strip()),
                "craftsman_time": float(row["Craftsman_Time_minutes"].strip()),
            }
    return products

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    products = load_product_table(os.path.join(data_dir, "table_1.csv"))

    machine_avail = params["machine_time_available"]
    craftsman_regular_avail = params["craftsman_regular_time_available"]
    craftsman_overtime_avail = params["craftsman_overtime_available"]
    machine_cost = params["machine_time_cost"]
    craftsman_regular_cost = params["craftsman_time_cost"]
    craftsman_overtime_cost = params["craftsman_overtime_cost"]
    rev_x = params["revenue_product_X"]
    rev_y = params["revenue_product_Y"]
    min_x = params["min_batches_product_X"]
    y_qa_threshold = params["product_Y_QA_threshold"]
    y_qa_fee = params["product_Y_QA_fee"]

    machine_time_x = products["X"]["machine_time"] / 60.0
    machine_time_y = products["Y"]["machine_time"] / 60.0
    craftsman_time_x = products["X"]["craftsman_time"] / 60.0
    craftsman_time_y = products["Y"]["craftsman_time"] / 60.0

    model = gp.Model("revised_production_planning")
    model.setParam("OutputFlag", 0)

    X = model.addVar(lb=min_x, vtype=GRB.CONTINUOUS, name="X")
    Y = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="Y")

    regular_craftsman_hours = model.addVar(lb=0.0, ub=craftsman_regular_avail, vtype=GRB.CONTINUOUS, name="regular_craftsman_hours")
    overtime_craftsman_hours = model.addVar(lb=0.0, ub=craftsman_overtime_avail, vtype=GRB.CONTINUOUS, name="overtime_craftsman_hours")

    y_qa_trigger = model.addVar(vtype=GRB.BINARY, name="y_qa_trigger")

    total_machine_hours = machine_time_x * X + machine_time_y * Y
    total_craftsman_hours = craftsman_time_x * X + craftsman_time_y * Y

    model.addConstr(total_machine_hours <= machine_avail, name="machine_capacity")
    model.addConstr(regular_craftsman_hours + overtime_craftsman_hours == total_craftsman_hours, name="craftsman_balance")

    max_y_from_machine = machine_avail / machine_time_y
    max_y_from_craftsman = (craftsman_regular_avail + craftsman_overtime_avail) / craftsman_time_y
    big_m_y = max(max_y_from_machine, max_y_from_craftsman, y_qa_threshold)

    model.addConstr(Y <= y_qa_threshold + big_m_y * y_qa_trigger, name="qa_trigger_upper")
    model.addConstr(Y >= y_qa_threshold * y_qa_trigger, name="qa_trigger_lower")

    revenue = rev_x * X + rev_y * Y
    costs = (
        machine_cost * total_machine_hours
        + craftsman_regular_cost * regular_craftsman_hours
        + craftsman_overtime_cost * overtime_craftsman_hours
        + y_qa_fee * y_qa_trigger
    )

    model.setObjective(revenue - costs, GRB.MAXIMIZE)

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
