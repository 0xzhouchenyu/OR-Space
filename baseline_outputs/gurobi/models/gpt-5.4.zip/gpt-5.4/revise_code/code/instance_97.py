import os
import csv
import gurobipy as gp
from gurobipy import GRB


def read_general_parameters(path):
    params = {}
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f, skipinitialspace=True)
        for row in reader:
            key = row["Parameter_Name"].strip()
            val = float(row["Value"].strip())
            params[key] = val
    return params


def read_material_data(path):
    materials = []
    sulfur = {}
    cost = {}
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f, skipinitialspace=True)
        for row in reader:
            m = row["Material"].strip()
            materials.append(m)
            sulfur[m] = float(row["Sulfur_Content_Percentage"].strip())
            cost[m] = float(row["Purchase_Price_Thousand_Yuan_Per_Ton"].strip())
    return materials, sulfur, cost


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = read_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    materials, sulfur_content, purchase_price = read_material_data(os.path.join(data_dir, "table_1.csv"))

    streams = ["A_premium", "A_standard", "B_premium", "B_standard"]

    sulfur_limit = {
        "A_premium": params["max_sulfur_content_A_premium"],
        "A_standard": params["max_sulfur_content_A_standard"],
        "B_premium": params["max_sulfur_content_B_premium"],
        "B_standard": params["max_sulfur_content_B_standard"],
    }

    selling_price = {
        "A_premium": params["selling_price_A_premium"],
        "A_standard": params["selling_price_A_standard"],
        "B_premium": params["selling_price_B_premium"],
        "B_standard": params["selling_price_B_standard"],
    }

    model = gp.Model("revised_mixing_problem")
    model.setParam("OutputFlag", 0)

    x = model.addVars(materials, streams, lb=0.0, vtype=GRB.CONTINUOUS, name="x")

    total = {s: gp.quicksum(x[m, s] for m in materials) for s in streams}

    # Objective: maximize profit = revenue - raw material cost
    revenue = gp.quicksum(selling_price[s] * total[s] for s in streams)
    raw_cost = gp.quicksum(purchase_price[m] * x[m, s] for m in materials for s in streams)
    model.setObjective(revenue - raw_cost, GRB.MAXIMIZE)

    # Sulfur constraints by stream
    for s in streams:
        model.addConstr(
            gp.quicksum(sulfur_content[m] * x[m, s] for m in materials) <= sulfur_limit[s] * total[s],
            name=f"sulfur_{s}"
        )

    # Supply limit for material D across all streams
    model.addConstr(
        gp.quicksum(x["D", s] for s in streams) <= params["max_supply_D"],
        name="supply_D"
    )

    # Family demand constraints
    model.addConstr(total["A_premium"] + total["A_standard"] <= params["market_demand_A"], name="demand_A")
    model.addConstr(total["B_premium"] + total["B_standard"] <= params["market_demand_B"], name="demand_B")

    # Premium volume bounds by family
    model.addConstr(total["A_premium"] >= params["min_premium_share_A"], name="min_premium_A")
    model.addConstr(total["A_premium"] <= params["max_premium_share_A"], name="max_premium_A")
    model.addConstr(total["B_premium"] >= params["min_premium_share_B"], name="min_premium_B")
    model.addConstr(total["B_premium"] <= params["max_premium_share_B"], name="max_premium_B")

    model.optimize()

    obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
