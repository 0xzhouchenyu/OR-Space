import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_general_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def read_products(path):
    products = []
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                "name": row["Product Name"].strip(),
                "labor": float(row["Labor per unit"].strip()),
                "material": float(row["Material per unit"].strip()),
                "price": float(row["Selling Price"].strip()),
                "var_cost": float(row["Variable Cost"].strip())
            })
    return products

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = read_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    products = read_products(os.path.join(data_dir, "table_1.csv"))

    fixed_cost_map = {
        "Shirt": params["fixed_cost_shirts"],
        "Short-sleeve": params["fixed_cost_short_sleeves"],
        "Casual Cloth": params["fixed_cost_casual_clothes"],
    }
    min_batch_map = {
        "Shirt": params["min_batch_shirts"],
        "Short-sleeve": params["min_batch_short_sleeves"],
        "Casual Cloth": params["min_batch_casual_clothes"],
    }
    max_prod_map = {
        "Shirt": params["max_prod_shirts"],
        "Short-sleeve": params["max_prod_short_sleeves"],
        "Casual Cloth": params["max_prod_casual_clothes"],
    }

    regular_discount = params["segment_regular_discount"]
    promo_discount = params["segment_promo_discount"]
    available_labor = params["available_labor"]
    available_material = params["available_material"]
    promo_labor_cap = params["segment_promo_labor_cap"]
    promo_material_cap = params["segment_promo_material_cap"]

    model = gp.Model("hongdou_revised")
    model.setParam("OutputFlag", 0)

    n = len(products)

    x_reg = {}
    x_promo = {}
    y_open = {}
    z_reg = {}
    z_promo = {}

    for i, p in enumerate(products):
        name = p["name"]
        max_prod = max_prod_map[name]

        x_reg[i] = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_prod, name=f"x_reg_{i}")
        x_promo[i] = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_prod, name=f"x_promo_{i}")
        y_open[i] = model.addVar(vtype=GRB.BINARY, name=f"y_open_{i}")
        z_reg[i] = model.addVar(vtype=GRB.BINARY, name=f"z_reg_{i}")
        z_promo[i] = model.addVar(vtype=GRB.BINARY, name=f"z_promo_{i}")

    # Resource constraints
    model.addConstr(
        gp.quicksum(products[i]["labor"] * (x_reg[i] + x_promo[i]) for i in range(n)) <= available_labor,
        name="total_labor"
    )
    model.addConstr(
        gp.quicksum(products[i]["material"] * (x_reg[i] + x_promo[i]) for i in range(n)) <= available_material,
        name="total_material"
    )

    # Promotional segment caps
    model.addConstr(
        gp.quicksum(products[i]["labor"] * x_promo[i] for i in range(n)) <= promo_labor_cap,
        name="promo_labor_cap"
    )
    model.addConstr(
        gp.quicksum(products[i]["material"] * x_promo[i] for i in range(n)) <= promo_material_cap,
        name="promo_material_cap"
    )

    # Product-specific activation, min batch, max production, and segment gates
    for i, p in enumerate(products):
        name = p["name"]
        min_batch = min_batch_map[name]
        max_prod = max_prod_map[name]

        total_prod = x_reg[i] + x_promo[i]

        # If equipment is opened, production must be within [min_batch, max_prod]
        model.addConstr(total_prod <= max_prod * y_open[i], name=f"open_max_{i}")
        model.addConstr(total_prod >= min_batch * y_open[i], name=f"open_min_{i}")

        # Segment presence only if segment clears product-specific minimum batch size
        model.addConstr(x_reg[i] <= max_prod * z_reg[i], name=f"reg_seg_ub_{i}")
        model.addConstr(x_reg[i] >= min_batch * z_reg[i], name=f"reg_seg_lb_{i}")
        model.addConstr(x_promo[i] <= max_prod * z_promo[i], name=f"promo_seg_ub_{i}")
        model.addConstr(x_promo[i] >= min_batch * z_promo[i], name=f"promo_seg_lb_{i}")

        # Cannot be present in a segment unless product line is opened
        model.addConstr(z_reg[i] <= y_open[i], name=f"reg_open_link_{i}")
        model.addConstr(z_promo[i] <= y_open[i], name=f"promo_open_link_{i}")

    # Objective
    profit_expr = gp.LinExpr()
    for i, p in enumerate(products):
        revenue_reg = regular_discount * p["price"]
        revenue_promo = promo_discount * p["price"]
        var_cost = p["var_cost"]
        fixed_cost = fixed_cost_map[p["name"]]

        profit_expr += (revenue_reg - var_cost) * x_reg[i]
        profit_expr += (revenue_promo - var_cost) * x_promo[i]
        profit_expr += -fixed_cost * y_open[i]

    model.setObjective(profit_expr, GRB.MAXIMIZE)
    model.optimize()

    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
