import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_parameters(data_path)

    a_p1 = params["product_a_process_1_time"]
    a_p2 = params["product_a_process_2_time"]
    b_p1 = params["product_b_process_1_time"]
    b_p2 = params["product_b_process_2_time"]

    T1 = params["available_time_process_1"]
    T2 = params["available_time_process_2"]
    T1_high = params["available_time_process_1_high"]
    T2_high = params["available_time_process_2_high"]

    c_per_b = params["byproduct_c_per_unit_b"]
    max_c_sales = params["max_byproduct_c_sales"]
    threshold_c = params["threshold_c"]
    bigM_disposal = params["bigM_disposal"]

    disposal_cost = params["disposal_cost_per_unit_c"]
    disposal_cost_high = params["disposal_cost_per_unit_c_high"]

    profit_a = params["profit_per_unit_a"]
    profit_b = params["profit_per_unit_b"]
    profit_c = params["profit_per_unit_c"]

    m = gp.Model("revised_chemical_production")
    m.setParam("OutputFlag", 0)

    xA = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA")
    xB = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB")
    cSold = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="cSold")
    cDisposeBase = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="cDisposeBase")
    cDisposeHigh = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="cDisposeHigh")

    y1 = m.addVar(vtype=GRB.BINARY, name="high_throughput_p1")
    y2 = m.addVar(vtype=GRB.BINARY, name="high_throughput_p2")
    z = m.addVar(vtype=GRB.BINARY, name="high_disposal_active")

    m.setObjective(
        profit_a * xA
        + profit_b * xB
        + profit_c * cSold
        - disposal_cost * cDisposeBase
        - disposal_cost_high * cDisposeHigh,
        GRB.MAXIMIZE,
    )

    m.addConstr(a_p1 * xA + b_p1 * xB <= T1 + (T1_high - T1) * y1, name="process1_capacity")
    m.addConstr(a_p2 * xA + b_p2 * xB <= T2 + (T2_high - T2) * y2, name="process2_capacity")
    m.addConstr(y1 + y2 <= 1, name="at_most_one_high_throughput")

    m.addConstr(cSold + cDisposeBase + cDisposeHigh == c_per_b * xB, name="byproduct_balance")
    m.addConstr(cSold <= max_c_sales, name="max_c_sales")

    m.addConstr(cDisposeBase <= threshold_c, name="base_disposal_limit")
    m.addConstr(cDisposeHigh <= bigM_disposal * z, name="high_disposal_upper")
    m.addConstr(cDisposeBase >= threshold_c * z, name="base_disposal_fill_if_high_used")
    m.addConstr(cDisposeBase <= threshold_c * z + threshold_c * (1 - z), name="base_disposal_consistency")

    m.optimize()

    obj_val = m.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
