import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = row["Value"].strip()
            try:
                if "." in val:
                    params[name] = float(val)
                else:
                    params[name] = int(val)
            except ValueError:
                params[name] = val
    return params


def load_demand():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "table_1.csv")
    demand = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            t = int(row["Week"].strip())
            demand[t] = {
                "I": float(row["I"].strip()),
                "II": float(row["II"].strip())
            }
    return demand


params = load_parameters()
demand = load_demand()

T = 8
weeks = range(1, T + 1)
train_start_weeks = range(1, T)  # 1..7

S0 = params["skilled_worker_count"]
rate_I = params["food_I_production_rate"]
rate_II = params["food_II_production_rate"]
normal_hours = params["worker_weekly_hours"]
overtime_hours = params["skilled_worker_overtime_hours"]
train_cap = params["training_capacity"]
train_period = params["training_period"]
wage_skilled = params["skilled_worker_weekly_wage"]
wage_trainee_during = params["trainee_weekly_wage_during_training"]
wage_trainee_after = params["trainee_weekly_wage_after_training"]
wage_overtime = params["skilled_worker_overtime_wage"]
comp_I = params["compensation_fee_food_I"]
comp_II = params["compensation_fee_food_II"]
new_worker_goal = params["new_worker_training_goal"]

m = gp.Model("factory_training_single_product_week")
m.setParam("OutputFlag", 0)

# Decision variables
n_train = m.addVars(train_start_weeks, vtype=GRB.INTEGER, lb=0, name="n_train")
n_overtime = m.addVars(weeks, vtype=GRB.INTEGER, lb=0, name="n_overtime")

# Weekly product-family choice
y_I = m.addVars(weeks, vtype=GRB.BINARY, name="y_I")
y_II = m.addVars(weeks, vtype=GRB.BINARY, name="y_II")

# Production hours by workforce source and product
h_I_s = m.addVars(weeks, lb=0.0, name="h_I_s")
h_II_s = m.addVars(weeks, lb=0.0, name="h_II_s")
h_I_ot = m.addVars(weeks, lb=0.0, name="h_I_ot")
h_II_ot = m.addVars(weeks, lb=0.0, name="h_II_ot")
h_I_g = m.addVars(weeks, lb=0.0, name="h_I_g")
h_II_g = m.addVars(weeks, lb=0.0, name="h_II_g")

# Backlogs
backlog_I = m.addVars(weeks, lb=0.0, name="backlog_I")
backlog_II = m.addVars(weeks, lb=0.0, name="backlog_II")

# Helper expressions
def trainers_busy_expr(t):
    return gp.quicksum(n_train[s] for s in train_start_weeks if s <= t <= s + train_period - 1)

def graduates_available_expr(t):
    return gp.quicksum(train_cap * n_train[s] for s in train_start_weeks if s + train_period <= t)

# Constraints
for t in weeks:
    busy_t = trainers_busy_expr(t)
    grads_t = graduates_available_expr(t)
    avail_skilled_t = S0 - busy_t

    # Feasible trainer load / available skilled workers
    m.addConstr(avail_skilled_t >= 0, name=f"avail_skilled_nonneg_{t}")

    # Overtime limited to skilled workers available for production
    m.addConstr(n_overtime[t] <= avail_skilled_t, name=f"overtime_limit_{t}")

    # Single-product-or-idle weekly commitment
    m.addConstr(y_I[t] + y_II[t] <= 1, name=f"single_family_{t}")

    # Skilled regular hours
    m.addConstr(
        h_I_s[t] + h_II_s[t] <= (avail_skilled_t - n_overtime[t]) * normal_hours,
        name=f"regular_hours_cap_{t}"
    )

    # Skilled overtime hours
    m.addConstr(
        h_I_ot[t] + h_II_ot[t] <= n_overtime[t] * overtime_hours,
        name=f"overtime_hours_cap_{t}"
    )

    # Graduated trainee hours
    m.addConstr(
        h_I_g[t] + h_II_g[t] <= grads_t * normal_hours,
        name=f"graduate_hours_cap_{t}"
    )

    # Mutual exclusion: all productive hours in week t must be for only one food family
    bigM_hours = (S0 * overtime_hours) + (train_cap * S0 * normal_hours)
    m.addConstr(h_I_s[t] <= bigM_hours * y_I[t], name=f"h_I_s_only_{t}")
    m.addConstr(h_I_ot[t] <= bigM_hours * y_I[t], name=f"h_I_ot_only_{t}")
    m.addConstr(h_I_g[t] <= bigM_hours * y_I[t], name=f"h_I_g_only_{t}")

    m.addConstr(h_II_s[t] <= bigM_hours * y_II[t], name=f"h_II_s_only_{t}")
    m.addConstr(h_II_ot[t] <= bigM_hours * y_II[t], name=f"h_II_ot_only_{t}")
    m.addConstr(h_II_g[t] <= bigM_hours * y_II[t], name=f"h_II_g_only_{t}")

    # Backlog balance
    prod_I_t = rate_I * (h_I_s[t] + h_I_ot[t] + h_I_g[t])
    prod_II_t = rate_II * (h_II_s[t] + h_II_ot[t] + h_II_g[t])

    if t == 1:
        m.addConstr(backlog_I[t] >= demand[t]["I"] - prod_I_t, name=f"backlog_I_bal_{t}")
        m.addConstr(backlog_II[t] >= demand[t]["II"] - prod_II_t, name=f"backlog_II_bal_{t}")
    else:
        m.addConstr(backlog_I[t] >= backlog_I[t - 1] + demand[t]["I"] - prod_I_t, name=f"backlog_I_bal_{t}")
        m.addConstr(backlog_II[t] >= backlog_II[t - 1] + demand[t]["II"] - prod_II_t, name=f"backlog_II_bal_{t}")

# Training goal by end of week 8: starts in weeks 1..7 count
m.addConstr(
    gp.quicksum(train_cap * n_train[s] for s in train_start_weeks) >= new_worker_goal,
    name="training_goal"
)

# Objective
# Skilled workers are all paid every week: available production workers + trainers = S0 total each week.
# Overtime workers receive overtime wage instead of normal wage, so incremental premium = wage_overtime - wage_skilled.
base_skilled_cost = T * S0 * wage_skilled

trainee_training_cost = gp.quicksum(
    train_period * train_cap * wage_trainee_during * n_train[s] for s in train_start_weeks
)

graduate_wage_cost = gp.quicksum(
    wage_trainee_after * graduates_available_expr(t) for t in weeks
)

overtime_premium_cost = gp.quicksum(
    (wage_overtime - wage_skilled) * n_overtime[t] for t in weeks
)

backlog_cost = gp.quicksum(
    comp_I * backlog_I[t] + comp_II * backlog_II[t] for t in weeks
)

m.setObjective(
    base_skilled_cost + trainee_training_cost + graduate_wage_cost + overtime_premium_cost + backlog_cost,
    GRB.MINIMIZE
)

m.optimize()

obj = m.ObjVal
if abs(obj - round(obj)) <= 1e-6:
    obj_str = str(int(round(obj)))
else:
    obj_str = f"{obj:.6f}".rstrip("0").rstrip(".")

print(f"FINAL_OBJ_VALUE: {obj_str}")
