import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), newline="") as f:
    for row in csv.DictReader(f):
        params[row["Parameter_Name"].strip()] = float(row["Value"])

products = {}
with open(os.path.join(data_dir, "table_1.csv"), newline="") as f:
    for row in csv.DictReader(f):
        products[row["Product"].strip()] = {
            "a_hrs": float(row["Workshop_A_Hours"]),
            "b_hrs": float(row["Workshop_B_Hours"]),
            "insp_cost": float(row["Inspection_Sales_Cost"]),
        }

m = products["Microwave_Oven"]
w = products["Water_Heater"]

model = gp.Model("revised_production_plan")
model.setParam("OutputFlag", 0)

# Decision variables
x_m = model.addVar(vtype=GRB.CONTINUOUS, lb=params["microwave_minimum_sales"], name="microwave")
x_w = model.addVar(vtype=GRB.CONTINUOUS, lb=params["water_heater_minimum_sales"], name="water_heater")

# Activation binaries for Workshop A certification/setup gate
y_m = model.addVar(vtype=GRB.BINARY, name="use_A_microwave")
y_w = model.addVar(vtype=GRB.BINARY, name="use_A_water_heater")

bigM = params["bigM"]

# Objective coefficients
unit_value_m = (
    m["a_hrs"] * params["workshop_a_hourly_cost"]
    + m["b_hrs"] * params["workshop_b_hourly_cost"]
    + m["insp_cost"]
    + params["green_bonus_m"]
)
unit_value_w = (
    w["a_hrs"] * params["workshop_a_hourly_cost"]
    + w["b_hrs"] * params["workshop_b_hourly_cost"]
    + w["insp_cost"]
    + params["green_bonus_w"]
)

# Objective: maximize total value net of fixed setup-hour consumption in A valued at A hourly cost
model.setObjective(
    unit_value_m * x_m
    + unit_value_w * x_w
    - params["setup_hours_A"] * params["workshop_a_hourly_cost"] * (y_m + y_w),
    GRB.MAXIMIZE,
)

# Workshop A capacity with overtime and fixed setup hours if product uses A
model.addConstr(
    m["a_hrs"] * x_m
    + w["a_hrs"] * x_w
    + params["setup_hours_A"] * (y_m + y_w)
    <= params["workshop_a_available_hours"] + params["workshop_a_overtime_limit"],
    name="workshop_A_capacity",
)

# Workshop B utilization requirement from original model
model.addConstr(
    m["b_hrs"] * x_m + w["b_hrs"] * x_w >= params["workshop_b_available_hours"],
    name="workshop_B_min_utilization",
)

# Inspection and sales cost limit
model.addConstr(
    m["insp_cost"] * x_m + w["insp_cost"] * x_w <= params["inspection_sales_cost_limit"],
    name="inspection_sales_limit",
)

# Shared technician pool
model.addConstr(
    params["tech_rate_m"] * x_m + params["tech_rate_w"] * x_w <= params["tech_pool_hours"],
    name="technician_pool",
)

# Activation linking constraints for Workshop A gate
model.addConstr(x_m <= bigM * y_m, name="link_m_upper")
model.addConstr(x_w <= bigM * y_w, name="link_w_upper")

model.optimize()

obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
print(f"FINAL_OBJ_VALUE: {obj_val}")
