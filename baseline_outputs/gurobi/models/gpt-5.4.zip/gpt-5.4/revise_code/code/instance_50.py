import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_general_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    return params

def read_monthly_data(path):
    months = []
    buy_price = {}
    sell_price = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row["Month"])
            months.append(m)
            buy_price[m] = float(row["Buy"])
            sell_price[m] = float(row["Sell"])
    months.sort()
    return months, buy_price, sell_price

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = read_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    months, buy_price, sell_price = read_monthly_data(os.path.join(data_dir, "table_1.csv"))

    warehouse_capacity = params["warehouse_capacity"]
    initial_stock = params["initial_stock"]
    fixed_order_cost = params["fixed_order_cost"]
    august_bulk_order_threshold = params["august_bulk_order_threshold"]
    august_bulk_receiving_fee = params["august_bulk_receiving_fee"]

    m = gp.Model("revised_purchase_sales_plan")
    m.setParam("OutputFlag", 0)

    buy = {t: m.addVar(lb=0.0, name=f"buy_{t}") for t in months}
    sell = {t: m.addVar(lb=0.0, name=f"sell_{t}") for t in months}
    stock = {t: m.addVar(lb=0.0, ub=warehouse_capacity, name=f"stock_{t}") for t in months}

    order_flag = {t: m.addVar(vtype=GRB.BINARY, name=f"order_flag_{t}") for t in months}
    august_bulk_flag = m.addVar(vtype=GRB.BINARY, name="august_bulk_flag")

    # Objective: maximize total revenue - purchase costs - fixed order costs - August bulk receiving fee
    m.setObjective(
        gp.quicksum(sell_price[t] * sell[t] - buy_price[t] * buy[t] - fixed_order_cost * order_flag[t] for t in months)
        - august_bulk_receiving_fee * august_bulk_flag,
        GRB.MAXIMIZE
    )

    for i, t in enumerate(months):
        prev_stock = initial_stock if i == 0 else stock[months[i - 1]]

        # Inventory balance
        m.addConstr(stock[t] == prev_stock + buy[t] - sell[t], name=f"balance_{t}")

        # Warehouse capacity immediately after buying
        m.addConstr(prev_stock + buy[t] <= warehouse_capacity, name=f"warehouse_after_buy_{t}")

        # Fixed order cost activation: if buy[t] > 0 then order_flag[t] = 1
        # Tight month-specific upper bound on buy given warehouse limit
        if i == 0:
            max_buy_t = warehouse_capacity - initial_stock
        else:
            max_buy_t = warehouse_capacity
        m.addConstr(buy[t] <= max_buy_t * order_flag[t], name=f"order_activation_{t}")

    # August bulk receiving gate
    if 8 in months:
        august_max_buy = warehouse_capacity
        m.addConstr(
            buy[8] <= august_bulk_order_threshold + (august_max_buy - august_bulk_order_threshold) * august_bulk_flag,
            name="august_bulk_gate"
        )

    m.optimize()

    obj_val = m.ObjVal if m.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
