import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_general_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

    products = ["A", "B"]
    weeks = [1, 2]

    base_profit = {
        "A": params["profit_per_kg_product_A"],
        "B": params["profit_per_kg_product_B"],
    }
    prod_hours = {
        "A": params["hours_per_kg_product_A"],
        "B": params["hours_per_kg_product_B"],
    }
    max_hours = {
        1: params["max_production_hours_week_1"],
        2: params["max_production_hours_week_2"],
    }
    min_ratio_B_to_A = params["min_output_ratio_product_B_to_A"]
    storage_ratio_A_to_B = params["storage_space_ratio_product_A_to_B"]
    storage_space = {"A": storage_ratio_A_to_B, "B": 1.0}
    max_storage_units = {
        1: params["max_storage_product_A_equiv_week_1"] * storage_ratio_A_to_B,
        2: params["max_storage_product_A_equiv_week_2"] * storage_ratio_A_to_B,
    }
    initial_inventory = {
        "A": params["initial_inventory_A"],
        "B": params["initial_inventory_B"],
    }
    storage_cost = {
        "A": params["storage_cost_per_kg_A"],
        "B": params["storage_cost_per_kg_B"],
    }
    promo_bonus = {
        "A": params["promo_profit_bonus_A"],
        "B": params["promo_profit_bonus_B"],
    }
    max_promotions = {
        "A": params["max_promotions_product_A"],
        "B": params["max_promotions_product_B"],
    }

    model = gp.Model("revised_liquid_products")
    model.setParam("OutputFlag", 0)

    produce = model.addVars(products, weeks, lb=0.0, name="produce")
    sell = model.addVars(products, weeks, lb=0.0, name="sell")
    inventory = model.addVars(products, weeks, lb=0.0, name="inventory")
    promo = model.addVars(products, weeks, vtype=GRB.BINARY, name="promo")
    promo_sales = model.addVars(products, weeks, lb=0.0, name="promo_sales")

    # Production capacity by week
    for w in weeks:
        model.addConstr(
            gp.quicksum(prod_hours[p] * produce[p, w] for p in products) <= max_hours[w],
            name=f"prod_hours_week_{w}",
        )

    # Weekly demand mix based on sales
    for w in weeks:
        model.addConstr(
            sell["B", w] >= min_ratio_B_to_A * sell["A", w],
            name=f"min_ratio_week_{w}",
        )

    # Inventory balance
    for p in products:
        model.addConstr(
            initial_inventory[p] + produce[p, 1] - sell[p, 1] == inventory[p, 1],
            name=f"inventory_balance_{p}_1",
        )
        model.addConstr(
            inventory[p, 1] + produce[p, 2] - sell[p, 2] == inventory[p, 2],
            name=f"inventory_balance_{p}_2",
        )

    # Storage capacity by week
    for w in weeks:
        model.addConstr(
            gp.quicksum(storage_space[p] * inventory[p, w] for p in products) <= max_storage_units[w],
            name=f"storage_week_{w}",
        )

    # Promotion limits
    for p in products:
        model.addConstr(
            gp.quicksum(promo[p, w] for w in weeks) <= max_promotions[p],
            name=f"max_promotions_{p}",
        )

    # Promotion bonus applies to sales only in promoted weeks
    big_m_sales = {}
    for p in products:
        max_sales_per_week = max(max_hours[w] / prod_hours[p] + max_storage_units[w] / storage_space[p] for w in weeks)
        big_m_sales[p] = max_sales_per_week + initial_inventory[p]

    for p in products:
        for w in weeks:
            model.addConstr(promo_sales[p, w] <= sell[p, w], name=f"promo_sales_le_sell_{p}_{w}")
            model.addConstr(
                promo_sales[p, w] <= big_m_sales[p] * promo[p, w],
                name=f"promo_sales_le_bigM_{p}_{w}",
            )

    # Objective: sales profit + promo bonus on promoted sales - storage cost for carryover from week 1 to week 2
    obj = gp.quicksum(
        base_profit[p] * sell[p, w] + promo_bonus[p] * promo_sales[p, w]
        for p in products for w in weeks
    ) - gp.quicksum(
        storage_cost[p] * inventory[p, 1] for p in products
    )

    model.setObjective(obj, GRB.MAXIMIZE)
    model.optimize()

    final_obj = model.ObjVal if model.status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {final_obj}")


if __name__ == "__main__":
    main()
