import os
import csv
import gurobipy as gp
from gurobipy import GRB


def read_table_1(path):
    workshops = []
    prod_capacity = {}
    rates = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row["Workshop"].strip()
            workshops.append(w)
            prod_capacity[w] = float(row["Production_Capacity_hours"])
            rates[(w, 1)] = float(row["Production_Rate_Component_1_units_per_hour"])
            rates[(w, 2)] = float(row["Production_Rate_Component_2_units_per_hour"])
            rates[(w, 3)] = float(row["Production_Rate_Component_3_units_per_hour"])
    return workshops, prod_capacity, rates


def read_general_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"])
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    table_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    workshops, prod_capacity, rates = read_table_1(table_path)
    params = read_general_parameters(params_path)

    components = [1, 2, 3]
    shifts = ["day", "night"]

    reg_limit = {}
    ot_limit = {}
    bigM = {}
    for w in workshops:
        reg_limit[(w, "day")] = params[f"regular_hours_limit_day_{w}"]
        reg_limit[(w, "night")] = params[f"regular_hours_limit_night_{w}"]
        ot_limit[(w, "day")] = params[f"overtime_capacity_day_{w}"]
        ot_limit[(w, "night")] = params[f"overtime_capacity_night_{w}"]
        bigM[w] = params[f"bigM_shift_{w}"]

    penalty_night_hour = params["penalty_night_hour"]
    penalty_overtime_hour = params["penalty_overtime_hour"]
    penalty_shortage_per_unit = params["penalty_shortage_per_unit"]
    z_target = params["z_target"]

    model = gp.Model("revised_workshop_plan")
    model.setParam("OutputFlag", 0)

    x_reg = model.addVars(workshops, shifts, components, lb=0.0, vtype=GRB.CONTINUOUS, name="x_reg")
    x_ot = model.addVars(workshops, shifts, components, lb=0.0, vtype=GRB.CONTINUOUS, name="x_ot")
    y_active = model.addVars(workshops, shifts, vtype=GRB.BINARY, name="y_active")

    z = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="z")
    shortage = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="shortage")

    # Workshop total available hours must respect original capacity
    for w in workshops:
        model.addConstr(
            gp.quicksum(x_reg[w, s, c] + x_ot[w, s, c] for s in shifts for c in components) <= prod_capacity[w],
            name=f"total_capacity_{w}"
        )

    # Shift regular and overtime limits
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x_reg[w, s, c] for c in components) <= reg_limit[(w, s)],
                name=f"reg_limit_{w}_{s}"
            )
            model.addConstr(
                gp.quicksum(x_ot[w, s, c] for c in components) <= ot_limit[(w, s)],
                name=f"ot_limit_{w}_{s}"
            )

    # Active workshop per shift and supervision limit
    for s in shifts:
        for w in workshops:
            model.addConstr(
                gp.quicksum(x_reg[w, s, c] + x_ot[w, s, c] for c in components) <= bigM[w] * y_active[w, s],
                name=f"active_link_{w}_{s}"
            )
        model.addConstr(
            gp.quicksum(y_active[w, s] for w in workshops) <= 2,
            name=f"max_two_active_{s}"
        )

    # Completed products limited by each component total output
    for c in components:
        model.addConstr(
            z <= gp.quicksum(
                rates[(w, c)] * (x_reg[w, s, c] + x_ot[w, s, c])
                for w in workshops for s in shifts
            ),
            name=f"component_balance_{c}"
        )

    # Shortage relative to target
    model.addConstr(shortage >= z_target - z, name="shortage_def")

    # Objective: maximize completed products while keeping night/overtime/shortage penalties small
    night_hours = gp.quicksum(x_reg[w, "night", c] for w in workshops for c in components)
    overtime_hours = gp.quicksum(x_ot[w, s, c] for w in workshops for s in shifts for c in components)

    model.setObjective(
        z
        - penalty_night_hour * night_hours
        - penalty_overtime_hour * overtime_hours
        - penalty_shortage_per_unit * shortage,
        GRB.MAXIMIZE
    )

    model.optimize()

    obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
