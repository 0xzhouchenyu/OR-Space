import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

budget = params["budget"]
property_4_excludes_property_3 = params.get("property_4_excludes_property_3", 0.0)
scen_1_prob = params["scen_1_prob"]
scen_2_prob = params["scen_2_prob"]
scen_1_risky_multiplier = params["scen_1_risky_multiplier"]
scen_2_risky_multiplier = params["scen_2_risky_multiplier"]
total_risky_budget = params["total_risky_budget"]
per_property_risky_cap = params["per_property_risky_cap"]
max_risky_properties = int(round(params["max_risky_properties"]))

# Read property data
properties = []
with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            "name": row["Property"],
            "income": float(row["Annual_Income"]),
            "cost": float(row["Cost"])
        })

# Expected multiplier for risky share
expected_risky_multiplier = (
    scen_1_prob * scen_1_risky_multiplier +
    scen_2_prob * scen_2_risky_multiplier
)

# Build model
model = gp.Model("Revised_RealEstateInvestment")
model.setParam("OutputFlag", 0)

# Decision variables
x = {}   # buy property
r = {}   # fraction allocated to risky leasing
z = {}   # whether property has any risky leasing

for p in properties:
    name = p["name"]
    x[name] = model.addVar(vtype=GRB.BINARY, name=f"buy_{name}")
    r[name] = model.addVar(lb=0.0, ub=1.0, vtype=GRB.CONTINUOUS, name=f"risky_frac_{name}")
    z[name] = model.addVar(vtype=GRB.BINARY, name=f"risky_used_{name}")

# Objective: expected annual income
obj = gp.quicksum(
    p["income"] * x[p["name"]] +
    p["income"] * (expected_risky_multiplier - 1.0) * r[p["name"]]
    for p in properties
)
model.setObjective(obj, GRB.MAXIMIZE)

# Budget for purchases
model.addConstr(
    gp.quicksum(p["cost"] * x[p["name"]] for p in properties) <= budget,
    name="purchase_budget"
)

# Mutual exclusion: if Property 4 is purchased, Property 3 cannot be purchased
if property_4_excludes_property_3 > 0.5:
    model.addConstr(x["Property_4"] + x["Property_3"] <= 1, name="prop4_excludes_prop3")

# Risky allocation only on purchased properties, with per-property cap and activation
for p in properties:
    name = p["name"]
    model.addConstr(r[name] <= per_property_risky_cap * x[name], name=f"risky_cap_if_bought_{name}")
    model.addConstr(r[name] <= per_property_risky_cap * z[name], name=f"risky_activation_upper_{name}")
    model.addConstr(z[name] <= x[name], name=f"risky_only_if_bought_{name}")

# Total risky exposure budget based on acquisition cost of properties hosting any risky tenants
model.addConstr(
    gp.quicksum(p["cost"] * z[p["name"]] for p in properties) <= total_risky_budget,
    name="total_risky_budget"
)

# Maximum number of risky properties
model.addConstr(
    gp.quicksum(z[p["name"]] for p in properties) <= max_risky_properties,
    name="max_risky_properties"
)

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
