import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    param_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(param_path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def main():
    params = load_parameters()

    product_units = params["product_units"]

    pollution = {
        "truck": params["truck_pollution"],
        "van": params["van_pollution"],
        "moto": params["motorcycle_pollution"],
        "ev": params["electric_vehicle_pollution"],
    }

    capacity = {
        "truck": params["truck_capacity"],
        "van": params["van_capacity"],
        "moto": params["motorcycle_capacity"],
        "ev": params["electric_vehicle_capacity"],
    }

    max_total_pollution = params["max_total_pollution"]
    min_truck_trips = params["min_truck_trips"]

    sales_points = ["sp1", "sp2", "sp3"]
    days = ["day1", "day2", "day3"]
    vehicles = ["truck", "van", "moto", "ev"]

    sales_point_share = {
        "sp1": params["sales_point_share_sp1"],
        "sp2": params["sales_point_share_sp2"],
        "sp3": params["sales_point_share_sp3"],
    }

    min_truck_share = {
        "sp1": params["min_truck_share_sp1"],
        "sp2": params["min_truck_share_sp2"],
        "sp3": params["min_truck_share_sp3"],
    }

    M = {
        "truck": params["M_truck_sp_day"],
        "ev": params["M_ev_sp_day"],
        "van": params["M_van_sp_day"],
        "moto": params["M_moto_sp_day"],
    }

    demand_sp = {sp: product_units * sales_point_share[sp] for sp in sales_points}

    model = gp.Model("revised_transportation_optimization")
    model.setParam("OutputFlag", 0)

    x = model.addVars(sales_points, days, vehicles, vtype=GRB.INTEGER, lb=0, name="x")
    y = model.addVars(sales_points, days, vtype=GRB.BINARY, name="family_mode")

    model.setObjective(
        gp.quicksum(pollution[v] * x[sp, d, v] for sp in sales_points for d in days for v in vehicles),
        GRB.MINIMIZE
    )

    for sp in sales_points:
        model.addConstr(
            gp.quicksum(capacity[v] * x[sp, d, v] for d in days for v in vehicles) >= demand_sp[sp],
            name=f"demand_{sp}"
        )

    model.addConstr(
        gp.quicksum(pollution[v] * x[sp, d, v] for sp in sales_points for d in days for v in vehicles)
        <= max_total_pollution,
        name="max_total_pollution"
    )

    model.addConstr(
        gp.quicksum(x[sp, d, "truck"] for sp in sales_points for d in days) >= min_truck_trips,
        name="min_total_truck_trips"
    )

    for sp in sales_points:
        truck_trips_sp = gp.quicksum(x[sp, d, "truck"] for d in days)
        total_trips_sp = gp.quicksum(x[sp, d, v] for d in days for v in vehicles)
        model.addConstr(
            truck_trips_sp >= min_truck_share[sp] * total_trips_sp,
            name=f"min_truck_share_{sp}"
        )

    for sp in sales_points:
        for d in days:
            model.addConstr(x[sp, d, "truck"] <= M["truck"] * y[sp, d], name=f"gate_truck_{sp}_{d}")
            model.addConstr(x[sp, d, "ev"] <= M["ev"] * y[sp, d], name=f"gate_ev_{sp}_{d}")
            model.addConstr(x[sp, d, "van"] <= M["van"] * (1 - y[sp, d]), name=f"gate_van_{sp}_{d}")
            model.addConstr(x[sp, d, "moto"] <= M["moto"] * (1 - y[sp, d]), name=f"gate_moto_{sp}_{d}")

    model.optimize()

    obj_val = model.ObjVal
    if abs(obj_val - round(obj_val)) <= 1e-9:
        obj_str = str(int(round(obj_val)))
    else:
        obj_str = str(obj_val)

    print(f"FINAL_OBJ_VALUE: {obj_str}")

if __name__ == "__main__":
    main()
