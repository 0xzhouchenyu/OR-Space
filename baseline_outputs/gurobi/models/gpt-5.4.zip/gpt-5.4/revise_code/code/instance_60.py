import os
import csv
import re
import gurobipy as gp
from gurobipy import GRB


def get_data_dir():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


def read_parameters(data_dir):
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = row["Value"].strip()
            params[name] = val
    return params


def read_distance_matrix(data_dir, n):
    D = [[0.0] * n for _ in range(n)]
    with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
        lines = f.readlines()

    for line in lines[1:]:
        nums = re.findall(r"\d+", line)
        if not nums:
            continue
        row_idx = int(nums[0]) - 1
        for j, val in enumerate(nums[1:]):
            col_idx = row_idx + 1 + j
            if col_idx < n:
                D[row_idx][col_idx] = float(val)
                D[col_idx][row_idx] = float(val)
    return D


def solve():
    data_dir = get_data_dir()
    params = read_parameters(data_dir)

    n = int(params["num_customers"])
    depot = int(params["start_location"]) - 1
    max_route_length_day = float(params["max_route_length_day"])
    route_cost_day = float(params["route_cost_day"])

    D = read_distance_matrix(data_dir, n)

    days = [0, 1]
    nodes = list(range(n))
    customers = [i for i in nodes if i != depot]

    m = gp.Model("two_day_tsp")
    m.setParam("OutputFlag", 0)

    x = m.addVars(
        [(i, j, d) for d in days for i in nodes for j in nodes if i != j],
        vtype=GRB.BINARY,
        name="x"
    )
    y = m.addVars(
        [(i, d) for i in customers for d in days],
        vtype=GRB.BINARY,
        name="y"
    )
    z = m.addVars(days, vtype=GRB.BINARY, name="z")
    u = m.addVars(
        [(i, d) for d in days for i in customers],
        lb=1.0,
        ub=float(len(customers)),
        vtype=GRB.CONTINUOUS,
        name="u"
    )

    travel_cost = gp.quicksum(D[i][j] * x[i, j, d] for d in days for i, j, dd in x.keys() if dd == d)
    fixed_cost = route_cost_day * gp.quicksum(z[d] for d in days)
    m.setObjective(travel_cost + fixed_cost, GRB.MINIMIZE)

    for i in customers:
        m.addConstr(gp.quicksum(y[i, d] for d in days) == 1, name=f"assign_once_{i}")

    for d in days:
        for i in customers:
            m.addConstr(
                gp.quicksum(x[i, j, d] for j in nodes if j != i) == y[i, d],
                name=f"out_customer_{i}_{d}"
            )
            m.addConstr(
                gp.quicksum(x[j, i, d] for j in nodes if j != i) == y[i, d],
                name=f"in_customer_{i}_{d}"
            )

    for d in days:
        m.addConstr(
            gp.quicksum(x[depot, j, d] for j in customers) == z[d],
            name=f"depot_out_{d}"
        )
        m.addConstr(
            gp.quicksum(x[j, depot, d] for j in customers) == z[d],
            name=f"depot_in_{d}"
        )

    for d in days:
        for i in customers:
            m.addConstr(y[i, d] <= z[d], name=f"use_day_if_customer_{i}_{d}")

    N = len(customers)
    for d in days:
        for i in customers:
            for j in customers:
                if i != j:
                    m.addConstr(
                        u[i, d] - u[j, d] + N * x[i, j, d] <= N - 1,
                        name=f"mtz_{i}_{j}_{d}"
                    )

    for d in days:
        m.addConstr(
            gp.quicksum(D[i][j] * x[i, j, d] for i in nodes for j in nodes if i != j) <= max_route_length_day,
            name=f"max_route_len_{d}"
        )

    m.optimize()

    obj = m.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj}")


if __name__ == "__main__":
    solve()
