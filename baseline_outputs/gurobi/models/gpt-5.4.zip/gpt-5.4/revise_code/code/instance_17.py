import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB


def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    parts = []
    with open(os.path.join(base_dir, "table_1.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                "id": int(row["Key_Part"]),
                "distance": float(row["Distance_from_Airport_km"]),
                "p_heavy": float(row["Probability_of_Destruction_per_Heavy_Bomb"]),
                "p_light": float(row["Probability_of_Destruction_per_Light_Bomb"]),
            })

    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])

    return parts, params


def base_fuel_per_heavy(distance, params):
    return (
        distance / params["fuel_efficiency_heavy_bomb"]
        + distance / params["fuel_efficiency_empty"]
        + params["fuel_takeoff_landing"]
    )


def base_fuel_per_light(distance, params):
    return (
        distance / params["fuel_efficiency_light_bomb"]
        + distance / params["fuel_efficiency_empty"]
        + params["fuel_takeoff_landing"]
    )


def prob_destroy_part(xh, xl, p_h, p_l):
    return 1.0 - ((1.0 - p_h) ** xh) * ((1.0 - p_l) ** xl)


def prob_at_least_k(probs, k):
    n = len(probs)
    dp = [0.0] * (n + 1)
    dp[0] = 1.0
    for i in range(n):
        new_dp = [0.0] * (n + 1)
        for j in range(i + 2):
            new_dp[j] += dp[j] * (1.0 - probs[i])
            if j > 0:
                new_dp[j] += dp[j - 1] * probs[i]
        dp = new_dp
    return sum(dp[j] for j in range(k, n + 1))


def main():
    parts, params = load_data()
    n = len(parts)

    max_heavy = int(round(params["max_heavy_bombs"]))
    max_light = int(round(params["max_light_bombs"]))
    fuel_limit = float(params["fuel_limit"])
    min_parts = int(round(params["min_parts_destroyed"]))

    max_sorties_A = int(round(params["max_sorties_A"]))
    max_sorties_B = int(round(params["max_sorties_B"]))
    overhead_A = float(params["sortie_fuel_overhead_A"])
    overhead_B = float(params["sortie_fuel_overhead_B"])
    scen_prob_A = float(params["scenario_prob_A"])
    scen_prob_B = float(params["scenario_prob_B"])

    sortie_cap = min(max_sorties_A, max_sorties_B)

    fuel_h_base = [base_fuel_per_heavy(p["distance"], params) for p in parts]
    fuel_l_base = [base_fuel_per_light(p["distance"], params) for p in parts]

    feasible_allocs = []
    objective_value = {}

    for i in range(n):
        feasible_allocs.append([])
        for xh in range(max_heavy + 1):
            for xl in range(max_light + 1):
                sorties = xh + xl
                if sorties > sortie_cap:
                    continue

                fuel_A = xh * (fuel_h_base[i] + overhead_A) + xl * (fuel_l_base[i] + overhead_A)
                fuel_B = xh * (fuel_h_base[i] + overhead_B) + xl * (fuel_l_base[i] + overhead_B)

                if fuel_A <= fuel_limit + 1e-9 and fuel_B <= fuel_limit + 1e-9:
                    feasible_allocs[i].append((xh, xl))

    destroy_prob = {}
    for i in range(n):
        for xh, xl in feasible_allocs[i]:
            destroy_prob[(i, xh, xl)] = prob_destroy_part(
                xh, xl, parts[i]["p_heavy"], parts[i]["p_light"]
            )

    # Since the same precommitted package is used in both scenarios and destruction probabilities
    # are not scenario-dependent, the expected mission success probability equals the single package
    # mission success probability times (scenario_prob_A + scenario_prob_B).
    # We keep the scenario weights explicitly.
    mission_success = {}
    for i in range(n):
        for xh, xl in feasible_allocs[i]:
            pass

    alloc_lists = feasible_allocs

    # Enumerate combinations of per-part allocations, compute exact objective, then solve as MILP over finite set.
    plans = []
    plan_obj = []

    current = []

    def recurse(idx, used_h, used_l, used_sorties, fuelA, fuelB):
        if idx == n:
            probs = [
                destroy_prob[(i, current[i][0], current[i][1])]
                for i in range(n)
            ]
            success_prob = prob_at_least_k(probs, min_parts)
            expected_success = (scen_prob_A + scen_prob_B) * success_prob
            plans.append(tuple(current))
            plan_obj.append(expected_success)
            return

        for xh, xl in alloc_lists[idx]:
            nh = used_h + xh
            nl = used_l + xl
            ns = used_sorties + xh + xl
            if nh > max_heavy or nl > max_light or ns > sortie_cap:
                continue

            addA = xh * (fuel_h_base[idx] + overhead_A) + xl * (fuel_l_base[idx] + overhead_A)
            addB = xh * (fuel_h_base[idx] + overhead_B) + xl * (fuel_l_base[idx] + overhead_B)

            if fuelA + addA > fuel_limit + 1e-9:
                continue
            if fuelB + addB > fuel_limit + 1e-9:
                continue

            current.append((xh, xl))
            recurse(idx + 1, nh, nl, ns, fuelA + addA, fuelB + addB)
            current.pop()

    recurse(0, 0, 0, 0, 0.0, 0.0)

    model = gp.Model("revised_bomb_allocation")
    model.setParam("OutputFlag", 0)

    z = model.addVars(len(plans), vtype=GRB.BINARY, name="z")
    model.addConstr(gp.quicksum(z[p] for p in range(len(plans))) == 1)
    model.setObjective(gp.quicksum(plan_obj[p] * z[p] for p in range(len(plans))), GRB.MAXIMIZE)

    model.optimize()

    obj = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj}")


if __name__ == "__main__":
    main()
