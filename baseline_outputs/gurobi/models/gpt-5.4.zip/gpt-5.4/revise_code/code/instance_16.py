import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_monthly_data(filepath):
    months = []
    purchasing_prices = {}
    selling_prices = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row["Month"])
            months.append(m)
            purchasing_prices[m] = float(row["Purchasing_Price_Yuan"])
            selling_prices[m] = float(row["Selling_Price_Yuan"])
    return months, purchasing_prices, selling_prices

def load_general_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    return params

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

months, purchasing_prices, selling_prices = load_monthly_data(os.path.join(data_dir, "table_1.csv"))
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

warehouse_capacity = params["warehouse_capacity"]
initial_stock = params["initial_stock"]
fixed_ordering_cost = params["fixed_ordering_cost"]
month2_bulk_receiving_threshold = params["month2_bulk_receiving_threshold"]
month2_bulk_receiving_fee = params["month2_bulk_receiving_fee"]

model = gp.Model("revised_purchasing_sales_plan")
model.setParam("OutputFlag", 0)

x = {m: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"purchase_{m}") for m in months}
s = {m: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"sell_{m}") for m in months}
inv = {m: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"inventory_{m}") for m in months}

y_order = {m: model.addVar(vtype=GRB.BINARY, name=f"order_indicator_{m}") for m in months}
z_bulk2 = model.addVar(vtype=GRB.BINARY, name="month2_bulk_receiving_indicator")

for idx, m in enumerate(months):
    prev_inv = initial_stock if idx == 0 else inv[months[idx - 1]]

    model.addConstr(inv[m] == prev_inv + x[m] - s[m], name=f"inventory_balance_{m}")
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, name=f"warehouse_after_purchase_{m}")
    model.addConstr(inv[m] <= warehouse_capacity, name=f"warehouse_end_{m}")
    model.addConstr(s[m] <= prev_inv + x[m], name=f"sell_limit_{m}")

    model.addConstr(x[m] <= warehouse_capacity * y_order[m], name=f"fixed_order_link_{m}")

month2 = 2
if month2 in months:
    M2 = warehouse_capacity
    model.addConstr(x[month2] <= month2_bulk_receiving_threshold + (M2 - month2_bulk_receiving_threshold) * z_bulk2,
                    name="month2_bulk_trigger_upper")
    model.addConstr(x[month2] >= month2_bulk_receiving_threshold * z_bulk2,
                    name="month2_bulk_trigger_lower")

objective = gp.quicksum(
    selling_prices[m] * s[m] - purchasing_prices[m] * x[m] - fixed_ordering_cost * y_order[m]
    for m in months
)

if month2 in months:
    objective -= month2_bulk_receiving_fee * z_bulk2

model.setObjective(objective, GRB.MAXIMIZE)
model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
