import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_general_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            value_str = row["Value"].strip()
            try:
                value = int(value_str)
            except ValueError:
                try:
                    value = float(value_str)
                except ValueError:
                    value = value_str
            params[name] = value
    return params


base_dir = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(base_dir, "data", "general_parameters.csv")
params = load_general_parameters(data_path)

cost_A = params["cost_per_chair_A"]
cost_B = params["cost_per_chair_B"]
cost_C = params["cost_per_chair_C"]

chairs_per_order_A = params["chairs_per_order_A"]
chairs_per_order_B = params["chairs_per_order_B"]
chairs_per_order_C = params["chairs_per_order_C"]

min_total = params["min_total_chairs"]
max_total = params["max_total_chairs"]

min_chairs_B_if_A = params["min_chairs_B_if_A"]
dependency_B_C = params["dependency_B_C"]

fixed_fee_A_regular = params["fixed_fee_A_regular"]
fixed_fee_A_express = params["fixed_fee_A_express"]
fixed_fee_B_regular = params["fixed_fee_B_regular"]
fixed_fee_B_express = params["fixed_fee_B_express"]
fixed_fee_C_regular = params["fixed_fee_C_regular"]
fixed_fee_C_express = params["fixed_fee_C_express"]

weekly_order_budget = params["weekly_order_budget"]

max_orders_A = max_total // chairs_per_order_A + 1
max_orders_B = max_total // chairs_per_order_B + 1
max_orders_C = max_total // chairs_per_order_C + 1

m = gp.Model("FurnitureOrderRevised")
m.setParam("OutputFlag", 0)

x_A = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_A, name="orders_A")
x_B = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_B, name="orders_B")
x_C = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_C, name="orders_C")

y_A = m.addVar(vtype=GRB.BINARY, name="use_A")
y_B = m.addVar(vtype=GRB.BINARY, name="use_B")
y_C = m.addVar(vtype=GRB.BINARY, name="use_C")

r_A = m.addVar(vtype=GRB.BINARY, name="A_regular")
e_A = m.addVar(vtype=GRB.BINARY, name="A_express")
r_B = m.addVar(vtype=GRB.BINARY, name="B_regular")
e_B = m.addVar(vtype=GRB.BINARY, name="B_express")
r_C = m.addVar(vtype=GRB.BINARY, name="C_regular")
e_C = m.addVar(vtype=GRB.BINARY, name="C_express")

chairs_A = chairs_per_order_A * x_A
chairs_B = chairs_per_order_B * x_B
chairs_C = chairs_per_order_C * x_C

m.setObjective(
    cost_A * chairs_A
    + cost_B * chairs_B
    + cost_C * chairs_C
    + fixed_fee_A_regular * r_A
    + fixed_fee_A_express * e_A
    + fixed_fee_B_regular * r_B
    + fixed_fee_B_express * e_B
    + fixed_fee_C_regular * r_C
    + fixed_fee_C_express * e_C,
    GRB.MINIMIZE,
)

m.addConstr(chairs_A + chairs_B + chairs_C >= min_total, name="MinChairs")
m.addConstr(chairs_A + chairs_B + chairs_C <= max_total, name="MaxChairs")

m.addConstr(x_A <= max_orders_A * y_A, name="LinkA1")
m.addConstr(x_A >= y_A, name="LinkA2")
m.addConstr(x_B <= max_orders_B * y_B, name="LinkB1")
m.addConstr(x_B >= y_B, name="LinkB2")
m.addConstr(x_C <= max_orders_C * y_C, name="LinkC1")
m.addConstr(x_C >= y_C, name="LinkC2")

m.addConstr(chairs_B >= min_chairs_B_if_A * y_A, name="DepAB")
if int(dependency_B_C) == 1:
    m.addConstr(y_B <= y_C, name="DepBC")

m.addConstr(r_A + e_A == y_A, name="ChannelA")
m.addConstr(r_B + e_B == y_B, name="ChannelB")
m.addConstr(r_C + e_C == y_C, name="ChannelC")

m.addConstr(r_A + e_A + r_B + e_B + r_C + e_C <= weekly_order_budget, name="WeeklyOrderBudget")

m.optimize()

obj_val = m.ObjVal
if abs(obj_val - round(obj_val)) < 1e-9:
    obj_val = int(round(obj_val))

print(f"FINAL_OBJ_VALUE: {obj_val}")
