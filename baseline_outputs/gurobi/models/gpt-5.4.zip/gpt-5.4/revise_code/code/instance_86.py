import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_csv_data(filepath):
    data = []
    with open(filepath, "r", newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip(): (v.strip() if v is not None else "") for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    products_raw = load_csv_data(os.path.join(data_dir, "table_1.csv"))
    params_raw = load_csv_data(os.path.join(data_dir, "general_parameters.csv"))

    params = {}
    for row in params_raw:
        params[row["Parameter_Name"]] = float(row["Value"])

    product_data = {}
    for row in products_raw:
        name = row["Product"]
        product_data[name] = {
            "price": float(row["Price_per_pack"]),
            "grains": float(row["Grains_per_pack"]),
            "meat": float(row["Meat_per_pack"]),
            "variable_cost": float(row["Variable_cost_per_pack"]),
            "capacity": float(row["Production_capacity"]) if row["Production_capacity"] else None,
        }

    max_grains = params["max_grains"]
    price_grains = params["price_per_lb_grains"]
    max_meat = params["max_meat"]
    price_meat = params["price_per_lb_meat"]
    line_fixed_cost = params["line_fixed_cost"]
    line_capacity_packs = params["line_capacity_packs"]
    min_batch_packs = params["min_batch_packs"]
    min_yummies = params["min_yummies"]
    retailer_rebate_yummies_threshold = params["retailer_rebate_yummies_threshold"]
    retailer_rebate_min_meaties = params["retailer_rebate_min_meaties"]
    retailer_rebate_fixed = params["retailer_rebate_fixed"]

    m = product_data["Meaties"]
    y = product_data["Yummies"]

    profit_meaties = m["price"] - m["variable_cost"] - (m["grains"] * price_grains + m["meat"] * price_meat)
    profit_yummies = y["price"] - y["variable_cost"] - (y["grains"] * price_grains + y["meat"] * price_meat)

    model = gp.Model("HealthyPetFoods_Revised")
    model.setParam("OutputFlag", 0)

    x_meaties = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="Meaties")
    x_yummies = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="Yummies")
    line_active = model.addVar(vtype=GRB.BINARY, name="LineActive")
    rebate_earned = model.addVar(vtype=GRB.BINARY, name="RetailerRebateEarned")

    model.setObjective(
        profit_meaties * x_meaties
        + profit_yummies * x_yummies
        - line_fixed_cost * line_active
        + retailer_rebate_fixed * rebate_earned,
        GRB.MAXIMIZE,
    )

    model.addConstr(m["grains"] * x_meaties + y["grains"] * x_yummies <= max_grains, name="GrainsLimit")
    model.addConstr(m["meat"] * x_meaties + y["meat"] * x_yummies <= max_meat, name="MeatLimit")

    if m["capacity"] is not None:
        model.addConstr(x_meaties <= m["capacity"], name="MeatiesCapacity")
    if y["capacity"] is not None:
        model.addConstr(x_yummies <= y["capacity"], name="YummiesCapacity")

    model.addConstr(x_meaties + x_yummies <= line_capacity_packs * line_active, name="LineCapacityIfActive")
    model.addConstr(x_meaties + x_yummies >= min_batch_packs * line_active, name="MinBatchIfActive")
    model.addConstr(x_yummies >= min_yummies * line_active, name="MinYummiesIfActive")

    model.addConstr(x_yummies >= retailer_rebate_yummies_threshold * rebate_earned, name="RebateYummiesThreshold")
    model.addConstr(x_meaties >= retailer_rebate_min_meaties * rebate_earned, name="RebateMeatiesThreshold")
    model.addConstr(rebate_earned <= line_active, name="RebateOnlyIfLineActive")

    model.optimize()

    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
