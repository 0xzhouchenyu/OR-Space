import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_csv_data(filepath):
    data = []
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    table1 = load_csv_data(os.path.join(data_dir, "table_1.csv"))
    params = load_csv_data(os.path.join(data_dir, "general_parameters.csv"))

    param_dict = {row["Parameter_Name"]: float(row["Value"]) for row in params}

    proc_I = table1[0]
    proc_II = table1[1]
    profit_row = table1[2]

    a_I = float(proc_I["Model_A_hours_per_unit"])
    b_I = float(proc_I["Model_B_hours_per_unit"])
    a_II = float(proc_II["Model_A_hours_per_unit"])
    b_II = float(proc_II["Model_B_hours_per_unit"])
    cap_II = float(proc_II["Maximum_Weekly_Processing_Capacity"])

    profit_A = float(profit_row["Model_A_hours_per_unit"])
    profit_B = float(profit_row["Model_B_hours_per_unit"])

    min_profit = param_dict["min_weekly_profit"]
    min_A = param_dict["min_model_A_units"]
    min_B = param_dict["min_model_B_units"]
    process_I_hours = param_dict["process_I_hours"]
    max_overtime = param_dict["process_II_max_overtime"]
    red_A = param_dict["model_A_overtime_profit_reduction"]
    red_B = param_dict["model_B_overtime_profit_reduction"]

    model = gp.Model("revised_microcomputer_production")
    model.setParam("OutputFlag", 0)

    xA_r = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA_regular")
    xA_o = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA_overtime")
    xB_r = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB_regular")
    xB_o = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB_overtime")

    total_A = xA_r + xA_o
    total_B = xB_r + xB_o

    model.addConstr(a_I * total_A + b_I * total_B == process_I_hours, name="process_I_exact")
    model.addConstr(a_II * xA_r + b_II * xB_r <= cap_II, name="process_II_regular_capacity")
    model.addConstr(a_II * xA_o + b_II * xB_o <= max_overtime, name="process_II_overtime_capacity")

    model.addConstr(total_A >= min_A, name="min_model_A")
    model.addConstr(total_B >= min_B, name="min_model_B")

    total_profit = (
        profit_A * xA_r
        + profit_B * xB_r
        + (profit_A - red_A) * xA_o
        + (profit_B - red_B) * xB_o
    )
    model.addConstr(total_profit >= min_profit, name="min_profit")

    total_units = total_A + total_B
    model.setObjective(total_units, GRB.MAXIMIZE)

    model.optimize()

    obj_val = model.ObjVal
    if abs(obj_val - round(obj_val)) < 1e-9:
        obj_str = str(int(round(obj_val)))
    else:
        obj_str = str(obj_val)

    print(f"FINAL_OBJ_VALUE: {obj_str}")


if __name__ == "__main__":
    main()
