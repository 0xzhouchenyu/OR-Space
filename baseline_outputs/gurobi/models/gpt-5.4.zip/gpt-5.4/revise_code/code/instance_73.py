import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_parameters(base_dir):
    params = {}
    path = os.path.join(base_dir, "data", "general_parameters.csv")
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    return params

def read_children_data(base_dir):
    children = []
    costs = {}
    path = os.path.join(base_dir, "data", "table_1.csv")
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row["Child"].strip()
            children.append(child)
            costs[child] = float(row["Cost"].strip())
    return children, costs

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    params = read_parameters(base_dir)
    children, costs = read_children_data(base_dir)

    max_children = int(float(params["max_children_trip"]))
    min_children = int(float(params["min_children_trip"]))
    max_distinct = int(float(params["max_distinct_children_trip"]))
    total_cost_budget = float(params["total_cost_budget"])
    bonus_saving = float(params["bonus_saving"])
    min_bob_days = int(float(params["min_bob_days"]))

    days = [1, 2]

    model = gp.Model("FamilyTripTwoDay")
    model.setParam("OutputFlag", 0)

    x = model.addVars(children, days, vtype=GRB.BINARY, name="x")
    y = model.addVars(children, vtype=GRB.BINARY, name="y")
    z = model.addVars(children, vtype=GRB.BINARY, name="z")

    # Daily min/max children constraints
    for d in days:
        model.addConstr(gp.quicksum(x[c, d] for c in children) >= min_children, name=f"MinChildren_day{d}")
        model.addConstr(gp.quicksum(x[c, d] for c in children) <= max_children, name=f"MaxChildren_day{d}")

    # Distinct child indicators across both days
    for c in children:
        model.addConstr(y[c] >= x[c, 1], name=f"DistinctLB1_{c}")
        model.addConstr(y[c] >= x[c, 2], name=f"DistinctLB2_{c}")
        model.addConstr(y[c] <= x[c, 1] + x[c, 2], name=f"DistinctUB_{c}")

    model.addConstr(gp.quicksum(y[c] for c in children) <= max_distinct, name="MaxDistinctChildren")

    # Bonus indicator: child attends both days
    for c in children:
        model.addConstr(z[c] <= x[c, 1], name=f"BonusUB1_{c}")
        model.addConstr(z[c] <= x[c, 2], name=f"BonusUB2_{c}")
        model.addConstr(z[c] >= x[c, 1] + x[c, 2] - 1, name=f"BonusLB_{c}")

    # Bob minimum attendance days
    model.addConstr(gp.quicksum(x["Bob", d] for d in days) >= min_bob_days, name="MinBobDays")

    # Daily relationship constraints
    for d in days:
        model.addConstr(x["Alice", d] + x["Diana", d] <= 1, name=f"AliceDiana_day{d}")
        model.addConstr(x["Bob", d] + x["Charlie", d] <= 1, name=f"BobCharlie_day{d}")
        model.addConstr(x["Charlie", d] <= x["Diana", d], name=f"CharlieRequiresDiana_day{d}")
        model.addConstr(x["Diana", d] <= x["Ella", d], name=f"DianaRequiresElla_day{d}")

    # Availability constraints
    model.addConstr(x["Alice", 2] == 0, name="AliceOnlyDay1")
    model.addConstr(x["Charlie", 1] == 0, name="CharlieOnlyDay2")
    model.addConstr(x["Diana", 1] == 0, name="DianaOnlyDay2")

    # Objective and budget
    total_cost = gp.quicksum(costs[c] * x[c, d] for c in children for d in days)
    total_bonus = gp.quicksum(bonus_saving * z[c] for c in children)
    net_cost = total_cost - total_bonus

    model.addConstr(net_cost <= total_cost_budget, name="TotalCostBudget")
    model.setObjective(net_cost, GRB.MINIMIZE)

    model.optimize()

    obj_val = model.ObjVal
    if abs(obj_val - round(obj_val)) < 1e-9:
        obj_str = str(int(round(obj_val)))
    else:
        obj_str = str(obj_val)

    print(f"FINAL_OBJ_VALUE: {obj_str}")

if __name__ == "__main__":
    main()
