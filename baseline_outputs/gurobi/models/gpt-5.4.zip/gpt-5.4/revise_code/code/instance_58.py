import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_parameters(data_path)

    fruits = ["apples", "pears", "oranges", "lemons"]
    seasons = ["spring", "autumn"]

    profit = {
        "apples": params["profit_per_acre_apples"],
        "pears": params["profit_per_acre_pears"],
        "oranges": params["profit_per_acre_oranges"],
        "lemons": params["profit_per_acre_lemons"],
    }

    water = {
        ("apples", "spring"): params["water_per_acre_apples_spring"],
        ("apples", "autumn"): params["water_per_acre_apples_autumn"],
        ("pears", "spring"): params["water_per_acre_pears_spring"],
        ("pears", "autumn"): params["water_per_acre_pears_autumn"],
        ("oranges", "spring"): params["water_per_acre_oranges_spring"],
        ("oranges", "autumn"): params["water_per_acre_oranges_autumn"],
        ("lemons", "spring"): params["water_per_acre_lemons_spring"],
        ("lemons", "autumn"): params["water_per_acre_lemons_autumn"],
    }

    total_farm_area = params["total_farm_area"]
    min_a_to_p = params["min_apples_to_pears_ratio"]
    min_a_to_l = params["min_apples_to_lemons_ratio"]
    o_to_l = params["oranges_to_lemons_ratio"]
    max_fruit_types = int(params["max_fruit_types"])

    water_cap = {
        "spring": params["water_cap_spring"],
        "autumn": params["water_cap_autumn"],
    }
    total_water_budget = params["total_water_budget"]
    min_annual_water_per_fruit = params["min_annual_water_per_fruit"]
    diversification_reward = params["diversification_reward"]

    m = gp.Model("revised_farm")
    m.setParam("OutputFlag", 0)

    x = m.addVars(fruits, seasons, lb=0.0, name="x")
    y = m.addVars(fruits, vtype=GRB.BINARY, name="y")
    z = m.addVar(vtype=GRB.BINARY, name="z_diversified")

    annual_area = {f: gp.quicksum(x[f, s] for s in seasons) for f in fruits}
    annual_water = {
        f: gp.quicksum(water[f, s] * x[f, s] for s in seasons) for f in fruits
        for f in fruits
    }

    m.setObjective(
        gp.quicksum(profit[f] * x[f, s] for f in fruits for s in seasons)
        + diversification_reward * z,
        GRB.MAXIMIZE,
    )

    for s in seasons:
        m.addConstr(gp.quicksum(x[f, s] for f in fruits) <= total_farm_area, name=f"area_{s}")

    for s in seasons:
        m.addConstr(
            gp.quicksum(water[f, s] * x[f, s] for f in fruits) <= water_cap[s],
            name=f"water_cap_{s}",
        )

    m.addConstr(
        gp.quicksum(water[f, s] * x[f, s] for f in fruits for s in seasons) <= total_water_budget,
        name="total_water_budget",
    )

    m.addConstr(annual_area["apples"] >= min_a_to_p * annual_area["pears"], name="ratio_apples_pears")
    m.addConstr(annual_area["apples"] >= min_a_to_l * annual_area["lemons"], name="ratio_apples_lemons")
    m.addConstr(annual_area["oranges"] == o_to_l * annual_area["lemons"], name="ratio_oranges_lemons")

    max_possible_annual_area = 2.0 * total_farm_area
    for f in fruits:
        m.addConstr(annual_area[f] <= max_possible_annual_area * y[f], name=f"activate_area_{f}")
        m.addConstr(annual_water[f] >= min_annual_water_per_fruit * y[f], name=f"min_water_if_used_{f}")

    m.addConstr(gp.quicksum(y[f] for f in fruits) <= max_fruit_types, name="max_types")

    m.addConstr(z <= gp.quicksum(y[f] for f in fruits) / 2.0, name="z_upper_count")
    m.addConstr(z >= gp.quicksum(y[f] for f in fruits) - 1, name="z_lower_count")

    m.optimize()

    obj_val = m.ObjVal if m.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
