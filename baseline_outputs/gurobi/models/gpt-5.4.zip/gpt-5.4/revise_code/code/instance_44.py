import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

m = int(params["m"])
n = int(params["n"])
p = int(params["p"])

I = range(1, m + 1)
J = range(1, n + 1)
K = range(1, p + 1)

a = {i: params[f"a_{i}"] for i in I}
b = {j: params[f"b_{j}"] for j in J}
f_cost = {k: params[f"f_{k}"] for k in K}
q = {k: params[f"q_{k}"] for k in K}
qexp = {k: params[f"qexp_{k}"] for k in K}
alpha = {j: params[f"alpha_{j}"] for j in J}
eps = params["eps"]
M = params["M"]

# Load costs for production -> station
cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row["i"])
        k = int(row["k"])
        cR_ik[(i, k)] = float(row["cR_ik"])
        cE_ik[(i, k)] = float(row["cE_ik"])

# Load costs for station -> demand
cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, "table_2.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row["k"])
        j = int(row["j"])
        cR_kj[(k, j)] = float(row["cR_kj"])
        cE_kj[(k, j)] = float(row["cE_kj"])

# Build model
model = gp.Model("revised_transportation")
model.setParam("OutputFlag", 0)

# Variables
xR = model.addVars(I, K, lb=0.0, vtype=GRB.CONTINUOUS, name="xR")
xE = model.addVars(I, K, lb=0.0, vtype=GRB.CONTINUOUS, name="xE")
yR = model.addVars(K, J, lb=0.0, vtype=GRB.CONTINUOUS, name="yR")
yE = model.addVars(K, J, lb=0.0, vtype=GRB.CONTINUOUS, name="yE")

z = model.addVars(K, vtype=GRB.BINARY, name="z")          # station open
w = model.addVars(K, J, vtype=GRB.BINARY, name="w")       # express link active to demand j from station k

# Objective
model.setObjective(
    gp.quicksum(cR_ik[i, k] * xR[i, k] + cE_ik[i, k] * xE[i, k] for i in I for k in K) +
    gp.quicksum(cR_kj[k, j] * yR[k, j] + cE_kj[k, j] * yE[k, j] for k in K for j in J) +
    gp.quicksum(f_cost[k] * z[k] for k in K),
    GRB.MINIMIZE
)

# Supply constraints
for i in I:
    model.addConstr(
        gp.quicksum(xR[i, k] + xE[i, k] for k in K) <= a[i],
        name=f"supply_{i}"
    )

# Demand satisfaction
for j in J:
    model.addConstr(
        gp.quicksum(yR[k, j] + yE[k, j] for k in K) >= b[j],
        name=f"demand_{j}"
    )

# Flow conservation by station and mode
for k in K:
    model.addConstr(
        gp.quicksum(xR[i, k] for i in I) == gp.quicksum(yR[k, j] for j in J),
        name=f"flow_regular_{k}"
    )
    model.addConstr(
        gp.quicksum(xE[i, k] for i in I) == gp.quicksum(yE[k, j] for j in J),
        name=f"flow_express_{k}"
    )

# Station capacity and opening link
for k in K:
    model.addConstr(
        gp.quicksum(xR[i, k] + xE[i, k] for i in I) <= q[k] * z[k],
        name=f"cap_total_{k}"
    )
    model.addConstr(
        gp.quicksum(xE[i, k] for i in I) <= qexp[k] * z[k],
        name=f"cap_express_{k}"
    )

# Express link activation and station-link consistency
for k in K:
    for j in J:
        model.addConstr(yE[k, j] <= M * w[k, j], name=f"express_upper_{k}_{j}")
        model.addConstr(yE[k, j] >= eps * w[k, j], name=f"express_lower_{k}_{j}")
        model.addConstr(w[k, j] <= z[k], name=f"link_open_{k}_{j}")

# Diversified express share:
# If more than one open station serves demand j in express, then at least alpha_j * b_j
# must be sent in express, diversified across at least two station-demand express links.
# With p=2 here, enforce at least two active express links whenever express share is positive enough.
for j in J:
    model.addConstr(
        gp.quicksum(yE[k, j] for k in K) >= alpha[j] * b[j] * (gp.quicksum(w[k, j] for k in K) - 1),
        name=f"expr_share_{j}"
    )

model.optimize()

obj_val = model.ObjVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
