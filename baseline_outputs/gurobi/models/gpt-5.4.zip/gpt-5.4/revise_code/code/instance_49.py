import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB


def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)


def main():
    # Load data
    params_df = pd.read_csv(get_data_path("general_parameters.csv"))
    demand_df = pd.read_csv(get_data_path("table_1.csv"))
    cost_df = pd.read_csv(get_data_path("table_2.csv"))

    # Parse parameters
    param_map = dict(zip(params_df["Parameter_Name"], params_df["Value"]))

    min_contract_types = int(float(param_map["min_contract_types"]))
    max_contract_types = int(float(param_map["max_contract_types"]))
    mutual_exclusion_1_and_4 = str(param_map["mutual_exclusion_1_and_4"]).strip().lower() == "true"
    monthly_max_parallel_contracts = int(float(param_map["monthly_max_parallel_contracts"]))
    min_area_per_contract_units = int(float(param_map["min_area_per_contract_units"]))
    activation_fee_per_contract = float(param_map["activation_fee_per_contract"])
    onboarding_loss_units = int(float(param_map["onboarding_loss_units"]))
    expedited_onboarding_fee = float(param_map["expedited_onboarding_fee"])

    # Demands in units of 100 sqm
    demands = {int(row["Month"]): int(round(float(row["Required_area_㎡"]) / 100.0)) for _, row in demand_df.iterrows()}
    rental_cost = {int(row["Contract_length_months"]): float(row["Rental_fee_per_100㎡_yuan"]) for _, row in cost_df.iterrows()}

    months = sorted(demands.keys())
    max_month = max(months)
    lengths = sorted(rental_cost.keys())

    # Feasible contract starts
    starts = [(s, l) for s in months for l in lengths if s + l - 1 <= max_month]

    # Big-M bounds
    total_demand_units = sum(demands.values())
    max_contract_count_total = monthly_max_parallel_contracts * len(months)

    # Model
    model = gp.Model("warehouse_rental_revised")
    model.setParam("OutputFlag", 0)

    # Variables
    # n[s,l]: number of contracts started at month s with length l
    n = model.addVars(starts, vtype=GRB.INTEGER, lb=0, name="n")

    # a[s,l]: rented area units (100 sqm units) per contract for contracts of type (s,l)
    a = model.addVars(starts, vtype=GRB.INTEGER, lb=0, name="a")

    # z[s,l]: binary, whether contract type (s,l) is used
    z = model.addVars(starts, vtype=GRB.BINARY, name="z")

    # e[s,l]: binary, whether expedited onboarding is used for contracts of type (s,l)
    e = model.addVars(starts, vtype=GRB.BINARY, name="e")

    # y[l]: binary, whether any contract of length l is used
    y = model.addVars(lengths, vtype=GRB.BINARY, name="y")

    # Objective
    model.setObjective(
        gp.quicksum(
            rental_cost[l] * l * a[s, l] * n[s, l]
            for s, l in starts
        ) * 0, GRB.MINIMIZE
    )

    # Since Gurobi does not allow direct multiplication of decision variables in linear model,
    # introduce w[s,l] = total rented area units across all contracts of type (s,l),
    # and c[s,l] = total number of contracts of type (s,l) with expedited onboarding.
    model.remove(model.getObjective())

    w = model.addVars(starts, vtype=GRB.INTEGER, lb=0, name="w")   # total area units rented by all contracts of type (s,l)
    c = model.addVars(starts, vtype=GRB.INTEGER, lb=0, name="c")   # expedited contract count among n[s,l]

    model.setObjective(
        gp.quicksum(rental_cost[l] * l * w[s, l] for s, l in starts) +
        gp.quicksum(activation_fee_per_contract * n[s, l] for s, l in starts) +
        gp.quicksum(expedited_onboarding_fee * c[s, l] for s, l in starts),
        GRB.MINIMIZE
    )

    # Linking n, z, y
    for s, l in starts:
        model.addConstr(n[s, l] <= max_contract_count_total * z[s, l], name=f"link_nz_ub_{s}_{l}")
        model.addConstr(n[s, l] >= z[s, l], name=f"link_nz_lb_{s}_{l}")
        model.addConstr(z[s, l] <= y[l], name=f"link_zy_{s}_{l}")

    for l in lengths:
        relevant = [(s, ll) for s, ll in starts if ll == l]
        model.addConstr(gp.quicksum(z[s, ll] for s, ll in relevant) >= y[l], name=f"link_y_lb_{l}")
        model.addConstr(gp.quicksum(z[s, ll] for s, ll in relevant) <= len(relevant) * y[l], name=f"link_y_ub_{l}")

    # Distinct contract lengths limits
    model.addConstr(gp.quicksum(y[l] for l in lengths) >= min_contract_types, name="min_contract_types")
    model.addConstr(gp.quicksum(y[l] for l in lengths) <= max_contract_types, name="max_contract_types")

    # Mutual exclusion
    if mutual_exclusion_1_and_4 and 1 in lengths and 4 in lengths:
        model.addConstr(y[1] + y[4] <= 1, name="mutual_exclusion_1_4")

    # Area-per-contract and total area linking
    # w[s,l] = n[s,l] * a[s,l], with a[s,l] integer and at least min_area_per_contract_units if active.
    # Linearize through bounds because all contracts of same (s,l) are identical in optimal aggregation.
    for s, l in starts:
        model.addConstr(w[s, l] >= min_area_per_contract_units * n[s, l], name=f"min_area_{s}_{l}")
        model.addConstr(w[s, l] <= total_demand_units * n[s, l], name=f"max_area_{s}_{l}")

    # Expedited counts
    for s, l in starts:
        model.addConstr(c[s, l] <= n[s, l], name=f"exp_count_le_n_{s}_{l}")
        model.addConstr(c[s, l] <= max_contract_count_total * e[s, l], name=f"exp_count_le_e_{s}_{l}")
        model.addConstr(c[s, l] >= n[s, l] - max_contract_count_total * (1 - e[s, l]), name=f"exp_count_ge_{s}_{l}")
        model.addConstr(e[s, l] <= z[s, l], name=f"exp_only_if_used_{s}_{l}")

    # Monthly demand fulfillment with onboarding loss on start month
    for m in months:
        expr = gp.LinExpr()
        for s, l in starts:
            if s <= m <= s + l - 1:
                if m == s:
                    expr += w[s, l] - onboarding_loss_units * (n[s, l] - c[s, l])
                else:
                    expr += w[s, l]
        model.addConstr(expr == demands[m], name=f"demand_{m}")

    # Max active contracts in any month
    for m in months:
        model.addConstr(
            gp.quicksum(n[s, l] for s, l in starts if s <= m <= s + l - 1) <= monthly_max_parallel_contracts,
            name=f"max_parallel_{m}"
        )

    model.optimize()

    obj_val = model.ObjVal
    if abs(obj_val - round(obj_val)) < 1e-6:
        obj_val = int(round(obj_val))

    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
