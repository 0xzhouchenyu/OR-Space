import os
import csv
import gurobipy as gp
from gurobipy import GRB


def read_general_parameters(path):
    params = {}
    with open(path, "r", newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def read_table_1(path):
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}

    with open(path, "r", newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row["Quarter"].strip()
            quarters.append(q)
            purchase_price[q] = float(row["Purchase_Price_10k_yuan_per_10k_m2"].strip())
            sale_price[q] = float(row["Sale_Price_10k_yuan_per_10k_m2"].strip())
            max_sales[q] = float(row["Estimated_Max_Sales_Volume_10k_m3"].strip())
            max_purchase[q] = float(row["max_purchase_10k_m3"].strip())

    return quarters, purchase_price, sale_price, max_sales, max_purchase


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = read_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    quarters, purchase_price, sale_price, max_sales, max_purchase = read_table_1(
        os.path.join(data_dir, "table_1.csv")
    )

    n = len(quarters)

    max_storage_10k_m3 = params["max_storage_capacity"] / 10000.0
    storage_cost_a = params["storage_cost_a"]
    storage_cost_b = params["storage_cost_b"]
    safety_inventory = params["safety_inventory_level_10k_m3"]
    terminal_inventory_value = params["terminal_inventory_value_per_10k_m3"]
    over_purchase_penalty = params["over_purchase_penalty_cost_per_10k_m3"]

    model = gp.Model("timber_revised")
    model.setParam("OutputFlag", 0)

    # x[i,j]: amount bought in quarter i and sold in quarter j, j >= i
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{i}_{j}")

    # y[i]: amount bought in quarter i and still held at end of autumn as terminal inventory
    y = {}
    for i in range(n):
        y[i] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"y_{i}")

    # excess terminal inventory above safety level
    excess = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="excess_terminal_inventory")

    # Purchase limits by quarter
    for i, q in enumerate(quarters):
        model.addConstr(
            gp.quicksum(x[i, j] for j in range(i, n)) + y[i] <= max_purchase[q],
            name=f"purchase_cap_{q}"
        )

    # Sales limits by quarter
    for j, q in enumerate(quarters):
        model.addConstr(
            gp.quicksum(x[i, j] for i in range(j + 1)) <= max_sales[q],
            name=f"sales_cap_{q}"
        )

    # Storage capacity after Winter, Spring, Summer, and end of Autumn
    for t in range(n):
        stored = gp.quicksum(
            x[i, j] for i in range(t + 1) for j in range(max(i, t + 1), n)
        ) + gp.quicksum(y[i] for i in range(t + 1))
        model.addConstr(stored <= max_storage_10k_m3, name=f"storage_cap_end_{quarters[t]}")

    # Safety inventory requirement at end of autumn
    terminal_inventory = gp.quicksum(y[i] for i in range(n))
    model.addConstr(terminal_inventory >= safety_inventory, name="safety_inventory_min")

    # Excess definition
    model.addConstr(excess >= terminal_inventory - safety_inventory, name="excess_def")

    # Objective
    obj = gp.LinExpr()

    # Profit from sold timber
    for i in range(n):
        for j in range(i, n):
            u = j - i
            storage_cost = 0.0 if u == 0 else (storage_cost_a + storage_cost_b * u)
            unit_profit = sale_price[quarters[j]] - purchase_price[quarters[i]] - storage_cost
            obj += unit_profit * x[i, j]

    # Terminal inventory value and storage cost for carried inventory
    for i in range(n):
        u = (n - 1) - i
        storage_cost = 0.0 if u == 0 else (storage_cost_a + storage_cost_b * u)
        unit_terminal_contrib = terminal_inventory_value - purchase_price[quarters[i]] - storage_cost
        obj += unit_terminal_contrib * y[i]

    # Penalty for inventory above safety level
    obj += -over_purchase_penalty * excess

    model.setObjective(obj, GRB.MAXIMIZE)
    model.optimize()

    final_obj = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {final_obj}")


if __name__ == "__main__":
    main()
