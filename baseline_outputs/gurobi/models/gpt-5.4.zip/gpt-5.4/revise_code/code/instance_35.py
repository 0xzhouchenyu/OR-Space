import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row["parameter"].strip()
            val = float(row["value"])
            params[key] = val
    return params

def load_processing_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(base_dir, "data", "table_1.csv")
    batches = []
    proc = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            b = int(row["Batch"])
            batches.append(b)
            proc[(b, 1)] = int(math.ceil(float(row["Vat_1_Time"])))
            proc[(b, 2)] = int(math.ceil(float(row["Vat_2_Time"])))
            proc[(b, 3)] = int(math.ceil(float(row["Vat_3_Time"])))
    return batches, proc

def active_periods(start_t, duration):
    return list(range(start_t, start_t + duration))

def main():
    params = load_general_parameters()
    batches, p = load_processing_data()

    T = int(params["planning_horizon_T"])
    energy_cost = {
        1: float(params["energy_cost_v1"]),
        2: float(params["energy_cost_v2"]),
        3: float(params["energy_cost_v3"]),
    }
    peak_mult = float(params["peak_energy_multiplier"])
    peak_cap = float(params["peak_energy_cap"])
    makespan_weight = float(params["makespan_weight"])
    energy_weight = float(params["energy_weight"])

    vats = [1, 2, 3]
    periods = list(range(1, T + 1))
    peak_periods = {6, 7, 8}
    maintenance_v2 = {4, 5}

    feasible_starts = {}
    for b in batches:
        for v in vats:
            dur = p[(b, v)]
            starts = []
            for t in range(1, T - dur + 2):
                occ = active_periods(t, dur)
                if max(occ) > T:
                    continue
                if v == 2 and any(tt in maintenance_v2 for tt in occ):
                    continue
                starts.append(t)
            feasible_starts[(b, v)] = starts

    model = gp.Model("dyeing_flowshop_discrete")
    model.setParam("OutputFlag", 0)

    x = {}
    for b in batches:
        for v in vats:
            for t in feasible_starts[(b, v)]:
                x[(b, v, t)] = model.addVar(vtype=GRB.BINARY, name=f"x_{b}_{v}_{t}")

    y = {}
    for v in vats:
        for t in periods:
            y[(v, t)] = model.addVar(vtype=GRB.BINARY, name=f"y_{v}_{t}")

    Cmax = model.addVar(vtype=GRB.CONTINUOUS, lb=0.0, name="Cmax")

    model.update()

    for b in batches:
        for v in vats:
            model.addConstr(
                gp.quicksum(x[(b, v, t)] for t in feasible_starts[(b, v)]) == 1,
                name=f"assign_{b}_{v}"
            )

    for v in vats:
        for tau in periods:
            expr = gp.quicksum(
                x[(b, v, t)]
                for b in batches
                for t in feasible_starts[(b, v)]
                if tau in active_periods(t, p[(b, v)])
            )
            model.addConstr(expr <= 1, name=f"cap_{v}_{tau}")
            model.addConstr(y[(v, tau)] == expr, name=f"link_y_{v}_{tau}")

    for b in batches:
        start_v1 = gp.quicksum(t * x[(b, 1, t)] for t in feasible_starts[(b, 1)])
        start_v2 = gp.quicksum(t * x[(b, 2, t)] for t in feasible_starts[(b, 2)])
        start_v3 = gp.quicksum(t * x[(b, 3, t)] for t in feasible_starts[(b, 3)])

        model.addConstr(
            start_v2 >= start_v1 + p[(b, 1)] - 1,
            name=f"precedence_{b}_1_2"
        )
        model.addConstr(
            start_v3 >= start_v2 + p[(b, 2)] - 1,
            name=f"precedence_{b}_2_3"
        )

    for b in batches:
        completion_v3 = gp.quicksum(
            (t + p[(b, 3)] - 1) * x[(b, 3, t)] for t in feasible_starts[(b, 3)]
        )
        model.addConstr(Cmax >= completion_v3, name=f"cmax_{b}")

    peak_energy_expr = gp.quicksum(
        energy_cost[v] * peak_mult * y[(v, t)]
        for v in vats for t in periods if t in peak_periods
    )
    model.addConstr(peak_energy_expr <= peak_cap, name="peak_cap")

    total_energy = gp.quicksum(
        energy_cost[v] * (peak_mult if t in peak_periods else 1.0) * y[(v, t)]
        for v in vats for t in periods
    )

    model.setObjective(
        makespan_weight * Cmax + energy_weight * total_energy,
        GRB.MINIMIZE
    )

    model.optimize()

    obj = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj}")

if __name__ == "__main__":
    main()
