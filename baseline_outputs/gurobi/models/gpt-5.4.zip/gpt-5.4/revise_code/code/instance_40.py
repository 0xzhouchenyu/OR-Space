import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(csv_path)
    return dict(zip(df["Parameter_Name"], df["Value"]))

def main():
    params = load_parameters()
    commodities = ["steel", "engine", "electronics", "plastic"]

    model = gp.Model("carelland_revised")
    model.setParam("OutputFlag", 0)

    # Decision variables
    x = {c: model.addVar(lb=0.0, name=f"prod_{c}") for c in commodities}      # domestic production
    m = {c: model.addVar(lb=0.0, ub=params["import_quota"], name=f"imp_{c}") for c in commodities}  # finished imports
    ot = model.addVar(lb=0.0, ub=params["overtime_cap"], name="overtime_labor")

    # Production limits where applicable
    for c in commodities:
        key = f"{c}_production_limit"
        if key in params:
            x[c].UB = params[key]

    # Intermediate consumption and net exports
    consumed = {}
    net_export = {}
    for c in commodities:
        consumed[c] = gp.quicksum(
            params.get(f"{cp}_{c}_requirement", 0.0) * x[cp]
            for cp in commodities
        )
        net_export[c] = x[c] + m[c] - consumed[c]

    # Commodity balance: satisfy domestic intermediate demand, exports can be positive, no shortage allowed
    for c in commodities:
        model.addConstr(net_export[c] >= 0.0, name=f"balance_{c}")

    # Labor constraint with overtime
    total_labor = gp.quicksum(
        params.get(f"{c}_labor_requirement", 0.0) * x[c]
        for c in commodities
    )
    model.addConstr(total_labor <= params["labor_force"] + ot, name="labor_limit")

    # Objective: export revenue minus imported input costs minus finished-import costs minus overtime wage
    export_revenue = gp.quicksum(
        params[f"{c}_price"] * net_export[c]
        for c in commodities
    )

    imported_input_costs = gp.quicksum(
        params.get(f"{c}_import_cost", 0.0) * x[c]
        for c in commodities
    )

    finished_import_costs = gp.quicksum(
        params["import_premium_ratio"] * params[f"{c}_price"] * m[c]
        for c in commodities
    )

    overtime_cost = params["overtime_wage"] * ot

    model.setObjective(
        export_revenue - imported_input_costs - finished_import_costs - overtime_cost,
        GRB.MAXIMIZE
    )

    model.optimize()

    obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
