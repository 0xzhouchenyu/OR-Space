import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_parameters(base_dir):
    params = {}
    path = os.path.join(base_dir, "data", "general_parameters.csv")
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def read_precedences(base_dir):
    precedences = []
    path = os.path.join(base_dir, "data", "table_1.csv")
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row["Predecessor"].strip(), row["Successor"].strip()))
    return precedences

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    params = read_parameters(base_dir)
    precedences = read_precedences(base_dir)

    activities = ["A", "B", "C", "D", "E", "F", "G"]
    dur = {a: int(params[f"activity_{a}_duration"]) for a in activities}

    work_cost = params["work_cost_per_day"]
    machine_cost = params["machine_rental_cost_per_day"]

    e_ot_reduction = int(params.get("activity_E_overtime_reduction", 0))
    e_ot_cost = params.get("activity_E_overtime_cost", 0.0)
    e_followup_trigger = int(params.get("activity_E_followup_review_trigger", 0))
    e_followup_cost = params.get("activity_E_followup_review_cost", 0.0)

    m = gp.Model("revised_project_optimization")
    m.setParam("OutputFlag", 0)

    S = {a: m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"S_{a}") for a in activities}
    T = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="T")
    yE = m.addVar(vtype=GRB.BINARY, name="yE_overtime")

    eff_dur = dur.copy()
    eff_dur["E"] = dur["E"] - e_ot_reduction * yE

    for pred, succ in precedences:
        m.addConstr(S[succ] >= S[pred] + eff_dur[pred], name=f"prec_{pred}_{succ}")

    m.addConstr(T >= S["C"] + dur["C"], name="makespan_C")
    m.addConstr(T >= S["B"] + dur["B"], name="makespan_B")

    machine_rental_duration = (S["B"] + dur["B"]) - S["A"]

    overtime_total_cost = e_ot_cost * yE + (e_followup_cost * yE if e_followup_trigger == 1 else 0.0)

    m.setObjective(
        work_cost * T + machine_cost * machine_rental_duration + overtime_total_cost,
        GRB.MINIMIZE
    )

    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == "__main__":
    main()
