import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_general_parameters():
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            name = row[0].strip()
            try:
                value = float(row[1].strip())
            except ValueError:
                value = row[1].strip()
            params[name] = value
    return params


def load_crop_data():
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    with open(filepath, "r", newline="") as f:
        reader = csv.reader(f)
        headers = next(reader)
        crops = [h.strip() for h in headers[1:]]
        data = {}
        for row in reader:
            item = row[0].strip()
            values = [float(v.strip()) for v in row[1:]]
            data[item] = dict(zip(crops, values))
    return crops, data


def main():
    params = load_general_parameters()
    crops, crop_data = load_crop_data()

    land_area = params["land_area"]
    funds_available = params["funds_available"]
    labor_aw = params["labor_autumn_winter"]
    labor_ss = params["labor_spring_summer"]
    ext_rate_ss = params["external_work_rate_spring_summer"]
    ext_rate_aw = params["external_work_rate_autumn_winter"]

    inv_dairy = params["investment_per_dairy_cow"]
    inv_chicken = params["investment_per_chicken"]
    land_dairy = params["land_per_dairy_cow"]
    labor_aw_dairy = params["labor_autumn_winter_per_dairy_cow"]
    labor_ss_dairy = params["labor_spring_summer_per_dairy_cow"]
    income_dairy = params["net_income_per_dairy_cow"]
    labor_aw_chicken = params["labor_autumn_winter_per_chicken"]
    labor_ss_chicken = params["labor_spring_summer_per_chicken"]
    income_chicken = params["net_income_per_chicken"]
    max_chickens = params["max_chickens"]
    max_dairy_cows = params["max_dairy_cows"]

    fixed_cost_chicken_setup = params["fixed_cost_chicken_setup"]
    min_chickens_if_coop_open = params["min_chickens_if_coop_open"]
    second_biosecurity_threshold = params["second_biosecurity_threshold"]
    second_biosecurity_cost = params["second_biosecurity_cost"]
    biosecurity_training_aw_days = params["biosecurity_training_aw_days"]
    biosecurity_training_ss_days = params["biosecurity_training_ss_days"]

    crop_aw = crop_data["Person-days (Autumn/Winter)"]
    crop_ss = crop_data["Person-days (Spring/Summer)"]
    crop_income = crop_data["Annual Net Income (Yuan/hectare)"]

    m = gp.Model("Farm_Optimization_Revised")
    m.setParam("OutputFlag", 0)

    x = {c: m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{c}") for c in crops}
    y_dairy = m.addVar(lb=0.0, ub=max_dairy_cows, vtype=GRB.CONTINUOUS, name="dairy_cows")
    y_chicken = m.addVar(lb=0.0, ub=max_chickens, vtype=GRB.CONTINUOUS, name="chickens")
    surplus_aw = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="surplus_aw")
    surplus_ss = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="surplus_ss")

    coop_open = m.addVar(vtype=GRB.BINARY, name="coop_open")
    second_step = m.addVar(vtype=GRB.BINARY, name="second_biosecurity_step")

    m.setObjective(
        gp.quicksum(crop_income[c] * x[c] for c in crops)
        + income_dairy * y_dairy
        + income_chicken * y_chicken
        + ext_rate_aw * surplus_aw
        + ext_rate_ss * surplus_ss
        - fixed_cost_chicken_setup * coop_open
        - second_biosecurity_cost * second_step,
        GRB.MAXIMIZE,
    )

    m.addConstr(
        gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area,
        name="Land",
    )

    m.addConstr(
        inv_dairy * y_dairy
        + inv_chicken * y_chicken
        + fixed_cost_chicken_setup * coop_open
        + second_biosecurity_cost * second_step
        <= funds_available,
        name="Funds",
    )

    m.addConstr(
        gp.quicksum(crop_aw[c] * x[c] for c in crops)
        + labor_aw_dairy * y_dairy
        + labor_aw_chicken * y_chicken
        + biosecurity_training_aw_days * coop_open
        + surplus_aw
        <= labor_aw,
        name="Labor_AW",
    )

    m.addConstr(
        gp.quicksum(crop_ss[c] * x[c] for c in crops)
        + labor_ss_dairy * y_dairy
        + labor_ss_chicken * y_chicken
        + biosecurity_training_ss_days * coop_open
        + surplus_ss
        <= labor_ss,
        name="Labor_SS",
    )

    m.addConstr(y_chicken <= max_chickens * coop_open, name="CoopOpenUpper")
    m.addConstr(y_chicken >= min_chickens_if_coop_open * coop_open, name="CoopOpenLower")

    m.addConstr(y_chicken <= second_biosecurity_threshold + (max_chickens - second_biosecurity_threshold) * second_step,
                name="SecondStepTriggerLB")
    m.addConstr(y_chicken >= second_biosecurity_threshold * second_step, name="SecondStepTriggerUB")
    m.addConstr(second_step <= coop_open, name="SecondStepRequiresCoop")

    m.optimize()

    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")


if __name__ == "__main__":
    main()
