import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_csv_data(filepath):
    data = []
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load general parameters
    params_data = load_csv_data(os.path.join(data_dir, "general_parameters.csv"))
    params = {}
    for row in params_data:
        params[row["Parameter_Name"]] = float(row["Value"])

    cost_per_km = params["cost_per_km"]
    adriatic_pool_shortage_trigger = params["adriatic_pool_shortage_trigger"]
    adriatic_pool_recovery_fee = params["adriatic_pool_recovery_fee"]

    # Load warehouse supply
    warehouses_data = load_csv_data(os.path.join(data_dir, "table_1.csv"))
    warehouses = []
    supply = {}
    for row in warehouses_data:
        w = row["Warehouse"]
        warehouses.append(w)
        supply[w] = int(row["Empty_Containers"])

    # Load port demand
    ports_data = load_csv_data(os.path.join(data_dir, "table_2.csv"))
    ports = []
    demand = {}
    for row in ports_data:
        p = row["Port"]
        ports.append(p)
        demand[p] = int(row["Container_Demand"])

    # Load distances
    distance_data = load_csv_data(os.path.join(data_dir, "table_3.csv"))
    distance = {}
    for row in distance_data:
        w = row["Warehouse"]
        for p in ports:
            distance[(w, p)] = float(row[p])

    # Load shortage penalty parameters
    shortage_data = load_csv_data(os.path.join(data_dir, "shortage_penalty.csv"))
    shortage_charge = {}
    grace_containers = {}
    recovery_fee = {}
    for row in shortage_data:
        p = row["Port"]
        shortage_charge[p] = float(row["Shortage_Charge"])
        grace_containers[p] = float(row["Grace_Containers"])
        recovery_fee[p] = float(row["Recovery_Fee"])

    adriatic_ports = [p for p in ["Venice", "Ancona", "Bari"] if p in ports]

    model = gp.Model("revised_container_transport")
    model.setParam("OutputFlag", 0)

    # Decision variables
    x = model.addVars(warehouses, ports, vtype=GRB.INTEGER, lb=0, name="x")
    s = model.addVars(ports, vtype=GRB.INTEGER, lb=0, name="shortage")
    y = model.addVars(ports, vtype=GRB.BINARY, name="local_recovery_open")
    z = model.addVar(vtype=GRB.BINARY, name="adriatic_recovery_open")

    # Objective
    transport_cost = gp.quicksum(
        cost_per_km * distance[(w, p)] * x[w, p] for w in warehouses for p in ports
    )
    shortage_cost = gp.quicksum(
        shortage_charge[p] * s[p] for p in ports
    )
    local_recovery_cost = gp.quicksum(
        recovery_fee[p] * y[p] for p in ports
    )
    adriatic_recovery_cost = adriatic_pool_recovery_fee * z

    model.setObjective(
        transport_cost + shortage_cost + local_recovery_cost + adriatic_recovery_cost,
        GRB.MINIMIZE
    )

    # Supply constraints
    for w in warehouses:
        model.addConstr(
            gp.quicksum(x[w, p] for p in ports) <= supply[w],
            name=f"supply_{w}"
        )

    # Demand / shortage balance
    for p in ports:
        model.addConstr(
            gp.quicksum(x[w, p] for w in warehouses) + s[p] == demand[p],
            name=f"demand_balance_{p}"
        )

    # Local recovery desk opens if shortage exceeds grace band
    for p in ports:
        model.addConstr(
            s[p] <= grace_containers[p] + demand[p] * y[p],
            name=f"local_recovery_trigger_{p}"
        )

    # Adriatic regional recovery desk opens if combined shortage exceeds trigger
    if adriatic_ports:
        model.addConstr(
            gp.quicksum(s[p] for p in adriatic_ports)
            <= adriatic_pool_shortage_trigger
            + gp.quicksum(demand[p] for p in adriatic_ports) * z,
            name="adriatic_recovery_trigger"
        )

    model.optimize()

    obj_val = model.ObjVal
    if abs(obj_val - round(obj_val)) < 1e-6:
        obj_str = str(int(round(obj_val)))
    else:
        obj_str = f"{obj_val:.6f}".rstrip("0").rstrip(".")

    print(f"FINAL_OBJ_VALUE: {obj_str}")


if __name__ == "__main__":
    main()
