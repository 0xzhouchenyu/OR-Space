import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_parameters():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def main():
    params = read_parameters()

    cost_a = params["cost_supplier_a"]
    cost_b = params["cost_supplier_b"]
    cost_c = params["cost_supplier_c"]

    size_a = int(params["order_size_supplier_a"])
    size_b = int(params["order_size_supplier_b"])
    size_c = int(params["order_size_supplier_c"])

    min_tables = int(params["min_tables_required"])
    max_tables = int(params["max_tables_allowed"])
    min_b_if_a = int(params["min_tables_supplier_b_if_a"])
    b_requires_c = int(params["supplier_b_requires_c"])

    max_free_orders_c = int(params["max_free_orders_c"])
    penalty_per_extra_order_c = params["penalty_per_extra_order_c"]
    bc_shared_inbound_trigger = int(params["supplier_bc_shared_inbound_trigger"])
    bc_shared_inbound_fee = params["supplier_bc_shared_inbound_fee"]

    max_orders_a = max_tables // size_a
    max_orders_b = max_tables // size_b
    max_orders_c = max_tables // size_c

    m = gp.Model("restaurant_tables_revised")
    m.setParam("OutputFlag", 0)

    x_a = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_a, name="orders_a")
    x_b = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_b, name="orders_b")
    x_c = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_c, name="orders_c")

    y_a = m.addVar(vtype=GRB.BINARY, name="use_a")
    y_b = m.addVar(vtype=GRB.BINARY, name="use_b")
    y_c = m.addVar(vtype=GRB.BINARY, name="use_c")
    y_bc = m.addVar(vtype=GRB.BINARY, name="use_bc_together")

    extra_c = m.addVar(vtype=GRB.INTEGER, lb=0, name="extra_orders_c")

    total_tables = size_a * x_a + size_b * x_b + size_c * x_c

    m.addConstr(total_tables >= min_tables, name="min_tables")
    m.addConstr(total_tables <= max_tables, name="max_tables")

    m.addConstr(x_a <= max_orders_a * y_a, name="link_a_upper")
    m.addConstr(x_a >= y_a, name="link_a_lower")

    m.addConstr(x_b <= max_orders_b * y_b, name="link_b_upper")
    m.addConstr(x_b >= y_b, name="link_b_lower")

    m.addConstr(x_c <= max_orders_c * y_c, name="link_c_upper")
    m.addConstr(x_c >= y_c, name="link_c_lower")

    m.addConstr(size_b * x_b >= min_b_if_a * y_a, name="b_min_if_a")

    if b_requires_c:
        m.addConstr(y_c >= y_b, name="b_requires_c_use")

    m.addConstr(extra_c >= x_c - max_free_orders_c, name="extra_c_def")

    if bc_shared_inbound_trigger:
        m.addConstr(y_bc <= y_b, name="bc_and_1")
        m.addConstr(y_bc <= y_c, name="bc_and_2")
        m.addConstr(y_bc >= y_b + y_c - 1, name="bc_and_3")
    else:
        m.addConstr(y_bc == 0, name="bc_not_active")

    m.setObjective(
        cost_a * size_a * x_a
        + cost_b * size_b * x_b
        + cost_c * size_c * x_c
        + penalty_per_extra_order_c * extra_c
        + bc_shared_inbound_fee * y_bc,
        GRB.MINIMIZE
    )

    m.optimize()

    obj = m.ObjVal
    if abs(obj - round(obj)) < 1e-9:
        obj_str = str(int(round(obj)))
    else:
        obj_str = str(obj)

    print(f"FINAL_OBJ_VALUE: {obj_str}")

if __name__ == "__main__":
    main()
