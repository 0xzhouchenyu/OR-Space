import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_csv(filepath):
    with open(filepath, "r", newline="") as f:
        return list(csv.DictReader(f))


def load_general_parameters(base_dir):
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    rows = load_csv(filepath)
    params = {}
    for row in rows:
        name = row["Parameter_Name"]
        value = row["Value"]
        try:
            if "." in value:
                params[name] = float(value)
            else:
                params[name] = int(value)
        except ValueError:
            params[name] = value
    return params


def load_task_methods(base_dir):
    filepath = os.path.join(base_dir, "data", "table_1.csv")
    rows = load_csv(filepath)
    data = {}
    tasks = []
    methods = set()
    for row in rows:
        t = row["Task"]
        m = row["Method"]
        if t not in tasks:
            tasks.append(t)
        methods.add(m)
        data[(t, m)] = {
            "Effective_Hours": float(row["Effective_Hours"]),
            "Fixed_Cost": float(row["Fixed_Cost"]),
        }
    return tasks, sorted(methods), data


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    params = load_general_parameters(base_dir)
    tasks, methods, tm_data = load_task_methods(base_dir)

    skilled_wage = params["skilled_worker_weekly_wage"]
    laborer_wage = params["laborer_weekly_wage"]
    skilled_hours = params["skilled_worker_weekly_hours"]
    laborer_hours = params["laborer_weekly_hours"]
    max_skilled = params["max_skilled_workers"]
    max_laborers = params["max_laborers"]
    min_skilled_task3_B = params["min_skilled_workers_task3_methodB"]
    skilled_hiring_ratio = params["skilled_worker_hiring_ratio"]

    min_share = {
        "Task_1": params["min_skilled_share_task1"],
        "Task_2": params["min_skilled_share_task2"],
        "Task_3": params["min_skilled_share_task3"],
    }
    max_share = {
        "Task_1": params["max_skilled_share_task1"],
        "Task_2": params["max_skilled_share_task2"],
        "Task_3": params["max_skilled_share_task3"],
    }

    model = gp.Model("revised_worker_allocation")
    model.setParam("OutputFlag", 0)

    y = model.addVars(tasks, methods, vtype=GRB.BINARY, name="y")
    s = model.addVars(tasks, methods, lb=0.0, vtype=GRB.CONTINUOUS, name="s")
    l = model.addVars(tasks, methods, lb=0.0, vtype=GRB.CONTINUOUS, name="l")

    total_skilled = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="total_skilled")
    total_laborers = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="total_laborers")

    task_skilled = model.addVars(tasks, lb=0.0, vtype=GRB.CONTINUOUS, name="task_skilled")
    task_laborers = model.addVars(tasks, lb=0.0, vtype=GRB.CONTINUOUS, name="task_laborers")

    model.setObjective(
        skilled_wage * total_skilled
        + laborer_wage * total_laborers
        + gp.quicksum(tm_data[(t, m)]["Fixed_Cost"] * y[t, m] for t in tasks for m in methods),
        GRB.MINIMIZE,
    )

    model.addConstr(
        total_skilled == gp.quicksum(s[t, m] for t in tasks for m in methods),
        name="TotalSkilledDef",
    )
    model.addConstr(
        total_laborers == gp.quicksum(l[t, m] for t in tasks for m in methods),
        name="TotalLaborersDef",
    )

    for t in tasks:
        model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1, name=f"OneMethod_{t}")
        model.addConstr(
            task_skilled[t] == gp.quicksum(s[t, m] for m in methods),
            name=f"TaskSkilledDef_{t}",
        )
        model.addConstr(
            task_laborers[t] == gp.quicksum(l[t, m] for m in methods),
            name=f"TaskLaborersDef_{t}",
        )

    M_s = max_skilled
    M_l = max_laborers

    for t in tasks:
        for m in methods:
            req_hours = tm_data[(t, m)]["Effective_Hours"]
            model.addConstr(
                skilled_hours * s[t, m] + laborer_hours * l[t, m] >= req_hours * y[t, m],
                name=f"Hours_{t}_{m}",
            )
            model.addConstr(s[t, m] <= M_s * y[t, m], name=f"LinkS_{t}_{m}")
            model.addConstr(l[t, m] <= M_l * y[t, m], name=f"LinkL_{t}_{m}")

    model.addConstr(total_skilled <= max_skilled, name="MaxSkilled")
    model.addConstr(total_laborers <= max_laborers, name="MaxLaborers")
    model.addConstr(total_skilled <= skilled_hiring_ratio * total_laborers, name="SkilledRatio")

    if params.get("exclusion_rule_task1_task3", 0):
        model.addConstr(y["Task_1", "Method_B"] + y["Task_3", "Method_A"] <= 1, name="ExclusionRule")

    model.addConstr(
        s["Task_3", "Method_B"] >= min_skilled_task3_B * y["Task_3", "Method_B"],
        name="MinSkilledTask3B",
    )

    for t in tasks:
        alpha = min_share[t]
        beta = max_share[t]
        model.addConstr(
            (1.0 - alpha) * task_skilled[t] - alpha * task_laborers[t] >= 0,
            name=f"MinSkilledShare_{t}",
        )
        model.addConstr(
            (1.0 - beta) * task_skilled[t] - beta * task_laborers[t] <= 0,
            name=f"MaxSkilledShare_{t}",
        )

    model.optimize()

    obj = model.ObjVal
    if abs(obj - round(obj)) < 1e-6:
        obj_str = str(int(round(obj)))
    else:
        obj_str = f"{obj:.10f}".rstrip("0").rstrip(".")

    print(f"FINAL_OBJ_VALUE: {obj_str}")


if __name__ == "__main__":
    main()
