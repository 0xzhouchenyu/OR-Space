import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB


def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    t1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    t2 = pd.read_csv(os.path.join(data_dir, "table_2.csv"))
    t3 = pd.read_csv(os.path.join(data_dir, "table_3.csv"))
    gp_df = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))

    df = t1.merge(t2, on="Product").merge(t3, on="Product")
    params = {row["Parameter_Name"]: float(row["Value"]) for _, row in gp_df.iterrows()}
    return df, params


def solve():
    df, params = load_data()

    products = df["Product"].tolist()
    data = {row["Product"]: row for _, row in df.iterrows()}

    prod_days = params["production_days"]
    a1_watch_threshold = params["a1_watch_threshold"]
    a1_deep_service_threshold = params["a1_deep_service_threshold"]
    maintenance_penalty_watch = params["maintenance_penalty_watch"]
    maintenance_penalty_deep = params["maintenance_penalty_deep"]
    a1_quality_release_fee = params["a1_quality_release_fee"]
    a1_deep_service_fee = params["a1_deep_service_fee"]
    a1_priority_price_lift = params["a1_priority_price_lift"]

    m = gp.Model("revised_production_planning")
    m.setParam("OutputFlag", 0)

    x = m.addVars(products, lb=0.0, name="x")
    y = m.addVars(products, vtype=GRB.BINARY, name="y")

    z_watch = m.addVar(vtype=GRB.BINARY, name="z_watch")
    z_deep = m.addVar(vtype=GRB.BINARY, name="z_deep")
    a1_priority_units = m.addVar(lb=0.0, name="a1_priority_units")

    # All three product types must be produced
    for p in products:
        m.addConstr(y[p] == 1, name=f"must_produce_{p}")

    # Demand and minimum batch constraints
    for p in products:
        row = data[p]
        max_demand = float(row["Maximum_Demand"])
        min_batch = float(row["Minimum_Batch"])
        m.addConstr(x[p] <= max_demand * y[p], name=f"max_demand_{p}")
        m.addConstr(x[p] >= min_batch * y[p], name=f"min_batch_{p}")

    # Threshold logic for A1
    max_a1 = float(data["A1"]["Maximum_Demand"])

    m.addConstr(x["A1"] <= a1_watch_threshold + (max_a1 - a1_watch_threshold) * z_watch, name="watch_upper_trigger")
    m.addConstr(x["A1"] >= a1_watch_threshold * z_watch, name="watch_lower_trigger")

    m.addConstr(x["A1"] <= a1_deep_service_threshold + (max_a1 - a1_deep_service_threshold) * z_deep, name="deep_upper_trigger")
    m.addConstr(x["A1"] >= a1_deep_service_threshold * z_deep, name="deep_lower_trigger")

    m.addConstr(z_deep <= z_watch, name="deep_implies_watch")

    # Priority uplift applies only to A1 units above the watch threshold
    m.addConstr(a1_priority_units <= x["A1"] - a1_watch_threshold + a1_watch_threshold * (1 - z_watch), name="priority_units_ub1")
    m.addConstr(a1_priority_units <= (max_a1 - a1_watch_threshold) * z_watch, name="priority_units_ub2")
    m.addConstr(a1_priority_units >= x["A1"] - a1_watch_threshold - a1_watch_threshold * (1 - z_watch), name="priority_units_lb")
    m.addConstr(a1_priority_units >= 0, name="priority_units_nonneg")

    # Production days with maintenance penalties
    m.addConstr(
        gp.quicksum(x[p] / float(data[p]["Production_Quota"]) for p in products)
        <= prod_days - maintenance_penalty_watch * z_watch - maintenance_penalty_deep * z_deep,
        name="production_days"
    )

    # Objective
    obj = gp.quicksum(
        (float(data[p]["Selling_Price"]) - float(data[p]["Production_Cost"])) * x[p]
        - float(data[p]["Activation_Cost"]) * y[p]
        for p in products
    )
    obj += a1_priority_price_lift * a1_priority_units
    obj -= a1_quality_release_fee * z_watch
    obj -= a1_deep_service_fee * z_deep

    m.setObjective(obj, GRB.MAXIMIZE)
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")


if __name__ == "__main__":
    solve()
