import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

base_dir = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(base_dir, "data", "general_parameters.csv")
params = load_general_parameters(data_path)

motorcycle_pollution = params["motorcycle_pollution"]
small_truck_pollution = params["small_truck_pollution"]
large_truck_pollution = params["large_truck_pollution"]

max_motorcycle_trips = int(params["max_motorcycle_trips"])

motorcycle_capacity = params["motorcycle_capacity"]
small_truck_capacity = params["small_truck_capacity"]
large_truck_capacity = params["large_truck_capacity"]

max_total_trips = int(params["max_total_trips"])

demand_peak_units = params["demand_peak_units"]
demand_offpeak_units = params["demand_offpeak_units"]

leasing_capacity = params["leasing_capacity"]
leasing_pollution_per_unit = params["leasing_pollution_per_unit"]
leasing_fixed_pollution = params["leasing_fixed_pollution"]
max_leasing_fraction_peak = params["max_leasing_fraction_peak"]
bigM_leasing = params["bigM_leasing"]
epsilon = params["epsilon"]

methods = ["motorcycle", "small_truck", "large_truck"]
periods = ["peak", "offpeak"]

pollution = {
    "motorcycle": motorcycle_pollution,
    "small_truck": small_truck_pollution,
    "large_truck": large_truck_pollution,
}

capacity = {
    "motorcycle": motorcycle_capacity,
    "small_truck": small_truck_capacity,
    "large_truck": large_truck_capacity,
}

demand = {
    "peak": demand_peak_units,
    "offpeak": demand_offpeak_units,
}

model = gp.Model("revised_transport_optimization")
model.setParam("OutputFlag", 0)

trips = model.addVars(methods, periods, vtype=GRB.INTEGER, lb=0, name="trips")
method_used = model.addVars(methods, vtype=GRB.BINARY, name="method_used")

lease = model.addVars(periods, vtype=GRB.CONTINUOUS, lb=0, name="lease")
leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")

model.setObjective(
    gp.quicksum(pollution[m] * trips[m, p] for m in methods for p in periods)
    + leasing_pollution_per_unit * gp.quicksum(lease[p] for p in periods)
    + leasing_fixed_pollution * leasing_used,
    GRB.MINIMIZE
)

for p in periods:
    model.addConstr(
        gp.quicksum(capacity[m] * trips[m, p] for m in methods) + lease[p] >= demand[p],
        name=f"demand_{p}"
    )

model.addConstr(
    gp.quicksum(trips[m, p] for m in methods for p in periods) <= max_total_trips,
    name="max_total_trips"
)

model.addConstr(
    gp.quicksum(trips["motorcycle", p] for p in periods) <= max_motorcycle_trips,
    name="max_motorcycle_trips"
)

model.addConstr(
    gp.quicksum(method_used[m] for m in methods) <= 2,
    name="choose_at_most_two_methods"
)

for m in methods:
    model.addConstr(
        gp.quicksum(trips[m, p] for p in periods) <= max_total_trips * method_used[m],
        name=f"link_method_used_{m}"
    )

model.addConstr(
    gp.quicksum(lease[p] for p in periods) <= leasing_capacity,
    name="leasing_capacity_day"
)

model.addConstr(
    lease["peak"] <= max_leasing_fraction_peak * demand_peak_units,
    name="max_leasing_peak_fraction"
)

total_leasing = gp.quicksum(lease[p] for p in periods)
model.addConstr(
    total_leasing <= bigM_leasing * leasing_used,
    name="leasing_activation_upper"
)
model.addConstr(
    total_leasing >= epsilon * leasing_used,
    name="leasing_activation_lower"
)

model.optimize()

obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
print(f"FINAL_OBJ_VALUE: {obj_val}")
