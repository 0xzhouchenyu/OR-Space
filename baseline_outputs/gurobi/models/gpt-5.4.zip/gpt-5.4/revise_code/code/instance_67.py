import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_csv(path):
    with open(path, "r", newline="") as f:
        return list(csv.DictReader(f))


def load_parameters(base_dir):
    rows = load_csv(os.path.join(base_dir, "data", "general_parameters.csv"))
    params = {}
    for row in rows:
        params[row["Parameter_Name"]] = float(row["Value"])
    return params


def load_demand(base_dir):
    rows = load_csv(os.path.join(base_dir, "data", "table_1.csv"))
    demand = {}
    for row in rows:
        demand[(row["Month"], row["Product"])] = float(row["Market_Demand_Units"])
    return demand


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    params = load_parameters(base_dir)
    demand_data = load_demand(base_dir)

    months = ["July", "August", "September", "October", "November", "December"]
    month_key = {
        "July": "july",
        "August": "august",
        "September": "september",
        "October": "october",
        "November": "november",
        "December": "december",
    }
    products = ["Product_I", "Product_II"]

    prod_cost = {
        "Product_I": params["product_I_cost_jun_to_dec"],
        "Product_II": params["product_II_cost_jun_to_dec"],
    }
    volume = {
        "Product_I": params["product_I_volume"],
        "Product_II": params["product_II_volume"],
    }
    machine_hours = {
        "Product_I": params["product_I_machine_hours"],
        "Product_II": params["product_II_machine_hours"],
    }
    power_kwh = {
        "Product_I": params["product_I_power_kwh"],
        "Product_II": params["product_II_power_kwh"],
    }

    machine_cap = params["machine_hours_capacity_monthly"]
    warehouse_cap = params["warehouse_capacity"]
    own_wh_cost = params["own_warehouse_cost"]
    grid_cost = params["grid_electricity_cost"]
    gen_cost = params["generator_electricity_cost"]
    initial_inventory = params["initial_inventory_july"]

    grid_quota = {m: params[f"grid_quota_{month_key[m]}"] for m in months}
    generator_max = {m: params[f"generator_max_{month_key[m]}"] for m in months}
    demand = {(m, p): demand_data[(m, p)] for m in months for p in products}

    model = gp.Model("revised_production_planning")
    model.setParam("OutputFlag", 0)

    x = model.addVars(months, products, lb=0.0, vtype=GRB.CONTINUOUS, name="prod")
    inv = model.addVars(months, products, lb=0.0, vtype=GRB.CONTINUOUS, name="inv")
    wh = model.addVars(months, lb=0.0, vtype=GRB.CONTINUOUS, name="warehouse_used")
    grid = model.addVars(months, lb=0.0, vtype=GRB.CONTINUOUS, name="grid_kwh")
    gen = model.addVars(months, lb=0.0, vtype=GRB.CONTINUOUS, name="generator_kwh")

    model.setObjective(
        gp.quicksum(prod_cost[p] * x[m, p] for m in months for p in products)
        + gp.quicksum(own_wh_cost * wh[m] for m in months)
        + gp.quicksum(grid_cost * grid[m] + gen_cost * gen[m] for m in months),
        GRB.MINIMIZE,
    )

    for idx, m in enumerate(months):
        for p in products:
            if idx == 0:
                model.addConstr(
                    inv[m, p] == initial_inventory + x[m, p] - demand[m, p],
                    name=f"inventory_balance_{m}_{p}",
                )
            else:
                prev_m = months[idx - 1]
                model.addConstr(
                    inv[m, p] == inv[prev_m, p] + x[m, p] - demand[m, p],
                    name=f"inventory_balance_{m}_{p}",
                )

        model.addConstr(
            gp.quicksum(machine_hours[p] * x[m, p] for p in products) <= machine_cap,
            name=f"machine_capacity_{m}",
        )

        total_power = gp.quicksum(power_kwh[p] * x[m, p] for p in products)
        model.addConstr(grid[m] + gen[m] == total_power, name=f"power_balance_{m}")
        model.addConstr(grid[m] <= grid_quota[m], name=f"grid_quota_{m}")
        model.addConstr(gen[m] <= generator_max[m], name=f"generator_limit_{m}")

        total_volume = gp.quicksum(volume[p] * inv[m, p] for p in products)
        model.addConstr(wh[m] == total_volume, name=f"warehouse_usage_{m}")
        model.addConstr(wh[m] <= warehouse_cap, name=f"warehouse_capacity_{m}")

    model.optimize()

    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
