import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_general_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = row["Value"].strip()
            try:
                if "." in val:
                    params[name] = float(val)
                else:
                    params[name] = int(val)
            except ValueError:
                params[name] = float(val)
    return params

def read_demand(path):
    demand = []
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row["Required_number"]))
    return demand

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = read_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    demand = read_demand(os.path.join(data_dir, "table_1_2.csv"))

    n_periods = len(demand)
    shift_duration = int(params["shift_duration"])
    periods_per_shift = shift_duration // 4

    driver_rest_gap = int(params["driver_rest_gap"])
    crew_rest_gap = int(params["crew_rest_gap"])
    max_night_driver_fraction = float(params["max_night_driver_fraction"])
    max_night_crew_fraction = float(params["max_night_crew_fraction"])
    max_overtime_shifts = int(params["max_overtime_shifts"])
    overtime_cost_factor = float(params["overtime_cost_factor"])

    night_periods = [4, 5]  # periods 5 and 6 in 0-based indexing

    model = gp.Model("revised_bus_staffing")
    model.setParam("OutputFlag", 0)

    # Regular and overtime starts by role and period
    reg_driver = model.addVars(n_periods, vtype=GRB.INTEGER, lb=0, name="reg_driver")
    ot_driver = model.addVars(n_periods, vtype=GRB.INTEGER, lb=0, name="ot_driver")
    reg_crew = model.addVars(n_periods, vtype=GRB.INTEGER, lb=0, name="reg_crew")
    ot_crew = model.addVars(n_periods, vtype=GRB.INTEGER, lb=0, name="ot_crew")

    # Objective: regular cost 1, overtime cost overtime_cost_factor
    model.setObjective(
        gp.quicksum(reg_driver[i] + reg_crew[i] for i in range(n_periods)) +
        overtime_cost_factor * gp.quicksum(ot_driver[i] + ot_crew[i] for i in range(n_periods)),
        GRB.MINIMIZE
    )

    # Coverage constraints for each role in each operating window
    for j in range(n_periods):
        covering_periods = [i for i in range(n_periods) if j in [((i + k) % n_periods) for k in range(periods_per_shift)]]

        model.addConstr(
            gp.quicksum(reg_driver[i] + ot_driver[i] for i in covering_periods) >= demand[j],
            name=f"driver_coverage_{j+1}"
        )
        model.addConstr(
            gp.quicksum(reg_crew[i] + ot_crew[i] for i in covering_periods) >= demand[j],
            name=f"crew_coverage_{j+1}"
        )

    # Total starts by role
    total_driver = gp.quicksum(reg_driver[i] + ot_driver[i] for i in range(n_periods))
    total_crew = gp.quicksum(reg_crew[i] + ot_crew[i] for i in range(n_periods))

    # Night starts by role
    night_driver = gp.quicksum(reg_driver[i] + ot_driver[i] for i in night_periods)
    night_crew = gp.quicksum(reg_crew[i] + ot_crew[i] for i in night_periods)

    # Fraction limits on night starts
    model.addConstr(
        night_driver <= max_night_driver_fraction * total_driver,
        name="max_night_driver_fraction"
    )
    model.addConstr(
        night_crew <= max_night_crew_fraction * total_crew,
        name="max_night_crew_fraction"
    )

    # Rest-gap proxy constraints in late-night cluster
    # Interpreted as requiring regular starts in periods 5 and 6 to be limited by
    # the available starts outside the night cluster scaled by role-specific gap.
    outside_night_driver = gp.quicksum(reg_driver[i] for i in range(n_periods) if i not in night_periods)
    outside_night_crew = gp.quicksum(reg_crew[i] for i in range(n_periods) if i not in night_periods)
    night_reg_driver = gp.quicksum(reg_driver[i] for i in night_periods)
    night_reg_crew = gp.quicksum(reg_crew[i] for i in night_periods)

    model.addConstr(
        driver_rest_gap * night_reg_driver <= outside_night_driver,
        name="driver_rest_gap_proxy"
    )
    model.addConstr(
        crew_rest_gap * night_reg_crew <= outside_night_crew,
        name="crew_rest_gap_proxy"
    )

    # Overtime cap across both groups
    model.addConstr(
        gp.quicksum(ot_driver[i] + ot_crew[i] for i in range(n_periods)) <= max_overtime_shifts,
        name="max_total_overtime"
    )

    model.optimize()

    obj_val = model.ObjVal
    if abs(obj_val - round(obj_val)) < 1e-9:
        obj_str = str(int(round(obj_val)))
    else:
        obj_str = str(obj_val)

    print(f"FINAL_OBJ_VALUE: {obj_str}")

if __name__ == "__main__":
    main()
