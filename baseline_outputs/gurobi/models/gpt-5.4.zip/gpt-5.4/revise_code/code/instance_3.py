import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load demand data
months = []
demand = []
with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        months.append(row["Month"])
        demand.append(float(row["Demand_Forecast"]))

T = len(months)

# Load parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

W0 = params["initial_workforce"]
I0 = params["initial_inventory"]
sp = params["sales_price"]
rmc = params["raw_material_cost"]
oc = params["outsourcing_cost"]
hc = params["inventory_holding_cost"]
bc = params["backorder_cost"]
lr = params["labor_requirement"]
rh = params["regular_labor_hours"]
rw = params["regular_wage"]
otl = params["overtime_hours_limit"]
ow = params["overtime_wage"]
hire_cost = params["hiring_cost"]
fire_cost = params["firing_cost"]
term_inv = params["terminal_inventory"]
term_bo = params["terminal_backorders"]
contract_min_units = params["contract_min_units"]
contract_bigM = params["contract_bigM"]

# Contract months: April, May, June
contract_month_names = {"April", "May", "June"}
contract_idx = [t for t, m in enumerate(months) if m in contract_month_names]

m = gp.Model("FoldableTableProductionRevised")
m.setParam("OutputFlag", 0)

# Decision variables
W = m.addVars(T, lb=0.0, vtype=GRB.CONTINUOUS, name="W")
H = m.addVars(T, lb=0.0, vtype=GRB.CONTINUOUS, name="H")
F = m.addVars(T, lb=0.0, vtype=GRB.CONTINUOUS, name="F")

P = m.addVars(T, lb=0.0, vtype=GRB.CONTINUOUS, name="P")          # total in-house production
R = m.addVars(T, lb=0.0, vtype=GRB.CONTINUOUS, name="R")          # regular-time in-house production
OTH = m.addVars(T, lb=0.0, vtype=GRB.CONTINUOUS, name="OTH")      # overtime hours
O = m.addVars(T, lb=0.0, vtype=GRB.CONTINUOUS, name="O")          # outsourced units

Inv = m.addVars(T, lb=0.0, vtype=GRB.CONTINUOUS, name="Inv")
B = m.addVars(T, lb=0.0, vtype=GRB.CONTINUOUS, name="B")

# Contract-related variables
Q = m.addVars(T, lb=0.0, vtype=GRB.CONTINUOUS, name="Q")          # contract-qualified quantity
Y = m.addVars(T, vtype=GRB.BINARY, name="Y")                      # binary indicators for contract accounting switch

# Constraints
for t in range(T):
    # Workforce balance
    if t == 0:
        m.addConstr(W[t] == W0 + H[t] - F[t], name=f"workforce_balance_{t}")
        prev_backlog = 0.0
    else:
        m.addConstr(W[t] == W[t - 1] + H[t] - F[t], name=f"workforce_balance_{t}")
        prev_backlog = B[t - 1]

    # Capacity decomposition
    m.addConstr(P[t] == R[t] + OTH[t] / lr, name=f"prod_decomp_{t}")
    m.addConstr(R[t] * lr <= W[t] * rh, name=f"regular_capacity_{t}")
    m.addConstr(OTH[t] <= W[t] * otl, name=f"overtime_limit_{t}")

    # Inventory / backlog balance
    prev_inv = I0 if t == 0 else Inv[t - 1]
    m.addConstr(
        Inv[t] - B[t] == prev_inv - prev_backlog + P[t] + O[t] - demand[t],
        name=f"inventory_balance_{t}"
    )

    # Contract constraints for April-June
    if t in contract_idx:
        live_requirement_expr = demand[t] + prev_backlog

        # Must satisfy minimum contract quantity
        m.addConstr(Q[t] >= contract_min_units, name=f"contract_min_{t}")

        # Qualified quantity cannot exceed regular-time production
        m.addConstr(Q[t] <= R[t], name=f"contract_q_le_regular_prod_{t}")

        # Qualified quantity cannot exceed live requirement (demand + carried backlog)
        m.addConstr(Q[t] <= live_requirement_expr, name=f"contract_q_le_live_req_{t}")

        # Binary indicator / big-M accounting constraints
        m.addConstr(Q[t] <= contract_bigM * Y[t], name=f"contract_bigM_up_{t}")
        m.addConstr(Q[t] >= contract_min_units - contract_bigM * (1 - Y[t]), name=f"contract_bigM_low_{t}")

        # Since contract applies in these months, force the switch active
        m.addConstr(Y[t] == 1, name=f"contract_indicator_on_{t}")
    else:
        m.addConstr(Q[t] == 0, name=f"no_contract_q_{t}")
        m.addConstr(Y[t] == 0, name=f"no_contract_y_{t}")

# Terminal conditions
m.addConstr(Inv[T - 1] >= term_inv, name="terminal_inventory")
m.addConstr(B[T - 1] <= term_bo, name="terminal_backorders")

# Objective
total_demand = sum(demand)
revenue = sp * total_demand

material_cost = gp.quicksum(rmc * P[t] for t in range(T))
outsource_cost = gp.quicksum(oc * O[t] for t in range(T))
holding_cost = gp.quicksum(hc * Inv[t] for t in range(T))
backorder_cost_total = gp.quicksum(bc * B[t] for t in range(T))
regular_labor_cost = gp.quicksum(rw * rh * W[t] for t in range(T))
overtime_cost = gp.quicksum(ow * OTH[t] for t in range(T))
hiring_cost_total = gp.quicksum(hire_cost * H[t] for t in range(T))
firing_cost_total = gp.quicksum(fire_cost * F[t] for t in range(T))

total_cost = (
    material_cost
    + outsource_cost
    + holding_cost
    + backorder_cost_total
    + regular_labor_cost
    + overtime_cost
    + hiring_cost_total
    + firing_cost_total
)

m.setObjective(revenue - total_cost, GRB.MAXIMIZE)

m.optimize()

obj_val = m.ObjVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
