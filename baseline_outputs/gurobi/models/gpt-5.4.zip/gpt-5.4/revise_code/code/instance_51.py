import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_demand(filepath):
    demand = []
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row["Required_Nurses"]))
    return demand


def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = row["Value"]
    return params


def parse_int_list(s):
    return [int(x.strip()) for x in s.split(";") if x.strip()]


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    demand = load_demand(os.path.join(data_dir, "table_1.csv"))
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

    shift_start_times = [x.strip() for x in params["shift_start_times"].split(";") if x.strip()]
    num_periods = len(demand)

    shift_duration = int(float(params["shift_duration"]))
    regular_pay = float(params["regular_nurse_pay"])
    contract_pay = float(params["contract_nurse_pay"])

    outsourced_regular_start_index = int(params["outsourced_regular_start_index"])
    banned_contract_start_index = int(params["banned_contract_start_index"])
    max_total_contract_starts = int(params["max_total_contract_starts"])
    min_regular_daytime_coverage = int(params["min_regular_daytime_coverage"])
    daytime_period_indices = parse_int_list(params["daytime_period_indices"])

    periods_per_shift = shift_duration // 4

    def shift_covers_period(j, i):
        return any(((j + k) % num_periods) == i for k in range(periods_per_shift))

    model = gp.Model("revised_nurse_scheduling")
    model.setParam("OutputFlag", 0)

    x = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="regular_start")
    y = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="contract_start")

    model.setObjective(
        gp.quicksum(regular_pay * shift_duration * x[j] + contract_pay * shift_duration * y[j] for j in range(num_periods)),
        GRB.MINIMIZE
    )

    for i in range(num_periods):
        covering_shifts = [j for j in range(num_periods) if shift_covers_period(j, i)]
        model.addConstr(
            gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i],
            name=f"total_coverage_{i}"
        )

    model.addConstr(x[outsourced_regular_start_index] == 0, name="outsourced_regular_shift")
    model.addConstr(y[banned_contract_start_index] == 0, name="banned_contract_shift")
    model.addConstr(gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts, name="max_total_contract_starts")

    for i in daytime_period_indices:
        covering_shifts = [j for j in range(num_periods) if shift_covers_period(j, i)]
        model.addConstr(
            gp.quicksum(x[j] for j in covering_shifts) >= max(demand[i], min_regular_daytime_coverage),
            name=f"regular_daytime_coverage_{i}"
        )

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")


if __name__ == "__main__":
    main()
