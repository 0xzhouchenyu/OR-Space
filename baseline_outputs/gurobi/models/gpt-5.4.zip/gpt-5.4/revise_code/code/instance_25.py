import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_parameters(data_path)

    W = params["initial_investment"]
    r1 = params["return_rate_option_1"]
    r2 = params["return_rate_option_2"]
    min_reserve_year1 = params["min_reserve_year1"]
    min_reserve_year2 = params["min_reserve_year2"]
    max_option2_start = params["max_option2_start"]
    late_settlement_rate = params["option2_year0_late_settlement_rate"]

    m = gp.Model("revised_investment")
    m.setParam("OutputFlag", 0)

    # Decision variables
    x0_1 = m.addVar(lb=0.0, name="x0_1")  # option 1 started at year 0
    x0_2 = m.addVar(lb=0.0, ub=max_option2_start, name="x0_2")  # option 2 started at year 0
    c1 = m.addVar(lb=0.0, name="c1")      # reserve held through year 1

    x1_1 = m.addVar(lb=0.0, name="x1_1")  # option 1 started at year 1
    x1_2 = m.addVar(lb=0.0, ub=max_option2_start, name="x1_2")  # option 2 started at year 1
    c2 = m.addVar(lb=0.0, name="c2")      # reserve held through year 2

    x2_1 = m.addVar(lb=0.0, name="x2_1")  # option 1 started at year 2

    # Year 0 allocation
    m.addConstr(x0_1 + x0_2 + c1 == W, name="year0_flow")

    # Reserve floor at end of year 1
    m.addConstr(c1 >= min_reserve_year1, name="min_reserve_year1")

    # Funds available for year 1 starts / year 2 reserve:
    # c1 carried from year 0 + proceeds from year-0 option 1
    m.addConstr(
        x1_1 + x1_2 + c2 == c1 + x0_1 * (1.0 + r1),
        name="year1_flow"
    )

    # Reserve floor at end of year 2
    m.addConstr(c2 >= min_reserve_year2, name="min_reserve_year2")

    # Year 2 reinvestment cutoff:
    # only c2 and proceeds from year-1 option 1 are available before cutoff
    # year-0 option 2 settles after the cutoff, so cannot fund x2_1
    m.addConstr(
        x2_1 <= c2 + x1_1 * (1.0 + r1),
        name="year2_flow_before_cutoff"
    )

    # Objective: final wealth at end of year 3
    # Includes:
    # - proceeds from year-2 option 1
    # - proceeds from year-1 option 2
    # - uninvested cash remaining after year-2 cutoff: c2 + x1_1*(1+r1) - x2_1
    # - late-settling proceeds from year-0 option 2 with service deduction
    final_wealth = (
        x2_1 * (1.0 + r1)
        + x1_2 * (1.0 + r2)
        + (c2 + x1_1 * (1.0 + r1) - x2_1)
        + x0_2 * (1.0 + r2) * (1.0 - late_settlement_rate)
    )

    m.setObjective(final_wealth, GRB.MAXIMIZE)
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")


if __name__ == "__main__":
    main()
