import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

base_dir = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(base_dir, "data", "general_parameters.csv")
params = load_general_parameters(data_path)

shirts_inventory = params["shirts_inventory"]
pants_inventory = params["pants_inventory"]

price_a = params["package_a_price"]
price_b = params["package_b_price"]
price_c = params["package_c_price"]

shirts_a = params["package_a_shirts"]
pants_a = params["package_a_pants"]
shirts_b = params["package_b_shirts"]
pants_b = params["package_b_pants"]
shirts_c = params["package_c_shirts"]
pants_c = params["package_c_pants"]

min_a = params["min_campaign_batch_a"]
min_b = params["min_campaign_batch_b"]
min_c = params["min_campaign_batch_c"]

activation_cost_a = params["activation_cost_a"]
activation_cost_b = params["activation_cost_b"]
activation_cost_c = params["activation_cost_c"]

labor_a = params["labor_hours_per_A"]
labor_b = params["labor_hours_per_B"]
labor_c = params["labor_hours_per_C"]
labor_total = params["labor_hours_total"]

bigM_a = params["bigM_a"]
bigM_b = params["bigM_b"]
bigM_c = params["bigM_c"]

b_review_threshold = params["package_b_review_threshold"]
b_review_charge = params["package_b_review_charge"]

c_review_threshold = params["package_c_review_threshold"]
c_review_charge = params["package_c_review_charge"]

model = gp.Model("revised_promotion_optimization")
model.setParam("OutputFlag", 0)

x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_a")
x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_b")
x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_c")

y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
y_c = model.addVar(vtype=GRB.BINARY, name="y_c")

z_b_review = model.addVar(vtype=GRB.BINARY, name="z_b_review")
z_c_review = model.addVar(vtype=GRB.BINARY, name="z_c_review")

model.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inventory, name="shirts_inventory")
model.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inventory, name="pants_inventory")
model.addConstr(labor_a * x_a + labor_b * x_b + labor_c * x_c <= labor_total, name="labor_budget")

model.addConstr(x_a >= min_a * y_a, name="min_batch_a")
model.addConstr(x_b >= min_b * y_b, name="min_batch_b")
model.addConstr(x_c >= min_c * y_c, name="min_batch_c")

model.addConstr(x_a <= bigM_a * y_a, name="link_a")
model.addConstr(x_b <= bigM_b * y_b, name="link_b")
model.addConstr(x_c <= bigM_c * y_c, name="link_c")

model.addConstr(x_b <= b_review_threshold + bigM_b * z_b_review, name="b_review_gate")
model.addConstr(z_b_review <= y_b, name="b_review_only_if_active")

model.addConstr(x_c <= c_review_threshold + bigM_c * z_c_review, name="c_review_gate")
model.addConstr(z_c_review <= y_c, name="c_review_only_if_active")

objective = (
    price_a * x_a + price_b * x_b + price_c * x_c
    - activation_cost_a * y_a - activation_cost_b * y_b - activation_cost_c * y_c
    - b_review_charge * z_b_review - c_review_charge * z_c_review
)

model.setObjective(objective, GRB.MAXIMIZE)
model.optimize()

obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float("nan")
print(f"FINAL_OBJ_VALUE: {obj_val}")
