import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    p = load_parameters(data_path)

    a = p["a"]
    b = p["b"]
    k = p["k"]
    d = p["d"]

    c_offpeak = p["c_offpeak"]
    c_peak = p["c_peak"]
    cap_offpeak = p["cap_offpeak"]
    cap_peak = p["cap_peak"]

    m_offpeak = p["m_offpeak"]
    n_offpeak = p["n_offpeak"]
    m_peak = p["m_peak"]
    n_peak = p["n_peak"]

    f_offpeak = p["f_offpeak"]
    f_peak = p["f_peak"]

    threshold = p["offpeak_cooldown_batch_threshold"]
    cooldown_fee = p["offpeak_cooldown_fee"]

    furnaces = [1, 2]

    model = gp.Model("revised_steel_furnace")
    model.setParam("OutputFlag", 0)

    # Continuous batch variables by furnace, period, and method
    x_off_m1 = {i: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_off_m1_{i}") for i in furnaces}
    x_off_m2 = {i: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_off_m2_{i}") for i in furnaces}
    x_peak_m1 = {i: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_peak_m1_{i}") for i in furnaces}
    x_peak_m2 = {i: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_peak_m2_{i}") for i in furnaces}

    # Binary activation variables
    y_off = {i: model.addVar(vtype=GRB.BINARY, name=f"y_off_{i}") for i in furnaces}
    y_peak = {i: model.addVar(vtype=GRB.BINARY, name=f"y_peak_{i}") for i in furnaces}

    # Binary cooldown trigger variables
    z_cool = {i: model.addVar(vtype=GRB.BINARY, name=f"z_cool_{i}") for i in furnaces}

    # Objective
    model.setObjective(
        gp.quicksum(
            m_offpeak * x_off_m1[i] +
            n_offpeak * x_off_m2[i] +
            m_peak * x_peak_m1[i] +
            n_peak * x_peak_m2[i] +
            f_offpeak * y_off[i] +
            f_peak * y_peak[i] +
            cooldown_fee * z_cool[i]
            for i in furnaces
        ),
        GRB.MINIMIZE
    )

    # Per-furnace time limits by period
    for i in furnaces:
        model.addConstr(a * x_off_m1[i] + b * x_off_m2[i] <= c_offpeak, name=f"offpeak_time_furnace_{i}")
        model.addConstr(a * x_peak_m1[i] + b * x_peak_m2[i] <= c_peak, name=f"peak_time_furnace_{i}")

    # Plant-wide time limits by period
    model.addConstr(
        gp.quicksum(a * x_off_m1[i] + b * x_off_m2[i] for i in furnaces) <= cap_offpeak,
        name="plant_offpeak_cap"
    )
    model.addConstr(
        gp.quicksum(a * x_peak_m1[i] + b * x_peak_m2[i] for i in furnaces) <= cap_peak,
        name="plant_peak_cap"
    )

    # Production requirement
    model.addConstr(
        k * gp.quicksum(
            x_off_m1[i] + x_off_m2[i] + x_peak_m1[i] + x_peak_m2[i]
            for i in furnaces
        ) >= d,
        name="min_production"
    )

    # Activation logic
    for i in furnaces:
        model.addConstr(a * x_off_m1[i] + b * x_off_m2[i] <= c_offpeak * y_off[i], name=f"activate_off_{i}")
        model.addConstr(a * x_peak_m1[i] + b * x_peak_m2[i] <= c_peak * y_peak[i], name=f"activate_peak_{i}")

    # Cooldown gate: if off-peak batches on furnace i exceed threshold, fee applies
    max_off_batches = c_offpeak / min(a, b)
    for i in furnaces:
        off_batches_i = x_off_m1[i] + x_off_m2[i]
        model.addConstr(
            off_batches_i <= threshold + max_off_batches * z_cool[i],
            name=f"cooldown_trigger_{i}"
        )

    model.optimize()

    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
