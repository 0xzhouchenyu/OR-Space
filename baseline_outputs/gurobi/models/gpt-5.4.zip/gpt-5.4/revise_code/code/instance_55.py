import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_courses(data_dir):
    filepath = os.path.join(data_dir, "table_1.csv")
    courses = {}
    categories = set()
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row["Course"].strip()
            cats = [c.strip() for c in row["Category"].split(";") if c.strip()]
            courses[course] = cats
            categories.update(cats)
    return courses, sorted(categories)

def load_parameters(data_dir):
    filepath = os.path.join(data_dir, "general_parameters.csv")
    params = {}
    prereq_raw = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            value = row["Value"].strip()
            if name == "min_courses_required":
                params["min_courses_required"] = int(value)
            elif name == "mandatory_foundation_for_cs_counting":
                params["mandatory_foundation_for_cs_counting"] = value
            elif name == "cs_category_name":
                params["cs_category_name"] = value
            elif name.startswith("prerequisite_"):
                course_key = name[len("prerequisite_"):].lower().replace("_", " ")
                prereq_raw[course_key] = value
    return params, prereq_raw

def match_course_name(key_name, course_list):
    key_norm = key_name.strip().lower()
    for c in course_list:
        if c.strip().lower() == key_norm:
            return c
    return None

def main():
    root_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(root_dir, "data")

    courses, all_categories = load_courses(data_dir)
    params, prereq_raw = load_parameters(data_dir)

    course_list = sorted(courses.keys())
    min_required = params["min_courses_required"]
    cs_category = params["cs_category_name"]
    cs_foundation = params["mandatory_foundation_for_cs_counting"]

    prerequisites = {}
    for raw_course, prereq in prereq_raw.items():
        actual_course = match_course_name(raw_course, course_list)
        if actual_course is None:
            raise ValueError(f"Could not match prerequisite course key: {raw_course}")
        prerequisites.setdefault(actual_course, []).append(prereq)

    model = gp.Model("revised_course_selection")
    model.setParam("OutputFlag", 0)

    x = model.addVars(course_list, vtype=GRB.BINARY, name="take")
    y = {}
    for c in course_list:
        for cat in courses[c]:
            y[c, cat] = model.addVar(vtype=GRB.BINARY, name=f"count[{c},{cat}]")

    # Objective: minimize total number of courses taken
    model.setObjective(gp.quicksum(x[c] for c in course_list), GRB.MINIMIZE)

    # A course can only be counted in a category if it is taken
    for c in course_list:
        for cat in courses[c]:
            model.addConstr(y[c, cat] <= x[c], name=f"count_only_if_taken[{c},{cat}]")

    # Cross-listed course cannot satisfy multiple category minima simultaneously
    for c in course_list:
        model.addConstr(
            gp.quicksum(y[c, cat] for cat in courses[c]) <= 1,
            name=f"at_most_one_count_category[{c}]"
        )

    # Category requirements must be met with distinct counted courses
    for cat in all_categories:
        eligible = [c for c in course_list if cat in courses[c]]
        model.addConstr(
            gp.quicksum(y[c, cat] for c in eligible) >= min_required,
            name=f"min_counted_courses[{cat}]"
        )

    # Prerequisite constraints for taking courses
    for c, prereqs in prerequisites.items():
        for p in prereqs:
            if p not in courses:
                raise ValueError(f"Prerequisite course '{p}' for '{c}' not found in course list")
            model.addConstr(x[c] <= x[p], name=f"prereq[{c},{p}]")

    # Programming foundation must be completed before any course is counted toward CS
    if cs_category not in all_categories:
        raise ValueError(f"CS category '{cs_category}' not found in categories")
    if cs_foundation not in courses:
        raise ValueError(f"Foundation course '{cs_foundation}' not found in courses")

    cs_eligible = [c for c in course_list if cs_category in courses[c]]
    for c in cs_eligible:
        model.addConstr(
            y[c, cs_category] <= x[cs_foundation],
            name=f"foundation_for_cs_counting[{c}]"
        )

    model.optimize()

    if model.Status != GRB.OPTIMAL:
        raise RuntimeError(f"Optimization ended with status {model.Status}")

    obj_val = model.ObjVal
    if abs(obj_val - round(obj_val)) <= 1e-9:
        obj_str = str(int(round(obj_val)))
    else:
        obj_str = str(obj_val)

    print(f"FINAL_OBJ_VALUE: {obj_str}")

if __name__ == "__main__":
    main()
