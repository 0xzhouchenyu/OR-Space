import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_goods_data(filepath):
    goods = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            g = row["Goods_Type"].strip()
            goods[g] = {
                "quantity": int(float(row["Quantity"].strip())),
                "weight": float(row["Weight_per_Unit"].strip()),
            }
    return goods

def load_parameters(filepath):
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    goods = load_goods_data(os.path.join(data_dir, "table_1.csv"))
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

    goods_types = list(goods.keys())
    quantities = {g: goods[g]["quantity"] for g in goods_types}
    weights = {g: goods[g]["weight"] for g in goods_types}

    max_cap = params["max_container_capacity"]
    min_load = params["min_container_load"]
    min_d_per_container = int(round(params["min_d_goods_per_container"]))
    min_c_per_a = int(round(params["min_c_per_a"]))

    total_weight = sum(quantities[g] * weights[g] for g in goods_types)

    ub_by_min_load = math.floor(total_weight / min_load)
    ub_by_d = quantities["D"] // min_d_per_container
    max_containers = min(ub_by_min_load, ub_by_d)

    model = gp.Model("revised_container_minimization")
    model.setParam("OutputFlag", 0)

    N = range(max_containers)

    x = model.addVars(goods_types, N, vtype=GRB.INTEGER, lb=0, name="x")
    y = model.addVars(N, vtype=GRB.BINARY, name="y")
    zA = model.addVars(N, vtype=GRB.BINARY, name="zA")
    zE = model.addVars(N, vtype=GRB.BINARY, name="zE")

    model.setObjective(gp.quicksum(y[j] for j in N), GRB.MINIMIZE)

    for g in goods_types:
        model.addConstr(gp.quicksum(x[g, j] for j in N) == quantities[g], name=f"demand_{g}")

    M = quantities

    for j in N:
        total_w_j = gp.quicksum(weights[g] * x[g, j] for g in goods_types)

        model.addConstr(total_w_j >= min_load * y[j], name=f"min_load_{j}")
        model.addConstr(total_w_j <= max_cap * y[j] - (max_cap - 45.0) * zE[j], name=f"cap_{j}")

        model.addConstr(x["D", j] >= min_d_per_container * y[j], name=f"minD_{j}")

        model.addConstr(x["A", j] <= M["A"] * zA[j], name=f"A_indicator_{j}")
        model.addConstr(x["C", j] >= min_c_per_a * zA[j], name=f"C_if_A_{j}")

        model.addConstr(x["E", j] <= M["E"] * zE[j], name=f"E_indicator_{j}")
        model.addConstr(zE[j] <= y[j], name=f"E_only_if_used_{j}")
        model.addConstr(zA[j] <= y[j], name=f"A_only_if_used_{j}")

        for g in goods_types:
            model.addConstr(x[g, j] <= M[g] * y[j], name=f"use_link_{g}_{j}")

    for j in range(max_containers - 1):
        model.addConstr(y[j] >= y[j + 1], name=f"symmetry_{j}")

    model.optimize()

    obj = model.ObjVal
    if abs(obj - round(obj)) < 1e-6:
        obj_str = str(int(round(obj)))
    else:
        obj_str = str(obj)

    print(f"FINAL_OBJ_VALUE: {obj_str}")

if __name__ == "__main__":
    main()
