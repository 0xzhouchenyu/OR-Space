import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_general_parameters(path):
    params = {}
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            params[name] = float(row["Value"])
    return params

def read_container_data(path):
    containers = []
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                "code": int(row["Container_Type_Code"]),
                "volume": int(row["Volume_cm3"]),
                "demand": int(row["Market_Demand_units"]),
                "var_cost": float(row["Unit_Variable_Production_Cost_Yuan_per_unit"]),
            })
    return containers

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = read_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    containers = read_container_data(os.path.join(data_dir, "table_1.csv"))

    fixed_setup_cost = params["fixed_setup_cost"]
    energy_cost_per_kwh = params["energy_cost_per_kwh"]
    max_total_energy_kwh = params["max_total_energy_kwh"]
    eco_capacity_share = params["eco_capacity_share"]
    eco_overhead_cost = params["eco_overhead_cost"]
    regular_energy_intensity = params["regular_energy_intensity_kwh_per_unit"]
    eco_energy_intensity = params["eco_energy_intensity_kwh_per_unit"]

    n = len(containers)
    total_demand = sum(c["demand"] for c in containers)

    model = gp.Model("revised_plastic_containers")
    model.setParam("OutputFlag", 0)

    eligible_pairs = [(i, j) for i in range(n) for j in range(n)
                      if containers[i]["volume"] >= containers[j]["volume"]]

    x_reg = model.addVars(eligible_pairs, vtype=GRB.INTEGER, lb=0, name="x_reg")
    x_eco = model.addVars(eligible_pairs, vtype=GRB.INTEGER, lb=0, name="x_eco")

    y_reg = model.addVars(n, vtype=GRB.BINARY, name="y_reg")
    y_eco = model.addVars(n, vtype=GRB.BINARY, name="y_eco")

    obj = gp.LinExpr()

    for i, j in eligible_pairs:
        var_cost = containers[i]["var_cost"]
        obj += (var_cost + energy_cost_per_kwh * regular_energy_intensity) * x_reg[i, j]
        obj += (var_cost + energy_cost_per_kwh * eco_energy_intensity) * x_eco[i, j]

    for i in range(n):
        obj += fixed_setup_cost * y_reg[i]
        obj += (fixed_setup_cost + eco_overhead_cost) * y_eco[i]

    model.setObjective(obj, GRB.MINIMIZE)

    for j in range(n):
        model.addConstr(
            gp.quicksum(x_reg[i, j] + x_eco[i, j] for i in range(n) if (i, j) in eligible_pairs) >= containers[j]["demand"],
            name=f"demand_{j}"
        )

    for i in range(n):
        reg_prod_i = gp.quicksum(x_reg[i, j] for j in range(n) if (i, j) in eligible_pairs)
        eco_prod_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in eligible_pairs)
        total_prod_i = reg_prod_i + eco_prod_i

        model.addConstr(reg_prod_i <= total_demand * y_reg[i], name=f"link_reg_{i}")
        model.addConstr(eco_prod_i <= total_demand * y_eco[i], name=f"link_eco_{i}")
        model.addConstr(eco_prod_i <= eco_capacity_share * total_prod_i, name=f"eco_share_{i}")

    model.addConstr(
        gp.quicksum(
            regular_energy_intensity * x_reg[i, j] + eco_energy_intensity * x_eco[i, j]
            for i, j in eligible_pairs
        ) <= max_total_energy_kwh,
        name="energy_limit"
    )

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
