import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_all_data():
    """
    Loads all necessary data from CSV files.
    """
    # Construct the path to the data directory relative to the script's location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load product-specific data tables
    t1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    t2 = pd.read_csv(os.path.join(data_dir, 'table_2.csv'))
    t3 = pd.read_csv(os.path.join(data_dir, 'table_3.csv'))
    
    # Load general parameters, renaming the DataFrame to avoid conflict with gurobipy
    gp_df = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))

    # Merge product data into a single DataFrame
    df = t1.merge(t2, on='Product').merge(t3, on='Product')
    
    # Parse general parameters into a dictionary for easy access
    params = {}
    for _, row in gp_df.iterrows():
        # Attempt to convert to float, handle non-numeric values if necessary (though not expected for these params)
        try:
            params[row['Parameter_Name']] = float(row['Value'])
        except ValueError:
            params[row['Parameter_Name']] = row['Value'] # Keep as string if not numeric
            
    return df, params

def solve_revised_problem():
    """
    Solves the revised production planning optimization problem using Gurobi.
    """
    df, params = load_all_data()

    # Extract parameters from the loaded dictionary
    prod_days = params['production_days']
    a1_watch_threshold = params['a1_watch_threshold']
    a1_deep_service_threshold = params['a1_deep_service_threshold']
    maintenance_penalty_watch = params['maintenance_penalty_watch']
    maintenance_penalty_deep = params['maintenance_penalty_deep']
    a1_quality_release_fee = params['a1_quality_release_fee']
    a1_deep_service_fee = params['a1_deep_service_fee']
    a1_priority_price_lift = params['a1_priority_price_lift']

    # Create a new Gurobi model
    model = gp.Model("Production_Planning_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Define sets
    products = df['Product'].tolist()

    # Decision Variables
    # x[p]: Production quantity for product p (continuous, non-negative)
    x = model.addVars(products, name="x", lb=0.0, vtype=GRB.CONTINUOUS)
    # y[p]: Binary variable, 1 if product p is produced (activated), 0 otherwise
    # The original heuristic forced y[p]=1 for all products. However, "fixed activation costs"
    # typically imply a decision to activate. We model y[p] as a true binary decision variable.
    y = model.addVars(products, name="y", vtype=GRB.BINARY)

    # New binary variables for A1 specific logic
    # y_a1_watch: 1 if A1 production strictly exceeds a1_watch_threshold, 0 otherwise
    y_a1_watch = model.addVar(name="y_a1_watch", vtype=GRB.BINARY)
    # y_a1_deep: 1 if A1 production strictly exceeds a1_deep_service_threshold, 0 otherwise
    y_a1_deep = model.addVar(name="y_a1_deep", vtype=GRB.BINARY)
    # x_a1_priority: Quantity of A1 produced strictly above a1_watch_threshold (continuous, non-negative)
    x_a1_priority = model.addVar(name="x_a1_priority", lb=0.0, vtype=GRB.CONTINUOUS)

    # Big M constant for linking binary and continuous variables
    # M_a1 is the maximum possible production of A1 (its maximum demand)
    M_a1 = df[df['Product'] == 'A1']['Maximum_Demand'].iloc[0]
    epsilon = 0.001 # A small positive value for strict inequalities (e.g., x > T)

    # Objective Function: Maximize total profit
    # Profit = (Selling Price - Production Cost) * Quantity - Activation Cost - A1 specific costs + A1 priority revenue
    objective_expr = gp.LinExpr()
    for _, row in df.iterrows():
        p = row['Product']
        # Base profit for all products
        objective_expr += (row['Selling_Price'] - row['Production_Cost']) * x[p]
        # Activation cost for each product, incurred only if activated (y[p]=1)
        objective_expr -= row['Activation_Cost'] * y[p]

    # Add A1 specific costs and revenues
    objective_expr += a1_priority_price_lift * x_a1_priority # Extra revenue for priority A1 units
    objective_expr -= a1_quality_release_fee * y_a1_watch   # Fixed cost if A1 watch threshold is cleared
    objective_expr -= a1_deep_service_fee * y_a1_deep       # Fixed cost if A1 deep service threshold is cleared

    model.setObjective(objective_expr, GRB.MAXIMIZE)

    # Constraints

    # 1. Link production quantity (x) to product activation (y)
    # If a product is not activated (y[p]=0), its production must be 0.
    # If activated (y[p]=1), production must be within min_batch and max_demand.
    for _, row in df.iterrows():
        p = row['Product']
        model.addConstr(x[p] <= row['Maximum_Demand'] * y[p], name=f"max_demand_link_{p}")
        model.addConstr(x[p] >= row['Minimum_Batch'] * y[p], name=f"min_batch_link_{p}")
        # Note: x[p] >= 0 is already set by lb=0.0

    # 2. A1 specific logic: Link x['A1'] to y_a1_watch
    # y_a1_watch = 1 if x['A1'] > a1_watch_threshold, else 0
    # If y_a1_watch = 0, then x['A1'] <= a1_watch_threshold
    model.addConstr(x['A1'] <= a1_watch_threshold + M_a1 * y_a1_watch, name="a1_watch_threshold_upper")
    # If y_a1_watch = 1, then x['A1'] >= a1_watch_threshold + epsilon (strictly greater)
    model.addConstr(x['A1'] >= a1_watch_threshold + epsilon - M_a1 * (1 - y_a1_watch), name="a1_watch_threshold_lower")

    # 3. A1 specific logic: Link x['A1'] to y_a1_deep
    # y_a1_deep = 1 if x['A1'] > a1_deep_service_threshold, else 0
    # If y_a1_deep = 0, then x['A1'] <= a1_deep_service_threshold
    model.addConstr(x['A1'] <= a1_deep_service_threshold + M_a1 * y_a1_deep, name="a1_deep_threshold_upper")
    # If y_a1_deep = 1, then x['A1'] >= a1_deep_service_threshold + epsilon (strictly greater)
    model.addConstr(x['A1'] >= a1_deep_service_threshold + epsilon - M_a1 * (1 - y_a1_deep), name="a1_deep_threshold_lower")

    # 4. Hierarchy constraint: Deep service implies watch level
    # If y_a1_deep is 1, then y_a1_watch must also be 1.
    model.addConstr(y_a1_deep <= y_a1_watch, name="a1_hierarchy_deep_implies_watch")

    # 5. Define x_a1_priority: Quantity of A1 produced strictly above a1_watch_threshold
    # This variable captures the amount of A1 production that qualifies for the priority uplift.
    # It should be 0 if y_a1_watch is 0, and x['A1'] - a1_watch_threshold if y_a1_watch is 1.
    model.addConstr(x_a1_priority >= x['A1'] - a1_watch_threshold, name="a1_priority_qty_lower")
    model.addConstr(x_a1_priority <= x['A1'] - a1_watch_threshold + M_a1 * (1 - y_a1_watch), name="a1_priority_qty_upper_1")
    model.addConstr(x_a1_priority <= M_a1 * y_a1_watch, name="a1_priority_qty_upper_2")
    # Note: x_a1_priority >= 0 is already set by lb=0.0

    # 6. Total production days constraint (revised)
    # Total time spent must be less than or equal to available days,
    # reduced by penalties if A1 thresholds are crossed.
    total_production_time = gp.LinExpr()
    for _, row in df.iterrows():
        total_production_time += x[row['Product']] / row['Production_Quota']
    
    # Calculate available production days, subtracting penalties
    available_prod_days = prod_days - maintenance_penalty_watch * y_a1_watch - maintenance_penalty_deep * y_a1_deep
    model.addConstr(total_production_time <= available_prod_days, name="total_production_days_limit")

    # Solve the model
    model.optimize()

    if model.status == GRB.OPTIMAL:
        return model.objVal
    else:
        # Handle cases where optimization fails (e.g., infeasible, unbounded)
        # For this problem, we expect an optimal solution.
        # If infeasible, model.computeIIS() could be used for debugging.
        return None

if __name__ == "__main__":
    obj_value = solve_revised_problem()
    if obj_value is not None:
        print(f"FINAL_OBJ_VALUE: {round(obj_value, 4)}")
