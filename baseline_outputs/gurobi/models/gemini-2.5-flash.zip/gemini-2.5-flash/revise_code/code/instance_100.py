import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # --- Data Loading ---
    # Construct the absolute path to the data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    bandwidth_data = {}
    nodes = []
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]] # Extract node names from header
        
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                if bw > 0: # Only consider valid connections (bandwidth > 0)
                    bandwidth_data[(row_node, col_node)] = bw
    
    # Calculate costs: cost = 100 - bandwidth for each valid link
    costs = { (u, v): 100 - bw for (u, v), bw in bandwidth_data.items() }
    
    # Define source, intermediate, and target nodes as per problem description
    source = 'A'
    intermediate = 'C'
    target = 'E'
    
    # --- Gurobi Model ---
    model = gp.Model("Bandwidth_Cost_Minimization")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # --- Decision Variables ---
    # x1[u,v]: Binary variable, 1 if link (u,v) is used in the A -> C segment, 0 otherwise
    # x2[u,v]: Binary variable, 1 if link (u,v) is used in the C -> E segment, 0 otherwise
    
    # Create a list of all possible edges (u,v) where bandwidth > 0
    edges = list(costs.keys())
    
    x1 = model.addVars(edges, vtype=GRB.BINARY, name="x_AC")
    x2 = model.addVars(edges, vtype=GRB.BINARY, name="x_CE")
    
    # --- Objective Function ---
    # Minimize the total routing cost, which is the sum of costs of all used links
    model.setObjective(
        gp.quicksum(costs[u,v] * x1[u,v] for u,v in edges) +
        gp.quicksum(costs[u,v] * x2[u,v] for u,v in edges),
        GRB.MINIMIZE
    )
    
    # --- Constraints ---
    
    # 1. Flow conservation constraints for the A -> C segment
    # For the source node 'A': net flow out must be 1
    model.addConstr(
        gp.quicksum(x1[source, v] for v in nodes if (source, v) in edges) -
        gp.quicksum(x1[u, source] for u in nodes if (u, source) in edges) == 1,
        name="flow_AC_source"
    )
    # For the intermediate node 'C' (which is the sink for this segment): net flow in must be 1
    model.addConstr(
        gp.quicksum(x1[intermediate, v] for v in nodes if (intermediate, v) in edges) -
        gp.quicksum(x1[u, intermediate] for u in nodes if (u, intermediate) in edges) == -1,
        name="flow_AC_sink"
    )
    # For all other nodes (intermediate nodes within the A->C segment): net flow must be 0
    for i in nodes:
        if i != source and i != intermediate:
            model.addConstr(
                gp.quicksum(x1[i, v] for v in nodes if (i, v) in edges) -
                gp.quicksum(x1[u, i] for u in nodes if (u, i) in edges) == 0,
                name=f"flow_AC_{i}"
            )
            
    # 2. Simple path constraints for the A -> C segment (no loops)
    # At most one incoming edge for any node (except the source 'A')
    for i in nodes:
        if i != source:
            model.addConstr(
                gp.quicksum(x1[u, i] for u in nodes if (u, i) in edges) <= 1,
                name=f"simple_AC_in_{i}"
            )
    # At most one outgoing edge from any node (except the sink 'C')
    for i in nodes:
        if i != intermediate:
            model.addConstr(
                gp.quicksum(x1[i, v] for v in nodes if (i, v) in edges) <= 1,
                name=f"simple_AC_out_{i}"
            )

    # 3. Flow conservation constraints for the C -> E segment
    # For the intermediate node 'C' (which is the source for this segment): net flow out must be 1
    model.addConstr(
        gp.quicksum(x2[intermediate, v] for v in nodes if (intermediate, v) in edges) -
        gp.quicksum(x2[u, intermediate] for u in nodes if (u, intermediate) in edges) == 1,
        name="flow_CE_source"
    )
    # For the target node 'E' (sink for this segment): net flow in must be 1
    model.addConstr(
        gp.quicksum(x2[target, v] for v in nodes if (target, v) in edges) -
        gp.quicksum(x2[u, target] for u in nodes if (u, target) in edges) == -1,
        name="flow_CE_sink"
    )
    # For all other nodes (intermediate nodes within the C->E segment): net flow must be 0
    for i in nodes:
        if i != intermediate and i != target:
            model.addConstr(
                gp.quicksum(x2[i, v] for v in nodes if (i, v) in edges) -
                gp.quicksum(x2[u, i] for u in nodes if (u, i) in edges) == 0,
                name=f"flow_CE_{i}"
            )

    # 4. Simple path constraints for the C -> E segment (no loops)
    # At most one incoming edge for any node (except the source 'C')
    for i in nodes:
        if i != intermediate:
            model.addConstr(
                gp.quicksum(x2[u, i] for u in nodes if (u, i) in edges) <= 1,
                name=f"simple_CE_in_{i}"
            )
    # At most one outgoing edge from any node (except the sink 'E')
    for i in nodes:
        if i != target:
            model.addConstr(
                gp.quicksum(x2[i, v] for v in nodes if (i, v) in edges) <= 1,
                name=f"simple_CE_out_{i}"
            )

    # 5. No shared intermediate nodes (except 'C')
    # Any node 'i' that is not A, C, or E cannot be visited in both segments.
    # This is enforced by ensuring that for such a node 'i', it receives an incoming edge
    # from at most one of the two segments (A->C or C->E).
    for i in nodes:
        if i != source and i != intermediate and i != target:
            model.addConstr(
                gp.quicksum(x1[u, i] for u in nodes if (u, i) in edges) +
                gp.quicksum(x2[u, i] for u in nodes if (u, i) in edges) <= 1,
                name=f"no_shared_node_{i}"
            )
            
    # 6. Additional constraints to prevent specific loops/visits
    # Ensure 'A' (source) is not visited as an intermediate node in the C->E path
    model.addConstr(gp.quicksum(x2[u, source] for u in nodes if (u, source) in edges) == 0, name="no_A_in_CE_path")
    # Ensure 'E' (target) is not visited as an intermediate node in the A->C path
    model.addConstr(gp.quicksum(x1[u, target] for u in nodes if (u, target) in edges) == 0, name="no_E_in_AC_path")

    # --- Optimize ---
    model.optimize()
    
    # --- Output ---
    if model.status == GRB.OPTIMAL:
        # The problem asks for the minimum total cost.
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # If no optimal solution is found (e.g., the problem is infeasible),
        # print infinity or a suitable indicator.
        print(f"FINAL_OBJ_VALUE: {float('inf')}")

if __name__ == '__main__':
    main()
