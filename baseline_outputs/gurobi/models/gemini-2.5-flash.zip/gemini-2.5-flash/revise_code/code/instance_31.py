import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_production_plan():
    # --- Data Parsing ---
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    # Parse table_1.csv
    proc_time = {}  # (equipment, product) -> hours per unit
    capacity = {}   # equipment -> available hours
    cost_rate = {}  # equipment -> cost per machine hour
    raw_cost = {}   # product -> raw material cost per unit
    price = {}      # product -> unit selling price

    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            if equip == 'Raw_Material_Cost':
                raw_cost = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            elif equip == 'Unit_Price':
                price = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            else:
                for prod, col in [('I', 'Product_I'), ('II', 'Product_II'), ('III', 'Product_III')]:
                    val = row[col].strip()
                    if val != '-':
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row['Effective_Machine_Hours'])
                cost_rate[equip] = float(row['Processing_Cost_per_Machine_Hour'])

    # Parse general_parameters.csv for joint calibration fee
    joint_calibration_fee = 0.0
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'].strip() == 'A2_B2_joint_calibration_fee':
                joint_calibration_fee = float(row['Value'])
                break # Assuming it's unique and found

    # Parse setup_costs.csv
    fixed_setup_cost = {} # equipment -> fixed setup cost
    with open(os.path.join(data_dir, 'setup_costs.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            fixed_setup_cost[equip] = float(row['Fixed_Setup_Cost'])

    # Equipment assignments (from general_parameters.csv, confirmed by proc_time keys)
    stage_A_equip = {'I': ['A1', 'A2'], 'II': ['A1', 'A2'], 'III': ['A2']}
    stage_B_equip = {'I': ['B1', 'B2', 'B3'], 'II': ['B1'], 'III': ['B2']}

    # Define sets for convenience
    PRODUCTS = ['I', 'II', 'III']
    ALL_EQUIPMENT = sorted(list(set(e for e, p in proc_time.keys()))) # Get all unique equipment names

    # --- Model Definition ---
    model = gp.Model("Factory_Production_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Decision variables
    # x[e, p]: units of product p processed on equipment e
    x = model.addVars(proc_time.keys(), name="x", vtype=GRB.CONTINUOUS, lb=0)

    # y[e]: binary variable, 1 if equipment e is active, 0 otherwise
    y = model.addVars(ALL_EQUIPMENT, name="y", vtype=GRB.BINARY)

    # z_A2_B2: binary variable, 1 if both A2 and B2 are active, 0 otherwise
    z_A2_B2 = model.addVar(name="z_A2_B2", vtype=GRB.BINARY)

    # Total production of each product (defined by stage A flow)
    # This is an expression, not a variable, as it's derived from x
    total_production = {}
    for p in PRODUCTS:
        total_production[p] = gp.quicksum(x[e, p] for e in stage_A_equip[p] if (e,p) in x)

    # --- Constraints ---

    # 1. Flow conservation: total units from Stage A == total units from Stage B for each product
    for p in PRODUCTS:
        model.addConstr(gp.quicksum(x[e, p] for e in stage_A_equip[p] if (e,p) in x) ==
                        gp.quicksum(x[e, p] for e in stage_B_equip[p] if (e,p) in x),
                        name=f"flow_conservation_{p}")

    # 2. Equipment Capacity constraints
    for e in ALL_EQUIPMENT:
        # Filter for (e,p) pairs that actually exist in proc_time
        relevant_x_vars_for_e = [x[e, p] for p in PRODUCTS if (e, p) in x]
        if relevant_x_vars_for_e: # Only add constraint if equipment can process something
            model.addConstr(gp.quicksum(proc_time[(e, p)] * x[e, p] for p in PRODUCTS if (e, p) in x) <= capacity[e],
                            name=f"capacity_{e}")

    # 3. Linking x and y (Fixed Setup Costs)
    # If any x[e,p] > 0, then y[e] must be 1.
    # sum(x[e,p] for p) <= M_e * y[e]
    # M_e is a big M value, representing the maximum possible units processed on equipment e.
    # A tight M_e can be capacity[e] / min_proc_time_on_e
    for e in ALL_EQUIPMENT:
        min_proc_time_on_e = float('inf')
        for p in PRODUCTS:
            if (e, p) in proc_time:
                min_proc_time_on_e = min(min_proc_time_on_e, proc_time[(e, p)])
        
        if min_proc_time_on_e != float('inf'): # Equipment can process something
            M_e = capacity[e] / min_proc_time_on_e
            model.addConstr(gp.quicksum(x[e, p] for p in PRODUCTS if (e, p) in x) <= M_e * y[e],
                            name=f"link_x_y_{e}")
        else: # Equipment cannot process any product, so it should never be active
            model.addConstr(y[e] == 0, name=f"y_{e}_inactive")


    # 4. Linking y_A2, y_B2 and z_A2_B2 (Joint Calibration)
    # z_A2_B2 = 1 if y['A2'] == 1 AND y['B2'] == 1
    model.addConstr(z_A2_B2 <= y['A2'], name="link_z_yA2_1")
    model.addConstr(z_A2_B2 <= y['B2'], name="link_z_yB2_1")
    model.addConstr(z_A2_B2 >= y['A2'] + y['B2'] - 1, name="link_z_yA2_yB2_2")

    # --- Objective Function ---
    # Maximize: Revenue - Raw Material Cost - Processing Cost - Fixed Setup Costs - Joint Calibration Cost

    revenue = gp.quicksum(price[p] * total_production[p] for p in PRODUCTS)
    raw_mat_cost = gp.quicksum(raw_cost[p] * total_production[p] for p in PRODUCTS)
    proc_cost = gp.quicksum(cost_rate[e] * proc_time[(e, p)] * x[e, p] for (e, p) in x)
    fixed_setup_total_cost = gp.quicksum(fixed_setup_cost[e] * y[e] for e in ALL_EQUIPMENT)
    joint_calibration_total_cost = joint_calibration_fee * z_A2_B2

    model.setObjective(revenue - raw_mat_cost - proc_cost - fixed_setup_total_cost - joint_calibration_total_cost, GRB.MAXIMIZE)

    # --- Solve and Output ---
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal:.2f}")
    elif model.status == GRB.INF_OR_UNBD:
        print("FINAL_OBJ_VALUE: Problem is infeasible or unbounded")
    elif model.status == GRB.INFEASIBLE:
        print("FINAL_OBJ_VALUE: Problem is infeasible")
    elif model.status == GRB.UNBOUNDED:
        print("FINAL_OBJ_VALUE: Problem is unbounded")
    else:
        print(f"FINAL_OBJ_VALUE: Optimization ended with status {model.status}")

if __name__ == "__main__":
    solve_production_plan()
