import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
# Assuming the script is located in a subdirectory (e.g., 'src/') and executed from the project root.
# This path resolution correctly points to the 'data' directory at the project root level.
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

# Load monthly prices
months = []
purchase_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        m = int(row['Month'])
        months.append(m)
        purchase_prices[m] = float(row['Purchase_Price_yuan_per_dan'])
        selling_prices[m] = float(row['Selling_Price_yuan_per_dan'])

# Load general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
initial_funds = params['initial_funds']
# end_of_quarter_inventory is 2000, min_inventory_month_3 is 2000.
# The min_inventory_month_3 constraint will cover the end_of_quarter_inventory.
buy_fast_capacity = params['buy_fast_capacity']
fast_purchase_premium_ratio = params['fast_purchase_premium_ratio']
credit_limit = params['credit_limit']
monthly_interest_rate = params['monthly_interest_rate']
min_inventory_month = {
    1: params['min_inventory_month_1'],
    2: params['min_inventory_month_2'],
    3: params['min_inventory_month_3']
}

# Create Gurobi model
model = gp.Model("Grain_Trading_Revised")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# Variables
# buy_regular[m]: Quantity of grain purchased through the regular channel in month m
buy_regular = model.addVars(months, name="buy_regular", lb=0)
# buy_fast[m]: Quantity of grain purchased through the fast channel in month m
buy_fast = model.addVars(months, name="buy_fast", lb=0)
# sell[m]: Quantity of grain sold in month m
sell = model.addVars(months, name="sell", lb=0)
# stock[m]: Inventory level at the end of month m
stock = model.addVars(months, name="stock", lb=0)
# funds[m]: Net financial position (cash - credit used) at the end of month m. Can be negative.
funds = model.addVars(months, name="funds", lb=-GRB.INFINITY)
# credit_used[m]: Amount of credit line in use at the end of month m. Non-negative.
credit_used = model.addVars(months, name="credit_used", lb=0)
# interest_paid[m]: Interest paid in month m. Non-negative.
interest_paid = model.addVars(months, name="interest_paid", lb=0)

# Objective: maximize final funds - initial funds - total interest paid
model.setObjective(funds[months[-1]] - initial_funds - gp.quicksum(interest_paid[m] for m in months), GRB.MAXIMIZE)

# Constraints for each month
for m in months:
    prev_stock = initial_stock if m == 1 else stock[m - 1]
    prev_funds = initial_funds if m == 1 else funds[m - 1]

    # 1. Stock balance
    # Closing stock = previous month's closing stock - sales + regular purchases + fast purchases
    model.addConstr(stock[m] == prev_stock - sell[m] + buy_regular[m] + buy_fast[m], f"stock_balance_{m}")

    # Calculate total purchase cost for the month
    purchase_cost_m = (buy_regular[m] * purchase_prices[m] +
                       buy_fast[m] * purchase_prices[m] * (1 + fast_purchase_premium_ratio))
    # Calculate total sales revenue for the month
    sales_revenue_m = sell[m] * selling_prices[m]

    # 2. Funds balance
    # Closing funds = previous month's closing funds + sales revenue - purchase cost - interest paid
    model.addConstr(funds[m] == prev_funds + sales_revenue_m - purchase_cost_m - interest_paid[m], f"funds_balance_{m}")

    # 3. Warehouse capacity
    model.addConstr(stock[m] <= warehouse_capacity, f"warehouse_capacity_{m}")

    # 4. Sell limit: Can only sell what was in stock at the end of the previous month
    model.addConstr(sell[m] <= prev_stock, f"sell_limit_{m}")

    # 5. Fast purchase capacity
    model.addConstr(buy_fast[m] <= buy_fast_capacity, f"buy_fast_capacity_{m}")

    # 6. Credit usage definition
    # credit_used[m] must be at least the negative of funds[m] if funds[m] is negative
    model.addConstr(credit_used[m] >= -funds[m], f"credit_min_funds_{m}")
    # credit_used[m] cannot exceed the credit_limit
    model.addConstr(credit_used[m] <= credit_limit, f"credit_limit_{m}")
    # This constraint, combined with the objective minimizing interest (cost),
    # ensures that credit_used[m] is exactly max(0, -funds[m]).
    # If funds[m] is positive, credit_used[m] will be 0.
    # If funds[m] is negative, credit_used[m] will be -funds[m].
    model.addConstr(funds[m] + credit_used[m] >= 0, f"funds_credit_net_non_negative_{m}")

    # 7. Interest paid definition
    model.addConstr(interest_paid[m] == monthly_interest_rate * credit_used[m], f"interest_paid_calc_{m}")

    # 8. Minimum inventory requirement for the month
    model.addConstr(stock[m] >= min_inventory_month[m], f"min_inventory_{m}")

# Optimize model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of non-optimal status, Gurobi might still provide a best objective found
    # or an indication of infeasibility/unboundedness.
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
