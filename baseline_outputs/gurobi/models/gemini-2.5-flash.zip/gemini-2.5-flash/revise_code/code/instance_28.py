import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Data Loading ---
# The script will be executed from the workspace root directory.
# Data files are in 'data/filename.csv' relative to the script's execution path.
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

initial_fund = params['initial_fund']
annual_rate = params['annual_profit_rate'] / 100
inv_limit_y1 = params['investment_limit_year1']
return_rate_y1y2 = params['return_rate_year1_to_year2'] / 100
inv_limit_y2 = params['investment_limit_year2']
return_rate_y2y3 = params['return_rate_year2_to_year3'] / 100
inv_limit_y3 = params['investment_limit_year3']
profit_rate_y3 = params['profit_rate_year3'] / 100
fee_year1 = params['fee_year1']
fee_year2 = params['fee_year2']
fee_year3 = params['fee_year3']

# --- Gurobi Model Setup ---
m = gp.Model("Investment_Optimization")
m.setParam('OutputFlag', 0) # Suppress Gurobi output

# --- Decision Variables ---
# Continuous investment amounts
# a1, a2, a3: amount invested in annual 20% investment at beginning of year 1, 2, 3
a1 = m.addVar(name="a1", lb=0.0, vtype=GRB.CONTINUOUS)
a2 = m.addVar(name="a2", lb=0.0, vtype=GRB.CONTINUOUS)
a3 = m.addVar(name="a3", lb=0.0, vtype=GRB.CONTINUOUS)

# b1: 2-year investment at beginning of year 1 (returns end of year 2)
b1 = m.addVar(name="b1", lb=0.0, vtype=GRB.CONTINUOUS)

# c2: 2-year investment at beginning of year 2 (returns end of year 3)
c2 = m.addVar(name="c2", lb=0.0, vtype=GRB.CONTINUOUS)

# d3: special 1-year investment at beginning of year 3
d3 = m.addVar(name="d3", lb=0.0, vtype=GRB.CONTINUOUS)

# Binary variables for special investment usage (to trigger fixed management fees)
y1 = m.addVar(name="y1", vtype=GRB.BINARY) # 1 if b1 is used, 0 otherwise
y2 = m.addVar(name="y2", vtype=GRB.BINARY) # 1 if c2 is used, 0 otherwise
y3 = m.addVar(name="y3", vtype=GRB.BINARY) # 1 if d3 is used, 0 otherwise

# --- Linking Constraints (Binary to Continuous Investment Amounts) ---
# These constraints ensure that if a special investment option is not used (y_i = 0),
# the investment amount for that option must be zero. If it is used (y_i = 1),
# the investment amount can be up to its specified limit.
m.addConstr(b1 <= inv_limit_y1 * y1, "Link_b1_y1")
m.addConstr(c2 <= inv_limit_y2 * y2, "Link_c2_y2")
m.addConstr(d3 <= inv_limit_y3 * y3, "Link_d3_y3")

# --- Budget Constraints (incorporating fixed management fees) ---

# Funds available at the beginning of Year 1
Funds_Y1_Start = initial_fund
# Investment and fee outflow in Year 1 must not exceed available funds
m.addConstr(a1 + b1 + fee_year1 * y1 <= Funds_Y1_Start, "Year1_budget")

# Cash remaining at the end of Year 1 (uninvested cash after Year 1 decisions and fees)
Cash_Y1_End = Funds_Y1_Start - (a1 + b1 + fee_year1 * y1)

# Funds available at the beginning of Year 2
# This includes uninvested cash from Year 1 plus returns from 'a1' investment
Funds_Y2_Start = Cash_Y1_End + a1 * (1 + annual_rate)
# Investment and fee outflow in Year 2 must not exceed available funds
m.addConstr(a2 + c2 + fee_year2 * y2 <= Funds_Y2_Start, "Year2_budget")

# Cash remaining at the end of Year 2 (uninvested cash after Year 2 decisions and fees)
Cash_Y2_End = Funds_Y2_Start - (a2 + c2 + fee_year2 * y2)

# Funds available at the beginning of Year 3
# This includes uninvested cash from Year 2 plus returns from 'a2' and 'b1' investments
Funds_Y3_Start = Cash_Y2_End + a2 * (1 + annual_rate) + b1 * return_rate_y1y2
# Investment and fee outflow in Year 3 must not exceed available funds
m.addConstr(a3 + d3 + fee_year3 * y3 <= Funds_Y3_Start, "Year3_budget")

# Cash remaining at the end of Year 3 (uninvested cash after Year 3 decisions and fees)
Cash_Y3_End = Funds_Y3_Start - (a3 + d3 + fee_year3 * y3)

# --- Objective Function ---
# Maximize total net principal and interest at the end of Year 3.
# This includes any uninvested cash from Year 3, plus returns from 'a3', 'c2', and 'd3' investments.
# The fixed management fees are already accounted for as cash outflows in their respective years.
Total_End_Y3 = Cash_Y3_End + a3 * (1 + annual_rate) + c2 * return_rate_y2y3 + d3 * (1 + profit_rate_y3)

m.setObjective(Total_End_Y3, GRB.MAXIMIZE)

# --- Optimize and Print Result ---
m.optimize()

if m.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {m.objVal}")
else:
    print(f"Optimization failed with status {m.status}")
