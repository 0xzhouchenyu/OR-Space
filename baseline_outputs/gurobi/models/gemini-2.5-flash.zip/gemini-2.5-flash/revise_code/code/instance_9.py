import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions (copied from src/utils.py for self-containment) ---
def load_toy_data(filepath):
    """
    Loads toy data from a CSV file.
    Expected columns: Toy_Type, Profit_Per_Unit, Wood_Required_Per_Unit, Steel_Required_Per_Unit.
    """
    toys = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                'type': row['Toy_Type'].strip(),
                'profit': float(row['Profit_Per_Unit']),
                'wood': float(row['Wood_Required_Per_Unit']),
                'steel': float(row['Steel_Required_Per_Unit']),
            })
    return toys

def load_general_parameters(filepath):
    """
    Loads general parameters from a CSV file.
    Expected columns: Parameter_Name, Value.
    """
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params
# --- End of utility functions ---

# Determine the base directory for data access.
# The script is expected to be executed from the workspace root directory.
# Data files are in the 'data/' subdirectory relative to the root.
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, 'data')

# Load data from CSV files
toys_data = load_toy_data(os.path.join(data_dir, 'table_1.csv'))
general_params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract specific parameters from the loaded data
available_wood = general_params['available_wood']
available_steel = general_params['available_steel']
profit_premium_bonus = general_params['profit_premium_bonus']
premium_steel_factor = general_params['premium_steel_factor']
premium_shift_capacity = general_params['premium_shift_capacity']

# Big M value: A sufficiently large number used for linking binary and continuous variables.
# Inherited from the original heuristic, 1000 is a safe upper bound given resource limits.
M = 1000

# Create a new Gurobi model
m = gp.Model("HausToysRevised")
m.setParam('OutputFlag', 0) # Suppress Gurobi output

# Define decision variables:
# x[t_type]: Continuous variable, representing the total quantity of toy 't_type' produced.
x = m.addVars([t['type'] for t in toys_data], name="x", vtype=GRB.CONTINUOUS, lb=0)

# y[t_type]: Binary variable, 1 if toy 't_type' is manufactured at all, 0 otherwise.
y = m.addVars([t['type'] for t in toys_data], name="y", vtype=GRB.BINARY)

# z[t_type]: Binary variable, 1 if toy 't_type' is manufactured on the premium shift,
# 0 if manufactured on the standard shift. This variable is only relevant if y[t_type] is 1.
z = m.addVars([t['type'] for t in toys_data], name="z", vtype=GRB.BINARY)

# w[t_type]: Continuous variable, helper for linearizing the product z_t * x_t.
# 'w_t' effectively represents the quantity of toy 't_type' produced specifically on the premium shift.
w = m.addVars([t['type'] for t in toys_data], name="w", vtype=GRB.CONTINUOUS, lb=0)

# Objective function: Maximize total profit
# Profit for each unit is base_profit + (premium_bonus if on premium shift).
# This translates to: sum(base_profit * x_t + premium_bonus * w_t)
m.setObjective(
    gp.quicksum(t['profit'] * x[t['type']] + profit_premium_bonus * w[t['type']] for t in toys_data),
    GRB.MAXIMIZE
)

# --- Constraints ---

# 1. Linking constraint: If a toy type is not manufactured (y_t=0), its production quantity must be zero (x_t=0).
# x_t <= M * y_t
for t in toys_data:
    m.addConstr(x[t['type']] <= M * y[t['type']], f"Link_x_y_{t['type']}")

# 2. Linking constraint: If a toy type is not manufactured (y_t=0), it cannot be assigned to the premium shift (z_t=0).
# z_t <= y_t
for t in toys_data:
    m.addConstr(z[t['type']] <= y[t['type']], f"Link_z_y_{t['type']}")

# 3. Linearization constraints for w_t = z_t * x_t (where z_t is binary, x_t is continuous)
# These constraints ensure w_t correctly captures x_t if z_t=1, and 0 if z_t=0.
for t in toys_data:
    m.addConstr(w[t['type']] <= M * z[t['type']], f"Linearize_w_z_upper_{t['type']}")
    m.addConstr(w[t['type']] <= x[t['type']], f"Linearize_w_x_upper_{t['type']}")
    m.addConstr(w[t['type']] >= x[t['type']] - M * (1 - z[t['type']]), f"Linearize_w_lower_{t['type']}")

# 4. Resource constraint: Total wood consumed cannot exceed available wood.
# Wood consumption is based on total production (x_t).
m.addConstr(
    gp.quicksum(t['wood'] * x[t['type']] for t in toys_data) <= available_wood,
    "Wood_Constraint"
)

# 5. Resource constraint: Total steel consumed cannot exceed available steel.
# Steel consumption has a base part (steel_per_unit * x_t) and an additional part
# for premium shift production ((premium_steel_factor - 1) * steel_per_unit * w_t).
m.addConstr(
    gp.quicksum(t['steel'] * x[t['type']] + (premium_steel_factor - 1) * t['steel'] * w[t['type']] for t in toys_data) <= available_steel,
    "Steel_Constraint"
)

# 6. Premium Shift Capacity Constraint: Total volume produced on the premium shift cannot exceed 'premium_shift_capacity'.
# The sum of w_t variables represents the total units produced on the premium shift.
m.addConstr(
    gp.quicksum(w[t['type']] for t in toys_data) <= premium_shift_capacity,
    "Premium_Shift_Capacity"
)

# 7. Business Rule: Truck-train exclusion.
# If trucks are manufactured (y['truck']=1), trains cannot be (y['train']=0), and vice-versa.
# This applies to manufacturing *any shift*.
m.addConstr(y['truck'] + y['train'] <= 1, "Truck_Train_Exclusion")

# 8. Business Rule: Boat-airplane dependency.
# If boats are manufactured (y['boat']=1), airplanes must also be manufactured (y['airplane']=1).
# This applies to manufacturing *any shift*.
m.addConstr(y['boat'] <= y['airplane'], "Boat_Airplane_Dependency")

# 9. Business Rule: Boat-train limit.
# The total number of toy boats manufactured cannot exceed the total number of toy trains manufactured.
# This applies to *total production summed across shifts* (x_t).
m.addConstr(x['boat'] <= x['train'], "Boat_Train_Limit")

# Optimize the model
m.optimize()

# Print the final objective value
if m.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {m.objVal}")
else:
    print(f"Optimization did not find an optimal solution. Status: {m.status}")
