import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions for data loading ---
def load_table_1(data_dir):
    """Load and parse table_1.csv to extract equipment hours, processing times, and base profits."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    equipment_names = []
    products = []
    processing_times = {}  # (equipment, product) -> time
    effective_hours = {}   # equipment -> hours
    base_profit = {}       # product -> profit (renamed from 'profit' to 'base_profit' for clarity)
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: Equipment_Code, I, II, III, Effective_Monthly_Equipment_Hours
        products = header[1:-1]  # Extracts product names, e.g., ['I', 'II', 'III']
        
        for row in reader:
            if row[0].startswith('Unit_Product_Profit'):
                # This is the profit row
                for j, prod in enumerate(products):
                    base_profit[prod] = float(row[j + 1])
            else:
                equip = row[0]
                equipment_names.append(equip)
                effective_hours[equip] = float(row[-1])
                for j, prod in enumerate(products):
                    processing_times[(equip, prod)] = float(row[j + 1])
    
    return products, equipment_names, processing_times, effective_hours, base_profit

def load_general_parameters(data_dir, products):
    """Load and parse general_parameters.csv to extract specific parameters."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader) # Skip header
        for row in reader:
            param_name = row[0]
            value = float(row[1])
            params[param_name] = value
    
    overtime_hours_cap = params['overtime_hours_cap']
    overtime_cost_multiplier = params['overtime_cost_multiplier']
    
    min_prod = {}
    for p in products:
        # Parameter names are like 'min_prod_I', 'min_prod_II', etc.
        min_prod[p] = params[f'min_prod_{p}']
        
    return overtime_hours_cap, overtime_cost_multiplier, min_prod

# --- Main script ---
if __name__ == "__main__":
    # Determine data directory path relative to the script's location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')

    # Load data from CSV files
    products, equipment_names, processing_times, effective_hours, base_profit = load_table_1(data_dir)
    overtime_hours_cap, overtime_cost_multiplier, min_prod = load_general_parameters(data_dir, products)

    # Calculate per-unit costs for regular and overtime production
    regular_cost = {p: base_profit[p] for p in products}
    overtime_cost = {p: overtime_cost_multiplier * base_profit[p] for p in products}

    # Create a new Gurobi model
    model = gp.Model("Factory_Production_Cost_Minimization")

    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)

    # Decision variables:
    # x_reg[p]: Regular-time production quantity for product p (continuous, >= 0)
    # x_ot[p]: Overtime production quantity for product p (continuous, >= 0)
    x_reg = model.addVars(products, name="x_reg", lb=0.0)
    x_ot = model.addVars(products, name="x_ot", lb=0.0)

    # Objective: Minimize total production cost
    # Total Cost = sum(regular_cost[p] * x_reg[p] + overtime_cost[p] * x_ot[p] for p in products)
    model.setObjective(
        gp.quicksum(regular_cost[p] * x_reg[p] + overtime_cost[p] * x_ot[p] for p in products),
        GRB.MINIMIZE
    )

    # Constraints:

    # 1. Equipment Capacity Constraints:
    # Total processing time for each equipment 'e' (sum of regular and overtime production)
    # must not exceed effective_hours[e].
    for equip in equipment_names:
        model.addConstr(
            gp.quicksum(processing_times[(equip, p)] * (x_reg[p] + x_ot[p]) for p in products) <= effective_hours[equip],
            name=f"Equipment_{equip}_capacity"
        )

    # 2. Overtime Hours Cap Constraint:
    # Total equipment hours consumed by all overtime work combined cannot exceed overtime_hours_cap.
    model.addConstr(
        gp.quicksum(processing_times[(equip, p)] * x_ot[p] for equip in equipment_names for p in products) <= overtime_hours_cap,
        name="Total_Overtime_Hours_Cap"
    )

    # 3. Minimum Production Constraints:
    # Total output for each product 'p' (regular + overtime) must meet its minimum commitment level.
    for p in products:
        model.addConstr(
            x_reg[p] + x_ot[p] >= min_prod[p],
            name=f"Min_Production_{p}"
        )

    # Optimize the model
    model.optimize()

    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
        # Optional: Print decision variable values for verification
        # for p in products:
        #     print(f"Product {p} Regular: {x_reg[p].X:.6f} units")
        #     print(f"Product {p} Overtime: {x_ot[p].X:.6f} units")
    else:
        print("Optimization did not find an optimal solution.")
        # For debugging infeasible models:
        # if model.status == GRB.INFEASIBLE:
        #     model.computeIIS()
        #     model.write("infeasible.ilp")
        #     print("Model is infeasible. An IIS has been written to 'infeasible.ilp'")
