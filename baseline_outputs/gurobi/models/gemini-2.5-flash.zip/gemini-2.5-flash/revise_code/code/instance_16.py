import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions (copied from src/utils.py) ---
def load_monthly_data(filepath):
    """Load monthly purchasing and selling price data."""
    months = []
    purchasing_prices = {}
    selling_prices = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            month = int(row['Month'])
            months.append(month)
            purchasing_prices[month] = float(row['Purchasing_Price_Yuan'])
            selling_prices[month] = float(row['Selling_Price_Yuan'])
    
    return months, purchasing_prices, selling_prices

def load_general_parameters(filepath):
    """Load general parameters."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params
# --- End of Utility functions ---

# Determine the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))

# Construct the path to the data directory
data_dir = os.path.join(script_dir, 'data')

# Load data
months, purchasing_prices, selling_prices = load_monthly_data(os.path.join(data_dir, 'table_1.csv'))
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params['fixed_ordering_cost']
month2_bulk_receiving_threshold = params['month2_bulk_receiving_threshold']
month2_bulk_receiving_fee = params['month2_bulk_receiving_fee']

# Create a new Gurobi model
model = gp.Model("Maximize_Profit")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# Decision variables
# x[m] = units purchased at the beginning of month m
x = model.addVars(months, name="purchase", vtype=GRB.CONTINUOUS, lb=0)
# s[m] = units sold during month m
s = model.addVars(months, name="sell", vtype=GRB.CONTINUOUS, lb=0)
# inv[m] = inventory at end of month m
inv = model.addVars(months, name="inventory", vtype=GRB.CONTINUOUS, lb=0)

# New binary variables for revised requirements
# y[m] = 1 if purchase occurs in month m, 0 otherwise
y = model.addVars(months, name="purchase_indicator", vtype=GRB.BINARY)
# z_feb_bulk = 1 if February purchase exceeds threshold, 0 otherwise
z_feb_bulk = model.addVar(name="feb_bulk_fee_indicator", vtype=GRB.BINARY)

# Objective: maximize total profit
# Original profit = sum of (selling revenue - purchasing cost)
objective_expr = gp.quicksum(selling_prices[m] * s[m] - purchasing_prices[m] * x[m] for m in months)

# Subtract fixed ordering costs for each month a purchase is made
objective_expr -= gp.quicksum(fixed_ordering_cost * y[m] for m in months)

# Subtract February bulk receiving fee if applicable
objective_expr -= month2_bulk_receiving_fee * z_feb_bulk

model.setObjective(objective_expr, GRB.MAXIMIZE)

# Constraints
# A sufficiently large number for Big-M constraints.
# Max possible purchase in a month is warehouse_capacity (if prev_inv is 0).
M = warehouse_capacity 
epsilon = 1e-3 # Small positive number for strict inequality in threshold comparison

for m in months:
    # Inventory balance: inv[m] = inv[m-1] + x[m] - s[m]
    if m == months[0]: # First month
        prev_inv = initial_stock
    else:
        prev_inv = inv[m - 1]
    
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], f"inventory_balance_{m}")
    
    # Warehouse capacity constraint: inventory after purchasing (before selling) <= warehouse_capacity
    # At the beginning of month m, we purchase x[m], so stock becomes prev_inv + x[m]
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, f"warehouse_after_purchase_{m}")
    
    # End-of-month inventory also cannot exceed warehouse capacity
    model.addConstr(inv[m] <= warehouse_capacity, f"warehouse_end_{m}")
    
    # Can't sell more than what's available (prev_inv + x[m])
    model.addConstr(s[m] <= prev_inv + x[m], f"sell_limit_{m}")

    # Link purchase quantity x[m] to binary indicator y[m] for fixed ordering cost
    # If x[m] > 0, then y[m] must be 1. If x[m] = 0, y[m] can be 0 (preferred by objective).
    model.addConstr(x[m] <= M * y[m], f"link_purchase_indicator_{m}")

# Specific constraints for February (Month 2) bulk receiving fee
feb_month = 2
if feb_month in months: # Ensure February is in the planning horizon
    # Link x[feb_month] to z_feb_bulk
    # If x[feb_month] > month2_bulk_receiving_threshold, then z_feb_bulk must be 1.
    # If x[feb_month] <= month2_bulk_receiving_threshold, then z_feb_bulk can be 0 (preferred by objective).
    
    # Constraint 1: If z_feb_bulk is 0, x[feb_month] cannot exceed the threshold.
    # x[feb_month] <= month2_bulk_receiving_threshold + M * z_feb_bulk
    model.addConstr(x[feb_month] - M * z_feb_bulk <= month2_bulk_receiving_threshold, "feb_bulk_link_1")
    
    # Constraint 2: If x[feb_month] exceeds the threshold (by epsilon), z_feb_bulk must be 1.
    # x[feb_month] >= month2_bulk_receiving_threshold + epsilon - M * (1 - z_feb_bulk)
    model.addConstr(x[feb_month] + M * (1 - z_feb_bulk) >= month2_bulk_receiving_threshold + epsilon, "feb_bulk_link_2")

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    # If an optimal solution is not found, print 0 as a fallback number.
    print(f"FINAL_OBJ_VALUE: 0")
