import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Start of load_csv_data function (copied from utils.py to ensure self-containment) ---
def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Strip whitespace from keys and values
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data
# --- End of load_csv_data function ---

def main():
    # Determine the directory for data files relative to the script's location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')
    
    # Load data from CSV files
    products_raw = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params_raw = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Parse general parameters into a dictionary
    params = {}
    for row in params_raw:
        params[row['Parameter_Name']] = float(row['Value'])
    
    # Extract general parameters
    max_grains = params['max_grains']
    price_grains = params['price_per_lb_grains']
    max_meat = params['max_meat']
    price_meat = params['price_per_lb_meat']
    
    # Extract new parameters from the revision brief
    line_fixed_cost = params['line_fixed_cost']
    line_capacity_packs = params['line_capacity_packs']
    min_batch_packs = params['min_batch_packs']
    min_yummies = params['min_yummies']
    retailer_rebate_yummies_threshold = params['retailer_rebate_yummies_threshold']
    retailer_rebate_min_meaties = params['retailer_rebate_min_meaties']
    retailer_rebate_fixed = params['retailer_rebate_fixed']
    
    # Parse product-specific data into a dictionary
    product_data = {}
    for row in products_raw:
        name = row['Product']
        product_data[name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'variable_cost': float(row['Variable_cost_per_pack']),
            'capacity': float(row['Production_capacity']) if row['Production_capacity'].strip() else None
        }
    
    # Assign product data to specific variables for easier access
    meaties_info = product_data['Meaties']
    yummies_info = product_data['Yummies']
    
    # Calculate profit per pack for each product (excluding fixed line cost and rebate)
    profit_meaties_per_pack = meaties_info['price'] - meaties_info['variable_cost'] - \
                              (meaties_info['grains'] * price_grains + meaties_info['meat'] * price_meat)
    profit_yummies_per_pack = yummies_info['price'] - yummies_info['variable_cost'] - \
                              (yummies_info['grains'] * price_grains + yummies_info['meat'] * price_meat)
    
    # Create a new Gurobi model
    model = gp.Model("HealthyPetFoods_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables
    # x_meaties: Quantity of Meaties packs produced (continuous, non-negative)
    x_meaties = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Meaties_Packs")
    # x_yummies: Quantity of Yummies packs produced (continuous, non-negative)
    x_yummies = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Yummies_Packs")
    
    # Binary variables for new business rules
    # y_line_active: 1 if the co-packing line is active, 0 otherwise
    y_line_active = model.addVar(vtype=GRB.BINARY, name="Line_Active")
    # y_rebate_yummies_met: 1 if Yummies production meets its rebate threshold, 0 otherwise
    y_rebate_yummies_met = model.addVar(vtype=GRB.BINARY, name="Rebate_Yummies_Met")
    # y_rebate_meaties_met: 1 if Meaties production meets its rebate threshold, 0 otherwise
    y_rebate_meaties_met = model.addVar(vtype=GRB.BINARY, name="Rebate_Meaties_Met")
    # y_rebate_earned: 1 if both rebate conditions are met and the fixed allowance is earned, 0 otherwise
    y_rebate_earned = model.addVar(vtype=GRB.BINARY, name="Rebate_Earned")
    
    # Objective function: Maximize total profit
    # Total Profit = (Profit from Meaties) + (Profit from Yummies) - (Fixed line cost if active) + (Retailer rebate if earned)
    model.setObjective(
        profit_meaties_per_pack * x_meaties + 
        profit_yummies_per_pack * x_yummies - 
        line_fixed_cost * y_line_active + 
        retailer_rebate_fixed * y_rebate_earned, 
        GRB.MAXIMIZE
    )
    
    # Constraints
    
    # 1. Raw material availability (Original constraints)
    model.addConstr(meaties_info['grains'] * x_meaties + yummies_info['grains'] * x_yummies <= max_grains, "Grains_Constraint")
    model.addConstr(meaties_info['meat'] * x_meaties + yummies_info['meat'] * x_yummies <= max_meat, "Meat_Constraint")
    
    # 2. Production capacity for Meaties (Original constraint)
    if meaties_info['capacity'] is not None:
        model.addConstr(x_meaties <= meaties_info['capacity'], "Meaties_Capacity")
    
    # 3. Co-packing line constraints (New rules)
    # If the line is active (y_line_active=1), total production is capped by line_capacity_packs.
    # If the line is inactive (y_line_active=0), total production must be 0.
    model.addConstr(x_meaties + x_yummies <= line_capacity_packs * y_line_active, "Line_Capacity_Constraint")
    
    # If the line is active, total production must meet min_batch_packs.
    # If the line is inactive, this constraint becomes 0 >= 0, which is always true.
    model.addConstr(x_meaties + x_yummies >= min_batch_packs * y_line_active, "Min_Batch_Constraint")
    
    # If the line is active, Yummies production must meet min_yummies.
    # If the line is inactive, this constraint becomes 0 >= 0, which is always true.
    model.addConstr(x_yummies >= min_yummies * y_line_active, "Min_Yummies_Constraint")
    
    # 4. Retailer rebate constraints (New rules)
    # M is a large number, representing an upper bound on production quantities.
    # A safe upper bound for individual product quantities, considering line capacity and Meaties capacity, is 120000.
    M = 120000 
    epsilon = 0.001 # Small value to handle strict inequalities for thresholds
    
    # Link y_rebate_yummies_met to x_yummies: y_rebate_yummies_met = 1 if x_yummies >= retailer_rebate_yummies_threshold
    model.addConstr(x_yummies >= retailer_rebate_yummies_threshold - M * (1 - y_rebate_yummies_met), "Rebate_Yummies_Link1")
    model.addConstr(x_yummies <= retailer_rebate_yummies_threshold - epsilon + M * y_rebate_yummies_met, "Rebate_Yummies_Link2")
    
    # Link y_rebate_meaties_met to x_meaties: y_rebate_meaties_met = 1 if x_meaties >= retailer_rebate_min_meaties
    model.addConstr(x_meaties >= retailer_rebate_min_meaties - M * (1 - y_rebate_meaties_met), "Rebate_Meaties_Link1")
    model.addConstr(x_meaties <= retailer_rebate_min_meaties - epsilon + M * y_rebate_meaties_met, "Rebate_Meaties_Link2")
    
    # Link y_rebate_earned to both y_rebate_yummies_met AND y_rebate_meaties_met
    # y_rebate_earned is 1 only if both y_rebate_yummies_met and y_rebate_meaties_met are 1.
    model.addConstr(y_rebate_earned <= y_rebate_yummies_met, "Rebate_Earned_And_Yummies")
    model.addConstr(y_rebate_earned <= y_rebate_meaties_met, "Rebate_Earned_And_Meaties")
    model.addConstr(y_rebate_earned >= y_rebate_yummies_met + y_rebate_meaties_met - 1, "Rebate_Earned_If_Both")
    
    # Optimize the model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Handle cases where an optimal solution is not found
        print("Optimization did not find an optimal solution.")
        print(f"Gurobi Status: {model.status} ({GRB.Status.getName(model.status)})")

if __name__ == "__main__":
    main()
