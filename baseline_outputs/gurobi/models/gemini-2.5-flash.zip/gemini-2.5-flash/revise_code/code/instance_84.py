import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, '..', 'data')

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Store all values as float initially, then cast to int where appropriate for counts
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    
    # New parameters from the revision
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = params['min_manager_experience']
    manager_bonus_per_candidate = params['manager_bonus_per_candidate']

    # Create optimization model
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Decision variables:
    # x_manager[c_name]: 1 if candidate c_name is hired as a manager, 0 otherwise
    # x_specialist[c_name]: 1 if candidate c_name is hired as a specialist, 0 otherwise
    x_manager = model.addVars([c['name'] for c in candidates], vtype=GRB.BINARY, name="x_manager")
    x_specialist = model.addVars([c['name'] for c in candidates], vtype=GRB.BINARY, name="x_specialist")

    # Helper expressions for common sums
    # Total base salary of all hired candidates
    total_base_salary_expr = gp.quicksum(c['salary'] * (x_manager[c['name']] + x_specialist[c['name']]) for c in candidates)
    # Total number of hired employees (managers + specialists)
    total_hired_expr = gp.quicksum(x_manager[c['name']] + x_specialist[c['name']] for c in candidates)
    # Total number of hired managers
    total_managers_expr = gp.quicksum(x_manager[c['name']] for c in candidates)

    # Objective: minimize total cost (base salary + manager bonuses)
    # The budget_limit applies only to base salaries, but the objective is total cost.
    total_cost = total_base_salary_expr + gp.quicksum(manager_bonus_per_candidate * x_manager[c['name']] for c in candidates)
    model.setObjective(total_cost, GRB.MINIMIZE)

    # Constraint 1 (NEW): Each hired candidate serves in at most one role (or not hired)
    for c in candidates:
        model.addConstr(x_manager[c['name']] + x_specialist[c['name']] <= 1, name=f"one_role_per_candidate_{c['name']}")

    # Constraint 2 (Original): Maximum number of new employees
    model.addConstr(total_hired_expr <= max_employees, name="max_employees_constraint")

    # Constraint 3 (Original, Revised interpretation): Total payment (base salaries only) does not exceed budget
    # The budget_limit is explicitly stated to be for "base salaries (excluding manager bonus)".
    model.addConstr(total_base_salary_expr <= budget_limit, name="budget_constraint")

    # Constraint 4 (Original): At least one candidate with a Master's or Doctoral degree
    advanced_candidates_expr = gp.quicksum(x_manager[c['name']] + x_specialist[c['name']] 
                                           for c in candidates 
                                           if c['qualification'] in ["Master's degree", "Doctoral degree"])
    model.addConstr(advanced_candidates_expr >= min_advanced, name="min_advanced_degree_constraint")

    # Constraint 5 (Original): Minimum total work experience of selected candidates
    total_experience_hired_expr = gp.quicksum(c['experience'] * (x_manager[c['name']] + x_specialist[c['name']]) for c in candidates)
    model.addConstr(total_experience_hired_expr >= min_experience, name="min_work_experience_constraint")

    # Constraint 6 (Original): At most one candidate from pair A and E
    model.addConstr((x_manager['A'] + x_specialist['A']) + (x_manager['E'] + x_specialist['E']) <= max_equivalent, name="max_equivalent_AE_constraint")

    # Constraint 7 (Original): Minimum number of new employees
    model.addConstr(total_hired_expr >= min_employees, name="min_employees_constraint")

    # Constraint 8 (NEW): Minimum number of managers
    model.addConstr(total_managers_expr >= min_managers, name="min_managers_constraint")

    # Constraint 9 (NEW): Maximum number of managers
    model.addConstr(total_managers_expr <= max_managers, name="max_managers_constraint")

    # Constraint 10 (NEW): Minimum total work experience for managers
    # Interpreted as the sum of experience for all hired managers, consistent with 'min_work_experience' for all hires.
    total_manager_experience_expr = gp.quicksum(c['experience'] * x_manager[c['name']] for c in candidates)
    model.addConstr(total_manager_experience_expr >= min_manager_experience, name="min_manager_experience_constraint")

    # Solve the model
    model.optimize()

    # Output the objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INFEASIBLE:
        print("No feasible solution found.")
    else:
        print(f"Optimization ended with status {model.status}")

if __name__ == '__main__':
    main()
