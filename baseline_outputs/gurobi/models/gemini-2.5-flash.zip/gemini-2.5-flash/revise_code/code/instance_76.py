import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {} # NEW parameter: quarter-specific purchase caps
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip()) # Read new purchase cap
    
    # Read general_parameters.csv
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_storage = float(params['max_storage_capacity'])  # 200000 m³
    storage_cost_a = float(params['storage_cost_a'])      # 70 yuan/m³
    storage_cost_b = float(params['storage_cost_b'])      # 100 yuan/m³/quarter
    
    # NEW parameters from general_parameters.csv
    safety_inventory_level = float(params['safety_inventory_level_10k_m3']) # Target minimum safety inventory at end of autumn (10k m³)
    terminal_inventory_value = float(params['terminal_inventory_value_per_10k_m3']) # Estimated end-of-autumn carrying value (10k yuan/10k m³)
    over_purchase_penalty = float(params['over_purchase_penalty_cost_per_10k_m3']) # Penalty cost for excess inventory (10k yuan/10k m³)
    
    # Convert storage capacity to 万m³ (10k m³) for consistency with other 10k units
    max_storage_wm3 = max_storage / 10000.0  # 20 万m³
    
    # Convert storage costs to 万元/万m³ (10k yuan / 10k m³)
    # 70 yuan/m³ = 70 * (10000 yuan / 10000 m³) = 70 万元/万m³
    # 100 yuan/m³/quarter = 100 * (10000 yuan / 10000 m³) / quarter = 100 万元/万m³/quarter
    storage_cost_a_w = storage_cost_a * 10000.0 / 10000.0  # = 70 万元/万m³
    storage_cost_b_w = storage_cost_b * 10000.0 / 10000.0  # = 100 万元/万m³/quarter
    
    # Quarter indices: 0=Winter, 1=Spring, 2=Summer, 3=Autumn
    n = len(quarters) # n = 4
    
    # Create a new Gurobi model
    model = gp.Model("Timber_Profit_Maximization_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables:
    # x[i, j] = amount purchased in quarter i and sold in quarter j (万m³)
    # where i, j are quarter indices, j >= i and j <= 3 (must sell by autumn)
    x = model.addVars(n, n, name="x", vtype=GRB.CONTINUOUS, lb=0)
    
    # y[i] = amount purchased in quarter i and carried over to the next year (万m³)
    # This timber forms part of the end-of-autumn inventory.
    y = model.addVars(n, name="y", vtype=GRB.CONTINUOUS, lb=0)
    
    # end_of_autumn_inventory = total inventory remaining at the end of autumn (万m³)
    end_of_autumn_inventory = model.addVar(name="end_of_autumn_inventory", vtype=GRB.CONTINUOUS, lb=0)
    
    # excess_inventory = amount of end-of-autumn inventory above the safety level (万m³)
    excess_inventory = model.addVar(name="excess_inventory", vtype=GRB.CONTINUOUS, lb=0)
    
    # Objective: maximize profit
    # Profit = Total Revenue - Total Purchase Cost - Total Storage Cost - Total Over-Purchase Penalty + Terminal Inventory Value
    
    # 1. Total Revenue from sales within the year
    revenue_terms = gp.quicksum(sale_price[quarters[j]] * x[i, j] for i in range(n) for j in range(i, n))
    
    # 2. Total Purchase Cost
    # Total purchased in quarter i is sum of x[i,j] (sold within year) + y[i] (carried over)
    purchase_cost_terms = gp.quicksum(
        purchase_price[quarters[i]] * (gp.quicksum(x[i, j] for j in range(i, n)) + y[i])
        for i in range(n)
    )
    
    # 3. Total Storage Cost
    # For x[i,j]: stored for u = j-i quarters. Cost = (storage_cost_a_w + storage_cost_b_w * u) * x[i,j] if u > 0
    storage_cost_x_terms = gp.quicksum(
        (storage_cost_a_w + storage_cost_b_w * (j - i)) * x[i, j]
        for i in range(n) for j in range(i + 1, n) # Only for j > i (i.e., stored for at least 1 quarter)
    )
    # For y[i]: purchased in quarter i and stored until end of autumn (quarter n-1).
    # Stored for u = (n-1)-i quarters. Cost = (storage_cost_a_w + storage_cost_b_w * u) * y[i] if u > 0
    storage_cost_y_terms = gp.quicksum(
        (storage_cost_a_w + storage_cost_b_w * (n - 1 - i)) * y[i]
        for i in range(n) if (n - 1 - i) > 0 # Only if stored for more than 0 quarters
    )
    
    # 4. Terminal inventory value (credit for all end-of-autumn inventory)
    terminal_value_term = terminal_inventory_value * end_of_autumn_inventory
    
    # 5. Over-purchase penalty (cost for inventory above safety level)
    over_purchase_penalty_term = over_purchase_penalty * excess_inventory
    
    model.setObjective(
        revenue_terms
        - purchase_cost_terms
        - storage_cost_x_terms
        - storage_cost_y_terms
        + terminal_value_term
        - over_purchase_penalty_term,
        GRB.MAXIMIZE
    )
    
    # Constraints:
    
    # 1. Sales constraints: total sold in quarter j <= max_sales[j]
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(j + 1)) <= max_sales[quarters[j]],
                        name=f"Sales_Limit_{quarters[j]}")
    
    # 2. Storage constraints: at end of each quarter t (before Autumn), stored timber <= max_storage_wm3
    # Stored timber after quarter t includes:
    #   - Timber purchased in i <= t and sold in j > t (later in the year)
    #   - Timber purchased in i <= t and carried over to the next year (y[i])
    for t in range(n - 1): # For Winter (t=0), Spring (t=1), Summer (t=2)
        stored_for_later_sale = gp.quicksum(x[i, j] for i in range(t + 1) for j in range(t + 1, n))
        stored_for_next_year = gp.quicksum(y[i] for i in range(t + 1))
        model.addConstr(stored_for_later_sale + stored_for_next_year <= max_storage_wm3,
                        name=f"Storage_Limit_After_{quarters[t]}")
    
    # 3. Purchase constraints (NEW): total purchased in quarter i <= max_purchase[i]
    for i in range(n):
        total_purchased_in_q = gp.quicksum(x[i, j] for j in range(i, n)) + y[i]
        model.addConstr(total_purchased_in_q <= max_purchase[quarters[i]],
                        name=f"Purchase_Limit_{quarters[i]}")
    
    # 4. End-of-autumn inventory definition (NEW)
    model.addConstr(end_of_autumn_inventory == gp.quicksum(y[i] for i in range(n)),
                    name="EndOfAutumnInventory_Def")
    
    # 5. Safety inventory level (NEW): end_of_autumn_inventory must be at least safety_inventory_level
    model.addConstr(end_of_autumn_inventory >= safety_inventory_level,
                    name="SafetyInventory_Min")
    
    # 6. Excess inventory definition (NEW): excess_inventory = max(0, end_of_autumn_inventory - safety_inventory_level)
    model.addConstr(excess_inventory >= end_of_autumn_inventory - safety_inventory_level,
                    name="ExcessInventory_Def1")
    # The lower bound of 0 for excess_inventory variable already handles the max(0, ...) part.
    
    # Optimize the model
    model.optimize()
    
    # Print the final objective value as required
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")
    else:
        print("FINAL_OBJ_VALUE: No optimal solution found.")

if __name__ == "__main__":
    main()
