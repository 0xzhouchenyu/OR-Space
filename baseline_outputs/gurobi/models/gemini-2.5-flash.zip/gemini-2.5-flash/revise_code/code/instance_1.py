import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions (adapted from src/utils.py for execution from root) ---
def load_csv(filename):
    # Assuming the script is executed from the revised workspace root directory
    # and data files are in the 'data' subdirectory.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, 'data', filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            rows.append(row)
    return rows

def load_parameters():
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name'].strip()
        val = row['Value'].strip()
        try:
            if '.' in val:
                params[name] = float(val)
            else:
                params[name] = int(val)
        except ValueError:
            params[name] = val
    return params

def load_demand():
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        week = int(row['Week'].strip())
        demand[week] = {
            'I': int(row['I'].strip()),
            'II': int(row['II'].strip())
        }
    return demand

# --- Main optimization script ---
if __name__ == "__main__":
    # Load parameters and demand data
    params = load_parameters()
    demand = load_demand()

    # Define planning horizon
    T = 8  # weeks
    weeks = range(1, T + 1)

    # Extract parameters
    S0 = params['skilled_worker_count']
    rate_I = params['food_I_production_rate']
    rate_II = params['food_II_production_rate']
    normal_hours = params['worker_weekly_hours']
    overtime_hours = params['skilled_worker_overtime_hours']
    train_cap = params['training_capacity']
    train_period = params['training_period']
    wage_skilled = params['skilled_worker_weekly_wage']
    wage_trainee_during = params['trainee_weekly_wage_during_training']
    wage_trainee_after = params['trainee_weekly_wage_after_training']
    wage_overtime = params['skilled_worker_overtime_wage']
    comp_I = params['compensation_fee_food_I']
    comp_II = params['compensation_fee_food_II']
    new_worker_goal = params['new_worker_training_goal']

    # Initialize Gurobi model
    m = gp.Model("factory_training")
    m.setParam('OutputFlag', 0)  # Suppress Gurobi output

    # --- Decision Variables ---
    # Training can start in weeks 1 to T - train_period + 1 (e.g., 1 to 7 for T=8, train_period=2)
    training_start_weeks = range(1, T - train_period + 2)

    # Number of skilled workers assigned to training starting in week t
    n_train = m.addVars(training_start_weeks, vtype=GRB.INTEGER, name="n_train")
    # Number of skilled workers working overtime in week t
    n_overtime = m.addVars(weeks, vtype=GRB.INTEGER, name="n_overtime")
    # Number of skilled workers doing normal production in week t
    n_skilled_normal = m.addVars(weeks, vtype=GRB.INTEGER, name="n_skilled_normal")

    # Hours spent on Food I/II by different worker categories
    h_I_s = m.addVars(weeks, vtype=GRB.CONTINUOUS, name="hIs")  # Skilled normal on Food I
    h_II_s = m.addVars(weeks, vtype=GRB.CONTINUOUS, name="hIIs") # Skilled normal on Food II
    h_I_ot = m.addVars(weeks, vtype=GRB.CONTINUOUS, name="hIot") # Skilled overtime on Food I
    h_II_ot = m.addVars(weeks, vtype=GRB.CONTINUOUS, name="hIIot")# Skilled overtime on Food II
    h_I_g = m.addVars(weeks, vtype=GRB.CONTINUOUS, name="hIg")  # Graduated trainees on Food I
    h_II_g = m.addVars(weeks, vtype=GRB.CONTINUOUS, name="hIIg") # Graduated trainees on Food II

    # Backlog (unmet demand) for Food I/II at the end of week t
    backlog_I = m.addVars(weeks, vtype=GRB.CONTINUOUS, name="bI")
    backlog_II = m.addVars(weeks, vtype=GRB.CONTINUOUS, name="bII")

    # Binary variables for mutual exclusion (1 if product is produced in week t, 0 otherwise)
    x_I = m.addVars(weeks, vtype=GRB.BINARY, name="xI")
    x_II = m.addVars(weeks, vtype=GRB.BINARY, name="xII")

    # --- Objective Function: Minimize Total Cost ---
    total_cost = gp.LinExpr()

    for t in weeks:
        # Helper expressions for current week's worker states (for objective and constraints)
        # Number of skilled workers busy training in week t
        current_trainers_busy = sum(n_train[s] for s in training_start_weeks if s <= t <= s + train_period - 1)
        # Number of trainees currently undergoing training in week t
        current_trainees_in_training = sum(n_train[s] * train_cap for s in training_start_weeks if s <= t <= s + train_period - 1)
        # Number of graduated trainees available for production in week t
        current_graduates_available = sum(n_train[s] * train_cap for s in training_start_weeks if s + train_period <= t)

        # 1. Skilled worker wages: All S0 skilled workers are paid wage_skilled.
        #    Overtime workers receive wage_overtime instead of wage_skilled, so add the premium.
        total_cost += S0 * wage_skilled + n_overtime[t] * (wage_overtime - wage_skilled)

        # 2. Trainee wages during training
        total_cost += current_trainees_in_training * wage_trainee_during

        # 3. Graduated trainee wages
        total_cost += current_graduates_available * wage_trainee_after

        # 4. Compensation fees for delayed deliveries
        total_cost += backlog_I[t] * comp_I + backlog_II[t] * comp_II

    m.setObjective(total_cost, GRB.MINIMIZE)

    # --- Constraints ---
    for t in weeks:
        # Re-calculate helper expressions for constraints
        current_trainers_busy = sum(n_train[s] for s in training_start_weeks if s <= t <= s + train_period - 1)
        current_graduates_available = sum(n_train[s] * train_cap for s in training_start_weeks if s + train_period <= t)

        # Skilled worker allocation constraint: Total skilled workers (normal production + overtime + trainers)
        # cannot exceed the initial number of skilled workers (S0).
        m.addConstr(n_skilled_normal[t] + n_overtime[t] + current_trainers_busy <= S0, f"skilled_worker_cap_{t}")
        m.addConstr(n_skilled_normal[t] >= 0, f"n_skilled_normal_nonneg_{t}")
        m.addConstr(n_overtime[t] >= 0, f"n_overtime_nonneg_{t}")
        
        # Hours constraints for skilled normal workers
        m.addConstr(h_I_s[t] + h_II_s[t] <= n_skilled_normal[t] * normal_hours, f"skilled_normal_hours_cap_{t}")
        m.addConstr(h_I_s[t] >= 0, f"hIs_nonneg_{t}")
        m.addConstr(h_II_s[t] >= 0, f"hIIs_nonneg_{t}")

        # Hours constraints for skilled overtime workers
        m.addConstr(h_I_ot[t] + h_II_ot[t] <= n_overtime[t] * overtime_hours, f"skilled_ot_hours_cap_{t}")
        m.addConstr(h_I_ot[t] >= 0, f"hIot_nonneg_{t}")
        m.addConstr(h_II_ot[t] >= 0, f"hIIot_nonneg_{t}")

        # Hours constraints for graduated trainees
        m.addConstr(h_I_g[t] + h_II_g[t] <= current_graduates_available * normal_hours, f"grad_hours_cap_{t}")
        m.addConstr(h_I_g[t] >= 0, f"hIg_nonneg_{t}")
        m.addConstr(h_II_g[t] >= 0, f"hIIg_nonneg_{t}")

        # Production calculation for the current week
        prod_I_t = (h_I_s[t] + h_I_ot[t] + h_I_g[t]) * rate_I
        prod_II_t = (h_II_s[t] + h_II_ot[t] + h_II_g[t]) * rate_II

        # Backlog balance constraints
        prev_bI = backlog_I[t-1] if t > 1 else 0
        prev_bII = backlog_II[t-1] if t > 1 else 0
        
        m.addConstr(backlog_I[t] >= prev_bI + demand[t]['I'] - prod_I_t, f"backlog_I_balance_{t}")
        m.addConstr(backlog_II[t] >= prev_bII + demand[t]['II'] - prod_II_t, f"backlog_II_balance_{t}")
        m.addConstr(backlog_I[t] >= 0, f"backlog_I_nonneg_{t}")
        m.addConstr(backlog_II[t] >= 0, f"backlog_II_nonneg_{t}")

        # Mutual Exclusion Constraints (new requirement)
        # At most one type of food can be produced in a given week
        m.addConstr(x_I[t] + x_II[t] <= 1, f"mutual_exclusion_{t}")

        # Big M formulation to link binary choice to production hours
        # M is an upper bound on the total possible production hours for one food type in a week.
        # Max possible hours = (S0 * overtime_hours) + (S0 * train_cap * normal_hours)
        # = (50 * 60) + (50 * 3 * 40) = 3000 + 6000 = 9000. Using 12000 for safety.
        M = 12000 

        # If x_I[t] is 1, then no hours can be spent on Food II
        m.addConstr(h_II_s[t] <= M * (1 - x_I[t]), f"hIIs_if_xI_{t}")
        m.addConstr(h_II_ot[t] <= M * (1 - x_I[t]), f"hIIot_if_xI_{t}")
        m.addConstr(h_II_g[t] <= M * (1 - x_I[t]), f"hIIg_if_xI_{t}")

        # If x_II[t] is 1, then no hours can be spent on Food I
        m.addConstr(h_I_s[t] <= M * (1 - x_II[t]), f"hIs_if_xII_{t}")
        m.addConstr(h_I_ot[t] <= M * (1 - x_II[t]), f"hIot_if_xII_{t}")
        m.addConstr(h_I_g[t] <= M * (1 - x_II[t]), f"hIg_if_xII_{t}")

    # New Worker Training Goal: at least 'new_worker_goal' workers trained by end of week 8
    # Trainees starting in week 's' finish by end of week 's+1'.
    # So, training starting in week 1 through week 7 (T-1) counts towards the goal.
    total_trained_workers = sum(n_train[s] * train_cap for s in training_start_weeks)
    m.addConstr(total_trained_workers >= new_worker_goal, "training_goal")

    # Optimize the model
    m.optimize()

    # Print the optimal objective value
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print("Optimization did not find an optimal solution.")
