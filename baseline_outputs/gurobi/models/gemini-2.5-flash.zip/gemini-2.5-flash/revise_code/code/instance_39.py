import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility function (from utils.py) ---
# This function is included directly to make the script self-contained as requested.
def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- Main script ---
# Determine the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))
# Construct the path to the data directory, assuming it's in 'data/' relative to the workspace root
data_dir = os.path.join(script_dir, '..', 'data')

# Load data from general_parameters.csv
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters for owned transportation methods
motorcycle_pollution = params['motorcycle_pollution']
small_truck_pollution = params['small_truck_pollution']
large_truck_pollution = params['large_truck_pollution']
max_motorcycle_trips = int(params['max_motorcycle_trips'])
motorcycle_capacity = params['motorcycle_capacity']
small_truck_capacity = params['small_truck_capacity']
large_truck_capacity = params['large_truck_capacity']

# Extract general constraints parameters
max_total_trips = int(params['max_total_trips'])

# Extract demand parameters for different periods
demand_peak_units = params['demand_peak_units']
demand_offpeak_units = params['demand_offpeak_units']

# Extract leasing parameters
leasing_capacity = params['leasing_capacity']
leasing_pollution_per_unit = params['leasing_pollution_per_unit']
leasing_fixed_pollution = params['leasing_fixed_pollution']
max_leasing_fraction_peak = params['max_leasing_fraction_peak']
bigM_leasing = params['bigM_leasing']
epsilon = params['epsilon']

# Define sets for methods and periods
methods = ['motorcycle', 'small_truck', 'large_truck']
periods = ['peak', 'offpeak']

# Create parameter dictionaries for easier access in the model
pollution = {
    'motorcycle': motorcycle_pollution,
    'small_truck': small_truck_pollution,
    'large_truck': large_truck_pollution
}

capacity = {
    'motorcycle': motorcycle_capacity,
    'small_truck': small_truck_capacity,
    'large_truck': large_truck_capacity
}

demand = {
    'peak': demand_peak_units,
    'offpeak': demand_offpeak_units
}

# Initialize the Gurobi model
model = gp.Model("Transport_Optimization_Revised")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# --- Decision Variables ---
# x[m, p]: Number of trips for method 'm' in period 'p'
# Integer, non-negative, as trips are discrete
x = model.addVars(methods, periods, vtype=GRB.INTEGER, name="trips", lb=0)

# y[m]: Binary variable, 1 if method 'm' is chosen for the day, 0 otherwise
y = model.addVars(methods, vtype=GRB.BINARY, name="method_chosen")

# lease_units[p]: Units transported by leasing in period 'p'
# Continuous, non-negative, as units can be fractional
lease_units = model.addVars(periods, vtype=GRB.CONTINUOUS, name="lease_units", lb=0)

# lease_active: Binary variable, 1 if leasing is used at all (total leased units > 0), 0 otherwise
lease_active = model.addVar(vtype=GRB.BINARY, name="lease_active")

# --- Objective Function ---
# Minimize total pollution: sum of owned method pollution + leasing variable pollution + leasing fixed pollution
obj_expr = gp.quicksum(pollution[m] * x[m, p] for m in methods for p in periods) \
           + gp.quicksum(leasing_pollution_per_unit * lease_units[p] for p in periods) \
           + leasing_fixed_pollution * lease_active
model.setObjective(obj_expr, GRB.MINIMIZE)

# --- Constraints ---

# 1. Choose exactly two owned transportation methods globally for the day
model.addConstr(gp.quicksum(y[m] for m in methods) == 2, "Choose_Two_Methods")

# 2. Link owned trips (x[m, p]) to chosen methods (y[m])
# If a method 'm' is not chosen (y[m]=0), then no trips can be made using it (x[m,p]=0).
# M_trips is a sufficiently large upper bound for x[m,p]. max_total_trips (20) is a safe choice.
M_trips = max_total_trips
for m in methods:
    for p in periods:
        model.addConstr(x[m, p] <= M_trips * y[m], f"Link_Trips_MethodChosen_{m}_{p}")

# 3. Demand satisfaction for each period
# The total capacity provided by owned methods and leasing must meet the demand for each period.
for p in periods:
    model.addConstr(gp.quicksum(capacity[m] * x[m, p] for m in methods) + lease_units[p] >= demand[p], f"Demand_Satisfaction_{p}")

# 4. Maximum total trips allowed across both periods
model.addConstr(gp.quicksum(x[m, p] for m in methods for p in periods) <= max_total_trips, "Max_Total_Trips")

# 5. Maximum motorcycle trips limit (total over the day, across both periods)
model.addConstr(gp.quicksum(x['motorcycle', p] for p in periods) <= max_motorcycle_trips, "Max_Motorcycle_Trips")

# 6. Maximum total leasing capacity over the day
model.addConstr(gp.quicksum(lease_units[p] for p in periods) <= leasing_capacity, "Max_Leasing_Capacity")

# 7. Maximum fraction of peak demand that can be satisfied by leasing
model.addConstr(lease_units['peak'] <= max_leasing_fraction_peak * demand['peak'], "Max_Leasing_Fraction_Peak")

# 8. Big-M formulation to link lease_active to total leased units
# If lease_active is 0, total leased units must be 0.
model.addConstr(gp.quicksum(lease_units[p] for p in periods) <= bigM_leasing * lease_active, "Leasing_Activation_Upper")
# If lease_active is 1, total leased units must be at least epsilon (to incur fixed cost).
model.addConstr(gp.quicksum(lease_units[p] for p in periods) >= epsilon * lease_active, "Leasing_Activation_Lower")

# Optimize the model
model.optimize()

# Print the final objective value as required
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # Handle cases where an optimal solution is not found
    print("Optimization problem did not find an optimal solution.")
    print(f"Status: {model.status}")
