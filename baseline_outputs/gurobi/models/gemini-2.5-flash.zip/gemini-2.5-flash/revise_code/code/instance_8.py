import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # --- 1. Data Loading ---
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

    # Load general_parameters.csv
    general_params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row['Parameter_Name']] = float(row['Value'])

    shared_temp_handoff_cost = general_params['shared_temp_handoff_cost']
    worker_II_V_pair_fee = general_params['worker_II_V_pair_fee']

    # Load table_1.csv
    filepath = os.path.join(data_dir, 'table_1.csv')

    workers = []
    tasks = []
    cost = {}  # Task-specific time cost
    fixed_cost = {}  # Fixed cost for selecting a worker

    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # Tasks are columns A, B, C, D. Exclude 'Worker' and 'Fixed_Cost'.
        tasks = header[1:-1]

        for row in reader:
            worker = row[0].strip()
            workers.append(worker)
            for j, task in enumerate(tasks):
                cost[(worker, task)] = int(row[j + 1])
            fixed_cost[worker] = int(row[-1])  # Last column is Fixed_Cost

    # --- 2. Create Gurobi Model ---
    model = gp.Model("Assignment")
    model.setParam('OutputFlag', 0)  # Suppress Gurobi output

    # --- 3. Decision Variables ---
    # x[w,t]: Binary, 1 if worker w is assigned to task t
    x = model.addVars(workers, tasks, vtype=GRB.BINARY, name="x")

    # y[w]: Binary, 1 if worker w is selected (assigned to any task)
    y = model.addVars(workers, vtype=GRB.BINARY, name="y")

    # z_III_V: Binary, 1 if both Worker III and Worker V are selected
    z_III_V = model.addVar(vtype=GRB.BINARY, name="z_III_V")

    # z_II_V: Binary, 1 if both Worker II and Worker V are selected
    z_II_V = model.addVar(vtype=GRB.BINARY, name="z_II_V")

    # --- 4. Objective Function ---
    # Minimize total cost = task_time_cost + worker_fixed_cost + pairing_fees
    obj_expr = gp.quicksum(cost[(w, t)] * x[w, t] for w in workers for t in tasks) \
               + gp.quicksum(fixed_cost[w] * y[w] for w in workers) \
               + shared_temp_handoff_cost * z_III_V \
               + worker_II_V_pair_fee * z_II_V

    model.setObjective(obj_expr, GRB.MINIMIZE)

    # --- 5. Constraints ---

    # C1: Each task must be assigned to exactly one worker
    for t in tasks:
        model.addConstr(gp.quicksum(x[w, t] for w in workers) == 1, name=f"Task_Assignment_{t}")

    # C2: Each worker can be assigned to at most one task
    for w in workers:
        model.addConstr(gp.quicksum(x[w, t] for t in tasks) <= 1, name=f"Worker_Max_One_Task_{w}")

    # C3: Link y[w] to x[w,t] (y[w] is 1 if worker w is assigned to any task)
    for w in workers:
        model.addConstr(y[w] == gp.quicksum(x[w, t] for t in tasks), name=f"Link_y_x_{w}")

    # C4: Exactly 4 workers must be selected (since there are 4 tasks)
    model.addConstr(gp.quicksum(y[w] for w in workers) == 4, name="Total_Workers_Selected")

    # C5: Rule 1 - Link z_III_V to y['III'] and y['V']
    # z_III_V = 1 if y['III'] == 1 and y['V'] == 1
    model.addConstr(z_III_V <= y['III'], name="Z_III_V_Upper1")
    model.addConstr(z_III_V <= y['V'], name="Z_III_V_Upper2")
    model.addConstr(z_III_V >= y['III'] + y['V'] - 1, name="Z_III_V_Lower")

    # C6: Rule 2 - Link z_II_V to y['II'] and y['V']
    # z_II_V = 1 if y['II'] == 1 and y['V'] == 1
    model.addConstr(z_II_V <= y['II'], name="Z_II_V_Upper1")
    model.addConstr(z_II_V <= y['V'], name="Z_II_V_Upper2")
    model.addConstr(z_II_V >= y['II'] + y['V'] - 1, name="Z_II_V_Lower")

    # --- 6. Solve the model ---
    model.optimize()

    # --- 7. Print Solution ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"Optimization did not find an optimal solution. Status: {model.status}")

if __name__ == "__main__":
    main()
