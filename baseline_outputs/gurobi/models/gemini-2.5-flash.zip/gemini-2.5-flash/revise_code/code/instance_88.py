import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility function (copied from src/utils.py) ---
def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- Load Data ---
# Determine the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, '..', 'data')

# Load general parameters
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
m1_liquid_time = params['machine_1_time_per_liquid_lot']
m2_liquid_time = params['machine_2_time_per_liquid_lot']
m1_solid_time = params['machine_1_time_per_solid_lot']
m2_solid_time = params['machine_2_time_per_solid_lot']

init_liquid_inv = params['initial_liquid_inventory']
init_solid_inv = params['initial_solid_inventory']

m1_avail_base_hours = params['machine_1_available_time']
m2_avail_base_hours = params['machine_2_available_time']

demand_liquid = params['forecast_liquid_demand']
demand_solid = params['forecast_solid_demand']

extended_extra_minutes = params['extended_extra_minutes']
labor_hours_per_machine_extended = params['labor_hours_per_machine_extended']
labor_budget_hours = params['labor_budget_hours']
extended_mode_penalty = params['extended_mode_penalty']
priority_reserve_lots = params['priority_reserve_lots']
excess_reserve_credit = params['excess_reserve_credit']

# Convert machine available time from hours to minutes
m1_avail_base_minutes = m1_avail_base_hours * 60
m2_avail_base_minutes = m2_avail_base_hours * 60

# --- Gurobi Model ---
model = gp.Model("Fertilizer_Resilience_Optimization")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# --- Decision Variables ---
# Production quantities (continuous, non-negative)
x_l = model.addVar(name="x_liquid_produced", lb=0.0, vtype=GRB.CONTINUOUS)
x_s = model.addVar(name="x_solid_produced", lb=0.0, vtype=GRB.CONTINUOUS)

# Binary variables for extended mode operation
y_m1 = model.addVar(name="y_machine1_extended", vtype=GRB.BINARY)
y_m2 = model.addVar(name="y_machine2_extended", vtype=GRB.BINARY)

# Ending inventory variables (continuous, non-negative)
# These are defined as variables to allow them to be used in constraints and objective
end_liquid = model.addVar(name="end_liquid_inventory", lb=0.0, vtype=GRB.CONTINUOUS)
end_solid = model.addVar(name="end_solid_inventory", lb=0.0, vtype=GRB.CONTINUOUS)

# Auxiliary variables for piecewise linear objective for inventory score
# These split the ending inventory into priority and excess bands
liquid_priority_inv = model.addVar(name="liquid_priority_inventory", lb=0.0, vtype=GRB.CONTINUOUS)
liquid_excess_inv = model.addVar(name="liquid_excess_inventory", lb=0.0, vtype=GRB.CONTINUOUS)
solid_priority_inv = model.addVar(name="solid_priority_inventory", lb=0.0, vtype=GRB.CONTINUOUS)
solid_excess_inv = model.addVar(name="solid_excess_inventory", lb=0.0, vtype=GRB.CONTINUOUS)

# --- Constraints ---
# 1. Ending Inventory Calculation
model.addConstr(end_liquid == init_liquid_inv + x_l - demand_liquid, "C_EndLiquidInventory")
model.addConstr(end_solid == init_solid_inv + x_s - demand_solid, "C_EndSolidInventory")

# 2. Machine Capacity Constraints
# Available time depends on whether machine is in extended mode
model.addConstr(m1_liquid_time * x_l + m1_solid_time * x_s <= m1_avail_base_minutes + y_m1 * extended_extra_minutes, "C_Machine1Capacity")
model.addConstr(m2_liquid_time * x_l + m2_solid_time * x_s <= m2_avail_base_minutes + y_m2 * extended_extra_minutes, "C_Machine2Capacity")

# 3. Skilled Labor Budget Constraint
model.addConstr(y_m1 * labor_hours_per_machine_extended + y_m2 * labor_hours_per_machine_extended <= labor_budget_hours, "C_LaborBudget")

# 4. Piecewise Linear Objective for Inventory (using auxiliary variables)
# For liquid inventory:
# Total ending liquid inventory is split into priority and excess parts
model.addConstr(end_liquid == liquid_priority_inv + liquid_excess_inv, "C_LiquidInvSplit")
# The priority part cannot exceed the priority_reserve_lots
model.addConstr(liquid_priority_inv <= priority_reserve_lots, "C_LiquidPriorityCap")
# liquid_priority_inv >= 0 and liquid_excess_inv >= 0 are ensured by lb=0.0

# For solid inventory:
# Total ending solid inventory is split into priority and excess parts
model.addConstr(end_solid == solid_priority_inv + solid_excess_inv, "C_SolidInvSplit")
# The priority part cannot exceed the priority_reserve_lots
model.addConstr(solid_priority_inv <= priority_reserve_lots, "C_SolidPriorityCap")
# solid_priority_inv >= 0 and solid_excess_inv >= 0 are ensured by lb=0.0

# --- Objective Function ---
# Maximize resilience score
# Score = (liquid_priority_inv * 1 + liquid_excess_inv * excess_reserve_credit)
#         + (solid_priority_inv * 1 + solid_excess_inv * excess_reserve_credit)
#         - (y_m1 + y_m2) * extended_mode_penalty

objective = (liquid_priority_inv * 1 + liquid_excess_inv * excess_reserve_credit) + \
            (solid_priority_inv * 1 + solid_excess_inv * excess_reserve_credit) - \
            (y_m1 + y_m2) * extended_mode_penalty

model.setObjective(objective, GRB.MAXIMIZE)

# --- Optimize the model ---
model.optimize()

# --- Output Results ---
if model.status == GRB.OPTIMAL:
    final_obj_value = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {final_obj_value:.2f}")
elif model.status == GRB.INFEASIBLE:
    print("Model is infeasible.")
elif model.status == GRB.UNBOUNDED:
    print("Model is unbounded.")
else:
    print(f"Optimization ended with status {model.status}")
