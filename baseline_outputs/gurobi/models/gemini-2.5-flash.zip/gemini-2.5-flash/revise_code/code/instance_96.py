import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_paths():
    """
    Determines the absolute paths to the data files.
    Assumes the script is in a subdirectory (e.g., 'src/') and data is in 'data/'
    at the same level as the script's parent directory.
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    return table_1_path, params_path

def solve_revised_problem():
    table_1_path, params_path = get_data_paths()

    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    params = {}
    for _, row in df_params.iterrows():
        params[row['Parameter_Name']] = row['Value']

    # --- Parse Supplier-Specific Parameters ---
    suppliers = [1, 2]
    supplier_data = {}

    for s in suppliers:
        supplier_data[s] = {
            'raw_pipe_length': float(params[f'raw_pipe_length_supplier{s}']),
            'max_cutting_patterns': int(params[f'max_cutting_patterns_supplier{s}']),
            'max_cuts_per_pipe': int(params[f'max_cuts_per_pipe_supplier{s}']),
            'max_leftover_length': float(params[f'max_leftover_length_supplier{s}']),
            'purchase_cost_per_pipe': float(params[f'purchase_cost_per_pipe_supplier{s}']),
            'cost_rates': []
        }
        # Collect cost rates for up to the third most frequent pattern as per new params
        rank_prefixes = ['most', 'second', 'third']
        for prefix in rank_prefixes:
            key = f"{prefix}_frequent_pattern_cost_rate_supplier{s}"
            if key in params:
                supplier_data[s]['cost_rates'].append(float(params[key]))
            else:
                break # Stop if a rank is not defined

    # Supplier 1 specific discount parameters
    discount_tier1_supplier1_max_qty = float(params['discount_tier1_supplier1_max_qty'])
    fixed_discount_tier2_supplier1 = float(params['fixed_discount_tier2_supplier1'])
    bigM_discount = float(params['bigM_discount']) # Big-M constant for modeling discount tier activation

    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)

    # --- Pattern Generation (Supplier-Specific) ---
    all_patterns = {}

    def generate_all_feasible_patterns(raw_pipe_length, max_cuts, max_leftover, lengths, n_items):
        """
        Generates all feasible cutting patterns for a given raw pipe length and constraints.
        A pattern is a tuple (q_0, q_1, ..., q_{n_items-1}) where q_i is the quantity of item i.
        """
        feasible_patterns = []
        min_length_allowed = raw_pipe_length - max_leftover

        # Stack for iterative DFS-like generation:
        # Each element: (current_pattern_quantities, current_total_length, current_total_cuts, current_item_idx)
        # Start with an empty pattern, 0 length, 0 cuts, at item 0
        stack = [([0] * n_items, 0, 0, 0)]

        while stack:
            current_pattern_quantities, current_total_length, current_total_cuts, item_idx = stack.pop()

            # If we have considered all item types
            if item_idx == n_items:
                # Check if this pattern is valid based on total length and cuts
                if current_total_length >= min_length_allowed and \
                   current_total_length <= raw_pipe_length and \
                   current_total_cuts > 0: # Must cut at least one piece
                    feasible_patterns.append(tuple(current_pattern_quantities))
                continue

            # For the current item type (lengths[item_idx]), try adding 0 to max_qty_possible
            max_qty_for_this_item = min(
                int((raw_pipe_length - current_total_length) // lengths[item_idx]),
                max_cuts - current_total_cuts
            )

            for q in range(max_qty_for_this_item + 1): # q=0 means this item type is not included in the pattern
                new_pattern_quantities = list(current_pattern_quantities) # Create a copy
                new_pattern_quantities[item_idx] = q
                new_total_length = current_total_length + q * lengths[item_idx]
                new_total_cuts = current_total_cuts + q
                
                # Only push to stack if it's still potentially valid (within raw pipe length and max cuts)
                if new_total_length <= raw_pipe_length and new_total_cuts <= max_cuts:
                    stack.append((new_pattern_quantities, new_total_length, new_total_cuts, item_idx + 1))
        return feasible_patterns

    for s in suppliers:
        all_patterns[s] = generate_all_feasible_patterns(
            supplier_data[s]['raw_pipe_length'],
            supplier_data[s]['max_cuts_per_pipe'],
            supplier_data[s]['max_leftover_length'],
            lengths,
            n_items
        )

    # --- Gurobi Model Setup ---
    model = gp.Model("Pipe_Cutting_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Decision Variables
    # y[s][p_idx]: Number of raw pipes cut using pattern p_idx from supplier s
    y = {} 
    # z[s][p_idx]: Binary, 1 if pattern p_idx from supplier s is used
    z = {} 
    # u[s][k]: Binary, 1 if the (k+1)-th most frequent pattern from supplier s is used (k=0 for most frequent)
    u = {} 
    # total_pipes_s[s]: Total raw pipes purchased from supplier s
    total_pipes_s = {} 

    for s in suppliers:
        num_patterns_s = len(all_patterns[s])
        y[s] = model.addVars(num_patterns_s, vtype=GRB.INTEGER, name=f"y_s{s}", lb=0)
        z[s] = model.addVars(num_patterns_s, vtype=GRB.BINARY, name=f"z_s{s}")
        u[s] = model.addVars(supplier_data[s]['max_cutting_patterns'], vtype=GRB.BINARY, name=f"u_s{s}_rank")
        total_pipes_s[s] = model.addVar(vtype=GRB.INTEGER, name=f"total_pipes_s{s}", lb=0)

    # Supplier 1 discount variable
    discount_s1_active = model.addVar(vtype=GRB.BINARY, name="discount_s1_active")

    # Objective Function
    total_cost = gp.LinExpr()

    # 1. Raw pipe purchasing cost
    total_cost += total_pipes_s[1] * supplier_data[1]['purchase_cost_per_pipe']
    total_cost += total_pipes_s[2] * supplier_data[2]['purchase_cost_per_pipe']

    # 2. Supplier 1 fixed discount
    total_cost -= fixed_discount_tier2_supplier1 * discount_s1_active

    # 3. Ranked pattern usage costs (per supplier)
    for s in suppliers:
        for k in range(supplier_data[s]['max_cutting_patterns']):
            if k < len(supplier_data[s]['cost_rates']): # Only add cost if rate is defined for this rank
                total_cost += supplier_data[s]['cost_rates'][k] * u[s][k]

    model.setObjective(total_cost, GRB.MINIMIZE)

    # --- Constraints ---

    # 1. Demand Coverage (shared across suppliers)
    for i in range(n_items):
        demand_expr = gp.LinExpr()
        for s in suppliers:
            for p_idx, pattern in enumerate(all_patterns[s]):
                demand_expr += pattern[i] * y[s][p_idx]
        model.addConstr(demand_expr >= demands[i], name=f"Demand_Item_{i}")

    # 2. Link y variables to total_pipes_s variables
    for s in suppliers:
        model.addConstr(total_pipes_s[s] == gp.quicksum(y[s][p_idx] for p_idx in range(len(all_patterns[s]))),
                        name=f"TotalPipes_s{s}")

    # 3. Link y variables to z (pattern usage) variables
    # M_big is a sufficiently large number, an upper bound on the number of pipes for any single pattern.
    # Sum of all demands is a safe upper bound for total pipes needed if each pipe yields at least one piece.
    M_big = sum(demands) 
    for s in suppliers:
        for p_idx in range(len(all_patterns[s])):
            model.addConstr(y[s][p_idx] <= M_big * z[s][p_idx], name=f"Link_y_z_s{s}_p{p_idx}")

    # 4. Link z variables to u (ranked pattern usage) variables
    for s in suppliers:
        # The total number of distinct patterns used for supplier s must equal the sum of active u[s][k] variables.
        # This also implicitly enforces the max_cutting_patterns_supplier_s limit.
        model.addConstr(gp.quicksum(z[s][p_idx] for p_idx in range(len(all_patterns[s]))) == gp.quicksum(u[s][k] for k in range(supplier_data[s]['max_cutting_patterns'])),
                        name=f"Link_z_u_sum_s{s}")

        # Ensure u[s][k] implies u[s][k+1] (i.e., higher ranks are filled first)
        for k in range(supplier_data[s]['max_cutting_patterns'] - 1):
            model.addConstr(u[s][k] >= u[s][k+1], name=f"RankOrder_s{s}_k{k}")

    # 5. Supplier 1 Discount Tier Constraints (nonlinear tiered discount via binary tiers)
    # If total_pipes_s[1] > discount_tier1_supplier1_max_qty, then discount_s1_active must be 1.
    # If total_pipes_s[1] <= discount_tier1_supplier1_max_qty, then discount_s1_active must be 0.
    model.addConstr(total_pipes_s[1] >= discount_tier1_supplier1_max_qty + 1 - bigM_discount * (1 - discount_s1_active),
                    name="Discount_Tier1_LowerBound")
    model.addConstr(total_pipes_s[1] <= discount_tier1_supplier1_max_qty + bigM_discount * discount_s1_active,
                    name="Discount_Tier1_UpperBound")

    # Optimize the model
    model.optimize()

    # Print the objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimization did not find an optimal solution.")
        print(f"Status: {model.status}")

if __name__ == "__main__":
    solve_revised_problem()
