import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    """
    Loads parameters from the general_parameters.csv file.
    Assumes the script is run from the workspace root directory.
    """
    # Construct the path to the data file relative to the script's location
    # The script is expected to be in the root directory, so 'data/general_parameters.csv'
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            # Attempt to convert value to int, then float, otherwise keep as string
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass # Keep as string if conversion fails
            params[name] = value
    return params

def solve():
    """
    Solves the revised toy manufacturing optimization problem using Gurobi.
    """
    params = load_parameters()
    
    # Extract parameters for clarity
    profit_robot = params['profit_per_robot']
    profit_car = params['profit_per_model_car']
    profit_blocks = params['profit_per_building_blocks']
    profit_doll = params['profit_per_doll']
    
    plastic_avail = params['plastic_available']
    plastic_robot = params['plastic_per_robot']
    plastic_car = params['plastic_per_model_car']
    plastic_blocks = params['plastic_per_building_blocks']
    plastic_doll = params['plastic_per_doll']
    
    electronic_components_avail = params['electronic_components_available']
    electronics_robot = params['electronics_per_robot']
    electronics_car = params['electronics_per_model_car']
    electronics_blocks = params['electronics_per_building_blocks']
    electronics_doll = params['electronics_per_doll']
    
    # A sufficiently large number for Big M constraints.
    # This M should be an upper bound on the maximum possible production quantity of any single toy.
    # Given resource limits (e.g., 1200 plastic units, min 10 plastic/toy), 10000 is a safe choice.
    M = 10000 
    
    # Create a new Gurobi model
    m = gp.Model("ToyManufacturing")
    
    # Suppress Gurobi output
    m.setParam('OutputFlag', 0)
    
    # Decision variables: number of each toy to manufacture (non-negative integers)
    x_robot = m.addVar(vtype=GRB.INTEGER, name="robots", lb=0)
    x_car = m.addVar(vtype=GRB.INTEGER, name="model_cars", lb=0)
    x_blocks = m.addVar(vtype=GRB.INTEGER, name="building_blocks", lb=0)
    x_doll = m.addVar(vtype=GRB.INTEGER, name="dolls", lb=0)
    
    # Binary indicator variables: 1 if a product is manufactured, 0 otherwise
    y_robot = m.addVar(vtype=GRB.BINARY, name="y_robot")
    y_doll = m.addVar(vtype=GRB.BINARY, name="y_doll")
    y_car = m.addVar(vtype=GRB.BINARY, name="y_car")
    y_blocks = m.addVar(vtype=GRB.BINARY, name="y_blocks")
    
    # Objective function: Maximize total profit
    m.setObjective(profit_robot * x_robot + profit_car * x_car + 
                   profit_blocks * x_blocks + profit_doll * x_doll, GRB.MAXIMIZE)
    
    # Resource constraints
    # Plastic availability
    m.addConstr(plastic_robot * x_robot + plastic_car * x_car + 
                plastic_blocks * x_blocks + plastic_doll * x_doll <= plastic_avail, "Plastic_Constraint")
    
    # Electronic components availability (added based on business requirements and data)
    m.addConstr(electronics_robot * x_robot + electronics_car * x_car + 
                electronics_blocks * x_blocks + electronics_doll * x_doll <= electronic_components_avail, "Electronics_Constraint")
    
    # Linking constraints between continuous (integer) and binary variables
    # These constraints ensure that y_i is 1 if x_i > 0, and 0 if x_i = 0.
    # 1. x_i <= M * y_i: If y_i = 0, then x_i must be 0.
    # 2. x_i >= y_i: If y_i = 1, then x_i must be at least 1 (since x_i is integer and non-negative).
    m.addConstr(x_robot <= M * y_robot, "Link_robot_upper")
    m.addConstr(x_robot >= y_robot, "Link_robot_lower")
    
    m.addConstr(x_car <= M * y_car, "Link_car_upper")
    m.addConstr(x_car >= y_car, "Link_car_lower")
    
    m.addConstr(x_blocks <= M * y_blocks, "Link_blocks_upper")
    m.addConstr(x_blocks >= y_blocks, "Link_blocks_lower")
    
    m.addConstr(x_doll <= M * y_doll, "Link_doll_upper")
    m.addConstr(x_doll >= y_doll, "Link_doll_lower")
    
    # Business rules
    # 1. Robots and dolls exclusion: If robots are manufactured, dolls cannot be manufactured.
    m.addConstr(y_robot + y_doll <= 1, "Robot_Doll_Exclusion")
    
    # 2. Model cars and building blocks dependency: If model cars are manufactured, building blocks must also be manufactured.
    m.addConstr(y_car <= y_blocks, "Car_Blocks_Dependency")
    
    # 3. Dolls cannot exceed model cars: The number of dolls manufactured cannot exceed the number of model cars manufactured.
    m.addConstr(x_doll <= x_car, "Dolls_leq_Cars")
    
    # NEW RULE (Revision): Model cars and building blocks cannot be produced in the same production plan.
    # This is a mutual exclusion constraint for the binary indicator variables.
    # Note: The combination of "Car_Blocks_Dependency" (y_car <= y_blocks) and 
    # "Car_Blocks_Mutual_Exclusion" (y_car + y_blocks <= 1) implies that y_car must be 0.
    # If y_car were 1, then y_blocks must be 1 (dependency), but y_car + y_blocks = 2, 
    # which violates the mutual exclusion. Thus, model cars cannot be produced.
    m.addConstr(y_car + y_blocks <= 1, "Car_Blocks_Mutual_Exclusion")
    
    # Optimize the model
    m.optimize()
    
    # Print the final objective value based on the optimization status
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    elif m.status == GRB.INFEASIBLE:
        print("Model is infeasible.")
        print("FINAL_OBJ_VALUE: 0") # Indicate infeasibility
    elif m.status == GRB.UNBOUNDED:
        print("Model is unbounded.")
        print("FINAL_OBJ_VALUE: -1") # Indicate unboundedness
    else:
        print(f"Optimization ended with status {m.status}")
        print("FINAL_OBJ_VALUE: 0") # Default for other non-optimal statuses

if __name__ == "__main__":
    solve()
