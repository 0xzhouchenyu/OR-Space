import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility function (from utils.py) ---
def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

# --- Data Loading ---
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load general parameters
params_data = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
params = {row['Parameter_Name']: float(row['Value']) for row in params_data}

cost_per_km = params['cost_per_km']
# truck_capacity is mentioned but the cost is defined per container per km,
# so it's not directly used in the cost calculation for this problem interpretation.
# truck_capacity = params['truck_capacity'] 
adriatic_pool_shortage_trigger = int(params['adriatic_pool_shortage_trigger'])
adriatic_pool_recovery_fee = params['adriatic_pool_recovery_fee']

# Load warehouse data
warehouses_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
warehouses = [row['Warehouse'] for row in warehouses_data]
supply = {row['Warehouse']: int(row['Empty_Containers']) for row in warehouses_data}

# Load port data
ports_data = load_csv_data(os.path.join(data_dir, 'table_2.csv'))
ports = [row['Port'] for row in ports_data]
demand = {row['Port']: int(row['Container_Demand']) for row in ports_data}

# Load distance data
distance_data = load_csv_data(os.path.join(data_dir, 'table_3.csv'))
distance = {}
for row in distance_data:
    wh = row['Warehouse']
    for port in ports:
        distance[(wh, port)] = float(row[port])

# Load shortage penalty data
shortage_penalty_data = load_csv_data(os.path.join(data_dir, 'shortage_penalty.csv'))
shortage_charge = {}
grace_containers = {}
recovery_fee = {}
for row in shortage_penalty_data:
    port_name = row['Port']
    shortage_charge[port_name] = float(row['Shortage_Charge'])
    grace_containers[port_name] = int(row['Grace_Containers'])
    recovery_fee[port_name] = float(row['Recovery_Fee'])

# Define Adriatic ports for regional shortage calculation
adriatic_ports = ['Venice', 'Ancona', 'Bari']

# --- Gurobi Model ---
model = gp.Model("Container_Transportation_Revised")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# Decision Variables
# x_ij: Number of containers transported from warehouse i to port j
x = model.addVars(warehouses, ports, vtype=GRB.INTEGER, name="x", lb=0)

# s_j: Shortage (unmet demand) at port j
s = model.addVars(ports, vtype=GRB.INTEGER, name="s", lb=0)

# y_j: Binary variable, 1 if port j's shortage exceeds its Grace_Containers, 0 otherwise
y = model.addVars(ports, vtype=GRB.BINARY, name="y")

# z_adriatic: Binary variable, 1 if combined Adriatic shortage exceeds adriatic_pool_shortage_trigger, 0 otherwise
z_adriatic = model.addVar(vtype=GRB.BINARY, name="z_adriatic")

# Objective Function
# Minimize total cost, which includes:
# 1. Transportation cost
transport_cost = gp.quicksum(x[i, j] * distance[(i, j)] * cost_per_km for i in warehouses for j in ports)

# 2. Per-container shortage cost for each port
shortage_per_container_cost = gp.quicksum(s[j] * shortage_charge[j] for j in ports)

# 3. Port-specific recovery desk fixed cost (if shortage exceeds grace band)
port_recovery_desk_cost = gp.quicksum(y[j] * recovery_fee[j] for j in ports)

# 4. Adriatic regional recovery desk fixed cost (if combined Adriatic shortage exceeds trigger)
adriatic_recovery_desk_cost = z_adriatic * adriatic_pool_recovery_fee

model.setObjective(transport_cost + shortage_per_container_cost + port_recovery_desk_cost + adriatic_recovery_desk_cost, GRB.MINIMIZE)

# Constraints

# 1. Supply constraints: Total containers shipped from a warehouse cannot exceed its supply
for i in warehouses:
    model.addConstr(gp.quicksum(x[i, j] for j in ports) <= supply[i], name=f"Supply_{i}")

# 2. Demand satisfaction with shortage: Total containers arriving at a port plus its shortage must meet demand
for j in ports:
    model.addConstr(gp.quicksum(x[i, j] for i in warehouses) + s[j] >= demand[j], name=f"Demand_Shortage_{j}")

# 3. Linking y_j to s_j (Port-specific recovery desk activation logic)
# y_j is 1 if s_j > grace_containers[j], 0 otherwise.
# We use Big-M formulation. M_j is an upper bound for s_j, which can be the port's demand.
for j in ports:
    M_j = demand[j] # Max possible shortage for port j is its total demand
    # If y_j = 0, then s_j <= grace_containers[j]. If y_j = 1, then s_j <= grace_containers[j] + M_j (always true).
    model.addConstr(s[j] <= grace_containers[j] + M_j * (1 - y[j]), name=f"Y_link_upper_{j}")
    # If y_j = 1, then s_j >= grace_containers[j] + 1. If y_j = 0, then s_j >= 0 (always true).
    model.addConstr(s[j] >= (grace_containers[j] + 1) * y[j], name=f"Y_link_lower_{j}")

# 4. Linking z_adriatic to combined Adriatic shortage (Regional recovery desk activation logic)
# z_adriatic is 1 if sum(s_j for j in adriatic_ports) > adriatic_pool_shortage_trigger, 0 otherwise.
S_adriatic = gp.quicksum(s[j] for j in adriatic_ports)

# M_adriatic is an upper bound for S_adriatic, which is the sum of demands for Adriatic ports.
M_adriatic = sum(demand[j] for j in adriatic_ports)

# If z_adriatic = 0, then S_adriatic <= adriatic_pool_shortage_trigger.
model.addConstr(S_adriatic <= adriatic_pool_shortage_trigger + M_adriatic * (1 - z_adriatic), name="Z_Adriatic_link_upper")
# If z_adriatic = 1, then S_adriatic >= adriatic_pool_shortage_trigger + 1.
model.addConstr(S_adriatic >= (adriatic_pool_shortage_trigger + 1) * z_adriatic, name="Z_Adriatic_link_lower")

# Optimize the model
model.optimize()

# Print the optimal objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("Optimization did not find an optimal solution.")
    print(f"Status: {model.status}")
