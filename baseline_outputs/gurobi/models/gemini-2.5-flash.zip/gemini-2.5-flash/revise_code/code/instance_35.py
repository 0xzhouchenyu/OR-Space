import os
import sys
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def solve_revised_problem():
    # --- 1. Data Loading and Preprocessing ---
    # Determine the base directory of the script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, '..', 'data')

    # Load general parameters from general_parameters.csv
    general_params = {}
    general_params_filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(general_params_filepath, 'r') as f:
        reader = csv.reader(f)
        next(reader) # Skip header row
        for row in reader:
            general_params[row[0]] = float(row[1])

    planning_horizon_T = int(general_params['planning_horizon_T'])
    energy_cost_v1 = general_params['energy_cost_v1']
    energy_cost_v2 = general_params['energy_cost_v2']
    energy_cost_v3 = general_params['energy_cost_v3']
    peak_energy_multiplier = general_params['peak_energy_multiplier']
    peak_energy_cap = general_params['peak_energy_cap']
    makespan_weight = general_params['makespan_weight']
    energy_weight = general_params['energy_weight']

    # Load batch and processing data from table_1.csv
    batch_ids = []
    processing_times_raw = []
    table_1_filepath = os.path.join(data_dir, 'table_1.csv')
    with open(table_1_filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        num_vats = len(header) - 1 # Number of vats (excluding 'Batch' column)
        for row in reader:
            batch_id = int(row[0])
            batch_ids.append(batch_id)
            # Convert processing times to float
            times = [float(row[j+1]) for j in range(num_vats)]
            processing_times_raw.append(times)

    # Round up processing times to the next full time unit
    # processing_times[b][v] will store the rounded duration for batch b on vat v
    processing_times = [[math.ceil(t) for t in vat_times] for vat_times in processing_times_raw]

    # Define sets for the model
    # Batches are 0-indexed internally for easier list access
    Batches = list(range(len(batch_ids)))
    # Vats are 0-indexed internally (0=Vat1, 1=Vat2, 2=Vat3)
    Vats = list(range(num_vats))
    # Time periods are 1-indexed as per problem description
    TimePeriods = list(range(1, planning_horizon_T + 1))

    # --- 2. Gurobi Model Setup ---
    model = gp.Model("FabricDyeingScheduler")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- 3. Decision Variables ---
    # x[b, v, t]: Binary variable, 1 if batch 'b' starts processing on vat 'v' at time 't'
    x = model.addVars(Batches, Vats, TimePeriods, vtype=GRB.BINARY, name="x")

    # C[b, v]: Continuous variable, completion time of batch 'b' on vat 'v'
    C = model.addVars(Batches, Vats, vtype=GRB.CONTINUOUS, name="C")

    # Makespan: Continuous variable, the completion time of the last batch on Vat 3
    Makespan = model.addVar(vtype=GRB.CONTINUOUS, name="Makespan")

    # y[v, t]: Binary variable, 1 if vat 'v' is active (processing a batch) at time 't'
    y = model.addVars(Vats, TimePeriods, vtype=GRB.BINARY, name="y")

    # TotalEnergyCost: Continuous variable, the total energy cost for the schedule
    TotalEnergyCost = model.addVar(vtype=GRB.CONTINUOUS, name="TotalEnergyCost")

    # --- 4. Constraints ---

    # 4.1. Each batch must be processed exactly once on each vat
    # For each batch 'b' and vat 'v', it must start exactly once across all time periods
    model.addConstrs((gp.quicksum(x[b, v, t] for t in TimePeriods) == 1
                      for b in Batches for v in Vats), name="OneStartPerBatchVat")

    # 4.2. Define completion time for each batch on each vat
    # C[b, v] = (start time of batch b on vat v) + (processing duration of batch b on vat v)
    model.addConstrs((C[b, v] == gp.quicksum(t * x[b, v, t] for t in TimePeriods) + processing_times[b][v]
                      for b in Batches for v in Vats), name="CompletionTimeDef")

    # 4.3. Flow shop sequence: Batches must proceed from Vat 1 -> Vat 2 -> Vat 3
    # Completion on vat 'v' must be less than or equal to the start time on vat 'v+1'
    # This allows immediate transfer (start in the same period the previous vat finished)
    model.addConstrs((C[b, v] <= gp.quicksum(t * x[b, v+1, t] for t in TimePeriods)
                      for b in Batches for v in Vats[:-1]), name="FlowShopSequence")

    # 4.4. Vat capacity: No vat can process more than one batch at a time
    # For each vat 'v' and time period 't_prime', the sum of 'x' variables for batches
    # that are active during 't_prime' must be at most 1.
    # A batch 'b' starting at 't' on vat 'v' occupies periods [t, t + P[b][v] - 1].
    for v in Vats:
        for t_prime in TimePeriods:
            model.addConstr(gp.quicksum(x[b, v, t] for b in Batches
                                        for t in TimePeriods
                                        if t <= t_prime < t + processing_times[b][v]) <= 1,
                            name=f"VatCapacity_v{v+1}_t{t_prime}")

    # 4.5. Maintenance shutdown on Vat 2 (Vats[1]) during periods 4 and 5
    # If a batch 'b' starts on Vat 2 at time 't' with duration P[b][1], it occupies [t, t + P[b][1] - 1].
    # This interval must not overlap with [4, 5].
    # This means: (t + P[b][1] - 1 < 4) OR (t > 5).
    # Equivalently, if (t <= 5) AND (t + P[b][1] - 1 >= 4), then x[b, Vat2_idx, t] must be 0.
    vat2_idx = Vats[1] # Vat 2 corresponds to index 1
    for b in Batches:
        for t in TimePeriods:
            if t <= 5 and (t + processing_times[b][vat2_idx] - 1) >= 4:
                model.addConstr(x[b, vat2_idx, t] == 0, name=f"Vat2Maintenance_b{batch_ids[b]}_t{t}")

    # 4.6. Makespan definition
    # The Makespan is the maximum completion time among all batches on the last vat (Vat 3)
    last_vat_idx = Vats[-1] # Vat 3 corresponds to the last index
    model.addConstrs((Makespan >= C[b, last_vat_idx] for b in Batches), name="MakespanDef")

    # 4.7. Vat active indicator y[v, t]
    # y[v, t_prime] is 1 if vat 'v' is active at time 't_prime'.
    # This is equivalent to the sum of 'x' variables for batches active at 't_prime' on vat 'v'.
    # Since VatCapacity ensures this sum is at most 1, 'y' will naturally be 0 or 1.
    for v in Vats:
        for t_prime in TimePeriods:
            model.addConstr(y[v, t_prime] == gp.quicksum(x[b, v, t] for b in Batches
                                                          for t in TimePeriods
                                                          if t <= t_prime < t + processing_times[b][v]),
                            name=f"VatActiveIndicator_v{v+1}_t{t_prime}")

    # --- 5. Energy Cost Calculation ---
    # Define energy costs per vat and time period based on peak/off-peak tariffs
    vat_base_costs = {Vats[0]: energy_cost_v1, Vats[1]: energy_cost_v2, Vats[2]: energy_cost_v3}
    peak_periods = [6, 7, 8]
    energy_cost_vat_time = {}
    for v in Vats:
        for t in TimePeriods:
            cost = vat_base_costs[v]
            if t in peak_periods:
                cost *= peak_energy_multiplier
            energy_cost_vat_time[v, t] = cost

    # Define TotalEnergyCost as the sum of (cost per period * active indicator)
    model.addConstr(TotalEnergyCost == gp.quicksum(energy_cost_vat_time[v, t] * y[v, t]
                                                   for v in Vats for t in TimePeriods),
                    name="TotalEnergyCostDef")

    # 5.1. Peak Energy Cap constraint
    # Total active energy usage (cost-weighted) in peak periods 6-8 must not exceed peak_energy_cap
    peak_energy_usage = gp.quicksum(energy_cost_vat_time[v, t] * y[v, t]
                                    for v in Vats for t in peak_periods)
    model.addConstr(peak_energy_usage <= peak_energy_cap, name="PeakEnergyCap")

    # --- 6. Objective Function ---
    # Minimize a weighted sum of Makespan and TotalEnergyCost
    objective = makespan_weight * Makespan + energy_weight * TotalEnergyCost
    model.setObjective(objective, GRB.MINIMIZE)

    # --- 7. Solve the model and print the result ---
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INFEASIBLE:
        print("No optimal solution found - The model is infeasible.")
    elif model.status == GRB.UNBOUNDED:
        print("No optimal solution found - The model is unbounded.")
    else:
        print(f"Optimization ended with status {model.status}")

if __name__ == '__main__':
    solve_revised_problem()
