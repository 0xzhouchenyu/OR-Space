import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- 1. Data Loading ---
# Determine the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Read table_1.csv
toy_data = {}
toys = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        toy_type = row['Toy_Type']
        toys.append(toy_type)
        toy_data[toy_type] = {
            'labor': float(row['Manufacturing_Labor_Hours']),
            'inspection': float(row['Inspection_Hours']),
            'profit': float(row['Profit_Per_Unit'])
        }

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Extract parameters for the two-period model
periods = [1, 2]

available_labor_reg = {p: params[f'available_labor_hours_period{p}'] for p in periods}
available_inspection = {p: params[f'available_inspection_hours_period{p}'] for p in periods}
max_demand = {}
for p in periods:
    for toy_type in toys:
        # Convert toy_type to match parameter naming convention (e.g., 'High-End' -> 'high_end')
        key_name_part = toy_type.replace('-', '_').lower()
        max_demand[(toy_type, p)] = params[f'max_demand_{key_name_part}_period{p}']

overtime_labor_cap = params['overtime_labor_cap']
overtime_labor_cost = params['overtime_labor_cost']
period1_overtime_fatigue_threshold = params['period1_overtime_fatigue_threshold']
period2_labor_recovery_loss = params['period2_labor_recovery_loss']
overtime_review_threshold = params['overtime_review_threshold']
seasonal_safety_review_fee = params['seasonal_safety_review_fee']

# Define Big-M values for linking binary variables.
# M should be sufficiently large, at least the maximum possible value of the expression it bounds.
# Max possible overtime is overtime_labor_cap.
M_fatigue = overtime_labor_cap + 100 # A value safely larger than any possible overtime
M_safety = overtime_labor_cap + 100 # A value safely larger than any possible total overtime

# A small epsilon for strict inequality in Big-M constraints
EPSILON = 0.001

# --- 2. Model Initialization ---
model = gp.Model("ToyProductionRevised")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# --- 3. Decision Variables ---
# Production quantity for each toy type in each period
x = model.addVars(toys, periods, name="x", vtype=GRB.CONTINUOUS, lb=0)

# Overtime labor hours for each period
labor_overtime = model.addVars(periods, name="labor_overtime", vtype=GRB.CONTINUOUS, lb=0)

# Binary variable: 1 if Period 1 overtime exceeds period1_overtime_fatigue_threshold
y_fatigue = model.addVar(name="y_fatigue", vtype=GRB.BINARY)

# Binary variable: 1 if total overtime exceeds overtime_review_threshold
y_safety_review = model.addVar(name="y_safety_review", vtype=GRB.BINARY)

# --- 4. Objective Function ---
# Maximize total profit from sales minus total overtime cost and seasonal safety review fee
total_profit_from_sales = gp.quicksum(toy_data[t]['profit'] * x[t, p] for t in toys for p in periods)
total_overtime_cost = gp.quicksum(overtime_labor_cost * labor_overtime[p] for p in periods)
total_safety_review_cost = seasonal_safety_review_fee * y_safety_review

model.setObjective(total_profit_from_sales - total_overtime_cost - total_safety_review_cost, GRB.MAXIMIZE)

# --- 5. Constraints ---

# Labor hours constraint for each period
for p in periods:
    labor_used = gp.quicksum(toy_data[t]['labor'] * x[t, p] for t in toys)
    if p == 1:
        model.addConstr(labor_used <= available_labor_reg[p] + labor_overtime[p], f"Labor_Hours_P{p}")
    elif p == 2:
        # Period 2 regular labor is reduced if y_fatigue is 1
        model.addConstr(labor_used <= available_labor_reg[p] - y_fatigue * period2_labor_recovery_loss + labor_overtime[p], f"Labor_Hours_P{p}")

# Inspection hours constraint for each period
for p in periods:
    inspection_used = gp.quicksum(toy_data[t]['inspection'] * x[t, p] for t in toys)
    model.addConstr(inspection_used <= available_inspection[p], f"Inspection_Hours_P{p}")

# Demand constraints for each toy type in each period
for t in toys:
    for p in periods:
        model.addConstr(x[t, p] <= max_demand[(t, p)], f"Demand_{t.replace(' ', '')}_P{p}")

# Overtime labor cap
model.addConstr(labor_overtime[1] + labor_overtime[2] <= overtime_labor_cap, "Total_Overtime_Cap")

# Fatigue Carryover: Link Period 1 overtime to y_fatigue
# If labor_overtime[1] > period1_overtime_fatigue_threshold, then y_fatigue must be 1.
# 1. If y_fatigue = 0, then labor_overtime[1] must be <= period1_overtime_fatigue_threshold
model.addConstr(labor_overtime[1] - period1_overtime_fatigue_threshold <= M_fatigue * y_fatigue, "Fatigue_Link_1")
# 2. If y_fatigue = 1, then labor_overtime[1] must be >= period1_overtime_fatigue_threshold + EPSILON
model.addConstr(labor_overtime[1] - period1_overtime_fatigue_threshold >= EPSILON - M_fatigue * (1 - y_fatigue), "Fatigue_Link_2")

# Seasonal Safety Review: Link total overtime to y_safety_review
total_overtime = labor_overtime[1] + labor_overtime[2]
# If total_overtime > overtime_review_threshold, then y_safety_review must be 1.
# 1. If y_safety_review = 0, then total_overtime must be <= overtime_review_threshold
model.addConstr(total_overtime - overtime_review_threshold <= M_safety * y_safety_review, "Safety_Review_Link_1")
# 2. If y_safety_review = 1, then total_overtime must be >= overtime_review_threshold + EPSILON
model.addConstr(total_overtime - overtime_review_threshold >= EPSILON - M_safety * (1 - y_safety_review), "Safety_Review_Link_2")

# --- 6. Solve ---
model.optimize()

# --- 7. Print Results ---
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # Handle cases where no optimal solution is found
    if model.status == GRB.INFEASIBLE:
        print("Model is infeasible.")
    elif model.status == GRB.UNBOUNDED:
        print("Model is unbounded.")
    else:
        print(f"Optimization ended with status {model.status}")
