import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Define data directory relative to the script's location
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

# Load general parameters from general_parameters.csv
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
    for row in csv.DictReader(f):
        try:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
        except ValueError:
            # In case some values are not floats, though for this problem, all relevant are.
            params[row['Parameter_Name'].strip()] = row['Value'].strip()

# Load product-specific parameters from table_1.csv
products_data = {}
with open(os.path.join(data_dir, 'table_1.csv')) as f:
    for row in csv.DictReader(f):
        product_name = row['Product'].strip()
        products_data[product_name] = {
            'a_hrs': float(row['Workshop_A_Hours']),
            'b_hrs': float(row['Workshop_B_Hours']),
            'insp_cost': float(row['Inspection_Sales_Cost'])
        }

# Extract specific product data for convenience
m_data = products_data['Microwave_Oven']
w_data = products_data['Water_Heater']

# Create a new Gurobi model
model = gp.Model("production_revised")
model.setParam('OutputFlag', 0)  # Suppress Gurobi output

# --- Decision Variables ---
# Production quantities for Microwave Ovens (x1) and Water Heaters (x2)
# Variables are continuous and non-negative, with minimum sales requirements as lower bounds.
x1 = model.addVar(lb=params['microwave_minimum_sales'], vtype=GRB.CONTINUOUS, name="microwave_units")
x2 = model.addVar(lb=params['water_heater_minimum_sales'], vtype=GRB.CONTINUOUS, name="water_heater_units")

# Binary variable y_A: 1 if Workshop A is used for production, 0 otherwise.
y_A = model.addVar(vtype=GRB.BINARY, name="workshop_A_activated")

# --- Objective Function ---
# The original heuristic maximizes a sum of costs per unit.
# We will maintain this structure, adjusting for new bonuses and fixed costs.
# Objective: Maximize Z = (original_cost_m * x1 + original_cost_w * x2)
#                        - (green_bonus_m * x1 + green_bonus_w * x2)  (Bonuses reduce net cost, so subtract)
#                        + (setup_cost_A * y_A)                       (Fixed cost increases total cost, so add)

# Calculate original cost components per unit (as per heuristic's rev_m, rev_w)
original_cost_m_per_unit = (m_data['a_hrs'] * params['workshop_a_hourly_cost'] +
                            m_data['b_hrs'] * params['workshop_b_hourly_cost'] +
                            m_data['insp_cost'])

original_cost_w_per_unit = (w_data['a_hrs'] * params['workshop_a_hourly_cost'] +
                            w_data['b_hrs'] * params['workshop_b_hourly_cost'] +
                            w_data['insp_cost'])

# Calculate fixed cost for Workshop A setup if activated
setup_cost_A = params['setup_hours_A'] * params['workshop_a_hourly_cost']

model.setObjective(
    original_cost_m_per_unit * x1 +
    original_cost_w_per_unit * x2 -
    params['green_bonus_m'] * x1 -
    params['green_bonus_w'] * x2 +
    setup_cost_A * y_A,
    GRB.MAXIMIZE
)

# --- Constraints ---

# 1. Workshop A utilization constraint
# Includes regular production hours and fixed setup hours if Workshop A is activated.
# Total hours must be within available hours plus overtime limit.
model.addConstr(
    m_data['a_hrs'] * x1 + w_data['a_hrs'] * x2 + params['setup_hours_A'] * y_A <=
    params['workshop_a_available_hours'] + params['workshop_a_overtime_limit'],
    name="workshop_A_capacity"
)

# 2. Workshop B utilization constraint
# As per the original heuristic, this is a minimum utilization requirement.
model.addConstr(
    m_data['b_hrs'] * x1 + w_data['b_hrs'] * x2 >= params['workshop_b_available_hours'],
    name="workshop_B_min_utilization"
)

# 3. Inspection and Sales Cost Limit
# Uses the updated limit from general_parameters.csv.
model.addConstr(
    m_data['insp_cost'] * x1 + w_data['insp_cost'] * x2 <= params['inspection_sales_cost_limit'],
    name="inspection_sales_cost_limit"
)

# 4. Minimum Sales Requirements
# These are already handled by the lower bounds (lb) set on variables x1 and x2.

# 5. Shared Technician Pool Constraint (New requirement)
# Total technician hours consumed must not exceed the available tech_pool_hours.
model.addConstr(
    params['tech_rate_m'] * x1 + params['tech_rate_w'] * x2 <= params['tech_pool_hours'],
    name="technician_pool_capacity"
)

# 6. Linking y_A (Workshop A activation) to production
# If any product requiring Workshop A is produced (both microwave and water heater do),
# then y_A must be 1. If no products requiring Workshop A are produced, y_A can be 0.
# We use a Big M constraint: x1 + x2 <= BigM * y_A.
# If x1 or x2 > 0, then y_A must be 1. If x1=0 and x2=0, y_A can be 0.
model.addConstr(
    x1 + x2 <= params['bigM'] * y_A,
    name="link_yA_production"
)

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("Optimization was not successful. Status:", model.status)
