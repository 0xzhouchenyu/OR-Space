import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Utility function to read CSV files
def read_csv(filepath):
    """Reads a CSV file and returns a list of dictionaries."""
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

def main():
    # Determine the base directory for data files
    # This assumes the script is run from the workspace root or its immediate subdirectory (e.g., src/)
    # and data is in a 'data' subdirectory relative to the script's parent.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Read product data from table_1.csv
    products_data = read_csv(os.path.join(data_dir, 'table_1.csv'))
    
    # Read general parameters from general_parameters.csv
    params_list = read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    # Convert parameters to a dictionary for easy access
    params = {row['Parameter_Name']: float(row['Value']) for row in params_list}
    
    # Create a dictionary for product details for easier access
    product_details = {p['Product']: {
        'Steel_Required_kg': float(p['Steel_Required_kg']),
        'Aluminum_Required_kg': float(p['Aluminum_Required_kg']),
        'Labor_Required_hours': float(p['Labor_Required_hours']),
        'Profit_yuan': float(p['Profit_yuan']),
        'Setup_Cost_yuan': float(p['Setup_Cost_yuan'])
    } for p in products_data}
    
    # Initialize Gurobi model
    model = gp.Model("Production_Optimization_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # --- Decision Variables ---
    
    # x[p]: Quantity of product p to produce (continuous, non-negative)
    x = model.addVars(product_details.keys(), name="x", vtype=GRB.CONTINUOUS, lb=0.0)
    
    # y[p]: Binary variable, 1 if product p is produced (x[p] > 0), 0 otherwise (for setup costs)
    y = model.addVars(product_details.keys(), name="y", vtype=GRB.BINARY)
    
    # labor_ot: Total overtime hours used (continuous, non-negative)
    labor_ot = model.addVar(name="labor_ot", vtype=GRB.CONTINUOUS, lb=0.0)
    
    # z_ot_review: Binary variable, 1 if total labor_ot exceeds overtime_review_threshold
    z_ot_review = model.addVar(name="z_ot_review", vtype=GRB.BINARY)
    
    # z_A_audit: Binary variable, 1 if production of Product A exceeds product_A_line_audit_threshold
    z_A_audit = model.addVar(name="z_A_audit", vtype=GRB.BINARY)
    
    # --- Objective Function ---
    # Maximize Total Profit - Total Costs
    
    # 1. Total Profit from products
    total_profit_products = gp.quicksum(product_details[p]['Profit_yuan'] * x[p] for p in product_details)
    
    # 2. Setup Costs (incurred if a product is produced)
    total_setup_cost = gp.quicksum(product_details[p]['Setup_Cost_yuan'] * y[p] for p in product_details)
    
    # 3. Overtime Pay
    overtime_cost = params['overtime_pay'] * labor_ot
    
    # 4. Overtime Review Fee (fixed cost if overtime exceeds threshold)
    overtime_review_fee_cost = params['overtime_review_fee'] * z_ot_review
    
    # 5. Product A Line Audit Fee (fixed cost if Product A production exceeds threshold)
    product_A_audit_fee_cost = params['product_A_line_audit_fee'] * z_A_audit
    
    model.setObjective(total_profit_products - total_setup_cost - overtime_cost - overtime_review_fee_cost - product_A_audit_fee_cost, GRB.MAXIMIZE)
    
    # --- Constraints ---
    
    # 1. Steel Constraint: Total steel used must not exceed available steel
    model.addConstr(gp.quicksum(product_details[p]['Steel_Required_kg'] * x[p] for p in product_details) <= params['available_steel'], "Steel_Constraint")
    
    # 2. Aluminum Constraint: Total aluminum used must not exceed available aluminum
    model.addConstr(gp.quicksum(product_details[p]['Aluminum_Required_kg'] * x[p] for p in product_details) <= params['available_aluminum'], "Aluminum_Constraint")
    
    # 3. Labor Constraint: Total labor required must be covered by available regular labor plus overtime
    total_labor_required = gp.quicksum(product_details[p]['Labor_Required_hours'] * x[p] for p in product_details)
    model.addConstr(total_labor_required <= params['available_labor'] + labor_ot, "Labor_Constraint")
    
    # 4. Maximum Overtime: Total overtime hours cannot exceed the maximum allowed
    model.addConstr(labor_ot <= params['max_overtime'], "Max_Overtime")
    
    # 5. Link x[p] and y[p] (Setup Cost): If x[p] > 0, then y[p] must be 1
    # We use a large M value for linking. A tight M for each product is its maximum possible production.
    # Calculate M_A and M_B based on resource availability
    M_A = min(params['available_steel'] / product_details['A']['Steel_Required_kg'],
              params['available_aluminum'] / product_details['A']['Aluminum_Required_kg'],
              (params['available_labor'] + params['max_overtime']) / product_details['A']['Labor_Required_hours'])
    
    M_B = min(params['available_steel'] / product_details['B']['Steel_Required_kg'],
              params['available_aluminum'] / product_details['B']['Aluminum_Required_kg'],
              (params['available_labor'] + params['max_overtime']) / product_details['B']['Labor_Required_hours'])

    model.addConstr(x['A'] <= M_A * y['A'], "Link_x_y_A")
    model.addConstr(x['B'] <= M_B * y['B'], "Link_x_y_B")
    
    # 6. Link labor_ot and z_ot_review (Overtime Review Fee)
    # If labor_ot > overtime_review_threshold, then z_ot_review must be 1.
    # M_ot is a large number, representing the maximum possible overtime.
    M_ot = params['max_overtime'] 
    epsilon = 0.001 # Small value to ensure strict inequality for threshold
    
    # If labor_ot exceeds threshold, z_ot_review must be 1
    model.addConstr(labor_ot <= params['overtime_review_threshold'] + M_ot * z_ot_review, "Overtime_Review_Link_1")
    # If labor_ot is less than or equal to threshold, z_ot_review can be 0
    model.addConstr(labor_ot >= params['overtime_review_threshold'] + epsilon - M_ot * (1 - z_ot_review), "Overtime_Review_Link_2")
    
    # 7. Link x['A'] and z_A_audit (Product A Line Audit Fee)
    # If x['A'] > product_A_line_audit_threshold, then z_A_audit must be 1.
    # M_A_audit is a large number, representing the maximum possible production of A.
    M_A_audit = M_A 
    
    # If x['A'] exceeds threshold, z_A_audit must be 1
    model.addConstr(x['A'] <= params['product_A_line_audit_threshold'] + M_A_audit * z_A_audit, "Product_A_Audit_Link_1")
    # If x['A'] is less than or equal to threshold, z_A_audit can be 0
    model.addConstr(x['A'] >= params['product_A_line_audit_threshold'] + epsilon - M_A_audit * (1 - z_A_audit), "Product_A_Audit_Link_2")
    
    # Optimize model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Handle cases where no optimal solution is found
        # For this problem, an optimal solution is expected given the constraints.
        print("No optimal solution found.")
        print(f"Model status: {model.status}")

if __name__ == "__main__":
    main()
