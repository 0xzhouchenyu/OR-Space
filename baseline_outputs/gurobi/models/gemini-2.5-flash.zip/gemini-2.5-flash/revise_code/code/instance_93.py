import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(data_dir):
    """
    Loads parameters from the general_parameters.csv file.
    """
    params = {}
    file_path = os.path.join(data_dir, 'general_parameters.csv')
    
    # Ensure the data directory and file exist
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Data file not found: {file_path}")

    with open(file_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            # Attempt to convert to float, handle 'unlimited' or other non-numeric values if necessary
            try:
                params[name] = float(val)
            except ValueError:
                params[name] = val # Keep as string if not a number
    return params

def main():
    # Determine the directory for data files relative to the script's location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load parameters from the CSV file
    params = load_parameters(data_dir)
    
    # Extract all necessary parameters, including new ones from the revision
    a1_yield = params['product_A1_yield']
    a1_time = params['product_A1_time']
    profit_a1 = params['profit_per_kg_A1']
    
    a2_yield = params['product_A2_yield']
    a2_time = params['product_A2_time']
    profit_a2 = params['profit_per_kg_A2']
    
    a3_yield = params['product_A3_yield']
    a3_time = params['product_A3_time']
    profit_a3 = params['profit_per_kg_A3']
    
    daily_milk_supply = params['daily_milk_supply']
    daily_labor_hours = params['daily_labor_hours']
    
    cap_A_shared = params['cap_A_shared']
    type_A_cleaning_loss_if_A3 = params['type_A_cleaning_loss_if_A3']
    
    min_A2_kg = params['min_A2_kg']
    min_A3_kg = params['min_A3_kg']
    
    cold_chain_bonus_threshold_kg = params['cold_chain_bonus_threshold_kg']
    cold_chain_bonus_yuan = params['cold_chain_bonus_yuan']

    # Create a new Gurobi model
    model = gp.Model("Dairy_Production_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables:
    # x1, x2, x3 = barrels of milk allocated to product A1, A2, A3 respectively
    x1 = model.addVar(lb=0.0, name="x1_barrels_A1")
    x2 = model.addVar(lb=0.0, name="x2_barrels_A2")
    x3 = model.addVar(lb=0.0, name="x3_barrels_A3")
    
    # Binary variable: y_A3_produced = 1 if A3 is produced (x3 > 0), 0 otherwise
    y_A3_produced = model.addVar(vtype=GRB.BINARY, name="y_A3_produced")
    
    # Binary variable: y_cold_chain_bonus = 1 if A3 production meets the cold chain bonus threshold, 0 otherwise
    y_cold_chain_bonus = model.addVar(vtype=GRB.BINARY, name="y_cold_chain_bonus")
    
    # Calculate profit per barrel for each product
    profit_per_barrel_a1 = profit_a1 * a1_yield
    profit_per_barrel_a2 = profit_a2 * a2_yield
    profit_per_barrel_a3 = profit_a3 * a3_yield
    
    # Objective function: Maximize total profit
    model.setObjective(
        profit_per_barrel_a1 * x1 + 
        profit_per_barrel_a2 * x2 + 
        profit_per_barrel_a3 * x3 +
        cold_chain_bonus_yuan * y_cold_chain_bonus,
        GRB.MAXIMIZE
    )
    
    # Constraints
    
    # 1. Milk Supply Constraint: Total milk used cannot exceed daily supply
    model.addConstr(x1 + x2 + x3 <= daily_milk_supply, "Milk_Supply")
    
    # 2. Labor Hours Constraint: Total labor hours used cannot exceed daily available labor
    model.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= daily_labor_hours, "Labor_Hours")
    
    # 3. Type A Equipment Capacity Constraint: Shared capacity for A1 and A3
    # The capacity is reduced by a cleaning loss if A3 is produced
    model.addConstr(a1_yield * x1 + a3_yield * x3 <= cap_A_shared - type_A_cleaning_loss_if_A3 * y_A3_produced, "Type_A_Capacity")
    
    # 4. Minimum A2 Production Constraint: A2 must satisfy the butter bundle
    model.addConstr(a2_yield * x2 >= min_A2_kg, "Min_A2_Production")
    
    # 5. Minimum A3 Production Constraint: A3 must satisfy its minimum if produced
    # If y_A3_produced = 1, then a3_yield * x3 >= min_A3_kg. If y_A3_produced = 0, then x3 must be 0 (from next constraint).
    model.addConstr(a3_yield * x3 >= min_A3_kg * y_A3_produced, "Min_A3_Production")
    
    # 6. Linking y_A3_produced to x3 (Big M constraint for production indicator)
    # If x3 > 0, then y_A3_produced must be 1. If x3 = 0, y_A3_produced can be 0.
    # M_A3 is a sufficiently large number, representing an upper bound for x3 (max barrels of milk for A3)
    M_A3 = daily_milk_supply 
    model.addConstr(x3 <= M_A3 * y_A3_produced, "Link_x3_yA3Produced")
    
    # 7. Linking y_cold_chain_bonus to A3 production (Big M constraints for threshold bonus)
    # y_cold_chain_bonus = 1 if (a3_yield * x3) >= cold_chain_bonus_threshold_kg
    # y_cold_chain_bonus = 0 if (a3_yield * x3) < cold_chain_bonus_threshold_kg
    
    A3_kg_produced = a3_yield * x3
    # M_bonus is an upper bound for A3_kg_produced (max possible A3 production in kg)
    M_bonus = daily_milk_supply * a3_yield 
    epsilon = 0.001 # A small value to handle strict inequality for the threshold
    
    # Constraint 7a: If A3_kg_produced >= threshold, force y_cold_chain_bonus to 1
    model.addConstr(A3_kg_produced >= cold_chain_bonus_threshold_kg - M_bonus * (1 - y_cold_chain_bonus), "Bonus_Constraint_1")
    
    # Constraint 7b: If A3_kg_produced < threshold, force y_cold_chain_bonus to 0
    model.addConstr(A3_kg_produced <= cold_chain_bonus_threshold_kg - epsilon + M_bonus * y_cold_chain_bonus, "Bonus_Constraint_2")
    
    # Optimize the model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Handle cases where an optimal solution is not found
        # For example, if the problem is infeasible or unbounded
        print("Optimization did not find an optimal solution.")
        print(f"Gurobi Status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
