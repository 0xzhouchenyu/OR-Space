import gurobipy as gp
from gurobipy import GRB
import os
import csv

# --- Utility functions (copied from src/utils.py and extended for general_parameters.csv) ---
def load_processing_times(filepath):
    """Load processing times from CSV file.
    Returns a list of lists: processing_times[i][j] = time for product i on machine j.
    """
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # Skip header
        for row in reader:
            # First column is product name, rest are processing times
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times

def load_general_parameters(filepath):
    """Load general parameters from CSV file.
    Returns a dictionary of parameter_name: value.
    Values are converted to int or float if possible.
    """
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # Skip header
        for row in reader:
            param_name = row[0]
            value_str = row[1]
            # Only process rows with a value
            if value_str:
                try:
                    params[param_name] = int(value_str)
                except ValueError:
                    try:
                        params[param_name] = float(value_str)
                    except ValueError:
                        params[param_name] = value_str # Keep as string if not a number
    return params
# --- End of utility functions ---


def main():
    # Determine data directory path relative to the script's location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')

    # Load data from CSV files
    processing_times = load_processing_times(os.path.join(data_dir, 'table_1.csv'))
    general_params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    n_products = len(processing_times)
    n_machines = len(processing_times[0])
    
    # Extract parameters from general_params dictionary
    # Note: Machine indices are 0-based in code, but 1-based in parameter names
    TW = [general_params[f'time_window_{j+1}'] for j in range(n_machines)]
    OTW = [general_params[f'overtime_window_{j+1}'] for j in range(n_machines)]
    OPPU = general_params['overtime_penalty_per_unit']
    M_val = [general_params[f'M_{j+1}'] for j in range(n_machines)] # Big-M constants for sequencing
    M1_OT_THRESHOLD = general_params['machine1_overtime_review_threshold']
    M1_OT_FEE = general_params['machine1_overtime_review_fee']

    # Create a new Gurobi model
    model = gp.Model("FlowShopWithPenalties")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- Decision Variables ---
    # C[i, j]: Completion time of product i on machine j
    C = model.addVars(n_products, n_machines, vtype=GRB.CONTINUOUS, name="C", lb=0.0)
    # S[i, j]: Start time of product i on machine j
    S = model.addVars(n_products, n_machines, vtype=GRB.CONTINUOUS, name="S", lb=0.0)
    
    # y[i, i_prime]: Binary, 1 if product i precedes i_prime in the global sequence
    y = model.addVars(n_products, n_products, vtype=GRB.BINARY, name="y")

    # C_max: Overall makespan (completion time of the last product on the last machine)
    C_max = model.addVar(vtype=GRB.CONTINUOUS, name="C_max", lb=0.0)

    # OT[j]: Total overtime used on machine j
    OT = model.addVars(n_machines, vtype=GRB.CONTINUOUS, name="OT", lb=0.0)

    # Total_Machine_Time[j]: Total time machine j is occupied (from start of first job to end of last job on that machine)
    Total_Machine_Time = model.addVars(n_machines, vtype=GRB.CONTINUOUS, name="Total_Machine_Time", lb=0.0)

    # OT_M1_exceeds_threshold: Binary, 1 if Machine 1 overtime exceeds M1_OT_THRESHOLD
    OT_M1_exceeds_threshold = model.addVar(vtype=GRB.BINARY, name="OT_M1_exceeds_threshold")

    # --- Constraints ---

    # 1. Start and Completion Times
    # The completion time of a product on a machine is its start time plus its processing time
    model.addConstrs(S[i, j] + processing_times[i][j] == C[i, j]
                     for i in range(n_products) for j in range(n_machines),
                     name="CompletionTimeDef")

    # 2. Machine Precedence (Flow Shop - within a product)
    # A product cannot start on machine j until it completes on machine j-1
    model.addConstrs(S[i, j] >= C[i, j-1]
                     for i in range(n_products) for j in range(1, n_machines),
                     name="MachinePrecedence")

    # 3. Job Precedence (Flow Shop - within a machine - single global sequence)
    # For any pair of distinct products i, i_prime, one must precede the other
    model.addConstrs(y[i, i_prime] + y[i_prime, i] == 1
                     for i in range(n_products) for i_prime in range(i + 1, n_products),
                     name="PrecedenceBinary")
    # A product cannot precede itself (y[i,i] should be 0, but not strictly needed with i != i_prime in other constraints)
    # model.addConstrs(y[i, i] == 0 for i in range(n_products), name="NoSelfPrecedence")

    # Big-M constraints for sequencing on each machine:
    # If product i precedes i_prime (y[i, i_prime] == 1), then i_prime must start after i finishes on the same machine.
    # S[i_prime, j] >= C[i, j]
    # If i_prime precedes i (y[i, i_prime] == 0), then S[i, j] >= C[i_prime, j].
    # This single constraint set, combined with y[i, i_prime] + y[i_prime, i] == 1, correctly models the precedence.
    for i in range(n_products):
        for i_prime in range(n_products):
            if i != i_prime:
                for j in range(n_machines):
                    model.addConstr(S[i_prime, j] >= C[i, j] - M_val[j] * (1 - y[i, i_prime]),
                                    name=f"JobPrecedence_{i}_{i_prime}_M{j}")

    # 4. Makespan Definition
    # C_max must be greater than or equal to the completion time of any product on the last machine
    model.addConstrs(C_max >= C[i, n_machines - 1] for i in range(n_products), name="MakespanDef")

    # 5. Machine Availability and Overtime
    # Total_Machine_Time[j] is the completion time of the last job on machine j
    model.addConstrs(Total_Machine_Time[j] >= C[i, j]
                     for i in range(n_products) for j in range(n_machines),
                     name="TotalMachineTimeDef")
    
    # Overtime calculation: OT[j] is the amount by which Total_Machine_Time[j] exceeds TW[j]
    model.addConstrs(OT[j] >= Total_Machine_Time[j] - TW[j]
                     for j in range(n_machines),
                     name="OvertimeCalc")
    
    # Maximum overtime limit: Overtime cannot exceed OTW[j]
    model.addConstrs(OT[j] <= OTW[j]
                     for j in range(n_machines),
                     name="OvertimeLimit")

    # 6. Machine 1 Special Overtime Rule
    # Link OT_M1_exceeds_threshold binary variable to OT[0] (Machine 1 overtime)
    epsilon = 0.001 # A small positive value to model strict inequality (OT[0] > M1_OT_THRESHOLD)
    # M_OT_M1 should be a sufficiently large number, e.g., max possible overtime on M1
    M_OT_M1 = M1_OT_THRESHOLD + OTW[0] 

    # If OT[0] > M1_OT_THRESHOLD, then OT_M1_exceeds_threshold must be 1
    model.addConstr(OT[0] - M1_OT_THRESHOLD <= M_OT_M1 * OT_M1_exceeds_threshold,
                    name="M1OT_Exceeds_1")
    # If OT[0] <= M1_OT_THRESHOLD, then OT_M1_exceeds_threshold must be 0
    model.addConstr(OT[0] - M1_OT_THRESHOLD >= epsilon - M_OT_M1 * (1 - OT_M1_exceeds_threshold),
                    name="M1OT_Exceeds_2")

    # --- Objective Function ---
    # Minimize: Makespan + Total Overtime Penalty + Machine 1 Review Fee
    total_overtime_penalty = gp.quicksum(OT[j] for j in range(n_machines)) * OPPU
    m1_review_fee = OT_M1_exceeds_threshold * M1_OT_FEE
    
    model.setObjective(C_max + total_overtime_penalty + m1_review_fee, GRB.MINIMIZE)

    # Optimize the model
    model.optimize()

    # --- Output Results ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INF_OR_UNBD:
        print("FINAL_OBJ_VALUE: Problem is infeasible or unbounded")
    elif model.status == GRB.INFEASIBLE:
        print("FINAL_OBJ_VALUE: Problem is infeasible")
    elif model.status == GRB.UNBOUNDED:
        print("FINAL_OBJ_VALUE: Problem is unbounded")
    else:
        print(f"FINAL_OBJ_VALUE: Optimization was stopped with status {model.status}")

if __name__ == "__main__":
    main()
