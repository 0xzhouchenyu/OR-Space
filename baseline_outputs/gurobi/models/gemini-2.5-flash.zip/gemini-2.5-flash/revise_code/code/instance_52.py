import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_bus_scheduling():
    # --- 1. File path setup ---
    # Get the directory where the script is located
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # Construct the path to the data directory
    data_dir = os.path.join(base_dir, 'data')
    
    # --- 2. Parameter Reading ---
    
    # Read shift requirements from table_1_2.csv
    required_numbers = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            required_numbers.append(int(row['Required_number']))
    
    n_periods = len(required_numbers) # Number of 4-hour periods (6)
    
    # Read general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Store values, converting to float for ratios/costs, int for counts
            if row['Parameter_Name'] in ['shift_duration', 'max_overtime_shifts']:
                params[row['Parameter_Name']] = int(row['Value'])
            else:
                params[row['Parameter_Name']] = float(row['Value'])
            
    shift_duration = params['shift_duration'] # 8 hours
    periods_per_shift = shift_duration // 4 # Each period is 4 hours, so 8/4 = 2 periods
    
    max_night_driver_fraction = params['max_night_driver_fraction']
    max_night_crew_fraction = params['max_night_crew_fraction']
    max_overtime_shifts = params['max_overtime_shifts']
    overtime_cost_factor = params['overtime_cost_factor']
    
    # Late-night periods (0-indexed): Periods 5 and 6 from CSV are 4 and 5
    late_night_periods = [4, 5] 
    
    # --- 3. Model Initialization ---
    model = gp.Model("RevisedBusScheduling")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # --- 4. Variable Definition ---
    
    # Decision variables: number of regular drivers/crew starting at period i
    x_d = model.addVars(n_periods, vtype=GRB.INTEGER, lb=0, name="regular_driver_start")
    x_c = model.addVars(n_periods, vtype=GRB.INTEGER, lb=0, name="regular_crew_start")
    
    # Decision variables: number of overtime drivers/crew starting at period i
    y_d = model.addVars(n_periods, vtype=GRB.INTEGER, lb=0, name="overtime_driver_start")
    y_c = model.addVars(n_periods, vtype=GRB.INTEGER, lb=0, name="overtime_crew_start")
    
    # --- 5. Objective Definition ---
    # Minimize total cost: regular shifts cost 1, overtime shifts cost overtime_cost_factor
    objective = gp.quicksum(x_d[i] for i in range(n_periods)) + \
                gp.quicksum(x_c[i] for i in range(n_periods)) + \
                overtime_cost_factor * (gp.quicksum(y_d[i] for i in range(n_periods)) + \
                                        gp.quicksum(y_c[i] for i in range(n_periods)))
    model.setObjective(objective, GRB.MINIMIZE)
    
    # --- 6. Constraint Definition ---
    
    # Helper function to determine which starting periods cover a given period j
    # A shift starting at 'i' covers periods 'i', (i+1)%n, ..., (i+periods_per_shift-1)%n
    # This function returns a list of 'i's such that a shift starting at 'i' covers 'j'.
    def get_covering_starts(j_target, n_periods_total, periods_per_shift_val):
        covering_indices = []
        for i_start in range(n_periods_total):
            # Check if j_target falls within the window covered by a shift starting at i_start
            # (j_target - i_start + n_periods_total) % n_periods_total gives the relative position
            # of j_target from i_start, considering wrap-around.
            # If this relative position is less than periods_per_shift_val, then i_start covers j_target.
            if (j_target - i_start + n_periods_total) % n_periods_total < periods_per_shift_val:
                covering_indices.append(i_start)
        return covering_indices

    # Demand Coverage Constraints
    # For each period j, ensure enough drivers and crew are available
    for j in range(n_periods):
        covering_starts = get_covering_starts(j, n_periods, periods_per_shift)
        
        # Drivers demand: sum of regular and overtime drivers covering period j must meet demand
        model.addConstr(gp.quicksum(x_d[i] + y_d[i] for i in covering_starts) >= required_numbers[j],
                        f"Driver_Demand_Period_{j+1}")
        
        # Crew demand: sum of regular and overtime crew covering period j must meet demand
        model.addConstr(gp.quicksum(x_c[i] + y_c[i] for i in covering_starts) >= required_numbers[j],
                        f"Crew_Demand_Period_{j+1}")
                        
    # Late-Night Shift Fraction Constraints
    
    # Total regular driver starts in late-night periods (periods 4 and 5, 0-indexed)
    total_late_night_drivers = gp.quicksum(x_d[p] for p in late_night_periods)
    # Total regular driver starts across all periods
    total_regular_drivers = gp.quicksum(x_d[i] for i in range(n_periods))
    
    # Constraint: total_late_night_drivers <= max_night_driver_fraction * total_regular_drivers
    # This is rewritten as a linear constraint: total_late_night_drivers - fraction * total_regular_drivers <= 0
    model.addConstr(total_late_night_drivers - max_night_driver_fraction * total_regular_drivers <= 0,
                    "Max_Night_Driver_Fraction")
    
    # Total regular crew starts in late-night periods
    total_late_night_crew = gp.quicksum(x_c[p] for p in late_night_periods)
    # Total regular crew starts across all periods
    total_regular_crew = gp.quicksum(x_c[i] for i in range(n_periods))
    
    # Constraint: total_late_night_crew <= max_night_crew_fraction * total_regular_crew
    model.addConstr(total_late_night_crew - max_night_crew_fraction * total_regular_crew <= 0,
                    "Max_Night_Crew_Fraction")
                    
    # Total Overtime Limit Constraint
    # Sum of all overtime shifts (drivers + crew, all periods) must not exceed max_overtime_shifts
    total_overtime_shifts = gp.quicksum(y_d[i] for i in range(n_periods)) + \
                            gp.quicksum(y_c[i] for i in range(n_periods))
    model.addConstr(total_overtime_shifts <= max_overtime_shifts, "Total_Overtime_Limit")
    
    # --- 7. Solve the model ---
    model.optimize()
    
    # --- 8. Print results ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case no optimal solution is found (e.g., infeasible or unbounded)
        print(f"No optimal solution found. Model status: {model.status}")

if __name__ == "__main__":
    solve_revised_bus_scheduling()
