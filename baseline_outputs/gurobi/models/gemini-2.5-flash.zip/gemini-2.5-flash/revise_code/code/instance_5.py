import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    # --- Load data ---
    script_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(script_dir, '..', 'data', 'table_1.csv')
    params_path = os.path.join(script_dir, '..', 'data', 'general_parameters.csv')
    
    df = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)
    
    # Extract general parameters
    budget = float(params[params['Parameter_Name'] == 'budget']['Value'].iloc[0])
    food_intake = float(params[params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
    weekday_budget_share = float(params[params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
    max_prep_time_weekday = float(params[params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
    max_prep_time_weekend = float(params[params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
    weekend_protein_ban = int(params[params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
    veg_balance_penalty = float(params[params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])
    
    # Fill missing fiber content with 0 (for proteins, which have no fiber)
    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)
    
    # Convert food intake from grams to 100g units for consistency with other data
    food_intake_100g = food_intake / 100.0
    
    # Create dictionaries for food properties
    foods = df['Food'].tolist()
    types = df.set_index('Food')['Type'].to_dict()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict() # New parameter
    
    proteins = [f for f in foods if types[f] == 'protein']
    vegetables = [f for f in foods if types[f] == 'vegetable']
    
    meals = ['weekday', 'weekend']
    max_prep_time = {'weekday': max_prep_time_weekday, 'weekend': max_prep_time_weekend}
    
    # --- Create Gurobi model ---
    model = gp.Model("Maximize_Fiber_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # --- Variables ---
    # x[f, m]: amount of food f in 100g for meal m
    x = model.addVars(foods, meals, name="x", lb=0.0, vtype=GRB.CONTINUOUS)
    
    # y[f, m]: binary, 1 if food f is included in meal m
    y = model.addVars(foods, meals, name="y", vtype=GRB.BINARY)
    
    # y_protein_selected[p]: binary, 1 if protein p is selected for the week's shopping logic
    y_protein_selected = model.addVars(proteins, name="y_protein_selected", vtype=GRB.BINARY)
    
    # Variables for vegetable balance penalty (absolute difference)
    diff_veg = model.addVar(name="diff_veg", lb=-GRB.INFINITY, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS)
    abs_diff_veg = model.addVar(name="abs_diff_veg", lb=0.0, vtype=GRB.CONTINUOUS)
    
    # --- Objective ---
    # Maximize total fiber intake across both meals, minus penalty for vegetable swings
    total_fiber = gp.quicksum(fiber[f] * x[f, m] for f in foods for m in meals)
    
    model.setObjective(total_fiber - veg_balance_penalty * abs_diff_veg, GRB.MAXIMIZE)
    
    # --- Constraints ---
    
    # 1. Total food intake per meal: Each meal must meet the specific total food intake requirement
    model.addConstrs((gp.quicksum(x[f, m] for f in foods) == food_intake_100g
                      for m in meals), name="total_food_intake")
    
    # 2. Budget constraints: Total budget is split between weekday and weekend meals
    model.addConstr(gp.quicksum(price[f] * x[f, 'weekday'] for f in foods) <= budget * weekday_budget_share,
                    name="weekday_budget")
    model.addConstr(gp.quicksum(price[f] * x[f, 'weekend'] for f in foods) <= budget * (1 - weekday_budget_share),
                    name="weekend_budget")
    
    # 3. Prep time limits per meal: Each meal must respect its maximum preparation time
    model.addConstrs((gp.quicksum(prep_time[f] * x[f, m] for f in foods) <= max_prep_time[m]
                      for m in meals), name="prep_time_limit")
    
    # 4. Linking constraints: x (amount) and y (inclusion binary)
    # M is the maximum possible amount of any single food item (total food intake in 100g units)
    M = food_intake_100g
    # If a food is included (y=1), its amount must be at least 0.1 (10g)
    model.addConstrs((x[f, m] >= 0.1 * y[f, m]
                      for f in foods for m in meals), name="min_inclusion")
    # If a food is not included (y=0), its amount must be 0. Otherwise, its amount is capped by M
    model.addConstrs((x[f, m] <= M * y[f, m]
                      for f in foods for m in meals), name="max_inclusion")
                      
    # 5. Protein shopping logic:
    # Exactly one protein type must be selected for the week's shopping
    model.addConstr(gp.quicksum(y_protein_selected[p] for p in proteins) == 1,
                    name="one_protein_type_selected")
    
    # A protein can only be used in a meal if it has been selected for the week
    model.addConstrs((y[p, m] <= y_protein_selected[p]
                      for p in proteins for m in meals), name="use_selected_protein_only")
    
    # If a protein is selected for the week, it must appear in at least one of the two meals
    model.addConstrs((y_protein_selected[p] <= y[p, 'weekday'] + y[p, 'weekend']
                      for p in proteins), name="selected_protein_must_appear")
    
    # 6. Exactly one protein source per meal (conditional on weekend_protein_ban)
    # Weekday meal always requires exactly one protein
    model.addConstr(gp.quicksum(y[p, 'weekday'] for p in proteins) == 1,
                    name="one_protein_weekday")
    # Weekend meal requires one protein if weekend_protein_ban is 0, or no protein if it's 1
    model.addConstr(gp.quicksum(y[p, 'weekend'] for p in proteins) == (1 - weekend_protein_ban),
                    name="one_protein_weekend")
    
    # 7. At least two kinds of vegetables per meal
    model.addConstrs((gp.quicksum(y[v, m] for v in vegetables) >= 2
                      for m in meals), name="at_least_two_vegetables")
                      
    # 8. Vegetable balance penalty constraints:
    # Calculate total vegetable amounts for each meal
    total_veg_weekday = gp.quicksum(x[v, 'weekday'] for v in vegetables)
    total_veg_weekend = gp.quicksum(x[v, 'weekend'] for v in vegetables)
    
    # Define the difference variable
    model.addConstr(diff_veg == total_veg_weekday - total_veg_weekend, name="diff_veg_def")
    
    # Define the absolute difference variable using auxiliary constraints
    model.addConstr(abs_diff_veg >= diff_veg, name="abs_diff_veg_pos")
    model.addConstr(abs_diff_veg >= -diff_veg, name="abs_diff_veg_neg")
    
    # --- Solve the problem ---
    model.optimize()
    
    # --- Output results ---
    if model.status == GRB.OPTIMAL:
        return round(model.ObjVal, 4)
    else:
        # Handle cases where no optimal solution is found (e.g., infeasible)
        return "No optimal solution found"

if __name__ == '__main__':
    print(f"FINAL_OBJ_VALUE: {solve()}")
