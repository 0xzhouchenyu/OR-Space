import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Start of load_data function (adapted from src/utils.py for root execution) ---
def load_data():
    # Adjust base path for the script being executed from the root directory
    # The 'data' folder is a direct subdirectory of the root.
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    students = []
    with open(os.path.join(base, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            s = {'Student_ID': int(row['Student_ID']),
                 'Wage_CNY_per_hour': float(row['Wage_CNY_per_hour'])}
            for d in ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']:
                s[d] = float(row[d])
            students.append(s)
    
    params = {}
    with open(os.path.join(base, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = row['Value']
            try:
                params[name] = int(val)
            except ValueError:
                try:
                    params[name] = float(val)
                except ValueError:
                    params[name] = val
    
    return students, params
# --- End of load_data function ---

def main():
    students_data, params = load_data()
    
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    student_ids = [s['Student_ID'] for s in students_data]
    
    # Calculate total operating hours per day (8:00 AM to 10:00 PM is 14 hours)
    hours_per_day = 14 
    
    # Extract parameters from the loaded data
    min_undergrad_hours = params['min_undergrad_hours']
    min_grad_hours = params['min_grad_hours']
    max_shifts_per_student = params['max_shifts_per_student']
    max_students_per_day = params['max_students_per_day']
    daily_open_fee_cny = params['daily_open_fee_cny'] # New parameter from revision
    min_grad_weekly_coverage_hours = params['min_grad_weekly_coverage_hours'] # New parameter from revision
    
    # Identify graduate students (as per revised business requirements: Students 1-4 undergrad, 5-6 grad)
    grad_students_ids = {5, 6}
    undergrad_students_ids = {s_id for s_id in student_ids if s_id not in grad_students_ids}
    
    # Prepare data for Gurobi model
    wage = {s['Student_ID']: s['Wage_CNY_per_hour'] for s in students_data}
    avail = {(s['Student_ID'], d): s[d] for s in students_data for d in days}
    
    # Create a new Gurobi model
    model = gp.Model("Lab_Scheduling_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision Variables
    # x[i, d]: Continuous variable representing hours student i works on day d
    x = model.addVars(student_ids, days, vtype=GRB.CONTINUOUS, name="hours_worked", lb=0)
    
    # y[i, d]: Binary variable, 1 if student i works on day d, 0 otherwise
    # This variable also serves as z[i,d] for the daily_open_fee_cny as per problem description.
    y = model.addVars(student_ids, days, vtype=GRB.BINARY, name="works_on_day")
    
    # Objective Function: Minimize total wages + fixed daily open fees
    total_wage_cost = gp.quicksum(wage[i] * x[i, d] for i in student_ids for d in days)
    total_fixed_fee_cost = gp.quicksum(daily_open_fee_cny * y[i, d] for i in student_ids for d in days)
    
    model.setObjective(total_wage_cost + total_fixed_fee_cost, GRB.MINIMIZE)
    
    # Constraints
    
    # C1: Daily Coverage - Exactly 14 hours per day
    # The lab must be staffed for 14 hours each day.
    for d in days:
        model.addConstr(gp.quicksum(x[i, d] for i in student_ids) == hours_per_day, f"Daily_Coverage_{d}")
    
    # C2: Link x and y variables, and respect daily availability
    # If a student works (x[i,d] > 0), then y[i,d] must be 1.
    # Also, hours worked cannot exceed the student's daily availability.
    for i in student_ids:
        for d in days:
            # M = avail[i,d] acts as a big-M value. If y[i,d]=0, x[i,d] must be 0.
            # If y[i,d]=1, x[i,d] <= avail[i,d].
            model.addConstr(x[i, d] <= avail[i, d] * y[i, d], f"Link_xy_Avail_{i}_{d}")
    
    # C3: Max shifts per student per week
    # No student may be scheduled on more than max_shifts_per_student days per week.
    for i in student_ids:
        model.addConstr(gp.quicksum(y[i, d] for d in days) <= max_shifts_per_student, f"Max_Shifts_{i}")
    
    # C4: Max students per day
    # No more than max_students_per_day different students can share coverage on any one day.
    for d in days:
        model.addConstr(gp.quicksum(y[i, d] for i in student_ids) <= max_students_per_day, f"Max_Students_Day_{d}")
    
    # C5: Minimum weekly hours per student
    # Each undergraduate and graduate student must meet their respective weekly minimum hours.
    for i in student_ids:
        if i in grad_students_ids:
            model.addConstr(gp.quicksum(x[i, d] for d in days) >= min_grad_hours, f"Min_Weekly_Hours_Grad_{i}")
        else: # Undergraduate student
            model.addConstr(gp.quicksum(x[i, d] for d in days) >= min_undergrad_hours, f"Min_Weekly_Hours_Undergrad_{i}")
            
    # C6: New constraint - Minimum total weekly hours collectively covered by graduate students
    # Graduate students together must cover at least min_grad_weekly_coverage_hours across the week.
    model.addConstr(gp.quicksum(x[i, d] for i in grad_students_ids for d in days) >= min_grad_weekly_coverage_hours, "Min_Grad_Weekly_Coverage")
    
    # Optimize the model
    model.optimize()
    
    # Output the final objective value as required
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"Optimization failed with status: {model.status}")

if __name__ == "__main__":
    main()
