import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # --- 1. Data Parsing ---
    # Construct the path to the data directory relative to the script's location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()

    max_children_trip = int(params['max_children_trip'])
    min_children_trip = int(params['min_children_trip'])
    max_distinct_children_trip = int(params['max_distinct_children_trip'])
    total_cost_budget = int(params['total_cost_budget'])
    bonus_saving = int(params['bonus_saving'])
    min_bob_days = int(params['min_bob_days'])

    # Read table_1 for children and costs
    children = []
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Child'].strip()
            cost = int(row['Cost'].strip())
            children.append(name)
            costs[name] = cost
    
    days = [1, 2] # Define the two days of the trip

    # --- 2. Model Creation ---
    model = gp.Model("FamilyTripTwoDay")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- 3. Decision Variables ---
    # x[child, day]: Binary variable, 1 if child is taken on the specified day, 0 otherwise
    x = model.addVars(children, days, vtype=GRB.BINARY, name="x")

    # y[child]: Binary variable, 1 if child is taken on BOTH days, 0 otherwise (for bonus saving)
    y = model.addVars(children, vtype=GRB.BINARY, name="y")

    # z[child]: Binary variable, 1 if child is taken on AT LEAST ONE day, 0 otherwise (for distinct children count)
    z = model.addVars(children, vtype=GRB.BINARY, name="z")

    # --- 4. Objective Function ---
    # Calculate total per-day cost
    total_per_day_cost = gp.quicksum(costs[child] * x[child, day] for child in children for day in days)
    
    # Calculate total bonus saving for children attending both days
    total_bonus_saving = bonus_saving * gp.quicksum(y[child] for child in children)

    # Objective: Minimize (Total per-day cost - Total bonus saving)
    model.setObjective(total_per_day_cost - total_bonus_saving, GRB.MINIMIZE)

    # --- 5. Constraints ---

    # Link y[child] to x[child, day]: y[child] is 1 if and only if x[child,1] and x[child,2] are both 1
    for child in children:
        model.addConstr(y[child] <= x[child, 1], f"y_link_{child}_day1")
        model.addConstr(y[child] <= x[child, 2], f"y_link_{child}_day2")
        model.addConstr(y[child] >= x[child, 1] + x[child, 2] - 1, f"y_link_{child}_both")

    # Link z[child] to x[child, day]: z[child] is 1 if and only if x[child,1] or x[child,2] (or both) are 1
    for child in children:
        model.addConstr(z[child] >= x[child, 1], f"z_link_{child}_day1")
        model.addConstr(z[child] >= x[child, 2], f"z_link_{child}_day2")
        model.addConstr(z[child] <= x[child, 1] + x[child, 2], f"z_link_{child}_either")

    # Daily Min/Max Children constraints
    for day in days:
        model.addConstr(gp.quicksum(x[child, day] for child in children) >= min_children_trip, f"MinChildren_Day{day}")
        model.addConstr(gp.quicksum(x[child, day] for child in children) <= max_children_trip, f"MaxChildren_Day{day}")

    # Relationship Constraints (applied per day)
    for day in days:
        # Alice and Diana cannot both be taken on the same day
        model.addConstr(x['Alice', day] + x['Diana', day] <= 1, f"AliceDianaConflict_Day{day}")
        # Bob and Charlie cannot both be taken on the same day
        model.addConstr(x['Bob', day] + x['Charlie', day] <= 1, f"BobCharlieConflict_Day{day}")
        # Charlie must be accompanied by Diana on the same day (if Charlie goes, Diana must go)
        model.addConstr(x['Charlie', day] <= x['Diana', day], f"CharlieRequiresDiana_Day{day}")
        # Diana must be accompanied by Ella on the same day (if Diana goes, Ella must go)
        model.addConstr(x['Diana', day] <= x['Ella', day], f"DianaRequiresElla_Day{day}")

    # Availability Constraints
    # Charlie can participate only on day 2
    model.addConstr(x['Charlie', 1] == 0, "CharlieOnlyDay2")
    # Diana can participate only on day 2
    model.addConstr(x['Diana', 1] == 0, "DianaOnlyDay2")
    # Alice can participate only on day 1
    model.addConstr(x['Alice', 2] == 0, "AliceOnlyDay1")

    # Limit total distinct children over both days
    model.addConstr(gp.quicksum(z[child] for child in children) <= max_distinct_children_trip, "MaxDistinctChildren")

    # Cap total cost by total_cost_budget
    model.addConstr(total_per_day_cost - total_bonus_saving <= total_cost_budget, "TotalCostBudget")

    # Require at least min_bob_days days for Bob
    model.addConstr(x['Bob', 1] + x['Bob', 2] >= min_bob_days, "BobMinDays")

    # --- 6. Solve the model ---
    model.optimize()

    # --- 7. Print Solution ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible.")
    elif model.status == GRB.UNBOUNDED:
        print("Model is unbounded.")
    else:
        print(f"Optimization ended with status {model.status}")

if __name__ == "__main__":
    main()
