import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- utils.py content (copied for self-containment as per instructions) ---
def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            try:
                params[name] = float(value)
            except ValueError:
                # Keep as string if not float (e.g., unit), though for this problem all 'Value' are numbers
                params[name] = value
    return params
# --- end utils.py content ---

def solve_revised_problem():
    # Determine the base directory for data files
    # This script is assumed to be in the 'src' directory, so 'data' is in '../data'
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')

    # Load parameters from the CSV file
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Define sets for fruits and seasons
    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']

    # Extract parameters
    profits_per_acre = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons'],
    }
    total_farm_area = params['total_farm_area']
    min_apples_to_pears_ratio = params['min_apples_to_pears_ratio']
    min_apples_to_lemons_ratio = params['min_apples_to_lemons_ratio']
    oranges_to_lemons_ratio = params['oranges_to_lemons_ratio']
    max_fruit_types = int(params['max_fruit_types']) # Cast to int as it's a count

    water_per_acre = {
        f: {s: params[f'water_per_acre_{f}_{s}'] for s in seasons}
        for f in fruits
    }
    water_cap = {
        s: params[f'water_cap_{s}'] for s in seasons
    }
    total_water_budget = params['total_water_budget']
    min_annual_water_per_fruit = params['min_annual_water_per_fruit']
    diversification_reward = params['diversification_reward']

    # Create a new Gurobi model
    model = gp.Model("Farm_Optimization_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- Decision Variables ---
    # x[f, s]: Acres of fruit 'f' grown in season 's' (continuous, non-negative)
    x = model.addVars(fruits, seasons, name="x", vtype=GRB.CONTINUOUS, lb=0.0)

    # y[f]: Binary variable, 1 if fruit 'f' is grown at all annually (i.e., meets min water threshold), 0 otherwise
    y = model.addVars(fruits, name="y", vtype=GRB.BINARY)

    # z_diversification: Binary variable, 1 if diversification reward is earned, 0 otherwise
    z_diversification = model.addVar(name="z_diversification", vtype=GRB.BINARY)

    # --- Helper Expressions for Annual Totals ---
    # Annual acreage for each fruit (sum of spring and autumn)
    x_annual = {f: gp.quicksum(x[f, s] for s in seasons) for f in fruits}

    # Annual water usage for each fruit (sum of spring and autumn water demand)
    water_annual_fruit = {
        f: gp.quicksum(water_per_acre[f][s] * x[f, s] for s in seasons)
        for f in fruits
    }

    # Total annual water usage across all fruits and seasons
    total_annual_water_usage = gp.quicksum(water_annual_fruit[f] for f in fruits)

    # --- Objective Function ---
    # Maximize total profit from fruit sales across both seasons, plus diversification reward
    objective = gp.quicksum(profits_per_acre[f] * x[f, s] for f in fruits for s in seasons) \
                + diversification_reward * z_diversification
    model.setObjective(objective, GRB.MAXIMIZE)

    # --- Constraints ---

    # 1. Seasonal Land Use Constraints: Total acreage in any season cannot exceed total_farm_area
    for s in seasons:
        model.addConstr(gp.quicksum(x[f, s] for f in fruits) <= total_farm_area, f"Land_Cap_{s}")

    # 2. Annual Land Ratio Constraints: Based on total annual acreage for each fruit
    model.addConstr(x_annual['apples'] >= min_apples_to_pears_ratio * x_annual['pears'], "Ratio_Apples_Pears")
    model.addConstr(x_annual['apples'] >= min_apples_to_lemons_ratio * x_annual['lemons'], "Ratio_Apples_Lemons")
    model.addConstr(x_annual['oranges'] == oranges_to_lemons_ratio * x_annual['lemons'], "Ratio_Oranges_Lemons")

    # 3. Water Constraints
    # Seasonal water caps: Total water usage in any season cannot exceed its cap
    for s in seasons:
        model.addConstr(gp.quicksum(water_per_acre[f][s] * x[f, s] for f in fruits) <= water_cap[s], f"Water_Cap_{s}")

    # Total annual water budget: Combined water usage over the year cannot exceed the total budget
    model.addConstr(total_annual_water_usage <= total_water_budget, "Total_Water_Budget")

    # 4. Link y[f] (fruit type grown) to annual water usage and minimum commitment
    # M_water is a large number, representing the maximum possible annual water usage for a single fruit type.
    # This ensures that if y[f] is 0, water_annual_fruit[f] must be 0.
    # A safe upper bound for M_water is total_water_budget (if only one fruit type is grown) or even higher.
    M_water = total_water_budget * len(fruits) # Max possible water if all fruits used max water budget

    for f in fruits:
        # If y[f] is 1, then annual water usage for fruit 'f' must meet the minimum threshold
        model.addConstr(water_annual_fruit[f] >= min_annual_water_per_fruit * y[f], f"Min_Water_Commitment_{f}")
        # If y[f] is 0, then annual water usage for fruit 'f' must be 0 (and thus no acreage for that fruit)
        model.addConstr(water_annual_fruit[f] <= M_water * y[f], f"Link_Water_Y_{f}")

    # 5. Max Fruit Types Constraint: No more than max_fruit_types can be genuinely grown
    model.addConstr(gp.quicksum(y[f] for f in fruits) <= max_fruit_types, "Max_Fruit_Types_Count")

    # 6. Diversification Reward Logic
    # The reward is earned if *exactly* max_fruit_types (which is 2) fruits are genuinely grown.
    num_fruits_grown = gp.quicksum(y[f] for f in fruits)

    # If z_diversification is 1, then num_fruits_grown must be equal to max_fruit_types
    model.addConstr(num_fruits_grown >= max_fruit_types * z_diversification, "Diversification_Link_Lower")
    model.addConstr(num_fruits_grown <= max_fruit_types - (1 - z_diversification), "Diversification_Link_Upper")
    # These two constraints together ensure:
    # - If z_diversification = 1, then num_fruits_grown >= max_fruit_types AND num_fruits_grown <= max_fruit_types,
    #   implying num_fruits_grown == max_fruit_types.
    # - If z_diversification = 0, then num_fruits_grown >= 0 AND num_fruits_grown <= max_fruit_types - 1,
    #   implying num_fruits_grown < max_fruit_types.
    # This correctly models z_diversification = 1 IFF num_fruits_grown == max_fruit_types.

    # Optimize the model
    model.optimize()

    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")
        # In case of infeasibility or other issues, print status
        # print(f"Model status: {model.status}")

# Call the solver function
if __name__ == "__main__":
    solve_revised_problem()
