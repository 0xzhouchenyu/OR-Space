import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    """
    Returns the absolute path to a file in the data directory.
    Assumes the script is run from the workspace root.
    """
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)

def solve():
    # Load data
    table_1 = pd.read_csv(get_data_path('table_1.csv'))
    table_2 = pd.read_csv(get_data_path('table_2.csv'))
    params = pd.read_csv(get_data_path('general_parameters.csv'))

    # Parse parameters
    def get_param_value(param_name, dtype=str):
        value = params.loc[params['Parameter_Name'] == param_name, 'Value'].values[0]
        if dtype == bool:
            return str(value).strip().lower() == 'true'
        return dtype(value)

    min_contract_types = get_param_value('min_contract_types', int)
    max_contract_types = get_param_value('max_contract_types', int)
    mutual_exclusion = get_param_value('mutual_exclusion_1_and_4', bool)
    onboarding_loss_units = get_param_value('onboarding_loss_units', int)
    expedited_onboarding_fee = get_param_value('expedited_onboarding_fee', float)
    monthly_max_parallel_contracts = get_param_value('monthly_max_parallel_contracts', int)
    min_area_per_contract_units = get_param_value('min_area_per_contract_units', int)
    activation_fee_per_contract = get_param_value('activation_fee_per_contract', float)

    # Convert required area to units of 100 ㎡
    demands = {int(row['Month']): float(row['Required_area_㎡']) / 100.0 for _, row in table_1.iterrows()}
    costs = {int(row['Contract_length_months']): float(row['Rental_fee_per_100㎡_yuan']) for _, row in table_2.iterrows()}

    months = list(demands.keys())
    contract_lengths = list(costs.keys())
    max_month = max(months)

    # Initialize model
    model = gp.Model("Warehouse_Rental")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Define indices for variables
    # A contract can start in month i and last for j months, if i + j - 1 <= max_month
    contract_start_length_indices = [(i, j) for i in months for j in contract_lengths if i + j - 1 <= max_month]

    # Variables
    # x_units[i, j] = total 100 sqm units rented for contracts starting at month i for j months
    x_units = model.addVars(contract_start_length_indices, vtype=GRB.INTEGER, lb=0, name="x_units")
    
    # num_contracts[i, j] = number of individual contracts signed starting at month i for j months
    num_contracts = model.addVars(contract_start_length_indices, vtype=GRB.INTEGER, lb=0, name="num_contracts")

    # num_expedited[i, j] = number of contracts of type (i, j) that have expedited onboarding
    num_expedited = model.addVars(contract_start_length_indices, vtype=GRB.INTEGER, lb=0, name="num_expedited")
    
    # y_length_used[j] = 1 if contract length j is used, 0 otherwise
    y_length_used = model.addVars(contract_lengths, vtype=GRB.BINARY, name="y_length_used")

    # Objective: Minimize total rental cost
    # 1. Base rental cost for the area rented
    obj_base_rental = gp.quicksum(costs[j] * x_units[i, j] for (i, j) in contract_start_length_indices)
    # 2. Activation fees for each individual contract
    obj_activation_fees = gp.quicksum(activation_fee_per_contract * num_contracts[i, j] for (i, j) in contract_start_length_indices)
    # 3. Expedited onboarding fees for contracts that opt for it
    obj_expedited_fees = gp.quicksum(expedited_onboarding_fee * num_expedited[i, j] for (i, j) in contract_start_length_indices)

    model.setObjective(obj_base_rental + obj_activation_fees + obj_expedited_fees, GRB.MINIMIZE)

    # Constraints

    # Big M values for linking variables
    # M_big_area: Max possible total area in 100sqm units across all months
    M_big_area = sum(demands.values()) + 1 
    # M_big_num_contracts: Max possible number of contracts of a certain length
    M_big_num_contracts = int(M_big_area / min_area_per_contract_units) + 1 

    # 1. Demand fulfillment for each month (REVISED)
    for m in months:
        # Total area provided by all active contracts in month m
        total_area_provided_by_contracts = gp.quicksum(
            x_units[i, j] for (i, j) in contract_start_length_indices if i <= m and i + j - 1 >= m
        )
        
        # Onboarding loss for contracts starting in month m that are NOT expedited
        # This loss only applies in the start month (m == i)
        onboarding_loss_in_month_m = gp.quicksum(
            (num_contracts[m, j] - num_expedited[m, j]) * onboarding_loss_units
            for j in contract_lengths if (m, j) in contract_start_length_indices
        )
        
        model.addConstr(total_area_provided_by_contracts - onboarding_loss_in_month_m == demands[m], f"Demand_Month_{m}")

    # 2. Link x_units to num_contracts and min_area_per_contract_units
    for (i, j) in contract_start_length_indices:
        # Each contract must rent at least min_area_per_contract_units.
        # So, total area x_units[i,j] must be at least num_contracts[i,j] * min_area_per_contract_units.
        model.addConstr(x_units[i, j] >= num_contracts[i, j] * min_area_per_contract_units, f"MinArea_Link1_{i}_{j}")
        # If no contracts of type (i,j) are signed (num_contracts[i,j] == 0), then no area is rented (x_units[i,j] == 0).
        # If num_contracts[i,j] > 0, x_units[i,j] can be up to M_big_area.
        model.addConstr(x_units[i, j] <= M_big_area * num_contracts[i, j], f"MinArea_Link2_{i}_{j}")

    # 3. num_expedited vs num_contracts: Cannot expedite more contracts than exist
    for (i, j) in contract_start_length_indices:
        model.addConstr(num_expedited[i, j] <= num_contracts[i, j], f"Expedited_Limit_{i}_{j}")

    # 4. monthly_max_parallel_contracts: Limit the total number of active contracts in any given month
    for m in months:
        model.addConstr(
            gp.quicksum(num_contracts[i, j] for (i, j) in contract_start_length_indices if i <= m and i + j - 1 >= m)
            <= monthly_max_parallel_contracts,
            f"MaxParallelContracts_Month_{m}"
        )

    # 5. Link num_contracts to y_length_used (binary variable indicating if a contract length type is used)
    for j in contract_lengths:
        # If y_length_used[j] is 1, at least one contract of length j must be signed across all start months.
        model.addConstr(gp.quicksum(num_contracts[i, j] for i in months if (i, j) in contract_start_length_indices) >= y_length_used[j], f"Link_y_lower_{j}")
        # If y_length_used[j] is 0, no contracts of length j can be signed across all start months.
        model.addConstr(gp.quicksum(num_contracts[i, j] for i in months if (i, j) in contract_start_length_indices) <= M_big_num_contracts * y_length_used[j], f"Link_y_upper_{j}")

    # 6. Contract types limits: Minimum and maximum number of distinct contract lengths used
    model.addConstr(gp.quicksum(y_length_used[j] for j in contract_lengths) >= min_contract_types, "Min_Contract_Types")
    model.addConstr(gp.quicksum(y_length_used[j] for j in contract_lengths) <= max_contract_types, "Max_Contract_Types")

    # 7. Mutual exclusion between 1-month and 4-month contracts
    if mutual_exclusion:
        if 1 in contract_lengths and 4 in contract_lengths: # Ensure these contract lengths exist
            model.addConstr(y_length_used[1] + y_length_used[4] <= 1, "Mutual_Exclusion_1_4")

    # Solve the problem
    model.optimize()

    # Output the objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    elif model.status == GRB.INFEASIBLE:
        print("FINAL_OBJ_VALUE: Infeasible")
    elif model.status == GRB.UNBOUNDED:
        print("FINAL_OBJ_VALUE: Unbounded")
    else:
        print(f"FINAL_OBJ_VALUE: Optimization ended with status {model.status}")

if __name__ == "__main__":
    solve()
