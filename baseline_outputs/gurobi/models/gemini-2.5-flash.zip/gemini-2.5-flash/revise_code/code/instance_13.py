import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine the directory of the script and construct the path to the data folder.
    # The script is executed from the revised workspace root directory.
    # So, os.path.dirname(os.path.abspath(__file__)) will be the root directory.
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read parameters from the CSV file
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Extract specific parameter values
    profit_corn = params['profit_per_acre_corn']
    profit_wheat = params['profit_per_acre_wheat']
    profit_soybeans = params['profit_per_acre_soybeans']
    profit_sorghum = params['profit_per_acre_sorghum']
    total_area = params['total_farm_area']
    corn_wheat_ratio = params['corn_wheat_ratio']
    soybeans_sorghum_ratio = params['soybeans_sorghum_ratio']
    wheat_sorghum_ratio = params['wheat_sorghum_ratio']

    # New parameter from the revised business requirements
    MIN_CORN_ACRES = 20
    
    # Create a new Gurobi model
    m = gp.Model("Farm_Optimization")
    
    # Suppress Gurobi output
    m.setParam('OutputFlag', 0)
    
    # Decision variables: acres allocated to each crop (continuous, non-negative)
    corn = m.addVar(lb=0, name="corn")
    wheat = m.addVar(lb=0, name="wheat")
    soybeans = m.addVar(lb=0, name="soybeans")
    sorghum = m.addVar(lb=0, name="sorghum")
    
    # Binary decision variables for mutual exclusion:
    # y_corn = 1 if corn is planted, 0 otherwise
    # y_soybeans = 1 if soybeans are planted, 0 otherwise
    y_corn = m.addVar(vtype=GRB.BINARY, name="y_corn")
    y_soybeans = m.addVar(vtype=GRB.BINARY, name="y_soybeans")
    
    # Objective function: maximize total profit
    m.setObjective(profit_corn * corn + profit_wheat * wheat + \
                   profit_soybeans * soybeans + profit_sorghum * sorghum, GRB.MAXIMIZE)
    
    # Constraints
    # 1. Total farm area constraint
    m.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area_constraint")
    
    # 2. Corn-wheat ratio constraint
    m.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio_constraint")
    
    # 3. Soybeans-sorghum ratio constraint
    m.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio_constraint")
    
    # 4. Wheat-sorghum equality constraint
    m.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_equality_constraint")
    
    # 5. Mutual exclusion constraint: corn and soybeans cannot both be planted
    m.addConstr(y_corn + y_soybeans <= 1, "mutual_exclusion_corn_soybeans")
    
    # 6. Linking binary variables to continuous acreage variables (Big M constraints)
    # If y_corn is 0, corn must be 0. If y_corn is 1, corn can be up to total_area.
    m.addConstr(corn <= total_area * y_corn, "link_corn_upper")
    # If y_soybeans is 0, soybeans must be 0. If y_soybeans is 1, soybeans can be up to total_area.
    m.addConstr(soybeans <= total_area * y_soybeans, "link_soybeans_upper")

    # 7. Minimum corn requirement: at least 20 acres of corn must be grown
    m.addConstr(corn >= MIN_CORN_ACRES, "min_corn_acres_constraint")
    
    # Optimize the model
    m.optimize()
    
    # Print the final objective value
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        # If optimization fails, print a status and a default/zero objective value
        # For this problem, given the constraints, an optimal solution is expected.
        print(f"Optimization was not successful. Gurobi status code: {m.status}")
        print(f"FINAL_OBJ_VALUE: {0.0}") # Indicate failure with 0.0 or similar

if __name__ == "__main__":
    main()
