import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Data Loading ---
# Determine the directory of the current script and construct the path to the data folder
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

# Read device data from table_1.csv
device_info = {}
devices = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        device_name = row['Device'].strip()
        devices.append(device_name)
        device_info[device_name] = {
            'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
            'max_cap': float(row['Max_Processing_Capacity_Units'].strip())
        }

# Read general parameters from general_parameters.csv
general_params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        general_params[param_name] = float(row['Value'].strip())

# Define periods as per the revised requirements
periods = ['peak', 'offpeak']

# --- Model Creation ---
model = gp.Model("MinCostProductionRevised")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# --- Decision Variables ---
# x[d, p]: Continuous variable, number of units produced on device d in period p
x = model.addVars(devices, periods, name="x", vtype=GRB.CONTINUOUS, lowBound=0)

# y[d]: Binary variable, 1 if device d is used at all (across any period), 0 otherwise.
# This variable captures the one-time 'Prep_Completion_Cost_Yuan'.
y = model.addVars(devices, name="y", vtype=GRB.BINARY)

# z[d, p]: Binary variable, 1 if device d is brought into service in period p, 0 otherwise.
# This variable captures the 'startup_cost' and 'startup_energy' for a device in a specific period.
z = model.addVars(devices, periods, name="z", vtype=GRB.BINARY)

# --- Objective Function ---
# Minimize Total Cost = (Original Prep Costs) + (Unit Production Costs) + (Startup Monetary Costs) + (Energy Costs)

obj = gp.LinExpr()

# 1. Original Preparation Completion Costs (fixed cost if device is used at all)
obj += gp.quicksum(device_info[d]['prep_cost'] * y[d] for d in devices)

# 2. Unit Production Costs (variable cost per unit produced)
obj += gp.quicksum(device_info[d]['unit_cost'] * x[d, p] for d in devices for p in periods)

# 3. Startup Monetary Costs (fixed cost for each device-period combination brought into service)
obj += general_params['startup_cost'] * gp.quicksum(z[d, p] for d in devices for p in periods)

# 4. Energy Costs (unit production energy + startup energy, multiplied by period-specific price)
for p in periods:
    period_energy_price = general_params[f'energy_price_{p}']
    
    # Energy consumed by unit production in this period
    unit_production_energy_in_period = gp.quicksum(
        general_params[f'energy_per_unit_{d}'] * x[d, p] for d in devices
    )
    
    # Energy consumed by device startups in this period
    startup_energy_in_period = gp.quicksum(
        general_params[f'startup_energy_{d}'] * z[d, p] for d in devices
    )
    
    obj += period_energy_price * (unit_production_energy_in_period + startup_energy_in_period)

model.setObjective(obj, GRB.MINIMIZE)

# --- Constraints ---

# 1. Total Production Requirement: The sum of all units produced must equal the required units.
model.addConstr(gp.quicksum(x[d, p] for d in devices for p in periods) == general_params['required_units'], "TotalProduction")

# 2. Device Capacity: Total production on device d across all periods cannot exceed its maximum processing capacity.
for d in devices:
    model.addConstr(gp.quicksum(x[d, p] for p in periods) <= device_info[d]['max_cap'], f"DeviceCapacity_{d}")

# 3. Linking x[d,p] to z[d,p]: If units are produced on device d in period p (x[d,p] > 0),
#    then device d must be brought into service in period p (z[d,p] must be 1).
#    Using Max_Processing_Capacity_Units as a Big M.
for d in devices:
    for p in periods:
        model.addConstr(x[d, p] <= device_info[d]['max_cap'] * z[d, p], f"Link_Production_Startup_{d}_{p}")

# 4. Linking z[d,p] to y[d]: If device d is brought into service in any period (z[d,p] = 1),
#    then device d must be considered "used" (y[d] must be 1).
for d in devices:
    for p in periods:
        model.addConstr(z[d, p] <= y[d], f"Link_Startup_DeviceUsed_{d}_{p}")

# 5. Peak Energy Budget: Total energy consumed in the peak period must not exceed the peak energy budget.
peak_energy_consumption = gp.quicksum(
    general_params[f'energy_per_unit_{d}'] * x[d, 'peak'] + 
    general_params[f'startup_energy_{d}'] * z[d, 'peak'] 
    for d in devices
)
model.addConstr(peak_energy_consumption <= general_params['energy_budget_peak'], "PeakEnergyBudget")

# 6. Off-peak Energy Budget: Total energy consumed in the off-peak period must not exceed the off-peak energy budget.
offpeak_energy_consumption = gp.quicksum(
    general_params[f'energy_per_unit_{d}'] * x[d, 'offpeak'] + 
    general_params[f'startup_energy_{d}'] * z[d, 'offpeak'] 
    for d in devices
)
model.addConstr(offpeak_energy_consumption <= general_params['energy_budget_offpeak'], "OffpeakEnergyBudget")

# 7. Startup Monetary Budget: Total monetary cost for all device startups must not exceed the startup budget.
total_startup_spend = general_params['startup_cost'] * gp.quicksum(z[d, p] for d in devices for p in periods)
model.addConstr(total_startup_spend <= general_params['startup_budget'], "StartupMonetaryBudget")

# --- Solve Model ---
model.optimize()

# --- Print Results ---
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"Model did not solve to optimality. Status: {model.status}")
