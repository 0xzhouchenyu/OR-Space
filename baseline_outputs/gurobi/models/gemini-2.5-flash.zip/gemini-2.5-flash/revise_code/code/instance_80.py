import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions (copied from src/utils.py and adapted for self-containment) ---

def load_csv(filename):
    """Load a CSV file and return a list of dictionaries."""
    # Adjust path to be relative to the script's location in the revised workspace root
    # The script is expected to be in the root, so 'data' is a direct subdirectory.
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

def load_general_parameters(filename='general_parameters.csv'):
    """Load general parameters into a dictionary."""
    rows = load_csv(filename)
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = row['Value']
        # Try to convert to numeric (int or float)
        try:
            if '.' in value:
                params[name] = float(value)
            else:
                params[name] = int(value)
        except ValueError:
            params[name] = value # Keep as string if not numeric
    return params

def load_task_methods(filename='table_1.csv'):
    """Load task-method data."""
    rows = load_csv(filename)
    data = []
    for row in rows:
        data.append({
            'Task': row['Task'],
            'Method': row['Method'],
            'Effective_Hours': float(row['Effective_Hours']),
            'Fixed_Cost': float(row['Fixed_Cost'])
        })
    return data

# --- Main script ---

# Load data from the revised data files
params = load_general_parameters()
task_methods_raw = load_task_methods()

# Extract parameters from the loaded data
skilled_wage = params['skilled_worker_weekly_wage']
laborer_wage = params['laborer_weekly_wage']
skilled_hours = params['skilled_worker_weekly_hours']
laborer_hours = params['laborer_weekly_hours']
max_skilled = params['max_skilled_workers']
max_laborers = params['max_laborers']
min_skilled_task3_B = params['min_skilled_workers_task3_methodB']
skilled_hiring_ratio = params['skilled_worker_hiring_ratio']

# Task-specific skill balance parameters (new in revision)
min_skilled_share = {
    'Task_1': params['min_skilled_share_task1'],
    'Task_2': params['min_skilled_share_task2'],
    'Task_3': params['min_skilled_share_task3'],
}
max_skilled_share = {
    'Task_1': params['max_skilled_share_task1'],
    'Task_2': params['max_skilled_share_task2'],
    'Task_3': params['max_skilled_share_task3'],
}

# Define sets for tasks and methods
tasks = ['Task_1', 'Task_2', 'Task_3']
methods = ['Method_A', 'Method_B']

# Build dictionary: (task, method) -> {Effective_Hours, Fixed_Cost} for easy lookup
tm_data = {}
for row in task_methods_raw:
    key = (row['Task'], row['Method'])
    tm_data[key] = row

# Create the Gurobi model
model = gp.Model("WorkerAllocation")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# --- Decision Variables ---

# y[t, m]: Binary variable, 1 if method 'm' is chosen for task 't'
y = model.addVars(tasks, methods, vtype=GRB.BINARY, name="y")

# s[t, m]: Continuous variable, number of skilled workers assigned to task 't' if method 'm' is chosen
s = model.addVars(tasks, methods, vtype=GRB.CONTINUOUS, lb=0, name="s")

# l[t, m]: Continuous variable, number of laborers assigned to task 't' if method 'm' is chosen
l = model.addVars(tasks, methods, vtype=GRB.CONTINUOUS, lb=0, name="l")

# total_skilled: Continuous variable, total number of skilled workers hired across all tasks
total_skilled = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="total_skilled")

# total_laborers: Continuous variable, total number of laborers hired across all tasks
total_laborers = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="total_laborers")

# s_task[t]: Auxiliary continuous variable, total skilled workers assigned to task 't'
s_task = model.addVars(tasks, vtype=GRB.CONTINUOUS, lb=0, name="s_task")

# l_task[t]: Auxiliary continuous variable, total laborers assigned to task 't'
l_task = model.addVars(tasks, vtype=GRB.CONTINUOUS, lb=0, name="l_task")

# --- Objective Function ---
# Minimize total weekly cost (wages + fixed costs)
model.setObjective(skilled_wage * total_skilled + laborer_wage * total_laborers +
                   gp.quicksum(tm_data[t, m]['Fixed_Cost'] * y[t, m] for t in tasks for m in methods),
                   GRB.MINIMIZE)

# --- Constraints ---

# 1. Overall total skilled and laborers definitions
model.addConstr(total_skilled == gp.quicksum(s[t, m] for t in tasks for m in methods), "TotalSkilledDef")
model.addConstr(total_laborers == gp.quicksum(l[t, m] for t in tasks for m in methods), "TotalLaborersDef")

# 2. Auxiliary task-level totals (sum of workers for a task across its methods)
for t in tasks:
    model.addConstr(s_task[t] == gp.quicksum(s[t, m] for m in methods), f"STaskDef_{t}")
    model.addConstr(l_task[t] == gp.quicksum(l[t, m] for m in methods), f"LTaskDef_{t}")

# 3. Exactly one method must be chosen for each task
for t in tasks:
    model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1, f"OneMethod_{t}")

# 4. Hours requirement and linking worker assignments to chosen methods (using Big-M)
M_big = 10000 # A sufficiently large number to link binary and continuous variables

for t in tasks:
    for m in methods:
        req_hours = tm_data[t, m]['Effective_Hours']
        
        # Hours constraint: The chosen method must meet its effective hours requirement
        model.addConstr(skilled_hours * s[t, m] + laborer_hours * l[t, m] >= req_hours * y[t, m],
                        f"Hours_{t}_{m}")
        
        # Linking constraints: If a method is NOT chosen (y[t,m]=0), no workers can be assigned to it.
        # If y[t,m]=1, s[t,m] and l[t,m] can take any value up to M_big (which is effectively unbounded for practical purposes).
        model.addConstr(s[t, m] <= M_big * y[t, m], f"LinkS_{t}_{m}")
        model.addConstr(l[t, m] <= M_big * y[t, m], f"LinkL_{t}_{m}")

# 5. Maximum overall worker limits
model.addConstr(total_skilled <= max_skilled, "MaxSkilled")
model.addConstr(total_laborers <= max_laborers, "MaxLaborers")

# 6. Overall skilled worker hiring ratio constraint
model.addConstr(total_skilled <= skilled_hiring_ratio * total_laborers, "SkilledRatio")

# 7. Exclusion rule: Task 1 using Method B excludes Task 3 using Method A
model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1, "ExclusionRule")

# 8. Minimum skilled workers for Task 3 if Method B is chosen
model.addConstr(s['Task_3', 'Method_B'] >= min_skilled_task3_B * y['Task_3', 'Method_B'], "MinSkilledTask3B")

# 9. NEW: Task-level skill-balance bands
# For each task, the proportion of skilled workers must be within specified bounds.
# s_task[t] / (s_task[t] + l_task[t]) >= min_skilled_share[t]
# s_task[t] / (s_task[t] + l_task[t]) <= max_skilled_share[t]
# These are linearized as:
# (1 - min_share) * s_task[t] - min_share * l_task[t] >= 0
# (1 - max_share) * s_task[t] - max_share * l_task[t] <= 0
for t in tasks:
    model.addConstr((1 - min_skilled_share[t]) * s_task[t] - min_skilled_share[t] * l_task[t] >= 0,
                    f"MinSkilledShare_{t}")
    model.addConstr((1 - max_skilled_share[t]) * s_task[t] - max_skilled_share[t] * l_task[t] <= 0,
                    f"MaxSkilledShare_{t}")

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: No optimal solution found")
