import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    # Determine the base directory of the script.
    # If the script is in the root, base_dir is the root.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general parameters from general_parameters.csv
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    mall_total_space = params['mall_total_space']
    rent_percentage = params['rent_percentage'] / 100.0 # Convert percentage to a multiplier
    common_area_factor = params['common_area_factor']
    general_merchandise_third_store_concession = params['general_merchandise_third_store_concession']
    # catering_third_store_security_threshold is descriptive, not directly used in the model logic
    catering_third_store_security_cost = params['catering_third_store_security_cost']
    
    # Read store data from table_1.csv
    stores_data = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            store_type = row['Store_Type'].strip()
            area_per_shop = int(row['Area_per_Shop_m2'].strip())
            min_shops = int(row['Min'].strip())
            max_shops = int(row['Max'].strip())
            
            profits_per_store_by_count = {}
            # Iterate through possible profit columns (Profit_1_Store, Profit_2_Stores, Profit_3_Stores)
            for k in range(1, 4): # Max profit count is 3 based on column names
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits_per_store_by_count[k] = float(val)
            
            # If 0 stores are allowed (min_shops = 0), their profit and area contribution is 0.
            if 0 not in profits_per_store_by_count:
                profits_per_store_by_count[0] = 0.0 
            
            stores_data.append({
                'name': store_type,
                'area': area_per_shop,
                'min': min_shops,
                'max': max_shops,
                'profits': profits_per_store_by_count # per-store profit when n stores of this type
            })
    
    # Create Gurobi model
    model = gp.Model("ShoppingMallLeaseOptimization")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision Variables:
    # y[store_name, k] is a binary variable, 1 if k stores of 'store_name' type are chosen, 0 otherwise.
    y = {}
    for store_info in stores_data:
        store_name = store_info['name']
        min_n = store_info['min']
        max_n = store_info['max']
        for k in range(min_n, max_n + 1):
            y[store_name, k] = model.addVar(vtype=GRB.BINARY, name=f"y_{store_name}_{k}")
    
    # Constraints:
    
    # 1. Exactly one count for each store type must be selected.
    for store_info in stores_data:
        store_name = store_info['name']
        min_n = store_info['min']
        max_n = store_info['max']
        model.addConstr(gp.quicksum(y[store_name, k] for k in range(min_n, max_n + 1)) == 1,
                        name=f"one_count_for_{store_name}")
    
    # 2. Total space constraint, considering common area factor.
    total_occupied_area_expression = gp.quicksum(
        y[store_info['name'], k] * k * store_info['area']
        for store_info in stores_data
        for k in range(store_info['min'], store_info['max'] + 1)
    )
    model.addConstr(total_occupied_area_expression * common_area_factor <= mall_total_space, 
                    name="total_space_constraint")
    
    # Objective Function: Maximize total rental income.
    # Total rental income = (rent_percentage * Total_Gross_Profit) - Total_Deductions_from_Rent
    
    # Calculate Total Gross Profit from all stores
    total_gross_profit_expression = gp.quicksum(
        y[store_info['name'], k] * k * store_info['profits'][k]
        for store_info in stores_data
        for k in range(store_info['min'], store_info['max'] + 1)
        if k in store_info['profits'] # Ensure profit data exists for this k (e.g., k=0 has 0 profit)
    )
    
    # Calculate total deductions from rent (concessions and costs)
    total_deductions_from_rent = 0
    
    # General Merchandise third store concession: reduces mall's rental income.
    gm_store_name = "General_Merchandise"
    gm_info = next((s for s in stores_data if s['name'] == gm_store_name), None)
    if gm_info:
        # Check if 3 stores is a possible option for General Merchandise
        if 3 in range(gm_info['min'], gm_info['max'] + 1):
            # If 3 GM stores are chosen (y[gm_store_name, 3] == 1), apply the concession
            total_deductions_from_rent += y[gm_store_name, 3] * general_merchandise_third_store_concession
    
    # Catering third store security cost: reduces mall's net rental income.
    catering_store_name = "Catering"
    catering_info = next((s for s in stores_data if s['name'] == catering_store_name), None)
    if catering_info:
        # Check if 3 stores is a possible option for Catering
        if 3 in range(catering_info['min'], catering_info['max'] + 1):
            # If 3 Catering stores are chosen (y[catering_store_name, 3] == 1), apply the cost
            total_deductions_from_rent += y[catering_store_name, 3] * catering_third_store_security_cost
    
    # Set the objective function
    objective = (rent_percentage * total_gross_profit_expression) - total_deductions_from_rent
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Optimize the model
    model.optimize()
    
    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()
