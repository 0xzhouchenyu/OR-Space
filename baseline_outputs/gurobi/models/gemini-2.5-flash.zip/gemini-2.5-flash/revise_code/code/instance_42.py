import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- utils.py content (copied for self-containment) ---
def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params
# --- end utils.py content ---

def main():
    # Construct the path to the data directory relative to the script's location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')
    
    # Load parameters from the CSV file
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Extract parameters for clarity
    a = params['a']  # Time required per furnace for the first steelmaking method
    b = params['b']  # Time required per furnace for the second steelmaking method
    k = params['k']  # Steel production per furnace batch
    d = params['d']  # Minimum total steel production requirement

    m_offpeak = params['m_offpeak']  # Fuel cost per furnace batch for method 1 in off-peak hours
    n_offpeak = params['n_offpeak']  # Fuel cost per furnace batch for method 2 in off-peak hours
    c_offpeak = params['c_offpeak']  # Maximum off-peak time available per furnace
    cap_offpeak = params['cap_offpeak'] # Plant-wide maximum off-peak time
    f_offpeak = params['f_offpeak'] # Fixed activation overhead cost if a furnace is used in off-peak hours

    m_peak = params['m_peak']    # Fuel cost per furnace batch for method 1 in peak hours
    n_peak = params['n_peak']    # Fuel cost per furnace batch for method 2 in peak hours
    c_peak = params['c_peak']    # Maximum peak time available per furnace
    cap_peak = params['cap_peak'] # Plant-wide maximum peak time
    f_peak = params['f_peak']    # Fixed activation overhead cost if a furnace is used in peak hours

    offpeak_cooldown_batch_threshold = params['offpeak_cooldown_batch_threshold']
    offpeak_cooldown_fee = params['offpeak_cooldown_fee']

    # Initialize the Gurobi model
    model = gp.Model("SteelFurnaceRevised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Define sets for easier iteration
    FURNACES = [1, 2]
    METHODS = [1, 2]
    PERIODS = ['offpeak', 'peak']

    # Decision Variables:
    # x[f, m, p]: Number of batches for furnace f, using method m, in period p (continuous, non-negative)
    x = model.addVars(FURNACES, METHODS, PERIODS, name="x", vtype=GRB.CONTINUOUS, lb=0)

    # y[f, p]: Binary variable, 1 if furnace f is used in period p, 0 otherwise (for fixed activation costs)
    y = model.addVars(FURNACES, PERIODS, name="y", vtype=GRB.BINARY)

    # z[f]: Binary variable, 1 if furnace f exceeds the off-peak cooldown threshold, 0 otherwise (for cooldown fee)
    z = model.addVars(FURNACES, name="z", vtype=GRB.BINARY)

    # Objective Function: Minimize total cost (fuel + fixed activation + cooldown fees)
    obj_fuel_cost = gp.quicksum(m_offpeak * x[f, 1, 'offpeak'] + n_offpeak * x[f, 2, 'offpeak'] for f in FURNACES) + \
                    gp.quicksum(m_peak * x[f, 1, 'peak'] + n_peak * x[f, 2, 'peak'] for f in FURNACES)

    obj_fixed_cost = gp.quicksum(f_offpeak * y[f, 'offpeak'] for f in FURNACES) + \
                     gp.quicksum(f_peak * y[f, 'peak'] for f in FURNACES)

    obj_cooldown_fee = gp.quicksum(offpeak_cooldown_fee * z[f] for f in FURNACES)

    model.setObjective(obj_fuel_cost + obj_fixed_cost + obj_cooldown_fee, GRB.MINIMIZE)

    # Constraints:

    # 1. Furnace Time Capacity (per furnace, per period)
    for f in FURNACES:
        model.addConstr(a * x[f, 1, 'offpeak'] + b * x[f, 2, 'offpeak'] <= c_offpeak, f"Furnace{f}_Time_Offpeak")
        model.addConstr(a * x[f, 1, 'peak'] + b * x[f, 2, 'peak'] <= c_peak, f"Furnace{f}_Time_Peak")

    # 2. Plant-wide Time Capacity (per period)
    model.addConstr(gp.quicksum(a * x[f, 1, 'offpeak'] + b * x[f, 2, 'offpeak'] for f in FURNACES) <= cap_offpeak, "PlantWide_Time_Offpeak")
    model.addConstr(gp.quicksum(a * x[f, 1, 'peak'] + b * x[f, 2, 'peak'] for f in FURNACES) <= cap_peak, "PlantWide_Time_Peak")

    # 3. Minimum Total Production Requirement
    total_production = gp.quicksum(k * x[f, m, p] for f in FURNACES for m in METHODS for p in PERIODS)
    model.addConstr(total_production >= d, "MinProduction")

    # 4. Link x variables to y variables (Fixed Activation Costs)
    # M_batches_per_furnace_per_period: A sufficiently large number representing the maximum possible batches
    # a single furnace can produce in a single period.
    # Max time per furnace in any period is max(c_offpeak, c_peak) = 12 hours.
    # Min time per batch is min(a, b) = 2 hours.
    # So, max batches = 12 / 2 = 6.
    M_batches_per_furnace_per_period = max(c_offpeak, c_peak) / min(a, b)

    for f in FURNACES:
        for p in PERIODS:
            total_batches_f_p = gp.quicksum(x[f, m, p] for m in METHODS)
            # If any batches are produced in period p by furnace f, y[f,p] must be 1.
            model.addConstr(total_batches_f_p <= M_batches_per_furnace_per_period * y[f, p], f"Link_y_Furnace{f}_Period{p}")

    # 5. Link x variables to z variables (Refractory Cooldown Fee)
    # M_cooldown: A sufficiently large number representing the maximum possible off-peak batches
    # a single furnace can produce.
    # Max off-peak time per furnace is c_offpeak = 12 hours.
    # Min time per batch is min(a, b) = 2 hours.
    # So, max off-peak batches = 12 / 2 = 6.
    M_cooldown = c_offpeak / min(a, b)

    for f in FURNACES:
        total_offpeak_batches_f = gp.quicksum(x[f, m, 'offpeak'] for m in METHODS)
        # If total off-peak batches for furnace f exceed the threshold, z[f] must be 1.
        model.addConstr(total_offpeak_batches_f - offpeak_cooldown_batch_threshold <= M_cooldown * z[f], f"Link_z_Furnace{f}")

    # Optimize the model
    model.optimize()

    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"Optimization did not find an optimal solution. Status: {model.status}")

if __name__ == "__main__":
    main()
