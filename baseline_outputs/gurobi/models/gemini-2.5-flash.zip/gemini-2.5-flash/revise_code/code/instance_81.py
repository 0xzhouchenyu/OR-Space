import gurobipy as gp
from gurobipy import GRB
import os
import sys

# Determine the directory where this script is located.
# The script is expected to be executed from the revised workspace root directory.
script_dir = os.path.dirname(os.path.abspath(__file__))

# Add the 'src' directory to sys.path to allow importing utils.py
sys.path.insert(0, os.path.join(script_dir, 'src'))

# Import utility functions
from utils import load_car_data, load_parameters

# Define the data directory relative to the script's execution location (root)
data_dir = os.path.join(script_dir, 'data')

# Load data
cars = load_car_data(data_dir)
params = load_parameters(data_dir)

# Extract relevant parameters
num_cars = int(params['num_cars'])
# max_length_one_side now refers to the maximum length allowed on the *single* usable side
max_length_one_side = params['max_length_one_side']

car_ids = list(cars.keys())
lengths = cars

# Calculate the total length of all cars
total_car_length = sum(lengths[i] for i in car_ids)

# Create a Gurobi model
m = gp.Model("ParkingRevised")

# Suppress Gurobi output
m.setParam('OutputFlag', 0)

# Decision variable: T represents the total length of the street occupied by party cars.
# Since all cars must be parked on a single side, T will be equal to the sum of all car lengths.
T = m.addVar(vtype=GRB.CONTINUOUS, name="TotalOccupiedLength", lb=0)

# Objective: Minimize T.
# As T is constrained to be equal to the total_car_length, this is effectively minimizing a constant.
# This setup allows Gurobi to check for feasibility and report the constant value if feasible.
m.setObjective(T, GRB.MINIMIZE)

# Constraint 1: The total occupied length (T) must be equal to the sum of all car lengths.
# This reflects the requirement that all friends' vehicles must be parked.
m.addConstr(T == total_car_length, "Set_TotalOccupiedLength")

# Constraint 2: The total occupied length (T) must not exceed the maximum allowed length for the single usable side.
# This captures the revised business rule that only one side is available and has a length limit.
m.addConstr(T <= max_length_one_side, "Max_Single_Side_Constraint")

# Optimize the model
m.optimize()

# Extract and print the solution
if m.status == GRB.OPTIMAL:
    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
elif m.status == GRB.INFEASIBLE:
    # If the model is infeasible, it means that the total length of all cars exceeds
    # the maximum allowed length for the single side. In this case, it's impossible
    # to park all cars under the given constraints.
    # As per the strict output format requiring a number, and given the objective
    # is to minimize length, an infinite value indicates that the problem cannot be solved
    # within the constraints (i.e., an infinitely large "minimum" length is required).
    print(f"FINAL_OBJ_VALUE: {float('inf')}")
else:
    # Handle other potential Gurobi statuses (e.g., UNBOUNDED, INF_OR_UNBD)
    print(f"FINAL_OBJ_VALUE: {float('nan')}")
