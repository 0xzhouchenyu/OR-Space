import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Determine the base directory for data files
# The script is executed from the revised workspace root directory.
# So, data files are in 'data/filename.csv' relative to the script.
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read property data
properties_data = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties_data.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Extract parameters
budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_risky_multiplier = params['scen_1_risky_multiplier']
scen_2_risky_multiplier = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = params['max_risky_properties']

# Calculate derived parameters for the objective function
# Expected multiplier for the risky portion of income
expected_risky_multiplier_avg = (scen_1_prob * scen_1_risky_multiplier +
                                 scen_2_prob * scen_2_risky_multiplier)
# The difference in income factor when a portion is made risky vs. dependable
# (expected_risky_multiplier_avg - 1) will be positive if risky is expected to yield more,
# and negative if less.
risky_income_factor_diff = expected_risky_multiplier_avg - 1

# Create a new Gurobi model
model = gp.Model("RealEstateInvestment")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# Decision variables:
# x[p_name]: Binary, 1 if property p_name is purchased, 0 otherwise.
# y[p_name]: Continuous, amount of property cost allocated to risky tenants for property p_name.
# z[p_name]: Binary, 1 if property p_name hosts any risky tenants, 0 otherwise.
x = {}
y = {}
z = {}

for p in properties_data:
    p_name = p['name']
    x[p_name] = model.addVar(vtype=GRB.BINARY, name=f"buy_{p_name}")
    y[p_name] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"risky_cost_allocation_{p_name}")
    z[p_name] = model.addVar(vtype=GRB.BINARY, name=f"has_risky_tenants_{p_name}")

# Objective: Maximize expected total annual income
# The objective consists of two parts for each property:
# 1. The base annual income if the property is purchased (p['income'] * x[p['name']]).
# 2. The additional expected income (or loss) from allocating a portion to risky tenants.
#    This is calculated as (risky_cost_allocated / total_property_cost) * base_income * (expected_risky_multiplier_avg - 1).
model.setObjective(
    gp.quicksum(p['income'] * x[p['name']] +
                (y[p['name']] / p['cost']) * p['income'] * risky_income_factor_diff
                for p in properties_data),
    GRB.MAXIMIZE
)

# Constraints

# 1. Budget constraint: Total cost of purchased properties must not exceed the budget.
model.addConstr(
    gp.quicksum(p['cost'] * x[p['name']] for p in properties_data) <= budget,
    "Budget_Constraint"
)

# 2. Exclusion constraint: If Property 4 is purchased, Property 3 cannot be purchased.
model.addConstr(x['Property_4'] + x['Property_3'] <= 1, "Property4_Excludes_Property3")

# 3. Risky allocation only if property is purchased AND within per-property risky cap.
#    y[p_name] <= per_property_risky_cap * p['cost'] * x[p['name']]
#    If x[p_name] is 0, y[p_name] must be 0.
#    If x[p_name] is 1, y[p_name] is capped at per_property_risky_cap * p['cost'].
for p in properties_data:
    p_name = p['name']
    model.addConstr(
        y[p_name] <= per_property_risky_cap * p['cost'] * x[p_name],
        f"PerPropertyRiskyCap_{p_name}"
    )

# 4. Link y to z: If y[p_name] (risky cost allocation) is positive, then z[p_name] (has risky tenants) must be 1.
#    y[p_name] <= p['cost'] * z[p_name]
#    p['cost'] serves as a Big M. If y[p_name] > 0, z[p_name] must be 1. If y[p_name] = 0, z[p_name] can be 0 or 1.
#    The objective and other constraints will naturally push z[p_name] to 0 if y[p_name] is 0 to minimize costs/sums.
for p in properties_data:
    p_name = p['name']
    model.addConstr(
        y[p_name] <= p['cost'] * z[p_name],
        f"Link_y_to_z_{p_name}"
    )

# 5. Link z to x: A property can only host risky tenants if it is purchased.
#    z[p_name] <= x[p_name]
for p in properties_data:
    p_name = p['name']
    model.addConstr(
        z[p_name] <= x[p_name],
        f"Link_z_to_x_{p_name}"
    )

# 6. Total risky exposure budget: Maximum total acquisition cost of properties that host any risky tenants.
model.addConstr(
    gp.quicksum(p['cost'] * z[p['name']] for p in properties_data) <= total_risky_budget,
    "TotalRiskyExposureBudget"
)

# 7. Maximum number of properties that may have any risky tenants.
model.addConstr(
    gp.quicksum(z[p['name']] for p in properties_data) <= max_risky_properties,
    "MaxRiskyProperties"
)

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # Handle cases where an optimal solution is not found
    print("Optimization did not find an optimal solution.")
    # For debugging, you might want to print the status code:
    # print(f"Model status: {model.status}")
