import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions (copied and adapted from src/utils.py for self-containment) ---

def load_coverage_data(data_dir):
    """Load the coverage data from table_1.csv.
    
    Returns:
        areas: list of all area codes
        coverage: dict mapping each area to the set of areas it can cover
    """
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)  # skip header
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            # The covered areas are in the second column onwards, but they might be split across columns
            # because the CSV has commas within the coverage list
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    
    return areas, coverage


def load_general_parameters(data_dir):
    """Load general parameters from general_parameters.csv."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    return params

# --- Main script for the revised optimization problem ---

def main():
    # Determine the base directory for data files
    # Assuming the script is run from the root, and data is in 'data/'
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load data
    potential_store_locations, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    # Parse parameters, providing default values if not found (though they should be present)
    small_cost = int(params.get('small_cost', 1))
    large_cost = int(params.get('large_cost', 2))
    small_cap_areas = int(params.get('small_cap_areas', 3))
    max_large_stores = int(params.get('max_large_stores', 1))
    minimum_neighborhood_counters = int(params.get('minimum_neighborhood_counters', 6))
    # 'small_store_counter_credit' is 1 and implicitly handled by counting x_s variables
    
    # Set of all residential areas that need to be covered.
    # In this problem, all 'Area_Code's are both potential store locations and areas needing coverage.
    all_residential_areas = set(potential_store_locations)
    
    # Create a new Gurobi model
    model = gp.Model("MinChainStoresRevised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # --- Decision Variables ---
    
    # x_s[j]: 1 if a Small-format store is built at location j, 0 otherwise
    x_s = model.addVars(potential_store_locations, vtype=GRB.BINARY, name="x_small")
    
    # x_l[j]: 1 if a Large-format store is built at location j, 0 otherwise
    x_l = model.addVars(potential_store_locations, vtype=GRB.BINARY, name="x_large")
    
    # z_s[i, j]: 1 if residential area i is covered by a Small-format store at location j, 0 otherwise
    # Variables are created only for (i, j) pairs where j can potentially cover i
    z_s = model.addVars(
        ((i, j) for j in potential_store_locations for i in coverage.get(j, set())),
        vtype=GRB.BINARY,
        name="z_small_coverage"
    )
    
    # z_l[i, j]: 1 if residential area i is covered by a Large-format store at location j, 0 otherwise
    # Variables are created only for (i, j) pairs where j can potentially cover i
    z_l = model.addVars(
        ((i, j) for j in potential_store_locations for i in coverage.get(j, set())),
        vtype=GRB.BINARY,
        name="z_large_coverage"
    )
    
    # --- Objective Function ---
    # Minimize total cost of opening stores
    model.setObjective(
        gp.quicksum(small_cost * x_s[j] for j in potential_store_locations) +
        gp.quicksum(large_cost * x_l[j] for j in potential_store_locations),
        GRB.MINIMIZE
    )
    
    # --- Constraints ---
    
    # 1. At most one store type per location j
    for j in potential_store_locations:
        model.addConstr(x_s[j] + x_l[j] <= 1, name=f"OneStoreType_{j}")
        
    # 2. Small store coverage capacity and linkage
    for j in potential_store_locations:
        # If a small store is built at j, it can cover up to small_cap_areas from its potential coverage list
        if coverage.get(j): # Only add capacity constraint if j can cover something
            model.addConstr(
                gp.quicksum(z_s[i, j] for i in coverage[j]) <= small_cap_areas * x_s[j],
                name=f"SmallStoreCapacity_{j}"
            )
        # Individual linkage: z_s[i, j] can only be 1 if x_s[j] is 1
        for i in coverage.get(j, set()):
            model.addConstr(z_s[i, j] <= x_s[j], name=f"SmallStoreLink_{i}_{j}")
            
    # 3. Large store coverage linkage
    for j in potential_store_locations:
        # If a large store is built at j, it MUST cover all areas in its potential coverage list
        for i in coverage.get(j, set()):
            model.addConstr(z_l[i, j] == x_l[j], name=f"LargeStoreLink_{i}_{j}")
            
    # 4. Each residential area must be covered by at least one store (small or large)
    for i in all_residential_areas:
        # Sum of coverage from small stores + sum of coverage from large stores for area i
        model.addConstr(
            gp.quicksum(z_s[i, j] for j in potential_store_locations if i in coverage.get(j, set())) +
            gp.quicksum(z_l[i, j] for j in potential_store_locations if i in coverage.get(j, set())) >= 1,
            name=f"CoverArea_{i}"
        )
        
    # 5. Maximum number of large stores allowed in the entire network
    model.addConstr(
        gp.quicksum(x_l[j] for j in potential_store_locations) <= max_large_stores,
        name="MaxLargeStores"
    )
    
    # 6. Minimum number of small stores (neighborhood counters) required for the rollout
    model.addConstr(
        gp.quicksum(x_s[j] for j in potential_store_locations) >= minimum_neighborhood_counters,
        name="MinSmallStores"
    )
            
    # Optimize the model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # If no optimal solution is found, indicate failure or infeasibility
        print(f"Optimization did not find an optimal solution. Status: {model.status}")
        print(f"FINAL_OBJ_VALUE: {float('inf')}") # Use infinity to denote no feasible solution or failure

if __name__ == "__main__":
    main()
