import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve_revised_problem():
    # Define paths
    # The script will be executed from the revised workspace root directory.
    # Data files are in subdirectories like "data/filename.csv".
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    # Read CSVs
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    # --- Parse Table 1 ---
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]
    
    # Production parameters
    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])
    
    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])
    
    # Capacity parameters (in-house inspection capacity is from table_1)
    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp_inhouse = float(row_cap['Inspection_hours_per_unit']) # Renamed for clarity
    
    # Process costs (for Mfg and Asm, inspection cost is from general_parameters)
    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])
    cost_asm = float(row_cost['Assembly_hours_per_unit'])
    
    # --- Parse General Parameters ---
    def get_param_value(param_name):
        return float(df_params[df_params['Parameter_Name'] == param_name]['Value'].iloc[0])

    min_weekly_profit = get_param_value('min_weekly_profit')
    min_type_a_production = get_param_value('min_type_a_production')
    
    insp_a_M = get_param_value('insp_a_M')
    insp_b_M = get_param_value('insp_b_M')
    insp_a_E = get_param_value('insp_a_E')
    insp_b_E = get_param_value('insp_b_E')
    
    cap_ext = get_param_value('cap_ext')
    
    cost_insp_M = get_param_value('cost_insp_M')
    cost_insp_E = get_param_value('cost_insp_E')
    cost_ext = get_param_value('cost_ext')
    
    mode_fee_M = get_param_value('mode_fee_M')
    mode_fee_E = get_param_value('mode_fee_E')
    risk_penalty_M = get_param_value('risk_penalty_M')
    
    cost_insp_weight = get_param_value('cost_insp_weight') # Weight for in-house inspection idle time
    
    planning_horizon_weeks = int(get_param_value('planning_horizon_weeks'))
    idle_tolerance = get_param_value('idle_tolerance')

    weeks = range(planning_horizon_weeks)
    
    # Big M for conditional constraints (a sufficiently large number)
    M = 10000 
    
    # --- Model 1: Minimize Weighted Idle Time + Risk Penalty ---
    model1 = gp.Model("Motorcycle_Production_Lexicographic_Step1")
    model1.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision Variables for each week
    x_A = model1.addVars(weeks, name="x_A", vtype=GRB.INTEGER, lb=min_type_a_production)
    x_B = model1.addVars(weeks, name="x_B", vtype=GRB.INTEGER, lb=0)
    
    y_M = model1.addVars(weeks, name="y_M", vtype=GRB.BINARY) # 1 if Manual protocol chosen
    y_E = model1.addVars(weeks, name="y_E", vtype=GRB.BINARY) # 1 if Enhanced protocol chosen
    
    # Actual inspection hours used (continuous, non-negative)
    insp_inhouse_actual = model1.addVars(weeks, name="insp_inhouse_actual", vtype=GRB.CONTINUOUS, lb=0)
    insp_ext_actual = model1.addVars(weeks, name="insp_ext_actual", vtype=GRB.CONTINUOUS, lb=0)
    
    # Idle time variables (continuous, non-negative)
    idle_mfg = model1.addVars(weeks, name="idle_mfg", vtype=GRB.CONTINUOUS, lb=0)
    idle_asm = model1.addVars(weeks, name="idle_asm", vtype=GRB.CONTINUOUS, lb=0)
    idle_insp = model1.addVars(weeks, name="idle_insp", vtype=GRB.CONTINUOUS, lb=0) # In-house inspection idle time
    
    # Constraints for each week
    for w in weeks:
        # 1. One inspection protocol per week
        model1.addConstr(y_M[w] + y_E[w] == 1, f"One_Protocol_W{w}")
        
        # 2. Manufacturing Capacity and Idle Time
        model1.addConstr(mfg_a * x_A[w] + mfg_b * x_B[w] <= cap_mfg, f"Mfg_Capacity_W{w}")
        model1.addConstr(idle_mfg[w] == cap_mfg - (mfg_a * x_A[w] + mfg_b * x_B[w]), f"Idle_Mfg_Def_W{w}")
        
        # 3. Assembly Capacity and Idle Time
        model1.addConstr(asm_a * x_A[w] + asm_b * x_B[w] <= cap_asm, f"Asm_Capacity_W{w}")
        model1.addConstr(idle_asm[w] == cap_asm - (asm_a * x_A[w] + asm_b * x_B[w]), f"Idle_Asm_Def_W{w}")
        
        # 4. In-house Inspection Capacity and Idle Time
        model1.addConstr(insp_inhouse_actual[w] <= cap_insp_inhouse, f"Inhouse_Insp_Capacity_W{w}")
        model1.addConstr(idle_insp[w] == cap_insp_inhouse - insp_inhouse_actual[w], f"Idle_Insp_Def_W{w}")
        
        # 5. External Inspection Capacity (only if Enhanced mode is chosen)
        model1.addConstr(insp_ext_actual[w] <= cap_ext, f"Ext_Insp_Capacity_W{w}")
        model1.addConstr(insp_ext_actual[w] <= M * y_E[w], f"Ext_Insp_Conditional_W{w}") # Must be 0 if y_E[w]=0
        
        # 6. Total Inspection Hours Required must be met based on chosen protocol
        total_insp_req_M_w = insp_a_M * x_A[w] + insp_b_M * x_B[w]
        total_insp_req_E_w = insp_a_E * x_A[w] + insp_b_E * x_B[w]
        
        # If Manual (y_M[w]=1), then insp_inhouse_actual[w] must be total_insp_req_M_w and insp_ext_actual[w] must be 0
        # If Enhanced (y_E[w]=1), then insp_inhouse_actual[w] + insp_ext_actual[w] must be total_insp_req_E_w
        # These are implemented using Big-M constraints:
        model1.addConstr(insp_inhouse_actual[w] + insp_ext_actual[w] >= total_insp_req_M_w - M * (1 - y_M[w]), f"Insp_Req_M_Lower_W{w}")
        model1.addConstr(insp_inhouse_actual[w] + insp_ext_actual[w] <= total_insp_req_M_w + M * (1 - y_M[w]), f"Insp_Req_M_Upper_W{w}")
        
        model1.addConstr(insp_inhouse_actual[w] + insp_ext_actual[w] >= total_insp_req_E_w - M * (1 - y_E[w]), f"Insp_Req_E_Lower_W{w}")
        model1.addConstr(insp_inhouse_actual[w] + insp_ext_actual[w] <= total_insp_req_E_w + M * (1 - y_E[w]), f"Insp_Req_E_Upper_W{w}")
        
        # 7. Minimum Weekly Profit
        weekly_revenue = price_a * x_A[w] + price_b * x_B[w]
        
        weekly_mfg_cost = (mfg_a * x_A[w] + mfg_b * x_B[w]) * cost_mfg
        weekly_asm_cost = (asm_a * x_A[w] + asm_b * x_B[w]) * cost_asm
        
        # Inspection costs depend on protocol chosen for the week
        weekly_insp_cost_M_calc = total_insp_req_M_w * cost_insp_M
        weekly_insp_cost_E_calc = insp_inhouse_actual[w] * cost_insp_E + insp_ext_actual[w] * cost_ext
        
        # Total inspection cost for the week (conditional on y_M or y_E)
        total_insp_cost_w = y_M[w] * weekly_insp_cost_M_calc + y_E[w] * weekly_insp_cost_E_calc
        
        weekly_mode_fee = y_M[w] * mode_fee_M + y_E[w] * mode_fee_E
        weekly_risk_penalty = y_M[w] * risk_penalty_M
        
        # Total weekly profit
        profit_w = weekly_revenue - weekly_mfg_cost - weekly_asm_cost - total_insp_cost_w - weekly_mode_fee - weekly_risk_penalty
        
        model1.addConstr(profit_w >= min_weekly_profit, f"Min_Profit_W{w}")
        
    # Objective 1: Minimize (Total Weighted Idle Time + Total Risk Penalty)
    # Weights for idle time: cost_mfg for manufacturing, cost_asm for assembly, cost_insp_weight for in-house inspection.
    total_weighted_idle_time = gp.quicksum(cost_mfg * idle_mfg[w] + cost_asm * idle_asm[w] + cost_insp_weight * idle_insp[w] for w in weeks)
    total_risk_penalty_cost = gp.quicksum(y_M[w] * risk_penalty_M for w in weeks)
    
    model1.setObjective(total_weighted_idle_time + total_risk_penalty_cost, GRB.MINIMIZE)
    
    model1.optimize()
    
    if model1.status == GRB.OPTIMAL:
        min_obj1_value = model1.objVal
    else:
        # If Model 1 is infeasible, the problem has no solution.
        # For this problem, we assume feasibility.
        raise Exception(f"Model 1 did not find an optimal solution. Status: {model1.status}")

    # --- Model 2: Maximize Total Profit subject to min_obj1_value ---
    model2 = gp.Model("Motorcycle_Production_Lexicographic_Step2")
    model2.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision Variables (re-add for model2)
    x_A2 = model2.addVars(weeks, name="x_A", vtype=GRB.INTEGER, lb=min_type_a_production)
    x_B2 = model2.addVars(weeks, name="x_B", vtype=GRB.INTEGER, lb=0)
    
    y_M2 = model2.addVars(weeks, name="y_M", vtype=GRB.BINARY)
    y_E2 = model2.addVars(weeks, name="y_E", vtype=GRB.BINARY)
    
    insp_inhouse_actual2 = model2.addVars(weeks, name="insp_inhouse_actual", vtype=GRB.CONTINUOUS, lb=0)
    insp_ext_actual2 = model2.addVars(weeks, name="insp_ext_actual", vtype=GRB.CONTINUOUS, lb=0)
    
    idle_mfg2 = model2.addVars(weeks, name="idle_mfg", vtype=GRB.CONTINUOUS, lb=0)
    idle_asm2 = model2.addVars(weeks, name="idle_asm", vtype=GRB.CONTINUOUS, lb=0)
    idle_insp2 = model2.addVars(weeks, name="idle_insp", vtype=GRB.CONTINUOUS, lb=0)
    
    # Constraints for each week (same as model1)
    for w in weeks:
        model2.addConstr(y_M2[w] + y_E2[w] == 1, f"One_Protocol_W{w}_M2")
        
        model2.addConstr(mfg_a * x_A2[w] + mfg_b * x_B2[w] <= cap_mfg, f"Mfg_Capacity_W{w}_M2")
        model2.addConstr(idle_mfg2[w] == cap_mfg - (mfg_a * x_A2[w] + mfg_b * x_B2[w]), f"Idle_Mfg_Def_W{w}_M2")
        
        model2.addConstr(asm_a * x_A2[w] + asm_b * x_B2[w] <= cap_asm, f"Asm_Capacity_W{w}_M2")
        model2.addConstr(idle_asm2[w] == cap_asm - (asm_a * x_A2[w] + asm_b * x_B2[w]), f"Idle_Asm_Def_W{w}_M2")
        
        model2.addConstr(insp_inhouse_actual2[w] <= cap_insp_inhouse, f"Inhouse_Insp_Capacity_W{w}_M2")
        model2.addConstr(idle_insp2[w] == cap_insp_inhouse - insp_inhouse_actual2[w], f"Idle_Insp_Def_W{w}_M2")
        
        model2.addConstr(insp_ext_actual2[w] <= cap_ext, f"Ext_Insp_Capacity_W{w}_M2")
        model2.addConstr(insp_ext_actual2[w] <= M * y_E2[w], f"Ext_Insp_Conditional_W{w}_M2")
        
        total_insp_req_M_w2 = insp_a_M * x_A2[w] + insp_b_M * x_B2[w]
        total_insp_req_E_w2 = insp_a_E * x_A2[w] + insp_b_E * x_B2[w]
        
        model2.addConstr(insp_inhouse_actual2[w] + insp_ext_actual2[w] >= total_insp_req_M_w2 - M * (1 - y_M2[w]), f"Insp_Req_M_Lower_W{w}_M2")
        model2.addConstr(insp_inhouse_actual2[w] + insp_ext_actual2[w] <= total_insp_req_M_w2 + M * (1 - y_M2[w]), f"Insp_Req_M_Upper_W{w}_M2")
        
        model2.addConstr(insp_inhouse_actual2[w] + insp_ext_actual2[w] >= total_insp_req_E_w2 - M * (1 - y_E2[w]), f"Insp_Req_E_Lower_W{w}_M2")
        model2.addConstr(insp_inhouse_actual2[w] + insp_ext_actual2[w] <= total_insp_req_E_w2 + M * (1 - y_E2[w]), f"Insp_Req_E_Upper_W{w}_M2")
        
        weekly_revenue2 = price_a * x_A2[w] + price_b * x_B2[w]
        weekly_mfg_cost2 = (mfg_a * x_A2[w] + mfg_b * x_B2[w]) * cost_mfg
        weekly_asm_cost2 = (asm_a * x_A2[w] + asm_b * x_B2[w]) * cost_asm
        
        weekly_insp_cost_M_calc2 = total_insp_req_M_w2 * cost_insp_M
        weekly_insp_cost_E_calc2 = insp_inhouse_actual2[w] * cost_insp_E + insp_ext_actual2[w] * cost_ext
        
        total_insp_cost_w2 = y_M2[w] * weekly_insp_cost_M_calc2 + y_E2[w] * weekly_insp_cost_E_calc2
        
        weekly_mode_fee2 = y_M2[w] * mode_fee_M + y_E2[w] * mode_fee_E
        weekly_risk_penalty2 = y_M2[w] * risk_penalty_M
        
        profit_w2 = weekly_revenue2 - weekly_mfg_cost2 - weekly_asm_cost2 - total_insp_cost_w2 - weekly_mode_fee2 - weekly_risk_penalty2
        
        model2.addConstr(profit_w2 >= min_weekly_profit, f"Min_Profit_W{w}_M2")
        
    # Add the constraint from Model 1's optimal objective value
    total_weighted_idle_time2 = gp.quicksum(cost_mfg * idle_mfg2[w] + cost_asm * idle_asm2[w] + cost_insp_weight * idle_insp2[w] for w in weeks)
    total_risk_penalty_cost2 = gp.quicksum(y_M2[w] * risk_penalty_M for w in weeks)
    
    model2.addConstr(total_weighted_idle_time2 + total_risk_penalty_cost2 <= min_obj1_value + idle_tolerance, "Lexicographic_Constraint")
    
    # Objective 2: Maximize Total Two-Week Profit
    total_profit_objective = gp.quicksum(
        (price_a * x_A2[w] + price_b * x_B2[w])
        - (mfg_a * x_A2[w] + mfg_b * x_B2[w]) * cost_mfg
        - (asm_a * x_A2[w] + asm_b * x_B2[w]) * cost_asm
        - (y_M2[w] * (insp_a_M * x_A2[w] + insp_b_M * x_B2[w]) * cost_insp_M) # Manual in-house insp cost
        - (y_E2[w] * insp_inhouse_actual2[w] * cost_insp_E + y_E2[w] * insp_ext_actual2[w] * cost_ext) # Enhanced in-house + external insp cost
        - (y_M2[w] * mode_fee_M + y_E2[w] * mode_fee_E) # Mode fees
        - (y_M2[w] * risk_penalty_M) # Risk penalty
        for w in weeks
    )
    
    model2.setObjective(total_profit_objective, GRB.MAXIMIZE)
    
    model2.optimize()
    
    if model2.status == GRB.OPTIMAL:
        final_obj_value = model2.objVal
        print(f"FINAL_OBJ_VALUE: {round(final_obj_value, 4)}")
    else:
        # If Model 2 is infeasible, it means no solution exists that satisfies the first objective's minimum value
        # within the given tolerance. This should ideally not happen if Model 1 was feasible.
        raise Exception(f"Model 2 did not find an optimal solution. Status: {model2.status}")

if __name__ == '__main__':
    solve_revised_problem()
