import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Construct the path to the general_parameters.csv file
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'general_parameters.csv')
    df = pd.read_csv(data_path)
    
    # Load parameters from the CSV
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = row['Value']
        
    # Extract quantities and lengths
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity']) # New: 5m bars
    L = int(params['raw_bar_length'])
    
    # New parameters for the revised problem
    setup_cost_per_pattern = float(params['setup_cost_per_pattern'])
    max_distinct_patterns = int(params['max_distinct_patterns'])
    
    # Lengths of the three types of steel bars
    lengths = [3, 4, 5]
    quantities = [q3, q4, q5]
    
    # Generate all valid cutting patterns
    # A pattern is a tuple (num_3m, num_4m, num_5m)
    patterns = []
    for c1 in range(L // lengths[0] + 1):
        for c2 in range(L // lengths[1] + 1):
            for c3 in range(L // lengths[2] + 1):
                if lengths[0] * c1 + lengths[1] * c2 + lengths[2] * c3 <= L:
                    # Ensure the pattern is not empty (cuts at least one piece)
                    if c1 > 0 or c2 > 0 or c3 > 0:
                        patterns.append((c1, c2, c3))
                        
    # Create a new Gurobi model
    model = gp.Model("CuttingStockRevised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables:
    # x_p[p]: number of times pattern 'p' is used (integer)
    x_p = model.addVars(len(patterns), vtype=GRB.INTEGER, name="num_raw_bars_cut_by_pattern")
    
    # y_p[p]: binary variable, 1 if pattern 'p' is used, 0 otherwise
    y_p = model.addVars(len(patterns), vtype=GRB.BINARY, name="pattern_is_used")
    
    # Objective: Minimize total waste (material waste + setup cost)
    
    # 1. Material waste calculation
    # Total length of raw bars used
    total_raw_bars_length = gp.quicksum(L * x_p[p] for p in range(len(patterns)))
    
    # Total length of required pieces
    total_required_length = sum(lengths[i] * quantities[i] for i in range(len(lengths)))
    
    # Waste from raw material (any overproduced pieces are also considered waste)
    waste_from_material = total_raw_bars_length - total_required_length
    
    # 2. Setup cost calculation
    total_setup_cost = setup_cost_per_pattern * gp.quicksum(y_p[p] for p in range(len(patterns)))
    
    # Set the objective function
    model.setObjective(waste_from_material + total_setup_cost, GRB.MINIMIZE)
    
    # Constraints:
    
    # 1. Demand constraints: satisfy the demand for each type of steel bar
    for i in range(len(lengths)):
        model.addConstr(gp.quicksum(patterns[p][i] * x_p[p] for p in range(len(patterns))) >= quantities[i], 
                        f"Demand_{lengths[i]}m")
                        
    # 2. Link x_p and y_p variables: if a pattern is used (x_p[p] > 0), then y_p[p] must be 1
    # We use a large M for the Big-M formulation.
    # A safe M is the maximum possible number of raw bars that could be used for a single pattern.
    # Total required length / min_length_per_piece = sum(quantities) * L / min(lengths)
    M = sum(quantities) * L / min(lengths) + 1 # e.g., (90+60+40)*10/3 + 1 = 634
    model.addConstrs((x_p[p] <= M * y_p[p] for p in range(len(patterns))), "Link_x_y")
    
    # 3. Maximum distinct patterns constraint
    model.addConstr(gp.quicksum(y_p[p] for p in range(len(patterns))) <= max_distinct_patterns, "Max_Patterns")
    
    # Optimize the model
    model.optimize()
    
    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimization did not find an optimal solution.")
        print(f"Model status: {model.status}")

if __name__ == "__main__":
    solve()
