import csv
import math
import os
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    """
    Constructs the absolute path to a data file.
    Assumes the script is executed from the revised workspace root directory.
    """
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)

def solve():
    # --- Data Loading ---
    table_1_path = get_data_path('table_1.csv')
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
            
    params_path = get_data_path('general_parameters.csv')
    std_widths = []
    pattern_setup_penalty = 0.0
    wide_roll_threshold_width = 0.0
    wide_roll_extra_setup_penalty = 0.0

    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if 'standard_width' in row['Parameter_Name']:
                std_widths.append(float(row['Value']))
            elif row['Parameter_Name'] == 'pattern_setup_penalty':
                pattern_setup_penalty = float(row['Value'])
            elif row['Parameter_Name'] == 'wide_roll_threshold_width':
                wide_roll_threshold_width = float(row['Value'])
            elif row['Parameter_Name'] == 'wide_roll_extra_setup_penalty':
                wide_roll_extra_setup_penalty = float(row['Value'])
                
    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    
    total_required_area = sum(w * l for w, l in zip(widths, lengths))
    
    # --- Pattern Generation ---
    # patterns_by_std_width will store:
    # {std_width_idx: {'sw': standard_width_value, 'patterns': [list_of_patterns]}}
    # Each pattern is a list [count_order1, count_order2, ...]
    patterns_by_std_width = {}
    for idx, sw in enumerate(std_widths):
        patterns = []
        
        # Recursive function to build all possible cutting patterns for a given standard width
        def build_pattern(order_idx, current_pattern, current_sum):
            if order_idx == len(widths):
                # Only add patterns that actually cut something (not all zeros)
                if any(c > 0 for c in current_pattern):
                    patterns.append(current_pattern)
                return
            
            # Calculate the maximum number of times the current order width can fit
            # Use a small epsilon for floating point comparisons to handle precision issues
            max_count = int(math.floor((sw - current_sum + 1e-9) / widths[order_idx]))
            for count in range(max_count + 1):
                build_pattern(order_idx + 1, current_pattern + [count], current_sum + count * widths[order_idx])
                
        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {'sw': sw, 'patterns': patterns}

    # --- Gurobi Model Formulation ---
    model = gp.Model("Minimize_Waste_with_Penalties")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Variables
    # x_vars[(std_width_idx, pattern_idx)] = total length of standard roll 'std_width_idx' cut using pattern 'pattern_idx'
    x_vars = {} 
    # y_vars[(std_width_idx, pattern_idx)] = 1 if pattern 'pattern_idx' for standard roll 'std_width_idx' is used, 0 otherwise (binary)
    y_vars = {} 

    # M is a large number used for linking constraints (Big-M formulation)
    # A safe upper bound for any x_vars value is the total length of all orders.
    M = sum(lengths) 
    
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            x_vars[(idx, i)] = model.addVar(lowbound=0, vtype=GRB.CONTINUOUS, name=f"x_{idx}_{i}")
            y_vars[(idx, i)] = model.addVar(vtype=GRB.BINARY, name=f"y_{idx}_{i}")
            
            # Linking constraint: If x_vars[(idx, i)] > 0, then y_vars[(idx, i)] must be 1.
            # If y_vars[(idx, i)] is 0, x_vars[(idx, i)] must be 0.
            model.addConstr(x_vars[(idx, i)] <= M * y_vars[(idx, i)], name=f"link_x_y_{idx}_{i}")

    # Objective: Minimize total waste
    # Total Waste = (Total Area of Standard Rolls Used) + (Total Pattern Setup Penalties) - (Total Area Required by Orders)
    
    # 1. Total Area of Standard Rolls Used
    total_area_used_expr = gp.quicksum(data['sw'] * x_vars[(idx, i)] 
                                       for idx, data in patterns_by_std_width.items() 
                                       for i, p in enumerate(data['patterns']))
    
    # 2. Total Pattern Setup Penalties
    total_penalty_expr = gp.quicksum(
        (pattern_setup_penalty + (wide_roll_extra_setup_penalty if data['sw'] >= wide_roll_threshold_width else 0)) * y_vars[(idx, i)]
        for idx, data in patterns_by_std_width.items() 
        for i, p in enumerate(data['patterns'])
    )
    
    # Set the objective function
    model.setObjective(total_area_used_expr + total_penalty_expr - total_required_area, GRB.MINIMIZE)
    
    # Constraints: Satisfy length requirements for each order width
    for j in range(len(widths)): # Iterate through each order type
        model.addConstr(gp.quicksum(p[j] * x_vars[(idx, i)] 
                                    for idx, data in patterns_by_std_width.items() 
                                    for i, p in enumerate(data['patterns'])) >= lengths[j], 
                        name=f"demand_order_{j}")
        
    # Optimize the model
    model.optimize()
    
    # --- Output Results ---
    if model.status == GRB.OPTIMAL:
        final_objective_value = model.objVal
        print(f"FINAL_OBJ_VALUE: {round(final_objective_value, 4)}")
    else:
        # Handle cases where an optimal solution is not found
        print("Optimization did not find an optimal solution.")
        print(f"Model status: {model.status}")

if __name__ == "__main__":
    solve()
