import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility function (copied from src/utils.py) ---
def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    return params

# --- Main script ---
if __name__ == "__main__":
    # Determine the script's directory.
    # The script is expected to be executed from the revised workspace root directory.
    # Data files are in a 'data' subdirectory relative to this root.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_filepath = os.path.join(script_dir, 'data', 'general_parameters.csv')

    # Load parameters from the CSV file
    params = load_parameters(data_filepath)

    # Extract parameters for clarity
    min_A = params['min_raw_material_A']
    min_B = params['min_raw_material_B']
    min_C = params['min_raw_material_C']

    cap_A_a = params['warehouse_A_truck_capacity_A']
    cap_A_b = params['warehouse_A_truck_capacity_B']
    cap_A_c = params['warehouse_A_truck_capacity_C']
    cost_A = params['warehouse_A_truck_cost']
    fixed_cost_A = params['warehouse_A_fixed_cost']

    cap_B_a = params['warehouse_B_truck_capacity_A']
    cap_B_b = params['warehouse_B_truck_capacity_B']
    cap_B_c = params['warehouse_B_truck_capacity_C']
    cost_B = params['warehouse_B_truck_cost']
    fixed_cost_B = params['warehouse_B_fixed_cost']
    overflow_threshold_B = params['warehouse_B_overflow_threshold_trucks']
    overflow_cost_B = params['warehouse_B_overflow_coordination_cost']

    reconciliation_trigger = params['dual_warehouse_reconciliation_trigger']
    reconciliation_fee = params['dual_warehouse_reconciliation_fee']

    # Create a new Gurobi model
    model = gp.Model("MinFreightCostRevised")

    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)

    # Decision variables: number of trucks from warehouse A and B (integers, non-negative)
    x_A = model.addVar(vtype=GRB.INTEGER, name="trucks_from_A", lb=0)
    x_B = model.addVar(vtype=GRB.INTEGER, name="trucks_from_B", lb=0)

    # Binary indicator variables for fixed costs and conditional costs
    # y_A_used = 1 if x_A >= 1, else 0
    y_A_used = model.addVar(vtype=GRB.BINARY, name="warehouse_A_used")
    # y_B_used = 1 if x_B >= 1, else 0
    y_B_used = model.addVar(vtype=GRB.BINARY, name="warehouse_B_used")
    # y_both_used = 1 if y_A_used == 1 AND y_B_used == 1, else 0
    y_both_used = model.addVar(vtype=GRB.BINARY, name="both_warehouses_used")
    # y_B_overflow = 1 if x_B > overflow_threshold_B, else 0
    y_B_overflow = model.addVar(vtype=GRB.BINARY, name="warehouse_B_overflow")

    # Objective: minimize total freight cost + fixed costs + conditional costs
    objective = cost_A * x_A + cost_B * x_B
    objective += fixed_cost_A * y_A_used
    objective += fixed_cost_B * y_B_used
    
    if reconciliation_trigger == 1:
        objective += reconciliation_fee * y_both_used
        
    objective += overflow_cost_B * y_B_overflow

    model.setObjective(objective, GRB.MINIMIZE)

    # Constraints: meet minimum raw material requirements
    model.addConstr(cap_A_a * x_A + cap_B_a * x_B >= min_A, "RawMaterialA")
    model.addConstr(cap_A_b * x_A + cap_B_b * x_B >= min_B, "RawMaterialB")
    model.addConstr(cap_A_c * x_A + cap_B_c * x_B >= min_C, "RawMaterialC")

    # Link binary variables to truck counts using Gurobi's indicator constraints
    # y_A_used = 1 if x_A >= 1, else 0
    model.addGenConstrIndicator(y_A_used, 1, x_A >= 1, name="Link_A_used_if_x_A_gt_0")
    model.addGenConstrIndicator(y_A_used, 0, x_A == 0, name="Link_A_used_if_x_A_eq_0")

    # y_B_used = 1 if x_B >= 1, else 0
    model.addGenConstrIndicator(y_B_used, 1, x_B >= 1, name="Link_B_used_if_x_B_gt_0")
    model.addGenConstrIndicator(y_B_used, 0, x_B == 0, name="Link_B_used_if_x_B_eq_0")

    # y_both_used = 1 if y_A_used == 1 AND y_B_used == 1, else 0
    # This is modeled using standard logical AND constraints for binary variables
    if reconciliation_trigger == 1:
        model.addConstr(y_both_used <= y_A_used, "Both_Used_Implies_A_Used")
        model.addConstr(y_both_used <= y_B_used, "Both_Used_Implies_B_Used")
        model.addConstr(y_both_used >= y_A_used + y_B_used - 1, "Both_Used_If_Both_Used")

    # y_B_overflow = 1 if x_B > overflow_threshold_B, else 0
    # For integer x_B, x_B > threshold is equivalent to x_B >= threshold + 1
    model.addGenConstrIndicator(y_B_overflow, 1, x_B >= overflow_threshold_B + 1, name="Overflow_if_x_B_gt_threshold")
    model.addGenConstrIndicator(y_B_overflow, 0, x_B <= overflow_threshold_B, name="No_Overflow_if_x_B_le_threshold")

    # Optimize the model
    model.optimize()

    # Output the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Handle cases where the model is not optimal (e.g., infeasible, unbounded)
        print(f"FINAL_OBJ_VALUE: Optimization did not reach an optimal solution. Status: {model.status}")
