import gurobipy as gp
from gurobipy import GRB
import csv
import os

# --- Data Loading Functions (Self-contained) ---
def load_goods_data(filepath):
    """Loads goods data from a CSV file."""
    goods = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            goods[row['Goods_Type'].strip()] = {
                'quantity': int(row['Quantity'].strip()),
                'weight': float(row['Weight_per_Unit'].strip())
            }
    return goods

def load_parameters(filepath):
    """Loads general parameters from a CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

# Determine the script's directory and construct data paths
script_dir = os.path.dirname(os.path.abspath(__file__))
# Assuming the script is in 'src/' and data is in 'data/' at the parent level
data_dir = os.path.join(script_dir, 'data') 

goods_data_filepath = os.path.join(data_dir, 'table_1.csv')
params_filepath = os.path.join(data_dir, 'general_parameters.csv')

# Load data
goods = load_goods_data(goods_data_filepath)
params = load_parameters(params_filepath)

# --- Extract Parameters ---
max_container_capacity = params['max_container_capacity']
min_container_load = params['min_container_load']
# REVISED parameter: Minimum D goods per container
min_d_goods_per_container = int(params['min_d_goods_per_container'])
min_c_per_a = int(params['min_c_per_a'])

# NEW parameter from business requirements (not in CSV, derived from text)
fragile_e_capacity = 45.0 # tons, for containers carrying Goods E

goods_types = list(goods.keys())
quantities = {g: goods[g]['quantity'] for g in goods_types}
weights = {g: goods[g]['weight'] for g in goods_types}

# --- Model Setup ---
model = gp.Model("ContainerMinimization")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# Upper bound on number of containers
# Total D goods: 90 units. Min D per container: 10 units. So, at least ceil(90/10) = 9 containers must carry D.
# Total weight of all goods: sum(q*w) = 402 tons.
# Max containers by min load: ceil(402 / 18) = 23.
# A generous upper bound like 25 should be sufficient.
max_containers = 25
N = range(max_containers) # Set of potential containers

# --- Decision Variables ---
# x[g, j] = number of units of goods type g in container j
x = model.addVars(goods_types, N, vtype=GRB.INTEGER, lb=0, name="x")
# y[j] = 1 if container j is used, 0 otherwise
y = model.addVars(N, vtype=GRB.BINARY, name="y")
# z[j] = 1 if container j contains Goods A, 0 otherwise (for C if A constraint)
z = model.addVars(N, vtype=GRB.BINARY, name="z")
# w[j] = 1 if container j contains Goods E, 0 otherwise (for fragile E capacity constraint)
w = model.addVars(N, vtype=GRB.BINARY, name="w")

# --- Objective Function ---
# Minimize the number of containers used
model.setObjective(gp.quicksum(y[j] for j in N), GRB.MINIMIZE)

# --- Constraints ---

# 1. All goods must be transported
for g in goods_types:
    model.addConstr(gp.quicksum(x[g, j] for j in N) == quantities[g], f"demand_{g}")

# Define total weight in each container for easier constraint formulation
total_weight_j = {j: gp.quicksum(weights[g] * x[g, j] for g in goods_types) for j in N}

for j in N:
    # Link y[j] to container usage: if any goods are in container j, y[j] must be 1.
    # This is implicitly handled by min_load * y[j] and max_cap * y[j] if min_load > 0.
    # If min_load could be 0, an explicit link like sum(x[g,j]) >= y[j] would be needed.

    # Link w[j] to x['E', j]: w[j] = 1 if x['E', j] > 0, else w[j] = 0
    # If w[j] is 0, x['E', j] must be 0.
    model.addConstr(x['E', j] <= quantities['E'] * w[j], f"link_E_present_upper_{j}")
    # If w[j] is 1, x['E', j] must be at least 1.
    model.addConstr(x['E', j] >= w[j], f"link_E_present_lower_{j}")

    # 2. Container weight capacity constraint (REVISED to include fragile E)
    # General maximum capacity if container is used
    model.addConstr(total_weight_j[j] <= max_container_capacity * y[j], f"max_cap_general_{j}")
    
    # Fragile E specific capacity: If w[j] is 1 (E is present), capacity is reduced to fragile_e_capacity
    # This is an indicator constraint: IF w[j] == 1 THEN total_weight_j[j] <= fragile_e_capacity
    model.addGenConstrIndicator(w[j], True, total_weight_j[j] <= fragile_e_capacity, f"max_cap_fragile_E_{j}")

    # 3. Minimum load constraint (if container is used)
    model.addConstr(total_weight_j[j] >= min_container_load * y[j], f"min_load_{j}")

    # 4. Minimum D goods per container (if container is used) - uses REVISED parameter
    model.addConstr(x['D', j] >= min_d_goods_per_container * y[j], f"min_D_{j}")

    # 5. If A goods are loaded, at least 1 C good must be loaded
    # Link z[j] to x['A', j]: z[j] = 1 if x['A', j] > 0, else z[j] = 0
    # If z[j] is 0, x['A', j] must be 0.
    model.addConstr(x['A', j] <= quantities['A'] * z[j], f"A_indicator_upper_{j}")
    # If z[j] is 1, x['A', j] must be at least 1.
    model.addConstr(x['A', j] >= z[j], f"A_indicator_lower_{j}")

    # If z[j] is 1 (A goods are present), then x['C', j] must be at least min_c_per_a
    model.addConstr(x['C', j] >= min_c_per_a * z[j], f"C_if_A_{j}")

# 6. Symmetry breaking: Encourage using lower-indexed containers first
for j in range(max_containers - 1):
    model.addConstr(y[j] >= y[j+1], f"symmetry_{j}")

# --- Solve the model ---
model.optimize()

# --- Output Results ---
if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    # If optimization fails or is not optimal, print -1 as an indicator
    print("FINAL_OBJ_VALUE: -1")
