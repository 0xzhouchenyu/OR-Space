import os
import sys
import gurobipy as gp
from gurobipy import GRB
import csv

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip()) # Consistent with original utils.py
            params[name] = value
    return params

def main():
    # Construct the path to the data directory relative to the script's location.
    # The script is executed from the revised workspace root directory,
    # so data files are in "data/filename.csv".
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Extract parameters from the loaded data
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    
    # New parameters introduced by the revision
    total_fleet_surge_threshold = params['total_fleet_surge_threshold']
    total_fleet_surge_fee = params['total_fleet_surge_fee']
    type_b_recovery_threshold = params['type_b_recovery_threshold']
    type_b_recovery_fee = params['type_b_recovery_fee']

    # Initialize Gurobi model
    model = gp.Model("TruckRental")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Decision variables
    # x: Number of Type A trucks (integer, non-negative)
    # y: Number of Type B trucks (integer, non-negative)
    x = model.addVar(vtype=GRB.INTEGER, name="TypeA_trucks", lb=0)
    y = model.addVar(vtype=GRB.INTEGER, name="TypeB_trucks", lb=0)

    # Binary indicator variables for the new fixed costs (gate rules)
    # z_total_surge: 1 if total trucks (x+y) exceed total_fleet_surge_threshold, 0 otherwise
    z_total_surge = model.addVar(vtype=GRB.BINARY, name="z_total_surge")
    # z_b_recovery: 1 if Type B trucks (y) exceed type_b_recovery_threshold, 0 otherwise
    z_b_recovery = model.addVar(vtype=GRB.BINARY, name="z_b_recovery")

    # Define a sufficiently large Big M value for the indicator constraints.
    # Based on cargo requirements and capacities, the maximum number of trucks
    # for x or y could be around 200 (e.g., 4000 / 20). For x+y, it could be up to 400.
    # M = 500 is a safe upper bound for the number of trucks.
    M = 500 

    # Objective function: Minimize total cost
    # Base rental costs + total fleet surge fee (if triggered) + Type B recovery fee (if triggered)
    model.setObjective(
        cost_a * x + cost_b * y + 
        total_fleet_surge_fee * z_total_surge + 
        type_b_recovery_fee * z_b_recovery, 
        GRB.MINIMIZE
    )

    # Constraints

    # 1. Cargo requirements (original constraints)
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedRequirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedRequirement")

    # 2. Big M constraints for the total fleet surge fee
    # This set of constraints links z_total_surge to the condition (x + y > total_fleet_surge_threshold).
    # For integer variables, this is equivalent to (x + y >= total_fleet_surge_threshold + 1).
    # If z_total_surge = 0, then x + y <= total_fleet_surge_threshold.
    # If z_total_surge = 1, then x + y >= total_fleet_surge_threshold + 1.
    model.addConstr(x + y <= total_fleet_surge_threshold + M * (1 - z_total_surge), "TotalFleetSurge_Upper")
    model.addConstr(x + y >= total_fleet_surge_threshold + 1 - M * z_total_surge, "TotalFleetSurge_Lower")

    # 3. Big M constraints for the Type B recovery fee
    # This set of constraints links z_b_recovery to the condition (y > type_b_recovery_threshold).
    # For integer variables, this is equivalent to (y >= type_b_recovery_threshold + 1).
    # If z_b_recovery = 0, then y <= type_b_recovery_threshold.
    # If z_b_recovery = 1, then y >= type_b_recovery_threshold + 1.
    model.addConstr(y <= type_b_recovery_threshold + M * (1 - z_b_recovery), "TypeBRecovery_Upper")
    model.addConstr(y >= type_b_recovery_threshold + 1 - M * z_b_recovery, "TypeBRecovery_Lower")

    # Optimize the model
    model.optimize()

    # Print the final objective value as required
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Handle cases where the model is not optimal (e.g., infeasible, unbounded)
        # For this problem, an optimal solution is expected.
        print(f"Optimization did not find an optimal solution. Status: {model.status}")

if __name__ == "__main__":
    main()
