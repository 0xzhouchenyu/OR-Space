import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Data Loading ---
# Determine the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load general parameters from general_parameters.csv
general_params = {}
general_params_path = os.path.join(data_dir, 'general_parameters.csv')
with open(general_params_path, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        value_str = row['Value'].strip()
        if value_str:
            try:
                general_params[param_name] = int(value_str)
            except ValueError:
                try:
                    general_params[param_name] = float(value_str)
                except ValueError:
                    general_params[param_name] = value_str
        else:
            general_params[param_name] = None

# Extract specific parameters required by the revised problem
son1_min_share = general_params['son1_min_share']
high_value_threshold = general_params['high_value_threshold']
max_high_value_items_per_son = general_params['max_high_value_items_per_son']
deferred_diamonds_per_son = general_params['deferred_diamonds_per_son']
immediate_tax_weight = general_params['immediate_tax_weight']
total_tax_weight = general_params['total_tax_weight']

# Read items and values from table_1.csv
items_data = []
table_1_path = os.path.join(data_dir, 'table_1.csv')
with open(table_1_path, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        items_data.append({
            'Item': row['Item'].strip(),
            'Value': int(row['Value'].strip())
        })

n = len(items_data)
items = [item['Item'] for item in items_data]
values = [item['Value'] for item in items_data]
total_inheritance_value = sum(values)

# Identify special item categories based on names
jr_indices = [i for i, item_name in enumerate(items) if 'Jack Russell' in item_name]
diamond_indices = [i for i, item_name in enumerate(items) if 'Diamond' in item_name]
high_value_indices = [i for i, val in enumerate(values) if val > high_value_threshold]

# --- Model Creation ---
model = gp.Model("Inheritance_Split_Revised")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# Decision variables:
# x[i, s, t] = 1 if item i goes to son s (0=son1, 1=son2) with transfer type t (0=immediate, 1=deferred)
x = model.addVars(n, 2, 2, vtype=GRB.BINARY, name="x")

# Auxiliary variables for absolute differences in objective function
diff_immediate_abs = model.addVar(vtype=GRB.CONTINUOUS, name="diff_immediate_abs", lb=0)
diff_total_abs = model.addVar(vtype=GRB.CONTINUOUS, name="diff_total_abs", lb=0)

# --- Expressions for values ---
# Immediate values for each son
value_son1_immediate = gp.quicksum(values[i] * x[i, 0, 0] for i in range(n))
value_son2_immediate = gp.quicksum(values[i] * x[i, 1, 0] for i in range(n))

# Total values for each son (immediate + deferred)
value_son1_total = gp.quicksum(values[i] * (x[i, 0, 0] + x[i, 0, 1]) for i in range(n))
value_son2_total = gp.quicksum(values[i] * (x[i, 1, 0] + x[i, 1, 1]) for i in range(n))

# --- Objective Function ---
# Minimize a weighted sum of absolute differences in immediate tax-weighted value and total value
# Linearize absolute difference for immediate values
model.addConstr(diff_immediate_abs >= value_son1_immediate - value_son2_immediate, "ImmediateDiff_pos")
model.addConstr(diff_immediate_abs >= value_son2_immediate - value_son1_immediate, "ImmediateDiff_neg")

# Linearize absolute difference for total values
model.addConstr(diff_total_abs >= value_son1_total - value_son2_total, "TotalDiff_pos")
model.addConstr(diff_total_abs >= value_son2_total - value_son1_total, "TotalDiff_neg")

model.setObjective(immediate_tax_weight * diff_immediate_abs + total_tax_weight * diff_total_abs, GRB.MINIMIZE)

# --- Constraints ---

# 1. Each item must be assigned to exactly one son and one transfer type
for i in range(n):
    model.addConstr(gp.quicksum(x[i, s, t] for s in [0, 1] for t in [0, 1]) == 1, f"AssignItem_{i}")

# 2. Jack Russell racing dogs must not be separated
if len(jr_indices) == 2:
    jr_idx1, jr_idx2 = jr_indices[0], jr_indices[1]
    for s in [0, 1]: # For each son
        for t in [0, 1]: # For each transfer type
            # Both dogs must go to the same son with the same transfer type
            model.addConstr(x[jr_idx1, s, t] == x[jr_idx2, s, t], f"JRSeparation_Son{s+1}_Type{t}")

# 3. `son1_min_share`: Son 1's total share must be at least son1_min_share of total inheritance value
model.addConstr(value_son1_total >= son1_min_share * total_inheritance_value, "Son1MinShare")

# 4. `max_high_value_items_per_son`: High-value items cannot be concentrated beyond this limit for any son
for s in [0, 1]: # For each son
    # Count high-value items assigned to son 's' (immediate or deferred)
    high_value_count_son_s = gp.quicksum(x[i, s, t] for i in high_value_indices for t in [0, 1])
    model.addConstr(high_value_count_son_s <= max_high_value_items_per_son, f"MaxHighValueItems_Son{s+1}")

# 5. `deferred_diamonds_per_son`: Limit on deferred diamond items per son
for s in [0, 1]: # For each son
    # Count deferred diamond items assigned to son 's'
    deferred_diamonds_count_son_s = gp.quicksum(x[i, s, 1] for i in diamond_indices) # t=1 for deferred
    model.addConstr(deferred_diamonds_count_son_s <= deferred_diamonds_per_son, f"DeferredDiamonds_Son{s+1}")

# --- Solve the model ---
model.optimize()

# --- Print Solution ---
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("Optimization did not find an optimal solution.")
    print(f"Status: {model.status}")
