import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    """
    Returns the absolute path to the data file.
    Assumes the script is executed from the workspace root directory.
    """
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)

def solve_revised_problem():
    # Load data
    table_path = get_data_path('table_3_3.csv')
    params_path = get_data_path('general_parameters.csv')
    
    df_clerks = pd.read_csv(table_path)
    df_params = pd.read_csv(params_path)
    
    # Extract parameters from general_parameters.csv
    sales_goal = float(df_params.loc[df_params['Parameter_Name'] == 'monthly_sales_goal', 'Value'].values[0])
    pt_ft_overtime_ratio = float(df_params.loc[df_params['Parameter_Name'] == 'pt_ft_overtime_ratio', 'Value'].values[0])
    
    # Extract clerk data for Full-time and Part-time roles
    ft_row = df_clerks[df_clerks['Role'] == 'Full-time'].iloc[0]
    pt_row = df_clerks[df_clerks['Role'] == 'Part-time'].iloc[0]
    
    # Default number of clerks, as per original heuristic's comment
    num_ft = 5
    num_pt = 4
    
    # Check if the CSV has a column for the number of clerks, otherwise use defaults
    for col in df_clerks.columns:
        if any(kw in col.lower() for kw in ['num', 'clerks', 'employees', 'count', '人员', '数量']):
            num_ft = float(ft_row[col])
            num_pt = float(pt_row[col])
            break
            
    # Extract specific clerk parameters for calculations
    ft_monthly_hours = ft_row['Monthly_Working_Hours']
    ft_sales_per_hour = ft_row['Sales_Volume_Pairs_Per_Hour']
    
    pt_monthly_hours = pt_row['Monthly_Working_Hours']
    pt_sales_per_hour = pt_row['Sales_Volume_Pairs_Per_Hour']
    
    # Calculate normal sales from full employment of all sales clerks
    normal_sales_ft = num_ft * ft_monthly_hours * ft_sales_per_hour
    normal_sales_pt = num_pt * pt_monthly_hours * pt_sales_per_hour
    total_normal_sales = normal_sales_ft + normal_sales_pt
    
    # Calculate the sales required from overtime. If negative, it means normal sales already meet the goal.
    required_overtime_sales = sales_goal - total_normal_sales
    
    # Create a new Gurobi model
    model = gp.Model("ShoeStore_Overtime_Optimization")
    
    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)
    
    # Decision Variables: Overtime hours for full-time (y_ft) and part-time (y_pt) clerks
    # Variables must be non-negative
    y_ft = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="overtime_hours_full_time")
    y_pt = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="overtime_hours_part_time")
    
    # Objective: Minimize total overtime hours
    model.setObjective(y_ft + y_pt, GRB.MINIMIZE)
    
    # Constraint 1: Achieve monthly sales goal
    # The sum of sales from overtime hours must be at least the required_overtime_sales.
    # If required_overtime_sales is negative (goal met by normal hours), this constraint
    # will be easily satisfied by zero overtime, which is consistent with minimizing overtime.
    model.addConstr(ft_sales_per_hour * y_ft + pt_sales_per_hour * y_pt >= required_overtime_sales, "Sales_Goal_Constraint")
    
    # Constraint 2 (NEW): Part-time overtime hours must be at least a specified ratio of full-time overtime hours
    model.addConstr(y_pt >= pt_ft_overtime_ratio * y_ft, "PT_FT_Overtime_Ratio_Constraint")
    
    # Optimize the model
    model.optimize()
    
    # Output the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 4)}")
    else:
        print(f"Model did not solve to optimality. Gurobi status code: {model.status}")

if __name__ == '__main__':
    solve_revised_problem()
