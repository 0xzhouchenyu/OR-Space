import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine the base directory for data files
    # This assumes the script is run from the 'src' directory or similar,
    # and data is in '../data' relative to the script's location.
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    
    # Load demand data from table_1.csv
    demand = {}
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # Extract quarter numbers from the header (e.g., '1', '2', '3', '4')
        quarters = [int(h) for h in header[1:]]
        for row in reader:
            product = row[0].strip()
            # Populate demand dictionary: demand[(product, quarter)] = quantity
            for j, q in enumerate(quarters):
                demand[(product, q)] = int(row[j+1])
    
    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    
    # Define sets for products and quarters
    products = ['I', 'II', 'III']
    # Quarters are already loaded from demand header
    
    # Extract core parameters
    init_inv = params['initial_inventory']
    end_inv_req = params['end_inventory_requirement']
    # Renamed for clarity as it's the overall cap before normal/peak split
    total_production_hours_per_quarter_overall_cap = params['production_hours_per_quarter'] 
    
    hours_per_unit = {'I': params['product_I_hours_per_unit'],
                      'II': params['product_II_hours_per_unit'],
                      'III': params['product_III_hours_per_unit']}
    
    delay_penalty = {'I': params['delay_penalty_product_I'],
                     'II': params['delay_penalty_product_II'],
                     'III': params['delay_penalty_product_III']}
    
    inv_cost = params['inventory_cost_per_unit']

    # Load new parameters for normal and peak production hours
    normal_hours_cap_fraction = {q: params[f'normal_hours_cap_fraction_q{q}'] for q in quarters}
    peak_hours_cap = {q: params[f'peak_hours_cap_q{q}'] for q in quarters}
    peak_cost_per_hour = {q: params[f'peak_cost_per_hour_q{q}'] for q in quarters}

    # Calculate the actual normal hours cap for each quarter
    normal_hours_cap = {q: normal_hours_cap_fraction[q] * total_production_hours_per_quarter_overall_cap for q in quarters}
    
    # Create a new Gurobi model
    model = gp.Model("ProductionScheduling")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables: production quantities, split into normal and peak hours
    # x_normal[(p, t)]: units of product p produced in quarter t using normal hours
    x_normal = model.addVars(products, quarters, vtype=GRB.INTEGER, lb=0, name="x_normal")
    # x_peak[(p, t)]: units of product p produced in quarter t using peak hours
    x_peak = model.addVars(products, quarters, vtype=GRB.INTEGER, lb=0, name="x_peak")
    
    # Inventory variables
    # inv[(p, t)]: net inventory of product p at the end of quarter t (can be negative)
    inv = model.addVars(products, quarters, vtype=GRB.CONTINUOUS, name="inv")
    # inv_pos[(p, t)]: positive part of inventory (actual stock held)
    inv_pos = model.addVars(products, quarters, vtype=GRB.CONTINUOUS, lb=0, name="inv_pos")
    # inv_neg[(p, t)]: negative part of inventory (backlog/delay)
    inv_neg = model.addVars(products, quarters, vtype=GRB.CONTINUOUS, lb=0, name="inv_neg")
    
    # --- Constraints ---
    
    # Inventory balance constraints
    for p in products:
        # Quarter 1 inventory balance
        model.addConstr(inv[(p, 1)] == init_inv + x_normal[(p, 1)] + x_peak[(p, 1)] - demand[(p, 1)], 
                        f"inv_balance_{p}_1")
        # Quarters 2-4 inventory balance
        for t in range(2, 5):
            model.addConstr(inv[(p, t)] == inv[(p, t-1)] + x_normal[(p, t)] + x_peak[(p, t)] - demand[(p, t)], 
                            f"inv_balance_{p}_{t}")
    
    # Split inventory into positive (holding) and negative (delay) parts
    for p in products:
        for t in quarters:
            model.addConstr(inv[(p, t)] == inv_pos[(p, t)] - inv_neg[(p, t)], 
                            f"inv_split_{p}_{t}")
    
    # End of Q4 inventory requirement: must be at least end_inv_req for each product
    for p in products:
        model.addConstr(inv[(p, 4)] >= end_inv_req, 
                        f"end_inv_req_{p}")
    
    # Production hours constraints per quarter (REVISED logic)
    for t in quarters:
        # Calculate total hours used in normal and peak bands for the current quarter
        total_normal_hours_used = gp.quicksum(hours_per_unit[p] * x_normal[(p, t)] for p in products)
        total_peak_hours_used = gp.quicksum(hours_per_unit[p] * x_peak[(p, t)] for p in products)

        # Constraint 1: Normal hours usage cannot exceed the normal hours cap for the quarter
        model.addConstr(total_normal_hours_used <= normal_hours_cap[t], 
                        f"normal_hours_cap_{t}")
        
        # Constraint 2: Peak hours usage cannot exceed the peak hours cap for the quarter
        model.addConstr(total_peak_hours_used <= peak_hours_cap[t], 
                        f"peak_hours_cap_{t}")

        # Constraint 3: The sum of normal and peak hours used cannot exceed the overall total production hours cap for the quarter
        model.addConstr(total_normal_hours_used + total_peak_hours_used <= total_production_hours_per_quarter_overall_cap, 
                        f"total_hours_overall_cap_{t}")
    
    # Product I cannot be produced in the second quarter (in either normal or peak hours)
    model.addConstr(x_normal[('I', 2)] == 0, "no_prod_I_q2_normal")
    model.addConstr(x_peak[('I', 2)] == 0, "no_prod_I_q2_peak")
    
    # --- Objective Function ---
    # Minimize total cost: delay penalties + inventory holding costs + peak production costs
    
    # Part 1: Delay penalties and inventory holding costs (from original problem)
    objective = gp.quicksum(delay_penalty[p] * inv_neg[(p, t)] + inv_cost * inv_pos[(p, t)] 
                            for p in products for t in quarters)
    
    # Part 2: Additional cost for peak production hours (from revision)
    objective += gp.quicksum(peak_cost_per_hour[t] * gp.quicksum(hours_per_unit[p] * x_peak[(p, t)] for p in products)
                             for t in quarters)
    
    model.setObjective(objective, GRB.MINIMIZE)
    
    # Optimize the model
    model.optimize()
    
    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # Handle cases where the model does not find an optimal solution
        print(f"Model did not solve to optimality. Status: {model.status}")
        # A common practice is to print a specific value indicating failure or infeasibility
        print(f"FINAL_OBJ_VALUE: -1") 

if __name__ == "__main__":
    main()
