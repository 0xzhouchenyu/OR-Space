import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Data Loading ---
# Determine the directory where the script is being executed from.
# The instruction states: "Your script will be saved and executed from the revised workspace root directory."
# So, os.path.dirname(os.path.abspath(__file__)) should be the root directory.
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load general parameters
initial_capital = 0.0
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Parameter_Name'].strip() == 'initial_capital':
            initial_capital = float(row['Value'].strip())

# Load liquidity policy parameters
min_year3_reserve = 0.0
reserve_shortfall_penalty = 0.0
with open(os.path.join(data_dir, 'liquidity_policy.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Parameter_Name'].strip() == 'min_year3_reserve':
            min_year3_reserve = float(row['Value'].strip())
        elif row['Parameter_Name'].strip() == 'reserve_shortfall_penalty':
            reserve_shortfall_penalty = float(row['Value'].strip())

# Project data is implicitly used by hardcoded variable bounds and interest rates,
# matching the structure of the original heuristic and table_1.csv.

# --- Gurobi Model Setup ---
model = gp.Model("Investment_Maximization")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# --- Decision Variables ---
# x1_1: amount invested in Project 1 at beginning of Year 1
# x1_2: amount invested in Project 1 at beginning of Year 2
# x1_3: amount invested in Project 1 at beginning of Year 3
# Project 1 has unlimited capacity and 1.20 interest rate, matures same year.
x1_1 = model.addVar(lb=0, name="x1_1")
x1_2 = model.addVar(lb=0, name="x1_2")
x1_3 = model.addVar(lb=0, name="x1_3")

# x2: amount invested in Project 2 at beginning of Year 1
# Project 2 has 120000 capacity and 1.50 interest rate, matures end of Year 2.
x2 = model.addVar(lb=0, ub=120000, name="x2")

# x3: amount invested in Project 3 at beginning of Year 2
# Project 3 has 150000 capacity and 1.60 interest rate, matures end of Year 2.
x3 = model.addVar(lb=0, ub=150000, name="x3")

# x4: amount invested in Project 4 at beginning of Year 3
# Project 4 has 100000 capacity and 1.40 interest rate, matures end of Year 3.
x4 = model.addVar(lb=0, ub=100000, name="x4")

# New variables for liquidity policy
# cash_held_Y3_var: amount of cash held uninvested at the beginning of Year 3.
# This cash remains through the end of Year 3 and counts towards final wealth.
cash_held_Y3_var = model.addVar(lb=0, name="cash_held_Y3")

# s_Y3: shortfall in the desired Year 3 reserve (min_year3_reserve).
# This variable will be penalized in the objective.
s_Y3 = model.addVar(lb=0, name="s_Y3")

# --- Constraints ---

# Year 1 budget constraint:
# Total investment in Year 1 projects cannot exceed initial capital.
model.addConstr(x1_1 + x2 <= initial_capital, "Year1_Budget")

# Year 2 budget constraint:
# Available cash at beginning of Year 2 = proceeds from x1_1 (matured end of Year 1).
cash_available_Y2 = x1_1 * 1.20
# Total investment in Year 2 projects cannot exceed available cash.
model.addConstr(x1_2 + x3 <= cash_available_Y2, "Year2_Budget")

# Year 3 budget and liquidity constraints:
# Available cash at beginning of Year 3 (before any Year 3 investments)
# = proceeds from x1_2 (matured end of Year 2)
# + proceeds from x2 (matured end of Year 2)
# + proceeds from x3 (matured end of Year 2)
cash_available_Y3 = x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60

# Define cash_held_Y3_var:
# This is the cash available at the start of Year 3 minus the amount invested in Year 3 projects.
# The lower bound of 0 for cash_held_Y3_var implicitly ensures that
# (x1_3 + x4) <= cash_available_Y3 (i.e., cannot invest more than available cash).
model.addConstr(cash_held_Y3_var == cash_available_Y3 - (x1_3 + x4), "Cash_Held_Y3_Definition")

# Shortfall definition:
# s_Y3 must be at least the difference between the desired reserve (min_year3_reserve)
# and the actual cash held (cash_held_Y3_var).
# Since s_Y3 is penalized in the objective function, Gurobi will minimize it,
# effectively making s_Y3 = max(0, min_year3_reserve - cash_held_Y3_var).
model.addConstr(s_Y3 >= min_year3_reserve - cash_held_Y3_var, "Shortfall_Definition")

# --- Objective Function ---
# Maximize total principal plus interest at the end of Year 3,
# minus any penalty for not meeting the Year 3 liquidity reserve.
# Total wealth at end of Year 3 includes:
# 1. Proceeds from Project 1 investment made in Year 3 (x1_3 * 1.20)
# 2. Proceeds from Project 4 investment made in Year 3 (x4 * 1.40)
# 3. The uninvested cash held at the beginning of Year 3 (cash_held_Y3_var),
#    which remains cash through the end of the horizon.
total_wealth_end_Y3 = (x1_3 * 1.20) + (x4 * 1.40) + cash_held_Y3_var

# Penalty for reserve shortfall:
penalty_cost = s_Y3 * reserve_shortfall_penalty

# The objective is to maximize the net value.
model.setObjective(total_wealth_end_Y3 - penalty_cost, GRB.MAXIMIZE)

# --- Solve the model ---
model.optimize()

# --- Output Results ---
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # If the model is not optimal (e.g., infeasible, unbounded),
    # print NaN or handle appropriately.
    print(f"FINAL_OBJ_VALUE: {float('nan')}")
