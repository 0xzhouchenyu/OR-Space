import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_problem():
    # Load data from general_parameters.csv
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    # Define sets for the problem dimensions
    SALES_POINTS = ['sp1', 'sp2', 'sp3']
    DAYS = ['day1', 'day2', 'day3']
    VEHICLES = ['truck', 'van', 'motorcycle', 'electric_vehicle']

    # Initialize Gurobi model
    model = gp.Model("Transportation_Pollution_Minimization_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Decision Variables
    # x[v, sp, d]: Number of trips for vehicle 'v' to sales point 'sp' on day 'd'
    x = model.addVars(VEHICLES, SALES_POINTS, DAYS, vtype=GRB.INTEGER, lb=0, name="trips")
    
    # y[sp, d]: Binary variable to choose vehicle family for a given sales point and day
    # y[sp, d] = 1 if truck/electric_vehicle family is used
    # y[sp, d] = 0 if van/motorcycle family is used
    y = model.addVars(SALES_POINTS, DAYS, vtype=GRB.BINARY, name="family_choice")

    # Objective Function: Minimize total pollution
    model.setObjective(
        gp.quicksum(params[v + '_pollution'] * x[v, sp, d] 
                    for v in VEHICLES 
                    for sp in SALES_POINTS 
                    for d in DAYS), 
        GRB.MINIMIZE
    )

    # Constraints

    # C1: Sales Point Demand Fulfillment
    # For each sales point, the total delivered capacity across all days must meet its committed share of total product units.
    for sp in SALES_POINTS:
        total_demand_sp = params['product_units'] * params['sales_point_share_' + sp]
        model.addConstr(
            gp.quicksum(params[v + '_capacity'] * x[v, sp, d] 
                        for v in VEHICLES 
                        for d in DAYS) >= total_demand_sp,
            f"Demand_SP_{sp}"
        )

    # C2: Total Pollution Limit
    # The overall maximum total pollution ceiling across all trips must not be exceeded.
    model.addConstr(
        gp.quicksum(params[v + '_pollution'] * x[v, sp, d] 
                    for v in VEHICLES 
                    for sp in SALES_POINTS 
                    for d in DAYS) <= params['max_total_pollution'],
        "Max_Total_Pollution"
    )

    # C3: Minimum Total Truck Trips
    # A minimum total number of truck trips is required across all sales points and days.
    model.addConstr(
        gp.quicksum(x['truck', sp, d] 
                    for sp in SALES_POINTS 
                    for d in DAYS) >= params['min_truck_trips'],
        "Min_Overall_Truck_Trips"
    )

    # C4: Service Discipline (Vehicle Family Choice)
    # On a given sales point-day, deliveries must come from either the truck/electric-vehicle family OR the van/motorcycle family.
    # This is enforced using Big-M constraints with the binary variable 'y'.
    for sp in SALES_POINTS:
        for d in DAYS:
            # If y[sp, d] = 1 (Truck/Electric Vehicle family chosen), then van and motorcycle trips must be zero.
            model.addConstr(x['van', sp, d] <= params['M_van_sp_day'] * (1 - y[sp, d]), 
                            f"Family_Choice_Van_SP{sp}_Day{d}")
            model.addConstr(x['motorcycle', sp, d] <= params['M_moto_sp_day'] * (1 - y[sp, d]), 
                            f"Family_Choice_Moto_SP{sp}_Day{d}")
            
            # If y[sp, d] = 0 (Van/Motorcycle family chosen), then truck and electric_vehicle trips must be zero.
            model.addConstr(x['truck', sp, d] <= params['M_truck_sp_day'] * y[sp, d], 
                            f"Family_Choice_Truck_SP{sp}_Day{d}")
            model.addConstr(x['electric_vehicle', sp, d] <= params['M_ev_sp_day'] * y[sp, d], 
                            f"Family_Choice_EV_SP{sp}_Day{d}")

    # C5: Sales Point Truck Share Promises
    # For each sales point, a minimum fraction of its total trips must be truck trips.
    for sp in SALES_POINTS:
        total_trips_sp = gp.quicksum(x[v, sp, d] for v in VEHICLES for d in DAYS)
        truck_trips_sp = gp.quicksum(x['truck', sp, d] for d in DAYS)
        
        # Constraint: truck_trips_sp >= min_truck_share_sp * total_trips_sp
        # Rearrange to a linear form: truck_trips_sp - min_truck_share_sp * total_trips_sp >= 0
        model.addConstr(
            truck_trips_sp - params['min_truck_share_' + sp] * total_trips_sp >= 0,
            f"Min_Truck_Share_SP_{sp}"
        )

    # Optimize the model
    model.optimize()

    # Output the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Handle cases where no optimal solution is found (e.g., infeasible, unbounded)
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_revised_problem()
