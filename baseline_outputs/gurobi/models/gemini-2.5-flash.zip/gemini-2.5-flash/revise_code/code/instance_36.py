import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    """
    Calculates the Euclidean distance between two points.
    """
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def solve():
    """
    Solves the Vehicle Routing Problem with Hard Time Windows (VRPHTW)
    with revised constraints for low-emission zones and outsourcing.
    """
    # Construct paths to data files
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')

    # --- Load General Parameters ---
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader) # Skip header
        for row in reader:
            if row:
                param_name = row[0]
                param_value = row[1]
                params[param_name] = param_value

    num_customers = int(params['num_customers'])
    truck_capacity = float(params['truck_capacity'])
    inhouse_truck_limit = int(params['inhouse_truck_limit']) # New fleet limit

    # Parse depot coordinates
    depot_str = params.get('depot_coordinates', '(40,50)').strip('()')
    depot_x, depot_y = map(float, depot_str.split(','))

    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])

    # --- Load Customer Data ---
    coords = [(depot_x, depot_y)] # Node 0 is depot
    demands_list = [0] # Demand for depot is 0
    tw_list = [(depot_tw_start, depot_tw_end)] # Time window for depot
    svc_list = [0] # Service time for depot is 0
    outsource_cost_list = [0] # Outsourcing cost for depot is 0
    mandatory_external_list = [0] # Depot is not mandatory external

    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((float(row['Coordinates_X']), float(row['Coordinates_Y'])))
            demands_list.append(float(row['Demand']))
            tw_list.append((float(row['Time_Window_Start']), float(row['Time_Window_End'])))
            svc_list.append(float(row['Service_Duration']))
            outsource_cost_list.append(float(row['Outsource_Cost']))
            mandatory_external_list.append(int(row['Mandatory_External']))

    # --- Model Setup ---
    n = len(coords) # Total number of nodes (depot + customers)
    N = list(range(1, n)) # Set of customers (nodes 1 to num_customers)
    V = list(range(n)) # Set of all nodes (depot + customers)

    # Calculate all-pairs distances
    dist = {}
    for i in V:
        for j in V:
            dist[i, j] = calculate_distance(coords[i], coords[j])

    # Pre-filter arcs based on time window feasibility (as in original heuristic)
    # An arc (i,j) is infeasible if earliest arrival at i + service at i + travel to j
    # is later than the latest allowed arrival at j.
    A = []
    for i in V:
        for j in V:
            if i == j:
                continue
            
            current_svc_time = svc_list[i] # Service time at node i (0 for depot)
            
            # Check if travel from i to j is possible within j's time window
            if tw_list[i][0] + current_svc_time + dist[i, j] > tw_list[j][1]:
                continue
            A.append((i, j))
    A_set = set(A) # For efficient lookup

    # Create Gurobi model
    model = gp.Model("VRPHTW_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- Decision Variables ---
    # x[i, j]: Binary, 1 if an in-house truck travels from node i to node j
    x = model.addVars(A, vtype=GRB.BINARY, name="x")
    
    # t[i]: Continuous, arrival time at node i
    t = model.addVars(V, vtype=GRB.CONTINUOUS, lb=0, name="t")
    
    # y[i]: Binary, 1 if customer i is served by an in-house truck, 0 if outsourced
    y = model.addVars(N, vtype=GRB.BINARY, name="y")

    # --- Auxiliary Variables for Constraints ---
    # q[i]: Continuous, load on the truck after visiting customer i (for capacity)
    q = model.addVars(N, vtype=GRB.CONTINUOUS, lb=0, name="q")
    
    # u[i]: Continuous, MTZ variable for subtour elimination
    u = model.addVars(N, vtype=GRB.CONTINUOUS, lb=0, name="u")

    # --- Objective Function ---
    # Minimize total in-house travel distance + total outsourcing cost
    model.setObjective(
        gp.quicksum(dist[i, j] * x[i, j] for i, j in A) +
        gp.quicksum(outsource_cost_list[i] * (1 - y[i]) for i in N),
        GRB.MINIMIZE
    )

    # --- Constraints ---

    # 1. Fleet size limit: Maximum number of in-house trucks allowed
    model.addConstr(gp.quicksum(x[0, j] for j in N if (0, j) in A_set) <= inhouse_truck_limit, "Fleet_Limit")

    # 2. Each customer in N is either served by an in-house truck or outsourced
    for i in N:
        # In-degree must be 1 if served by in-house truck (y[i]=1), 0 otherwise (y[i]=0)
        model.addConstr(gp.quicksum(x[j, i] for j in V if (j, i) in A_set) == y[i], f"Customer_InDegree_{i}")
        # Out-degree must be 1 if served by in-house truck (y[i]=1), 0 otherwise (y[i]=0)
        model.addConstr(gp.quicksum(x[i, j] for j in V if (i, j) in A_set) == y[i], f"Customer_OutDegree_{i}")

    # 3. Trucks leaving the depot must return to the depot
    model.addConstr(
        gp.quicksum(x[i, 0] for i in N if (i, 0) in A_set) == gp.quicksum(x[0, j] for j in N if (0, j) in A_set),
        "Depot_Return"
    )

    # 4. Mandatory external customers must be outsourced (y[i] = 0)
    for i in N:
        if mandatory_external_list[i] == 1:
            model.addConstr(y[i] == 0, f"Mandatory_External_{i}")

    # 5. Time window constraints
    # Depot time window
    model.addConstr(t[0] >= tw_list[0][0], "Depot_TW_Start")
    model.addConstr(t[0] <= tw_list[0][1], "Depot_TW_End")

    # Calculate a sufficiently large M for time constraints
    M_time = max(tw[1] for tw in tw_list) + max(svc_list) + max(dist[i,j] for i,j in A) + 100 # Add buffer

    # Customer time windows (conditional on being served by an in-house truck)
    for i in N:
        # If y[i]=1, t[i] must be within [tw_list[i][0], tw_list[i][1]]
        # If y[i]=0, t[i] is unconstrained (effectively 0 due to lb=0 and other constraints)
        model.addConstr(t[i] >= tw_list[i][0] * y[i], f"Customer_TW_Start_{i}")
        model.addConstr(t[i] <= tw_list[i][1] + M_time * (1 - y[i]), f"Customer_TW_End_{i}")

    # Time precedence constraints: t_i + service_i + travel_ij <= t_j if x_ij = 1
    for i, j in A:
        # svc_list[0] is 0, so this constraint works for depot as well.
        model.addConstr(t[i] + svc_list[i] + dist[i, j] - t[j] <= M_time * (1 - x[i, j]), f"Time_Precedence_{i}_{j}")

    # 6. Capacity constraints (using q[i] as cumulative load on the truck)
    for i in N:
        # If customer i is served (y[i]=1), its demand must be loaded, and total load must not exceed capacity
        model.addConstr(q[i] >= demands_list[i] * y[i], f"Load_LowerBound_{i}")
        model.addConstr(q[i] <= truck_capacity * y[i], f"Load_UpperBound_{i}")

    for i, j in A:
        if i == 0 and j in N: # From depot to a customer
            # If x[0,j]=1, then q[j] must be at least demands_list[j]
            model.addConstr(q[j] >= demands_list[j] - truck_capacity * (1 - x[0, j]), f"Capacity_Depot_to_Customer_{j}")
        elif i in N and j in N: # From customer to customer
            # If x[i,j]=1, then q[j] must be at least q[i] + demands_list[j]
            model.addConstr(q[j] >= q[i] + demands_list[j] - truck_capacity * (1 - x[i, j]), f"Capacity_Customer_to_Customer_{i}_{j}")
        # No capacity constraint for arcs returning to depot (j=0) as load is dropped.

    # 7. Subtour elimination constraints (MTZ-like using u[i])
    # M_mtz for MTZ constraints (n is total nodes, so n-1 is max customer index)
    M_mtz = n 

    for i in N:
        # If customer i is served (y[i]=1), u[i] must be between 1 and n-1
        model.addConstr(u[i] >= y[i], f"MTZ_LowerBound_{i}")
        model.addConstr(u[i] <= (n - 1) * y[i], f"MTZ_UpperBound_{i}")

    for i in N:
        for j in N:
            if i != j and (i, j) in A_set:
                # Standard MTZ constraint: u[i] - u[j] + M_mtz * x[i, j] <= M_mtz - 1
                # This is relaxed if either customer i or j is outsourced (y[i]=0 or y[j]=0)
                model.addConstr(
                    u[i] - u[j] + M_mtz * x[i, j] <= M_mtz - 1 + M_mtz * (1 - y[i]) + M_mtz * (1 - y[j]),
                    f"MTZ_{i}_{j}"
                )

    # --- Optimize and Print Results ---
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {round(obj, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

# Execute the solver
if __name__ == '__main__':
    solve()
