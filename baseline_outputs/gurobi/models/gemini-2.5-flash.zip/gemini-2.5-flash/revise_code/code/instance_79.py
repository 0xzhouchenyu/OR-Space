import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility function (from src/utils.py) ---
def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- Main script ---
# Determine the base directory for data access
# This assumes the script is run from the workspace root or its immediate subdirectory (e.g., 'src')
# and data is in 'data/' relative to the root.
script_dir = os.path.dirname(os.path.abspath(__file__))
# Adjust path to go up one level from 'src' to the root, then into 'data'
data_dir = os.path.join(script_dir, '..', 'data') 

# Load parameters from the general_parameters.csv file
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters for clarity and direct use in the model
# Original parameters
sell_price_table = params['sell_price_table']
sell_price_chair = params['sell_price_chair']
sell_price_bookshelf = params['sell_price_bookshelf']

cost_table = params['manufacturing_cost_table']
cost_chair = params['manufacturing_cost_chair']
cost_bookshelf = params['manufacturing_cost_bookshelf']

space_table = params['warehouse_space_table']
space_chair = params['warehouse_space_chair']
space_bookshelf = params['warehouse_space_bookshelf']

max_warehouse = params['max_warehouse_space']
min_tables = params['min_tables']
min_bookshelves = params['min_bookshelves']
max_total = params['max_total_items']

# New parameters introduced by the revision
labor_hours_table = params['labor_hours_table']
labor_hours_chair = params['labor_hours_chair']
labor_hours_bookshelf = params['labor_hours_bookshelf']

max_labor_hours_month_regular = params['max_labor_hours_month_regular']
max_labor_hours_month_rush = params['max_labor_hours_month_rush']
max_rush_items_month = params['max_rush_items_month']

rush_profit_bonus_table = params['rush_profit_bonus_table']
rush_profit_bonus_chair = params['rush_profit_bonus_chair']
rush_profit_bonus_bookshelf = params['rush_profit_bonus_bookshelf']

# Calculate base profit per item (selling price - manufacturing cost)
profit_table_base = sell_price_table - cost_table
profit_chair_base = sell_price_chair - cost_chair
profit_bookshelf_base = sell_price_bookshelf - cost_bookshelf

# Calculate total profit per item type, distinguishing between regular and rush orders
profit_table_regular = profit_table_base
profit_chair_regular = profit_chair_base
profit_bookshelf_regular = profit_bookshelf_base

profit_table_rush = profit_table_base + rush_profit_bonus_table
profit_chair_rush = profit_chair_base + rush_profit_bonus_chair
profit_bookshelf_rush = profit_bookshelf_base + rush_profit_bonus_bookshelf

# Create a new Gurobi model
model = gp.Model("Furniture_Production_Revised")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# Decision variables:
# x_item_type_order_type represents the number of items of a specific type (tables, chairs, bookshelves)
# produced under a specific order type (regular, rush).
# All variables must be integers and non-negative.
x_tables_regular = model.addVar(vtype=GRB.INTEGER, name="tables_regular", lb=0)
x_chairs_regular = model.addVar(vtype=GRB.INTEGER, name="chairs_regular", lb=0)
x_bookshelves_regular = model.addVar(vtype=GRB.INTEGER, name="bookshelves_regular", lb=0)

x_tables_rush = model.addVar(vtype=GRB.INTEGER, name="tables_rush", lb=0)
x_chairs_rush = model.addVar(vtype=GRB.INTEGER, name="chairs_rush", lb=0)
x_bookshelves_rush = model.addVar(vtype=GRB.INTEGER, name="bookshelves_rush", lb=0)

# Objective function: Maximize total profit from all regular and rush orders
model.setObjective(
    profit_table_regular * x_tables_regular +
    profit_chair_regular * x_chairs_regular +
    profit_bookshelf_regular * x_bookshelves_regular +
    profit_table_rush * x_tables_rush +
    profit_chair_rush * x_chairs_rush +
    profit_bookshelf_rush * x_bookshelves_rush,
    GRB.MAXIMIZE
)

# Constraints

# 1. Warehouse space constraint: Total space used by all items (regular + rush) must not exceed max_warehouse_space.
model.addConstr(
    space_table * (x_tables_regular + x_tables_rush) +
    space_chair * (x_chairs_regular + x_chairs_rush) +
    space_bookshelf * (x_bookshelves_regular + x_bookshelves_rush) <= max_warehouse,
    "Warehouse_Space_Total"
)

# 2. Minimum production requirements: Total production for tables and bookshelves (regular + rush)
# must meet the minimums.
model.addConstr(x_tables_regular + x_tables_rush >= min_tables, "Min_Tables_Combined")
model.addConstr(x_bookshelves_regular + x_bookshelves_rush >= min_bookshelves, "Min_Bookshelves_Combined")

# 3. Maximum total production: The sum of all items produced (regular + rush) must not exceed max_total_items.
model.addConstr(
    x_tables_regular + x_tables_rush +
    x_chairs_regular + x_chairs_rush +
    x_bookshelves_regular + x_bookshelves_rush <= max_total,
    "Max_Total_Items_Combined"
)

# 4. Regular Labor Hours Cap: Total labor hours for regular orders must not exceed max_labor_hours_month_regular.
model.addConstr(
    labor_hours_table * x_tables_regular +
    labor_hours_chair * x_chairs_regular +
    labor_hours_bookshelf * x_bookshelves_regular <= max_labor_hours_month_regular,
    "Max_Regular_Labor_Hours"
)

# 5. Rush Labor Hours Cap: Total labor hours for rush orders must not exceed max_labor_hours_month_rush.
model.addConstr(
    labor_hours_table * x_tables_rush +
    labor_hours_chair * x_chairs_rush +
    labor_hours_bookshelf * x_bookshelves_rush <= max_labor_hours_month_rush,
    "Max_Rush_Labor_Hours"
)

# 6. Maximum Total Rush Items: The total number of rush items must not exceed max_rush_items_month.
model.addConstr(
    x_tables_rush + x_chairs_rush + x_bookshelves_rush <= max_rush_items_month,
    "Max_Total_Rush_Items"
)

# Optimize the model
model.optimize()

# Output the final objective value as required
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case the model is not optimal (e.g., infeasible or unbounded)
    print("Optimization was not successful.")
    # For debugging, you might want to print model.status
    # print(f"Gurobi Status: {model.status}")
