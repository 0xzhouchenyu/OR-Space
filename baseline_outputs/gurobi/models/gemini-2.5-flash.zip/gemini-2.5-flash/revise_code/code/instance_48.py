import os
import csv
import gurobipy as gp
from gurobipy import GRB

# The load_csv_data utility function is provided in the original workspace context
# and is included here for self-containment as per instructions.
def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

def main():
    # Construct the path to the data directory relative to the script's location.
    # The script is expected to be in 'src/' and executed from the workspace root.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')

    # Load data from CSV files
    table1_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    general_params_data = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))

    # Parse general parameters into a dictionary for easy access
    param_dict = {}
    for row in general_params_data:
        param_dict[row['Parameter_Name']] = float(row['Value'])

    # Parse table_1 data
    # Assuming the order of rows in table_1.csv is Process I, Process II, Profit
    proc_I_row = table1_data[0]
    proc_II_row = table1_data[1]
    profit_row = table1_data[2]

    # Extract specific parameters for the model
    # Process I parameters
    a_I = float(proc_I_row['Model_A_hours_per_unit'])  # Hours for Model A in Process I
    b_I = float(proc_I_row['Model_B_hours_per_unit'])  # Hours for Model B in Process I
    process_I_hours_exact = param_dict['process_I_hours'] # Exact total hours for Process I

    # Process II parameters
    a_II = float(proc_II_row['Model_A_hours_per_unit'])  # Hours for Model A in Process II
    b_II = float(proc_II_row['Model_B_hours_per_unit'])  # Hours for Model B in Process II
    cap_II_regular = float(proc_II_row['Maximum_Weekly_Processing_Capacity']) # Regular capacity for Process II
    process_II_max_overtime = param_dict['process_II_max_overtime'] # Maximum allowable overtime for Process II

    # Profit parameters
    profit_A_base = float(profit_row['Model_A_hours_per_unit'])  # Base profit per unit of Model A
    profit_B_base = float(profit_row['Model_B_hours_per_unit'])  # Base profit per unit of Model B
    model_A_overtime_profit_reduction = param_dict['model_A_overtime_profit_reduction'] # Profit reduction for A in overtime
    model_B_overtime_profit_reduction = param_dict['model_B_overtime_profit_reduction'] # Profit reduction for B in overtime

    # Calculate actual profits for units produced during overtime
    profit_A_overtime = profit_A_base - model_A_overtime_profit_reduction
    profit_B_overtime = profit_B_base - model_B_overtime_profit_reduction

    # Business goal parameters (constraints)
    min_weekly_profit = param_dict['min_weekly_profit']
    min_model_A_units = param_dict['min_model_A_units']
    min_model_B_units = param_dict['min_model_B_units']

    # Create a new Gurobi model
    model = gp.Model("Microcomputer_Production_Revised")

    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)

    # Define Decision Variables:
    # We separate production into regular and overtime for Process II to handle profit reduction.
    # xA_r: Units of Model A produced using regular Process II time
    # xA_o: Units of Model A produced using overtime Process II time
    # xB_r: Units of Model B produced using regular Process II time
    # xB_o: Units of Model B produced using overtime Process II time
    xA_r = model.addVar(name="xA_regular", lb=0.0, vtype=GRB.CONTINUOUS)
    xA_o = model.addVar(name="xA_overtime", lb=0.0, vtype=GRB.CONTINUOUS)
    xB_r = model.addVar(name="xB_regular", lb=0.0, vtype=GRB.CONTINUOUS)
    xB_o = model.addVar(name="xB_overtime", lb=0.0, vtype=GRB.CONTINUOUS)

    # Helper expressions for total units of each model and total units overall
    total_A = xA_r + xA_o
    total_B = xB_r + xB_o
    total_units_produced = total_A + total_B

    # Set the Objective Function: Maximize the total number of units produced
    model.setObjective(total_units_produced, GRB.MAXIMIZE)

    # Add Constraints

    # 1. Process I exact processing time constraint:
    # The total time spent on Process I must exactly equal the specified hours.
    model.addConstr(a_I * total_A + b_I * total_B == process_I_hours_exact, "Process_I_Exact_Time")

    # 2. Process II regular capacity constraint:
    # The total time spent on Process II using regular capacity must not exceed its maximum.
    model.addConstr(a_II * xA_r + b_II * xB_r <= cap_II_regular, "Process_II_Regular_Capacity")

    # 3. Process II overtime capacity constraint:
    # The total time spent on Process II using overtime must not exceed the maximum allowed overtime.
    model.addConstr(a_II * xA_o + b_II * xB_o <= process_II_max_overtime, "Process_II_Overtime_Capacity")

    # 4. Minimum production requirement for Model A:
    model.addConstr(total_A >= min_model_A_units, "Min_Production_Model_A")

    # 5. Minimum production requirement for Model B:
    model.addConstr(total_B >= min_model_B_units, "Min_Production_Model_B")

    # 6. Minimum total weekly profit constraint:
    # The total profit (considering overtime reductions) must meet the minimum threshold.
    total_profit_expression = (profit_A_base * xA_r + profit_B_base * xB_r +
                               profit_A_overtime * xA_o + profit_B_overtime * xB_o)
    model.addConstr(total_profit_expression >= min_weekly_profit, "Min_Weekly_Profit_Goal")

    # Optimize the model
    model.optimize()

    # Print the final objective value if an optimal solution is found
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Handle cases where the model is not optimal (e.g., infeasible, unbounded)
        print(f"Optimization did not find an optimal solution. Status: {model.status}")

if __name__ == "__main__":
    main()
