import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility function (from src/utils.py, adapted for self-contained script) ---
def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- Main script ---
if __name__ == "__main__":
    # Determine the path to the data directory.
    # The script is expected to be run from the workspace root.
    # So, 'data' is a direct subdirectory.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load parameters from the CSV file
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Extract parameters for clarity and use in the model
    cow_price = params['cow_selling_price']
    sheep_price = params['sheep_selling_price']
    chicken_price = params['chicken_selling_price']
    cow_feed = params['cow_feed_cost']
    sheep_feed = params['sheep_feed_cost']
    chicken_feed = params['chicken_feed_cost']
    cow_manure = params['cow_manure_production']
    sheep_manure = params['sheep_manure_production']
    chicken_manure = params['chicken_manure_production']
    max_manure_capacity_base = params['max_manure_capacity'] # Base capacity
    max_chickens_overall = params['max_chickens'] # Overall limit for chickens
    min_cows_overall = params['min_cows'] # Overall minimum for cows
    min_sheep_overall = params['min_sheep'] # Overall minimum for sheep
    max_total_animals_base = params['max_total_animals'] # Base total animal capacity

    # New parameters from the revision brief
    premium_capacity_multiplier = params['premium_capacity_multiplier']
    premium_manure_multiplier = params['premium_manure_multiplier']
    expansion_cost = params['expansion_cost']
    premium_feed_multiplier = params['premium_feed_multiplier']
    base_land_usage_cow = params['base_land_usage_cow']
    base_land_usage_sheep = params['base_land_usage_sheep']
    base_land_usage_chicken = params['base_land_usage_chicken']
    base_land_capacity = params['base_land_capacity']
    expansion_land_increase = params['expansion_land_increase']

    # Create a new Gurobi model
    model = gp.Model("FarmProfitRevised")

    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # Number of regular animals
    cows = model.addVar(name="cows", vtype=GRB.INTEGER, lb=0)
    sheep = model.addVar(name="sheep", vtype=GRB.INTEGER, lb=0)
    chickens = model.addVar(name="chickens", vtype=GRB.INTEGER, lb=0)

    # Number of premium animals (only possible in expanded mode)
    premium_cows = model.addVar(name="premium_cows", vtype=GRB.INTEGER, lb=0)
    premium_sheep = model.addVar(name="premium_sheep", vtype=GRB.INTEGER, lb=0)
    premium_chickens = model.addVar(name="premium_chickens", vtype=GRB.INTEGER, lb=0)

    # Binary variable to decide if the farm operates in expanded mode (1) or normal mode (0)
    expanded_mode = model.addVar(name="expanded_mode", vtype=GRB.BINARY)

    # --- Objective Function: Maximize Total Profit ---
    # Profit per regular animal
    profit_per_cow = cow_price - cow_feed
    profit_per_sheep = sheep_price - sheep_feed
    profit_per_chicken = chicken_price - chicken_feed

    # Profit per premium animal (same selling price, but higher feed cost)
    profit_per_premium_cow = cow_price - (cow_feed * premium_feed_multiplier)
    profit_per_premium_sheep = sheep_price - (sheep_feed * premium_feed_multiplier)
    profit_per_premium_chicken = chicken_price - (chicken_feed * premium_feed_multiplier)

    # Total profit calculation: sum of profits from all animals minus expansion cost if applicable
    total_profit = (profit_per_cow * cows +
                    profit_per_sheep * sheep +
                    profit_per_chicken * chickens +
                    profit_per_premium_cow * premium_cows +
                    profit_per_premium_sheep * premium_sheep +
                    profit_per_premium_chicken * premium_chickens -
                    expansion_cost * expanded_mode)
    model.setObjective(total_profit, GRB.MAXIMIZE)

    # --- Constraints ---

    # Total number of each animal type (regular + premium)
    total_cows = cows + premium_cows
    total_sheep = sheep + premium_sheep
    total_chickens = chickens + premium_chickens
    total_animals = total_cows + total_sheep + total_chickens

    # 1. Manure capacity constraint
    # Effective manure capacity changes based on expanded_mode
    effective_max_manure_capacity = max_manure_capacity_base + (max_manure_capacity_base * premium_manure_multiplier - max_manure_capacity_base) * expanded_mode
    model.addConstr(cow_manure * total_cows +
                    sheep_manure * total_sheep +
                    chicken_manure * total_chickens <= effective_max_manure_capacity,
                    "Manure_Capacity")

    # 2. Total animals capacity constraint
    # Effective total animal capacity changes based on expanded_mode
    effective_max_total_animals = max_total_animals_base + (max_total_animals_base * premium_capacity_multiplier - max_total_animals_base) * expanded_mode
    model.addConstr(total_animals <= effective_max_total_animals, "Total_Animals_Capacity")

    # 3. Maximum chickens constraint (applies to all chickens, regardless of mode)
    model.addConstr(total_chickens <= max_chickens_overall, "Max_Chickens")

    # 4. Minimum cows demand constraint (applies to all cows, regardless of mode)
    model.addConstr(total_cows >= min_cows_overall, "Min_Cows")

    # 5. Minimum sheep demand constraint (applies to all sheep, regardless of mode)
    model.addConstr(total_sheep >= min_sheep_overall, "Min_Sheep")

    # 6. Premium animals are only credible when expanded mode is active (Big-M constraints)
    # If expanded_mode is 0, premium animals must be 0. If 1, they can be up to their respective maximums.
    # Using max_total_animals_base as a sufficiently large M for cows/sheep, and max_chickens_overall for chickens.
    M_cows_premium = max_total_animals_base # A large enough upper bound for premium cows
    M_sheep_premium = max_total_animals_base # A large enough upper bound for premium sheep
    M_chickens_premium = max_chickens_overall # A large enough upper bound for premium chickens

    model.addConstr(premium_cows <= M_cows_premium * expanded_mode, "Premium_Cows_Link")
    model.addConstr(premium_sheep <= M_sheep_premium * expanded_mode, "Premium_Sheep_Link")
    model.addConstr(premium_chickens <= M_chickens_premium * expanded_mode, "Premium_Chickens_Link")

    # 7. Land usage constraint
    # Effective land capacity changes based on expanded_mode
    total_land_usage = (base_land_usage_cow * total_cows +
                        base_land_usage_sheep * total_sheep +
                        base_land_usage_chicken * total_chickens)
    effective_land_capacity = base_land_capacity + expansion_land_increase * expanded_mode
    model.addConstr(total_land_usage <= effective_land_capacity, "Land_Usage")

    # Optimize the model
    model.optimize()

    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    # Optional: print detailed solution if needed for debugging
    # print(f"Cows: {cows.X}")
    # print(f"Sheep: {sheep.X}")
    # print(f"Chickens: {chickens.X}")
    # print(f"Premium Cows: {premium_cows.X}")
    # print(f"Premium Sheep: {premium_sheep.X}")
    # print(f"Premium Chickens: {premium_chickens.X}")
    # print(f"Expanded Mode: {expanded_mode.X}")
    else:
        print("Optimization did not find an optimal solution.")
        print(f"Status: {model.status}")
