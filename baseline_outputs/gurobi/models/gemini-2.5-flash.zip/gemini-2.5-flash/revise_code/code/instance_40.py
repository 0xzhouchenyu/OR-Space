import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve_revised_problem():
    """
    Solves the revised Carelland GDP maximization problem using Gurobi.
    """

    # Utility function to load general parameters.
    # This function is copied from src/utils.py to ensure self-containment.
    def load_parameters():
        csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
        df = pd.read_csv(csv_path)
        return dict(zip(df['Parameter_Name'], df['Value']))

    params = load_parameters()

    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # Create a new Gurobi model
    m = gp.Model("Carelland_GDP_Maximization_Revised")
    m.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- Variables ---
    # x[c]: Production level of commodity c
    x = m.addVars(commodities, name="production", lb=0)

    # y_import_finished[c]: Amount of finished commodity c imported to satisfy domestic demand
    # This is new, allowing imports of finished goods.
    y_import_finished = m.addVars(commodities, name="import_finished", lb=0)

    # z_export[c]: Amount of finished commodity c exported
    z_export = m.addVars(commodities, name="export", lb=0)

    # overtime_labor: Amount of overtime labor used
    # This is new, allowing flexible labor beyond the regular labor_force.
    overtime_labor = m.addVar(name="overtime_labor", lb=0)

    # --- Objective Function ---
    # Maximize GDP = Export Revenue - Input Import Costs - Finished Commodity Import Costs - Overtime Labor Costs

    # 1. Export Revenue: Income from selling commodities on the world market
    export_revenue = gp.quicksum(params[f"{c}_price"] * z_export[c] for c in commodities)

    # 2. Input Import Costs: Cost of other imported goods required to produce commodities (original problem term)
    input_import_costs = gp.quicksum(
        params.get(f"{c}_import_cost", 0.0) * x[c] for c in commodities
    )

    # 3. Finished Commodity Import Costs: Cost of importing finished commodities (new in revision)
    # This cost is the world price multiplied by an import premium ratio.
    finished_import_costs = gp.quicksum(
        params[f"{c}_price"] * params['import_premium_ratio'] * y_import_finished[c]
        for c in commodities
    )

    # 4. Overtime Labor Costs: Cost incurred for using overtime labor (new in revision)
    overtime_labor_costs = overtime_labor * params['overtime_wage']

    m.setObjective(export_revenue - input_import_costs - finished_import_costs - overtime_labor_costs, GRB.MAXIMIZE)

    # --- Constraints ---

    # 1. Production Limits: Upper bounds on production for specific commodities
    for c in commodities:
        # Check for various parameter names for production limits as in the original heuristic
        for suffix in ['_production_limit', '_limit', '_capacity']:
            key = f"{c}{suffix}"
            if key in params:
                m.addConstr(x[c] <= params[key], name=f"Production_Limit_{c}")

    # 2. Material Balance / Domestic Demand Satisfaction:
    # Production + Finished Imports - Domestic Consumption = Exports
    # Domestic consumption of commodity c is the sum of requirements for producing other commodities.
    for c in commodities:
        domestic_consumption_c = gp.quicksum(
            params.get(f"{c_prime}_{c}_requirement", 0.0) * x[c_prime]
            for c_prime in commodities
        )
        m.addConstr(x[c] + y_import_finished[c] - domestic_consumption_c == z_export[c], name=f"Material_Balance_{c}")

    # 3. Finished Commodity Import Quota: Upper bound on importing each finished commodity (new in revision)
    for c in commodities:
        m.addConstr(y_import_finished[c] <= params['import_quota'], name=f"Import_Quota_{c}")

    # 4. Total Labor Constraint: Total labor required must be within regular labor force plus overtime labor
    total_labor_required = gp.quicksum(
        params.get(f"{c}_labor_requirement", 0.0) * x[c] for c in commodities
    )
    m.addConstr(total_labor_required <= params['labor_force'] + overtime_labor, name="Total_Labor_Limit")

    # 5. Overtime Labor Cap: Overtime labor used cannot exceed the maximum available overtime capacity (new in revision)
    m.addConstr(overtime_labor <= params['overtime_cap'], name="Overtime_Cap")

    # Optimize the model
    m.optimize()

    if m.status == GRB.OPTIMAL:
        return m.objVal
    else:
        return None

if __name__ == '__main__':
    result = solve_revised_problem()
    if result is not None:
        print(f"FINAL_OBJ_VALUE: {round(result, 3)}")
    else:
        print("FINAL_OBJ_VALUE: None")
