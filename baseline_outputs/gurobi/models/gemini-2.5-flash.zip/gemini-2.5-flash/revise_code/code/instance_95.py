import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions (copied from src/utils.py for self-containment) ---
def load_table_1(data_dir):
    """Load the weekly demand, capacity, and cost data."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    weeks = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })
    return weeks

def load_general_parameters(data_dir):
    """Load general parameters."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params
# --- End of utility functions ---

# Determine the script's directory to correctly locate data files
# The script is expected to be in the root directory of the workspace.
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load data
weeks_data = load_table_1(data_dir)
params = load_general_parameters(data_dir)

# Extract parameters
storage_cost = params['storage_cost_per_thousand_boxes']
fixed_setup_cost = params['fixed_setup_cost']
week2_push_threshold = params['week2_push_threshold']
week3_capacity_loss_after_week2_push = params['week3_capacity_loss_after_week2_push']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']

n_weeks = len(weeks_data)
epsilon = 0.001 # Small positive number to handle strict inequalities (e.g., x > threshold)

# Create a new Gurobi model
model = gp.Model("Beverage_Production_Planning_Revised")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# Decision variables
# x[t] = production in week t (in thousand boxes)
x = model.addVars(n_weeks, name="x", lb=0.0)
# s[t] = inventory at end of week t (in thousand boxes)
s = model.addVars(n_weeks, name="s", lb=0.0)
# y[t] = binary, 1 if production occurs in week t, 0 otherwise
y = model.addVars(n_weeks, name="y", vtype=GRB.BINARY)

# Binary variable for Week 2 micro-clean trigger
# z_microclean = 1 if x[1] (Week 2 production) > week2_microclean_threshold, 0 otherwise
z_microclean = model.addVar(name="z_microclean", vtype=GRB.BINARY)

# Binary variable for Week 3 capacity loss trigger
# z_capacity_loss = 1 if x[1] (Week 2 production) > week2_push_threshold, 0 otherwise
z_capacity_loss = model.addVar(name="z_capacity_loss", vtype=GRB.BINARY)

# Objective: minimize total production cost + storage cost + fixed setup cost + micro-clean fee
objective = gp.quicksum(weeks_data[t]['cost'] * x[t] for t in range(n_weeks)) + \
            gp.quicksum(storage_cost * s[t] for t in range(n_weeks)) + \
            gp.quicksum(fixed_setup_cost * y[t] for t in range(n_weeks)) + \
            week2_microclean_fee * z_microclean

model.setObjective(objective, GRB.MINIMIZE)

# Constraints

# 1. Inventory balance
# Assume initial inventory is 0
# For week 1 (index 0): x[0] - s[0] = demand[0]
model.addConstr(x[0] - s[0] == weeks_data[0]['demand'], "balance_week_1")
# For week t > 1: s[t-1] + x[t] - s[t] = demand[t]
for t in range(1, n_weeks):
    model.addConstr(s[t-1] + x[t] - s[t] == weeks_data[t]['demand'], f"balance_week_{t+1}")

# 2. Production capacity
for t in range(n_weeks):
    if t == 2: # Week 3 (index 2) has conditional capacity
        # Effective capacity for Week 3 is reduced if z_capacity_loss is 1
        model.addConstr(x[t] <= weeks_data[t]['capacity'] - week3_capacity_loss_after_week2_push * z_capacity_loss, f"capacity_week_{t+1}")
    else:
        model.addConstr(x[t] <= weeks_data[t]['capacity'], f"capacity_week_{t+1}")

# 3. Linking production x[t] with setup binary y[t]
# If x[t] > 0, then y[t] must be 1. If y[t] = 0, then x[t] must be 0.
for t in range(n_weeks):
    # M is the maximum possible production in week t, which is its capacity
    M_capacity = weeks_data[t]['capacity']
    model.addConstr(x[t] <= M_capacity * y[t], f"link_x_y_{t+1}")

# 4. Linking Week 2 production x[1] with micro-clean binary z_microclean
# z_microclean = 1 if x[1] > week2_microclean_threshold
# M_microclean is the maximum possible production in Week 2
M_microclean = weeks_data[1]['capacity'] 
model.addConstr(x[1] <= week2_microclean_threshold + M_microclean * z_microclean, "link_x2_microclean_1")
model.addConstr(x[1] >= week2_microclean_threshold + epsilon - M_microclean * (1 - z_microclean), "link_x2_microclean_2")

# 5. Linking Week 2 production x[1] with capacity loss binary z_capacity_loss
# z_capacity_loss = 1 if x[1] > week2_push_threshold
# M_push_threshold is the maximum possible production in Week 2
M_push_threshold = weeks_data[1]['capacity'] 
model.addConstr(x[1] <= week2_push_threshold + M_push_threshold * z_capacity_loss, "link_x2_caploss_1")
model.addConstr(x[1] >= week2_push_threshold + epsilon - M_push_threshold * (1 - z_capacity_loss), "link_x2_caploss_2")

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("Optimization did not find an optimal solution.")
