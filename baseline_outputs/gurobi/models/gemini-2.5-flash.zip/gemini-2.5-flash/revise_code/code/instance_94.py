import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
# The script will be executed from the revised workspace root directory.
# Data files are in subdirectories like "data/filename.csv".
# Use os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "filename.csv") to access them.
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

# Extract parameters
min_A_I = params['min_proportion_crude_A_type_I'] / 100.0
min_A_II = params['min_proportion_crude_A_type_II'] / 100.0
price_I = params['selling_price_type_I']
price_II = params['selling_price_type_II']
inv_A = params['inventory_crude_A']
inv_B = params['inventory_crude_B']
max_purchase_A = params['max_purchase_crude_A']
cost_tier1 = params['market_price_crude_A_tier_1']
cost_tier2 = params['market_price_crude_A_tier_2']
cost_tier3 = params['market_price_crude_A_tier_3']

# New parameters from revision
proc_cap = params['processing_capacity']
min_total_gas_out = params['min_total_gasoline_output']
proc_cost_per_ton = params['processing_cost_per_ton']
type_II_thresh = params['type_II_contract_threshold']
type_II_lift = params['type_II_price_lift']
bulk_rebate_thresh = params['bulk_purchase_rebate_threshold']
bulk_rebate = params['bulk_purchase_rebate']

# Create a new Gurobi model
model = gp.Model("Oil_Blending_Revised")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# Decision variables
# Amount of crude A used in gasoline I and II
a1 = model.addVar(name="crude_A_in_I", lb=0)  # crude A -> gasoline I
a2 = model.addVar(name="crude_A_in_II", lb=0)  # crude A -> gasoline II
b1 = model.addVar(name="crude_B_in_I", lb=0)  # crude B -> gasoline I
b2 = model.addVar(name="crude_B_in_II", lb=0)  # crude B -> gasoline II

# Tiered purchase variables for crude A
p1 = model.addVar(name="purchase_tier1", lb=0, ub=500)   # first 500t
p2 = model.addVar(name="purchase_tier2", lb=0, ub=500)   # next 500t
p3 = model.addVar(name="purchase_tier3", lb=0, ub=500)   # last 500t

# Binary variables to enforce tiered ordering for crude A purchases
y1 = model.addVar(vtype=GRB.BINARY, name="y1")  # 1 if tier1 is fully used
y2 = model.addVar(vtype=GRB.BINARY, name="y2")  # 1 if tier2 is fully used

# Binary variables for new commercial thresholds
z_type_II_lift = model.addVar(vtype=GRB.BINARY, name="z_type_II_lift") # 1 if Type II output meets threshold
z_bulk_rebate = model.addVar(vtype=GRB.BINARY, name="z_bulk_rebate") # 1 if total crude A purchase meets threshold

# Auxiliary variable for linearized product (total_gasoline_II * z_type_II_lift)
# This variable represents the quantity of Type II gasoline that qualifies for the price lift.
lifted_revenue_II_var = model.addVar(name="lifted_revenue_II_var", lb=0, ub=proc_cap)

# Define total quantities for convenience
total_gasoline_I = a1 + b1
total_gasoline_II = a2 + b2
total_gasoline_output = total_gasoline_I + total_gasoline_II
total_A_purchased = p1 + p2 + p3

# Constraints

# Tiered ordering constraints for crude A purchases
# p1 must be filled before p2 can be purchased, p2 before p3
model.addConstr(p2 <= 500 * y1, "tier_order_p2")
model.addConstr(p3 <= 500 * y2, "tier_order_p3")
# These ensure y1 is 1 if p1 is fully used, and y2 is 1 if p2 is fully used
model.addConstr(p1 >= 500 * y1, "tier_fill_y1")
model.addConstr(p2 >= 500 * y2, "tier_fill_y2")

# Crude A purchase limit
model.addConstr(total_A_purchased <= max_purchase_A, "max_crude_A_purchase")

# Crude supply constraints
model.addConstr(a1 + a2 <= inv_A + total_A_purchased, "crude_A_supply")
model.addConstr(b1 + b2 <= inv_B, "crude_B_supply")

# Blending constraints (minimum proportion of crude A)
model.addConstr(a1 >= min_A_I * total_gasoline_I, "blend_A_I")
model.addConstr(a2 >= min_A_II * total_gasoline_II, "blend_A_II")

# New constraints from revision
# Total gasoline output capacity
model.addConstr(total_gasoline_output <= proc_cap, "max_total_gasoline_output")
# Minimum total gasoline output
model.addConstr(total_gasoline_output >= min_total_gas_out, "min_total_gasoline_output")

# Big M for conditional Type II price lift
# M_gasoline is the maximum possible total gasoline output, used as Big M
M_gasoline = proc_cap
epsilon = 0.001 # Small positive number to ensure strict inequality for threshold checks

# If total_gasoline_II >= type_II_thresh, then z_type_II_lift must be 1
model.addConstr(total_gasoline_II >= type_II_thresh * z_type_II_lift, "type_II_lift_cond1")
# If total_gasoline_II < type_II_thresh, then z_type_II_lift must be 0
model.addConstr(total_gasoline_II <= type_II_thresh - epsilon + M_gasoline * z_type_II_lift, "type_II_lift_cond2")

# Linearization for lifted_revenue_II_var = total_gasoline_II * z_type_II_lift
# This set of constraints correctly models the product of a continuous variable (total_gasoline_II)
# and a binary variable (z_type_II_lift).
model.addConstr(lifted_revenue_II_var <= total_gasoline_II, "lifted_rev_lin1")
model.addConstr(lifted_revenue_II_var <= M_gasoline * z_type_II_lift, "lifted_rev_lin2")
model.addConstr(lifted_revenue_II_var >= total_gasoline_II - M_gasoline * (1 - z_type_II_lift), "lifted_rev_lin3")
# lifted_revenue_II_var >= 0 is handled by its lower bound definition

# Big M for conditional bulk purchase rebate
# M_crude_A_purchase is the maximum possible crude A purchase, used as Big M
M_crude_A_purchase = max_purchase_A

# If total_A_purchased >= bulk_rebate_thresh, then z_bulk_rebate must be 1
model.addConstr(total_A_purchased >= bulk_rebate_thresh * z_bulk_rebate, "bulk_rebate_cond1")
# If total_A_purchased < bulk_rebate_thresh, then z_bulk_rebate must be 0
model.addConstr(total_A_purchased <= bulk_rebate_thresh - epsilon + M_crude_A_purchase * z_bulk_rebate, "bulk_rebate_cond2")

# Objective function: Maximize (Revenue - Purchase Cost - Processing Cost + Rebate)
# Revenue from Type I gasoline
obj_revenue_I = price_I * total_gasoline_I
# Revenue from Type II gasoline (base price + conditional lift)
obj_revenue_II = price_II * total_gasoline_II + type_II_lift * lifted_revenue_II_var

# Total purchase cost for crude A
obj_purchase_cost = cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3

# Total processing cost
obj_processing_cost = proc_cost_per_ton * total_gasoline_output

# Bulk purchase rebate (added to objective as it reduces cost)
obj_rebate = bulk_rebate * z_bulk_rebate

model.setObjective(obj_revenue_I + obj_revenue_II - obj_purchase_cost - obj_processing_cost + obj_rebate, GRB.MAXIMIZE)

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
elif model.status == GRB.INF_OR_UNBD:
    print("Model is infeasible or unbounded")
elif model.status == GRB.INFEASIBLE:
    print("Model is infeasible")
elif model.status == GRB.UNBOUNDED:
    print("Model is unbounded")
else:
    print(f"Optimization was stopped with status {model.status}")
