import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    """
    Loads and parses data from table_1_7.csv and general_parameters.csv.
    """
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    data = {}

    # Load table_1_7.csv
    filepath_table = os.path.join(base_dir, 'table_1_7.csv')
    with open(filepath_table, 'r') as f:
        reader = csv.reader(f)
        rows = list(reader)
        
        # Raw material costs and limits (rows 1-3)
        # Raw materials A, B, C correspond to indices 0, 1, 2
        data['raw_cost'] = [0.0] * 3
        data['limits'] = [0.0] * 3
        for i in range(3):
            item_row = rows[i+1] # Skip header row
            data['raw_cost'][i] = float(item_row[4])
            data['limits'][i] = float(item_row[5])
        
        # Processing fees and selling prices (rows 5-6)
        # Brands A, B, C correspond to indices 0, 1, 2
        data['proc_fee'] = [0.0] * 3
        data['sell_price'] = [0.0] * 3
        
        proc_fee_row = rows[4] # Row for Processing Fee
        sell_price_row = rows[5] # Row for Selling Price
        for j in range(3):
            data['proc_fee'][j] = float(proc_fee_row[j+1]) # +1 because first column is 'Item'
            data['sell_price'][j] = float(sell_price_row[j+1])
            
    # Load general_parameters.csv
    filepath_general = os.path.join(base_dir, 'general_parameters.csv')
    data['setup_cost'] = [0.0] * 3 # For Brands A, B, C (indices 0, 1, 2)
    data['shared_wrapper_fee'] = 0.0
    
    with open(filepath_general, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            value = float(row['Value'])
            if param_name == 'SetupCost_A':
                data['setup_cost'][0] = value
            elif param_name == 'SetupCost_B':
                data['setup_cost'][1] = value
            elif param_name == 'SetupCost_C':
                data['setup_cost'][2] = value
            elif param_name == 'BrandAB_SharedWrapper_Fee':
                data['shared_wrapper_fee'] = value
            # 'BrandAB_SharedWrapper_Trigger' is a boolean flag, not a value to be used directly in the model.
            
    return data

def main():
    # Load and parse data
    data = load_data()
    
    # Define indices for raw materials and brands for clarity
    raw_materials = ['A', 'B', 'C'] # Index 0, 1, 2
    brands = ['A', 'B', 'C']         # Index 0, 1, 2
    
    # Extract data into local variables
    raw_cost = data['raw_cost']
    proc_fee = data['proc_fee']
    sell_price = data['sell_price']
    limits = data['limits']
    setup_cost = data['setup_cost']
    shared_wrapper_fee = data['shared_wrapper_fee']
    
    # Create a new Gurobi model
    model = gp.Model("CandyFactory")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables:
    # x[i, j]: kg of raw material i used in brand j
    x = model.addVars(len(raw_materials), len(brands), name="x", vtype=GRB.CONTINUOUS, lb=0.0)
    
    # y[j]: total production quantity of brand j (kg)
    y = model.addVars(len(brands), name="y", vtype=GRB.CONTINUOUS, lb=0.0)
    
    # z_prod[j]: binary variable, 1 if brand j is produced, 0 otherwise
    z_prod = model.addVars(len(brands), name="z_prod", vtype=GRB.BINARY)
    
    # z_AB_shared: binary variable, 1 if both Brand A and Brand B are produced, 0 otherwise
    z_AB_shared = model.addVar(name="z_AB_shared", vtype=GRB.BINARY)
    
    # Link y[j] to x[i,j]: Total production of brand j is the sum of raw materials used for it
    for j in range(len(brands)):
        model.addConstr(y[j] == gp.quicksum(x[i, j] for i in range(len(raw_materials))), 
                        name=f"TotalProduction_Brand{brands[j]}")
        
    # Objective: Maximize Profit
    # Profit = Total Revenue - Total Material Cost - Total Processing Cost - Total Setup Costs - Shared Wrapper Fee
    
    total_revenue = gp.quicksum(sell_price[j] * y[j] for j in range(len(brands)))
    total_material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(len(raw_materials)) for j in range(len(brands)))
    total_processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in range(len(brands)))
    total_setup_costs = gp.quicksum(setup_cost[j] * z_prod[j] for j in range(len(brands)))
    shared_wrapper_cost = shared_wrapper_fee * z_AB_shared
    
    model.setObjective(total_revenue - total_material_cost - total_processing_cost - total_setup_costs - shared_wrapper_cost, 
                       GRB.MAXIMIZE)
    
    # Constraints:
    
    # 1. Raw material supply limits
    for i in range(len(raw_materials)):
        model.addConstr(gp.quicksum(x[i, j] for j in range(len(brands))) <= limits[i], 
                        name=f"RMLimit_RM{raw_materials[i]}")
    
    # 2. Composition constraints (percentage constraints)
    # Raw material A (index 0):
    #   >=60% in brand A (index 0)
    model.addConstr(x[0, 0] >= 0.60 * y[0], name="Comp_RMA_BrandA_Min")
    #   >=15% in brand B (index 1)
    model.addConstr(x[0, 1] >= 0.15 * y[1], name="Comp_RMA_BrandB_Min")
    
    # Raw material C (index 2):
    #   <=20% in brand A (index 0)
    model.addConstr(x[2, 0] <= 0.20 * y[0], name="Comp_RMC_BrandA_Max")
    #   <=60% in brand B (index 1)
    model.addConstr(x[2, 1] <= 0.60 * y[1], name="Comp_RMC_BrandB_Max")
    #   <=50% in brand C (index 2)
    model.addConstr(x[2, 2] <= 0.50 * y[2], name="Comp_RMC_BrandC_Max")
    
    # 3. Linking constraints for fixed setup costs (y[j] > 0 implies z_prod[j] = 1)
    # Use a Big-M formulation: y[j] <= M * z_prod[j]
    # M should be a sufficiently large number, an upper bound on total production of any single brand.
    # Sum of all raw material limits is a safe upper bound.
    M = sum(limits) # 2000 + 2500 + 1200 = 5700
    for j in range(len(brands)):
        model.addConstr(y[j] <= M * z_prod[j], name=f"Link_y_zprod_{brands[j]}")
        # If y[j] > 0, then z_prod[j] must be 1. If y[j] == 0, z_prod[j] can be 0 (preferred by objective).
        
    # 4. Linking constraints for shared wrapper fee (z_AB_shared = 1 if z_prod[0]=1 AND z_prod[1]=1)
    # This is a standard way to model logical AND for binary variables:
    # z_AB_shared >= z_prod[0] + z_prod[1] - 1
    # z_AB_shared <= z_prod[0]
    # z_AB_shared <= z_prod[1]
    model.addConstr(z_AB_shared >= z_prod[0] + z_prod[1] - 1, name="Link_zAB_Shared_1")
    model.addConstr(z_AB_shared <= z_prod[0], name="Link_zAB_Shared_2")
    model.addConstr(z_AB_shared <= z_prod[1], name="Link_zAB_Shared_3")
    
    # Optimize the model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")
    else:
        # This case should ideally not be reached for a well-formulated LP/MIP
        print("No optimal solution found.")
        print(f"Model status: {model.status}")

if __name__ == "__main__":
    main()
