import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine the base directory for data files
    # The script is expected to be run from the revised workspace root directory.
    # So, data files are in 'data/filename.csv' relative to the script.
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # --- Load data from table_1.csv ---
    table1_path = os.path.join(base_dir, 'table_1.csv')
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader) # Skip header row
        rows = []
        for row in reader:
            rows.append(row)
    
    # Parse process data and profit per unit
    # Row 0: Process I, Row 1: Process II, Row 2: Profit_per_unit
    a_I = float(rows[0][1])  # Model A hours for Process I
    b_I = float(rows[0][2])  # Model B hours for Process I
    # cap_I from table_1.csv is 150, which matches process_I_hours from general_parameters.csv.
    # We will use process_I_hours from general_parameters.csv as the source for normal capacity.
    
    a_II = float(rows[1][1]) # Model A hours for Process II
    b_II = float(rows[1][2]) # Model B hours for Process II
    # cap_II from table_1.csv is 70, which matches process_II_hours from general_parameters.csv.
    
    profit_A = float(rows[2][1]) # Profit per unit Model A
    profit_B = float(rows[2][2]) # Profit per unit Model B
    
    # --- Load data from general_parameters.csv ---
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Assign parameters to descriptive variables
    min_total_profit = params['min_weekly_profit'] # Renamed for clarity, now total over two weeks
    min_total_A = params['min_model_A_units']     # Renamed for clarity, now total over two weeks
    min_total_B = params['min_model_B_units']     # Renamed for clarity, now total over two weeks
    
    week1_min_A = params['week1_min_model_A_units']
    week1_min_B = params['week1_min_model_B_units']
    week2_min_A = params['week2_min_model_A_units']
    week2_min_B = params['week2_min_model_B_units']
    
    normal_cap_I = params['process_I_hours']
    normal_cap_II = params['process_II_hours']
    
    max_ot_I = params['max_overtime_I_per_week']
    max_ot_II = params['max_overtime_II_per_week']
    
    ot_premium_I = params['overtime_premium_I']
    ot_premium_II = params['overtime_premium_II']
    
    min_util_I = params['min_avg_utilization_I']
    min_util_II = params['min_avg_utilization_II']
    
    ot_fatigue_thresh_I = params['week1_overtime_fatigue_threshold_I']
    ot_fatigue_thresh_II = params['week1_overtime_fatigue_threshold_II']
    
    recovery_loss_I = params['week2_recovery_loss_I']
    recovery_loss_II = params['week2_recovery_loss_II']

    # --- Create Gurobi model ---
    model = gp.Model("Microcomputer_Production_Two_Weeks")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # --- Decision Variables ---
    # Production quantities for Model A and B in Week 1 and Week 2
    x_A_W1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="x_A_W1")
    x_B_W1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="x_B_W1")
    x_A_W2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="x_A_W2")
    x_B_W2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="x_B_W2")
    
    # Overtime hours for Process I and II in Week 1 (only Week 1 overtime is mentioned)
    ot_I_W1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="ot_I_W1")
    ot_II_W1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="ot_II_W1")
    
    # Binary variables for recovery rule (1 if Week 1 overtime exceeds threshold)
    y_I_recovery = model.addVar(vtype=GRB.BINARY, name="y_I_recovery")
    y_II_recovery = model.addVar(vtype=GRB.BINARY, name="y_II_recovery")

    # Variables to track regular hours used for utilization calculation
    used_reg_I_W1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="used_reg_I_W1")
    used_reg_II_W1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="used_reg_II_W1")
    used_reg_I_W2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="used_reg_I_W2")
    used_reg_II_W2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="used_reg_II_W2")

    # --- Objective Function: Maximize total profit over two weeks after overtime spending ---
    total_profit = (profit_A * (x_A_W1 + x_A_W2) + profit_B * (x_B_W1 + x_B_W2))
    overtime_cost = (ot_premium_I * ot_I_W1 + ot_premium_II * ot_II_W1)
    model.setObjective(total_profit - overtime_cost, GRB.MAXIMIZE)
    
    # --- Constraints ---

    # 1. Process Time Allocation (linking production to regular and overtime hours)
    model.addConstr(a_I * x_A_W1 + b_I * x_B_W1 == used_reg_I_W1 + ot_I_W1, "Process_I_Time_W1")
    model.addConstr(a_II * x_A_W1 + b_II * x_B_W1 == used_reg_II_W1 + ot_II_W1, "Process_II_Time_W1")
    model.addConstr(a_I * x_A_W2 + b_I * x_B_W2 == used_reg_I_W2, "Process_I_Time_W2") # No overtime in W2
    model.addConstr(a_II * x_A_W2 + b_II * x_B_W2 == used_reg_II_W2, "Process_II_Time_W2") # No overtime in W2

    # 2. Regular Capacity Limits
    model.addConstr(used_reg_I_W1 <= normal_cap_I, "Reg_Cap_I_W1")
    model.addConstr(used_reg_II_W1 <= normal_cap_II, "Reg_Cap_II_W1")
    
    # Week 2 regular capacity is affected by recovery rule
    model.addConstr(used_reg_I_W2 <= normal_cap_I - y_I_recovery * recovery_loss_I, "Reg_Cap_I_W2_Recovery")
    model.addConstr(used_reg_II_W2 <= normal_cap_II - y_II_recovery * recovery_loss_II, "Reg_Cap_II_W2_Recovery")

    # 3. Overtime Limits (Week 1)
    model.addConstr(ot_I_W1 <= max_ot_I, "Max_OT_I_W1")
    model.addConstr(ot_II_W1 <= max_ot_II, "Max_OT_II_W1")

    # 4. Recovery Rule (Big-M formulation for y_recovery)
    # y_recovery = 1 if Week 1 overtime > threshold, 0 otherwise.
    # M is a sufficiently large number, e.g., max_overtime_per_week.
    # Epsilon (1e-3) is used to model strict inequality ('>').
    M_I = max_ot_I
    M_II = max_ot_II
    epsilon = 1e-3 

    # For Process I:
    # If ot_I_W1 > ot_fatigue_thresh_I, then y_I_recovery must be 1.
    model.addConstr(ot_I_W1 <= ot_fatigue_thresh_I + M_I * y_I_recovery, "Recovery_Rule_I_1")
    model.addConstr(ot_I_W1 >= ot_fatigue_thresh_I + epsilon - M_I * (1 - y_I_recovery), "Recovery_Rule_I_2")

    # For Process II:
    # If ot_II_W1 > ot_fatigue_thresh_II, then y_II_recovery must be 1.
    model.addConstr(ot_II_W1 <= ot_fatigue_thresh_II + M_II * y_II_recovery, "Recovery_Rule_II_1")
    model.addConstr(ot_II_W1 >= ot_fatigue_thresh_II + epsilon - M_II * (1 - y_II_recovery), "Recovery_Rule_II_2")

    # 5. Weekly Delivery Promises
    model.addConstr(x_A_W1 >= week1_min_A, "Min_A_W1")
    model.addConstr(x_B_W1 >= week1_min_B, "Min_B_W1")
    model.addConstr(x_A_W2 >= week2_min_A, "Min_A_W2")
    model.addConstr(x_B_W2 >= week2_min_B, "Min_B_W2")

    # 6. Total Production Requirements (over two weeks)
    model.addConstr(x_A_W1 + x_A_W2 >= min_total_A, "Min_Total_A")
    model.addConstr(x_B_W1 + x_B_W2 >= min_total_B, "Min_Total_B")

    # 7. Minimum Net Profit (over two weeks)
    model.addConstr(total_profit - overtime_cost >= min_total_profit, "Min_Net_Profit")

    # 8. Minimum Average Utilization of Regular Hours
    # Total available regular hours for Process I over two weeks
    total_avail_reg_I = normal_cap_I + (normal_cap_I - y_I_recovery * recovery_loss_I)
    # Total available regular hours for Process II over two weeks
    total_avail_reg_II = normal_cap_II + (normal_cap_II - y_II_recovery * recovery_loss_II)

    model.addConstr(used_reg_I_W1 + used_reg_I_W2 >= min_util_I * total_avail_reg_I, "Min_Avg_Util_I")
    model.addConstr(used_reg_II_W1 + used_reg_II_W2 >= min_util_II * total_avail_reg_II, "Min_Avg_Util_II")

    # --- Optimize the model ---
    model.optimize()

    # --- Print results ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible.")
    elif model.status == GRB.UNBOUNDED:
        print("Model is unbounded.")
    else:
        print(f"Optimization ended with status {model.status}")

if __name__ == "__main__":
    main()
