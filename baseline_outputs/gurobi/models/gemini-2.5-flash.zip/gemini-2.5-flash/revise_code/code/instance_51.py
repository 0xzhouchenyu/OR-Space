import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions (copied for self-contained script) ---

def load_demand(filepath):
    """Load nurse demand per time period from CSV."""
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand

def load_parameters(filepath):
    """Load general parameters from CSV."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    return params

# --- Main optimization script ---

# Determine the base directory for data access
# The script is expected to be executed from the revised workspace root directory.
# So, 'data' is a direct subdirectory.
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load data
demand = load_demand(os.path.join(data_dir, 'table_1.csv'))
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Parse parameters from the loaded data
shift_duration = int(params['shift_duration'])  # 8 hours
regular_pay = float(params['regular_nurse_pay'])  # 10 yuan/hour
contract_pay = float(params['contract_nurse_pay'])  # 15 yuan/hour

# New parameters from the revision brief
outsourced_regular_start_index = int(params['outsourced_regular_start_index'])
banned_contract_start_index = int(params['banned_contract_start_index'])
max_total_contract_starts = int(params['max_total_contract_starts'])
min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])
daytime_period_indices = [int(x) for x in params['daytime_period_indices'].split(';')]

num_periods = len(demand)  # 6 periods, each 4 hours
# periods_per_shift = shift_duration // 4  # 2 periods per shift (not explicitly used in loop logic, but good to note)

# Initialize Gurobi model
model = gp.Model("NurseScheduling")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# Decision variables:
# x[j] = number of regular nurses starting shift j
# y[j] = number of contract nurses starting shift j
x = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="x")
y = model.addVars(num_periods, vtype=GRB.INTEGER, lb=0, name="y")

# Objective: minimize total cost
# Each nurse works for the full shift_duration
total_cost = gp.quicksum([(regular_pay * shift_duration) * x[j] + (contract_pay * shift_duration) * y[j] for j in range(num_periods)])
model.setObjective(total_cost, GRB.MINIMIZE)

# --- Constraints ---

# 1. Demand Coverage Constraints (Original Requirement)
# For each time period i, the sum of nurses (regular + contract) from shifts that cover period i must meet the demand.
# A shift j (starting at shift_start_times[j]) works for `shift_duration` (8 hours).
# Each time period is 4 hours. So, a shift covers 2 consecutive periods.
# Shift j covers period j and period (j+1) % num_periods.
for i in range(num_periods):
    covering_shifts_for_period_i = []
    for j in range(num_periods):
        # Check if shift j covers period i
        covered_periods_by_shift_j = [j, (j + 1) % num_periods]
        if i in covered_periods_by_shift_j:
            covering_shifts_for_period_i.append(j)
    
    model.addConstr(gp.quicksum(x[j] + y[j] for j in covering_shifts_for_period_i) >= demand[i], f"Demand_Period_{i}")

# 2. New Constraints from Revision Brief

# Contract nurses cannot begin the overnight 22:00 shift.
# The 22:00 shift corresponds to `banned_contract_start_index`.
model.addConstr(y[banned_contract_start_index] == 0, "No_Contract_2200_Shift")

# The 10:00 start is outsourced rather than staffed by full-time nurses.
# The 10:00 shift corresponds to `outsourced_regular_start_index`.
model.addConstr(x[outsourced_regular_start_index] == 0, "No_Regular_1000_Shift")

# Every daytime period from 6:00 through 22:00 must keep at least the required number of full-time nurses on duty.
# `daytime_period_indices` specifies these periods.
for i in daytime_period_indices:
    covering_shifts_for_regular_nurses_in_period_i = []
    for j in range(num_periods):
        # Check if shift j covers period i
        covered_periods_by_shift_j = [j, (j + 1) % num_periods]
        if i in covered_periods_by_shift_j:
            covering_shifts_for_regular_nurses_in_period_i.append(j)
            
    model.addConstr(gp.quicksum(x[j] for j in covering_shifts_for_regular_nurses_in_period_i) >= min_regular_daytime_coverage, f"Min_Regular_Daytime_Coverage_Period_{i}")

# Total contract starts are also capped for infection-control continuity.
model.addConstr(gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts, "Max_Total_Contract_Starts")

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("Optimization did not find an optimal solution.")
    # print(f"Model status: {model.status}") # Uncomment for debugging if needed
