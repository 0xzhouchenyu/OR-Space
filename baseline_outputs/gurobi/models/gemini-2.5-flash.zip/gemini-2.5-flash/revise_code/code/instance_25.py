import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Utility function (copied from original src/utils.py to be self-contained)
def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            # Attempt to convert to float, if it fails, keep as string (e.g., for units)
            try:
                value = float(row['Value'].strip())
            except ValueError:
                value = row['Value'].strip()
            params[name] = value
    return params

def solve_revised_investment_problem():
    # Construct the path to the data directory.
    # The script is executed from the workspace root, so 'data' is a direct subdirectory.
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Extract parameters from the loaded data
    initial_investment = params['initial_investment']  # W
    return_rate_option_1 = params['return_rate_option_1']  # r1
    return_rate_option_2 = params['return_rate_option_2']  # r2
    planning_horizon = int(params['planning_horizon'])  # T = 3 years
    min_reserve_year1 = params['min_reserve_year1']
    min_reserve_year2 = params['min_reserve_year2']
    max_option2_start = params['max_option2_start']
    option2_year0_late_settlement_rate = params['option2_year0_late_settlement_rate']

    # Create a new Gurobi model
    model = gp.Model("Revised_Investment_Portfolio")
    model.setParam('OutputFlag', 0)  # Suppress Gurobi output

    # --- Decision Variables ---
    # invest[t, option_type]: Amount invested in 'option_type' at the start of year 't'.
    # option_type 1: 1-year investment (matures at t+1)
    # option_type 2: 2-year investment (matures at t+2)
    #
    # Option 1 can be started at year 0, 1, 2 (matures at 1, 2, 3 respectively).
    # Option 2 can be started at year 0, 1 (matures at 2, 3 respectively).
    # Starting Option 2 at year 2 would mature at year 4, beyond the planning horizon.
    invest = model.addVars(
        [(t, opt) for t in range(planning_horizon) for opt in [1, 2]
         if (opt == 1 and t < planning_horizon) or (opt == 2 and t < planning_horizon - 1)],
        name="invest", lb=0.0
    )

    # cash_reserve[t]: Cash held at the end of year 't'.
    # This represents the liquid assets after investment decisions for year 't' are made
    # and any investments maturing at year 't' have returned their proceeds.
    # cash_reserve[0]: Initial uninvested cash from initial_investment.
    # cash_reserve[1]: Cash at the end of year 1 (after year 1 investments, before year 2 investments).
    # cash_reserve[2]: Cash at the end of year 2 (after year 2 investments, before year 3 final settlement).
    # cash_reserve[3]: Total wealth at the end of year 3.
    cash_reserve = model.addVars(range(planning_horizon + 1), name="cash_reserve", lb=0.0)

    # --- Objective Function ---
    # Maximize total wealth at the end of year 3, which is represented by cash_reserve[3].
    model.setObjective(cash_reserve[planning_horizon], GRB.MAXIMIZE)

    # --- Constraints ---

    # 1. Year 0 Budget Constraint:
    # Initial investment is allocated to Option 1, Option 2, or kept as cash.
    model.addConstr(
        invest[0, 1] + invest[0, 2] + cash_reserve[0] == initial_investment,
        "Budget_Year0"
    )

    # 2. Year 1 Budget Constraint:
    # Funds available at the start of year 1 come from:
    # - Option 1 started at year 0 maturing: invest[0, 1] * (1 + return_rate_option_1)
    # - Cash carried over from year 0: cash_reserve[0]
    # These funds are then allocated to Option 1, Option 2, or kept as cash.
    model.addConstr(
        invest[1, 1] + invest[1, 2] + cash_reserve[1] ==
        invest[0, 1] * (1 + return_rate_option_1) + cash_reserve[0],
        "Budget_Year1"
    )

    # 3. Year 2 Budget Constraint:
    # Funds available at the start of year 2 come from:
    # - Option 1 started at year 1 maturing: invest[1, 1] * (1 + return_rate_option_1)
    # - Cash carried over from year 1: cash_reserve[1]
    # IMPORTANT REVISION: Proceeds from Option 2 started at year 0 (invest[0,2]) are NOT available
    # for reinvestment in year 2 due to late settlement. They only contribute to final year 3 wealth.
    # These funds are then allocated to Option 1 or kept as cash.
    model.addConstr(
        invest[2, 1] + cash_reserve[2] ==
        invest[1, 1] * (1 + return_rate_option_1) + cash_reserve[1],
        "Budget_Year2"
    )

    # 4. Year 3 Final Wealth Calculation:
    # Total wealth at the end of year 3 is the sum of all maturing assets and remaining cash.
    # - Option 1 started at year 2 maturing: invest[2, 1] * (1 + return_rate_option_1)
    # - Option 2 started at year 1 maturing: invest[1, 2] * (1 + return_rate_option_2)
    # - Option 2 started at year 0 maturing (with late settlement deduction):
    #   invest[0, 2] * (1 + return_rate_option_2) * (1 - option2_year0_late_settlement_rate)
    # - Cash carried over from year 2: cash_reserve[2]
    model.addConstr(
        cash_reserve[planning_horizon] ==
        invest[2, 1] * (1 + return_rate_option_1) +
        invest[1, 2] * (1 + return_rate_option_2) +
        invest[0, 2] * (1 + return_rate_option_2) * (1 - option2_year0_late_settlement_rate) +
        cash_reserve[2],
        "Final_Wealth_Year3"
    )

    # 5. Reserve Floors (Revision Requirement):
    # Minimum emergency cash reserve required at the end of year 1 and year 2.
    model.addConstr(cash_reserve[1] >= min_reserve_year1, "Min_Reserve_Year1")
    model.addConstr(cash_reserve[2] >= min_reserve_year2, "Min_Reserve_Year2")

    # 6. Exposure Ceiling for Option 2 (Revision Requirement):
    # Maximum amount allowed in the two-year option in any eligible start year.
    model.addConstr(invest[0, 2] <= max_option2_start, "Max_Option2_Start_Year0")
    model.addConstr(invest[1, 2] <= max_option2_start, "Max_Option2_Start_Year1")

    # Optimize the model
    model.optimize()

    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("Optimization did not find an optimal solution.")
        # print(f"Gurobi Status: {model.status}") # Uncomment for debugging
        # If no optimal solution, print a placeholder or error value
        print(f"FINAL_OBJ_VALUE: {float('nan')}")

if __name__ == "__main__":
    solve_revised_investment_problem()
