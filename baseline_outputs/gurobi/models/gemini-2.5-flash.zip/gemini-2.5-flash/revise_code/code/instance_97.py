import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    # Determine the base directory of the script
    # The script is executed from the revised workspace root directory.
    # Data files are in a 'data' subdirectory relative to this root.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # --- Data Loading ---
    
    # Read table_1.csv
    materials = []
    sulfur_content = {}
    purchase_price = {}
    
    try:
        with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                mat = row['Material'].strip()
                materials.append(mat)
                sulfur_content[mat] = float(row['Sulfur_Content_Percentage'].strip())
                purchase_price[mat] = float(row['Purchase_Price_Thousand_Yuan_Per_Ton'].strip())
    except FileNotFoundError:
        print(f"Error: table_1.csv not found at {os.path.join(data_dir, 'table_1.csv')}")
        return
    except KeyError as e:
        print(f"Error reading table_1.csv: Missing column {e}. Please check CSV headers.")
        return
    except ValueError as e:
        print(f"Error parsing numeric value in table_1.csv: {e}. Data might be malformed.")
        return

    # Read general_parameters.csv
    params = {}
    try:
        with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                param_name = row['Parameter_Name'].strip()
                val = float(row['Value'].strip())
                params[param_name] = val
    except FileNotFoundError:
        print(f"Error: general_parameters.csv not found at {os.path.join(data_dir, 'general_parameters.csv')}")
        return
    except KeyError as e:
        print(f"Error reading general_parameters.csv: Missing column {e}. Please check CSV headers.")
        return
    except ValueError as e:
        print(f"Error parsing numeric value in general_parameters.csv: {e}. Data might be malformed.")
        return
    
    # Define product tiers based on the revised problem
    product_tiers = ['ProdA_premium', 'ProdA_standard', 'ProdB_premium', 'ProdB_standard']
    
    # Extract specific parameters into more usable dictionaries/variables
    max_sulfur_content_tier = {
        'ProdA_premium': params.get('max_sulfur_content_A_premium'),
        'ProdA_standard': params.get('max_sulfur_content_A_standard'),
        'ProdB_premium': params.get('max_sulfur_content_B_premium'),
        'ProdB_standard': params.get('max_sulfur_content_B_standard'),
    }
    
    selling_price_tier = {
        'ProdA_premium': params.get('selling_price_A_premium'),
        'ProdA_standard': params.get('selling_price_A_standard'),
        'ProdB_premium': params.get('selling_price_B_premium'),
        'ProdB_standard': params.get('selling_price_B_standard'),
    }
    
    # Check if all required parameters were loaded
    required_params = [
        'max_supply_D', 'market_demand_A', 'market_demand_B',
        'min_premium_share_A', 'max_premium_share_A',
        'min_premium_share_B', 'max_premium_share_B'
    ]
    for rp in required_params:
        if rp not in params:
            print(f"Error: Missing required parameter '{rp}' in general_parameters.csv")
            return
    for pt in product_tiers:
        if max_sulfur_content_tier.get(pt) is None:
            print(f"Error: Missing sulfur content for '{pt}' in general_parameters.csv")
            return
        if selling_price_tier.get(pt) is None:
            print(f"Error: Missing selling price for '{pt}' in general_parameters.csv")
            return

    max_supply_D = params['max_supply_D']
    demand_A = params['market_demand_A']
    demand_B = params['market_demand_B']
    min_premium_share_A = params['min_premium_share_A']
    max_premium_share_A = params['max_premium_share_A']
    min_premium_share_B = params['min_premium_share_B']
    max_premium_share_B = params['max_premium_share_B']
    
    # --- Gurobi Model Setup ---
    
    # Create a new model
    model = gp.Model("Mixing_Problem_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables: x[m, pt] = tons of material m used in product tier pt
    x = model.addVars(materials, product_tiers, name="x", lb=0.0)
    
    # Auxiliary variables for total output of each product tier
    total_output = model.addVars(product_tiers, name="total_output", lb=0.0)
    for pt in product_tiers:
        model.addConstr(total_output[pt] == gp.quicksum(x[m, pt] for m in materials), name=f"TotalOutput_{pt}")
        
    # Auxiliary variables for total material used
    total_material_used = model.addVars(materials, name="total_material_used", lb=0.0)
    for m in materials:
        model.addConstr(total_material_used[m] == gp.quicksum(x[m, pt] for pt in product_tiers), name=f"TotalMaterialUsed_{m}")
    
    # Objective: Maximize Profit (Revenue - Cost)
    revenue = gp.quicksum(selling_price_tier[pt] * total_output[pt] for pt in product_tiers)
    cost = gp.quicksum(purchase_price[m] * total_material_used[m] for m in materials)
    
    model.setObjective(revenue - cost, GRB.MAXIMIZE)
    
    # --- Constraints ---
    
    # Sulfur content constraints for each product tier
    # sum(sulfur[m]*x[m,pt]) <= max_sulfur_content_tier[pt] * total_output[pt]
    for pt in product_tiers:
        model.addConstr(gp.quicksum(sulfur_content[m] * x[m, pt] for m in materials) <= max_sulfur_content_tier[pt] * total_output[pt], name=f"Sulfur_{pt}")
    
    # Supply limit for material D
    if 'D' in materials:
        model.addConstr(total_material_used['D'] <= max_supply_D, name="Supply_D")
    else:
        # If material D is not in table_1.csv, this constraint is not applicable.
        # For robustness, we might want to log a warning or handle this case.
        # Assuming 'D' is always present as per problem description.
        pass 
    
    # Market demand constraints for product families (sum of premium and standard)
    model.addConstr(total_output['ProdA_premium'] + total_output['ProdA_standard'] <= demand_A, name="Demand_A")
    model.addConstr(total_output['ProdB_premium'] + total_output['ProdB_standard'] <= demand_B, name="Demand_B")
    
    # Premium share constraints for product A
    model.addConstr(total_output['ProdA_premium'] >= min_premium_share_A, name="Min_Premium_A")
    model.addConstr(total_output['ProdA_premium'] <= max_premium_share_A, name="Max_Premium_A")
    
    # Premium share constraints for product B
    model.addConstr(total_output['ProdB_premium'] >= min_premium_share_B, name="Min_Premium_B")
    model.addConstr(total_output['ProdB_premium'] <= max_premium_share_B, name="Max_Premium_B")
    
    # --- Optimize and Output ---
    
    # Optimize the model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INF_OR_UNBD:
        print("FINAL_OBJ_VALUE: Problem is infeasible or unbounded")
    elif model.status == GRB.INFEASIBLE:
        print("FINAL_OBJ_VALUE: Problem is infeasible")
    elif model.status == GRB.UNBOUNDED:
        print("FINAL_OBJ_VALUE: Problem is unbounded")
    else:
        print(f"FINAL_OBJ_VALUE: Optimization was stopped with status {model.status}")

if __name__ == "__main__":
    main()
