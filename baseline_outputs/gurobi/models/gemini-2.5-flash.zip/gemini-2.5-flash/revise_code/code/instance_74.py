import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Construct the path to the data directory
    # The script will be executed from the revised workspace root directory.
    # If the script is in 'src/', data is in 'data/'.
    # os.path.abspath(__file__) gives the path to the current script (e.g., /path/to/workspace/src/script.py)
    # os.path.dirname(...) gives /path/to/workspace/src/
    # os.path.join(..., '..') gives /path/to/workspace/
    # os.path.join(..., 'data') gives /path/to/workspace/data/
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

    # --- Load Parameters ---
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Clean up parameter names and values, convert values to float
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    precedences = []
    with open(os.path.join(data_dir, 'table_1.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))

    # Define all activities
    activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']

    # Extract base durations for activities
    dur = {a: int(params[f'activity_{a}_duration']) for a in activities}

    # Extract other costs and parameters
    work_cost = params['work_cost_per_day']
    machine_cost = params['machine_rental_cost_per_day']
    E_overtime_reduction = params['activity_E_overtime_reduction']
    E_overtime_cost_fixed = params['activity_E_overtime_cost']
    E_followup_cost = params['activity_E_followup_review_cost']
    # The parameter 'activity_E_followup_review_trigger' has a value of 1,
    # indicating that the follow-up review applies if overtime is chosen for Activity E.
    # We directly use E_followup_cost multiplied by the overtime decision variable.

    # --- Gurobi Model Setup ---
    model = gp.Model("Project_Cost_Minimization")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- Decision Variables ---
    # S_a: Start time for each activity 'a' (continuous, non-negative)
    S = model.addVars(activities, vtype=GRB.CONTINUOUS, lb=0, name="S")
    
    # T: Project completion time (continuous, non-negative)
    T = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="T")
    
    # X_E_overtime: Binary variable, 1 if Activity E uses overtime, 0 otherwise
    X_E_overtime = model.addVar(vtype=GRB.BINARY, name="X_E_overtime")

    # --- Objective Function ---
    # Minimize total cost, which includes:
    # 1. Work cost: work_cost_per_day * Project_Completion_Time (T)
    # 2. Machine rental cost: machine_rental_cost_per_day * (End_of_B - Start_of_A)
    #    (This specific calculation for machine rental duration is taken directly from the original heuristic)
    # 3. Activity E overtime premium: activity_E_overtime_cost * X_E_overtime
    # 4. Activity E follow-up review cost: activity_E_followup_review_cost * X_E_overtime
    model.setObjective(
        work_cost * T
        + machine_cost * (S['B'] + dur['B'] - S['A'])
        + E_overtime_cost_fixed * X_E_overtime
        + E_followup_cost * X_E_overtime,
        GRB.MINIMIZE
    )

    # --- Constraints ---
    # 1. Precedence relationships: S[successor] >= S[predecessor] + actual_duration[predecessor]
    for pred, succ in precedences:
        if pred == 'E':
            # If Activity E is the predecessor, its actual duration depends on the overtime decision
            model.addConstr(S[succ] >= S[pred] + (dur['E'] - E_overtime_reduction * X_E_overtime), f"Precedence_{pred}_{succ}")
        else:
            # For other activities, use their base duration
            model.addConstr(S[succ] >= S[pred] + dur[pred], f"Precedence_{pred}_{succ}")

    # 2. Project completion time (T) must be greater than or equal to the completion time of all terminal activities.
    # Based on the provided precedence graph and the original heuristic, C and B are terminal activities.
    model.addConstr(T >= S['C'] + dur['C'], "Project_Completion_C")
    model.addConstr(T >= S['B'] + dur['B'], "Project_Completion_B")

    # --- Solve the Model ---
    model.optimize()

    # --- Print Results ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Handle cases where the model might not find an optimal solution
        print(f"Model did not solve to optimality. Status: {model.status}")
        # For debugging, one might add:
        # if model.status == GRB.INFEASIBLE:
        #     model.computeIIS()
        #     model.write("infeasible.ilp")

solve()
