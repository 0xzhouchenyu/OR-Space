import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions (copied from src/utils.py) ---
def load_feed_data(filepath):
    """
    Loads feed nutritional content and price data from a CSV file.
    """
    feeds = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            feed = {
                'Feed': int(row['Feed']),
                'Protein_g': float(row['Protein_g']),
                'Minerals_g': float(row['Minerals_g']),
                'Vitamins_mg': float(row['Vitamins_mg']),
                'Price_Y_per_kg': float(row['Price_Y_per_kg']),
            }
            feeds.append(feed)
    return feeds


def load_general_parameters(filepath):
    """
    Loads general parameters (e.g., nutritional requirements) from a CSV file.
    """
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params
# --- End Utility functions ---


# Construct paths to data files
# The script is executed from the workspace root, so `__file__` is at the root.
# `os.path.dirname(os.path.abspath(__file__))` will be the root directory.
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load data
feeds = load_feed_data(os.path.join(data_dir, 'table_1.csv'))
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract nutritional requirements
min_protein = params['min_protein_requirement']
min_minerals = params['min_minerals_requirement']
min_vitamins = params['min_vitamins_requirement']

# Create Gurobi model
model = gp.Model("MinimizeFeedCostWithExclusion")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# --- Decision Variables ---
# x_f: Amount of each feed type 'f' (in kg), non-negative continuous
x = {}
for f in feeds:
    feed_id = f['Feed']
    x[feed_id] = model.addVar(name=f"x_{feed_id}", lb=0, vtype=GRB.CONTINUOUS)

# y_4, y_5: Binary indicator variables for Feed 4 and Feed 5
# y_f = 1 if Feed f is selected, 0 otherwise
y_4 = model.addVar(name="y_4", vtype=GRB.BINARY)
y_5 = model.addVar(name="y_5", vtype=GRB.BINARY)

# Update model to incorporate new variables
model.update()

# --- Objective Function ---
# Minimize total cost
model.setObjective(gp.quicksum(f['Price_Y_per_kg'] * x[f['Feed']] for f in feeds), GRB.MINIMIZE)

# --- Constraints ---
# 1. Nutritional requirements
model.addConstr(gp.quicksum(f['Protein_g'] * x[f['Feed']] for f in feeds) >= min_protein, "ProteinRequirement")
model.addConstr(gp.quicksum(f['Minerals_g'] * x[f['Feed']] for f in feeds) >= min_minerals, "MineralsRequirement")
model.addConstr(gp.quicksum(f['Vitamins_mg'] * x[f['Feed']] for f in feeds) >= min_vitamins, "VitaminsRequirement")

# 2. Mutual exclusion constraint for Feed 4 and Feed 5
# This requires linking the continuous feed amount variables (x_f) to binary indicators (y_f)
# using a "Big-M" formulation, and then applying the mutual exclusion on the binary variables.

# Define a sufficiently large number M.
# A rough upper bound for any single feed type could be total max requirement / min nutrient content.
# E.g., 700g protein / 1g/kg (from Feed 3) = 700kg. M=1000kg is a safe upper bound.
M = 1000.0

# Link x_4 to y_4: If y_4 is 0, x_4 must be 0. If y_4 is 1, x_4 can be up to M.
model.addConstr(x[4] <= M * y_4, "Link_x4_y4")

# Link x_5 to y_5: If y_5 is 0, x_5 must be 0. If y_5 is 1, x_5 can be up to M.
model.addConstr(x[5] <= M * y_5, "Link_x5_y5")

# Mutual exclusion: Only one of Feed 4 or Feed 5 can be selected (y_4 + y_5 <= 1)
model.addConstr(y_4 + y_5 <= 1, "MutualExclusion_Feed4_Feed5")

# --- Optimize the model ---
model.optimize()

# --- Print results ---
if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    # Handle cases where an optimal solution is not found
    # For this problem, an optimal solution is expected.
    # If not, print a high value or an error indicator.
    print(f"Optimization did not find an optimal solution. Status: {model.status}")
    print(f"FINAL_OBJ_VALUE: {float('inf')}") # Indicate failure to find a finite optimal solution
