import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine the directory of the script and construct data file paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')
    
    # --- Data Loading ---
    
    # Read product data from table_1.csv
    products_data = {}
    product_names = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Product Name'].strip()
            products_data[name] = {
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            }
            product_names.append(name)
    
    # Read general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Extract general parameters
    available_labor = params['available_labor']
    available_material = params['available_material']
    segment_regular_discount = params['segment_regular_discount']
    segment_promo_discount = params['segment_promo_discount']
    segment_promo_labor_cap = params['segment_promo_labor_cap']
    segment_promo_material_cap = params['segment_promo_material_cap']

    # Map product-specific parameters
    fixed_costs = {
        'Shirt': params['fixed_cost_shirts'],
        'Short-sleeve': params['fixed_cost_short_sleeves'],
        'Casual Cloth': params['fixed_cost_casual_clothes']
    }
    min_batch = {
        'Shirt': params['min_batch_shirts'],
        'Short-sleeve': params['min_batch_short_sleeves'],
        'Casual Cloth': params['min_batch_casual_clothes']
    }
    max_prod = {
        'Shirt': params['max_prod_shirts'],
        'Short-sleeve': params['max_prod_short_sleeves'],
        'Casual Cloth': params['max_prod_casual_clothes']
    }

    # Calculate unit profits for each segment
    unit_profit_r = {} # Regular segment unit profit
    unit_profit_p = {} # Promotional segment unit profit
    for p in product_names:
        base_price = products_data[p]['price']
        var_cost = products_data[p]['var_cost']
        unit_profit_r[p] = base_price * segment_regular_discount - var_cost
        unit_profit_p[p] = base_price * segment_promo_discount - var_cost

    # --- Gurobi Model Setup ---
    
    model = gp.Model("Hongdou_Clothing_Production")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # --- Decision Variables ---
    
    # Production quantity for each product in regular segment (integer)
    x_ir = model.addVars(product_names, vtype=GRB.INTEGER, lb=0, name="x_regular")
    # Production quantity for each product in promotional segment (integer)
    x_ip = model.addVars(product_names, vtype=GRB.INTEGER, lb=0, name="x_promo")
    
    # Binary variable: 1 if equipment for product 'p' is activated (any production), 0 otherwise
    y_i = model.addVars(product_names, vtype=GRB.BINARY, name="y_equipment_active")
    
    # Binary variable: 1 if product 'p' in regular segment meets min batch size, 0 otherwise
    z_ir = model.addVars(product_names, vtype=GRB.BINARY, name="z_regular_min_batch")
    # Binary variable: 1 if product 'p' in promotional segment meets min batch size, 0 otherwise
    z_ip = model.addVars(product_names, vtype=GRB.BINARY, name="z_promo_min_batch")

    # Continuous variables for actual profit contribution (linearization of conditional profit)
    profit_ir = model.addVars(product_names, vtype=GRB.CONTINUOUS, lb=0, name="profit_regular")
    profit_ip = model.addVars(product_names, vtype=GRB.CONTINUOUS, lb=0, name="profit_promo")
    
    # --- Objective Function ---
    
    # Maximize total profit = (sum of conditional profits from regular segment)
    #                       + (sum of conditional profits from promotional segment)
    #                       - (sum of fixed costs for activated equipment)
    model.setObjective(
        gp.quicksum(profit_ir[p] for p in product_names) +
        gp.quicksum(profit_ip[p] for p in product_names) -
        gp.quicksum(fixed_costs[p] * y_i[p] for p in product_names),
        GRB.MAXIMIZE
    )
    
    # --- Constraints ---
    
    # 1. Total Labor Constraint
    model.addConstr(
        gp.quicksum(products_data[p]['labor'] * (x_ir[p] + x_ip[p]) for p in product_names) <= available_labor,
        "Total_Labor_Constraint"
    )
    
    # 2. Total Material Constraint
    model.addConstr(
        gp.quicksum(products_data[p]['material'] * (x_ir[p] + x_ip[p]) for p in product_names) <= available_material,
        "Total_Material_Constraint"
    )
    
    # 3. Promotional Segment Labor Cap
    model.addConstr(
        gp.quicksum(products_data[p]['labor'] * x_ip[p] for p in product_names) <= segment_promo_labor_cap,
        "Promo_Labor_Cap"
    )
    
    # 4. Promotional Segment Material Cap
    model.addConstr(
        gp.quicksum(products_data[p]['material'] * x_ip[p] for p in product_names) <= segment_promo_material_cap,
        "Promo_Material_Cap"
    )

    for p in product_names:
        # 5. Fixed Cost Activation (y_i): Link production to equipment activation
        # If any units of product 'p' are produced, y_i[p] must be 1.
        # If y_i[p] is 0, no units of product 'p' can be produced.
        model.addConstr(x_ir[p] + x_ip[p] <= max_prod[p] * y_i[p], f"Equipment_Activation_{p}")
        # The reverse (if y_i[p]=1, then production >= 1) is not strictly needed for maximization,
        # as y_i[p] will naturally be 0 if no production occurs to avoid fixed costs.

        # 6. Minimum Batch Size for Regular Segment (z_ir)
        # If z_ir[p] is 1, x_ir[p] must be at least min_batch[p].
        model.addConstr(x_ir[p] >= min_batch[p] * z_ir[p], f"Min_Batch_Regular_Lower_{p}")
        # If x_ir[p] is less than min_batch[p], z_ir[p] must be 0.
        model.addConstr(x_ir[p] <= (min_batch[p] - 1) * (1 - z_ir[p]) + max_prod[p] * z_ir[p], f"Min_Batch_Regular_Upper_{p}")

        # 7. Minimum Batch Size for Promotional Segment (z_ip)
        # If z_ip[p] is 1, x_ip[p] must be at least min_batch[p].
        model.addConstr(x_ip[p] >= min_batch[p] * z_ip[p], f"Min_Batch_Promo_Lower_{p}")
        # If x_ip[p] is less than min_batch[p], z_ip[p] must be 0.
        model.addConstr(x_ip[p] <= (min_batch[p] - 1) * (1 - z_ip[p]) + max_prod[p] * z_ip[p], f"Min_Batch_Promo_Upper_{p}")

        # 8. Profit Calculation for Regular Segment (profit_ir) - Linearization of conditional profit
        # profit_ir[p] = unit_profit_r[p] * x_ir[p] if z_ir[p] == 1, else 0
        M_profit_r = unit_profit_r[p] * max_prod[p] # Big-M for profit
        model.addConstr(profit_ir[p] <= unit_profit_r[p] * x_ir[p], f"Profit_Regular_UB1_{p}")
        model.addConstr(profit_ir[p] <= M_profit_r * z_ir[p], f"Profit_Regular_UB2_{p}")
        model.addConstr(profit_ir[p] >= unit_profit_r[p] * x_ir[p] - M_profit_r * (1 - z_ir[p]), f"Profit_Regular_LB1_{p}")
        # profit_ir[p] >= 0 is already set by lb=0 for the variable

        # 9. Profit Calculation for Promotional Segment (profit_ip) - Linearization of conditional profit
        # profit_ip[p] = unit_profit_p[p] * x_ip[p] if z_ip[p] == 1, else 0
        M_profit_p = unit_profit_p[p] * max_prod[p] # Big-M for profit
        model.addConstr(profit_ip[p] <= unit_profit_p[p] * x_ip[p], f"Profit_Promo_UB1_{p}")
        model.addConstr(profit_ip[p] <= M_profit_p * z_ip[p], f"Profit_Promo_UB2_{p}")
        model.addConstr(profit_ip[p] >= unit_profit_p[p] * x_ip[p] - M_profit_p * (1 - z_ip[p]), f"Profit_Promo_LB1_{p}")
        # profit_ip[p] >= 0 is already set by lb=0 for the variable

        # 10. Maximum Total Production for each product
        model.addConstr(x_ir[p] + x_ip[p] <= max_prod[p], f"Max_Total_Production_{p}")

    # --- Optimize and Print Results ---
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        # print("Optimal production plan:")
        # for p in product_names:
        #     print(f"  {p} (Regular): {x_ir[p].X:.0f} units")
        #     print(f"  {p} (Promo): {x_ip[p].X:.0f} units")
        #     # print(f"    Equipment active: {y_i[p].X:.0f}")
        #     # print(f"    Regular segment active: {z_ir[p].X:.0f}")
        #     # print(f"    Promo segment active: {z_ip[p].X:.0f}")
        #     # print(f"    Profit Regular: {profit_ir[p].X:.2f}")
        #     # print(f"    Profit Promo: {profit_ip[p].X:.2f}")
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible.")
    elif model.status == GRB.UNBOUNDED:
        print("Model is unbounded.")
    else:
        print(f"Optimization ended with status {model.status}")

if __name__ == "__main__":
    main()
