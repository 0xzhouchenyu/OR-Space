import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine the base directory of the script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load processing costs from table_1.csv
    cost = {}  # cost[(machine, part)] = value
    parts = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p) for p in header[1:]] # Extract part numbers from header
        for row in reader:
            machine = row[0].strip()
            for j, p in enumerate(parts):
                cost[(machine, p)] = float(row[j + 1])

    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    # Extract specific parameters
    d = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    max_C = int(params['max_parts_on_C'])
    overtime_threshold = int(params['overtime_threshold'])
    overtime_penalty = params['overtime_penalty']

    machines = ['A', 'B', 'C']

    # Create a new Gurobi model
    model = gp.Model("MachineAssignment")

    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # x[m, p] = 1 if part p is assigned to machine m, 0 otherwise (binary)
    x = model.addVars(machines, parts, vtype=GRB.BINARY, name="x")

    # y[m] = 1 if machine m is used (i.e., at least one part is assigned to it), 0 otherwise (binary)
    y = model.addVars(machines, vtype=GRB.BINARY, name="y")

    # z[m] = 1 if machine m incurs an overtime penalty, 0 otherwise (binary)
    z = model.addVars(machines, vtype=GRB.BINARY, name="z")

    # --- Objective Function ---
    # Minimize total cost: processing costs + setup costs + overtime penalties
    model.setObjective(
        gp.quicksum(cost[m, p] * x[m, p] for m in machines for p in parts)  # Processing costs
        + gp.quicksum(d[m] * y[m] for m in machines)                       # Setup costs
        + gp.quicksum(overtime_penalty * z[m] for m in machines),          # Overtime penalties
        GRB.MINIMIZE
    )

    # --- Constraints ---

    # Requirement 1: One piece of each of the 10 types of parts needs to be processed
    # Each part must be assigned to exactly one machine.
    for p in parts:
        model.addConstr(gp.quicksum(x[m, p] for m in machines) == 1, f"Part_Assignment_{p}")

    # Linking y to x: If any part is processed on machine m, then machine m is considered "used" (y[m]=1).
    # This ensures setup cost is incurred if the machine is used.
    # If y[m] is 0, no parts can be assigned to machine m.
    for m in machines:
        model.addConstr(gp.quicksum(x[m, p] for p in parts) <= len(parts) * y[m], f"Link_y_to_x_{m}")

    # Requirement 2: Conditional assignment for Parts 1 and 2
    # If part 1 is on machine A, part 2 must be on B or C.
    # If part 1 is on B or C, part 2 must be on A.
    # This is equivalent to: exactly one of part 1 or part 2 must be on machine A.
    model.addConstr(x['A', 1] + x['A', 2] == 1, "Part1_Part2_Conditional")

    # Requirement 3: Fixed assignments for Parts 3, 4, and 5
    model.addConstr(x['A', 3] == 1, "Fixed_Part3_on_A")
    model.addConstr(x['B', 4] == 1, "Fixed_Part4_on_B")
    model.addConstr(x['C', 5] == 1, "Fixed_Part5_on_C")

    # Requirement 4: The number of parts processed on machine C should not exceed max_C types
    model.addConstr(gp.quicksum(x['C', p] for p in parts) <= max_C, "Max_Parts_on_C")

    # Requirement 5: Overtime penalty
    # If any machine processes more than 'overtime_threshold' parts, a fixed penalty is incurred.
    for m in machines:
        # Calculate the number of parts assigned to machine m
        num_parts_on_m = gp.quicksum(x[m, p] for p in parts)
        
        # Big-M constraint to link num_parts_on_m to z[m]:
        # If num_parts_on_m > overtime_threshold, then z[m] must be 1.
        # M is set to len(parts), which is a safe upper bound for num_parts_on_m.
        model.addConstr(num_parts_on_m - overtime_threshold <= len(parts) * z[m], f"Overtime_Trigger_{m}")
        # Note: Since z[m] has a positive cost in the objective, Gurobi will set z[m] to 0
        # if num_parts_on_m <= overtime_threshold, as this minimizes cost and satisfies the constraint.

    # Optimize the model
    model.optimize()

    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()
