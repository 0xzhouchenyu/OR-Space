import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # Corrected data directory path: from src/ to data/
    data_dir = os.path.join(base_dir, '..', 'data') 
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = float(params['fixed_order_cost'])
    august_bulk_order_threshold = int(params['august_bulk_order_threshold'])
    august_bulk_receiving_fee = float(params['august_bulk_receiving_fee'])
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create a new Gurobi model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables
    # buy[m]: Quantity purchased in month m
    buy = model.addVars(months, name="buy", vtype=GRB.CONTINUOUS, lb=0)
    # sell[m]: Quantity sold in month m
    sell = model.addVars(months, name="sell", vtype=GRB.CONTINUOUS, lb=0)
    # stock[m]: Stock level at the end of month m
    stock = model.addVars(months, name="stock", vtype=GRB.CONTINUOUS, lb=0, ub=warehouse_capacity)
    
    # New binary variables for revised requirements
    # is_buying[m]: 1 if any purchase is made in month m, 0 otherwise
    is_buying = model.addVars(months, name="is_buying", vtype=GRB.BINARY)
    # august_bulk_fee_triggered: 1 if August purchases exceed the threshold, 0 otherwise
    august_bulk_fee_triggered = model.addVar(name="august_bulk_fee_triggered", vtype=GRB.BINARY)
    
    # Objective: maximize total profit (revenue - cost)
    # Original revenue part (sales revenue - purchase cost)
    objective_expr = gp.quicksum(sell_price[m] * sell[m] - buy_price[m] * buy[m] for m in months)
    
    # Subtract fixed order costs for each month a purchase is made
    objective_expr -= gp.quicksum(fixed_order_cost * is_buying[m] for m in months)
    
    # Subtract the August bulk receiving fee if triggered
    objective_expr -= august_bulk_receiving_fee * august_bulk_fee_triggered
    
    model.setObjective(objective_expr, GRB.MAXIMIZE)
    
    # Constraints
    for i, m in enumerate(months):
        # Determine previous month's stock for balance and capacity checks
        if i == 0: # July (first month in the planning horizon)
            prev_stock_expr = initial_stock
        else:
            prev_stock_expr = stock[months[i-1]]
        
        # Stock balance constraint: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock_expr + buy[m] - sell[m], f"balance_{m}")
        
        # Warehouse capacity constraint (after buying, before selling)
        # The sum of current stock and new purchases must not exceed warehouse capacity
        model.addConstr(prev_stock_expr + buy[m] <= warehouse_capacity, f"warehouse_after_buy_{m}")
        
        # Linking is_buying[m] to buy[m] (Big M constraint)
        # If buy[m] > 0, then is_buying[m] must be 1 to incur the fixed cost.
        # warehouse_capacity serves as a safe upper bound (Big M) for buy[m].
        model.addConstr(buy[m] <= warehouse_capacity * is_buying[m], f"link_buy_is_buying_{m}")
        # No explicit lower bound link (e.g., buy[m] >= epsilon * is_buying[m]) is needed
        # because the objective penalizes is_buying[m], so Gurobi will set it to 0 if buy[m] is 0.
    
    # Linking august_bulk_fee_triggered to buy[8] (August special receiving fee)
    # This is a step function: if buy[8] > august_bulk_order_threshold, the fee is incurred.
    # Gurobi's indicator constraints provide a robust way to model this conditional logic.
    
    # Rule 1: If august_bulk_fee_triggered is 0, then buy[8] must be <= august_bulk_order_threshold
    model.addGenConstrIndicator(august_bulk_fee_triggered, 0, 
                                buy[8] <= august_bulk_order_threshold, 
                                name="aug_bulk_fee_off")
    
    # Rule 2: If august_bulk_fee_triggered is 1, then buy[8] must be >= august_bulk_order_threshold + epsilon
    # We use a small epsilon (e.g., 0.001) to represent "strictly greater than"
    model.addGenConstrIndicator(august_bulk_fee_triggered, 1, 
                                buy[8] >= august_bulk_order_threshold + 0.001, 
                                name="aug_bulk_fee_on")
    
    # Optimize the model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Handle cases where an optimal solution is not found
        print("Optimization did not find an optimal solution.")
        # For debugging, you might print model.status
        # print(f"Model status: {model.status}")

if __name__ == "__main__":
    main()
