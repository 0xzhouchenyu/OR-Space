import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Ensure utils.py is discoverable by adding its directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils import load_general_parameters, load_crop_data

def main():
    # Load data
    params = load_general_parameters()
    crops, crop_data = load_crop_data()
    
    # Extract general parameters
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']
    
    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = params['max_chickens']
    max_dairy_cows = params['max_dairy_cows']

    # Extract new parameters from the revision
    fixed_cost_chicken_setup = params['fixed_cost_chicken_setup']
    min_chickens_if_coop_open = params['min_chickens_if_coop_open']
    second_biosecurity_threshold = params['second_biosecurity_threshold']
    second_biosecurity_cost = params['second_biosecurity_cost']
    biosecurity_training_aw_days = params['biosecurity_training_aw_days']
    biosecurity_training_ss_days = params['biosecurity_training_ss_days']
    
    # Crop data
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']
    
    # Create Gurobi model
    m = gp.Model("Farm_Optimization")
    m.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables
    # Crop areas (continuous)
    x = m.addVars(crops, name="x", lb=0.0)
    
    # Number of dairy cows (integer)
    y_dairy = m.addVar(name="dairy_cows", lb=0.0, ub=max_dairy_cows, vtype=GRB.INTEGER)
    
    # Number of chickens (integer)
    y_chicken = m.addVar(name="chickens", lb=0.0, ub=max_chickens, vtype=GRB.INTEGER)
    
    # Surplus labor for external work (continuous)
    surplus_aw = m.addVar(name="surplus_aw", lb=0.0)
    surplus_ss = m.addVar(name="surplus_ss", lb=0.0)

    # Binary variables for biosecurity gates
    # z_coop_open = 1 if any chickens are raised, 0 otherwise
    z_coop_open = m.addVar(name="z_coop_open", vtype=GRB.BINARY) 
    # z_large_flock = 1 if chicken flock > second_biosecurity_threshold, 0 otherwise
    z_large_flock = m.addVar(name="z_large_flock", vtype=GRB.BINARY) 

    # Objective: maximize net income
    obj = gp.quicksum(crop_income[c] * x[c] for c in crops) + \
          income_dairy * y_dairy + income_chicken * y_chicken + \
          ext_rate_aw * surplus_aw + ext_rate_ss * surplus_ss - \
          fixed_cost_chicken_setup * z_coop_open - \
          second_biosecurity_cost * z_large_flock
    m.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints
    # Land constraint
    m.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, "Land")
    
    # Funds constraint
    m.addConstr(inv_dairy * y_dairy + inv_chicken * y_chicken <= funds_available, "Funds")
    
    # Labor autumn/winter constraint (modified for biosecurity training)
    m.addConstr(gp.quicksum(crop_aw[c] * x[c] for c in crops) + \
                labor_aw_dairy * y_dairy + labor_aw_chicken * y_chicken + \
                biosecurity_training_aw_days * z_coop_open + \
                surplus_aw <= labor_aw, "Labor_AW")
    
    # Labor spring/summer constraint (modified for biosecurity training)
    m.addConstr(gp.quicksum(crop_ss[c] * x[c] for c in crops) + \
                labor_ss_dairy * y_dairy + labor_ss_chicken * y_chicken + \
                biosecurity_training_ss_days * z_coop_open + \
                surplus_ss <= labor_ss, "Labor_SS")

    # Biosecurity Gate 1: Coop opening conditions
    # Link z_coop_open to y_chicken: if y_chicken > 0, then z_coop_open must be 1.
    # If y_chicken = 0, z_coop_open can be 0 (preferred by objective cost).
    # Constraint: y_chicken <= M * z_coop_open
    M_coop_open = max_chickens # A sufficiently large number for y_chicken
    m.addConstr(y_chicken <= M_coop_open * z_coop_open, "Link_CoopOpen_Upper")

    # Minimum chickens if coop is open: if z_coop_open = 1, then y_chicken >= min_chickens_if_coop_open
    m.addConstr(y_chicken >= min_chickens_if_coop_open * z_coop_open, "Min_Chickens_If_Open")

    # External work trade-off: if coop is open (z_coop_open = 1), no external work is possible
    M_surplus_aw = labor_aw # Max possible surplus AW labor
    M_surplus_ss = labor_ss # Max possible surplus SS labor
    m.addConstr(surplus_aw <= M_surplus_aw * (1 - z_coop_open), "No_External_Work_AW_If_Coop_Open")
    m.addConstr(surplus_ss <= M_surplus_ss * (1 - z_coop_open), "No_External_Work_SS_If_Coop_Open")

    # Biosecurity Gate 2: Large flock inspection
    # Link z_large_flock to y_chicken: if y_chicken > second_biosecurity_threshold, then z_large_flock must be 1.
    # If y_chicken <= second_biosecurity_threshold, z_large_flock can be 0 (preferred by objective cost).
    # Constraint: y_chicken <= second_biosecurity_threshold + M * z_large_flock
    M_large_flock = max_chickens # A sufficiently large number for y_chicken
    m.addConstr(y_chicken <= second_biosecurity_threshold + M_large_flock * z_large_flock, "Link_LargeFlock_Upper")

    # Optimize the model
    m.optimize()
    
    # Output results
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
