import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Determine the directory where the script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Construct the path to the data directory
    data_dir = os.path.join(script_dir, 'data')

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    # Read product segments and profits
    products = []
    segments = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row['Product']
            if p not in segments:
                segments[p] = []
                products.append(p)
            rng = row['Sales_Volume_Range']
            profit = float(row['Profit'])
            if rng.startswith('Above_'):
                lower = float(rng.split('_')[1])
                upper = float('inf') # Use infinity for upper bound
            else:
                parts = rng.split('_')
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({'lower': lower, 'upper': upper, 'profit': profit})

    # Create a new Gurobi model
    model = gp.Model("Maximize_Profit")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Big M constant (sufficiently large for the problem scale)
    M = 10000

    # Decision Variables
    x = {} # Production quantity for each product (integer)
    p_var = {} # Total profit for each product (continuous)
    y = {} # Binary variables for segment selection for each product

    for prod in products:
        pname = prod.split('_')[1] # e.g., 'A' from 'Product_A'
        x[prod] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{pname}")
        p_var[prod] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"p_{pname}")
        y[prod] = []
        for i in range(len(segments[prod])):
            yi = model.addVar(vtype=GRB.BINARY, name=f"y_{pname}_{i}")
            y[prod].append(yi)

    # Overtime labor variables
    overtime_labor_used = model.addVar(lb=0, ub=params['overtime_cap_hours'], vtype=GRB.CONTINUOUS, name="overtime_labor_used")
    y_overtime_tier2 = model.addVar(vtype=GRB.BINARY, name="y_overtime_tier2")

    # Objective Function
    # Maximize total profit from products minus overtime costs and review fees
    total_profit_from_products = gp.quicksum(p_var[prod] for prod in products)
    overtime_cost = params['overtime_cost_per_hour'] * overtime_labor_used
    second_review_fee = params['overtime_second_review_fee'] * y_overtime_tier2

    model.setObjective(total_profit_from_products - overtime_cost - second_review_fee, GRB.MAXIMIZE)

    # Constraints

    # Product segment logic (piecewise profit as step function, as per original heuristic)
    for prod in products:
        segs = segments[prod]
        pname = prod.split('_')[1]

        # Mutual exclusivity: at most one segment active
        model.addConstr(gp.quicksum(y[prod]) <= 1, name=f"segment_mut_excl_{pname}")

        for i, seg in enumerate(segs):
            lo = seg['lower']
            hi = seg['upper']
            profit_per_unit = seg['profit']

            # If y[prod][i]=1, x[prod] must be in [lo+1, hi] (or [lo+1, inf] for last segment)
            # The original heuristic used lo+1 for lo>0 and 1 for lo=0.
            # This implies that if a segment is active, at least one unit must be produced.
            if lo == 0:
                model.addConstr(x[prod] >= 1 - M * (1 - y[prod][i]), name=f"x_lower_bound_{pname}_{i}")
            else:
                model.addConstr(x[prod] >= (lo + 1) - M * (1 - y[prod][i]), name=f"x_lower_bound_{pname}_{i}")

            if hi != float('inf'):
                model.addConstr(x[prod] <= hi + M * (1 - y[prod][i]), name=f"x_upper_bound_{pname}_{i}")

            # Profit calculation: p_var[prod] is the total profit for product 'prod'
            # If y[prod][i]=1, then p_var[prod] <= profit_per_unit * x[prod]
            # The maximization objective will push p_var[prod] to be equal to profit_per_unit * x[prod]
            model.addConstr(p_var[prod] <= profit_per_unit * x[prod] + M * (1 - y[prod][i]), name=f"profit_calc_{pname}_{i}")

        # If no segment active (production=0), force x=0 and profit=0
        # If sum(y[prod]) = 0, then x[prod] <= 0 and p_var[prod] <= 0
        model.addConstr(x[prod] <= M * gp.quicksum(y[prod]), name=f"x_zero_if_no_segment_{pname}")
        model.addConstr(p_var[prod] <= M * gp.quicksum(y[prod]), name=f"profit_zero_if_no_segment_{pname}")


    # Resource constraints

    # Technical Preparation Time
    model.addConstr(
        gp.quicksum(
            params[f"technical_prep_time_{prod.split('_')[1]}"] * x[prod]
            for prod in products
        ) <= params['available_technical_prep_time'],
        name="technical_prep_constraint"
    )

    # Materials
    model.addConstr(
        gp.quicksum(
            params[f"materials_{prod.split('_')[1]}"] * x[prod]
            for prod in products
        ) <= params['available_materials'],
        name="materials_constraint"
    )

    # Revised Labor Constraint
    total_labor_required = gp.quicksum(
        params[f"labor_time_{prod.split('_')[1]}"] * x[prod]
        for prod in products
    )
    # Total labor required must be covered by regular labor + overtime labor
    model.addConstr(
        total_labor_required <= params['available_labor_time'] + overtime_labor_used,
        name="total_labor_constraint"
    )
    # Overtime labor used is already bounded by its upper bound variable definition (ub=params['overtime_cap_hours'])

    # Overtime Second Review Tier Logic
    # If overtime_labor_used > overtime_second_review_threshold, then y_overtime_tier2 must be 1
    # 1. If y_overtime_tier2 = 0, then overtime_labor_used <= overtime_second_review_threshold
    model.addConstr(
        overtime_labor_used <= params['overtime_second_review_threshold'] + M * y_overtime_tier2,
        name="overtime_tier2_link_upper"
    )
    # 2. If overtime_labor_used > overtime_second_review_threshold, then y_overtime_tier2 must be 1
    #    Using a small epsilon (0.001) to handle strict inequality for threshold crossing
    model.addConstr(
        overtime_labor_used >= params['overtime_second_review_threshold'] + 0.001 - M * (1 - y_overtime_tier2),
        name="overtime_tier2_link_lower"
    )

    # New Packaging Constraint
    total_packaging_units_required = gp.quicksum(
        params[f"pack_units_{prod.split('_')[1]}"] * x[prod]
        for prod in products
    )
    model.addConstr(
        total_packaging_units_required <= params['packaging_cap_units'],
        name="packaging_constraint"
    )

    # Optimize the model
    model.optimize()

    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.ObjVal, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
