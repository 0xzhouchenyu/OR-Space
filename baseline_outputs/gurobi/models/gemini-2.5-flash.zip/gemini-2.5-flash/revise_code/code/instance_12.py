import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine the base directory of the script.
    # If the script is in 'src/', this will be the 'src/' directory.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Data files are in 'data/' relative to the workspace root.
    # If the script is in 'src/', the data directory is at '../data/' relative to the script.
    data_dir = os.path.join(base_dir, '..', 'data')

    # Load container data from table_1.csv
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    fixed_setup_cost = params['fixed_setup_cost']
    energy_cost_per_kwh = params['energy_cost_per_kwh']
    max_total_energy_kwh = params['max_total_energy_kwh']
    eco_capacity_share = params['eco_capacity_share']
    eco_overhead_cost = params['eco_overhead_cost']
    regular_energy_intensity_kwh_per_unit = params['regular_energy_intensity_kwh_per_unit']
    eco_energy_intensity_kwh_per_unit = params['eco_energy_intensity_kwh_per_unit']

    n = len(containers) # Number of distinct container types
    
    # Create a new Gurobi model
    model = gp.Model("PlasticContainers")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- Decision Variables ---

    # y[i]: Binary variable, 1 if production equipment for container type i is activated (in any mode).
    # This incurs the fixed_setup_cost.
    y = model.addVars(n, vtype=GRB.BINARY, name="y")

    # y_eco[i]: Binary variable, 1 if Eco mode is activated for container type i.
    # This incurs the eco_overhead_cost.
    y_eco = model.addVars(n, vtype=GRB.BINARY, name="y_eco")

    # x_reg[i, j]: Units of container type i produced in Regular mode to fulfill demand of type j.
    # x_eco[i, j]: Units of container type i produced in Eco mode to fulfill demand of type j.
    x_reg = {}
    x_eco = {}
    x_reg_keys = [] # Store (i, j) keys for x_reg variables for efficient quicksum
    x_eco_keys = [] # Store (i, j) keys for x_eco variables for efficient quicksum

    for i in range(n):
        for j in range(n):
            # A container type i can substitute for type j only if its volume is larger or equal.
            if containers[i]['volume'] >= containers[j]['volume']:
                x_reg[i, j] = model.addVar(vtype=GRB.INTEGER, lowBound=0, name=f"x_reg_{i}_{j}")
                x_reg_keys.append((i, j))
                x_eco[i, j] = model.addVar(vtype=GRB.INTEGER, lowBound=0, name=f"x_eco_{i}_{j}")
                x_eco_keys.append((i, j))

    # --- Objective Function ---
    # Minimize total cost = (variable production costs) + (fixed setup costs) + (eco overhead costs) + (energy costs)

    # 1. Variable production costs (based on unit variable production cost)
    obj_var_cost = gp.quicksum(containers[i]['cost'] * x_reg[i, j] for (i, j) in x_reg_keys) + \
                   gp.quicksum(containers[i]['cost'] * x_eco[i, j] for (i, j) in x_eco_keys)

    # 2. Fixed setup costs (incurred for activating equipment for any container type)
    obj_fixed_setup_cost = gp.quicksum(fixed_setup_cost * y[i] for i in range(n))

    # 3. Eco overhead costs (additional fixed cost if Eco mode is used for a container type)
    obj_eco_overhead_cost = gp.quicksum(eco_overhead_cost * y_eco[i] for i in range(n))

    # 4. Energy costs (based on energy intensity, energy cost per kWh, and total energy consumed)
    total_energy_consumed_expr = gp.quicksum(regular_energy_intensity_kwh_per_unit * x_reg[i, j] for (i, j) in x_reg_keys) + \
                                 gp.quicksum(eco_energy_intensity_kwh_per_unit * x_eco[i, j] for (i, j) in x_eco_keys)
    obj_energy_cost = energy_cost_per_kwh * total_energy_consumed_expr

    model.setObjective(obj_var_cost + obj_fixed_setup_cost + obj_eco_overhead_cost + obj_energy_cost, GRB.MINIMIZE)

    # --- Constraints ---

    # 1. Demand constraints: For each container type j, the total units supplied (from any type i, in any mode)
    #    must be greater than or equal to its market demand.
    for j in range(n):
        model.addConstr(
            gp.quicksum(x_reg[i, j] for i in range(n) if (i, j) in x_reg_keys) +
            gp.quicksum(x_eco[i, j] for i in range(n) if (i, j) in x_eco_keys) >= containers[j]['demand'],
            f"demand_{j}"
        )

    # 2. Linking constraints for overall setup (y[i]): If any units of type i are produced (in either Regular or Eco mode),
    #    then the overall setup binary variable y[i] must be 1.
    #    M is a large number, an upper bound on the total production of any single container type.
    M = sum(c['demand'] for c in containers) # Sum of all demands is a safe upper bound for total production of any type
    for i in range(n):
        total_produced_i = gp.quicksum(x_reg[i, j] for j in range(n) if (i, j) in x_reg_keys) + \
                           gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco_keys)
        model.addConstr(total_produced_i <= M * y[i], f"setup_overall_{i}")

    # 3. Linking constraints for Eco mode setup (y_eco[i]): If any units of type i are produced in Eco mode,
    #    then the Eco mode setup binary variable y_eco[i] must be 1.
    for i in range(n):
        total_produced_i_eco = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco_keys)
        model.addConstr(total_produced_i_eco <= M * y_eco[i], f"setup_eco_{i}")

    # 4. Eco Capacity Share constraint: Total production of type i in Eco mode cannot exceed
    #    'eco_capacity_share' of the total production of type i (Regular + Eco).
    #    Expressed as: P_eco <= S * (P_reg + P_eco)  =>  P_eco * (1 - S) <= S * P_reg
    for i in range(n):
        total_produced_i_reg = gp.quicksum(x_reg[i, j] for j in range(n) if (i, j) in x_reg_keys)
        total_produced_i_eco = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco_keys)
        model.addConstr(
            (1 - eco_capacity_share) * total_produced_i_eco - eco_capacity_share * total_produced_i_reg <= 0,
            f"eco_capacity_share_{i}"
        )

    # 5. Total Energy Limit constraint: The sum of energy consumed by all production (Regular + Eco)
    #    across all container types must not exceed 'max_total_energy_kwh'.
    model.addConstr(total_energy_consumed_expr <= max_total_energy_kwh, "total_energy_limit")

    # Optimize the model
    model.optimize()

    # Print the final objective value as required
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Handle cases where no optimal solution is found (e.g., infeasible, unbounded)
        print("FINAL_OBJ_VALUE: No optimal solution found.")

if __name__ == "__main__":
    main()
