import pandas as pd
import gurobipy as gp
from gurobipy import GRB
import os

# Utility function to get data path, adjusted for script execution from root.
# The instruction states: "Your script will be saved and executed from the revised workspace root directory."
# This means if the script is at /workspace/solve.py, data files are at /workspace/data/filename.csv.
def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)

def solve():
    # Load data
    demand_df = pd.read_csv(get_data_path('table_4_3.csv'))
    supply_df = pd.read_csv(get_data_path('table_4_4.csv'))
    params_df = pd.read_csv(get_data_path('general_parameters.csv'))
    
    # Parse parameters
    # priority_2_target is now a minimum requirement.
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])
    # priority_3_target is a legacy parameter and not used in the revised objective or constraints.
    
    # Parse demand data
    demand = {} # {(city, specialty): demand_quantity}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0] # e.g., "Donghai City" -> "Donghai"
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem
        
    # Parse supply data
    supply = {} # {applicant_type: {'num': ..., 'suit': [...], 'pref_spec': ..., 'pref_city': ...}}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = float(row['Number_of_People'])
        suit = [int(x) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }
        
    # Define sets for iteration
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]
    
    # Create a new Gurobi model
    model = gp.Model("JieliStaffingRevised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision Variables:
    # x[i, j, k] = number of people of type 'i' assigned to 'j' city for 'k' specialty
    x = model.addVars(types, cities, specs, vtype=GRB.INTEGER, name="x")
    
    # Objective Function:
    # Maximize the total number of recruits who simultaneously satisfy both their preferred specialty and preferred city.
    # This is sum(x[i, preferred_city_of_i, preferred_specialty_of_i] for all applicant types i)
    obj_expr = gp.quicksum(x[i, supply[i]['pref_city'], supply[i]['pref_spec']] for i in types)
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Constraint 1 (Priority 1 - Hard Requirement):
    # All demand for all three specialties in both branches must be met.
    # For each city 'j' and specialty 'k', the total number of people assigned must be at least the demand.
    for j in cities:
        for k in specs:
            model.addConstr(gp.quicksum(x[i, j, k] for i in types) >= demand[(j, k)], f"Demand_Met_{j}_Spec{k}")
            
    # Constraint 2 (Priority 2 - Hard Requirement):
    # At least 'p2_target' number of recruited personnel are placed into their preferred specialty.
    # This is sum(x[i, j, preferred_specialty_of_i] for all applicant types i and cities j) >= p2_target
    p2_satisfied_expr = gp.quicksum(x[i, j, supply[i]['pref_spec']] for i in types for j in cities)
    model.addConstr(p2_satisfied_expr >= p2_target, "P2_Min_Preferred_Specialty")
    
    # Constraint 3: Supply limit for each applicant type.
    # The total number of people of type 'i' assigned cannot exceed their available number.
    # sum(x[i, j, k] for all cities j and specialties k) <= supply[i]['num'] for each applicant type i
    for i in types:
        model.addConstr(gp.quicksum(x[i, j, k] for j in cities for k in specs) <= supply[i]['num'], f"Supply_Limit_Type{i}")
        
    # Constraint 4: Suitability constraint.
    # A person of type 'i' can only be assigned to a specialty 'k' if 'k' is in their suitable specialties.
    # If specialty 'k' is not suitable for type 'i', then x[i, j, k] must be 0.
    for i in types:
        for j in cities:
            for k in specs:
                if k not in supply[i]['suit']:
                    model.addConstr(x[i, j, k] == 0, f"Suitability_Type{i}_City{j}_Spec{k}")
                    
    # Optimize the model
    model.optimize()
    
    # Check if the model was solved successfully and print the objective value
    if model.status == GRB.OPTIMAL:
        final_obj_value = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {final_obj_value}")
    else:
        print(f"Model did not solve to optimality. Status: {model.status}")

if __name__ == '__main__':
    solve()
