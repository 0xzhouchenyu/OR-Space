import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
# The script will be executed from the revised workspace root directory.
# Data files are in subdirectories like "data/filename.csv".
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read time periods and minimum waiters needed from table_1.csv
time_periods = []
min_waiters_needed = []
try:
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            time_periods.append(row['Time'].strip())
            min_waiters_needed.append(int(row['Minimum_Number_of_Waiters_Needed'].strip()))
except FileNotFoundError:
    print("Error: table_1.csv not found. Please ensure it's in the 'data' directory.")
    exit()

# Initialize parameters from general_parameters.csv
n = len(time_periods) # Number of 4-hour periods (6 periods for 24 hours)
peak_indicators = [0] * n
quality_weights = [0] * n
waiter_cost_per_shift = 0.0
waiter_budget = 0.0
waiter_work_hours = 0 # Not directly used in constraints, but loaded for completeness

try:
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if param_name == 'waiter_work_hours':
                waiter_work_hours = int(value)
            elif param_name.startswith('peak_'):
                idx = int(param_name.split('_')[1])
                if 0 <= idx < n:
                    peak_indicators[idx] = int(value)
            elif param_name.startswith('quality_'):
                idx = int(param_name.split('_')[1])
                if 0 <= idx < n:
                    quality_weights[idx] = int(value)
            elif param_name == 'waiter_cost_per_shift':
                waiter_cost_per_shift = float(value)
            elif param_name == 'waiter_budget':
                waiter_budget = float(value)
except FileNotFoundError:
    print("Error: general_parameters.csv not found. Please ensure it's in the 'data' directory.")
    exit()

# Create a new Gurobi model
model = gp.Model("Restaurant_Waiters_Revised")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# Decision variables:
# x[i] = number of waiters starting work at the beginning of period i
# Each waiter works for 8 continuous hours, which means two consecutive 4-hour periods.
x = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="x")

# Objective: Maximize the total service quality score
# The service quality score is the sum of (waiters working in period j * quality_weight_j) for all periods j.
# Waiters working in period j are those who started in period j (x[j])
# AND those who started in the previous period (j-1)%n (x[(j-1+n)%n]).
total_service_quality = gp.quicksum(
    (x[j] + x[(j - 1 + n) % n]) * quality_weights[j] for j in range(n)
)
model.setObjective(total_service_quality, GRB.MAXIMIZE)

# Constraints:

# 1. Demand Coverage:
# For each period j, the total number of waiters working must be greater than or equal to the minimum required.
for j in range(n):
    model.addConstr(x[j] + x[(j - 1 + n) % n] >= min_waiters_needed[j], f"Demand_{time_periods[j]}")

# 2. Peak/Off-peak Shift Requirement:
# A compliant waiter tour (8-hour block = 2 adjacent 4-hour windows) must consist of one peak window and one off-peak window.
# A waiter starting at period i works during periods i and (i+1)%n.
# The sum of peak indicators for these two periods must be exactly 1 (one peak, one off-peak).
# If peak_indicators[i] + peak_indicators[(i+1)%n] is not equal to 1, then no waiters can start at period i.
for i in range(n):
    if peak_indicators[i] + peak_indicators[(i + 1) % n] != 1:
        model.addConstr(x[i] == 0, f"Peak_OffPeak_Rule_Start_{time_periods[i]}")

# 3. Budget Constraint:
# The total staffing spend must stay within the `waiter_budget`.
# Total cost is the sum of (number of waiters starting at period i * cost per shift).
total_staffing_cost = gp.quicksum(x[i] * waiter_cost_per_shift for i in range(n))
model.addConstr(total_staffing_cost <= waiter_budget, "Staffing_Budget")

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
elif model.status == GRB.INFEASIBLE:
    print("FINAL_OBJ_VALUE: No feasible solution found (infeasible)")
elif model.status == GRB.UNBOUNDED:
    print("FINAL_OBJ_VALUE: Model is unbounded")
else:
    print(f"FINAL_OBJ_VALUE: Optimization stopped with status {model.status}")
