import csv
import os
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions (adapted from src/utils.py) ---
def load_courses(data_dir):
    """Load course data from table_1.csv"""
    filepath = os.path.join(data_dir, 'table_1.csv')
    courses = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            categories = [c.strip() for c in row['Category'].split(';')]
            courses[course] = categories
    return courses

def load_parameters(data_dir):
    """Load general parameters from general_parameters.csv"""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    prerequisites_raw = {}
    
    # New parameters from the revision brief
    mandatory_foundation_for_cs_counting = None
    cs_category_name = None

    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if name == 'min_courses_required':
                params['min_courses_required'] = int(value)
            elif name.startswith('prerequisite_'):
                course_key = name[len('prerequisite_'):]
                prerequisites_raw[course_key] = value
            elif name == 'mandatory_foundation_for_cs_counting':
                mandatory_foundation_for_cs_counting = value
            elif name == 'cs_category_name':
                cs_category_name = value
    
    params['mandatory_foundation_for_cs_counting'] = mandatory_foundation_for_cs_counting
    params['cs_category_name'] = cs_category_name

    return params, prerequisites_raw

def match_prerequisite_course(prereq_key, course_list):
    """Match a prerequisite key (like 'computer_simulation') to actual course name"""
    key_lower = prereq_key.lower().replace('_', ' ')
    for course in course_list:
        if course.lower() == key_lower:
            return course
    return None

# --- Main script ---
if __name__ == "__main__":
    # Data directory
    # The script is executed from the workspace root, so data is in 'data/'
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    # Load data
    courses_data = load_courses(data_dir) # {course_name: [category1, category2]}
    params, prereq_raw = load_parameters(data_dir)

    min_required = params['min_courses_required']
    mandatory_foundation_for_cs_counting = params['mandatory_foundation_for_cs_counting']
    cs_category_name = params['cs_category_name']

    # Build prerequisite mapping: course -> list of prerequisites
    course_list = list(courses_data.keys())
    prerequisites = {} # {course_name: [prereq1, prereq2]}

    for prereq_key, prereq_value in prereq_raw.items():
        course_name = match_prerequisite_course(prereq_key, course_list)
        if course_name:
            if course_name not in prerequisites:
                prerequisites[course_name] = []
            prerequisites[course_name].append(prereq_value.strip())

    # Get all unique categories
    all_categories = set()
    for cats in courses_data.values():
        for c in cats:
            all_categories.add(c)
    all_categories = sorted(list(all_categories)) # For consistent order

    # Create Gurobi model
    model = gp.Model("CourseSelection")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- Decision Variables ---
    # x[course]: Binary, 1 if course is taken, 0 otherwise
    x = model.addVars(course_list, vtype=GRB.BINARY, name="x")

    # y[course, category]: Binary, 1 if course is taken AND counts towards category's minimum, 0 otherwise
    # This variable is defined only for courses that belong to a given category.
    y = {}
    for course in course_list:
        for category in courses_data[course]:
            y[(course, category)] = model.addVar(vtype=GRB.BINARY, name=f"y_{course.replace(' ', '_')}_{category.replace(' ', '_')}")
    
    # --- Objective Function ---
    # Minimize total number of courses taken
    model.setObjective(gp.quicksum(x[course] for course in course_list), GRB.MINIMIZE)

    # --- Constraints ---

    # 1. Prerequisite constraints: if you take a course, you must take its prerequisites
    for course, prereqs in prerequisites.items():
        for prereq in prereqs:
            # Ensure the prerequisite course exists in our list
            if prereq in course_list:
                model.addConstr(x[course] <= x[prereq], f"Prereq_{course.replace(' ', '_')}_needs_{prereq.replace(' ', '_')}")
            # else: Prerequisite course not found, this implies data inconsistency.
            # For this problem, all prerequisites are valid courses.

    # 2. Linking x and y variables:
    # If y[course, category] is 1, then x[course] must be 1 (course must be taken)
    for (course, category), var in y.items():
        model.addConstr(var <= x[course], f"Link_y_{course.replace(' ', '_')}_{category.replace(' ', '_')}_to_x")

    # 3. Distinct Courses for Category Minima: A course can count towards at most one category's minimum
    # This addresses "a cross-listed course can no longer satisfy multiple category minima at the same time."
    for course in course_list:
        # Sum of y variables for this course across all categories it belongs to
        model.addConstr(gp.quicksum(y[(course, cat)] for cat in courses_data[course]) <= 1, 
                        f"DistinctCount_{course.replace(' ', '_')}")

    # 4. Minimum Courses per Category (Revised):
    # "Category requirements must be met with distinct courses"
    for category in all_categories:
        # Sum of y variables for courses that belong to this category and are counted for it
        courses_in_cat = [course for course, cats in courses_data.items() if category in cats]
        if courses_in_cat: # Only add constraint if there are courses in this category
            model.addConstr(gp.quicksum(y[(course, category)] for course in courses_in_cat if (course, category) in y) >= min_required, 
                            f"Min_{category.replace(' ', '_')}")
        # else: If a category has no courses, it's impossible to meet the minimum.
        # This scenario is not expected with the given data.

    # 5. Programming Foundation for CS Counting (Revised):
    # "the programming foundation must be completed before any course is counted toward the computer-science portion"
    
    foundation_course_name = mandatory_foundation_for_cs_counting
    
    if foundation_course_name in course_list and cs_category_name in all_categories:
        # Get all courses that belong to the CS category
        cs_courses = [course for course, cats in courses_data.items() if cs_category_name in cats]
        
        # Sum of y variables for courses counted towards CS category
        sum_y_cs = gp.quicksum(y[(course, cs_category_name)] for course in cs_courses if (course, cs_category_name) in y)
        
        # M is a large number, e.g., the total number of courses in the CS category
        # This ensures that if x[foundation_course_name] is 0, then sum_y_cs must be 0.
        # If x[foundation_course_name] is 1, sum_y_cs can be up to M.
        M = len(cs_courses) if cs_courses else 1 
        model.addConstr(sum_y_cs <= M * x[foundation_course_name], 
                        f"FoundationForCSCounting_{foundation_course_name.replace(' ', '_')}")
    # else: Handle cases where foundation course or CS category might be missing from data.
    # For this problem, they are present.

    # Optimize model
    model.optimize()

    # Print results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # If no optimal solution is found, print a high value or an error indicator.
        # GRB.INFEASIBLE (3), GRB.UNBOUNDED (4), GRB.INF_OR_UNBD (5)
        print(f"Optimization did not find an optimal solution. Status: {model.status}")
        print(f"FINAL_OBJ_VALUE: {float('inf')}")
