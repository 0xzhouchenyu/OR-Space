import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    """Load a CSV file and return list of dictionaries."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # Adjust path to go up one level from 'src' to the root, then into 'data'
    filepath = os.path.join(base_dir, '..', 'data', filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return [row for row in reader]

def load_demand():
    """Load demand data from table_1.csv."""
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        month = row['Month']
        product = row['Product']
        units = int(row['Market_Demand_Units'])
        demand[(month, product)] = units
    return demand

def load_parameters():
    """Load general parameters, including new ones and month-specific quotas."""
    rows = load_csv('general_parameters.csv')
    params = {}
    grid_quotas = {}
    generator_maxes = {}
    
    for row in rows:
        name = row['Parameter_Name']
        value = float(row['Value'])
        params[name] = value
        
        # Extract month-specific quotas
        if name.startswith('grid_quota_'):
            month = name.replace('grid_quota_', '').capitalize()
            grid_quotas[month] = value
        elif name.startswith('generator_max_'):
            month = name.replace('generator_max_', '').capitalize()
            generator_maxes[month] = value
            
    return params, grid_quotas, generator_maxes


def main():
    params, grid_quotas, generator_maxes = load_parameters()
    demand_data = load_demand()
    
    # Planning months: July to December
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']
    
    # Parameters
    prod_cost = {
        'Product_I': params['product_I_cost_jun_to_dec'],
        'Product_II': params['product_II_cost_jun_to_dec']
    }
    
    volume = {
        'Product_I': params['product_I_volume'],
        'Product_II': params['product_II_volume']
    }
    
    warehouse_cap = params['warehouse_capacity']
    own_cost = params['own_warehouse_cost']
    
    machine_hours_per_unit = {
        'Product_I': params['product_I_machine_hours'],
        'Product_II': params['product_II_machine_hours']
    }
    machine_hours_cap_monthly = params['machine_hours_capacity_monthly']
    
    grid_elec_cost = params['grid_electricity_cost']
    gen_elec_cost = params['generator_electricity_cost']
    
    power_kwh_per_unit = {
        'Product_I': params['product_I_power_kwh'],
        'Product_II': params['product_II_power_kwh']
    }
    
    # Demand for planning months
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]
            
    # Initial inventory (0 for July for both products)
    initial_inventory_july = params['initial_inventory_july']

    # Gurobi Model
    model = gp.Model("Production_Planning_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables
    # Production quantities (units)
    x = model.addVars([(m, p) for m in months for p in products], name="prod", vtype=GRB.CONTINUOUS, lb=0)
    
    # Inventory at end of month (units)
    inv = model.addVars([(m, p) for m in months for p in products], name="inv", vtype=GRB.CONTINUOUS, lb=0)
    
    # Own warehouse usage volume (cubic meters)
    own_wh_vol = model.addVars(months, name="own_wh_vol", vtype=GRB.CONTINUOUS, lb=0)
    
    # Grid electricity usage (kWh)
    grid_elec_usage = model.addVars(months, name="grid_elec_usage", vtype=GRB.CONTINUOUS, lb=0)
    
    # Generator electricity usage (kWh)
    gen_elec_usage = model.addVars(months, name="gen_elec_usage", vtype=GRB.CONTINUOUS, lb=0)
    
    # Objective: minimize total cost
    # Production cost
    obj_prod_cost = gp.quicksum(prod_cost[p] * x[(m, p)] for m in months for p in products)
    
    # Inventory holding cost (only own warehouse)
    obj_inv_cost = gp.quicksum(own_cost * own_wh_vol[m] for m in months)
    
    # Electricity cost
    obj_elec_cost = gp.quicksum(grid_elec_cost * grid_elec_usage[m] + gen_elec_cost * gen_elec_usage[m] for m in months)
    
    model.setObjective(obj_prod_cost + obj_inv_cost + obj_elec_cost, GRB.MINIMIZE)
    
    # Constraints
    for i, m in enumerate(months):
        # Inventory balance
        for p in products:
            if i == 0: # July
                model.addConstr(inv[(m, p)] == initial_inventory_july + x[(m, p)] - demand[(m, p)], name=f"inv_balance_{m}_{p}")
            else:
                prev_m = months[i - 1]
                model.addConstr(inv[(m, p)] == inv[(prev_m, p)] + x[(m, p)] - demand[(m, p)], name=f"inv_balance_{m}_{p}")
        
        # Machine hours capacity
        model.addConstr(gp.quicksum(machine_hours_per_unit[p] * x[(m, p)] for p in products) <= machine_hours_cap_monthly, name=f"machine_cap_{m}")
        
        # Warehouse: total volume of inventory must be stored in own_wh_vol
        total_inv_vol_month = gp.quicksum(volume[p] * inv[(m, p)] for p in products)
        model.addConstr(own_wh_vol[m] == total_inv_vol_month, name=f"own_wh_vol_calc_{m}")
        
        # Own warehouse capacity
        model.addConstr(own_wh_vol[m] <= warehouse_cap, name=f"own_wh_cap_{m}")
        
        # Electricity demand
        total_elec_demand_month = gp.quicksum(power_kwh_per_unit[p] * x[(m, p)] for p in products)
        model.addConstr(total_elec_demand_month == grid_elec_usage[m] + gen_elec_usage[m], name=f"elec_demand_{m}")
        
        # Grid electricity quota
        model.addConstr(grid_elec_usage[m] <= grid_quotas[m], name=f"grid_quota_{m}")
        
        # Generator max capacity
        model.addConstr(gen_elec_usage[m] <= generator_maxes[m], name=f"gen_max_{m}")
    
    # Solve
    model.optimize()
    
    # Check if optimal solution found
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print("No optimal solution found. Status:", model.status)

if __name__ == "__main__":
    main()
