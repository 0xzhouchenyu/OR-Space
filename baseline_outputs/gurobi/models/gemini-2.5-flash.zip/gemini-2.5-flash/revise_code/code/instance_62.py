import os
import csv
import gurobipy as gp
from gurobipy import GRB


# --- Utility functions (adapted from original, but self-contained) ---
def load_restaurant_data(filepath):
    """Load restaurant data from CSV file."""
    restaurants = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'standard_staff_hours': float(row['Standard_Staff_Hours'].strip()),
                'premium_staff_hours': float(row['Premium_Staff_Hours'].strip())
            })
    return restaurants


def load_general_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    return params


# --- Main script ---
def main():
    # Determine data directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Assuming the script is in a 'src' subdirectory and data is in a 'data' subdirectory
    # at the same level as 'src'. So, from 'src', go up one level (to the root), then into 'data'.
    data_dir = os.path.join(script_dir, '..', 'data')

    # Load data
    restaurants_data = load_restaurant_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Extract parameters
    investment_budget = params['investment_budget']
    premium_revenue_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']

    # Create a new Gurobi model
    model = gp.Model("Restaurant_Investment_Revised")
    model.setParam('OutputFlag', 0)  # Suppress Gurobi output

    # Decision variables:
    # x_r: binary, 1 if restaurant r is acquired, 0 otherwise
    # y_r: binary, 1 if restaurant r is acquired AND operated in Premium mode, 0 otherwise
    x = model.addVars([r['name'] for r in restaurants_data], vtype=GRB.BINARY, name="x")
    y = model.addVars([r['name'] for r in restaurants_data], vtype=GRB.BINARY, name="y")

    # Objective: Maximize total annual revenue
    # Revenue for restaurant r:
    # - If not acquired (x_r=0, y_r=0): 0
    # - If acquired as Standard (x_r=1, y_r=0): r['revenue']
    # - If acquired as Premium (x_r=1, y_r=1): r['revenue'] * (1 + premium_revenue_uplift)
    # This can be expressed as: r['revenue'] * x_r + r['revenue'] * premium_revenue_uplift * y_r
    objective_expr = gp.quicksum(
        r['revenue'] * x[r['name']] + r['revenue'] * premium_revenue_uplift * y[r['name']]
        for r in restaurants_data
    )
    model.setObjective(objective_expr, GRB.MAXIMIZE)

    # Constraints

    # 1. Budget constraint: total acquisition cost + total premium upgrade cost <= investment_budget
    # Cost for restaurant r: r['cost'] * x_r (acquisition) + premium_upgrade_cost * y_r (premium upgrade)
    budget_expr = gp.quicksum(
        r['cost'] * x[r['name']] + premium_upgrade_cost * y[r['name']]
        for r in restaurants_data
    )
    model.addConstr(budget_expr <= investment_budget, "Budget_Constraint")

    # 2. D-A Exclusion Constraint: If Restaurant D is purchased, Restaurant A cannot be purchased
    if 'Restaurant_D' in x and 'Restaurant_A' in x:
        model.addConstr(x['Restaurant_D'] + x['Restaurant_A'] <= 1, "D_A_Exclusion_Constraint")

    # 3. Linking constraint: y_r <= x_r for all restaurants r
    # This ensures that a restaurant can only be operated in Premium mode if it is acquired.
    for r in restaurants_data:
        model.addConstr(y[r['name']] <= x[r['name']], f"Premium_Requires_Acquisition_{r['name']}")

    # 4. Staff Hours Cap Constraint: "total premium staffing must stay within staff_hours_cap"
    # Based on the brief's specific wording, only staff hours from restaurants operated in Premium mode
    # contribute to this cap. Standard_Staff_Hours are not included in this specific cap.
    premium_staff_hours_expr = gp.quicksum(
        r['premium_staff_hours'] * y[r['name']]
        for r in restaurants_data
    )
    model.addConstr(premium_staff_hours_expr <= staff_hours_cap, "Premium_Staff_Hours_Cap_Constraint")

    # Optimize the model
    model.optimize()

    # Print results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # If the model is not optimal, print N/A as per the instruction
        # "with the optimal objective value".
        print(f"FINAL_OBJ_VALUE: N/A")


if __name__ == "__main__":
    main()
