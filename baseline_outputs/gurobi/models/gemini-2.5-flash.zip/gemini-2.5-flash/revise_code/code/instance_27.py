import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions (adapted from src/utils.py to load new parameters) ---
def load_table1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in ['Product_I', 'Product_II', 'Product_III']:
                val = row[p].strip() if row[p].strip() else None
                proc_times[e][p] = float(val) if val else None
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())
    
    return equipment, proc_times, eff_hours, op_costs

def load_general_params(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    raw_costs = {}
    prices = {}
    
    mapping_raw = {
        'raw_material_cost_product_I': 'Product_I',
        'raw_material_cost_product_II': 'Product_II',
        'raw_material_cost_product_III': 'Product_III',
    }
    mapping_price = {
        'unit_price_product_I': 'Product_I',
        'unit_price_product_II': 'Product_II',
        'unit_price_product_III': 'Product_III',
    }
    
    shared_labor_hours = None
    labor_coeffs = {}
    b2_activation_fee = None

    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            if name in mapping_raw:
                raw_costs[mapping_raw[name]] = val
            elif name in mapping_price:
                prices[mapping_price[name]] = val
            elif name == 'shared_labor_hours':
                shared_labor_hours = val
            elif name.startswith('labor_coeff_'):
                equipment_name = name.replace('labor_coeff_', '')
                labor_coeffs[equipment_name] = val
            elif name == 'b2_activation_fee':
                b2_activation_fee = val
    
    return raw_costs, prices, shared_labor_hours, labor_coeffs, b2_activation_fee

# --- Main script logic ---
def main():
    # Determine the path to the data directory
    # This assumes the script is run from the workspace root,
    # and data is in a 'data' subdirectory.
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    
    # Load data
    equipment, proc_times, eff_hours, op_costs = load_table1(data_dir)
    raw_costs, prices, shared_labor_hours, labor_coeffs, b2_activation_fee = load_general_params(data_dir)
    
    products = ['Product_I', 'Product_II', 'Product_III']
    
    A_equip = [e for e in equipment if e.startswith('A')]
    B_equip = [e for e in equipment if e.startswith('B')]
    
    # Create a new Gurobi model
    model = gp.Model("Factory_Production_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision Variables
    # x[e][p] = number of units of product p processed on equipment e
    x = {}
    for e in equipment:
        x[e] = {}
        for p in products:
            if proc_times[e][p] is not None:
                x[e][p] = model.addVar(lowBound=0, vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")
    
    # y_B2 = binary variable, 1 if B2 is used, 0 otherwise
    y_B2 = model.addVar(vtype=GRB.BINARY, name="y_B2")
    
    # Update model to integrate new variables
    model.update()
    
    # Constraints
    
    # 1. Capacity constraints: total processing time <= effective machine hours
    for e in equipment:
        # Only sum for products that can be processed on this equipment
        expr = gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None)
        model.addConstr(expr <= eff_hours[e], f"capacity_{e}")
    
    # 2. Flow balance: for each product, total A-processed = total B-processed
    # Calculate total production for each product across A and B equipment
    total_prod_A = {}
    total_prod_B = {}
    for p in products:
        total_prod_A[p] = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
        total_prod_B[p] = gp.quicksum(x[e][p] for e in B_equip if proc_times[e][p] is not None)
        model.addConstr(total_prod_A[p] == total_prod_B[p], f"balance_{p}")
    
    # Total production of each product (can use either A or B sum due to balance constraint)
    total_prod = total_prod_A 
    
    # 3. Shared Labor Constraint
    # Total labor hours consumed across all equipment must be <= shared_labor_hours
    total_labor_consumed = gp.quicksum(
        x[e][p] * proc_times[e][p] * labor_coeffs[e]
        for e in equipment
        for p in products
        if proc_times[e][p] is not None
    )
    model.addConstr(total_labor_consumed <= shared_labor_hours, "shared_labor_capacity")
    
    # 4. B2 Activation Linking Constraint
    # If B2 is used at all, y_B2 must be 1.
    # Sum of machine hours on B2
    b2_usage_hours = gp.quicksum(x['B2'][p] * proc_times['B2'][p] for p in products if proc_times['B2'][p] is not None)
    # M is the maximum possible usage of B2, which is its effective machine hours
    M_B2 = eff_hours['B2'] 
    model.addConstr(b2_usage_hours <= M_B2 * y_B2, "link_b2_activation")
    
    # Objective Function: Maximize Profit = Revenue - Raw Material Costs - Operating Costs - B2 Activation Fee
    
    # Revenue
    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)
    
    # Raw material costs
    raw_cost_total = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)
    
    # Operating costs: proportional to usage fraction
    operating_cost = gp.quicksum(
        op_costs[e] * (gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None) / eff_hours[e])
        for e in equipment
    )
    
    # B2 Activation Fee
    b2_fee_cost = b2_activation_fee * y_B2
    
    # Set objective
    model.setObjective(revenue - raw_cost_total - operating_cost - b2_fee_cost, GRB.MAXIMIZE)
    
    # Optimize the model
    model.optimize()
    
    # Output results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.4f}")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible.")
    elif model.status == GRB.UNBOUNDED:
        print("Model is unbounded.")
    else:
        print(f"Optimization ended with status {model.status}")

if __name__ == "__main__":
    main()
