import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    """
    Loads parameters and demand data from CSV files.
    Adjusted to correctly locate data files relative to the script's directory.
    """
    # Get the directory of the current script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Construct the path to the data directory
    data_dir = os.path.join(script_dir, 'data')

    table_1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    params = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    
    param_dict = dict(zip(params['Parameter_Name'], params['Value']))
    demand = dict(zip(table_1['stage'], table_1['tool_requirement']))
    
    # Convert relevant parameters to their types
    n = int(param_dict['n'])
    cost_new_tool = float(param_dict['cost_new_tool'])
    cost_slow_repair = float(param_dict['cost_slow_repair'])
    cost_fast_repair = float(param_dict['cost_fast_repair'])
    slow_repair_duration = int(param_dict['slow_repair_duration'])
    fast_repair_duration = int(param_dict['fast_repair_duration'])
    
    # New parameters from the revised problem
    max_fast_stage = int(param_dict['max_fast_stage'])
    max_slow_stage = int(param_dict['max_slow_stage'])
    emission_buy = float(param_dict['emission_buy'])
    emission_fast_repair = float(param_dict['emission_fast_repair'])
    emission_slow_repair = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_shortage = float(param_dict['penalty_shortage'])
    
    # Store all parameters in a single dict for easier passing
    all_params = {
        'n': n,
        'cost_new_tool': cost_new_tool,
        'cost_slow_repair': cost_slow_repair,
        'cost_fast_repair': cost_fast_repair,
        'slow_repair_duration': slow_repair_duration,
        'fast_repair_duration': fast_repair_duration,
        'max_fast_stage': max_fast_stage,
        'max_slow_stage': max_slow_stage,
        'emission_buy': emission_buy,
        'emission_fast_repair': emission_fast_repair,
        'emission_slow_repair': emission_slow_repair,
        'carbon_budget': carbon_budget,
        'penalty_shortage': penalty_shortage
    }
    
    return all_params, demand

def solve():
    """
    Solves the revised tool repair optimization problem using Gurobi.
    """
    params, demand = load_data()
    
    # Unpack parameters
    n = params['n']
    cost_new_tool = params['cost_new_tool']
    cost_slow_repair = params['cost_slow_repair']
    cost_fast_repair = params['cost_fast_repair']
    slow_repair_duration = params['slow_repair_duration']
    fast_repair_duration = params['fast_repair_duration']
    max_fast_stage = params['max_fast_stage']
    max_slow_stage = params['max_slow_stage']
    emission_buy = params['emission_buy']
    emission_fast_repair = params['emission_fast_repair']
    emission_slow_repair = params['emission_slow_repair']
    carbon_budget = params['carbon_budget']
    penalty_shortage = params['penalty_shortage']
    
    # Create a new Gurobi model
    model = gp.Model("Tool_Repair_Problem_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    stages = list(range(1, n + 1))
    
    # Define variables
    # x[i]: Number of new tools purchased at stage i
    x = model.addVars(stages, name="buy", vtype=GRB.INTEGER, lb=0)
    # y[i]: Number of tools sent to fast repair at stage i
    y = model.addVars(stages, name="fast_repair", vtype=GRB.INTEGER, lb=0)
    # z[i]: Number of tools sent to slow repair at stage i
    z = model.addVars(stages, name="slow_repair", vtype=GRB.INTEGER, lb=0)
    # c[i]: Number of clean tools remaining after stage i (available for stage i+1)
    c = model.addVars([0] + stages, name="clean_stock", vtype=GRB.INTEGER, lb=0)
    # d[i]: Number of dirty tools remaining after stage i (waiting for repair in stage i+1)
    d = model.addVars([0] + stages, name="dirty_stock", vtype=GRB.INTEGER, lb=0)
    
    # New variables for the revised problem
    # prebuy_clean: Initial clean stock secured before stage 1
    prebuy_clean = model.addVar(name="prebuy_clean", vtype=GRB.INTEGER, lb=0)
    # satisfaction_short[i]: Unmet demand (shortage) at stage i
    satisfaction_short = model.addVars(stages, name="shortage", vtype=GRB.INTEGER, lb=0)
    
    # Objective function: Minimize total cost (purchases + repairs + shortage penalties)
    model.setObjective(
        gp.quicksum(cost_new_tool * x[i] + cost_fast_repair * y[i] + cost_slow_repair * z[i] + penalty_shortage * satisfaction_short[i] for i in stages),
        GRB.MINIMIZE
    )
    
    # Constraints
    
    # 1. Initial conditions
    # Initial clean stock is prebuy_clean
    model.addConstr(c[0] == prebuy_clean, "Initial_Clean_Stock")
    # No inherited backlog of dirty tools before stage 1
    model.addConstr(d[0] == 0, "Initial_Dirty_Stock")
    
    # 2. Tool balance constraints for each stage
    for i in stages:
        # Calculate tools ready from repair for current stage i
        # Based on the original heuristic's index logic: sent at t, ready at t + duration + 1
        fast_ready_for_i = y[i - fast_repair_duration - 1] if i - fast_repair_duration - 1 >= 1 else 0
        slow_ready_for_i = z[i - slow_repair_duration - 1] if i - slow_repair_duration - 1 >= 1 else 0
        
        # Clean tool balance:
        # Tools available for stage i: c[i-1] (from previous stage) + x[i] (new purchases) + fast_ready_for_i + slow_ready_for_i
        # These tools are used to meet demand (demand[i] - satisfaction_short[i]) and any surplus becomes c[i]
        model.addConstr(
            c[i-1] + x[i] + fast_ready_for_i + slow_ready_for_i == (demand[i] - satisfaction_short[i]) + c[i],
            f"Clean_Balance_{i}"
        )
        
        # Dirty tool balance:
        # Tools used in stage i become dirty: (demand[i] - satisfaction_short[i])
        # These, plus any dirty tools carried over from d[i-1], are either sent for repair (y[i] + z[i])
        # or carried over as dirty inventory (d[i])
        model.addConstr(
            (demand[i] - satisfaction_short[i]) + d[i-1] == y[i] + z[i] + d[i],
            f"Dirty_Balance_{i}"
        )
        
        # 3. Repair capacity constraints (New)
        # Maximum number of tools that can be sent to fast repair in any stage
        model.addConstr(y[i] <= max_fast_stage, f"Max_Fast_Repair_{i}")
        # Maximum number of tools that can be sent to slow repair in any stage
        model.addConstr(z[i] <= max_slow_stage, f"Max_Slow_Repair_{i}")
        
        # 4. Shortage cannot exceed demand (implicit from non-negativity of c[i] and x[i] etc., but explicit for clarity)
        model.addConstr(satisfaction_short[i] <= demand[i], f"Shortage_Cap_{i}")
        
    # 5. Carbon budget constraint (New)
    # Total carbon emissions from new purchases, all repair actions, and initial clean stock
    total_carbon_emissions = gp.quicksum(
        emission_buy * x[i] + emission_fast_repair * y[i] + emission_slow_repair * z[i]
        for i in stages
    ) + emission_buy * prebuy_clean # Assuming prebuy_clean tools have the same emission factor as new purchases
    
    model.addConstr(total_carbon_emissions <= carbon_budget, "Carbon_Budget")
    
    # Optimize the model
    model.optimize()
    
    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
