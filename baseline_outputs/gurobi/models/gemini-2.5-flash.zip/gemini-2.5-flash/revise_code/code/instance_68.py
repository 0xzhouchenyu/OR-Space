import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility functions (copied from src/utils.py and adapted for direct use) ---
def load_distances(data_dir):
    """Load distance data from table_1.csv"""
    filepath = os.path.join(data_dir, 'table_1.csv')
    distances = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            yard = row['Coal_Yard'].strip()
            area = int(row['Residential_Area'].strip())
            dist = float(row['Distance_km'].strip())
            distances[(yard, area)] = dist
    return distances

def load_parameters(data_dir):
    """Load general parameters from general_parameters.csv"""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params
# --- End Utility functions ---

# Determine the directory for data files.
# The script is assumed to be executed from the workspace root directory.
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load data
distances = load_distances(data_dir)
params = load_parameters(data_dir)

# Extract parameters
min_supply = {
    'A': params['min_coal_yard_A'],
    'B': params['min_coal_yard_B_adjusted'] # Use adjusted minimum for Coal Yard B
}

demand = {
    1: params['residential_area_1_demand'],
    2: params['residential_area_2_demand'],
    3: params['residential_area_3_demand']
}

area3_A_staging_threshold = params['area3_A_staging_threshold']
area3_A_excess_staging_cost = params['area3_A_excess_staging_cost']
min_share_area3_from_A = params['min_share_area3_from_A']

coal_yards = ['A', 'B']
areas = [1, 2, 3]

# Create a new Gurobi model
model = gp.Model("Coal_Distribution_Revised")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# Decision variables: amount of coal shipped from yard i to area j
# x[yard, area] represents the total amount shipped from yard to area
x = model.addVars(coal_yards, areas, name="x", vtype=GRB.CONTINUOUS, lb=0)

# Special variables for A to Area 3 due to piecewise cost
# x_A_3_base: amount up to the staging threshold (normal cost)
# x_A_3_extra: amount above the staging threshold (extra cost)
x_A_3_base = model.addVar(name="x_A_3_base", vtype=GRB.CONTINUOUS, lb=0, ub=area3_A_staging_threshold)
x_A_3_extra = model.addVar(name="x_A_3_extra", vtype=GRB.CONTINUOUS, lb=0)

# Link the total shipment from A to Area 3 to its components
model.addConstr(x['A', 3] == x_A_3_base + x_A_3_extra, "Link_x_A_3_components")

# Objective: minimize total transportation cost
obj_expr = gp.LinExpr()
for yard in coal_yards:
    for area in areas:
        if (yard, area) == ('A', 3):
            # Special cost for A to Area 3: piecewise linear cost
            obj_expr += distances[('A', 3)] * x_A_3_base
            obj_expr += (distances[('A', 3)] + area3_A_excess_staging_cost) * x_A_3_extra
        elif (yard, area) in distances:
            # Normal cost for existing routes
            obj_expr += distances[(yard, area)] * x[yard, area]
        else:
            # If a route does not exist in distances (e.g., B to Area 3),
            # ensure no coal is shipped on that route by setting flow to zero.
            model.addConstr(x[yard, area] == 0, f"No_Flow_{yard}_{area}")

model.setObjective(obj_expr, GRB.MINIMIZE)

# Constraints:
# 1. Each coal yard must supply at least its minimum requirement
for yard in coal_yards:
    model.addConstr(gp.quicksum(x[yard, area] for area in areas) >= min_supply[yard], f"Min_Supply_{yard}")

# 2. Each residential area must receive exactly its demand
for area in areas:
    model.addConstr(gp.quicksum(x[yard, area] for yard in coal_yards) == demand[area], f"Demand_{area}")

# 3. New constraint: Residential Area 3 minimum share from Coal Yard A
# Coal Yard A must supply at least a minimum fraction of Area 3's demand.
model.addConstr(x['A', 3] >= min_share_area3_from_A * demand[3], "Min_Share_Area3_from_A")

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
    print(f"Model status: {model.status}")
