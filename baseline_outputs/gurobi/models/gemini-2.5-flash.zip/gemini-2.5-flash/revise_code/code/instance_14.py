import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_problem():
    # Determine the base directory for data files
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    data_dir = os.path.join(base_dir, 'data')

    # --- 1. Load Data ---
    items_data = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items_data.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })

    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_daily_calories = params['min_daily_calories']
    max_daily_calories = params['max_daily_calories']
    max_daily_sodium = params['max_daily_sodium']

    # Derived constants based on problem description
    # max_units is an upper bound on daily purchase_units[i] per item
    max_units_per_item_purchase = int(total_weight_limit // 100)
    # max_meal_units is an upper bound on lunch_units[i] and dinner_units[i] per item
    max_meal_units_per_item = 3 # 300g per meal / 100g per unit = 3 units
    meal_portion_grams = 300

    # Create a Gurobi model
    model = gp.Model("MarysDailyMealPlan")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- 2. Define Sets and Indices ---
    item_indices = range(len(items_data))
    veg_indices = [i for i in item_indices if items_data[i]['type'] == 'Vegetable']
    # protein_indices = [i for i in item_indices if items_data[i]['type'] == 'Protein'] # Not explicitly needed for constraints

    # --- 3. Define Variables ---
    # purchase_units[i]: number of 100g units of item i purchased for the day
    purchase_units = model.addVars(item_indices, vtype=GRB.INTEGER, lb=0, name="purchase_units")

    # lunch_units[i]: number of 100g units of item i used in lunch
    lunch_units = model.addVars(item_indices, vtype=GRB.INTEGER, lb=0, name="lunch_units")

    # dinner_units[i]: number of 100g units of item i used in dinner
    dinner_units = model.addVars(item_indices, vtype=GRB.INTEGER, lb=0, name="dinner_units")

    # select_item[i]: binary, 1 if item i is purchased at all
    select_item = model.addVars(item_indices, vtype=GRB.BINARY, name="select_item")

    # lunch_veg_selected[i]: binary, 1 if vegetable item i is used in lunch
    lunch_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg_selected")

    # dinner_veg_selected[i]: binary, 1 if vegetable item i is used in dinner
    dinner_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg_selected")

    # --- 4. Objective Function ---
    # Maximize total protein intake over both meals (from assigned units)
    model.setObjective(
        gp.quicksum(items_data[i]['protein'] * (lunch_units[i] + dinner_units[i]) for i in item_indices),
        GRB.MAXIMIZE
    )

    # --- 5. Constraints ---

    # Constraint 1: Linking purchase and meal assignment
    # For every item i, purchase_units[i] >= lunch_units[i] + dinner_units[i]
    for i in item_indices:
        model.addConstr(purchase_units[i] >= lunch_units[i] + dinner_units[i], 
                        f"link_purchase_meal_{items_data[i]['name']}")

    # Constraint 2: Total daily budget
    # Total cost of all purchases <= max_budget
    model.addConstr(
        gp.quicksum(items_data[i]['cost'] * purchase_units[i] for i in item_indices) <= max_budget,
        "daily_budget"
    )

    # Constraint 3: Total daily weight limit (for purchased items)
    # 100 * sum(purchase_units[i]) <= total_weight_limit
    model.addConstr(
        gp.quicksum(100 * purchase_units[i] for i in item_indices) <= total_weight_limit,
        "daily_purchase_weight_limit"
    )

    # Constraint 4: Per-meal weight balance
    # For lunch: sum(100 * lunch_units[i]) == 300
    model.addConstr(
        gp.quicksum(100 * lunch_units[i] for i in item_indices) == meal_portion_grams,
        "lunch_weight_balance"
    )
    # For dinner: sum(100 * dinner_units[i]) == 300
    model.addConstr(
        gp.quicksum(100 * dinner_units[i] for i in item_indices) == meal_portion_grams,
        "dinner_weight_balance"
    )

    # Constraint 5: Daily calorie intake bounds (from assigned units)
    total_daily_calories_expr = gp.quicksum(items_data[i]['calories'] * (lunch_units[i] + dinner_units[i]) for i in item_indices)
    model.addConstr(total_daily_calories_expr >= min_daily_calories, "min_daily_calories")
    model.addConstr(total_daily_calories_expr <= max_daily_calories, "max_daily_calories")

    # Constraint 6: Daily sodium intake bound (from assigned units)
    total_daily_sodium_expr = gp.quicksum(items_data[i]['sodium'] * (lunch_units[i] + dinner_units[i]) for i in item_indices)
    model.addConstr(total_daily_sodium_expr <= max_daily_sodium, "max_daily_sodium")

    # Constraint 7: Purchase selection linkage (Big-M constraints)
    # If select_item[i] = 0, then purchase_units[i], lunch_units[i], dinner_units[i] must be 0.
    # If select_item[i] = 1, they may be positive.
    for i in item_indices:
        model.addConstr(purchase_units[i] <= max_units_per_item_purchase * select_item[i], 
                        f"link_purchase_select_M1_{items_data[i]['name']}")
        model.addConstr(lunch_units[i] <= max_meal_units_per_item * select_item[i], 
                        f"link_lunch_select_M2_{items_data[i]['name']}")
        model.addConstr(dinner_units[i] <= max_meal_units_per_item * select_item[i], 
                        f"link_dinner_select_M3_{items_data[i]['name']}")

    # Constraint 8: Additional meal-level vegetable coverage constraints
    # Link lunch_units[i] to lunch_veg_selected[i] and dinner_units[i] to dinner_veg_selected[i]
    for i in veg_indices:
        # If lunch_veg_selected[i] is 1, at least 1 unit of veg i must be in lunch
        model.addConstr(lunch_units[i] >= lunch_veg_selected[i], 
                        f"link_lunch_veg_lower_{items_data[i]['name']}")
        # If lunch_veg_selected[i] is 0, no units of veg i can be in lunch
        model.addConstr(lunch_units[i] <= max_meal_units_per_item * lunch_veg_selected[i], 
                        f"link_lunch_veg_upper_{items_data[i]['name']}")

        # If dinner_veg_selected[i] is 1, at least 1 unit of veg i must be in dinner
        model.addConstr(dinner_units[i] >= dinner_veg_selected[i], 
                        f"link_dinner_veg_lower_{items_data[i]['name']}")
        # If dinner_veg_selected[i] is 0, no units of veg i can be in dinner
        model.addConstr(dinner_units[i] <= max_meal_units_per_item * dinner_veg_selected[i], 
                        f"link_dinner_veg_upper_{items_data[i]['name']}")

    # Minimum number of distinct vegetable types per meal
    model.addConstr(gp.quicksum(lunch_veg_selected[i] for i in veg_indices) >= min_veg_types, 
                    "min_veg_types_lunch")
    model.addConstr(gp.quicksum(dinner_veg_selected[i] for i in veg_indices) >= min_veg_types, 
                    "min_veg_types_dinner")

    # --- 6. Optimize and Print Results ---
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INF_OR_UNBD:
        print("Model is infeasible or unbounded")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible")
    elif model.status == GRB.UNBOUNDED:
        print("Model is unbounded")
    else:
        print(f"Optimization was stopped with status {model.status}")

if __name__ == "__main__":
    solve_revised_problem()
