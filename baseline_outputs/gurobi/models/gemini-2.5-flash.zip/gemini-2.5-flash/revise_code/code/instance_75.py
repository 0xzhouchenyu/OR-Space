import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility function (from src/utils.py, adapted for self-containment) ---
def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- Main script ---
# Determine the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))

# Construct the path to the data directory, assuming it's one level up from 'src'
# and then into 'data'.
data_dir = os.path.join(script_dir, '..', 'data')

# Load parameters from the CSV file
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters for clarity
a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']

T1_normal = params['available_time_process_1']
T2_normal = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']

c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
bigM_disposal = params['bigM_disposal']
disposal_cost_base = params['disposal_cost_per_unit_c']
disposal_cost_high = params['disposal_cost_per_unit_c_high']

profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

# Create a new Gurobi model
model = gp.Model("MaxProfitRevised")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# --- Decision Variables ---
# Product quantities (continuous, non-negative)
xA = model.addVar(vtype=GRB.CONTINUOUS, name="xA", lb=0)  # units of product A
xB = model.addVar(vtype=GRB.CONTINUOUS, name="xB", lb=0)  # units of product B

# By-product C management (continuous, non-negative)
cSold = model.addVar(vtype=GRB.CONTINUOUS, name="cSold", lb=0)  # units of by-product C sold
cDisposed = model.addVar(vtype=GRB.CONTINUOUS, name="cDisposed", lb=0) # Total units of C disposed

# Variables for piecewise linear C disposal cost (continuous, non-negative)
cDisposed_low = model.addVar(vtype=GRB.CONTINUOUS, name="cDisposed_low", lb=0) # C disposed at base cost
cDisposed_high = model.addVar(vtype=GRB.CONTINUOUS, name="cDisposed_high", lb=0) # C disposed at high cost

# Binary variable for C disposal threshold (1 if cDisposed > threshold_c, 0 otherwise)
z_c_disposal = model.addVar(vtype=GRB.BINARY, name="z_c_disposal")

# Binary variables for high-throughput operation (1 if process uses high-throughput, 0 otherwise)
y1 = model.addVar(vtype=GRB.BINARY, name="y1") # Process 1 high-throughput
y2 = model.addVar(vtype=GRB.BINARY, name="y2") # Process 2 high-throughput

# --- Objective Function ---
# Maximize total profit: (Profit from A) + (Profit from B) + (Profit from selling C) - (Cost of disposing C)
model.setObjective(
    profit_a * xA + profit_b * xB + profit_c * cSold
    - disposal_cost_base * cDisposed_low
    - disposal_cost_high * cDisposed_high,
    GRB.MAXIMIZE
)

# --- Constraints ---

# 1. Process 1 time constraint
# Available time depends on whether high-throughput mode (y1) is active for Process 1.
# If y1=0, available time is T1_normal. If y1=1, available time is T1_high.
model.addConstr(a_p1 * xA + b_p1 * xB <= T1_normal + (T1_high - T1_normal) * y1, "Process1Time")

# 2. Process 2 time constraint
# Available time depends on whether high-throughput mode (y2) is active for Process 2.
# If y2=0, available time is T2_normal. If y2=1, available time is T2_high.
model.addConstr(a_p2 * xA + b_p2 * xB <= T2_normal + (T2_high - T2_normal) * y2, "Process2Time")

# 3. High-throughput rule: At most one reaction stage may use the high-throughput setting
model.addConstr(y1 + y2 <= 1, "AtMostOneHighThroughput")

# 4. By-product C balance: total C produced = C sold + C disposed
model.addConstr(cSold + cDisposed == c_per_b * xB, "ByproductBalance")

# 5. Maximum C that can be sold
model.addConstr(cSold <= max_c_sales, "MaxCSales")

# 6. Piecewise linear C disposal cost linearization constraints
#    a. Total disposed amount is the sum of amounts at base and high costs
model.addConstr(cDisposed == cDisposed_low + cDisposed_high, "CDisposedSum")
#    b. Amount disposed at base cost cannot exceed the threshold
model.addConstr(cDisposed_low <= threshold_c, "CDisposedLowLimit")
#    c. Amount disposed at high cost is zero if the threshold is not crossed (z_c_disposal = 0)
model.addConstr(cDisposed_high <= bigM_disposal * z_c_disposal, "CDisposedHighLink1")
#    d. Link z_c_disposal to cDisposed crossing the threshold (Big M formulation)
#       If cDisposed > threshold_c, then z_c_disposal must be 1.
#       Using a small epsilon (e.g., 1e-6) to handle strict inequality for threshold crossing.
epsilon = 1e-6
model.addConstr(cDisposed >= threshold_c + epsilon - bigM_disposal * (1 - z_c_disposal), "CDisposedLink2")
#       If cDisposed <= threshold_c, then z_c_disposal must be 0.
model.addConstr(cDisposed <= threshold_c + bigM_disposal * z_c_disposal, "CDisposedLink3")

# --- Optimize the model ---
model.optimize()

# --- Output results ---
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
elif model.status == GRB.INF_OR_UNBD:
    # This status indicates the model is either infeasible or unbounded.
    # For production, further analysis (e.g., IIS for infeasibility) would be needed.
    print("Model is infeasible or unbounded")
elif model.status == GRB.INFEASIBLE:
    print("Model is infeasible")
elif model.status == GRB.UNBOUNDED:
    print("Model is unbounded")
else:
    print(f"Optimization ended with status {model.status}")
