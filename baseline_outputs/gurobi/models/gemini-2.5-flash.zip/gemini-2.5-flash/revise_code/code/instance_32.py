import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, '..', 'data')
    
    # --- Data Loading ---
    
    # Read table_1.csv for workshops, components, and production rates
    workshops = []
    rates = {}  # rates[(workshop, component)] = production rate
    
    filepath = os.path.join(data_dir, 'table_1.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    components = [1, 2, 3]
    shifts = ['Day', 'Night']
    hour_types = ['Regular', 'Overtime']

    # Read general_parameters.csv for limits, penalties, z_target, and Big-M values
    general_params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            try:
                general_params[param_name] = float(value)
            except ValueError:
                general_params[param_name] = value # Should not happen for the parameters we need

    reg_hours_limit = {}
    ot_capacity = {}
    bigM_shift = {}

    for w in workshops:
        for s in shifts:
            reg_hours_limit[(w, s)] = general_params[f"regular_hours_limit_{s.lower()}_{w}"]
            ot_capacity[(w, s)] = general_params[f"overtime_capacity_{s.lower()}_{w}"]
        bigM_shift[w] = general_params[f"bigM_shift_{w}"]

    penalty_night_hour = general_params['penalty_night_hour']
    penalty_overtime_hour = general_params['penalty_overtime_hour']
    penalty_shortage_per_unit = general_params['penalty_shortage_per_unit']
    z_target = general_params['z_target']

    # --- Gurobi Model Setup ---
    model = gp.Model("Maximize_Completed_Products_with_Costs")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- Decision Variables ---
    # x[w, c, s, t]: Hours workshop w allocates to component c in shift s as hour type t
    x = model.addVars(workshops, components, shifts, hour_types, name="x", vtype=GRB.CONTINUOUS, lb=0)

    # z: Number of completed products
    z = model.addVar(name="z", vtype=GRB.CONTINUOUS, lb=0)

    # shortfall: Units below z_target
    shortfall = model.addVar(name="shortfall", vtype=GRB.CONTINUOUS, lb=0)

    # y[w, s]: Binary variable, 1 if workshop w is active in shift s, 0 otherwise
    y = model.addVars(workshops, shifts, name="y", vtype=GRB.BINARY)

    # --- Objective Function ---
    # Maximize (z - total_penalties)
    # total_penalties = night_hours_penalty + overtime_hours_penalty + shortage_penalty

    night_hours_penalty = gp.quicksum(
        penalty_night_hour * x[w, c, 'Night', 'Regular']
        for w in workshops for c in components
    )

    overtime_hours_penalty = gp.quicksum(
        penalty_overtime_hour * x[w, c, s, 'Overtime']
        for w in workshops for c in components for s in shifts
    )

    shortage_penalty = penalty_shortage_per_unit * shortfall

    model.setObjective(z - night_hours_penalty - overtime_hours_penalty - shortage_penalty, GRB.MAXIMIZE)

    # --- Constraints ---

    # 1. Regular hours limits per workshop per shift
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x[w, c, s, 'Regular'] for c in components) <= reg_hours_limit[(w, s)],
                f"Regular_Hours_Limit_{w}_{s}"
            )

    # 2. Overtime hours limits per workshop per shift
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x[w, c, s, 'Overtime'] for c in components) <= ot_capacity[(w, s)],
                f"Overtime_Capacity_{w}_{s}"
            )

    # 3. Total production of each component and completed products 'z' definition
    for c in components:
        total_units_c = gp.quicksum(
            rates[(w, c)] * (x[w, c, s, 'Regular'] + x[w, c, s, 'Overtime'])
            for w in workshops for s in shifts
        )
        model.addConstr(z <= total_units_c, f"Min_Component_Production_{c}")

    # 4. Shortfall definition: z + shortfall >= z_target
    model.addConstr(z + shortfall >= z_target, "Shortfall_Constraint")

    # 5. Supervision limit: no more than two workshops active in the same shift
    for s in shifts:
        model.addConstr(gp.quicksum(y[w, s] for w in workshops) <= 2, f"Supervision_Limit_{s}")

    # 6. Linking y[w, s] to actual hours worked (Big-M constraints)
    # If y[w,s] is 0, total_hours_ws must be 0. If y[w,s] is 1, total_hours_ws can be up to Big-M.
    for w in workshops:
        for s in shifts:
            total_hours_ws = gp.quicksum(
                x[w, c, s, 'Regular'] + x[w, c, s, 'Overtime']
                for c in components
            )
            model.addConstr(total_hours_ws <= bigM_shift[w] * y[w, s], f"Link_Active_Hours_{w}_{s}")

    # --- Optimize the model ---
    model.optimize()

    # --- Print Results ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
    else:
        print(f"Optimization did not find an optimal solution. Status: {model.status}")

if __name__ == "__main__":
    main()
