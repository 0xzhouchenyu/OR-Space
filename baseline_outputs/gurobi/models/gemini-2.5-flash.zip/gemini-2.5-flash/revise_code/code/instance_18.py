import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Utility function (copied from src/utils.py to be self-contained as per instructions)
def load_parameters(data_dir):
    """Load general parameters from CSV file."""
    params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

# Determine the data directory.
# The script is executed from the revised workspace root directory.
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load general parameters
params = load_parameters(data_dir)

weekly_production_time = params['weekly_production_time']
fabric_production_rate = params['fabric_production_rate']
min_curtain_fabric_sales = params['min_curtain_fabric_sales']
min_clothing_fabric_sales = params['min_clothing_fabric_sales']

day_shift_regular_capacity = params['day_shift_regular_capacity']
night_shift_regular_capacity = params['night_shift_regular_capacity']
day_overtime_limit = params['day_overtime_limit']
night_overtime_limit = params['night_overtime_limit']
day_overtime_penalty = params['day_overtime_penalty']
night_overtime_penalty = params['night_overtime_penalty']
day_min_utilization_ratio = params['day_min_utilization_ratio']
night_min_utilization_ratio = params['night_min_utilization_ratio']

# Convert sales requirements from meters to hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

# Create a new Gurobi model
model = gp.Model("Textile_Factory_Shift_Optimization")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# Decision variables:
# Regular hours allocated to each fabric type in each shift
day_clothing_reg = model.addVar(name="day_clothing_reg", lb=0)
day_curtain_reg = model.addVar(name="day_curtain_reg", lb=0)
night_clothing_reg = model.addVar(name="night_clothing_reg", lb=0)
night_curtain_reg = model.addVar(name="night_curtain_reg", lb=0)

# Overtime hours allocated to each fabric type in each shift
day_clothing_ot = model.addVar(name="day_clothing_ot", lb=0)
day_curtain_ot = model.addVar(name="day_curtain_ot", lb=0)
night_clothing_ot = model.addVar(name="night_clothing_ot", lb=0)
night_curtain_ot = model.addVar(name="night_curtain_ot", lb=0)

# Define total overtime for each shift for objective and limits
total_day_overtime = day_clothing_ot + day_curtain_ot
total_night_overtime = night_clothing_ot + night_curtain_ot

# Objective: Minimize total overtime penalty cost
model.setObjective(total_day_overtime * day_overtime_penalty +
                   total_night_overtime * night_overtime_penalty, GRB.MINIMIZE)

# Constraints

# 1. Minimum sales requirements (total production hours for each fabric type across all shifts)
model.addConstr((day_clothing_reg + day_clothing_ot) +
                (night_clothing_reg + night_clothing_ot) >= min_clothing_hours, "Min_Clothing_Production")

model.addConstr((day_curtain_reg + day_curtain_ot) +
                (night_curtain_reg + night_curtain_ot) >= min_curtain_hours, "Min_Curtain_Production")

# 2. Shift regular hours capacity limits
total_day_reg_hours = day_clothing_reg + day_curtain_reg
total_night_reg_hours = night_clothing_reg + night_curtain_reg

model.addConstr(total_day_reg_hours <= day_shift_regular_capacity, "Day_Shift_Regular_Capacity")
model.addConstr(total_night_reg_hours <= night_shift_regular_capacity, "Night_Shift_Regular_Capacity")

# 3. Shift regular utilization requirements
model.addConstr(total_day_reg_hours >= day_shift_regular_capacity * day_min_utilization_ratio, "Day_Shift_Min_Utilization")
model.addConstr(total_night_reg_hours >= night_shift_regular_capacity * night_min_utilization_ratio, "Night_Shift_Min_Utilization")

# 4. Shift overtime limits
model.addConstr(total_day_overtime <= day_overtime_limit, "Day_Overtime_Limit")
model.addConstr(total_night_overtime <= night_overtime_limit, "Night_Overtime_Limit")

# 5. Total weekly regular production time limit (global cap on regular hours across both shifts)
# The 'weekly_production_time' parameter (110 hours) is described as "shared across day and night shifts"
# and is less than the sum of individual shift regular capacities (60+60=120).
# This implies a global upper bound on total regular hours.
model.addConstr(total_day_reg_hours + total_night_reg_hours <= weekly_production_time, "Total_Weekly_Regular_Time_Limit")

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("Optimization was not successful.")
    # Optionally print status for debugging
    # print(f"Status: {model.status}")
