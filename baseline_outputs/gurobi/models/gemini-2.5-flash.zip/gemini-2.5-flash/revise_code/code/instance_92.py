import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    return params

# Determine the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load data
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

num_students = int(params['num_students'])
num_buses = int(params['num_buses'])
bus_capacity = int(params['bus_capacity'])
num_minibuses = int(params['num_minibuses'])
minibus_capacity = int(params['minibus_capacity'])
num_drivers = int(params['num_drivers'])
bus_rental_cost = float(params['bus_rental_cost'])
minibus_rental_cost = float(params['minibus_rental_cost'])

# Create a new model
model = gp.Model("SchoolTrip")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# Decision variables
# x: number of buses
# y: number of minibuses
x = model.addVar(lb=0, ub=num_buses, vtype=GRB.INTEGER, name="buses")
y = model.addVar(lb=0, ub=num_minibuses, vtype=GRB.INTEGER, name="minibuses")

# Objective: minimize total rental cost
model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

# Constraints

# 1. Must transport all students
model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, "StudentCapacity")

# 2. Total vehicles (drivers) constraint
model.addConstr(x + y <= num_drivers, "DriverLimit")

# 3. Safety policy: at least two buses per minibus
#    x >= 2 * y  =>  x - 2*y >= 0
model.addConstr(x - 2 * y >= 0, "BusesPerMinibusSafety")

# 4. Minimum one minibus to be rented
model.addConstr(y >= 1, "MinimumMinibus")

# Optimize the model
model.optimize()

# Output results
if model.status == GRB.OPTIMAL:
    final_obj_value = model.objVal
    # print(f"Buses: {int(x.X)}")
    # print(f"Minibuses: {int(y.X)}")
    print(f"FINAL_OBJ_VALUE: {final_obj_value}")
elif model.status == GRB.INF_OR_UNBD:
    print("FINAL_OBJ_VALUE: Problem is infeasible or unbounded")
elif model.status == GRB.INFEASIBLE:
    print("FINAL_OBJ_VALUE: Problem is infeasible")
elif model.status == GRB.UNBOUNDED:
    print("FINAL_OBJ_VALUE: Problem is unbounded")
else:
    print(f"FINAL_OBJ_VALUE: Optimization was stopped with status {model.status}")
