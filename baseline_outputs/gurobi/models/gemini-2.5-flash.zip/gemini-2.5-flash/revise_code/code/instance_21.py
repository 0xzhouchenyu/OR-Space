import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    
    # Parse general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Extract parameters
    cost_a = params['cost_supplier_a']
    cost_b = params['cost_supplier_b']
    cost_c = params['cost_supplier_c']
    size_a = int(params['order_size_supplier_a'])
    size_b = int(params['order_size_supplier_b'])
    size_c = int(params['order_size_supplier_c'])
    min_tables = int(params['min_tables_required'])
    max_tables = int(params['max_tables_allowed'])
    min_b_if_a = int(params['min_tables_supplier_b_if_a'])
    b_requires_c = int(params['supplier_b_requires_c']) # boolean (1 or 0)
    max_free_orders_c = int(params['max_free_orders_c'])
    penalty_per_extra_order_c = params['penalty_per_extra_order_c']
    supplier_bc_shared_inbound_trigger = int(params['supplier_bc_shared_inbound_trigger']) # boolean (1 or 0)
    supplier_bc_shared_inbound_fee = params['supplier_bc_shared_inbound_fee']
    
    M = 1000  # Big-M for linking binary and integer variables. Max orders is 600/15 = 40, so 1000 is sufficient.
    
    # Create a new Gurobi model
    model = gp.Model("Restaurant_Tables_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables: number of orders from each supplier (integer >= 0)
    x_a = model.addVar(vtype=GRB.INTEGER, name="orders_a", lb=0)
    x_b = model.addVar(vtype=GRB.INTEGER, name="orders_b", lb=0)
    x_c = model.addVar(vtype=GRB.INTEGER, name="orders_c", lb=0)
    
    # Binary variables to indicate if orders are placed from a supplier (1 if x_i >= 1, 0 otherwise)
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")
    
    # New variables for revised requirements
    # z_c_penalty: number of orders from C that incur a penalty
    z_c_penalty = model.addVar(vtype=GRB.INTEGER, name="z_c_penalty", lb=0) 
    # y_bc_combined: binary, 1 if both B and C are used, 0 otherwise
    y_bc_combined = model.addVar(vtype=GRB.BINARY, name="y_bc_combined") 
    
    # Objective: minimize total cost
    # Base cost from orders
    objective = cost_a * size_a * x_a + cost_b * size_b * x_b + cost_c * size_c * x_c
    
    # Add Supplier C penalty cost for orders beyond the free limit
    objective += penalty_per_extra_order_c * z_c_penalty
    
    # Add shared inbound fee if triggered
    if supplier_bc_shared_inbound_trigger == 1:
        objective += supplier_bc_shared_inbound_fee * y_bc_combined
        
    model.setObjective(objective, GRB.MINIMIZE)
    
    # Constraints
    
    # 1. Total tables constraints
    total_tables = size_a * x_a + size_b * x_b + size_c * x_c
    model.addConstr(total_tables >= min_tables, "Min_Total_Tables")
    model.addConstr(total_tables <= max_tables, "Max_Total_Tables")
    
    # 2. Link binary variables to order variables (y_i = 1 if x_i >= 1, else y_i = 0)
    # If x_i > 0, y_i must be 1. If x_i = 0, y_i must be 0.
    model.addConstr(x_a <= M * y_a, "Link_x_a_y_a_upper")
    model.addConstr(x_a >= y_a, "Link_x_a_y_a_lower") 
    
    model.addConstr(x_b <= M * y_b, "Link_x_b_y_b_upper")
    model.addConstr(x_b >= y_b, "Link_x_b_y_b_lower")
    
    model.addConstr(x_c <= M * y_c, "Link_x_c_y_c_upper")
    model.addConstr(x_c >= y_c, "Link_x_c_y_c_lower")
    
    # 3. If ordering from A, then tables from B must be at least min_b_if_a
    # This means if y_a is 1, then size_b * x_b must be >= min_b_if_a
    model.addConstr(size_b * x_b >= min_b_if_a * y_a, "Min_B_if_A")
    
    # 4. If ordering from B, must order from C
    # This means if y_b is 1, then y_c must be 1 (i.e., x_c >= 1)
    if b_requires_c == 1:
        model.addConstr(y_b <= y_c, "B_Requires_C")
    
    # 5. Supplier C comfort band penalty
    # z_c_penalty should be max(0, x_c - max_free_orders_c)
    # The objective will naturally minimize z_c_penalty to this value.
    model.addConstr(z_c_penalty >= x_c - max_free_orders_c, "C_Penalty_Lower")
    # z_c_penalty >= 0 is already enforced by its lower bound.
    
    # 6. Shared receiving desk fee for Supplier B and C combination
    # y_bc_combined = 1 if y_b = 1 AND y_c = 1, otherwise 0.
    if supplier_bc_shared_inbound_trigger == 1:
        model.addConstr(y_bc_combined <= y_b, "Link_y_bc_y_b")
        model.addConstr(y_bc_combined <= y_c, "Link_y_bc_y_c")
        model.addConstr(y_bc_combined >= y_b + y_c - 1, "Link_y_bc_both")
    
    # Optimize model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # If no optimal solution is found, print the model status
        print(f"FINAL_OBJ_VALUE: {model.status}")
        
if __name__ == "__main__":
    main()
