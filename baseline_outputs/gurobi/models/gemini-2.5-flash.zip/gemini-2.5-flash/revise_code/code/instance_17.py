import gurobipy as gp
from gurobipy import GRB
import csv
import os
import math

# --- Utility functions (copied and adapted from src/utils.py) ---
def load_data():
    """
    Loads data from 'table_1.csv' and 'general_parameters.csv'.
    Assumes data files are in a 'data' subdirectory relative to the script.
    """
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load table_1.csv
    parts = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
    
    # Load general_parameters.csv
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    return parts, params

def fuel_per_heavy_bomb(distance, params):
    """
    Calculates the base fuel consumption for one trip carrying a heavy bomb
    to target and returning empty. This includes takeoff/landing fuel,
    but excludes scenario-specific overheads.
    """
    eff_heavy = params['fuel_efficiency_heavy_bomb']
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    return distance / eff_heavy + distance / eff_empty + takeoff_landing

def fuel_per_light_bomb(distance, params):
    """
    Calculates the base fuel consumption for one trip carrying a light bomb
    to target and returning empty. This includes takeoff/landing fuel,
    but excludes scenario-specific overheads.
    """
    eff_light = params['fuel_efficiency_light_bomb']
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    return distance / eff_light + distance / eff_empty + takeoff_landing

# --- Main optimization script ---
def solve_revised_problem():
    parts_data, params = load_data()

    # Extract parameters from loaded data
    max_heavy_bombs = int(params['max_heavy_bombs'])
    max_light_bombs = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts_destroyed = int(params['min_parts_destroyed'])
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    sortie_fuel_overhead_A = params['sortie_fuel_overhead_A']
    sortie_fuel_overhead_B = params['sortie_fuel_overhead_B']
    # Scenario probabilities are for context of robust feasibility, not for objective weighting
    # scenario_prob_A = params['scenario_prob_A']
    # scenario_prob_B = params['scenario_prob_B']

    n_parts = len(parts_data)
    part_indices = range(n_parts)

    # Pre-calculate base fuel costs per bomb type per part
    # These are the costs for the loaded outbound leg, empty return leg, and takeoff/landing.
    base_fuel_h = [fuel_per_heavy_bomb(p['distance'], params) for p in parts_data]
    base_fuel_l = [fuel_per_light_bomb(p['distance'], params) for p in parts_data]

    # Create Gurobi model
    model = gp.Model("StrategicBomberAllocation")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    # Enable non-convex quadratic/polynomial optimization for GenConstrs
    model.setParam('NonConvex', 2) 

    # --- Decision Variables ---
    # xh[i]: number of heavy bombs allocated to part i
    # xl[i]: number of light bombs allocated to part i
    # The upper bound for individual bombs is limited by total stockpile and total sorties.
    # Total sorties must be <= min(max_sorties_A, max_sorties_B).
    # min(max_sorties_A, max_sorties_B) = min(14, 10) = 10.
    # So, an individual xh[i] or xl[i] cannot exceed 10.
    xh = model.addVars(part_indices, vtype=GRB.INTEGER, name="xh", 
                       ub=min(max_heavy_bombs, max_sorties_B))
    xl = model.addVars(part_indices, vtype=GRB.INTEGER, name="xl", 
                       ub=min(max_light_bombs, max_sorties_B))

    # --- Constraints ---
    # 1. Bomb stockpile limits
    model.addConstr(xh.sum() <= max_heavy_bombs, "HeavyBombStockpile")
    model.addConstr(xl.sum() <= max_light_bombs, "LightBombStockpile")

    # 2. Total sorties limit (must be feasible for both scenarios)
    total_sorties = model.addVar(vtype=GRB.INTEGER, name="total_sorties")
    model.addConstr(total_sorties == gp.quicksum(xh[i] + xl[i] for i in part_indices), "TotalSortiesDef")
    # The total number of sorties must be within the limits of both aircraft types.
    model.addConstr(total_sorties <= max_sorties_A, "SortieLimit_A")
    model.addConstr(total_sorties <= max_sorties_B, "SortieLimit_B")

    # 3. Fuel limits (must be feasible for both scenarios)
    # Calculate the base fuel consumption (sum of individual bomb trip costs)
    base_fuel_consumption = gp.quicksum(xh[i] * base_fuel_h[i] + xl[i] * base_fuel_l[i] for i in part_indices)

    # Fuel consumption for scenario A (base + total sorties * overhead A)
    fuel_consumed_A = model.addVar(name="fuel_consumed_A")
    model.addConstr(fuel_consumed_A == base_fuel_consumption + total_sorties * sortie_fuel_overhead_A, "FuelConsumed_A_Def")
    model.addConstr(fuel_consumed_A <= fuel_limit, "FuelLimit_A")

    # Fuel consumption for scenario B (base + total sorties * overhead B)
    fuel_consumed_B = model.addVar(name="fuel_consumed_B")
    model.addConstr(fuel_consumed_B == base_fuel_consumption + total_sorties * sortie_fuel_overhead_B, "FuelConsumed_B_Def")
    model.addConstr(fuel_consumed_B <= fuel_limit, "FuelLimit_B")

    # --- Non-linear Objective: Maximize Probability of Mission Success ---
    # The objective is P(at least min_parts_destroyed successes)
    # where P_i = 1 - (1 - p_heavy_i)^xh_i * (1 - p_light_i)^xl_i

    # Auxiliary variables for destruction probabilities P[i] and survival probabilities Q[i]
    P = model.addVars(part_indices, vtype=GRB.CONTINUOUS, lb=0.0, ub=1.0, name="P")
    Q = model.addVars(part_indices, vtype=GRB.CONTINUOUS, lb=0.0, ub=1.0, name="Q") # Q[i] = 1 - P[i]

    # Link P[i] to xh[i], xl[i] using Gurobi General Constraints (GenConstrs)
    for i in part_indices:
        p_h_i = parts_data[i]['p_heavy']
        p_l_i = parts_data[i]['p_light']
        q_h_i = 1.0 - p_h_i # Probability of a heavy bomb NOT destroying part i
        q_l_i = 1.0 - p_l_i # Probability of a light bomb NOT destroying part i

        # Variables for (1-p_heavy)^xh and (1-p_light)^xl
        # These represent the probability of xh heavy bombs (or xl light bombs) all failing to destroy part i.
        var_q_h_pow = model.addVar(lb=0.0, ub=1.0, name=f"q_h_pow_{i}")
        var_q_l_pow = model.addVar(lb=0.0, ub=1.0, name=f"q_l_pow_{i}")

        # Add power constraints: var_q_h_pow = q_h_i ^ xh[i]
        # Gurobi's addGenConstrPow(x, y, z, name) means z = x^y.
        # Here, x is a constant (q_h_i), y is an integer variable (xh[i]), and z is a continuous variable.
        model.addGenConstrPow(q_h_i, xh[i], var_q_h_pow, name=f"pow_h_{i}")
        model.addGenConstrPow(q_l_i, xl[i], var_q_l_pow, name=f"pow_l_{i}")

        # Variable for product: var_prod_survival = var_q_h_pow * var_q_l_pow
        # This is the probability that part i survives after xh heavy and xl light bombs.
        var_prod_survival = model.addVar(lb=0.0, ub=1.0, name=f"prod_survival_{i}")
        model.addGenConstrProd([var_q_h_pow, var_q_l_pow], var_prod_survival, name=f"prod_survival_constr_{i}")

        # P[i] = 1 - var_prod_survival (Probability of destroying part i)
        model.addConstr(P[i] == 1.0 - var_prod_survival, name=f"P_def_{i}")
        # Q[i] = 1 - P[i] (Probability of part i surviving)
        model.addConstr(Q[i] == 1.0 - P[i], name=f"Q_def_{i}")

    # Calculate P(at least k successes) for n=4, k=min_parts_destroyed (which is 2)
    # P(at least 2) = P(exactly 2) + P(exactly 3) + P(exactly 4)
    # This involves products of P[i] and Q[i] variables.
    # We need auxiliary variables for each product term, then sum them for the objective.

    objective_terms = []

    # P(exactly 2 successes) - 6 terms
    # P0 P1 Q2 Q3
    term_P0P1Q2Q3 = model.addVar(lb=0.0, ub=1.0, name="term_P0P1Q2Q3")
    model.addGenConstrProd([P[0], P[1], Q[2], Q[3]], term_P0P1Q2Q3, "prod_P0P1Q2Q3")
    objective_terms.append(term_P0P1Q2Q3)

    # P0 Q1 P2 Q3
    term_P0Q1P2Q3 = model.addVar(lb=0.0, ub=1.0, name="term_P0Q1P2Q3")
    model.addGenConstrProd([P[0], Q[1], P[2], Q[3]], term_P0Q1P2Q3, "prod_P0Q1P2Q3")
    objective_terms.append(term_P0Q1P2Q3)

    # P0 Q1 Q2 P3
    term_P0Q1Q2P3 = model.addVar(lb=0.0, ub=1.0, name="term_P0Q1Q2P3")
    model.addGenConstrProd([P[0], Q[1], Q[2], P[3]], term_P0Q1Q2P3, "prod_P0Q1Q2P3")
    objective_terms.append(term_P0Q1Q2P3)

    # Q0 P1 P2 Q3
    term_Q0P1P2Q3 = model.addVar(lb=0.0, ub=1.0, name="term_Q0P1P2Q3")
    model.addGenConstrProd([Q[0], P[1], P[2], Q[3]], term_Q0P1P2Q3, "prod_Q0P1P2Q3")
    objective_terms.append(term_Q0P1P2Q3)

    # Q0 P1 Q2 P3
    term_Q0P1Q2P3 = model.addVar(lb=0.0, ub=1.0, name="term_Q0P1Q2P3")
    model.addGenConstrProd([Q[0], P[1], Q[2], P[3]], term_Q0P1Q2P3, "prod_Q0P1Q2P3")
    objective_terms.append(term_Q0P1Q2P3)

    # Q0 Q1 P2 P3
    term_Q0Q1P2P3 = model.addVar(lb=0.0, ub=1.0, name="term_Q0Q1P2P3")
    model.addGenConstrProd([Q[0], Q[1], P[2], P[3]], term_Q0Q1P2P3, "prod_Q0Q1P2P3")
    objective_terms.append(term_Q0Q1P2P3)

    # P(exactly 3 successes) - 4 terms
    # P0 P1 P2 Q3
    term_P0P1P2Q3 = model.addVar(lb=0.0, ub=1.0, name="term_P0P1P2Q3")
    model.addGenConstrProd([P[0], P[1], P[2], Q[3]], term_P0P1P2Q3, "prod_P0P1P2Q3")
    objective_terms.append(term_P0P1P2Q3)

    # P0 P1 Q2 P3
    term_P0P1Q2P3 = model.addVar(lb=0.0, ub=1.0, name="term_P0P1Q2P3")
    model.addGenConstrProd([P[0], P[1], Q[2], P[3]], term_P0P1Q2P3, "prod_P0P1Q2P3")
    objective_terms.append(term_P0P1Q2P3)

    # P0 Q1 P2 P3
    term_P0Q1P2P3 = model.addVar(lb=0.0, ub=1.0, name="term_P0Q1P2P3")
    model.addGenConstrProd([P[0], Q[1], P[2], P[3]], term_P0Q1P2P3, "prod_P0Q1P2P3")
    objective_terms.append(term_P0Q1P2P3)

    # Q0 P1 P2 P3
    term_Q0P1P2P3 = model.addVar(lb=0.0, ub=1.0, name="term_Q0P1P2P3")
    model.addGenConstrProd([Q[0], P[1], P[2], P[3]], term_Q0P1P2P3, "prod_Q0P1P2P3")
    objective_terms.append(term_Q0P1P2P3)

    # P(exactly 4 successes) - 1 term
    # P0 P1 P2 P3
    term_P0P1P2P3 = model.addVar(lb=0.0, ub=1.0, name="term_P0P1P2P3")
    model.addGenConstrProd([P[0], P[1], P[2], P[3]], term_P0P1P2P3, "prod_P0P1P2P3")
    objective_terms.append(term_P0P1P2P3)

    # Set objective: Maximize the sum of all these terms
    model.setObjective(gp.quicksum(objective_terms), GRB.MAXIMIZE)

    # Optimize the model
    model.optimize()

    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.4f}")
    else:
        print("Optimization did not find an optimal solution.")
        print(f"Model status: {model.status}")

if __name__ == '__main__':
    solve_revised_problem()
