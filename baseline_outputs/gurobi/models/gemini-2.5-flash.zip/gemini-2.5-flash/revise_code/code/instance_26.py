import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_problem():
    # --- 1. Load Data ---
    # Determine the directory of the current script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')

    # Load general parameters from general_parameters.csv
    general_params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row['Parameter_Name']] = float(row['Value'])

    full_time_cost = general_params['full_time_cost']
    part_time_cost = general_params['part_time_cost']
    part_time_cap_per_period = int(general_params['part_time_cap_per_period'])
    min_full_time_per_period = int(general_params['min_full_time_per_period'])

    # Load staffing requirements from table_1.csv
    requirements = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row['Time_Period'].strip()
            req = int(row['Required_Salespeople'].strip())
            requirements[period] = req

    # The time periods and their requirements in order, indexed 0 to n-1
    periods = list(requirements.keys())
    req_values = list(requirements.values())
    n = len(periods)  # Number of 4-hour periods (should be 6)

    # --- 2. Initialize Gurobi Model ---
    model = gp.Model("ConvenienceStoreStaffingRevised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- 3. Define Decision Variables ---
    # x[i]: number of full-time salespeople starting a shift at the beginning of period i
    # Full-time shifts are 8 hours, covering period i and (i+1)%n
    x = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="full_time_starts")

    # y[j]: number of part-time salespeople assigned to work during period j
    # Part-time shifts are 4 hours, covering only period j
    y = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="part_time_assignments")

    # --- 4. Set Objective Function ---
    # Minimize total daily labor cost
    # Total Cost = (sum of full-time costs) + (sum of part-time costs)
    model.setObjective(
        gp.quicksum(x[i] * full_time_cost for i in range(n)) +
        gp.quicksum(y[j] * part_time_cost for j in range(n)),
        GRB.MINIMIZE
    )

    # --- 5. Add Constraints ---

    # Constraint 1: Total Staffing Requirement for each period j
    # In each period j, the combined staff (full-time + part-time) must meet the demand.
    # Full-time staff present in period j are those who started in period j (x[j])
    # and those who started in period (j-1)%n (x[(j-1+n)%n], using +n to handle j=0 correctly).
    for j in range(n):
        model.addConstr(
            x[j] + x[(j - 1 + n) % n] + y[j] >= req_values[j],
            f"total_demand_period_{j}"
        )

    # Constraint 2: Part-time Cap for each period j
    # The number of part-time workers in any period j cannot exceed part_time_cap_per_period.
    for j in range(n):
        model.addConstr(
            y[j] <= part_time_cap_per_period,
            f"part_time_cap_period_{j}"
        )

    # Constraint 3: Minimum Full-time Staff for each period j
    # The number of full-time staff physically present in each period j must be at least min_full_time_per_period.
    for j in range(n):
        model.addConstr(
            x[j] + x[(j - 1 + n) % n] >= min_full_time_per_period,
            f"min_full_time_period_{j}"
        )

    # --- 6. Optimize the Model ---
    model.optimize()

    # --- 7. Print Results ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # Handle cases where the model is not optimal (e.g., infeasible, unbounded)
        print(f"Optimization did not find an optimal solution. Status: {model.status}")
        if model.status == GRB.INFEASIBLE:
            # Optional: Compute and print an IIS for debugging infeasibility
            # model.computeIIS()
            # model.write("model.ilp")
            # print("Infeasible model written to 'model.ilp'")
            pass

if __name__ == "__main__":
    solve_revised_problem()
