import os
import re
import csv
import gurobipy as gp
from gurobipy import GRB

# Utility function from the original workspace
def get_data_dir():
    # This assumes the script is in src/
    # and data is in data/
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

def solve_revised_tsp():
    data_dir = get_data_dir()

    # --- 1. Read Parameters ---
    num_customers = 0
    start_location = 0
    end_location = 0
    max_route_length_day = 0.0
    route_cost_day = 0.0

    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'num_customers':
                num_customers = int(row['Value'])
            elif row['Parameter_Name'] == 'start_location':
                start_location = int(row['Value']) - 1 # Convert to 0-indexed
            elif row['Parameter_Name'] == 'end_location':
                end_location = int(row['Value']) - 1 # Convert to 0-indexed
            elif row['Parameter_Name'] == 'max_route_length_day':
                max_route_length_day = float(row['Value'])
            elif row['Parameter_Name'] == 'route_cost_day':
                route_cost_day = float(row['Value'])

    # Ensure start_location and end_location are the same (depot)
    if start_location != end_location:
        raise ValueError("Start and end locations must be the same (depot) for this problem.")
    DEPOT = start_location

    # Define sets
    N = range(num_customers) # All locations (0 to num_customers-1)
    CUSTOMER_NODES = range(1, num_customers) # Only actual customers (1 to num_customers-1)
    DAYS = range(2) # Day 0 and Day 1

    # --- 2. Read Distance Matrix D ---
    D = [[0] * num_customers for _ in range(num_customers)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        lines = f.readlines()
        for line in lines[1:]: # Skip header
            nums = re.findall(r'\d+', line)
            if not nums:
                continue
            row_idx = int(nums[0]) - 1 # Convert to 0-indexed
            for j, val in enumerate(nums[1:]):
                col_idx = row_idx + 1 + j # Calculate 0-indexed column
                if col_idx < num_customers: # Ensure within bounds
                    D[row_idx][col_idx] = int(val)
                    D[col_idx][row_idx] = int(val) # Symmetric matrix

    # --- 3. Gurobi Model ---
    model = gp.Model("Revised_TSP")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- 4. Decision Variables ---
    # x[i, j, d]: 1 if travel from i to j on day d, 0 otherwise
    x = model.addVars(N, N, DAYS, vtype=GRB.BINARY, name="x")
    # y[i, d]: 1 if customer i is visited on day d, 0 otherwise
    y = model.addVars(CUSTOMER_NODES, DAYS, vtype=GRB.BINARY, name="y")
    # z[d]: 1 if day d is active (at least one customer assigned), 0 otherwise
    z = model.addVars(DAYS, vtype=GRB.BINARY, name="z")
    # u[i, d]: Subtour elimination variable for customer i on day d
    # u variables are for customer nodes only, not the depot. Low bound 0 to allow for unvisited customers.
    u = model.addVars(CUSTOMER_NODES, DAYS, vtype=GRB.CONTINUOUS, name="u")

    # --- 5. Objective Function ---
    # Minimize total travel distance + fixed daily costs
    obj_expr = gp.quicksum(D[i][j] * x[i, j, d] for i in N for j in N for d in DAYS if i != j) \
               + gp.quicksum(route_cost_day * z[d] for d in DAYS)
    model.setObjective(obj_expr, GRB.MINIMIZE)

    # --- 6. Constraints ---

    # a. Each customer visited exactly once across all days
    for i in CUSTOMER_NODES:
        model.addConstr(gp.quicksum(y[i, d] for d in DAYS) == 1, name=f"customer_once_{i}")

    # b. Flow conservation and linking x, y, z
    for d in DAYS:
        # Depot exit/entry (DEPOT is 0-indexed start_location)
        # If day d is active (z[d]=1), exactly one edge leaves/enters the depot.
        # If day d is inactive (z[d]=0), no edges leave/enter the depot.
        model.addConstr(gp.quicksum(x[DEPOT, j, d] for j in CUSTOMER_NODES) == z[d], name=f"depot_exit_{d}")
        model.addConstr(gp.quicksum(x[j, DEPOT, d] for j in CUSTOMER_NODES) == z[d], name=f"depot_entry_{d}")

        # Customer flow
        for i in CUSTOMER_NODES:
            # One edge leaves customer i if visited on day d
            model.addConstr(gp.quicksum(x[i, j, d] for j in N if j != i) == y[i, d], name=f"flow_out_{i}_{d}")
            # One edge enters customer i if visited on day d
            model.addConstr(gp.quicksum(x[j, i, d] for j in N if j != i) == y[i, d], name=f"flow_in_{i}_{d}")

        # No self-loops (redundant given sums, but good for clarity)
        for i in N:
            model.addConstr(x[i, i, d] == 0, name=f"no_self_loop_{i}_{d}")

    # c. Link z[d] to y[i, d] (day activation)
    for d in DAYS:
        # If z[d]=0, no customers can be assigned to day d
        model.addConstr(gp.quicksum(y[i, d] for i in CUSTOMER_NODES) <= (num_customers - 1) * z[d], name=f"z_link_upper_{d}")
        # If z[d]=1, at least one customer must be assigned to day d
        model.addConstr(gp.quicksum(y[i, d] for i in CUSTOMER_NODES) >= z[d], name=f"z_link_lower_{d}")

    # d. Subtour elimination (MTZ formulation)
    # u variables are for customer nodes only
    for d in DAYS:
        for i in CUSTOMER_NODES:
            # u[i,d] must be 0 if customer i is not visited on day d, and bounded if visited
            model.addConstr(u[i, d] >= y[i, d], name=f"u_lower_bound_{i}_{d}")
            model.addConstr(u[i, d] <= (num_customers - 1) * y[i, d], name=f"u_upper_bound_{i}_{d}")

        for i in CUSTOMER_NODES:
            for j in CUSTOMER_NODES:
                if i != j:
                    # Standard MTZ constraint: u[i] - u[j] + M * x[i,j] <= M - 1
                    # where M is the number of customer nodes (num_customers - 1)
                    # This constraint is effective only if x[i,j,d]=1, which implies y[i,d]=1 and y[j,d]=1
                    model.addConstr(u[i, d] - u[j, d] + (num_customers - 1) * x[i, j, d] <= num_customers - 2, name=f"mtz_{i}_{j}_{d}")

    # e. Daily maximum route length constraint
    for d in DAYS:
        model.addConstr(gp.quicksum(D[i][j] * x[i, j, d] for i in N for j in N if i != j) <= max_route_length_day, name=f"max_route_length_{d}")

    # --- 7. Optimize Model ---
    model.optimize()

    # --- 8. Print Results ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible.")
    elif model.status == GRB.UNBOUNDED:
        print("Model is unbounded.")
    else:
        print(f"Optimization ended with status {model.status}")

if __name__ == "__main__":
    solve_revised_tsp()
