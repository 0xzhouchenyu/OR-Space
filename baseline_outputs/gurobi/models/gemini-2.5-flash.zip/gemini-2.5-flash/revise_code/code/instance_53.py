import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # --- 1. Load Data ---
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    
    # Read costs from table_1.csv
    costs = {}
    children = []
    modes = ['budget', 'balanced', 'premium']
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            child_name = row['Child'].strip()
            children.append(child_name)
            costs[child_name] = {
                'budget': float(row['Cost_budget'].strip()),
                'balanced': float(row['Cost_balanced'].strip()),
                'premium': float(row['Cost_premium'].strip())
            }
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children = int(params['max_children'])
    min_children = int(params['min_children'])
    fairness_penalty = float(params['fairness_penalty'])
    max_total_cost = float(params['max_total_cost'])
    min_children_per_mode = int(params['min_children_per_mode'])

    # Define a large M for big-M constraints.
    # Max possible child cost is 1900 (Hermione premium).
    # Min possible child cost is 600 (Ron budget).
    # M should be larger than any possible cost or cost difference.
    M = 2000 

    # --- 2. Create Gurobi Model ---
    m = gp.Model("ZhangFamilyTripRevised")
    m.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- 3. Decision Variables ---
    # x[c]: binary, 1 if child c is taken, 0 otherwise
    x = m.addVars(children, vtype=GRB.BINARY, name="x")
    
    # y[mode]: binary, 1 if mode is selected, 0 otherwise
    y = m.addVars(modes, vtype=GRB.BINARY, name="y")

    # z[c, m]: binary, 1 if child c is taken AND mode m is selected
    # Used for linearizing the product x[c] * y[m]
    z = m.addVars(children, modes, vtype=GRB.BINARY, name="z")

    # child_cost_if_selected[c]: continuous, actual cost of child c if selected, based on chosen mode.
    # This variable holds the cost of child c under the chosen mode, regardless of whether x[c] is 1.
    # It's used as a base for fairness calculation.
    child_cost_if_selected = m.addVars(children, vtype=GRB.CONTINUOUS, name="child_cost_if_selected")

    # total_actual_cost: continuous, total monetary cost of all selected children under the chosen mode
    total_actual_cost = m.addVar(vtype=GRB.CONTINUOUS, name="total_actual_cost")

    # min_child_cost: continuous, minimum cost among selected children
    min_child_cost = m.addVar(vtype=GRB.CONTINUOUS, name="min_child_cost")
    # max_child_cost: continuous, maximum cost among selected children
    max_child_cost = m.addVar(vtype=GRB.CONTINUOUS, name="max_child_cost")
    # cost_spread: continuous, max_child_cost - min_child_cost
    cost_spread = m.addVar(vtype=GRB.CONTINUOUS, name="cost_spread")

    # u_min[c]: binary, 1 if child c has the minimum cost among selected children
    u_min = m.addVars(children, vtype=GRB.BINARY, name="u_min")
    # u_max[c]: binary, 1 if child c has the maximum cost among selected children
    u_max = m.addVars(children, vtype=GRB.BINARY, name="u_max")

    # --- 4. Objective Function ---
    # Minimize total actual cost plus fairness penalty (fairness_penalty * cost_spread)
    m.setObjective(total_actual_cost + fairness_penalty * cost_spread, GRB.MINIMIZE)

    # --- 5. Constraints ---

    # Core Family Rules (from original problem)
    m.addConstr(x['Ginny'] == 1, "Ginny_must_go")
    
    num_selected = gp.quicksum(x[c] for c in children)
    m.addConstr(num_selected <= max_children, "Max_children")
    
    m.addConstr(x['Harry'] + x['Fred'] <= 1, "Harry_no_Fred")
    m.addConstr(x['Harry'] + x['George'] <= 1, "Harry_no_George")
    m.addConstr(x['George'] <= x['Fred'], "George_requires_Fred")
    m.addConstr(x['George'] <= x['Hermione'], "George_requires_Hermione")

    # Pace Mode Selection: Exactly one pace mode must be selected
    m.addConstr(gp.quicksum(y[mode] for mode in modes) == 1, "One_pace_mode")

    # Linearization of x[c] * y[m] product (z[c,m])
    # z[c,m] is 1 if child c is taken AND mode m is selected
    for c in children:
        for mode in modes:
            m.addConstr(z[c, mode] <= x[c], f"z_{c}_{mode}_le_x_{c}")
            m.addConstr(z[c, mode] <= y[mode], f"z_{c}_{mode}_le_y_{mode}")
            m.addConstr(z[c, mode] >= x[c] + y[mode] - 1, f"z_{c}_{mode}_ge_x_{c}_plus_y_{mode}_minus_1")

    # Total Actual Cost Definition
    # total_actual_cost is the sum of costs for selected children under the chosen mode
    m.addConstr(total_actual_cost == gp.quicksum(costs[c][mode] * z[c, mode] for c in children for mode in modes), "Total_Actual_Cost_Def")

    # Child Cost If Selected Definition (for fairness calculation)
    # child_cost_if_selected[c] takes the value of costs[c][mode] for the selected mode
    for c in children:
        m.addConstr(child_cost_if_selected[c] == gp.quicksum(costs[c][mode] * y[mode] for mode in modes), f"Child_Cost_If_Selected_{c}")

    # Fairness Constraints
    m.addConstr(cost_spread == max_child_cost - min_child_cost, "Cost_Spread_Def")

    # Link min_child_cost and max_child_cost to selected children's costs
    # 1. min_child_cost must be less than or equal to the cost of any selected child
    # 2. max_child_cost must be greater than or equal to the cost of any selected child
    for c in children:
        m.addConstr(min_child_cost <= child_cost_if_selected[c] + M * (1 - x[c]), f"Min_Cost_Upper_Bound_{c}")
        m.addConstr(max_child_cost >= child_cost_if_selected[c] - M * (1 - x[c]), f"Max_Cost_Lower_Bound_{c}")
    
    # 3. Ensure min_child_cost is the actual minimum among selected children
    # 4. Ensure max_child_cost is the actual maximum among selected children
    # This is done by selecting one child as the minimum and one as the maximum.
    m.addConstr(gp.quicksum(u_min[c] for c in children) == 1, "One_Min_Child")
    m.addConstr(gp.quicksum(u_max[c] for c in children) == 1, "One_Max_Child")
    
    for c in children:
        # The child designated as min/max must actually be selected for the trip
        m.addConstr(u_min[c] <= x[c], f"Min_Child_Must_Be_Selected_{c}") 
        m.addConstr(u_max[c] <= x[c], f"Max_Child_Must_Be_Selected_{c}") 
        
        # If u_min[c] is 1, then min_child_cost must be >= child_cost_if_selected[c]
        m.addConstr(min_child_cost >= child_cost_if_selected[c] - M * (1 - u_min[c]), f"Min_Cost_Lower_Bound_{c}")
        # If u_max[c] is 1, then max_child_cost must be <= child_cost_if_selected[c]
        m.addConstr(max_child_cost <= child_cost_if_selected[c] + M * (1 - u_max[c]), f"Max_Cost_Upper_Bound_{c}")

    # Budget Constraint: Total actual cost must not exceed max_total_cost
    m.addConstr(total_actual_cost <= max_total_cost, "Max_Total_Cost")

    # Min Children per Mode Constraint
    # If budget mode (y['budget']==1), min_children applies.
    # If balanced or premium mode (y['budget']==0), min_children_per_mode applies.
    # This can be formulated as: num_selected >= min_children_per_mode - (min_children_per_mode - min_children) * y['budget']
    # If y['budget'] = 1: num_selected >= min_children_per_mode - (min_children_per_mode - min_children) = min_children
    # If y['budget'] = 0: num_selected >= min_children_per_mode
    m.addConstr(num_selected >= min_children_per_mode - (min_children_per_mode - min_children) * y['budget'], "Min_Children_Per_Mode")

    # --- 6. Solve Model ---
    m.optimize()

    # --- 7. Print Solution ---
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    elif m.status == GRB.INFEASIBLE:
        print("FINAL_OBJ_VALUE: Infeasible")
    elif m.status == GRB.UNBOUNDED:
        print("FINAL_OBJ_VALUE: Unbounded")
    else:
        print(f"FINAL_OBJ_VALUE: {m.objVal if m.objVal is not None else 'N/A'}")

if __name__ == "__main__":
    main()
