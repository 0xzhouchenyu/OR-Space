import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Utility function to load parameters
def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                params[row['Parameter_Name']] = float(row['Value'])
            except ValueError:
                # In case a parameter value is not a float, store as string.
                # For this problem, all relevant parameters are floats.
                params[row['Parameter_Name']] = row['Value']
    return params

# Determine the directory for data files
# This script is expected to be run from the workspace root,
# so data files are in 'data/' relative to the script's parent directory.
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, '..', 'data')

# Load parameters from general_parameters.csv
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
a1 = params['a1']
a2 = params['a2']
training_capacity_per_jet = params['training_capacity_per_jet']
dual_use_training_efficiency = params['dual_use_training_efficiency']
training_intensity_cap = params['training_intensity_cap']
combat_jet_min_year2 = params['combat_jet_min_year2']
combat_weight = params['combat_weight']
training_weight = params['training_weight']

# Create a new Gurobi model
model = gp.Model("FighterJetAllocation")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# --- Decision Variables ---
# All variables represent counts of jets and must be non-negative integers.

# Year 1 allocations
T1 = model.addVar(vtype=GRB.INTEGER, name="T1_ExclusiveTraining_Y1")
M1 = model.addVar(vtype=GRB.INTEGER, name="M1_MixedUse_Y1")
C1 = model.addVar(vtype=GRB.INTEGER, name="C1_ExclusiveCombat_Y1")

# Year 2 allocations based on their origin (from Y1 categories or new A2 production)

# Jets that were in exclusive training in Y1 (T1)
T2_from_T1 = model.addVar(vtype=GRB.INTEGER, name="T2_from_T1_ExclusiveTraining_Y2")
M2_from_T1 = model.addVar(vtype=GRB.INTEGER, name="M2_from_T1_MixedUse_Y2")

# Jets that were in mixed-use in Y1 (M1)
T2_from_M1 = model.addVar(vtype=GRB.INTEGER, name="T2_from_M1_ExclusiveTraining_Y2")
M2_from_M1 = model.addVar(vtype=GRB.INTEGER, name="M2_from_M1_MixedUse_Y2")

# Jets that were in exclusive combat in Y1 (C1)
T2_from_C1 = model.addVar(vtype=GRB.INTEGER, name="T2_from_C1_ExclusiveTraining_Y2")
M2_from_C1 = model.addVar(vtype=GRB.INTEGER, name="M2_from_C1_MixedUse_Y2")
C2_from_C1 = model.addVar(vtype=GRB.INTEGER, name="C2_from_C1_ExclusiveCombat_Y2")

# Newly produced jets in Y2 (A2)
T2_from_A2 = model.addVar(vtype=GRB.INTEGER, name="T2_from_A2_ExclusiveTraining_Y2")
M2_from_A2 = model.addVar(vtype=GRB.INTEGER, name="M2_from_A2_MixedUse_Y2")
C2_from_A2 = model.addVar(vtype=GRB.INTEGER, name="C2_from_A2_ExclusiveCombat_Y2")

# --- Derived Variables for Year 2 Totals ---
# These expressions simplify the formulation of constraints and the objective function.
T2 = T2_from_T1 + T2_from_M1 + T2_from_C1 + T2_from_A2
M2 = M2_from_T1 + M2_from_M1 + M2_from_C1 + M2_from_A2
C2 = C2_from_C1 + C2_from_A2

# --- Constraints ---

# 1. Year 1 Jet Allocation: All 'a1' jets must be allocated in Year 1.
model.addConstr(T1 + M1 + C1 == a1, "C1_Y1_Allocation")

# 2. Year 1 T-jets flow: Jets committed to exclusive training in Y1 (T1) must continue
#    as either exclusive training (T2) or mixed-use (M2) in Y2.
model.addConstr(T2_from_T1 + M2_from_T1 == T1, "C2_T1_Flow")

# 3. Year 1 M-jets flow: Jets committed to mixed-use in Y1 (M1) must continue
#    as either exclusive training (T2) or mixed-use (M2) in Y2.
model.addConstr(T2_from_M1 + M2_from_M1 == M1, "C3_M1_Flow")

# 4. Year 1 C-jets flow: Jets committed to exclusive combat in Y1 (C1) can be re-allocated
#    to any category (T2, M2, or C2) in Y2.
model.addConstr(T2_from_C1 + M2_from_C1 + C2_from_C1 == C1, "C4_C1_Flow")

# 5. Year 2 New jets allocation: All 'a2' newly produced jets must be allocated in Y2.
model.addConstr(T2_from_A2 + M2_from_A2 + C2_from_A2 == a2, "C5_A2_Allocation")

# 6. Year 2 Combat Minimum: The total number of combat-available jets (exclusive combat + mixed-use)
#    in Year 2 must meet the minimum requirement.
model.addConstr(C2 + M2 >= combat_jet_min_year2, "C6_CombatMin_Y2")

# 7. Year 1 Training Intensity Cap: The fraction of jets in training-only or dual-use modes
#    in Year 1 cannot exceed the specified cap.
model.addConstr(T1 + M1 <= training_intensity_cap * a1, "C7_TrainingIntensityCap_Y1")

# 8. Year 2 Training Intensity Cap: The fraction of jets in training-only or dual-use modes
#    in Year 2 cannot exceed the specified cap. The total fleet in Y2 is a1 + a2.
model.addConstr(T2 + M2 <= training_intensity_cap * (a1 + a2), "C8_TrainingIntensityCap_Y2")

# --- Objective Function ---
# Maximize a weighted sum of total pilots trained over two years and combat jets in Year 2.

# Total pilots trained: Sum of pilots trained in Year 1 and Year 2.
# Each exclusive training jet trains 'training_capacity_per_jet' pilots per year.
# Each mixed-use jet trains 'training_capacity_per_jet * dual_use_training_efficiency' pilots per year.
obj_pilots_trained = training_capacity_per_jet * (
    T1 + dual_use_training_efficiency * M1 +
    T2 + dual_use_training_efficiency * M2
)

# Total combat jets in Year 2: Exclusive combat jets (C2) plus mixed-use jets (M2),
# as mixed-use aircraft still support combat availability.
obj_combat_jets_y2 = C2 + M2

# Set the objective function
model.setObjective(training_weight * obj_pilots_trained + combat_weight * obj_combat_jets_y2, GRB.MAXIMIZE)

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
elif model.status == GRB.INF_OR_UNBD:
    print("FINAL_OBJ_VALUE: Model is Infeasible or Unbounded")
elif model.status == GRB.INFEASIBLE:
    print("FINAL_OBJ_VALUE: Model is Infeasible")
elif model.status == GRB.UNBOUNDED:
    print("FINAL_OBJ_VALUE: Model is Unbounded")
else:
    print(f"FINAL_OBJ_VALUE: Optimization was stopped with status {model.status}")
