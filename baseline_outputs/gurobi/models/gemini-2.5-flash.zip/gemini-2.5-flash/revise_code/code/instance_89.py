import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- Data Loading ---
# Determine the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))
# Construct the path to the data directory
data_dir = os.path.join(script_dir, '..', 'data')

# Load general parameters
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# --- Extract Parameters ---
# General parameters
min_output_ratio_product_B_to_A = params['min_output_ratio_product_B_to_A']
storage_space_ratio_product_A_to_B = params['storage_space_ratio_product_A_to_B']

# Dictionaries for product-specific parameters
products = ['A', 'B']
profit_per_kg = {
    'A': params['profit_per_kg_product_A'],
    'B': params['profit_per_kg_product_B']
}
hours_per_kg = {
    'A': params['hours_per_kg_product_A'],
    'B': params['hours_per_kg_product_B']
}
initial_inventory = {
    'A': params['initial_inventory_A'],
    'B': params['initial_inventory_B']
}
storage_cost_per_kg = {
    'A': params['storage_cost_per_kg_A'],
    'B': params['storage_cost_per_kg_B']
}
promo_profit_bonus = {
    'A': params['promo_profit_bonus_A'],
    'B': params['promo_profit_bonus_B']
}
max_promotions_product = {
    'A': params['max_promotions_product_A'],
    'B': params['max_promotions_product_B']
}

# Dictionaries for week-specific parameters
weeks = [1, 2]
max_production_hours = {
    1: params['max_production_hours_week_1'],
    2: params['max_production_hours_week_2']
}
max_storage_product_A_equiv = {
    1: params['max_storage_product_A_equiv_week_1'],
    2: params['max_storage_product_A_equiv_week_2']
}

# --- Gurobi Model Setup ---
model = gp.Model("Liquid_Products_Two_Week_Plan")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# --- Decision Variables ---
# Production quantity for each product in each week (kg)
x = model.addVars(products, weeks, name="production", vtype=GRB.CONTINUOUS, lowBound=0)
# Sales quantity for each product in each week (kg)
s = model.addVars(products, weeks, name="sales", vtype=GRB.CONTINUOUS, lowBound=0)
# Inventory at the end of each week for each product (kg)
inv = model.addVars(products, weeks, name="inventory", vtype=GRB.CONTINUOUS, lowBound=0)
# Binary variable: 1 if product is promoted in a week, 0 otherwise
promo = model.addVars(products, weeks, name="promotion", vtype=GRB.BINARY)

# --- Objective Function: Maximize Total Profit ---
# Total profit from sales over two weeks
total_profit = gp.LinExpr()
for w in weeks:
    for p in products:
        total_profit += (profit_per_kg[p] + promo_profit_bonus[p] * promo[p, w]) * s[p, w]

# Subtract inventory holding costs (only for inventory carried from week 1 to week 2)
for p in products:
    total_profit -= storage_cost_per_kg[p] * inv[p, 1]

model.setObjective(total_profit, GRB.MAXIMIZE)

# --- Constraints ---

# 1. Inventory Balance Constraints
for p in products:
    # Week 1: Initial inventory + production = sales + end-of-week inventory
    model.addConstr(initial_inventory[p] + x[p, 1] == s[p, 1] + inv[p, 1], f"Inventory_Balance_{p}_Week1")
    # Week 2: Previous week's inventory + production = sales + end-of-week inventory
    model.addConstr(inv[p, 1] + x[p, 2] == s[p, 2] + inv[p, 2], f"Inventory_Balance_{p}_Week2")

# 2. Production Time Constraints
for w in weeks:
    model.addConstr(hours_per_kg['A'] * x['A', w] + hours_per_kg['B'] * x['B', w] <= max_production_hours[w],
                    f"Production_Hours_Week{w}")

# 3. Market Demand Ratio Constraint (applies to sales)
for w in weeks:
    model.addConstr(s['B', w] >= min_output_ratio_product_B_to_A * s['A', w], f"Market_Demand_Week{w}")

# 4. Storage Capacity Constraints (applies to end-of-week inventory)
for w in weeks:
    # Total storage capacity in "units of space"
    max_storage_units_week_w = max_storage_product_A_equiv[w] * storage_space_ratio_product_A_to_B
    model.addConstr(storage_space_ratio_product_A_to_B * inv['A', w] + inv['B', w] <= max_storage_units_week_w,
                    f"Storage_Capacity_Week{w}")

# 5. Promotion Limit Constraints
for p in products:
    model.addConstr(gp.quicksum(promo[p, w] for w in weeks) <= max_promotions_product[p], f"Promotion_Limit_{p}")

# --- Solve the Model ---
model.optimize()

# --- Print Results ---
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal:.3f}")
# else:
#     print("No optimal solution found.")
#     if model.status == GRB.INFEASIBLE:
#         print("Model is infeasible.")
#     elif model.status == GRB.UNBOUNDED:
#         print("Model is unbounded.")

# Optional: Print detailed solution (commented out as only final objective is requested)
# if model.status == GRB.OPTIMAL:
#     print("\n--- Solution Details ---")
#     for w in weeks:
#         print(f"\nWeek {w}:")
#         for p in products:
#             print(f"  Product {p}:")
#             print(f"    Production: {x[p, w].X:.4f} kg")
#             print(f"    Sales: {s[p, w].X:.4f} kg")
#             print(f"    Inventory (end of week): {inv[p, w].X:.4f} kg")
#             print(f"    Promoted: {'Yes' if promo[p, w].X > 0.5 else 'No'}")
#     print(f"\nTotal Profit: {model.objVal:.3f} GBP")
