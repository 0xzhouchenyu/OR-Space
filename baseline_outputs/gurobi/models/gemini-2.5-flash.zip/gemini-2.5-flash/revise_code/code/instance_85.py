import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine the base directory for data files
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'table_1.csv')
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Extract parameters from the loaded data
    machine_avail = params['machine_time_available']  # hours
    craftsman_regular_avail = params['craftsman_regular_time_available']  # hours
    craftsman_overtime_avail = params['craftsman_overtime_available']  # hours
    machine_cost = params['machine_time_cost']  # GBP per hour
    craftsman_regular_cost = params['craftsman_time_cost']  # GBP per hour (for regular time)
    craftsman_overtime_cost = params['craftsman_overtime_cost']  # GBP per hour
    rev_X = params['revenue_product_X']  # GBP per batch
    rev_Y = params['revenue_product_Y']  # GBP per batch
    min_X = params['min_batches_product_X']  # batches
    product_Y_QA_threshold = params['product_Y_QA_threshold'] # batches
    product_Y_QA_fee = params['product_Y_QA_fee'] # GBP (one-time fee)
    
    # Create a new Gurobi model
    model = gp.Model("Production_Planning_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables
    # X: Number of batches of Product X to produce (continuous, non-negative)
    # Y: Number of batches of Product Y to produce (continuous, non-negative)
    X = model.addVar(name="X", lb=0.0, vtype=GRB.CONTINUOUS)
    Y = model.addVar(name="Y", lb=0.0, vtype=GRB.CONTINUOUS)
    
    # Variables for craftsman time split
    # craftsman_regular_hours_used: Total regular craftsman hours utilized
    # craftsman_overtime_hours_used: Total overtime craftsman hours utilized
    craftsman_regular_hours_used = model.addVar(name="Craftsman_Regular_Hours_Used", lb=0.0, vtype=GRB.CONTINUOUS)
    craftsman_overtime_hours_used = model.addVar(name="Craftsman_Overtime_Hours_Used", lb=0.0, vtype=GRB.CONTINUOUS)

    # Binary variable for Product Y QA fee
    # Y_QA_fee_incurred: 1 if Y production exceeds the threshold, 0 otherwise
    Y_QA_fee_incurred = model.addVar(name="Y_QA_Fee_Incurred", vtype=GRB.BINARY)
    
    # Expressions for resource usage (converted to hours)
    machine_hours_used = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0
    total_craftsman_hours_required = (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0
    
    # Objective function: Maximize total profit (Revenue - Costs)
    # Total Revenue
    total_revenue = rev_X * X + rev_Y * Y
    
    # Total Costs
    machine_time_cost_total = machine_cost * machine_hours_used
    craftsman_regular_time_cost_total = craftsman_regular_cost * craftsman_regular_hours_used
    craftsman_overtime_time_cost_total = craftsman_overtime_cost * craftsman_overtime_hours_used
    
    # QA fee for Product Y (incurred only if Y exceeds threshold)
    qa_fee_cost = product_Y_QA_fee * Y_QA_fee_incurred
    
    model.setObjective(total_revenue - machine_time_cost_total - craftsman_regular_time_cost_total - craftsman_overtime_time_cost_total - qa_fee_cost, GRB.MAXIMIZE)
    
    # Constraints
    # 1. Machine time availability constraint
    model.addConstr(machine_hours_used <= machine_avail, "Machine_Time_Constraint")
    
    # 2. Craftsman regular time availability constraint
    model.addConstr(craftsman_regular_hours_used <= craftsman_regular_avail, "Craftsman_Regular_Time_Constraint")
    
    # 3. Craftsman overtime availability constraint
    model.addConstr(craftsman_overtime_hours_used <= craftsman_overtime_avail, "Craftsman_Overtime_Time_Constraint")
    
    # 4. Total craftsman time required must be met by regular and overtime hours
    model.addConstr(total_craftsman_hours_required == craftsman_regular_hours_used + craftsman_overtime_hours_used, "Total_Craftsman_Time_Balance")
    
    # 5. Minimum production for Product X (contractual obligation)
    model.addConstr(X >= min_X, "Min_Production_X")
    
    # 6. Product Y QA fee logic (fixed charge using Big-M formulation)
    # If Y production exceeds product_Y_QA_threshold, the Y_QA_fee_incurred binary variable must be 1.
    # We need a sufficiently large 'M' value. An upper bound for Y can be estimated from resource limits.
    # Max Y from machine time: (40 hours * 60 min/hour) / 19 min/batch approx 126 batches
    # Max Y from craftsman time: ((25+10) hours * 60 min/hour) / 29 min/batch approx 72 batches
    # So, M = 200 is a safe upper bound for Y.
    M = 200.0 
    model.addConstr(Y - product_Y_QA_threshold <= M * Y_QA_fee_incurred, "Y_QA_Fee_Trigger")
    # The solver will naturally set Y_QA_fee_incurred to 0 if Y <= product_Y_QA_threshold
    # because setting it to 1 would incur a cost without necessity.
    
    # Optimize the model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
    else:
        # Handle cases where an optimal solution is not found
        # For this problem, we expect an optimal solution to exist.
        # In a real-world scenario, more robust error handling would be needed.
        print("Optimization did not find an optimal solution.")
        # print(f"Gurobi Status: {model.status}") # For debugging
        # if model.status == GRB.INFEASIBLE:
        #     model.computeIIS()
        #     model.write("infeasible_model.ilp")

if __name__ == "__main__":
    main()
