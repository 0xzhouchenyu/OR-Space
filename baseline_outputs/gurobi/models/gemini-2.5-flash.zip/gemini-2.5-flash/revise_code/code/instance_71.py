import gurobipy as gp
from gurobipy import GRB
import os
import csv

def solve_revised_problem():
    # Determine the base directory for file access
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, '..', 'data')

    # --- 1. Load Parameters and Data ---
    
    # Load general_parameters.csv
    general_params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row['Parameter_Name']] = row['Value']
    
    n = int(general_params['n'])
    premium_cost_multiplier = float(general_params['premium_cost_multiplier'])
    min_premium_share = float(general_params['min_premium_share'])

    # Load table_1.csv for d_ij and c_pj
    # d_ij: volume from factory i to destination j
    # c_pj: unit transportation cost from location p to destination j
    
    # The CSV structure implies that the row index corresponds to the factory for d_ij
    # and also to the location for c_pj.
    # So, row 'i' in CSV provides d[i][j] and c[i][j] (where i is factory/location index)
    
    d_ij_matrix = [] # d_ij_matrix[factory_idx][destination_idx]
    c_pj_matrix = [] # c_pj_matrix[location_idx][destination_idx]
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    for i in range(n): # Iterate through factories (and implicitly, locations for costs)
        row = rows[i]
        d_row = []
        c_row = []
        for j in range(n): # Iterate through destinations
            d_row.append(float(row[f'Transportation_volume_to_Location_{j+1}']))
            c_row.append(float(row[f'Transportation_cost_to_Location_{j+1}']))
        d_ij_matrix.append(d_row)
        c_pj_matrix.append(c_row)

    # Pre-calculate outbound_volume_i, c_std_ip, c_prem_ip
    outbound_volume = [0.0] * n
    for i in range(n):
        outbound_volume[i] = sum(d_ij_matrix[i][j] for j in range(n))

    c_std_ip = [[0.0 for _ in range(n)] for _ in range(n)]
    c_prem_ip = [[0.0 for _ in range(n)] for _ in range(n)]

    for i in range(n): # factory index
        for p in range(n): # location index
            if outbound_volume[i] > 0:
                sum_d_c = sum(d_ij_matrix[i][j] * c_pj_matrix[p][j] for j in range(n))
                c_std_ip[i][p] = sum_d_c / outbound_volume[i]
            else:
                c_std_ip[i][p] = 0.0 # No cost if no volume
            c_prem_ip[i][p] = premium_cost_multiplier * c_std_ip[i][p]

    # --- 2. Create Gurobi Model ---
    model = gp.Model("FactoryAssignmentWithHandling")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- 3. Define Decision Variables ---
    
    # x[i,p]: 1 if factory i is assigned to location p, 0 otherwise
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")
    
    # y[i,p]: 1 if premium handling is chosen for factory i at location p, 0 otherwise
    y = model.addVars(n, n, vtype=GRB.BINARY, name="y")
    
    # v_std[i,p]: volume handled in standard mode for factory i at location p
    v_std = model.addVars(n, n, vtype=GRB.CONTINUOUS, lb=0.0, name="v_std")
    
    # v_prem[i,p]: volume handled in premium mode for factory i at location p
    v_prem = model.addVars(n, n, vtype=GRB.CONTINUOUS, lb=0.0, name="v_prem")

    # --- 4. Set Objective Function ---
    # Minimize total transportation + handling cost
    objective = gp.quicksum(
        v_std[i,p] * c_std_ip[i][p] + v_prem[i,p] * c_prem_ip[i][p]
        for i in range(n) for p in range(n)
    )
    model.setObjective(objective, GRB.MINIMIZE)

    # --- 5. Add Constraints ---

    # C1: Each factory assigned to exactly one location
    for i in range(n):
        model.addConstr(gp.quicksum(x[i,p] for p in range(n)) == 1, f"Factory_Assignment_{i}")

    # C2: No location hosts more than one factory
    for p in range(n):
        model.addConstr(gp.quicksum(x[i,p] for i in range(n)) <= 1, f"Location_Capacity_{p}")

    # C3a: Total volume split between standard and premium at assigned location
    # v_std[i,p] + v_prem[i,p] == outbound_volume[i] * x[i,p]
    for i in range(n):
        for p in range(n):
            model.addConstr(v_std[i,p] + v_prem[i,p] == outbound_volume[i] * x[i,p], f"Volume_Split_{i}_{p}")
            
    # C3b: Premium volume only if premium mode is chosen (y[i,p]=1)
    # v_prem[i,p] <= outbound_volume[i] * y[i,p]
    for i in range(n):
        for p in range(n):
            model.addConstr(v_prem[i,p] <= outbound_volume[i] * y[i,p], f"Premium_Volume_Limit_{i}_{p}")

    # C4: Premium handling implies minimum volume share
    # v_prem[i,p] >= min_premium_share * outbound_volume[i] * y[i,p]
    for i in range(n):
        for p in range(n):
            model.addConstr(v_prem[i,p] >= min_premium_share * outbound_volume[i] * y[i,p], f"Min_Premium_Share_{i}_{p}")

    # C5: Premium handling only if factory is assigned to location
    # y[i,p] <= x[i,p]
    for i in range(n):
        for p in range(n):
            model.addConstr(y[i,p] <= x[i,p], f"Premium_Only_If_Assigned_{i}_{p}")

    # --- 6. Optimize Model ---
    model.optimize()

    # --- 7. Print Results ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # This case should ideally not be reached for a well-formulated problem
        # with a feasible solution space.
        print(f"Model did not solve to optimality. Status: {model.status}")

if __name__ == "__main__":
    solve_revised_problem()
