import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility function (copied from src/utils.py) ---
def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- Main script ---
if __name__ == "__main__":
    # Determine the path to the data directory.
    # The script is assumed to be in a subdirectory (e.g., 'src/')
    # and executed from the workspace root.
    # The data files are in 'data/'.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')
    params_filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = load_general_parameters(params_filepath)

    # Extract parameters from the loaded data
    shirts_inventory = params['shirts_inventory']
    pants_inventory = params['pants_inventory']
    labor_hours_total = params['labor_hours_total']

    price_a = params['package_a_price']
    price_b = params['package_b_price']
    price_c = params['package_c_price']

    shirts_a = params['package_a_shirts']
    pants_a = params['package_a_pants']
    shirts_b = params['package_b_shirts']
    pants_b = params['package_b_pants']
    shirts_c = params['package_c_shirts']
    pants_c = params['package_c_pants']

    min_campaign_batch_a = params['min_campaign_batch_a']
    min_campaign_batch_b = params['min_campaign_batch_b']
    min_campaign_batch_c = params['min_campaign_batch_c']

    activation_cost_a = params['activation_cost_a']
    activation_cost_b = params['activation_cost_b']
    activation_cost_c = params['activation_cost_c']

    labor_hours_per_A = params['labor_hours_per_A']
    labor_hours_per_B = params['labor_hours_per_B']
    labor_hours_per_C = params['labor_hours_per_C']

    bigM_a = params['bigM_a'] # Upper bound for x_a, used in linking constraints
    bigM_b = params['bigM_b'] # Upper bound for x_b, used in linking constraints
    bigM_c = params['bigM_c'] # Upper bound for x_c, used in linking constraints

    package_b_review_threshold = params['package_b_review_threshold']
    package_b_review_charge = params['package_b_review_charge']
    package_c_review_threshold = params['package_c_review_threshold']
    package_c_review_charge = params['package_c_review_charge']

    # Create a new Gurobi model
    model = gp.Model("Maximize_Revenue_Revised")

    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # x_P: number of packages P sold (integer, non-negative)
    x_a = model.addVar(vtype=GRB.INTEGER, name="x_a", lb=0)
    x_b = model.addVar(vtype=GRB.INTEGER, name="x_b", lb=0)
    x_c = model.addVar(vtype=GRB.INTEGER, name="x_c", lb=0)

    # y_P: binary variable, 1 if package P campaign is activated (i.e., x_P > 0), 0 otherwise
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")

    # z_P: binary variable, 1 if package P review charge is incurred, 0 otherwise
    z_b = model.addVar(vtype=GRB.BINARY, name="z_b")
    z_c = model.addVar(vtype=GRB.BINARY, name="z_c")

    # --- Objective Function ---
    # Maximize (Total Revenue from sales - Total Activation Costs - Total Review Charges)
    objective = (price_a * x_a + price_b * x_b + price_c * x_c
                 - activation_cost_a * y_a - activation_cost_b * y_b - activation_cost_c * y_c
                 - package_b_review_charge * z_b - package_c_review_charge * z_c)
    model.setObjective(objective, GRB.MAXIMIZE)

    # --- Constraints ---

    # 1. Inventory constraints for shirts and pants
    model.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inventory, "Shirts_Inventory_Constraint")
    model.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inventory, "Pants_Inventory_Constraint")

    # 2. Total labor hours constraint
    model.addConstr(labor_hours_per_A * x_a + labor_hours_per_B * x_b + labor_hours_per_C * x_c <= labor_hours_total, "Labor_Hours_Constraint")

    # 3. Campaign activation linking constraints (x_P and y_P)
    # These constraints ensure:
    #   - If y_P = 0, then x_P must be 0 (no sales if campaign not activated).
    #   - If y_P = 1, then x_P must be at least min_campaign_batch_P (minimum sales if campaign activated).
    #   - x_P cannot exceed its Big M upper bound (implicitly handled by inventory, but explicit for linking).
    model.addConstr(x_a <= bigM_a * y_a, "Link_xA_yA_Upper")
    model.addConstr(x_a >= min_campaign_batch_a * y_a, "Link_xA_yA_Lower")

    model.addConstr(x_b <= bigM_b * y_b, "Link_xB_yB_Upper")
    model.addConstr(x_b >= min_campaign_batch_b * y_b, "Link_xB_yB_Lower")

    model.addConstr(x_c <= bigM_c * y_c, "Link_xC_yC_Upper")
    model.addConstr(x_c >= min_campaign_batch_c * y_c, "Link_xC_yC_Lower")

    # 4. Package B review charge linking constraints (x_b and z_b)
    # These constraints ensure:
    #   - If x_b > package_b_review_threshold (i.e., x_b >= threshold + 1 for integer x_b), then z_b must be 1.
    #   - If x_b <= package_b_review_threshold, then z_b can be 0.
    # We use bigM_b as a sufficiently large upper bound for x_b in these linking constraints.
    model.addConstr(x_b <= package_b_review_threshold + bigM_b * z_b, "Link_xB_zB_Upper")
    model.addConstr(x_b >= (package_b_review_threshold + 1) - bigM_b * (1 - z_b), "Link_xB_zB_Lower")

    # 5. Package C deluxe-display review charge linking constraints (x_c and z_c)
    # Similar logic to Package B review charge.
    # We use bigM_c as a sufficiently large upper bound for x_c.
    model.addConstr(x_c <= package_c_review_threshold + bigM_c * z_c, "Link_xC_zC_Upper")
    model.addConstr(x_c >= (package_c_review_threshold + 1) - bigM_c * (1 - z_c), "Link_xC_zC_Lower")

    # Optimize the model
    model.optimize()

    # Output the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    elif model.status == GRB.INFEASIBLE:
        print(f"FINAL_OBJ_VALUE: {float('-inf')}") # Indicate infeasibility
    elif model.status == GRB.UNBOUNDED:
        print(f"FINAL_OBJ_VALUE: {float('inf')}") # Indicate unboundedness
    else:
        # Handle other possible statuses (e.g., NO_SOLUTION_FOUND, INF_OR_UNBD)
        print(f"Optimization ended with status {model.status}. No optimal solution found.")
        print(f"FINAL_OBJ_VALUE: N/A")
