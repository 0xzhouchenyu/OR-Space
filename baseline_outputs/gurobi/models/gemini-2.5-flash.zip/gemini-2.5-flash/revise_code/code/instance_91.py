import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Start of utils.py content (copied for self-containment) ---
def load_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            
            # Handle ratio values like "5:2"
            if ':' in value_str:
                params[name + '_raw'] = value_str
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params
# --- End of utils.py content ---

def main():
    # Determine the base directory for data access.
    # The script is expected to be executed from the revised workspace root directory.
    # So, os.path.dirname(os.path.abspath(__file__)) will be the root directory.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load parameters from the CSV file
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Extract relevant parameters
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_hours = params['machine_working_time']
    machine_working_time_minutes = machine_working_time_hours * 60  # Convert hours to minutes
    
    # Production ratio (e.g., (5, 2) for 5:2)
    ratio_A, ratio_B = params['production_ratio_A_to_B']
    
    # New parameters for the Product A senior-assembler tier
    product_A_senior_batch_threshold = params['product_A_senior_batch_threshold']
    product_A_senior_batch_fee = params['product_A_senior_batch_fee']
    
    # Initialize Gurobi model
    model = gp.Model("Product_Mix_Revised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output
    
    # Decision variables
    # A: Quantity of Product A (continuous, non-negative)
    A = model.addVar(vtype=GRB.CONTINUOUS, name="Product_A", lb=0)
    # B: Quantity of Product B (continuous, non-negative)
    B = model.addVar(vtype=GRB.CONTINUOUS, name="Product_B", lb=0)
    
    # Binary variable for the Product A senior batch fee
    # Y_A = 1 if Product A production exceeds the threshold, 0 otherwise
    Y_A = model.addVar(vtype=GRB.BINARY, name="Product_A_Senior_Batch_Flag")
    
    # Objective function: Maximize total profit, subtracting the fixed staffing burden if applicable
    model.setObjective(profit_A * A + profit_B * B - product_A_senior_batch_fee * Y_A, GRB.MAXIMIZE)
    
    # Constraint 1: Machine working time limit
    # Total assembly time for A and B must not exceed available machine working time
    model.addConstr(assembly_time_A * A + assembly_time_B * B <= machine_working_time_minutes, "Machine_Time")
    
    # Constraint 2: Production ratio
    # "at least 2 units of product B for every 5 units of product A produced"
    # This translates to B / A >= 2 / 5, or 5B >= 2A, which is 2A - 5B <= 0
    model.addConstr(ratio_B * A - ratio_A * B <= 0, "Production_Ratio")
    
    # Constraint 3: Link Product A quantity to the senior batch fee (Big-M formulation)
    # If A > product_A_senior_batch_threshold, then Y_A must be 1.
    # This is modeled by ensuring that if Y_A is 0, A cannot exceed the threshold.
    # M is a sufficiently large number, an upper bound for A.
    # Max A can be machine_working_time_minutes / assembly_time_A = 1800 / 12 = 150 units.
    M = 150 
    model.addConstr(A <= product_A_senior_batch_threshold + M * Y_A, "Product_A_Senior_Batch_Link")
    
    # Optimize the model
    model.optimize()
    
    # Print the final objective value if an optimal solution is found
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")
    else:
        # Handle other possible statuses (e.g., infeasible, unbounded)
        # For this problem, we expect an optimal solution.
        print(f"Optimization did not find an optimal solution. Status: {model.status}")

if __name__ == "__main__":
    main()
