import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Utility function from src/utils.py ---
def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            # Try to convert to numeric
            try:
                value = int(value_str)
            except ValueError:
                try:
                    value = float(value_str)
                except ValueError:
                    value = value_str
            params[name] = value
    return params

# --- Main script ---

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
cost_A = params['cost_per_chair_A']
cost_B = params['cost_per_chair_B']
cost_C = params['cost_per_chair_C']
chairs_per_order_A = params['chairs_per_order_A']
chairs_per_order_B = params['chairs_per_order_B']
chairs_per_order_C = params['chairs_per_order_C']
min_total = params['min_total_chairs']
max_total = params['max_total_chairs']
min_chairs_B_if_A = params['min_chairs_B_if_A']
dependency_B_C = params['dependency_B_C'] # 1 if dependency exists, 0 otherwise

# New parameters from revision
fixed_fee_A_regular = params['fixed_fee_A_regular']
fixed_fee_A_express = params['fixed_fee_A_express']
fixed_fee_B_regular = params['fixed_fee_B_regular']
fixed_fee_B_express = params['fixed_fee_B_express']
fixed_fee_C_regular = params['fixed_fee_C_regular']
fixed_fee_C_express = params['fixed_fee_C_express']
weekly_order_budget = params['weekly_order_budget']

# Create a new model
model = gp.Model("FurnitureOrder")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# Decision variables: number of orders from each manufacturer (integer, >= 0)
# We need upper bounds. Max total chairs is 500.
max_orders_A = max_total // int(chairs_per_order_A) + 1
max_orders_B = max_total // int(chairs_per_order_B) + 1
max_orders_C = max_total // int(chairs_per_order_C) + 1

x_A = model.addVar(lb=0, ub=max_orders_A, vtype=GRB.INTEGER, name="orders_A")
x_B = model.addVar(lb=0, ub=max_orders_B, vtype=GRB.INTEGER, name="orders_B")
x_C = model.addVar(lb=0, ub=max_orders_C, vtype=GRB.INTEGER, name="orders_C")

# Binary variables to indicate if we order from each manufacturer
y_A = model.addVar(vtype=GRB.BINARY, name="y_A")
y_B = model.addVar(vtype=GRB.BINARY, name="y_B")
y_C = model.addVar(vtype=GRB.BINARY, name="y_C")

# Binary variables for channel selection (regular/express) for each manufacturer
z_A_reg = model.addVar(vtype=GRB.BINARY, name="z_A_regular")
z_A_exp = model.addVar(vtype=GRB.BINARY, name="z_A_express")
z_B_reg = model.addVar(vtype=GRB.BINARY, name="z_B_regular")
z_B_exp = model.addVar(vtype=GRB.BINARY, name="z_B_express")
z_C_reg = model.addVar(vtype=GRB.BINARY, name="z_C_regular")
z_C_exp = model.addVar(vtype=GRB.BINARY, name="z_C_express")

# Total chairs from each manufacturer (expressions)
chairs_A = chairs_per_order_A * x_A
chairs_B = chairs_per_order_B * x_B
chairs_C = chairs_per_order_C * x_C

# Objective: minimize total cost
# Total cost = (variable costs) + (fixed fees for chosen channels)
total_variable_cost = cost_A * chairs_A + cost_B * chairs_B + cost_C * chairs_C
total_fixed_fees = (fixed_fee_A_regular * z_A_reg + fixed_fee_A_express * z_A_exp +
                    fixed_fee_B_regular * z_B_reg + fixed_fee_B_express * z_B_exp +
                    fixed_fee_C_regular * z_C_reg + fixed_fee_C_express * z_C_exp)

model.setObjective(total_variable_cost + total_fixed_fees, GRB.MINIMIZE)

# Constraints

# 1. Total chairs between min and max
model.addConstr(chairs_A + chairs_B + chairs_C >= min_total, "MinChairs")
model.addConstr(chairs_A + chairs_B + chairs_C <= max_total, "MaxChairs")

# 2. Big M for linking y variables to x variables (manufacturer usage)
M = max_total + 1 # A sufficiently large number
model.addConstr(x_A <= M * y_A, "LinkA_x_y_upper")
model.addConstr(x_A >= y_A, "LinkA_x_y_lower") # if y_A=1, then x_A >= 1; if x_A=0, then y_A=0
model.addConstr(x_B <= M * y_B, "LinkB_x_y_upper")
model.addConstr(x_B >= y_B, "LinkB_x_y_lower")
model.addConstr(x_C <= M * y_C, "LinkC_x_y_upper")
model.addConstr(x_C >= y_C, "LinkC_x_y_lower")

# 3. Dependency: if ordering from A, must order at least min_chairs_B_if_A chairs from B
model.addConstr(chairs_B >= min_chairs_B_if_A * y_A, "DepAB")

# 4. Dependency: if ordering from B, must also order from C (only if dependency_B_C is 1)
if dependency_B_C == 1:
    model.addConstr(y_B <= y_C, "DepBC")

# 5. New Constraints for Channel Selection and Budget

# For each manufacturer used, choose either regular or express, never both
# If manufacturer is used (y=1), then exactly one channel must be chosen (z_reg + z_exp = 1)
# If manufacturer is not used (y=0), then no channel can be chosen (z_reg + z_exp = 0)
model.addConstr(z_A_reg + z_A_exp == y_A, "ChannelChoiceA")
model.addConstr(z_B_reg + z_B_exp == y_B, "ChannelChoiceB")
model.addConstr(z_C_reg + z_C_exp == y_C, "ChannelChoiceC")

# Weekly order budget: maximum number of active manufacturer-mode combinations
model.addConstr(z_A_reg + z_A_exp + z_B_reg + z_B_exp + z_C_reg + z_C_exp <= weekly_order_budget, "WeeklyBudget")

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
elif model.status == GRB.INFEASIBLE:
    print("FINAL_OBJ_VALUE: Infeasible")
elif model.status == GRB.UNBOUNDED:
    print("FINAL_OBJ_VALUE: Unbounded")
else:
    print(f"FINAL_OBJ_VALUE: Optimization stopped with status {model.status}")
