import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
# Determine the base directory for data files relative to the script's location
base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

# Load demand forecast from table_1.csv
demand = {}
with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for i, row in enumerate(reader):
        demand[i] = float(row['Demand_Forecast'])

T = len(demand)  # Number of months in the planning horizon (January to June = 6 months)

# Load general parameters from general_parameters.csv
params = {}
with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Assign parameters to variables for easier access
W0 = int(params['initial_workforce'])
I0 = params['initial_inventory']
sp = params['sales_price']
rmc = params['raw_material_cost']
oc = params['outsourcing_cost']
hc = params['inventory_holding_cost']
bc = params['backorder_cost']
lr = params['labor_requirement']
rh = params['regular_labor_hours']
rw = params['regular_wage']
otl = params['overtime_hours_limit']
ow = params['overtime_wage']
hire_cost = params['hiring_cost']
fire_cost = params['firing_cost']
term_inv = params['terminal_inventory']
term_bo = params['terminal_backorders']
contract_min_units = params['contract_min_units']
contract_bigM = params['contract_bigM']

# Initialize the Gurobi model
model = gp.Model("FoldableTableProduction")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# Decision variables
# Workforce and HR
W = model.addVars(T, name="Workforce", vtype=GRB.CONTINUOUS, lb=0)  # Workforce at the end of month t
H = model.addVars(T, name="Hired", vtype=GRB.CONTINUOUS, lb=0)      # Workers hired in month t
F = model.addVars(T, name="Fired", vtype=GRB.CONTINUOUS, lb=0)      # Workers fired in month t

# Production and Sourcing
P = model.addVars(T, name="TotalProduction", vtype=GRB.CONTINUOUS, lb=0) # Total in-house production in month t
P_regular = model.addVars(T, name="RegularProduction", vtype=GRB.CONTINUOUS, lb=0) # In-house production from regular hours
P_overtime = model.addVars(T, name="OvertimeProduction", vtype=GRB.CONTINUOUS, lb=0) # In-house production from overtime hours
OT_total = model.addVars(T, name="TotalOvertimeHours", vtype=GRB.CONTINUOUS, lb=0) # Total overtime hours used in month t
O = model.addVars(T, name="Outsourced", vtype=GRB.CONTINUOUS, lb=0) # Units outsourced in month t

# Inventory and Backorders
Inv = model.addVars(T, name="Inventory", vtype=GRB.CONTINUOUS, lb=0) # Inventory at the end of month t
B = model.addVars(T, name="Backorders", vtype=GRB.CONTINUOUS, lb=0) # Backorders at the end of month t

# Contract-specific variables for months April, May, June (indices 3, 4, 5)
contract_months = [3, 4, 5] # 0-indexed: January=0, February=1, March=2, April=3, May=4, June=5
P_contract_qual = model.addVars(contract_months, name="ContractQualifiedProduction", vtype=GRB.CONTINUOUS, lb=0)
Y_contract = model.addVars(contract_months, name="BinaryContractMin", vtype=GRB.BINARY) # Binary indicator for min() formulation

# Constraints
for t in range(T):
    # 1. Workforce balance
    if t == 0:
        model.addConstr(W[t] == W0 + H[t] - F[t], name=f"WorkforceBalance_{t}")
    else:
        model.addConstr(W[t] == W[t-1] + H[t] - F[t], name=f"WorkforceBalance_{t}")
    
    # 2. Labor hour allocation and production definition
    # Regular production capacity
    model.addConstr(P_regular[t] * lr <= W[t] * rh, name=f"RegularProductionCapacity_{t}")
    # Overtime production capacity
    model.addConstr(P_overtime[t] * lr <= OT_total[t], name=f"OvertimeProductionCapacity_{t}")
    # Total in-house production is sum of regular and overtime production
    model.addConstr(P[t] == P_regular[t] + P_overtime[t], name=f"TotalProductionDefinition_{t}")
    
    # 3. Overtime limit per worker (total overtime hours for the workforce)
    model.addConstr(OT_total[t] <= W[t] * otl, name=f"OvertimeLimit_{t}")
    
    # 4. Inventory balance equation
    prev_inv = I0 if t == 0 else Inv[t-1]
    prev_b = 0 if t == 0 else B[t-1]
    # Net inventory (Inv - B) at end of month t = Net inventory at start + Production + Outsourcing - Demand
    model.addConstr(Inv[t] - B[t] == prev_inv - prev_b + P[t] + O[t] - demand[t], name=f"InventoryBalance_{t}")

    # 5. Contract-specific constraints for April, May, June (indices 3, 4, 5)
    if t in contract_months:
        # Effective demand for contract calculation: current month's demand + starting backlog
        # For t=3,4,5, B[t-1] is always defined.
        D_effective_contract_t = demand[t] + B[t-1]

        # 5a. Explicit floor: at least contract_min_units must be contract-qualified
        model.addConstr(P_contract_qual[t] >= contract_min_units, name=f"ContractMinUnits_{t}")

        # 5b. Big-M formulation to define P_contract_qual[t] = min(P_regular[t], D_effective_contract_t)
        # P_contract_qual[t] cannot exceed regular-time production
        model.addConstr(P_contract_qual[t] <= P_regular[t], name=f"ContractQual_Upper_PRegular_{t}")
        # P_contract_qual[t] cannot exceed the month's effective demand (demand + starting backlog)
        model.addConstr(P_contract_qual[t] <= D_effective_contract_t, name=f"ContractQual_Upper_DEffective_{t}")
        
        # If Y_contract[t] = 1, then P_regular[t] is the minimum
        # P_contract_qual[t] >= P_regular[t] - M * (1 - Y_contract[t])
        model.addConstr(P_contract_qual[t] >= P_regular[t] - contract_bigM * (1 - Y_contract[t]), name=f"ContractQual_Lower1_{t}")
        # If Y_contract[t] = 0, then D_effective_contract_t is the minimum
        # P_contract_qual[t] >= D_effective_contract_t - M * Y_contract[t]
        model.addConstr(P_contract_qual[t] >= D_effective_contract_t - contract_bigM * Y_contract[t], name=f"ContractQual_Lower2_{t}")

# 6. Terminal conditions (end of June, T-1)
model.addConstr(Inv[T-1] >= term_inv, name="TerminalInventory")
model.addConstr(B[T-1] == term_bo, name="TerminalBackorders") # term_bo is 0

# Objective: maximize net profit
# Revenue: All demand is eventually met (due to terminal_backorders = 0), so revenue is sales_price * total_demand
total_demand_sum = gp.quicksum(demand[t] for t in range(T))
revenue = sp * total_demand_sum

# Costs
material_cost = gp.quicksum(rmc * P[t] for t in range(T))
outsource_cost = gp.quicksum(oc * O[t] for t in range(T))
holding_cost = gp.quicksum(hc * Inv[t] for t in range(T))
backorder_cost_total = gp.quicksum(bc * B[t] for t in range(T))
regular_labor_cost = gp.quicksum(rw * rh * W[t] for t in range(T))
overtime_cost = gp.quicksum(ow * OT_total[t] for t in range(T))
hiring_cost_total = gp.quicksum(hire_cost * H[t] for t in range(T))
firing_cost_total = gp.quicksum(fire_cost * F[t] for t in range(T))

total_cost = (material_cost + outsource_cost + holding_cost + backorder_cost_total +
              regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total)

model.setObjective(revenue - total_cost, GRB.MAXIMIZE)

# Solve the model
model.optimize()

# Output the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"Optimization did not find an optimal solution. Status: {model.status}")
