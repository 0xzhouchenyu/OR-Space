import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
# The script will be executed from the revised workspace root directory.
# Data files are in subdirectories like "data/filename.csv".
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

# Load general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

m = int(params['m'])  # number of production points
n = int(params['n'])  # number of demand points
p = int(params['p'])  # number of intermediate marshaling stations

a = {i: params[f'a_{i}'] for i in range(1, m+1)}  # production capacities
b = {j: params[f'b_{j}'] for j in range(1, n+1)}  # demands
f_cost = {k: params[f'f_{k}'] for k in range(1, p+1)}  # fixed costs for marshaling stations
q = {k: params[f'q_{k}'] for k in range(1, p+1)}  # maximum total transshipment capacity at marshaling station k
qexp = {k: params[f'qexp_{k}'] for k in range(1, p+1)} # maximum express transshipment capacity at marshaling station k
alpha = {j: params[f'alpha_{j}'] for j in range(1, n+1)} # minimum express fraction for demand point j
eps = params['eps'] # minimum strictly positive express flow to activate source indicator
M_param = params['M'] # Big-M upper bound on express flow yE_kj per station-demand pair

# Load transportation costs from production to marshaling stations
cR_ik = {} # Regular service cost from production i to marshaling k
cE_ik = {} # Express service cost from production i to marshaling k
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row['i'])
        k = int(row['k'])
        cR_ik[(i, k)] = float(row['cR_ik'])
        cE_ik[(i, k)] = float(row['cE_ik'])

# Load transportation costs from marshaling stations to demand points
cR_kj = {} # Regular service cost from marshaling k to demand j
cE_kj = {} # Express service cost from marshaling k to demand j
with open(os.path.join(data_dir, 'table_2.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row['k'])
        j = int(row['j'])
        cR_kj[(k, j)] = float(row["cR_kj"])
        cE_kj[(k, j)] = float(row["cE_kj"])

# Create the optimization model
model = gp.Model("Transportation_Problem_Revised")
model.setParam('OutputFlag', 0) # Suppress Gurobi output

# Decision variables
# xR_ik: amount shipped from production point i to marshaling station k via regular service
xR = model.addVars([(i, k) for i in range(1, m+1) for k in range(1, p+1)], vtype=GRB.CONTINUOUS, name="xR")
# xE_ik: amount shipped from production point i to marshaling station k via express service
xE = model.addVars([(i, k) for i in range(1, m+1) for k in range(1, p+1)], vtype=GRB.CONTINUOUS, name="xE")

# yR_kj: amount shipped from marshaling station k to demand point j via regular service
yR = model.addVars([(k, j) for k in range(1, p+1) for j in range(1, n+1)], vtype=GRB.CONTINUOUS, name="yR")
# yE_kj: amount shipped from marshaling station k to demand point j via express service
yE = model.addVars([(k, j) for k in range(1, p+1) for j in range(1, n+1)], vtype=GRB.CONTINUOUS, name="yE")

# z_k: binary variable indicating whether marshaling station k is used
z = model.addVars([k for k in range(1, p+1)], vtype=GRB.BINARY, name="z")

# w_kj: binary variable, 1 if express service is used from marshaling station k to demand point j
w = model.addVars([(k, j) for k in range(1, p+1) for j in range(1, n+1)], vtype=GRB.BINARY, name="w")

# Auxiliary variable for counting open stations
Z_count = model.addVar(vtype=GRB.INTEGER, name="Z_count")
model.addConstr(Z_count == gp.quicksum(z[k] for k in range(1, p+1)), "Z_count_def")

# Auxiliary binary variable for "more than one open station" condition
is_multiple_open = model.addVar(vtype=GRB.BINARY, name="is_multiple_open")
# Link is_multiple_open to Z_count >= 2
# If is_multiple_open is 1, Z_count must be at least 2
model.addConstr(Z_count >= 2 * is_multiple_open, "Link_is_multiple_open_1")
# If is_multiple_open is 0, Z_count must be at most 1 (p is max Z_count)
model.addConstr(Z_count <= 1 + p * (1 - is_multiple_open), "Link_is_multiple_open_2")

# Objective: minimize total transportation cost + fixed costs
objective = gp.quicksum(cR_ik[(i, k)] * xR[(i, k)] + cE_ik[(i, k)] * xE[(i, k)]
                        for i in range(1, m+1) for k in range(1, p+1)) + \
            gp.quicksum(cR_kj[(k, j)] * yR[(k, j)] + cE_kj[(k, j)] * yE[(k, j)]
                        for k in range(1, p+1) for j in range(1, n+1)) + \
            gp.quicksum(f_cost[k] * z[k] for k in range(1, p+1))

model.setObjective(objective, GRB.MINIMIZE)

# Constraints

# 1. Supply constraints: total shipped from production point i <= a_i
for i in range(1, m+1):
    model.addConstr(gp.quicksum(xR[(i, k)] + xE[(i, k)] for k in range(1, p+1)) <= a[i], f"Supply_{i}")

# 2. Demand constraints: total received at demand point j >= b_j
for j in range(1, n+1):
    model.addConstr(gp.quicksum(yR[(k, j)] + yE[(k, j)] for k in range(1, p+1)) >= b[j], f"Demand_{j}")

# 3. Flow conservation at marshaling stations
for k in range(1, p+1):
    model.addConstr(gp.quicksum(xR[(i, k)] + xE[(i, k)] for i in range(1, m+1)) ==
                    gp.quicksum(yR[(k, j)] + yE[(k, j)] for j in range(1, n+1)), f"FlowBalance_{k}")

# 4. Total Capacity constraints at marshaling stations (linked with z_k)
for k in range(1, p+1):
    model.addConstr(gp.quicksum(xR[(i, k)] + xE[(i, k)] for i in range(1, m+1)) <= q[k] * z[k], f"TotalCapacity_{k}")

# 5. Express Capacity constraints at marshaling stations (linked with z_k)
for k in range(1, p+1):
    model.addConstr(gp.quicksum(yE[(k, j)] for j in range(1, n+1)) <= qexp[k] * z[k], f"ExpressCapacity_{k}")

# 6. Link w_kj to yE_kj (Minimum strictly positive express flow to activate source indicator)
for k in range(1, p+1):
    for j in range(1, n+1):
        # If w_kj is 0, yE_kj must be 0. If w_kj is 1, yE_kj must be at least eps.
        model.addConstr(yE[(k, j)] <= M_param * w[(k, j)], f"Link_w_kj_upper_{k}_{j}")
        model.addConstr(yE[(k, j)] >= eps * w[(k, j)], f"Link_w_kj_lower_{k}_{j}")

# 7. Diversified express share constraint (conditional on is_multiple_open)
# "Demand points with more than one open station need a diversified express share of at least alpha_j across two station links"
for j in range(1, n+1):
    total_flow_to_j = gp.quicksum(yR[(k, j)] + yE[(k, j)] for k in range(1, p+1))
    total_express_flow_to_j = gp.quicksum(yE[(k, j)] for k in range(1, p+1))

    # Condition 1: Express share fraction
    # total_express_flow_to_j >= alpha[j] * total_flow_to_j, if is_multiple_open == 1
    # This constraint is relaxed by M_param * (1 - is_multiple_open) if is_multiple_open is 0.
    model.addConstr(total_express_flow_to_j >= alpha[j] * total_flow_to_j - M_param * (1 - is_multiple_open),
                    f"Diversified_Express_Share_Fraction_{j}")

    # Condition 2: "across two station links" implies at least two w_kj must be active for demand j
    # gp.quicksum(w[(k, j)] for k in range(1, p+1)) >= 2, if is_multiple_open == 1
    # This constraint is relaxed by p * (1 - is_multiple_open) if is_multiple_open is 0.
    model.addConstr(gp.quicksum(w[(k, j)] for k in range(1, p+1)) >= 2 - p * (1 - is_multiple_open),
                    f"Diversified_Express_Links_{j}") # Use p as Big-M for number of links

# Optimize the model
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("Optimization was not successful. Status:", model.status)
