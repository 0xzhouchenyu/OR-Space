import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, '..', 'data')
    
    # Load candidate data
    candidates_data = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates_data.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            })
    
    candidate_names = [c['name'] for c in candidates_data]
    candidate_map = {c['name']: c for c in candidates_data} # For easy lookup by name

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Convert relevant parameters to int as they represent counts or discrete values
    params['max_employees'] = int(params['max_employees'])
    params['max_one_candidate_g_j'] = int(params['max_one_candidate_g_j'])
    params['min_leads'] = int(params['min_leads'])
    params['max_pairs'] = int(params['max_pairs'])

    # Create a new Gurobi model
    model = gp.Model("HiringOptimizationRevised")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # --- Decision Variables ---
    # x[c_name]: Binary, 1 if candidate c_name is hired, 0 otherwise
    x = model.addVars(candidate_names, vtype=GRB.BINARY, name="x")

    # is_lead[c_name]: Binary, 1 if candidate c_name is hired AND assigned as Lead, 0 otherwise
    is_lead = model.addVars(candidate_names, vtype=GRB.BINARY, name="is_lead")

    # is_engineer[c_name]: Binary, 1 if candidate c_name is hired AND assigned as Engineer, 0 otherwise
    is_engineer = model.addVars(candidate_names, vtype=GRB.BINARY, name="is_engineer")

    # num_mentorship_pairs: Integer, number of active Lead-Engineer mentorship pairs
    num_mentorship_pairs = model.addVar(vtype=GRB.INTEGER, name="num_mentorship_pairs")

    # --- Objective Function ---
    # Minimize total net cost: (base salaries) + (lead premium for Leads) - (mentorship bonus for pairs)
    total_base_salary = gp.quicksum(candidate_map[c_name]['salary'] * x[c_name] for c_name in candidate_names)
    total_lead_premium_cost = gp.quicksum(params['lead_premium'] * is_lead[c_name] for c_name in candidate_names)
    total_mentorship_bonus_credit = params['mentor_bonus'] * num_mentorship_pairs

    model.setObjective(total_base_salary + total_lead_premium_cost - total_mentorship_bonus_credit, GRB.MINIMIZE)

    # --- Constraints ---

    # 1. Hiring and Role Assignment Linkage:
    # If a candidate is hired (x[c_name] == 1), they must be assigned exactly one role (Lead or Engineer).
    # If not hired (x[c_name] == 0), they cannot be assigned any role.
    for c_name in candidate_names:
        model.addConstr(is_lead[c_name] + is_engineer[c_name] == x[c_name], f"RoleAssignment_{c_name}")

    # 2. Budget Constraint (Net Hiring Cost)
    model.addConstr(total_base_salary + total_lead_premium_cost - total_mentorship_bonus_credit <= params['company_budget'], "Budget")

    # 3. Max Employees Constraint
    model.addConstr(gp.quicksum(x[c_name] for c_name in candidate_names) <= params['max_employees'], "MaxEmployees")

    # 4. Min Skill Level Constraint
    model.addConstr(gp.quicksum(candidate_map[c_name]['skill'] * x[c_name] for c_name in candidate_names) >= params['min_skill_level'], "MinSkill")

    # 5. Min Project Management Experience Constraint
    model.addConstr(gp.quicksum(candidate_map[c_name]['pm_exp'] * x[c_name] for c_name in candidate_names) >= params['min_project_experience'], "MinPMExp")

    # 6. At most one of G and J can be hired
    model.addConstr(x['G'] + x['J'] <= params['max_one_candidate_g_j'], "MaxOneGJ")

    # 7. Minimum Leads Constraint
    total_leads = gp.quicksum(is_lead[c_name] for c_name in candidate_names)
    model.addConstr(total_leads >= params['min_leads'], "MinLeads")

    # 8. Mentorship Pairs Constraints
    total_engineers = gp.quicksum(is_engineer[c_name] for c_name in candidate_names)
    
    # The number of mentorship pairs cannot exceed the total number of Leads
    model.addConstr(num_mentorship_pairs <= total_leads, "MaxPairsByLeads")
    
    # The number of mentorship pairs cannot exceed the total number of Engineers
    model.addConstr(num_mentorship_pairs <= total_engineers, "MaxPairsByEngineers")
    
    # The number of mentorship pairs cannot exceed the company's maximum supported pairs
    model.addConstr(num_mentorship_pairs <= params['max_pairs'], "MaxPairsCompanyCap")

    # Solve the model
    model.optimize()

    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible.")
    elif model.status == GRB.UNBOUNDED:
        print("Model is unbounded.")
    else:
        print(f"Optimization ended with status {model.status}")

if __name__ == "__main__":
    main()
