import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

# Extract parameters from general_parameters.csv
produce = params['produce_to_transport']
horse_poll = params['horse_pollution_per_trip']
bike_poll = params['bicycle_pollution_per_trip']
cart_poll = params['handcart_pollution_per_trip']
max_poll = params['max_total_pollution']
min_horse = params['min_horse_trips']
horse_cap = params['horse_capacity_per_trip']
bike_cap = params['bicycle_capacity_per_trip']
cart_cap = params['handcart_capacity_per_trip']
min_produce = params['min_total_produce']

# New parameters from the revision
horse_cost_per_trip = params['horse_cost_per_trip']
bicycle_cost_per_trip = params['bicycle_cost_per_trip']
handcart_cost_per_trip = params['handcart_cost_per_trip']
horse_fixed_cost = params['horse_fixed_cost']
bicycle_fixed_cost = params['bicycle_fixed_cost']
handcart_fixed_cost = params['handcart_fixed_cost']
pollution_penalty_per_unit = params['pollution_penalty_per_unit']
horse_pollution_permit_threshold = params['horse_pollution_permit_threshold']
horse_pollution_permit_fee = params['horse_pollution_permit_fee']

# Model
m = gp.Model("FarmTransport")
m.setParam('OutputFlag', 0)  # Suppress Gurobi output

# Big-M constant: A sufficiently large number for Big-M constraints
M = 10000

# Decision variables
# Number of trips for each transportation method (non-negative integers)
x_horse = m.addVar(vtype=GRB.INTEGER, name="horse_trips", lb=0)
x_bike = m.addVar(vtype=GRB.INTEGER, name="bike_trips", lb=0)
x_cart = m.addVar(vtype=GRB.INTEGER, name="cart_trips", lb=0)

# Binary variable to choose between bicycle (y=1) and handcart (y=0)
y = m.addVar(vtype=GRB.BINARY, name="choose_bike")

# Binary variables to indicate if a transportation method is used (for fixed costs)
z_horse = m.addVar(vtype=GRB.BINARY, name="use_horse")
z_bike = m.addVar(vtype=GRB.BINARY, name="use_bike")
z_cart = m.addVar(vtype=GRB.BINARY, name="use_cart")

# Binary variable for the pollution permit fee (1 if fee is paid, 0 otherwise)
b_permit_fee = m.addVar(vtype=GRB.BINARY, name="pay_permit_fee")

# Intermediate expressions for clarity and objective function
total_pollution = horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart
total_produce_transported = horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart

# Objective: Minimize total cost
# Total Cost = Variable Trip Costs + Fixed Setup Costs + Pollution Penalty + Permit Fee
m.setObjective(
    (horse_cost_per_trip * x_horse + bicycle_cost_per_trip * x_bike + handcart_cost_per_trip * x_cart) +
    (horse_fixed_cost * z_horse + bicycle_fixed_cost * z_bike + handcart_fixed_cost * z_cart) +
    (pollution_penalty_per_unit * total_pollution) +
    (horse_pollution_permit_fee * b_permit_fee),
    GRB.MINIMIZE
)

# Constraints

# 1. Must transport at least the minimum required produce
m.addConstr(total_produce_transported >= min_produce, "C_min_produce")

# 2. Total pollution must not exceed the maximum allowable pollution
m.addConstr(total_pollution <= max_poll, "C_max_pollution")

# 3. Minimum number of trips that must be made using the horse
m.addConstr(x_horse >= min_horse, "C_min_horse_trips")

# 4. Either bicycle or handcart, but not both
# If y=1, bicycle trips are allowed (x_bike <= M), handcart trips must be 0 (x_cart <= 0)
# If y=0, handcart trips are allowed (x_cart <= M), bicycle trips must be 0 (x_bike <= 0)
m.addConstr(x_bike <= M * y, "C_bike_choice")
m.addConstr(x_cart <= M * (1 - y), "C_cart_choice")

# 5. Link trip variables to fixed cost binary variables (z_horse, z_bike, z_cart)
# If x_var > 0, then z_var must be 1. If x_var = 0, z_var can be 0 (and will be 0 due to minimization).
m.addConstr(x_horse <= M * z_horse, "C_link_horse_1")
m.addConstr(x_horse >= z_horse, "C_link_horse_2") # If x_horse is integer and > 0, it must be >= 1, forcing z_horse to 1.

m.addConstr(x_bike <= M * z_bike, "C_link_bike_1")
m.addConstr(x_bike >= z_bike, "C_link_bike_2")

m.addConstr(x_cart <= M * z_cart, "C_link_cart_1")
m.addConstr(x_cart >= z_cart, "C_link_cart_2")

# 6. Permit fee logic: b_permit_fee = 1 if total_pollution strictly exceeds horse_pollution_permit_threshold
# Constraint 1: If b_permit_fee is 0, then total_pollution must be <= threshold.
m.addConstr(total_pollution - horse_pollution_permit_threshold <= M * b_permit_fee, "C_permit_fee_1")
# Constraint 2: If b_permit_fee is 1, then total_pollution must be strictly > threshold.
# We use '1' as the epsilon value because pollution units are integers.
m.addConstr(total_pollution - horse_pollution_permit_threshold >= 1 - M * (1 - b_permit_fee), "C_permit_fee_2")


# Optimize the model
m.optimize()

# Output the final objective value
if m.status == GRB.OPTIMAL:
    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print("No optimal solution found.")
    # print(f"Model status: {m.status}") # For debugging if needed
