import csv
import os
import gurobipy as gp
from gurobipy import GRB

# --- Utility Functions (adapted from original workspace) ---

def load_distance_matrix(filepath):
    """Load distance matrix from CSV file.
    
    Returns:
        cities: list of city labels (e.g., ['1', '2', '3', '4'])
        dist: 2D list of distances (dist[i][j] = distance from city i to city j)
    """
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: ['City', '1', '2', '3', '4', ...]
        city_labels = header[1:]
        
        dist = []
        cities = []
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
    
    return cities, dist

def load_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader) # Skip header: ['parameter', 'value']
        for row in reader:
            if row: # Ensure row is not empty
                param_name = row[0].strip()
                param_value = row[1].strip()
                
                # Attempt to convert to int or float if possible, otherwise keep as string
                try:
                    params[param_name] = int(param_value)
                except ValueError:
                    try:
                        params[param_name] = float(param_value)
                    except ValueError:
                        params[param_name] = param_value
    return params

# --- Main Solver Function ---

def solve_revised_tsp():
    # Determine data directory relative to the script's location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load distance matrix from table_1.csv
    dist_file = os.path.join(data_dir, 'table_1.csv')
    cities, dist = load_distance_matrix(dist_file)
    n = len(cities) # Number of cities

    # Load general parameters from general_parameters.csv
    params_file = os.path.join(data_dir, 'general_parameters.csv')
    params = load_parameters(params_file)
    
    # Map city labels from parameters to their integer indices
    # Ensure labels are treated as strings for dictionary lookup
    start_city_idx = cities.index(str(params['start_city']))
    end_city_idx = cities.index(str(params['end_city']))
    prohibited_from_idx = cities.index(str(params['prohibited_from']))
    prohibited_to_idx = cities.index(str(params['prohibited_to']))
    inspection_arc_from_idx = cities.index(str(params['inspection_arc_from']))
    inspection_arc_to_idx = cities.index(str(params['inspection_arc_to']))
    inspection_stop_cost = params['inspection_stop_cost']

    # Create Gurobi model
    model = gp.Model("Revised_TSP")
    model.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Decision variables: x[i, j] = 1 if travel from city i to city j, 0 otherwise
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")

    # MTZ variables: u[i] for subtour elimination
    # u[i] represents the order of visiting city i in the tour, relative to the start_city_idx.
    # u variables are defined for all cities EXCEPT the start_city_idx.
    # Their bounds are 1 to n-1.
    u_vars = {}
    for i in range(n):
        if i != start_city_idx:
            u_vars[i] = model.addVar(vtype=GRB.CONTINUOUS, lb=1, ub=n-1, name=f"u_{i}")
    
    # Objective function: Minimize total distance
    # Initial objective includes all distances
    obj = gp.quicksum(dist[i][j] * x[i, j] for i in range(n) for j in range(n) if i != j)
    
    # Add inspection stop cost if the specific arc is taken
    obj += inspection_stop_cost * x[inspection_arc_from_idx, inspection_arc_to_idx]
    
    model.setObjective(obj, GRB.MINIMIZE)

    # --- Constraints ---

    # 1. Each city must be left exactly once
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(n) if i != j) == 1, name=f"leave_{i}")

    # 2. Each city must be entered exactly once
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(n) if i != j) == 1, name=f"enter_{j}")

    # 3. Prohibited arc: Cannot travel directly from `prohibited_from` to `prohibited_to`
    model.addConstr(x[prohibited_from_idx, prohibited_to_idx] == 0, name="prohibited_arc")

    # 4. Fixed return arc: The tour must end at `end_city_idx` and return to `start_city_idx`.
    # This means the arc from `end_city_idx` to `start_city_idx` must be taken.
    model.addConstr(x[end_city_idx, start_city_idx] == 1, name="fixed_return_arc")

    # 5. Subtour elimination constraints (MTZ formulation)
    # u[i] - u[j] + n * x[i, j] <= n - 1
    # These constraints apply for all i, j in V \ {start_city_idx}, where i != j.
    # The `u_vars` dictionary already excludes `start_city_idx`.
    for i in range(n):
        for j in range(n):
            if i != j and i != start_city_idx and j != start_city_idx:
                model.addConstr(u_vars[i] - u_vars[j] + n * x[i, j] <= n - 1, name=f"mtz_{i}_{j}")

    # Optimize the model
    model.optimize()

    # Print the optimal objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("Optimization did not find an optimal solution.")

if __name__ == "__main__":
    solve_revised_tsp()
