import gurobipy as gp
from gurobipy import GRB
import os
import csv
import math

# --- Utility functions (adapted from src/utils.py for self-containment) ---

def load_csv(filename):
    """Load a CSV file and return headers and rows.
    
    The script is expected to be executed from the revised workspace root directory.
    Data files are in the 'data/' subdirectory relative to the root.
    """
    # Construct the path to the data file based on the script's location
    # and the specified data directory structure.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(script_dir, "data", filename)
    
    rows = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    return rows

def load_general_parameters(filename='general_parameters.csv'):
    """Load general parameters into a dictionary."""
    rows = load_csv(filename)
    params = {}
    for row in rows:
        params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_reliability_table(filename='table_1.csv'):
    """Load reliability table. Returns dict: {num_spares: [r1, r2, r3]}"""
    rows = load_csv(filename)
    reliability = {}
    for row in rows:
        n_spares = int(row['Number_of_Spares'])
        # Component_Number column is always '1' in the provided table,
        # so we directly map to component indices 0, 1, 2.
        r1 = float(row['Component_1_Reliability'])
        r2 = float(row['Component_2_Reliability'])
        r3 = float(row['Component_3_Reliability'])
        reliability[n_spares] = [r1, r2, r3]
    return reliability

# --- Main optimization script ---

def solve_revised_problem():
    # Load data using the utility functions
    params = load_general_parameters()
    reliability_data = load_reliability_table()
    
    # Extract specific parameters for the model
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    
    total_budget_A = params['total_budget_scenario_A']
    total_budget_B = params['total_budget_scenario_B']
    weight_limit_A = params['weight_limit_scenario_A']
    weight_limit_B = params['weight_limit_scenario_B']
    
    num_components = 3
    # Determine the maximum number of spares from the reliability table
    max_spares = max(reliability_data.keys()) # This will be 5 based on table_1.csv
    
    # Pre-calculate log-reliabilities for the objective function.
    # Maximizing product(R_i) is equivalent to maximizing sum(log(R_i)).
    # This transforms a non-linear product objective into a linear sum objective.
    log_reliabilities = {}
    for s_val in range(max_spares + 1):
        log_reliabilities[s_val] = []
        for c_idx in range(num_components):
            # Ensure reliability is positive before taking log.
            # All reliability values in the provided data are > 0.
            log_reliabilities[s_val].append(math.log(reliability_data[s_val][c_idx]))

    # Initialize Gurobi model
    m = gp.Model("SystemReliabilityRevised")
    m.setParam('OutputFlag', 0) # Suppress Gurobi output

    # Decision Variables:
    # x[c_idx, s_val]: Binary variable, 1 if component c_idx has s_val spares, 0 otherwise.
    x = m.addVars(num_components, max_spares + 1, vtype=GRB.BINARY, name="x")
    
    # s[c_idx]: Integer variable representing the number of spares for component c_idx.
    # This variable is linked to the binary x variables for convenience in constraints.
    s = m.addVars(num_components, vtype=GRB.INTEGER, name="s")

    # Constraints:
    # 1. Each component must have exactly one chosen number of spares (from 0 to max_spares).
    m.addConstrs((gp.quicksum(x[c_idx, s_val] for s_val in range(max_spares + 1)) == 1
                  for c_idx in range(num_components)), name="one_spare_count_per_component")
    
    # 2. Link the integer variable s[c_idx] to the binary choices x[c_idx, s_val].
    m.addConstrs((s[c_idx] == gp.quicksum(s_val * x[c_idx, s_val] for s_val in range(max_spares + 1))
                  for c_idx in range(num_components)), name="link_s_x")
    
    # 3. Total cost constraints for both Scenario A and Scenario B.
    # The chosen spare package must satisfy both budget limits.
    total_cost_expr = gp.quicksum(s[c_idx] * unit_price[c_idx] for c_idx in range(num_components))
    m.addConstr(total_cost_expr <= total_budget_A, name="budget_A_limit")
    m.addConstr(total_cost_expr <= total_budget_B, name="budget_B_limit")
    
    # 4. Total weight constraints for both Scenario A and Scenario B.
    # The chosen spare package must satisfy both weight limits.
    total_weight_expr = gp.quicksum(s[c_idx] * unit_weight[c_idx] for c_idx in range(num_components))
    m.addConstr(total_weight_expr <= weight_limit_A, name="weight_A_limit")
    m.addConstr(total_weight_expr <= weight_limit_B, name="weight_B_limit")
    
    # Objective Function:
    # Maximize the sum of log reliabilities for each component.
    # This sum corresponds to log(R1*R2*R3).
    # The expected reliability is 0.5*SysRel_A + 0.5*SysRel_B.
    # Since SysRel_A = SysRel_B = R1*R2*R3, the objective is to maximize R1*R2*R3.
    objective_expr = gp.quicksum(
        gp.quicksum(log_reliabilities[s_val][c_idx] * x[c_idx, s_val] 
                    for s_val in range(max_spares + 1))
        for c_idx in range(num_components)
    )
    m.setObjective(objective_expr, GRB.MAXIMIZE)
    
    # Optimize the model
    m.optimize()
    
    # Extract and print results
    if m.status == GRB.OPTIMAL:
        # The Gurobi objective value is the sum of log reliabilities.
        # To get the actual system reliability (which is the expected reliability),
        # we need to exponentiate this sum.
        optimal_log_reliability_sum = m.objVal
        optimal_system_reliability = math.exp(optimal_log_reliability_sum)
        
        # Print the final objective value as required
        print(f"FINAL_OBJ_VALUE: {optimal_system_reliability}")
    else:
        # Handle cases where no optimal solution is found (e.g., infeasible)
        print("No optimal solution found.")
        print(f"Model status: {m.status}")

if __name__ == '__main__':
    solve_revised_problem()
