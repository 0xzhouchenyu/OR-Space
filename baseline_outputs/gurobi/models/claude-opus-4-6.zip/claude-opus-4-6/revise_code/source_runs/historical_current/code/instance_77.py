import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load processing costs from table_1.csv
    cost = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p) for p in header[1:]]
        for row in reader:
            machine = row[0].strip()
            for j, p in enumerate(parts):
                cost[(machine, p)] = float(row[j + 1])

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    d = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    max_C = int(params['max_parts_on_C'])
    overtime_threshold = int(params['overtime_threshold'])
    overtime_penalty = params['overtime_penalty']

    machines = ['A', 'B', 'C']

    # Create model
    model = gp.Model("MachineAssignment")
    model.setParam('OutputFlag', 0)

    # x[m,p] = 1 if part p is assigned to machine m
    x = {}
    for m in machines:
        for p in parts:
            x[(m, p)] = model.addVar(vtype=GRB.BINARY, name=f"x_{m}_{p}")

    # y[m] = 1 if machine m is used
    y = {}
    for m in machines:
        y[m] = model.addVar(vtype=GRB.BINARY, name=f"y_{m}")

    # z[m] = 1 if machine m processes more than overtime_threshold parts
    z = {}
    for m in machines:
        z[m] = model.addVar(vtype=GRB.BINARY, name=f"z_{m}")

    model.update()

    # Objective: minimize processing costs + setup costs + overtime penalties
    obj = gp.quicksum(cost[(m, p)] * x[(m, p)] for m in machines for p in parts) \
        + gp.quicksum(d[m] * y[m] for m in machines) \
        + gp.quicksum(overtime_penalty * z[m] for m in machines)
    model.setObjective(obj, GRB.MINIMIZE)

    # Each part assigned to exactly one machine
    for p in parts:
        model.addConstr(gp.quicksum(x[(m, p)] for m in machines) == 1, name=f"assign_{p}")

    # Linking y to x
    for m in machines:
        for p in parts:
            model.addConstr(x[(m, p)] <= y[m], name=f"link_{m}_{p}")

    # Constraint 2: x[A,1] + x[A,2] = 1
    model.addConstr(x[('A', 1)] + x[('A', 2)] == 1, name="part1_part2")

    # Constraint 3: Fixed assignments
    model.addConstr(x[('A', 3)] == 1, name="fix_3A")
    model.addConstr(x[('B', 4)] == 1, name="fix_4B")
    model.addConstr(x[('C', 5)] == 1, name="fix_5C")

    # Constraint 4: At most max_C parts on machine C
    model.addConstr(gp.quicksum(x[('C', p)] for p in parts) <= max_C, name="max_C")

    # Constraint 5: Overtime penalty linking
    # z[m] = 1 if sum of parts on m > overtime_threshold
    # sum_x[m] <= overtime_threshold + N * z[m]  (N = len(parts))
    # sum_x[m] >= overtime_threshold + 1 - N*(1 - z[m])  -- to force z=1 when exceeded
    N = len(parts)
    for m in machines:
        sum_x_m = gp.quicksum(x[(m, p)] for p in parts)
        # If sum > threshold then z must be 1
        model.addConstr(sum_x_m <= overtime_threshold + N * z[m], name=f"ot_upper_{m}")
        # If sum <= threshold then z can be 0 (this forces z=1 when sum >= threshold+1)
        model.addConstr(sum_x_m >= overtime_threshold + 1 - N * (1 - z[m]), name=f"ot_lower_{m}")

    model.optimize()

    obj_val = model.ObjVal

    # Print assignments for debugging
    for p in parts:
        for m in machines:
            if x[(m, p)].X > 0.5:
                print(f"Part {p} -> Machine {m} (cost={cost[(m,p)]})")
    for m in machines:
        if y[m].X > 0.5:
            print(f"Machine {m} used, setup cost={d[m]}")
        if z[m].X > 0.5:
            print(f"Machine {m} overtime penalty={overtime_penalty}")

    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == '__main__':
    main()
