import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read property data
properties = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_risky_multiplier = params['scen_1_risky_multiplier']
scen_2_risky_multiplier = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = int(params['max_risky_properties'])

# Create optimization model
model = gp.Model("RealEstateInvestment")
model.setParam('OutputFlag', 0)

n = len(properties)

# Decision variables
# x[i]: binary, whether to purchase property i
x = {}
for i, p in enumerate(properties):
    x[i] = model.addVar(vtype=GRB.BINARY, name=f"x_{p['name']}")

# r[i]: fraction of property i allocated to risky tenants (continuous, 0 to per_property_risky_cap)
r = {}
for i, p in enumerate(properties):
    r[i] = model.addVar(lb=0.0, ub=1.0, vtype=GRB.CONTINUOUS, name=f"r_{p['name']}")

# y[i]: binary, whether property i has any risky tenants
y = {}
for i, p in enumerate(properties):
    y[i] = model.addVar(vtype=GRB.BINARY, name=f"y_{p['name']}")

model.update()

# Objective: maximize expected annual income
# For each property i that is purchased:
#   - Safe portion: (1 - r[i]) * income[i]  (deterministic)
#   - Risky portion: r[i] * income[i] * (scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier)
# Expected risky multiplier
expected_risky_mult = scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier

obj_expr = gp.LinExpr()
for i, p in enumerate(properties):
    income_i = p['income']
    # Safe income: (1 - r[i]) * income_i, but only if purchased
    # Risky income: r[i] * income_i * expected_risky_mult, but only if purchased
    # Total: income_i * x[i] - r[i] * income_i + r[i] * income_i * expected_risky_mult
    #       = income_i * x[i] + r[i] * income_i * (expected_risky_mult - 1)
    # But r[i] is only valid when x[i]=1, enforced by constraints
    obj_expr += income_i * x[i] + income_i * (expected_risky_mult - 1.0) * r[i]

model.setObjective(obj_expr, GRB.MAXIMIZE)

# Budget constraint
model.addConstr(
    gp.quicksum(p['cost'] * x[i] for i, p in enumerate(properties)) <= budget,
    "budget"
)

# Exclusion: Property 4 and Property 3 cannot both be purchased
# Find indices
idx_map = {p['name']: i for i, p in enumerate(properties)}
model.addConstr(x[idx_map['Property_4']] + x[idx_map['Property_3']] <= 1, "exclude_3_4")

# Risky fraction only allowed if property is purchased
for i, p in enumerate(properties):
    model.addConstr(r[i] <= per_property_risky_cap * x[i], f"risky_cap_{p['name']}")

# y[i] = 1 if r[i] > 0 (linking binary indicator for risky allocation)
# r[i] <= y[i] (since r[i] <= per_property_risky_cap <= 1)
# y[i] <= x[i]
for i, p in enumerate(properties):
    model.addConstr(r[i] <= y[i], f"risky_link_{p['name']}")
    model.addConstr(y[i] <= x[i], f"risky_buy_link_{p['name']}")

# Total risky budget: sum of cost[i] * y[i] <= total_risky_budget
# "Maximum total acquisition cost of properties that host any risky tenants"
model.addConstr(
    gp.quicksum(p['cost'] * y[i] for i, p in enumerate(properties)) <= total_risky_budget,
    "total_risky_budget"
)

# Maximum number of properties with risky tenants
model.addConstr(
    gp.quicksum(y[i] for i in range(n)) <= max_risky_properties,
    "max_risky_properties"
)

# Solve
model.optimize()

# Print results
for i, p in enumerate(properties):
    print(f"{p['name']}: buy={int(round(x[i].X))}, risky_frac={r[i].X:.4f}, risky_flag={int(round(y[i].X))}")

obj_val = model.ObjVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
