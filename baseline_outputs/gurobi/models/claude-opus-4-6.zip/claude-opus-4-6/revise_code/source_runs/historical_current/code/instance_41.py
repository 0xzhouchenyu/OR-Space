import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Parameter_Name'].strip() == 'initial_capital':
            initial_capital = float(row['Value'].strip())

# Load liquidity policy parameters
with open(os.path.join(data_dir, 'liquidity_policy.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        if name == 'min_year3_reserve':
            min_year3_reserve = float(row['Value'].strip())
        elif name == 'reserve_shortfall_penalty':
            reserve_shortfall_penalty = float(row['Value'].strip())

# Load project data
projects = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        projects.append(row)

# Create model
model = gp.Model("Investment_Maximization")
model.setParam('OutputFlag', 0)

# Decision variables
# x1_1: amount invested in Project 1 at beginning of Year 1 (matures end of Year 1, returns x1_1 * 1.20)
# x1_2: amount invested in Project 1 at beginning of Year 2 (matures end of Year 2, returns x1_2 * 1.20)
# x1_3: amount invested in Project 1 at beginning of Year 3 (matures end of Year 3, returns x1_3 * 1.20)
# x2: amount invested in Project 2 at beginning of Year 1 (matures end of Year 2, returns x2 * 1.50)
# x3: amount invested in Project 3 at beginning of Year 2 (matures end of Year 2, returns x3 * 1.60)
# x4: amount invested in Project 4 at beginning of Year 3 (matures end of Year 3, returns x4 * 1.40)

x1_1 = model.addVar(lb=0, name="x1_1")
x1_2 = model.addVar(lb=0, name="x1_2")
x1_3 = model.addVar(lb=0, name="x1_3")
x2 = model.addVar(lb=0, ub=120000, name="x2")
x3 = model.addVar(lb=0, ub=150000, name="x3")
x4 = model.addVar(lb=0, ub=100000, name="x4")

# Reserve variable: how much cash is held uninvested at beginning of Year 3
reserve = model.addVar(lb=0, name="reserve")

# Shortfall variable: max(0, min_year3_reserve - reserve)
shortfall = model.addVar(lb=0, name="shortfall")

# Year 1 budget constraint: x1_1 + x2 <= initial_capital
model.addConstr(x1_1 + x2 <= initial_capital, "Year1_Budget")

# Year 2 budget constraint: 
# Available at beginning of Year 2: x1_1 * 1.20 (Project 1 from Year 1 matures end of Year 1)
# Spend on: x1_2 + x3
model.addConstr(x1_2 + x3 <= x1_1 * 1.20, "Year2_Budget")

# Year 3 budget constraint:
# Available at beginning of Year 3: x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60
# This must cover: x1_3 + x4 + reserve
cash_available_year3 = x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60
model.addConstr(x1_3 + x4 + reserve <= cash_available_year3, "Year3_Budget")

# Shortfall constraint: shortfall >= min_year3_reserve - reserve
model.addConstr(shortfall >= min_year3_reserve - reserve, "Shortfall_Def")

# Objective: maximize net profit = terminal wealth - initial_capital - penalty
# Terminal wealth at end of Year 3:
#   - x1_3 * 1.20 (Project 1 Year 3 matures)
#   - x4 * 1.40 (Project 4 matures)
#   - reserve (cash held through Year 3, no return)
# Net profit = terminal_wealth - initial_capital - penalty * shortfall
# But actually, re-reading the requirement: "maximizing net profit at the end of Year 3 after applying a liquidity reserve penalty"
# and "each yuan by which the beginning-of-Year-3 cash holdback falls short of 80,000 yuan reduces the plan's final score by 0.5 yuan"
# The "final score" seems to be terminal wealth minus the penalty (not net profit per se).
# Let me re-read: "The objective is changed from maximizing only terminal wealth to maximizing net profit at the end of Year 3 after applying a liquidity reserve penalty."
# Original objective was terminal wealth. Now it's "net profit" = terminal wealth - initial_capital, minus penalty.
# Actually, looking more carefully: the original code maximized x1_3*1.20 + x4*1.40 which is just the returns from Year 3 investments,
# not including cash that wasn't invested. But that was because in the original problem, all cash would optimally be invested.
# 
# Now with the reserve, terminal wealth = x1_3 * 1.20 + x4 * 1.40 + reserve
# And the "plan's final score" is reduced by 0.5 * shortfall.
# 
# The revision says "maximizing net profit at the end of Year 3 after applying a liquidity reserve penalty"
# I'll interpret this as: maximize (terminal_wealth - initial_capital - penalty*shortfall)
# But since initial_capital is a constant, maximizing terminal_wealth - penalty*shortfall is equivalent.
# Let me just maximize terminal_wealth - penalty*shortfall to get the right investment decisions,
# then report it. Actually, for the objective value to be "net profit", let me subtract initial_capital.

# Actually, let me re-read the revision more carefully:
# "The objective is changed from maximizing only terminal wealth to maximizing net profit at the end of Year 3 after applying a liquidity reserve penalty."
# So: objective = (terminal wealth - initial capital) - penalty * shortfall = net profit - penalty
# But wait, the original heuristic didn't subtract initial capital either. Let me look at what makes sense.
# The original objective was just x1_3*1.20 + x4*1.40 (terminal wealth from investments only).
# Now we need to include reserve in terminal wealth and subtract penalty.
# 
# I think the cleanest interpretation: 
# Objective = total ending funds - penalty = (x1_3*1.20 + x4*1.40 + reserve) - 0.5*shortfall
# This is "terminal wealth" adjusted by penalty. Whether we call it "net profit" by subtracting 
# initial_capital is just a constant shift that doesn't affect the optimal solution.
# I'll maximize total ending funds minus penalty (without subtracting initial capital, 
# consistent with the original code's approach).

model.setObjective(x1_3 * 1.20 + x4 * 1.40 + reserve - reserve_shortfall_penalty * shortfall, GRB.MAXIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    for v in model.getVars():
        print(f"{v.VarName} = {v.X}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Model status: {model.status}")
    print(f"FINAL_OBJ_VALUE: N/A")
