import os
import csv
import gurobipy as gp
from gurobipy import GRB
from itertools import combinations

# Load parameters
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
motorcycle_pollution = params['motorcycle_pollution']       # 40
small_truck_pollution = params['small_truck_pollution']     # 70
large_truck_pollution = params['large_truck_pollution']     # 100
max_motorcycle_trips = int(params['max_motorcycle_trips'])  # 8
motorcycle_capacity = params['motorcycle_capacity']         # 10
small_truck_capacity = params['small_truck_capacity']       # 20
large_truck_capacity = params['large_truck_capacity']       # 50
max_total_trips = int(params['max_total_trips'])            # 20
demand_peak = params['demand_peak_units']                   # 200
demand_offpeak = params['demand_offpeak_units']             # 120
leasing_capacity = params['leasing_capacity']               # 200
leasing_pollution_per_unit = params['leasing_pollution_per_unit']  # 60
leasing_fixed_pollution = params['leasing_fixed_pollution']       # 100
max_leasing_fraction_peak = params['max_leasing_fraction_peak']   # 0.25
bigM_leasing = params['bigM_leasing']                             # 400
epsilon = params['epsilon']                                       # 1

methods = ['motorcycle', 'small_truck', 'large_truck']
periods = ['peak', 'offpeak']

pollution = {
    'motorcycle': motorcycle_pollution,
    'small_truck': small_truck_pollution,
    'large_truck': large_truck_pollution
}

capacity = {
    'motorcycle': motorcycle_capacity,
    'small_truck': small_truck_capacity,
    'large_truck': large_truck_capacity
}

demand = {
    'peak': demand_peak,
    'offpeak': demand_offpeak
}

best_obj = float('inf')
best_model = None

# Enumerate all combinations of 2 methods (the company can only choose 2 out of 3)
for combo in combinations(methods, 2):
    model = gp.Model(f"Transport_{'_'.join(combo)}")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of trips for each method in each period (integer, non-negative)
    trips = {}
    for m in combo:
        for p in periods:
            trips[m, p] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"trips_{m}_{p}")
    
    # Leasing variables per period
    leasing = {}
    for p in periods:
        leasing[p] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"leasing_{p}")
    
    # Binary variable: whether leasing is used at all (day-wide)
    leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")
    
    model.update()
    
    # Objective: minimize total pollution
    # Owned trips pollution
    obj_owned = gp.quicksum(pollution[m] * trips[m, p] for m in combo for p in periods)
    # Leasing variable pollution (per unit)
    total_leasing = gp.quicksum(leasing[p] for p in periods)
    obj_leasing_variable = leasing_pollution_per_unit * total_leasing
    # Leasing fixed pollution
    obj_leasing_fixed = leasing_fixed_pollution * leasing_used
    
    model.setObjective(obj_owned + obj_leasing_variable + obj_leasing_fixed, GRB.MINIMIZE)
    
    # Demand constraints per period
    for p in periods:
        model.addConstr(
            gp.quicksum(capacity[m] * trips[m, p] for m in combo) + leasing[p] >= demand[p],
            name=f"demand_{p}"
        )
    
    # Maximum total trips across both periods
    model.addConstr(
        gp.quicksum(trips[m, p] for m in combo for p in periods) <= max_total_trips,
        name="max_trips"
    )
    
    # Motorcycle trips limit (total across both periods)
    if 'motorcycle' in combo:
        model.addConstr(
            gp.quicksum(trips['motorcycle', p] for p in periods) <= max_motorcycle_trips,
            name="max_motorcycle"
        )
    
    # Leasing capacity constraint (total over day)
    model.addConstr(total_leasing <= leasing_capacity, name="leasing_cap")
    
    # Maximum leasing fraction in peak period
    model.addConstr(leasing['peak'] <= max_leasing_fraction_peak * demand_peak, name="leasing_peak_frac")
    
    # Big-M linking: if leasing_used = 0, then total_leasing = 0
    # total_leasing <= bigM_leasing * leasing_used
    model.addConstr(total_leasing <= bigM_leasing * leasing_used, name="leasing_bigM_upper")
    
    # If leasing_used = 1, then total_leasing >= epsilon
    # total_leasing >= epsilon * leasing_used
    model.addConstr(total_leasing >= epsilon * leasing_used, name="leasing_bigM_lower")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        if obj_val < best_obj:
            best_obj = obj_val
            best_info = {
                'combo': combo,
                'trips': {(m, p): trips[m, p].X for m in combo for p in periods},
                'leasing': {p: leasing[p].X for p in periods},
                'leasing_used': leasing_used.X
            }

# Print solution details
if best_obj < float('inf'):
    info = best_info
    print(f"Best combination: {info['combo']}")
    for p in periods:
        print(f"  Period: {p}")
        for m in info['combo']:
            print(f"    {m}: {info['trips'][m, p]} trips")
        print(f"    leasing: {info['leasing'][p]} units")
    print(f"  Leasing used: {info['leasing_used']}")
    total_pollution = best_obj
    print(f"Total pollution: {total_pollution}")

print(f"FINAL_OBJ_VALUE: {best_obj}")
