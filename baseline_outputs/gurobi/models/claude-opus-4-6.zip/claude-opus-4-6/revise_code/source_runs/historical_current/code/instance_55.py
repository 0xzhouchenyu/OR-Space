import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load courses
courses = {}
filepath = os.path.join(data_dir, "table_1.csv")
with open(filepath, "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        course = row["Course"].strip()
        categories = [c.strip() for c in row["Category"].split(";")]
        courses[course] = categories

# Load parameters
filepath = os.path.join(data_dir, "general_parameters.csv")
params = {}
prereq_raw = {}
mandatory_foundation_for_cs = None
cs_category_name = None

with open(filepath, "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        value = row["Value"].strip()
        if name == "min_courses_required":
            params["min_courses_required"] = int(value)
        elif name.startswith("prerequisite_"):
            course_key = name[len("prerequisite_"):]
            prereq_raw[course_key] = value
        elif name == "mandatory_foundation_for_cs_counting":
            mandatory_foundation_for_cs = value
        elif name == "cs_category_name":
            cs_category_name = value

min_required = params["min_courses_required"]

# Match prerequisite keys to course names
course_list = list(courses.keys())

def match_course(key, course_list):
    key_lower = key.lower().replace("_", " ")
    for c in course_list:
        if c.lower() == key_lower:
            return c
    return None

prerequisites = {}
for prereq_key, prereq_value in prereq_raw.items():
    course_name = match_course(prereq_key, course_list)
    if course_name:
        if course_name not in prerequisites:
            prerequisites[course_name] = []
        prerequisites[course_name].append(prereq_value.strip())

# Get all categories
all_categories = set()
for cats in courses.values():
    for c in cats:
        all_categories.add(c)

print("Courses and categories:", courses)
print("Prerequisites:", prerequisites)
print("Min courses per category:", min_required)
print("Categories:", all_categories)
print("Mandatory foundation for CS:", mandatory_foundation_for_cs)
print("CS category name:", cs_category_name)

# Create optimization model
model = gp.Model("CourseSelection")
model.setParam("OutputFlag", 0)

# Decision variables: binary, whether to take each course
x = {}
for course in course_list:
    x[course] = model.addVar(vtype=GRB.BINARY, name=f"x_{course.replace(' ', '_')}")

# Assignment variables: y[course, category] = 1 if course is counted toward category
# A cross-listed course can only be counted toward ONE category (revised requirement)
y = {}
for course in course_list:
    for cat in courses[course]:
        y[course, cat] = model.addVar(vtype=GRB.BINARY, name=f"y_{course.replace(' ', '_')}_{cat.replace(' ', '_')}")

# Variable: whether CS category is "activated" (has courses counted toward it)
cs_active = model.addVar(vtype=GRB.BINARY, name="cs_active")

model.update()

# Objective: minimize total number of courses taken
model.setObjective(gp.quicksum(x[course] for course in course_list), GRB.MINIMIZE)

# Constraint: y[course, cat] <= x[course] (can only count a course if you take it)
for course in course_list:
    for cat in courses[course]:
        model.addConstr(y[course, cat] <= x[course],
                        name=f"assign_take_{course.replace(' ', '_')}_{cat.replace(' ', '_')}")

# Constraint: each course can be counted toward at most ONE category
for course in course_list:
    if len(courses[course]) > 1:
        model.addConstr(
            gp.quicksum(y[course, cat] for cat in courses[course]) <= 1,
            name=f"single_cat_{course.replace(' ', '_')}"
        )

# Constraint: at least min_required distinct counted courses in each category
for category in all_categories:
    courses_in_cat = [course for course, cats in courses.items() if category in cats]
    model.addConstr(
        gp.quicksum(y[course, category] for course in courses_in_cat) >= min_required,
        name=f"Min_{category.replace(' ', '_')}"
    )

# Prerequisite constraints: if you take a course, you must take its prerequisites
for course, prereqs in prerequisites.items():
    for prereq in prereqs:
        if prereq in x:
            model.addConstr(x[course] <= x[prereq],
                            name=f"Prereq_{course.replace(' ', '_')}_needs_{prereq.replace(' ', '_')}")

# Mandatory foundation for CS: if any course is counted toward CS category,
# Computer Programming must be taken
# cs_active = 1 if any y[course, CS] = 1
if cs_category_name and mandatory_foundation_for_cs:
    cs_courses = [course for course, cats in courses.items() if cs_category_name in cats]
    
    # cs_active >= y[course, cs_category_name] for each CS course
    for course in cs_courses:
        model.addConstr(cs_active >= y[course, cs_category_name],
                        name=f"cs_active_link_{course.replace(' ', '_')}")
    
    # cs_active <= sum of y[course, cs_category_name]
    model.addConstr(cs_active <= gp.quicksum(y[course, cs_category_name] for course in cs_courses),
                    name="cs_active_upper")
    
    # If CS is active, the foundation course must be taken
    if mandatory_foundation_for_cs in x:
        model.addConstr(x[mandatory_foundation_for_cs] >= cs_active,
                        name="cs_foundation_required")
    
    # Additionally, the foundation course (Computer Programming) must be taken 
    # before any course is counted toward CS. Since we already have prerequisite 
    # constraints for specific courses, we also need: for any course counted toward CS,
    # Computer Programming must be selected.
    # This is already handled by cs_active constraint above plus the fact that
    # min_required >= 2 forces cs_active = 1 which forces Computer Programming.
    # But let's be explicit: any course counted toward CS requires CP to be taken
    for course in cs_courses:
        if course != mandatory_foundation_for_cs:
            model.addConstr(
                y[course, cs_category_name] <= x[mandatory_foundation_for_cs],
                name=f"cs_foundation_for_{course.replace(' ', '_')}"
            )

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"\nStatus: Optimal")
    print("\nSelected courses:")
    for course in course_list:
        if x[course].X > 0.5:
            assigned_cats = []
            for cat in courses[course]:
                if (course, cat) in y and y[course, cat].X > 0.5:
                    assigned_cats.append(cat)
            print(f"  {course}: categories={courses[course]}, counted_toward={assigned_cats}")
    
    obj_val = model.ObjVal
    print(f"\nFINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
