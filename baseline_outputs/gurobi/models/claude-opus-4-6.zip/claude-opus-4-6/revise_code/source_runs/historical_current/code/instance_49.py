import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    table_1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    table_2 = pd.read_csv(os.path.join(data_dir, "table_2.csv"))
    params = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    
    # Parse parameters
    def get_param(name):
        return params.loc[params['Parameter_Name'] == name, 'Value'].values[0]
    
    min_contract_types = int(get_param('min_contract_types'))
    max_contract_types = int(get_param('max_contract_types'))
    mutual_exclusion = str(get_param('mutual_exclusion_1_and_4')).strip().lower() == 'true'
    monthly_max_parallel = int(get_param('monthly_max_parallel_contracts'))
    min_area_per_contract = int(get_param('min_area_per_contract_units'))
    activation_fee = float(get_param('activation_fee_per_contract'))
    onboarding_loss = int(get_param('onboarding_loss_units'))
    expedited_fee = float(get_param('expedited_onboarding_fee'))
    
    # Data
    demands = {int(row['Month']): float(row['Required_area_㎡']) / 100.0 
               for _, row in table_1.iterrows()}
    costs = {int(row['Contract_length_months']): float(row['Rental_fee_per_100㎡_yuan']) 
             for _, row in table_2.iterrows()}
    
    months = sorted(demands.keys())
    max_month = max(months)
    contract_lengths = sorted(costs.keys())
    
    # Valid (start_month, contract_length) pairs
    valid_pairs = [(i, j) for i in months for j in contract_lengths if i + j - 1 <= max_month]
    
    M_big = sum(demands.values()) * 2  # big-M
    
    model = gp.Model("Warehouse_Rental_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i,j] = number of 100 sqm units rented starting month i for j months
    x = {}
    for (i, j) in valid_pairs:
        x[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}")
    
    # z[i,j] = binary: 1 if contract (i,j) is active (x[i,j] > 0)
    z = {}
    for (i, j) in valid_pairs:
        z[i, j] = model.addVar(vtype=GRB.BINARY, name=f"z_{i}_{j}")
    
    # y[j] = binary: 1 if contract length j is used at all
    y = {}
    for j in contract_lengths:
        y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")
    
    # e[i,j] = binary: 1 if expedited onboarding is purchased for contract (i,j)
    e = {}
    for (i, j) in valid_pairs:
        e[i, j] = model.addVar(vtype=GRB.BINARY, name=f"e_{i}_{j}")
    
    model.update()
    
    # Objective: minimize total rental cost + activation fees + expedited onboarding fees
    obj = gp.LinExpr()
    for (i, j) in valid_pairs:
        obj += costs[j] * x[i, j]  # rental cost
        obj += activation_fee * z[i, j]  # activation fee per contract
        obj += expedited_fee * e[i, j]  # expedited onboarding fee
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Link x and z: x[i,j] > 0 iff z[i,j] = 1
    for (i, j) in valid_pairs:
        model.addConstr(x[i, j] <= M_big * z[i, j], name=f"link_upper_{i}_{j}")
        model.addConstr(x[i, j] >= z[i, j], name=f"link_lower_{i}_{j}")
    
    # e[i,j] can only be 1 if z[i,j] = 1
    for (i, j) in valid_pairs:
        model.addConstr(e[i, j] <= z[i, j], name=f"exp_link_{i}_{j}")
    
    # Link y[j] to z[i,j]: y[j] = 1 iff any contract of length j is used
    for j in contract_lengths:
        pairs_j = [(i, jj) for (i, jj) in valid_pairs if jj == j]
        model.addConstr(gp.quicksum(z[i, jj] for (i, jj) in pairs_j) >= y[j], 
                        name=f"y_link_lower_{j}")
        for (i, jj) in pairs_j:
            model.addConstr(z[i, jj] <= y[j], name=f"y_link_upper_{i}_{jj}")
    
    # Demand fulfillment for each month (exact)
    # Effective area contributed by contract (i,j) in month m:
    # - If m is NOT the start month (m != i): full x[i,j] units
    # - If m IS the start month (m == i): x[i,j] - onboarding_loss * z[i,j] + onboarding_loss * e[i,j]
    #   i.e., x[i,j] - onboarding_loss * (z[i,j] - e[i,j])
    for m in months:
        active_pairs = [(i, j) for (i, j) in valid_pairs if i <= m and i + j - 1 >= m]
        expr = gp.LinExpr()
        for (i, j) in active_pairs:
            if i == m:
                # Start month: reduced by onboarding loss unless expedited
                expr += x[i, j] - onboarding_loss * z[i, j] + onboarding_loss * e[i, j]
            else:
                # Not start month: full area
                expr += x[i, j]
        model.addConstr(expr == demands[m], name=f"demand_{m}")
    
    # Min area per contract: if active, at least min_area_per_contract units
    for (i, j) in valid_pairs:
        model.addConstr(x[i, j] >= min_area_per_contract * z[i, j], 
                        name=f"min_area_{i}_{j}")
    
    # Contract type limits
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) >= min_contract_types, 
                    name="min_types")
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) <= max_contract_types, 
                    name="max_types")
    
    # Mutual exclusion between 1-month and 4-month contracts
    if mutual_exclusion:
        if 1 in y and 4 in y:
            model.addConstr(y[1] + y[4] <= 1, name="mutual_excl_1_4")
    
    # Monthly max parallel contracts
    for m in months:
        active_pairs = [(i, j) for (i, j) in valid_pairs if i <= m and i + j - 1 >= m]
        model.addConstr(gp.quicksum(z[i, j] for (i, j) in active_pairs) <= monthly_max_parallel, 
                        name=f"max_parallel_{m}")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INFEASIBLE:
        # Debug
        model.computeIIS()
        model.write("debug.ilp")
        print("FINAL_OBJ_VALUE: INFEASIBLE")
    else:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
