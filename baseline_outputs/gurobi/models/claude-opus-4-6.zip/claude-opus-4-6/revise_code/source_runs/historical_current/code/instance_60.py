import os
import re
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    num_customers = 7
    max_route_length_day = 1000
    route_cost_day = 20
    
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'num_customers':
                num_customers = int(row['Value'])
            elif row['Parameter_Name'] == 'max_route_length_day':
                max_route_length_day = float(row['Value'])
            elif row['Parameter_Name'] == 'route_cost_day':
                route_cost_day = float(row['Value'])
    
    n = num_customers  # number of locations (0-indexed: 0=depot, 1..6=customers)
    
    # Read distance matrix
    D = [[0] * n for _ in range(n)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:
            nums = re.findall(r'\d+', line)
            if not nums:
                continue
            row_idx = int(nums[0]) - 1  # convert to 0-indexed
            for j, val in enumerate(nums[1:]):
                col_idx = row_idx + 1 + j
                if col_idx < n:
                    D[row_idx][col_idx] = int(val)
                    D[col_idx][row_idx] = int(val)
    
    # Sets
    customers = list(range(1, n))  # customer nodes (0-indexed: 1..6)
    days = [1, 2]
    depot = 0
    
    model = gp.Model("TSP_2day")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # y[i,d] = 1 if customer i is assigned to day d
    y = {}
    for i in customers:
        for d in days:
            y[i, d] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{d}")
    
    # x[i,j,d] = 1 if arc (i,j) is used on day d
    x = {}
    for d in days:
        for i in range(n):
            for j in range(n):
                if i != j:
                    x[i, j, d] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}_{d}")
    
    # u[i,d] for subtour elimination (MTZ), for customer nodes on day d
    u = {}
    for i in customers:
        for d in days:
            u[i, d] = model.addVar(lb=1, ub=n-1, vtype=GRB.CONTINUOUS, name=f"u_{i}_{d}")
    
    # z[d] = 1 if day d is used (has at least one customer)
    z = {}
    for d in days:
        z[d] = model.addVar(vtype=GRB.BINARY, name=f"z_{d}")
    
    model.update()
    
    # Objective: minimize total travel distance + fixed route costs
    obj = gp.LinExpr()
    for d in days:
        for i in range(n):
            for j in range(n):
                if i != j:
                    obj += D[i][j] * x[i, j, d]
        obj += route_cost_day * z[d]
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Each customer assigned to exactly one day
    for i in customers:
        model.addConstr(gp.quicksum(y[i, d] for d in days) == 1, name=f"assign_{i}")
    
    # Link z[d] to y: if any customer on day d, z[d]=1
    for d in days:
        for i in customers:
            model.addConstr(y[i, d] <= z[d], name=f"link_yz_{i}_{d}")
        # z[d] <= sum of y[i,d] (don't pay for empty day)
        model.addConstr(z[d] <= gp.quicksum(y[i, d] for i in customers), name=f"link_zy_{d}")
    
    # Flow constraints for each day
    for d in days:
        # For each customer: if assigned to day d, exactly one arc in and one arc out
        for i in customers:
            model.addConstr(
                gp.quicksum(x[j, i, d] for j in range(n) if j != i) == y[i, d],
                name=f"flow_in_{i}_{d}"
            )
            model.addConstr(
                gp.quicksum(x[i, j, d] for j in range(n) if j != i) == y[i, d],
                name=f"flow_out_{i}_{d}"
            )
        
        # Depot: number of arcs leaving depot = number of arcs entering depot
        # and equals number of customers on that day (but for TSP it equals 1 if any customers,
        # actually it equals 1 since it's a single tour)
        # Wait - depot leaves once and returns once in a TSP tour
        # Actually depot out = depot in = z[d] (leaves once if day is used)
        # No wait - if there are k customers on a day, depot still has degree 1 out and 1 in
        # because it's a single Hamiltonian cycle through depot + assigned customers
        model.addConstr(
            gp.quicksum(x[depot, j, d] for j in range(n) if j != depot) == z[d],
            name=f"depot_out_{d}"
        )
        model.addConstr(
            gp.quicksum(x[j, depot, d] for j in range(n) if j != depot) == z[d],
            name=f"depot_in_{d}"
        )
    
    # No arcs involving customers not assigned to that day
    for d in days:
        for i in customers:
            for j in range(n):
                if j != i:
                    model.addConstr(x[i, j, d] <= y[i, d], name=f"arc_assign1_{i}_{j}_{d}")
                    model.addConstr(x[j, i, d] <= (1 if j == depot else y[j, d]) if j != depot else z[d],
                                    name=f"arc_assign2_{j}_{i}_{d}")
    
    # Actually let me redo arc constraints more carefully
    # For arc (i,j,d) where i and j are both customers: both must be on day d
    # For arc (depot, j, d): j must be on day d
    # For arc (i, depot, d): i must be on day d
    # The flow constraints already handle most of this, but let's be safe with MTZ
    
    # MTZ subtour elimination for each day
    for d in days:
        for i in customers:
            for j in customers:
                if i != j:
                    model.addConstr(
                        u[i, d] - u[j, d] + (n - 1) * x[i, j, d] <= n - 2,
                        name=f"mtz_{i}_{j}_{d}"
                    )
    
    # Max route length per day
    for d in days:
        model.addConstr(
            gp.quicksum(D[i][j] * x[i, j, d] for i in range(n) for j in range(n) if i != j) <= max_route_length_day,
            name=f"max_route_{d}"
        )
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible")
        model.computeIIS()
        model.write("model.ilp")
    else:
        print(f"Optimization ended with status {model.status}")
        if model.SolCount > 0:
            print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
