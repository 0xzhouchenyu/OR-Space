import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read costs from table_1.csv
    costs = {}
    children = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row['Child'].strip()
            children.append(child)
            costs[child] = {
                'budget': float(row['Cost_budget'].strip()),
                'balanced': float(row['Cost_balanced'].strip()),
                'premium': float(row['Cost_premium'].strip())
            }
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children = int(params['max_children'])
    min_children = int(params['min_children'])
    fairness_penalty = float(params['fairness_penalty'])
    max_total_cost = float(params['max_total_cost'])
    min_children_per_mode = int(params['min_children_per_mode'])
    
    modes = ['budget', 'balanced', 'premium']
    
    # Big-M values
    M = 100000
    
    # Get max possible cost for big-M purposes
    max_cost_val = max(costs[c][m] for c in children for m in modes)
    
    model = gp.Model("ZhangFamilyTrip")
    model.setParam('OutputFlag', 0)
    
    # Binary variables: x[child] = 1 if child is selected
    x = {}
    for child in children:
        x[child] = model.addVar(vtype=GRB.BINARY, name=f"x_{child}")
    
    # Binary variables: y[mode] = 1 if mode is selected
    y = {}
    for mode in modes:
        y[mode] = model.addVar(vtype=GRB.BINARY, name=f"y_{mode}")
    
    # Exactly one mode must be selected
    model.addConstr(gp.quicksum(y[mode] for mode in modes) == 1, "one_mode")
    
    # Ginny must go
    model.addConstr(x['Ginny'] == 1, "Ginny_must_go")
    
    # Number of children constraints
    num_children = gp.quicksum(x[child] for child in children)
    model.addConstr(num_children <= max_children, "Max_children")
    model.addConstr(num_children >= min_children, "Min_children")
    
    # Compatibility constraints
    model.addConstr(x['Harry'] + x['Fred'] <= 1, "Harry_no_Fred")
    model.addConstr(x['Harry'] + x['George'] <= 1, "Harry_no_George")
    model.addConstr(x['George'] <= x['Fred'], "George_requires_Fred")
    model.addConstr(x['George'] <= x['Hermione'], "George_requires_Hermione")
    
    # Min children per mode for balanced and premium
    # If balanced or premium is selected, num_children >= min_children_per_mode
    # y['balanced'] => num_children >= min_children_per_mode
    # y['premium'] => num_children >= min_children_per_mode
    model.addConstr(num_children >= min_children_per_mode * (y['balanced'] + y['premium']), 
                    "min_children_higher_modes")
    
    # We need to model the effective cost of each child under the selected mode
    # effective_cost[child] = sum over modes: costs[child][mode] * y[mode] * x[child]
    # This is a product of two binary variables. We linearize with auxiliary variables.
    
    # z[child, mode] = x[child] * y[mode]
    z = {}
    for child in children:
        for mode in modes:
            z[child, mode] = model.addVar(vtype=GRB.BINARY, name=f"z_{child}_{mode}")
            model.addConstr(z[child, mode] <= x[child])
            model.addConstr(z[child, mode] <= y[mode])
            model.addConstr(z[child, mode] >= x[child] + y[mode] - 1)
    
    # effective_cost[child] = cost of child under selected mode, if child is selected; 0 otherwise
    eff_cost = {}
    for child in children:
        eff_cost[child] = model.addVar(lb=0, ub=max_cost_val, vtype=GRB.CONTINUOUS, 
                                        name=f"eff_cost_{child}")
        model.addConstr(eff_cost[child] == gp.quicksum(costs[child][mode] * z[child, mode] 
                                                         for mode in modes),
                        f"eff_cost_def_{child}")
    
    # Total monetary cost
    total_cost = model.addVar(lb=0, ub=max_total_cost + M, vtype=GRB.CONTINUOUS, name="total_cost")
    model.addConstr(total_cost == gp.quicksum(eff_cost[child] for child in children), "total_cost_def")
    
    # Max total cost constraint
    model.addConstr(total_cost <= max_total_cost, "max_total_cost_constr")
    
    # Fairness: spread = max_cost_among_selected - min_cost_among_selected
    # We need max and min of eff_cost among selected children only
    # For selected children, eff_cost[child] > 0; for unselected, eff_cost[child] = 0
    
    # We need the max and min cost among SELECTED children under the chosen mode
    # cost_if_selected[child] = costs[child][selected_mode] (the mode-specific cost, regardless of selection)
    # But we only care about spread among selected children.
    
    # Let's define:
    # mode_cost[child] = cost of child under selected mode (regardless of whether child is selected)
    mode_cost = {}
    for child in children:
        mode_cost[child] = model.addVar(lb=0, ub=max_cost_val, vtype=GRB.CONTINUOUS,
                                         name=f"mode_cost_{child}")
        model.addConstr(mode_cost[child] == gp.quicksum(costs[child][mode] * y[mode] for mode in modes),
                        f"mode_cost_def_{child}")
    
    # max_selected_cost >= mode_cost[child] for all selected children
    # min_selected_cost <= mode_cost[child] for all selected children
    max_sel_cost = model.addVar(lb=0, ub=max_cost_val, vtype=GRB.CONTINUOUS, name="max_sel_cost")
    min_sel_cost = model.addVar(lb=0, ub=max_cost_val, vtype=GRB.CONTINUOUS, name="min_sel_cost")
    
    for child in children:
        # max_sel_cost >= mode_cost[child] if child is selected
        # max_sel_cost >= mode_cost[child] - M*(1 - x[child])
        model.addConstr(max_sel_cost >= mode_cost[child] - M * (1 - x[child]),
                        f"max_sel_{child}")
        # min_sel_cost <= mode_cost[child] if child is selected
        # min_sel_cost <= mode_cost[child] + M*(1 - x[child])
        model.addConstr(min_sel_cost <= mode_cost[child] + M * (1 - x[child]),
                        f"min_sel_{child}")
    
    # We also need max_sel_cost <= mode_cost[child] + M*(1-x[child]) for tightness (it will be minimized naturally if penalty > 0)
    # And min_sel_cost >= mode_cost[child] - M*(1-x[child]) (it will be maximized naturally)
    # Since we're minimizing and fairness_penalty >= 0, spread = max_sel_cost - min_sel_cost will be pushed down
    # max_sel_cost will be pushed down and min_sel_cost pushed up naturally by the objective
    
    spread = model.addVar(lb=0, ub=max_cost_val, vtype=GRB.CONTINUOUS, name="spread")
    model.addConstr(spread == max_sel_cost - min_sel_cost, "spread_def")
    
    # Objective: minimize total_cost + fairness_penalty * spread
    obj = model.addVar(lb=-GRB.INFINITY, vtype=GRB.CONTINUOUS, name="obj")
    model.addConstr(obj == total_cost + fairness_penalty * spread, "obj_def")
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        # Print solution details
        selected_mode = None
        for mode in modes:
            if y[mode].X > 0.5:
                selected_mode = mode
                break
        
        print(f"Selected mode: {selected_mode}")
        for child in children:
            if x[child].X > 0.5:
                print(f"{child}: selected (cost={eff_cost[child].X})")
        
        print(f"Total cost: {total_cost.X}")
        print(f"Spread: {spread.X}")
        print(f"Fairness penalty contribution: {fairness_penalty * spread.X}")
        
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: INFEASIBLE")

if __name__ == "__main__":
    main()
