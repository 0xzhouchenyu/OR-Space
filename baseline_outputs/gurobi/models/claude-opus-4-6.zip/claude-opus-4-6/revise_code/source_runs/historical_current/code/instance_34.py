import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def load_goods_data(filepath):
    goods = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            goods[row['Goods_Type'].strip()] = {
                'quantity': int(row['Quantity'].strip()),
                'weight': float(row['Weight_per_Unit'].strip())
            }
    return goods

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

goods = load_goods_data(os.path.join(data_dir, 'table_1.csv'))
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

max_cap = params['max_container_capacity']  # 60
min_load = params['min_container_load']  # 18
min_d_per_container = int(params['min_d_goods_per_container'])  # 10
min_c_per_a = int(params['min_c_per_a'])  # 1
reduced_cap_E = 45  # reduced capacity when E is present

goods_types = list(goods.keys())
quantities = {g: goods[g]['quantity'] for g in goods_types}
weights = {g: goods[g]['weight'] for g in goods_types}

# Upper bound on containers
max_containers = 15

N = range(max_containers)

model = gp.Model("ContainerMinimization")
model.setParam('OutputFlag', 0)
model.setParam('TimeLimit', 120)

# Decision variables
x = {}
for g in goods_types:
    for j in N:
        x[g, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{g}_{j}")

y = {}
for j in N:
    y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")

# z[j] = 1 if container j has A goods
z = {}
for j in N:
    z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{j}")

# e[j] = 1 if container j has E goods
e = {}
for j in N:
    e[j] = model.addVar(vtype=GRB.BINARY, name=f"e_{j}")

model.update()

# Objective: minimize number of containers
model.setObjective(gp.quicksum(y[j] for j in N), GRB.MINIMIZE)

# All goods must be transported
for g in goods_types:
    model.addConstr(gp.quicksum(x[g, j] for j in N) == quantities[g], name=f"demand_{g}")

# Container capacity constraint (standard)
for j in N:
    model.addConstr(
        gp.quicksum(weights[g] * x[g, j] for g in goods_types) <= max_cap * y[j],
        name=f"max_cap_{j}"
    )

# Reduced capacity when E is present
# If e[j]=1, capacity is 45 instead of 60
# sum(w*x) <= 60*y - (60-45)*e = 60*y - 15*e
for j in N:
    model.addConstr(
        gp.quicksum(weights[g] * x[g, j] for g in goods_types) <= max_cap * y[j] - (max_cap - reduced_cap_E) * e[j],
        name=f"reduced_cap_E_{j}"
    )

# Link e[j] to presence of E goods
M_E = quantities['E']
for j in N:
    # If x[E,j] > 0 then e[j] = 1
    model.addConstr(x['E', j] <= M_E * e[j], name=f"E_indicator_{j}")
    # If e[j] = 1 then x[E,j] >= 1 (optional but tightens)
    # Actually e[j] can be 1 even if no E, but that would only hurt objective indirectly via capacity
    # To be safe, let's not force e[j]=0 when no E, the solver will figure it out
    # But for correctness, e[j] should only be 1 when E is present
    # Actually, since reducing capacity is a penalty, solver will naturally set e[j]=0 when possible
    # So the linking x[E,j] <= M_E * e[j] is sufficient

# Minimum load constraint
for j in N:
    model.addConstr(
        gp.quicksum(weights[g] * x[g, j] for g in goods_types) >= min_load * y[j],
        name=f"min_load_{j}"
    )

# Minimum D goods per container (if container is used)
for j in N:
    model.addConstr(x['D', j] >= min_d_per_container * y[j], name=f"min_D_{j}")

# If A goods are loaded, at least min_c_per_a C goods must be loaded
M_A = quantities['A']
for j in N:
    model.addConstr(x['A', j] <= M_A * z[j], name=f"A_indicator_{j}")
    model.addConstr(x['C', j] >= min_c_per_a * z[j], name=f"C_if_A_{j}")

# Upper bounds on variables
for g in goods_types:
    for j in N:
        model.addConstr(x[g, j] <= quantities[g] * y[j], name=f"ub_{g}_{j}")

# Symmetry breaking
for j in range(len(N) - 1):
    model.addConstr(y[j] >= y[j + 1], name=f"symmetry_{j}")

model.optimize()

if model.status == GRB.OPTIMAL or model.status == GRB.SUBOPTIMAL:
    obj_val = model.objVal
    for j in N:
        if y[j].X > 0.5:
            contents = {}
            for g in goods_types:
                val = x[g, j].X
                if val > 0.5:
                    contents[g] = int(round(val))
            total_w = sum(weights[g] * x[g, j].X for g in goods_types)
            has_e = "E-fragile" if e[j].X > 0.5 else ""
            print(f"  Container {j}: {contents}, weight={total_w:.1f} {has_e}")
    print(f"FINAL_OBJ_VALUE: {int(round(obj_val))}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
