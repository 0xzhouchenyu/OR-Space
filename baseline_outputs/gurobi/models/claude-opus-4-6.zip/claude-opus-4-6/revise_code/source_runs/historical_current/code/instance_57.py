import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read orders
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
    
    # Read parameters
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    std_widths = []
    pattern_setup_penalty = 0
    wide_roll_threshold_width = 0
    wide_roll_extra_setup_penalty = 0
    
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            value = float(row['Value'])
            if 'standard_width' in name:
                std_widths.append(value)
            elif name == 'pattern_setup_penalty':
                pattern_setup_penalty = value
            elif name == 'wide_roll_threshold_width':
                wide_roll_threshold_width = value
            elif name == 'wide_roll_extra_setup_penalty':
                wide_roll_extra_setup_penalty = value
    
    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    n_orders = len(orders)
    
    total_required_area = sum(w * l for w, l in zip(widths, lengths))
    
    # Generate cutting patterns for each standard width
    patterns_by_std_width = {}
    for idx, sw in enumerate(std_widths):
        patterns = []
        
        def build_pattern(index, current_pattern, current_sum):
            if index == n_orders:
                if any(c > 0 for c in current_pattern):
                    patterns.append(list(current_pattern))
                return
            max_count = int(math.floor((sw - current_sum + 1e-7) / widths[index]))
            for count in range(max_count + 1):
                current_pattern.append(count)
                build_pattern(index + 1, current_pattern, current_sum + count * widths[index])
                current_pattern.pop()
        
        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {'sw': sw, 'patterns': patterns}
    
    # Create model
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[idx, i] = length of standard roll idx cut using pattern i (continuous)
    # y[idx, i] = binary indicator whether pattern i on standard roll idx is used
    x_vars = {}
    y_vars = {}
    
    # Big-M for linking x and y
    # Upper bound on x: the maximum length needed for any single pattern
    # A safe upper bound is the sum of all order lengths
    M = sum(lengths) + 1
    
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            x_vars[(idx, i)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{idx}_{i}")
            y_vars[(idx, i)] = model.addVar(vtype=GRB.BINARY, name=f"y_{idx}_{i}")
    
    model.update()
    
    # Objective: Minimize waste = total area used + setup penalties - required area
    # Total area used = sum of sw * x[idx,i] for all patterns
    # Setup penalty for each used pattern = pattern_setup_penalty * y[idx,i]
    # Additional wide-roll penalty for patterns on rolls >= wide_roll_threshold_width
    # Waste = total_area_used + penalties - total_required_area
    # But we minimize total cost (area + penalties), then subtract required area for waste
    
    obj_expr = gp.LinExpr()
    
    for idx, data in patterns_by_std_width.items():
        sw = data['sw']
        for i, p in enumerate(data['patterns']):
            # Area contribution
            obj_expr += sw * x_vars[(idx, i)]
            # Pattern setup penalty
            obj_expr += pattern_setup_penalty * y_vars[(idx, i)]
            # Wide roll extra setup penalty
            if sw >= wide_roll_threshold_width:
                obj_expr += wide_roll_extra_setup_penalty * y_vars[(idx, i)]
    
    # Subtract required area to get waste
    # Actually, let's minimize the total cost and then compute waste = obj - required_area
    # But the objective should be waste = total_area_used + penalties - required_area
    # Since required_area is constant, minimizing (total_area_used + penalties) is equivalent
    
    model.setObjective(obj_expr, GRB.MINIMIZE)
    
    # Constraints: Satisfy length requirements for each order
    for j in range(n_orders):
        model.addConstr(
            gp.quicksum(p[j] * x_vars[(idx, i)] 
                       for idx, data in patterns_by_std_width.items() 
                       for i, p in enumerate(data['patterns'])) >= lengths[j],
            name=f"demand_{j}"
        )
    
    # Linking constraints: x[idx,i] <= M * y[idx,i]
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            model.addConstr(x_vars[(idx, i)] <= M * y_vars[(idx, i)],
                          name=f"link_{idx}_{i}")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        total_obj = model.objVal
        waste = total_obj - total_required_area
        print(f"FINAL_OBJ_VALUE: {round(waste, 4)}")
    else:
        print(f"FINAL_OBJ_VALUE: NO_SOLUTION (status={model.status})")

if __name__ == "__main__":
    solve()
