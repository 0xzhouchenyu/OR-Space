import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        
        bandwidth = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                bandwidth[(row_node, col_node)] = bw
    
    source = 'A'
    intermediate = 'C'
    target = 'E'
    
    # Build list of valid arcs (bandwidth > 0)
    arcs = []
    cost = {}
    for (i, j), bw in bandwidth.items():
        if bw > 0:
            arcs.append((i, j))
            cost[(i, j)] = 100 - bw
    
    # We need to find a simple path from A to E passing through C.
    # Decompose: path from A to C, then C to E, no repeated nodes.
    # 
    # Model as MIP: two flow layers.
    # Layer 1: flow from A to C (flow of 1 unit)
    # Layer 2: flow from C to E (flow of 1 unit)
    # Each node can be visited at most once across both layers.
    # Minimize total cost of arcs used.
    
    model = gp.Model('min_cost_routing')
    model.setParam('OutputFlag', 0)
    
    # Binary variables for arc usage in each layer
    x1 = {}  # Layer 1: A -> C
    x2 = {}  # Layer 2: C -> E
    for (i, j) in arcs:
        x1[(i, j)] = model.addVar(vtype=GRB.BINARY, name=f'x1_{i}_{j}')
        x2[(i, j)] = model.addVar(vtype=GRB.BINARY, name=f'x2_{i}_{j}')
    
    # Node visit variables
    y = {}
    for n in nodes:
        y[n] = model.addVar(vtype=GRB.BINARY, name=f'y_{n}')
    
    model.update()
    
    # Flow conservation for layer 1 (A -> C)
    for n in nodes:
        outflow1 = gp.quicksum(x1[(n, j)] for (i, j) in arcs if i == n)
        inflow1 = gp.quicksum(x1[(i, n)] for (i, j) in arcs if j == n)
        if n == source:
            model.addConstr(outflow1 - inflow1 == 1, name=f'flow1_{n}')
        elif n == intermediate:
            model.addConstr(outflow1 - inflow1 == -1, name=f'flow1_{n}')
        else:
            model.addConstr(outflow1 - inflow1 == 0, name=f'flow1_{n}')
    
    # Flow conservation for layer 2 (C -> E)
    for n in nodes:
        outflow2 = gp.quicksum(x2[(n, j)] for (i, j) in arcs if i == n)
        inflow2 = gp.quicksum(x2[(i, n)] for (i, j) in arcs if j == n)
        if n == intermediate:
            model.addConstr(outflow2 - inflow2 == 1, name=f'flow2_{n}')
        elif n == target:
            model.addConstr(outflow2 - inflow2 == -1, name=f'flow2_{n}')
        else:
            model.addConstr(outflow2 - inflow2 == 0, name=f'flow2_{n}')
    
    # Node visit: a node is visited if any arc in either layer uses it
    for n in nodes:
        total_usage = gp.quicksum(x1[(i, j)] + x2[(i, j)] for (i, j) in arcs if i == n or j == n)
        # If node is used, y[n] = 1
        model.addConstr(total_usage <= len(arcs) * y[n], name=f'visit_{n}')
    
    # No repeated nodes (simple path): each node except A, C, E can appear in at most one layer
    # More precisely, for nodes other than A, C, E: total flow through them across both layers <= 1
    # For A: only in layer 1 (as source), should not appear in layer 2
    # For E: only in layer 2 (as sink), should not appear in layer 1
    # For C: endpoint of layer 1, start of layer 2 - ok
    
    for n in nodes:
        # Layer 1 usage of node n (as intermediate, i.e., flow through)
        through1 = gp.quicksum(x1[(i, n)] for (i, j_) in arcs if j_ == n)
        through2 = gp.quicksum(x2[(i, n)] for (i, j_) in arcs if j_ == n)
        
        if n == source:
            # A should not be visited in layer 2
            model.addConstr(through2 == 0, name=f'no_A_in_layer2')
            # Also no incoming to A in layer 1 (simple path)
            # Actually flow conservation handles it but let's ensure simplicity
        elif n == target:
            # E should not be visited in layer 1
            in1 = gp.quicksum(x1[(i, n)] for (i, j_) in arcs if j_ == n)
            out1 = gp.quicksum(x1[(n, j_)] for (i, j_) in arcs if i == n)
            model.addConstr(in1 == 0, name=f'no_E_in_layer1_in')
            model.addConstr(out1 == 0, name=f'no_E_in_layer1_out')
        elif n == intermediate:
            # C is endpoint of layer 1 and start of layer 2, that's fine
            # No outgoing from C in layer 1 (it's the sink)
            # No incoming to C in layer 2 (it's the source)
            # Flow conservation already handles this, but to be safe:
            pass
        else:
            # For other nodes (B, D): can be used in at most one of the two layers
            used_in_1 = gp.quicksum(x1[(i, j)] for (i, j) in arcs if i == n or j == n)
            used_in_2 = gp.quicksum(x2[(i, j)] for (i, j) in arcs if i == n or j == n)
            z1 = model.addVar(vtype=GRB.BINARY, name=f'z1_{n}')
            z2 = model.addVar(vtype=GRB.BINARY, name=f'z2_{n}')
            model.addConstr(used_in_1 <= len(arcs) * z1)
            model.addConstr(used_in_2 <= len(arcs) * z2)
            model.addConstr(z1 + z2 <= 1, name=f'exclusive_{n}')
    
    # Objective: minimize total routing cost
    obj = gp.quicksum(cost[(i, j)] * (x1[(i, j)] + x2[(i, j)]) for (i, j) in arcs)
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        
        # Print the path
        print("Layer 1 arcs (A->C):")
        for (i, j) in arcs:
            if x1[(i, j)].X > 0.5:
                print(f"  {i} -> {j}, cost = {cost[(i,j)]}")
        
        print("Layer 2 arcs (C->E):")
        for (i, j) in arcs:
            if x2[(i, j)].X > 0.5:
                print(f"  {i} -> {j}, cost = {cost[(i,j)]}")
        
        print(f"Total minimum routing cost: {obj_val}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == '__main__':
    main()
