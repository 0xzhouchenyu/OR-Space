import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read table_1.csv
    workshops = []
    capacities = {}
    rates = {}

    filepath = os.path.join(data_dir, "table_1.csv")
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())

    # Read general_parameters.csv
    params = {}
    filepath = os.path.join(data_dir, "general_parameters.csv")
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val

    components = [1, 2, 3]
    shifts = ['day', 'night']

    # Extract parameters
    regular_limit = {}
    overtime_cap = {}
    bigM = {}
    for w in workshops:
        for s in shifts:
            regular_limit[(w, s)] = params[f'regular_hours_limit_{s}_{w}']
            overtime_cap[(w, s)] = params[f'overtime_capacity_{s}_{w}']
        bigM[w] = params[f'bigM_shift_{w}']

    penalty_night = params['penalty_night_hour']
    penalty_overtime = params['penalty_overtime_hour']
    penalty_shortage = params['penalty_shortage_per_unit']
    z_target = params['z_target']

    # Create model
    model = gp.Model("Revised_Product_Maximization")
    model.setParam('OutputFlag', 0)

    # Decision variables:
    # x_reg[(w, s, c)] = regular hours workshop w allocates to component c in shift s
    # x_ot[(w, s, c)] = overtime hours workshop w allocates to component c in shift s
    x_reg = {}
    x_ot = {}
    for w in workshops:
        for s in shifts:
            for c in components:
                x_reg[(w, s, c)] = model.addVar(lb=0, name=f"x_reg_{w}_{s}_{c}")
                x_ot[(w, s, c)] = model.addVar(lb=0, name=f"x_ot_{w}_{s}_{c}")

    # Binary variables: y[(w, s)] = 1 if workshop w is active in shift s
    y = {}
    for w in workshops:
        for s in shifts:
            y[(w, s)] = model.addVar(vtype=GRB.BINARY, name=f"y_{w}_{s}")

    # z = number of completed products
    z = model.addVar(lb=0, name="z")

    # shortage variable
    shortage = model.addVar(lb=0, name="shortage")

    model.update()

    # Objective: maximize z - penalties
    # Penalties: night regular hours, all overtime hours, shortage below z_target
    total_night_regular = gp.quicksum(
        x_reg[(w, 'night', c)] for w in workshops for c in components
    )
    total_overtime = gp.quicksum(
        x_ot[(w, s, c)] for w in workshops for s in shifts for c in components
    )

    model.setObjective(
        z - penalty_night * total_night_regular - penalty_overtime * total_overtime - penalty_shortage * shortage,
        GRB.MAXIMIZE
    )

    # Constraints:

    # 1. Regular hours capacity per workshop per shift
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x_reg[(w, s, c)] for c in components) <= regular_limit[(w, s)],
                name=f"reg_cap_{w}_{s}"
            )

    # 2. Overtime capacity per workshop per shift
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x_ot[(w, s, c)] for c in components) <= overtime_cap[(w, s)],
                name=f"ot_cap_{w}_{s}"
            )

    # 3. Total hours per workshop (regular + overtime across both shifts) <= Production_Capacity_hours
    for w in workshops:
        model.addConstr(
            gp.quicksum(x_reg[(w, s, c)] + x_ot[(w, s, c)] for s in shifts for c in components) <= capacities[w],
            name=f"total_cap_{w}"
        )

    # 4. z <= total production of each component (across all workshops, shifts, regular+overtime)
    for c in components:
        model.addConstr(
            z <= gp.quicksum(
                rates[(w, c)] * (x_reg[(w, s, c)] + x_ot[(w, s, c)])
                for w in workshops for s in shifts
            ),
            name=f"min_component_{c}"
        )

    # 5. Shortage: shortage >= z_target - z
    model.addConstr(shortage >= z_target - z, name="shortage_def")

    # 6. Linking active indicator to hours (big-M): if workshop w works in shift s, y[(w,s)]=1
    for w in workshops:
        for s in shifts:
            model.addConstr(
                gp.quicksum(x_reg[(w, s, c)] + x_ot[(w, s, c)] for c in components) <= bigM[w] * y[(w, s)],
                name=f"bigM_link_{w}_{s}"
            )

    # 7. No more than two workshops active in the same shift
    for s in shifts:
        model.addConstr(
            gp.quicksum(y[(w, s)] for w in workshops) <= 2,
            name=f"max_active_{s}"
        )

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL or model.status == GRB.SUBOPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val:.6f}")
    else:
        print(f"FINAL_OBJ_VALUE: infeasible or unbounded (status={model.status})")

if __name__ == "__main__":
    main()
