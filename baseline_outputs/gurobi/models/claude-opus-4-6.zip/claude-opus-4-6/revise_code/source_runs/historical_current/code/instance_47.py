import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    return headers, rows

def load_general_parameters(filename='general_parameters.csv'):
    headers, rows = load_csv(filename)
    params = {}
    for row in rows:
        name = row[0].strip()
        try:
            value = float(row[1].strip())
        except ValueError:
            value = row[1].strip()
        params[name] = value
    return params

def load_crop_data(filename='table_1.csv'):
    headers, rows = load_csv(filename)
    crops = [h.strip() for h in headers[1:]]
    data = {}
    for row in rows:
        item = row[0].strip()
        values = [float(v.strip()) for v in row[1:]]
        data[item] = dict(zip(crops, values))
    return crops, data

def main():
    params = load_general_parameters()
    crops, crop_data = load_crop_data()

    # General parameters
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']

    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = int(params['max_chickens'])
    max_dairy_cows = int(params['max_dairy_cows'])

    # New biosecurity parameters
    fixed_cost_chicken_setup = params['fixed_cost_chicken_setup']
    min_chickens_if_coop_open = params['min_chickens_if_coop_open']
    second_biosecurity_threshold = params['second_biosecurity_threshold']
    second_biosecurity_cost = params['second_biosecurity_cost']
    biosecurity_training_aw_days = params['biosecurity_training_aw_days']
    biosecurity_training_ss_days = params['biosecurity_training_ss_days']

    # Crop data
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']

    # Create model
    m = gp.Model("Farm_Optimization")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # Crop areas (continuous)
    x = {}
    for c in crops:
        x[c] = m.addVar(lb=0, name=f"x_{c}")

    # Number of dairy cows (continuous, bounded)
    y_dairy = m.addVar(lb=0, ub=max_dairy_cows, name="dairy_cows")

    # Number of chickens (continuous, bounded)
    y_chicken = m.addVar(lb=0, ub=max_chickens, name="chickens")

    # Binary: is the coop open?
    z_coop = m.addVar(vtype=GRB.BINARY, name="coop_open")

    # Binary: is flock above second biosecurity threshold?
    z_second = m.addVar(vtype=GRB.BINARY, name="second_biosecurity")

    # Surplus labor for external work
    surplus_aw = m.addVar(lb=0, name="surplus_aw")
    surplus_ss = m.addVar(lb=0, name="surplus_ss")

    m.update()

    # Objective: maximize net income from crops + animals + external work - fixed costs
    obj = gp.quicksum(crop_income[c] * x[c] for c in crops) + \
          income_dairy * y_dairy + income_chicken * y_chicken + \
          ext_rate_aw * surplus_aw + ext_rate_ss * surplus_ss - \
          fixed_cost_chicken_setup * z_coop - \
          second_biosecurity_cost * z_second

    m.setObjective(obj, GRB.MAXIMIZE)

    # Land constraint
    m.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, "Land")

    # Funds constraint (investment for animals only, as in original)
    m.addConstr(inv_dairy * y_dairy + inv_chicken * y_chicken <= funds_available, "Funds")

    # Labor autumn/winter constraint
    # When coop is open, biosecurity training consumes labor before external work can be sold
    m.addConstr(
        gp.quicksum(crop_aw[c] * x[c] for c in crops) +
        labor_aw_dairy * y_dairy +
        labor_aw_chicken * y_chicken +
        biosecurity_training_aw_days * z_coop +
        surplus_aw <= labor_aw,
        "Labor_AW"
    )

    # Labor spring/summer constraint
    m.addConstr(
        gp.quicksum(crop_ss[c] * x[c] for c in crops) +
        labor_ss_dairy * y_dairy +
        labor_ss_chicken * y_chicken +
        biosecurity_training_ss_days * z_coop +
        surplus_ss <= labor_ss,
        "Labor_SS"
    )

    # Chicken coop logic:
    # If coop is open (z_coop=1), chickens >= min_chickens_if_coop_open
    # If coop is closed (z_coop=0), chickens = 0
    # y_chicken <= max_chickens * z_coop
    m.addConstr(y_chicken <= max_chickens * z_coop, "Coop_open_link")
    # y_chicken >= min_chickens_if_coop_open * z_coop
    m.addConstr(y_chicken >= min_chickens_if_coop_open * z_coop, "Min_flock")

    # Second biosecurity threshold:
    # z_second = 1 if y_chicken > second_biosecurity_threshold
    # Since this is a gate: if flock exceeds threshold, must pay additional cost
    # y_chicken <= second_biosecurity_threshold + (max_chickens - second_biosecurity_threshold) * z_second
    m.addConstr(
        y_chicken <= second_biosecurity_threshold + (max_chickens - second_biosecurity_threshold) * z_second,
        "Second_bio_link"
    )
    # z_second can only be 1 if coop is open
    m.addConstr(z_second <= z_coop, "Second_bio_requires_coop")

    # Solve
    m.optimize()

    if m.status == GRB.OPTIMAL:
        obj_val = m.ObjVal
        for c in crops:
            print(f"{c}: {x[c].X:.4f} hectares")
        print(f"Dairy cows: {y_dairy.X:.4f}")
        print(f"Chickens: {y_chicken.X:.4f}")
        print(f"Coop open: {z_coop.X:.0f}")
        print(f"Second biosecurity: {z_second.X:.0f}")
        print(f"Surplus labor AW: {surplus_aw.X:.4f} person-days")
        print(f"Surplus labor SS: {surplus_ss.X:.4f} person-days")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {m.status}")
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
