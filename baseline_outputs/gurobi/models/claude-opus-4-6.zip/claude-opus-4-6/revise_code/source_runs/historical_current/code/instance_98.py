import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    available_steel = params['available_steel']
    available_aluminum = params['available_aluminum']
    available_labor = params['available_labor']
    overtime_pay = params['overtime_pay']
    max_overtime = params['max_overtime']
    overtime_review_threshold = params['overtime_review_threshold']
    overtime_review_fee = params['overtime_review_fee']
    product_A_line_audit_threshold = params['product_A_line_audit_threshold']
    product_A_line_audit_fee = params['product_A_line_audit_fee']
    
    # Build product info
    prod_info = {}
    for p in products:
        prod_info[p['Product']] = {
            'steel': float(p['Steel_Required_kg']),
            'aluminum': float(p['Aluminum_Required_kg']),
            'labor': float(p['Labor_Required_hours']),
            'profit': float(p['Profit_yuan']),
            'setup_cost': float(p['Setup_Cost_yuan'])
        }
    
    # Create model
    model = gp.Model("Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Production quantities (continuous, non-negative)
    x = {}
    for pname in prod_info:
        x[pname] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{pname}")
    
    # Binary variable: whether each product is produced (for setup cost)
    y = {}
    for pname in prod_info:
        y[pname] = model.addVar(vtype=GRB.BINARY, name=f"y_{pname}")
    
    # Overtime hours (continuous, non-negative)
    overtime = model.addVar(lb=0, ub=max_overtime, vtype=GRB.CONTINUOUS, name="overtime")
    
    # Binary: whether overtime exceeds the review threshold
    z_overtime = model.addVar(vtype=GRB.BINARY, name="z_overtime_review")
    
    # Binary: whether Product A exceeds line audit threshold
    z_line_audit = model.addVar(vtype=GRB.BINARY, name="z_line_audit")
    
    model.update()
    
    # Big-M values
    # Max possible production for any product (upper bound)
    M_prod = 1000  # sufficiently large
    
    # Link production to binary setup variables
    for pname in prod_info:
        model.addConstr(x[pname] <= M_prod * y[pname], name=f"setup_link_{pname}")
    
    # Steel constraint
    model.addConstr(
        gp.quicksum(prod_info[pname]['steel'] * x[pname] for pname in prod_info) <= available_steel,
        name="Steel"
    )
    
    # Aluminum constraint
    model.addConstr(
        gp.quicksum(prod_info[pname]['aluminum'] * x[pname] for pname in prod_info) <= available_aluminum,
        name="Aluminum"
    )
    
    # Labor constraint: total labor <= available_labor + overtime
    total_labor = gp.quicksum(prod_info[pname]['labor'] * x[pname] for pname in prod_info)
    model.addConstr(total_labor <= available_labor + overtime, name="Labor")
    
    # Overtime review threshold logic:
    # If overtime > overtime_review_threshold, then z_overtime = 1 (pay review fee)
    # If overtime <= overtime_review_threshold, then z_overtime = 0
    # overtime <= overtime_review_threshold + max_overtime * z_overtime
    # overtime >= (overtime_review_threshold + epsilon) * z_overtime
    # Use: overtime - overtime_review_threshold <= max_overtime * z_overtime
    #      overtime - overtime_review_threshold >= epsilon * z_overtime - (1 - z_overtime) * overtime_review_threshold
    # Simpler big-M formulation:
    # overtime <= overtime_review_threshold + max_overtime * z_overtime
    # overtime >= overtime_review_threshold + 0.0001 - (1 - z_overtime) * (overtime_review_threshold + 0.0001)
    # Actually, let's be careful. We want:
    # z_overtime = 1 if overtime > overtime_review_threshold, 0 otherwise
    # But since we're maximizing profit (minimizing costs), the model will naturally set z_overtime=0 if possible.
    # We need: if overtime > threshold => z_overtime = 1
    # overtime - threshold <= M * z_overtime  (M = max_overtime)
    # And we want z_overtime=0 to be allowed only when overtime <= threshold
    # This constraint alone suffices because the fee incentivizes z_overtime=0
    
    eps = 1e-4
    model.addConstr(overtime - overtime_review_threshold <= max_overtime * z_overtime, name="overtime_review_trigger")
    # Also need: z_overtime can only be 1 if overtime > threshold (optional, but helps correctness)
    # Actually for cost minimization, the model won't set z_overtime=1 unnecessarily, so the above is sufficient.
    
    # Product A line audit threshold logic:
    # If x_A > 29, then z_line_audit = 1 (pay line audit fee)
    # x_A - product_A_line_audit_threshold <= M * z_line_audit
    model.addConstr(x['A'] - product_A_line_audit_threshold <= M_prod * z_line_audit, name="line_audit_trigger")
    
    # Objective: maximize profit - setup costs - overtime cost - review fees - line audit fee
    profit = gp.quicksum(prod_info[pname]['profit'] * x[pname] for pname in prod_info)
    setup_costs = gp.quicksum(prod_info[pname]['setup_cost'] * y[pname] for pname in prod_info)
    overtime_cost = overtime_pay * overtime
    review_cost = overtime_review_fee * z_overtime
    line_audit_cost = product_A_line_audit_fee * z_line_audit
    
    model.setObjective(profit - setup_costs - overtime_cost - review_cost - line_audit_cost, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        for pname in prod_info:
            print(f"{pname}: {x[pname].X}")
        print(f"Overtime: {overtime.X}")
        for pname in prod_info:
            print(f"Setup {pname}: {y[pname].X}")
        print(f"Overtime review triggered: {z_overtime.X}")
        print(f"Line audit triggered: {z_line_audit.X}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
