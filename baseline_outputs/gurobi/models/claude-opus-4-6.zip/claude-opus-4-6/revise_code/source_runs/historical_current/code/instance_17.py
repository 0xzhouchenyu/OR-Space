import os
import csv
import itertools
from gurobipy import GRB
import gurobipy as gp

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    parts = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
    
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    return parts, params

def fuel_per_heavy_bomb(distance, params):
    eff_heavy = params['fuel_efficiency_heavy_bomb']
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    return distance / eff_heavy + distance / eff_empty + takeoff_landing

def fuel_per_light_bomb(distance, params):
    eff_light = params['fuel_efficiency_light_bomb']
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    return distance / eff_light + distance / eff_empty + takeoff_landing

def prob_destroy_part(x_heavy, x_light, p_heavy, p_light):
    return 1.0 - (1.0 - p_heavy) ** x_heavy * (1.0 - p_light) ** x_light

def prob_at_least_k(probs, k):
    n = len(probs)
    dp = [0.0] * (n + 1)
    dp[0] = 1.0
    for i in range(n):
        new_dp = [0.0] * (n + 1)
        for j in range(i + 2):
            new_dp[j] += dp[j] * (1.0 - probs[i])
            if j > 0:
                new_dp[j] += dp[j - 1] * probs[i]
        dp = new_dp
    return sum(dp[j] for j in range(k, n + 1))

def main():
    parts, params = load_data()
    
    max_heavy = int(params['max_heavy_bombs'])
    max_light = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts = int(params['min_parts_destroyed'])
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    sortie_fuel_overhead_A = params['sortie_fuel_overhead_A']
    sortie_fuel_overhead_B = params['sortie_fuel_overhead_B']
    scenario_prob_A = params['scenario_prob_A']
    scenario_prob_B = params['scenario_prob_B']
    
    n = len(parts)
    
    # Fuel costs per bomb type per part (base: distance-based + takeoff/landing)
    fuel_h_base = [fuel_per_heavy_bomb(p['distance'], params) for p in parts]
    fuel_l_base = [fuel_per_light_bomb(p['distance'], params) for p in parts]
    
    # Total sorties constraint: must fit in both scenarios
    max_sorties = min(max_sorties_A, max_sorties_B)
    
    # For scenario A: fuel per sortie = base fuel + sortie_fuel_overhead_A
    # For scenario B: fuel per sortie = base fuel + sortie_fuel_overhead_B
    # Both must be <= fuel_limit
    
    # Since this is a nonlinear objective (probability calculation), we'll use enumeration
    # similar to the original heuristic but with updated constraints.
    
    # The total number of sorties = sum of all bombs allocated
    # Constraints:
    # 1. sum(xh[i] + xl[i]) <= max_sorties (min of A and B)
    # 2. sum(xh[i]) <= max_heavy
    # 3. sum(xl[i]) <= max_light
    # 4. Fuel scenario A: sum(xh[i] * (fuel_h_base[i] + overhead_A) + xl[i] * (fuel_l_base[i] + overhead_A)) <= fuel_limit
    # 5. Fuel scenario B: sum(xh[i] * (fuel_h_base[i] + overhead_B) + xl[i] * (fuel_l_base[i] + overhead_B)) <= fuel_limit
    
    # Fuel per bomb in each scenario
    fuel_h_A = [fuel_h_base[i] + sortie_fuel_overhead_A for i in range(n)]
    fuel_l_A = [fuel_l_base[i] + sortie_fuel_overhead_A for i in range(n)]
    fuel_h_B = [fuel_h_base[i] + sortie_fuel_overhead_B for i in range(n)]
    fuel_l_B = [fuel_l_base[i] + sortie_fuel_overhead_B for i in range(n)]
    
    # Since the objective is nonlinear (product of probabilities), we use exhaustive search
    # with pruning, similar to the original heuristic.
    
    best_obj = 0.0
    best_alloc = None
    alloc = []
    
    def evaluate(candidate):
        probs = [
            prob_destroy_part(candidate[i][0], candidate[i][1], parts[i]['p_heavy'], parts[i]['p_light'])
            for i in range(n)
        ]
        return prob_at_least_k(probs, min_parts)
    
    def search(idx, remaining_heavy, remaining_light, remaining_fuel_A, remaining_fuel_B, remaining_sorties):
        nonlocal best_obj, best_alloc
        if idx == n:
            obj = evaluate(alloc)
            if obj > best_obj:
                best_obj = obj
                best_alloc = list(alloc)
            return
        
        # Upper bounds for this part
        max_h_here = min(remaining_heavy, remaining_sorties,
                         int(remaining_fuel_A / fuel_h_A[idx]) if fuel_h_A[idx] > 0 else remaining_heavy,
                         int(remaining_fuel_B / fuel_h_B[idx]) if fuel_h_B[idx] > 0 else remaining_heavy)
        
        for xh in range(max_h_here + 1):
            fuel_used_h_A = xh * fuel_h_A[idx]
            fuel_used_h_B = xh * fuel_h_B[idx]
            if fuel_used_h_A > remaining_fuel_A or fuel_used_h_B > remaining_fuel_B:
                break
            
            sorties_left_after_h = remaining_sorties - xh
            fuel_left_A_after_h = remaining_fuel_A - fuel_used_h_A
            fuel_left_B_after_h = remaining_fuel_B - fuel_used_h_B
            
            max_l_here = min(remaining_light, sorties_left_after_h,
                             int(fuel_left_A_after_h / fuel_l_A[idx]) if fuel_l_A[idx] > 0 else remaining_light,
                             int(fuel_left_B_after_h / fuel_l_B[idx]) if fuel_l_B[idx] > 0 else remaining_light)
            
            for xl in range(max_l_here + 1):
                fuel_used_l_A = xl * fuel_l_A[idx]
                fuel_used_l_B = xl * fuel_l_B[idx]
                if fuel_used_l_A > fuel_left_A_after_h or fuel_used_l_B > fuel_left_B_after_h:
                    break
                
                alloc.append((xh, xl))
                search(
                    idx + 1,
                    remaining_heavy - xh,
                    remaining_light - xl,
                    fuel_left_A_after_h - fuel_used_l_A,
                    fuel_left_B_after_h - fuel_used_l_B,
                    sorties_left_after_h - xl,
                )
                alloc.pop()
    
    search(0, max_heavy, max_light, fuel_limit, fuel_limit, max_sorties)
    
    # The objective: since the plan must work in both scenarios and the damage probabilities
    # don't depend on the scenario (same bombs hit same targets), the mission success probability
    # is the same regardless of which fleet flies. The scenario weights just weight the same value.
    # So objective = scenario_prob_A * P(success) + scenario_prob_B * P(success) = P(success)
    # since scenario_prob_A + scenario_prob_B = 1.
    
    # Actually, re-reading: "maximize expected mission-success probability weighted by scenario probabilities"
    # Since the allocation is the same and damage probs are the same, the success prob is identical
    # in both scenarios. So weighted objective = P(success).
    
    final_obj = best_obj
    
    if best_alloc is not None:
        total_heavy = sum(item[0] for item in best_alloc)
        total_light = sum(item[1] for item in best_alloc)
        total_fuel_A = sum(best_alloc[i][0] * fuel_h_A[i] + best_alloc[i][1] * fuel_l_A[i] for i in range(n))
        total_fuel_B = sum(best_alloc[i][0] * fuel_h_B[i] + best_alloc[i][1] * fuel_l_B[i] for i in range(n))
        total_sorties = total_heavy + total_light
    
    print(f"FINAL_OBJ_VALUE: {final_obj:.6f}")

if __name__ == '__main__':
    main()
