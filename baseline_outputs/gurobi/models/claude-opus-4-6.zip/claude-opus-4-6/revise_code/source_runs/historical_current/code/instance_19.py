import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value_str = row['Value'].strip()
        try:
            value = int(value_str)
        except ValueError:
            try:
                value = float(value_str)
            except ValueError:
                value = value_str
        params[name] = value

# Extract parameters
cost_A = params['cost_per_chair_A']
cost_B = params['cost_per_chair_B']
cost_C = params['cost_per_chair_C']
chairs_per_order_A = params['chairs_per_order_A']
chairs_per_order_B = params['chairs_per_order_B']
chairs_per_order_C = params['chairs_per_order_C']
min_total = params['min_total_chairs']
max_total = params['max_total_chairs']
min_chairs_B_if_A = params['min_chairs_B_if_A']
dependency_B_C = params['dependency_B_C']

fixed_fee_A_regular = params['fixed_fee_A_regular']
fixed_fee_A_express = params['fixed_fee_A_express']
fixed_fee_B_regular = params['fixed_fee_B_regular']
fixed_fee_B_express = params['fixed_fee_B_express']
fixed_fee_C_regular = params['fixed_fee_C_regular']
fixed_fee_C_express = params['fixed_fee_C_express']
weekly_order_budget = params['weekly_order_budget']

# Create model
model = gp.Model("FurnitureOrder_Revised")
model.setParam('OutputFlag', 0)

M = max_total + 1

# For each manufacturer, we have two possible channels: regular and express.
# Binary variables for channel selection
# y_A_r = 1 if manufacturer A is used via regular channel
# y_A_e = 1 if manufacturer A is used via express channel
# Similarly for B and C

y_A_r = model.addVar(vtype=GRB.BINARY, name="y_A_r")
y_A_e = model.addVar(vtype=GRB.BINARY, name="y_A_e")
y_B_r = model.addVar(vtype=GRB.BINARY, name="y_B_r")
y_B_e = model.addVar(vtype=GRB.BINARY, name="y_B_e")
y_C_r = model.addVar(vtype=GRB.BINARY, name="y_C_r")
y_C_e = model.addVar(vtype=GRB.BINARY, name="y_C_e")

# Number of orders from each manufacturer (integer >= 0)
max_orders_A = max_total // int(chairs_per_order_A) + 1
max_orders_B = max_total // int(chairs_per_order_B) + 1
max_orders_C = max_total // int(chairs_per_order_C) + 1

x_A = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_A, name="orders_A")
x_B = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_B, name="orders_B")
x_C = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_C, name="orders_C")

# y_A indicates if manufacturer A is used at all (via either channel)
y_A = model.addVar(vtype=GRB.BINARY, name="y_A")
y_B = model.addVar(vtype=GRB.BINARY, name="y_B")
y_C = model.addVar(vtype=GRB.BINARY, name="y_C")

# Link y_A to y_A_r and y_A_e: can use at most one channel, and y_A = y_A_r + y_A_e
model.addConstr(y_A == y_A_r + y_A_e, "channel_A")
model.addConstr(y_B == y_B_r + y_B_e, "channel_B")
model.addConstr(y_C == y_C_r + y_C_e, "channel_C")

# Link order variables to usage variables
model.addConstr(x_A <= M * y_A, "LinkA1")
model.addConstr(x_A >= y_A, "LinkA2")
model.addConstr(x_B <= M * y_B, "LinkB1")
model.addConstr(x_B >= y_B, "LinkB2")
model.addConstr(x_C <= M * y_C, "LinkC1")
model.addConstr(x_C >= y_C, "LinkC2")

# Total chairs
chairs_A = chairs_per_order_A * x_A
chairs_B = chairs_per_order_B * x_B
chairs_C = chairs_per_order_C * x_C

# Min and max total chairs
model.addConstr(chairs_A + chairs_B + chairs_C >= min_total, "MinChairs")
model.addConstr(chairs_A + chairs_B + chairs_C <= max_total, "MaxChairs")

# Dependency: if ordering from A, must order at least min_chairs_B_if_A chairs from B
model.addConstr(chairs_B >= min_chairs_B_if_A * y_A, "DepAB")

# Dependency: if ordering from B, must also order from C
model.addConstr(y_B <= y_C, "DepBC")

# Weekly order budget: total number of active manufacturer-mode combinations <= weekly_order_budget
model.addConstr(y_A_r + y_A_e + y_B_r + y_B_e + y_C_r + y_C_e <= weekly_order_budget, "WeeklyBudget")

# Objective: minimize total cost (variable chair cost + fixed fees)
total_variable_cost = cost_A * chairs_A + cost_B * chairs_B + cost_C * chairs_C
total_fixed_fees = (fixed_fee_A_regular * y_A_r + fixed_fee_A_express * y_A_e +
                    fixed_fee_B_regular * y_B_r + fixed_fee_B_express * y_B_e +
                    fixed_fee_C_regular * y_C_r + fixed_fee_C_express * y_C_e)

model.setObjective(total_variable_cost + total_fixed_fees, GRB.MINIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"Status: Optimal")
    print(f"Orders from A: {x_A.X}, Chairs: {x_A.X * chairs_per_order_A}")
    print(f"Orders from B: {x_B.X}, Chairs: {x_B.X * chairs_per_order_B}")
    print(f"Orders from C: {x_C.X}, Chairs: {x_C.X * chairs_per_order_C}")
    total_chairs = x_A.X * chairs_per_order_A + x_B.X * chairs_per_order_B + x_C.X * chairs_per_order_C
    print(f"Total chairs: {total_chairs}")
    print(f"Channel A: regular={y_A_r.X}, express={y_A_e.X}")
    print(f"Channel B: regular={y_B_r.X}, express={y_B_e.X}")
    print(f"Channel C: regular={y_C_r.X}, express={y_C_e.X}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Status: {model.status}")
    print(f"FINAL_OBJ_VALUE: N/A")
