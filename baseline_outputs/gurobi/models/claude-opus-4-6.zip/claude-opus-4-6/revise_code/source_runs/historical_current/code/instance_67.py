import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return [row for row in reader]

def load_demand():
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        month = row['Month']
        product = row['Product']
        units = int(row['Market_Demand_Units'])
        demand[(month, product)] = units
    return demand

def load_parameters():
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = float(row['Value'])
        params[name] = value
    return params

def main():
    demand_data = load_demand()
    params = load_parameters()

    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']

    # Production costs (June-Dec)
    prod_cost = {
        'Product_I': params['product_I_cost_jun_to_dec'],   # 4.5
        'Product_II': params['product_II_cost_jun_to_dec'],  # 7
    }

    # Volume per unit
    volume = {
        'Product_I': params['product_I_volume'],   # 0.2
        'Product_II': params['product_II_volume'],  # 0.4
    }

    # Warehouse
    warehouse_cap = params['warehouse_capacity']  # 30,000 cubic meters
    own_wh_cost = params['own_warehouse_cost']    # 1 yuan/m³/month
    # No external warehouse in revised model

    # Machine hours
    machine_hours = {
        'Product_I': params['product_I_machine_hours'],   # 0.8
        'Product_II': params['product_II_machine_hours'],  # 1.6
    }
    machine_hours_cap = params['machine_hours_capacity_monthly']  # 120,000

    # Electricity
    power_kwh = {
        'Product_I': params['product_I_power_kwh'],   # 2
        'Product_II': params['product_II_power_kwh'],  # 3
    }
    grid_cost = params['grid_electricity_cost']       # 0.6
    gen_cost = params['generator_electricity_cost']    # 0.9

    month_key_map = {
        'July': 'july', 'August': 'august', 'September': 'september',
        'October': 'october', 'November': 'november', 'December': 'december'
    }

    grid_quota = {}
    gen_max = {}
    for m in months:
        mk = month_key_map[m]
        grid_quota[m] = params[f'grid_quota_{mk}']
        gen_max[m] = params[f'generator_max_{mk}']

    # Demand
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]

    # Model
    model = gp.Model("Production_Planning_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # Production quantities
    x = model.addVars(months, products, lb=0, name="prod")

    # Inventory at end of month
    inv = model.addVars(months, products, lb=0, name="inv")

    # Own warehouse usage (cubic meters) - capped at warehouse_cap
    own_wh = model.addVars(months, lb=0, ub=warehouse_cap, name="own_wh")

    # Grid electricity used per month
    grid_elec = model.addVars(months, lb=0, name="grid_elec")

    # Generator electricity used per month
    gen_elec = model.addVars(months, lb=0, name="gen_elec")

    # Objective: production cost + warehouse cost + electricity cost
    obj = gp.LinExpr()
    for m in months:
        for p in products:
            obj += prod_cost[p] * x[m, p]
        obj += own_wh_cost * own_wh[m]
        obj += grid_cost * grid_elec[m]
        obj += gen_cost * gen_elec[m]

    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    for i, m in enumerate(months):
        # Inventory balance
        for p in products:
            if i == 0:
                model.addConstr(inv[m, p] == x[m, p] - demand[(m, p)],
                                name=f"inv_balance_{m}_{p}")
            else:
                prev_m = months[i - 1]
                model.addConstr(inv[m, p] == inv[prev_m, p] + x[m, p] - demand[(m, p)],
                                name=f"inv_balance_{m}_{p}")

        # Machine hours capacity
        model.addConstr(
            gp.quicksum(machine_hours[p] * x[m, p] for p in products) <= machine_hours_cap,
            name=f"machine_hours_{m}"
        )

        # Electricity: total consumption must be met by grid + generator
        total_elec = gp.quicksum(power_kwh[p] * x[m, p] for p in products)
        model.addConstr(grid_elec[m] + gen_elec[m] >= total_elec,
                        name=f"elec_balance_{m}")

        # Grid quota
        model.addConstr(grid_elec[m] <= grid_quota[m],
                        name=f"grid_quota_{m}")

        # Generator max
        model.addConstr(gen_elec[m] <= gen_max[m],
                        name=f"gen_max_{m}")

        # Warehouse: total volume of inventory <= own warehouse (no external)
        total_vol = gp.quicksum(volume[p] * inv[m, p] for p in products)
        model.addConstr(own_wh[m] >= total_vol, name=f"wh_vol_{m}")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
