import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    
    n = len(shifts)  # 6 periods
    required = [s['required'] for s in shifts]
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    shift_duration = int(params['shift_duration'])  # 8 hours
    max_night_driver_fraction = params['max_night_driver_fraction']  # 0.4
    max_night_crew_fraction = params['max_night_crew_fraction']  # 0.5
    max_overtime_shifts = int(params['max_overtime_shifts'])  # 20
    overtime_cost_factor = params['overtime_cost_factor']  # 1.5
    
    # Each period is 4 hours, shift covers 2 consecutive periods
    periods_per_shift = shift_duration // 4  # 2
    
    # Late-night periods: periods 5 and 6 (indices 4 and 5)
    late_night_indices = [4, 5]
    
    # Create model
    model = gp.Model("BusScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables:
    # d[i] = number of regular drivers starting at period i (0-indexed)
    # c[i] = number of regular crew starting at period i
    # od[i] = number of overtime drivers starting at period i
    # oc[i] = number of overtime crew starting at period i
    
    d = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="d")
    c = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="c")
    od = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="od")
    oc = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="oc")
    
    # Objective: minimize total cost
    # Regular shifts cost 1 each, overtime shifts cost overtime_cost_factor each
    obj = gp.quicksum(d[i] + c[i] for i in range(n)) + \
          overtime_cost_factor * gp.quicksum(od[i] + oc[i] for i in range(n))
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Coverage constraints: for each period j, total drivers (regular + overtime) covering j >= required[j]
    # Same for crew
    for j in range(n):
        driver_cover = []
        crew_cover = []
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                driver_cover.append(d[i] + od[i])
                crew_cover.append(c[i] + oc[i])
        model.addConstr(gp.quicksum(driver_cover) >= required[j], 
                       name=f"driver_demand_{j}")
        model.addConstr(gp.quicksum(crew_cover) >= required[j], 
                       name=f"crew_demand_{j}")
    
    # Late-night fraction constraints for drivers
    # Sum of driver starts in late-night periods <= max_night_driver_fraction * total driver starts
    total_driver_starts = gp.quicksum(d[i] + od[i] for i in range(n))
    late_night_driver_starts = gp.quicksum(d[i] + od[i] for i in late_night_indices)
    model.addConstr(late_night_driver_starts <= max_night_driver_fraction * total_driver_starts,
                   name="night_driver_fraction")
    
    # Late-night fraction constraints for crew
    total_crew_starts = gp.quicksum(c[i] + oc[i] for i in range(n))
    late_night_crew_starts = gp.quicksum(c[i] + oc[i] for i in late_night_indices)
    model.addConstr(late_night_crew_starts <= max_night_crew_fraction * total_crew_starts,
                   name="night_crew_fraction")
    
    # Max overtime shifts constraint (total across both groups)
    model.addConstr(gp.quicksum(od[i] + oc[i] for i in range(n)) <= max_overtime_shifts,
                   name="max_overtime")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        
        print("=== Driver Schedule (Regular) ===")
        for i in range(n):
            print(f"  Period {i+1}: {d[i].X:.0f} regular drivers")
        print("=== Driver Schedule (Overtime) ===")
        for i in range(n):
            print(f"  Period {i+1}: {od[i].X:.0f} overtime drivers")
        print("=== Crew Schedule (Regular) ===")
        for i in range(n):
            print(f"  Period {i+1}: {c[i].X:.0f} regular crew")
        print("=== Crew Schedule (Overtime) ===")
        for i in range(n):
            print(f"  Period {i+1}: {oc[i].X:.0f} overtime crew")
        
        total_regular = sum(d[i].X + c[i].X for i in range(n))
        total_overtime = sum(od[i].X + oc[i].X for i in range(n))
        print(f"Total regular shifts: {total_regular:.0f}")
        print(f"Total overtime shifts: {total_overtime:.0f}")
        
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
