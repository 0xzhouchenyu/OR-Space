import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Determine paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load monthly data
months = []
purchasing_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        month = int(row["Month"])
        months.append(month)
        purchasing_prices[month] = float(row["Purchasing_Price_Yuan"])
        selling_prices[month] = float(row["Selling_Price_Yuan"])

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

warehouse_capacity = params["warehouse_capacity"]
initial_stock = params["initial_stock"]
fixed_ordering_cost = params["fixed_ordering_cost"]
month2_bulk_threshold = params["month2_bulk_receiving_threshold"]
month2_bulk_fee = params["month2_bulk_receiving_fee"]

# Create model
model = gp.Model("Maximize_Profit")
model.setParam("OutputFlag", 0)

# Big-M for binary variable linking
M = warehouse_capacity  # upper bound on purchase quantity in any month

# Decision variables
x = {}  # units purchased at beginning of month m
s = {}  # units sold during month m
inv = {}  # inventory at end of month m
y = {}  # binary: 1 if any purchase is made in month m (for fixed ordering cost)

for m in months:
    x[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"purchase_{m}")
    s[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"sell_{m}")
    inv[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"inventory_{m}")
    y[m] = model.addVar(vtype=GRB.BINARY, name=f"order_binary_{m}")

# Month 2 bulk receiving binary: 1 if month 2 purchase exceeds threshold
z2 = model.addVar(vtype=GRB.BINARY, name="month2_bulk_binary")

model.update()

# Constraints
for m in months:
    if m == months[0]:
        prev_inv = initial_stock
    else:
        prev_inv = inv[m - 1]

    # Inventory balance
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], name=f"inventory_balance_{m}")

    # Warehouse capacity after purchasing (before selling)
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, name=f"warehouse_after_purchase_{m}")

    # End-of-month inventory capacity
    model.addConstr(inv[m] <= warehouse_capacity, name=f"warehouse_end_{m}")

    # Can't sell more than available
    model.addConstr(s[m] <= prev_inv + x[m], name=f"sell_limit_{m}")

    # Link binary y[m] to x[m]: if x[m] > 0 then y[m] = 1
    model.addConstr(x[m] <= M * y[m], name=f"order_link_{m}")

# Month 2 bulk receiving constraints:
# z2 = 1 if x[2] > month2_bulk_threshold (300)
# We model: x[2] <= threshold + M * z2  (if z2=0, x[2] <= threshold)
# and: x[2] >= threshold + epsilon when z2=1 => x[2] >= (threshold + epsilon)*z2
# More precisely:
# x[2] - threshold <= M * z2
# x[2] - threshold >= epsilon * z2  (but this forces z2=1 only if x[2] > threshold)
# Actually we need: z2=1 iff x[2] > threshold
# Use: x[2] <= threshold + M*z2
#      x[2] >= threshold + 0.001*z2  -- but this is tricky with continuous
# Better formulation for cost minimization (we want to minimize cost, so z2 being 1 costs money):
# Since z2=1 incurs a cost, the solver will set z2=0 whenever possible.
# We just need: if x[2] > threshold then z2 must be 1
# x[2] - threshold <= M * z2
model.addConstr(x[2] - month2_bulk_threshold <= M * z2, name="month2_bulk_link")

# Objective: maximize profit
# Revenue - purchasing cost - fixed ordering costs - month2 bulk fee
obj = gp.LinExpr()
for m in months:
    obj += selling_prices[m] * s[m] - purchasing_prices[m] * x[m]
    obj -= fixed_ordering_cost * y[m]
obj -= month2_bulk_fee * z2

model.setObjective(obj, GRB.MAXIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    for m in months:
        print(f"Month {m}: Purchase = {x[m].X}, Sell = {s[m].X}, End Inventory = {inv[m].X}, Order = {y[m].X}")
    print(f"Month 2 bulk receiving: {z2.X}")
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
