import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            if ':' in value_str:
                params[name + '_raw'] = value_str
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_hours = params['machine_working_time']
    machine_working_time_minutes = machine_working_time_hours * 60

    max_overtime_hours = params['max_overtime_hours']
    max_overtime_minutes = max_overtime_hours * 60
    overtime_penalty_per_hour = params['overtime_penalty_per_hour']
    overtime_penalty_per_minute = overtime_penalty_per_hour / 60.0

    overtime_review_threshold_hours = params['overtime_review_threshold_hours']
    overtime_review_threshold_minutes = overtime_review_threshold_hours * 60
    overtime_review_fee = params['overtime_review_fee']

    product_A_senior_batch_threshold = params['product_A_senior_batch_threshold']
    product_A_senior_batch_fee = params['product_A_senior_batch_fee']

    ratio_A = 5
    ratio_B = 2

    # Big-M values
    M_large = 1e6

    model = gp.Model("Product_Mix_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    A = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_A")
    B = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_B")

    # Overtime in minutes
    overtime = model.addVar(lb=0, ub=max_overtime_minutes, vtype=GRB.CONTINUOUS, name="Overtime")

    # Binary: whether overtime exceeds the review threshold
    y_overtime_review = model.addVar(vtype=GRB.BINARY, name="y_overtime_review")

    # Binary: whether Product A exceeds senior batch threshold
    y_senior_batch = model.addVar(vtype=GRB.BINARY, name="y_senior_batch")

    model.update()

    # Total assembly time = assembly_time_A * A + assembly_time_B * B
    # This must be <= machine_working_time_minutes + overtime
    model.addConstr(
        assembly_time_A * A + assembly_time_B * B <= machine_working_time_minutes + overtime,
        "Machine_Time_With_Overtime"
    )

    # Production ratio: B >= (2/5)*A => 2A - 5B <= 0
    model.addConstr(ratio_B * A - ratio_A * B <= 0, "Production_Ratio")

    # Overtime review threshold logic:
    # If overtime > overtime_review_threshold_minutes, then y_overtime_review = 1
    # If overtime <= overtime_review_threshold_minutes, then y_overtime_review = 0
    # overtime <= overtime_review_threshold_minutes + M_large * y_overtime_review
    # overtime >= (overtime_review_threshold_minutes + epsilon) * y_overtime_review
    # Using: overtime > threshold => y=1, overtime <= threshold => y=0
    # We model: overtime <= threshold + M * y  (always true)
    #           overtime >= threshold * y + epsilon * y  -- not clean
    # Better formulation:
    # overtime - threshold <= M * y_overtime_review
    # overtime - threshold >= epsilon - M*(1 - y_overtime_review)
    # But since the fee is a cost, the optimizer will set y=0 whenever possible.
    # So we just need: overtime > threshold => y=1
    # overtime <= threshold + M * y_overtime_review  (if y=0, overtime <= threshold)
    epsilon = 0.001
    model.addConstr(overtime <= overtime_review_threshold_minutes + M_large * y_overtime_review,
                    "Overtime_Review_Link1")
    # If y=1, no additional constraint needed (overtime can be anything up to max)
    # The optimizer will prefer y=0 to avoid fee, so this is sufficient.

    # Senior batch threshold logic for Product A:
    # If A > 100, then y_senior_batch = 1 (and fee applies)
    # A <= 100 + M * y_senior_batch
    model.addConstr(A <= product_A_senior_batch_threshold + M_large * y_senior_batch,
                    "Senior_Batch_Link1")

    # Objective: maximize profit - overtime cost - overtime review fee - senior batch fee
    # Overtime cost: overtime (in minutes) * penalty per minute
    obj = (profit_A * A + profit_B * B
           - overtime_penalty_per_minute * overtime
           - overtime_review_fee * y_overtime_review
           - product_A_senior_batch_fee * y_senior_batch)

    model.setObjective(obj, GRB.MAXIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")
    else:
        print(f"FINAL_OBJ_VALUE: N/A (Status: {model.status})")

if __name__ == "__main__":
    main()
