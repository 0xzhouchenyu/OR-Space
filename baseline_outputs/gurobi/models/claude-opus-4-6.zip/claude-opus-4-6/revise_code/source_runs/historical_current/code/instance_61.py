import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read device data
devices = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            'name': row['Device'].strip(),
            'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
            'max_cap': float(row['Max_Processing_Capacity_Units'].strip())
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

required_units = params['required_units']
energy_budget_peak = params['energy_budget_peak']
energy_budget_offpeak = params['energy_budget_offpeak']
startup_budget = params['startup_budget']
startup_cost = params['startup_cost']
energy_price_peak = params['energy_price_peak']
energy_price_offpeak = params['energy_price_offpeak']

# Energy per unit for each device
energy_per_unit = {
    'A': params['energy_per_unit_A'],
    'B': params['energy_per_unit_B'],
    'C': params['energy_per_unit_C'],
    'D': params['energy_per_unit_D'],
}

# Startup energy for each device
startup_energy = {
    'A': params['startup_energy_A'],
    'B': params['startup_energy_B'],
    'C': params['startup_energy_C'],
    'D': params['startup_energy_D'],
}

n = len(devices)
periods = ['peak', 'offpeak']

# Create model
model = gp.Model("MinCostProduction_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
# x[i,p]: units produced on device i in period p
x = {}
for i in range(n):
    for p in periods:
        x[i, p] = model.addVar(lb=0, ub=devices[i]['max_cap'], vtype=GRB.CONTINUOUS,
                                name=f"x_{devices[i]['name']}_{p}")

# y[i,p]: binary, whether device i is used (started) in period p
y = {}
for i in range(n):
    for p in periods:
        y[i, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{devices[i]['name']}_{p}")

# z[i]: binary, whether device i is used at all (for prep completion cost)
z = {}
for i in range(n):
    z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{devices[i]['name']}")

model.update()

# Objective: minimize total cost
# Components:
# 1. Prep completion cost: prep_cost_i * z_i (once per device if used at all)
# 2. Unit production cost: unit_cost_i * x[i,p] for all i,p
# 3. Startup monetary cost: startup_cost * y[i,p] for all i,p
# 4. Energy cost: energy_per_unit * x[i,p] * energy_price_p + startup_energy * y[i,p] * energy_price_p

obj = gp.LinExpr()
for i in range(n):
    dname = devices[i]['name']
    # Prep completion cost
    obj += devices[i]['prep_cost'] * z[i]
    for p in periods:
        ep = energy_price_peak if p == 'peak' else energy_price_offpeak
        # Unit production cost (non-energy)
        obj += devices[i]['unit_cost'] * x[i, p]
        # Startup monetary cost
        obj += startup_cost * y[i, p]
        # Energy cost for production
        obj += energy_per_unit[dname] * ep * x[i, p]
        # Energy cost for startup
        obj += startup_energy[dname] * ep * y[i, p]

model.setObjective(obj, GRB.MINIMIZE)

# Constraint: total production must equal required units
model.addConstr(
    gp.quicksum(x[i, p] for i in range(n) for p in periods) == required_units,
    "TotalProduction"
)

# Linking constraints: x[i,p] <= max_cap * y[i,p]
for i in range(n):
    for p in periods:
        model.addConstr(x[i, p] <= devices[i]['max_cap'] * y[i, p],
                        f"Link_{devices[i]['name']}_{p}")

# z[i] >= y[i,p] for all p (if started in any period, device is used)
for i in range(n):
    for p in periods:
        model.addConstr(z[i] >= y[i, p], f"DeviceUsed_{devices[i]['name']}_{p}")

# z[i] <= sum of y[i,p] (device used only if started in at least one period)
for i in range(n):
    model.addConstr(z[i] <= gp.quicksum(y[i, p] for p in periods),
                    f"DeviceUsedUB_{devices[i]['name']}")

# Energy budget for peak period
model.addConstr(
    gp.quicksum(energy_per_unit[devices[i]['name']] * x[i, 'peak'] +
                startup_energy[devices[i]['name']] * y[i, 'peak']
                for i in range(n)) <= energy_budget_peak,
    "EnergyBudgetPeak"
)

# Energy budget for off-peak period
model.addConstr(
    gp.quicksum(energy_per_unit[devices[i]['name']] * x[i, 'offpeak'] +
                startup_energy[devices[i]['name']] * y[i, 'offpeak']
                for i in range(n)) <= energy_budget_offpeak,
    "EnergyBudgetOffpeak"
)

# Startup budget constraint (monetary)
model.addConstr(
    gp.quicksum(startup_cost * y[i, p] for i in range(n) for p in periods) <= startup_budget,
    "StartupBudget"
)

# Device capacity constraint: total production on device i across periods <= max_cap
for i in range(n):
    model.addConstr(
        gp.quicksum(x[i, p] for p in periods) <= devices[i]['max_cap'],
        f"MaxCap_{devices[i]['name']}"
    )

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    for i in range(n):
        dname = devices[i]['name']
        used = int(z[i].X + 0.5)
        total_units = sum(x[i, p].X for p in periods)
        peak_units = x[i, 'peak'].X
        offpeak_units = x[i, 'offpeak'].X
        print(f"Device {dname}: used={used}, peak={peak_units:.1f}, offpeak={offpeak_units:.1f}, total={total_units:.1f}")
    for i in range(n):
        for p in periods:
            if y[i, p].X > 0.5:
                print(f"  Device {devices[i]['name']} started in {p}")
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
