import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load data
    products = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params_raw = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Parse general parameters
    params = {}
    for row in params_raw:
        params[row['Parameter_Name']] = float(row['Value'])
    
    max_grains = params['max_grains']
    price_grains = params['price_per_lb_grains']
    max_meat = params['max_meat']
    price_meat = params['price_per_lb_meat']
    line_fixed_cost = params['line_fixed_cost']
    line_capacity_packs = params['line_capacity_packs']
    min_batch_packs = params['min_batch_packs']
    min_yummies = params['min_yummies']
    retailer_rebate_yummies_threshold = params['retailer_rebate_yummies_threshold']
    retailer_rebate_min_meaties = params['retailer_rebate_min_meaties']
    retailer_rebate_fixed = params['retailer_rebate_fixed']
    
    # Parse product data
    product_data = {}
    for row in products:
        name = row['Product']
        product_data[name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'variable_cost': float(row['Variable_cost_per_pack']),
            'capacity': float(row['Production_capacity']) if row['Production_capacity'].strip() else None
        }
    
    m_data = product_data['Meaties']
    y_data = product_data['Yummies']
    
    # Profit per pack (selling price - variable cost - raw material cost)
    profit_meaties = m_data['price'] - m_data['variable_cost'] - (m_data['grains'] * price_grains + m_data['meat'] * price_meat)
    profit_yummies = y_data['price'] - y_data['variable_cost'] - (y_data['grains'] * price_grains + y_data['meat'] * price_meat)
    
    # Big-M values
    # Max possible meaties production
    M_meaties = min(m_data['capacity'] if m_data['capacity'] else 1e9, max_grains / m_data['grains'], max_meat / m_data['meat'], line_capacity_packs)
    M_yummies = min(y_data['capacity'] if y_data['capacity'] else 1e9, max_grains / y_data['grains'], max_meat / y_data['meat'], line_capacity_packs)
    M_total = line_capacity_packs
    
    # Create model
    model = gp.Model("HealthyPetFoods")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_meaties = model.addVar(lb=0, name="Meaties")
    x_yummies = model.addVar(lb=0, name="Yummies")
    
    # Binary: is the co-packing line active?
    y_line = model.addVar(vtype=GRB.BINARY, name="line_active")
    
    # Binary: does the retailer rebate apply?
    y_rebate = model.addVar(vtype=GRB.BINARY, name="rebate_active")
    
    # Helper binaries for rebate conditions
    y_rebate_yummies = model.addVar(vtype=GRB.BINARY, name="rebate_yummies_met")
    y_rebate_meaties = model.addVar(vtype=GRB.BINARY, name="rebate_meaties_met")
    
    # Objective: maximize profit
    # profit from sales - line fixed cost (if active) + retailer rebate (if conditions met)
    model.setObjective(
        profit_meaties * x_meaties + profit_yummies * x_yummies 
        - line_fixed_cost * y_line 
        + retailer_rebate_fixed * y_rebate,
        GRB.MAXIMIZE
    )
    
    # --- Constraints ---
    
    # Production only if line is active
    model.addConstr(x_meaties <= M_meaties * y_line, "Meaties_line_link")
    model.addConstr(x_yummies <= M_yummies * y_line, "Yummies_line_link")
    
    # Grains availability
    model.addConstr(m_data['grains'] * x_meaties + y_data['grains'] * x_yummies <= max_grains, "Grains_Constraint")
    
    # Meat availability
    model.addConstr(m_data['meat'] * x_meaties + y_data['meat'] * x_yummies <= max_meat, "Meat_Constraint")
    
    # Production capacity for Meaties
    if m_data['capacity'] is not None:
        model.addConstr(x_meaties <= m_data['capacity'], "Meaties_Capacity")
    
    # Production capacity for Yummies (if any)
    if y_data['capacity'] is not None:
        model.addConstr(x_yummies <= y_data['capacity'], "Yummies_Capacity")
    
    # Line capacity (total throughput)
    model.addConstr(x_meaties + x_yummies <= line_capacity_packs, "Line_Capacity")
    
    # Minimum batch if line is active
    model.addConstr(x_meaties + x_yummies >= min_batch_packs * y_line, "Min_Batch")
    
    # Minimum Yummies if line is active
    model.addConstr(x_yummies >= min_yummies * y_line, "Min_Yummies")
    
    # --- Retailer rebate logic ---
    # y_rebate_yummies = 1 iff x_yummies >= retailer_rebate_yummies_threshold
    # y_rebate_meaties = 1 iff x_meaties >= retailer_rebate_min_meaties
    # y_rebate = 1 iff both are 1
    
    # Big M for indicator constraints
    BM_yummies = max(M_yummies, line_capacity_packs) + 1
    BM_meaties = max(M_meaties, line_capacity_packs) + 1
    
    # x_yummies >= threshold - BM*(1 - y_rebate_yummies)
    # If y_rebate_yummies=1, then x_yummies >= threshold
    model.addConstr(x_yummies >= retailer_rebate_yummies_threshold - BM_yummies * (1 - y_rebate_yummies), "Rebate_yummies_lb")
    # If y_rebate_yummies=0, then x_yummies < threshold (i.e., x_yummies <= threshold - 1 or threshold - epsilon)
    # x_yummies <= threshold - 1 + BM*(y_rebate_yummies) -- but continuous, use small epsilon approach or:
    # x_yummies <= threshold * y_rebate_yummies + BM_yummies * (1 - y_rebate_yummies) -- not quite right
    # Better: x_yummies <= retailer_rebate_yummies_threshold - 1 + BM_yummies * y_rebate_yummies
    # When y_rebate_yummies=0: x_yummies <= threshold - 1 (forces below threshold for integer-like)
    # When y_rebate_yummies=1: x_yummies <= threshold - 1 + BM (non-binding)
    # Since production is effectively integer-scale, use epsilon = 1
    model.addConstr(x_yummies <= retailer_rebate_yummies_threshold - 1 + BM_yummies * y_rebate_yummies, "Rebate_yummies_ub")
    
    # x_meaties >= retailer_rebate_min_meaties - BM*(1 - y_rebate_meaties)
    model.addConstr(x_meaties >= retailer_rebate_min_meaties - BM_meaties * (1 - y_rebate_meaties), "Rebate_meaties_lb")
    model.addConstr(x_meaties <= retailer_rebate_min_meaties - 1 + BM_meaties * y_rebate_meaties, "Rebate_meaties_ub")
    
    # y_rebate = 1 only if both conditions met
    model.addConstr(y_rebate <= y_rebate_yummies, "Rebate_req_yummies")
    model.addConstr(y_rebate <= y_rebate_meaties, "Rebate_req_meaties")
    # If both conditions met, rebate should be 1 (optimizer will set it to 1 since it helps objective)
    model.addConstr(y_rebate >= y_rebate_yummies + y_rebate_meaties - 1, "Rebate_both")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"Meaties: {x_meaties.X}")
        print(f"Yummies: {x_yummies.X}")
        print(f"Line active: {y_line.X}")
        print(f"Rebate active: {y_rebate.X}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible")
        print(f"FINAL_OBJ_VALUE: infeasible")
    else:
        print(f"Optimization ended with status {model.status}")
        print(f"FINAL_OBJ_VALUE: {model.ObjVal if model.SolCount > 0 else 'N/A'}")

if __name__ == "__main__":
    main()
