import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    W = params['initial_investment']                # 100000
    r1 = params['return_rate_option_1']             # 0.7
    r2 = params['return_rate_option_2']             # 2.0
    T = int(params['planning_horizon'])             # 3
    min_reserve_y1 = params['min_reserve_year1']    # 10000
    min_reserve_y2 = params['min_reserve_year2']    # 15000
    max_opt2 = params['max_option2_start']          # 30000
    late_rate = params['option2_year0_late_settlement_rate']  # 0.02
    
    # Decision variables:
    # x0_1: amount invested in Option 1 at year 0
    # x0_2: amount invested in Option 2 at year 0 (matures after year 2, but LATE - settles after year-2 reinvestment cut-off)
    # x1_1: amount invested in Option 1 at year 1
    # x1_2: amount invested in Option 2 at year 1 (matures at end of year 3)
    # x2_1: amount invested in Option 1 at year 2
    # cash_y1: uninvested cash reserve at end of year 1
    # cash_y2: uninvested cash reserve at end of year 2
    
    # KEY REVISION:
    # The two-year product started at year 0 (x0_2) now settles AFTER the year-2 reinvestment cut-off.
    # This means:
    # - x0_2 proceeds are NOT available for year-2 investments (cannot fund x2_1)
    # - x0_2 proceeds go directly to final cash position at year 3
    # - x0_2 proceeds are subject to a late settlement deduction: effective return = (1 + r2) * (1 - late_rate)
    
    model = gp.Model("Investment")
    model.setParam('OutputFlag', 0)
    
    x0_1 = model.addVar(lb=0, name="x0_1")
    x0_2 = model.addVar(lb=0, name="x0_2")
    x1_1 = model.addVar(lb=0, name="x1_1")
    x1_2 = model.addVar(lb=0, name="x1_2")
    x2_1 = model.addVar(lb=0, name="x2_1")
    cash_y1 = model.addVar(lb=0, name="cash_y1")  # cash reserve at end of year 1
    cash_y2 = model.addVar(lb=0, name="cash_y2")  # cash reserve at end of year 2
    
    # Year 0 budget constraint
    model.addConstr(x0_1 + x0_2 <= W, "year0_budget")
    
    # Year 1: money available = returns from x0_1 = x0_1 * (1 + r1)
    # Must allocate to x1_1, x1_2, and keep cash_y1 reserve
    model.addConstr(x1_1 + x1_2 + cash_y1 == x0_1 * (1 + r1), "year1_budget")
    
    # Minimum reserve at end of year 1
    model.addConstr(cash_y1 >= min_reserve_y1, "reserve_y1")
    
    # Year 2: money available = returns from x1_1 + cash carried from y1
    # REVISION: x0_2 proceeds are NOT available here (late settlement)
    model.addConstr(x2_1 + cash_y2 == x1_1 * (1 + r1) + cash_y1, "year2_budget")
    
    # Minimum reserve at end of year 2
    model.addConstr(cash_y2 >= min_reserve_y2, "reserve_y2")
    
    # Per-start exposure ceiling for two-year product
    model.addConstr(x0_2 <= max_opt2, "max_opt2_year0")
    model.addConstr(x1_2 <= max_opt2, "max_opt2_year1")
    
    # Year 3 (end): total wealth
    # = x2_1 * (1 + r1)                              [Option 1 from year 2 matures]
    # + x1_2 * (1 + r2)                              [Option 2 from year 1 matures]
    # + x0_2 * (1 + r2) * (1 - late_rate)            [Option 2 from year 0, late settlement with deduction]
    # + cash_y2                                        [cash carried from year 2]
    
    effective_r2_late = (1 + r2) * (1 - late_rate)
    
    model.setObjective(
        x2_1 * (1 + r1) + x1_2 * (1 + r2) + x0_2 * effective_r2_late + cash_y2,
        GRB.MAXIMIZE
    )
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found (status {model.status})")

if __name__ == "__main__":
    main()
