import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read general parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    total_space = float(params['mall_total_space'])
    rent_pct = float(params['rent_percentage']) / 100.0
    common_area_factor = float(params['common_area_factor'])
    gm_third_store_concession = float(params['general_merchandise_third_store_concession'])
    catering_security_threshold = int(params['catering_third_store_security_threshold'])
    catering_security_cost = float(params['catering_third_store_security_cost'])
    
    # Read store data
    stores = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            stores.append({
                'name': row['Store_Type'].strip(),
                'code': int(row['Code'].strip()),
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits
            })
    
    num_stores = len(stores)
    
    # Build model
    m = gp.Model("mall_optimization")
    m.setParam('OutputFlag', 0)
    
    # For each store type i and each possible count k, create a binary variable y[i,k]
    # indicating whether we choose exactly k stores of type i
    y = {}
    for i in range(num_stores):
        s = stores[i]
        for k in range(s['min'], s['max'] + 1):
            # Only allow k if we have profit data for it (or k==0)
            if k == 0 or k in s['profits']:
                y[i, k] = m.addVar(vtype=GRB.BINARY, name=f"y_{i}_{k}")
    
    # Each store type must have exactly one choice
    for i in range(num_stores):
        s = stores[i]
        valid_ks = [k for k in range(s['min'], s['max'] + 1) if (k == 0 or k in s['profits'])]
        m.addConstr(gp.quicksum(y[i, k] for k in valid_ks) == 1, name=f"one_choice_{i}")
    
    # Space constraint with common_area_factor
    # Each store's effective area = area_per_shop * common_area_factor * number_of_shops
    m.addConstr(
        gp.quicksum(
            k * stores[i]['area'] * common_area_factor * y[i, k]
            for i in range(num_stores)
            for k in range(stores[i]['min'], stores[i]['max'] + 1)
            if (i, k) in y
        ) <= total_space,
        name="space"
    )
    
    # Compute total rent income (base)
    # For each store type with k stores: rent contribution = rent_pct * k * per_store_profit(k)
    # Then subtract penalties
    
    # Base rent income expression
    base_rent = gp.quicksum(
        rent_pct * k * stores[i]['profits'][k] * y[i, k]
        for i in range(num_stores)
        for k in range(stores[i]['min'], stores[i]['max'] + 1)
        if (i, k) in y and k > 0
    )
    
    # Find indices for General_Merchandise and Catering
    gm_idx = None
    cat_idx = None
    for i in range(num_stores):
        if stores[i]['name'] == 'General_Merchandise':
            gm_idx = i
        if stores[i]['name'] == 'Catering':
            cat_idx = i
    
    # Penalty for third General Merchandise store
    gm_penalty = 0
    if gm_idx is not None and (gm_idx, 3) in y:
        gm_penalty = gm_third_store_concession * y[gm_idx, 3]
    
    # Penalty for third Catering store (security cost)
    cat_penalty = 0
    if cat_idx is not None and (cat_idx, 3) in y:
        cat_penalty = catering_security_cost * y[cat_idx, 3]
    
    # Objective: maximize total rent minus penalties
    m.setObjective(base_rent - gm_penalty - cat_penalty, GRB.MAXIMIZE)
    
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        obj_val = m.ObjVal
        
        # Print solution details
        for i in range(num_stores):
            s = stores[i]
            for k in range(s['min'], s['max'] + 1):
                if (i, k) in y and y[i, k].X > 0.5:
                    print(f"  {s['name']}: {k} stores")
        
        total_area_used = sum(
            k * stores[i]['area'] * common_area_factor * y[i, k].X
            for i in range(num_stores)
            for k in range(stores[i]['min'], stores[i]['max'] + 1)
            if (i, k) in y and y[i, k].X > 0.5
        )
        print(f"Total effective area used: {total_area_used}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {m.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == '__main__':
    main()
