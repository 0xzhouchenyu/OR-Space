import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Construct paths
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load feed data
feeds = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        feed = {
            "Feed": int(row["Feed"]),
            "Protein_g": float(row["Protein_g"]),
            "Minerals_g": float(row["Minerals_g"]),
            "Vitamins_mg": float(row["Vitamins_mg"]),
            "Price_Y_per_kg": float(row["Price_Y_per_kg"]),
        }
        feeds.append(feed)

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

min_protein = params["min_protein_requirement"]
min_minerals = params["min_minerals_requirement"]
min_vitamins = params["min_vitamins_requirement"]

# Big-M value (upper bound on any single feed quantity)
M = 100000

# Create model
model = gp.Model("MinimizeFeedCost")
model.setParam("OutputFlag", 0)

# Decision variables: amount of each feed (kg), non-negative continuous
x = {}
for f in feeds:
    x[f["Feed"]] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{f['Feed']}")

# Binary variables for mutual exclusion of Feed 4 and Feed 5
y4 = model.addVar(vtype=GRB.BINARY, name="y4")  # 1 if Feed 4 is used
y5 = model.addVar(vtype=GRB.BINARY, name="y5")  # 1 if Feed 5 is used

model.update()

# Objective: minimize total cost
model.setObjective(
    gp.quicksum(f["Price_Y_per_kg"] * x[f["Feed"]] for f in feeds),
    GRB.MINIMIZE,
)

# Protein constraint
model.addConstr(
    gp.quicksum(f["Protein_g"] * x[f["Feed"]] for f in feeds) >= min_protein,
    "ProteinRequirement",
)

# Minerals constraint
model.addConstr(
    gp.quicksum(f["Minerals_g"] * x[f["Feed"]] for f in feeds) >= min_minerals,
    "MineralsRequirement",
)

# Vitamins constraint
model.addConstr(
    gp.quicksum(f["Vitamins_mg"] * x[f["Feed"]] for f in feeds) >= min_vitamins,
    "VitaminsRequirement",
)

# Mutual exclusion: Feed 4 and Feed 5 cannot both be used
# x[4] <= M * y4
model.addConstr(x[4] <= M * y4, "Feed4_Link")
# x[5] <= M * y5
model.addConstr(x[5] <= M * y5, "Feed5_Link")
# y4 + y5 <= 1
model.addConstr(y4 + y5 <= 1, "MutualExclusion_4_5")

# Solve
model.optimize()

# Print results
if model.status == GRB.OPTIMAL:
    for f in feeds:
        val = x[f["Feed"]].X
        print(f"Feed {f['Feed']}: {val:.6f} kg")
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
