import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read items and values
items = []
values = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        items.append(row['Item'].strip())
        values.append(int(row['Value'].strip()))

n = len(items)
total_value = sum(values)

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        val = row['Value'].strip()
        params[name] = val

son1_min_share = float(params['son1_min_share'])
high_value_threshold = float(params['high_value_threshold'])
max_high_value_items_per_son = int(params['max_high_value_items_per_son'])
deferred_diamonds_per_son = int(params['deferred_diamonds_per_son'])
immediate_tax_weight = float(params['immediate_tax_weight'])
total_tax_weight = float(params['total_tax_weight'])

# Identify special items
jr_indices = [i for i, item in enumerate(items) if 'Jack Russell' in item]
diamond_indices = [i for i, item in enumerate(items) if 'Diamond' in item]
high_value_indices = [i for i in range(n) if values[i] > high_value_threshold]

# Create model
model = gp.Model("Inheritance_Split_Revised")
model.setParam('OutputFlag', 0)

# Decision variables:
# x[i] = 1 if item i goes to son 1 (immediate), 0 otherwise
# y[i] = 1 if item i goes to son 2 (immediate), 0 otherwise
# dx[i] = 1 if item i is deferred to son 1, 0 otherwise
# dy[i] = 1 if item i is deferred to son 2, 0 otherwise
# Each item must go to exactly one of: son1 immediate, son2 immediate, son1 deferred, son2 deferred

x = model.addVars(n, vtype=GRB.BINARY, name="x")    # son1 immediate
y = model.addVars(n, vtype=GRB.BINARY, name="y")    # son2 immediate
dx = model.addVars(n, vtype=GRB.BINARY, name="dx")  # son1 deferred
dy = model.addVars(n, vtype=GRB.BINARY, name="dy")  # son2 deferred

# Each item assigned exactly once
for i in range(n):
    model.addConstr(x[i] + y[i] + dx[i] + dy[i] == 1, name=f"assign_{i}")

# Total ownership: son1 owns items assigned via x[i] or dx[i]
# son1_total_value = sum of values[i] * (x[i] + dx[i]) for all i
# son1_immediate_value = sum of values[i] * x[i] for all i

son1_total = gp.quicksum(values[i] * (x[i] + dx[i]) for i in range(n))
son2_total = gp.quicksum(values[i] * (y[i] + dy[i]) for i in range(n))
son1_immediate = gp.quicksum(values[i] * x[i] for i in range(n))
son2_immediate = gp.quicksum(values[i] * y[i] for i in range(n))

# son1_min_share: son 1 must receive at least this fraction of total value in total ownership
model.addConstr(son1_total >= son1_min_share * total_value, name="son1_min_share")

# Jack Russell dogs must not be separated (same son, same transfer type - both together)
if len(jr_indices) == 2:
    i0, i1 = jr_indices
    # They must go to the same son (total ownership)
    # x[i0] + dx[i0] = x[i1] + dx[i1] means both go to son1 or both go to son2
    model.addConstr(x[i0] + dx[i0] == x[i1] + dx[i1], name="jr_together")

# High value items concentration limit per son
# A son's high-value items (immediate + deferred) <= max_high_value_items_per_son
model.addConstr(
    gp.quicksum(x[i] + dx[i] for i in high_value_indices) <= max_high_value_items_per_son,
    name="high_value_son1"
)
model.addConstr(
    gp.quicksum(y[i] + dy[i] for i in high_value_indices) <= max_high_value_items_per_son,
    name="high_value_son2"
)

# Deferred diamonds per son limit
model.addConstr(
    gp.quicksum(dx[i] for i in diamond_indices) <= deferred_diamonds_per_son,
    name="deferred_diamonds_son1"
)
model.addConstr(
    gp.quicksum(dy[i] for i in diamond_indices) <= deferred_diamonds_per_son,
    name="deferred_diamonds_son2"
)

# Objective: minimize weighted combination of immediate imbalance and total imbalance
# diff_immediate >= |son1_immediate - son2_immediate|
# diff_total >= |son1_total - son2_total|
diff_immediate = model.addVar(lb=0, name="diff_immediate")
diff_total = model.addVar(lb=0, name="diff_total")

total_immediate = gp.quicksum(values[i] * (x[i] + y[i]) for i in range(n))

model.addConstr(diff_immediate >= 2 * son1_immediate - (son1_immediate + son2_immediate), name="diff_imm_pos")
model.addConstr(diff_immediate >= (son1_immediate + son2_immediate) - 2 * son1_immediate, name="diff_imm_neg")

model.addConstr(diff_total >= 2 * son1_total - total_value, name="diff_tot_pos")
model.addConstr(diff_total >= total_value - 2 * son1_total, name="diff_tot_neg")

model.setObjective(immediate_tax_weight * diff_immediate + total_tax_weight * diff_total, GRB.MINIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal

    son1_imm_items = []
    son1_def_items = []
    son2_imm_items = []
    son2_def_items = []
    s1_imm_val = 0
    s1_def_val = 0
    s2_imm_val = 0
    s2_def_val = 0

    for i in range(n):
        if x[i].X > 0.5:
            son1_imm_items.append((items[i], values[i]))
            s1_imm_val += values[i]
        elif dx[i].X > 0.5:
            son1_def_items.append((items[i], values[i]))
            s1_def_val += values[i]
        elif y[i].X > 0.5:
            son2_imm_items.append((items[i], values[i]))
            s2_imm_val += values[i]
        else:
            son2_def_items.append((items[i], values[i]))
            s2_def_val += values[i]

    print(f"Total inheritance value: {total_value}")
    print()
    print("Son 1 - Immediate:")
    for item, val in son1_imm_items:
        print(f"  {item}: {val}")
    print(f"  Subtotal: {s1_imm_val}")
    print("Son 1 - Deferred:")
    for item, val in son1_def_items:
        print(f"  {item}: {val}")
    print(f"  Subtotal: {s1_def_val}")
    print(f"  Son 1 Total: {s1_imm_val + s1_def_val}")
    print()
    print("Son 2 - Immediate:")
    for item, val in son2_imm_items:
        print(f"  {item}: {val}")
    print(f"  Subtotal: {s2_imm_val}")
    print("Son 2 - Deferred:")
    for item, val in son2_def_items:
        print(f"  {item}: {val}")
    print(f"  Subtotal: {s2_def_val}")
    print(f"  Son 2 Total: {s2_imm_val + s2_def_val}")
    print()
    print(f"Immediate difference: {abs(s1_imm_val - s2_imm_val)}")
    print(f"Total difference: {abs((s1_imm_val + s1_def_val) - (s2_imm_val + s2_def_val))}")
    print(f"Objective: {immediate_tax_weight} * {abs(s1_imm_val - s2_imm_val)} + {total_tax_weight} * {abs((s1_imm_val + s1_def_val) - (s2_imm_val + s2_def_val))}")

    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
