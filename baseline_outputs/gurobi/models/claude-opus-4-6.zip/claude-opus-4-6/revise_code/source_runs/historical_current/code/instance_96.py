import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    params = {}
    for _, row in df_params.iterrows():
        params[row['Parameter_Name']] = row['Value']

    # Supplier 1 parameters
    raw_len_s1 = float(params['raw_pipe_length_supplier1'])
    max_patterns_s1 = int(params['max_cutting_patterns_supplier1'])
    max_cuts_s1 = int(params['max_cuts_per_pipe_supplier1'])
    max_leftover_s1 = float(params['max_leftover_length_supplier1'])
    purchase_cost_s1 = float(params['purchase_cost_per_pipe_supplier1'])

    # Supplier 2 parameters
    raw_len_s2 = float(params['raw_pipe_length_supplier2'])
    max_patterns_s2 = int(params['max_cutting_patterns_supplier2'])
    max_cuts_s2 = int(params['max_cuts_per_pipe_supplier2'])
    max_leftover_s2 = float(params['max_leftover_length_supplier2'])
    purchase_cost_s2 = float(params['purchase_cost_per_pipe_supplier2'])

    # Discount parameters
    discount_tier1_max = int(params['discount_tier1_supplier1_max_qty'])
    fixed_discount = float(params['fixed_discount_tier2_supplier1'])
    bigM_discount = float(params['bigM_discount'])

    # Cost rates for supplier 1
    cost_rates_s1 = []
    rank_prefixes = ['most', 'second', 'third', 'fourth', 'fifth']
    for prefix in rank_prefixes:
        key = f"{prefix}_frequent_pattern_cost_rate_supplier1"
        if key in params:
            cost_rates_s1.append(float(params[key]))
        else:
            break

    # Cost rates for supplier 2
    cost_rates_s2 = []
    for prefix in rank_prefixes:
        key = f"{prefix}_frequent_pattern_cost_rate_supplier2"
        if key in params:
            cost_rates_s2.append(float(params[key]))
        else:
            break

    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)

    # Generate feasible patterns for a given supplier
    def generate_patterns(raw_len, max_cuts, max_leftover):
        min_used = raw_len - max_leftover
        pats = []
        def recurse(current_pattern, current_length, current_cuts, item_idx):
            if item_idx == n_items:
                if current_cuts > 0 and current_length >= min_used and current_length <= raw_len:
                    pats.append(tuple(current_pattern))
                return
            max_qty = min(
                int((raw_len - current_length) // lengths[item_idx]),
                max_cuts - current_cuts
            )
            for q in range(max_qty + 1):
                recurse(
                    current_pattern + [q],
                    current_length + q * lengths[item_idx],
                    current_cuts + q,
                    item_idx + 1
                )
        recurse([], 0, 0, 0)
        return pats

    patterns_s1 = generate_patterns(raw_len_s1, max_cuts_s1, max_leftover_s1)
    patterns_s2 = generate_patterns(raw_len_s2, max_cuts_s2, max_leftover_s2)

    n_p1 = len(patterns_s1)
    n_p2 = len(patterns_s2)

    M = sum(demands) + 100  # big M for pattern usage

    model = gp.Model("PipeCutting")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # y1[p] = number of raw pipes from supplier 1 cut with pattern p
    y1 = model.addVars(n_p1, vtype=GRB.INTEGER, lb=0, name="y1")
    # y2[p] = number of raw pipes from supplier 2 cut with pattern p
    y2 = model.addVars(n_p2, vtype=GRB.INTEGER, lb=0, name="y2")

    # z1[p] = 1 if pattern p is used for supplier 1
    z1 = model.addVars(n_p1, vtype=GRB.BINARY, name="z1")
    # z2[p] = 1 if pattern p is used for supplier 2
    z2 = model.addVars(n_p2, vtype=GRB.BINARY, name="z2")

    # u1[k] = 1 if supplier 1 uses at least k patterns (k=1,...,max_patterns_s1)
    u1 = model.addVars(range(1, max_patterns_s1 + 1), vtype=GRB.BINARY, name="u1")
    # u2[k] = 1 if supplier 2 uses at least k patterns
    u2 = model.addVars(range(1, max_patterns_s2 + 1), vtype=GRB.BINARY, name="u2")

    # Discount binary: delta = 1 if total supplier 1 pipes > discount_tier1_max
    delta = model.addVar(vtype=GRB.BINARY, name="delta")

    # Total pipes from each supplier
    total_s1 = gp.quicksum(y1[p] for p in range(n_p1))
    total_s2 = gp.quicksum(y2[p] for p in range(n_p2))

    # Demand satisfaction
    for i in range(n_items):
        model.addConstr(
            gp.quicksum(patterns_s1[p][i] * y1[p] for p in range(n_p1)) +
            gp.quicksum(patterns_s2[p][i] * y2[p] for p in range(n_p2)) >= demands[i],
            name=f"demand_{i}"
        )

    # Link y and z for supplier 1
    for p in range(n_p1):
        model.addConstr(y1[p] <= M * z1[p], name=f"link_y1z1_{p}")

    # Link y and z for supplier 2
    for p in range(n_p2):
        model.addConstr(y2[p] <= M * z2[p], name=f"link_y2z2_{p}")

    # Number of patterns used equals sum of u for each supplier
    model.addConstr(
        gp.quicksum(z1[p] for p in range(n_p1)) == gp.quicksum(u1[k] for k in range(1, max_patterns_s1 + 1)),
        name="patterns_count_s1"
    )
    model.addConstr(
        gp.quicksum(z2[p] for p in range(n_p2)) == gp.quicksum(u2[k] for k in range(1, max_patterns_s2 + 1)),
        name="patterns_count_s2"
    )

    # Ordering constraints on u (u[k] >= u[k+1])
    for k in range(1, max_patterns_s1):
        model.addConstr(u1[k] >= u1[k + 1], name=f"order_u1_{k}")
    for k in range(1, max_patterns_s2):
        model.addConstr(u2[k] >= u2[k + 1], name=f"order_u2_{k}")

    # Max patterns constraints
    model.addConstr(
        gp.quicksum(z1[p] for p in range(n_p1)) <= max_patterns_s1,
        name="max_patterns_s1"
    )
    model.addConstr(
        gp.quicksum(z2[p] for p in range(n_p2)) <= max_patterns_s2,
        name="max_patterns_s2"
    )

    # Discount tier modeling for supplier 1
    # delta = 1 iff total_s1 > discount_tier1_max, i.e., total_s1 >= discount_tier1_max + 1
    # total_s1 >= discount_tier1_max + 1 - bigM*(1-delta)
    # total_s1 <= discount_tier1_max + bigM*delta
    model.addConstr(total_s1 >= (discount_tier1_max + 1) - bigM_discount * (1 - delta), name="discount_lb")
    model.addConstr(total_s1 <= discount_tier1_max + bigM_discount * delta, name="discount_ub")

    # Pattern ranking cost for supplier 1
    extra_cost_s1 = gp.quicksum(
        cost_rates_s1[k - 1] * u1[k] for k in range(1, max_patterns_s1 + 1) if k - 1 < len(cost_rates_s1)
    )

    # Pattern ranking cost for supplier 2
    extra_cost_s2 = gp.quicksum(
        cost_rates_s2[k - 1] * u2[k] for k in range(1, max_patterns_s2 + 1) if k - 1 < len(cost_rates_s2)
    )

    # Objective: purchase costs + pattern ranking costs - discount
    obj = (purchase_cost_s1 * total_s1 + purchase_cost_s2 * total_s2 +
           extra_cost_s1 + extra_cost_s2 - fixed_discount * delta)

    model.setObjective(obj, GRB.MINIMIZE)
    model.optimize()

    if model.status == GRB.OPTIMAL or model.status == GRB.SUBOPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
