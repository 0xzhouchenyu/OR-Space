import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = params['min_manager_experience']
    manager_bonus = params['manager_bonus_per_candidate']

    cand_names = [c['name'] for c in candidates]
    salary = {c['name']: c['salary'] for c in candidates}
    experience = {c['name']: c['experience'] for c in candidates}
    qualification = {c['name']: c['qualification'] for c in candidates}

    # Create model
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[i] = 1 if candidate i is hired
    x = model.addVars(cand_names, vtype=GRB.BINARY, name="x")
    # m[i] = 1 if candidate i is hired as Manager
    m = model.addVars(cand_names, vtype=GRB.BINARY, name="m")
    # s[i] = 1 if candidate i is hired as Specialist
    s = model.addVars(cand_names, vtype=GRB.BINARY, name="s")

    # Link: a candidate is hired iff assigned to exactly one role
    for i in cand_names:
        model.addConstr(x[i] == m[i] + s[i], name=f"role_link_{i}")

    # Objective: minimize total salary + manager bonus for each manager
    model.setObjective(
        gp.quicksum(salary[i] * x[i] for i in cand_names) +
        gp.quicksum(manager_bonus * m[i] for i in cand_names),
        GRB.MINIMIZE
    )

    # Constraint 1: max employees
    model.addConstr(gp.quicksum(x[i] for i in cand_names) <= max_employees, "max_emp")

    # Constraint 2: budget on base salaries (excluding manager bonus per the description)
    # "budget_limit" is for base salaries excluding manager bonus
    model.addConstr(gp.quicksum(salary[i] * x[i] for i in cand_names) <= budget_limit, "budget")

    # Constraint 3: at least min_advanced candidates with Master's or Doctoral degree
    advanced = [c['name'] for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(x[i] for i in advanced) >= min_advanced, "advanced_degree")

    # Constraint 4: minimum total work experience of selected candidates
    model.addConstr(gp.quicksum(experience[i] * x[i] for i in cand_names) >= min_experience, "min_exp")

    # Constraint 5: at most one from pair A and E
    model.addConstr(x['A'] + x['E'] <= max_equivalent, "equivalent_pair")

    # Constraint 6: minimum employees
    model.addConstr(gp.quicksum(x[i] for i in cand_names) >= min_employees, "min_emp")

    # Constraint 7: min and max managers
    model.addConstr(gp.quicksum(m[i] for i in cand_names) >= min_managers, "min_mgr")
    model.addConstr(gp.quicksum(m[i] for i in cand_names) <= max_managers, "max_mgr")

    # Constraint 8: minimum total work experience of hired managers
    model.addConstr(gp.quicksum(experience[i] * m[i] for i in cand_names) >= min_manager_experience, "min_mgr_exp")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        for i in cand_names:
            if x[i].X > 0.5:
                role = "Manager" if m[i].X > 0.5 else "Specialist"
                print(f"Selected: {i} (Salary: {salary[i]}, Role: {role})")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == '__main__':
    main()
