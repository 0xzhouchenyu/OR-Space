import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            params[name] = val
    
    # Extract parameters
    a1_yield = float(params['product_A1_yield'])       # 3 kg per barrel
    a1_time = float(params['product_A1_time'])          # 12 hours per barrel
    a2_yield = float(params['product_A2_yield'])        # 4 kg per barrel
    a2_time = float(params['product_A2_time'])          # 8 hours per barrel
    a3_yield = float(params['product_A3_yield'])        # 2 kg per barrel
    a3_time = float(params['product_A3_time'])          # 10 hours per barrel
    profit_a1 = float(params['profit_per_kg_A1'])       # 24 yuan/kg
    profit_a2 = float(params['profit_per_kg_A2'])       # 16 yuan/kg
    profit_a3 = float(params['profit_per_kg_A3'])       # 30 yuan/kg
    milk_supply = float(params['daily_milk_supply'])     # 50 barrels
    labor_hours = float(params['daily_labor_hours'])     # 480 hours
    cap_A_shared = float(params['cap_A_shared'])         # 90 kg shared capacity for A1 and A3
    min_a2_kg = float(params['min_A2_kg'])               # 40 kg minimum A2
    min_a3_kg = float(params['min_A3_kg'])               # 20 kg minimum A3
    cleaning_loss = float(params['type_A_cleaning_loss_if_A3'])  # 12 kg
    cold_chain_threshold = float(params['cold_chain_bonus_threshold_kg'])  # 30 kg
    cold_chain_bonus = float(params['cold_chain_bonus_yuan'])    # 300 yuan
    
    model = gp.Model("Dairy_Production_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: barrels of milk allocated to each product
    x1 = model.addVar(lb=0, name="x1")  # barrels for A1
    x2 = model.addVar(lb=0, name="x2")  # barrels for A2
    x3 = model.addVar(lb=0, name="x3")  # barrels for A3
    
    # Binary variable: whether A3 is produced (y3 = 1 if x3 > 0)
    y3 = model.addVar(vtype=GRB.BINARY, name="y3")  # 1 if A3 is produced
    
    # Binary variable: whether cold chain bonus is earned
    z_cold = model.addVar(vtype=GRB.BINARY, name="z_cold")  # 1 if A3 >= threshold
    
    model.update()
    
    # Objective: maximize profit + cold chain bonus
    profit_expr = (profit_a1 * a1_yield * x1 + 
                   profit_a2 * a2_yield * x2 + 
                   profit_a3 * a3_yield * x3 +
                   cold_chain_bonus * z_cold)
    model.setObjective(profit_expr, GRB.MAXIMIZE)
    
    # Big-M for linking constraints
    M = milk_supply  # upper bound on barrels
    
    # Constraint: Milk supply
    model.addConstr(x1 + x2 + x3 <= milk_supply, "Milk_Supply")
    
    # Constraint: Labor hours
    model.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours, "Labor_Hours")
    
    # Constraint: Type A shared capacity for A1 and A3
    # If A3 is produced (y3=1), cleaning loss reduces the shared capacity
    # a1_yield * x1 + a3_yield * x3 <= cap_A_shared - cleaning_loss * y3
    model.addConstr(a1_yield * x1 + a3_yield * x3 <= cap_A_shared - cleaning_loss * y3, "Type_A_Shared_Capacity")
    
    # Linking y3 to x3: if x3 > 0 then y3 = 1
    # x3 <= M * y3
    model.addConstr(x3 <= M * y3, "Link_y3_upper")
    # Also if y3 = 1 then x3 must be positive enough to meet minimum
    # (minimum A3 constraint handles this)
    
    # If A3 is produced at all, minimum A3 production must be met
    # a3_yield * x3 >= min_a3_kg * y3
    model.addConstr(a3_yield * x3 >= min_a3_kg * y3, "Min_A3_Production")
    
    # Minimum A2 production (butter bundle)
    model.addConstr(a2_yield * x2 >= min_a2_kg, "Min_A2_Production")
    
    # Cold chain bonus: z_cold = 1 only if A3 output >= threshold
    # a3_yield * x3 >= cold_chain_threshold * z_cold
    model.addConstr(a3_yield * x3 >= cold_chain_threshold * z_cold, "Cold_Chain_Threshold")
    # z_cold can only be 1 if y3 is 1
    model.addConstr(z_cold <= y3, "Cold_Chain_Requires_A3")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"x1 (barrels for A1) = {x1.X}")
        print(f"x2 (barrels for A2) = {x2.X}")
        print(f"x3 (barrels for A3) = {x3.X}")
        print(f"A1 produced = {x1.X * a1_yield} kg")
        print(f"A2 produced = {x2.X * a2_yield} kg")
        print(f"A3 produced = {x3.X * a3_yield} kg")
        print(f"y3 = {y3.X}, z_cold = {z_cold.X}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print(f"FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
