import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    precedences = []
    with open(os.path.join(data_dir, 'table_1.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))

    activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    dur = {a: int(params[f'activity_{a}_duration']) for a in activities}
    work_cost = params['work_cost_per_day']
    machine_cost = params['machine_rental_cost_per_day']
    
    e_overtime_reduction = int(params['activity_E_overtime_reduction'])
    e_overtime_cost = params['activity_E_overtime_cost']
    e_followup_review_cost = params['activity_E_followup_review_cost']

    model = gp.Model("Project_Cost_Minimization")
    model.setParam('OutputFlag', 0)

    # Start times
    S = {}
    for a in activities:
        S[a] = model.addVar(lb=0, name=f'S_{a}')
    
    # Project completion time
    T = model.addVar(lb=0, name='T')
    
    # Binary: whether to use overtime on E
    y_E = model.addVar(vtype=GRB.BINARY, name='y_E')
    
    # Effective duration of E
    dur_E_eff = model.addVar(lb=0, name='dur_E_eff')
    
    model.update()
    
    # Effective duration of E: dur_E - reduction * y_E
    model.addConstr(dur_E_eff == dur['E'] - e_overtime_reduction * y_E, name='E_eff_dur')
    
    # Precedence constraints
    for pred, succ in precedences:
        if pred == 'E':
            model.addConstr(S[succ] >= S[pred] + dur_E_eff, name=f'prec_{pred}_{succ}')
        else:
            model.addConstr(S[succ] >= S[pred] + dur[pred], name=f'prec_{pred}_{succ}')
    
    # Project completion: T >= finish time of all activities
    # Activities with no successors or terminal activities: B, C
    # C and B are terminal based on precedence graph
    model.addConstr(T >= S['C'] + dur['C'], name='proj_end_C')
    model.addConstr(T >= S['B'] + dur['B'], name='proj_end_B')
    
    # Also need to ensure T >= finish of E (with effective duration) in case E has no path to terminal
    # E -> F -> C and E -> F -> B, so it's covered through precedences
    # But let's be safe and add for all activities
    for a in activities:
        if a == 'E':
            model.addConstr(T >= S[a] + dur_E_eff, name=f'proj_end_{a}')
        else:
            model.addConstr(T >= S[a] + dur[a], name=f'proj_end_{a}')
    
    # Machine rental: machine is rented from start of A to end of B
    # machine_rental_duration = S_B + dur_B - S_A
    machine_rental = S['B'] + dur['B'] - S['A']
    
    # Objective: work cost * T + machine rental cost * rental duration 
    #            + overtime cost * y_E + followup review cost * y_E
    # The overtime premium and follow-up review are both triggered by the binary decision y_E
    obj = work_cost * T + machine_cost * machine_rental + (e_overtime_cost + e_followup_review_cost) * y_E
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

solve()
