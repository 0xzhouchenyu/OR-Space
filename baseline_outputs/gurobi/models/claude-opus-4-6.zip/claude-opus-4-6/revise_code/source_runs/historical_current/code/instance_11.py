import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    def get_param(name):
        return df_params[df_params['Parameter_Name'] == name]['Value'].iloc[0]

    # Parse Table 1
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]

    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])

    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])

    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp = float(row_cap['Inspection_hours_per_unit'])

    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])
    cost_asm = float(row_cost['Assembly_hours_per_unit'])
    # cost_insp from table_1 is 10, but we have mode-specific costs now

    # Parse general parameters
    min_profit = float(get_param('min_weekly_profit'))
    min_a = float(get_param('min_type_a_production'))

    insp_a_M = float(get_param('insp_a_M'))
    insp_b_M = float(get_param('insp_b_M'))
    insp_a_E = float(get_param('insp_a_E'))
    insp_b_E = float(get_param('insp_b_E'))

    cap_ext = float(get_param('cap_ext'))

    cost_insp_M = float(get_param('cost_insp_M'))
    cost_insp_E = float(get_param('cost_insp_E'))
    cost_ext = float(get_param('cost_ext'))

    mode_fee_M = float(get_param('mode_fee_M'))
    mode_fee_E = float(get_param('mode_fee_E'))

    risk_penalty_M = float(get_param('risk_penalty_M'))

    cost_insp_weight = float(get_param('cost_insp_weight'))

    planning_horizon = int(float(get_param('planning_horizon_weeks')))
    idle_tolerance = float(get_param('idle_tolerance'))

    weeks = range(planning_horizon)

    # =========================================================================
    # The problem is a two-week planning problem.
    # Each week t:
    #   - Choose inspection mode: Manual (M) or Enhanced (E)
    #   - Decide production quantities x_A[t], x_B[t] (integer, >= 0)
    #   - x_A[t] >= min_a
    #
    # Constraints per week t:
    #   Manufacturing: mfg_a * x_A[t] + mfg_b * x_B[t] <= cap_mfg
    #   Assembly:      asm_a * x_A[t] + asm_b * x_B[t] <= cap_asm
    #   In-house inspection capacity: 
    #     If Manual: insp_a_M * x_A[t] + insp_b_M * x_B[t] <= cap_insp
    #     If Enhanced: insp_a_E * x_A[t] + insp_b_E * x_B[t] <= cap_insp + cap_ext
    #       (in-house up to cap_insp, external up to cap_ext, but total in-house hours <= cap_insp)
    #       Actually, Enhanced mode uses less in-house hours per unit but also has external capacity.
    #       Let me re-read: Enhanced mode has its own in-house inspection hours (insp_a_E, insp_b_E)
    #       and also external inspection capacity cap_ext hours.
    #       The in-house inspection hours still bounded by cap_insp (40 hours).
    #       The external hours bounded by cap_ext (20 hours).
    #       But what uses external hours? Let me think...
    #       
    #       Under Enhanced mode, each unit needs insp_a_E or insp_b_E in-house hours.
    #       The external capacity is additional. Perhaps total inspection = in-house + external?
    #       Or perhaps some units can be inspected externally?
    #       
    #       Simplest interpretation: Under Enhanced mode, inspection is split.
    #       In-house inspection hours: insp_a_E * x_A + insp_b_E * x_B <= cap_insp
    #       But there's also external capacity of cap_ext hours available.
    #       Perhaps: total inspection needed per unit is still (insp_a_M or insp_a_E) in-house,
    #       but Enhanced allows offloading some to external.
    #       
    #       Actually, let me reconsider. The simplest reading:
    #       - Under Manual: in-house inspection = insp_a_M * xA + insp_b_M * xB, <= cap_insp
    #       - Under Enhanced: in-house inspection = insp_a_E * xA + insp_b_E * xB, <= cap_insp
    #         PLUS external inspection capacity of cap_ext hours is available.
    #         But what consumes external hours? Maybe the remaining inspection from 
    #         the difference (insp_a_M - insp_a_E) is done externally?
    #         Or maybe external capacity is a separate constraint for overflow.
    #
    #       Given Enhanced has LOWER in-house hours (2 vs 3 for A, 4 vs 6 for B),
    #       the external capacity likely handles the difference or is additional.
    #       
    #       Let me just model it as:
    #       Under Enhanced mode, each unit needs insp_a_E (or insp_b_E) in-house hours,
    #       and the external capacity of cap_ext is available for additional inspection.
    #       The external hours per unit could be the difference, or we can model it as:
    #       total inspection hours needed per unit = original inspection hours from table_1,
    #       in Enhanced mode: in-house portion = insp_a_E, external portion = (original - insp_a_E).
    #       So external hours used = (3-2)*xA + (6-4)*xB = xA + 2*xB <= cap_ext = 20.
    #
    #       This makes sense! Enhanced mode splits inspection: some in-house, some external.
    #       Total inspection per unit is same, but Enhanced uses less in-house hours
    #       and outsources the rest externally.
    #
    #       Actually wait - let me not over-think. The parameters say:
    #       insp_a_E = 2 hours/unit in-house under Enhanced
    #       insp_b_E = 4 hours/unit in-house under Enhanced
    #       cap_ext = 20 hours/week external capacity under Enhanced
    #       
    #       So under Enhanced:
    #         In-house inspection: insp_a_E * xA + insp_b_E * xB <= cap_insp (40)
    #         External inspection: ext_hours_used <= cap_ext (20)
    #         But what determines ext_hours_used? 
    #         
    #       Perhaps the total inspection requirement per unit is fixed (from table_1: 3 for A, 6 for B),
    #       and under Enhanced, the in-house portion is insp_a_E/insp_b_E with the remainder external:
    #         External for A: (3-2)=1 hour/unit, External for B: (6-4)=2 hours/unit
    #         So: 1*xA + 2*xB <= 20
    #
    #       This interpretation is clean. Let me go with it.
    #       Under Manual: all inspection is in-house at insp_a_M, insp_b_M rates.
    #       Under Enhanced: in-house at insp_a_E, insp_b_E; external at (insp_a_M-insp_a_E), (insp_b_M-insp_b_E).

    insp_a_orig = float(row_a['Inspection_hours_per_unit'])  # 3
    insp_b_orig = float(row_b['Inspection_hours_per_unit'])  # 6

    ext_a = insp_a_orig - insp_a_E  # 1
    ext_b = insp_b_orig - insp_b_E  # 2

    # Profit per unit:
    # Revenue - manufacturing cost - assembly cost - inspection cost (mode-dependent)
    # Under Manual:
    #   cost_A_M = mfg_a * cost_mfg + asm_a * cost_asm + insp_a_M * cost_insp_M
    #   cost_B_M = mfg_b * cost_mfg + asm_b * cost_asm + insp_b_M * cost_insp_M
    # Under Enhanced:
    #   cost_A_E = mfg_a * cost_mfg + asm_a * cost_asm + insp_a_E * cost_insp_E + ext_a * cost_ext
    #   cost_B_E = mfg_b * cost_mfg + asm_b * cost_asm + insp_b_E * cost_insp_E + ext_b * cost_ext

    var_cost_a_M = mfg_a * cost_mfg + asm_a * cost_asm + insp_a_M * cost_insp_M
    profit_a_M = price_a - var_cost_a_M

    var_cost_b_M = mfg_b * cost_mfg + asm_b * cost_asm + insp_b_M * cost_insp_M
    profit_b_M = price_b - var_cost_b_M

    var_cost_a_E = mfg_a * cost_mfg + asm_a * cost_asm + insp_a_E * cost_insp_E + ext_a * cost_ext
    profit_a_E = price_a - var_cost_a_E

    var_cost_b_E = mfg_b * cost_mfg + asm_b * cost_asm + insp_b_E * cost_insp_E + ext_b * cost_ext
    profit_b_E = price_b - var_cost_b_E

    # Idle time weighting:
    # Manufacturing idle weight: cost_mfg = 12
    # Assembly idle weight: cost_asm = 8
    # In-house inspection idle weight: cost_insp_weight = 11
    #   (This is a unified weight for inspection idle time regardless of mode)

    # =========================================================================
    # LEXICOGRAPHIC OPTIMIZATION:
    # Priority 1 (highest): Minimize weighted idle time + risk penalty
    #   = sum over weeks of:
    #     cost_mfg * idle_mfg[t] + cost_asm * idle_asm[t] + cost_insp_weight * idle_insp[t]
    #     + risk_penalty_M * y_M[t]
    #   where idle_insp[t] = cap_insp - (in-house inspection hours used in week t)
    #
    # Priority 2: Maximize total two-week profit
    #   = sum over weeks of: profit per unit * units - mode_fee - risk_penalty (already in P1?)
    #   Actually, the business says:
    #   "Leadership first wants to protect paid capacity from sitting idle 
    #    while avoiding the riskier Manual protocol through inspection_risk_penalty"
    #   So Priority 1 = minimize (weighted idle time + inspection_risk_penalty for Manual)
    #   Priority 2 = maximize two-week production profit
    #
    #   The "profit" for Priority 2 should be the accounting profit:
    #   revenue - variable costs - mode fees - risk penalties
    #   But risk penalties are already in P1... Let me think about what "two-week production profit" means.
    #   
    #   The problem says "the two-week production profit decide among tied plans"
    #   So profit = revenue - all costs (variable + fixed fees + risk penalties)
    #   Or perhaps profit is just production profit = revenue - variable production costs - mode fees
    #   and risk penalty is only an objective term in P1.
    #
    #   I'll define:
    #   P1 objective: minimize sum_t [ cost_mfg*idle_mfg[t] + cost_asm*idle_asm[t] + cost_insp_weight*idle_insp[t] + risk_penalty_M * y_M[t] ]
    #   P2 objective: maximize sum_t [ unit_profit[t] * x[t] - mode_fee[t] ]
    #   where unit_profit depends on mode, and mode_fee depends on mode.
    #   (Risk penalty is NOT double-counted in profit - it's a separate objective penalty in P1)
    #   Actually, let me include everything in profit for a clean accounting:
    #   Weekly profit = revenue - variable costs - mode_fee - risk_penalty(if Manual)
    #   
    #   But the problem says min_weekly_profit constraint is 3000 per week.
    #   Let me define weekly profit carefully. The original profit was:
    #   price - (mfg*cost_mfg + asm*cost_asm + insp*cost_insp) per unit
    #   Now with modes, the variable cost changes. Plus there are fixed fees.
    #   
    #   I think the weekly profit constraint should be:
    #   sum(unit_profit * x) - mode_fee >= min_weekly_profit
    #   where unit_profit uses the mode-specific costs.
    #   Risk penalty may or may not be included in the profit constraint.
    #   I'll include it since it's a real cost: 
    #   sum(unit_profit * x) - mode_fee - risk_penalty(if M) >= min_weekly_profit
    #
    #   Actually, let me be more careful. The risk penalty is described as a "cost" in the data.
    #   So weekly profit = revenue - all costs = sum(price*x) - sum(var_cost*x) - mode_fee - risk_penalty*y_M
    #   And this should be >= 3000 each week.

    # =========================================================================
    # MODEL
    # =========================================================================

    M_big = 1e6  # big-M

    # --- STAGE 1: Minimize weighted idle + risk penalty ---
    m1 = gp.Model("stage1")
    m1.setParam('OutputFlag', 0)

    # Decision variables per week
    x_A = {}
    x_B = {}
    y_M = {}  # binary: 1 if Manual mode in week t
    y_E = {}  # binary: 1 if Enhanced mode in week t

    # Production variables conditional on mode
    # We need to handle the fact that costs/constraints differ by mode.
    # Use big-M or disaggregated variables.
    # Let's use: x_A_M[t], x_A_E[t], x_B_M[t], x_B_E[t] 
    # where x_A[t] = x_A_M[t] + x_A_E[t], etc.
    # Only one set is nonzero depending on mode.
    
    # Actually simpler: since exactly one mode is chosen per week,
    # use big-M to link x_A[t], x_B[t] to the chosen mode's constraints.

    idle_mfg = {}
    idle_asm = {}
    idle_insp = {}

    for t in weeks:
        x_A[t] = m1.addVar(lb=0, vtype=GRB.INTEGER, name=f'x_A_{t}')
        x_B[t] = m1.addVar(lb=0, vtype=GRB.INTEGER, name=f'x_B_{t}')
        y_M[t] = m1.addVar(vtype=GRB.BINARY, name=f'y_M_{t}')
        y_E[t] = m1.addVar(vtype=GRB.BINARY, name=f'y_E_{t}')
        idle_mfg[t] = m1.addVar(lb=0, name=f'idle_mfg_{t}')
        idle_asm[t] = m1.addVar(lb=0, name=f'idle_asm_{t}')
        idle_insp[t] = m1.addVar(lb=0, name=f'idle_insp_{t}')

    m1.update()

    for t in weeks:
        # Exactly one mode per week
        m1.addConstr(y_M[t] + y_E[t] == 1, name=f'one_mode_{t}')

        # Min production Type A
        m1.addConstr(x_A[t] >= min_a, name=f'min_a_{t}')

        # Manufacturing capacity
        m1.addConstr(mfg_a * x_A[t] + mfg_b * x_B[t] <= cap_mfg, name=f'cap_mfg_{t}')

        # Assembly capacity
        m1.addConstr(asm_a * x_A[t] + asm_b * x_B[t] <= cap_asm, name=f'cap_asm_{t}')

        # Idle time definitions
        m1.addConstr(idle_mfg[t] == cap_mfg - (mfg_a * x_A[t] + mfg_b * x_B[t]), name=f'idle_mfg_def_{t}')
        m1.addConstr(idle_asm[t] == cap_asm - (asm_a * x_A[t] + asm_b * x_B[t]), name=f'idle_asm_def_{t}')

        # In-house inspection capacity and idle time depend on mode
        # Under Manual: in-house hours = insp_a_M * xA + insp_b_M * xB <= cap_insp
        # Under Enhanced: in-house hours = insp_a_E * xA + insp_b_E * xB <= cap_insp
        #                 external hours = ext_a * xA + ext_b * xB <= cap_ext

        # Big-M constraints for inspection capacity:
        # If Manual (y_M=1): insp_a_M * xA + insp_b_M * xB <= cap_insp
        # If Enhanced (y_E=1): insp_a_E * xA + insp_b_E * xB <= cap_insp
        #                       ext_a * xA + ext_b * xB <= cap_ext

        # Manual inspection capacity (active when y_M=1, relaxed when y_E=1)
        m1.addConstr(insp_a_M * x_A[t] + insp_b_M * x_B[t] <= cap_insp + M_big * (1 - y_M[t]),
                     name=f'insp_cap_M_{t}')

        # Enhanced in-house inspection capacity (active when y_E=1)
        m1.addConstr(insp_a_E * x_A[t] + insp_b_E * x_B[t] <= cap_insp + M_big * (1 - y_E[t]),
                     name=f'insp_cap_E_{t}')

        # Enhanced external capacity (active when y_E=1)
        m1.addConstr(ext_a * x_A[t] + ext_b * x_B[t] <= cap_ext + M_big * (1 - y_E[t]),
                     name=f'ext_cap_E_{t}')

        # Idle inspection time:
        # Under Manual: idle_insp = cap_insp - (insp_a_M * xA + insp_b_M * xB)
        # Under Enhanced: idle_insp = cap_insp - (insp_a_E * xA + insp_b_E * xB)
        # We need to linearize this.
        # 
        # idle_insp[t] = cap_insp - in_house_insp_hours[t]
        # in_house_insp_hours[t] = y_M[t] * (insp_a_M*xA + insp_b_M*xB) + y_E[t] * (insp_a_E*xA + insp_b_E*xB)
        # This is nonlinear. Use auxiliary variables.
        
        # Let's define in_house_insp[t] and constrain it:
        # When y_M=1: in_house_insp = insp_a_M * xA + insp_b_M * xB
        # When y_E=1: in_house_insp = insp_a_E * xA + insp_b_E * xB

    # Add in_house_insp variables
    in_house_insp = {}
    for t in weeks:
        in_house_insp[t] = m1.addVar(lb=0, name=f'in_house_insp_{t}')
    m1.update()

    for t in weeks:
        # in_house_insp[t] >= insp_a_M * xA + insp_b_M * xB - M*(1-y_M)
        # in_house_insp[t] <= insp_a_M * xA + insp_b_M * xB + M*(1-y_M)
        m1.addConstr(in_house_insp[t] >= insp_a_M * x_A[t] + insp_b_M * x_B[t] - M_big * (1 - y_M[t]),
                     name=f'ih_lb_M_{t}')
        m1.addConstr(in_house_insp[t] <= insp_a_M * x_A[t] + insp_b_M * x_B[t] + M_big * (1 - y_M[t]),
                     name=f'ih_ub_M_{t}')

        m1.addConstr(in_house_insp[t] >= insp_a_E * x_A[t] + insp_b_E * x_B[t] - M_big * (1 - y_E[t]),
                     name=f'ih_lb_E_{t}')
        m1.addConstr(in_house_insp[t] <= insp_a_E * x_A[t] + insp_b_E * x_B[t] + M_big * (1 - y_E[t]),
                     name=f'ih_ub_E_{t}')

        # idle_insp[t] = cap_insp - in_house_insp[t]
        m1.addConstr(idle_insp[t] == cap_insp - in_house_insp[t], name=f'idle_insp_def_{t}')

        # Weekly profit constraint
        # Weekly profit = revenue - variable costs - mode_fee - risk_penalty
        # We need to linearize mode-dependent profit.
        # profit_week[t] = y_M[t] * (profit_a_M * xA + profit_b_M * xB - mode_fee_M - risk_penalty_M)
        #                + y_E[t] * (profit_a_E * xA + profit_b_E * xB - mode_fee_E)
        # This is nonlinear. Use big-M.
        
        # Under Manual: profit_a_M * xA + profit_b_M * xB - mode_fee_M - risk_penalty_M >= min_profit
        # Under Enhanced: profit_a_E * xA + profit_b_E * xB - mode_fee_E >= min_profit
        
        m1.addConstr(profit_a_M * x_A[t] + profit_b_M * x_B[t] - mode_fee_M - risk_penalty_M
                     >= min_profit - M_big * (1 - y_M[t]),
                     name=f'profit_M_{t}')
        m1.addConstr(profit_a_E * x_A[t] + profit_b_E * x_B[t] - mode_fee_E
                     >= min_profit - M_big * (1 - y_E[t]),
                     name=f'profit_E_{t}')

    # Stage 1 objective: minimize weighted idle + risk penalty
    obj1 = gp.LinExpr()
    for t in weeks:
        obj1 += cost_mfg * idle_mfg[t] + cost_asm * idle_asm[t] + cost_insp_weight * idle_insp[t]
        obj1 += risk_penalty_M * y_M[t]

    m1.setObjective(obj1, GRB.MINIMIZE)
    m1.optimize()

    if m1.status != GRB.OPTIMAL:
        print(f"Stage 1 status: {m1.status}")
        return

    opt_idle_risk = m1.ObjVal

    # --- STAGE 2: Maximize total profit, subject to idle+risk <= opt + tolerance ---
    m2 = gp.Model("stage2")
    m2.setParam('OutputFlag', 0)

    x_A2 = {}
    x_B2 = {}
    y_M2 = {}
    y_E2 = {}
    idle_mfg2 = {}
    idle_asm2 = {}
    idle_insp2 = {}
    in_house_insp2 = {}

    for t in weeks:
        x_A2[t] = m2.addVar(lb=0, vtype=GRB.INTEGER, name=f'x_A_{t}')
        x_B2[t] = m2.addVar(lb=0, vtype=GRB.INTEGER, name=f'x_B_{t}')
        y_M2[t] = m2.addVar(vtype=GRB.BINARY, name=f'y_M_{t}')
        y_E2[t] = m2.addVar(vtype=GRB.BINARY, name=f'y_E_{t}')
        idle_mfg2[t] = m2.addVar(lb=0, name=f'idle_mfg_{t}')
        idle_asm2[t] = m2.addVar(lb=0, name=f'idle_asm_{t}')
        idle_insp2[t] = m2.addVar(lb=0, name=f'idle_insp_{t}')
        in_house_insp2[t] = m2.addVar(lb=0, name=f'in_house_insp_{t}')

    # Also need profit variables for the objective
    week_profit = {}
    for t in weeks:
        week_profit[t] = m2.addVar(lb=-GRB.INFINITY, name=f'week_profit_{t}')

    m2.update()

    for t in weeks:
        m2.addConstr(y_M2[t] + y_E2[t] == 1)
        m2.addConstr(x_A2[t] >= min_a)
        m2.addConstr(mfg_a * x_A2[t] + mfg_b * x_B2[t] <= cap_mfg)
        m2.addConstr(asm_a * x_A2[t] + asm_b * x_B2[t] <= cap_asm)

        m2.addConstr(insp_a_M * x_A2[t] + insp_b_M * x_B2[t] <= cap_insp + M_big * (1 - y_M2[t]))
        m2.addConstr(insp_a_E * x_A2[t] + insp_b_E * x_B2[t] <= cap_insp + M_big * (1 - y_E2[t]))
        m2.addConstr(ext_a * x_A2[t] + ext_b * x_B2[t] <= cap_ext + M_big * (1 - y_E2[t]))

        m2.addConstr(in_house_insp2[t] >= insp_a_M * x_A2[t] + insp_b_M * x_B2[t] - M_big * (1 - y_M2[t]))
        m2.addConstr(in_house_insp2[t] <= insp_a_M * x_A2[t] + insp_b_M * x_B2[t] + M_big * (1 - y_M2[t]))
        m2.addConstr(in_house_insp2[t] >= insp_a_E * x_A2[t] + insp_b_E * x_B2[t] - M_big * (1 - y_E2[t]))
        m2.addConstr(in_house_insp2[t] <= insp_a_E * x_A2[t] + insp_b_E * x_B2[t] + M_big * (1 - y_E2[t]))

        m2.addConstr(idle_mfg2[t] == cap_mfg - (mfg_a * x_A2[t] + mfg_b * x_B2[t]))
        m2.addConstr(idle_asm2[t] == cap_asm - (asm_a * x_A2[t] + asm_b * x_B2[t]))
        m2.addConstr(idle_insp2[t] == cap_insp - in_house_insp2[t])

        # Profit constraints per week
        m2.addConstr(profit_a_M * x_A2[t] + profit_b_M * x_B2[t] - mode_fee_M - risk_penalty_M
                     >= min_profit - M_big * (1 - y_M2[t]))
        m2.addConstr(profit_a_E * x_A2[t] + profit_b_E * x_B2[t] - mode_fee_E
                     >= min_profit - M_big * (1 - y_E2[t]))

        # Weekly profit variable (for objective)
        # When Manual: week_profit = profit_a_M * xA + profit_b_M * xB - mode_fee_M - risk_penalty_M
        # When Enhanced: week_profit = profit_a_E * xA + profit_b_E * xB - mode_fee_E
        m2.addConstr(week_profit[t] <= profit_a_M * x_A2[t] + profit_b_M * x_B2[t] - mode_fee_M - risk_penalty_M
                     + M_big * (1 - y_M2[t]))
        m2.addConstr(week_profit[t] >= profit_a_M * x_A2[t] + profit_b_M * x_B2[t] - mode_fee_M - risk_penalty_M
                     - M_big * (1 - y_M2[t]))
        m2.addConstr(week_profit[t] <= profit_a_E * x_A2[t] + profit_b_E * x_B2[t] - mode_fee_E
                     + M_big * (1 - y_E2[t]))
        m2.addConstr(week_profit[t] >= profit_a_E * x_A2[t] + profit_b_E * x_B2[t] - mode_fee_E
                     - M_big * (1 - y_E2[t]))

    # Constraint: P1 objective <= optimal + tolerance
    idle_risk_expr = gp.LinExpr()
    for t in weeks:
        idle_risk_expr += cost_mfg * idle_mfg2[t] + cost_asm * idle_asm2[t] + cost_insp_weight * idle_insp2[t]
        idle_risk_expr += risk_penalty_M * y_M2[t]

    m2.addConstr(idle_risk_expr <= opt_idle_risk + idle_tolerance, name='idle_risk_bound')

    # Objective: maximize total profit
    m2.setObjective(gp.quicksum(week_profit[t] for t in weeks), GRB.MAXIMIZE)
    m2.optimize()

    if m2.status != GRB.OPTIMAL:
        print(f"Stage 2 status: {m2.status}")
        return

    final_obj = m2.ObjVal
    print(f"FINAL_OBJ_VALUE: {round(final_obj, 4)}")


if __name__ == '__main__':
    solve()
