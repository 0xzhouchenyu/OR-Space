import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Data loading
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load table_1.csv
weeks_data = []
filepath = os.path.join(data_dir, "table_1.csv")
with open(filepath, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Week'].strip().lower() == 'total':
            continue
        weeks_data.append({
            'week': int(row['Week']),
            'demand': float(row['Demand_1000_boxes']),
            'capacity': float(row['Production_Capacity_1000_boxes']),
            'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
        })

# Load general_parameters.csv
params = {}
filepath = os.path.join(data_dir, "general_parameters.csv")
with open(filepath, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'])

storage_cost = params['storage_cost_per_thousand_boxes']
fixed_setup_cost = params['fixed_setup_cost']
week2_push_threshold = params['week2_push_threshold']
week3_capacity_loss = params['week3_capacity_loss_after_week2_push']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']

n_weeks = len(weeks_data)

# Create model
model = gp.Model("Beverage_Production_Planning")
model.setParam('OutputFlag', 0)

# Big-M value
M = 200  # large enough

# Decision variables
x = {}  # production in week t
s = {}  # inventory at end of week t
y = {}  # binary: 1 if production occurs in week t (for fixed setup cost)

for t in range(n_weeks):
    x[t] = model.addVar(lb=0, ub=weeks_data[t]['capacity'], name=f"x_{t+1}")
    s[t] = model.addVar(lb=0, name=f"s_{t+1}")
    y[t] = model.addVar(vtype=GRB.BINARY, name=f"y_{t+1}")

# Binary variable: 1 if week 2 production exceeds push threshold (35)
z_push = model.addVar(vtype=GRB.BINARY, name="z_push")

# Binary variable: 1 if week 2 production exceeds microclean threshold (30)
z_micro = model.addVar(vtype=GRB.BINARY, name="z_micro")

# Week 3 effective capacity variable
cap3_eff = model.addVar(lb=0, name="cap3_eff")

model.update()

# Linking y[t] to x[t]: if x[t] > 0 then y[t] = 1
for t in range(n_weeks):
    model.addConstr(x[t] <= weeks_data[t]['capacity'] * y[t], name=f"setup_link_{t+1}")

# Inventory balance constraints (initial inventory = 0)
for t in range(n_weeks):
    if t == 0:
        model.addConstr(x[t] - s[t] == weeks_data[t]['demand'], name=f"balance_week_{t+1}")
    else:
        model.addConstr(s[t-1] + x[t] - s[t] == weeks_data[t]['demand'], name=f"balance_week_{t+1}")

# Week 2 push threshold logic: z_push = 1 if x[1] > 35
# x[1] <= 35 + M * z_push
# x[1] >= 35 + epsilon  =>  x[1] - 35 <= M * z_push  and  x[1] - 35 >= epsilon * z_push (not exact but we use indicator-like)
# We use: x[1] <= week2_push_threshold + M * z_push
#          x[1] >= week2_push_threshold + 0.001 - M * (1 - z_push)  -- but this forces z_push=1 only when x[1] > threshold
# Actually for cost minimization, z_push being 1 is penalized, so we only need:
# x[1] <= week2_push_threshold + M * z_push  (if z_push=0, x[1] <= 35)
model.addConstr(x[1] <= week2_push_threshold + M * z_push, name="push_threshold")

# Week 3 capacity depends on z_push
# cap3_eff = 45 if z_push=0, cap3_eff = 45 - 20 = 25 if z_push=1
base_cap3 = weeks_data[2]['capacity']  # 45
model.addConstr(cap3_eff == base_cap3 - week3_capacity_loss * z_push, name="cap3_effective")
model.addConstr(x[2] <= cap3_eff, name="cap3_limit")

# Week 2 microclean threshold logic: z_micro = 1 if x[1] > 30
# x[1] <= 30 + M * z_micro
model.addConstr(x[1] <= week2_microclean_threshold + M * z_micro, name="micro_threshold")

# Objective: production cost + storage cost + fixed setup cost + microclean fee (if triggered)
obj = gp.LinExpr()

# Production costs
for t in range(n_weeks):
    obj += weeks_data[t]['cost'] * x[t]

# Storage costs
for t in range(n_weeks):
    obj += storage_cost * s[t]

# Fixed setup costs
for t in range(n_weeks):
    obj += fixed_setup_cost * y[t]

# Microclean fee
obj += week2_microclean_fee * z_micro

model.setObjective(obj, GRB.MINIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    for t in range(n_weeks):
        print(f"Week {t+1}: Produce {x[t].X:.1f}, Inventory {s[t].X:.1f}, Setup {y[t].X:.0f}")
    print(f"z_push = {z_push.X:.0f}, z_micro = {z_micro.X:.0f}")
    print(f"Week 3 effective capacity: {cap3_eff.X:.1f}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
