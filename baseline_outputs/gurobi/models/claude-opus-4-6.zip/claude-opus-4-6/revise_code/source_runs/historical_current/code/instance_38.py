import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_processing_times(filepath):
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            name = row[0].strip()
            val = row[1].strip()
            if val:
                try:
                    params[name] = float(val)
                except ValueError:
                    params[name] = val
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    processing_times = load_processing_times(os.path.join(data_dir, "table_1.csv"))
    gen_params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

    n_products = len(processing_times)  # 3
    n_machines = len(processing_times[0])  # 3

    time_windows = [gen_params[f'time_window_{j+1}'] for j in range(n_machines)]
    overtime_windows = [gen_params[f'overtime_window_{j+1}'] for j in range(n_machines)]
    overtime_penalty = gen_params['overtime_penalty_per_unit']
    big_M = [gen_params[f'M_{j+1}'] for j in range(n_machines)]
    
    machine1_ot_review_threshold = gen_params['machine1_overtime_review_threshold']
    machine1_ot_review_fee = gen_params['machine1_overtime_review_fee']

    # p[i][j] = processing time of product i on machine j
    p = processing_times

    model = gp.Model("flowshop")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # s[i][j] = start time of product i on machine j (in the sequence position)
    # But we need to determine the sequence as well.
    
    # We use assignment-based formulation:
    # x[i][k] = 1 if product i is assigned to position k in the sequence
    x = {}
    for i in range(n_products):
        for k in range(n_products):
            x[i, k] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{k}")

    # start[k][j] = start time of the product in position k on machine j
    start = {}
    for k in range(n_products):
        for j in range(n_machines):
            start[k, j] = model.addVar(lb=0, name=f"start_{k}_{j}")

    # completion[k][j] = completion time of product in position k on machine j
    comp = {}
    for k in range(n_products):
        for j in range(n_machines):
            comp[k, j] = model.addVar(lb=0, name=f"comp_{k}_{j}")

    # Processing time of product in position k on machine j
    pt = {}
    for k in range(n_products):
        for j in range(n_machines):
            pt[k, j] = model.addVar(lb=0, name=f"pt_{k}_{j}")

    # Overtime variables for each machine
    overtime = {}
    for j in range(n_machines):
        overtime[j] = model.addVar(lb=0, ub=overtime_windows[j], name=f"overtime_{j}")

    # Machine 1 overtime review binary and excess variable
    z_m1 = model.addVar(vtype=GRB.BINARY, name="z_m1_review")
    m1_ot_excess = model.addVar(lb=0, name="m1_ot_excess")

    # Makespan
    makespan = model.addVar(lb=0, name="makespan")

    model.update()

    # Assignment constraints: each product assigned to exactly one position
    for i in range(n_products):
        model.addConstr(gp.quicksum(x[i, k] for k in range(n_products)) == 1)

    # Each position has exactly one product
    for k in range(n_products):
        model.addConstr(gp.quicksum(x[i, k] for i in range(n_products)) == 1)

    # Link processing times to positions
    for k in range(n_products):
        for j in range(n_machines):
            model.addConstr(pt[k, j] == gp.quicksum(p[i][j] * x[i, k] for i in range(n_products)))

    # Completion = start + processing time
    for k in range(n_products):
        for j in range(n_machines):
            model.addConstr(comp[k, j] == start[k, j] + pt[k, j])

    # Precedence on machines: product in position k must finish on machine j before machine j+1
    for k in range(n_products):
        for j in range(n_machines - 1):
            model.addConstr(start[k, j + 1] >= comp[k, j])

    # Precedence on positions: position k must finish on machine j before position k+1 starts on machine j
    for k in range(n_products - 1):
        for j in range(n_machines):
            model.addConstr(start[k + 1, j] >= comp[k, j])

    # Machine availability: total usage of each machine <= time_window + overtime
    # Total usage on machine j = completion time of last product on machine j (since no idle beyond sequencing)
    # Actually, the total time machine j is occupied = comp[n_products-1, j] - start[0, j]
    # But more precisely, the "span" on machine j from first start to last completion
    # The machine is available for time_window + overtime seconds total
    # The total occupancy on machine j is the completion of the last job on that machine
    # (assuming first job starts at time 0 or later on that machine)
    
    # The machine span = comp[last, j] (since start[0, j] >= 0, the machine needs to be available
    # from time 0 to comp[last, j], but the constraint is about machine availability window)
    # Actually, the total processing time on machine j = sum of all processing times on that machine
    # The machine span includes idle times between jobs.
    # The constraint should be: comp[n_products-1, j] <= time_window_j + overtime_j
    
    for j in range(n_machines):
        model.addConstr(comp[n_products - 1, j] <= time_windows[j] + overtime[j])

    # Machine 1 overtime review: if overtime[0] > threshold, then z_m1 = 1 and fee applies
    # m1_ot_excess = max(0, overtime[0] - threshold)
    model.addConstr(m1_ot_excess >= overtime[0] - machine1_ot_review_threshold)
    model.addConstr(m1_ot_excess >= 0)
    # z_m1 = 1 if m1_ot_excess > 0
    # m1_ot_excess <= overtime_windows[0] * z_m1
    model.addConstr(m1_ot_excess <= overtime_windows[0] * z_m1)
    # Also need: if overtime[0] > threshold then z_m1 = 1
    # The above constraints achieve: m1_ot_excess >= overtime[0] - threshold, 
    # m1_ot_excess <= big_number * z_m1, and z_m1 is binary
    # Since we minimize cost including m1_ot_excess penalty terms, this should work

    # Makespan
    for j in range(n_machines):
        model.addConstr(makespan >= comp[n_products - 1, j])

    # Objective: minimize makespan + overtime penalties + machine 1 review fee
    # overtime_penalty_per_unit applies to each second of overtime on each machine
    # machine1_overtime_review_fee is a one-time fee if machine 1 overtime > threshold
    obj = makespan
    for j in range(n_machines):
        obj += overtime_penalty * overtime[j]
    # Machine 1 special: the review fee of 1.2 if overtime > 1 second
    obj += machine1_ot_review_fee * z_m1

    model.setObjective(obj, GRB.MINIMIZE)
    model.optimize()

    if model.status == GRB.OPTIMAL or model.status == GRB.SUBOPTIMAL:
        obj_val = model.ObjVal
        
        # Print solution details
        seq = [0] * n_products
        for i in range(n_products):
            for k in range(n_products):
                if x[i, k].X > 0.5:
                    seq[k] = i
        
        print(f"Optimal sequence: {[s+1 for s in seq]}")
        print(f"Makespan: {makespan.X}")
        for j in range(n_machines):
            print(f"Machine {j+1} overtime: {overtime[j].X}")
        print(f"Machine 1 overtime excess beyond threshold: {m1_ot_excess.X}")
        print(f"Machine 1 review triggered: {z_m1.X}")
        print(f"Objective value: {obj_val}")
        
        print(f"\nFINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        # Try relaxing to find issue
        model.computeIIS()
        model.write("model_iis.ilp")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
