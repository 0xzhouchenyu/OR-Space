import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'table_1.csv')
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    machine_avail = params['machine_time_available']  # 40 hours
    craftsman_regular_avail = params['craftsman_regular_time_available']  # 25 hours
    craftsman_overtime_avail = params['craftsman_overtime_available']  # 10 hours
    machine_cost = params['machine_time_cost']  # 10 GBP/hour
    craftsman_cost = params['craftsman_time_cost']  # 2 GBP/hour
    craftsman_overtime_cost = params['craftsman_overtime_cost']  # 7 GBP/hour
    rev_X = params['revenue_product_X']  # 20 GBP/batch
    rev_Y = params['revenue_product_Y']  # 30 GBP/batch
    min_X = params['min_batches_product_X']  # 10 batches
    qa_threshold = params['product_Y_QA_threshold']  # 60 batches
    qa_fee = params['product_Y_QA_fee']  # 10 GBP one-time
    
    # Create model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    X = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="X")
    Y = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Y")
    
    # Craftsman time split: regular and overtime
    craftsman_regular = model.addVar(lb=0, ub=craftsman_regular_avail, vtype=GRB.CONTINUOUS, name="craftsman_regular")
    craftsman_overtime = model.addVar(lb=0, ub=craftsman_overtime_avail, vtype=GRB.CONTINUOUS, name="craftsman_overtime")
    
    # Binary variable for QA fee trigger
    z_qa = model.addVar(vtype=GRB.BINARY, name="z_qa")
    
    # Total machine hours used
    machine_hours_used = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0
    
    # Total craftsman hours used
    craftsman_hours_used = (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0
    
    # Machine time constraint
    model.addConstr(machine_hours_used <= machine_avail, "Machine_Time_Constraint")
    
    # Craftsman time: regular + overtime must cover total needed
    model.addConstr(craftsman_regular + craftsman_overtime >= craftsman_hours_used, "Craftsman_Time_Coverage")
    
    # Minimum production of X
    model.addConstr(X >= min_X, "Min_Production_X")
    
    # QA threshold: if Y > qa_threshold, z_qa = 1
    # Big-M formulation: Y <= qa_threshold + M * z_qa
    # We need an upper bound on Y. Given machine constraint: Y <= 40*60/19 ≈ 126.3
    M_qa = 200  # sufficiently large
    model.addConstr(Y <= qa_threshold + M_qa * z_qa, "QA_Threshold")
    
    # Objective: maximize revenue - costs
    profit = (rev_X * X + rev_Y * Y 
              - machine_cost * machine_hours_used 
              - craftsman_cost * craftsman_regular 
              - craftsman_overtime_cost * craftsman_overtime
              - qa_fee * z_qa)
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal:.4f}")

if __name__ == "__main__":
    main()
