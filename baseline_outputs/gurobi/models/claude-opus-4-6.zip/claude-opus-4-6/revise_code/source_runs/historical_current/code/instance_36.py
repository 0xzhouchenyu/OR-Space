import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')

    # Read parameters
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']

    num_customers = int(params['num_customers'])
    max_trucks = int(params['max_trucks'])
    truck_capacity = float(params['truck_capacity'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])

    depot_str = params['depot_coordinates'].strip().strip('"').strip('()')
    if ',' in depot_str:
        depot_x, depot_y = map(float, depot_str.split(','))
    else:
        depot_x, depot_y = map(float, depot_str.split())

    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])

    # Read customer data
    coords = [(depot_x, depot_y)]  # index 0 = depot
    demands_list = [0]
    tw_list = [(depot_tw_start, depot_tw_end)]
    svc_list = [0]
    outsource_cost = [0]  # depot has no outsource cost
    mandatory_external = [0]  # depot is not external

    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((float(row['Coordinates_X']), float(row['Coordinates_Y'])))
            demands_list.append(float(row['Demand']))
            tw_list.append((float(row['Time_Window_Start']), float(row['Time_Window_End'])))
            svc_list.append(float(row['Service_Duration']))
            outsource_cost.append(float(row['Outsource_Cost']))
            mandatory_external.append(int(row['Mandatory_External']))

    n = len(coords)  # 0=depot, 1..20=customers
    N = list(range(1, n))  # all customers
    V = list(range(n))     # all nodes including depot

    # Identify mandatory external customers and optional customers
    mandatory_ext = [i for i in N if mandatory_external[i] == 1]
    optional_cust = [i for i in N if mandatory_external[i] == 0]

    # All customers that could potentially be served in-house
    # Mandatory external ones cannot be served in-house
    inhouse_candidates = optional_cust  # customers that can be either in-house or outsourced

    # Distance matrix
    dist = {}
    for i in V:
        for j in V:
            dist[i, j] = calculate_distance(coords[i], coords[j])

    # Build arc set - only for nodes that could be in-house (depot + inhouse_candidates)
    # Nodes in the routing: depot (0) + inhouse_candidates
    route_nodes = [0] + inhouse_candidates

    A = []
    for i in route_nodes:
        for j in route_nodes:
            if i == j:
                continue
            # Time feasibility pruning
            if i != 0 and j != 0:
                if tw_list[i][0] + svc_list[i] + dist[i, j] > tw_list[j][1]:
                    continue
            if i == 0 and j != 0:
                if tw_list[0][0] + dist[0, j] > tw_list[j][1]:
                    continue
            if i != 0 and j == 0:
                if tw_list[i][0] + svc_list[i] + dist[i, 0] > tw_list[0][1]:
                    continue
            A.append((i, j))

    A_set = set(A)

    # Create model
    model = gp.Model("VRPHTW_Revised")
    model.setParam('OutputFlag', 0)
    model.setParam('TimeLimit', 300)

    # Decision variables
    # x[i,j] = 1 if arc (i,j) is used by some in-house truck
    x = {}
    for (i, j) in A:
        x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")

    # y[i] = 1 if customer i is outsourced (for optional customers)
    y = {}
    for i in inhouse_candidates:
        y[i] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}")

    # t[i] = arrival/start-of-service time at node i
    t = {}
    for i in route_nodes:
        t[i] = model.addVar(lb=tw_list[i][0], ub=tw_list[i][1], vtype=GRB.CONTINUOUS, name=f"t_{i}")

    # u[i] = cumulative load when arriving at customer i (for subtour elimination / capacity)
    u = {}
    for i in inhouse_candidates:
        u[i] = model.addVar(lb=demands_list[i], ub=truck_capacity, vtype=GRB.CONTINUOUS, name=f"u_{i}")

    model.update()

    # Objective: minimize in-house travel distance + outsourcing costs
    # Mandatory external customers always incur their outsource cost
    mandatory_ext_cost = sum(outsource_cost[i] for i in mandatory_ext)

    model.setObjective(
        gp.quicksum(dist[i, j] * x[i, j] for (i, j) in A) +
        gp.quicksum(outsource_cost[i] * y[i] for i in inhouse_candidates) +
        mandatory_ext_cost,
        GRB.MINIMIZE
    )

    # Constraints

    # 1. Fleet size limit: number of trucks leaving depot <= inhouse_truck_limit
    model.addConstr(
        gp.quicksum(x[0, j] for j in inhouse_candidates if (0, j) in A_set) <= inhouse_truck_limit,
        "fleet_limit"
    )

    # 2. Each optional customer is either served in-house (exactly one visit) or outsourced
    for i in inhouse_candidates:
        # sum of arcs into i = 1 - y[i] (if in-house, exactly one visit; if outsourced, zero visits)
        model.addConstr(
            gp.quicksum(x[j, i] for j in route_nodes if (j, i) in A_set) == 1 - y[i],
            f"visit_in_{i}"
        )
        # flow conservation: arcs in = arcs out for each customer
        model.addConstr(
            gp.quicksum(x[j, i] for j in route_nodes if (j, i) in A_set) ==
            gp.quicksum(x[i, j] for j in route_nodes if (i, j) in A_set),
            f"flow_{i}"
        )

    # 3. Depot flow balance: trucks leaving = trucks returning
    model.addConstr(
        gp.quicksum(x[0, j] for j in inhouse_candidates if (0, j) in A_set) ==
        gp.quicksum(x[i, 0] for i in inhouse_candidates if (i, 0) in A_set),
        "depot_flow"
    )

    # 4. Time window constraints with big-M
    M_val = depot_tw_end + max(svc_list) + max(dist[i, j] for i in route_nodes for j in route_nodes if i != j)
    for (i, j) in A:
        if j != 0:
            model.addConstr(
                t[i] + svc_list[i] + dist[i, j] - t[j] <= M_val * (1 - x[i, j]),
                f"time_{i}_{j}"
            )
        else:
            # Return to depot: ensure truck returns within depot window
            model.addConstr(
                t[i] + svc_list[i] + dist[i, 0] <= depot_tw_end + M_val * (1 - x[i, 0]),
                f"time_return_{i}"
            )

    # 5. Capacity constraints using MTZ-style
    for (i, j) in A:
        if i != 0 and j != 0:
            model.addConstr(
                u[i] + demands_list[j] - u[j] <= truck_capacity * (1 - x[i, j]),
                f"cap_{i}_{j}"
            )
        elif i == 0 and j != 0:
            model.addConstr(
                demands_list[j] - u[j] <= truck_capacity * (1 - x[0, j]),
                f"cap_depot_{j}"
            )

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL or model.status == GRB.TIME_LIMIT:
        if model.SolCount > 0:
            obj = model.ObjVal
            print(f"FINAL_OBJ_VALUE: {round(obj, 2)}")
        else:
            print("FINAL_OBJ_VALUE: None")
    else:
        print("FINAL_OBJ_VALUE: None")

solve()
