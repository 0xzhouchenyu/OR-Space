import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read table_1.csv
    filepath = os.path.join(data_dir, "table_1.csv")
    
    workers = []
    tasks = []
    cost = {}
    fixed_cost = {}
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        tasks = header[1:-1]  # ['A', 'B', 'C', 'D'] excluding 'Fixed_Cost'
        
        for row in reader:
            worker = row[0].strip()
            workers.append(worker)
            for j, task in enumerate(tasks):
                cost[(worker, task)] = int(row[j + 1])
            fixed_cost[worker] = int(row[-1])
    
    # Read general_parameters.csv
    params_filepath = os.path.join(data_dir, "general_parameters.csv")
    params = {}
    with open(params_filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    
    shared_temp_handoff_cost = params['shared_temp_handoff_cost']  # 6, for III and V
    worker_II_V_pair_fee = params['worker_II_V_pair_fee']  # 5, for II and V
    
    # Understand the fixed cost logic from the business brief:
    # "Crossing a named business line changes eligibility for the allowance, desk, setup, waiver, or fee; 
    #  staying on the other side does not."
    # This is described as a "gate" - a threshold. Looking at Fixed_Cost column:
    # Worker I: 2, II: 10, III: 8, IV: 3, V: 4
    # The "gate" concept: there's a threshold. Workers whose fixed cost crosses (exceeds) a business line
    # incur the fixed cost; those who don't, don't.
    # The threshold appears to be 5 (median-ish value). Workers with Fixed_Cost > 5: II(10), III(8)
    # Workers with Fixed_Cost <= 5: I(2), IV(3), V(4)
    # So workers II and III incur their fixed cost if selected; others don't.
    # Actually, re-reading: "Crossing a named business line changes eligibility"
    # The fixed cost is the cost that applies when a worker crosses the threshold.
    # Let me use threshold = 5 as the gate. Workers with Fixed_Cost > 5 pay their Fixed_Cost.
    
    threshold = 5  # The gate/business line
    
    # Create model
    model = gp.Model("Assignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    for w in workers:
        for t in tasks:
            x[(w, t)] = model.addVar(vtype=GRB.BINARY, name=f"x_{w}_{t}")
    
    # y[w] = 1 if worker w is selected (assigned to any task)
    y = {}
    for w in workers:
        y[w] = model.addVar(vtype=GRB.BINARY, name=f"y_{w}")
    
    # z_III_V = 1 if both III and V are selected
    z_III_V = model.addVar(vtype=GRB.BINARY, name="z_III_V")
    
    # z_II_V = 1 if both II and V are selected
    z_II_V = model.addVar(vtype=GRB.BINARY, name="z_II_V")
    
    model.update()
    
    # Constraints
    # Each task assigned to exactly one worker
    for t in tasks:
        model.addConstr(gp.quicksum(x[(w, t)] for w in workers) == 1)
    
    # Each worker assigned to at most one task
    for w in workers:
        model.addConstr(gp.quicksum(x[(w, t)] for t in tasks) <= 1)
    
    # Link y to x
    for w in workers:
        model.addConstr(y[w] == gp.quicksum(x[(w, t)] for t in tasks))
    
    # Exactly 4 workers selected
    model.addConstr(gp.quicksum(y[w] for w in workers) == 4)
    
    # z_III_V linearization
    model.addConstr(z_III_V >= y['III'] + y['V'] - 1)
    model.addConstr(z_III_V <= y['III'])
    model.addConstr(z_III_V <= y['V'])
    
    # z_II_V linearization
    model.addConstr(z_II_V >= y['II'] + y['V'] - 1)
    model.addConstr(z_II_V <= y['II'])
    model.addConstr(z_II_V <= y['V'])
    
    # Objective: task costs + fixed costs for workers crossing the gate + pair fees
    # Fixed cost applies only if worker's Fixed_Cost > threshold (the gate)
    obj = gp.quicksum(cost[(w, t)] * x[(w, t)] for w in workers for t in tasks)
    
    for w in workers:
        if fixed_cost[w] > threshold:
            obj += fixed_cost[w] * y[w]
    
    obj += shared_temp_handoff_cost * z_III_V
    obj += worker_II_V_pair_fee * z_II_V
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print("Assignment:")
        for w in workers:
            for t in tasks:
                if x[(w, t)].X > 0.5:
                    fc = fixed_cost[w] if fixed_cost[w] > threshold else 0
                    print(f"  Worker {w} -> Task {t} (time: {cost[(w, t)]}, fixed: {fc})")
        if z_III_V.X > 0.5:
            print(f"  III-V handoff charge: {shared_temp_handoff_cost}")
        if z_II_V.X > 0.5:
            print(f"  II-V pair fee: {worker_II_V_pair_fee}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")

if __name__ == "__main__":
    main()
