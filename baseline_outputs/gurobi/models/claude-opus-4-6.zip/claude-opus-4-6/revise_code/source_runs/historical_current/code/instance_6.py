import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load demand data
    demand = {}
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        quarters = [int(h) for h in header[1:]]
        for row in reader:
            product = row[0].strip()
            for j, q in enumerate(quarters):
                demand[(product, q)] = int(row[j+1])
    
    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    
    products = ['I', 'II', 'III']
    quarters_list = [1, 2, 3, 4]
    
    init_inv = params['initial_inventory']
    end_inv_req = params['end_inventory_requirement']
    hours_per_quarter = params['production_hours_per_quarter']
    hours_per_unit = {
        'I': params['product_I_hours_per_unit'],
        'II': params['product_II_hours_per_unit'],
        'III': params['product_III_hours_per_unit']
    }
    delay_penalty = {
        'I': params['delay_penalty_product_I'],
        'II': params['delay_penalty_product_II'],
        'III': params['delay_penalty_product_III']
    }
    inv_cost = params['inventory_cost_per_unit']
    
    # Normal hours cap per quarter
    normal_hours_cap = {}
    for t in quarters_list:
        frac = params[f'normal_hours_cap_fraction_q{t}']
        normal_hours_cap[t] = frac * hours_per_quarter
    
    # Peak hours cap per quarter
    peak_hours_cap = {}
    for t in quarters_list:
        peak_hours_cap[t] = params[f'peak_hours_cap_q{t}']
    
    # Peak cost per hour per quarter
    peak_cost_per_hour = {}
    for t in quarters_list:
        peak_cost_per_hour[t] = params[f'peak_cost_per_hour_q{t}']
    
    # Create model
    model = gp.Model("ProductionScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: production quantities (integer)
    x = {}
    for p in products:
        for t in quarters_list:
            ub = GRB.INFINITY
            if p == 'I' and t == 2:
                ub = 0  # Product I cannot be produced in Q2
            x[(p, t)] = model.addVar(lb=0, ub=ub, vtype=GRB.INTEGER, name=f"x_{p}_{t}")
    
    # Peak hours used per quarter
    peak_hours = {}
    for t in quarters_list:
        peak_hours[t] = model.addVar(lb=0, ub=peak_hours_cap[t], vtype=GRB.CONTINUOUS, name=f"peak_hours_{t}")
    
    # Inventory variables (can be negative = backlog/delay)
    inv = {}
    for p in products:
        for t in quarters_list:
            inv[(p, t)] = model.addVar(lb=-GRB.INFINITY, vtype=GRB.CONTINUOUS, name=f"inv_{p}_{t}")
    
    # Positive and negative inventory parts
    inv_pos = {}
    inv_neg = {}
    for p in products:
        for t in quarters_list:
            inv_pos[(p, t)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"inv_pos_{p}_{t}")
            inv_neg[(p, t)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"inv_neg_{p}_{t}")
    
    model.update()
    
    # Inventory balance constraints
    for p in products:
        # Quarter 1
        model.addConstr(inv[(p, 1)] == init_inv + x[(p, 1)] - demand[(p, 1)], name=f"inv_bal_{p}_1")
        # Quarters 2-4
        for t in range(2, 5):
            model.addConstr(inv[(p, t)] == inv[(p, t-1)] + x[(p, t)] - demand[(p, t)], name=f"inv_bal_{p}_{t}")
    
    # Split inventory into positive and negative parts
    for p in products:
        for t in quarters_list:
            model.addConstr(inv[(p, t)] == inv_pos[(p, t)] - inv_neg[(p, t)], name=f"inv_split_{p}_{t}")
    
    # End of Q4: inventory must be at least end_inv_req
    for p in products:
        model.addConstr(inv[(p, 4)] >= end_inv_req, name=f"end_inv_{p}")
    
    # Production hours constraints per quarter:
    # Total production hours = sum of hours_per_unit[p] * x[p,t] for all p
    # This must be <= normal_hours_cap[t] + peak_hours[t]
    # peak_hours[t] <= peak_hours_cap[t]
    # Normal hours used = total_hours - peak_hours (if total > normal cap, overflow goes to peak)
    # We need: total_hours <= normal_hours_cap[t] + peak_hours[t]
    # and peak_hours[t] >= total_hours - normal_hours_cap[t] (peak hours captures overflow)
    # and peak_hours[t] >= 0
    
    for t in quarters_list:
        total_hours_expr = gp.quicksum(hours_per_unit[p] * x[(p, t)] for p in products)
        # Total hours cannot exceed normal + peak cap
        model.addConstr(total_hours_expr <= normal_hours_cap[t] + peak_hours_cap[t], name=f"total_hours_cap_{t}")
        # Peak hours must cover any overflow beyond normal cap
        model.addConstr(peak_hours[t] >= total_hours_expr - normal_hours_cap[t], name=f"peak_overflow_{t}")
        # Peak hours bounded by actual usage (can't exceed total hours used)
        # This is implicitly handled since peak_hours >= 0 and we minimize cost
    
    # Objective: minimize delay penalties + inventory holding costs + peak hours costs
    obj = gp.quicksum(
        delay_penalty[p] * inv_neg[(p, t)] + inv_cost * inv_pos[(p, t)]
        for p in products for t in quarters_list
    ) + gp.quicksum(
        peak_cost_per_hour[t] * peak_hours[t]
        for t in quarters_list
    )
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal if model.SolCount > 0 else 'INFEASIBLE'}")

if __name__ == "__main__":
    main()
