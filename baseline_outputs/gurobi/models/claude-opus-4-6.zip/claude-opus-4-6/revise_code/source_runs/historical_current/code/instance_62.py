import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Load restaurant data
    restaurants = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'standard_staff_hours': float(row['Standard_Staff_Hours'].strip()),
                'premium_staff_hours': float(row['Premium_Staff_Hours'].strip()),
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    
    budget = params['investment_budget']
    premium_revenue_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']
    
    # Create model
    model = gp.Model("Restaurant_Investment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i] = 1 if restaurant i is bought (standard mode)
    # p[i] = 1 if restaurant i is bought and operated in premium mode
    # Note: a restaurant is bought if x[i] + p[i] >= 1, but we model it as:
    # buy[i] = 1 if bought, premium[i] = 1 if operated in premium mode (requires buy[i]=1)
    
    names = [r['name'] for r in restaurants]
    
    buy = {}
    premium = {}
    for r in restaurants:
        n = r['name']
        buy[n] = model.addVar(vtype=GRB.BINARY, name=f"buy_{n}")
        premium[n] = model.addVar(vtype=GRB.BINARY, name=f"premium_{n}")
    
    # Premium requires buying
    for r in restaurants:
        n = r['name']
        model.addConstr(premium[n] <= buy[n], name=f"premium_requires_buy_{n}")
    
    # Objective: maximize total annual revenue
    # Revenue for restaurant i: revenue_i if standard, revenue_i * (1 + uplift) if premium
    # = revenue_i * buy[i] + revenue_i * premium_revenue_uplift * premium[i]
    obj = gp.LinExpr()
    for r in restaurants:
        n = r['name']
        obj += r['revenue'] * buy[n] + r['revenue'] * premium_revenue_uplift * premium[n]
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Budget constraint: sum of (cost[i]*buy[i] + premium_upgrade_cost*premium[i]) <= budget
    budget_expr = gp.LinExpr()
    for r in restaurants:
        n = r['name']
        budget_expr += r['cost'] * buy[n] + premium_upgrade_cost * premium[n]
    model.addConstr(budget_expr <= budget, name="Budget_Constraint")
    
    # Staff hours constraint: 
    # For each bought restaurant, staff hours = standard if not premium, premium if premium
    # = standard_staff_hours * (buy[i] - premium[i]) + premium_staff_hours * premium[i]
    # = standard_staff_hours * buy[i] + (premium_staff_hours - standard_staff_hours) * premium[i]
    staff_expr = gp.LinExpr()
    for r in restaurants:
        n = r['name']
        staff_expr += r['standard_staff_hours'] * buy[n] + (r['premium_staff_hours'] - r['standard_staff_hours']) * premium[n]
    model.addConstr(staff_expr <= staff_hours_cap, name="Staff_Hours_Constraint")
    
    # D-A exclusion constraint
    if 'Restaurant_D' in buy and 'Restaurant_A' in buy:
        model.addConstr(buy['Restaurant_D'] + buy['Restaurant_A'] <= 1, name="D_A_Exclusion")
    
    # Solve
    model.optimize()
    
    # Print results
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        for r in restaurants:
            n = r['name']
            b = buy[n].X
            p = premium[n].X
            if b > 0.5:
                mode = "Premium" if p > 0.5 else "Standard"
                print(f"{n}: Buy ({mode})")
            else:
                print(f"{n}: Do not buy")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found (status={model.status})")

if __name__ == "__main__":
    main()
