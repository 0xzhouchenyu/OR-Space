from gurobi_execution_record import install_gurobi_objective_recorder
install_gurobi_objective_recorder('Advanced_35')

import os
import sys
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load processing times
    filepath = os.path.join(base_dir, 'table_1.csv')
    batches = []
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        num_vats = len(header) - 1
        for row in reader:
            batch_id = int(row[0])
            times = [float(row[j+1]) for j in range(num_vats)]
            batches.append(batch_id)
            processing_times.append(times)
    
    # Load general parameters
    params = {}
    filepath2 = os.path.join(base_dir, 'general_parameters.csv')
    with open(filepath2, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            params[row[0].strip()] = float(row[1])
    
    return batches, processing_times, num_vats, params

def solve():
    batches, processing_times, num_vats, params = load_data()
    
    n = len(batches)
    T = int(params['planning_horizon_T'])
    energy_cost = [params['energy_cost_v1'], params['energy_cost_v2'], params['energy_cost_v3']]
    peak_multiplier = params['peak_energy_multiplier']
    peak_cap = params['peak_energy_cap']
    makespan_weight = params['makespan_weight']
    energy_weight = params['energy_weight']
    
    # Round up processing times to next integer
    proc = []
    for i in range(n):
        proc.append([int(math.ceil(processing_times[i][j])) for j in range(num_vats)])
    
    # Periods: 1 to T
    periods = list(range(1, T + 1))
    peak_periods = [6, 7, 8]
    maintenance_periods = [4, 5]  # Vat 2 (index 1) maintenance
    
    model = gp.Model("dyeing_schedule")
    model.setParam('OutputFlag', 0)
    model.setParam('TimeLimit', 300)
    
    # Binary start variables: x[i,j,t] = 1 if batch i starts on vat j at period t
    x = {}
    for i in range(n):
        for j in range(num_vats):
            p_ij = proc[i][j]
            for t in periods:
                # Batch must finish within horizon: t + p_ij - 1 <= T
                if t + p_ij - 1 <= T:
                    # Check maintenance: if vat j=1 (Vat 2), no overlap with periods 4,5
                    # The batch occupies periods t, t+1, ..., t+p_ij-1
                    occupied = set(range(t, t + p_ij))
                    if j == 1 and occupied.intersection(maintenance_periods):
                        continue
                    x[i, j, t] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}_{t}")
    
    model.update()
    
    # Each batch must start exactly once on each vat
    for i in range(n):
        for j in range(num_vats):
            valid_vars = [x[i, j, t] for t in periods if (i, j, t) in x]
            model.addConstr(gp.quicksum(valid_vars) == 1, name=f"assign_{i}_{j}")
    
    # No overlap: each vat processes at most one batch at a time
    # For each vat j and period t, sum over batches i of indicator that batch i occupies vat j at period t <= 1
    # Batch i occupies vat j at period t if it started at some s where s <= t <= s + p_ij - 1
    for j in range(num_vats):
        for t in periods:
            overlap_vars = []
            for i in range(n):
                p_ij = proc[i][j]
                for s in range(max(1, t - p_ij + 1), t + 1):
                    if (i, j, s) in x:
                        overlap_vars.append(x[i, j, s])
            if overlap_vars:
                model.addConstr(gp.quicksum(overlap_vars) <= 1, name=f"nooverlap_{j}_{t}")
    
    # Precedence constraints: batch i must finish on vat j before starting on vat j+1
    # "If a batch's booked run on one vat ends in a given indexed period, 
    #  the next vat may take it at the start of that same indexed period"
    # So: start[i,j] + proc[i][j] <= start[i,j+1] + 1
    # Which means: completion period of vat j = start[i,j] + proc[i][j] - 1
    # Next vat can start at that same period: start[i,j+1] >= start[i,j] + proc[i][j] - 1
    # Actually let me re-read: "ends in a given indexed period, the next vat may take it at the start of that same indexed period"
    # If batch occupies vat j in periods s, s+1, ..., s+p-1, it "ends" in period s+p-1.
    # Next vat can start at period s+p-1 (same indexed period).
    # So: start[i,j+1] >= start[i,j] + proc[i][j] - 1
    
    # We need to express start times. Let's create auxiliary variables for start times.
    start_time = {}
    for i in range(n):
        for j in range(num_vats):
            start_time[i, j] = model.addVar(lb=1, ub=T, vtype=GRB.INTEGER, name=f"st_{i}_{j}")
            # Link to x variables
            model.addConstr(
                start_time[i, j] == gp.quicksum(t * x[i, j, t] for t in periods if (i, j, t) in x),
                name=f"link_st_{i}_{j}"
            )
    
    for i in range(n):
        for j in range(num_vats - 1):
            # start[i,j+1] >= start[i,j] + proc[i][j] - 1
            model.addConstr(
                start_time[i, j+1] >= start_time[i, j] + proc[i][j] - 1,
                name=f"prec_{i}_{j}"
            )
    
    # Makespan variable
    makespan = model.addVar(lb=0, ub=T, vtype=GRB.INTEGER, name="makespan")
    for i in range(n):
        j = num_vats - 1  # last vat
        # Completion time of batch i on last vat = start[i,j] + proc[i][j] - 1
        model.addConstr(
            makespan >= start_time[i, j] + proc[i][j] - 1,
            name=f"makespan_{i}"
        )
    
    # Energy cost computation
    # y[j,t] = 1 if vat j is active (processing some batch) in period t
    y = {}
    for j in range(num_vats):
        for t in periods:
            y[j, t] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}_{t}")
            # y[j,t] = 1 if any batch occupies vat j at period t
            overlap_vars = []
            for i in range(n):
                p_ij = proc[i][j]
                for s in range(max(1, t - p_ij + 1), t + 1):
                    if (i, j, s) in x:
                        overlap_vars.append(x[i, j, s])
            if overlap_vars:
                model.addConstr(y[j, t] == gp.quicksum(overlap_vars), name=f"ylink_{j}_{t}")
            else:
                model.addConstr(y[j, t] == 0, name=f"ylink_{j}_{t}")
    
    # Total energy cost
    total_energy = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_energy")
    energy_expr = gp.LinExpr()
    for j in range(num_vats):
        for t in periods:
            if t in peak_periods:
                cost = energy_cost[j] * peak_multiplier
            else:
                cost = energy_cost[j]
            energy_expr += cost * y[j, t]
    
    model.addConstr(total_energy == energy_expr, name="energy_def")
    
    # Peak energy cap: total tariff-weighted usage in peak periods
    peak_usage = gp.LinExpr()
    for j in range(num_vats):
        for t in peak_periods:
            peak_usage += energy_cost[j] * peak_multiplier * y[j, t]
    
    model.addConstr(peak_usage <= peak_cap, name="peak_cap")
    
    # Objective: minimize makespan_weight * makespan + energy_weight * total_energy
    model.setObjective(
        makespan_weight * makespan + energy_weight * total_energy,
        GRB.MINIMIZE
    )
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL or model.status == GRB.TIME_LIMIT:
        obj_val = model.ObjVal
        
        print(f"Makespan: {makespan.X}")
        print(f"Total Energy Cost: {total_energy.X}")
        
        for i in range(n):
            for j in range(num_vats):
                st = int(round(start_time[i, j].X))
                end = st + proc[i][j] - 1
                print(f"Batch {batches[i]}, Vat {j+1}: start={st}, end={end}, duration={proc[i][j]}")
        
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        # Try to get any feasible solution
        if model.SolCount > 0:
            obj_val = model.ObjVal
            print(f"FINAL_OBJ_VALUE: {obj_val}")
        else:
            print("No feasible solution found")
            print(f"FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    solve()
