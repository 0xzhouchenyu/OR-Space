import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'name': row['Product Name'].strip(),
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            })
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    available_labor = params['available_labor']
    available_material = params['available_material']
    fixed_costs = [params['fixed_cost_shirts'], params['fixed_cost_short_sleeves'], params['fixed_cost_casual_clothes']]
    
    regular_discount = params['segment_regular_discount']
    promo_discount = params['segment_promo_discount']
    promo_labor_cap = params['segment_promo_labor_cap']
    promo_material_cap = params['segment_promo_material_cap']
    
    min_batch = [params['min_batch_shirts'], params['min_batch_short_sleeves'], params['min_batch_casual_clothes']]
    max_prod = [params['max_prod_shirts'], params['max_prod_short_sleeves'], params['max_prod_casual_clothes']]
    
    n = len(products)
    
    model = gp.Model("clothing_production_revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_r[i] = units of product i sold in regular segment
    # x_p[i] = units of product i sold in promotional segment
    x_r = [model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_r_{i}") for i in range(n)]
    x_p = [model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_p_{i}") for i in range(n)]
    
    # y[i] = 1 if equipment for product i is activated (product line is open)
    y = [model.addVar(vtype=GRB.BINARY, name=f"y_{i}") for i in range(n)]
    
    # z_r[i] = 1 if product i is present in regular segment (clears min batch in that segment)
    # z_p[i] = 1 if product i is present in promo segment (clears min batch in that segment)
    z_r = [model.addVar(vtype=GRB.BINARY, name=f"z_r_{i}") for i in range(n)]
    z_p = [model.addVar(vtype=GRB.BINARY, name=f"z_p_{i}") for i in range(n)]
    
    model.update()
    
    # Objective: maximize profit
    # Revenue from regular segment: regular_discount * price * x_r[i]
    # Revenue from promo segment: promo_discount * price * x_p[i]
    # Variable cost: var_cost * (x_r[i] + x_p[i])
    # Fixed cost: fixed_costs[i] * y[i]
    
    obj = gp.LinExpr()
    for i in range(n):
        obj += regular_discount * products[i]['price'] * x_r[i]
        obj += promo_discount * products[i]['price'] * x_p[i]
        obj -= products[i]['var_cost'] * (x_r[i] + x_p[i])
        obj -= fixed_costs[i] * y[i]
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Global labor constraint
    model.addConstr(
        gp.quicksum(products[i]['labor'] * (x_r[i] + x_p[i]) for i in range(n)) <= available_labor,
        "total_labor"
    )
    
    # Global material constraint
    model.addConstr(
        gp.quicksum(products[i]['material'] * (x_r[i] + x_p[i]) for i in range(n)) <= available_material,
        "total_material"
    )
    
    # Promotional segment labor cap
    model.addConstr(
        gp.quicksum(products[i]['labor'] * x_p[i] for i in range(n)) <= promo_labor_cap,
        "promo_labor_cap"
    )
    
    # Promotional segment material cap
    model.addConstr(
        gp.quicksum(products[i]['material'] * x_p[i] for i in range(n)) <= promo_material_cap,
        "promo_material_cap"
    )
    
    # Production upper bounds and equipment activation
    for i in range(n):
        # Total production bounded by max_prod and linked to equipment activation
        model.addConstr(x_r[i] + x_p[i] <= max_prod[i] * y[i], f"equip_link_{i}")
        
        # If equipment is activated, minimum total batch must be met
        model.addConstr(x_r[i] + x_p[i] >= min_batch[i] * y[i], f"min_batch_{i}")
    
    # Segment presence: product is present in a segment only if it clears min batch in that segment
    # "Sales will only treat a product as present in a segment if that segment clears 
    #  its product-specific minimum batch size"
    # This means: x_r[i] >= min_batch[i] * z_r[i] and x_r[i] <= max_prod[i] * z_r[i]
    # Similarly for promo segment
    
    for i in range(n):
        # Regular segment: can only produce if z_r[i]=1, and if z_r[i]=1 must meet min batch
        model.addConstr(x_r[i] <= max_prod[i] * z_r[i], f"reg_upper_{i}")
        model.addConstr(x_r[i] >= min_batch[i] * z_r[i], f"reg_min_batch_{i}")
        
        # Promo segment: can only produce if z_p[i]=1, and if z_p[i]=1 must meet min batch
        model.addConstr(x_p[i] <= max_prod[i] * z_p[i], f"promo_upper_{i}")
        model.addConstr(x_p[i] >= min_batch[i] * z_p[i], f"promo_min_batch_{i}")
        
        # Segment presence requires equipment to be open
        model.addConstr(z_r[i] <= y[i], f"seg_reg_equip_{i}")
        model.addConstr(z_p[i] <= y[i], f"seg_promo_equip_{i}")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        for i in range(n):
            print(f"{products[i]['name']}: regular={x_r[i].X}, promo={x_p[i].X}, equipment={'ON' if y[i].X > 0.5 else 'OFF'}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
