import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Parse table_1.csv
    proc_time = {}
    capacity = {}
    cost_rate = {}
    raw_cost = {}
    price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            if equip == 'Raw_Material_Cost':
                raw_cost = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            elif equip == 'Unit_Price':
                price = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            else:
                for prod, col in [('I', 'Product_I'), ('II', 'Product_II'), ('III', 'Product_III')]:
                    val = row[col].strip()
                    if val != '-':
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row['Effective_Machine_Hours'])
                cost_rate[equip] = float(row['Processing_Cost_per_Machine_Hour'])
    
    # Parse setup_costs.csv
    setup_cost = {}
    with open(os.path.join(data_dir, 'setup_costs.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            setup_cost[equip] = float(row['Fixed_Setup_Cost'])
    
    # Parse general_parameters.csv for calibration info
    joint_cal_fee = 100.0
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            pname = row['Parameter_Name'].strip()
            if pname == 'A2_B2_joint_calibration_fee':
                joint_cal_fee = float(row['Value'])
    
    # Equipment assignments
    stage_A_equip = {'I': ['A1', 'A2'], 'II': ['A1', 'A2'], 'III': ['A2']}
    stage_B_equip = {'I': ['B1', 'B2', 'B3'], 'II': ['B1'], 'III': ['B2']}
    
    products = ['I', 'II', 'III']
    all_equip = ['A1', 'A2', 'B1', 'B2', 'B3']
    
    # Big-M for linking binary to continuous
    # Maximum possible usage on any equipment is bounded by capacity / min proc time
    M = {}
    for equip in all_equip:
        # Find all products that can use this equipment
        max_units = 0
        for prod in products:
            if (equip, prod) in proc_time:
                max_units += capacity[equip] / proc_time[(equip, prod)]
        M[equip] = max_units + 1
    
    model = gp.Model("Factory_Production")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[(equip, prod)] = units of product processed on equipment
    x = {}
    for prod in products:
        for equip in stage_A_equip[prod]:
            x[(equip, prod)] = model.addVar(lb=0, name=f"x_{equip}_{prod}")
        for equip in stage_B_equip[prod]:
            x[(equip, prod)] = model.addVar(lb=0, name=f"x_{equip}_{prod}")
    
    # Binary variables: y[equip] = 1 if equipment is active (used)
    y = {}
    for equip in all_equip:
        y[equip] = model.addVar(vtype=GRB.BINARY, name=f"y_{equip}")
    
    # Binary variable for joint calibration: z = 1 if both A2 and B2 are active
    z = model.addVar(vtype=GRB.BINARY, name="z_joint_cal")
    
    model.update()
    
    # Flow conservation: stage A total == stage B total for each product
    for prod in products:
        model.addConstr(
            gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod]) ==
            gp.quicksum(x[(e, prod)] for e in stage_B_equip[prod]),
            name=f"flow_{prod}"
        )
    
    # Capacity constraints
    for equip in all_equip:
        relevant = [(equip, prod) for prod in products if (equip, prod) in x]
        if relevant:
            model.addConstr(
                gp.quicksum(proc_time[(equip, prod)] * x[(equip, prod)] for eq, prod in relevant) <= capacity[equip],
                name=f"cap_{equip}"
            )
    
    # Linking constraints: if any product uses equipment, y[equip] = 1
    for equip in all_equip:
        relevant_prods = [prod for prod in products if (equip, prod) in x]
        if relevant_prods:
            # Sum of all units on this equipment <= M * y[equip]
            model.addConstr(
                gp.quicksum(x[(equip, prod)] for prod in relevant_prods) <= M[equip] * y[equip],
                name=f"link_{equip}"
            )
    
    # Joint calibration: z >= y[A2] + y[B2] - 1 (z=1 when both active)
    model.addConstr(z >= y['A2'] + y['B2'] - 1, name="joint_cal_1")
    model.addConstr(z <= y['A2'], name="joint_cal_2")
    model.addConstr(z <= y['B2'], name="joint_cal_3")
    
    # Total production of each product
    total = {}
    for prod in products:
        total[prod] = gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod])
    
    # Objective: profit = revenue - raw material - processing cost - setup costs - joint calibration fee
    revenue = gp.quicksum(price[p] * total[p] for p in products)
    raw_mat = gp.quicksum(raw_cost[p] * total[p] for p in products)
    proc_cost = gp.quicksum(cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x)
    setup = gp.quicksum(setup_cost[equip] * y[equip] for equip in all_equip)
    joint_cal = joint_cal_fee * z
    
    model.setObjective(revenue - raw_mat - proc_cost - setup - joint_cal, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")

main()
