import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.dirname(os.path.abspath(__file__))

def load_parameters():
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            try:
                if '.' in val:
                    params[name] = float(val)
                else:
                    params[name] = int(val)
            except ValueError:
                params[name] = val
    return params

def load_demand():
    filepath = os.path.join(base_dir, "data", "table_1.csv")
    demand = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            week = int(row['Week'].strip())
            demand[week] = {
                'I': int(row['I'].strip()),
                'II': int(row['II'].strip())
            }
    return demand

params = load_parameters()
demand = load_demand()

T = 8
weeks = range(1, T + 1)

S0 = params['skilled_worker_count']  # 50
rate_I = params['food_I_production_rate']  # 10 kg/h
rate_II = params['food_II_production_rate']  # 6 kg/h
normal_hours = params['worker_weekly_hours']  # 40
overtime_hours = params['skilled_worker_overtime_hours']  # 60
train_cap = params['training_capacity']  # 3
train_period = params['training_period']  # 2
wage_skilled = params['skilled_worker_weekly_wage']  # 360
wage_trainee_during = params['trainee_weekly_wage_during_training']  # 120
wage_trainee_after = params['trainee_weekly_wage_after_training']  # 240
wage_overtime = params['skilled_worker_overtime_wage']  # 540
comp_I = params['compensation_fee_food_I']  # 0.5
comp_II = params['compensation_fee_food_II']  # 0.6
new_worker_goal = params['new_worker_training_goal']  # 50

model = gp.Model("factory_training_revised")
model.setParam('OutputFlag', 0)

# Decision variables

# n_train[t]: number of skilled workers assigned to start training in week t
# Training takes 2 weeks, so trainer starting in week t is busy in weeks t and t+1
# Trainees available from week t+2
# Can start training in weeks 1..7 (need t+1 <= 8, so t <= 7)
n_train = {}
for t in weeks:
    if t <= T - 1:  # weeks 1..7
        n_train[t] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_train_{t}")

# Binary: y_I[t] = 1 if week t is devoted to Food I
# Binary: y_II[t] = 1 if week t is devoted to Food II
# At most one can be 1 (or both 0 = idle)
y_I = {t: model.addVar(vtype=GRB.BINARY, name=f"yI_{t}") for t in weeks}
y_II = {t: model.addVar(vtype=GRB.BINARY, name=f"yII_{t}") for t in weeks}

# Number of skilled workers on overtime in week t
n_overtime = {t: model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_ot_{t}") for t in weeks}

# Total production hours available for the chosen food type in week t
# Split into: skilled normal hours, skilled overtime hours, graduate hours
# But since only one food type per week, we just need total hours allocated to production
# and multiply by the appropriate rate.

# h_skilled_normal[t]: total normal hours from skilled workers in production
h_skilled_normal = {t: model.addVar(lb=0, name=f"h_sn_{t}") for t in weeks}
# h_skilled_ot[t]: total overtime hours from skilled workers
h_skilled_ot = {t: model.addVar(lb=0, name=f"h_sot_{t}") for t in weeks}
# h_grad[t]: total hours from graduated trainees
h_grad = {t: model.addVar(lb=0, name=f"h_g_{t}") for t in weeks}

# Backlog variables
backlog_I = {t: model.addVar(lb=0, name=f"bI_{t}") for t in weeks}
backlog_II = {t: model.addVar(lb=0, name=f"bII_{t}") for t in weeks}

# Production of food I and food II in week t
prod_I = {t: model.addVar(lb=0, name=f"pI_{t}") for t in weeks}
prod_II = {t: model.addVar(lb=0, name=f"pII_{t}") for t in weeks}

model.update()

# Mutual exclusion: at most one food type per week
for t in weeks:
    model.addConstr(y_I[t] + y_II[t] <= 1, name=f"mutex_{t}")

# Helper expressions
def trainers_busy(t):
    """Number of skilled workers busy training in week t"""
    expr = gp.LinExpr(0)
    for s in n_train:
        if s <= t <= s + train_period - 1:
            expr += n_train[s]
    return expr

def graduates_available(t):
    """Number of graduated trainees available in week t"""
    expr = gp.LinExpr(0)
    for s in n_train:
        if s + train_period <= t:
            expr += train_cap * n_train[s]
    return expr

for t in weeks:
    busy_t = trainers_busy(t)
    grads_t = graduates_available(t)
    
    # Available skilled workers for production
    # avail_skilled_t = S0 - busy_t
    # Must be >= 0
    model.addConstr(S0 - busy_t >= 0, name=f"enough_skilled_{t}")
    
    # Overtime workers <= available skilled workers
    model.addConstr(n_overtime[t] <= S0 - busy_t, name=f"ot_limit_{t}")
    
    # Normal skilled hours = (avail_skilled - n_overtime) * normal_hours
    # But we need to be careful: if the week is idle, no production hours used
    # The hours are available but only used for the chosen product
    
    # h_skilled_normal[t] <= (S0 - busy_t - n_overtime[t]) * normal_hours
    model.addConstr(h_skilled_normal[t] <= (S0 - busy_t - n_overtime[t]) * normal_hours, 
                    name=f"sn_hours_{t}")
    
    # h_skilled_ot[t] <= n_overtime[t] * overtime_hours
    model.addConstr(h_skilled_ot[t] <= n_overtime[t] * overtime_hours, name=f"sot_hours_{t}")
    
    # h_grad[t] <= grads_t * normal_hours
    model.addConstr(h_grad[t] <= grads_t * normal_hours, name=f"grad_hours_{t}")
    
    # Total hours for production
    total_hours_t = h_skilled_normal[t] + h_skilled_ot[t] + h_grad[t]
    
    # Production of food I: only if y_I[t] = 1
    # prod_I[t] = total_hours_t * rate_I if y_I[t]=1, else 0
    # Use big-M: prod_I[t] <= M * y_I[t]
    # and prod_I[t] = total_hours_t * rate_I when active
    
    # Upper bound on total hours: (S0 * overtime_hours + max_grads * normal_hours)
    # max_grads over all weeks could be up to S0*train_cap = 150 (theoretical max if all trained)
    # So M_hours = S0 * overtime_hours + 200 * normal_hours = 50*60 + 200*40 = 3000+8000 = 11000
    M_hours = S0 * overtime_hours + 200 * normal_hours  # generous upper bound
    
    # If y_I[t] = 0, no hours can be used for food I production
    # If y_II[t] = 0, no hours can be used for food II production
    # If both are 0, no production (idle)
    
    # All hours go to one product. We model:
    # prod_I[t] = total_hours_t * rate_I, but only when y_I[t]=1
    # prod_II[t] = total_hours_t * rate_II, but only when y_II[t]=1
    
    # When y_I[t]=1: prod_I[t] = total_hours * rate_I, prod_II[t] = 0
    # When y_II[t]=1: prod_II[t] = total_hours * rate_II, prod_I[t] = 0
    # When idle: prod_I[t]=0, prod_II[t]=0, total_hours=0
    
    # Linking: total_hours <= M_hours * (y_I[t] + y_II[t])
    model.addConstr(total_hours_t <= M_hours * (y_I[t] + y_II[t]), name=f"hours_active_{t}")
    
    # prod_I[t] <= rate_I * M_hours * y_I[t]
    model.addConstr(prod_I[t] <= rate_I * M_hours * y_I[t], name=f"prodI_link_{t}")
    # prod_II[t] <= rate_II * M_hours * y_II[t]
    model.addConstr(prod_II[t] <= rate_II * M_hours * y_II[t], name=f"prodII_link_{t}")
    
    # prod_I[t] = total_hours_t * rate_I when y_I=1
    # We need: prod_I[t] <= total_hours_t * rate_I
    # and prod_I[t] >= total_hours_t * rate_I - M*(1 - y_I[t])
    # Similarly for II
    
    model.addConstr(prod_I[t] <= total_hours_t * rate_I, name=f"prodI_ub_{t}")
    model.addConstr(prod_I[t] >= total_hours_t * rate_I - rate_I * M_hours * (1 - y_I[t]), 
                    name=f"prodI_lb_{t}")
    
    model.addConstr(prod_II[t] <= total_hours_t * rate_II, name=f"prodII_ub_{t}")
    model.addConstr(prod_II[t] >= total_hours_t * rate_II - rate_II * M_hours * (1 - y_II[t]), 
                    name=f"prodII_lb_{t}")
    
    # Backlog balance
    prev_bI = backlog_I[t-1] if t > 1 else 0
    prev_bII = backlog_II[t-1] if t > 1 else 0
    
    model.addConstr(backlog_I[t] >= prev_bI + demand[t]['I'] - prod_I[t], name=f"backlog_I_{t}")
    model.addConstr(backlog_II[t] >= prev_bII + demand[t]['II'] - prod_II[t], name=f"backlog_II_{t}")

# Training goal: at least 50 new workers by end of week 8
total_trained = gp.LinExpr(0)
for s in n_train:
    # Training starting in week s finishes at end of week s+1
    # For s <= 7: s+1 <= 8, so training completes within horizon
    total_trained += train_cap * n_train[s]
model.addConstr(total_trained >= new_worker_goal, name="training_goal")

# Objective: minimize total cost
# Components:
# 1. Skilled worker wages: ALL S0 skilled workers get paid every week
#    - Normal workers (not overtime, not training): wage_skilled
#    - Overtime workers: wage_overtime (instead of wage_skilled)
#    - Trainers: wage_skilled
#    So total skilled wage = S0 * wage_skilled + n_overtime[t] * (wage_overtime - wage_skilled)
#    Wait: skilled workers doing overtime get wage_overtime INSTEAD of wage_skilled
#    So: (S0 - n_overtime[t]) * wage_skilled + n_overtime[t] * wage_overtime
#    = S0 * wage_skilled + n_overtime[t] * (wage_overtime - wage_skilled)

# 2. Trainee wages during training: for trainees in training in week t
#    Trainees starting in week s: train_cap * n_train[s] trainees, in training during weeks s and s+1
#    Each gets wage_trainee_during per week during training

# 3. Graduated trainee wages: graduates available in week t get wage_trainee_after
#    Even if idle (they're employed)

# 4. Compensation: comp_I * backlog_I[t] + comp_II * backlog_II[t] for each week

obj = gp.LinExpr(0)

for t in weeks:
    # Skilled worker wages (all S0 get paid)
    obj += S0 * wage_skilled
    # Overtime premium
    obj += n_overtime[t] * (wage_overtime - wage_skilled)
    
    # Trainees in training during week t
    trainees_in_training_t = gp.LinExpr(0)
    for s in n_train:
        if s <= t <= s + train_period - 1:
            trainees_in_training_t += train_cap * n_train[s]
    obj += trainees_in_training_t * wage_trainee_during
    
    # Graduated trainees (available from week s+2)
    grads_t = graduates_available(t)
    obj += grads_t * wage_trainee_after
    
    # Compensation
    obj += comp_I * backlog_I[t]
    obj += comp_II * backlog_II[t]

model.setObjective(obj, GRB.MINIMIZE)
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
elif model.status == GRB.INFEASIBLE:
    model.computeIIS()
    print("Model is infeasible")
else:
    print(f"Optimization ended with status {model.status}")
    if model.solCount > 0:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
