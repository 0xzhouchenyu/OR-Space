import os
import csv
import gurobipy as gp
from gurobipy import GRB

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
    for row in csv.DictReader(f):
        params[row['Parameter_Name'].strip()] = float(row['Value'])

# Load product data
products = {}
with open(os.path.join(data_dir, 'table_1.csv')) as f:
    for row in csv.DictReader(f):
        products[row['Product'].strip()] = {
            'a_hrs': float(row['Workshop_A_Hours']),
            'b_hrs': float(row['Workshop_B_Hours']),
            'insp_cost': float(row['Inspection_Sales_Cost'])
        }

m_data = products['Microwave_Oven']
w_data = products['Water_Heater']

# Parameters
ws_a_avail = params['workshop_a_available_hours']
ws_a_cost = params['workshop_a_hourly_cost']
ws_b_avail = params['workshop_b_available_hours']
ws_b_cost = params['workshop_b_hourly_cost']
insp_limit = params['inspection_sales_cost_limit']
min_micro = params['microwave_minimum_sales']
min_water = params['water_heater_minimum_sales']
ot_limit = params['workshop_a_overtime_limit']
setup_A = params['setup_hours_A']
tech_pool = params['tech_pool_hours']
tech_rate_m = params['tech_rate_m']
tech_rate_w = params['tech_rate_w']
green_bonus_m = params['green_bonus_m']
green_bonus_w = params['green_bonus_w']
bigM = params['bigM']

model = gp.Model("production_revised")
model.setParam('OutputFlag', 0)

# Decision variables
x1 = model.addVar(lb=min_micro, name="microwave")  # microwave units
x2 = model.addVar(lb=min_water, name="water_heater")  # water heater units

# Binary activation variables for Workshop A usage
# Both products use Workshop A (Workshop_A_Hours > 0 for both), 
# but the "gate" rule means: if a product is produced (uses workshop A),
# the line consumes fixed setup_hours_A before productive work begins.
# y_m = 1 if microwaves are produced (use workshop A), y_w = 1 if water heaters are produced
y_m = model.addVar(vtype=GRB.BINARY, name="y_microwave_A")
y_w = model.addVar(vtype=GRB.BINARY, name="y_water_heater_A")

# Linking constraints: if x1 > 0 then y_m = 1 (and since x1 >= min_micro > 0, y_m will be 1)
# But we model it properly with big-M
model.addConstr(x1 <= bigM * y_m, "link_micro_activate")
model.addConstr(x2 <= bigM * y_w, "link_water_activate")

# Revenue per unit (base): workshop costs + inspection/sales cost
rev_m_base = m_data['a_hrs'] * ws_a_cost + m_data['b_hrs'] * ws_b_cost + m_data['insp_cost']
rev_w_base = w_data['a_hrs'] * ws_a_cost + w_data['b_hrs'] * ws_b_cost + w_data['insp_cost']

# Green bonus: certified output earns the listed green bonus per unit
# Products that use workshop A (activated) earn the green bonus
# We add green_bonus per unit for products whose workshop A line is activated

# Objective: maximize revenue including green bonus
# Base revenue + green bonus for certified units
# Green bonus only applies if the product's workshop A line is activated
# Since both products use workshop A, and activation is binary,
# we need to handle the bonus conditionally. 
# If y_m=1, each microwave gets green_bonus_m; if y_w=1, each water heater gets green_bonus_w.
# We can linearize: green_bonus_m * x1 * y_m -> since x1 <= bigM * y_m, when y_m=0, x1=0
# So green_bonus_m * x1 is equivalent (since x1=0 when y_m=0).

obj = rev_m_base * x1 + rev_w_base * x2 + green_bonus_m * x1 + green_bonus_w * x2
model.setObjective(obj, GRB.MAXIMIZE)

# Workshop A constraint: productive hours + setup hours for each activated product line
# Total workshop A hours = productive hours + setup hours per activated product
# Must be <= available + overtime
model.addConstr(
    m_data['a_hrs'] * x1 + w_data['a_hrs'] * x2 + setup_A * y_m + setup_A * y_w
    <= ws_a_avail + ot_limit,
    "workshop_a_capacity"
)

# Workshop B constraint (from original: >= available hours, meaning must use at least that much)
model.addConstr(
    m_data['b_hrs'] * x1 + w_data['b_hrs'] * x2 >= ws_b_avail,
    "workshop_b_utilization"
)

# Inspection and sales cost constraint
model.addConstr(
    m_data['insp_cost'] * x1 + w_data['insp_cost'] * x2 <= insp_limit,
    "inspection_sales_limit"
)

# Shared technician pool constraint
model.addConstr(
    tech_rate_m * x1 + tech_rate_w * x2 <= tech_pool,
    "tech_pool_constraint"
)

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
elif model.status == GRB.INFEASIBLE:
    model.computeIIS()
    print("Model is infeasible")
else:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
