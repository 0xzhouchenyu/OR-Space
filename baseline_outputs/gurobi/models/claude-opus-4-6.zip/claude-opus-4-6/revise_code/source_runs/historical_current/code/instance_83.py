import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read time periods and minimum waiters needed
time_periods = []
min_waiters = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        time_periods.append(row['Time'].strip())
        min_waiters.append(int(row['Minimum_Number_of_Waiters_Needed'].strip()))

# Read general parameters
peak = {}
quality = {}
waiter_budget = None
waiter_cost_per_shift = None
work_hours = None

with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        val = row['Value'].strip()
        if name == 'waiter_work_hours':
            work_hours = int(val)
        elif name.startswith('peak_'):
            idx = int(name.split('_')[1])
            peak[idx] = int(val)
        elif name.startswith('quality_'):
            idx = int(name.split('_')[1])
            quality[idx] = int(val)
        elif name == 'waiter_cost_per_shift':
            waiter_cost_per_shift = float(val)
        elif name == 'waiter_budget':
            waiter_budget = float(val)

n = len(time_periods)  # 6 periods, each 4 hours

# Periods indexed 0..5:
# 0: 2-6
# 1: 6-10
# 2: 10-14
# 3: 14-18
# 4: 18-22
# 5: 22-2

# Each waiter works 8 hours = 2 consecutive 4-hour periods
# A "compliant waiter tour" is one 8-hour block made of two adjacent 4-hour windows,
# with one peak window and one off-peak window.

# Identify valid tours: tour i covers periods i and (i+1) mod n
# A compliant tour must have one peak and one off-peak window
valid_tours = []
for i in range(n):
    j = (i + 1) % n
    p_i = peak[i]
    p_j = peak[j]
    # One peak and one off-peak
    if (p_i + p_j) == 1:
        valid_tours.append(i)

# Decision variables: x_i = number of waiters starting at period i (valid tours only)
model = gp.Model("Restaurant_Waiters")
model.setParam('OutputFlag', 0)

x = {}
for i in valid_tours:
    x[i] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}")

# Also need to track coverage in each period
# w_j = total waiters working in period j
# Waiters from tour i work in periods i and (i+1) mod n
# w_j = sum of x_i for all valid tours i where i == j or (i+1) % n == j

# Coverage constraints: for each period j, coverage >= min_waiters[j]
for j in range(n):
    coverage = gp.LinExpr()
    for i in valid_tours:
        if i == j or (i + 1) % n == j:
            coverage += x[i]
    model.addConstr(coverage >= min_waiters[j], name=f"coverage_{j}")

# Budget constraint: total cost <= waiter_budget
total_cost = gp.LinExpr()
for i in valid_tours:
    total_cost += waiter_cost_per_shift * x[i]
model.addConstr(total_cost <= waiter_budget, name="budget")

# Objective: maximize service_quality_score
# service_quality_score = sum over all periods j of quality[j] * (waiters working in period j)
obj = gp.LinExpr()
for j in range(n):
    for i in valid_tours:
        if i == j or (i + 1) % n == j:
            obj += quality[j] * x[i]

model.setObjective(obj, GRB.MAXIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    for i in valid_tours:
        print(f"Waiters starting at period {time_periods[i]}: {int(x[i].X)}")
    print(f"Total waiters: {int(sum(x[i].X for i in valid_tours))}")
    print(f"Total cost: {sum(waiter_cost_per_shift * x[i].X for i in valid_tours)}")
    
    # Compute service quality score
    sq = 0
    for j in range(n):
        cov = sum(x[i].X for i in valid_tours if i == j or (i+1) % n == j)
        sq += quality[j] * cov
    print(f"Service quality score: {sq}")
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
elif model.status == GRB.INFEASIBLE:
    print("Model is infeasible")
    model.computeIIS()
    model.write("model.ilp")
    print("FINAL_OBJ_VALUE: INFEASIBLE")
else:
    print(f"Optimization ended with status {model.status}")
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
