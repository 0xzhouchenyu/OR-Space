import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(csv_path)
    params = dict(zip(df['Parameter_Name'], df['Value']))

    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # Prices
    price = {c: params[f"{c}_price"] for c in commodities}

    # Production requirements: to produce 1 unit of c, you need req[c][c2] units of c2
    # Parameter naming: {c}_{c2}_requirement means units of c2 needed to produce 1 unit of c
    req = {}
    for c in commodities:
        req[c] = {}
        for c2 in commodities:
            key = f"{c}_{c2}_requirement"
            req[c][c2] = params.get(key, 0.0)

    # Import costs (other imported goods for production)
    import_cost = {c: params.get(f"{c}_import_cost", 0.0) for c in commodities}

    # Labor requirements
    labor_req = {c: params.get(f"{c}_labor_requirement", 0.0) for c in commodities}

    # Production limits
    prod_limit = {}
    for c in commodities:
        for suffix in ['_production_limit', '_limit', '_capacity']:
            key = f"{c}{suffix}"
            if key in params:
                prod_limit[c] = params[key]

    # New parameters
    labor_force = params['labor_force']
    overtime_cap = params['overtime_cap']
    overtime_wage = params['overtime_wage']
    import_premium_ratio = params['import_premium_ratio']
    import_quota = params['import_quota']

    # Model
    model = gp.Model("Maximize_GDP")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[c] = domestic production of commodity c
    x = {}
    for c in commodities:
        ub = prod_limit.get(c, GRB.INFINITY)
        x[c] = model.addVar(lb=0, ub=ub, name=f"x_{c}")

    # imp[c] = imports of finished commodity c (to cover domestic demand shortfall)
    imp = {}
    for c in commodities:
        imp[c] = model.addVar(lb=0, ub=import_quota, name=f"imp_{c}")

    # overtime = overtime labor used
    overtime = model.addVar(lb=0, ub=overtime_cap, name="overtime")

    model.update()

    # Domestic consumption of commodity c = sum over all producing commodities c' of req[c'][c] * x[c']
    # i.e., how much of commodity c is consumed domestically by all production processes
    domestic_consumption = {}
    for c in commodities:
        domestic_consumption[c] = gp.quicksum(req[c_prime][c] * x[c_prime] for c_prime in commodities)

    # Supply of commodity c available = x[c] (domestic production) + imp[c] (imports of finished commodity)
    # This supply must cover domestic consumption. The remainder is exported.
    # net_export[c] = x[c] + imp[c] - domestic_consumption[c]
    # net_export[c] >= 0 (can't export more than available after domestic use)

    # But wait - we need to think about this carefully.
    # The supply available for domestic use and export = domestic production + imports
    # Domestic demand = consumption by other production processes
    # Net export = supply - domestic demand = x[c] + imp[c] - domestic_consumption[c]

    # Revenue from exports: price[c] * max(0, net_export[c])
    # But since we want to maximize, and importing is costly, the model will naturally
    # only export (net_export >= 0 is enforced)

    # Cost of importing finished commodities: import_premium_ratio * price[c] * imp[c]
    # Cost of other imported goods for production: import_cost[c] * x[c]
    # Cost of overtime: overtime_wage * overtime

    # GDP = Export revenue - Production import costs - Finished commodity import costs - Overtime costs

    net_export = {}
    for c in commodities:
        net_export[c] = x[c] + imp[c] - domestic_consumption[c]
        model.addConstr(net_export[c] >= 0, name=f"Demand_{c}")

    # Export revenue
    export_revenue = gp.quicksum(price[c] * net_export[c] for c in commodities)

    # Production import costs (other imported goods needed for production)
    prod_import_costs = gp.quicksum(import_cost[c] * x[c] for c in commodities)

    # Finished commodity import costs
    finished_import_costs = gp.quicksum(import_premium_ratio * price[c] * imp[c] for c in commodities)

    # Overtime costs
    overtime_costs = overtime_wage * overtime

    # GDP objective
    gdp = export_revenue - prod_import_costs - finished_import_costs - overtime_costs
    model.setObjective(gdp, GRB.MAXIMIZE)

    # Labor constraint: regular + overtime
    total_labor = gp.quicksum(labor_req[c] * x[c] for c in commodities)
    model.addConstr(total_labor <= labor_force + overtime, name="Labor_Limit")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        return model.ObjVal
    else:
        return None

if __name__ == '__main__':
    result = solve()
    if result is not None:
        print(f"FINAL_OBJ_VALUE: {round(result, 3)}")
    else:
        print("FINAL_OBJ_VALUE: None")
