import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children = int(params['max_children_trip'])
    min_children = int(params['min_children_trip'])
    max_distinct = int(params['max_distinct_children_trip'])
    total_budget = int(params['total_cost_budget'])
    bonus_saving = int(params['bonus_saving'])
    min_bob_days = int(params['min_bob_days'])
    
    # Read table_1 for children and costs
    children = []
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Child'].strip()
            cost = int(row['Cost'].strip())
            children.append(name)
            costs[name] = cost
    
    days = [1, 2]
    
    # Create the optimization model
    model = gp.Model("FamilyTrip2Day")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: binary for each child on each day
    x = {}
    for child in children:
        for d in days:
            x[child, d] = model.addVar(vtype=GRB.BINARY, name=f"x_{child}_{d}")
    
    # Bonus indicator: 1 if child attends both days
    b = {}
    for child in children:
        b[child] = model.addVar(vtype=GRB.BINARY, name=f"b_{child}")
    
    # Distinct children indicator: 1 if child attends at least one day
    y = {}
    for child in children:
        y[child] = model.addVar(vtype=GRB.BINARY, name=f"y_{child}")
    
    model.update()
    
    # Objective: minimize total two-day cost minus bonus savings
    total_cost = gp.quicksum(costs[child] * x[child, d] for child in children for d in days)
    total_bonus = gp.quicksum(bonus_saving * b[child] for child in children)
    model.setObjective(total_cost - total_bonus, GRB.MINIMIZE)
    
    # Link y (distinct) variables: y[child] >= x[child,d] for each day
    for child in children:
        for d in days:
            model.addConstr(y[child] >= x[child, d], name=f"distinct_{child}_{d}")
        # y[child] <= sum of x over days
        model.addConstr(y[child] <= gp.quicksum(x[child, d] for d in days), name=f"distinct_upper_{child}")
    
    # Link b (bonus) variables: b[child] = 1 iff child attends both days
    for child in children:
        for d in days:
            model.addConstr(b[child] <= x[child, d], name=f"bonus_{child}_{d}")
        model.addConstr(b[child] >= gp.quicksum(x[child, d] for d in days) - 1, name=f"bonus_lower_{child}")
    
    # Daily min/max children constraints
    for d in days:
        model.addConstr(gp.quicksum(x[child, d] for child in children) >= min_children, name=f"MinChildren_day{d}")
        model.addConstr(gp.quicksum(x[child, d] for child in children) <= max_children, name=f"MaxChildren_day{d}")
    
    # Max distinct children over both days
    model.addConstr(gp.quicksum(y[child] for child in children) <= max_distinct, name="MaxDistinct")
    
    # Total cost budget: net cost <= budget
    model.addConstr(total_cost - total_bonus <= total_budget, name="TotalBudget")
    
    # Bob must attend at least min_bob_days days
    model.addConstr(gp.quicksum(x['Bob', d] for d in days) >= min_bob_days, name="MinBobDays")
    
    # Availability constraints:
    # Charlie can only participate on day 2
    model.addConstr(x['Charlie', 1] == 0, name="Charlie_day1_unavail")
    # Diana can only participate on day 2
    model.addConstr(x['Diana', 1] == 0, name="Diana_day1_unavail")
    # Alice can only participate on day 1
    model.addConstr(x['Alice', 2] == 0, name="Alice_day2_unavail")
    
    # Relationship constraints (apply per day):
    for d in days:
        # Alice and Diana cannot both be taken on the same day
        model.addConstr(x['Alice', d] + x['Diana', d] <= 1, name=f"AliceDiana_day{d}")
        
        # Bob and Charlie cannot both be taken on the same day
        model.addConstr(x['Bob', d] + x['Charlie', d] <= 1, name=f"BobCharlie_day{d}")
        
        # Charlie must be accompanied by Diana (if Charlie goes, Diana must go)
        model.addConstr(x['Charlie', d] <= x['Diana', d], name=f"CharlieReqDiana_day{d}")
        
        # Diana must be accompanied by Ella (if Diana goes, Ella must go)
        model.addConstr(x['Diana', d] <= x['Ella', d], name=f"DianaReqElla_day{d}")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"Status: Optimal")
        for d in days:
            print(f"Day {d}:")
            for child in children:
                if x[child, d].X > 0.5:
                    print(f"  {child}: taken (cost={costs[child]})")
        for child in children:
            if b[child].X > 0.5:
                print(f"  {child}: bonus saving applied ({bonus_saving})")
        
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
