import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    param_dict = dict(zip(params['Parameter_Name'], params['Value']))
    
    table_1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    demand = dict(zip(table_1['stage'], table_1['tool_requirement']))
    
    n = int(param_dict['n'])
    cost_new = float(param_dict['cost_new_tool'])
    cost_slow = float(param_dict['cost_slow_repair'])
    cost_fast = float(param_dict['cost_fast_repair'])
    dur_slow = int(param_dict['slow_repair_duration'])
    dur_fast = int(param_dict['fast_repair_duration'])
    max_fast = int(param_dict['max_fast_stage'])
    max_slow = int(param_dict['max_slow_stage'])
    emission_buy = float(param_dict['emission_buy'])
    emission_fast = float(param_dict['emission_fast_repair'])
    emission_slow = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_shortage = float(param_dict['penalty_shortage'])
    
    stages = list(range(1, n + 1))
    
    model = gp.Model("Tool_Repair_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # prebuy_clean: initial clean stock at stage 0
    prebuy = model.addVar(lb=0, vtype=GRB.INTEGER, name="prebuy_clean")
    
    # x[i]: new tools purchased at stage i
    x = model.addVars(stages, lb=0, vtype=GRB.INTEGER, name="buy")
    
    # y[i]: tools sent to fast repair after stage i
    y = model.addVars(stages, lb=0, vtype=GRB.INTEGER, name="fast")
    
    # z[i]: tools sent to slow repair after stage i
    z = model.addVars(stages, lb=0, vtype=GRB.INTEGER, name="slow")
    
    # c[i]: clean (usable) tools carried over from stage i (available at start of i+1)
    # c[0] = prebuy_clean (initial clean stock)
    c = model.addVars([0] + stages, lb=0, vtype=GRB.INTEGER, name="clean")
    
    # d[i]: dirty tools waiting (not yet assigned to repair) carried from stage i
    d = model.addVars([0] + stages, lb=0, vtype=GRB.INTEGER, name="dirty")
    
    # s[i]: shortage (unmet demand) at stage i
    s = model.addVars(stages, lb=0, vtype=GRB.INTEGER, name="shortage")
    
    # Initial conditions
    model.addConstr(c[0] == prebuy, "init_clean")
    model.addConstr(d[0] == 0, "init_dirty")
    
    # Flow constraints for each stage
    for i in stages:
        # Tools available at stage i: carried clean from previous + new purchases + repairs returning
        # Fast repair sent at stage j returns at stage j + dur_fast + 1 (available at start of that stage)
        # Actually, let's think carefully:
        # If fast repair takes dur_fast stages and tools are sent after stage j,
        # they return ready for use at stage j + dur_fast + 1? 
        # Original code: fast_ready at stage i = y[i - dur_fast - 1] if i - dur_fast - 1 >= 1
        # So tools sent to fast repair after stage (i - dur_fast - 1) are available at stage i
        # That means: sent after stage j, available at stage j + dur_fast + 1
        # But wait, the original code has: fast_ready = y[i - dur_fast - 1] 
        # With dur_fast=1: fast_ready at stage i = y[i-2] (sent after stage i-2, available at i)
        # That's a turnaround of dur_fast stages between sending and availability
        # Let me re-examine: if dur_fast = 1, sent after stage j, takes 1 stage duration,
        # so available at stage j+1+1 = j+2? No, that would be y[i-2] for stage i.
        # Actually y[i - dur_fast - 1] with dur_fast=1 gives y[i-2].
        # But conceptually: sent after stage j, repair takes dur_fast stages, 
        # so ready at start of stage j + dur_fast + 1? That gives y[i - dur_fast - 1].
        # Hmm, let me reconsider. The original code indexes as:
        # fast_ready = y[i - dur_fast - 1] ... but maybe it should be y[i - dur_fast]?
        # Let's think: fast repair duration = 1 stage. Tool used in stage j, sent to fast repair.
        # It takes 1 stage to repair. So if sent at end of stage j (or beginning, same thing),
        # it's ready at end of stage j+1, i.e., available for stage j+2? 
        # Or: sent at stage j, repaired during 1 stage gap, ready at stage j+1?
        # 
        # The original code: y[i - dur_fast - 1] for dur_fast=1 means y[i-2]
        # So sent after stage i-2, available at stage i. That's a gap of 2 stages which seems
        # like 1 stage of repair + the "sending" stage.
        #
        # Actually I think the interpretation is: tools are used in stage i, then at end of stage i
        # they're dirty. They're sent to repair which takes dur_fast stages. So they're available
        # at stage i + dur_fast + 1 (the +1 because they were used in stage i, become dirty at end
        # of stage i, then dur_fast stages of repair).
        # Wait no. Let me re-read the original code more carefully:
        #
        # The original code has y[i] as fast repair sent at stage i (from dirty pool at stage i).
        # The dirty balance: demand[i] + d[i-1] == y[i] + z[i] + d[i]
        # This means: after stage i, demand[i] tools become dirty, plus leftover dirty d[i-1],
        # and we allocate y[i] to fast, z[i] to slow, d[i] remain dirty.
        #
        # Then fast_ready at stage i = y[i - dur_fast - 1] if valid.
        # With dur_fast=1: y[i-2]. Sent at stage i-2, available at stage i. 
        # Gap = 2 stages, but repair duration = 1.
        # 
        # Hmm, maybe the interpretation is different. Perhaps y[i] means tools sent to fast repair
        # at the END of stage i, and they need dur_fast stages to complete, so they're ready at
        # the START of stage i + dur_fast + 1. That would mean available for stage i + dur_fast + 1.
        # So at stage i, fast_ready = y[i - dur_fast - 1]. With dur_fast=1: y[i-2]. ✓
        #
        # For slow with dur_slow=3: z[i-4]. Sent at end of stage i-4, ready at start of i. ✓
        #
        # Actually wait - I think a simpler reading: sent to repair at stage j, takes dur stages,
        # ready at stage j + dur. So fast_ready at i = y[i - dur_fast].
        # With dur_fast=1: y[i-1]. But original has y[i-2]. 
        #
        # The original has the -1 extra offset. Let me just follow the original code's convention
        # since it was presumably correct for the original problem.
        
        # Following original code convention:
        fast_ready = 0
        if i - dur_fast - 1 >= 1:
            fast_ready = y[i - dur_fast - 1]
        
        slow_ready = 0
        if i - dur_slow - 1 >= 1:
            slow_ready = z[i - dur_slow - 1]
        
        # Clean balance: available tools = clean carryover + new + returned repairs
        # These must cover: actual usage (demand - shortage) + clean carryover to next
        # tools_used = demand[i] - s[i]
        # available = c[i-1] + x[i] + fast_ready + slow_ready
        # available = tools_used + c[i]
        # So: c[i-1] + x[i] + fast_ready + slow_ready = (demand[i] - s[i]) + c[i]
        model.addConstr(
            c[i-1] + x[i] + fast_ready + slow_ready == demand[i] - s[i] + c[i],
            f"clean_balance_{i}"
        )
        
        # Dirty balance: tools used become dirty
        # dirty arriving = (demand[i] - s[i]) + d[i-1]
        # allocated to: fast y[i] + slow z[i] + remaining dirty d[i]
        model.addConstr(
            (demand[i] - s[i]) + d[i-1] == y[i] + z[i] + d[i],
            f"dirty_balance_{i}"
        )
        
        # Repair capacity constraints
        model.addConstr(y[i] <= max_fast, f"max_fast_{i}")
        model.addConstr(z[i] <= max_slow, f"max_slow_{i}")
    
    # Carbon budget constraint
    # Emissions from: new purchases, fast repairs, slow repairs, and prebuy
    # prebuy tools are "newly purchased" effectively, so they have emission_buy
    carbon_expr = emission_buy * prebuy
    for i in stages:
        carbon_expr += emission_buy * x[i]
        carbon_expr += emission_fast * y[i]
        carbon_expr += emission_slow * z[i]
    model.addConstr(carbon_expr <= carbon_budget, "carbon_budget")
    
    # Objective: minimize total cost
    obj = cost_new * prebuy  # prebuy tools cost money too
    for i in stages:
        obj += cost_new * x[i]
        obj += cost_fast * y[i]
        obj += cost_slow * z[i]
        obj += penalty_shortage * s[i]
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.status == GRB.INFEASIBLE:
        # Try to debug
        model.computeIIS()
        model.write("model.ilp")
        print("FINAL_OBJ_VALUE: INFEASIBLE")
    else:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
