import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    budget = params['company_budget']
    max_employees = int(params['max_employees'])
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_gj = int(params['max_one_candidate_g_j'])
    lead_premium = params['lead_premium']
    min_leads = int(params['min_leads'])
    mentor_bonus = params['mentor_bonus']
    max_pairs = int(params['max_pairs'])
    
    cand_names = [c['name'] for c in candidates]
    
    # Create model
    model = gp.Model("HiringOptimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i] = 1 if candidate i is hired
    x = {}
    for c in candidates:
        x[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{c['name']}")
    
    # l[i] = 1 if candidate i is hired as Lead
    l = {}
    for c in candidates:
        l[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"l_{c['name']}")
    
    # e[i] = 1 if candidate i is hired as Engineer
    e = {}
    for c in candidates:
        e[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"e_{c['name']}")
    
    # p = number of mentorship pairs counted (integer)
    p = model.addVar(vtype=GRB.INTEGER, lb=0, name="pairs")
    
    # Total leads and engineers
    total_leads = gp.quicksum(l[c['name']] for c in candidates)
    total_engineers = gp.quicksum(e[c['name']] for c in candidates)
    
    # Constraints
    
    # Each hired candidate has exactly one role: Lead or Engineer
    for c in candidates:
        model.addConstr(l[c['name']] + e[c['name']] == x[c['name']], f"RoleAssign_{c['name']}")
    
    # Budget constraint: net cost <= budget
    # Net cost = sum of salaries + lead_premium * leads - mentor_bonus * pairs
    net_cost = (gp.quicksum(c['salary'] * x[c['name']] for c in candidates) +
                lead_premium * total_leads -
                mentor_bonus * p)
    model.addConstr(net_cost <= budget, "Budget")
    
    # Max employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, "MaxEmployees")
    
    # Min skill level
    model.addConstr(gp.quicksum(c['skill'] * x[c['name']] for c in candidates) >= min_skill, "MinSkill")
    
    # Min project management experience
    model.addConstr(gp.quicksum(c['pm_exp'] * x[c['name']] for c in candidates) >= min_pm_exp, "MinPMExp")
    
    # At most one of G and J
    model.addConstr(x['G'] + x['J'] <= max_gj, "MaxOneGJ")
    
    # Minimum leads
    model.addConstr(total_leads >= min_leads, "MinLeads")
    
    # Mentorship pairs: p <= min(total_leads, total_engineers) and p <= max_pairs
    model.addConstr(p <= total_leads, "PairsLeads")
    model.addConstr(p <= total_engineers, "PairsEngineers")
    model.addConstr(p <= max_pairs, "MaxPairs")
    
    # Objective: minimize net cost
    model.setObjective(net_cost, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        for c in candidates:
            if x[c['name']].X > 0.5:
                role = "Lead" if l[c['name']].X > 0.5 else "Engineer"
                print(f"Hire {c['name']} as {role}: Salary={c['salary']}, Skill={c['skill']}, PM_Exp={c['pm_exp']}")
        print(f"Mentorship pairs: {int(round(p.X))}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
