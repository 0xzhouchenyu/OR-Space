import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
filepath = os.path.join(data_dir, "general_parameters.csv")

params = {}
with open(filepath, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        val = float(row['Value'].strip())
        params[name] = val

# Extract parameters
min_A = params['min_raw_material_A']
min_B = params['min_raw_material_B']
min_C = params['min_raw_material_C']

cap_A_a = params['warehouse_A_truck_capacity_A']
cap_A_b = params['warehouse_A_truck_capacity_B']
cap_A_c = params['warehouse_A_truck_capacity_C']
cost_A = params['warehouse_A_truck_cost']

cap_B_a = params['warehouse_B_truck_capacity_A']
cap_B_b = params['warehouse_B_truck_capacity_B']
cap_B_c = params['warehouse_B_truck_capacity_C']
cost_B = params['warehouse_B_truck_cost']

fixed_cost_A = params['warehouse_A_fixed_cost']
fixed_cost_B = params['warehouse_B_fixed_cost']

overflow_threshold_B = params['warehouse_B_overflow_threshold_trucks']
overflow_cost_B = params['warehouse_B_overflow_coordination_cost']

reconciliation_fee = params['dual_warehouse_reconciliation_fee']

# Big-M (upper bound on number of trucks - generous)
M = 10000

# Create model
model = gp.Model("MinFreightCost")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_A")  # trucks from warehouse A
y = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_B")  # trucks from warehouse B

# Binary: whether warehouse A is used
z_A = model.addVar(vtype=GRB.BINARY, name="use_warehouse_A")
# Binary: whether warehouse B is used
z_B = model.addVar(vtype=GRB.BINARY, name="use_warehouse_B")
# Binary: whether both warehouses are used (for reconciliation fee)
z_both = model.addVar(vtype=GRB.BINARY, name="use_both_warehouses")
# Binary: whether warehouse B exceeds overflow threshold
z_overflow = model.addVar(vtype=GRB.BINARY, name="overflow_B")

# Link x to z_A: x > 0 => z_A = 1, x = 0 => z_A = 0
model.addConstr(x <= M * z_A, "link_x_zA")
model.addConstr(x >= z_A, "link_zA_x")  # if z_A=1 then x>=1

# Link y to z_B: y > 0 => z_B = 1, y = 0 => z_B = 0
model.addConstr(y <= M * z_B, "link_y_zB")
model.addConstr(y >= z_B, "link_zB_y")  # if z_B=1 then y>=1

# z_both = z_A AND z_B
model.addConstr(z_both >= z_A + z_B - 1, "both_lb")
model.addConstr(z_both <= z_A, "both_ub1")
model.addConstr(z_both <= z_B, "both_ub2")

# Overflow: y > overflow_threshold => z_overflow = 1
# y - overflow_threshold <= M * z_overflow
# y - overflow_threshold >= (1 - (1 - z_overflow)) * epsilon ... use indicator or big-M
model.addConstr(y - overflow_threshold_B <= M * z_overflow, "overflow_ub")
model.addConstr(y - overflow_threshold_B >= 1 - M * (1 - z_overflow), "overflow_lb")

# Raw material constraints
model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# Objective
model.setObjective(
    cost_A * x + cost_B * y +
    fixed_cost_A * z_A + fixed_cost_B * z_B +
    overflow_cost_B * z_overflow +
    reconciliation_fee * z_both,
    GRB.MINIMIZE
)

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"Trucks from Warehouse A: {int(round(x.X))}")
    print(f"Trucks from Warehouse B: {int(round(y.X))}")
    print(f"Use A: {int(round(z_A.X))}, Use B: {int(round(z_B.X))}, Both: {int(round(z_both.X))}, Overflow: {int(round(z_overflow.X))}")
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
