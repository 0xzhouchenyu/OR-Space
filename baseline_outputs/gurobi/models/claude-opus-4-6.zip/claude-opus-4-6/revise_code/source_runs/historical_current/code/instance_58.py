import os
import csv
import gurobipy as gp
from gurobipy import GRB
from itertools import combinations

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Extract parameters
    profits = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons'],
    }
    total_area = params['total_farm_area']
    min_a_to_p = params['min_apples_to_pears_ratio']
    min_a_to_l = params['min_apples_to_lemons_ratio']
    o_to_l = params['oranges_to_lemons_ratio']
    max_types = int(params['max_fruit_types'])

    water_per_acre = {
        ('apples', 'spring'): params['water_per_acre_apples_spring'],
        ('apples', 'autumn'): params['water_per_acre_apples_autumn'],
        ('pears', 'spring'): params['water_per_acre_pears_spring'],
        ('pears', 'autumn'): params['water_per_acre_pears_autumn'],
        ('oranges', 'spring'): params['water_per_acre_oranges_spring'],
        ('oranges', 'autumn'): params['water_per_acre_oranges_autumn'],
        ('lemons', 'spring'): params['water_per_acre_lemons_spring'],
        ('lemons', 'autumn'): params['water_per_acre_lemons_autumn'],
    }

    water_cap_spring = params['water_cap_spring']
    water_cap_autumn = params['water_cap_autumn']
    total_water_budget = params['total_water_budget']
    min_annual_water = params['min_annual_water_per_fruit']
    diversification_reward = params['diversification_reward']

    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']

    # Big-M for linking binary to continuous
    # Maximum possible water for a fruit is bounded by total_water_budget
    M_water = total_water_budget + 1

    model = gp.Model("farm_revised")
    model.setParam('OutputFlag', 0)

    # Decision variables: acres of each fruit in each season
    x = {}
    for f in fruits:
        for s in seasons:
            x[f, s] = model.addVar(lb=0, name=f"x_{f}_{s}")

    # Binary: whether fruit f is grown (genuinely) over the year
    y = {}
    for f in fruits:
        y[f] = model.addVar(vtype=GRB.BINARY, name=f"y_{f}")

    # Binary: whether diversification reward is earned
    div = model.addVar(vtype=GRB.BINARY, name="div_reward")

    # Annual acres for each fruit
    annual = {}
    for f in fruits:
        annual[f] = model.addVar(lb=0, name=f"annual_{f}")

    # Annual water for each fruit
    annual_water = {}
    for f in fruits:
        annual_water[f] = model.addVar(lb=0, name=f"annual_water_{f}")

    model.update()

    # Define annual acres
    for f in fruits:
        model.addConstr(annual[f] == x[f, 'spring'] + x[f, 'autumn'], name=f"annual_def_{f}")

    # Define annual water
    for f in fruits:
        model.addConstr(
            annual_water[f] == gp.quicksum(water_per_acre[f, s] * x[f, s] for s in seasons),
            name=f"annual_water_def_{f}"
        )

    # Seasonal land constraints
    for s in seasons:
        model.addConstr(
            gp.quicksum(x[f, s] for f in fruits) <= total_area,
            name=f"land_{s}"
        )

    # Water cap spring
    model.addConstr(
        gp.quicksum(water_per_acre[f, 'spring'] * x[f, 'spring'] for f in fruits) <= water_cap_spring,
        name="water_cap_spring"
    )

    # Water cap autumn
    model.addConstr(
        gp.quicksum(water_per_acre[f, 'autumn'] * x[f, 'autumn'] for f in fruits) <= water_cap_autumn,
        name="water_cap_autumn"
    )

    # Total water budget
    model.addConstr(
        gp.quicksum(annual_water[f] for f in fruits) <= total_water_budget,
        name="total_water_budget"
    )

    # Annual ratio constraints (applied to annual totals)
    # apples >= min_a_to_p * pears
    model.addConstr(annual['apples'] >= min_a_to_p * annual['pears'], name="apples_pears_ratio")
    # apples >= min_a_to_l * lemons
    model.addConstr(annual['apples'] >= min_a_to_l * annual['lemons'], name="apples_lemons_ratio")
    # oranges == o_to_l * lemons
    model.addConstr(annual['oranges'] == o_to_l * annual['lemons'], name="oranges_lemons_ratio")

    # Linking y[f] to actual growing: if y[f]=0, no acres; if y[f]=1, must meet min water threshold
    # Upper bound on annual water when y=0
    for f in fruits:
        model.addConstr(annual_water[f] <= M_water * y[f], name=f"link_upper_{f}")
    
    # If y[f]=1, annual water >= min_annual_water
    for f in fruits:
        model.addConstr(annual_water[f] >= min_annual_water * y[f], name=f"link_lower_{f}")

    # Max fruit types
    model.addConstr(gp.quicksum(y[f] for f in fruits) <= max_types, name="max_types")

    # Diversification reward: div=1 only if at least 2 fruit types grown
    # div <= sum(y)/2  (so if sum(y)<2, div must be 0)
    # Also div >= (sum(y) - 1) / (num_fruits - 1) would be complex; simpler:
    # div <= y[f] for each f is wrong. Use:
    # sum(y) >= 2*div
    model.addConstr(gp.quicksum(y[f] for f in fruits) >= 2 * div, name="div_min_types")
    # We want div=1 whenever sum(y)>=2 (to maximize). Since it's in objective with positive coeff,
    # optimizer will set div=1 whenever feasible.
    # But we also need: div <= 1 (already binary) and div can only be 1 if sum(y)>=2.
    # The constraint sum(y) >= 2*div handles this.

    # Objective: maximize total profit + diversification reward
    obj = gp.quicksum(
        profits[f] * (x[f, 'spring'] + x[f, 'autumn']) for f in fruits
    ) + diversification_reward * div

    model.setObjective(obj, GRB.MAXIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # Try to get best solution
        if model.SolCount > 0:
            obj_val = model.ObjVal
            print(f"FINAL_OBJ_VALUE: {obj_val}")
        else:
            print(f"FINAL_OBJ_VALUE: -1")

solve()
