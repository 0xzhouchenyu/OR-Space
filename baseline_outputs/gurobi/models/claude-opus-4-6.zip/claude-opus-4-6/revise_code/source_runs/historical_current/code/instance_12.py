import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load container data
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    fixed_cost = params['fixed_setup_cost']
    energy_cost_per_kwh = params['energy_cost_per_kwh']
    max_total_energy = params['max_total_energy_kwh']
    eco_capacity_share = params['eco_capacity_share']
    eco_overhead_cost = params['eco_overhead_cost']
    regular_energy_intensity = params['regular_energy_intensity_kwh_per_unit']
    eco_energy_intensity = params['eco_energy_intensity_kwh_per_unit']

    n = len(containers)
    M = sum(c['demand'] for c in containers)

    model = gp.Model("PlasticContainers_Revised")
    model.setParam('OutputFlag', 0)

    # Modes: 'R' = regular, 'E' = eco
    # x_r[i,j] = units of type i produced in regular mode to fulfill demand of type j
    # x_e[i,j] = units of type i produced in eco mode to fulfill demand of type j
    # Only allowed if volume[i] >= volume[j]
    x_r = {}
    x_e = {}
    valid_pairs = []
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                valid_pairs.append((i, j))
                x_r[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"xr_{i}_{j}")
                x_e[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"xe_{i}_{j}")

    # y_r[i] = 1 if type i is produced in regular mode
    # y_e[i] = 1 if type i is produced in eco mode
    y_r = {}
    y_e = {}
    for i in range(n):
        y_r[i] = model.addVar(vtype=GRB.BINARY, name=f"yr_{i}")
        y_e[i] = model.addVar(vtype=GRB.BINARY, name=f"ye_{i}")

    model.update()

    # Objective: variable production costs + energy costs + fixed setup costs + eco overhead costs
    obj = gp.LinExpr()
    # Variable production costs
    for (i, j) in valid_pairs:
        obj += containers[i]['cost'] * (x_r[i, j] + x_e[i, j])
    # Energy costs
    for (i, j) in valid_pairs:
        obj += energy_cost_per_kwh * regular_energy_intensity * x_r[i, j]
        obj += energy_cost_per_kwh * eco_energy_intensity * x_e[i, j]
    # Fixed setup costs: incurred for activating production equipment for any container type in any mode
    for i in range(n):
        obj += fixed_cost * y_r[i]
        obj += fixed_cost * y_e[i]
    # Eco overhead cost
    for i in range(n):
        obj += eco_overhead_cost * y_e[i]

    model.setObjective(obj, GRB.MINIMIZE)

    # Demand constraints: for each type j, total supplied >= demand[j]
    for j in range(n):
        model.addConstr(
            gp.quicksum(x_r[i, j] + x_e[i, j] for i in range(n) if (i, j) in x_r) >= containers[j]['demand'],
            name=f"demand_{j}"
        )

    # Linking constraints for regular mode
    for i in range(n):
        total_regular_i = gp.quicksum(x_r[i, j] for j in range(n) if (i, j) in x_r)
        model.addConstr(total_regular_i <= M * y_r[i], name=f"setup_r_{i}")

    # Linking constraints for eco mode
    for i in range(n):
        total_eco_i = gp.quicksum(x_e[i, j] for j in range(n) if (i, j) in x_e)
        model.addConstr(total_eco_i <= M * y_e[i], name=f"setup_e_{i}")

    # Eco capacity constraint: eco production of type i <= eco_capacity_share * total production of type i
    # i.e., total_eco_i <= eco_capacity_share * (total_regular_i + total_eco_i)
    # => total_eco_i * (1 - eco_capacity_share) <= eco_capacity_share * total_regular_i
    for i in range(n):
        total_regular_i = gp.quicksum(x_r[i, j] for j in range(n) if (i, j) in x_r)
        total_eco_i = gp.quicksum(x_e[i, j] for j in range(n) if (i, j) in x_e)
        model.addConstr(
            total_eco_i * (1 - eco_capacity_share) <= eco_capacity_share * total_regular_i,
            name=f"eco_cap_{i}"
        )

    # Total energy constraint
    total_energy = gp.LinExpr()
    for (i, j) in valid_pairs:
        total_energy += regular_energy_intensity * x_r[i, j]
        total_energy += eco_energy_intensity * x_e[i, j]
    model.addConstr(total_energy <= max_total_energy, name="max_energy")

    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible")
        model.computeIIS()
        model.write("model.ilp")
    else:
        print(f"Optimization ended with status {model.status}")

if __name__ == "__main__":
    main()
