import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = float(params['fixed_order_cost'])
    august_bulk_order_threshold = float(params['august_bulk_order_threshold'])
    august_bulk_receiving_fee = float(params['august_bulk_receiving_fee'])
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Big-M for binary variable linking
    M = warehouse_capacity  # max possible purchase in any month
    
    # Create model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = {}
    sell = {}
    stock = {}
    y_order = {}  # binary: 1 if any purchase is made in month m (for fixed order cost)
    
    for m in months:
        buy[m] = model.addVar(lb=0, name=f"buy_{m}")
        sell[m] = model.addVar(lb=0, name=f"sell_{m}")
        stock[m] = model.addVar(lb=0, ub=warehouse_capacity, name=f"stock_{m}")
        y_order[m] = model.addVar(vtype=GRB.BINARY, name=f"y_order_{m}")
    
    # August bulk receiving binary: 1 if August purchase exceeds threshold
    y_aug_bulk = model.addVar(vtype=GRB.BINARY, name="y_aug_bulk")
    
    model.update()
    
    # Objective: maximize total profit (revenue - purchasing cost - fixed order costs - august bulk fee)
    obj = gp.LinExpr()
    for m in months:
        obj += sell_price[m] * sell[m] - buy_price[m] * buy[m]
        obj -= fixed_order_cost * y_order[m]
    obj -= august_bulk_receiving_fee * y_aug_bulk
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints
    for i, m in enumerate(months):
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_stock = stock[months[i-1]]
        
        # Stock balance
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], name=f"balance_{m}")
        
        # Warehouse capacity after buying (before selling)
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, name=f"warehouse_after_buy_{m}")
        
        # Link buy to y_order: if buy[m] > 0, then y_order[m] = 1
        model.addConstr(buy[m] <= M * y_order[m], name=f"order_link_{m}")
    
    # August bulk receiving constraint:
    # If buy[8] > august_bulk_order_threshold, then y_aug_bulk = 1
    # buy[8] <= august_bulk_order_threshold + M * y_aug_bulk
    model.addConstr(buy[8] <= august_bulk_order_threshold + M * y_aug_bulk, name="aug_bulk_link")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        for m in months:
            print(f"Month {m}: Buy={buy[m].X:.1f} @ {buy_price[m]}, "
                  f"Sell={sell[m].X:.1f} @ {sell_price[m]}, "
                  f"Stock={stock[m].X:.1f}, "
                  f"OrderPlaced={y_order[m].X:.0f}")
        print(f"August bulk receiving activated: {y_aug_bulk.X:.0f}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
