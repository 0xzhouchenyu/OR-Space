import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read table_1.csv
toys = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            'type': row['Toy_Type'],
            'labor': float(row['Manufacturing_Labor_Hours']),
            'inspection': float(row['Inspection_Hours']),
            'profit': float(row['Profit_Per_Unit'])
        })

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Extract parameters
available_labor_p1 = params['available_labor_hours_period1']
available_labor_p2 = params['available_labor_hours_period2']
available_inspection_p1 = params['available_inspection_hours_period1']
available_inspection_p2 = params['available_inspection_hours_period2']

max_demand = {
    ('High-End', 1): params['max_demand_high_end_period1'],
    ('Mid-Range', 1): params['max_demand_mid_range_period1'],
    ('Low-End', 1): params['max_demand_low_end_period1'],
    ('High-End', 2): params['max_demand_high_end_period2'],
    ('Mid-Range', 2): params['max_demand_mid_range_period2'],
    ('Low-End', 2): params['max_demand_low_end_period2'],
}

overtime_labor_cap = params['overtime_labor_cap']
overtime_labor_cost = params['overtime_labor_cost']
period1_overtime_fatigue_threshold = params['period1_overtime_fatigue_threshold']
period2_labor_recovery_loss = params['period2_labor_recovery_loss']
overtime_review_threshold = params['overtime_review_threshold']
seasonal_safety_review_fee = params['seasonal_safety_review_fee']

# Build model
model = gp.Model("ToyProduction_TwoPeriod")
model.setParam('OutputFlag', 0)

periods = [1, 2]
toy_types = [t['type'] for t in toys]
toy_data = {t['type']: t for t in toys}

# Decision variables: production quantities per toy type per period
x = {}
for t in toy_types:
    for p in periods:
        x[t, p] = model.addVar(lb=0, name=f"x_{t}_{p}")

# Overtime variables per period
ot1 = model.addVar(lb=0, name="overtime_p1")
ot2 = model.addVar(lb=0, name="overtime_p2")

# Binary variable: whether period-1 overtime exceeds fatigue threshold
fatigue_triggered = model.addVar(vtype=GRB.BINARY, name="fatigue_triggered")

# Auxiliary variable: excess overtime in period 1 above threshold
ot1_excess = model.addVar(lb=0, name="ot1_excess")

# Binary variable: whether total overtime exceeds review threshold
review_triggered = model.addVar(vtype=GRB.BINARY, name="review_triggered")

# Total overtime
total_ot = model.addVar(lb=0, name="total_overtime")

model.update()

# Total overtime definition
model.addConstr(total_ot == ot1 + ot2, "total_overtime_def")

# Overtime cap (total across both periods)
model.addConstr(total_ot <= overtime_labor_cap, "overtime_cap")

# Period 1 labor constraint: regular + overtime
model.addConstr(
    gp.quicksum(toy_data[t]['labor'] * x[t, 1] for t in toy_types) <= available_labor_p1 + ot1,
    "labor_p1"
)

# Period 1 inspection constraint
model.addConstr(
    gp.quicksum(toy_data[t]['inspection'] * x[t, 1] for t in toy_types) <= available_inspection_p1,
    "inspection_p1"
)

# Fatigue carryover logic:
# If ot1 > period1_overtime_fatigue_threshold, then fatigue_triggered = 1
# and period-2 regular labor is reduced by period2_labor_recovery_loss
# 
# We model: ot1_excess >= ot1 - period1_overtime_fatigue_threshold
# fatigue_triggered = 1 iff ot1 > period1_overtime_fatigue_threshold
#
# Using big-M:
M_big = overtime_labor_cap + 1  # ot1 can be at most overtime_labor_cap

# ot1_excess >= ot1 - threshold (when positive)
model.addConstr(ot1_excess >= ot1 - period1_overtime_fatigue_threshold, "fatigue_excess_lb")

# Link fatigue_triggered to ot1 exceeding threshold
# If ot1 > threshold then fatigue_triggered = 1
model.addConstr(ot1 - period1_overtime_fatigue_threshold <= M_big * fatigue_triggered, "fatigue_trigger_1")
# If fatigue_triggered = 0 then ot1 <= threshold
model.addConstr(ot1 <= period1_overtime_fatigue_threshold + M_big * fatigue_triggered, "fatigue_trigger_1b")
# Actually we need: fatigue_triggered=1 iff ot1 > threshold
# But for LP relaxation purposes, since triggering fatigue is costly (reduces capacity),
# the model will only set fatigue_triggered=1 when forced.
# ot1 > threshold => fatigue_triggered = 1: already handled by fatigue_trigger_1
# fatigue_triggered = 1 => ot1 >= threshold is NOT required (conservative: could trigger even if not needed, but optimizer won't)
# ot1_excess should be 0 when fatigue not triggered
model.addConstr(ot1_excess <= M_big * fatigue_triggered, "fatigue_excess_ub")

# Period 2 labor constraint with fatigue effect
# Available regular labor in period 2 is reduced by recovery_loss if fatigue triggered
model.addConstr(
    gp.quicksum(toy_data[t]['labor'] * x[t, 2] for t in toy_types) <= 
    available_labor_p2 - period2_labor_recovery_loss * fatigue_triggered + ot2,
    "labor_p2"
)

# Period 2 inspection constraint
model.addConstr(
    gp.quicksum(toy_data[t]['inspection'] * x[t, 2] for t in toy_types) <= available_inspection_p2,
    "inspection_p2"
)

# Demand constraints
for t in toy_types:
    for p in periods:
        model.addConstr(x[t, p] <= max_demand[t, p], f"demand_{t}_{p}")

# Safety review logic:
# If total_ot > overtime_review_threshold, review_triggered = 1 and fee applies
M_big2 = overtime_labor_cap + 1
model.addConstr(total_ot - overtime_review_threshold <= M_big2 * review_triggered, "review_trigger_1")
# If review_triggered = 0, total_ot <= threshold
# (This is already implied by the constraint above when review_triggered=0)

# Objective: maximize profit - overtime costs - safety review fee
profit_expr = gp.quicksum(
    toy_data[t]['profit'] * x[t, p] for t in toy_types for p in periods
)
overtime_cost_expr = overtime_labor_cost * total_ot
review_cost_expr = seasonal_safety_review_fee * review_triggered

model.setObjective(profit_expr - overtime_cost_expr - review_cost_expr, GRB.MAXIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    for t in toy_types:
        for p in periods:
            print(f"{t} Period {p}: {x[t, p].X:.4f}")
    print(f"Overtime P1: {ot1.X:.4f}")
    print(f"Overtime P2: {ot2.X:.4f}")
    print(f"Total Overtime: {total_ot.X:.4f}")
    print(f"Fatigue Triggered: {fatigue_triggered.X:.0f}")
    print(f"Review Triggered: {review_triggered.X:.0f}")
    print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
