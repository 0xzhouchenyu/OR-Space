import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
m1_liquid = params['machine_1_time_per_liquid_lot']  # 50 min/lot
m2_liquid = params['machine_2_time_per_liquid_lot']  # 30 min/lot
m1_solid = params['machine_1_time_per_solid_lot']    # 24 min/lot
m2_solid = params['machine_2_time_per_solid_lot']    # 33 min/lot

init_liquid = params['initial_liquid_inventory']  # 30 lots
init_solid = params['initial_solid_inventory']    # 90 lots

m1_base = params['machine_1_available_time'] * 60  # 2400 minutes
m2_base = params['machine_2_available_time'] * 60  # 2100 minutes

demand_liquid = params['forecast_liquid_demand']  # 75 lots
demand_solid = params['forecast_solid_demand']    # 95 lots

extended_extra = params['extended_extra_minutes']        # 600 minutes
labor_per_ext = params['labor_hours_per_machine_extended']  # 8 hours
labor_budget = params['labor_budget_hours']               # 10 hours
ext_penalty = params['extended_mode_penalty']             # 0.5 score per extended machine
priority_reserve = params['priority_reserve_lots']        # 10 lots
excess_credit = params['excess_reserve_credit']           # 0.35 score/lot

# Build optimization model
model = gp.Model("Fertilizer_Resilience")
model.setParam('OutputFlag', 0)

# Decision variables
x_l = model.addVar(lb=0, name="x_liquid")  # lots of liquid produced
x_s = model.addVar(lb=0, name="x_solid")   # lots of solid produced

# Binary variables for extended mode on each machine
ext_m1 = model.addVar(vtype=GRB.BINARY, name="ext_m1")
ext_m2 = model.addVar(vtype=GRB.BINARY, name="ext_m2")

# Ending inventories
# end_liquid = init_liquid + x_l - demand_liquid
# end_solid = init_solid + x_s - demand_solid
end_liquid = model.addVar(lb=0, name="end_liquid")
end_solid = model.addVar(lb=0, name="end_solid")

model.addConstr(end_liquid == init_liquid + x_l - demand_liquid, "end_liquid_def")
model.addConstr(end_solid == init_solid + x_s - demand_solid, "end_solid_def")

# Demand satisfaction (ending inventory >= 0 already via lb=0)

# Machine capacity constraints with optional extension
model.addConstr(m1_liquid * x_l + m1_solid * x_s <= m1_base + extended_extra * ext_m1, "Machine_1_Cap")
model.addConstr(m2_liquid * x_l + m2_solid * x_s <= m2_base + extended_extra * ext_m2, "Machine_2_Cap")

# Labor budget constraint for extended modes
model.addConstr(labor_per_ext * ext_m1 + labor_per_ext * ext_m2 <= labor_budget, "Labor_Budget")

# Resilience score computation:
# For each product: first priority_reserve_lots count fully (1 per lot),
# inventory above that counts at excess_reserve_credit per lot.
# Score = sum over products of (min(end_inv, priority_reserve) + excess_reserve_credit * max(end_inv - priority_reserve, 0))
#       - extended_mode_penalty * (ext_m1 + ext_m2)

# For liquid:
# priority_liquid = min(end_liquid, priority_reserve)
# excess_liquid = max(end_liquid - priority_reserve, 0)
priority_liquid = model.addVar(lb=0, ub=priority_reserve, name="priority_liquid")
excess_liquid = model.addVar(lb=0, name="excess_liquid")
model.addConstr(priority_liquid + excess_liquid == end_liquid, "liquid_split")
# To ensure priority_liquid fills first (since it has higher coefficient in objective,
# the optimizer will naturally fill priority_liquid first up to its ub)

# For solid:
priority_solid = model.addVar(lb=0, ub=priority_reserve, name="priority_solid")
excess_solid = model.addVar(lb=0, name="excess_solid")
model.addConstr(priority_solid + excess_solid == end_solid, "solid_split")

# Objective: maximize resilience score
obj = (priority_liquid + excess_credit * excess_liquid +
       priority_solid + excess_credit * excess_solid -
       ext_penalty * (ext_m1 + ext_m2))

model.setObjective(obj, GRB.MAXIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"Liquid produced: {x_l.X:.4f} lots")
    print(f"Solid produced: {x_s.X:.4f} lots")
    print(f"Ending liquid inventory: {end_liquid.X:.4f}")
    print(f"Ending solid inventory: {end_solid.X:.4f}")
    print(f"Extended M1: {ext_m1.X:.0f}, Extended M2: {ext_m2.X:.0f}")
    print(f"Priority liquid: {priority_liquid.X:.4f}, Excess liquid: {excess_liquid.X:.4f}")
    print(f"Priority solid: {priority_solid.X:.4f}, Excess solid: {excess_solid.X:.4f}")
    print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
