import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_coverage_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    
    return areas, coverage

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    distance_limit = int(params.get('distance_limit', 800))
    small_cost = int(params.get('small_cost', 1))
    large_cost = int(params.get('large_cost', 2))
    small_cap_areas = int(params.get('small_cap_areas', 3))
    max_large_stores = int(params.get('max_large_stores', 1))
    minimum_neighborhood_counters = int(params.get('minimum_neighborhood_counters', 6))
    small_store_counter_credit = int(params.get('small_store_counter_credit', 1))
    
    all_areas = set(areas)
    
    model = gp.Model("MinChainStores")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_s[j] = 1 if we open a Small-format store at area j
    # x_l[j] = 1 if we open a Large-format store at area j
    x_s = {}
    x_l = {}
    for j in areas:
        x_s[j] = model.addVar(vtype=GRB.BINARY, name=f"x_s_{j}")
        x_l[j] = model.addVar(vtype=GRB.BINARY, name=f"x_l_{j}")
    
    # For small stores, we need to decide which areas they actually serve (up to small_cap_areas)
    # y_s[j, i] = 1 if small store at j serves area i
    y_s = {}
    for j in areas:
        for i in coverage[j]:
            y_s[j, i] = model.addVar(vtype=GRB.BINARY, name=f"y_s_{j}_{i}")
    
    # For large stores, they serve all areas in their coverage (no cap mentioned, follow existing rules)
    # y_l[j, i] = 1 if large store at j serves area i (equals x_l[j] for i in coverage[j])
    y_l = {}
    for j in areas:
        for i in coverage[j]:
            y_l[j, i] = model.addVar(vtype=GRB.BINARY, name=f"y_l_{j}_{i}")
    
    model.update()
    
    # Objective: minimize total cost
    obj = gp.LinExpr()
    for j in areas:
        obj += small_cost * x_s[j] + large_cost * x_l[j]
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraint: each area must be covered by at least one store (small or large)
    for i in areas:
        covering_expr = gp.LinExpr()
        for j in areas:
            if i in coverage[j]:
                if (j, i) in y_s:
                    covering_expr += y_s[j, i]
                if (j, i) in y_l:
                    covering_expr += y_l[j, i]
        model.addConstr(covering_expr >= 1, name=f"Cover_{i}")
    
    # Small store can only serve areas in its coverage list
    # y_s[j,i] <= x_s[j]
    for j in areas:
        for i in coverage[j]:
            if (j, i) in y_s:
                model.addConstr(y_s[j, i] <= x_s[j], name=f"SmallLink_{j}_{i}")
    
    # Small store serves at most small_cap_areas areas
    for j in areas:
        serve_expr = gp.LinExpr()
        for i in coverage[j]:
            if (j, i) in y_s:
                serve_expr += y_s[j, i]
        model.addConstr(serve_expr <= small_cap_areas * x_s[j], name=f"SmallCap_{j}")
    
    # Large store serves all areas in coverage if opened
    # y_l[j,i] = x_l[j] for i in coverage[j]
    for j in areas:
        for i in coverage[j]:
            if (j, i) in y_l:
                model.addConstr(y_l[j, i] == x_l[j], name=f"LargeLink_{j}_{i}")
    
    # Maximum number of large stores
    model.addConstr(gp.quicksum(x_l[j] for j in areas) <= max_large_stores, name="MaxLarge")
    
    # Cannot open both small and large at same location (or can we? Not stated, allow both)
    # Actually, let's allow both types at the same location unless restricted
    
    # Minimum neighborhood counters: at least 6 small-format stores
    model.addConstr(
        gp.quicksum(small_store_counter_credit * x_s[j] for j in areas) >= minimum_neighborhood_counters,
        name="MinCounters"
    )
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        
        selected_small = [j for j in areas if x_s[j].X > 0.5]
        selected_large = [j for j in areas if x_l[j].X > 0.5]
        
        print(f"Optimal total cost: {obj_val}")
        print(f"Small-format store locations: {sorted(selected_small)}")
        print(f"Large-format store locations: {sorted(selected_large)}")
        print(f"Total stores: {len(selected_small) + len(selected_large)}")
        
        # Verify coverage
        covered_total = set()
        for j in selected_small:
            served = [i for i in coverage[j] if (j, i) in y_s and y_s[j, i].X > 0.5]
            print(f"  Small store at {j} serves: {sorted(served)}")
            covered_total.update(served)
        for j in selected_large:
            served = [i for i in coverage[j] if (j, i) in y_l and y_l[j, i].X > 0.5]
            print(f"  Large store at {j} serves: {sorted(served)}")
            covered_total.update(served)
        
        print(f"All areas covered: {all_areas.issubset(covered_total)}")
        print(f"Covered areas: {sorted(covered_total)}")
        print(f"Number of small stores (counters): {len(selected_small)}")
        
        print(f"\nFINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
