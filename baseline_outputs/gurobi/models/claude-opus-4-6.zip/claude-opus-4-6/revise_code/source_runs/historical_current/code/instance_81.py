import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load car data
cars = {}
filepath = os.path.join(data_dir, "table_1.csv")
with open(filepath, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row['i'])
        length = float(row['lambda_i'])
        cars[i] = length

# Load parameters
params = {}
filepath = os.path.join(data_dir, "general_parameters.csv")
with open(filepath, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'])
        params[name] = value

num_cars = int(params['num_cars'])
max_length_one_side = params['max_length_one_side']
available_party_side_count = int(params['available_party_side_count'])

car_ids = list(cars.keys())
lengths = cars

# Revised problem:
# Only ONE side of the street is available for party cars (available_party_side_count = 1).
# The other side must remain completely clear.
# All 15 cars must park on the single usable side.
# The usable side has a max_length_one_side constraint (60 meters).
# The total length of all cars on the usable side is the street length occupied.
# Since all cars go on one side, the objective is simply the sum of all car lengths
# (assuming all cars must park), subject to the capacity constraint.
#
# However, re-reading the original problem: "minimize the total length of the street occupied"
# With two sides, the street length occupied = max(side1, side2) since cars on opposite sides
# overlap in street length usage. With only one side available, all cars on one side,
# the street length occupied = sum of all car lengths on that side.
#
# All 15 cars need to park. With one side available and max 60m:
# Total car length = sum of all = 4+4.5+5+4.1+2.4+5.2+3.7+3.5+3.2+4.5+2.3+3.3+3.8+4.6+3 = 57.1
# 57.1 <= 60, so all cars fit on one side.
#
# The objective (minimizing street length occupied) with one side = total length of cars on that side.
# Since all must park on that one side, objective = 57.1.

total_length = sum(lengths[i] for i in car_ids)

# Create model
model = gp.Model("ParkingRevised")
model.setParam('OutputFlag', 0)

# All cars must be parked on the single available side.
# The street length occupied is the sum of their lengths.
# We just need to verify feasibility (total <= max_length_one_side).

# For completeness, model it properly:
# x_i = 1 if car i is parked (on the one available side)
# We want all cars parked, but let's model it as: all cars must be parked.

x = {}
for i in car_ids:
    x[i] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}")

# T = street length occupied (length of the single usable side)
T = model.addVar(lb=0, name="T")

model.update()

# All cars must be parked on the available side
for i in car_ids:
    model.addConstr(x[i] == 1, name=f"must_park_{i}")

# T = total length on the usable side
side_length = gp.quicksum(lengths[i] * x[i] for i in car_ids)
model.addConstr(T == side_length, name="T_def")

# Capacity constraint on the usable side
model.addConstr(side_length <= max_length_one_side, name="max_side")

# Objective: minimize street length occupied
model.setObjective(T, GRB.MINIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"Total car length: {total_length}")
    print(f"Cars parked: {[i for i in car_ids if x[i].X > 0.5]}")
    print(f"Street length occupied: {obj_val}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")
elif model.status == GRB.INFEASIBLE:
    print("Problem is infeasible - cars don't fit on the available side")
    print(f"Total car length: {total_length}, Max allowed: {max_length_one_side}")
    print(f"FINAL_OBJ_VALUE: infeasible")
else:
    print(f"Optimization ended with status {model.status}")
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
