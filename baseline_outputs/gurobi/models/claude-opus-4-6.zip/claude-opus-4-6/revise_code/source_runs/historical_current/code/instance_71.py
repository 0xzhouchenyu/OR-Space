import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    base = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base, "data")
    
    # Read general parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    
    n = int(params['n'])
    premium_cost_multiplier = float(params['premium_cost_multiplier'])
    min_premium_share = float(params['min_premium_share'])
    
    # Read table_1.csv
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    # d[i][j] = transportation volume from factory i to location j
    # c[p][q] = unit transportation cost from location p to location q
    d = []
    c = []
    for row in rows:
        d.append([float(row[f'Transportation_volume_to_Location_{j+1}']) for j in range(n)])
        c.append([float(row[f'Transportation_cost_to_Location_{j+1}']) for j in range(n)])
    
    # d[i][j]: volume from factory i to destination j (locations as destinations)
    # c[p][q]: cost per unit from location p to location q
    
    # outbound_volume_i = sum_j d[i][j]
    outbound_volume = [sum(d[i][j] for j in range(n)) for i in range(n)]
    
    # c_std_ip = (sum_j d[i][j] * c[p][j]) / outbound_volume[i] when outbound_volume[i] > 0
    c_std = [[0.0]*n for _ in range(n)]
    for i in range(n):
        for p in range(n):
            if outbound_volume[i] > 0:
                c_std[i][p] = sum(d[i][j] * c[p][j] for j in range(n)) / outbound_volume[i]
            else:
                c_std[i][p] = 0.0
    
    # c_prem_ip = premium_cost_multiplier * c_std_ip
    c_prem = [[premium_cost_multiplier * c_std[i][p] for p in range(n)] for i in range(n)]
    
    # M_i = outbound_volume[i]
    M = outbound_volume
    
    # Create model
    model = gp.Model("factory_assignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i,p] = 1 if factory i is assigned to location p
    x = {}
    for i in range(n):
        for p in range(n):
            x[i, p] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{p}")
    
    # y[i,p] = 1 if premium handling is selected for factory i at location p
    y = {}
    for i in range(n):
        for p in range(n):
            y[i, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{p}")
    
    # v_std[i,p] = volume handled in standard mode for factory i at location p
    v_std = {}
    for i in range(n):
        for p in range(n):
            v_std[i, p] = model.addVar(lb=0, ub=M[i], name=f"v_std_{i}_{p}")
    
    # v_prem[i,p] = volume handled in premium mode for factory i at location p
    v_prem = {}
    for i in range(n):
        for p in range(n):
            v_prem[i, p] = model.addVar(lb=0, ub=M[i], name=f"v_prem_{i}_{p}")
    
    model.update()
    
    # Constraints
    
    # Each factory assigned to exactly one location
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, p] for p in range(n)) == 1, name=f"assign_factory_{i}")
    
    # Each location hosts at most one factory
    for p in range(n):
        model.addConstr(gp.quicksum(x[i, p] for i in range(n)) <= 1, name=f"location_cap_{p}")
    
    # Total volume at assigned location equals outbound volume
    # v_std[i,p] + v_prem[i,p] = outbound_volume[i] * x[i,p]
    for i in range(n):
        for p in range(n):
            model.addConstr(v_std[i, p] + v_prem[i, p] == M[i] * x[i, p],
                            name=f"vol_balance_{i}_{p}")
    
    # Premium mode can only be selected if factory is assigned to that location
    # y[i,p] <= x[i,p]
    for i in range(n):
        for p in range(n):
            model.addConstr(y[i, p] <= x[i, p], name=f"premium_only_if_assigned_{i}_{p}")
    
    # Premium volume only possible if premium is selected
    # v_prem[i,p] <= M[i] * y[i,p]
    for i in range(n):
        for p in range(n):
            model.addConstr(v_prem[i, p] <= M[i] * y[i, p], name=f"prem_vol_upper_{i}_{p}")
    
    # If premium is selected, minimum premium share constraint
    # v_prem[i,p] >= min_premium_share * outbound_volume[i] * y[i,p]
    for i in range(n):
        for p in range(n):
            model.addConstr(v_prem[i, p] >= min_premium_share * M[i] * y[i, p],
                            name=f"min_prem_share_{i}_{p}")
    
    # Objective: minimize total cost
    # total_cost = sum_{i,p} (c_std[i][p] * v_std[i,p] + c_prem[i][p] * v_prem[i,p])
    obj = gp.quicksum(
        c_std[i][p] * v_std[i, p] + c_prem[i][p] * v_prem[i, p]
        for i in range(n) for p in range(n)
    )
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        
        # Print solution details for debugging
        for i in range(n):
            for p in range(n):
                if x[i, p].X > 0.5:
                    print(f"Factory {i+1} -> Location {p+1}, "
                          f"v_std={v_std[i,p].X:.2f}, v_prem={v_prem[i,p].X:.2f}, "
                          f"y={y[i,p].X:.0f}, "
                          f"c_std={c_std[i][p]:.4f}, c_prem={c_prem[i][p]:.4f}")
        
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

solve()
