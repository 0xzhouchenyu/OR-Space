import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
profit_A = params['profit_per_kg_product_A']  # 30
profit_B = params['profit_per_kg_product_B']  # 10
max_hours_w1 = params['max_production_hours_week_1']  # 40
max_hours_w2 = params['max_production_hours_week_2']  # 40
hours_A = params['hours_per_kg_product_A']  # 6
hours_B = params['hours_per_kg_product_B']  # 3
min_ratio_B_to_A = params['min_output_ratio_product_B_to_A']  # 3
storage_ratio = params['storage_space_ratio_product_A_to_B']  # 4
max_storage_w1 = params['max_storage_product_A_equiv_week_1']  # 4 (in equiv kg of A)
max_storage_w2 = params['max_storage_product_A_equiv_week_2']  # 4
init_inv_A = params['initial_inventory_A']  # 0
init_inv_B = params['initial_inventory_B']  # 0
storage_cost_A = params['storage_cost_per_kg_A']  # 1
storage_cost_B = params['storage_cost_per_kg_B']  # 1
promo_bonus_A = params['promo_profit_bonus_A']  # 2
promo_bonus_B = params['promo_profit_bonus_B']  # 1
max_promos_A = int(params['max_promotions_product_A'])  # 1
max_promos_B = int(params['max_promotions_product_B'])  # 1

weeks = [1, 2]
max_hours = {1: max_hours_w1, 2: max_hours_w2}
max_storage_equiv = {1: max_storage_w1, 2: max_storage_w2}
# Total storage capacity in space units: max_storage_A_equiv * storage_ratio
# Because product A takes `storage_ratio` units per kg, and product B takes 1 unit per kg
# max_storage_A_equiv is in kg of A, so total space = max_storage_A_equiv * storage_ratio
max_storage_space = {w: max_storage_equiv[w] * storage_ratio for w in weeks}

# Create model
m = gp.Model("two_week_production")
m.setParam('OutputFlag', 0)

# Decision variables per week
# Production
prod_A = {w: m.addVar(lb=0, name=f"prod_A_{w}") for w in weeks}
prod_B = {w: m.addVar(lb=0, name=f"prod_B_{w}") for w in weeks}

# Sales
sell_A = {w: m.addVar(lb=0, name=f"sell_A_{w}") for w in weeks}
sell_B = {w: m.addVar(lb=0, name=f"sell_B_{w}") for w in weeks}

# End-of-week inventory (what's carried over)
inv_A = {w: m.addVar(lb=0, name=f"inv_A_{w}") for w in weeks}
inv_B = {w: m.addVar(lb=0, name=f"inv_B_{w}") for w in weeks}

# Promotion binary variables
promo_A = {w: m.addVar(vtype=GRB.BINARY, name=f"promo_A_{w}") for w in weeks}
promo_B = {w: m.addVar(vtype=GRB.BINARY, name=f"promo_B_{w}") for w in weeks}

# Big-M for linearizing promo bonus * sales
# Upper bound on sales in any week: generous bound
M_A = max_hours_w1 / hours_A + init_inv_A + 100  # generous upper bound
M_B = max_hours_w1 / hours_B + init_inv_B + 100

# Auxiliary variables for promo_sales (promo * sell)
promo_sell_A = {w: m.addVar(lb=0, name=f"promo_sell_A_{w}") for w in weeks}
promo_sell_B = {w: m.addVar(lb=0, name=f"promo_sell_B_{w}") for w in weeks}

m.update()

# Objective: maximize total profit - holding costs
# Profit from sales each week + promo bonus for promoted weeks - storage costs for carry-over
# Storage cost applies to inventory carried from week 1 to week 2
# (inventory at end of week 2 has no further cost since it's end of horizon, 
#  but we only charge for carry-over from w1 to w2)

obj = gp.LinExpr()
for w in weeks:
    # Base profit from sales
    obj += profit_A * sell_A[w] + profit_B * sell_B[w]
    # Promo bonus (linearized)
    obj += promo_bonus_A * promo_sell_A[w] + promo_bonus_B * promo_sell_B[w]

# Storage/holding cost: only for inventory carried from week 1 to week 2
obj -= storage_cost_A * inv_A[1] + storage_cost_B * inv_B[1]

m.setObjective(obj, GRB.MAXIMIZE)

# Constraints

# Inventory balance
# Week 1: initial_inv + production = sales + end_inv
m.addConstr(init_inv_A + prod_A[1] == sell_A[1] + inv_A[1], "inv_balance_A_1")
m.addConstr(init_inv_B + prod_B[1] == sell_B[1] + inv_B[1], "inv_balance_B_1")

# Week 2: carry-over inv from week 1 + production = sales + end_inv
m.addConstr(inv_A[1] + prod_A[2] == sell_A[2] + inv_A[2], "inv_balance_A_2")
m.addConstr(inv_B[1] + prod_B[2] == sell_B[2] + inv_B[2], "inv_balance_B_2")

# Production time constraints per week
for w in weeks:
    m.addConstr(hours_A * prod_A[w] + hours_B * prod_B[w] <= max_hours[w],
                f"production_hours_{w}")

# Market demand: B sold >= 3 * A sold each week
# The requirement says "output of product B to be at least three times the output of product A in each week"
# "output" likely means production
for w in weeks:
    m.addConstr(prod_B[w] >= min_ratio_B_to_A * prod_A[w], f"market_demand_{w}")

# Storage capacity per week (applies to end-of-week inventory)
# Storage space: A takes `storage_ratio` units per kg, B takes 1 unit per kg
# Total capacity in space units = max_storage_equiv * storage_ratio
for w in weeks:
    m.addConstr(storage_ratio * inv_A[w] + inv_B[w] <= max_storage_space[w],
                f"storage_capacity_{w}")

# Promotion limits across the two weeks
m.addConstr(gp.quicksum(promo_A[w] for w in weeks) <= max_promos_A, "max_promo_A")
m.addConstr(gp.quicksum(promo_B[w] for w in weeks) <= max_promos_B, "max_promo_B")

# Linearize promo_sell_A[w] = promo_A[w] * sell_A[w]
for w in weeks:
    m.addConstr(promo_sell_A[w] <= M_A * promo_A[w], f"promo_sell_A_upper1_{w}")
    m.addConstr(promo_sell_A[w] <= sell_A[w], f"promo_sell_A_upper2_{w}")
    m.addConstr(promo_sell_A[w] >= sell_A[w] - M_A * (1 - promo_A[w]), f"promo_sell_A_lower_{w}")

    m.addConstr(promo_sell_B[w] <= M_B * promo_B[w], f"promo_sell_B_upper1_{w}")
    m.addConstr(promo_sell_B[w] <= sell_B[w], f"promo_sell_B_upper2_{w}")
    m.addConstr(promo_sell_B[w] >= sell_B[w] - M_B * (1 - promo_B[w]), f"promo_sell_B_lower_{w}")

# Solve
m.optimize()

if m.status == GRB.OPTIMAL:
    obj_val = m.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")
elif m.status == GRB.INFEASIBLE:
    print("Model is infeasible")
    m.computeIIS()
    print("FINAL_OBJ_VALUE: infeasible")
else:
    print(f"Optimization ended with status {m.status}")
    print(f"FINAL_OBJ_VALUE: {m.ObjVal:.4f}")
