import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

initial_fund = params['initial_fund']  # 300000
annual_rate = params['annual_profit_rate'] / 100  # 0.20
inv_limit_y1 = params['investment_limit_year1']  # 150000
return_rate_y1y2 = params['return_rate_year1_to_year2'] / 100  # 1.50
inv_limit_y2 = params['investment_limit_year2']  # 200000
return_rate_y2y3 = params['return_rate_year2_to_year3'] / 100  # 1.60
inv_limit_y3 = params['investment_limit_year3']  # 100000
profit_rate_y3 = params['profit_rate_year3'] / 100  # 0.40
fee_y1 = params['fee_year1']  # 10000
fee_y2 = params['fee_year2']  # 12000
fee_y3 = params['fee_year3']  # 5000

# Create model
model = gp.Model("Investment_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
# a1, a2, a3: amount invested in annual 20% investment at beginning of year 1, 2, 3
a1 = model.addVar(lb=0, name="a1")
a2 = model.addVar(lb=0, name="a2")
a3 = model.addVar(lb=0, name="a3")

# b1: 2-year special investment at beginning of year 1 (returns end of year 2), max 150000
b1 = model.addVar(lb=0, ub=inv_limit_y1, name="b1")

# c2: 2-year special investment at beginning of year 2 (returns end of year 3), max 200000
c2 = model.addVar(lb=0, ub=inv_limit_y2, name="c2")

# d3: special 1-year investment at beginning of year 3, max 100000
d3 = model.addVar(lb=0, ub=inv_limit_y3, name="d3")

# Binary variables for whether special investments are used
y1 = model.addVar(vtype=GRB.BINARY, name="y1")  # 1 if b1 > 0
y2 = model.addVar(vtype=GRB.BINARY, name="y2")  # 1 if c2 > 0
y3 = model.addVar(vtype=GRB.BINARY, name="y3")  # 1 if d3 > 0

# Link binary variables to investment amounts
model.addConstr(b1 <= inv_limit_y1 * y1, "link_b1_y1")
model.addConstr(c2 <= inv_limit_y2 * y2, "link_c2_y2")
model.addConstr(d3 <= inv_limit_y3 * y3, "link_d3_y3")

# Budget constraint at beginning of Year 1:
# Fees for using special investment in year 1 are paid from the fund
model.addConstr(a1 + b1 + fee_y1 * y1 <= initial_fund, "Year1_budget")

# Available funds at beginning of Year 2:
# Cash carried from year 1 + return from a1
funds_y2 = (initial_fund - a1 - b1 - fee_y1 * y1) + a1 * (1 + annual_rate)

model.addConstr(a2 + c2 + fee_y2 * y2 <= funds_y2, "Year2_budget")

# Available funds at beginning of Year 3:
# Cash carried from year 2 + return from a2 + return from b1
funds_y3 = (funds_y2 - a2 - c2 - fee_y2 * y2) + a2 * (1 + annual_rate) + b1 * return_rate_y1y2

model.addConstr(a3 + d3 + fee_y3 * y3 <= funds_y3, "Year3_budget")

# Total funds at end of year 3:
cash_end = (funds_y3 - a3 - d3 - fee_y3 * y3) + a3 * (1 + annual_rate) + c2 * return_rate_y2y3 + d3 * (1 + profit_rate_y3)

# Objective: maximize net total at end of year 3
model.setObjective(cash_end, GRB.MAXIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"a1={a1.X}, b1={b1.X}, a2={a2.X}, c2={c2.X}, a3={a3.X}, d3={d3.X}")
    print(f"y1={y1.X}, y2={y2.X}, y3={y3.X}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"FINAL_OBJ_VALUE: {None}")
