import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    # Read product segments and profits
    products = []
    segments = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row['Product']
            if p not in segments:
                segments[p] = []
                products.append(p)
            rng = row['Sales_Volume_Range']
            profit = float(row['Profit'])
            if rng.startswith('Above_'):
                lower = float(rng.split('_')[1])
                upper = None
            else:
                parts = rng.split('_')
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({'lower': lower, 'upper': upper, 'profit': profit})

    model = gp.Model("Maximize_Profit")
    model.setParam('OutputFlag', 0)

    M = 10000

    x = {}
    p_var = {}
    y = {}

    for prod in products:
        pname = prod.split('_')[1]
        x[prod] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{pname}")
        p_var[prod] = model.addVar(lb=0, name=f"p_{pname}")
        y[prod] = []
        for i in range(len(segments[prod])):
            yi = model.addVar(vtype=GRB.BINARY, name=f"y_{pname}_{i}")
            y[prod].append(yi)

    # Overtime variable
    overtime = model.addVar(lb=0, ub=params['overtime_cap_hours'], name="overtime")
    
    # Binary variable for second review tier
    z_review = model.addVar(vtype=GRB.BINARY, name="z_review")

    model.update()

    # Segment constraints for each product
    for prod in products:
        segs = segments[prod]
        # Mutual exclusivity: at most one segment active
        model.addConstr(gp.quicksum(y[prod]) <= 1)

        for i, seg in enumerate(segs):
            lo = seg['lower']
            hi = seg['upper']
            profit = seg['profit']

            # If y[i]=1, x must be in [lo+1, hi] (or [lo+1, inf] for last segment)
            # For the first segment starting at 0, lo=0, so x >= 1
            if lo == 0:
                model.addConstr(x[prod] >= 1 - M * (1 - y[prod][i]))
            else:
                model.addConstr(x[prod] >= (lo + 1) - M * (1 - y[prod][i]))

            if hi is not None:
                model.addConstr(x[prod] <= hi + M * (1 - y[prod][i]))

            # Profit bound
            model.addConstr(p_var[prod] <= profit * x[prod] + M * (1 - y[prod][i]))

        # If no segment active (production=0), force x=0 and profit=0
        model.addConstr(x[prod] <= M * gp.quicksum(y[prod]))
        model.addConstr(p_var[prod] <= M * gp.quicksum(y[prod]))

    # Resource constraints
    # Technical preparation time
    model.addConstr(
        gp.quicksum(params[f"technical_prep_time_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params['available_technical_prep_time']
    )

    # Labor time: regular + overtime
    model.addConstr(
        gp.quicksum(params[f"labor_time_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params['available_labor_time'] + overtime
    )

    # Materials
    model.addConstr(
        gp.quicksum(params[f"materials_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params['available_materials']
    )

    # Packaging constraint
    model.addConstr(
        gp.quicksum(params[f"pack_units_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params['packaging_cap_units']
    )

    # Second review tier constraints
    # If overtime > threshold, z_review = 1 and we pay the fee
    threshold = params['overtime_second_review_threshold']
    fee = params['overtime_second_review_fee']
    
    # overtime <= threshold + M * z_review (if overtime > threshold, z_review must be 1)
    model.addConstr(overtime <= threshold + M * z_review)
    # Also: if z_review = 0, overtime <= threshold
    # The above constraint already handles this.
    
    # Objective: sum of product profits - overtime cost - review fee if applicable
    overtime_cost = params['overtime_cost_per_hour']
    
    model.setObjective(
        gp.quicksum(p_var[prod] for prod in products)
        - overtime_cost * overtime
        - fee * z_review,
        GRB.MAXIMIZE
    )

    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj = model.objVal
        print(f"FINAL_OBJ_VALUE: {round(obj, 2)}")
    else:
        print(f"FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
