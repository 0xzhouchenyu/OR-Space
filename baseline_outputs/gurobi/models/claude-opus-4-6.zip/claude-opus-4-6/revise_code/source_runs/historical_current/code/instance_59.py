import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load general parameters
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = {}
    filepath = os.path.join(base_dir, "general_parameters.csv")
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    setup_cost_A = params['SetupCost_A']  # 300
    setup_cost_B = params['SetupCost_B']  # 500
    setup_cost_C = params['SetupCost_C']  # 200
    shared_wrapper_fee = params['BrandAB_SharedWrapper_Fee']  # 300
    
    # Raw material costs
    raw_cost = [2.00, 1.50, 1.00]
    # Processing fees per brand
    proc_fee = [0.50, 0.40, 0.30]
    # Selling prices per brand
    sell_price = [3.40, 2.85, 2.25]
    # Monthly limits for raw materials
    limits = [2000, 2500, 1200]
    
    # Big-M for binary variable linking
    M = sum(limits)  # Upper bound on total production of any brand
    
    # Create model
    model = gp.Model("CandyFactory")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i][j] = kg of raw material i used in brand j
    # Raw materials: 0=A, 1=B, 2=C
    # Brands: 0=A, 1=B, 2=C
    x = {}
    for i in range(3):
        for j in range(3):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    # Binary variables for whether each brand is produced
    z = {}
    for j in range(3):
        z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{j}")
    
    # Binary variable for shared wrapper coordination (both A and B produced)
    w = model.addVar(vtype=GRB.BINARY, name="w_shared_wrapper")
    
    model.update()
    
    # Total production of each brand
    y = {}
    for j in range(3):
        y[j] = gp.quicksum(x[i, j] for i in range(3))
    
    # Link binary variables to production: if y[j] > 0 then z[j] = 1
    # y[j] <= M * z[j]
    for j in range(3):
        model.addConstr(y[j] <= M * z[j], name=f"link_z_{j}")
    
    # Shared wrapper: w >= z[0] + z[1] - 1 (if both A and B produced, w=1)
    # w <= z[0], w <= z[1] (w can only be 1 if both are produced)
    model.addConstr(w >= z[0] + z[1] - 1, name="shared_wrapper_lb")
    model.addConstr(w <= z[0], name="shared_wrapper_ub1")
    model.addConstr(w <= z[1], name="shared_wrapper_ub2")
    
    # Raw material supply constraints
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= limits[i],
                        name=f"supply_{i}")
    
    # Composition constraints
    # Raw material A (i=0): >=60% in brand A (j=0), >=15% in brand B (j=1)
    model.addConstr(x[0, 0] >= 0.60 * y[0], name="comp_A_brandA")
    model.addConstr(x[0, 1] >= 0.15 * y[1], name="comp_A_brandB")
    
    # Raw material C (i=2): <=20% in brand A (j=0), <=60% in brand B (j=1), <=50% in brand C (j=2)
    model.addConstr(x[2, 0] <= 0.20 * y[0], name="comp_C_brandA")
    model.addConstr(x[2, 1] <= 0.60 * y[1], name="comp_C_brandB")
    model.addConstr(x[2, 2] <= 0.50 * y[2], name="comp_C_brandC")
    
    # Objective: maximize profit
    revenue = gp.quicksum(sell_price[j] * y[j] for j in range(3))
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in range(3))
    setup_costs = setup_cost_A * z[0] + setup_cost_B * z[1] + setup_cost_C * z[2]
    wrapper_cost = shared_wrapper_fee * w
    
    profit = revenue - material_cost - processing_cost - setup_costs - wrapper_cost
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj:.1f}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal:.1f}")

if __name__ == "__main__":
    main()
