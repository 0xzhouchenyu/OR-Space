import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    t1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    t2 = pd.read_csv(os.path.join(data_dir, "table_2.csv"))
    t3 = pd.read_csv(os.path.join(data_dir, "table_3.csv"))
    gp_df = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    
    df = t1.merge(t2, on="Product").merge(t3, on="Product")
    
    params = {}
    for _, row in gp_df.iterrows():
        params[row["Parameter_Name"]] = float(row["Value"])
    
    prod_days = params["production_days"]
    a1_watch_threshold = params["a1_watch_threshold"]
    a1_deep_service_threshold = params["a1_deep_service_threshold"]
    maintenance_penalty_watch = params["maintenance_penalty_watch"]
    maintenance_penalty_deep = params["maintenance_penalty_deep"]
    a1_quality_release_fee = params["a1_quality_release_fee"]
    a1_deep_service_fee = params["a1_deep_service_fee"]
    a1_priority_price_lift = params["a1_priority_price_lift"]
    
    products = df["Product"].tolist()
    product_data = {}
    for _, row in df.iterrows():
        product_data[row["Product"]] = row
    
    model = gp.Model("Production_Planning")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    x = {}  # production quantity
    y = {}  # binary activation
    for p in products:
        x[p] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{p}")
        y[p] = model.addVar(vtype=GRB.BINARY, name=f"y_{p}")
    
    # A1-specific variables
    # z_watch = 1 if A1 production > a1_watch_threshold
    z_watch = model.addVar(vtype=GRB.BINARY, name="z_watch")
    # z_deep = 1 if A1 production > a1_deep_service_threshold
    z_deep = model.addVar(vtype=GRB.BINARY, name="z_deep")
    # x_above_watch = units of A1 above watch threshold (gets priority uplift)
    x_above_watch = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="x_above_watch")
    
    model.update()
    
    # All products must be activated
    for p in products:
        model.addConstr(y[p] == 1, name=f"activate_{p}")
    
    # Demand and minimum batch constraints
    for p in products:
        row = product_data[p]
        model.addConstr(x[p] <= row["Maximum_Demand"] * y[p], name=f"demand_{p}")
        model.addConstr(x[p] >= row["Minimum_Batch"] * y[p], name=f"minbatch_{p}")
    
    # A1 watch threshold logic:
    # z_watch = 1 iff x[A1] > a1_watch_threshold
    # We model: x[A1] > a1_watch_threshold => z_watch = 1
    #           x[A1] <= a1_watch_threshold => z_watch = 0
    # Using big-M: 
    # x[A1] <= a1_watch_threshold + M * z_watch
    # x[A1] >= a1_watch_threshold + epsilon - M*(1 - z_watch)  [if z_watch=1, x[A1] >= threshold + eps]
    # Actually, for "clears" the threshold, let's interpret as x[A1] >= a1_watch_threshold + 1 triggers it
    # But since x is continuous, we use: x[A1] > threshold <=> z_watch = 1
    # Practical formulation with small epsilon or just >=:
    
    M_a1 = product_data["A1"]["Maximum_Demand"]
    eps = 0.001  # small epsilon for strict inequality
    
    # If x[A1] > a1_watch_threshold then z_watch must be 1
    # x[A1] - a1_watch_threshold <= M * z_watch
    model.addConstr(x["A1"] - a1_watch_threshold <= M_a1 * z_watch, name="watch_trigger")
    # If z_watch = 1 then x[A1] > a1_watch_threshold (at least threshold + eps effectively)
    # Actually the optimizer will only set z_watch=1 if beneficial. Since z_watch=1 costs money,
    # we need: if z_watch=1, x[A1] >= a1_watch_threshold + eps (to prevent z_watch=1 with low production)
    # But actually we should allow the model freedom. The key constraints are:
    # z_watch=0 => x[A1] <= a1_watch_threshold
    # z_watch=1 => penalties apply, and x_above_watch = x[A1] - a1_watch_threshold
    # The model won't voluntarily set z_watch=1 unless it's profitable.
    
    # x_above_watch = max(0, x[A1] - a1_watch_threshold)
    # When z_watch = 0: x[A1] <= a1_watch_threshold, x_above_watch = 0
    # When z_watch = 1: x_above_watch = x[A1] - a1_watch_threshold
    model.addConstr(x_above_watch <= M_a1 * z_watch, name="above_watch_link1")
    model.addConstr(x_above_watch >= x["A1"] - a1_watch_threshold, name="above_watch_link2")
    model.addConstr(x_above_watch <= x["A1"] - a1_watch_threshold + M_a1 * (1 - z_watch), name="above_watch_link3")
    model.addConstr(x_above_watch >= 0, name="above_watch_nonneg")
    
    # Deep service threshold logic:
    # z_deep = 1 iff x[A1] > a1_deep_service_threshold
    # z_deep=0 => x[A1] <= a1_deep_service_threshold
    model.addConstr(x["A1"] - a1_deep_service_threshold <= M_a1 * z_deep, name="deep_trigger")
    # z_deep can only be 1 if z_watch is also 1 (since deep > watch)
    model.addConstr(z_deep <= z_watch, name="deep_implies_watch")
    
    # Production days constraint with penalties
    # Available days = prod_days - maintenance_penalty_watch * z_watch - maintenance_penalty_deep * z_deep
    available_days = prod_days - maintenance_penalty_watch * z_watch - maintenance_penalty_deep * z_deep
    
    model.addConstr(
        gp.quicksum(x[product_data[p]["Product"]] / product_data[p]["Production_Quota"] for p in products) <= available_days,
        name="production_days"
    )
    
    # Objective: maximize profit
    # Base profit for each product
    base_profit = gp.quicksum(
        (product_data[p]["Selling_Price"] - product_data[p]["Production_Cost"]) * x[p] - product_data[p]["Activation_Cost"] * y[p]
        for p in products
    )
    
    # A1 priority uplift on units above watch threshold
    priority_revenue = a1_priority_price_lift * x_above_watch
    
    # Fees
    fees = a1_quality_release_fee * z_watch + a1_deep_service_fee * z_deep
    
    model.setObjective(base_profit + priority_revenue - fees, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {round(obj_val, 4)}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found, status={model.status}")

if __name__ == "__main__":
    solve()
