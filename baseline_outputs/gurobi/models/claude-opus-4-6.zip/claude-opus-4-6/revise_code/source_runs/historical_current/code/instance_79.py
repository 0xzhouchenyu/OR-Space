import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
sell_price_table = params['sell_price_table']
sell_price_chair = params['sell_price_chair']
sell_price_bookshelf = params['sell_price_bookshelf']

cost_table = params['manufacturing_cost_table']
cost_chair = params['manufacturing_cost_chair']
cost_bookshelf = params['manufacturing_cost_bookshelf']

space_table = params['warehouse_space_table']
space_chair = params['warehouse_space_chair']
space_bookshelf = params['warehouse_space_bookshelf']

max_warehouse = params['max_warehouse_space']
min_tables = params['min_tables']
min_bookshelves = params['min_bookshelves']
max_total = params['max_total_items']

labor_hours_table = params['labor_hours_table']
labor_hours_chair = params['labor_hours_chair']
labor_hours_bookshelf = params['labor_hours_bookshelf']

max_labor_regular = params['max_labor_hours_month_regular']
max_labor_rush = params['max_labor_hours_month_rush']
max_rush_items = params['max_rush_items_month']

rush_bonus_table = params['rush_profit_bonus_table']
rush_bonus_chair = params['rush_profit_bonus_chair']
rush_bonus_bookshelf = params['rush_profit_bonus_bookshelf']

# Profit per item (base)
profit_table = sell_price_table - cost_table        # 80
profit_chair = sell_price_chair - cost_chair          # 30
profit_bookshelf = sell_price_bookshelf - cost_bookshelf  # 60

# Create model
model = gp.Model("Furniture_Production_Revised")
model.setParam('OutputFlag', 0)

# Decision variables: regular and rush for each product type
rt = model.addVar(vtype=GRB.INTEGER, lb=0, name="regular_tables")
rc = model.addVar(vtype=GRB.INTEGER, lb=0, name="regular_chairs")
rb = model.addVar(vtype=GRB.INTEGER, lb=0, name="regular_bookshelves")

rush_t = model.addVar(vtype=GRB.INTEGER, lb=0, name="rush_tables")
rush_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="rush_chairs")
rush_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="rush_bookshelves")

# Objective: maximize profit
# Regular items get base profit, rush items get base profit + rush bonus
obj = (profit_table * rt + profit_chair * rc + profit_bookshelf * rb +
       (profit_table + rush_bonus_table) * rush_t +
       (profit_chair + rush_bonus_chair) * rush_c +
       (profit_bookshelf + rush_bonus_bookshelf) * rush_b)

model.setObjective(obj, GRB.MAXIMIZE)

# Constraints

# Warehouse space: all items (regular + rush) share the same warehouse
model.addConstr(
    space_table * (rt + rush_t) + space_chair * (rc + rush_c) + space_bookshelf * (rb + rush_b) <= max_warehouse,
    "Warehouse_Space"
)

# Minimum production requirements (total = regular + rush)
model.addConstr(rt + rush_t >= min_tables, "Min_Tables")
model.addConstr(rb + rush_b >= min_bookshelves, "Min_Bookshelves")

# Maximum total production (all items)
model.addConstr(rt + rc + rb + rush_t + rush_c + rush_b <= max_total, "Max_Total_Items")

# Regular labor hours constraint
model.addConstr(
    labor_hours_table * rt + labor_hours_chair * rc + labor_hours_bookshelf * rb <= max_labor_regular,
    "Max_Regular_Labor"
)

# Rush labor hours constraint
model.addConstr(
    labor_hours_table * rush_t + labor_hours_chair * rush_c + labor_hours_bookshelf * rush_b <= max_labor_rush,
    "Max_Rush_Labor"
)

# Maximum rush items
model.addConstr(rush_t + rush_c + rush_b <= max_rush_items, "Max_Rush_Items")

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"Regular Tables: {int(round(rt.X))}")
    print(f"Regular Chairs: {int(round(rc.X))}")
    print(f"Regular Bookshelves: {int(round(rb.X))}")
    print(f"Rush Tables: {int(round(rush_t.X))}")
    print(f"Rush Chairs: {int(round(rush_c.X))}")
    print(f"Rush Bookshelves: {int(round(rush_b.X))}")
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print(f"Optimization ended with status {model.status}")
    print(f"FINAL_OBJ_VALUE: N/A")
