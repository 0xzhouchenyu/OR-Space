import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = row['Value'].strip()

num_students = int(params['num_students'])
num_buses = int(params['num_buses'])
bus_capacity = int(params['bus_capacity'])
num_minibuses = int(params['num_minibuses'])
minibus_capacity = int(params['minibus_capacity'])
num_drivers = int(params['num_drivers'])
bus_rental_cost = float(params['bus_rental_cost'])
minibus_rental_cost = float(params['minibus_rental_cost'])

# Create model
model = gp.Model("SchoolTrip")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVar(lb=0, ub=num_buses, vtype=GRB.INTEGER, name="buses")
y = model.addVar(lb=1, ub=num_minibuses, vtype=GRB.INTEGER, name="minibuses")

# Objective: minimize total rental cost
model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

# Constraints
# Must transport all students
model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, "StudentCapacity")

# Total vehicles (drivers) constraint
model.addConstr(x + y <= num_drivers, "DriverLimit")

# Safety policy: for every minibus, at least two buses must be rented (x >= 2*y)
model.addConstr(x >= 2 * y, "SafetyPolicy")

# At least one minibus (already enforced by lb=1, but explicit for clarity)
model.addConstr(y >= 1, "MinOneMinibus")

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"Buses: {int(x.X)}")
    print(f"Minibuses: {int(y.X)}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
