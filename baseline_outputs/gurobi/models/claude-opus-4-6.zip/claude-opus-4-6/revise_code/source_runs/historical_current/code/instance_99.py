import os
import sys
import csv

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    return rows

def load_general_parameters(filename='general_parameters.csv'):
    rows = load_csv(filename)
    params = {}
    for row in rows:
        params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_reliability_table(filename='table_1.csv'):
    rows = load_csv(filename)
    reliability = {}
    for row in rows:
        n_spares = int(row['Number_of_Spares'])
        r1 = float(row['Component_1_Reliability'])
        r2 = float(row['Component_2_Reliability'])
        r3 = float(row['Component_3_Reliability'])
        reliability[n_spares] = [r1, r2, r3]
    return reliability

def solve():
    params = load_general_parameters()
    reliability = load_reliability_table()
    
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    
    budget_A = params['total_budget_scenario_A']
    budget_B = params['total_budget_scenario_B']
    weight_A = params['weight_limit_scenario_A']
    weight_B = params['weight_limit_scenario_B']
    
    max_spares = max(reliability.keys())
    spare_options = list(range(max_spares + 1))
    
    import math
    
    # Log-transform reliabilities for linearization
    log_rel = {}
    for n in spare_options:
        log_rel[n] = []
        for c in range(3):
            r = reliability[n][c]
            if r > 0:
                log_rel[n].append(math.log(r))
            else:
                log_rel[n].append(-1e10)  # effectively -infinity
    
    # Create model
    m = gp.Model("spare_parts")
    m.setParam('OutputFlag', 0)
    
    # Binary variables: x[i][k] = 1 if component i has k spares
    x = {}
    for i in range(3):
        for k in spare_options:
            x[i, k] = m.addVar(vtype=GRB.BINARY, name=f"x_{i}_{k}")
    
    # Each component must have exactly one spare count selected
    for i in range(3):
        m.addConstr(gp.quicksum(x[i, k] for k in spare_options) == 1, name=f"one_choice_{i}")
    
    # Total cost expression
    total_cost = gp.quicksum(k * unit_price[i] * x[i, k] for i in range(3) for k in spare_options)
    
    # Total weight expression
    total_weight = gp.quicksum(k * unit_weight[i] * x[i, k] for i in range(3) for k in spare_options)
    
    # Budget constraints for both scenarios (must satisfy both)
    m.addConstr(total_cost <= budget_A, name="budget_A")
    m.addConstr(total_cost <= budget_B, name="budget_B")
    
    # Weight constraints for both scenarios
    m.addConstr(total_weight <= weight_A, name="weight_A")
    m.addConstr(total_weight <= weight_B, name="weight_B")
    
    # Objective: maximize sum of log reliabilities (equivalent to maximizing product)
    # Since both scenarios have same reliability, ExpectedReliability = 0.5*R + 0.5*R = R
    # So we just maximize R = R1 * R2 * R3, equivalently maximize log(R1) + log(R2) + log(R3)
    
    log_obj = gp.quicksum(log_rel[k][i] * x[i, k] for i in range(3) for k in spare_options)
    m.setObjective(log_obj, GRB.MAXIMIZE)
    
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        # Extract solution
        best_spares = [0, 0, 0]
        for i in range(3):
            for k in spare_options:
                if x[i, k].X > 0.5:
                    best_spares[i] = k
                    break
        
        s1, s2, s3 = best_spares
        r1 = reliability[s1][0]
        r2 = reliability[s2][1]
        r3 = reliability[s3][2]
        
        sys_rel = r1 * r2 * r3
        expected_rel = 0.5 * sys_rel + 0.5 * sys_rel  # same for both scenarios
        
        print(f"Optimal spare parts: Component 1: {s1}, Component 2: {s2}, Component 3: {s3}")
        print(f"Total cost: {s1*unit_price[0] + s2*unit_price[1] + s3*unit_price[2]}")
        print(f"Total weight: {s1*unit_weight[0] + s2*unit_weight[1] + s3*unit_weight[2]}")
        print(f"Component reliabilities: {r1}, {r2}, {r3}")
        print(f"System reliability: {sys_rel}")
        print(f"FINAL_OBJ_VALUE: {expected_rel}")
    else:
        print(f"Model status: {m.status}")
        print("FINAL_OBJ_VALUE: 0")

if __name__ == '__main__':
    solve()
