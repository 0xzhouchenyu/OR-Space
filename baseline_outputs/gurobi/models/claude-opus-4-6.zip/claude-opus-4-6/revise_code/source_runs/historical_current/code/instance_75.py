import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']
T1 = params['available_time_process_1']
T2 = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']
c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
bigM_disposal = params['bigM_disposal']
disposal_cost = params['disposal_cost_per_unit_c']
disposal_cost_high = params['disposal_cost_per_unit_c_high']
profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

# Create model
model = gp.Model("MaxProfit")
model.setParam('OutputFlag', 0)

# Decision variables
xA = model.addVar(lb=0, name="xA")  # units of product A
xB = model.addVar(lb=0, name="xB")  # units of product B
cSold = model.addVar(lb=0, name="cSold")  # units of by-product C sold
cDisposed = model.addVar(lb=0, name="cDisposed")  # total units of by-product C disposed

# Binary variables for high-throughput mode selection
# At most one reaction stage may use high-throughput
y1 = model.addVar(vtype=GRB.BINARY, name="y1")  # 1 if process 1 is in high-throughput mode
y2 = model.addVar(vtype=GRB.BINARY, name="y2")  # 1 if process 2 is in high-throughput mode

# Disposal threshold variables
# cDisposed = cDisp_base + cDisp_high
# cDisp_base <= threshold_c (if disposal exceeds threshold, base part = threshold_c)
# cDisp_high = max(0, cDisposed - threshold_c)
cDisp_base = model.addVar(lb=0, name="cDisp_base")  # disposal at base cost
cDisp_high = model.addVar(lb=0, name="cDisp_high")  # disposal at high cost

# Binary variable for whether disposal exceeds threshold
# "gate" logic: crossing threshold_c changes the cost regime
z = model.addVar(vtype=GRB.BINARY, name="z")  # 1 if cDisposed > threshold_c (i.e., above threshold)

model.update()

# Objective: maximize total profit
model.setObjective(
    profit_a * xA + profit_b * xB + profit_c * cSold
    - disposal_cost * cDisp_base - disposal_cost_high * cDisp_high,
    GRB.MAXIMIZE
)

# Constraints

# At most one reaction stage may use high-throughput mode
model.addConstr(y1 + y2 <= 1, "AtMostOneHighThroughput")

# Process 1 time constraint: capacity depends on whether high-throughput is selected
# a_p1*xA + b_p1*xB <= T1 + (T1_high - T1)*y1
model.addConstr(a_p1 * xA + b_p1 * xB <= T1 + (T1_high - T1) * y1, "Process1Time")

# Process 2 time constraint: capacity depends on whether high-throughput is selected
# a_p2*xA + b_p2*xB <= T2 + (T2_high - T2)*y2
model.addConstr(a_p2 * xA + b_p2 * xB <= T2 + (T2_high - T2) * y2, "Process2Time")

# By-product C balance
model.addConstr(cSold + cDisposed == c_per_b * xB, "ByproductBalance")

# Maximum C that can be sold
model.addConstr(cSold <= max_c_sales, "MaxCSales")

# Disposal split into base and high portions
model.addConstr(cDisp_base + cDisp_high == cDisposed, "DisposalSplit")

# cDisp_base <= threshold_c
model.addConstr(cDisp_base <= threshold_c, "BaseDisposalCap")

# Gate logic: if cDisposed <= threshold_c, then cDisp_high = 0 (all at base cost)
# if cDisposed > threshold_c, then cDisp_base = threshold_c, and cDisp_high = cDisposed - threshold_c
# Use binary z: z=1 means disposal exceeds threshold
# cDisp_high <= bigM_disposal * z
model.addConstr(cDisp_high <= bigM_disposal * z, "HighDisposalOnlyIfAboveThreshold")
# cDisp_base >= threshold_c * z (if z=1, base must be at least threshold_c, forcing it to exactly threshold_c)
model.addConstr(cDisp_base >= threshold_c * z, "BaseFullIfAboveThreshold")

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"xA = {xA.X}")
    print(f"xB = {xB.X}")
    print(f"cSold = {cSold.X}")
    print(f"cDisposed = {cDisposed.X}")
    print(f"cDisp_base = {cDisp_base.X}")
    print(f"cDisp_high = {cDisp_high.X}")
    print(f"y1 = {y1.X}")
    print(f"y2 = {y2.X}")
    print(f"z = {z.X}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Optimization ended with status {model.status}")
    print(f"FINAL_OBJ_VALUE: N/A")
