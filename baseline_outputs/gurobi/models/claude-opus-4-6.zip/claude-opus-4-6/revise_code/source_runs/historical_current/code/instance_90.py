import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
shirts_inventory = params['shirts_inventory']
pants_inventory = params['pants_inventory']

price_a = params['package_a_price']
price_b = params['package_b_price']
price_c = params['package_c_price']

shirts_a = params['package_a_shirts']
pants_a = params['package_a_pants']
shirts_b = params['package_b_shirts']
pants_b = params['package_b_pants']
shirts_c = params['package_c_shirts']
pants_c = params['package_c_pants']

min_a = params['min_campaign_batch_a']
min_b = params['min_campaign_batch_b']
min_c = params['min_campaign_batch_c']

activation_a = params['activation_cost_a']
activation_b = params['activation_cost_b']
activation_c = params['activation_cost_c']

labor_a = params['labor_hours_per_A']
labor_b = params['labor_hours_per_B']
labor_c = params['labor_hours_per_C']
labor_total = params['labor_hours_total']

bigM_a = params['bigM_a']
bigM_b = params['bigM_b']
bigM_c = params['bigM_c']

review_threshold_b = params['package_b_review_threshold']
review_charge_b = params['package_b_review_charge']
review_threshold_c = params['package_c_review_threshold']
review_charge_c = params['package_c_review_charge']

# Create model
model = gp.Model("Maximize_Revenue")
model.setParam('OutputFlag', 0)

# Decision variables
x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_a")
x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_b")
x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_c")

# Binary variables for campaign activation
y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
y_c = model.addVar(vtype=GRB.BINARY, name="y_c")

# Binary variables for review charge triggers
z_b = model.addVar(vtype=GRB.BINARY, name="z_b_review")  # 1 if x_b > threshold_b
z_c = model.addVar(vtype=GRB.BINARY, name="z_c_review")  # 1 if x_c > threshold_c

# Linking constraints: x <= bigM * y (can only sell if campaign is activated)
model.addConstr(x_a <= bigM_a * y_a, "link_a")
model.addConstr(x_b <= bigM_b * y_b, "link_b")
model.addConstr(x_c <= bigM_c * y_c, "link_c")

# Minimum batch if campaign is activated
model.addConstr(x_a >= min_a * y_a, "min_batch_a")
model.addConstr(x_b >= min_b * y_b, "min_batch_b")
model.addConstr(x_c >= min_c * y_c, "min_batch_c")

# Inventory constraints
model.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inventory, "shirts_inv")
model.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inventory, "pants_inv")

# Labor constraint
model.addConstr(labor_a * x_a + labor_b * x_b + labor_c * x_c <= labor_total, "labor")

# Review charge linking for Package B:
# z_b = 1 if x_b > review_threshold_b, i.e., x_b >= review_threshold_b + 1
# x_b >= (threshold_b + 1) * z_b  -- if z_b=1, x_b must exceed threshold
# x_b <= threshold_b + bigM_b * z_b -- if z_b=0, x_b <= threshold
model.addConstr(x_b <= review_threshold_b + bigM_b * z_b, "review_b_upper")
model.addConstr(x_b >= (review_threshold_b + 1) * z_b, "review_b_lower")

# Review charge linking for Package C:
# z_c = 1 if x_c > review_threshold_c
model.addConstr(x_c <= review_threshold_c + bigM_c * z_c, "review_c_upper")
model.addConstr(x_c >= (review_threshold_c + 1) * z_c, "review_c_lower")

# Objective: maximize revenue minus activation costs minus review charges
obj = (price_a * x_a + price_b * x_b + price_c * x_c
       - activation_a * y_a - activation_b * y_b - activation_c * y_c
       - review_charge_b * z_b - review_charge_c * z_c)

model.setObjective(obj, GRB.MAXIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"Package A: {int(round(x_a.X))}, Campaign: {int(round(y_a.X))}")
    print(f"Package B: {int(round(x_b.X))}, Campaign: {int(round(y_b.X))}")
    print(f"Package C: {int(round(x_c.X))}, Campaign: {int(round(y_c.X))}")
    print(f"Review B triggered: {int(round(z_b.X))}, Review C triggered: {int(round(z_c.X))}")
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print(f"Optimization ended with status {model.status}")
    print(f"FINAL_OBJ_VALUE: N/A")
