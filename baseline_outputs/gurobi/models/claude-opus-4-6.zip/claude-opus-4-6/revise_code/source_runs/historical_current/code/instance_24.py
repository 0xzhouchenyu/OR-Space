import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    product_units = params['product_units']
    truck_pollution = params['truck_pollution']
    van_pollution = params['van_pollution']
    motorcycle_pollution = params['motorcycle_pollution']
    ev_pollution = params['electric_vehicle_pollution']
    max_total_pollution = params['max_total_pollution']
    min_truck_trips = params['min_truck_trips']
    truck_capacity = params['truck_capacity']
    van_capacity = params['van_capacity']
    motorcycle_capacity = params['motorcycle_capacity']
    ev_capacity = params['electric_vehicle_capacity']
    
    sp_share = {
        'sp1': params['sales_point_share_sp1'],
        'sp2': params['sales_point_share_sp2'],
        'sp3': params['sales_point_share_sp3'],
    }
    
    min_truck_share = {
        'sp1': params['min_truck_share_sp1'],
        'sp2': params['min_truck_share_sp2'],
        'sp3': params['min_truck_share_sp3'],
    }
    
    M_truck = params['M_truck_sp_day']
    M_ev = params['M_ev_sp_day']
    M_van = params['M_van_sp_day']
    M_moto = params['M_moto_sp_day']
    
    sales_points = ['sp1', 'sp2', 'sp3']
    days = [1, 2, 3]
    
    # Demand per sales point
    demand = {sp: product_units * sp_share[sp] for sp in sales_points}
    
    # Create model
    model = gp.Model("Transportation_Pollution_Minimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of trips for each vehicle type per sales point per day
    x_truck = {}
    x_van = {}
    x_moto = {}
    x_ev = {}
    y = {}  # binary: 1 = truck/EV family, 0 = van/motorcycle family
    
    for sp in sales_points:
        for d in days:
            x_truck[sp, d] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"truck_{sp}_{d}")
            x_van[sp, d] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"van_{sp}_{d}")
            x_moto[sp, d] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"moto_{sp}_{d}")
            x_ev[sp, d] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"ev_{sp}_{d}")
            y[sp, d] = model.addVar(vtype=GRB.BINARY, name=f"mode_{sp}_{d}")
    
    model.update()
    
    # Objective: minimize total pollution
    total_pollution = gp.quicksum(
        truck_pollution * x_truck[sp, d] + van_pollution * x_van[sp, d] +
        motorcycle_pollution * x_moto[sp, d] + ev_pollution * x_ev[sp, d]
        for sp in sales_points for d in days
    )
    model.setObjective(total_pollution, GRB.MINIMIZE)
    
    # Constraint: mode selection per sales point per day
    # y[sp,d] = 1 => truck/EV family allowed, van/moto = 0
    # y[sp,d] = 0 => van/moto family allowed, truck/EV = 0
    for sp in sales_points:
        for d in days:
            # If y=1 (truck/EV mode): van and moto must be 0
            model.addConstr(x_van[sp, d] <= M_van * (1 - y[sp, d]),
                            name=f"van_off_{sp}_{d}")
            model.addConstr(x_moto[sp, d] <= M_moto * (1 - y[sp, d]),
                            name=f"moto_off_{sp}_{d}")
            # If y=0 (van/moto mode): truck and EV must be 0
            model.addConstr(x_truck[sp, d] <= M_truck * y[sp, d],
                            name=f"truck_off_{sp}_{d}")
            model.addConstr(x_ev[sp, d] <= M_ev * y[sp, d],
                            name=f"ev_off_{sp}_{d}")
    
    # Constraint: demand per sales point must be met (summed over days)
    for sp in sales_points:
        model.addConstr(
            gp.quicksum(
                truck_capacity * x_truck[sp, d] + van_capacity * x_van[sp, d] +
                motorcycle_capacity * x_moto[sp, d] + ev_capacity * x_ev[sp, d]
                for d in days
            ) >= demand[sp],
            name=f"demand_{sp}"
        )
    
    # Constraint: max total pollution
    model.addConstr(total_pollution <= max_total_pollution, name="max_pollution")
    
    # Constraint: minimum total truck trips across all sales points and days
    model.addConstr(
        gp.quicksum(x_truck[sp, d] for sp in sales_points for d in days) >= min_truck_trips,
        name="min_truck_trips_total"
    )
    
    # Constraint: minimum truck share per sales point
    # min_truck_share_sp means: truck_trips_sp / total_trips_sp >= min_truck_share
    # Equivalently: truck_trips_sp >= min_truck_share * total_trips_sp
    # truck_trips_sp - min_truck_share * (truck_trips_sp + van_trips_sp + moto_trips_sp + ev_trips_sp) >= 0
    for sp in sales_points:
        total_trips_sp = gp.quicksum(
            x_truck[sp, d] + x_van[sp, d] + x_moto[sp, d] + x_ev[sp, d]
            for d in days
        )
        truck_trips_sp = gp.quicksum(x_truck[sp, d] for d in days)
        model.addConstr(
            truck_trips_sp >= min_truck_share[sp] * total_trips_sp,
            name=f"min_truck_share_{sp}"
        )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        
        for sp in sales_points:
            for d in days:
                tr = x_truck[sp, d].X
                va = x_van[sp, d].X
                mo = x_moto[sp, d].X
                ev = x_ev[sp, d].X
                mode = y[sp, d].X
                if tr > 0.5 or va > 0.5 or mo > 0.5 or ev > 0.5:
                    pass  # silent
        
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
