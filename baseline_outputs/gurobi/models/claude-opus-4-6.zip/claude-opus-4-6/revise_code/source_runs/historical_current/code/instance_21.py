import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Parse general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    cost_a = float(params['cost_supplier_a'])       # 120 USD per table
    cost_b = float(params['cost_supplier_b'])       # 110 USD per table
    cost_c = float(params['cost_supplier_c'])       # 100 USD per table
    size_a = int(float(params['order_size_supplier_a']))  # 20 tables per order
    size_b = int(float(params['order_size_supplier_b']))  # 15 tables per order
    size_c = int(float(params['order_size_supplier_c']))  # 15 tables per order
    min_tables = int(float(params['min_tables_required']))  # 150
    max_tables = int(float(params['max_tables_allowed']))   # 600
    min_b_if_a = int(float(params['min_tables_supplier_b_if_a']))  # 30 tables from B if A is used
    b_requires_c = int(float(params['supplier_b_requires_c']))      # 1 (boolean)
    max_free_orders_c = int(float(params['max_free_orders_c']))  # 5
    penalty_per_extra_order_c = float(params['penalty_per_extra_order_c'])  # 600
    supplier_bc_shared_inbound_trigger = int(float(params['supplier_bc_shared_inbound_trigger']))  # 1
    supplier_bc_shared_inbound_fee = float(params['supplier_bc_shared_inbound_fee'])  # 1000
    
    M = 1000  # Big-M
    
    model = gp.Model("Restaurant_Tables")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of orders from each supplier (integer >= 0)
    x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_a")
    x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_b")
    x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_c")
    
    # Binary variables for conditional constraints
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")  # 1 if ordering from A
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")  # 1 if ordering from B
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")  # 1 if ordering from C
    
    # Variable for extra orders from C beyond the free limit
    extra_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="extra_c")
    
    # Binary variable for shared inbound desk (B and C both used)
    y_bc = model.addVar(vtype=GRB.BINARY, name="y_bc")  # 1 if both B and C are used
    
    model.update()
    
    # Objective: minimize total cost
    # cost per table * tables from each supplier + penalty for extra C orders + shared inbound fee
    obj = (cost_a * size_a * x_a + 
           cost_b * size_b * x_b + 
           cost_c * size_c * x_c +
           penalty_per_extra_order_c * extra_c +
           supplier_bc_shared_inbound_fee * y_bc)
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Total tables constraints
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c >= min_tables)
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c <= max_tables)
    
    # Link binary variables to order variables
    model.addConstr(x_a <= M * y_a)
    model.addConstr(x_a >= y_a)
    model.addConstr(x_b <= M * y_b)
    model.addConstr(x_b >= y_b)
    model.addConstr(x_c <= M * y_c)
    model.addConstr(x_c >= y_c)
    
    # If ordering from A, then tables from B >= 30
    model.addConstr(size_b * x_b >= min_b_if_a * y_a)
    
    # If ordering from B, must order from C
    if b_requires_c:
        model.addConstr(x_c >= y_b)
    
    # Supplier C penalty: extra_c captures orders beyond the free limit
    model.addConstr(extra_c >= x_c - max_free_orders_c)
    
    # Shared inbound desk: if both B and C are used, y_bc must be 1
    if supplier_bc_shared_inbound_trigger:
        model.addConstr(y_bc >= y_b + y_c - 1)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"Orders from A: {x_a.X}, Tables: {x_a.X * size_a}")
        print(f"Orders from B: {x_b.X}, Tables: {x_b.X * size_b}")
        print(f"Orders from C: {x_c.X}, Tables: {x_c.X * size_c}")
        print(f"Extra C orders (penalized): {extra_c.X}")
        print(f"Shared inbound fee active: {y_bc.X}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
