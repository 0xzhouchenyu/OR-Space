import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    a = params['a']              # hours per batch, method 1
    b = params['b']              # hours per batch, method 2
    m_offpeak = params['m_offpeak']  # cost per batch, method 1, off-peak
    n_offpeak = params['n_offpeak']  # cost per batch, method 2, off-peak
    m_peak = params['m_peak']        # cost per batch, method 1, peak
    n_peak = params['n_peak']        # cost per batch, method 2, peak
    k = params['k']              # tons per batch
    d = params['d']              # minimum production tons
    c_offpeak = params['c_offpeak']  # max off-peak hours per furnace
    c_peak = params['c_peak']        # max peak hours per furnace
    cap_offpeak = params['cap_offpeak']  # plant-wide max off-peak hours
    cap_peak = params['cap_peak']        # plant-wide max peak hours
    f_offpeak = params['f_offpeak']      # fixed activation cost, off-peak per furnace
    f_peak = params['f_peak']            # fixed activation cost, peak per furnace
    cooldown_threshold = params['offpeak_cooldown_batch_threshold']  # 2 batches
    cooldown_fee = params['offpeak_cooldown_fee']  # 20 dollars

    model = gp.Model("SteelFurnace_Revised")
    model.setParam('OutputFlag', 0)

    # Big-M for activation constraints
    # Max batches per furnace in off-peak: c_offpeak / min(a,b) = 12/2 = 6
    # Max batches per furnace in peak: c_peak / min(a,b) = 8/2 = 4
    M_offpeak = c_offpeak / min(a, b) + 1  # upper bound on batches per furnace off-peak
    M_peak = c_peak / min(a, b) + 1

    furnaces = [1, 2]

    # Decision variables:
    # x[i, method, period] = number of batches for furnace i, method j, period p
    x = {}
    for i in furnaces:
        for j in [1, 2]:
            for p in ['offpeak', 'peak']:
                x[i, j, p] = model.addVar(lb=0, vtype=GRB.CONTINUOUS,
                                           name=f"x_{i}_{j}_{p}")

    # Binary activation variables
    y_offpeak = {}
    y_peak = {}
    for i in furnaces:
        y_offpeak[i] = model.addVar(vtype=GRB.BINARY, name=f"y_offpeak_{i}")
        y_peak[i] = model.addVar(vtype=GRB.BINARY, name=f"y_peak_{i}")

    # Binary cooldown variables: z[i] = 1 if furnace i has more than threshold off-peak batches
    z = {}
    for i in furnaces:
        z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_cooldown_{i}")

    model.update()

    # Objective: minimize total fuel cost + fixed activation costs + cooldown fees
    fuel_cost = gp.LinExpr()
    for i in furnaces:
        fuel_cost += m_offpeak * x[i, 1, 'offpeak'] + n_offpeak * x[i, 2, 'offpeak']
        fuel_cost += m_peak * x[i, 1, 'peak'] + n_peak * x[i, 2, 'peak']

    activation_cost = gp.LinExpr()
    for i in furnaces:
        activation_cost += f_offpeak * y_offpeak[i] + f_peak * y_peak[i]

    cooldown_cost = gp.LinExpr()
    for i in furnaces:
        cooldown_cost += cooldown_fee * z[i]

    model.setObjective(fuel_cost + activation_cost + cooldown_cost, GRB.MINIMIZE)

    # Time constraints per furnace per period
    for i in furnaces:
        model.addConstr(a * x[i, 1, 'offpeak'] + b * x[i, 2, 'offpeak'] <= c_offpeak,
                        name=f"Furnace{i}_OffpeakTime")
        model.addConstr(a * x[i, 1, 'peak'] + b * x[i, 2, 'peak'] <= c_peak,
                        name=f"Furnace{i}_PeakTime")

    # Plant-wide time constraints
    model.addConstr(
        sum(a * x[i, 1, 'offpeak'] + b * x[i, 2, 'offpeak'] for i in furnaces) <= cap_offpeak,
        name="PlantWide_OffpeakTime")
    model.addConstr(
        sum(a * x[i, 1, 'peak'] + b * x[i, 2, 'peak'] for i in furnaces) <= cap_peak,
        name="PlantWide_PeakTime")

    # Minimum production requirement
    total_batches = sum(x[i, j, p] for i in furnaces for j in [1, 2] for p in ['offpeak', 'peak'])
    model.addConstr(k * total_batches >= d, name="MinProduction")

    # Activation constraints: if any batches in a period, activation variable must be 1
    for i in furnaces:
        offpeak_batches_i = x[i, 1, 'offpeak'] + x[i, 2, 'offpeak']
        model.addConstr(offpeak_batches_i <= M_offpeak * y_offpeak[i],
                        name=f"Activation_offpeak_{i}")
        peak_batches_i = x[i, 1, 'peak'] + x[i, 2, 'peak']
        model.addConstr(peak_batches_i <= M_peak * y_peak[i],
                        name=f"Activation_peak_{i}")

    # Cooldown constraints for off-peak:
    # If off-peak batches for furnace i > threshold, then z[i] = 1
    # offpeak_batches_i - threshold <= M * z[i]
    # Also: offpeak_batches_i - threshold >= epsilon * z[i] (to force z=0 when below)
    # But since we minimize cost, z[i] will naturally be 0 when not forced.
    # We only need: offpeak_batches_i - threshold <= M * z[i]
    # which means if offpeak_batches > threshold, z must be 1.
    # Since the fee is a cost, optimizer won't set z=1 unnecessarily.
    
    # However, the business rule says "more than 2" triggers the fee (strictly greater).
    # offpeak_batches_i > threshold => z[i] = 1
    # With continuous variables: offpeak_batches_i - threshold <= M * z[i]
    # This forces z[i]=1 when offpeak_batches_i > threshold (even slightly above).
    # When offpeak_batches_i <= threshold, z[i] can be 0.
    
    M_cool = M_offpeak  # upper bound on off-peak batches per furnace
    for i in furnaces:
        offpeak_batches_i = x[i, 1, 'offpeak'] + x[i, 2, 'offpeak']
        model.addConstr(offpeak_batches_i - cooldown_threshold <= M_cool * z[i],
                        name=f"Cooldown_trigger_{i}")

    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible")
        model.computeIIS()
        model.write("model.ilp")
    else:
        print(f"Optimization ended with status {model.status}")

if __name__ == "__main__":
    main()
