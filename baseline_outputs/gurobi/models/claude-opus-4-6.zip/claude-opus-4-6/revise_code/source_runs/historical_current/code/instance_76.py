import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
    
    # Read general_parameters.csv
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_storage = float(params['max_storage_capacity'])  # 200000 m³
    storage_cost_a = float(params['storage_cost_a'])      # 70 yuan/m³
    storage_cost_b = float(params['storage_cost_b'])      # 100 yuan/m³/quarter
    safety_inventory = float(params['safety_inventory_level_10k_m3'])  # 20 万m³
    terminal_value = float(params['terminal_inventory_value_per_10k_m3'])  # 455 万元/万m³
    over_purchase_penalty = float(params['over_purchase_penalty_cost_per_10k_m3'])  # 300 万元/万m³
    
    # Convert storage capacity to 万m³
    max_storage_wm3 = max_storage / 10000.0  # 20 万m³
    
    # Convert storage costs to 万元/万m³
    # 70 yuan/m³ = 70 万元/万m³ (since 70 yuan/m³ * 10000 m³/万m³ = 700000 yuan = 70 万元)
    storage_cost_a_w = storage_cost_a * 10000.0 / 10000.0  # = 70 万元/万m³
    storage_cost_b_w = storage_cost_b * 10000.0 / 10000.0  # = 100 万元/万m³/quarter
    
    n = len(quarters)  # 4 quarters: 0=Winter, 1=Spring, 2=Summer, 3=Autumn
    
    model = gp.Model("Timber_Profit_Maximization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables:
    # x[i,j] = amount purchased in quarter i and sold in quarter j (万m³), j >= i, j <= 3
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    # r[i] = amount purchased in quarter i destined for end-of-autumn reserve (万m³)
    # This timber is purchased but NOT sold during the year; it stays as terminal inventory
    r = {}
    for i in range(n):
        r[i] = model.addVar(lb=0, name=f"r_{i}")
    
    # Terminal inventory at end of autumn
    terminal_inv = model.addVar(lb=0, name="terminal_inv")
    
    # Excess inventory above safety level
    excess_inv = model.addVar(lb=0, name="excess_inv")
    
    model.update()
    
    # Terminal inventory = sum of all reserve purchases
    model.addConstr(terminal_inv == gp.quicksum(r[i] for i in range(n)), "terminal_inv_def")
    
    # Excess inventory above safety level
    model.addConstr(excess_inv >= terminal_inv - safety_inventory, "excess_inv_def")
    
    # Purchase constraints: total purchased in quarter i <= max_purchase[i]
    for i in range(n):
        total_purchased_i = gp.quicksum(x[i, j] for j in range(i, n)) + r[i]
        model.addConstr(total_purchased_i <= max_purchase[quarters[i]], f"purchase_cap_{i}")
    
    # Sales constraints: total sold in quarter j <= max_sales[j]
    for j in range(n):
        model.addConstr(
            gp.quicksum(x[i, j] for i in range(j + 1)) <= max_sales[quarters[j]],
            f"sales_cap_{j}"
        )
    
    # Storage constraints: at end of each quarter t (for t = 0,1,2), stored timber <= max_storage
    # Stored timber at end of quarter t = timber bought in quarters 0..t that will be sold in quarters t+1..3 or held as reserve
    for t in range(n - 1):
        stored = gp.quicksum(x[i, j] for i in range(t + 1) for j in range(t + 1, n))
        # Also add reserve timber that was purchased in quarters 0..t (it's sitting in warehouse)
        stored += gp.quicksum(r[i] for i in range(t + 1))
        model.addConstr(stored <= max_storage_wm3, f"storage_cap_{t}")
    
    # Objective: maximize profit
    # Profit from sales: (sale_price[j] - purchase_price[i] - storage_cost) * x[i,j]
    profit_terms = []
    for i in range(n):
        for j in range(i, n):
            u = j - i
            revenue = sale_price[quarters[j]]
            cost = purchase_price[quarters[i]]
            if u > 0:
                s_cost = storage_cost_a_w + storage_cost_b_w * u
            else:
                s_cost = 0
            profit_terms.append((revenue - cost - s_cost) * x[i, j])
    
    # Reserve inventory: credit at terminal value, minus purchase cost, minus storage cost for holding through year
    # Reserve timber bought in quarter i is stored from quarter i until end of autumn (quarter 3)
    # Storage time u = (3 - i) quarters if i < 3, or 0 if bought in autumn
    # But wait - reserve timber bought in autumn with u=0: does it incur storage cost?
    # Per the problem: "same-quarter turn requires no storage charge; anything carried forward picks up..."
    # Reserve timber bought in autumn is held past autumn (it's terminal inventory), so it IS carried forward.
    # But the storage cost logic is about carrying timber from one quarter to the next WITHIN the year.
    # The terminal inventory credit/penalty is the year-end consequence.
    # For reserve timber, the storage cost during the year applies for quarters it sits in warehouse.
    # If bought in winter (i=0) and held to end of autumn, it's stored for 3 quarters within the year.
    for i in range(n):
        u = n - 1 - i  # quarters stored within the year (from purchase to end of autumn)
        # Actually, reserve timber is NOT sold in autumn. It's held PAST autumn.
        # So it's stored from quarter i through the end of autumn = 4 - i quarters? 
        # No: bought at beginning of quarter i, held through end of quarter 3 (autumn).
        # That's (3 - i) quarter transitions if i < 3. If i = 3 (autumn), 0 transitions within year.
        # But it still exists at end of autumn. The within-year storage cost is for u = 3 - i quarters.
        # However, there might be an additional storage cost for holding it past autumn? 
        # The problem says terminal value and penalty handle the year-end part.
        # Within the year, storage cost for reserve follows same logic as sold timber.
        if u > 0:
            s_cost = storage_cost_a_w + storage_cost_b_w * u
        else:
            s_cost = 0
        cost = purchase_price[quarters[i]]
        # No sale revenue from reserve; instead terminal value credit
        profit_terms.append((-cost - s_cost) * r[i])
    
    # Terminal inventory value credit
    profit_terms.append(terminal_value * terminal_inv)
    
    # Over-purchase penalty for excess above safety level
    profit_terms.append(-over_purchase_penalty * excess_inv)
    
    model.setObjective(gp.quicksum(profit_terms), GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        
        for i in range(n):
            for j in range(i, n):
                val = x[i, j].X
                if val > 0.001:
                    u = j - i
                    print(f"Buy in {quarters[i]}, sell in {quarters[j]} (store {u}q): {val:.2f} 万m³")
        
        for i in range(n):
            val = r[i].X
            if val > 0.001:
                print(f"Buy in {quarters[i]} for reserve: {val:.2f} 万m³")
        
        print(f"Terminal inventory: {terminal_inv.X:.2f} 万m³")
        print(f"Excess inventory: {excess_inv.X:.2f} 万m³")
        print(f"FINAL_OBJ_VALUE: {obj_val:.1f}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
