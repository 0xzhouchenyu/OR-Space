import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    table1 = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Parse parameters
    param_dict = {}
    for row in params:
        param_dict[row['Parameter_Name']] = float(row['Value'])
    
    # Parse table1
    proc_I = table1[0]
    proc_II = table1[1]
    profit_row = table1[2]
    
    a_I = float(proc_I['Model_A_hours_per_unit'])  # 4
    b_I = float(proc_I['Model_B_hours_per_unit'])  # 6
    cap_I = float(proc_I['Maximum_Weekly_Processing_Capacity'])  # 150
    
    a_II = float(proc_II['Model_A_hours_per_unit'])  # 3
    b_II = float(proc_II['Model_B_hours_per_unit'])  # 2
    cap_II = float(proc_II['Maximum_Weekly_Processing_Capacity'])  # 70
    
    profit_A = float(profit_row['Model_A_hours_per_unit'])  # 300
    profit_B = float(profit_row['Model_B_hours_per_unit'])  # 450
    
    min_profit = param_dict['min_weekly_profit']  # 10000
    min_A = param_dict['min_model_A_units']  # 10
    min_B = param_dict['min_model_B_units']  # 15
    proc_I_hours = param_dict['process_I_hours']  # 150
    max_overtime = param_dict['process_II_max_overtime']  # 30
    red_A = param_dict['model_A_overtime_profit_reduction']  # 20
    red_B = param_dict['model_B_overtime_profit_reduction']  # 25
    
    # Build model
    m = gp.Model("Microcomputer_Production_MarketShare")
    m.setParam('OutputFlag', 0)
    
    # Decision variables: regular and overtime production for each model
    xA_r = m.addVar(lb=0, name="xA_r")  # Model A regular
    xA_o = m.addVar(lb=0, name="xA_o")  # Model A overtime
    xB_r = m.addVar(lb=0, name="xB_r")  # Model B regular
    xB_o = m.addVar(lb=0, name="xB_o")  # Model B overtime
    
    # Total production
    total_A = xA_r + xA_o
    total_B = xB_r + xB_o
    
    # Process I exact constraint: 4*(xA_r+xA_o) + 6*(xB_r+xB_o) = 150
    m.addConstr(a_I * total_A + b_I * total_B == proc_I_hours, "Process_I_exact")
    
    # Process II regular capacity: 3*xA_r + 2*xB_r <= 70
    m.addConstr(a_II * xA_r + b_II * xB_r <= cap_II, "Process_II_regular")
    
    # Process II overtime capacity: 3*xA_o + 2*xB_o <= 30
    m.addConstr(a_II * xA_o + b_II * xB_o <= max_overtime, "Process_II_overtime")
    
    # Minimum production constraints
    m.addConstr(total_A >= min_A, "Min_A")
    m.addConstr(total_B >= min_B, "Min_B")
    
    # Profit calculation: regular units get full profit, overtime units get reduced profit
    total_profit = profit_A * xA_r + profit_B * xB_r + (profit_A - red_A) * xA_o + (profit_B - red_B) * xB_o
    
    # Minimum profit constraint
    m.addConstr(total_profit >= min_profit, "Min_Profit")
    
    # REVISED OBJECTIVE: Maximize total units produced
    m.setObjective(total_A + total_B, GRB.MAXIMIZE)
    
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        obj_val = m.ObjVal
        print(f"xA_regular = {xA_r.X}")
        print(f"xA_overtime = {xA_o.X}")
        print(f"xB_regular = {xB_r.X}")
        print(f"xB_overtime = {xB_o.X}")
        print(f"Total A = {xA_r.X + xA_o.X}")
        print(f"Total B = {xB_r.X + xB_o.X}")
        print(f"Total Profit = {profit_A * xA_r.X + profit_B * xB_r.X + (profit_A - red_A) * xA_o.X + (profit_B - red_B) * xB_o.X}")
        print(f"Process II regular hours = {a_II * xA_r.X + b_II * xB_r.X}")
        print(f"Process II overtime hours = {a_II * xA_o.X + b_II * xB_o.X}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {m.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
