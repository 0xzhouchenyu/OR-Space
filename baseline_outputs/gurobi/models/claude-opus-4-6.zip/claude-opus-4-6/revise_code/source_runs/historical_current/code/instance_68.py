import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Determine paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Load distances
distances = {}
with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        yard = row['Coal_Yard'].strip()
        area = int(row['Residential_Area'].strip())
        dist = float(row['Distance_km'].strip())
        distances[(yard, area)] = dist

# Extract parameters
min_supply = {
    'A': params['min_coal_yard_A'],
    'B': params['min_coal_yard_B_adjusted']
}

demand = {
    1: params['residential_area_1_demand'],
    2: params['residential_area_2_demand'],
    3: params['residential_area_3_demand']
}

min_share_area3_from_A = params['min_share_area3_from_A']
area3_A_staging_threshold = params['area3_A_staging_threshold']
area3_A_excess_staging_cost = params['area3_A_excess_staging_cost']

coal_yards = ['A', 'B']
areas = [1, 2, 3]

# Note: B->3 route is not in table_1.csv (temporary route suspension)
# So B cannot supply area 3

# Create model
model = gp.Model("Coal_Distribution")
model.setParam('OutputFlag', 0)

# Decision variables: amount of coal shipped from yard i to area j
x = {}
for yard in coal_yards:
    for area in areas:
        if (yard, area) in distances:
            x[(yard, area)] = model.addVar(lb=0, name=f"x_{yard}_{area}")

# Variable for excess tonnage from A to Area 3 above staging threshold
# x_A_3 = x_A_3_normal + x_A_3_excess where x_A_3_normal <= threshold
x_A3_excess = model.addVar(lb=0, name="x_A3_excess")

model.update()

# Objective: minimize total transportation cost
# Normal cost: distance * amount for all routes
# Plus extra handling cost for A->3 excess above threshold
obj = gp.LinExpr()
for (yard, area), var in x.items():
    obj += distances[(yard, area)] * var
# Extra handling cost for A->3 excess
obj += area3_A_excess_staging_cost * x_A3_excess

model.setObjective(obj, GRB.MINIMIZE)

# Constraints:

# 1. Each coal yard must supply at least its minimum requirement
for yard in coal_yards:
    model.addConstr(
        gp.quicksum(x[(yard, area)] for area in areas if (yard, area) in x) >= min_supply[yard],
        name=f"Min_Supply_{yard}"
    )

# 2. Each residential area must receive exactly its demand
for area in areas:
    model.addConstr(
        gp.quicksum(x[(yard, area)] for yard in coal_yards if (yard, area) in x) == demand[area],
        name=f"Demand_{area}"
    )

# 3. Minimum share of area 3 demand from coal yard A
model.addConstr(
    x[('A', 3)] >= min_share_area3_from_A * demand[3],
    name="Min_Share_Area3_A"
)

# 4. Excess staging constraint: x_A3_excess >= x_A_3 - threshold
model.addConstr(
    x_A3_excess >= x[('A', 3)] - area3_A_staging_threshold,
    name="Staging_Excess"
)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
