import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    profit_corn = params['profit_per_acre_corn']
    profit_wheat = params['profit_per_acre_wheat']
    profit_soybeans = params['profit_per_acre_soybeans']
    profit_sorghum = params['profit_per_acre_sorghum']
    total_area = params['total_farm_area']
    corn_wheat_ratio = params['corn_wheat_ratio']
    soybeans_sorghum_ratio = params['soybeans_sorghum_ratio']
    wheat_sorghum_ratio = params['wheat_sorghum_ratio']
    
    # Create model
    model = gp.Model("Farm_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    corn = model.addVar(lb=0, name="corn")
    wheat = model.addVar(lb=0, name="wheat")
    soybeans = model.addVar(lb=0, name="soybeans")
    sorghum = model.addVar(lb=0, name="sorghum")
    
    # Binary variables for mutual exclusion: corn and soybeans cannot both be planted
    # y_corn = 1 if corn is planted, y_soy = 1 if soybeans are planted
    y_corn = model.addVar(vtype=GRB.BINARY, name="y_corn")
    y_soy = model.addVar(vtype=GRB.BINARY, name="y_soy")
    
    M = total_area  # Big-M value
    
    # Objective: maximize profit
    model.setObjective(
        profit_corn * corn + profit_wheat * wheat + profit_soybeans * soybeans + profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )
    
    # Constraints
    # Total area
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")
    
    # Corn >= 2 * wheat
    model.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio")
    
    # Soybeans >= 0.5 * sorghum
    model.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio")
    
    # Wheat = 3 * sorghum
    model.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_ratio")
    
    # Mutual exclusion: corn and soybeans cannot both be planted
    model.addConstr(y_corn + y_soy <= 1, "mutual_exclusion")
    
    # Link binary variables to continuous variables
    model.addConstr(corn <= M * y_corn, "corn_link")
    model.addConstr(soybeans <= M * y_soy, "soy_link")
    
    # Minimum 20 acres of corn (standing outlet agreement)
    model.addConstr(corn >= 20, "min_corn")
    
    # Since corn >= 20 > 0, y_corn must be 1 (this is implied but let's be explicit)
    # Actually the min_corn constraint + corn_link will force y_corn = 1
    # And mutual_exclusion will then force y_soy = 0, so soybeans = 0
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"Status: Optimal")
        print(f"Corn: {corn.X:.2f} acres")
        print(f"Wheat: {wheat.X:.2f} acres")
        print(f"Soybeans: {soybeans.X:.2f} acres")
        print(f"Sorghum: {sorghum.X:.2f} acres")
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print(f"Status: {model.status}")
        print(f"FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
