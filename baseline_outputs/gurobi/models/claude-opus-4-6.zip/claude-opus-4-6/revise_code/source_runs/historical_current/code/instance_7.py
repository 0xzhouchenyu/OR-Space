import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

# Get the data directory path
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

def load_csv_data(filepath):
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

# Load warehouse data
warehouses_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
warehouses = []
supply = {}
for row in warehouses_data:
    name = row['Warehouse']
    warehouses.append(name)
    supply[name] = int(row['Empty_Containers'])

# Load port data
ports_data = load_csv_data(os.path.join(data_dir, 'table_2.csv'))
ports = []
demand = {}
for row in ports_data:
    name = row['Port']
    ports.append(name)
    demand[name] = int(row['Container_Demand'])

# Load distance data
distance_data = load_csv_data(os.path.join(data_dir, 'table_3.csv'))
distance = {}
for row in distance_data:
    wh = row['Warehouse']
    for port in ports:
        distance[(wh, port)] = float(row[port])

# Load general parameters
params_data = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
params = {}
for row in params_data:
    params[row['Parameter_Name']] = float(row['Value'])

cost_per_km = params['cost_per_km']
truck_capacity = params['truck_capacity']
adriatic_pool_shortage_trigger = params['adriatic_pool_shortage_trigger']
adriatic_pool_recovery_fee = params['adriatic_pool_recovery_fee']

# Load shortage penalty data
shortage_data = load_csv_data(os.path.join(data_dir, 'shortage_penalty.csv'))
shortage_charge = {}
grace_containers = {}
recovery_fee = {}
for row in shortage_data:
    port = row['Port']
    shortage_charge[port] = float(row['Shortage_Charge'])
    grace_containers[port] = float(row['Grace_Containers'])
    recovery_fee[port] = float(row['Recovery_Fee'])

# Adriatic ports
adriatic_ports = ['Venice', 'Ancona', 'Bari']

# Create model
model = gp.Model("Container_Transportation")
model.setParam('OutputFlag', 0)

# Decision variables: number of trucks from warehouse i to port j (integer)
t = {}
for i in warehouses:
    for j in ports:
        t[(i, j)] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"t_{i}_{j}")

# Shortage variables for each port (continuous, >= 0)
s = {}
for j in ports:
    s[j] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"shortage_{j}")

# Binary variable: whether recovery desk is opened for each port
# Recovery desk opens when shortage > grace band
r = {}
for j in ports:
    r[j] = model.addVar(vtype=GRB.BINARY, name=f"recovery_{j}")

# Binary variable: whether Adriatic regional recovery desk is opened
r_adriatic = model.addVar(vtype=GRB.BINARY, name="recovery_adriatic")

# Adriatic combined shortage
adriatic_shortage = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="adriatic_shortage")

model.update()

# Supply constraints: total containers shipped from warehouse i <= supply[i]
for i in warehouses:
    model.addConstr(
        gp.quicksum(t[(i, j)] * truck_capacity for j in ports) <= supply[i],
        name=f"supply_{i}"
    )

# Demand/shortage constraints: containers received at port j + shortage = demand[j]
for j in ports:
    model.addConstr(
        gp.quicksum(t[(i, j)] * truck_capacity for i in warehouses) + s[j] >= demand[j],
        name=f"demand_{j}"
    )
    # Also, shortage = demand - received (but received could exceed demand, so shortage = max(0, demand - received))
    # We define s[j] = demand[j] - sum received, but s[j] >= 0
    # To ensure s[j] is exactly the shortage (not inflated), the cost structure will handle it
    # since shortage_charge > 0, optimizer will minimize s[j]
    # But we need s[j] = demand[j] - sum_received when demand > received
    # Let's add: s[j] <= demand[j] (can't have more shortage than demand)
    model.addConstr(s[j] <= demand[j], name=f"max_shortage_{j}")
    
    # Actually, let's make it exact: s[j] = demand[j] - sum_i t[i,j]*truck_capacity when positive
    # Since we minimize cost and shortage has positive cost, the optimizer will set
    # s[j] = max(0, demand[j] - sum received). But with the >= constraint above and lb=0,
    # s[j] could be larger than needed. Let's use equality with a surplus variable.
    # Better approach: received + shortage >= demand is fine because cost minimization
    # will push shortage down. But we also need shortage to be exactly right for the
    # grace band logic. Let's add received <= demand + M*(1-something)... 
    # Actually, since shortage_charge > 0, the optimizer will minimize shortage.
    # And received can exceed demand (over-delivery is allowed, just wastes supply).
    # So the constraint received + shortage >= demand with shortage >= 0 is correct.

# Recovery desk logic: if shortage > grace, recovery desk must open
# r[j] = 1 if s[j] > grace_containers[j]
# We model: s[j] - grace_containers[j] <= M * r[j]  (if shortage exceeds grace, r must be 1)
# And: s[j] <= grace_containers[j] + M * r[j]  -- this is the same
# Actually we want: if s[j] > grace_containers[j], then r[j] = 1
# Equivalently: s[j] <= grace_containers[j] + M * r[j]
# where M is big enough (e.g., max demand)
M = max(demand.values()) + 10

for j in ports:
    model.addConstr(
        s[j] <= grace_containers[j] + M * r[j],
        name=f"recovery_trigger_{j}"
    )

# Adriatic combined shortage
model.addConstr(
    adriatic_shortage == gp.quicksum(s[j] for j in adriatic_ports),
    name="adriatic_shortage_def"
)

# Adriatic regional recovery desk: opens if combined shortage > trigger
model.addConstr(
    adriatic_shortage <= adriatic_pool_shortage_trigger + M * r_adriatic,
    name="adriatic_recovery_trigger"
)

# Objective: minimize transport cost + shortage charges + recovery fees
# Transport cost: number of trucks * distance * cost_per_km
transport_cost = gp.quicksum(
    t[(i, j)] * distance[(i, j)] * cost_per_km
    for i in warehouses for j in ports
)

# Shortage charge: each uncovered container carries the port's daily disruption charge
shortage_cost = gp.quicksum(
    s[j] * shortage_charge[j] for j in ports
)

# Recovery fees: fixed cost per port if recovery desk is opened
recovery_cost = gp.quicksum(
    r[j] * recovery_fee[j] for j in ports
)

# Adriatic regional recovery fee
adriatic_recovery_cost = r_adriatic * adriatic_pool_recovery_fee

model.setObjective(
    transport_cost + shortage_cost + recovery_cost + adriatic_recovery_cost,
    GRB.MINIMIZE
)

model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
elif model.status == GRB.INFEASIBLE:
    print("Model is infeasible")
    model.computeIIS()
    model.write("model.ilp")
else:
    print(f"Optimization ended with status {model.status}")
