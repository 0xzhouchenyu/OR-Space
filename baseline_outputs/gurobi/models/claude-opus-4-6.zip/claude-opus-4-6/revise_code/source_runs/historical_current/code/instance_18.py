import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read general parameters
params = {}
filepath = os.path.join(data_dir, 'general_parameters.csv')
with open(filepath, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

weekly_production_time = params['weekly_production_time']             # 110 hours
fabric_production_rate = params['fabric_production_rate']             # 1000 meters/hour
min_curtain_fabric_sales = params['min_curtain_fabric_sales']         # 70000 meters
curtain_fabric_profit = params['curtain_fabric_profit']               # 2.5 yuan/meter
min_clothing_fabric_sales = params['min_clothing_fabric_sales']       # 45000 meters
clothing_fabric_profit = params['clothing_fabric_profit']             # 1.5 yuan/meter
day_shift_regular_capacity = params['day_shift_regular_capacity']     # 60 hours
night_shift_regular_capacity = params['night_shift_regular_capacity'] # 60 hours
day_overtime_limit = params['day_overtime_limit']                     # 3 hours
night_overtime_limit = params['night_overtime_limit']                 # 3 hours
day_overtime_penalty = params['day_overtime_penalty']                 # 1.0 yuan/hour
night_overtime_penalty = params['night_overtime_penalty']             # 1.5 yuan/hour
day_min_utilization_ratio = params['day_min_utilization_ratio']       # 0.45
night_min_utilization_ratio = params['night_min_utilization_ratio']   # 0.45

# Convert sales requirements to hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate  # 70 hours
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate  # 45 hours

# Create model
model = gp.Model("Textile_Factory_Revised")
model.setParam('OutputFlag', 0)

# Decision variables:
# Regular hours for clothing and curtain in day and night shifts
day_clothing_reg = model.addVar(lb=0, name="day_clothing_reg")
day_curtain_reg = model.addVar(lb=0, name="day_curtain_reg")
night_clothing_reg = model.addVar(lb=0, name="night_clothing_reg")
night_curtain_reg = model.addVar(lb=0, name="night_curtain_reg")

# Overtime hours for day and night shifts
day_overtime_hours = model.addVar(lb=0, ub=day_overtime_limit, name="day_overtime_hours")
night_overtime_hours = model.addVar(lb=0, ub=night_overtime_limit, name="night_overtime_hours")

# Overtime hours split by product (for tracking, overtime can be used for either product)
day_clothing_ot = model.addVar(lb=0, name="day_clothing_ot")
day_curtain_ot = model.addVar(lb=0, name="day_curtain_ot")
night_clothing_ot = model.addVar(lb=0, name="night_clothing_ot")
night_curtain_ot = model.addVar(lb=0, name="night_curtain_ot")

# Auxiliary: total regular hours in day and night
day_reg_total = model.addVar(lb=0, name="day_reg_total")
night_reg_total = model.addVar(lb=0, name="night_reg_total")

# Objective: minimize total overtime penalty cost
model.setObjective(
    day_overtime_penalty * day_overtime_hours + night_overtime_penalty * night_overtime_hours,
    GRB.MINIMIZE
)

# Day regular total
model.addConstr(day_reg_total == day_clothing_reg + day_curtain_reg, "day_reg_total_def")
# Night regular total
model.addConstr(night_reg_total == night_clothing_reg + night_curtain_reg, "night_reg_total_def")

# Regular hours capacity constraints per shift
model.addConstr(day_reg_total <= day_shift_regular_capacity, "day_reg_cap")
model.addConstr(night_reg_total <= night_shift_regular_capacity, "night_reg_cap")

# Overtime breakdown
model.addConstr(day_clothing_ot + day_curtain_ot == day_overtime_hours, "day_ot_breakdown")
model.addConstr(night_clothing_ot + night_curtain_ot == night_overtime_hours, "night_ot_breakdown")

# Total production time (regular) must equal weekly_production_time
# The weekly_production_time of 110 hours is the total regular production scheduled
model.addConstr(day_reg_total + night_reg_total == weekly_production_time, "weekly_regular_time")

# Minimum utilization ratios: fraction of total regular hours assigned to each shift
# day_reg_total >= day_min_utilization_ratio * (day_reg_total + night_reg_total)
# Since day_reg_total + night_reg_total = weekly_production_time:
model.addConstr(day_reg_total >= day_min_utilization_ratio * weekly_production_time, "day_min_util")
model.addConstr(night_reg_total >= night_min_utilization_ratio * weekly_production_time, "night_min_util")

# Meet minimum sales requirements (in hours)
# Total clothing hours (regular + overtime across both shifts) >= min_clothing_hours
model.addConstr(
    day_clothing_reg + night_clothing_reg + day_clothing_ot + night_clothing_ot >= min_clothing_hours,
    "min_clothing"
)
# Total curtain hours (regular + overtime across both shifts) >= min_curtain_hours
model.addConstr(
    day_curtain_reg + night_curtain_reg + day_curtain_ot + night_curtain_ot >= min_curtain_hours,
    "min_curtain"
)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"Status: Optimal")
    print(f"Day regular hours: {day_reg_total.X:.2f}")
    print(f"Night regular hours: {night_reg_total.X:.2f}")
    print(f"Day overtime hours: {day_overtime_hours.X:.2f}")
    print(f"Night overtime hours: {night_overtime_hours.X:.2f}")
    print(f"Day clothing reg: {day_clothing_reg.X:.2f}, Day curtain reg: {day_curtain_reg.X:.2f}")
    print(f"Night clothing reg: {night_clothing_reg.X:.2f}, Night curtain reg: {night_curtain_reg.X:.2f}")
    print(f"Day clothing OT: {day_clothing_ot.X:.2f}, Day curtain OT: {day_curtain_ot.X:.2f}")
    print(f"Night clothing OT: {night_clothing_ot.X:.2f}, Night curtain OT: {night_curtain_ot.X:.2f}")
    total_clothing = day_clothing_reg.X + night_clothing_reg.X + day_clothing_ot.X + night_clothing_ot.X
    total_curtain = day_curtain_reg.X + night_curtain_reg.X + day_curtain_ot.X + night_curtain_ot.X
    print(f"Total clothing produced: {total_clothing * fabric_production_rate:.0f} meters")
    print(f"Total curtain produced: {total_curtain * fabric_production_rate:.0f} meters")
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Status: {model.status}")
    print(f"FINAL_OBJ_VALUE: N/A")
