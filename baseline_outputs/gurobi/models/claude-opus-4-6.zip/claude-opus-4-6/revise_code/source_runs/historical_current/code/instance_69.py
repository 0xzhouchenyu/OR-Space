import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(data_path)
    
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = row['Value']
    
    q3 = int(params['batch_3m_quantity'])       # 90
    q4 = int(params['batch_4m_quantity'])       # 60
    q5 = int(params['batch_5m_quantity'])       # 40
    L = int(params['raw_bar_length'])            # 10
    setup_cost = float(params['setup_cost_per_pattern'])  # 2.5
    max_patterns = int(params['max_distinct_patterns'])    # 4
    
    len1 = 3
    len2 = 4
    len3 = 5
    
    # Generate all valid cutting patterns (a, b, c) where 3a + 4b + 5c <= L
    patterns = []
    for a in range(L // len1 + 1):
        for b in range(L // len2 + 1):
            for c in range(L // len3 + 1):
                if len1 * a + len2 * b + len3 * c <= L:
                    if a > 0 or b > 0 or c > 0:
                        patterns.append((a, b, c))
    
    P = len(patterns)
    
    # Upper bound on how many times any pattern could be used
    max_use = q3 + q4 + q5  # conservative upper bound
    
    model = gp.Model("CuttingStock_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i] = number of times pattern i is used (integer >= 0)
    x = model.addVars(P, vtype=GRB.INTEGER, lb=0, name="x")
    # y[i] = 1 if pattern i is used (binary)
    y = model.addVars(P, vtype=GRB.BINARY, name="y")
    
    # Link x and y: x[i] <= M * y[i]
    for i in range(P):
        model.addConstr(x[i] <= max_use * y[i], name=f"link_{i}")
    
    # Demand constraints
    model.addConstr(gp.quicksum(patterns[i][0] * x[i] for i in range(P)) >= q3, name="demand_3m")
    model.addConstr(gp.quicksum(patterns[i][1] * x[i] for i in range(P)) >= q4, name="demand_4m")
    model.addConstr(gp.quicksum(patterns[i][2] * x[i] for i in range(P)) >= q5, name="demand_5m")
    
    # Max distinct patterns constraint
    model.addConstr(gp.quicksum(y[i] for i in range(P)) <= max_patterns, name="max_patterns")
    
    # Objective: minimize total waste
    # Total waste = raw material used - required material + setup costs
    # Raw material used = L * sum(x[i])
    # Required material = 3*90 + 4*60 + 5*40 = 270 + 240 + 200 = 710
    # But overproduction counts as waste too (already included since we use L*x[i] - required)
    # Setup cost = setup_cost_per_pattern * number of distinct patterns used
    required = len1 * q3 + len2 * q4 + len3 * q5
    
    total_waste = (gp.quicksum(L * x[i] for i in range(P)) - required 
                   + setup_cost * gp.quicksum(y[i] for i in range(P)))
    
    model.setObjective(total_waste, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    elif model.status == GRB.INFEASIBLE:
        print("Model is infeasible")
    else:
        print(f"Optimization ended with status {model.status}")

if __name__ == "__main__":
    solve()
