import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

produce = params['produce_to_transport']
horse_poll = params['horse_pollution_per_trip']
bike_poll = params['bicycle_pollution_per_trip']
cart_poll = params['handcart_pollution_per_trip']
max_poll = params['max_total_pollution']
min_horse = params['min_horse_trips']
horse_cap = params['horse_capacity_per_trip']
bike_cap = params['bicycle_capacity_per_trip']
cart_cap = params['handcart_capacity_per_trip']
min_produce = params['min_total_produce']

horse_cost = params['horse_cost_per_trip']
bike_cost = params['bicycle_cost_per_trip']
cart_cost = params['handcart_cost_per_trip']
horse_fixed = params['horse_fixed_cost']
bike_fixed = params['bicycle_fixed_cost']
cart_fixed = params['handcart_fixed_cost']
poll_penalty = params['pollution_penalty_per_unit']
poll_threshold = params['horse_pollution_permit_threshold']
permit_fee = params['horse_pollution_permit_fee']

M = 10000

model = gp.Model("FarmTransport")
model.setParam('OutputFlag', 0)

# Decision variables
x_horse = model.addVar(vtype=GRB.INTEGER, lb=0, name="horse_trips")
x_bike = model.addVar(vtype=GRB.INTEGER, lb=0, name="bike_trips")
x_cart = model.addVar(vtype=GRB.INTEGER, lb=0, name="cart_trips")

# Binary: y=1 means bicycle chosen, y=0 means handcart chosen
y = model.addVar(vtype=GRB.BINARY, name="choose_bike")

# Binary: z=1 if horse is used (trips > 0). Since min_horse >= 8, horse is always used, but include for fixed cost
z_horse = model.addVar(vtype=GRB.BINARY, name="use_horse")

# Binary: w=1 if total pollution exceeds threshold
w = model.addVar(vtype=GRB.BINARY, name="pollution_permit")

# Total pollution
total_pollution = model.addVar(lb=0, name="total_pollution")

model.update()

# Total pollution definition
model.addConstr(total_pollution == horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart,
                "pollution_def")

# Must transport at least min_produce
model.addConstr(horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce,
                "min_produce_constr")

# Pollution constraint
model.addConstr(total_pollution <= max_poll, "max_pollution")

# Minimum horse trips
model.addConstr(x_horse >= min_horse, "min_horse_trips")

# Either bicycle or handcart, not both
model.addConstr(x_bike <= M * y, "bike_only_if_chosen")
model.addConstr(x_cart <= M * (1 - y), "cart_only_if_chosen")

# Horse usage linking (since min_horse >= 8, horse is always used, but model it correctly)
model.addConstr(x_horse <= M * z_horse, "horse_usage_upper")
model.addConstr(x_horse >= z_horse, "horse_usage_lower")

# Pollution permit threshold logic:
# If total_pollution > threshold, then w = 1
# If total_pollution <= threshold, then w = 0
# total_pollution <= threshold + M * w
# total_pollution >= threshold + epsilon - M * (1 - w)  [if pollution > threshold, w must be 1]
# Using: total_pollution - threshold <= M * w
#        total_pollution - threshold >= (1 - M * (1 - w))  -> but we need strict >
# For MIP with integer pollution values:
# total_pollution >= threshold + 1 - M*(1-w)  [forces w=1 when pollution > threshold]
# total_pollution <= threshold + M*w           [forces w=0 when pollution <= threshold]

# Since horse_poll=80 and x_horse is integer, total_pollution is a multiple of 80 (bike/cart poll=0)
# So pollution is always integer. We can use:
model.addConstr(total_pollution <= poll_threshold + M * w, "permit_trigger_upper")
model.addConstr(total_pollution >= poll_threshold + 1 - M * (1 - w), "permit_trigger_lower")

# Objective: minimize total cost
# = variable trip costs + fixed costs + pollution penalty + permit fee if applicable
# Fixed cost for horse: always used (min 8 trips), but model with z_horse
# Fixed cost for bike: if y=1
# Fixed cost for cart: if y=0... but we need a binary for "handcart is used"
# y=1 -> bike chosen, y=0 -> cart chosen
# The problem says farmer chooses one of bike/cart. If chosen, there's a fixed cost.
# But the farmer might choose bike and make 0 trips? The constraint is "choose only one"
# The fixed cost should apply if that mode is actually used (trips > 0)
# However, since horse always has min 8 trips, horse fixed cost always applies.
# For bike/cart: if y=1, bike is available. But does fixed cost apply even if 0 bike trips?
# Interpretation: fixed cost applies if the mode is used (trips > 0).

# Let's add binary for actual use of bike and cart
z_bike = model.addVar(vtype=GRB.BINARY, name="use_bike")
z_cart = model.addVar(vtype=GRB.BINARY, name="use_cart")

model.update()

model.addConstr(x_bike <= M * z_bike, "bike_use_upper")
model.addConstr(x_bike >= z_bike, "bike_use_lower")
model.addConstr(x_cart <= M * z_cart, "cart_use_upper")
model.addConstr(x_cart >= z_cart, "cart_use_lower")

# z_bike can only be 1 if y=1
model.addConstr(z_bike <= y, "bike_use_only_if_chosen")
# z_cart can only be 1 if y=0
model.addConstr(z_cart <= 1 - y, "cart_use_only_if_chosen")

# Objective
obj = (horse_cost * x_horse + bike_cost * x_bike + cart_cost * x_cart +
       horse_fixed * z_horse + bike_fixed * z_bike + cart_fixed * z_cart +
       poll_penalty * total_pollution +
       permit_fee * w)

model.setObjective(obj, GRB.MINIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"Horse trips: {x_horse.X}")
    print(f"Bicycle trips: {x_bike.X}")
    print(f"Handcart trips: {x_cart.X}")
    print(f"Choose bicycle: {y.X}")
    print(f"Total produce: {horse_cap * x_horse.X + bike_cap * x_bike.X + cart_cap * x_cart.X}")
    print(f"Total pollution: {total_pollution.X}")
    print(f"Permit needed: {w.X}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
