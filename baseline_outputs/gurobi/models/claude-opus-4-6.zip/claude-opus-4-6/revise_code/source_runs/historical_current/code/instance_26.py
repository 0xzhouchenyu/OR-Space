import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read staffing requirements
    requirements = {}
    periods_order = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row['Time_Period'].strip()
            req = int(row['Required_Salespeople'].strip())
            requirements[period] = req
            periods_order.append(period)
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    full_time_cost = float(params['full_time_cost'])
    part_time_cost = float(params['part_time_cost'])
    part_time_cap = int(params['part_time_cap_per_period'])
    min_ft_per_period = int(params['min_full_time_per_period'])
    
    periods = list(periods_order)
    req_values = [requirements[p] for p in periods]
    n = len(periods)  # 6
    
    # Create model
    model = gp.Model("MinStaffingCost")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i] = number of full-time salespeople starting shift at period i
    x = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="x")
    # p[j] = number of part-time salespeople assigned to period j
    p = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="p")
    
    # Objective: minimize total daily labor cost
    model.setObjective(
        gp.quicksum(full_time_cost * x[i] for i in range(n)) +
        gp.quicksum(part_time_cost * p[j] for j in range(n)),
        GRB.MINIMIZE
    )
    
    # Constraints
    for j in range(n):
        # Full-time present in period j: those who started in period j and period (j-1) mod n
        ft_present = x[j] + x[(j - 1) % n]
        
        # Demand coverage: full-time + part-time >= required
        model.addConstr(ft_present + p[j] >= req_values[j], name=f"demand_{j}")
        
        # Part-time cap per period
        model.addConstr(p[j] <= part_time_cap, name=f"pt_cap_{j}")
        
        # Minimum full-time per period
        model.addConstr(ft_present >= min_ft_per_period, name=f"min_ft_{j}")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        
        for i in range(n):
            print(f"Full-time shift starting at {periods[i]}: {int(round(x[i].X))} salespeople")
        for j in range(n):
            print(f"Part-time workers in {periods[j]}: {int(round(p[j].X))} salespeople")
        
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
