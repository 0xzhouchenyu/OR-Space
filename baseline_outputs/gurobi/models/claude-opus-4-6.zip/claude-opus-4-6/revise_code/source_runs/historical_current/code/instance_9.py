import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load toy data
toys = []
with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            'type': row['Toy_Type'].strip(),
            'profit': float(row['Profit_Per_Unit']),
            'wood': float(row['Wood_Required_Per_Unit']),
            'steel': float(row['Steel_Required_Per_Unit']),
        })

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'])

available_wood = params['available_wood']
available_steel = params['available_steel']
profit_premium_bonus = params['profit_premium_bonus']
premium_steel_factor = params['premium_steel_factor']
premium_shift_capacity = params['premium_shift_capacity']

toy_types = [t['type'] for t in toys]
toy_data = {t['type']: t for t in toys}

M = 10000  # Big M

# Create model
model = gp.Model("HausToys_DualShift")
model.setParam('OutputFlag', 0)

# Decision variables
# x_s[t] = quantity of toy t produced on standard shift
# x_p[t] = quantity of toy t produced on premium shift
x_s = {}
x_p = {}
# y[t] = 1 if toy type t is manufactured at all
y = {}
# z_s[t] = 1 if toy type t is assigned to standard shift
# z_p[t] = 1 if toy type t is assigned to premium shift
z_s = {}
z_p = {}

for t in toy_types:
    x_s[t] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_s_{t}")
    x_p[t] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_p_{t}")
    y[t] = model.addVar(vtype=GRB.BINARY, name=f"y_{t}")
    z_s[t] = model.addVar(vtype=GRB.BINARY, name=f"z_s_{t}")
    z_p[t] = model.addVar(vtype=GRB.BINARY, name=f"z_p_{t}")

model.update()

# Objective: maximize profit
# Standard shift: normal profit per unit
# Premium shift: normal profit + profit_premium_bonus per unit
obj = gp.LinExpr()
for t in toy_types:
    obj += toy_data[t]['profit'] * x_s[t]
    obj += (toy_data[t]['profit'] + profit_premium_bonus) * x_p[t]
model.setObjective(obj, GRB.MAXIMIZE)

# Each toy type produced must run entirely on one shift
# If manufactured (y=1), must be on exactly one shift
for t in toy_types:
    model.addConstr(z_s[t] + z_p[t] == y[t], name=f"shift_assign_{t}")

# Linking: production only if assigned to that shift
for t in toy_types:
    model.addConstr(x_s[t] <= M * z_s[t], name=f"link_std_{t}")
    model.addConstr(x_p[t] <= M * z_p[t], name=f"link_prem_{t}")

# Wood constraint: wood usage is the same regardless of shift
model.addConstr(
    gp.quicksum(toy_data[t]['wood'] * (x_s[t] + x_p[t]) for t in toy_types) <= available_wood,
    name="Wood_Constraint"
)

# Steel constraint: standard shift uses normal steel, premium uses premium_steel_factor * normal
model.addConstr(
    gp.quicksum(toy_data[t]['steel'] * x_s[t] + premium_steel_factor * toy_data[t]['steel'] * x_p[t] for t in toy_types) <= available_steel,
    name="Steel_Constraint"
)

# Premium shift capacity: total units on premium shift <= premium_shift_capacity
model.addConstr(
    gp.quicksum(x_p[t] for t in toy_types) <= premium_shift_capacity,
    name="Premium_Shift_Capacity"
)

# Truck-train exclusion: if trucks manufactured, no trains (any shift)
model.addConstr(y['truck'] + y['train'] <= 1, name="Truck_Train_Exclusion")

# Boat-airplane dependency: if boats manufactured, airplanes must be too
model.addConstr(y['boat'] <= y['airplane'], name="Boat_Airplane_Dependency")

# Boat-train limit: total boats <= total trains
model.addConstr(
    x_s['boat'] + x_p['boat'] <= x_s['train'] + x_p['train'],
    name="Boat_Train_Limit"
)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    for t in toy_types:
        std_val = x_s[t].X
        prem_val = x_p[t].X
        mfg = y[t].X
        shift_s = z_s[t].X
        shift_p = z_p[t].X
        print(f"{t}: std={std_val:.2f}, prem={prem_val:.2f}, manufacture={mfg:.0f}, shift_std={shift_s:.0f}, shift_prem={shift_p:.0f}")
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print(f"Model status: {model.status}")
    print(f"FINAL_OBJ_VALUE: N/A")
