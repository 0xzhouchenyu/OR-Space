import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

m = int(params['m'])  # production points
n = int(params['n'])  # demand points
p = int(params['p'])  # marshaling stations

a = {i: params[f'a_{i}'] for i in range(1, m+1)}  # production capacities
b = {j: params[f'b_{j}'] for j in range(1, n+1)}  # demands
f_cost = {k: params[f'f_{k}'] for k in range(1, p+1)}  # fixed costs
q = {k: params[f'q_{k}'] for k in range(1, p+1)}  # max total transshipment capacity
qexp = {k: params[f'qexp_{k}'] for k in range(1, p+1)}  # max express transshipment capacity
alpha = {j: params[f'alpha_{j}'] for j in range(1, n+1)}  # minimum express fraction
eps_val = params['eps']  # minimum strictly positive express flow
M_val = params['M']  # Big-M

# Load transportation costs from production to marshaling stations (regular and express)
cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row['i'])
        k = int(row['k'])
        cR_ik[(i, k)] = float(row['cR_ik'])
        cE_ik[(i, k)] = float(row['cE_ik'])

# Load transportation costs from marshaling stations to demand points (regular and express)
cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, 'table_2.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row['k'])
        j = int(row['j'])
        cR_kj[(k, j)] = float(row['cR_kj'])
        cE_kj[(k, j)] = float(row['cE_kj'])

# Create the optimization model
model = gp.Model("Revised_Transportation_Problem")
model.setParam('OutputFlag', 0)

# Decision variables
# xR_ik: regular amount shipped from production point i to marshaling station k
xR = {}
xE = {}
for i in range(1, m+1):
    for k in range(1, p+1):
        xR[(i, k)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"xR_{i}_{k}")
        xE[(i, k)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"xE_{i}_{k}")

# yR_kj: regular amount shipped from marshaling station k to demand point j
# yE_kj: express amount shipped from marshaling station k to demand point j
yR = {}
yE = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        yR[(k, j)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"yR_{k}_{j}")
        yE[(k, j)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"yE_{k}_{j}")

# z_k: binary variable indicating whether marshaling station k is used
z = {}
for k in range(1, p+1):
    z[k] = model.addVar(vtype=GRB.BINARY, name=f"z_{k}")

# w_kj: binary indicator that express flow yE_kj > 0 (used for diversification)
w = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        w[(k, j)] = model.addVar(vtype=GRB.BINARY, name=f"w_{k}_{j}")

model.update()

# Objective: minimize total transportation cost + fixed costs
obj = gp.LinExpr()
for i in range(1, m+1):
    for k in range(1, p+1):
        obj += cR_ik[(i, k)] * xR[(i, k)] + cE_ik[(i, k)] * xE[(i, k)]
for k in range(1, p+1):
    for j in range(1, n+1):
        obj += cR_kj[(k, j)] * yR[(k, j)] + cE_kj[(k, j)] * yE[(k, j)]
for k in range(1, p+1):
    obj += f_cost[k] * z[k]

model.setObjective(obj, GRB.MINIMIZE)

# Constraints

# 1. Supply constraints: total shipped from production point i <= a_i
for i in range(1, m+1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for k in range(1, p+1)) <= a[i],
        name=f"Supply_{i}"
    )

# 2. Demand constraints: total received at demand point j >= b_j
for j in range(1, n+1):
    model.addConstr(
        gp.quicksum(yR[(k, j)] + yE[(k, j)] for k in range(1, p+1)) >= b[j],
        name=f"Demand_{j}"
    )

# 3. Flow conservation at marshaling stations - regular mode
for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] for i in range(1, m+1)) == gp.quicksum(yR[(k, j)] for j in range(1, n+1)),
        name=f"FlowBalanceR_{k}"
    )

# 3b. Flow conservation at marshaling stations - express mode
for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xE[(i, k)] for i in range(1, m+1)) == gp.quicksum(yE[(k, j)] for j in range(1, n+1)),
        name=f"FlowBalanceE_{k}"
    )

# 4. Total capacity constraints at marshaling stations (linked with z_k)
for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for i in range(1, m+1)) <= q[k] * z[k],
        name=f"TotalCapacity_{k}"
    )

# 5. Express capacity constraints at marshaling stations
for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xE[(i, k)] for i in range(1, m+1)) <= qexp[k],
        name=f"ExpressCapacity_{k}"
    )

# 6. Linking w_kj to yE_kj: w_kj = 1 iff yE_kj > 0
# yE_kj >= eps * w_kj  (if w=1, then yE >= eps)
# yE_kj <= M * w_kj    (if w=0, then yE = 0)
for k in range(1, p+1):
    for j in range(1, n+1):
        model.addConstr(yE[(k, j)] >= eps_val * w[(k, j)], name=f"wLink_lb_{k}_{j}")
        model.addConstr(yE[(k, j)] <= M_val * w[(k, j)], name=f"wLink_ub_{k}_{j}")

# 7. Diversification constraint: for demand points served by more than one open station,
#    the express share must be at least alpha_j, enforced across at least two station links.
#
# Interpretation: if demand point j has more than one open station (i.e., sum_k z_k >= 2 
# AND the station actually serves j), then:
#   sum_k yE_kj >= alpha_j * b_j  (minimum express fraction)
#   sum_k w_kj >= 2               (express from at least 2 stations)
#
# We use a conditional: let s_j = number of open stations serving j.
# If sum_k z_k >= 2 (more than one station open), then diversification applies.
# We model this with auxiliary binary d_j = 1 if diversification required for j.

# d_j: binary, 1 if demand point j has diversification requirement
d = {}
for j in range(1, n+1):
    d[j] = model.addVar(vtype=GRB.BINARY, name=f"d_{j}")

model.update()

# d_j = 1 if sum_k z_k >= 2
# sum_k z_k >= 2 * d_j  => if d_j=1 then at least 2 stations open
# sum_k z_k <= 1 + (p-1)*d_j => if d_j=0 then at most 1 station open
for j in range(1, n+1):
    model.addConstr(
        gp.quicksum(z[k] for k in range(1, p+1)) >= 2 * d[j],
        name=f"Diversify_lb_{j}"
    )
    model.addConstr(
        gp.quicksum(z[k] for k in range(1, p+1)) <= 1 + (p - 1) * d[j],
        name=f"Diversify_ub_{j}"
    )

# If d_j = 1: express fraction >= alpha_j and at least 2 express sources
for j in range(1, n+1):
    # sum_k yE_kj >= alpha_j * b_j * d_j
    model.addConstr(
        gp.quicksum(yE[(k, j)] for k in range(1, p+1)) >= alpha[j] * b[j] * d[j],
        name=f"ExpressFraction_{j}"
    )
    # sum_k w_kj >= 2 * d_j
    model.addConstr(
        gp.quicksum(w[(k, j)] for k in range(1, p+1)) >= 2 * d[j],
        name=f"ExpressDiversity_{j}"
    )

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
elif model.status == GRB.INFEASIBLE:
    print("Model is infeasible")
    model.computeIIS()
    model.write("model.ilp")
    print("FINAL_OBJ_VALUE: INFEASIBLE")
else:
    print(f"Optimization ended with status {model.status}")
    print(f"FINAL_OBJ_VALUE: {model.ObjVal if model.SolCount > 0 else 'N/A'}")
