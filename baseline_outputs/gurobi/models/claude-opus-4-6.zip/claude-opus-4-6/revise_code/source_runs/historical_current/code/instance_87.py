import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    base_a = params['base_fleet_type_a']
    base_b = params['base_fleet_type_b']
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    type_b_threshold = params['type_b_recovery_threshold']
    type_b_fee = params['type_b_recovery_fee']
    total_threshold = params['total_fleet_surge_threshold']
    total_fee = params['total_fleet_surge_fee']

    M = 10000  # Big-M

    model = gp.Model("TruckRental")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeA_trucks")
    y = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeB_trucks")

    # Excess over base fleet
    excess_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="excess_a")
    excess_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="excess_b")

    # Binary for Type B recovery threshold
    z_b = model.addVar(vtype=GRB.BINARY, name="z_type_b_recovery")

    # Binary for total fleet surge threshold
    z_total = model.addVar(vtype=GRB.BINARY, name="z_total_surge")

    # Constraints: capacity requirements
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedRequirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedRequirement")

    # Excess over base fleet constraints
    model.addConstr(excess_a >= x - base_a, "ExcessA")
    model.addConstr(excess_b >= y - base_b, "ExcessB")

    # Type B recovery threshold: z_b = 1 if y > type_b_threshold
    # y - type_b_threshold <= M * z_b  (if y <= threshold, z_b can be 0)
    # y - type_b_threshold >= 1 - M*(1 - z_b)  (if z_b = 1, y > threshold)
    # But we want: z_b = 1 iff y > type_b_threshold (i.e., y >= type_b_threshold + 1 since integer)
    model.addConstr(y - type_b_threshold <= M * z_b, "TypeB_recovery_activate")
    model.addConstr(y - type_b_threshold >= (1) - M * (1 - z_b), "TypeB_recovery_force")

    # Total fleet surge threshold: z_total = 1 if x + y > total_threshold
    model.addConstr(x + y - total_threshold <= M * z_total, "Total_surge_activate")
    model.addConstr(x + y - total_threshold >= (1) - M * (1 - z_total), "Total_surge_force")

    # Objective: minimize total cost
    # Base rental costs + penalty for excess + conditional fees
    obj = (cost_a * x + cost_b * y +
           penalty_a * excess_a + penalty_b * excess_b +
           type_b_fee * z_b +
           total_fee * z_total)

    model.setObjective(obj, GRB.MINIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"Type A trucks: {int(round(x.X))}")
        print(f"Type B trucks: {int(round(y.X))}")
        print(f"Excess A: {int(round(excess_a.X))}")
        print(f"Excess B: {int(round(excess_b.X))}")
        print(f"Type B recovery triggered: {int(round(z_b.X))}")
        print(f"Total surge triggered: {int(round(z_total.X))}")
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
