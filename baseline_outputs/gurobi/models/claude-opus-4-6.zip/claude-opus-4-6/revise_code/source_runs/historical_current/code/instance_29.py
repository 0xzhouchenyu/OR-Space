import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load data
    demand_df = pd.read_csv(os.path.join(base_dir, "data", "table_4_3.csv"))
    supply_df = pd.read_csv(os.path.join(base_dir, "data", "table_4_4.csv"))
    params_df = pd.read_csv(os.path.join(base_dir, "data", "general_parameters.csv"))
    
    # Parse parameters
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])
    
    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem
    
    # Parse supply
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = float(row['Number_of_People'])
        suit = [int(x.strip()) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }
    
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]
    
    # Build model
    model = gp.Model("revised_staffing")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i,j,k] = number of type i people assigned to city j, specialty k
    x = {}
    for i in types:
        for j in cities:
            for k in specs:
                if k in supply[i]['suit']:
                    x[i, j, k] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{i}_{j}_{k}")
                else:
                    x[i, j, k] = model.addVar(lb=0, ub=0, vtype=GRB.INTEGER, name=f"x_{i}_{j}_{k}")
    
    model.update()
    
    # Constraint: Supply limit for each type
    for i in types:
        model.addConstr(
            gp.quicksum(x[i, j, k] for j in cities for k in specs) <= supply[i]['num'],
            name=f"supply_{i}"
        )
    
    # Constraint: Demand must be met (Priority 1 - hard constraint)
    for j in cities:
        for k in specs:
            model.addConstr(
                gp.quicksum(x[i, j, k] for i in types) >= demand[(j, k)],
                name=f"demand_{j}_{k}"
            )
    
    # Constraint: Priority 2 - at least p2_target people meet their preferred specialty (hard constraint)
    p2_expr = gp.quicksum(
        x[i, j, supply[i]['pref_spec']] 
        for i in types 
        for j in cities
    )
    model.addConstr(p2_expr >= p2_target, name="priority_2")
    
    # Objective: Maximize number of recruits who simultaneously get preferred specialty AND preferred city
    # A person of type i gets both preferences if assigned to (pref_city, pref_spec)
    dual_match_expr = gp.quicksum(
        x[i, supply[i]['pref_city'], supply[i]['pref_spec']]
        for i in types
    )
    
    model.setObjective(dual_match_expr, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {int(round(obj_val))}")
    else:
        print(f"FINAL_OBJ_VALUE: No optimal solution found, status={model.status}")

if __name__ == '__main__':
    solve()
