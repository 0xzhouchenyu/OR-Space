import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    filepath = os.path.join(data_dir, 'table_1.csv')
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in ['Product_I', 'Product_II', 'Product_III']:
                val = row[p].strip() if row[p].strip() else None
                proc_times[e][p] = float(val) if val else None
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())
    
    # Load general_parameters.csv
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    raw_costs = {}
    prices = {}
    labor_coeff = {}
    shared_labor_hours = None
    b2_activation_fee = None
    
    mapping_raw = {
        'raw_material_cost_product_I': 'Product_I',
        'raw_material_cost_product_II': 'Product_II',
        'raw_material_cost_product_III': 'Product_III',
    }
    mapping_price = {
        'unit_price_product_I': 'Product_I',
        'unit_price_product_II': 'Product_II',
        'unit_price_product_III': 'Product_III',
    }
    labor_coeff_mapping = {
        'labor_coeff_A1': 'A1',
        'labor_coeff_A2': 'A2',
        'labor_coeff_B1': 'B1',
        'labor_coeff_B2': 'B2',
        'labor_coeff_B3': 'B3',
    }
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            if name in mapping_raw:
                raw_costs[mapping_raw[name]] = val
            if name in mapping_price:
                prices[mapping_price[name]] = val
            if name in labor_coeff_mapping:
                labor_coeff[labor_coeff_mapping[name]] = val
            if name == 'shared_labor_hours':
                shared_labor_hours = val
            if name == 'b2_activation_fee':
                b2_activation_fee = val
    
    products = ['Product_I', 'Product_II', 'Product_III']
    A_equip = [e for e in equipment if e.startswith('A')]
    B_equip = [e for e in equipment if e.startswith('B')]
    
    model = gp.Model("Factory_Production")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[e][p] = number of units of product p processed on equipment e
    x = {}
    for e in equipment:
        x[e] = {}
        for p in products:
            if proc_times[e][p] is not None:
                x[e][p] = model.addVar(lb=0, name=f"x_{e}_{p}")
    
    # Binary variable for B2 activation
    y_b2 = model.addVar(vtype=GRB.BINARY, name="y_b2")
    
    model.update()
    
    # Machine hours used by each equipment
    machine_hours_used = {}
    for e in equipment:
        machine_hours_used[e] = gp.quicksum(
            x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None
        )
    
    # Capacity constraints
    for e in equipment:
        model.addConstr(machine_hours_used[e] <= eff_hours[e], name=f"capacity_{e}")
    
    # Flow balance: for each product, total A-processed = total B-processed
    for p in products:
        a_sum = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
        b_sum = gp.quicksum(x[e][p] for e in B_equip if proc_times[e][p] is not None)
        model.addConstr(a_sum == b_sum, name=f"balance_{p}")
    
    # Shared labor hours constraint
    labor_usage = gp.quicksum(
        labor_coeff[e] * machine_hours_used[e] for e in equipment
    )
    model.addConstr(labor_usage <= shared_labor_hours, name="shared_labor")
    
    # B2 activation: if any production on B2, y_b2 must be 1
    # Link: machine_hours_used[B2] <= eff_hours[B2] * y_b2
    model.addConstr(machine_hours_used['B2'] <= eff_hours['B2'] * y_b2, name="b2_activation_link")
    
    # Total production of each product (from A side)
    total_prod = {}
    for p in products:
        total_prod[p] = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
    
    # Revenue
    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)
    
    # Raw material costs
    raw_cost_total = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)
    
    # Operating costs: proportional to usage fraction
    operating_cost = gp.quicksum(
        op_costs[e] * machine_hours_used[e] / eff_hours[e] for e in equipment
    )
    
    # B2 activation fee
    activation_cost = b2_activation_fee * y_b2
    
    # Objective: maximize profit
    model.setObjective(revenue - raw_cost_total - operating_cost - activation_cost, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        for e in equipment:
            for p in products:
                if proc_times[e][p] is not None:
                    val = x[e][p].X
                    if val > 1e-6:
                        print(f"  {e} -> {p}: {val:.4f} units")
        if y_b2.X > 0.5:
            print("  B2 is activated (fee applied)")
        print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    main()
