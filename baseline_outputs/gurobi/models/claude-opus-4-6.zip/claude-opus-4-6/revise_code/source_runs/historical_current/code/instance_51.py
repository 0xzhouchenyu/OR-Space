import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load demand
demand = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        demand.append(int(row['Required_Nurses']))

# Load parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = row['Value']

shift_duration = int(params['shift_duration'])  # 8 hours
regular_pay = float(params['regular_nurse_pay'])  # 10 yuan/hour
contract_pay = float(params['contract_nurse_pay'])  # 15 yuan/hour
outsourced_regular_start_index = int(params['outsourced_regular_start_index'])  # 2 (10:00 shift)
banned_contract_start_index = int(params['banned_contract_start_index'])  # 5 (22:00 shift)
max_total_contract_starts = int(params['max_total_contract_starts'])  # 20
min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])  # 8
daytime_period_indices = [int(x) for x in params['daytime_period_indices'].split(';')]  # [1,2,3,4]

num_periods = len(demand)  # 6 periods, each 4 hours
periods_per_shift = shift_duration // 4  # 2 periods per shift

# Create model
model = gp.Model("NurseScheduling")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}  # regular nurses starting at shift j
y = {}  # contract nurses starting at shift j

for j in range(num_periods):
    x[j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{j}")
    y[j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"y_{j}")

model.update()

# Constraint: Regular nurses cannot start the outsourced shift (index 2, i.e., 10:00)
model.addConstr(x[outsourced_regular_start_index] == 0, "no_regular_at_outsourced")

# Constraint: Contract nurses cannot start the overnight shift (index 5, i.e., 22:00)
model.addConstr(y[banned_contract_start_index] == 0, "no_contract_at_overnight")

# Constraint: Total contract starts capped
model.addConstr(gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts, "max_contract_starts")

# Coverage constraints: for each time period i, sum of nurses from shifts that cover period i >= demand[i]
# Shift j covers periods j and (j+1) % num_periods
for i in range(num_periods):
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(
        gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i],
        f"Demand_period_{i}"
    )

# Constraint: Minimum regular nurses covering each daytime period
# Daytime periods: indices 1,2,3,4 (6:00-10:00, 10:00-14:00, 14:00-18:00, 18:00-22:00)
for i in daytime_period_indices:
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(
        gp.quicksum(x[j] for j in covering_shifts) >= min_regular_daytime_coverage,
        f"Min_regular_daytime_{i}"
    )

# Objective: minimize total cost
cost = gp.quicksum(
    (regular_pay * shift_duration) * x[j] + (contract_pay * shift_duration) * y[j]
    for j in range(num_periods)
)
model.setObjective(cost, GRB.MINIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    total_cost = model.objVal
    for j in range(num_periods):
        print(f"Shift {j}: Regular={int(x[j].X)}, Contract={int(y[j].X)}")
    print(f"FINAL_OBJ_VALUE: {total_cost}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: N/A")
