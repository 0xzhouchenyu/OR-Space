import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

# Extract parameters
min_A_I = params['min_proportion_crude_A_type_I'] / 100.0  # 0.50
min_A_II = params['min_proportion_crude_A_type_II'] / 100.0  # 0.60
price_I = params['selling_price_type_I']  # 4800
price_II = params['selling_price_type_II']  # 5600
inv_A = params['inventory_crude_A']  # 500
inv_B = params['inventory_crude_B']  # 1000
max_purchase_A = params['max_purchase_crude_A']  # 1500
cost_tier1 = params['market_price_crude_A_tier_1']  # 10000
cost_tier2 = params['market_price_crude_A_tier_2']  # 8000
cost_tier3 = params['market_price_crude_A_tier_3']  # 6000
processing_capacity = params['processing_capacity']  # 2500
min_total_output = params['min_total_gasoline_output']  # 1500
processing_cost = params['processing_cost_per_ton']  # 500
type_II_threshold = params['type_II_contract_threshold']  # 900
type_II_lift = params['type_II_price_lift']  # 300
bulk_rebate_threshold = params['bulk_purchase_rebate_threshold']  # 1000
bulk_rebate = params['bulk_purchase_rebate']  # 200000

M_big = 10000  # Big-M constant

model = gp.Model("Oil_Blending_Revised")
model.setParam('OutputFlag', 0)

# Decision variables: crude allocation
a1 = model.addVar(lb=0, name="crude_A_in_I")
a2 = model.addVar(lb=0, name="crude_A_in_II")
b1 = model.addVar(lb=0, name="crude_B_in_I")
b2 = model.addVar(lb=0, name="crude_B_in_II")

# Tiered purchase variables for crude A
p1 = model.addVar(lb=0, ub=500, name="purchase_tier1")
p2 = model.addVar(lb=0, ub=500, name="purchase_tier2")
p3 = model.addVar(lb=0, ub=500, name="purchase_tier3")

# Binary variables for tiered ordering
y1 = model.addVar(vtype=GRB.BINARY, name="y1")  # 1 if tier1 fully used
y2 = model.addVar(vtype=GRB.BINARY, name="y2")  # 1 if tier2 fully used

# Binary variable for Type II price lift
z_typeII = model.addVar(vtype=GRB.BINARY, name="z_typeII")  # 1 if Type II output >= threshold

# Binary variable for bulk purchase rebate
z_bulk = model.addVar(vtype=GRB.BINARY, name="z_bulk")  # 1 if total purchase >= bulk threshold

# Tiered ordering constraints
model.addConstr(p1 <= 500)
model.addConstr(p2 <= 500 * y1)
model.addConstr(p3 <= 500 * y2)
model.addConstr(p1 >= 500 * y1)
model.addConstr(p2 >= 500 * y2)

# Total purchased
total_purchased = p1 + p2 + p3

# Supply constraints
model.addConstr(a1 + a2 <= inv_A + total_purchased, "crude_A_supply")
model.addConstr(b1 + b2 <= inv_B, "crude_B_supply")

# Blending constraints
# a1 >= min_A_I * (a1 + b1) => (1 - min_A_I)*a1 >= min_A_I * b1
model.addConstr(a1 >= min_A_I * (a1 + b1), "blend_I")
# a2 >= min_A_II * (a2 + b2)
model.addConstr(a2 >= min_A_II * (a2 + b2), "blend_II")

# Total gasoline output
total_output = a1 + b1 + a2 + b2
type_I_output = a1 + b1
type_II_output = a2 + b2

# Throughput window constraints
model.addConstr(total_output <= processing_capacity, "max_capacity")
model.addConstr(total_output >= min_total_output, "min_output")

# Type II contract threshold: z_typeII = 1 iff type_II_output >= type_II_threshold
# type_II_output >= type_II_threshold - M*(1 - z_typeII)
# type_II_output <= type_II_threshold - epsilon + M*z_typeII
model.addConstr(type_II_output >= type_II_threshold - M_big * (1 - z_typeII), "typeII_thresh_lb")
model.addConstr(type_II_output <= type_II_threshold - 0.001 + M_big * z_typeII, "typeII_thresh_ub")

# Bulk purchase rebate threshold: z_bulk = 1 iff total_purchased >= bulk_rebate_threshold
model.addConstr(total_purchased >= bulk_rebate_threshold - M_big * (1 - z_bulk), "bulk_thresh_lb")
model.addConstr(total_purchased <= bulk_rebate_threshold - 0.001 + M_big * z_bulk, "bulk_thresh_ub")

# Objective: Revenue - Purchase Cost - Processing Cost + conditional lift + conditional rebate
revenue = price_I * type_I_output + price_II * type_II_output
purchase_cost = cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3
proc_cost = processing_cost * total_output
type_II_bonus = type_II_lift * type_II_output * z_typeII  # nonlinear, need linearization

# Linearize type_II_lift * type_II_output * z_typeII
# Let w = type_II_output * z_typeII
# w <= type_II_output, w <= M * z_typeII, w >= type_II_output - M*(1-z_typeII), w >= 0
w_typeII = model.addVar(lb=0, name="w_typeII")
M_output = processing_capacity  # upper bound on type_II_output
model.addConstr(w_typeII <= type_II_output, "lin_w1")
model.addConstr(w_typeII <= M_output * z_typeII, "lin_w2")
model.addConstr(w_typeII >= type_II_output - M_output * (1 - z_typeII), "lin_w3")

objective = revenue + type_II_lift * w_typeII - purchase_cost - proc_cost + bulk_rebate * z_bulk

model.setObjective(objective, GRB.MAXIMIZE)
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
elif model.status == GRB.INFEASIBLE:
    print("Model is infeasible")
    model.computeIIS()
    print("FINAL_OBJ_VALUE: infeasible")
else:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
