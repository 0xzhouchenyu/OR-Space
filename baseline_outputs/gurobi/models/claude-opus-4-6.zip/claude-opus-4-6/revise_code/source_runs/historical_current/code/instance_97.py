import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read table_1.csv
    materials = []
    sulfur_content = {}
    purchase_price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            mat = row['Material'].strip()
            materials.append(mat)
            for key in row:
                if 'Sulfur_Content_Percentage' in key:
                    sulfur_content[mat] = float(row[key].strip())
                if 'Purchase_Price' in key:
                    purchase_price[mat] = float(row[key].strip())
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            for key in row:
                if 'Value' in key and key.strip() != 'Parameter_Name':
                    val = float(row[key].strip())
                    params[param_name] = val
                    break
    
    max_sulfur_A_prem = params['max_sulfur_content_A_premium']
    max_sulfur_A_std = params['max_sulfur_content_A_standard']
    max_sulfur_B_prem = params['max_sulfur_content_B_premium']
    max_sulfur_B_std = params['max_sulfur_content_B_standard']
    
    price_A_prem = params['selling_price_A_premium']
    price_A_std = params['selling_price_A_standard']
    price_B_prem = params['selling_price_B_premium']
    price_B_std = params['selling_price_B_standard']
    
    max_supply_D = params['max_supply_D']
    demand_A = params['market_demand_A']
    demand_B = params['market_demand_B']
    
    min_prem_A = params['min_premium_share_A']
    max_prem_A = params['max_premium_share_A']
    min_prem_B = params['min_premium_share_B']
    max_prem_B = params['max_premium_share_B']
    
    # Four streams
    streams = ['A_prem', 'A_std', 'B_prem', 'B_std']
    
    selling_price = {
        'A_prem': price_A_prem,
        'A_std': price_A_std,
        'B_prem': price_B_prem,
        'B_std': price_B_std
    }
    
    max_sulfur = {
        'A_prem': max_sulfur_A_prem,
        'A_std': max_sulfur_A_std,
        'B_prem': max_sulfur_B_prem,
        'B_std': max_sulfur_B_std
    }
    
    # Model
    model = gp.Model("Tiered_Mixing")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[m, s] = tons of material m used in stream s
    x = {}
    for m in materials:
        for s in streams:
            x[m, s] = model.addVar(lb=0, name=f"x_{m}_{s}")
    
    model.update()
    
    # Total tons in each stream
    total = {}
    for s in streams:
        total[s] = gp.quicksum(x[m, s] for m in materials)
    
    # Objective: maximize revenue - cost
    revenue = gp.quicksum(selling_price[s] * total[s] for s in streams)
    cost = gp.quicksum(purchase_price[m] * gp.quicksum(x[m, s] for s in streams) for m in materials)
    model.setObjective(revenue - cost, GRB.MAXIMIZE)
    
    # Sulfur constraints for each stream:
    # sum(sulfur[m] * x[m,s]) <= max_sulfur[s] * sum(x[m,s])
    for s in streams:
        model.addConstr(
            gp.quicksum(sulfur_content[m] * x[m, s] for m in materials) <= max_sulfur[s] * total[s],
            name=f"Sulfur_{s}"
        )
    
    # Supply limit for material D
    model.addConstr(
        gp.quicksum(x['D', s] for s in streams) <= max_supply_D,
        name="Supply_D"
    )
    
    # Market demand constraints (family level)
    model.addConstr(total['A_prem'] + total['A_std'] <= demand_A, name="Demand_A")
    model.addConstr(total['B_prem'] + total['B_std'] <= demand_B, name="Demand_B")
    
    # Premium share constraints for family A
    model.addConstr(total['A_prem'] >= min_prem_A, name="Min_Prem_A")
    model.addConstr(total['A_prem'] <= max_prem_A, name="Max_Prem_A")
    
    # Premium share constraints for family B
    model.addConstr(total['B_prem'] >= min_prem_B, name="Min_Prem_B")
    model.addConstr(total['B_prem'] <= max_prem_B, name="Max_Prem_B")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: {None}")

if __name__ == "__main__":
    main()
