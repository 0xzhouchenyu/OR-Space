from gurobi_execution_record import install_gurobi_objective_recorder
install_gurobi_objective_recorder('Advanced_2')

import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

a1 = params['a1']  # 10 - jets produced in year 1
a2 = params['a2']  # 15 - jets produced in year 2
training_capacity = params['training_capacity_per_jet']  # 5
training_duration = params['training_duration']  # 2
dual_eff = params['dual_use_training_efficiency']  # 0.6
intensity_cap = params['training_intensity_cap']  # 0.8
combat_min_y2 = params['combat_jet_min_year2']  # 8
combat_weight = params['combat_weight']  # 2
training_weight = params['training_weight']  # 1

# Model
m = gp.Model("fighter_jet_training")
m.setParam('OutputFlag', 0)

# Decision variables for year 1:
# Jets available in year 1: a1
# Each jet is assigned to: training-only (t1), combat-only (c1), or dual-use (d1)
t1 = m.addVar(lb=0, name="training_year1")
c1 = m.addVar(lb=0, name="combat_year1")
d1 = m.addVar(lb=0, name="dual_year1")

# Decision variables for year 2:
# Jets available in year 2: a1 + a2 (cumulative fleet)
t2 = m.addVar(lb=0, name="training_year2")
c2 = m.addVar(lb=0, name="combat_year2")
d2 = m.addVar(lb=0, name="dual_year2")

# Fleet availability constraints
# Year 1: only a1 jets available
m.addConstr(t1 + c1 + d1 == a1, "fleet_year1")

# Year 2: a1 + a2 jets available (all jets produced through year 2)
m.addConstr(t2 + c2 + d2 == a1 + a2, "fleet_year2")

# Training intensity cap: fraction of fleet in training-only or dual-use <= intensity_cap
# Year 1: (t1 + d1) / a1 <= intensity_cap
m.addConstr(t1 + d1 <= intensity_cap * a1, "intensity_cap_year1")

# Year 2: (t2 + d2) / (a1 + a2) <= intensity_cap
m.addConstr(t2 + d2 <= intensity_cap * (a1 + a2), "intensity_cap_year2")

# Minimum combat jets in year 2: combat-only + dual-use (dual-use supports combat availability)
m.addConstr(c2 + d2 >= combat_min_y2, "combat_min_year2")

# Total pilots trained over 2 years:
# Training-only jets produce: training_capacity pilots per jet per year
# Dual-use jets produce: training_capacity * dual_eff pilots per jet per year
total_pilots = training_capacity * (t1 + t2) + training_capacity * dual_eff * (d1 + d2)

# Combat jets in year 2 (combat-only + dual-use count as combat available)
combat_jets_y2 = c2 + d2

# Objective: maximize weighted sum of trained pilots and combat jets in year 2
m.setObjective(training_weight * total_pilots + combat_weight * combat_jets_y2, GRB.MAXIMIZE)

m.optimize()

if m.status == GRB.OPTIMAL:
    obj_val = m.ObjVal
    print(f"Year 1: training={t1.X:.2f}, combat={c1.X:.2f}, dual={d1.X:.2f}")
    print(f"Year 2: training={t2.X:.2f}, combat={c2.X:.2f}, dual={d2.X:.2f}")
    pilots = training_capacity * (t1.X + t2.X) + training_capacity * dual_eff * (d1.X + d2.X)
    combat_y2 = c2.X + d2.X
    print(f"Total pilots trained: {pilots:.2f}")
    print(f"Combat jets year 2: {combat_y2:.2f}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Model status: {m.status}")
    print("FINAL_OBJ_VALUE: N/A")
