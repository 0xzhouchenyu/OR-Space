import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'table_1.csv')
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    
    a_I = float(rows[0][1])   # Model A hours for Process I = 4
    b_I = float(rows[0][2])   # Model B hours for Process I = 6
    a_II = float(rows[1][1])  # Model A hours for Process II = 3
    b_II = float(rows[1][2])  # Model B hours for Process II = 2
    profit_A = float(rows[2][1])  # 300
    profit_B = float(rows[2][2])  # 450
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    min_profit = params['min_weekly_profit']  # 10000 (net total over both weeks)
    min_A = params['min_model_A_units']       # 10
    min_B = params['min_model_B_units']       # 15
    w1_min_A = params['week1_min_model_A_units']  # 5
    w1_min_B = params['week1_min_model_B_units']  # 6
    w2_min_A = params['week2_min_model_A_units']  # 5
    w2_min_B = params['week2_min_model_B_units']  # 9
    
    normal_I = params['process_I_hours']      # 150
    normal_II = params['process_II_hours']    # 70
    
    max_ot_I = params['max_overtime_I_per_week']    # 30
    max_ot_II = params['max_overtime_II_per_week']  # 20
    
    ot_cost_I = params['overtime_premium_I']    # 50
    ot_cost_II = params['overtime_premium_II']  # 40
    
    min_avg_util_I = params['min_avg_utilization_I']    # 0.6
    min_avg_util_II = params['min_avg_utilization_II']  # 0.5
    
    fatigue_thresh_I = params['week1_overtime_fatigue_threshold_I']    # 10
    fatigue_thresh_II = params['week1_overtime_fatigue_threshold_II']  # 8
    
    recovery_loss_I = params['week2_recovery_loss_I']    # 15
    recovery_loss_II = params['week2_recovery_loss_II']  # 10
    
    # Create model
    m = gp.Model("Microcomputer_2Week")
    m.setParam('OutputFlag', 0)
    
    # Decision variables
    # Production quantities per week
    xA1 = m.addVar(lb=0, name="xA1")  # Model A, week 1
    xB1 = m.addVar(lb=0, name="xB1")  # Model B, week 1
    xA2 = m.addVar(lb=0, name="xA2")  # Model A, week 2
    xB2 = m.addVar(lb=0, name="xB2")  # Model B, week 2
    
    # Overtime hours per process per week
    ot_I_1 = m.addVar(lb=0, ub=max_ot_I, name="ot_I_1")    # Process I overtime, week 1
    ot_II_1 = m.addVar(lb=0, ub=max_ot_II, name="ot_II_1")  # Process II overtime, week 1
    ot_I_2 = m.addVar(lb=0, ub=max_ot_I, name="ot_I_2")    # Process I overtime, week 2
    ot_II_2 = m.addVar(lb=0, ub=max_ot_II, name="ot_II_2")  # Process II overtime, week 2
    
    # Binary variables for fatigue/recovery trigger
    # z_I = 1 if week-1 Process I overtime > fatigue_thresh_I
    # z_II = 1 if week-1 Process II overtime > fatigue_thresh_II
    z_I = m.addVar(vtype=GRB.BINARY, name="z_I")
    z_II = m.addVar(vtype=GRB.BINARY, name="z_II")
    
    # Big-M for linking binary to overtime threshold
    M_I = max_ot_I + 1
    M_II = max_ot_II + 1
    
    # Fatigue linking constraints:
    # If ot_I_1 > fatigue_thresh_I then z_I = 1
    # If ot_I_1 <= fatigue_thresh_I then z_I = 0
    # We model: ot_I_1 - fatigue_thresh_I <= M_I * z_I  (if ot exceeds threshold, z must be 1)
    # and: ot_I_1 - fatigue_thresh_I >= epsilon * z_I - M_I * (1 - z_I) ... but this is tricky
    # 
    # Actually we need: z_I = 1 iff ot_I_1 > fatigue_thresh_I
    # Use: ot_I_1 <= fatigue_thresh_I + M_I * z_I  (always true, but forces z=1 when ot exceeds)
    # and: ot_I_1 >= fatigue_thresh_I + epsilon - M_I * (1 - z_I) (forces z=0 when ot <= threshold)
    #
    # Simpler formulation: since we want to maximize profit and recovery loss hurts us,
    # the optimizer would prefer z=0. So we only need:
    # ot_I_1 - fatigue_thresh_I <= M_I * z_I  (forces z_I=1 when overtime exceeds threshold)
    # But we also need z_I=0 to be forced when ot_I_1 <= threshold (otherwise optimizer could set z=1 for free).
    # Actually since z=1 reduces week-2 capacity (which is bad for the objective), the optimizer
    # will naturally want z=0 whenever possible. So we only need the one direction:
    # ot_I_1 > fatigue_thresh_I => z_I = 1
    # Which is: ot_I_1 - fatigue_thresh_I <= M_I * z_I
    # 
    # But strictly, "rises above" means strictly greater than. With continuous variables,
    # we use: ot_I_1 - fatigue_thresh_I <= M_I * z_I
    # This means at ot_I_1 = fatigue_thresh_I exactly, z_I can be 0 (no recovery loss).
    
    m.addConstr(ot_I_1 - fatigue_thresh_I <= M_I * z_I, "fatigue_link_I")
    m.addConstr(ot_II_1 - fatigue_thresh_II <= M_II * z_II, "fatigue_link_II")
    
    # Week 2 available regular hours considering recovery
    # If z_I = 1, week 2 Process I regular hours = normal_I - recovery_loss_I
    # If z_I = 0, week 2 Process I regular hours = normal_I
    # avail_I_2 = normal_I - recovery_loss_I * z_I
    # avail_II_2 = normal_II - recovery_loss_II * z_II
    
    # Week 1 capacity constraints (regular + overtime)
    m.addConstr(a_I * xA1 + b_I * xB1 <= normal_I + ot_I_1, "w1_proc_I")
    m.addConstr(a_II * xA1 + b_II * xB1 <= normal_II + ot_II_1, "w1_proc_II")
    
    # Week 2 capacity constraints (regular - recovery loss + overtime)
    m.addConstr(a_I * xA2 + b_I * xB2 <= normal_I - recovery_loss_I * z_I + ot_I_2, "w2_proc_I")
    m.addConstr(a_II * xA2 + b_II * xB2 <= normal_II - recovery_loss_II * z_II + ot_II_2, "w2_proc_II")
    
    # Weekly delivery promises (met in their own week)
    m.addConstr(xA1 >= w1_min_A, "w1_min_A")
    m.addConstr(xB1 >= w1_min_B, "w1_min_B")
    m.addConstr(xA2 >= w2_min_A, "w2_min_A")
    m.addConstr(xB2 >= w2_min_B, "w2_min_B")
    
    # Total production requirements over both weeks
    m.addConstr(xA1 + xA2 >= min_A, "total_min_A")
    m.addConstr(xB1 + xB2 >= min_B, "total_min_B")
    
    # Minimum average utilization of regular hours over two weeks
    # For Process I: average utilization = (hours used in regular time across both weeks) / (total regular hours available across both weeks)
    # The regular hours used in week t for process p is min(production_hours, regular_capacity_t).
    # But simpler interpretation: the production hours on each process (excluding overtime contribution)
    # should on average meet the utilization threshold.
    #
    # Actually, the utilization constraint says: the total regular hours actually used across both weeks
    # divided by the total regular hours available across both weeks >= threshold.
    #
    # Regular hours used in week 1 for Process I = min(a_I*xA1 + b_I*xB1, normal_I)
    # Regular hours used in week 2 for Process I = min(a_I*xA2 + b_I*xB2, normal_I - recovery_loss_I*z_I)
    #
    # But since production = regular + overtime, regular used = production - overtime used on that process.
    # reg_used_I_1 = (a_I*xA1 + b_I*xB1) - ot_I_1   ... but this could be wrong if ot isn't fully used.
    # Actually: total hours on process = regular_used + overtime_used, where:
    #   regular_used <= normal_capacity
    #   overtime_used <= max_overtime
    #   regular_used + overtime_used = production_hours
    # So regular_used = production_hours - overtime_used
    # And since we want to maximize regular utilization (or at least meet minimum), and overtime costs money,
    # the optimizer will use regular hours first.
    #
    # The capacity constraint is: production_hours <= normal + overtime
    # If we define regular_used = production_hours - overtime_used, then:
    #   regular_used = (a_I*xA1 + b_I*xB1) - ot_I_1 for week 1
    #   But ot_I_1 could be slack (more overtime allocated than needed beyond regular).
    #   Actually ot_I_1 is the overtime hours used. The constraint a_I*xA1+b_I*xB1 <= normal_I + ot_I_1
    #   means ot_I_1 >= production - normal_I. But ot_I_1 could be larger (slack).
    #   However since overtime costs money, the optimizer will minimize ot_I_1, so ot_I_1 = max(0, production - normal_I).
    #
    # For the utilization constraint, a clean way:
    # Total regular hours available over 2 weeks for Process I = normal_I + (normal_I - recovery_loss_I * z_I)
    # We want: sum of regular hours used >= min_avg_util * total regular hours available
    # regular hours used in week t = min(production_hours_t, regular_capacity_t) = production_hours_t - overtime_used_t
    # But overtime_used >= max(0, production - regular_cap), and the optimizer will set it to exactly that.
    #
    # So: sum of (production - overtime) >= threshold * sum of regular_capacity
    # (a_I*xA1 + b_I*xB1 - ot_I_1) + (a_I*xA2 + b_I*xB2 - ot_I_2) >= min_avg_util_I * (normal_I + normal_I - recovery_loss_I * z_I)
    #
    # But this only works if we ensure regular_used <= regular_capacity, which is:
    # production - overtime <= regular_capacity => production <= regular_capacity + overtime (already our constraint)
    # And regular_used >= 0 => overtime <= production (overtime can't exceed production hours, but let's add this)
    
    m.addConstr(ot_I_1 <= a_I * xA1 + b_I * xB1, "ot_I_1_ub_prod")
    m.addConstr(ot_II_1 <= a_II * xA1 + b_II * xB1, "ot_II_1_ub_prod")
    m.addConstr(ot_I_2 <= a_I * xA2 + b_I * xB2, "ot_I_2_ub_prod")
    m.addConstr(ot_II_2 <= a_II * xA2 + b_II * xB2, "ot_II_2_ub_prod")
    
    # Utilization constraints
    # Process I: average utilization over 2 weeks >= 0.6
    reg_used_I = (a_I * xA1 + b_I * xB1 - ot_I_1) + (a_I * xA2 + b_I * xB2 - ot_I_2)
    reg_avail_I = normal_I + normal_I - recovery_loss_I * z_I
    m.addConstr(reg_used_I >= min_avg_util_I * reg_avail_I, "avg_util_I")
    
    # Process II: average utilization over 2 weeks >= 0.5
    reg_used_II = (a_II * xA1 + b_II * xB1 - ot_II_1) + (a_II * xA2 + b_II * xB2 - ot_II_2)
    reg_avail_II = normal_II + normal_II - recovery_loss_II * z_II
    m.addConstr(reg_used_II >= min_avg_util_II * reg_avail_II, "avg_util_II")
    
    # Objective: maximize two-week profit after overtime spending
    total_revenue = profit_A * (xA1 + xA2) + profit_B * (xB1 + xB2)
    total_ot_cost = ot_cost_I * (ot_I_1 + ot_I_2) + ot_cost_II * (ot_II_1 + ot_II_2)
    net_profit = total_revenue - total_ot_cost
    
    m.setObjective(net_profit, GRB.MAXIMIZE)
    
    # Minimum net profit constraint
    m.addConstr(net_profit >= min_profit, "min_net_profit")
    
    # Solve
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        obj_val = m.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    elif m.status == GRB.INFEASIBLE:
        print("Model is infeasible")
        m.computeIIS()
        m.write("model.ilp")
        print("FINAL_OBJ_VALUE: INFEASIBLE")
    else:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal if m.SolCount > 0 else 'NO_SOLUTION'}")

if __name__ == "__main__":
    main()
