import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_path = os.path.join(base_dir, "data", "table_3_3.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    
    df = pd.read_csv(table_path)
    params_df = pd.read_csv(params_path)
    
    # Extract parameters
    sales_goal = float(params_df.loc[params_df['Parameter_Name'] == 'monthly_sales_goal', 'Value'].values[0])
    pt_ft_ratio = float(params_df.loc[params_df['Parameter_Name'] == 'pt_ft_overtime_ratio', 'Value'].values[0])
    
    # Extract clerk data
    ft_row = df[df['Role'] == 'Full-time'].iloc[0]
    pt_row = df[df['Role'] == 'Part-time'].iloc[0]
    
    # Default number of clerks (classic textbook values)
    num_ft = 5
    num_pt = 4
    for col in df.columns:
        if any(kw in col.lower() for kw in ['num', 'clerks', 'employees', 'count', '人员', '数量']):
            num_ft = float(ft_row[col])
            num_pt = float(pt_row[col])
            break
    
    # Calculate normal sales from full employment
    normal_sales_ft = num_ft * ft_row['Monthly_Working_Hours'] * ft_row['Sales_Volume_Pairs_Per_Hour']
    normal_sales_pt = num_pt * pt_row['Monthly_Working_Hours'] * pt_row['Sales_Volume_Pairs_Per_Hour']
    total_normal_sales = normal_sales_ft + normal_sales_pt
    
    # Build model
    model = gp.Model("Minimize_Overtime")
    model.setParam('OutputFlag', 0)
    
    # Variables for overtime hours
    y_ft = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name='y_ft')
    y_pt = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name='y_pt')
    
    # Objective: Minimize total overtime hours
    model.setObjective(y_ft + y_pt, GRB.MINIMIZE)
    
    # Constraint: Achieve monthly sales goal
    sales_needed = sales_goal - total_normal_sales
    model.addConstr(
        y_ft * ft_row['Sales_Volume_Pairs_Per_Hour'] + y_pt * pt_row['Sales_Volume_Pairs_Per_Hour'] >= sales_needed,
        name='sales_goal'
    )
    
    # NEW constraint: part-time overtime hours >= 50% of full-time overtime hours
    model.addConstr(y_pt >= pt_ft_ratio * y_ft, name='pt_ft_overtime_ratio')
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {round(obj_val, 4)}")
    else:
        print(f"FINAL_OBJ_VALUE: N/A (status={model.status})")

if __name__ == '__main__':
    solve()
