import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Load demand forecast
demand = {}
with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for i, row in enumerate(reader):
        demand[i] = float(row['Demand_Forecast'])

T = len(demand)  # 6 months

# Load general parameters
params = {}
with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

W0 = int(params['initial_workforce'])
I0 = params['initial_inventory']
sp = params['sales_price']
rmc = params['raw_material_cost']
oc = params['outsourcing_cost']
hc = params['inventory_holding_cost']
bc = params['backorder_cost']
lr = params['labor_requirement']
rh = params['regular_labor_hours']
rw = params['regular_wage']
otl = params['overtime_hours_limit']
ow = params['overtime_wage']
hire_cost = params['hiring_cost']
fire_cost = params['firing_cost']
term_inv = params['terminal_inventory']
term_bo = params['terminal_backorders']
contract_min = params['contract_min_units']
contract_bigM = params['contract_bigM']

# Contract months: April (t=3), May (t=4), June (t=5)
contract_months = [3, 4, 5]

# Model
model = gp.Model("FoldableTableProduction")
model.setParam('OutputFlag', 0)

# Decision variables
W = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="W")  # workforce
H = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="H")  # hired
F = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="F")  # fired
P = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="P")  # in-house production
OT_total = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="OT")  # total overtime hours
O = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="O")  # outsourced units
Inv = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="Inv")  # inventory
B = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="B")  # backorders

# Regular-time production (units produced using only regular hours)
P_reg = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="P_reg")

# Contract-qualified production for contract months
# This is the amount of regular-time production that counts toward the contract
CQ = model.addVars(T, lb=0, vtype=GRB.CONTINUOUS, name="CQ")

# Binary indicators for contract enforcement
# y[t] = 1 if contract is active (always 1 for contract months, but we use it for big-M)
y = model.addVars(T, vtype=GRB.BINARY, name="y")

# Constraints
for t in range(T):
    # Workforce balance
    if t == 0:
        model.addConstr(W[t] == W0 + H[t] - F[t])
    else:
        model.addConstr(W[t] == W[t-1] + H[t] - F[t])
    
    # Production limited by total labor hours (regular + overtime)
    model.addConstr(P[t] * lr <= W[t] * rh + OT_total[t])
    
    # Overtime limit
    model.addConstr(OT_total[t] <= W[t] * otl)
    
    # Regular-time production capacity
    model.addConstr(P_reg[t] * lr <= W[t] * rh)
    
    # Regular-time production cannot exceed total production
    model.addConstr(P_reg[t] <= P[t])
    
    # Inventory balance: Inv[t] - B[t] = (Inv[t-1] - B[t-1]) + P[t] + O[t] - demand[t]
    prev_inv = I0 if t == 0 else Inv[t-1]
    prev_b = 0 if t == 0 else B[t-1]
    model.addConstr(Inv[t] - B[t] == prev_inv - prev_b + P[t] + O[t] - demand[t])

# Terminal conditions
model.addConstr(Inv[T-1] >= term_inv)
model.addConstr(B[T-1] <= term_bo)

# Contract constraints for April (t=3), May (t=4), June (t=5)
for t in range(T):
    if t in contract_months:
        # Force binary to 1 for contract months
        model.addConstr(y[t] == 1)
        
        # CQ[t] is the contract-qualified quantity
        # It must be at least contract_min_units
        model.addConstr(CQ[t] >= contract_min)
        
        # CQ[t] cannot exceed regular-time production
        model.addConstr(CQ[t] <= P_reg[t])
        
        # CQ[t] cannot exceed the month's requirement (demand + backlog from prior month)
        # Month's requirement = demand[t] + B[t-1] (backlog carried in)
        prev_b = 0 if t == 0 else B[t-1]
        model.addConstr(CQ[t] <= demand[t] + prev_b)
    else:
        # No contract constraint for non-contract months
        model.addConstr(y[t] == 0)
        model.addConstr(CQ[t] == 0)

# Objective: maximize net profit
# Revenue = sales_price * total units sold
# Since terminal backorders = 0, all demand is eventually met
total_demand = sum(demand[t] for t in range(T))
revenue = sp * total_demand

# Costs
material_cost = gp.quicksum(rmc * P[t] for t in range(T))
outsource_cost = gp.quicksum(oc * O[t] for t in range(T))
holding_cost = gp.quicksum(hc * Inv[t] for t in range(T))
backorder_cost_total = gp.quicksum(bc * B[t] for t in range(T))
regular_labor_cost = gp.quicksum(rw * rh * W[t] for t in range(T))
overtime_cost = gp.quicksum(ow * OT_total[t] for t in range(T))
hiring_cost_total = gp.quicksum(hire_cost * H[t] for t in range(T))
firing_cost_total = gp.quicksum(fire_cost * F[t] for t in range(T))

total_cost = (material_cost + outsource_cost + holding_cost + backorder_cost_total +
              regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total)

model.setObjective(revenue - total_cost, GRB.MAXIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
elif model.status == GRB.INFEASIBLE:
    print("Model is infeasible")
    model.computeIIS()
    print("FINAL_OBJ_VALUE: INFEASIBLE")
else:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
