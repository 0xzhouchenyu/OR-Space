import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    
    df = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)
    
    # Extract parameters
    budget = float(params[params['Parameter_Name'] == 'budget']['Value'].iloc[0])
    food_intake = float(params[params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
    weekday_budget_share = float(params[params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
    max_prep_time_weekday = float(params[params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
    max_prep_time_weekend = float(params[params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
    weekend_protein_ban = int(params[params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
    veg_balance_penalty = float(params[params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])
    
    # Fill missing fiber content with 0
    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)
    
    foods = df['Food'].tolist()
    types = df.set_index('Food')['Type'].to_dict()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()
    
    proteins = [f for f in foods if types[f] == 'protein']
    vegetables = [f for f in foods if types[f] == 'vegetable']
    
    # Budget allocation
    weekday_budget = budget * weekday_budget_share
    weekend_budget = budget * (1 - weekday_budget_share)
    
    # Food intake in 100g units
    intake_units = food_intake / 100.0  # 5 units
    
    # Big M
    M = intake_units
    
    # Create model
    model = gp.Model("MaryDinnerPlan")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_w[f] = amount of food f in weekday dinner (in 100g units)
    # x_e[f] = amount of food f in weekend dinner (in 100g units)
    x_w = model.addVars(foods, lb=0, vtype=GRB.CONTINUOUS, name="x_w")
    x_e = model.addVars(foods, lb=0, vtype=GRB.CONTINUOUS, name="x_e")
    
    # Binary: y_w[f] = 1 if food f is chosen for weekday
    # Binary: y_e[f] = 1 if food f is chosen for weekend
    y_w = model.addVars(foods, vtype=GRB.BINARY, name="y_w")
    y_e = model.addVars(foods, vtype=GRB.BINARY, name="y_e")
    
    # Binary: z[f] = 1 if protein f is "labeled" (used in at least one meal)
    z = model.addVars(proteins, vtype=GRB.BINARY, name="z")
    
    # Vegetable balance deviation variables
    # For each vegetable, deviation between weekday and weekend amounts
    dev = model.addVars(vegetables, lb=0, vtype=GRB.CONTINUOUS, name="dev")
    
    # Objective: maximize total fiber from both meals minus veg balance penalty
    total_fiber = gp.quicksum(fiber[f] * x_w[f] for f in foods) + gp.quicksum(fiber[f] * x_e[f] for f in foods)
    total_penalty = veg_balance_penalty * gp.quicksum(dev[v] for v in vegetables)
    model.setObjective(total_fiber - total_penalty, GRB.MAXIMIZE)
    
    # Constraints
    # 1. Total food intake per dinner
    model.addConstr(gp.quicksum(x_w[f] for f in foods) == intake_units, "weekday_intake")
    model.addConstr(gp.quicksum(x_e[f] for f in foods) == intake_units, "weekend_intake")
    
    # 2. Budget constraints per dinner
    model.addConstr(gp.quicksum(price[f] * x_w[f] for f in foods) <= weekday_budget, "weekday_budget")
    model.addConstr(gp.quicksum(price[f] * x_e[f] for f in foods) <= weekend_budget, "weekend_budget")
    
    # 3. Prep time constraints
    model.addConstr(gp.quicksum(prep_time[f] * x_w[f] for f in foods) <= max_prep_time_weekday, "weekday_prep")
    model.addConstr(gp.quicksum(prep_time[f] * x_e[f] for f in foods) <= max_prep_time_weekend, "weekend_prep")
    
    # 4. Exactly one protein source per dinner (shared shopping logic - same structure)
    # "The pair must share the same shopping logic" - both meals follow same selection rules
    model.addConstr(gp.quicksum(y_w[f] for f in proteins) == 1, "weekday_one_protein")
    model.addConstr(gp.quicksum(y_e[f] for f in proteins) == 1, "weekend_one_protein")
    
    # 5. At least two kinds of vegetables per dinner
    model.addConstr(gp.quicksum(y_w[f] for f in vegetables) >= 2, "weekday_min_veg")
    model.addConstr(gp.quicksum(y_e[f] for f in vegetables) >= 2, "weekend_min_veg")
    
    # 6. Linking constraints
    for f in foods:
        model.addConstr(x_w[f] >= 0.1 * y_w[f], f"link_lb_w_{f}")
        model.addConstr(x_w[f] <= M * y_w[f], f"link_ub_w_{f}")
        model.addConstr(x_e[f] >= 0.1 * y_e[f], f"link_lb_e_{f}")
        model.addConstr(x_e[f] <= M * y_e[f], f"link_ub_e_{f}")
    
    # 7. Weekend protein ban
    if weekend_protein_ban == 1:
        for f in proteins:
            model.addConstr(y_e[f] == 0, f"weekend_ban_{f}")
    
    # 8. Protein label constraint: avoid using a protein label unless that protein 
    # appears in at least one of the two meals
    # z[f] = 1 only if protein f is used in at least one meal
    # y_w[f] <= z[f], y_e[f] <= z[f] would force z=1 if used
    # But the requirement says "avoid using a protein label on paper unless that protein 
    # appears in at least one of the two meals"
    # This means: z[f] <= y_w[f] + y_e[f] (can't label it unless it's used)
    # And we need z[f] >= y_w[f] and z[f] >= y_e[f] to track usage
    # Actually: the constraint is that a protein is "labeled" only if used in at least one meal
    # This effectively means: for each protein, if it's selected in either meal, it counts
    # But we can't select it without it being used. The constraint ensures no phantom selections.
    for f in proteins:
        model.addConstr(z[f] >= y_w[f], f"label_w_{f}")
        model.addConstr(z[f] >= y_e[f], f"label_e_{f}")
        model.addConstr(z[f] <= y_w[f] + y_e[f], f"label_used_{f}")
    
    # 9. Vegetable balance deviation constraints
    for v in vegetables:
        model.addConstr(dev[v] >= x_w[v] - x_e[v], f"dev_pos_{v}")
        model.addConstr(dev[v] >= x_e[v] - x_w[v], f"dev_neg_{v}")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        return round(obj_val, 4)
    else:
        # Try to get best solution
        if model.SolCount > 0:
            return round(model.ObjVal, 4)
        else:
            return None

if __name__ == '__main__':
    result = solve()
    print(f"FINAL_OBJ_VALUE: {result}")
