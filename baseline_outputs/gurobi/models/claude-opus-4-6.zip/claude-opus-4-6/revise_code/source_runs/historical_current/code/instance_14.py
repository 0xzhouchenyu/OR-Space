import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load food items
    items = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })
    
    # Load parameters
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_daily_calories = params['min_daily_calories']
    max_daily_calories = params['max_daily_calories']
    max_daily_sodium = params['max_daily_sodium']
    
    max_units = int(total_weight_limit // 100)  # max 100g units per item for daily purchase
    max_meal_units = 3  # 300g per meal / 100g per unit
    
    n = len(items)
    veg_indices = [i for i in range(n) if items[i]['type'] == 'Vegetable']
    
    model = gp.Model("meal_planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # purchase_units[i]: total 100g units purchased of item i
    purchase = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="purchase")
    # lunch_units[i]: 100g units of item i assigned to lunch
    lunch = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="lunch")
    # dinner_units[i]: 100g units of item i assigned to dinner
    dinner = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="dinner")
    # select_item[i]: binary, whether item i is purchased
    select_item = model.addVars(n, vtype=GRB.BINARY, name="select")
    # lunch_veg_selected[i]: binary, whether vegetable i appears in lunch
    lunch_veg = model.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg")
    # dinner_veg_selected[i]: binary, whether vegetable i appears in dinner
    dinner_veg = model.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg")
    
    # Objective: maximize total protein from lunch and dinner
    model.setObjective(
        gp.quicksum(items[i]['protein'] * (lunch[i] + dinner[i]) for i in range(n)),
        GRB.MAXIMIZE
    )
    
    # Constraint 1: Total daily budget (based on purchased units)
    model.addConstr(
        gp.quicksum(items[i]['cost'] * purchase[i] for i in range(n)) <= max_budget,
        "budget"
    )
    
    # Constraint 2: Total daily weight limit (based on purchased units)
    model.addConstr(
        gp.quicksum(100 * purchase[i] for i in range(n)) <= total_weight_limit,
        "weight_limit"
    )
    
    # Constraint: Linking purchase to meal assignments
    for i in range(n):
        model.addConstr(purchase[i] >= lunch[i] + dinner[i], f"link_purchase_{i}")
    
    # Constraint 7: Purchase selection linkage (big-M)
    for i in range(n):
        model.addConstr(purchase[i] <= max_units * select_item[i], f"select_purchase_{i}")
        model.addConstr(lunch[i] <= max_meal_units * select_item[i], f"select_lunch_{i}")
        model.addConstr(dinner[i] <= max_meal_units * select_item[i], f"select_dinner_{i}")
    
    # Constraint 4: Per-meal weight balance (exactly 300g each)
    model.addConstr(
        gp.quicksum(100 * lunch[i] for i in range(n)) == 300,
        "lunch_weight"
    )
    model.addConstr(
        gp.quicksum(100 * dinner[i] for i in range(n)) == 300,
        "dinner_weight"
    )
    
    # Constraint 5: Daily calorie bounds
    total_calories = gp.quicksum(items[i]['calories'] * (lunch[i] + dinner[i]) for i in range(n))
    model.addConstr(total_calories >= min_daily_calories, "min_calories")
    model.addConstr(total_calories <= max_daily_calories, "max_calories")
    
    # Constraint 6: Daily sodium bound
    total_sodium = gp.quicksum(items[i]['sodium'] * (lunch[i] + dinner[i]) for i in range(n))
    model.addConstr(total_sodium <= max_daily_sodium, "max_sodium")
    
    # Constraint 3: Minimum vegetable types per meal
    # Vegetable coverage constraints for lunch
    for i in veg_indices:
        model.addConstr(lunch[i] >= lunch_veg[i], f"lunch_veg_lb_{i}")
        model.addConstr(lunch[i] <= max_meal_units * lunch_veg[i], f"lunch_veg_ub_{i}")
    
    model.addConstr(
        gp.quicksum(lunch_veg[i] for i in veg_indices) >= min_veg_types,
        "min_veg_lunch"
    )
    
    # Vegetable coverage constraints for dinner
    for i in veg_indices:
        model.addConstr(dinner[i] >= dinner_veg[i], f"dinner_veg_lb_{i}")
        model.addConstr(dinner[i] <= max_meal_units * dinner_veg[i], f"dinner_veg_ub_{i}")
    
    model.addConstr(
        gp.quicksum(dinner_veg[i] for i in veg_indices) >= min_veg_types,
        "min_veg_dinner"
    )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj = model.ObjVal
        for i in range(n):
            p_val = purchase[i].X
            l_val = lunch[i].X
            d_val = dinner[i].X
            if p_val > 0.5:
                print(f"{items[i]['name']}: purchased={p_val*100}g, lunch={l_val*100}g, dinner={d_val*100}g, "
                      f"protein={items[i]['protein']*(l_val+d_val)}g, cost=${items[i]['cost']*p_val}")
        print(f"FINAL_OBJ_VALUE: {obj}")
    else:
        print(f"Model status: {model.status}")
        print("FINAL_OBJ_VALUE: infeasible")

main()
