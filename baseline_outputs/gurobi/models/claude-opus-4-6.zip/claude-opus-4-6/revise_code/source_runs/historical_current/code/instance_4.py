import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
cow_price = params['cow_selling_price']
sheep_price = params['sheep_selling_price']
chicken_price = params['chicken_selling_price']
cow_feed = params['cow_feed_cost']
sheep_feed = params['sheep_feed_cost']
chicken_feed = params['chicken_feed_cost']
cow_manure = params['cow_manure_production']
sheep_manure = params['sheep_manure_production']
chicken_manure = params['chicken_manure_production']
max_manure = params['max_manure_capacity']
max_chickens = params['max_chickens']
min_cows = params['min_cows']
min_sheep = params['min_sheep']
max_total = params['max_total_animals']

premium_capacity_mult = params['premium_capacity_multiplier']
premium_manure_mult = params['premium_manure_multiplier']
expansion_cost = params['expansion_cost']
premium_feed_mult = params['premium_feed_multiplier']

base_land_cow = params['base_land_usage_cow']
base_land_sheep = params['base_land_usage_sheep']
base_land_chicken = params['base_land_usage_chicken']
base_land_capacity = params['base_land_capacity']
expansion_land_increase = params['expansion_land_increase']

# Big-M values
M_total = 1000
M_manure = 10000
M_land = 1000

model = gp.Model("FarmProfit")
model.setParam('OutputFlag', 0)

# Binary: whether to use expanded mode
expand = model.addVar(vtype=GRB.BINARY, name="expand")

# Regular animals (always available)
cows = model.addVar(lb=0, vtype=GRB.INTEGER, name="cows")
sheep = model.addVar(lb=0, vtype=GRB.INTEGER, name="sheep")
chickens = model.addVar(lb=0, vtype=GRB.INTEGER, name="chickens")

# Premium animals (only available when expanded mode is active)
pcows = model.addVar(lb=0, vtype=GRB.INTEGER, name="pcows")
psheep = model.addVar(lb=0, vtype=GRB.INTEGER, name="psheep")
pchickens = model.addVar(lb=0, vtype=GRB.INTEGER, name="pchickens")

# Minimum demand constraints (total of regular + premium)
model.addConstr(cows + pcows >= min_cows, "min_cows")
model.addConstr(sheep + psheep >= min_sheep, "min_sheep")

# Max chickens constraint (total)
model.addConstr(chickens + pchickens <= max_chickens, "max_chickens")

# Premium animals only available if expanded mode is on
model.addConstr(pcows <= M_total * expand, "premium_cows_link")
model.addConstr(psheep <= M_total * expand, "premium_sheep_link")
model.addConstr(pchickens <= M_total * expand, "premium_chickens_link")

# Total animals constraint:
# If not expanded: total <= max_total
# If expanded: total <= max_total * premium_capacity_multiplier
total_animals = cows + sheep + chickens + pcows + psheep + pchickens
model.addConstr(total_animals <= max_total + (max_total * premium_capacity_mult - max_total) * expand, "total_animals")

# Manure constraint:
# Regular animals produce normal manure, premium animals produce manure * premium_manure_multiplier
# Capacity: if not expanded: max_manure; if expanded: max_manure * premium_manure_mult
# Wait - re-reading the brief: "changes effective capacity and manure burden through premium_capacity_multiplier and premium_manure_multiplier"
# premium_manure_multiplier applies to max_manure_capacity when expanded
# Premium animals have higher manure burden? The brief says "changes ... manure burden through ... premium_manure_multiplier"
# Looking at the multiplier value (1.2) and it's described as "Multiplier for max_manure_capacity when expanded mode is selected"
# So the manure capacity increases in expanded mode.
# For premium animals, they still produce normal manure (the capacity just increases).
# Actually, "manure burden" could mean the animals produce more manure. But the CSV description says 
# "Multiplier for max_manure_capacity when expanded mode is selected" - so it's the capacity that's multiplied.

total_manure = (cow_manure * (cows + pcows) + 
                sheep_manure * (sheep + psheep) + 
                chicken_manure * (chickens + pchickens))

model.addConstr(total_manure <= max_manure + (max_manure * premium_manure_mult - max_manure) * expand, "manure_capacity")

# Land constraint:
# Base: base_land_capacity; Expanded: base_land_capacity + expansion_land_increase
total_land = (base_land_cow * (cows + pcows) + 
              base_land_sheep * (sheep + psheep) + 
              base_land_chicken * (chickens + pchickens))

model.addConstr(total_land <= base_land_capacity + expansion_land_increase * expand, "land_capacity")

# Objective: maximize profit
# Regular animals: (price - feed) per animal
# Premium animals: (price - feed * premium_feed_multiplier) per animal
# If expanded: subtract expansion_cost

regular_profit = ((cow_price - cow_feed) * cows + 
                  (sheep_price - sheep_feed) * sheep + 
                  (chicken_price - chicken_feed) * chickens)

premium_profit = ((cow_price - cow_feed * premium_feed_mult) * pcows + 
                  (sheep_price - sheep_feed * premium_feed_mult) * psheep + 
                  (chicken_price - chicken_feed * premium_feed_mult) * pchickens)

model.setObjective(regular_profit + premium_profit - expansion_cost * expand, GRB.MAXIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"Expand: {expand.X}")
    print(f"Cows: {cows.X}, Premium Cows: {pcows.X}")
    print(f"Sheep: {sheep.X}, Premium Sheep: {psheep.X}")
    print(f"Chickens: {chickens.X}, Premium Chickens: {pchickens.X}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    print(f"Model status: {model.status}")
    print("FINAL_OBJ_VALUE: infeasible")
