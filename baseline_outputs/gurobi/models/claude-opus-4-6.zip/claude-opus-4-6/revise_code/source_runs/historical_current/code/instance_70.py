import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_distance_matrix(filepath):
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        city_labels = header[1:]
        dist = []
        cities = []
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
    return cities, dist

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['parameter'].strip()] = row['value'].strip()
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    dist_file = os.path.join(base_dir, "data", "table_1.csv")
    params_file = os.path.join(base_dir, "data", "general_parameters.csv")

    cities, dist = load_distance_matrix(dist_file)
    params = load_general_parameters(params_file)

    n = len(cities)

    # Map city labels to indices
    city_to_idx = {cities[i]: i for i in range(n)}

    start_city = params['start_city']
    end_city = params['end_city']
    prohibited_from = params['prohibited_from']
    prohibited_to = params['prohibited_to']
    inspection_from = params['inspection_arc_from']
    inspection_to = params['inspection_arc_to']
    inspection_cost = float(params['inspection_stop_cost'])

    start_idx = city_to_idx[start_city]
    end_idx = city_to_idx[end_city]
    prohib_from_idx = city_to_idx[prohibited_from]
    prohib_to_idx = city_to_idx[prohibited_to]
    insp_from_idx = city_to_idx[inspection_from]
    insp_to_idx = city_to_idx[inspection_to]

    # This is an open TSP (Hamiltonian path) from start_city to end_city
    # visiting all cities exactly once.
    # Constraints:
    # 1. Start at start_city (city 1), end at end_city (city 4)
    # 2. Direct arc from prohibited_from to prohibited_to is forbidden (1->3)
    # 3. Arc from inspection_from to inspection_to (2->3) has extra cost of 4

    # Build cost matrix with inspection cost added
    cost = [[0.0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            cost[i][j] = dist[i][j]
    # Add inspection cost on arc 2->3
    cost[insp_from_idx][insp_to_idx] += inspection_cost

    # Model: open path TSP from start_idx to end_idx
    # We can model this by adding a dummy arc from end_idx to start_idx with cost 0
    # and solving a standard TSP on the augmented graph, then removing that dummy arc.
    # Actually, easier approach: model as assignment + subtour elimination for a path.

    # Approach: Add a dummy node that connects end_idx -> dummy -> start_idx with 0 cost.
    # This converts the open path into a closed tour.
    # dummy node index = n
    N = n + 1  # includes dummy
    
    model = gp.Model("TSP_revised")
    model.setParam('OutputFlag', 0)

    # Decision variables x[i,j] for i != j, i,j in 0..N-1
    x = {}
    for i in range(N):
        for j in range(N):
            if i != j:
                # Determine cost
                if i == n or j == n:
                    # Dummy node arcs
                    # dummy -> start_idx: cost 0
                    # end_idx -> dummy: cost 0
                    # All other arcs to/from dummy: very high cost (forbidden)
                    if i == n and j == start_idx:
                        c = 0.0
                    elif i == end_idx and j == n:
                        c = 0.0
                    else:
                        c = 1e10  # effectively forbidden
                else:
                    c = cost[i][j]
                x[i, j] = model.addVar(vtype=GRB.BINARY, obj=c, name=f"x_{i}_{j}")

    model.update()

    # Degree constraints: each node has exactly one incoming and one outgoing arc
    for i in range(N):
        model.addConstr(gp.quicksum(x[i, j] for j in range(N) if j != i) == 1,
                        name=f"out_{i}")
        model.addConstr(gp.quicksum(x[j, i] for j in range(N) if j != i) == 1,
                        name=f"in_{i}")

    # Prohibited arc: 1->3
    model.addConstr(x[prohib_from_idx, prohib_to_idx] == 0, name="prohibit_1_3")

    # MTZ subtour elimination
    # u[i] for i in 0..N-1, but we fix u for the dummy node
    u = {}
    for i in range(N):
        u[i] = model.addVar(lb=0, ub=N-1, vtype=GRB.CONTINUOUS, name=f"u_{i}")

    # Fix dummy node position
    model.addConstr(u[n] == 0, name="u_dummy")

    # MTZ constraints: for all i,j != dummy (or we can include all)
    for i in range(N):
        for j in range(N):
            if i != j and j != n:  # don't constrain returning to dummy
                if (i, j) in x:
                    model.addConstr(u[i] - u[j] + N * x[i, j] <= N - 1,
                                    name=f"mtz_{i}_{j}")

    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
