import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass
            params[name] = value
    return params

def solve():
    params = load_parameters()
    
    profit_robot = params['profit_per_robot']
    profit_car = params['profit_per_model_car']
    profit_blocks = params['profit_per_building_blocks']
    profit_doll = params['profit_per_doll']
    
    plastic_avail = params['plastic_available']
    plastic_robot = params['plastic_per_robot']
    plastic_car = params['plastic_per_model_car']
    plastic_blocks = params['plastic_per_building_blocks']
    plastic_doll = params['plastic_per_doll']
    
    elec_avail = params['electronic_components_available']
    elec_robot = params['electronics_per_robot']
    elec_car = params['electronics_per_model_car']
    elec_blocks = params['electronics_per_building_blocks']
    elec_doll = params['electronics_per_doll']
    
    M = 10000
    
    model = gp.Model("ToyManufacturing")
    model.setParam('OutputFlag', 0)
    
    # Integer decision variables
    x_robot = model.addVar(vtype=GRB.INTEGER, lb=0, name="robots")
    x_car = model.addVar(vtype=GRB.INTEGER, lb=0, name="model_cars")
    x_blocks = model.addVar(vtype=GRB.INTEGER, lb=0, name="building_blocks")
    x_doll = model.addVar(vtype=GRB.INTEGER, lb=0, name="dolls")
    
    # Binary variables
    y_robot = model.addVar(vtype=GRB.BINARY, name="y_robot")
    y_doll = model.addVar(vtype=GRB.BINARY, name="y_doll")
    y_car = model.addVar(vtype=GRB.BINARY, name="y_car")
    y_blocks = model.addVar(vtype=GRB.BINARY, name="y_blocks")
    
    # Objective
    model.setObjective(
        profit_robot * x_robot + profit_car * x_car + profit_blocks * x_blocks + profit_doll * x_doll,
        GRB.MAXIMIZE
    )
    
    # Resource constraints
    model.addConstr(
        plastic_robot * x_robot + plastic_car * x_car + plastic_blocks * x_blocks + plastic_doll * x_doll <= plastic_avail,
        "Plastic"
    )
    model.addConstr(
        elec_robot * x_robot + elec_car * x_car + elec_blocks * x_blocks + elec_doll * x_doll <= elec_avail,
        "Electronics"
    )
    
    # Link binary variables to production quantities
    model.addConstr(x_robot <= M * y_robot, "Link_robot")
    model.addConstr(x_doll <= M * y_doll, "Link_doll")
    model.addConstr(x_car <= M * y_car, "Link_car")
    model.addConstr(x_blocks <= M * y_blocks, "Link_blocks")
    
    # Reverse link: if binary is 1, must produce at least 1
    model.addConstr(y_robot <= x_robot, "RevLink_robot")
    model.addConstr(y_doll <= x_doll, "RevLink_doll")
    model.addConstr(y_car <= x_car, "RevLink_car")
    model.addConstr(y_blocks <= x_blocks, "RevLink_blocks")
    
    # Constraint 1: If robots are manufactured, dolls cannot be manufactured (exclusion)
    model.addConstr(y_robot + y_doll <= 1, "Robot_Doll_Exclusion")
    
    # Constraint 2: If model cars are manufactured, building blocks must also be manufactured
    model.addConstr(y_car <= y_blocks, "Car_Blocks_Dependency")
    
    # Constraint 3: Dolls cannot exceed model cars
    model.addConstr(x_doll <= x_car, "Dolls_leq_Cars")
    
    # NEW Constraint (REVISION): Model cars and building blocks cannot both be produced
    # Mutual exclusion on the molding line
    model.addConstr(y_car + y_blocks <= 1, "Car_Blocks_Exclusion")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"Status: Optimal")
        print(f"Robots: {x_robot.X}")
        print(f"Model Cars: {x_car.X}")
        print(f"Building Blocks: {x_blocks.X}")
        print(f"Dolls: {x_doll.X}")
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print(f"Status: {model.status}")
        print(f"FINAL_OBJ_VALUE: N/A")

if __name__ == "__main__":
    solve()
