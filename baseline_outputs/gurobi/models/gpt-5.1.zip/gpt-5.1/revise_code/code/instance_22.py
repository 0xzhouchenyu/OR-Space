import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    t1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    t2 = pd.read_csv(os.path.join(data_dir, "table_2.csv"))
    t3 = pd.read_csv(os.path.join(data_dir, "table_3.csv"))
    gp_params = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))

    df = t1.merge(t2, on="Product").merge(t3, on="Product")

    def get_param(name):
        return float(gp_params[gp_params["Parameter_Name"] == name]["Value"].iloc[0])

    prod_days = get_param("production_days")
    a1_watch_threshold = get_param("a1_watch_threshold")
    a1_deep_service_threshold = get_param("a1_deep_service_threshold")
    maintenance_penalty_watch = get_param("maintenance_penalty_watch")
    maintenance_penalty_deep = get_param("maintenance_penalty_deep")
    a1_quality_release_fee = get_param("a1_quality_release_fee")
    a1_deep_service_fee = get_param("a1_deep_service_fee")
    a1_priority_price_lift = get_param("a1_priority_price_lift")

    params = {
        "prod_days": prod_days,
        "a1_watch_threshold": a1_watch_threshold,
        "a1_deep_service_threshold": a1_deep_service_threshold,
        "maintenance_penalty_watch": maintenance_penalty_watch,
        "maintenance_penalty_deep": maintenance_penalty_deep,
        "a1_quality_release_fee": a1_quality_release_fee,
        "a1_deep_service_fee": a1_deep_service_fee,
        "a1_priority_price_lift": a1_priority_price_lift,
    }

    return df, params

def solve():
    df, params = load_data()

    model = gp.Model("Revised_Production_Planning")
    model.setParam('OutputFlag', 0)

    products = df["Product"].tolist()

    # Decision variables
    x = {p: model.addVar(lb=0.0, name=f"x_{p}") for p in products}
    # Activation variables kept for structural similarity (though requirement forces production of all products)
    y = {p: model.addVar(vtype=GRB.BINARY, name=f"y_{p}") for p in products}

    # Piecewise structure for A1 watch / deep service thresholds
    # x_A1 is split into:
    #   x1: units up to watch threshold
    #   x2: units between watch and deep thresholds
    #   x3: units above deep threshold
    # Priority price lift applies to x2 and x3
    # Additional binary variables for thresholds:
    #   z_watch = 1 if x_A1 >= watch_threshold (quality crew booked)
    #   z_deep  = 1 if x_A1 >= deep_threshold  (deep service booked)
    # With z_deep <= z_watch
    p_a1 = "A1"
    x1 = model.addVar(lb=0.0, name="x1_A1_watch_band")
    x2 = model.addVar(lb=0.0, name="x2_A1_watch_to_deep_band")
    x3 = model.addVar(lb=0.0, name="x3_A1_above_deep_band")

    z_watch = model.addVar(vtype=GRB.BINARY, name="z_watch")
    z_deep = model.addVar(vtype=GRB.BINARY, name="z_deep")

    # Parameters for A1 thresholds
    W = params["a1_watch_threshold"]
    D = params["a1_deep_service_threshold"]
    L = params["a1_priority_price_lift"]

    # Link x_A1 to band variables: x_A1 = x1 + x2 + x3
    model.addConstr(x[p_a1] == x1 + x2 + x3, name="A1_band_sum")

    # Band upper bounds with threshold binaries (big-M like but tight)
    # x1 <= W
    model.addConstr(x1 <= W, name="A1_band1_cap")

    # x2 <= (D-W)*z_watch
    model.addConstr(x2 <= (D - W) * z_watch, name="A1_band2_cap")

    # x3 <= (MaxDemand - D)*z_deep
    max_demand_a1 = float(df[df["Product"] == p_a1]["Maximum_Demand"].iloc[0])
    model.addConstr(x3 <= (max_demand_a1 - D) * z_deep, name="A1_band3_cap")

    # Logical relationship: deep implies watch
    model.addConstr(z_deep <= z_watch, name="A1_deep_implies_watch")

    # Gate constraints for thresholds:
    # If z_watch = 1, x_A1 >= W; if 0, x_A1 <= W-1 (or W)
    # Implement as:
    #   x_A1 >= W * z_watch
    #   x_A1 <= W - epsilon + (max_demand - W + epsilon)*z_watch
    epsilon = 1e-3
    model.addConstr(x[p_a1] >= W * z_watch, name="A1_watch_lb")
    model.addConstr(
        x[p_a1] <= (W - epsilon) + (max_demand_a1 - W + epsilon) * z_watch,
        name="A1_watch_ub_logic"
    )

    # Similarly for deep threshold:
    #   x_A1 >= D * z_deep
    #   x_A1 <= D - epsilon + (max_demand - D + epsilon)*z_deep
    model.addConstr(x[p_a1] >= D * z_deep, name="A1_deep_lb")
    model.addConstr(
        x[p_a1] <= (D - epsilon) + (max_demand_a1 - D + epsilon) * z_deep,
        name="A1_deep_ub_logic"
    )

    # Production of all three products must occur (as in original heuristic)
    for p in products:
        model.addConstr(y[p] == 1, name=f"must_produce_{p}")

    # Demand and minimum batch constraints
    for _, row in df.iterrows():
        p = row["Product"]
        max_d = float(row["Maximum_Demand"])
        min_batch = float(row["Minimum_Batch"])

        model.addConstr(x[p] <= max_d * y[p], name=f"max_demand_{p}")
        model.addConstr(x[p] >= min_batch * y[p], name=f"min_batch_{p}")

    # Production days constraint with maintenance penalties
    prod_days = params["prod_days"]
    maintenance_penalty_watch = params["maintenance_penalty_watch"]
    maintenance_penalty_deep = params["maintenance_penalty_deep"]

    # Sum over products of (x_p / quota_p) <= prod_days - penalties
    lhs = 0
    for _, row in df.iterrows():
        p = row["Product"]
        quota = float(row["Production_Quota"])
        lhs += x[p] / quota

    effective_days = prod_days - maintenance_penalty_watch * z_watch - maintenance_penalty_deep * z_deep
    model.addConstr(lhs <= effective_days, name="production_days")

    # Objective: maximize profit with A1 priority uplift and fees
    # Base profit: sum_p ( (price - cost) * x_p - activation_cost * y_p )
    profit_expr = 0
    for _, row in df.iterrows():
        p = row["Product"]
        price = float(row["Selling_Price"])
        cost = float(row["Production_Cost"])
        act_cost = float(row["Activation_Cost"])
        profit_expr += (price - cost) * x[p] - act_cost * y[p]

    # Add uplift for A1 units above watch threshold:
    # Uplift applies to x2 + x3
    profit_expr += L * (x2 + x3)

    # Subtract watch and deep service fees
    a1_quality_release_fee = params["a1_quality_release_fee"]
    a1_deep_service_fee = params["a1_deep_service_fee"]

    profit_expr -= a1_quality_release_fee * z_watch
    profit_expr -= a1_deep_service_fee * z_deep

    model.setObjective(profit_expr, GRB.MAXIMIZE)

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")

if __name__ == "__main__":
    solve()
