import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(script_dir, "data", "general_parameters.csv")
    params = load_general_parameters(data_path)

    motorcycle_pollution = params['motorcycle_pollution']
    small_truck_pollution = params['small_truck_pollution']
    large_truck_pollution = params['large_truck_pollution']
    max_motorcycle_trips = int(params['max_motorcycle_trips'])
    motorcycle_capacity = params['motorcycle_capacity']
    small_truck_capacity = params['small_truck_capacity']
    large_truck_capacity = params['large_truck_capacity']
    max_total_trips = int(params['max_total_trips'])

    demand_peak_units = params['demand_peak_units']
    demand_offpeak_units = params['demand_offpeak_units']

    leasing_capacity = params['leasing_capacity']
    leasing_pollution_per_unit = params['leasing_pollution_per_unit']
    leasing_fixed_pollution = params['leasing_fixed_pollution']
    max_leasing_fraction_peak = params['max_leasing_fraction_peak']
    bigM_leasing = params['bigM_leasing']
    epsilon = params['epsilon']

    methods = ['motorcycle', 'small_truck', 'large_truck']

    capacity = {
        'motorcycle': motorcycle_capacity,
        'small_truck': small_truck_capacity,
        'large_truck': large_truck_capacity
    }

    pollution = {
        'motorcycle': motorcycle_pollution,
        'small_truck': small_truck_pollution,
        'large_truck': large_truck_pollution
    }

    try:
        model = gp.Model("Revised_Transport")
        model.setParam('OutputFlag', 0)

        # Decision variables
        trips_peak = {
            m: model.addVar(vtype=GRB.INTEGER, name=f"trips_peak_{m}", lb=0)
            for m in methods
        }
        trips_offpeak = {
            m: model.addVar(vtype=GRB.INTEGER, name=f"trips_offpeak_{m}", lb=0)
            for m in methods
        }

        # Method selection (at most 2 active methods day-wide)
        y = {
            m: model.addVar(vtype=GRB.BINARY, name=f"y_{m}")
            for m in methods
        }

        # Leasing variables
        leasing_peak = model.addVar(vtype=GRB.CONTINUOUS, name="leasing_peak", lb=0)
        leasing_offpeak = model.addVar(vtype=GRB.CONTINUOUS, name="leasing_offpeak", lb=0)
        leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")

        fixed_leasing_pollution = model.addVar(vtype=GRB.CONTINUOUS, name="fixed_leasing_pollution", lb=0)

        model.update()

        # Objective: minimize total pollution
        obj_expr = gp.quicksum(
            pollution[m] * (trips_peak[m] + trips_offpeak[m])
            for m in methods
        )
        obj_expr += leasing_pollution_per_unit * (leasing_peak + leasing_offpeak)
        obj_expr += fixed_leasing_pollution

        model.setObjective(obj_expr, GRB.MINIMIZE)

        # Constraints

        # Capacity per period meets demand
        model.addConstr(
            gp.quicksum(capacity[m] * trips_peak[m] for m in methods) + leasing_peak
            >= demand_peak_units,
            name="peak_demand"
        )

        model.addConstr(
            gp.quicksum(capacity[m] * trips_offpeak[m] for m in methods) + leasing_offpeak
            >= demand_offpeak_units,
            name="offpeak_demand"
        )

        # Max total trips across both periods
        model.addConstr(
            gp.quicksum(trips_peak[m] + trips_offpeak[m] for m in methods)
            <= max_total_trips,
            name="max_total_trips"
        )

        # Motorcycle trip limit across both periods
        model.addConstr(
            trips_peak['motorcycle'] + trips_offpeak['motorcycle']
            <= max_motorcycle_trips,
            name="max_motorcycle_trips"
        )

        # Limit to at most 2 active owned methods
        model.addConstr(
            gp.quicksum(y[m] for m in methods) <= 2,
            name="max_two_methods"
        )

        bigM_trips = max_total_trips  # reasonable big-M for trips

        # Link method activity with trips (gatestyle)
        for m in methods:
            model.addConstr(
                trips_peak[m] + trips_offpeak[m] <= bigM_trips * y[m],
                name=f"trip_activation_{m}"
            )

        # Leasing capacity limit over the day
        model.addConstr(
            leasing_peak + leasing_offpeak <= leasing_capacity,
            name=" leasing_capacity_limit"
        )

        # Leasing gate: total leasing linked with leasing_used binary
        model.addConstr(
            leasing_peak + leasing_offpeak <= bigM_leasing * leasing_used,
            name="leasing_bigM_upper"
        )
        model.addConstr(
            leasing_peak + leasing_offpeak >= epsilon * leasing_used,
            name="leasing_bigM_lower"
        )

        # Fixed pollution only if leasing used
        model.addConstr(
            fixed_leasing_pollution >= leasing_fixed_pollution * leasing_used,
            name="fixed_leasing_pollution_lower"
        )
        model.addConstr(
            fixed_leasing_pollution <= leasing_fixed_pollution * leasing_used,
            name="fixed_leasing_pollution_upper"
        )

        # Peak leasing fraction limit
        model.addConstr(
            leasing_peak <= max_leasing_fraction_peak * demand_peak_units,
            name="max_leasing_fraction_peak"
        )

        model.optimize()

        if model.status == GRB.OPTIMAL:
            obj_val = model.objVal
        else:
            obj_val = float('nan')

        print(f"FINAL_OBJ_VALUE: {obj_val}")

    except gp.GurobiError:
        print("FINAL_OBJ_VALUE: nan")

if __name__ == "__main__":
    main()
