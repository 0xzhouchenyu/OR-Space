import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_processing_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "table_1.csv")
    batches = []
    proc_times = {}  # (batch, vat) -> duration (float)
    with open(filepath, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            b = int(row["Batch"])
            batches.append(b)
            proc_times[(b, 1)] = float(row["Vat_1_Time"])
            proc_times[(b, 2)] = float(row["Vat_2_Time"])
            proc_times[(b, 3)] = float(row["Vat_3_Time"])
    return batches, proc_times

def load_general_parameters():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(filepath, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row["parameter"]
            val = float(row["value"])
            params[key] = val
    return params

def main():
    batches, proc_times = load_processing_data()
    params = load_general_parameters()

    T = int(params["planning_horizon_T"])
    energy_cost = {
        1: params["energy_cost_v1"],
        2: params["energy_cost_v2"],
        3: params["energy_cost_v3"],
    }
    peak_multiplier = params["peak_energy_multiplier"]
    peak_cap = params["peak_energy_cap"]
    makespan_weight = params["makespan_weight"]
    energy_weight = params["energy_weight"]

    vats = [1, 2, 3]
    periods = list(range(1, T + 1))
    peak_periods = [6, 7, 8]

    # Round up processing times to integers
    p = {}
    for b in batches:
        for v in vats:
            p[b, v] = int(math.ceil(proc_times[b, v]))

    # Precompute feasible start times respecting horizon and maintenance
    S = {}
    for b in batches:
        for v in vats:
            S[b, v] = []
            dur = p[b, v]
            for t in periods:
                if t + dur - 1 > T:
                    continue
                # Maintenance for Vat 2: no occupation in periods 4-5
                if v == 2:
                    occupied = range(t, t + dur)
                    if any(tp in [4, 5] for tp in occupied):
                        continue
                S[b, v].append(t)

    m = gp.Model("dyeing_schedule")
    m.setParam('OutputFlag', 0)

    # Variables
    # x[b,v,t]: batch b starts on vat v at time t
    x = m.addVars(
        [(b, v, t) for b in batches for v in vats for t in S[b, v]],
        vtype=GRB.BINARY,
        name="x",
    )

    # y[v,t]: vat v active in period t
    y = m.addVars(vats, periods, vtype=GRB.BINARY, name="y")

    # Makespan
    Cmax = m.addVar(vtype=GRB.CONTINUOUS, name="Cmax")

    # Each batch must be processed exactly once on each vat
    for b in batches:
        for v in vats:
            m.addConstr(gp.quicksum(x[b, v, t] for t in S[b, v]) == 1,
                        name=f"one_start_b{b}_v{v}")

    # Flow-shop precedence: Vat 1 -> Vat 2 -> Vat 3
    # Completion time on vat v: sum_t (t-1 + p[b,v]) * x[b,v,t]
    # Start on next vat must be >= completion on previous vat
    for b in batches:
        for (v_prev, v_next) in [(1, 2), (2, 3)]:
            # completion_prev = Σ t_prev x[b,v_prev,t_prev] * (t_prev - 1 + p[b,v_prev])
            completion_prev = gp.quicksum(
                (t_prev - 1 + p[b, v_prev]) * x[b, v_prev, t_prev]
                for t_prev in S[b, v_prev]
            )
            # start_next = Σ t_next x[b,v_next,t_next] * t_next
            start_next = gp.quicksum(
                t_next * x[b, v_next, t_next]
                for t_next in S[b, v_next]
            )
            m.addConstr(start_next >= completion_prev,
                        name=f"precedence_b{b}_v{v_prev}_to_v{v_next}")

    # Vat capacity: at most one batch at a time, link to y[v,t]
    for v in vats:
        for tau in periods:
            # batches occupying vat v at tau
            occupiers = []
            for b in batches:
                dur = p[b, v]
                for t in S[b, v]:
                    if t <= tau <= t + dur - 1:
                        occupiers.append((b, v, t))
            if occupiers:
                m.addConstr(gp.quicksum(x[idx] for idx in occupiers) <= 1,
                            name=f"capacity_v{v}_t{tau}")
                # Link to activity y[v,t]
                m.addConstr(y[v, tau] >= gp.quicksum(x[idx] for idx in occupiers),
                            name=f"link_y_v{v}_t{tau}")
            else:
                m.addConstr(y[v, tau] == 0, name=f"no_activity_v{v}_t{tau}")

    # Maintenance window on Vat 2 is already enforced via feasible S[b,2],
    # but ensure vat cannot be active in 4-5
    for tau in [4, 5]:
        m.addConstr(y[2, tau] == 0, name=f"maintenance_v2_t{tau}")

    # Makespan definition: last completion on Vat 3
    for b in batches:
        comp_b3 = gp.quicksum(
            (t - 1 + p[b, 3]) * x[b, 3, t]
            for t in S[b, 3]
        )
        m.addConstr(Cmax >= comp_b3, name=f"makespan_b{b}")

    # Energy cost calculation
    total_energy_cost = gp.LinExpr()
    peak_energy_usage = gp.LinExpr()

    for v in vats:
        for tau in periods:
            cost = energy_cost[v]
            if tau in peak_periods:
                cost *= peak_multiplier
                peak_energy_usage += cost * y[v, tau]
            total_energy_cost += cost * y[v, tau]

    # Peak energy cap
    m.addConstr(peak_energy_usage <= peak_cap, name="peak_energy_cap")

    # Objective
    m.setObjective(
        makespan_weight * Cmax + energy_weight * total_energy_cost,
        GRB.MINIMIZE
    )

    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
