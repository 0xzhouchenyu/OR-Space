import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            if ':' in value_str:
                params[name + '_raw'] = value_str
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_parameters(data_path)

    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_hours = params['machine_working_time']
    machine_working_time_minutes = machine_working_time_hours * 60

    ratio_A, ratio_B = params['production_ratio_A_to_B']  # stored as (5,2)

    max_overtime_hours = params['max_overtime_hours']
    overtime_penalty_per_hour = params['overtime_penalty_per_hour']
    overtime_review_threshold_hours = params['overtime_review_threshold_hours']
    overtime_review_fee = params['overtime_review_fee']

    senior_threshold = params['product_A_senior_batch_threshold']
    senior_fee = params['product_A_senior_batch_fee']

    max_overtime_minutes = max_overtime_hours * 60
    overtime_review_threshold_minutes = overtime_review_threshold_hours * 60

    model = gp.Model("Revised_Product_Mix")
    model.setParam('OutputFlag', 0)

    # Decision variables
    A = model.addVar(name="Product_A", lb=0, vtype=GRB.CONTINUOUS)
    B = model.addVar(name="Product_B", lb=0, vtype=GRB.CONTINUOUS)

    overtime = model.addVar(name="Overtime_Minutes", lb=0, ub=max_overtime_minutes, vtype=GRB.CONTINUOUS)
    z_review = model.addVar(name="Overtime_Review_Indicator", vtype=GRB.BINARY)
    z_senior = model.addVar(name="Senior_Fee_Indicator", vtype=GRB.BINARY)

    model.update()

    # Machine time with overtime
    model.addConstr(
        assembly_time_A * A + assembly_time_B * B <= machine_working_time_minutes + overtime,
        name="Machine_Time_With_Overtime"
    )

    # Overtime review gate: if overtime > threshold then z_review = 1, else can be 0
    M_overtime = max_overtime_minutes
    model.addConstr(overtime - overtime_review_threshold_minutes <= M_overtime * z_review,
                    name="Overtime_Review_Upper")
    model.addConstr(overtime - overtime_review_threshold_minutes >= 1e-6 - M_overtime * (1 - z_review),
                    name="Overtime_Review_Lower")

    # Production ratio: at least 2 units of B for every 5 units of A
    # B >= (ratio_B/ratio_A) * A  => ratio_B * A - ratio_A * B <= 0
    model.addConstr(ratio_B * A - ratio_A * B <= 0, name="Production_Ratio")

    # Senior-assembler fee gate: if A > threshold then z_senior = 1, else can be 0
    M_A = 1e6
    model.addConstr(A - senior_threshold <= M_A * z_senior, name="Senior_Fee_Upper")
    model.addConstr(A - senior_threshold >= 1e-6 - M_A * (1 - z_senior), name="Senior_Fee_Lower")

    # Objective: maximize profit minus overtime costs and fees
    profit_expr = profit_A * A + profit_B * B
    overtime_cost_expr = (overtime / 60.0) * overtime_penalty_per_hour
    review_fee_expr = overtime_review_fee * z_review
    senior_fee_expr = senior_fee * z_senior

    model.setObjective(profit_expr - overtime_cost_expr - review_fee_expr - senior_fee_expr, GRB.MAXIMIZE)

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
