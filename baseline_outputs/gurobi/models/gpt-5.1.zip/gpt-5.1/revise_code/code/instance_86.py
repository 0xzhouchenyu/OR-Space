import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    data = []
    with open(filepath, 'r', newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load data
    products = load_csv_data(os.path.join(data_dir, "table_1.csv"))
    params_raw = load_csv_data(os.path.join(data_dir, "general_parameters.csv"))

    # Parse general parameters
    params = {}
    for row in params_raw:
        params[row["Parameter_Name"]] = float(row["Value"])

    max_grains = params["max_grains"]
    price_grains = params["price_per_lb_grains"]
    max_meat = params["max_meat"]
    price_meat = params["price_per_lb_meat"]
    line_fixed_cost = params["line_fixed_cost"]
    line_capacity_packs = params["line_capacity_packs"]
    min_batch_packs = params["min_batch_packs"]
    min_yummies = params["min_yummies"]
    rebate_yummies_threshold = params["retailer_rebate_yummies_threshold"]
    rebate_min_meaties = params["retailer_rebate_min_meaties"]
    retailer_rebate_fixed = params["retailer_rebate_fixed"]

    # Parse product data
    product_data = {}
    for row in products:
        name = row["Product"]
        product_data[name] = {
            "price": float(row["Price_per_pack"]),
            "grains": float(row["Grains_per_pack"]),
            "meat": float(row["Meat_per_pack"]),
            "variable_cost": float(row["Variable_cost_per_pack"]),
            "capacity": float(row["Production_capacity"]) if row["Production_capacity"].strip() else None
        }

    m = product_data["Meaties"]
    y = product_data["Yummies"]

    # Profit per pack excluding line-level costs and rebates
    profit_meaties = m["price"] - m["variable_cost"] - (m["grains"] * price_grains + m["meat"] * price_meat)
    profit_yummies = y["price"] - y["variable_cost"] - (y["grains"] * price_grains + y["meat"] * price_meat)

    # Build Gurobi model
    model = gp.Model("HealthyPetFoods_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables: number of packs produced
    x_meaties = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="Meaties")
    x_yummies = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="Yummies")

    # Binary variable: whether co-packing line is active
    line_active = model.addVar(vtype=GRB.BINARY, name="line_active")

    # Binary variable: whether retailer rebate is earned
    rebate_earned = model.addVar(vtype=GRB.BINARY, name="rebate_earned")

    # Constraints

    # Ingredient limits
    model.addConstr(m["grains"] * x_meaties + y["grains"] * x_yummies <= max_grains, name="Grains_Constraint")
    model.addConstr(m["meat"] * x_meaties + y["meat"] * x_yummies <= max_meat, name="Meat_Constraint")

    # Meaties production capacity
    if m["capacity"] is not None:
        model.addConstr(x_meaties <= m["capacity"], name="Meaties_Capacity")

    # Shared co-packing line capacity when active
    model.addConstr(x_meaties + x_yummies <= line_capacity_packs * line_active, name="Line_Capacity")

    # Minimum combined batch size if line is active
    model.addConstr(x_meaties + x_yummies >= min_batch_packs * line_active, name="Min_Batch_if_Active")

    # Yummies minimum production commitment if line is active
    model.addConstr(x_yummies >= min_yummies * line_active, name="Min_Yummies_if_Active")

    # Rebate gating constraints
    # Use big-M values based on maximum possible production (bounded by line capacity and ingredient limits)
    # For safety, use line_capacity_packs as an upper bound for each product
    M_meaties = line_capacity_packs
    M_yummies = line_capacity_packs

    # If rebate_earned = 1, enforce thresholds; if 0, allow below thresholds
    model.addConstr(x_yummies >= rebate_yummies_threshold * rebate_earned, name="Rebate_Yummies_Min")
    model.addConstr(x_yummies <= rebate_yummies_threshold + M_yummies * (1 - rebate_earned), name="Rebate_Yummies_Upper")
    model.addConstr(x_meaties >= rebate_min_meaties * rebate_earned, name="Rebate_Meaties_Min")
    model.addConstr(x_meaties <= rebate_min_meaties + M_meaties * (1 - rebate_earned), name="Rebate_Meaties_Upper")

    # Ensure rebate can only be earned if line is active
    model.addConstr(rebate_earned <= line_active, name="Rebate_only_if_line_active")

    # Objective: maximize profit
    # Profit = per-pack profit * volume - line fixed cost (if active) + retailer rebate (if earned)
    total_profit = (profit_meaties * x_meaties +
                    profit_yummies * x_yummies -
                    line_fixed_cost * line_active +
                    retailer_rebate_fixed * rebate_earned)

    model.setObjective(total_profit, GRB.MAXIMIZE)

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
