import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])

    warehouse_capacity = int(params["warehouse_capacity"])
    initial_stock = int(params["initial_stock"])
    fixed_order_cost = float(params["fixed_order_cost"])
    august_bulk_order_threshold = float(params["august_bulk_order_threshold"])
    august_bulk_receiving_fee = float(params["august_bulk_receiving_fee"])

    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row["Month"])
            months.append(m)
            buy_price[m] = float(row["Buy"])
            sell_price[m] = float(row["Sell"])

    months.sort()

    # Create Gurobi model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)

    # Decision variables
    buy = {m: model.addVar(lb=0.0, name=f"buy_{m}") for m in months}
    sell = {m: model.addVar(lb=0.0, name=f"sell_{m}") for m in months}
    stock = {
        m: model.addVar(lb=0.0, ub=warehouse_capacity, name=f"stock_{m}")
        for m in months
    }

    # Binary variables for fixed order cost per month
    y = {
        m: model.addVar(vtype=GRB.BINARY, name=f"order_indicator_{m}")
        for m in months
    }

    # August special receiving slot indicator
    aug_bulk = model.addVar(vtype=GRB.BINARY, name="aug_bulk")

    # Objective: maximize total profit (revenue - costs)
    # Revenue from selling
    revenue = gp.quicksum(sell_price[m] * sell[m] for m in months)

    # Purchasing cost
    purchase_cost = gp.quicksum(buy_price[m] * buy[m] for m in months)

    # Fixed order cost per month if any purchase is made
    fixed_costs = gp.quicksum(fixed_order_cost * y[m] for m in months)

    # August bulk receiving fee (one-time)
    bulk_fee = august_bulk_receiving_fee * aug_bulk

    model.setObjective(revenue - purchase_cost - fixed_costs - bulk_fee, GRB.MAXIMIZE)

    # Constraints

    # Stock balance and warehouse capacity after buying (before selling)
    for i, m in enumerate(months):
        if i == 0:
            prev_stock_expr = initial_stock
        else:
            prev_stock_expr = stock[months[i - 1]]

        # stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(
            stock[m] == prev_stock_expr + buy[m] - sell[m],
            name=f"balance_{m}"
        )

        # After buying, before selling, warehouse constraint:
        # prev_stock + buy[m] <= warehouse_capacity
        model.addConstr(
            prev_stock_expr + buy[m] <= warehouse_capacity,
            name=f"warehouse_after_buy_{m}"
        )

    # Link buy and monthly fixed order indicator y[m]
    # Use a big-M equal to warehouse capacity (cannot buy more than capacity)
    M = warehouse_capacity
    for m in months:
        # If y[m] = 0 then buy[m] = 0; if buy[m] > 0 then y[m] = 1
        model.addConstr(buy[m] <= M * y[m], name=f"link_buy_y_{m}")

    # August bulk receiving gate:
    # If buy_8 > august_bulk_order_threshold then aug_bulk = 1, else 0.
    # Implement with big-M inequalities:
    # buy_8 <= threshold + M*(aug_bulk)
    # buy_8 >= threshold + epsilon - M*(1 - aug_bulk)
    # Use epsilon small positive; choose 1e-5 but adjusted to units.
    august_month = 8
    if august_month in months:
        M_aug = warehouse_capacity
        epsilon = 1e-3

        model.addConstr(
            buy[august_month] <= august_bulk_order_threshold + M_aug * aug_bulk,
            name="aug_upper_gate"
        )

        model.addConstr(
            buy[august_month] >= august_bulk_order_threshold + epsilon - M_aug * (1 - aug_bulk),
            name="aug_lower_gate"
        )
    else:
        # If for some reason month 8 not present, aug_bulk must be 0
        model.addConstr(aug_bulk == 0, name="no_aug_month")

    # Optimize
    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
