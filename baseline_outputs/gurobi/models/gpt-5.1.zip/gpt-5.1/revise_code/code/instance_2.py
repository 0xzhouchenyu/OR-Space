import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params


def main():
    # Locate data file
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")

    params = load_parameters(data_path)

    a1 = params['a1']
    a2 = params['a2']
    training_capacity = params['training_capacity_per_jet']
    training_duration = params['training_duration']  # not used explicitly but kept for completeness
    dual_eff = params['dual_use_training_efficiency']
    intensity_cap = params['training_intensity_cap']
    combat_min_y2 = params['combat_jet_min_year2']
    combat_weight = params['combat_weight']
    training_weight = params['training_weight']

    # Total jets each year (assuming no retirement and production adds to fleet)
    total_y1 = a1
    total_y2 = a1 + a2

    # Model
    m = gp.Model("fighter_jets_revised")
    m.setParam('OutputFlag', 0)

    # Decision variables:
    # For each year t in {1,2}, split fleet into training-only (T_t),
    # dual-use (D_t), and combat-only (C_t)
    T1 = m.addVar(lb=0, ub=total_y1, vtype=GRB.CONTINUOUS, name="T1")
    D1 = m.addVar(lb=0, ub=total_y1, vtype=GRB.CONTINUOUS, name="D1")
    C1 = m.addVar(lb=0, ub=total_y1, vtype=GRB.CONTINUOUS, name="C1")

    T2 = m.addVar(lb=0, ub=total_y2, vtype=GRB.CONTINUOUS, name="T2")
    D2 = m.addVar(lb=0, ub=total_y2, vtype=GRB.CONTINUOUS, name="D2")
    C2 = m.addVar(lb=0, ub=total_y2, vtype=GRB.CONTINUOUS, name="C2")

    # Fleet balance each year
    m.addConstr(T1 + D1 + C1 == total_y1, name="fleet_balance_y1")
    m.addConstr(T2 + D2 + C2 == total_y2, name="fleet_balance_y2")

    # Training intensity cap per year
    m.addConstr(T1 + D1 <= intensity_cap * total_y1, name="intensity_cap_y1")
    m.addConstr(T2 + D2 <= intensity_cap * total_y2, name="intensity_cap_y2")

    # Year-2 combat requirement (dual-use counts as combat-capable)
    m.addConstr(C2 + D2 >= combat_min_y2, name="combat_min_y2")

    # Training output
    pilots_y1 = training_capacity * (T1 + dual_eff * D1)
    pilots_y2 = training_capacity * (T2 + dual_eff * D2)
    total_pilots = pilots_y1 + pilots_y2

    # Combat jets in year 2 (combat-only plus dual-use)
    combat_jets_y2 = C2 + D2

    # Objective: weighted sum of year-2 combat jets and total trained pilots
    m.setObjective(combat_weight * combat_jets_y2 + training_weight * total_pilots,
                   GRB.MAXIMIZE)

    m.optimize()

    if m.status == GRB.OPTIMAL:
        obj_val = m.objVal
    else:
        obj_val = float('nan')

    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
