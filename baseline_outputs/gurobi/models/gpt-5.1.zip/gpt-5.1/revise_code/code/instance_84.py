import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Load candidate data
    candidates = []
    table_path = os.path.join(base_dir, "data", "table_1.csv")
    with open(table_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': float(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': float(row['Work_Experience'].strip())
            })

    # Load general parameters
    params = {}
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = params['min_manager_experience']
    manager_bonus_per_candidate = params['manager_bonus_per_candidate']

    # Build model
    m = gp.Model("Recruitment")
    m.setParam('OutputFlag', 0)

    cand_names = [c['name'] for c in candidates]

    # Decision variables
    x = m.addVars(cand_names, vtype=GRB.BINARY, name="x")
    manager = m.addVars(cand_names, vtype=GRB.BINARY, name="manager")
    specialist = m.addVars(cand_names, vtype=GRB.BINARY, name="specialist")

    # Objective: minimize total salary + manager bonuses
    base_cost = gp.quicksum(c['salary'] * x[c['name']] for c in candidates)
    manager_cost = manager_bonus_per_candidate * gp.quicksum(manager[c['name']] for c in candidates)
    m.setObjective(base_cost + manager_cost, GRB.MINIMIZE)

    # Linking: each hired candidate has exactly one role; non-hired have none
    for c in cand_names:
        m.addConstr(manager[c] + specialist[c] == x[c], name=f"role_link_{c}")

    # Constraint: total employees
    m.addConstr(gp.quicksum(x[c] for c in cand_names) <= max_employees, "max_employees")
    m.addConstr(gp.quicksum(x[c] for c in cand_names) >= min_employees, "min_employees")

    # Budget on base salaries only
    m.addConstr(
        gp.quicksum(next(cc['salary'] for cc in candidates if cc['name'] == c) * x[c] for c in cand_names)
        <= budget_limit,
        "budget_limit"
    )

    # At least one advanced degree (Master's or Doctoral)
    advanced = [c['name'] for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    if advanced:
        m.addConstr(gp.quicksum(x[c] for c in advanced) >= min_advanced, "min_advanced_degree")

    # Minimum total work experience (all hires)
    m.addConstr(
        gp.quicksum(next(cc['experience'] for cc in candidates if cc['name'] == c) * x[c] for c in cand_names)
        >= min_experience,
        "min_total_experience"
    )

    # At most one from pair A and E
    if 'A' in cand_names and 'E' in cand_names:
        m.addConstr(x['A'] + x['E'] <= max_equivalent, "equivalent_A_E")

    # Manager headcount limits
    m.addConstr(gp.quicksum(manager[c] for c in cand_names) >= min_managers, "min_managers")
    m.addConstr(gp.quicksum(manager[c] for c in cand_names) <= max_managers, "max_managers")

    # Minimum total experience of hired managers
    m.addConstr(
        gp.quicksum(
            next(cc['experience'] for cc in candidates if cc['name'] == c) * manager[c]
            for c in cand_names
        ) >= min_manager_experience,
        "min_manager_experience"
    )

    # Solve
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
