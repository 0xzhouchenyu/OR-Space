import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    table_1_path = os.path.join(data_dir, "table_1.csv")

    # Read general parameters
    params = {}
    with open(params_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('Parameter_Name'):
                continue
            parts = line.split(',')
            params[parts[0]] = ','.join(parts[1:-2]) if len(parts) > 4 else parts[1]

    num_customers = int(params['num_customers'])
    truck_capacity = float(params['truck_capacity'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])

    depot_str = params.get('depot_coordinates', '(40 50)').strip('()"')
    depot_str = depot_str.strip('()')
    if ',' in depot_str:
        depot_x, depot_y = map(float, depot_str.split(','))
    else:
        depot_x, depot_y = map(float, depot_str.split())

    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])

    # Read customer data
    coords = [(depot_x, depot_y)]
    demands = [0.0]
    tw = [(depot_tw_start, depot_tw_end)]
    service = [0.0]
    outsource_cost = [0.0]
    mandatory_external = [0]

    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((float(row['Coordinates_X']), float(row['Coordinates_Y'])))
            demands.append(float(row['Demand']))
            tw.append((float(row['Time_Window_Start']), float(row['Time_Window_End'])))
            service.append(float(row['Service_Duration']))
            outsource_cost.append(float(row['Outsource_Cost']))
            mandatory_external.append(int(row['Mandatory_External']))

    n = len(coords)          # including depot 0
    N = list(range(1, n))    # customers
    V = list(range(n))       # all nodes including depot

    # Distance matrix
    dist = {}
    for i in V:
        for j in V:
            dist[i, j] = calculate_distance(coords[i], coords[j])

    # Build feasible arc set based on time-window reachability (same logic as heuristic)
    A = []
    for i in V:
        for j in V:
            if i == j:
                continue
            if i != 0 and j != 0:
                if tw[i][0] + service[i] + dist[i, j] > tw[j][1]:
                    continue
            if i == 0 and j != 0:
                if tw[0][0] + dist[0, j] > tw[j][1]:
                    continue
            if i != 0 and j == 0:
                if tw[i][0] + service[i] + dist[i, 0] > tw[0][1]:
                    continue
            A.append((i, j))
    A_set = set(A)

    # Create model
    m = gp.Model("VRPHTW_with_outsourcing")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # x[i,j] = 1 if in-house route uses arc (i,j)
    x = m.addVars(A, vtype=GRB.BINARY, name="x")
    # t[i] service start time at node i (only relevant if served in-house, but defined for all)
    t = m.addVars(V, vtype=GRB.CONTINUOUS, lb=0.0, name="t")
    # y[i] = 1 if customer i is served by in-house truck; 0 if outsourced
    y = m.addVars(N, vtype=GRB.BINARY, name="y")

    # Objective: minimize in-house travel distance + outsourcing cost
    inhouse_travel = gp.quicksum(dist[i, j] * x[i, j] for (i, j) in A)
    outsourcing = gp.quicksum(outsource_cost[i] * (1 - y[i]) for i in N)
    m.setObjective(inhouse_travel + outsourcing, GRB.MINIMIZE)

    # Fleet size limit: number of routes from depot cannot exceed inhouse_truck_limit
    m.addConstr(gp.quicksum(x[0, j] for j in N if (0, j) in A_set) <= inhouse_truck_limit, name="fleet_limit")

    # Flow conservation and linking with y
    for i in N:
        # Exactly one "service mode": if y[i]=1, exactly one incoming-arc; if y[i]=0, none
        m.addConstr(gp.quicksum(x[j, i] for j in V if (j, i) in A_set) == y[i], name=f"in_flow_{i}")
        m.addConstr(gp.quicksum(x[i, j] for j in V if (i, j) in A_set) == y[i], name=f"out_flow_{i}")

    # Depot flow: every in-house route starts and ends at depot
    m.addConstr(
        gp.quicksum(x[0, j] for j in N if (0, j) in A_set) ==
        gp.quicksum(x[i, 0] for i in N if (i, 0) in A_set),
        name="depot_flow_balance"
    )

    # Time windows for customers served in-house
    for i in N:
        m.addConstr(t[i] >= tw[i][0] * y[i], name=f"tw_lb_{i}")
        # if y[i]=0, t[i] is unconstrained on upper bound except by this inequality,
        # so we bound it by customer TW end to keep it reasonable
        m.addConstr(t[i] <= tw[i][1], name=f"tw_ub_{i}")

    # Depot time window
    m.addConstr(t[0] >= tw[0][0], name="depot_tw_lb")
    m.addConstr(t[0] <= tw[0][1], name="depot_tw_ub")

    # Big-M time propagation constraints
    M_val = tw[0][1] + max(service)
    for (i, j) in A:
        if j == 0:
            # arrival back at depot also within depot window when arc used
            m.addConstr(
                t[i] + service[i] + dist[i, j] <= tw[0][1] + M_val * (1 - x[i, j]),
                name=f"time_back_depot_{i}_{j}"
            )
        else:
            # standard time propagation
            m.addConstr(
                t[i] + service[i] + dist[i, j] - t[j] <= M_val * (1 - x[i, j]),
                name=f"time_prop_{i}_{j}"
            )

    # Capacity constraints: any connected customers on a truck must respect capacity
    # Here we keep the simple pairwise capacity surrogate from the heuristic
    for (i, j) in A:
        if i != 0 and j != 0:
            m.addConstr(
                demands[i] + demands[j] <= truck_capacity + truck_capacity * (1 - x[i, j]),
                name=f"cap_pair_{i}_{j}"
            )

    # Mandatory external customers cannot be served in-house
    for i in N:
        if mandatory_external[i] == 1:
            m.addConstr(y[i] == 0, name=f"mandatory_external_{i}")

    # Optimize
    m.optimize()

    if m.Status == GRB.OPTIMAL:
        obj_val = m.ObjVal
    else:
        obj_val = float('nan')

    print(f"FINAL_OBJ_VALUE: {obj_val:.2f}")

if __name__ == "__main__":
    main()
