import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    table1 = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))

    # Parse parameters into a dictionary
    param_dict = {row['Parameter_Name']: float(row['Value']) for row in params}

    # Parse table1
    proc_I = table1[0]
    proc_II = table1[1]
    profit_row = table1[2]

    a_I = float(proc_I['Model_A_hours_per_unit'])  # 4
    b_I = float(proc_I['Model_B_hours_per_unit'])  # 6
    cap_I = float(proc_I['Maximum_Weekly_Processing_Capacity'])  # 150

    a_II = float(proc_II['Model_A_hours_per_unit'])  # 3
    b_II = float(proc_II['Model_B_hours_per_unit'])  # 2
    cap_II = float(proc_II['Maximum_Weekly_Processing_Capacity'])  # 70

    profit_A = float(profit_row['Model_A_hours_per_unit'])  # 300
    profit_B = float(profit_row['Model_B_hours_per_unit'])  # 450

    min_profit = param_dict['min_weekly_profit']  # 10000
    min_A = param_dict['min_model_A_units']       # 10
    min_B = param_dict['min_model_B_units']       # 15
    proc_I_hours = param_dict['process_I_hours']  # 150
    max_overtime = param_dict['process_II_max_overtime']  # 30
    red_A = param_dict['model_A_overtime_profit_reduction']  # 20
    red_B = param_dict['model_B_overtime_profit_reduction']  # 25

    # Build model
    m = gp.Model("Microcomputer_Production_MarketShare")
    m.setParam('OutputFlag', 0)

    # Decision variables
    xA_r = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA_r")
    xA_o = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA_o")
    xB_r = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB_r")
    xB_o = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB_o")

    # Total units
    total_A = xA_r + xA_o
    total_B = xB_r + xB_o

    # Constraints

    # Process I exact hours usage
    m.addConstr(a_I * total_A + b_I * total_B == proc_I_hours, name="Process_I_exact")

    # Process II regular capacity
    m.addConstr(a_II * xA_r + b_II * xB_r <= cap_II, name="Process_II_regular_cap")

    # Process II overtime capacity
    m.addConstr(a_II * xA_o + b_II * xB_o <= max_overtime, name="Process_II_overtime_cap")

    # Minimum production (contract requirements)
    m.addConstr(total_A >= min_A, name="Min_A_units")
    m.addConstr(total_B >= min_B, name="Min_B_units")

    # Profit calculation
    total_profit = (
        profit_A * xA_r
        + profit_B * xB_r
        + (profit_A - red_A) * xA_o
        + (profit_B - red_B) * xB_o
    )

    # Minimum profit requirement
    m.addConstr(total_profit >= min_profit, name="Min_profit")

    # Objective: maximize total units produced (market share)
    m.setObjective(total_A + total_B, GRB.MAXIMIZE)

    # Optimize
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
