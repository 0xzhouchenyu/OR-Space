import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_demand(filepath):
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand


def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    demand = load_demand(os.path.join(base_dir, "data", "table_1.csv"))
    params = load_parameters(os.path.join(base_dir, "data", "general_parameters.csv"))

    shift_duration = int(params['shift_duration'])
    regular_pay = float(params['regular_nurse_pay'])
    contract_pay = float(params['contract_nurse_pay'])

    outsourced_regular_start_index = int(params['outsourced_regular_start_index'])
    banned_contract_start_index = int(params['banned_contract_start_index'])
    max_total_contract_starts = int(params['max_total_contract_starts'])
    min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])

    # daytime_period_indices stored as semicolon-separated indices
    daytime_period_indices = [int(i) for i in params['daytime_period_indices'].split(';')]

    num_periods = len(demand)        # 6 periods, each 4 hours
    periods_per_shift = shift_duration // 4  # 2 periods per shift

    # Create model
    model = gp.Model("RevisedNurseScheduling")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[j] - regular nurses starting at shift j
    # y[j] - contract nurses starting at shift j
    x = model.addVars(num_periods, vtype=GRB.INTEGER, name="x", lb=0)
    y = model.addVars(num_periods, vtype=GRB.INTEGER, name="y", lb=0)

    # Apply start restrictions:
    # Regular nurses cannot start at outsourced_regular_start_index
    x[outsourced_regular_start_index].ub = 0

    # Contract nurses cannot start at banned_contract_start_index
    y[banned_contract_start_index].ub = 0

    # Objective: minimize total cost = hours * pay * number of nurses
    model.setObjective(
        gp.quicksum((regular_pay * shift_duration) * x[j] +
                    (contract_pay * shift_duration) * y[j]
                    for j in range(num_periods)),
        GRB.MINIMIZE
    )

    # Coverage constraints for each period i
    for i in range(num_periods):
        # Shifts that cover period i: j and (j-1) mod num_periods
        covering_shifts = [(i) % num_periods, (i - 1) % num_periods]
        model.addConstr(
            gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i],
            name=f"TotalDemand_period_{i}"
        )

    # Daytime minimum regular coverage constraints
    for i in daytime_period_indices:
        covering_shifts = [(i) % num_periods, (i - 1) % num_periods]
        model.addConstr(
            gp.quicksum(x[j] for j in covering_shifts) >= min_regular_daytime_coverage,
            name=f"RegularDaytimeMin_period_{i}"
        )

    # Cap on total contract starts
    model.addConstr(
        gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts,
        name="MaxTotalContractStarts"
    )

    # Optimize
    model.optimize()

    final_obj = model.objVal
    print(f"FINAL_OBJ_VALUE: {final_obj}")


if __name__ == "__main__":
    main()
