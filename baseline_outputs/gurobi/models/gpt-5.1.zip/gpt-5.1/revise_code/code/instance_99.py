import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    return rows

def load_general_parameters():
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_reliability_table():
    rows = load_csv('table_1.csv')
    reliability = {}
    for row in rows:
        n_spares = int(row['Number_of_Spares'])
        r1 = float(row['Component_1_Reliability'])
        r2 = float(row['Component_2_Reliability'])
        r3 = float(row['Component_3_Reliability'])
        reliability[n_spares] = [r1, r2, r3]
    return reliability

def main():
    # Load data
    params = load_general_parameters()
    reliability = load_reliability_table()

    # Extract parameters
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]

    total_budget_A = params['total_budget_scenario_A']
    total_budget_B = params['total_budget_scenario_B']
    weight_limit_A = params['weight_limit_scenario_A']
    weight_limit_B = params['weight_limit_scenario_B']

    # Sets
    components = range(3)  # 0,1,2 for components 1,2,3
    spares_set = range(6)  # 0..5

    # Precompute system reliability for each (s1,s2,s3)
    sys_rel = {}
    for s1 in spares_set:
        for s2 in spares_set:
            for s3 in spares_set:
                if s1 in reliability and s2 in reliability and s3 in reliability:
                    r1 = reliability[s1][0]
                    r2 = reliability[s2][1]
                    r3 = reliability[s3][2]
                    sys_rel[(s1, s2, s3)] = r1 * r2 * r3
                else:
                    sys_rel[(s1, s2, s3)] = 0.0

    # Build model
    m = gp.Model("revised_spare_allocation")
    m.setParam('OutputFlag', 0)

    # Decision variables: s_i integer in {0,..,5}
    s = m.addVars(components, vtype=GRB.INTEGER, lb=0, ub=5, name="s")

    # Auxiliary variable for system reliability (continuous)
    R = m.addVar(vtype=GRB.CONTINUOUS, lb=0.0, ub=1.0, name="R")

    # Constraints: budgets and weights must satisfy both scenarios
    total_cost = gp.quicksum(s[i] * unit_price[i] for i in components)
    total_weight = gp.quicksum(s[i] * unit_weight[i] for i in components)

    m.addConstr(total_cost <= total_budget_A, "budget_A")
    m.addConstr(total_cost <= total_budget_B, "budget_B")
    m.addConstr(total_weight <= weight_limit_A, "weight_A")
    m.addConstr(total_weight <= weight_limit_B, "weight_B")

    # Nonlinear relation R = product of reliabilities, linearized via enumeration
    # Use binary variables z[s1,s2,s3] selecting the spare combination; link to s[i]
    z = m.addVars(spares_set, spares_set, spares_set, vtype=GRB.BINARY, name="z")

    # Exactly one configuration chosen
    m.addConstr(gp.quicksum(z[s1, s2, s3] for s1 in spares_set for s2 in spares_set for s3 in spares_set) == 1, "one_config")

    # Link s[i] to selected configuration
    m.addConstr(s[0] == gp.quicksum(s1 * z[s1, s2, s3] for s1 in spares_set for s2 in spares_set for s3 in spares_set), "link_s1")
    m.addConstr(s[1] == gp.quicksum(s2 * z[s1, s2, s3] for s1 in spares_set for s2 in spares_set for s3 in spares_set), "link_s2")
    m.addConstr(s[2] == gp.quicksum(s3 * z[s1, s2, s3] for s1 in spares_set for s2 in spares_set for s3 in spares_set), "link_s3")

    # Define R as the system reliability of the chosen configuration
    m.addConstr(
        R == gp.quicksum(sys_rel[(s1, s2, s3)] * z[s1, s2, s3] for s1 in spares_set for s2 in spares_set for s3 in spares_set),
        "def_R"
    )

    # Objective: maximize expected reliability = R (since scenarios equal and same R)
    m.setObjective(R, GRB.MAXIMIZE)

    m.optimize()

    obj_val = m.objVal if m.status == GRB.OPTIMAL else 0.0
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
