import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")

    df = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)

    def get_param(name):
        return float(params[params['Parameter_Name'] == name]['Value'].iloc[0])

    total_budget = get_param('budget')
    food_intake = get_param('food_intake')           # per dinner, grams
    weekday_budget_share = get_param('weekday_budget_share')
    max_prep_time_weekday = get_param('max_prep_time_weekday')
    max_prep_time_weekend = get_param('max_prep_time_weekend')
    weekend_protein_ban = int(get_param('weekend_protein_ban'))
    veg_balance_penalty = get_param('veg_balance_penalty')

    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)

    foods = df['Food'].tolist()
    types = df.set_index('Food')['Type'].to_dict()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()

    proteins = [f for f in foods if types[f] == 'protein']
    vegetables = [f for f in foods if types[f] == 'vegetable']

    # Budget per dinner
    weekday_budget = weekday_budget_share * total_budget
    weekend_budget = (1 - weekday_budget_share) * total_budget

    # Model
    m = gp.Model("Two_Dinner_Fiber")
    m.setParam('OutputFlag', 0)

    # Amount variables: units of 100g
    x_w = m.addVars(foods, lb=0, name="x_w")
    x_e = m.addVars(foods, lb=0, name="x_e")

    # Selection indicators per dinner
    y_w = m.addVars(foods, vtype=GRB.BINARY, name="y_w")
    y_e = m.addVars(foods, vtype=GRB.BINARY, name="y_e")

    # Global label usage for proteins
    z_p = m.addVars(proteins, vtype=GRB.BINARY, name="z_p")

    # Veg balance deviation variables (for absolute value)
    d_plus = m.addVars(vegetables, lb=0, name="d_plus")
    d_minus = m.addVars(vegetables, lb=0, name="d_minus")

    # Total food intake constraints (convert grams to 100g units)
    total_units = food_intake / 100.0
    m.addConstr(gp.quicksum(x_w[f] for f in foods) == total_units, "weekday_intake")
    m.addConstr(gp.quicksum(x_e[f] for f in foods) == total_units, "weekend_intake")

    # Budget constraints
    m.addConstr(gp.quicksum(price[f] * x_w[f] for f in foods) <= weekday_budget, "weekday_budget")
    m.addConstr(gp.quicksum(price[f] * x_e[f] for f in foods) <= weekend_budget, "weekend_budget")
    m.addConstr(
        gp.quicksum(price[f] * (x_w[f] + x_e[f]) for f in foods) <= total_budget,
        "total_budget"
    )

    # Prep time constraints
    m.addConstr(gp.quicksum(prep_time[f] * x_w[f] for f in foods) <= max_prep_time_weekday, "weekday_prep")
    m.addConstr(gp.quicksum(prep_time[f] * x_e[f] for f in foods) <= max_prep_time_weekend, "weekend_prep")

    # Exactly one protein per dinner
    m.addConstr(gp.quicksum(y_w[f] for f in proteins) == 1, "weekday_one_protein")
    if weekend_protein_ban == 1:
        # No proteins allowed weekend
        m.addConstr(gp.quicksum(y_e[f] for f in proteins) == 0, "weekend_no_protein")
        # Also force quantities to zero
        for f in proteins:
            m.addConstr(x_e[f] == 0, f"weekend_protein_amount_zero_{f}")
    else:
        m.addConstr(gp.quicksum(y_e[f] for f in proteins) == 1, "weekend_one_protein")

    # At least two vegetables per dinner
    m.addConstr(gp.quicksum(y_w[f] for f in vegetables) >= 2, "weekday_veg_min2")
    m.addConstr(gp.quicksum(y_e[f] for f in vegetables) >= 2, "weekend_veg_min2")

    # Linking amount and selection with minimum inclusion 0.1 units
    M = total_units
    for f in foods:
        # Weekday
        m.addConstr(x_w[f] >= 0.1 * y_w[f], f"weekday_min_{f}")
        m.addConstr(x_w[f] <= M * y_w[f], f"weekday_max_{f}")
        # Weekend
        m.addConstr(x_e[f] >= 0.1 * y_e[f], f"weekend_min_{f}")
        m.addConstr(x_e[f] <= M * y_e[f], f"weekend_max_{f}")

    # Protein label usage consistency
    for p in proteins:
        m.addConstr(y_w[p] <= z_p[p], f"weekday_label_{p}")
        m.addConstr(y_e[p] <= z_p[p], f"weekend_label_{p}")
        m.addConstr(z_p[p] <= y_w[p] + y_e[p], f"label_used_{p}")

    # Vegetable balance deviations
    for v in vegetables:
        m.addConstr(x_w[v] - x_e[v] == d_plus[v] - d_minus[v], f"veg_balance_{v}")

    # Objective: maximize total fiber minus veg balance penalty
    total_fiber = (
        gp.quicksum(fiber[f] * x_w[f] for f in foods) +
        gp.quicksum(fiber[f] * x_e[f] for f in foods)
    )
    total_penalty = veg_balance_penalty * gp.quicksum(d_plus[v] + d_minus[v] for v in vegetables)

    m.setObjective(total_fiber - total_penalty, GRB.MAXIMIZE)

    m.optimize()

    obj_val = m.objVal if m.status == GRB.OPTIMAL else float('nan')
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
