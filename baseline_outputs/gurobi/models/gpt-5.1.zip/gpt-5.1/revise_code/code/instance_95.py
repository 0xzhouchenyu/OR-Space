import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_table_1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    weeks = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })
    return weeks

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')

    weeks_data = load_table_1(data_dir)
    params = load_general_parameters(data_dir)

    storage_cost = params['storage_cost_per_thousand_boxes']
    fixed_setup_cost = params['fixed_setup_cost']
    week2_push_threshold = params['week2_push_threshold']  # thousand boxes
    week3_capacity_loss_after_week2_push = params['week3_capacity_loss_after_week2_push']  # thousand boxes
    week2_microclean_threshold = params['week2_microclean_threshold']  # thousand boxes
    week2_microclean_fee = params['week2_microclean_fee']  # thousand yuan

    n_weeks = len(weeks_data)

    # Create model
    model = gp.Model("Revised_Beverage_Production_Planning")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[t] = production in week t (in thousand boxes)
    # s[t] = inventory at end of week t (in thousand boxes)
    x = {}
    s = {}
    y = {}   # setup binary: 1 if produce in week t
    for t in range(n_weeks):
        week = t + 1
        cap = weeks_data[t]['capacity']
        x[week] = model.addVar(lb=0.0, ub=cap, vtype=GRB.CONTINUOUS, name=f"x_{week}")
        s[week] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"s_{week}")
        y[week] = model.addVar(vtype=GRB.BINARY, name=f"y_{week}")

    # Week 2 push-related binary (for capacity loss in week 3)
    z_push = model.addVar(vtype=GRB.BINARY, name="z_push_week2")
    # Week 2 micro-clean binary
    z_micro = model.addVar(vtype=GRB.BINARY, name="z_micro_week2")

    model.update()

    # Big-M values (capacities are in thousand boxes)
    # For linking x and y: M_prod can be the actual capacity of each week
    for t in range(n_weeks):
        week = t + 1
        cap = weeks_data[t]['capacity']
        model.addConstr(x[week] <= cap * y[week], name=f"prod_setup_link_week{week}")

    # Inventory balance constraints
    for t in range(n_weeks):
        week = t + 1
        demand = weeks_data[t]['demand']
        if week == 1:
            model.addConstr(x[week] - s[week] == demand, name=f"balance_week{week}")
        else:
            model.addConstr(s[week - 1] + x[week] - s[week] == demand, name=f"balance_week{week}")

    # Week 2 push threshold and Week 3 capacity loss
    # z_push = 1 if x2 > week2_push_threshold
    # Implement with:
    # x2 - threshold <= M1 * z_push
    # x2 - threshold >= epsilon - M2 * (1 - z_push)
    # And week3 capacity reduced when z_push=1:
    # x3 <= base_cap3 - loss * z_push
    x2 = x[2]
    x3 = x[3]
    cap3_base = weeks_data[2]['capacity']
    threshold_push = week2_push_threshold
    loss3 = week3_capacity_loss_after_week2_push

    # Big-M for threshold logic
    # M can be the maximum possible production in week 2, i.e., capacity
    M_push = weeks_data[1]['capacity']
    epsilon = 1e-5

    # If z_push = 0 -> x2 <= threshold
    model.addConstr(x2 - threshold_push <= M_push * z_push, name="push_ub")
    # If z_push = 1 -> x2 >= threshold + epsilon (approximately > threshold)
    model.addConstr(x2 - threshold_push >= epsilon - M_push * (1 - z_push), name="push_lb")

    # Week 3 capacity adjustment
    model.addConstr(x3 <= cap3_base - loss3 * z_push, name="week3_cap_after_push")

    # Week 2 micro-clean threshold and fee
    # z_micro = 1 if x2 > week2_microclean_threshold
    threshold_micro = week2_microclean_threshold
    M_micro = weeks_data[1]['capacity']

    # If z_micro = 0 -> x2 <= threshold_micro
    model.addConstr(x2 - threshold_micro <= M_micro * z_micro, name="micro_ub")
    # If z_micro = 1 -> x2 >= threshold_micro + epsilon
    model.addConstr(x2 - threshold_micro >= epsilon - M_micro * (1 - z_micro), name="micro_lb")

    # Objective: production variable cost + storage cost + fixed setup costs + micro-clean fee
    prod_cost = gp.quicksum(weeks_data[t]['cost'] * x[t + 1] for t in range(n_weeks))
    inv_cost = gp.quicksum(storage_cost * s[t + 1] for t in range(n_weeks))
    setup_cost = gp.quicksum(fixed_setup_cost * y[t + 1] for t in range(n_weeks))
    micro_cost = week2_microclean_fee * z_micro

    model.setObjective(prod_cost + inv_cost + setup_cost + micro_cost, GRB.MINIMIZE)

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
