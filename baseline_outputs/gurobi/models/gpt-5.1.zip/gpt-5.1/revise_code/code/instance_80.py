import os
import csv
import gurobipy as gp
from gurobipy import GRB

# ---------- Data loading helpers ----------

def load_csv(filepath):
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

base_dir = os.path.dirname(os.path.abspath(__file__))

# Load parameters
params_rows = load_csv(os.path.join(base_dir, "data", "general_parameters.csv"))
params = {}
for row in params_rows:
    name = row['Parameter_Name']
    value = row['Value']
    try:
        if '.' in value:
            params[name] = float(value)
        else:
            params[name] = int(value)
    except ValueError:
        params[name] = value

# Extract parameters
skilled_wage = params['skilled_worker_weekly_wage']
laborer_wage = params['laborer_weekly_wage']
skilled_hours = params['skilled_worker_weekly_hours']
laborer_hours = params['laborer_weekly_hours']
max_skilled = params['max_skilled_workers']
max_laborers = params['max_laborers_workers'] if 'max_laborers_workers' in params else params['max_laborers']
min_skilled_task3_B = params['min_skilled_workers_task3_methodB']
skilled_hiring_ratio = params['skilled_worker_hiring_ratio']

# Task-level skilled share bands
min_share = {
    'Task_1': params['min_skilled_share_task1'],
    'Task_2': params['min_skilled_share_task2'],
    'Task_3': params['min_skilled_share_task3']
}
max_share = {
    'Task_1': params['max_skilled_share_task1'],
    'Task_2': params['max_skilled_share_task2'],
    'Task_3': params['max_skilled_share_task3']
}

# Load task-method data
tm_rows = load_csv(os.path.join(base_dir, "data", "table_1.csv"))
tasks = ['Task_1', 'Task_2', 'Task_3']
methods = ['Method_A', 'Method_B']

tm_data = {}
for row in tm_rows:
    tm_data[(row['Task'], row['Method'])] = {
        'Effective_Hours': float(row['Effective_Hours']),
        'Fixed_Cost': float(row['Fixed_Cost'])
    }

# ---------- Model ----------

model = gp.Model("WorkerAllocation")
model.setParam('OutputFlag', 0)

# Decision variables
y = model.addVars(tasks, methods, vtype=GRB.BINARY, name="y")
s = model.addVars(tasks, methods, lb=0.0, vtype=GRB.CONTINUOUS, name="s")
l = model.addVars(tasks, methods, lb=0.0, vtype=GRB.CONTINUOUS, name="l")

total_skilled = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="total_skilled")
total_laborers = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="total_laborers")

# Objective: minimize total cost
fixed_cost_expr = gp.quicksum(tm_data[(t, m)]['Fixed_Cost'] * y[t, m]
                              for t in tasks for m in methods)
model.setObjective(skilled_wage * total_skilled +
                   laborer_wage * total_laborers +
                   fixed_cost_expr, GRB.MINIMIZE)

# Total skilled / laborers definition
model.addConstr(total_skilled == gp.quicksum(s[t, m] for t in tasks for m in methods),
                name="TotalSkilledDef")
model.addConstr(total_laborers == gp.quicksum(l[t, m] for t in tasks for m in methods),
                name="TotalLaborersDef")

# Exactly one method per task
for t in tasks:
    model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1, name=f"OneMethod_{t}")

# Hours requirement and linking constraints
M_big = 10000.0
for t in tasks:
    for m in methods:
        req_hours = tm_data[(t, m)]['Effective_Hours']
        # Hours requirement
        model.addConstr(skilled_hours * s[t, m] +
                        laborer_hours * l[t, m] >= req_hours * y[t, m],
                        name=f"Hours_{t}_{m}")
        # Linking
        model.addConstr(s[t, m] <= M_big * y[t, m], name=f"LinkS_{t}_{m}")
        model.addConstr(l[t, m] <= M_big * y[t, m], name=f"LinkL_{t}_{m}")

# Max workforce constraints
model.addConstr(total_skilled <= max_skilled, name="MaxSkilled")
model.addConstr(total_laborers <= max_laborers, name="MaxLaborers")

# Overall skilled hiring ratio
model.addConstr(total_skilled <= skilled_hiring_ratio * total_laborers, name="SkilledRatio")

# Exclusion rule: Task 1 using Method B excludes Task 3 using Method A
model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1,
                name="ExclusionRule")

# Minimum skilled workers for Task 3 if Method B is chosen
model.addConstr(s['Task_3', 'Method_B'] >= min_skilled_task3_B * y['Task_3', 'Method_B'],
                name="MinSkilledTask3B")

# Task-level skilled share bands
# For each task, compute total skilled and total workers (skilled + laborers) across methods.
# Then impose: min_share_t <= (Skilled_t / TotalWorkers_t) <= max_share_t when task is staffed.
for t in tasks:
    # Total skilled and total workers for task t
    s_task = gp.quicksum(s[t, m] for m in methods)
    l_task = gp.quicksum(l[t, m] for m in methods)
    total_task_workers = s_task + l_task

    # Avoid division: min_share_t * total_task_workers <= s_task <= max_share_t * total_task_workers
    # Note: If total_task_workers = 0, these constraints reduce to 0 <= 0 and are trivially satisfied.
    model.addConstr(s_task >= min_share[t] * total_task_workers,
                    name=f"MinShare_{t}")
    model.addConstr(s_task <= max_share[t] * total_task_workers,
                    name=f"MaxShare_{t}")

# Solve
model.optimize()

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
