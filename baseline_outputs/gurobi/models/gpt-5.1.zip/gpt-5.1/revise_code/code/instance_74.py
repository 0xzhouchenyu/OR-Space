import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    precedences = []
    with open(os.path.join(data_dir, 'table_1.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))

    activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    dur = {a: int(params[f'activity_{a}_duration']) for a in activities}

    work_cost = params['work_cost_per_day']
    machine_cost = params['machine_rental_cost_per_day']

    # Overtime parameters for activity E
    e_ot_red = int(params.get('activity_E_overtime_reduction', 0))
    e_ot_cost = params.get('activity_E_overtime_cost', 0.0)
    e_followup_trigger = int(params.get('activity_E_followup_review_trigger', 0))
    e_followup_cost = params.get('activity_E_followup_review_cost', 0.0)

    # Model
    model = gp.Model("Project_Cost_Minimization_Revised")
    model.setParam('OutputFlag', 0)

    # Variables: start times
    S = {a: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"S_{a}") for a in activities}

    # Project completion time
    T = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="T")

    # Binary variable for using overtime on activity E
    y_E = model.addVar(vtype=GRB.BINARY, name="y_E_overtime")

    # Effective duration of E: dur_E_eff = dur_E - e_ot_red * y_E
    # Precedence constraints
    for pred, succ in precedences:
        if pred == 'E':
            # S_F >= S_E + dur_E_eff
            # S_F >= S_E + dur_E - e_ot_red * y_E
            model.addConstr(
                S[succ] >= S[pred] + dur['E'] - e_ot_red * y_E,
                name=f"prec_{pred}_{succ}"
            )
        else:
            model.addConstr(
                S[succ] >= S[pred] + dur[pred],
                name=f"prec_{pred}_{succ}"
            )

    # Project completion time constraints: T >= completion of C and B
    model.addConstr(T >= S['C'] + dur['C'], name="T_ge_C")
    model.addConstr(T >= S['B'] + dur['B'], name="T_ge_B")

    # Objective components:
    # Work cost: per day over project makespan T
    # Machine rental cost: same structure as original heuristic:
    # machine_cost * (S_B + dur_B - S_A)
    work_cost_term = work_cost * T
    machine_cost_term = machine_cost * (S['B'] + dur['B'] - S['A'])

    # Overtime + follow-up review cost if overtime is chosen (gate, one-time)
    overtime_total_cost = 0.0
    if e_ot_red > 0:
        overtime_total_cost += e_ot_cost
        if e_followup_trigger == 1:
            overtime_total_cost += e_followup_cost

    overtime_cost_term = overtime_total_cost * y_E

    model.setObjective(work_cost_term + machine_cost_term + overtime_cost_term, GRB.MINIMIZE)

    # Optimize
    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
