import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def main():
    # Load data
    table_path = get_data_path('table_3_3.csv')
    params_path = get_data_path('general_parameters.csv')

    df = pd.read_csv(table_path)
    params_df = pd.read_csv(params_path)

    # Extract parameters
    sales_goal = float(params_df.loc[params_df['Parameter_Name'] == 'monthly_sales_goal', 'Value'].values[0])
    pt_ft_ratio = float(params_df.loc[params_df['Parameter_Name'] == 'pt_ft_overtime_ratio', 'Value'].values[0])

    # Extract clerk data
    ft_row = df[df['Role'] == 'Full-time'].iloc[0]
    pt_row = df[df['Role'] == 'Part-time'].iloc[0]

    # Determine number of clerks (default to classic values if not provided)
    num_ft = 5
    num_pt = 4
    for col in df.columns:
        if any(kw in col.lower() for kw in ['num', 'clerks', 'employees', 'count', '人员', '数量']):
            num_ft = float(ft_row[col])
            num_pt = float(pt_row[col])
            break

    # Calculate normal sales from full employment of all sales clerks
    normal_sales_ft = num_ft * ft_row['Monthly_Working_Hours'] * ft_row['Sales_Volume_Pairs_Per_Hour']
    normal_sales_pt = num_pt * pt_row['Monthly_Working_Hours'] * pt_row['Sales_Volume_Pairs_Per_Hour']
    total_normal_sales = normal_sales_ft + normal_sales_pt

    # Build Gurobi model
    m = gp.Model("Minimize_Overtime")
    m.setParam('OutputFlag', 0)

    # Decision variables: overtime hours for full-time and part-time clerks
    y_ft = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="y_ft")
    y_pt = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="y_pt")

    # Objective: minimize total overtime hours
    m.setObjective(y_ft + y_pt, GRB.MINIMIZE)

    # Sales goal constraint including overtime contribution
    ft_sales_rate = float(ft_row['Sales_Volume_Pairs_Per_Hour'])
    pt_sales_rate = float(pt_row['Sales_Volume_Pairs_Per_Hour'])
    m.addConstr(
        y_ft * ft_sales_rate + y_pt * pt_sales_rate >= sales_goal - total_normal_sales,
        name="sales_goal"
    )

    # New dependency constraint: part-time overtime >= ratio * full-time overtime
    m.addConstr(
        y_pt >= pt_ft_ratio * y_ft,
        name="pt_ft_overtime_ratio"
    )

    # Optimize
    m.optimize()

    obj_val = m.objVal if m.status == GRB.OPTIMAL else float('nan')
    print(f"FINAL_OBJ_VALUE: {round(obj_val, 4)}")

if __name__ == "__main__":
    main()
