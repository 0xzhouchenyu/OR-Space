import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")

params = {}
with open(data_dir, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

produce = params['produce_to_transport']
horse_poll = params['horse_pollution_per_trip']
bike_poll = params['bicycle_pollution_per_trip']
cart_poll = params['handcart_pollution_per_trip']
max_poll = params['max_total_pollution']
min_horse = params['min_horse_trips']
horse_cap = params['horse_capacity_per_trip']
bike_cap = params['bicycle_capacity_per_trip']
cart_cap = params['handcart_capacity_per_trip']
min_produce = params['min_total_produce']

horse_cost_trip = params['horse_cost_per_trip']
bike_cost_trip = params['bicycle_cost_per_trip']
cart_cost_trip = params['handcart_cost_per_trip']
horse_fixed_cost = params['horse_fixed_cost']
bike_fixed_cost = params['bicycle_fixed_cost']
cart_fixed_cost = params['handcart_fixed_cost']
pollution_penalty = params['pollution_penalty_per_unit']
poll_threshold = params['horse_pollution_permit_threshold']
poll_fee = params['horse_pollution_permit_fee']

# Model
m = gp.Model("FarmTransportRevised")
m.setParam('OutputFlag', 0)

# Decision variables
x_horse = m.addVar(vtype=GRB.INTEGER, lb=0, name="horse_trips")
x_bike = m.addVar(vtype=GRB.INTEGER, lb=0, name="bike_trips")
x_cart = m.addVar(vtype=GRB.INTEGER, lb=0, name="cart_trips")

# Binary choice: 1 if bicycle chosen, 0 if handcart chosen
y_bike = m.addVar(vtype=GRB.BINARY, name="choose_bike")

# Binary usage indicators for fixed costs
z_horse = m.addVar(vtype=GRB.BINARY, name="use_horse")
z_bike = m.addVar(vtype=GRB.BINARY, name="use_bike")
z_cart = m.addVar(vtype=GRB.BINARY, name="use_cart")

# Binary for pollution permit fee (1 if pollution exceeds threshold)
z_permit = m.addVar(vtype=GRB.BINARY, name="pollution_permit_fee_indicator")

# Auxiliary variable for total pollution
total_pollution = m.addVar(vtype=GRB.CONTINUOUS, lb=0, name="total_pollution")

M = 10000

# Total pollution definition
m.addConstr(
    total_pollution == horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart,
    name="pollution_def"
)

# Must transport at least min_produce
m.addConstr(
    horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce,
    name="produce_requirement"
)

# Pollution constraint
m.addConstr(total_pollution <= max_poll, name="max_pollution")

# Minimum horse trips
m.addConstr(x_horse >= min_horse, name="min_horse_trips")

# Either bicycle or handcart, not both
m.addConstr(x_bike <= M * y_bike, name="bike_allowed_if_chosen")
m.addConstr(x_cart <= M * (1 - y_bike), name="cart_allowed_if_not_bike")

# Link usage binaries with trips
m.addConstr(x_horse <= M * z_horse, name="horse_use_link")
m.addConstr(x_bike <= M * z_bike, name="bike_use_link")
m.addConstr(x_cart <= M * z_cart, name="cart_use_link")

# Permit fee logic: pay fee if total_pollution > poll_threshold
# Implement with big-M:
m.addConstr(total_pollution - poll_threshold <= M * z_permit, name="permit_upper")
m.addConstr(total_pollution - poll_threshold >= 1 - M * (1 - z_permit), name="permit_lower")

# Objective: total monetary cost
variable_cost = (
    horse_cost_trip * x_horse +
    bike_cost_trip * x_bike +
    cart_cost_trip * x_cart
)

fixed_cost = (
    horse_fixed_cost * z_horse +
    bike_fixed_cost * z_bike +
    cart_fixed_cost * z_cart
)

pollution_cost = pollution_penalty * total_pollution

permit_cost = poll_fee * z_permit

m.setObjective(variable_cost + fixed_cost + pollution_cost + permit_cost, GRB.MINIMIZE)

m.optimize()

obj_val = m.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
