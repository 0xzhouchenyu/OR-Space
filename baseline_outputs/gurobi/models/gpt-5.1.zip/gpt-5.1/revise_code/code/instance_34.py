import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_goods_data(filepath):
    goods = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            goods[row['Goods_Type'].strip()] = {
                'quantity': int(row['Quantity'].strip()),
                'weight': float(row['Weight_per_Unit'].strip())
            }
    return goods

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    goods = load_goods_data(os.path.join(data_dir, "table_1.csv"))
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

    max_cap = params['max_container_capacity']
    min_load = params['min_container_load']
    min_d_per_container = int(params['min_d_goods_per_container'])
    min_c_per_a = int(params['min_c_per_a'])

    goods_types = list(goods.keys())
    quantities = {g: goods[g]['quantity'] for g in goods_types}
    weights = {g: goods[g]['weight'] for g in goods_types}

    # Upper bound on number of containers (generic generous bound)
    total_weight = sum(quantities[g] * weights[g] for g in goods_types)
    max_containers = int(total_weight // min_load) + 5
    if max_containers < 1:
        max_containers = 1

    N = range(max_containers)

    model = gp.Model("RevisedContainerMinimization")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {(g, j): model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{g}_{j}")
         for g in goods_types for j in N}
    y = {j: model.addVar(vtype=GRB.BINARY, name=f"y_{j}") for j in N}
    # Indicator for presence of A
    zA = {j: model.addVar(vtype=GRB.BINARY, name=f"zA_{j}") for j in N}
    # Indicator for presence of E
    zE = {j: model.addVar(vtype=GRB.BINARY, name=f"zE_{j}") for j in N}

    model.update()

    # Objective: minimize number of containers
    model.setObjective(gp.quicksum(y[j] for j in N), GRB.MINIMIZE)

    # All goods must be transported
    for g in goods_types:
        model.addConstr(gp.quicksum(x[g, j] for j in N) == quantities[g],
                        name=f"demand_{g}")

    # Container load and capacity constraints
    for j in N:
        total_weight_j = gp.quicksum(weights[g] * x[g, j] for g in goods_types)

        # Minimum load if container used
        model.addConstr(total_weight_j >= min_load * y[j], name=f"min_load_{j}")

        # Capacity constraints depending on presence of E
        # Base constraint: cannot exceed global max_cap
        model.addConstr(total_weight_j <= max_cap * y[j], name=f"max_cap_{j}")

        # Reduced capacity if E is present: total_weight <= 45 when zE=1
        # Implement via: total_weight_j <= 45 + M*(1 - zE[j])
        M_cap = max_cap  # safe upper bound on weight
        model.addConstr(total_weight_j <= 45 + M_cap * (1 - zE[j]),
                        name=f"cap_E_{j}")

    # Minimum D goods per container (if container is used)
    for j in N:
        model.addConstr(x['D', j] >= min_d_per_container * y[j],
                        name=f"min_D_{j}")

    # If A goods are loaded, at least 1 C good must be loaded
    M_A = quantities['A']
    for j in N:
        # zA[j] indicates presence of A
        model.addConstr(x['A', j] <= M_A * zA[j], name=f"A_indicator_{j}")
        model.addConstr(x['C', j] >= min_c_per_a * zA[j], name=f"C_if_A_{j}")

    # Link zE[j] to presence of E in container j
    M_E = quantities['E']
    for j in N:
        model.addConstr(x['E', j] <= M_E * zE[j], name=f"E_indicator_upper_{j}")
        # If zE[j]=1 then at least 1 unit of E
        model.addConstr(x['E', j] >= zE[j], name=f"E_indicator_lower_{j}")

    # Ensure containers used if they contain any goods
    for j in N:
        bigM_qty = sum(quantities[g] for g in goods_types)
        model.addConstr(gp.quicksum(x[g, j] for g in goods_types) <= bigM_qty * y[j],
                        name=f"use_if_goods_{j}")

    # Symmetry breaking: enforce ordering on y
    for j in range(max_containers - 1):
        model.addConstr(y[j] >= y[j + 1], name=f"symmetry_{j}")

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
