import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    params = {}
    with open(params_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = row["Value"].strip()
            params[name] = float(val)

    # Extract parameters
    milk_per_barrel = params["milk_per_barrel"]          # 1 barrel per unit of milk
    a1_yield = params["product_A1_yield"]                # kg per barrel
    a2_yield = params["product_A2_yield"]
    a3_yield = params["product_A3_yield"]
    a1_time = params["product_A1_time"]                  # hours per barrel
    a2_time = params["product_A2_time"]
    a3_time = params["product_A3_time"]
    profit_a1 = params["profit_per_kg_A1"]
    profit_a2 = params["profit_per_kg_A2"]
    profit_a3 = params["profit_per_kg_A3"]
    milk_supply = params["daily_milk_supply"]
    labor_hours = params["daily_labor_hours"]
    cap_A_shared = params["cap_A_shared"]                # shared A1/A3 capacity (kg)
    min_A2_kg = params["min_A2_kg"]
    min_A3_kg = params["min_A3_kg"]
    cleaning_loss = params["type_A_cleaning_loss_if_A3"]
    bonus_threshold = params["cold_chain_bonus_threshold_kg"]
    bonus_amount = params["cold_chain_bonus_yuan"]

    # Profit per barrel
    profit_per_barrel_a1 = a1_yield * profit_a1
    profit_per_barrel_a2 = a2_yield * profit_a2
    profit_per_barrel_a3 = a3_yield * profit_a3

    # Big-M for bonus indicator
    # Upper bound on A3 kg: limited by milk & labor; choose conservative M
    # Max barrels by milk
    max_barrels_milk = milk_supply / milk_per_barrel
    # Max barrels by labor if all labor on A3
    max_barrels_labor = labor_hours / a3_time if a3_time > 0 else max_barrels_milk
    max_barrels_a3 = min(max_barrels_milk, max_barrels_labor)
    max_a3_kg = max_barrels_a3 * a3_yield
    M = max_a3_kg if max_a3_kg > bonus_threshold else bonus_threshold * 2.0

    # Build model
    m = gp.Model("Dairy_Production_Revised")
    m.setParam('OutputFlag', 0)

    # Decision variables: barrels for each product
    x1 = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="x1")  # barrels to A1
    x2 = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="x2")  # barrels to A2
    x3 = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="x3")  # barrels to A3

    # Indicator for bonus
    z_bonus = m.addVar(vtype=GRB.BINARY, name="z_bonus")

    # Objective: base profit + bonus
    base_profit = (
        profit_per_barrel_a1 * x1 +
        profit_per_barrel_a2 * x2 +
        profit_per_barrel_a3 * x3
    )
    m.setObjective(base_profit + bonus_amount * z_bonus, GRB.MAXIMIZE)

    # Constraints

    # Milk supply: each barrel uses milk_per_barrel units; milk_per_barrel is 1
    m.addConstr(
        milk_per_barrel * (x1 + x2 + x3) <= milk_supply,
        name="Milk_Supply"
    )

    # Labor hours
    m.addConstr(
        a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours,
        name="Labor_Hours"
    )

    # Type A shared capacity (A1 and A3) with cleaning loss if A3>0
    # a1_yield * x1 + a3_yield * x3 + cleaning_loss * y <= cap_A_shared
    # We don't know if A3 is produced from data alone, so we use bonus indicator as a surrogate
    # Introduce y_clean as binary if A3>0; here reuse z_bonus? No, A3 could be produced < threshold.
    # So define separate indicator:
    y_clean = m.addVar(vtype=GRB.BINARY, name="y_clean")

    # Link y_clean with x3 (A3 barrels)
    # If x3 > 0 then y_clean = 1; standard big-M:
    m.addConstr(x3 <= M * y_clean, name="Link_clean_upper")
    # To encourage y_clean=1 when x3>0, we can add x3 >= epsilon * y_clean, but epsilon can be small.
    epsilon = 1e-6
    m.addConstr(x3 >= epsilon * y_clean, name="Link_clean_lower")

    # Capacity constraint with cleaning loss
    m.addConstr(
        a1_yield * x1 + a3_yield * x3 + cleaning_loss * y_clean <= cap_A_shared,
        name="Type_A_Shared_Capacity"
    )

    # Minimum A2 production in kg
    m.addConstr(
        a2_yield * x2 >= min_A2_kg,
        name="Min_A2_Production"
    )

    # Minimum A3 production in kg
    m.addConstr(
        a3_yield * x3 >= min_A3_kg,
        name="Min_A3_Production"
    )

    # Cold-chain bonus threshold constraint using z_bonus
    # If z_bonus = 1 then A3_kg >= threshold; if 0 then A3_kg can be anything
    # Implement with:
    # A3_kg >= threshold * z_bonus
    # A3_kg <= threshold + (M - threshold) * z_bonus  (optional upper tie)
    m.addConstr(
        a3_yield * x3 >= bonus_threshold * z_bonus,
        name="Bonus_LB"
    )
    m.addConstr(
        a3_yield * x3 <= bonus_threshold + (M - bonus_threshold) * z_bonus,
        name="Bonus_UB"
    )

    # Optimize
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
