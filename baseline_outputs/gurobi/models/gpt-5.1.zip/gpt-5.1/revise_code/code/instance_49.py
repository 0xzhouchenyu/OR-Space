import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def solve():
    # Load data
    table_1 = pd.read_csv(get_data_path('table_1.csv'))
    table_2 = pd.read_csv(get_data_path('table_2.csv'))
    params = pd.read_csv(get_data_path('general_parameters.csv'))

    # Parse parameters
    def get_param(name, cast=float):
        v = params.loc[params['Parameter_Name'] == name, 'Value'].values[0]
        return cast(v)

    min_contract_types = get_param('min_contract_types', int)
    max_contract_types = get_param('max_contract_types', int)
    mutual_exclusion = str(get_param('mutual_exclusion_1_and_4')).strip().lower() == 'true'
    monthly_max_parallel_contracts = get_param('monthly_max_parallel_contracts', int)
    min_area_per_contract_units = get_param('min_area_per_contract_units', float)
    activation_fee_per_contract = get_param('activation_fee_per_contract', float)
    onboarding_loss_units = get_param('onboarding_loss_units', float)
    expedited_onboarding_fee = get_param('expedited_onboarding_fee', float)

    # Demands in 100 sqm units
    demands = {int(row['Month']): float(row['Required_area_㎡']) / 100.0
               for _, row in table_1.iterrows()}

    # Rental cost per 100 sqm
    costs = {int(row['Contract_length_months']): float(row['Rental_fee_per_100㎡_yuan'])
             for _, row in table_2.iterrows()}

    months = sorted(demands.keys())
    max_month = max(months)
    lengths = sorted(costs.keys())

    # Build feasible (start, length) pairs
    starts = months
    starts_lengths = [(i, j) for i in starts for j in lengths if i + j - 1 <= max_month]

    # Create model
    model = gp.Model("Warehouse_Rental_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[i,j]: 100-sqm units rented under a contract starting at i of length j
    x = model.addVars(starts_lengths, vtype=GRB.INTEGER, name="x", lb=0)

    # z[i,j]: 1 if contract (i,j) is active (has positive capacity), 0 otherwise
    z = model.addVars(starts_lengths, vtype=GRB.BINARY, name="z")

    # e[i,j]: 1 if expedited onboarding is bought for contract (i,j)
    e = model.addVars(starts_lengths, vtype=GRB.BINARY, name="e")

    # y[j]: 1 if at least one contract of length j is used
    y = model.addVars(lengths, vtype=GRB.BINARY, name="y")

    # Objective: rental cost + activation fees + onboarding fees
    model.setObjective(
        gp.quicksum(costs[j] * x[i, j] for (i, j) in starts_lengths) +
        gp.quicksum(activation_fee_per_contract * z[i, j] for (i, j) in starts_lengths) +
        gp.quicksum(expedited_onboarding_fee * e[i, j] for (i, j) in starts_lengths),
        GRB.MINIMIZE
    )

    # Constraints

    # Link x and z, enforce minimum area per active contract
    bigM_area = sum(demands.values())  # upper bound on any x[i,j]
    for (i, j) in starts_lengths:
        model.addConstr(x[i, j] <= bigM_area * z[i, j], name=f"x_le_Mz_{i}_{j}")
        model.addConstr(x[i, j] >= min_area_per_contract_units * z[i, j], name=f"x_ge_min_{i}_{j}")

    # Demand fulfillment with onboarding loss
    for m in months:
        # Contracts covering month m
        covering_pairs = [(i, j) for (i, j) in starts_lengths if i <= m <= i + j - 1]
        expr = gp.LinExpr()
        for (i, j) in covering_pairs:
            if m == i:
                # Start month: lose onboarding_loss_units if not expedited
                expr += x[i, j] - onboarding_loss_units * (z[i, j] - e[i, j])
            else:
                expr += x[i, j]
        model.addConstr(expr == demands[m], name=f"demand_{m}")

    # Monthly maximum parallel contracts (count of active contracts)
    for m in months:
        active_pairs = [(i, j) for (i, j) in starts_lengths if i <= m <= i + j - 1]
        model.addConstr(
            gp.quicksum(z[i, j] for (i, j) in active_pairs) <= monthly_max_parallel_contracts,
            name=f"max_parallel_{m}"
        )

    # At most max_contract_types distinct contract lengths, at least min_contract_types
    for j in lengths:
        # y[j] = 1 if any contract of length j is active
        model.addConstr(
            gp.quicksum(z[i, j] for i in starts if (i, j) in z) <= bigM_area * y[j],
            name=f"y_upper_{j}"
        )
        model.addConstr(
            gp.quicksum(z[i, j] for i in starts if (i, j) in z) >= y[j],
            name=f"y_lower_{j}"
        )

    model.addConstr(gp.quicksum(y[j] for j in lengths) >= min_contract_types, name="min_contract_types")
    model.addConstr(gp.quicksum(y[j] for j in lengths) <= max_contract_types, name="max_contract_types")

    # Mutual exclusion between 1-month and 4-month contracts
    if mutual_exclusion and 1 in lengths and 4 in lengths:
        model.addConstr(y[1] + y[4] <= 1, name="mutual_exclusion_1_4")

    # Solve
    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    solve()
