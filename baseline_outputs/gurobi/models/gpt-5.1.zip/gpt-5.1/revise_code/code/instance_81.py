import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_car_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    cars = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            i = int(row['i'])
            length = float(row['lambda_i'])
            cars[i] = length
    return cars

def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'])
            params[name] = value
    return params

def main():
    # Determine data directory relative to this script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load data
    cars = load_car_data(data_dir)
    params = load_parameters(data_dir)

    max_length_one_side = params['max_length_one_side']
    available_party_side_count = int(params.get('available_party_side_count', 1))

    car_ids = list(cars.keys())
    lengths = cars

    # Build model
    model = gp.Model("ParkingSingleSide")
    model.setParam('OutputFlag', 0)

    # Decision variables:
    # y_i = 1 if car i is parked on the usable side, 0 if not parked (since only one side is allowed)
    y = model.addVars(car_ids, vtype=GRB.BINARY, name="y")

    # Objective: minimize total occupied length on the single usable side
    total_length = gp.quicksum(lengths[i] * y[i] for i in car_ids)
    model.setObjective(total_length, GRB.MINIMIZE)

    # Constraint: only one side available for party cars (resident-access rule)
    # This is encoded conceptually: no second-side variables exist.
    # Length limit on the usable side:
    model.addConstr(total_length <= max_length_one_side, name="max_length_single_side")

    # If business logic required all cars to be parked, enforce that here.
    # With one side only, this becomes a feasibility check under the length cap.
    model.addConstr(gp.quicksum(y[i] for i in car_ids) == len(car_ids), name="all_cars_must_park")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        obj_val = float('nan')

    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
