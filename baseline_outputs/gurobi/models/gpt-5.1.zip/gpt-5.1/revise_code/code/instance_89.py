import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params


def main():
    # Load data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_general_parameters(data_path)

    # Extract parameters
    profit_A = params['profit_per_kg_product_A']
    profit_B = params['profit_per_kg_product_B']

    max_hours_w1 = params['max_production_hours_week_1']
    max_hours_w2 = params['max_production_hours_week_2']

    hours_A = params['hours_per_kg_product_A']
    hours_B = params['hours_per_kg_product_B']

    min_ratio_B_to_A = params['min_output_ratio_product_B_to_A']
    storage_ratio_A_to_B = params['storage_space_ratio_product_A_to_B']

    max_storage_A_equiv_w1 = params['max_storage_product_A_equiv_week_1']
    max_storage_A_equiv_w2 = params['max_storage_product_A_equiv_week_2']

    init_inv_A = params['initial_inventory_A']
    init_inv_B = params['initial_inventory_B']

    hold_cost_A = params['storage_cost_per_kg_A']
    hold_cost_B = params['storage_cost_per_kg_B']

    promo_bonus_A = params['promo_profit_bonus_A']
    promo_bonus_B = params['promo_profit_bonus_B']

    max_promos_A = params['max_promotions_product_A']
    max_promos_B = params['max_promotions_product_B']

    # Derived storage capacities in "space units"
    cap_w1 = max_storage_A_equiv_w1 * storage_ratio_A_to_B
    cap_w2 = max_storage_A_equiv_w2 * storage_ratio_A_to_B

    # Sets: weeks = {1,2}
    weeks = [1, 2]

    # Model
    m = gp.Model("TwoWeek_Liquid_Products")
    m.setParam('OutputFlag', 0)

    # Decision variables
    prod_A = m.addVars(weeks, name="prod_A", lb=0.0)
    prod_B = m.addVars(weeks, name="prod_B", lb=0.0)

    sales_A = m.addVars(weeks, name="sales_A", lb=0.0)
    sales_B = m.addVars(weeks, name="sales_B", lb=0.0)

    inv_A = m.addVars([0, 1, 2], name="inv_A", lb=0.0)
    inv_B = m.addVars([0, 1, 2], name="inv_B", lb=0.0)

    promo_A = m.addVars(weeks, vtype=GRB.BINARY, name="promo_A")
    promo_B = m.addVars(weeks, vtype=GRB.BINARY, name="promo_B")

    # Initial inventory
    m.addConstr(inv_A[0] == init_inv_A, name="InitInvA")
    m.addConstr(inv_B[0] == init_inv_B, name="InitInvB")

    # Inventory balance and production time per week
    for w in weeks:
        # Production time constraints
        if w == 1:
            m.addConstr(hours_A * prod_A[w] + hours_B * prod_B[w] <= max_hours_w1,
                        name=f"ProdTime_w{w}")
        else:
            m.addConstr(hours_A * prod_A[w] + hours_B * prod_B[w] <= max_hours_w2,
                        name=f"ProdTime_w{w}")

        # Inventory balance: inv_{w-1} + prod_w - sales_w = inv_w
        m.addConstr(inv_A[w - 1] + prod_A[w] - sales_A[w] == inv_A[w],
                    name=f"InvBal_A_w{w}")
        m.addConstr(inv_B[w - 1] + prod_B[w] - sales_B[w] == inv_B[w],
                    name=f"InvBal_B_w{w}")

        # Cannot sell more than available (inventory + production)
        m.addConstr(sales_A[w] <= inv_A[w - 1] + prod_A[w],
                    name=f"SalesCap_A_w{w}")
        m.addConstr(sales_B[w] <= inv_B[w - 1] + prod_B[w],
                    name=f"SalesCap_B_w{w}")

        # Market demand ratio per week: sales_B >= 3 * sales_A
        m.addConstr(sales_B[w] >= min_ratio_B_to_A * sales_A[w],
                    name=f"MarketDemand_w{w}")

        # Storage capacity per week (applies to end-of-week inventory)
        if w == 1:
            m.addConstr(storage_ratio_A_to_B * inv_A[w] + inv_B[w] <= cap_w1,
                        name=f"StorageCap_w{w}")
        else:
            m.addConstr(storage_ratio_A_to_B * inv_A[w] + inv_B[w] <= cap_w2,
                        name=f"StorageCap_w{w}")

    # Optional: can allow end-of-horizon inventory; no additional constraint specified

    # Promotion limits (over two weeks)
    m.addConstr(gp.quicksum(promo_A[w] for w in weeks) <= max_promos_A,
                name="MaxPromosA")
    m.addConstr(gp.quicksum(promo_B[w] for w in weeks) <= max_promos_B,
                name="MaxPromosB")

    # Objective: profit from sales (including promo bonuses) minus holding cost of inv at end of week 1
    total_profit = gp.LinExpr()

    for w in weeks:
        # base profit
        total_profit += profit_A * sales_A[w]
        total_profit += profit_B * sales_B[w]
        # promo incremental profit
        # Using linearization: bonus * sales_w * promo_w (binary -> active only if promo=1)
        total_profit += promo_bonus_A * sales_A[w] * promo_A[w]
        total_profit += promo_bonus_B * sales_B[w] * promo_B[w]

    # Holding cost from end of week 1 to week 2
    total_profit -= hold_cost_A * inv_A[1]
    total_profit -= hold_cost_B * inv_B[1]

    m.setObjective(total_profit, GRB.MAXIMIZE)

    # Optimize
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
