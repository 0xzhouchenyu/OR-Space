import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = load_parameters(data_path)

    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']

    base_a = params['base_fleet_type_a']
    base_b = params['base_fleet_type_b']
    pen_a = params['penalty_cost_type_a']
    pen_b = params['penalty_cost_type_b']

    b_thresh = params['type_b_recovery_threshold']
    b_fee = params['type_b_recovery_fee']

    tot_thresh = params['total_fleet_surge_threshold']
    tot_fee = params['total_fleet_surge_fee']

    # Upper bounds for trucks for big-Ms
    # Simple safe upper bound from capacity requirements (ceil)
    max_trucks_a = max(ref_req / rc_a if rc_a > 0 else 0,
                       nonref_req / nc_a if nc_a > 0 else 0) + base_a + 100
    max_trucks_b = max(ref_req / rc_b if rc_b > 0 else 0,
                       nonref_req / nc_b if nc_b > 0 else 0) + base_b + 100
    max_trucks_a = int(max_trucks_a)
    max_trucks_b = int(max_trucks_b)
    max_total_trucks = max_trucks_a + max_trucks_b

    m = gp.Model("RevisedTruckRental")
    m.setParam('OutputFlag', 0)

    # Decision variables
    x = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_trucks_a, name="TypeA_trucks")
    y = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_trucks_b, name="TypeB_trucks")

    # Excess over base fleets (nonnegative continuous)
    excess_a = m.addVar(vtype=GRB.CONTINUOUS, lb=0, name="ExcessA")
    excess_b = m.addVar(vtype=GRB.CONTINUOUS, lb=0, name="ExcessB")

    # Gate binaries
    z_b = m.addVar(vtype=GRB.BINARY, name="TypeB_Recovery_Triggered")
    z_tot = m.addVar(vtype=GRB.BINARY, name="Total_Fleet_Surge_Triggered")

    # Constraints: cargo requirements
    m.addConstr(rc_a * x + rc_b * y >= ref_req, name="RefrigeratedRequirement")
    m.addConstr(nc_a * x + nc_b * y >= nonref_req, name="NonRefrigeratedRequirement")

    # Excess over base fleets
    # x - base_a <= excess_a
    m.addConstr(x - base_a <= excess_a, name="ExcessA_ge")
    # excess_a >= 0 already by lb, and cannot exceed max_trucks_a
    m.addConstr(excess_a <= max_trucks_a, name="ExcessA_ub")

    m.addConstr(y - base_b <= excess_b, name="ExcessB_ge")
    m.addConstr(excess_b <= max_trucks_b, name="ExcessB_ub")

    # Type B recovery desk gate: if y > b_thresh then z_b=1; else z_b can be 0
    # y - b_thresh <= M * z_b
    M_b = max_trucks_b
    m.addConstr(y - b_thresh <= M_b * z_b, name="TypeB_gate")

    # Total fleet surge gate: if x + y > tot_thresh then z_tot=1
    M_tot = max_total_trucks
    m.addConstr(x + y - tot_thresh <= M_tot * z_tot, name="TotalFleet_gate")

    # Objective: base rental + penalties + fixed fees
    obj = (
        cost_a * x +
        cost_b * y +
        pen_a * excess_a +
        pen_b * excess_b +
        b_fee * z_b +
        tot_fee * z_tot
    )

    m.setObjective(obj, GRB.MINIMIZE)
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    main()
