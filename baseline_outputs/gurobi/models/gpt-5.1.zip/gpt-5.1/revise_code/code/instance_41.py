import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine data directory (workspace root + data)
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Load general parameters
    initial_capital = None
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'].strip() == 'initial_capital':
                initial_capital = float(row['Value'].strip())
                break
    if initial_capital is None:
        raise ValueError("initial_capital not found in general_parameters.csv")

    # Load liquidity policy
    min_year3_reserve = None
    reserve_shortfall_penalty = None
    with open(os.path.join(data_dir, 'liquidity_policy.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            if name == 'min_year3_reserve':
                min_year3_reserve = float(row['Value'].strip())
            elif name == 'reserve_shortfall_penalty':
                reserve_shortfall_penalty = float(row['Value'].strip())
    if min_year3_reserve is None or reserve_shortfall_penalty is None:
        raise ValueError("Liquidity policy parameters not found correctly.")

    # Load project data
    projects = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            pid = int(row['Project_ID'])
            projects[pid] = {
                'Availability_Start': row['Availability_Start'].strip(),
                'Availability_End': row['Availability_End'].strip(),
                'Maturity_End': row['Maturity_End'].strip(),
                'Interest_Rate': float(row['Interest_Rate'].strip()),
                'Investment_Capacity': row['Investment_Capacity'].strip()
            }

    # Extract parameters for convenience
    r1 = projects[1]['Interest_Rate']
    r2 = projects[2]['Interest_Rate']
    r3 = projects[3]['Interest_Rate']
    r4 = projects[4]['Interest_Rate']

    cap2 = float(projects[2]['Investment_Capacity']) if projects[2]['Investment_Capacity'] != 'Unlimited' else GRB.INFINITY
    cap3 = float(projects[3]['Investment_Capacity']) if projects[3]['Investment_Capacity'] != 'Unlimited' else GRB.INFINITY
    cap4 = float(projects[4]['Investment_Capacity']) if projects[4]['Investment_Capacity'] != 'Unlimited' else GRB.INFINITY

    # Build model
    m = gp.Model("Revised_Investment_Maximization")
    m.setParam('OutputFlag', 0)

    # Decision variables (continuous, >=0)
    x1_1 = m.addVar(lb=0.0, name="x1_1")                     # Project 1 in Year 1
    x1_2 = m.addVar(lb=0.0, name="x1_2")                     # Project 1 in Year 2
    x1_3 = m.addVar(lb=0.0, name="x1_3")                     # Project 1 in Year 3
    x2   = m.addVar(lb=0.0, ub=cap2, name="x2")              # Project 2 in Year 1
    x3   = m.addVar(lb=0.0, ub=cap3, name="x3")              # Project 3 in Year 2
    x4   = m.addVar(lb=0.0, ub=cap4, name="x4")              # Project 4 in Year 3

    # Year 3 reserve (cash left uninvested at beginning of Year 3)
    R3 = m.addVar(lb=0.0, name="R3")

    # Reserve shortfall (>=0, equals max(0, min_year3_reserve - R3))
    shortfall = m.addVar(lb=0.0, name="reserve_shortfall")

    # Constraints

    # Year 1 budget: invest in P1 (Year1) and P2
    m.addConstr(x1_1 + x2 <= initial_capital, name="Year1_Budget")

    # Year 2 budget: proceeds from P1 invested in Year1
    # P1 matures same year, so x1_1*r1 is available at beginning of Year2
    m.addConstr(x1_2 + x3 <= x1_1 * r1, name="Year2_Budget")

    # Cash available at beginning of Year 3
    # From P1 (Year2), P2, P3
    cash_year3 = x1_2 * r1 + x2 * r2 + x3 * r3

    # Year 3 budget: investments in P1 (Year3) and P4 plus reserve must not exceed cash_year3
    m.addConstr(x1_3 + x4 + R3 <= cash_year3, name="Year3_Budget")

    # Shortfall definition: shortfall >= min_reserve - R3, and >= 0 by lb
    m.addConstr(shortfall >= min_year3_reserve - R3, name="Shortfall_Def")

    # Objective: terminal wealth at end of Year3
    # - R3 stays as cash (no interest)
    # - P1 (Year3): x1_3 * r1
    # - P4: x4 * r4
    # minus penalty for reserve shortfall
    terminal_wealth = R3 + x1_3 * r1 + x4 * r4
    penalty = reserve_shortfall_penalty * shortfall
    m.setObjective(terminal_wealth - penalty, GRB.MAXIMIZE)

    # Optimize
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
