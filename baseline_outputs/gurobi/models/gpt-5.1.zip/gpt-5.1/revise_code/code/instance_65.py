import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
    for row in csv.DictReader(f):
        params[row['Parameter_Name'].strip()] = float(row['Value'])

# Read product data
products = {}
with open(os.path.join(data_dir, 'table_1.csv')) as f:
    for row in csv.DictReader(f):
        products[row['Product'].strip()] = {
            'a_hrs': float(row['Workshop_A_Hours']),
            'b_hrs': float(row['Workshop_B_Hours']),
            'insp_cost': float(row['Inspection_Sales_Cost'])
        }

m = products['Microwave_Oven']
w = products['Water_Heater']

# Revenue per unit: processing value (hours * cost) + inspection/sales cost + green bonus
rev_m = (m['a_hrs'] * params['workshop_a_hourly_cost']
         + m['b_hrs'] * params['workshop_b_hourly_cost']
         + m['insp_cost']
         + params['green_bonus_m'])

rev_w = (w['a_hrs'] * params['workshop_a_hourly_cost']
         + w['b_hrs'] * params['workshop_b_hourly_cost']
         + w['insp_cost']
         + params['green_bonus_w'])

# Big-M for activation linking
bigM = params['bigM']

# Build model
model = gp.Model("revised_production")
model.setParam('OutputFlag', 0)

# Decision variables
x_m = model.addVar(vtype=GRB.CONTINUOUS,
                   lb=params['microwave_minimum_sales'],
                   name="microwave")
x_w = model.addVar(vtype=GRB.CONTINUOUS,
                   lb=params['water_heater_minimum_sales'],
                   name="water_heater")

# Activation binaries for Workshop A setup
y_mA = model.addVar(vtype=GRB.BINARY, name="y_mA")
y_wA = model.addVar(vtype=GRB.BINARY, name="y_wA")

model.update()

# Objective: maximize total profit/value
model.setObjective(rev_m * x_m + rev_w * x_w, GRB.MAXIMIZE)

# Constraints

# Workshop A time: processing + setup hours for activated products
model.addConstr(
    m['a_hrs'] * x_m + w['a_hrs'] * x_w
    + params['setup_hours_A'] * (y_mA + y_wA)
    <= params['workshop_a_available_hours'] + params['workshop_a_overtime_limit'],
    name="workshop_A_hours"
)

# Workshop B time: at least utilize available hours (as in original heuristic)
model.addConstr(
    m['b_hrs'] * x_m + w['b_hrs'] * x_w
    >= params['workshop_b_available_hours'],
    name="workshop_B_hours"
)

# Inspection and sales cost limit
model.addConstr(
    m['insp_cost'] * x_m + w['insp_cost'] * x_w
    <= params['inspection_sales_cost_limit'],
    name="inspection_sales_cost_limit"
)

# Technician pool constraint
model.addConstr(
    params['tech_rate_m'] * x_m + params['tech_rate_w'] * x_w
    <= params['tech_pool_hours'],
    name="technician_pool"
)

# Activation linking: if any units of a product use workshop A, setup is triggered
model.addConstr(x_m <= bigM * y_mA, name="link_mA")
model.addConstr(x_w <= bigM * y_wA, name="link_wA")

model.optimize()

obj_val = model.ObjVal if model.Status == GRB.OPTIMAL else float('nan')
print(f"FINAL_OBJ_VALUE: {obj_val}")
