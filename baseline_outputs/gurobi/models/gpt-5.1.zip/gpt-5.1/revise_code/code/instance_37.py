import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Load table_1.csv
    table1_path = os.path.join(base_dir, "data", "table_1.csv")
    with open(table1_path, "r") as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = [row for row in reader]

    # Parse process data
    # Row 0: Process I, Row 1: Process II, Row 2: Profit_per_unit
    a_I = float(rows[0][1])  # Model A hours for Process I
    b_I = float(rows[0][2])  # Model B hours for Process I
    cap_I = float(rows[0][3])  # Max weekly capacity Process I (normal hours per week)

    a_II = float(rows[1][1])  # Model A hours for Process II
    b_II = float(rows[1][2])  # Model B hours for Process II
    cap_II = float(rows[1][3])  # Max weekly capacity Process II (normal hours per week)

    profit_A = float(rows[2][1])  # Profit per unit Model A
    profit_B = float(rows[2][2])  # Profit per unit Model B

    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(params_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])

    # General parameters
    min_total_profit = params["min_weekly_profit"]
    min_total_A = params["min_model_A_units"]
    min_total_B = params["min_model_B_units"]

    week1_min_A = params["week1_min_model_A_units"]
    week1_min_B = params["week1_min_model_B_units"]
    week2_min_A = params["week2_min_model_A_units"]
    week2_min_B = params["week2_min_model_B_units"]

    normal_I = params["process_I_hours"]        # weekly normal hours for I
    normal_II = params["process_II_hours"]      # weekly normal hours for II

    max_ot_I = params["max_overtime_I_per_week"]
    max_ot_II = params["max_overtime_II_per_week"]

    ot_prem_I = params["overtime_premium_I"]
    ot_prem_II = params["overtime_premium_II"]

    min_util_I = params["min_avg_utilization_I"]
    min_util_II = params["min_avg_utilization_II"]

    fatigue_thr_I = params["week1_overtime_fatigue_threshold_I"]
    fatigue_thr_II = params["week1_overtime_fatigue_threshold_II"]

    recovery_loss_I = params["week2_recovery_loss_I"]
    recovery_loss_II = params["week2_recovery_loss_II"]

    # Build model
    m = gp.Model("Revised_Microcomputer_Production")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # Production variables: units of A and B in each week
    xA1 = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA_week1")
    xB1 = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB_week1")
    xA2 = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA_week2")
    xB2 = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB_week2")

    # Overtime hours per process and week
    ot_I1 = m.addVar(lb=0.0, ub=max_ot_I, vtype=GRB.CONTINUOUS, name="ot_I_week1")
    ot_I2 = m.addVar(lb=0.0, ub=max_ot_I, vtype=GRB.CONTINUOUS, name="ot_I_week2")
    ot_II1 = m.addVar(lb=0.0, ub=max_ot_II, vtype=GRB.CONTINUOUS, name="ot_II_week1")
    ot_II2 = m.addVar(lb=0.0, ub=max_ot_II, vtype=GRB.CONTINUOUS, name="ot_II_week2")

    # Binary variables to trigger recovery loss if overtime in week1 exceeds threshold
    z_I = m.addVar(vtype=GRB.BINARY, name="recovery_I_trigger")
    z_II = m.addVar(vtype=GRB.BINARY, name="recovery_II_trigger")

    # Auxiliary "excess overtime" variables for big-M linking
    excess_I = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="excess_ot_I")
    excess_II = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="excess_ot_II")

    # Week 1 capacity constraints (Process I and II)
    m.addConstr(a_I * xA1 + b_I * xB1 <= normal_I + ot_I1, name="Proc_I_week1_cap")
    m.addConstr(a_II * xA1 + b_II * xB1 <= normal_II + ot_II1, name="Proc_II_week1_cap")

    # Week 2 regular capacity after possible recovery loss
    # Effective normal hours Week 2 for I: normal_I - recovery_loss_I * z_I
    # Effective normal hours Week 2 for II: normal_II - recovery_loss_II * z_II
    m.addConstr(a_I * xA2 + b_I * xB2 <= normal_I - recovery_loss_I * z_I + ot_I2,
                name="Proc_I_week2_cap")
    m.addConstr(a_II * xA2 + b_II * xB2 <= normal_II - recovery_loss_II * z_II + ot_II2,
                name="Proc_II_week2_cap")

    # Fatigue trigger logic: if overtime > threshold, z must be 1
    # Model: excess_I >= ot_I1 - threshold, excess_I <= ot_I1 - threshold + M*(1-z_I), excess_I <= M*z_I, excess_I >= 0
    M_I = max_ot_I  # upper bound on overtime; sufficient as big-M
    M_II = max_ot_II

    m.addConstr(excess_I >= ot_I1 - fatigue_thr_I, name="excess_I_lb")
    m.addConstr(excess_I <= ot_I1 - fatigue_thr_I + M_I * (1 - z_I), name="excess_I_ub1")
    m.addConstr(excess_I <= M_I * z_I, name="excess_I_ub2")

    m.addConstr(excess_II >= ot_II1 - fatigue_thr_II, name="excess_II_lb")
    m.addConstr(excess_II <= ot_II1 - fatigue_thr_II + M_II * (1 - z_II), name="excess_II_ub1")
    m.addConstr(excess_II <= M_II * z_II, name="excess_II_ub2")

    # Weekly delivery promises (week-specific minimums)
    m.addConstr(xA1 >= week1_min_A, name="week1_min_A")
    m.addConstr(xB1 >= week1_min_B, name="week1_min_B")
    m.addConstr(xA2 >= week2_min_A, name="week2_min_A")
    m.addConstr(xB2 >= week2_min_B, name="week2_min_B")

    # Total production minimums over two weeks
    m.addConstr(xA1 + xA2 >= min_total_A, name="total_min_A")
    m.addConstr(xB1 + xB2 >= min_total_B, name="total_min_B")

    # Average utilization constraints for regular hours (over two weeks)
    # Use only normal hours (excluding overtime) in the numerator
    # Averages are over 2 weeks; total regular use >= 2 * min_util * normal_hours
    total_reg_use_I = (
        a_I * xA1 + b_I * xB1 +
        a_I * xA2 + b_I * xB2
    ) - (ot_I1 + ot_I2)  # subtract overtime hours counted in total proc hours

    total_reg_use_II = (
        a_II * xA1 + b_II * xB1 +
        a_II * xA2 + b_II * xB2
    ) - (ot_II1 + ot_II2)

    m.addConstr(total_reg_use_I >= 2.0 * min_util_I * normal_I, name="min_avg_util_I")
    m.addConstr(total_reg_use_II >= 2.0 * min_util_II * normal_II, name="min_avg_util_II")

    # Profit calculations
    total_revenue = profit_A * (xA1 + xA2) + profit_B * (xB1 + xB2)
    total_overtime_cost = ot_prem_I * (ot_I1 + ot_I2) + ot_prem_II * (ot_II1 + ot_II2)
    net_profit = total_revenue - total_overtime_cost

    # Minimum net profit requirement
    m.addConstr(net_profit >= min_total_profit, name="min_total_profit")

    # Objective: maximize net profit over two weeks
    m.setObjective(net_profit, GRB.MAXIMIZE)

    m.optimize()

    if m.Status == GRB.OPTIMAL or m.Status == GRB.SUBOPTIMAL:
        obj_val = m.ObjVal
    else:
        obj_val = float('nan')

    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
