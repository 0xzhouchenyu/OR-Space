import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_csv(filepath):
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read data
    products = read_csv(os.path.join(data_dir, "table_1.csv"))
    params_rows = read_csv(os.path.join(data_dir, "general_parameters.csv"))
    params = {row["Parameter_Name"]: float(row["Value"]) for row in params_rows}

    available_steel = params["available_steel"]
    available_aluminum = params["available_aluminum"]
    available_labor = params["available_labor"]
    overtime_pay = params["overtime_pay"]
    max_overtime = params["max_overtime"]
    overtime_review_threshold = params["overtime_review_threshold"]
    overtime_review_fee = params["overtime_review_fee"]
    product_A_line_audit_threshold = params["product_A_line_audit_threshold"]
    product_A_line_audit_fee = params["product_A_line_audit_fee"]

    # Identify product A explicitly
    prod_index = {p["Product"]: p for p in products}
    if "A" not in prod_index or "B" not in prod_index:
        raise ValueError("Products A and B must be present in table_1.csv")

    # Create model
    m = gp.Model("Revised_Production_Optimization")
    m.setParam('OutputFlag', 0)

    # Decision variables: production quantities
    x = {}
    for p in products:
        name = p["Product"]
        x[name] = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{name}")

    # Overtime hours (continuous, >=0)
    overtime = m.addVar(lb=0.0, ub=max_overtime, vtype=GRB.CONTINUOUS, name="overtime")

    # Binary variable for overtime review fee (if overtime exceeds overtime_review_threshold)
    y_overtime_review = m.addVar(vtype=GRB.BINARY, name="y_overtime_review")

    # Binary variable for Product A line audit fee (if x_A exceeds threshold)
    y_line_audit_A = m.addVar(vtype=GRB.BINARY, name="y_line_audit_A")

    m.update()

    # Parameters from table for convenience
    steel_req = {p["Product"]: float(p["Steel_Required_kg"]) for p in products}
    alum_req = {p["Product"]: float(p["Aluminum_Required_kg"]) for p in products}
    labor_req = {p["Product"]: float(p["Labor_Required_hours"]) for p in products}
    profit = {p["Product"]: float(p["Profit_yuan"]) for p in products}
    setup_cost = {p["Product"]: float(p["Setup_Cost_yuan"]) for p in products}

    # Total labor used
    total_labor = gp.quicksum(labor_req[p["Product"]] * x[p["Product"]] for p in products)

    # Constraints

    # Steel constraint
    m.addConstr(gp.quicksum(steel_req[p["Product"]] * x[p["Product"]] for p in products) <= available_steel,
                name="Steel")

    # Aluminum constraint
    m.addConstr(gp.quicksum(alum_req[p["Product"]] * x[p["Product"]] for p in products) <= available_aluminum,
                name="Aluminum")

    # Labor with overtime: base labor + overtime >= total labor; base capped by available_labor
    # Let base_labor = available_labor (fixed cap), overtime supplies any extra requirement beyond available_labor
    m.addConstr(total_labor <= available_labor + overtime, name="Labor_with_overtime")

    # Overtime classification: y_overtime_review = 1 if overtime > overtime_review_threshold
    # Use big-M linearization
    M_overtime = max_overtime
    # If y=0 -> overtime <= threshold
    m.addConstr(overtime <= overtime_review_threshold + M_overtime * y_overtime_review, name="Overtime_upper_logic")
    # If y=1 -> overtime >= threshold (or at least nontrivially above). Allow equality at threshold without fee?
    # Business text: fee if overtime exceeds threshold, but we model as >= threshold for practicality
    epsilon = 0.0
    m.addConstr(overtime >= overtime_review_threshold - M_overtime * (1 - y_overtime_review) + epsilon,
                name="Overtime_lower_logic")

    # Product A line audit: y_line_audit_A = 1 if x_A > threshold
    xA = x["A"]
    M_A = 1e5
    # If y=0 -> xA <= threshold
    m.addConstr(xA <= product_A_line_audit_threshold + M_A * y_line_audit_A, name="A_line_audit_upper_logic")
    # If y=1 -> xA >= threshold (approx for 'exceeds')
    m.addConstr(xA >= product_A_line_audit_threshold - M_A * (1 - y_line_audit_A),
                name="A_line_audit_lower_logic")

    # Objective: maximize profit minus setup costs minus overtime and review fees minus line audit fee
    total_profit = gp.quicksum(profit[p["Product"]] * x[p["Product"]] for p in products)
    total_setup_cost = gp.quicksum(setup_cost[p["Product"]] * (1 if setup_cost[p["Product"]] != 0 else 0) for p in products)
    # The above treats setup costs as fixed if product exists; but typical interpretation is per run.
    # The data gives a single setup cost per product; without binary "produce or not" variables, we treat
    # it as incurred whenever production is positive using a big-M binary.
    # So refine: add binaries for setup.
    y_setup = {}
    for p in products:
        name = p["Product"]
        y_setup[name] = m.addVar(vtype=GRB.BINARY, name=f"y_setup_{name}")
    m.update()
    for p in products:
        name = p["Product"]
        # If y_setup=0, x <= 0; if y_setup=1, x can be positive up to big M_x
        M_x = 1e5
        m.addConstr(x[name] <= M_x * y_setup[name], name=f"Setup_link_{name}")

    total_setup_cost = gp.quicksum(setup_cost[p["Product"]] * y_setup[p["Product"]] for p in products)

    total_overtime_cost = overtime_pay * overtime
    total_overtime_review_fee = overtime_review_fee * y_overtime_review
    total_line_audit_fee_A = product_A_line_audit_fee * y_line_audit_A

    m.setObjective(
        total_profit
        - total_setup_cost
        - total_overtime_cost
        - total_overtime_review_fee
        - total_line_audit_fee_A,
        GRB.MAXIMIZE
    )

    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
