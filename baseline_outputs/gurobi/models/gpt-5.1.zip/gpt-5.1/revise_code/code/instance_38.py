import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_processing_times(filepath):
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times


def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if not row or len(row) < 2:
                continue
            name = row[0]
            val = row[1]
            if val == '':
                continue
            try:
                params[name] = float(val)
            except ValueError:
                params[name] = val
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    processing_times = load_processing_times(os.path.join(data_dir, "table_1.csv"))
    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

    n_jobs = len(processing_times)
    n_machines = len(processing_times[0])
    jobs = range(n_jobs)
    machines = range(n_machines)

    time_window = {
        0: params.get("time_window_1", 0.0),
        1: params.get("time_window_2", 0.0),
        2: params.get("time_window_3", 0.0),
    }
    overtime_window = {
        0: params.get("overtime_window_1", 0.0),
        1: params.get("overtime_window_2", 0.0),
        2: params.get("overtime_window_3", 0.0),
    }
    overtime_penalty = params.get("overtime_penalty_per_unit", 0.0)
    M_seq = {
        0: params.get("M_1", 1000.0),
        1: params.get("M_2", 1000.0),
        2: params.get("M_3", 1000.0),
    }
    m1_review_threshold = params.get("machine1_overtime_review_threshold", 0.0)
    m1_review_fee = params.get("machine1_overtime_review_fee", 0.0)

    model = gp.Model("revised_flowshop")
    model.setParam('OutputFlag', 0)

    # Variables
    C = model.addVars(jobs, machines, name="C", lb=0.0)
    y = model.addVars(jobs, name="y", vtype=GRB.BINARY)  # position indicator on M1: job j precedes others if y[j]=1
    z = model.addVar(name="z_review", vtype=GRB.BINARY)

    # Makespan
    makespan = model.addVar(name="makespan", lb=0.0)

    # Overtime variables per machine
    overtime = model.addVars(machines, name="overtime", lb=0.0)

    # Sequencing on each machine: we enforce a single common order via continuous positions on M1
    # position[j] in [0, n_jobs-1]
    position = model.addVars(jobs, name="pos", lb=0.0, ub=n_jobs - 1)

    # All-different via integer ordering: position are continuous, but we enforce ordering via binary pairwise
    order = model.addVars(jobs, jobs, vtype=GRB.BINARY, name="order")
    bigM_pos = n_jobs

    for i in jobs:
        model.addConstr(order[i, i] == 0)
        for k in jobs:
            if i == k:
                continue
            # Either i before k or k before i
            model.addConstr(order[i, k] + order[k, i] == 1)
            # position constraints
            model.addConstr(position[k] >= position[i] + 1 - bigM_pos * (1 - order[i, k]))

    # Fix one job as first on M1 to avoid symmetry (optional)
    # Use y[j] to indicate that job j is first on M1
    model.addConstr(gp.quicksum(y[j] for j in jobs) == 1)
    for j in jobs:
        model.addConstr(position[j] <= (n_jobs - 1) * (1 - y[j]))
        model.addConstr(position[j] >= 0)

    # Processing time data
    p = {(i, m): processing_times[i][m] for i in jobs for m in machines}

    # Completion time constraints
    for j in jobs:
        for m in machines:
            proc = p[j, m]
            if m == 0:
                model.addConstr(C[j, m] >= proc)
            else:
                # must start after completion on previous machine
                model.addConstr(C[j, m] >= C[j, m - 1] + proc - M_seq[m] * 0)

    # Common sequence constraints using positions:
    # If job i is before k, then completion times on each machine respect that order.
    for m in machines:
        for i in jobs:
            for k in jobs:
                if i == k:
                    continue
                model.addConstr(
                    C[k, m] >= C[i, m] + p[k, m] - M_seq[m] * (1 - order[i, k])
                )

    # Makespan definition
    for j in jobs:
        model.addConstr(makespan >= C[j, n_machines - 1])

    # Overtime calculation: sum of processing times on machine m vs window
    total_proc_machine = {m: gp.quicksum(p[j, m] for j in jobs) for m in machines}
    for m in machines:
        model.addConstr(overtime[m] >= total_proc_machine[m] - time_window[m])
        model.addConstr(overtime[m] <= overtime_window[m])
        model.addConstr(overtime[m] >= 0.0)

    # Machine 1 overtime review threshold and fee
    # z = 1 if overtime[0] > m1_review_threshold
    bigM_ot = overtime_window[0] + time_window[0]
    model.addConstr(overtime[0] - m1_review_threshold <= bigM_ot * z)
    model.addConstr(overtime[0] - m1_review_threshold >= 1e-6 - bigM_ot * (1 - z))

    # Objective: minimize makespan + overtime penalty + review fee
    obj = makespan
    obj += overtime_penalty * gp.quicksum(overtime[m] for m in machines)
    obj += m1_review_fee * z

    model.setObjective(obj, GRB.MINIMIZE)
    model.optimize()

    if model.Status in [GRB.OPTIMAL, GRB.SUBOPTIMAL]:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: inf")


if __name__ == "__main__":
    main()
