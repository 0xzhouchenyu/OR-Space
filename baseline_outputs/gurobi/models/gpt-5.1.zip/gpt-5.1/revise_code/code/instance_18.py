import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

def main():
    params = load_parameters()

    weekly_production_time = params['weekly_production_time']
    fabric_production_rate = params['fabric_production_rate']
    min_curtain_fabric_sales = params['min_curtain_fabric_sales']
    min_clothing_fabric_sales = params['min_clothing_fabric_sales']

    day_shift_regular_capacity = params['day_shift_regular_capacity']
    night_shift_regular_capacity = params['night_shift_regular_capacity']
    day_overtime_limit = params['day_overtime_limit']
    night_overtime_limit = params['night_overtime_limit']
    day_overtime_penalty = params['day_overtime_penalty']
    night_overtime_penalty = params['night_overtime_penalty']
    day_min_utilization_ratio = params['day_min_utilization_ratio']
    night_min_utilization_ratio = params['night_min_utilization_ratio']

    # Convert sales requirements to hours
    min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
    min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

    # Model
    m = gp.Model("Textile_Factory_Day_Night_Shifts")
    m.setParam('OutputFlag', 0)

    # Decision variables: regular hours
    day_clothing = m.addVar(lb=0.0, name="day_clothing_hours")
    day_curtain = m.addVar(lb=0.0, name="day_curtain_hours")
    night_clothing = m.addVar(lb=0.0, name="night_clothing_hours")
    night_curtain = m.addVar(lb=0.0, name="night_curtain_hours")

    # Overtime variables per shift
    day_overtime_hours = m.addVar(lb=0.0, ub=day_overtime_limit, name="day_overtime_hours")
    night_overtime_hours = m.addVar(lb=0.0, ub=night_overtime_limit, name="night_overtime_hours")

    # Helper expressions
    day_regular_total = day_clothing + day_curtain
    night_regular_total = night_clothing + night_curtain
    total_regular = day_regular_total + night_regular_total
    total_time = total_regular + day_overtime_hours + night_overtime_hours

    # Objective: minimize overtime penalties
    m.setObjective(day_overtime_penalty * day_overtime_hours +
                   night_overtime_penalty * night_overtime_hours, GRB.MINIMIZE)

    # Sales (production) requirements
    m.addConstr(day_clothing + night_clothing >= min_clothing_hours, "min_clothing_hours")
    m.addConstr(day_curtain + night_curtain >= min_curtain_hours, "min_curtain_hours")

    # Regular capacity per shift
    m.addConstr(day_regular_total <= day_shift_regular_capacity, "day_regular_capacity")
    m.addConstr(night_regular_total <= night_shift_regular_capacity, "night_regular_capacity")

    # Weekly production time usage including overtime
    m.addConstr(total_time == weekly_production_time + day_overtime_hours + night_overtime_hours,
                "production_time_balance")

    # Utilization constraints on regular hours (only if total_regular can be positive)
    # day_min_utilization_ratio * total_regular <= day_regular_total
    m.addConstr(day_regular_total >= day_min_utilization_ratio * total_regular,
                "day_min_utilization")
    m.addConstr(night_regular_total >= night_min_utilization_ratio * total_regular,
                "night_min_utilization")

    # Solve
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
