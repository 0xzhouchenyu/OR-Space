import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    filepath = os.path.join(data_dir, "table_1.csv")

    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        bandwidth = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                bandwidth[(row_node, col_node)] = bw

    source = 'A'
    intermediate = 'C'
    target = 'E'

    # Compute costs for edges with positive bandwidth
    arcs = []
    cost = {}
    for (i, j), bw in bandwidth.items():
        if bw > 0:
            arcs.append((i, j))
            cost[(i, j)] = 100 - bw

    # Build model
    m = gp.Model("routing_min_cost")
    m.setParam('OutputFlag', 0)

    # Binary variables for using each arc
    x = m.addVars(arcs, vtype=GRB.BINARY, name="x")

    # Flow-conservation-like constraints for path A -> C -> E without loops
    for n in nodes:
        inflow = gp.quicksum(x[i, j] for (i, j) in arcs if j == n)
        outflow = gp.quicksum(x[i, j] for (i, j) in arcs if i == n)

        if n == source:
            m.addConstr(outflow - inflow == 1)
        elif n == target:
            m.addConstr(inflow - outflow == 1)
        elif n == intermediate:
            # Net flow 0 at C, but must be visited: at least one in and one out
            m.addConstr(inflow - outflow == 0)
            m.addConstr(inflow >= 1)
            m.addConstr(outflow >= 1)
        else:
            m.addConstr(inflow - outflow == 0)

    # Objective: minimize total routing cost
    m.setObjective(gp.quicksum(cost[i, j] * x[i, j] for (i, j) in arcs), GRB.MINIMIZE)

    m.optimize()

    obj_val = m.ObjVal if m.status == GRB.OPTIMAL else float('inf')
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
