import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Read general parameters
    general_params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(general_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val

    total_space = params['mall_total_space']
    rent_pct = params['rent_percentage'] / 100.0
    common_area_factor = params.get('common_area_factor', 1.0)
    gm_third_store_concession = params.get('general_merchandise_third_store_concession', 0.0)
    catering_security_threshold = int(params.get('catering_third_store_security_threshold', 0))
    catering_security_cost = params.get('catering_third_store_security_cost', 0.0)

    # Read store data
    table_path = os.path.join(base_dir, "data", "table_1.csv")
    stores = []
    with open(table_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            profits = {}
            for k in range(1, 4):
                key = 'Profit_1_Store' if k == 1 else f'Profit_{k}_Stores'
                if key in row:
                    val = row[key].strip()
                    if val and val != '-':
                        profits[k] = float(val)
            stores.append({
                'name': row['Store_Type'].strip(),
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits
            })

    n_types = len(stores)

    # Build model
    m = gp.Model("mall_lease")
    m.setParam('OutputFlag', 0)

    # Decision variables: integer number of stores per type
    x = {}
    for i in range(n_types):
        s = stores[i]
        x[i] = m.addVar(vtype=GRB.INTEGER, lb=s['min'], ub=s['max'], name=f"x_{i}")

    m.update()

    # Effective area constraint with common area factor
    total_effective_area = gp.quicksum(x[i] * stores[i]['area'] for i in range(n_types)) * common_area_factor
    m.addConstr(total_effective_area <= total_space, name="space_constraint")

    # Objective construction
    # Piecewise per-store profits depending on count 1-3; no profits defined beyond max
    total_profit = gp.LinExpr()
    for i in range(n_types):
        s = stores[i]
        # For each possible n in [min, max], if profits defined, use indicator
        # Introduce binary indicators for discrete choices of n
    ind = {}
    for i in range(n_types):
        s = stores[i]
        ind[i] = {}
        for n in range(s['min'], s['max'] + 1):
            ind[i][n] = m.addVar(vtype=GRB.BINARY, name=f"ind_{i}_{n}")
        # Ensure exactly one choice of n equals x[i]
        # Sum_n ind[i][n] = 1
        m.addConstr(gp.quicksum(ind[i][n] for n in ind[i]) == 1, name=f"choice_{i}")
        # Link x[i] = sum_n n * ind[i][n]
        m.addConstr(x[i] == gp.quicksum(n * ind[i][n] for n in ind[i]), name=f"link_{i}")

    # Now build profit using indicators
    for i in range(n_types):
        s = stores[i]
        for n, b in ind[i].items():
            if n in s['profits']:
                per_store_profit = s['profits'][n]
                total_profit += per_store_profit * n * b
            else:
                # If profit not defined for this n, forbid this n
                m.addConstr(b == 0, name=f"forbid_{i}_{n}")

    # Adjustments for General Merchandise third store concession
    gm_index = None
    catering_index = None
    for i, s in enumerate(stores):
        if s['name'] == 'General_Merchandise':
            gm_index = i
        if s['name'] == 'Catering':
            catering_index = i

    # General Merchandise: if exactly 3 stores, subtract concession from rent income (i.e., from rent units)
    gm_indicator_3 = None
    if gm_index is not None:
        # Indicator for gm having 3 stores is ind[gm_index][3] if defined
        if 3 in ind[gm_index]:
            gm_indicator_3 = ind[gm_index][3]

    # Catering security cost: if number of catering stores exceeds threshold (i.e., 3), subtract cost
    catering_indicator_3 = None
    if catering_index is not None:
        if 3 in ind[catering_index]:
            catering_indicator_3 = ind[catering_index][3]

    # Rent is rent_pct * (total_profit) minus concessions/costs expressed in rent-income units
    total_rent = rent_pct * total_profit

    # Apply GM concession (rent_income_units)
    if gm_indicator_3 is not None and gm_third_store_concession != 0.0:
        total_rent -= gm_third_store_concession * gm_indicator_3

    # Apply Catering security cost only if third store retained and threshold is 2
    if catering_indicator_3 is not None and catering_security_cost != 0.0:
        # According to brief: one or two stores ordinary, third store triggers cost
        total_rent -= catering_security_cost * catering_indicator_3

    m.setObjective(total_rent, GRB.MAXIMIZE)

    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
