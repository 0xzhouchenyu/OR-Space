import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = {}
    with open(data_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    return params

def main():
    params = load_parameters()

    # Extract parameters
    min_A_I = params['min_proportion_crude_A_type_I'] / 100.0
    min_A_II = params['min_proportion_crude_A_type_II'] / 100.0
    price_I = params['selling_price_type_I']
    price_II = params['selling_price_type_II']
    inv_A = params['inventory_crude_A']
    inv_B = params['inventory_crude_B']
    max_purchase_A = params['max_purchase_crude_A']
    cost_tier1 = params['market_price_crude_A_tier_1']
    cost_tier2 = params['market_price_crude_A_tier_2']
    cost_tier3 = params['market_price_crude_A_tier_3']
    proc_cap = params['processing_capacity']
    min_output = params['min_total_gasoline_output']
    proc_cost = params['processing_cost_per_ton']
    type_II_thresh = params['type_II_contract_threshold']
    type_II_lift = params['type_II_price_lift']
    bulk_thresh = params['bulk_purchase_rebate_threshold']
    bulk_rebate = params['bulk_purchase_rebate']

    # Model
    m = gp.Model("Revised_Oil_Blending")
    m.setParam('OutputFlag', 0)

    # Decision variables
    a1 = m.addVar(lb=0.0, name="crude_A_in_I")
    a2 = m.addVar(lb=0.0, name="crude_A_in_II")
    b1 = m.addVar(lb=0.0, name="crude_B_in_I")
    b2 = m.addVar(lb=0.0, name="crude_B_in_II")

    # Tiered purchase of crude A
    p1 = m.addVar(lb=0.0, ub=500.0, name="purchase_tier1")
    p2 = m.addVar(lb=0.0, ub=500.0, name="purchase_tier2")
    p3 = m.addVar(lb=0.0, ub=500.0, name="purchase_tier3")

    # Binary vars for tier order
    y1 = m.addVar(vtype=GRB.BINARY, name="y1")
    y2 = m.addVar(vtype=GRB.BINARY, name="y2")

    # Binary for Type II uplift
    z_typeII = m.addVar(vtype=GRB.BINARY, name="z_typeII_uplift")

    # Binary for bulk purchase rebate
    z_rebate = m.addVar(vtype=GRB.BINARY, name="z_bulk_rebate")

    # Total outputs
    x_I = m.addVar(lb=0.0, name="output_Type_I")
    x_II = m.addVar(lb=0.0, name="output_Type_II")

    # Constraints

    # Link outputs to crude usage
    m.addConstr(x_I == a1 + b1, name="output_I_balance")
    m.addConstr(x_II == a2 + b2, name="output_II_balance")

    # Supply constraints for crude A and B
    total_purchased_A = p1 + p2 + p3
    m.addConstr(total_purchased_A <= max_purchase_A, name="max_purchase_A")
    m.addConstr(a1 + a2 <= inv_A + total_purchased_A, name="crude_A_supply")
    m.addConstr(b1 + b2 <= inv_B, name="crude_B_supply")

    # Processing capacity window
    m.addConstr(x_I + x_II <= proc_cap, name="max_processing")
    m.addConstr(x_I + x_II >= min_output, name="min_processing")

    # Blending quality constraints
    # a1 >= min_A_I * (a1 + b1)
    m.addConstr(a1 >= min_A_I * (a1 + b1), name="blend_I_minA")
    # a2 >= min_A_II * (a2 + b2)
    m.addConstr(a2 >= min_A_II * (a2 + b2), name="blend_II_minA")

    # Tier ordering constraints (p1, p2, p3 with y1, y2)
    m.addConstr(p1 <= 500.0, name="tier1_ub")
    m.addConstr(p2 <= 500.0 * y1, name="tier2_ub_y1")
    m.addConstr(p3 <= 500.0 * y2, name="tier3_ub_y2")
    m.addConstr(p1 >= 500.0 * y1, name="tier1_lb_y1")
    m.addConstr(p2 >= 500.0 * y2, name="tier2_lb_y2")

    # Type II uplift threshold: x_II >= type_II_thresh * z_typeII
    m.addConstr(x_II >= type_II_thresh * z_typeII, name="typeII_uplift_min")
    # Also cannot exceed big-M: x_II <= type_II_thresh + (proc_cap - type_II_thresh)*z_typeII
    # but not strictly needed; z_typeII only indicates threshold achieved to collect uplift.
    # The uplift is only beneficial when z_typeII=1 and x_II >= threshold.

    # Bulk purchase rebate threshold: total_purchased_A >= bulk_thresh * z_rebate
    m.addConstr(total_purchased_A >= bulk_thresh * z_rebate, name="bulk_rebate_min")

    # Objective: revenue + uplift + rebate - purchase cost - processing cost
    revenue = price_I * x_I + price_II * x_II
    uplift = type_II_lift * x_II * z_typeII
    purchase_cost = cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3
    processing_cost = proc_cost * (x_I + x_II)
    rebate = bulk_rebate * z_rebate

    m.setObjective(revenue + uplift + rebate - purchase_cost - processing_cost, GRB.MAXIMIZE)

    # Optimize
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
