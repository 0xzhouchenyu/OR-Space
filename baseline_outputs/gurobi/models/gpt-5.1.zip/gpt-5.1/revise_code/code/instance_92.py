import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    return params

def main():
    # Load data
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = load_parameters(data_path)

    num_students = int(params['num_students'])
    num_buses = int(params['num_buses'])
    bus_capacity = int(params['bus_capacity'])
    num_minibuses = int(params['num_minibuses'])
    minibus_capacity = int(params['minibus_capacity'])
    num_drivers = int(params['num_drivers'])
    bus_rental_cost = float(params['bus_rental_cost'])
    minibus_rental_cost = float(params['minibus_rental_cost'])

    # Create model
    model = gp.Model("SchoolTripRevised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = model.addVar(vtype=GRB.INTEGER, name="buses", lb=0, ub=num_buses)
    y = model.addVar(vtype=GRB.INTEGER, name="minibuses", lb=0, ub=num_minibuses)

    # Objective: minimize total rental cost
    model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

    # Constraints

    # Must transport all students
    model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, name="StudentCapacity")

    # Total vehicles limited by number of drivers
    model.addConstr(x + y <= num_drivers, name="DriverLimit")

    # Safety policy: for every minibus, at least two buses
    model.addConstr(x >= 2 * y, name="EscortPolicy")

    # At least one minibus must be rented
    model.addConstr(y >= 1, name="MinMinibus")

    # Optimize
    model.optimize()

    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
