import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                "name": row["Candidate"].strip(),
                "salary": float(row["Salary"].strip()),
                "skill": float(row["Skill_Level"].strip()),
                "pm_exp": float(row["Project_Management_Experience"].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

    budget = params["company_budget"]
    max_employees = int(params["max_employees"])
    min_skill = params["min_skill_level"]
    min_pm_exp = params["min_project_experience"]
    max_gj = int(params["max_one_candidate_g_j"])
    lead_premium = params["lead_premium"]
    min_leads = int(params["min_leads"])
    mentor_bonus = params["mentor_bonus"]
    max_pairs = params["max_pairs"]

    cand_names = [c["name"] for c in candidates]

    # Create model
    model = gp.Model("RevisedHiringOptimization")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = model.addVars(cand_names, vtype=GRB.BINARY, name="x")
    l = model.addVars(cand_names, vtype=GRB.BINARY, name="lead")
    e = model.addVars(cand_names, vtype=GRB.BINARY, name="eng")

    # Count of leads and engineers
    L = model.addVar(vtype=GRB.INTEGER, name="num_leads")
    E = model.addVar(vtype=GRB.INTEGER, name="num_engs")

    # Mentorship pairs (integer)
    z = model.addVar(vtype=GRB.INTEGER, name="pairs")

    # Role assignment: each hired candidate must be exactly one of Lead or Engineer
    for c in cand_names:
        model.addConstr(l[c] + e[c] == x[c], name=f"RoleAssign_{c}")

    # Link L and E
    model.addConstr(L == gp.quicksum(l[c] for c in cand_names), name="TotalLeads")
    model.addConstr(E == gp.quicksum(e[c] for c in cand_names), name="TotalEngs")

    # Original constraints
    # Team size
    model.addConstr(gp.quicksum(x[c] for c in cand_names) <= max_employees, name="MaxEmployees")

    # Skill
    model.addConstr(
        gp.quicksum(cand["skill"] * x[cand["name"]] for cand in candidates) >= min_skill,
        name="MinSkill"
    )

    # Project management experience
    model.addConstr(
        gp.quicksum(cand["pm_exp"] * x[cand["name"]] for cand in candidates) >= min_pm_exp,
        name="MinPMExp"
    )

    # G-J incompatibility
    if "G" in cand_names and "J" in cand_names:
        model.addConstr(x["G"] + x["J"] <= max_gj, name="MaxOneGJ")

    # Minimum leads
    model.addConstr(L >= min_leads, name="MinLeads")

    # Mentorship pairs constraints: z <= L, z <= E, z <= max_pairs
    model.addConstr(z <= L, name="PairsLeads")
    model.addConstr(z <= E, name="PairsEngs")
    model.addConstr(z <= max_pairs, name="PairsCap")

    # Budget constraint on net hiring cost
    base_salary_term = gp.quicksum(cand["salary"] * x[cand["name"]] for cand in candidates)
    lead_premium_term = lead_premium * L
    mentor_bonus_term = mentor_bonus * z
    net_cost = base_salary_term + lead_premium_term - mentor_bonus_term
    model.addConstr(net_cost <= budget, name="Budget")

    # Objective: minimize net hiring cost
    model.setObjective(net_cost, GRB.MINIMIZE)

    # Optimize
    model.optimize()

    # Print final objective value
    obj_val = model.objVal if model.status == GRB.OPTIMAL else float('nan')
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
