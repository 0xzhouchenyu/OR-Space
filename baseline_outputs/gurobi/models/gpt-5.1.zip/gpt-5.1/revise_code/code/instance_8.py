import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    table_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Read general parameters
    shared_temp_handoff_cost = None  # Workers III & V pair cost
    worker_II_V_pair_fee = None      # Workers II & V pair cost

    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'])
            if name == 'shared_temp_handoff_cost':
                shared_temp_handoff_cost = val
            elif name == 'worker_II_V_pair_fee':
                worker_II_V_pair_fee = val

    # Read table_1.csv
    workers = []
    tasks = []
    time_cost = {}
    fixed_cost = {}

    with open(table_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: Worker, A, B, C, D, Fixed_Cost
        tasks = header[1:-1]  # A,B,C,D
        for row in reader:
            w = row[0].strip()
            workers.append(w)
            for j, t in enumerate(tasks):
                time_cost[(w, t)] = float(row[j + 1])
            fixed_cost[w] = float(row[-1])

    # Create model
    model = gp.Model("Revised_Assignment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = model.addVars(
        [(w, t) for w in workers for t in tasks],
        vtype=GRB.BINARY,
        name="x"
    )

    # Pair trigger variables (one-time fees)
    y_III_V = model.addVar(vtype=GRB.BINARY, name="y_III_V")
    y_II_V = model.addVar(vtype=GRB.BINARY, name="y_II_V")

    # Objective: time costs + fixed worker costs + pair costs
    obj = gp.quicksum(time_cost[w, t] * x[w, t] for w in workers for t in tasks)

    # Add fixed cost for each worker selected at least once (here each worker can be used at most once)
    # Selection indicator is sum_t x[w,t]
    obj += gp.quicksum(fixed_cost[w] * gp.quicksum(x[w, t] for t in tasks) for w in workers)

    # Pair fees
    if shared_temp_handoff_cost is not None:
        obj += shared_temp_handoff_cost * y_III_V
    if worker_II_V_pair_fee is not None:
        obj += worker_II_V_pair_fee * y_II_V

    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints

    # Each task assigned to exactly one worker
    for t in tasks:
        model.addConstr(gp.quicksum(x[w, t] for w in workers) == 1, name=f"task_{t}_assign")

    # Each worker assigned to at most one task
    for w in workers:
        model.addConstr(gp.quicksum(x[w, t] for t in tasks) <= 1, name=f"worker_{w}_capacity")

    # Pair trigger constraints for Workers III and V
    # y_III_V = 1 if both III and V are selected
    if 'III' in workers and 'V' in workers:
        model.addConstr(
            gp.quicksum(x['III', t] for t in tasks) >= y_III_V,
            name="III_V_pair_lb1"
        )
        model.addConstr(
            gp.quicksum(x['V', t] for t in tasks) >= y_III_V,
            name="III_V_pair_lb2"
        )
        model.addConstr(
            gp.quicksum(x['III', t] for t in tasks) + gp.quicksum(x['V', t] for t in tasks) <= 2 * y_III_V + 1,
            name="III_V_pair_ub"
        )
    else:
        model.addConstr(y_III_V == 0, name="III_V_pair_disabled")

    # Pair trigger constraints for Workers II and V
    # y_II_V = 1 if both II and V are selected
    if 'II' in workers and 'V' in workers:
        model.addConstr(
            gp.quicksum(x['II', t] for t in tasks) >= y_II_V,
            name="II_V_pair_lb1"
        )
        model.addConstr(
            gp.quicksum(x['V', t] for t in tasks) >= y_II_V,
            name="II_V_pair_lb2"
        )
        model.addConstr(
            gp.quicksum(x['II', t] for t in tasks) + gp.quicksum(x['V', t] for t in tasks) <= 2 * y_II_V + 1,
            name="II_V_pair_ub"
        )
    else:
        model.addConstr(y_II_V == 0, name="II_V_pair_disabled")

    # Optimize
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
