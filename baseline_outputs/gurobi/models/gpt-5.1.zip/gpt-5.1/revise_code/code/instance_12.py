import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load container data
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'])
            params[name] = val

    fixed_setup_cost = params.get('fixed_setup_cost')
    energy_cost_per_kwh = params.get('energy_cost_per_kwh')
    max_total_energy_kwh = params.get('max_total_energy_kwh')
    eco_capacity_share = params.get('eco_capacity_share')
    eco_overhead_cost = params.get('eco_overhead_cost')
    regular_energy_intensity = params.get('regular_energy_intensity_kwh_per_unit')
    eco_energy_intensity = params.get('eco_energy_intensity_kwh_per_unit')

    n = len(containers)

    # Build model
    model = gp.Model("RedStar_Plastic_Containers")
    model.setParam('OutputFlag', 0)

    # Indices: i = production container type, j = demand container type
    # Variables:
    # x_reg[i,j] >= 0: units of type i produced in regular mode to satisfy demand of type j
    # x_eco[i,j] >= 0: units of type i produced in eco mode to satisfy demand of type j
    # y_reg[i] binary: setup regular mode for type i
    # y_eco[i] binary: setup eco mode for type i

    x_reg = {}
    x_eco = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x_reg[i, j] = model.addVar(vtype=GRB.CONTINUOUS, lb=0.0,
                                           name=f"x_reg_{i}_{j}")
                x_eco[i, j] = model.addVar(vtype=GRB.CONTINUOUS, lb=0.0,
                                           name=f"x_eco_{i}_{j}")

    y_reg = {i: model.addVar(vtype=GRB.BINARY, name=f"y_reg_{i}") for i in range(n)}
    y_eco = {i: model.addVar(vtype=GRB.BINARY, name=f"y_eco_{i}") for i in range(n)}

    model.update()

    # Objective: minimize variable production + energy cost + fixed setup + eco overhead
    obj = gp.LinExpr()

    for (i, j), var in x_reg.items():
        prod_cost = containers[i]['cost']
        obj += prod_cost * var
    for (i, j), var in x_eco.items():
        prod_cost = containers[i]['cost']
        obj += prod_cost * var

    # Energy cost
    for (i, j), var in x_reg.items():
        obj += energy_cost_per_kwh * regular_energy_intensity * var
    for (i, j), var in x_eco.items():
        obj += energy_cost_per_kwh * eco_energy_intensity * var

    # Fixed setup costs
    for i in range(n):
        obj += fixed_setup_cost * y_reg[i]
        obj += fixed_setup_cost * y_eco[i]
        obj += eco_overhead_cost * y_eco[i]

    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints

    # 1) Demand satisfaction: for each j, total supplied (reg+eco over all i) >= demand_j
    for j in range(n):
        model.addConstr(
            gp.quicksum(x_reg[i, j] for i in range(n)
                        if (i, j) in x_reg) +
            gp.quicksum(x_eco[i, j] for i in range(n)
                        if (i, j) in x_eco)
            >= containers[j]['demand'],
            name=f"demand_{j}"
        )

    # Big-M for linking and eco-capacity; upper bound on total production of any type
    M = sum(c['demand'] for c in containers)

    # 2) Setup linking: production in each mode only if corresponding setup is active
    for i in range(n):
        total_reg_i = gp.quicksum(x_reg[i, j] for j in range(n) if (i, j) in x_reg)
        total_eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)

        model.addConstr(total_reg_i <= M * y_reg[i], name=f"setup_reg_{i}")
        model.addConstr(total_eco_i <= M * y_eco[i], name=f"setup_eco_{i}")

        # 3) Eco capacity share: eco production for type i <= share * total production of type i
        model.addConstr(
            total_eco_i <= eco_capacity_share * (total_reg_i + total_eco_i),
            name=f"eco_share_{i}"
        )

    # 4) Total energy consumption constraint
    total_energy = gp.LinExpr()
    for (i, j), var in x_reg.items():
        total_energy += regular_energy_intensity * var
    for (i, j), var in x_eco.items():
        total_energy += eco_energy_intensity * var

    model.addConstr(total_energy <= max_total_energy_kwh, name="energy_limit")

    model.optimize()

    final_obj = model.objVal
    print(f"FINAL_OBJ_VALUE: {final_obj}")

if __name__ == "__main__":
    main()
