import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_toy_data(filepath):
    toys = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                'type': row['Toy_Type'].strip(),
                'profit': float(row['Profit_Per_Unit']),
                'wood': float(row['Wood_Required_Per_Unit']),
                'steel': float(row['Steel_Required_Per_Unit']),
            })
    return toys

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    toys = load_toy_data(os.path.join(data_dir, "table_1.csv"))
    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

    available_wood = params['available_wood']
    available_steel = params['available_steel']
    profit_premium_bonus = params['profit_premium_bonus']
    premium_steel_factor = params['premium_steel_factor']
    premium_shift_capacity = params['premium_shift_capacity']

    # Big-M for linking binary/continuous
    M = 1000.0

    model = gp.Model("HausToys_Revised")
    model.setParam('OutputFlag', 0)

    toy_types = [t['type'] for t in toys]
    profit = {t['type']: t['profit'] for t in toys}
    wood_req = {t['type']: t['wood'] for t in toys}
    steel_req = {t['type']: t['steel'] for t in toys}

    # Decision variables
    # Quantities per shift
    x_std = model.addVars(toy_types, lb=0.0, vtype=GRB.CONTINUOUS, name="x_std")
    x_prem = model.addVars(toy_types, lb=0.0, vtype=GRB.CONTINUOUS, name="x_prem")

    # Binary: manufacture on standard / premium shift
    y_std = model.addVars(toy_types, vtype=GRB.BINARY, name="y_std")
    y_prem = model.addVars(toy_types, vtype=GRB.BINARY, name="y_prem")

    # Objective: maximize profit
    obj = gp.quicksum(
        profit[t] * x_std[t] +
        (profit[t] + profit_premium_bonus) * x_prem[t]
        for t in toy_types
    )
    model.setObjective(obj, GRB.MAXIMIZE)

    # Resource constraints
    # Wood: same requirement per unit on both shifts
    model.addConstr(
        gp.quicksum(wood_req[t] * (x_std[t] + x_prem[t]) for t in toy_types) <= available_wood,
        name="Wood_Constraint"
    )

    # Steel: premium shift uses premium_steel_factor times steel
    model.addConstr(
        gp.quicksum(
            steel_req[t] * x_std[t] + premium_steel_factor * steel_req[t] * x_prem[t]
            for t in toy_types
        ) <= available_steel,
        name="Steel_Constraint"
    )

    # Premium shift capacity: total premium units limited
    model.addConstr(
        gp.quicksum(x_prem[t] for t in toy_types) <= premium_shift_capacity,
        name="Premium_Shift_Capacity"
    )

    # Linking constraints: quantities to binaries
    for t in toy_types:
        # Cannot produce same toy on both shifts
        model.addConstr(y_std[t] + y_prem[t] <= 1, name=f"One_Shift_{t}")

        # Link quantities to activation
        model.addConstr(x_std[t] <= M * y_std[t], name=f"Link_std_{t}")
        model.addConstr(x_prem[t] <= M * y_prem[t], name=f"Link_prem_{t}")

    # Truck-train exclusion: if trucks produced on any shift, no trains on any shift
    # y_any_t = y_std[t] + y_prem[t]
    if 'truck' in toy_types and 'train' in toy_types:
        model.addConstr(
            (y_std['truck'] + y_prem['truck']) +
            (y_std['train'] + y_prem['train']) <= 1,
            name="Truck_Train_Exclusion"
        )

    # Boat-airplane dependency: if boats any shift, airplanes any shift
    if 'boat' in toy_types and 'airplane' in toy_types:
        model.addConstr(
            (y_std['boat'] + y_prem['boat']) <=
            (y_std['airplane'] + y_prem['airplane']),
            name="Boat_Airplane_Dependency"
        )

    # Boat-train limit: total boats (all shifts) <= total trains (all shifts)
    if 'boat' in toy_types and 'train' in toy_types:
        model.addConstr(
            (x_std['boat'] + x_prem['boat']) <=
            (x_std['train'] + x_prem['train']),
            name="Boat_Train_Limit"
        )

    model.optimize()

    obj_val = model.objVal if model.status == GRB.OPTIMAL else float('nan')
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
