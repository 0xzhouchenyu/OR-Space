import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
table_1_path = os.path.join(data_dir, "table_1.csv")
general_params_path = os.path.join(data_dir, "general_parameters.csv")

# Load device data
devices = []
with open(table_1_path, "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            "name": row["Device"].strip(),
            "prep_cost": float(row["Prep_Completion_Cost_Yuan"].strip()),
            "unit_cost": float(row["Unit_Production_Cost_Yuan_per_Unit"].strip()),
            "max_cap": float(row["Max_Processing_Capacity_Units"].strip())
        })

# Load general parameters into dict
params = {}
with open(general_params_path, "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        val = float(row["Value"].strip())
        params[name] = val

required_units = params["required_units"]
energy_budget_peak = params["energy_budget_peak"]
energy_budget_offpeak = params["energy_budget_offpeak"]
startup_budget = params["startup_budget"]
startup_cost = params["startup_cost"]
energy_price_peak = params["energy_price_peak"]
energy_price_offpeak = params["energy_price_offpeak"]

# Energy per unit and startup energy per device
energy_per_unit = {}
startup_energy = {}
for d in devices:
    name = d["name"]
    energy_per_unit[name] = params[f"energy_per_unit_{name}"]
    startup_energy[name] = params[f"startup_energy_{name}"]

# Periods
periods = ["peak", "offpeak"]

# Create model
m = gp.Model("RevisedMinCostProduction")
m.setParam('OutputFlag', 0)

# Decision variables
# x[d,p]: units produced on device d in period p
x = {}
# y[d,p]: 1 if device d is started/used in period p
y = {}

for dev in devices:
    dname = dev["name"]
    for p in periods:
        x[dname, p] = m.addVar(lb=0.0, ub=dev["max_cap"], vtype=GRB.CONTINUOUS,
                               name=f"x_{dname}_{p}")
        y[dname, p] = m.addVar(vtype=GRB.BINARY, name=f"y_{dname}_{p}")

m.update()

# Constraints

# Total production requirement
m.addConstr(gp.quicksum(x[d["name"], p] for d in devices for p in periods) == required_units,
            name="TotalProduction")

# Capacity linking per device-period: x[d,p] <= max_cap_d * y[d,p]
for d in devices:
    dname = d["name"]
    cap = d["max_cap"]
    for p in periods:
        m.addConstr(x[dname, p] <= cap * y[dname, p], name=f"Link_{dname}_{p}")

# Device total production across periods cannot exceed max capacity (if needed)
for d in devices:
    dname = d["name"]
    cap = d["max_cap"]
    m.addConstr(gp.quicksum(x[dname, p] for p in periods) <= cap,
                name=f"TotalCap_{dname}")

# Peak energy budget
m.addConstr(
    gp.quicksum(x[d["name"], "peak"] * energy_per_unit[d["name"]] for d in devices) +
    gp.quicksum(y[d["name"], "peak"] * startup_energy[d["name"]] for d in devices)
    <= energy_budget_peak,
    name="EnergyBudgetPeak"
)

# Off-peak energy budget
m.addConstr(
    gp.quicksum(x[d["name"], "offpeak"] * energy_per_unit[d["name"]] for d in devices) +
    gp.quicksum(y[d["name"], "offpeak"] * startup_energy[d["name"]] for d in devices)
    <= energy_budget_offpeak,
    name="EnergyBudgetOffpeak"
)

# Startup budget across both periods
m.addConstr(
    gp.quicksum(y[d["name"], p] * startup_cost for d in devices for p in periods)
    <= startup_budget,
    name="StartupBudget"
)

# Objective: minimize total cost
# Components:
# - Prep completion cost per device if used in any period (one-time per device)
# - Unit production cost (per unit, independent of period)
# - Energy cost: period-specific (per kWh) for unit production and startup energy

obj = gp.LinExpr()

for d in devices:
    dname = d["name"]
    prep_cost = d["prep_cost"]
    unit_cost = d["unit_cost"]

    # Binary to indicate whether device is used in any period
    z_d = m.addVar(vtype=GRB.BINARY, name=f"z_{dname}")
    # z_d >= y[d,peak], z_d >= y[d,offpeak]
    for p in periods:
        m.addConstr(z_d >= y[dname, p], name=f"UseLink_{dname}_{p}")
    # Optional: if z_d = 0 then all y[d,p]=0 is already implied by above constraints

    # Prep cost once per device
    obj += prep_cost * z_d

    # Unit production costs (same across periods)
    for p in periods:
        obj += unit_cost * x[dname, p]

        # Energy cost for production
        if p == "peak":
            energy_price = energy_price_peak
        else:
            energy_price = energy_price_offpeak
        obj += energy_price * energy_per_unit[dname] * x[dname, p]

        # Startup energy cost when device is started in period p
        obj += energy_price * startup_energy[dname] * y[dname, p]

m.setObjective(obj, GRB.MINIMIZE)

# Optimize
m.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {m.objVal}")
