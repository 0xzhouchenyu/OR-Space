import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Load parameters
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_parameters(data_path)

    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']

    # Extract parameters
    profit_per_acre = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons']
    }

    total_farm_area = params['total_farm_area']
    min_a_to_p = params['min_apples_to_pears_ratio']
    min_a_to_l = params['min_apples_to_lemons_ratio']
    o_to_l = params['oranges_to_lemons_ratio']
    max_fruit_types = int(params['max_fruit_types'])

    water_per_acre = {
        ('apples', 'spring'): params['water_per_acre_apples_spring'],
        ('apples', 'autumn'): params['water_per_acre_apples_autumn'],
        ('pears', 'spring'): params['water_per_acre_pears_spring'],
        ('pears', 'autumn'): params['water_per_acre_pears_autumn'],
        ('oranges', 'spring'): params['water_per_acre_oranges_spring'],
        ('oranges', 'autumn'): params['water_per_acre_oranges_autumn'],
        ('lemons', 'spring'): params['water_per_acre_lemons_spring'],
        ('lemons', 'autumn'): params['water_per_acre_lemons_autumn'],
    }

    water_cap_spring = params['water_cap_spring']
    water_cap_autumn = params['water_cap_autumn']
    total_water_budget = params['total_water_budget']
    min_annual_water_per_fruit = params['min_annual_water_per_fruit']
    diversification_reward = params['diversification_reward']

    # Build model
    m = gp.Model("farm_two_seasons")
    m.setParam('OutputFlag', 0)

    # Decision variables
    x = m.addVars(fruits, seasons, name="x", lb=0.0)  # acres per fruit per season
    y = m.addVars(fruits, vtype=GRB.BINARY, name="y")  # whether fruit is included
    z = m.addVar(vtype=GRB.BINARY, name="z")  # diversification indicator

    # Helper expressions
    # Annual acres and water per fruit
    annual_acres = {f: gp.quicksum(x[f, s] for s in seasons) for f in fruits}
    annual_water = {
        f: gp.quicksum(water_per_acre[(f, s)] * x[f, s] for s in seasons)
        for f in fruits
    }

    # Objective: profit from all seasons + diversification reward
    profit_expr = gp.quicksum(
        profit_per_acre[f] * x[f, s]
        for f in fruits for s in seasons
    )
    m.setObjective(profit_expr + diversification_reward * z, GRB.MAXIMIZE)

    # Land constraints per season
    for s in seasons:
        m.addConstr(gp.quicksum(x[f, s] for f in fruits) <= total_farm_area,
                    name=f"land_{s}")

    # Water constraints per season
    m.addConstr(
        gp.quicksum(water_per_acre[(f, 'spring')] * x[f, 'spring'] for f in fruits)
        <= water_cap_spring,
        name="water_spring"
    )
    m.addConstr(
        gp.quicksum(water_per_acre[(f, 'autumn')] * x[f, 'autumn'] for f in fruits)
        <= water_cap_autumn,
        name="water_autumn"
    )

    # Annual water budget
    m.addConstr(
        gp.quicksum(annual_water[f] for f in fruits) <= total_water_budget,
        name="total_water_budget"
    )

    # Annual mix constraints (on total acres across seasons)
    # apples >= min_a_to_p * pears
    m.addConstr(annual_acres['apples'] >= min_a_to_p * annual_acres['pears'],
                name="apple_pear_ratio")
    # apples >= min_a_to_l * lemons
    m.addConstr(annual_acres['apples'] >= min_a_to_l * annual_acres['lemons'],
                name="apple_lemon_ratio")
    # oranges == o_to_l * lemons
    m.addConstr(annual_acres['oranges'] == o_to_l * annual_acres['lemons'],
                name="orange_lemon_ratio")

    # Link y_f to water and ensure minimum annual water if grown
    # Also ensure if any acreage is planted then y_f must be 1
    big_M_water = total_water_budget
    big_M_acre = 2 * total_farm_area  # upper bound on annual acres per fruit

    for f in fruits:
        # If y_f = 1 then annual_water[f] >= min_annual_water_per_fruit
        m.addConstr(annual_water[f] >= min_annual_water_per_fruit * y[f],
                    name=f"min_water_if_used_{f}")
        # If y_f = 0 then annual_water[f] <= 0, implemented via big-M
        m.addConstr(annual_water[f] <= big_M_water * y[f],
                    name=f"water_upper_if_used_{f}")
        # Force y_f = 1 if any positive acreage: annual_acres[f] <= M * y_f
        m.addConstr(annual_acres[f] <= big_M_acre * y[f],
                    name=f"acre_link_{f}")

    # Limit on number of fruits
    m.addConstr(gp.quicksum(y[f] for f in fruits) <= max_fruit_types,
                name="max_fruit_types")

    # Diversification reward: z = 1 iff at least two fruits are genuinely grown
    # Because y_f already implies minimum water when 1, "genuinely" matches y_f = 1
    # Enforce: z <= sum(y_f)/2 and z >= sum(y_f) - 1
    sum_y = gp.quicksum(y[f] for f in fruits)
    m.addConstr(z <= sum_y / 2.0, name="z_upper")
    m.addConstr(z >= sum_y - 1.0, name="z_lower")

    # Optimize
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
