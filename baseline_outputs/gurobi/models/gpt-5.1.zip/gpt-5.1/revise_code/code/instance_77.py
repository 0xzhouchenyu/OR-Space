import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load processing costs from table_1.csv
    cost = {}  # cost[(machine, part)] = value
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p) for p in header[1:]]
        for row in reader:
            machine = row[0].strip()
            for j, p in enumerate(parts):
                cost[(machine, p)] = float(row[j + 1])

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    d = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    max_C = int(params['max_parts_on_C'])
    overtime_threshold = int(params['overtime_threshold'])
    overtime_penalty = params['overtime_penalty']

    machines = ['A', 'B', 'C']

    # Build model
    model = gp.Model("RevisedMachineAssignment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[m,p] = 1 if part p is processed on machine m
    x = model.addVars(machines, parts, vtype=GRB.BINARY, name="x")

    # y[m] = 1 if machine m is used
    y = model.addVars(machines, vtype=GRB.BINARY, name="y")

    # z[m] = 1 if machine m incurs overtime penalty
    z = model.addVars(machines, vtype=GRB.BINARY, name="z")

    # Objective: processing costs + setup costs + overtime penalties
    proc_cost = gp.quicksum(cost[(m, p)] * x[m, p] for m in machines for p in parts)
    setup_cost = gp.quicksum(d[m] * y[m] for m in machines)
    overtime_cost = gp.quicksum(overtime_penalty * z[m] for m in machines)
    model.setObjective(proc_cost + setup_cost + overtime_cost, GRB.MINIMIZE)

    # Constraints

    # 1. Each part assigned to exactly one machine
    for p in parts:
        model.addConstr(gp.quicksum(x[m, p] for m in machines) == 1, name=f"assign_part_{p}")

    # Linking y to x: if any part on machine m, y[m] = 1
    for m in machines:
        for p in parts:
            model.addConstr(x[m, p] <= y[m], name=f"link_y_{m}_{p}")

    # 2. Relation between parts 1 and 2:
    # x[A,1] + x[A,2] = 1
    model.addConstr(x['A', 1] + x['A', 2] == 1, name="part1_2_relation")

    # 3. Fixed assignments
    model.addConstr(x['A', 3] == 1, name="fixed_part_3_A")
    model.addConstr(x['B', 4] == 1, name="fixed_part_4_B")
    model.addConstr(x['C', 5] == 1, name="fixed_part_5_C")

    # 4. At most max_C parts on machine C
    model.addConstr(gp.quicksum(x['C', p] for p in parts) <= max_C, name="max_parts_C")

    # 5. Overtime constraints:
    # If number of parts on m > overtime_threshold then z[m] = 1 (and pay penalty).
    # Implement with:
    # sum_p x[m,p] <= overtime_threshold + (bigM - overtime_threshold) * z[m]
    # and
    # sum_p x[m,p] >= (overtime_threshold + 1) * z[m]
    bigM = len(parts)
    for m in machines:
        total_parts_m = gp.quicksum(x[m, p] for p in parts)
        model.addConstr(total_parts_m <= overtime_threshold + (bigM - overtime_threshold) * z[m],
                        name=f"overtime_upper_{m}")
        model.addConstr(total_parts_m >= (overtime_threshold + 1) * z[m],
                        name=f"overtime_lower_{m}")

    # Optimize
    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
