import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

initial_fund = params["initial_fund"]  # 300000
annual_rate = params["annual_profit_rate"] / 100  # 0.20
inv_limit_y1 = params["investment_limit_year1"]  # 150000
return_rate_y1y2 = params["return_rate_year1_to_year2"] / 100  # 1.50
inv_limit_y2 = params["investment_limit_year2"]  # 200000
return_rate_y2y3 = params["return_rate_year2_to_year3"] / 100  # 1.60
inv_limit_y3 = params["investment_limit_year3"]  # 100000
profit_rate_y3 = params["profit_rate_year3"] / 100  # 0.40
fee_y1 = params["fee_year1"]
fee_y2 = params["fee_year2"]
fee_y3 = params["fee_year3"]

# Model
m = gp.Model("Investment_Optimization_Revised")
m.setParam('OutputFlag', 0)

# Decision variables
a1 = m.addVar(lb=0.0, name="a1")
a2 = m.addVar(lb=0.0, name="a2")
a3 = m.addVar(lb=0.0, name="a3")

b1 = m.addVar(lb=0.0, ub=inv_limit_y1, name="b1")
c2 = m.addVar(lb=0.0, ub=inv_limit_y2, name="c2")
d3 = m.addVar(lb=0.0, ub=inv_limit_y3, name="d3")

# Binary variables for using special investments
y1 = m.addVar(vtype=GRB.BINARY, name="y1")  # for b1
y2 = m.addVar(vtype=GRB.BINARY, name="y2")  # for c2
y3 = m.addVar(vtype=GRB.BINARY, name="y3")  # for d3

# Link binaries to continuous special investment usage (Big-M with given limits)
m.addConstr(b1 <= inv_limit_y1 * y1, "link_b1_y1")
m.addConstr(c2 <= inv_limit_y2 * y2, "link_c2_y2")
m.addConstr(d3 <= inv_limit_y3 * y3, "link_d3_y3")

# Budget constraints

# Year 1: investments a1 (annual) and b1 (special) plus fee if b1 used
m.addConstr(a1 + b1 + fee_y1 * y1 <= initial_fund, "Year1_budget")

# Funds available at start of Year 2:
# cash from year1 = initial_fund - a1 - b1 - fee_y1*y1
# plus return from a1: a1*(1+annual_rate)
funds_year2 = (initial_fund - a1 - b1 - fee_y1 * y1) + a1 * (1 + annual_rate)

# Year 2: investments a2 and c2 plus fee if c2 used
m.addConstr(a2 + c2 + fee_y2 * y2 <= funds_year2, "Year2_budget")

# Funds available at start of Year 3:
# cash from year2 = funds_year2 - a2 - c2 - fee_y2*y2
# plus returns from a2: a2*(1+annual_rate)
# plus returns from b1: b1*return_rate_y1y2
funds_year3 = (funds_year2 - a2 - c2 - fee_y2 * y2) + a2 * (1 + annual_rate) + b1 * return_rate_y1y2

# Year 3: investments a3 and d3 plus fee if d3 used
m.addConstr(a3 + d3 + fee_y3 * y3 <= funds_year3, "Year3_budget")

# Cash remaining at start of year3 after investments and fee
cash_year3 = funds_year3 - a3 - d3 - fee_y3 * y3

# Total end-of-year-3 net funds:
# cash_year3 + returns from a3, c2, d3
total_end = cash_year3 + a3 * (1 + annual_rate) + c2 * return_rate_y2y3 + d3 * (1 + profit_rate_y3)

m.setObjective(total_end, GRB.MAXIMIZE)

m.optimize()

obj_val = m.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
