import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read table_1.csv
    materials = []
    sulfur_content = {}
    purchase_price = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            mat = row["Material"].strip()
            materials.append(mat)
            # Handle possible space in column names
            if " Sulfur_Content_Percentage" in row:
                sulfur_content[mat] = float(row[" Sulfur_Content_Percentage"].strip())
            else:
                sulfur_content[mat] = float(row["Sulfur_Content_Percentage"].strip())
            for key in row:
                if "Purchase_Price" in key:
                    purchase_price[mat] = float(row[key].strip())

    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            if " Value" in row:
                val = float(row[" Value"].strip())
            else:
                val = float(row["Value"].strip())
            params[name] = val

    max_sulfur_A_prem = params["max_sulfur_content_A_premium"]
    max_sulfur_A_std = params["max_sulfur_content_A_standard"]
    max_sulfur_B_prem = params["max_sulfur_content_B_premium"]
    max_sulfur_B_std = params["max_sulfur_content_B_standard"]

    price_A_prem = params["selling_price_A_premium"]
    price_A_std = params["selling_price_A_standard"]
    price_B_prem = params["selling_price_B_premium"]
    price_B_std = params["selling_price_B_standard"]

    max_supply_D = params["max_supply_D"]
    demand_A = params["market_demand_A"]
    demand_B = params["market_demand_B"]

    min_prem_A = params["min_premium_share_A"]
    max_prem_A = params["max_premium_share_A"]
    min_prem_B = params["min_premium_share_B"]
    max_prem_B = params["max_premium_share_B"]

    # Define product streams
    streams = ["A_premium", "A_standard", "B_premium", "B_standard"]

    # Mapping for convenience
    stream_family = {
        "A_premium": "A",
        "A_standard": "A",
        "B_premium": "B",
        "B_standard": "B",
    }

    stream_price = {
        "A_premium": price_A_prem,
        "A_standard": price_A_std,
        "B_premium": price_B_prem,
        "B_standard": price_B_std,
    }

    stream_sulfur_cap = {
        "A_premium": max_sulfur_A_prem,
        "A_standard": max_sulfur_A_std,
        "B_premium": max_sulfur_B_prem,
        "B_standard": max_sulfur_B_std,
    }

    # Create model
    m = gp.Model("Revised_Mixing_Problem")
    m.setParam("OutputFlag", 0)

    # Decision variables: x[m,s] = tons of material m used in stream s
    x = m.addVars(materials, streams, name="x", lb=0.0)

    # Total production per stream
    total_stream = {}
    for s in streams:
        total_stream[s] = gp.quicksum(x[mat, s] for mat in materials)

    # Objective: maximize profit = revenue - cost
    revenue = gp.quicksum(stream_price[s] * total_stream[s] for s in streams)
    cost = gp.quicksum(purchase_price[mat] * x[mat, s] for mat in materials for s in streams)
    m.setObjective(revenue - cost, GRB.MAXIMIZE)

    # Sulfur constraints for each stream
    for s in streams:
        lhs = gp.quicksum(sulfur_content[mat] * x[mat, s] for mat in materials)
        m.addConstr(lhs <= stream_sulfur_cap[s] * total_stream[s], name=f"Sulfur_{s}")

    # Supply limit for material D
    if "D" in materials:
        m.addConstr(
            gp.quicksum(x["D", s] for s in streams) <= max_supply_D,
            name="Supply_D",
        )

    # Market demand constraints at family level
    total_A = total_stream["A_premium"] + total_stream["A_standard"]
    total_B = total_stream["B_premium"] + total_stream["B_standard"]

    m.addConstr(total_A <= demand_A, name="Demand_A")
    m.addConstr(total_B <= demand_B, name="Demand_B")

    # Premium participation constraints
    premium_A = total_stream["A_premium"]
    premium_B = total_stream["B_premium"]

    m.addConstr(premium_A >= min_prem_A, name="Min_Premium_A")
    m.addConstr(premium_A <= max_prem_A, name="Max_Premium_A")
    m.addConstr(premium_B >= min_prem_B, name="Min_Premium_B")
    m.addConstr(premium_B <= max_prem_B, name="Max_Premium_B")

    # Optimize
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
