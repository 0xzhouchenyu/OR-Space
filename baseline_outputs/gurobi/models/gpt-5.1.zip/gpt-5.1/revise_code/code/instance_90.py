import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")

    params = load_general_parameters(data_path)

    shirts_inventory = params['shirts_inventory']
    pants_inventory = params['pants_inventory']

    price_a = params['package_a_price']
    price_b = params['package_b_price']
    price_c = params['package_c_price']

    shirts_a = params['package_a_shirts']
    pants_a = params['package_a_pants']
    shirts_b = params['package_b_shirts']
    pants_b = params['package_b_pants']
    shirts_c = params['package_c_shirts']
    pants_c = params['package_c_pants']

    min_batch_a = params['min_campaign_batch_a']
    min_batch_b = params['min_campaign_batch_b']
    min_batch_c = params['min_campaign_batch_c']

    activation_cost_a = params['activation_cost_a']
    activation_cost_b = params['activation_cost_b']
    activation_cost_c = params['activation_cost_c']

    labor_hours_per_A = params['labor_hours_per_A']
    labor_hours_per_B = params['labor_hours_per_B']
    labor_hours_per_C = params['labor_hours_per_C']
    labor_hours_total = params['labor_hours_total']

    bigM_a = params['bigM_a']
    bigM_b = params['bigM_b']
    bigM_c = params['bigM_c']

    b_thr = params['package_b_review_threshold']
    b_charge = params['package_b_review_charge']

    c_thr = params['package_c_review_threshold']
    c_charge = params['package_c_review_charge']

    m = gp.Model("Revised_Maximize_Revenue")
    m.setParam('OutputFlag', 0)

    # Decision variables: package counts
    x_a = m.addVar(vtype=GRB.INTEGER, lb=0, name="Package_A")
    x_b = m.addVar(vtype=GRB.INTEGER, lb=0, name="Package_B")
    x_c = m.addVar(vtype=GRB.INTEGER, lb=0, name="Package_C")

    # Campaign activation binaries
    y_a = m.addVar(vtype=GRB.BINARY, name="Activate_A")
    y_b = m.addVar(vtype=GRB.BINARY, name="Activate_B")
    y_c = m.addVar(vtype=GRB.BINARY, name="Activate_C")

    # Review charge gate binaries
    z_b = m.addVar(vtype=GRB.BINARY, name="B_review_trigger")
    z_c = m.addVar(vtype=GRB.BINARY, name="C_review_trigger")

    # Inventory constraints
    m.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inventory, "Shirts_Inventory")
    m.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inventory, "Pants_Inventory")

    # Labor constraint
    m.addConstr(labor_hours_per_A * x_a +
                labor_hours_per_B * x_b +
                labor_hours_per_C * x_c <= labor_hours_total, "Labor_Hours")

    # Campaign linking and minimum batch constraints
    m.addConstr(x_a <= bigM_a * y_a, "Link_A_upper")
    m.addConstr(x_b <= bigM_b * y_b, "Link_B_upper")
    m.addConstr(x_c <= bigM_c * y_c, "Link_C_upper")

    m.addConstr(x_a >= min_batch_a * y_a, "Min_Batch_A")
    m.addConstr(x_b >= min_batch_b * y_b, "Min_Batch_B")
    m.addConstr(x_c >= min_batch_c * y_c, "Min_Batch_C")

    # Gate modeling for Package B review charge
    # z_b = 1 if x_b > b_thr, 0 otherwise
    # Ensure: if z_b = 0 then x_b <= b_thr
    m.addConstr(x_b <= b_thr + bigM_b * z_b, "B_gate_upper1")
    # Ensure: if z_b = 1 then x_b >= b_thr+1 (whenever campaign active)
    # bigM formulation tied to y_b to avoid forcing sales when campaign off
    m.addConstr(x_b >= (b_thr + 1) * z_b, "B_gate_lower1")

    # Gate modeling for Package C review charge
    m.addConstr(x_c <= c_thr + bigM_c * z_c, "C_gate_upper1")
    m.addConstr(x_c >= (c_thr + 1) * z_c, "C_gate_lower1")

    # Objective: revenue minus activation costs and review charges
    revenue = price_a * x_a + price_b * x_b + price_c * x_c
    activation_costs = activation_cost_a * y_a + activation_cost_b * y_b + activation_cost_c * y_c
    review_costs = b_charge * z_b + c_charge * z_c

    m.setObjective(revenue - activation_costs - review_costs, GRB.MAXIMIZE)

    m.optimize()

    obj_val = m.objVal if m.status == GRB.OPTIMAL or m.status == GRB.SUBOPTIMAL else 0.0
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
