import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Read product data
    products = []
    with open(os.path.join(base_dir, "data", "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                "name": row["Product Name"].strip(),
                "labor": float(row["Labor per unit"].strip()),
                "material": float(row["Material per unit"].strip()),
                "price": float(row["Selling Price"].strip()),
                "var_cost": float(row["Variable Cost"].strip())
            })

    # Map product order: assume same order as in fixed costs & parameters
    prod_index = {p["name"]: i for i, p in enumerate(products)}

    # Read general parameters
    params = {}
    with open(os.path.join(base_dir, "data", "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

    available_labor = params["available_labor"]
    available_material = params["available_material"]

    fixed_costs = [
        params["fixed_cost_shirts"],
        params["fixed_cost_short_sleeves"],
        params["fixed_cost_casual_clothes"]
    ]

    seg_reg_disc = params["segment_regular_discount"]
    seg_pr_disc = params["segment_promo_discount"]
    promo_labor_cap = params["segment_promo_labor_cap"]
    promo_material_cap = params["segment_promo_material_cap"]

    min_batch = [
        params["min_batch_shirts"],
        params["min_batch_short_sleeves"],
        params["min_batch_casual_clothes"]
    ]
    max_prod = [
        params["max_prod_shirts"],
        params["max_prod_short_sleeves"],
        params["max_prod_casual_clothes"]
    ]

    n = len(products)

    # Build model
    m = gp.Model("clothing_production_revised")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # x_reg[i], x_promo[i] : integer production for regular and promo segments
    x_reg = m.addVars(n, vtype=GRB.INTEGER, name="x_reg", lb=0)
    x_pr = m.addVars(n, vtype=GRB.INTEGER, name="x_pr", lb=0)

    # y_equipment[i] : 1 if equipment for product i is active
    y_eq = m.addVars(n, vtype=GRB.BINARY, name="y_eq")

    # y_reg[i], y_promo[i] : 1 if product i is present in regular/promo segment
    y_reg = m.addVars(n, vtype=GRB.BINARY, name="y_reg")
    y_pr = m.addVars(n, vtype=GRB.BINARY, name="y_pr")

    # Objective: profit
    profit_terms = []
    for i in range(n):
        p = products[i]
        base_price = p["price"]
        unit_profit_reg = seg_reg_disc * base_price - p["var_cost"]
        unit_profit_pr = seg_pr_disc * base_price - p["var_cost"]

        profit_terms.append(unit_profit_reg * x_reg[i])
        profit_terms.append(unit_profit_pr * x_pr[i])
        # subtract fixed cost if equipment is on
        profit_terms.append(-fixed_costs[i] * y_eq[i])

    m.setObjective(gp.quicksum(profit_terms), GRB.MAXIMIZE)

    # Constraints

    # Total labor and material
    m.addConstr(
        gp.quicksum(products[i]["labor"] * (x_reg[i] + x_pr[i]) for i in range(n)) <= available_labor,
        name="total_labor"
    )
    m.addConstr(
        gp.quicksum(products[i]["material"] * (x_reg[i] + x_pr[i]) for i in range(n)) <= available_material,
        name="total_material"
    )

    # Promo segment caps
    m.addConstr(
        gp.quicksum(products[i]["labor"] * x_pr[i] for i in range(n)) <= promo_labor_cap,
        name="promo_labor_cap"
    )
    m.addConstr(
        gp.quicksum(products[i]["material"] * x_pr[i] for i in range(n)) <= promo_material_cap,
        name="promo_material_cap"
    )

    # Equipment activation and big-M bounds for total production
    for i in range(n):
        # total production for product i
        m.addConstr(x_reg[i] + x_pr[i] <= max_prod[i] * y_eq[i], name=f"max_prod_{i}")

        # minimum batch if equipment on
        m.addConstr(x_reg[i] + x_pr[i] >= min_batch[i] * y_eq[i], name=f"min_batch_{i}")

    # Segment presence gates based on product-specific minimum batch size
    # If segment present (y_reg/y_pr = 1), must meet min_batch; if 0, production in that segment must be 0
    for i in range(n):
        # Regular segment
        m.addConstr(x_reg[i] <= max_prod[i] * y_reg[i], name=f"reg_upper_{i}")
        m.addConstr(x_reg[i] >= min_batch[i] * y_reg[i], name=f"reg_lower_{i}")

        # Promo segment
        m.addConstr(x_pr[i] <= max_prod[i] * y_pr[i], name=f"promo_upper_{i}")
        m.addConstr(x_pr[i] >= min_batch[i] * y_pr[i], name=f"promo_lower_{i}")

        # If either segment is present, equipment must be on
        m.addConstr(y_reg[i] <= y_eq[i], name=f"reg_eq_link_{i}")
        m.addConstr(y_pr[i] <= y_eq[i], name=f"promo_eq_link_{i}")

    m.optimize()

    obj_val = m.objVal if m.status == GRB.OPTIMAL else float('-inf')
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
