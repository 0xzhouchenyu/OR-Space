import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params


def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")

    # Load parameters
    params = load_parameters(data_path)

    cow_price = params['cow_selling_price']
    sheep_price = params['sheep_selling_price']
    chicken_price = params['chicken_selling_price']

    cow_feed = params['cow_feed_cost']
    sheep_feed = params['sheep_feed_cost']
    chicken_feed = params['chicken_feed_cost']

    cow_manure = params['cow_manure_production']
    sheep_manure = params['sheep_manure_production']
    chicken_manure = params['chicken_manure_production']

    max_manure = params['max_manure_capacity']
    max_chickens = params['max_chickens']
    min_cows = params['min_cows']
    min_sheep = params['min_sheep']
    max_total = params['max_total_animals']

    premium_capacity_multiplier = params['premium_capacity_multiplier']
    premium_manure_multiplier = params['premium_manure_multiplier']
    expansion_cost = params['expansion_cost']
    premium_feed_multiplier = params['premium_feed_multiplier']

    base_land_usage_cow = params['base_land_usage_cow']
    base_land_usage_sheep = params['base_land_usage_sheep']
    base_land_usage_chicken = params['base_land_usage_chicken']
    base_land_capacity = params['base_land_capacity']
    expansion_land_increase = params['expansion_land_increase']

    # Big-M values for linking premium animals with expansion
    # Upper bounds based on expanded capacities
    max_total_expanded = max_total * premium_capacity_multiplier
    max_manure_expanded = max_manure * premium_manure_multiplier
    land_capacity_expanded = base_land_capacity + expansion_land_increase

    # Big-M for number of animals: cannot exceed min of expanded total and land-driven capacities
    # Compute conservative per-species upper bounds from capacities
    # From total animals (expanded)
    M_total = int(max_total_expanded)

    # From manure capacity, assuming all of one animal type
    M_cow_manure = int(max_manure_expanded // cow_manure) if cow_manure > 0 else M_total
    M_sheep_manure = int(max_manure_expanded // sheep_manure) if sheep_manure > 0 else M_total
    M_chicken_manure = int(max_manure_expanded // chicken_manure) if chicken_manure > 0 else max_chickens

    # From land capacity
    M_cow_land = int(land_capacity_expanded // base_land_usage_cow) if base_land_usage_cow > 0 else M_total
    M_sheep_land = int(land_capacity_expanded // base_land_usage_sheep) if base_land_usage_sheep > 0 else M_total
    M_chicken_land = int(land_capacity_expanded // base_land_usage_chicken) if base_land_usage_chicken > 0 else max_chickens

    M_cow = min(M_total, M_cow_manure, M_cow_land)
    M_sheep = min(M_total, M_sheep_manure, M_sheep_land)
    M_chicken = min(max_chickens, M_chicken_manure, M_chicken_land)

    # Model
    model = gp.Model("RevisedFarmProfit")
    model.setParam('OutputFlag', 0)

    # Decision variables
    cows_reg = model.addVar(vtype=GRB.INTEGER, name="cows_regular", lb=0)
    cows_prem = model.addVar(vtype=GRB.INTEGER, name="cows_premium", lb=0)

    sheep_reg = model.addVar(vtype=GRB.INTEGER, name="sheep_regular", lb=0)
    sheep_prem = model.addVar(vtype=GRB.INTEGER, name="sheep_premium", lb=0)

    chickens_reg = model.addVar(vtype=GRB.INTEGER, name="chickens_regular", lb=0, ub=max_chickens)
    chickens_prem = model.addVar(vtype=GRB.INTEGER, name="chickens_premium", lb=0, ub=max_chickens)

    # Binary variable for expansion gate
    expanded = model.addVar(vtype=GRB.BINARY, name="expanded")

    # Aggregate variables (for convenience)
    cows = model.addVar(vtype=GRB.INTEGER, name="cows_total")
    sheep = model.addVar(vtype=GRB.INTEGER, name="sheep_total")
    chickens = model.addVar(vtype=GRB.INTEGER, name="chickens_total")

    # Link aggregate variables with components
    model.addConstr(cows == cows_reg + cows_prem, name="cows_aggregation")
    model.addConstr(sheep == sheep_reg + sheep_prem, name="sheep_aggregation")
    model.addConstr(chickens == chickens_reg + chickens_prem, name="chickens_aggregation")

    # Minimum demand constraints on totals
    model.addConstr(cows >= min_cows, name="min_cows")
    model.addConstr(sheep >= min_sheep, name="min_sheep")

    # Chicken bound applies to total chickens
    model.addConstr(chickens <= max_chickens, name="max_chickens_total")

    # Premium animals only when expanded: use big-M constraints
    model.addConstr(cows_prem <= M_cow * expanded, name="cow_premium_expanded")
    model.addConstr(sheep_prem <= M_sheep * expanded, name="sheep_premium_expanded")
    model.addConstr(chickens_prem <= M_chicken * expanded, name="chicken_premium_expanded")

    # Effective total animal capacity
    total_animals = cows + sheep + chickens
    model.addConstr(
        total_animals <= max_total + (max_total_expanded - max_total) * expanded,
        name="total_animal_capacity"
    )

    # Manure capacity with multiplier under expansion
    total_manure = (
        cow_manure * cows +
        sheep_manure * sheep +
        chicken_manure * chickens
    )
    model.addConstr(
        total_manure <= max_manure + (max_manure_expanded - max_manure) * expanded,
        name="manure_capacity"
    )

    # Land capacity constraints
    total_land_use = (
        base_land_usage_cow * cows +
        base_land_usage_sheep * sheep +
        base_land_usage_chicken * chickens
    )
    model.addConstr(
        total_land_use <= base_land_capacity + expansion_land_increase * expanded,
        name="land_capacity"
    )

    # Objective: revenue - feed costs - expansion cost if expanded
    profit_cows_reg = (cow_price - cow_feed) * cows_reg
    profit_sheep_reg = (sheep_price - sheep_feed) * sheep_reg
    profit_chickens_reg = (chicken_price - chicken_feed) * chickens_reg

    # Premium animals have higher feed cost
    profit_cows_prem = (cow_price - premium_feed_multiplier * cow_feed) * cows_prem
    profit_sheep_prem = (sheep_price - premium_feed_multiplier * sheep_feed) * sheep_prem
    profit_chickens_prem = (chicken_price - premium_feed_multiplier * chicken_feed) * chickens_prem

    total_profit = (
        profit_cows_reg +
        profit_sheep_reg +
        profit_chickens_reg +
        profit_cows_prem +
        profit_sheep_prem +
        profit_chickens_prem -
        expansion_cost * expanded
    )

    model.setObjective(total_profit, GRB.MAXIMIZE)

    # Optimize
    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
