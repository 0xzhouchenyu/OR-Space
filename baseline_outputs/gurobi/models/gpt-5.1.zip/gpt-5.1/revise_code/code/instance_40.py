import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(csv_path)
    return dict(zip(df["Parameter_Name"], df["Value"]))

def main():
    params = load_parameters()

    commodities = ["steel", "engine", "electronics", "plastic"]

    m = gp.Model("Revised_Maximize_GDP")
    m.setParam('OutputFlag', 0)

    # Production variables
    x = {c: m.addVar(lb=0.0, name=f"x_{c}") for c in commodities}

    # Imports of finished commodities (new)
    imp = {c: m.addVar(lb=0.0, ub=params["import_quota"], name=f"import_{c}") for c in commodities}

    # Regular and overtime labor
    L_reg = m.addVar(lb=0.0, ub=params["labor_force"], name="L_regular")
    L_ot = m.addVar(lb=0.0, ub=params["overtime_cap"], name="L_overtime")

    # Apply production upper bounds if they exist
    for c in commodities:
        for suffix in ["_production_limit", "_limit", "_capacity"]:
            key = f"{c}{suffix}"
            if key in params:
                x[c].UB = params[key]

    # Net export and domestic balance
    net_export = {}
    for c in commodities:
        consumed = gp.quicksum(
            params.get(f"{c_prime}_{c}_requirement", 0.0) * x[c_prime]
            for c_prime in commodities
        )
        # Domestic demand must be satisfied by domestic production + imports
        # x[c] + imp[c] >= consumed   => net_export[c] = x[c] - consumed
        m.addConstr(x[c] + imp[c] >= consumed, name=f"Domestic_Demand_{c}")
        net_export[c] = x[c] - consumed

    # Labor constraint: production labor equals regular + overtime
    total_labor_required = gp.quicksum(
        params.get(f"{c}_labor_requirement", 0.0) * x[c] for c in commodities
    )
    m.addConstr(total_labor_required == L_reg + L_ot, name="Labor_balance")

    # Objective: GDP = export revenue - import costs (intermediate + finished) - overtime wages
    # Export revenue from net exports (can be zero if purely domestic)
    export_revenue = gp.quicksum(params[f"{c}_price"] * net_export[c] for c in commodities)

    # Intermediate import costs (unchanged)
    intermediate_import_costs = gp.quicksum(
        params.get(f"{c}_import_cost", 0.0) * x[c] for c in commodities
    )

    # Finished-commodity imports: priced at import_premium_ratio * world price
    import_premium_ratio = params["import_premium_ratio"]
    finished_import_costs = gp.quicksum(
        import_premium_ratio * params[f"{c}_price"] * imp[c] for c in commodities
    )

    # Overtime wage cost
    overtime_cost = params["overtime_wage"] * L_ot

    gdp = export_revenue - intermediate_import_costs - finished_import_costs - overtime_cost
    m.setObjective(gdp, GRB.MAXIMIZE)

    m.optimize()

    obj_val = m.objVal if m.SolCount > 0 else None
    if obj_val is not None:
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
