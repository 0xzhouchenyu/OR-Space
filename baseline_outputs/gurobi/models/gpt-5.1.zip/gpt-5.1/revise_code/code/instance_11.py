import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")

    # Read data
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    # Helper to get parameter values
    def get_param(name):
        return float(df_params[df_params["Parameter_Name"] == name]["Value"].iloc[0])

    # Extract rows from table_1
    row_a = df1[df1["Type"] == "Type_A"].iloc[0]
    row_b = df1[df1["Type"] == "Type_B"].iloc[0]
    row_cap = df1[df1["Type"] == "Max_weekly_capacity"].iloc[0]
    row_cost = df1[df1["Type"] == "Process_cost_Yuan_per_hour"].iloc[0]

    # Base technology and prices (same for all weeks/modes)
    mfg_a = float(row_a["Manufacturing_hours_per_unit"])
    asm_a = float(row_a["Assembly_hours_per_unit"])
    price_a = float(row_a["Selling_Price_Yuan_per_unit"])

    mfg_b = float(row_b["Manufacturing_hours_per_unit"])
    asm_b = float(row_b["Assembly_hours_per_unit"])
    price_b = float(row_b["Selling_Price_Yuan_per_unit"])

    cap_mfg = float(row_cap["Manufacturing_hours_per_unit"])
    cap_asm = float(row_cap["Assembly_hours_per_unit"])
    cap_insp = float(row_cap["Inspection_hours_per_unit"])

    cost_mfg = float(row_cost["Manufacturing_hours_per_unit"])
    cost_asm = float(row_cost["Assembly_hours_per_unit"])

    # Parameters from general_parameters.csv
    min_profit = get_param("min_weekly_profit")
    min_a = get_param("min_type_a_production")

    # Mode-specific inspection parameters
    insp_a_M = get_param("insp_a_M")
    insp_b_M = get_param("insp_b_M")
    insp_a_E = get_param("insp_a_E")
    insp_b_E = get_param("insp_b_E")
    cap_ext = get_param("cap_ext")

    cost_insp_M = get_param("cost_insp_M")
    cost_insp_E = get_param("cost_insp_E")
    cost_ext = get_param("cost_ext")

    mode_fee_M = get_param("mode_fee_M")
    mode_fee_E = get_param("mode_fee_E")
    risk_penalty_M = get_param("risk_penalty_M")

    cost_insp_weight = get_param("cost_insp_weight")

    planning_horizon_weeks = int(get_param("planning_horizon_weeks"))
    idle_tolerance = get_param("idle_tolerance")

    # Weeks index set
    Weeks = range(1, planning_horizon_weeks + 1)

    # ---------- Stage 1: Minimize (weighted idle cost + inspection_risk_penalty) ----------
    model1 = gp.Model("Stage1_Minimize_Idle_and_Risk")
    model1.setParam('OutputFlag', 0)

    # Decision variables
    xA = model1.addVars(Weeks, vtype=GRB.INTEGER, name="xA", lb=min_a)
    xB = model1.addVars(Weeks, vtype=GRB.INTEGER, name="xB", lb=0)

    yM = model1.addVars(Weeks, vtype=GRB.BINARY, name="yM")  # Manual
    yE = model1.addVars(Weeks, vtype=GRB.BINARY, name="yE")  # Enhanced

    # External inspection hours (only used in Enhanced mode)
    extA = model1.addVars(Weeks, lb=0.0, name="extA")
    extB = model1.addVars(Weeks, lb=0.0, name="extB")

    # Constraints per week
    for w in Weeks:
        # Exactly one mode per week
        model1.addConstr(yM[w] + yE[w] == 1, name=f"mode_choice_week{w}")

        # Manufacturing capacity
        model1.addConstr(mfg_a * xA[w] + mfg_b * xB[w] <= cap_mfg, name=f"cap_mfg_week{w}")

        # Assembly capacity
        model1.addConstr(asm_a * xA[w] + asm_b * xB[w] <= cap_asm, name=f"cap_asm_week{w}")

        # Inspection capacity and ext usage:
        # Total required in-house inspection hours by mode:
        #   Manual: insp_a_M * xA + insp_b_M * xB
        #   Enhanced: insp_a_E * xA + insp_b_E * xB
        # Let req_M, req_E be implied expressions
        req_M = insp_a_M * xA[w] + insp_b_M * xB[w]
        req_E = insp_a_E * xA[w] + insp_b_E * xB[w]

        # In-house inspection hours actually used under each mode
        # In Manual: all required must be in-house; no external inspection.
        # In Enhanced: part of req_E can be external (extA+extB), limited by cap_ext;
        # remaining must be in-house and within internal inspection capacity.
        # Internal inspection capacity constraint:
        model1.addConstr(
            req_M * yM[w] + (req_E - (extA[w] + extB[w])) * yE[w] <= cap_insp,
            name=f"cap_insp_week{w}"
        )

        # External inspection hours only if Enhanced mode is on; total <= cap_ext
        model1.addConstr(extA[w] + extB[w] <= cap_ext * yE[w], name=f"cap_ext_week{w}")

        # External hours cannot exceed requirement under Enhanced mode
        model1.addConstr(extA[w] <= xA[w] * insp_a_E, name=f"extA_le_req_week{w}")
        model1.addConstr(extB[w] <= xB[w] * insp_b_E, name=f"extB_le_req_week{w}")

        # Profit in each week must be >= min_weekly_profit
        # Compute cost and revenue expressions:
        # Manufacturing + assembly costs
        cost_mfg_asm = cost_mfg * (mfg_a * xA[w] + mfg_b * xB[w]) + \
                       cost_asm * (asm_a * xA[w] + asm_b * xB[w])

        # In-house inspection cost depends on mode:
        #   Manual: cost_insp_M * req_M
        #   Enhanced: cost_insp_E * (req_E - (extA+extB))
        cost_insp_M_expr = cost_insp_M * req_M
        cost_insp_E_expr = cost_insp_E * (req_E - (extA[w] + extB[w]))
        cost_insp_total = cost_insp_M_expr * yM[w] + cost_insp_E_expr * yE[w]

        # External inspection cost (only Enhanced)
        cost_ext_total = cost_ext * (extA[w] + extB[w])

        # Mode fees and risk penalties
        fee_cost = mode_fee_M * yM[w] + mode_fee_E * yE[w]
        risk_cost = risk_penalty_M * yM[w]

        # Revenue
        revenue = price_a * xA[w] + price_b * xB[w]

        profit_w = revenue - (cost_mfg_asm + cost_insp_total + cost_ext_total + fee_cost + risk_cost)

        model1.addConstr(profit_w >= min_profit, name=f"min_profit_week{w}")

    # Stage-1 objective: minimize total idle cost + total risk_penalty_M
    idle_cost_terms = []
    risk_cost_terms = []

    for w in Weeks:
        # Manufacturing idle
        used_mfg = mfg_a * xA[w] + mfg_b * xB[w]
        idle_mfg = cap_mfg - used_mfg
        idle_cost_terms.append(cost_mfg * idle_mfg)

        # Assembly idle
        used_asm = asm_a * xA[w] + asm_b * xB[w]
        idle_asm = cap_asm - used_asm
        idle_cost_terms.append(cost_asm * idle_asm)

        # Inspection idle (in-house). Use cost_insp_weight, independent of mode.
        # In-house inspection used:
        req_M = insp_a_M * xA[w] + insp_b_M * xB[w]
        req_E = insp_a_E * xA[w] + insp_b_E * xB[w]
        inh_used = req_M * yM[w] + (req_E - (extA[w] + extB[w])) * yE[w]
        idle_insp = cap_insp - inh_used
        idle_cost_terms.append(cost_insp_weight * idle_insp)

        # Risk penalty (already counted in profit, but explicitly added to stage-1 objective)
        risk_cost_terms.append(risk_penalty_M * yM[w])

    total_idle_cost = gp.quicksum(idle_cost_terms)
    total_risk_cost = gp.quicksum(risk_cost_terms)

    model1.setObjective(total_idle_cost + total_risk_cost, GRB.MINIMIZE)

    model1.optimize()

    best_idle_risk = model1.objVal

    # ---------- Stage 2: Among those, maximize total profit ----------
    model2 = gp.Model("Stage2_Maximize_Profit")
    model2.setParam('OutputFlag', 0)

    # Decision variables (replicate)
    xA2 = model2.addVars(Weeks, vtype=GRB.INTEGER, name="xA", lb=min_a)
    xB2 = model2.addVars(Weeks, vtype=GRB.INTEGER, name="xB", lb=0)

    yM2 = model2.addVars(Weeks, vtype=GRB.BINARY, name="yM")
    yE2 = model2.addVars(Weeks, vtype=GRB.BINARY, name="yE")

    extA2 = model2.addVars(Weeks, lb=0.0, name="extA")
    extB2 = model2.addVars(Weeks, lb=0.0, name="extB")

    profit_week = {}

    idle_cost_terms2 = []
    risk_cost_terms2 = []

    for w in Weeks:
        model2.addConstr(yM2[w] + yE2[w] == 1, name=f"mode_choice_week{w}")

        model2.addConstr(mfg_a * xA2[w] + mfg_b * xB2[w] <= cap_mfg, name=f"cap_mfg_week{w}")
        model2.addConstr(asm_a * xA2[w] + asm_b * xB2[w] <= cap_asm, name=f"cap_asm_week{w}")

        req_M2 = insp_a_M * xA2[w] + insp_b_M * xB2[w]
        req_E2 = insp_a_E * xA2[w] + insp_b_E * xB2[w]

        model2.addConstr(
            req_M2 * yM2[w] + (req_E2 - (extA2[w] + extB2[w])) * yE2[w] <= cap_insp,
            name=f"cap_insp_week{w}"
        )

        model2.addConstr(extA2[w] + extB2[w] <= cap_ext * yE2[w], name=f"cap_ext_week{w}")
        model2.addConstr(extA2[w] <= xA2[w] * insp_a_E, name=f"extA_le_req_week{w}")
        model2.addConstr(extB2[w] <= xB2[w] * insp_b_E, name=f"extB_le_req_week{w}")

        cost_mfg_asm2 = cost_mfg * (mfg_a * xA2[w] + mfg_b * xB2[w]) + \
                        cost_asm * (asm_a * xA2[w] + asm_b * xB2[w])

        cost_insp_M_expr2 = cost_insp_M * req_M2
        cost_insp_E_expr2 = cost_insp_E * (req_E2 - (extA2[w] + extB2[w]))
        cost_insp_total2 = cost_insp_M_expr2 * yM2[w] + cost_insp_E_expr2 * yE2[w]

        cost_ext_total2 = cost_ext * (extA2[w] + extB2[w])
        fee_cost2 = mode_fee_M * yM2[w] + mode_fee_E * yE2[w]
        risk_cost2 = risk_penalty_M * yM2[w]

        revenue2 = price_a * xA2[w] + price_b * xB2[w]
        profit_w2 = revenue2 - (cost_mfg_asm2 + cost_insp_total2 + cost_ext_total2 + fee_cost2 + risk_cost2)
        profit_week[w] = profit_w2

        model2.addConstr(profit_w2 >= min_profit, name=f"min_profit_week{w}")

        # Idle + risk terms for lexicographic tie
        used_mfg2 = mfg_a * xA2[w] + mfg_b * xB2[w]
        idle_mfg2 = cap_mfg - used_mfg2
        idle_cost_terms2.append(cost_mfg * idle_mfg2)

        used_asm2 = asm_a * xA2[w] + asm_b * xB2[w]
        idle_asm2 = cap_asm - used_asm2
        idle_cost_terms2.append(cost_asm * idle_asm2)

        inh_used2 = req_M2 * yM2[w] + (req_E2 - (extA2[w] + extB2[w])) * yE2[w]
        idle_insp2 = cap_insp - inh_used2
        idle_cost_terms2.append(cost_insp_weight * idle_insp2)

        risk_cost_terms2.append(risk_penalty_M * yM2[w])

    total_idle_cost2 = gp.quicksum(idle_cost_terms2)
    total_risk_cost2 = gp.quicksum(risk_cost_terms2)

    # Enforce stage-1 optimal idle+risk within tolerance
    model2.addConstr(total_idle_cost2 + total_risk_cost2 <= best_idle_risk + idle_tolerance,
                     name="idle_risk_tight")

    # Stage-2 objective: maximize total profit over horizon
    total_profit = gp.quicksum(profit_week[w] for w in Weeks)
    model2.setObjective(total_profit, GRB.MAXIMIZE)

    model2.optimize()

    final_obj = model2.objVal
    print(f"FINAL_OBJ_VALUE: {round(final_obj, 4)}")

if __name__ == "__main__":
    main()
