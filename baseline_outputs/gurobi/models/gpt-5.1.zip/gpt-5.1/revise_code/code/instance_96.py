import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")

    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    params = {row['Parameter_Name']: row['Value'] for _, row in df_params.iterrows()}

    # Parameters
    raw_len_s1 = float(params['raw_pipe_length_supplier1'])
    raw_len_s2 = float(params['raw_pipe_length_supplier2'])

    max_patterns_s1 = int(params['max_cutting_patterns_supplier1'])
    max_patterns_s2 = int(params['max_cutting_patterns_supplier2'])

    max_cuts_s1 = int(params['max_cuts_per_pipe_supplier1'])
    max_cuts_s2 = int(params['max_cuts_per_pipe_supplier2'])

    max_leftover_s1 = float(params['max_leftover_length_supplier1'])
    max_leftover_s2 = float(params['max_leftover_length_supplier2'])

    purchase_cost_s1 = float(params['purchase_cost_per_pipe_supplier1'])
    purchase_cost_s2 = float(params['purchase_cost_per_pipe_supplier2'])

    discount_tier1_max_qty_s1 = float(params['discount_tier1_supplier1_max_qty'])
    fixed_discount_tier2_s1 = float(params['fixed_discount_tier2_supplier1'])
    bigM_discount = float(params['bigM_discount'])

    # Pattern cost rates per supplier
    def collect_cost_rates(prefix_base):
        rates = []
        rank_prefixes = ['most', 'second', 'third', 'fourth', 'fifth',
                         'sixth', 'seventh', 'eighth', 'ninth', 'tenth']
        for pref in rank_prefixes:
            key = f"{pref}_frequent_pattern_cost_rate_{prefix_base}"
            if key in params:
                rates.append(float(params[key]))
            else:
                break
        return rates

    cost_rates_s1 = collect_cost_rates('supplier1')
    cost_rates_s2 = collect_cost_rates('supplier2')

    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)

    # Pattern generation
    def generate_patterns(raw_length, max_cuts, max_leftover):
        patterns = []
        min_length = raw_length - max_leftover

        def rec(current_pattern, current_length, current_cuts, item_idx):
            if item_idx == n_items:
                if current_cuts > 0 and min_length <= current_length <= raw_length:
                    patterns.append(tuple(current_pattern))
                return

            remaining_len = raw_length - current_length
            max_qty_by_len = int(remaining_len // lengths[item_idx]) if lengths[item_idx] > 0 else 0
            max_qty_by_cuts = max_cuts - current_cuts
            max_qty = min(max_qty_by_len, max_qty_by_cuts)
            for q in range(max_qty + 1):
                rec(
                    current_pattern + [q],
                    current_length + q * lengths[item_idx],
                    current_cuts + q,
                    item_idx + 1
                )

        rec([], 0, 0, 0)
        return patterns

    patterns_s1 = generate_patterns(raw_len_s1, max_cuts_s1, max_leftover_s1)
    patterns_s2 = generate_patterns(raw_len_s2, max_cuts_s2, max_leftover_s2)

    # Build model
    m = gp.Model("TwoSupplierPipeCutting")
    m.setParam('OutputFlag', 0)

    # Variables
    y1 = m.addVars(len(patterns_s1), vtype=GRB.INTEGER, lb=0, name="y1")
    z1 = m.addVars(len(patterns_s1), vtype=GRB.BINARY, name="z1")

    y2 = m.addVars(len(patterns_s2), vtype=GRB.INTEGER, lb=0, name="y2")
    z2 = m.addVars(len(patterns_s2), vtype=GRB.BINARY, name="z2")

    # u variables for ranking-based costs per supplier
    u1 = m.addVars(range(1, max_patterns_s1 + 1), vtype=GRB.BINARY, name="u1")
    u2 = m.addVars(range(1, max_patterns_s2 + 1), vtype=GRB.BINARY, name="u2")

    # Discount tier variable for supplier 1
    d1 = m.addVar(vtype=GRB.BINARY, name="discount_s1")

    # Total pipes per supplier
    total_pipes_s1 = gp.quicksum(y1[p] for p in range(len(patterns_s1)))
    total_pipes_s2 = gp.quicksum(y2[p] for p in range(len(patterns_s2)))

    # Demand fulfillment constraints (shared across suppliers)
    for i in range(n_items):
        m.addConstr(
            gp.quicksum(patterns_s1[p][i] * y1[p] for p in range(len(patterns_s1))) +
            gp.quicksum(patterns_s2[p][i] * y2[p] for p in range(len(patterns_s2)))
            >= demands[i],
            name=f"demand_{i}"
        )

    # Big-M linking y and z for each supplier
    M1 = sum(demands)
    M2 = sum(demands)

    for p in range(len(patterns_s1)):
        m.addConstr(y1[p] <= M1 * z1[p], name=f"link_yz1_{p}")

    for p in range(len(patterns_s2)):
        m.addConstr(y2[p] <= M2 * z2[p], name=f"link_yz2_{p}")

    # Number of patterns actually used per supplier
    m.addConstr(
        gp.quicksum(z1[p] for p in range(len(patterns_s1))) ==
        gp.quicksum(u1[k] for k in range(1, max_patterns_s1 + 1)),
        name="pattern_count_s1_eq"
    )
    m.addConstr(
        gp.quicksum(z2[p] for p in range(len(patterns_s2))) ==
        gp.quicksum(u2[k] for k in range(1, max_patterns_s2 + 1)),
        name="pattern_count_s2_eq"
    )

    # Monotonicity of u's (ranking slots)
    for k in range(1, max_patterns_s1):
        m.addConstr(u1[k] >= u1[k + 1], name=f"u1_monotone_{k}")
    for k in range(1, max_patterns_s2):
        m.addConstr(u2[k] >= u2[k + 1], name=f"u2_monotone_{k}")

    # Max patterns per supplier (redundant with equality but safe if bounds differ)
    m.addConstr(
        gp.quicksum(z1[p] for p in range(len(patterns_s1))) <= max_patterns_s1,
        name="max_patterns_s1"
    )
    m.addConstr(
        gp.quicksum(z2[p] for p in range(len(patterns_s2))) <= max_patterns_s2,
        name="max_patterns_s2"
    )

    # Discount tier constraints for supplier 1
    # If d1 = 1, total_pipes_s1 >= discount_tier1_max_qty_s1 + epsilon
    # If d1 = 0, total_pipes_s1 <= discount_tier1_max_qty_s1
    # Using bigM_discount on upper constraint
    m.addConstr(
        total_pipes_s1 >= discount_tier1_max_qty_s1 + 1 - bigM_discount * (1 - d1),
        name="discount_lower_s1"
    )
    m.addConstr(
        total_pipes_s1 <= discount_tier1_max_qty_s1 + bigM_discount * d1,
        name="discount_upper_s1"
    )

    # Objective
    # Purchasing cost
    purchase_cost = purchase_cost_s1 * total_pipes_s1 + purchase_cost_s2 * total_pipes_s2

    # Pattern ranking extra costs (per supplier)
    extra_cost_s1 = gp.LinExpr()
    for k in range(1, max_patterns_s1 + 1):
        if k - 1 < len(cost_rates_s1):
            extra_cost_s1 += cost_rates_s1[k - 1] * u1[k]

    extra_cost_s2 = gp.LinExpr()
    for k in range(1, max_patterns_s2 + 1):
        if k - 1 < len(cost_rates_s2):
            extra_cost_s2 += cost_rates_s2[k - 1] * u2[k]

    # Discount from supplier 1 (negative cost because it is a deduction)
    discount_term = -fixed_discount_tier2_s1 * d1

    m.setObjective(purchase_cost + extra_cost_s1 + extra_cost_s2 + discount_term, GRB.MINIMIZE)

    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
