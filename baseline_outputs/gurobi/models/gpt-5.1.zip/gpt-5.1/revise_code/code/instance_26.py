import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine data directory relative to this script
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = row["Value"].strip()
            params[name] = val

    # Extract needed parameters
    shift_duration = int(params.get("shift_duration"))
    shift_start_times = [t.strip() for t in params.get("shift_start_times").split(";")]
    full_time_cost = float(params.get("full_time_cost"))
    part_time_cost = float(params.get("part_time_cost"))
    part_time_cap_per_period = int(params.get("part_time_cap_per_period"))
    min_full_time_per_period = int(params.get("min_full_time_per_period"))

    # Read staffing requirements
    periods = []
    req_values = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            periods.append(row["Time_Period"].strip())
            req_values.append(int(row["Required_Salespeople"].strip()))

    n = len(periods)  # number of 4-hour periods; also number of full-time start options

    # Build model
    model = gp.Model("MinDailyLaborCost")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x_i: number of full-time staff starting at period i (8-hour shift covering i and (i+1) mod n)
    x = model.addVars(n, vtype=GRB.INTEGER, name="x", lb=0)

    # y_j: number of part-time staff assigned in period j (4-hour shift covering only j)
    y = model.addVars(n, vtype=GRB.INTEGER, name="y", lb=0)

    # Objective: minimize total daily labor cost
    model.setObjective(
        full_time_cost * gp.quicksum(x[i] for i in range(n)) +
        part_time_cost * gp.quicksum(y[j] for j in range(n)),
        GRB.MINIMIZE
    )

    # Constraints
    for j in range(n):
        # Full-time staff present in period j come from starts in j and (j-1) mod n
        full_time_present = x[j] + x[(j - 1) % n]

        # 1) Demand coverage: full-time present + part-time in j >= required salespeople
        model.addConstr(
            full_time_present + y[j] >= req_values[j],
            name=f"demand_{j}"
        )

        # 2) Part-time cap per period
        model.addConstr(
            y[j] <= part_time_cap_per_period,
            name=f"pt_cap_{j}"
        )

        # 3) Minimum full-time presence per period
        model.addConstr(
            full_time_present >= min_full_time_per_period,
            name=f"min_ft_{j}"
        )

    # Optimize
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
