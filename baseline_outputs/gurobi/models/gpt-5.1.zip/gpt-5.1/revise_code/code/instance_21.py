import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Locate data directory relative to this script
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Read parameters
    params = {}
    with open(params_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

    cost_a = params["cost_supplier_a"]
    cost_b = params["cost_supplier_b"]
    cost_c = params["cost_supplier_c"]
    size_a = int(params["order_size_supplier_a"])
    size_b = int(params["order_size_supplier_b"])
    size_c = int(params["order_size_supplier_c"])
    min_tables = int(params["min_tables_required"])
    max_tables = int(params["max_tables_allowed"])
    min_b_if_a = int(params["min_tables_supplier_b_if_a"])
    b_requires_c = int(params["supplier_b_requires_c"])
    max_free_orders_c = int(params["max_free_orders_c"])
    penalty_per_extra_order_c = params["penalty_per_extra_order_c"]
    bc_shared_trigger = int(params["supplier_bc_shared_inbound_trigger"])
    bc_shared_fee = params["supplier_bc_shared_inbound_fee"]

    # Big-M for linking binaries and integers
    M = 1000

    # Create model
    model = gp.Model("Restaurant_Tables_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables: number of orders from each supplier (integer >= 0)
    x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_a")
    x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_b")
    x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_c")

    # Binary variables for whether suppliers are used
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")

    # Binary variable for whether B and C are both used (shared inbound)
    y_bc = model.addVar(vtype=GRB.BINARY, name="y_bc")

    # Integer variable for orders from C beyond the free limit
    extra_orders_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="extra_orders_c")

    # Objective: base table costs
    base_cost = (
        cost_a * size_a * x_a
        + cost_b * size_b * x_b
        + cost_c * size_c * x_c
    )

    # Penalty for extra C orders beyond free limit
    penalty_cost = penalty_per_extra_order_c * extra_orders_c

    # Shared inbound fee when B and C are both used
    inbound_cost = 0
    if bc_shared_trigger:
        inbound_cost = bc_shared_fee * y_bc

    model.setObjective(base_cost + penalty_cost + inbound_cost, GRB.MINIMIZE)

    # Total tables constraints
    total_tables = size_a * x_a + size_b * x_b + size_c * x_c
    model.addConstr(total_tables >= min_tables, "min_tables")
    model.addConstr(total_tables <= max_tables, "max_tables")

    # Link usage binaries to order counts
    model.addConstr(x_a <= M * y_a, "link_a_up")
    model.addConstr(x_a >= y_a, "link_a_down")
    model.addConstr(x_b <= M * y_b, "link_b_up")
    model.addConstr(x_b >= y_b, "link_b_down")
    model.addConstr(x_c <= M * y_c, "link_c_up")
    model.addConstr(x_c >= y_c, "link_c_down")

    # If ordering from A, then tables from B >= min_b_if_a
    model.addConstr(size_b * x_b >= min_b_if_a * y_a, "min_b_if_a")

    # If ordering from B, must order from C
    if b_requires_c:
        # If B used then C used
        model.addConstr(y_c >= y_b, "b_requires_c")

    # Supplier C comfort band:
    # Up to max_free_orders_c orders are "free" w.r.t penalty.
    # extra_orders_c captures orders above that limit.
    model.addConstr(x_c <= max_free_orders_c + extra_orders_c, "extra_c_lb")
    model.addConstr(extra_orders_c >= x_c - max_free_orders_c, "extra_c_def")

    # Shared inbound fee logic: y_bc = 1 iff both B and C are used
    # Enforce y_bc <= y_b, y_bc <= y_c, and y_bc >= y_b + y_c - 1
    model.addConstr(y_bc <= y_b, "y_bc_le_yb")
    model.addConstr(y_bc <= y_c, "y_bc_le_yc")
    model.addConstr(y_bc >= y_b + y_c - 1, "y_bc_ge_yb_plus_yc_minus1")

    # Optimize
    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
