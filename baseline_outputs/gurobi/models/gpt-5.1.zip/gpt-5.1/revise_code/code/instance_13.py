import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load parameters
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = {}
    with open(data_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

    profit_corn = params["profit_per_acre_corn"]
    profit_wheat = params["profit_per_acre_wheat"]
    profit_soybeans = params["profit_per_acre_soybeans"]
    profit_sorghum = params["profit_per_acre_sorghum"]
    total_area = params["total_farm_area"]
    corn_wheat_ratio = params["corn_wheat_ratio"]
    soybeans_sorghum_ratio = params["soybeans_sorghum_ratio"]
    wheat_sorghum_ratio = params["wheat_sorghum_ratio"]

    # Big-M for acreage bounds
    M = total_area

    # Build model
    model = gp.Model("Revised_Farm_Optimization")
    model.setParam('OutputFlag', 0)

    # Continuous variables (acres)
    corn = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="corn")
    wheat = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="wheat")
    soybeans = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="soybeans")
    sorghum = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="sorghum")

    # Binary variable: 1 if corn program is chosen, 0 if soybean program is chosen
    y_corn = model.addVar(vtype=GRB.BINARY, name="y_corn")

    # Objective: maximize profit
    model.setObjective(
        profit_corn * corn +
        profit_wheat * wheat +
        profit_soybeans * soybeans +
        profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )

    # Total area constraint
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, name="total_area")

    # Corn >= 2 * wheat
    model.addConstr(corn >= corn_wheat_ratio * wheat, name="corn_wheat_ratio")

    # Soybeans >= 0.5 * sorghum
    model.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, name="soybeans_sorghum_ratio")

    # Wheat = 3 * sorghum
    model.addConstr(wheat == wheat_sorghum_ratio * sorghum, name="wheat_sorghum_ratio")

    # Operational commitments:
    # 1) Must plant at least 20 acres of corn
    model.addConstr(corn >= 20, name="min_corn")

    # 2) Mutual exclusion of corn and soybeans via program choice
    # y_corn = 1 -> corn allowed (up to M), soybeans must be 0
    # y_corn = 0 -> soybeans allowed (up to M), corn must be 0
    model.addConstr(corn <= M * y_corn, name="corn_program_binding")
    model.addConstr(soybeans <= M * (1 - y_corn), name="soybeans_program_binding")

    # Solve model
    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
