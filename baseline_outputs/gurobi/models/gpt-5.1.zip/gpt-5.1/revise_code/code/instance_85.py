import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Load table_1.csv
    table1_path = os.path.join(base_dir, "data", "table_1.csv")
    products = {}
    with open(table1_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row["Item"].strip()
            products[item] = {
                "machine_time": float(row["Machine_Time_minutes"].strip()),
                "craftsman_time": float(row["Craftsman_Time_minutes"].strip()),
            }

    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(params_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

    machine_avail = params["machine_time_available"]  # hours
    craftsman_reg_avail = params["craftsman_regular_time_available"]  # hours
    craftsman_ot_avail = params["craftsman_overtime_available"]  # hours
    machine_cost = params["machine_time_cost"]  # GBP per hour
    craftsman_reg_cost = params["craftsman_time_cost"]  # GBP per hour
    craftsman_ot_cost = params["craftsman_overtime_cost"]  # GBP per hour
    rev_X = params["revenue_product_X"]  # GBP per batch
    rev_Y = params["revenue_product_Y"]  # GBP per batch
    min_X = params["min_batches_product_X"]  # batches
    Y_QA_threshold = params["product_Y_QA_threshold"]  # batches
    Y_QA_fee = params["product_Y_QA_fee"]  # GBP

    m = gp.Model("Revised_Production_Planning")
    m.setParam('OutputFlag', 0)

    # Decision variables
    X = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="X")
    Y = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="Y")

    # Craftsman time split between regular and overtime (in hours)
    C_reg = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="C_reg")
    C_ot = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="C_ot")

    # Binary variable for QA fee if Y exceeds threshold
    z_QA = m.addVar(vtype=GRB.BINARY, name="z_QA")

    # Derived total craftsman hours required
    craftsman_hours_required = (
        products["X"]["craftsman_time"] * X + products["Y"]["craftsman_time"] * Y
    ) / 60.0

    # Derived machine hours required
    machine_hours_required = (
        products["X"]["machine_time"] * X + products["Y"]["machine_time"] * Y
    ) / 60.0

    # Constraints

    # Machine time availability
    m.addConstr(machine_hours_required <= machine_avail, name="Machine_Time_Constraint")

    # Craftsman time split: total equals required
    m.addConstr(C_reg + C_ot == craftsman_hours_required, name="Craftsman_Time_Balance")

    # Regular and overtime capacity limits
    m.addConstr(C_reg <= craftsman_reg_avail, name="Regular_Craftsman_Limit")
    m.addConstr(C_ot <= craftsman_ot_avail, name="Overtime_Craftsman_Limit")

    # Minimum production of X
    m.addConstr(X >= min_X, name="Min_Production_X")

    # QA fee trigger constraints (big-M formulation)
    # z_QA = 1 if Y > Y_QA_threshold, else 0.
    # Use big-M large enough given capacities. Upper bound for Y from machine time:
    max_Y_machine = machine_avail * 60.0 / products["Y"]["machine_time"]
    max_Y_craft = (craftsman_reg_avail + craftsman_ot_avail) * 60.0 / products["Y"]["craftsman_time"]
    Y_upper_bound = max(max_Y_machine, max_Y_craft)
    M = Y_upper_bound + Y_QA_threshold + 1.0

    # If z_QA = 0 -> Y <= threshold
    m.addConstr(Y <= Y_QA_threshold + M * z_QA, name="QA_Upper_Bound")
    # If z_QA = 1 -> Y >= threshold (or threshold + small epsilon); here ensure Y not forced
    m.addConstr(Y >= Y_QA_threshold * z_QA, name="QA_Lower_Bound")

    # Objective: maximize profit = revenue - costs - QA fee
    profit = (
        rev_X * X
        + rev_Y * Y
        - machine_cost * machine_hours_required
        - craftsman_reg_cost * C_reg
        - craftsman_ot_cost * C_ot
        - Y_QA_fee * z_QA
    )

    m.setObjective(profit, GRB.MAXIMIZE)

    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
