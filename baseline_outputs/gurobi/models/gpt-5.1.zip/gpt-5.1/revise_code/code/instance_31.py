import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # ----- Read table_1.csv -----
    proc_time = {}   # (equip, prod) -> hours per unit
    capacity = {}    # equip -> available hours
    cost_rate = {}   # equip -> variable cost per machine hour
    raw_cost = {}
    price = {}

    with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row["Equipment"].strip()
            if equip == "Raw_Material_Cost":
                raw_cost = {
                    "I": float(row["Product_I"]),
                    "II": float(row["Product_II"]),
                    "III": float(row["Product_III"]),
                }
            elif equip == "Unit_Price":
                price = {
                    "I": float(row["Product_I"]),
                    "II": float(row["Product_II"]),
                    "III": float(row["Product_III"]),
                }
            else:
                # processing times
                for prod, col in [("I", "Product_I"), ("II", "Product_II"), ("III", "Product_III")]:
                    val = row[col].strip()
                    if val != "-":
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row["Effective_Machine_Hours"])
                cost_rate[equip] = float(row["Processing_Cost_per_Machine_Hour"])

    # ----- Read general_parameters.csv for calibration parameters (not strictly needed for logic gate, but read anyway) -----
    joint_calibration_trigger = 0
    joint_calibration_fee = 0.0
    with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            pname = row["Parameter_Name"].strip()
            if pname == "A2_B2_joint_calibration_trigger":
                joint_calibration_trigger = int(row["Value"])
            elif pname == "A2_B2_joint_calibration_fee":
                joint_calibration_fee = float(row["Value"])

    # ----- Read setup_costs.csv -----
    setup_cost = {}
    with open(os.path.join(data_dir, "setup_costs.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row["Equipment"].strip()
            setup_cost[equip] = float(row["Fixed_Setup_Cost"])

    # ----- Sets based on business rules -----
    products = ["I", "II", "III"]
    stage_A_equip = {"I": ["A1", "A2"], "II": ["A1", "A2"], "III": ["A2"]}
    stage_B_equip = {"I": ["B1", "B2", "B3"], "II": ["B1"], "III": ["B2"]}
    all_equipment = ["A1", "A2", "B1", "B2", "B3"]

    # ----- Build model -----
    m = gp.Model("Revised_Factory_Production")
    m.setParam("OutputFlag", 0)

    # Continuous production variables x[e,p] >= 0
    x = {}
    for p in products:
        for e in stage_A_equip[p]:
            x[(e, p)] = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")
        for e in stage_B_equip[p]:
            x[(e, p)] = m.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")

    # Binary setup/usage variables for each machine (active if any production on that equipment)
    y = {}
    bigM = 1e6  # sufficiently large upper bound on units
    for e in all_equipment:
        y[e] = m.addVar(vtype=GRB.BINARY, name=f"y_{e}")

    # Binary variable for joint calibration between A2 and B2
    z_joint = m.addVar(vtype=GRB.BINARY, name="z_A2_B2_joint")

    # ----- Constraints -----

    # Flow conservation (stage A total = stage B total for each product)
    total_prod = {}
    for p in products:
        total_A = gp.quicksum(x[(e, p)] for e in stage_A_equip[p])
        total_B = gp.quicksum(x[(e, p)] for e in stage_B_equip[p])
        m.addConstr(total_A == total_B, name=f"flow_{p}")
        total_prod[p] = total_A

    # Capacity constraints per equipment
    for e in all_equipment:
        # gather all product pairs that use this equipment
        relevant = [(e, p) for p in products if (e, p) in x]
        if relevant:
            m.addConstr(
                gp.quicksum(proc_time[(e, p)] * x[(e, p)] for (e2, p) in relevant) <= capacity[e],
                name=f"cap_{e}",
            )

    # Link production variables to setup usage y[e]
    for e in all_equipment:
        relevant = [(e, p) for p in products if (e, p) in x]
        if relevant:
            m.addConstr(
                gp.quicksum(x[(e, p)] for (e2, p) in relevant) <= bigM * y[e],
                name=f"use_link_{e}",
            )

    # Joint calibration gating between A2 and B2:
    # z_joint can be 1 only if both A2 and B2 are active.
    # Since the calibration is a gate (one-time fee), we enforce z_joint <= y[A2], z_joint <= y[B2].
    if joint_calibration_trigger == 1:
        m.addConstr(z_joint <= y["A2"], name="joint_le_A2")
        m.addConstr(z_joint <= y["B2"], name="joint_le_B2")
        # Optionally could allow z_joint to be 0 even if both are 1; this is optimal to set to 1 only when both are 1
        # For completeness, upper bound z_joint <= (y[A2]+y[B2])/2 could be added but is not necessary.

    # ----- Objective: maximize profit -----
    # Revenue
    revenue = gp.quicksum(price[p] * total_prod[p] for p in products)

    # Raw material cost
    raw_mat_cost = gp.quicksum(raw_cost[p] * total_prod[p] for p in products)

    # Processing cost (variable)
    proc_cost = gp.quicksum(
        cost_rate[e] * proc_time[(e, p)] * x[(e, p)]
        for (e, p) in x
    )

    # Fixed setup costs per machine when active
    fixed_setup = gp.quicksum(setup_cost[e] * y[e] for e in all_equipment)

    # Joint calibration fee (one-time profit reduction when the gate is crossed)
    joint_fee = 0.0
    if joint_calibration_trigger == 1:
        joint_fee = joint_calibration_fee * z_joint

    m.setObjective(revenue - raw_mat_cost - proc_cost - fixed_setup - joint_fee, GRB.MAXIMIZE)

    # ----- Solve -----
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
