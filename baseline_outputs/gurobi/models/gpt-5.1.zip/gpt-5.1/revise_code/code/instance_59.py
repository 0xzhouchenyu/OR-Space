import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_table_1_7(base_dir):
    filepath = os.path.join(base_dir, "data", "table_1_7.csv")
    with open(filepath, "r", newline="") as f:
        reader = list(csv.reader(f))
    # Expect structure as in original:
    # Row 1 header: Item,A,B,C,Raw Material Cost (Yuan/kg),Monthly Limit (kg)
    # Row 2: A,>=60%,>=15%,,2.00,2000
    # Row 3: B,,,,1.50,2500
    # Row 4: C,<=20%,<=60%,<=50%,1.00,1200
    # Row 5: Processing Fee (Yuan/kg),0.50,0.40,0.30,,
    # Row 6: Selling Price (Yuan/kg),3.40,2.85,2.25,,
    # Parse raw material costs and limits
    raw_cost = [0.0] * 3
    limits = [0.0] * 3
    # Raw A: row index 1
    raw_cost[0] = float(reader[1][4])
    limits[0] = float(reader[1][5])
    # Raw B: row index 2
    raw_cost[1] = float(reader[2][4])
    limits[1] = float(reader[2][5])
    # Raw C: row index 3
    raw_cost[2] = float(reader[3][4])
    limits[2] = float(reader[3][5])
    # Processing fees row index 4
    proc_fee = [
        float(reader[4][1]),
        float(reader[4][2]),
        float(reader[4][3]),
    ]
    # Selling prices row index 5
    sell_price = [
        float(reader[5][1]),
        float(reader[5][2]),
        float(reader[5][3]),
    ]
    return raw_cost, limits, proc_fee, sell_price

def load_general_parameters(base_dir):
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(filepath, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"]
            value = row["Value"]
            # store numeric where appropriate
            try:
                if "." in value or "e" in value.lower():
                    params[name] = float(value)
                else:
                    params[name] = int(value)
            except ValueError:
                params[name] = value
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    raw_cost, limits, proc_fee, sell_price = load_table_1_7(base_dir)
    gen_params = load_general_parameters(base_dir)

    setup_cost = [
        gen_params.get("SetupCost_A", 0.0),
        gen_params.get("SetupCost_B", 0.0),
        gen_params.get("SetupCost_C", 0.0),
    ]
    wrapper_trigger = gen_params.get("BrandAB_SharedWrapper_Trigger", 1)
    wrapper_fee = gen_params.get("BrandAB_SharedWrapper_Fee", 0.0)

    m = gp.Model("RevisedCandyFactory")
    m.setParam('OutputFlag', 0)

    raw_materials = range(3)  # 0=A,1=B,2=C
    brands = range(3)         # 0=A,1=B,2=C

    # x[i,j]: kg of raw material i used in brand j
    x = m.addVars(raw_materials, brands, name="x", lb=0.0)

    # Total production y[j]: sum_i x[i,j]
    y = m.addVars(brands, name="y", lb=0.0)

    # Binary variables for setup / production of each brand
    z = m.addVars(brands, vtype=GRB.BINARY, name="z")

    # Binary for shared wrapper coordination when A and B both produced
    w = m.addVar(vtype=GRB.BINARY, name="w")

    # Link y and x
    for j in brands:
        m.addConstr(y[j] == gp.quicksum(x[i, j] for i in raw_materials), name=f"def_y_{j}")

    # Raw material supply constraints
    for i in raw_materials:
        m.addConstr(gp.quicksum(x[i, j] for j in brands) <= limits[i], name=f"limit_rm_{i}")

    # Composition constraints
    # Raw material A (i=0): >=60% in brand A (j=0), >=15% in brand B (j=1)
    m.addConstr(x[0, 0] >= 0.60 * y[0], name="comp_A_in_brandA")
    m.addConstr(x[0, 1] >= 0.15 * y[1], name="comp_A_in_brandB")

    # Raw material C (i=2): <=20% in brand A (j=0), <=60% in brand B (j=1), <=50% in brand C (j=2)
    m.addConstr(x[2, 0] <= 0.20 * y[0], name="comp_C_in_brandA")
    m.addConstr(x[2, 1] <= 0.60 * y[1], name="comp_C_in_brandB")
    m.addConstr(x[2, 2] <= 0.50 * y[2], name="comp_C_in_brandC")

    # Big-M linking between production quantities and setup binaries
    # Use total raw material limits as upper bounds for each brand
    max_prod = sum(limits)
    for j in brands:
        m.addConstr(y[j] <= max_prod * z[j], name=f"link_yz_{j}")

    # Shared wrapper logic: w = 1 if both A and B produced
    # Enforce w <= z_A, w <= z_B, w >= z_A + z_B - 1
    if wrapper_trigger:
        m.addConstr(w <= z[0], name="wrap_le_zA")
        m.addConstr(w <= z[1], name="wrap_le_zB")
        m.addConstr(w >= z[0] + z[1] - 1, name="wrap_ge_zApluszBminus1")
    else:
        m.addConstr(w == 0, name="wrap_disabled")

    # Objective: maximize profit
    revenue = gp.quicksum(sell_price[j] * y[j] for j in brands)
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in raw_materials for j in brands)
    processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in brands)
    setup_total = gp.quicksum(setup_cost[j] * z[j] for j in brands)
    wrapper_cost = wrapper_fee * w

    m.setObjective(revenue - material_cost - processing_cost - setup_total - wrapper_cost, GRB.MAXIMIZE)

    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}") 

if __name__ == "__main__":
    main()
