import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_parameters(data_path)

    W = params['initial_investment']
    r1 = params['return_rate_option_1']
    r2 = params['return_rate_option_2']
    T = int(params['planning_horizon'])
    min_reserve_year1 = params['min_reserve_year1']
    min_reserve_year2 = params['min_reserve_year2']
    max_option2_start = params['max_option2_start']
    opt2_late_rate = params['option2_year0_late_settlement_rate']

    # Create model
    m = gp.Model("Revised_Investment")
    m.setParam('OutputFlag', 0)

    # Decision variables
    x0_1 = m.addVar(lb=0.0, name="x0_1")   # Option 1 at year 0
    x0_2 = m.addVar(lb=0.0, name="x0_2")   # Option 2 at year 0
    x1_1 = m.addVar(lb=0.0, name="x1_1")   # Option 1 at year 1
    x1_2 = m.addVar(lb=0.0, name="x1_2")   # Option 2 at year 1
    x2_1 = m.addVar(lb=0.0, name="x2_1")   # Option 1 at year 2

    c1 = m.addVar(lb=0.0, name="c1")       # Cash at end of year 1
    c2 = m.addVar(lb=0.0, name="c2")       # Cash at end of year 2

    # Constraints

    # Year 0 budget
    # Initial wealth W is fully allocated between option1 and option2 at year 0
    m.addConstr(x0_1 + x0_2 <= W, name="year0_budget")

    # Option 2 per-start exposure cap
    m.addConstr(x0_2 <= max_option2_start, name="year0_option2_cap")
    m.addConstr(x1_2 <= max_option2_start, name="year1_option2_cap")

    # Year 1 cash flow:
    # Wealth entering year 1 is W (no returns yet).
    # At year 1 start, we allocate x1_1 and x1_2 into new investments;
    # leftover becomes cash c1 at end of year 1.
    m.addConstr(c1 + x1_1 + x1_2 == W, name="year1_flow")

    # Year 1 reserve requirement
    m.addConstr(c1 >= min_reserve_year1, name="year1_reserve")

    # Year 2 cash flow:
    # Available at year 2 after subscription window:
    # - Cash carried from year1 with 0 return: c1
    # - Maturity of year0 option1: x0_1*(1 + r1)
    # Note: year0 two-year product has not settled yet.
    # At year2, we can invest x2_1 in option1; remaining is cash c2.
    m.addConstr(c2 + x2_1 == c1 + x0_1 * (1.0 + r1), name="year2_flow")

    # Year 2 reserve requirement
    m.addConstr(c2 >= min_reserve_year2, name="year2_reserve")

    # Objective: maximize wealth at end of year 3
    # Components:
    # - Year2 option1: x2_1*(1 + r1)
    # - Year1 option1: x1_1*(1 + r1)
    # - Year1 option2 (2-year): x1_2*(1 + r2)
    # - Year0 option2 with late settlement: x0_2*(1 + r2)*(1 - opt2_late_rate)
    # - Cash c2 carried with zero interest
    final_wealth = (
        x2_1 * (1.0 + r1) +
        x1_1 * (1.0 + r1) +
        x1_2 * (1.0 + r2) +
        x0_2 * (1.0 + r2) * (1.0 - opt2_late_rate) +
        c2
    )

    m.setObjective(final_wealth, GRB.MAXIMIZE)

    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
