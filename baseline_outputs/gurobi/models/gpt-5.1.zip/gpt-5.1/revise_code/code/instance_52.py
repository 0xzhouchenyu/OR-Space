import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })

    n = len(shifts)
    required = [s['required'] for s in shifts]

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']

    shift_duration = int(params['shift_duration'])
    driver_rest_gap = int(params['driver_rest_gap'])
    crew_rest_gap = int(params['crew_rest_gap'])
    max_night_driver_fraction = float(params['max_night_driver_fraction'])
    max_night_crew_fraction = float(params['max_night_crew_fraction'])
    max_overtime_shifts = int(params['max_overtime_shifts'])
    overtime_cost_factor = float(params['overtime_cost_factor'])

    # Each period is 4 hours; shift_duration=8 => covers 2 periods
    periods_per_shift = shift_duration // 4

    # Indices 0..n-1
    night_periods = [4, 5]  # periods 5 and 6 in 0-based indexing

    # Build model
    m = gp.Model("RevisedBusStaffing")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # Regular and overtime shifts for drivers and crew
    xD = m.addVars(n, vtype=GRB.INTEGER, lb=0, name="xD")   # regular driver
    yD = m.addVars(n, vtype=GRB.INTEGER, lb=0, name="yD")   # overtime driver
    xC = m.addVars(n, vtype=GRB.INTEGER, lb=0, name="xC")   # regular crew
    yC = m.addVars(n, vtype=GRB.INTEGER, lb=0, name="yC")   # overtime crew

    # Coverage constraints for each period j
    for j in range(n):
        # Drivers
        coverD = []
        coverC = []
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                coverD.append(xD[i] + yD[i])
                coverC.append(xC[i] + yC[i])
        m.addConstr(gp.quicksum(coverD) >= required[j], name=f"DriverDemand_{j+1}")
        m.addConstr(gp.quicksum(coverC) >= required[j], name=f"CrewDemand_{j+1}")

    # Night fraction constraints (using regular starts for the denominator)
    total_reg_drivers = gp.quicksum(xD[i] for i in range(n))
    total_reg_crew = gp.quicksum(xC[i] for i in range(n))

    night_reg_drivers = gp.quicksum(xD[i] for i in night_periods)
    night_reg_crew = gp.quicksum(xC[i] for i in night_periods)

    # Avoid division: night <= fraction * total
    # To make these meaningful even if totals are zero, they automatically hold.
    m.addConstr(night_reg_drivers <= max_night_driver_fraction * total_reg_drivers,
                name="MaxNightDriverFraction")
    m.addConstr(night_reg_crew <= max_night_crew_fraction * total_reg_crew,
                name="MaxNightCrewFraction")

    # Rest gap proxies: limiting night-period regular starts
    # Interpret rest_gap as maximum allowed regular night starts
    m.addConstr(night_reg_drivers <= driver_rest_gap, name="DriverRestGap")
    m.addConstr(night_reg_crew <= crew_rest_gap, name="CrewRestGap")

    # Overtime limit (drivers + crew, all periods)
    total_overtime = gp.quicksum(yD[i] + yC[i] for i in range(n))
    m.addConstr(total_overtime <= max_overtime_shifts, name="MaxOvertimeShifts")

    # Objective: minimize total regular + overtime_cost_factor * overtime
    obj = (
        gp.quicksum(xD[i] + xC[i] for i in range(n)) +
        overtime_cost_factor * gp.quicksum(yD[i] + yC[i] for i in range(n))
    )
    m.setObjective(obj, GRB.MINIMIZE)

    m.optimize()

    final_obj = m.objVal
    print(f"FINAL_OBJ_VALUE: {final_obj}")

if __name__ == "__main__":
    main()
