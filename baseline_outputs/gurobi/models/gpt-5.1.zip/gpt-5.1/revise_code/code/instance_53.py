import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Locate data directory relative to this script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read table_1 with mode-dependent costs
    children = []
    cost_budget = {}
    cost_balanced = {}
    cost_premium = {}

    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row["Child"].strip()
            children.append(child)
            cost_budget[child] = float(row["Cost_budget"])
            cost_balanced[child] = float(row["Cost_balanced"])
            cost_premium[child] = float(row["Cost_premium"])

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()

    max_children = int(params["max_children"])
    min_children = int(params["min_children"])
    fairness_penalty = float(params["fairness_penalty"])
    max_total_cost = float(params["max_total_cost"])
    min_children_per_mode = int(params["min_children_per_mode"])

    # Build model
    m = gp.Model("ZhangFamilyTripRevised")
    m.setParam('OutputFlag', 0)

    # Child selection variables
    x = {c: m.addVar(vtype=GRB.BINARY, name=f"x_{c}") for c in children}

    # Mode selection binaries: exactly one mode
    y_budget = m.addVar(vtype=GRB.BINARY, name="y_budget")
    y_balanced = m.addVar(vtype=GRB.BINARY, name="y_balanced")
    y_premium = m.addVar(vtype=GRB.BINARY, name="y_premium")

    # Per-child cost variables; equal to cost under chosen mode if child selected, 0 otherwise
    cost = {c: m.addVar(vtype=GRB.CONTINUOUS, lb=0.0, name=f"cost_{c}") for c in children}

    # Total spend and fairness spread variables
    total_spend = m.addVar(vtype=GRB.CONTINUOUS, lb=0.0, name="total_spend")
    max_cost = m.addVar(vtype=GRB.CONTINUOUS, lb=0.0, name="max_cost")
    min_cost = m.addVar(vtype=GRB.CONTINUOUS, lb=0.0, name="min_cost")

    # Big-M for cost linking and fairness spread
    M_cost = max(
        max(cost_budget.values()),
        max(cost_balanced.values()),
        max(cost_premium.values())
    )

    # Constraints

    # Exactly one mode
    m.addConstr(y_budget + y_balanced + y_premium == 1, name="one_mode")

    # Ginny must go
    m.addConstr(x["Ginny"] == 1, name="Ginny_must_go")

    # Group size bounds
    m.addConstr(gp.quicksum(x[c] for c in children) <= max_children, name="Max_children")
    m.addConstr(gp.quicksum(x[c] for c in children) >= min_children, name="Min_children")

    # Mode-dependent minimum size for balanced/premium
    m.addConstr(
        gp.quicksum(x[c] for c in children) >= min_children_per_mode * (y_balanced + y_premium),
        name="Min_children_per_mode"
    )

    # Compatibility constraints
    m.addConstr(x["Harry"] + x["Fred"] <= 1, name="Harry_no_Fred")
    m.addConstr(x["Harry"] + x["George"] <= 1, name="Harry_no_George")
    m.addConstr(x["George"] <= x["Fred"], name="George_requires_Fred")
    m.addConstr(x["George"] <= x["Hermione"], name="George_requires_Hermione")

    # Link per-child cost to mode and selection
    for c in children:
        # cost_c <= corresponding mode cost if that mode is chosen and child selected; else 0
        m.addConstr(
            cost[c] <= cost_budget[c] * x[c] + M_cost * (1 - y_budget),
            name=f"cost_budget_ub_{c}"
        )
        m.addConstr(
            cost[c] >= cost_budget[c] * x[c] - M_cost * (1 - y_budget),
            name=f"cost_budget_lb_{c}"
        )

        m.addConstr(
            cost[c] <= cost_balanced[c] * x[c] + M_cost * (1 - y_balanced),
            name=f"cost_balanced_ub_{c}"
        )
        m.addConstr(
            cost[c] >= cost_balanced[c] * x[c] - M_cost * (1 - y_balanced),
            name=f"cost_balanced_lb_{c}"
        )

        m.addConstr(
            cost[c] <= cost_premium[c] * x[c] + M_cost * (1 - y_premium),
            name=f"cost_premium_ub_{c}"
        )
        m.addConstr(
            cost[c] >= cost_premium[c] * x[c] - M_cost * (1 - y_premium),
            name=f"cost_premium_lb_{c}"
        )

        # If child not selected, cost must be zero
        m.addConstr(cost[c] <= M_cost * x[c], name=f"cost_zero_if_not_selected_ub_{c}")
        # lower bound already non-negative; this plus linking ensures cost[c]=0 when x[c]=0

    # Total spend definition
    m.addConstr(total_spend == gp.quicksum(cost[c] for c in children), name="Total_spend_def")

    # Budget cap
    m.addConstr(total_spend <= max_total_cost, name="Max_total_cost")

    # Fairness: max_cost and min_cost over selected children
    for c in children:
        # max_cost >= cost[c]
        m.addConstr(max_cost >= cost[c], name=f"max_cost_ge_{c}")
        # For min_cost: min_cost <= cost[c] + M_cost*(1 - x[c])
        # If x[c]=1, min_cost <= cost[c]; if x[c]=0, relaxed
        m.addConstr(min_cost <= cost[c] + M_cost * (1 - x[c]), name=f"min_cost_le_{c}")

    # Also bound min_cost from below by 0
    m.addConstr(min_cost >= 0, name="min_cost_lb")

    # Objective: total spend + fairness_penalty * (max_cost - min_cost)
    m.setObjective(total_spend + fairness_penalty * (max_cost - min_cost), GRB.MINIMIZE)

    # Optimize
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
