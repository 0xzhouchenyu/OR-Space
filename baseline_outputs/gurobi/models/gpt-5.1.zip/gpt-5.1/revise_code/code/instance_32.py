import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Read production data
    table1_path = os.path.join(base_dir, "data", "table_1.csv")
    workshops = []
    capacities = {}
    rates = {}  # rates[(w,c)]
    with open(table1_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row["Workshop"].strip()
            workshops.append(w)
            capacities[w] = float(row["Production_Capacity_hours"])
            rates[(w, 1)] = float(row["Production_Rate_Component_1_units_per_hour"])
            rates[(w, 2)] = float(row["Production_Rate_Component_2_units_per_hour"])
            rates[(w, 3)] = float(row["Production_Rate_Component_3_units_per_hour"])

    components = [1, 2, 3]

    # Read general parameters
    gp_path = os.path.join(base_dir, "data", "general_parameters.csv")
    gen_params = {}
    with open(gp_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = float(row["Value"])
            gen_params[name] = val

    # Derived sets
    shifts = ["day", "night"]
    time_types = ["regular", "overtime"]

    # Convenience accessors for limits and Big-M
    def reg_limit(w, s):
        key = f"regular_hours_limit_{s}_{w}"
        return gen_params.get(key, 0.0)

    def ot_limit(w, s):
        key = f"overtime_capacity_{s}_{w}"
        return gen_params.get(key, 0.0)

    def bigM(w):
        key = f"bigM_shift_{w}"
        return gen_params.get(key, capacities[w])

    penalty_night_hour = gen_params["penalty_night_hour"]
    penalty_overtime_hour = gen_params["penalty_overtime_hour"]
    penalty_short_per_unit = gen_params["penalty_shortage_per_unit"]
    z_target = gen_params["z_target"]

    # Build model
    m = gp.Model("Revised_Workshop_Scheduling")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # x[w,s,t,c] hours
    x = {}
    for w in workshops:
        for s in shifts:
            for t in time_types:
                for c in components:
                    x[(w, s, t, c)] = m.addVar(lb=0.0, name=f"x_{w}_{s}_{t}_c{c}")

    # Shift active binaries y[w,s]
    y = {}
    for w in workshops:
        for s in shifts:
            y[(w, s)] = m.addVar(vtype=GRB.BINARY, name=f"y_{w}_{s}")

    # Overall completed products
    z = m.addVar(lb=0.0, name="z")

    # Shortage to target
    s_short = m.addVar(lb=0.0, name="shortage")

    m.update()

    # Capacity link: total hours per workshop <= original capacity
    for w in workshops:
        m.addConstr(
            gp.quicksum(x[(w, s, t, c)] for s in shifts for t in time_types for c in components)
            <= capacities[w],
            name=f"TotalCap_{w}"
        )

    # Regular and overtime limits per shift and workshop
    for w in workshops:
        for s in shifts:
            # Regular-time hours
            m.addConstr(
                gp.quicksum(x[(w, s, "regular", c)] for c in components)
                <= reg_limit(w, s),
                name=f"RegLimit_{w}_{s}"
            )
            # Overtime hours
            m.addConstr(
                gp.quicksum(x[(w, s, "overtime", c)] for c in components)
                <= ot_limit(w, s),
                name=f"OTLimit_{w}_{s}"
            )

    # Big-M linking hours to shift activation
    for w in workshops:
        M_w = bigM(w)
        for s in shifts:
            m.addConstr(
                gp.quicksum(x[(w, s, t, c)] for t in time_types for c in components)
                <= M_w * y[(w, s)],
                name=f"BigM_{w}_{s}"
            )

    # At most two workshops active per shift
    for s in shifts:
        m.addConstr(
            gp.quicksum(y[(w, s)] for w in workshops) <= 2,
            name=f"MaxActive_{s}"
        )

    # Production balance for z: z <= total production of each component
    for c in components:
        m.addConstr(
            z <= gp.quicksum(
                rates[(w, c)] * x[(w, s, t, c)]
                for w in workshops for s in shifts for t in time_types
            ),
            name=f"MinComp_{c}"
        )

    # Shortage definition: s_short >= z_target - z and >= 0
    m.addConstr(s_short >= z_target - z, name="ShortDef")

    # Objective: maximize effective value = z - penalties
    # Penalties: night regular hours, overtime hours, shortage
    night_penalty_expr = gp.quicksum(
        x[(w, "night", "regular", c)] * penalty_night_hour
        for w in workshops for c in components
    )
    overtime_penalty_expr = gp.quicksum(
        x[(w, s, "overtime", c)] * penalty_overtime_hour
        for w in workshops for s in shifts for c in components
    )
    shortage_penalty_expr = penalty_short_per_unit * s_short

    m.setObjective(
        z - night_penalty_expr - overtime_penalty_expr - shortage_penalty_expr,
        GRB.MAXIMIZE
    )

    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
