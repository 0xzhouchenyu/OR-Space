import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load items
    items = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                "name": row["Item"].strip(),
                "protein": float(row["Protein_Content_per_100g"]),
                "cost": float(row["Cost_per_100g"]),
                "type": row["Type"].strip(),
                "calories": float(row["Calories_per_100g"]),
                "sodium": float(row["Sodium_mg_per_100g"]),
            })

    # Load parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

    min_veg_types = int(params["min_vegetable_types"])
    max_budget = params["max_budget"]
    total_weight_limit = params["total_weight_limit"]
    min_daily_calories = params["min_daily_calories"]
    max_daily_calories = params["max_daily_calories"]
    max_daily_sodium = params["max_daily_sodium"]

    n = len(items)
    max_units = int(total_weight_limit // 100)
    max_meal_units = 3  # 300g / 100g per unit

    # Build model
    m = gp.Model("mary_meals")
    m.setParam('OutputFlag', 0)

    idx = range(n)

    # Decision variables
    purchase_units = m.addVars(idx, vtype=GRB.INTEGER, lb=0, name="purchase")
    lunch_units = m.addVars(idx, vtype=GRB.INTEGER, lb=0, name="lunch")
    dinner_units = m.addVars(idx, vtype=GRB.INTEGER, lb=0, name="dinner")
    select_item = m.addVars(idx, vtype=GRB.BINARY, name="select")

    veg_indices = [i for i in idx if items[i]["type"] == "Vegetable"]
    lunch_veg_selected = m.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg_sel")
    dinner_veg_selected = m.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg_sel")

    # Objective: maximize total protein from assigned units (lunch + dinner)
    m.setObjective(
        gp.quicksum(items[i]["protein"] * (lunch_units[i] + dinner_units[i]) for i in idx),
        GRB.MAXIMIZE
    )

    # Linking of purchase and meal assignment
    for i in idx:
        m.addConstr(purchase_units[i] >= lunch_units[i] + dinner_units[i],
                    name=f"purchase_ge_assign_{items[i]['name']}")

    # Budget constraint
    m.addConstr(
        gp.quicksum(items[i]["cost"] * purchase_units[i] for i in idx) <= max_budget,
        name="budget"
    )

    # Total weight limit on purchases
    m.addConstr(
        100 * gp.quicksum(purchase_units[i] for i in idx) <= total_weight_limit,
        name="total_weight_limit"
    )

    # Per-meal weight balance: exactly 300g = 3 units
    m.addConstr(
        100 * gp.quicksum(lunch_units[i] for i in idx) == 300,
        name="lunch_weight"
    )
    m.addConstr(
        100 * gp.quicksum(dinner_units[i] for i in idx) == 300,
        name="dinner_weight"
    )

    # Daily calories from assigned units
    total_calories = gp.quicksum(
        items[i]["calories"] * (lunch_units[i] + dinner_units[i]) for i in idx
    )
    m.addConstr(total_calories >= min_daily_calories, name="min_calories")
    m.addConstr(total_calories <= max_daily_calories, name="max_calories")

    # Daily sodium from assigned units
    total_sodium = gp.quicksum(
        items[i]["sodium"] * (lunch_units[i] + dinner_units[i]) for i in idx
    )
    m.addConstr(total_sodium <= max_daily_sodium, name="max_sodium")

    # Purchase selection linkage via big-M
    for i in idx:
        m.addConstr(purchase_units[i] <= max_units * select_item[i],
                    name=f"purchase_bigM_{items[i]['name']}")
        m.addConstr(lunch_units[i] <= max_meal_units * select_item[i],
                    name=f"lunch_bigM_{items[i]['name']}")
        m.addConstr(dinner_units[i] <= max_meal_units * select_item[i],
                    name=f"dinner_bigM_{items[i]['name']}")

    # Vegetable coverage and linkage for each meal
    for i in veg_indices:
        # Link lunch units and lunch_veg_selected
        m.addConstr(lunch_units[i] >= lunch_veg_selected[i],
                    name=f"lunch_veg_lb_{items[i]['name']}")
        m.addConstr(lunch_units[i] <= max_meal_units * lunch_veg_selected[i],
                    name=f"lunch_veg_ub_{items[i]['name']}")

        # Link dinner units and dinner_veg_selected
        m.addConstr(dinner_units[i] >= dinner_veg_selected[i],
                    name=f"dinner_veg_lb_{items[i]['name']}")
        m.addConstr(dinner_units[i] <= max_meal_units * dinner_veg_selected[i],
                    name=f"dinner_veg_ub_{items[i]['name']}")

    # Minimum number of vegetable types per meal
    m.addConstr(
        gp.quicksum(lunch_veg_selected[i] for i in veg_indices) >= min_veg_types,
        name="min_veg_lunch"
    )
    m.addConstr(
        gp.quicksum(dinner_veg_selected[i] for i in veg_indices) >= min_veg_types,
        name="min_veg_dinner"
    )

    # If an item is not selected for purchase, it cannot be used in meals
    for i in idx:
        m.addConstr(lunch_units[i] <= max_meal_units * select_item[i],
                    name=f"lunch_select_link_{items[i]['name']}")
        m.addConstr(dinner_units[i] <= max_meal_units * select_item[i],
                    name=f"dinner_select_link_{items[i]['name']}")
        m.addConstr(purchase_units[i] <= max_units * select_item[i],
                    name=f"purchase_select_link_{items[i]['name']}")

    m.optimize()

    obj_val = m.objVal if m.status == GRB.OPTIMAL or m.status == GRB.SUBOPTIMAL else float('nan')
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
