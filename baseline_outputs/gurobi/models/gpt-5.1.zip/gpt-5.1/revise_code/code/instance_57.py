import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def main():
    # Read orders
    table_1_path = get_data_path('table_1.csv')
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })

    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]

    # Read parameters
    params_path = get_data_path('general_parameters.csv')
    std_widths = []
    pattern_setup_penalty = None
    wide_roll_threshold_width = None
    wide_roll_extra_setup_penalty = None

    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = float(row['Value'])
            if 'standard_width' in name:
                std_widths.append(val)
            elif name == 'pattern_setup_penalty':
                pattern_setup_penalty = val
            elif name == 'wide_roll_threshold_width':
                wide_roll_threshold_width = val
            elif name == 'wide_roll_extra_setup_penalty':
                wide_roll_extra_setup_penalty = val

    total_required_area = sum(w * l for w, l in zip(widths, lengths))

    # Build all feasible cutting patterns for each standard width
    patterns_by_std_width = {}  # sw_idx -> {'sw': sw, 'patterns': [pattern]}
    for idx, sw in enumerate(std_widths):
        patterns = []

        def build_pattern(index, current_pattern, current_sum):
            if index == len(widths):
                if any(c > 0 for c in current_pattern):
                    patterns.append(current_pattern)
                return
            max_count = int(math.floor((sw - current_sum + 1e-9) / widths[index]))
            for count in range(max_count + 1):
                build_pattern(index + 1,
                              current_pattern + [count],
                              current_sum + count * widths[index])

        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {'sw': sw, 'patterns': patterns}

    # Build MIP model
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {}  # number of rolls using pattern p on std width idx
    y = {}  # binary: pattern used or not
    M = 1e9  # big-M for linking x and y

    for idx, data in patterns_by_std_width.items():
        sw = data['sw']
        for p_idx, pattern in enumerate(data['patterns']):
            x[idx, p_idx] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS,
                                         name=f"x_{idx}_{p_idx}")
            y[idx, p_idx] = model.addVar(vtype=GRB.BINARY,
                                         name=f"y_{idx}_{p_idx}")

    model.update()

    # Link x and y: if pattern used (y=1), x can be positive. If y=0, x=0.
    for (idx, p_idx), xvar in x.items():
        model.addConstr(xvar <= M * y[idx, p_idx], name=f"link_{idx}_{p_idx}")

    # Demand constraints: each order's required length
    for j in range(len(widths)):
        model.addConstr(
            gp.quicksum(
                patterns_by_std_width[idx]['patterns'][p_idx][j] * x[idx, p_idx]
                for idx in patterns_by_std_width
                for p_idx in range(len(patterns_by_std_width[idx]['patterns']))
            ) >= lengths[j],
            name=f"demand_{j}"
        )

    # Objective components
    # 1) Area of material rolled out under all patterns
    area_used = gp.quicksum(
        patterns_by_std_width[idx]['sw'] * x[idx, p_idx]
        for idx in patterns_by_std_width
        for p_idx in range(len(patterns_by_std_width[idx]['patterns']))
    )

    # 2) Pattern setup penalty for each used pattern
    setup_penalty = pattern_setup_penalty * gp.quicksum(
        y[idx, p_idx]
        for idx in patterns_by_std_width
        for p_idx in range(len(patterns_by_std_width[idx]['patterns']))
    )

    # 3) Extra wide-roll setup penalty for each used pattern with sw >= threshold
    wide_penalty = gp.quicksum(
        wide_roll_extra_setup_penalty * y[idx, p_idx]
        for idx, data in patterns_by_std_width.items()
        if data['sw'] >= wide_roll_threshold_width
        for p_idx in range(len(data['patterns']))
    )

    total_area_used_equiv = area_used + setup_penalty + wide_penalty
    waste = total_area_used_equiv - total_required_area

    model.setObjective(waste, GRB.MINIMIZE)

    model.optimize()

    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
