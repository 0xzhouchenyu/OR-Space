import os
import re
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read general parameters
    num_customers = 7
    start_location = 1
    end_location = 1
    max_route_length_day = 1000
    route_cost_day = 20

    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = row['Value']
            if name == 'num_customers':
                num_customers = int(val)
            elif name == 'start_location':
                start_location = int(val)
            elif name == 'end_location':
                end_location = int(val)
            elif name == 'max_route_length_day':
                max_route_length_day = float(val)
            elif name == 'route_cost_day':
                route_cost_day = float(val)

    n = num_customers
    depot = start_location - 1  # zero-based index

    # Read distance matrix (symmetric upper triangle in CSV)
    D = [[0.0] * n for _ in range(n)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:
            nums = re.findall(r'\d+', line)
            if not nums:
                continue
            row_idx = int(nums[0]) - 1
            for j, val in enumerate(nums[1:]):
                col_idx = row_idx + 1 + j
                if col_idx < n:
                    dist = float(val)
                    D[row_idx][col_idx] = dist
                    D[col_idx][row_idx] = dist

    # Create model
    m = gp.Model("TwoDay_TSP")
    m.setParam('OutputFlag', 0)

    days = [1, 2]
    nodes = list(range(n))
    customers = [i for i in nodes if i != depot]

    # Decision variables
    # x[i,j,d] = 1 if arc i->j used on day d
    x = m.addVars(
        [(i, j, d) for d in days for i in nodes for j in nodes if i != j],
        vtype=GRB.BINARY,
        name="x"
    )

    # y[i,d] = 1 if customer i is visited on day d (i != depot)
    y = m.addVars(
        [(i, d) for d in days for i in customers],
        vtype=GRB.BINARY,
        name="y"
    )

    # z[d] = 1 if day d is used (any customer assigned)
    z = m.addVars(days, vtype=GRB.BINARY, name="z")

    # MTZ variables for subtour elimination on each day for customers only
    # u[i,d] for i in customers
    u = m.addVars(
        [(i, d) for d in days for i in customers],
        lb=1, ub=len(customers), vtype=GRB.CONTINUOUS,
        name="u"
    )

    # Objective: travel cost + fixed cost per used day
    travel_cost = gp.quicksum(D[i][j] * x[i, j, d]
                              for d in days
                              for i in nodes
                              for j in nodes if i != j)
    fixed_cost = gp.quicksum(route_cost_day * z[d] for d in days)
    m.setObjective(travel_cost + fixed_cost, GRB.MINIMIZE)

    # Constraints

    # Each customer assigned to exactly one day
    for i in customers:
        m.addConstr(gp.quicksum(y[i, d] for d in days) == 1, name=f"assign_once_{i}")

    # Day usage and depot degree relations
    for d in days:
        # Depot degree equals 2*z[d] if day used, 0 otherwise
        m.addConstr(
            gp.quicksum(x[depot, j, d] for j in nodes if j != depot) ==
            2 * z[d],
            name=f"depot_out_{d}"
        )
        m.addConstr(
            gp.quicksum(x[i, depot, d] for i in nodes if i != depot) ==
            2 * z[d],
            name=f"depot_in_{d}"
        )

    # For each day and customer: degree constraints linked to assignment
    for d in days:
        for i in customers:
            m.addConstr(
                gp.quicksum(x[i, j, d] for j in nodes if j != i) == y[i, d],
                name=f"out_deg_{i}_{d}"
            )
            m.addConstr(
                gp.quicksum(x[j, i, d] for j in nodes if j != i) == y[i, d],
                name=f"in_deg_{i}_{d}"
            )

    # Link assignment y[i,d] to day usage z[d]
    for d in days:
        for i in customers:
            m.addConstr(y[i, d] <= z[d], name=f"assign_implies_day_{i}_{d}")

    # MTZ subtour elimination per day over customers
    bigM = len(customers)
    for d in days:
        for i in customers:
            for j in customers:
                if i != j:
                    m.addConstr(
                        u[i, d] - u[j, d] + bigM * x[i, j, d] <= bigM - 1,
                        name=f"mtz_{i}_{j}_{d}"
                    )

    # Daily route length cap
    for d in days:
        m.addConstr(
            gp.quicksum(D[i][j] * x[i, j, d]
                        for i in nodes for j in nodes if i != j)
            <= max_route_length_day * z[d],
            name=f"route_len_cap_{d}"
        )

    # Optimize
    m.optimize()

    obj_val = m.objVal if m.status == GRB.OPTIMAL else float('nan')
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
