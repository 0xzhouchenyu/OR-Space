import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Load demand forecast
    demand = []
    with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(float(row["Demand_Forecast"]))
    T = len(demand)  # 6 months

    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])

    W0 = int(params["initial_workforce"])
    I0 = params["initial_inventory"]
    sp = params["sales_price"]
    rmc = params["raw_material_cost"]
    oc = params["outsourcing_cost"]
    hc = params["inventory_holding_cost"]
    bc = params["backorder_cost"]
    lr = params["labor_requirement"]
    rh = params["regular_labor_hours"]
    rw = params["regular_wage"]
    otl = params["overtime_hours_limit"]
    ow = params["overtime_wage"]
    hire_cost = params["hiring_cost"]
    fire_cost = params["firing_cost"]
    term_inv = params["terminal_inventory"]
    term_bo = params["terminal_backorders"]
    contract_min_units = params["contract_min_units"]
    contract_bigM = params["contract_bigM"]

    # Model
    m = gp.Model("FoldableTableProduction_Revised")
    m.setParam('OutputFlag', 0)

    months = range(T)  # 0..5

    # Decision variables
    W = m.addVars(months, name="W", lb=0)          # workforce
    H = m.addVars(months, name="H", lb=0)          # hired
    F = m.addVars(months, name="F", lb=0)          # fired
    P = m.addVars(months, name="P", lb=0)          # in-house total production (units)
    OT_total = m.addVars(months, name="OT", lb=0)  # overtime hours
    O = m.addVars(months, name="O", lb=0)          # outsourced units
    Inv = m.addVars(months, name="Inv", lb=0)      # inventory
    B = m.addVars(months, name="B", lb=0)          # backorders

    # Regular-time production in hours and units
    RegHours = m.addVars(months, name="RegHours", lb=0)
    RegProd = m.addVars(months, name="RegProd", lb=0)

    # Contract-related variables for months April-June (indices 3,4,5)
    contract_months = [3, 4, 5]
    ContractUnits = m.addVars(contract_months, name="ContractUnits", lb=0)
    z_contract = m.addVars(contract_months, vtype=GRB.BINARY, name="z_contract")

    # Constraints

    for t in months:
        # Workforce balance
        if t == 0:
            m.addConstr(W[t] == W0 + H[t] - F[t], name=f"WorkforceBal_{t}")
        else:
            m.addConstr(W[t] == W[t-1] + H[t] - F[t], name=f"WorkforceBal_{t}")

        # Regular hours available and used
        m.addConstr(RegHours[t] <= W[t] * rh, name=f"RegHoursCap_{t}")
        m.addConstr(RegProd[t] * lr == RegHours[t], name=f"RegProdDef_{t}")

        # Total production limited by regular + overtime hours
        m.addConstr(P[t] * lr <= RegHours[t] + OT_total[t], name=f"ProdCap_{t}")

        # Overtime limit
        m.addConstr(OT_total[t] <= W[t] * otl, name=f"OTCap_{t}")

        # Regular-time production cannot exceed total production
        m.addConstr(RegProd[t] <= P[t], name=f"RegProdLeP_{t}")

        # Inventory balance: Inv[t] - B[t] = (Inv[t-1] - B[t-1]) + P[t] + O[t] - demand[t]
        if t == 0:
            prev_inv = I0
            prev_b = 0.0
        else:
            prev_inv = Inv[t-1]
            prev_b = B[t-1]
        m.addConstr(
            Inv[t] - B[t] == prev_inv - prev_b + P[t] + O[t] - demand[t],
            name=f"InvBal_{t}"
        )

    # Terminal conditions
    m.addConstr(Inv[T-1] >= term_inv, name="TerminalInv")
    m.addConstr(B[T-1] <= term_bo, name="TerminalBO")

    # Contract constraints for April-June
    for t in contract_months:
        # Requirement for month t is its forecast plus backlog coming in from previous month
        if t == 0:
            prev_bo = 0.0
        else:
            prev_bo = B[t-1]
        Requirement_t = demand[t] + prev_bo

        # ContractUnits must be at least contract_min_units
        m.addConstr(ContractUnits[t] >= contract_min_units, name=f"ContractMin_{t}")

        # ContractUnits cannot exceed regular-time production units
        m.addConstr(ContractUnits[t] <= RegProd[t], name=f"ContractLeRegProd_{t}")

        # ContractUnits cannot exceed the month's requirement (demand plus entering backlog)
        m.addConstr(ContractUnits[t] <= Requirement_t, name=f"ContractLeReq_{t}")

        # Big-M switch to ensure feasibility with binary indicator
        # ContractUnits <= contract_bigM * z_contract[t]
        m.addConstr(ContractUnits[t] <= contract_bigM * z_contract[t],
                    name=f"ContractBigMup_{t}")

        # Enforce that the contract is "on": since ContractUnits[t] >= contract_min_units,
        # we must have z_contract[t] = 1; use lower big-M style bound
        m.addConstr(ContractUnits[t] >= contract_min_units * z_contract[t],
                    name=f"ContractBigMlow_{t}")

    # Objective: maximize net profit
    total_demand = sum(demand)
    revenue = sp * total_demand

    material_cost = gp.quicksum(rmc * P[t] for t in months)
    outsource_cost = gp.quicksum(oc * O[t] for t in months)
    holding_cost = gp.quicksum(hc * Inv[t] for t in months)
    backorder_cost_total = gp.quicksum(bc * B[t] for t in months)
    regular_labor_cost = gp.quicksum(rw * rh * W[t] for t in months)
    overtime_cost = gp.quicksum(ow * OT_total[t] for t in months)
    hiring_cost_total = gp.quicksum(hire_cost * H[t] for t in months)
    firing_cost_total = gp.quicksum(fire_cost * F[t] for t in months)

    total_cost = (material_cost + outsource_cost + holding_cost +
                  backorder_cost_total + regular_labor_cost + overtime_cost +
                  hiring_cost_total + firing_cost_total)

    m.setObjective(revenue - total_cost, GRB.MAXIMIZE)

    # Solve
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
