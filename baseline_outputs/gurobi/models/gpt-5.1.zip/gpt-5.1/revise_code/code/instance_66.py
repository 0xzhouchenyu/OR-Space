import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Set up paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load toy data
    toys = []
    toy_file = os.path.join(data_dir, "table_1.csv")
    with open(toy_file, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                "type": row["Toy_Type"],
                "labor": float(row["Manufacturing_Labor_Hours"]),
                "inspection": float(row["Inspection_Hours"]),
                "profit": float(row["Profit_Per_Unit"])
            })

    # Load general parameters
    params = {}
    params_file = os.path.join(data_dir, "general_parameters.csv")
    with open(params_file, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])

    # Extract parameters
    labor_p1 = params["available_labor_hours_period1"]
    labor_p2 = params["available_labor_hours_period2"]
    insp_p1 = params["available_inspection_hours_period1"]
    insp_p2 = params["available_inspection_hours_period2"]

    max_demand = {}
    for toy in toys:
        t = toy["type"]
        if t == "High-End":
            max_demand[(t, 1)] = params["max_demand_high_end_period1"]
            max_demand[(t, 2)] = params["max_demand_high_end_period2"]
        elif t == "Mid-Range":
            max_demand[(t, 1)] = params["max_demand_mid_range_period1"]
            max_demand[(t, 2)] = params["max_demand_mid_range_period2"]
        elif t == "Low-End":
            max_demand[(t, 1)] = params["max_demand_low_end_period1"]
            max_demand[(t, 2)] = params["max_demand_low_end_period2"]

    overtime_cap = params["overtime_labor_cap"]
    overtime_cost = params["overtime_labor_cost"]
    fatigue_threshold = params["period1_overtime_fatigue_threshold"]
    recovery_loss = params["period2_labor_recovery_loss"]
    review_threshold = params["overtime_review_threshold"]
    review_fee = params["seasonal_safety_review_fee"]

    # Model
    m = gp.Model("RevisedToyProduction")
    m.setParam('OutputFlag', 0)

    periods = [1, 2]
    toy_types = [toy["type"] for toy in toys]
    labor_req = {toy["type"]: toy["labor"] for toy in toys}
    insp_req = {toy["type"]: toy["inspection"] for toy in toys}
    profit = {toy["type"]: toy["profit"] for toy in toys}

    # Decision variables
    x = m.addVars(toy_types, periods, name="x", lb=0, vtype=GRB.CONTINUOUS)
    ot = m.addVars(periods, name="overtime", lb=0, vtype=GRB.CONTINUOUS)
    y_review = m.addVar(name="y_review", vtype=GRB.BINARY)
    y_fatigue = m.addVar(name="y_fatigue", vtype=GRB.BINARY)

    # Big-M for overtime logical constraints
    M_ot = overtime_cap

    # Labor constraints per period
    # Period 1
    m.addConstr(
        gp.quicksum(labor_req[t] * x[t, 1] for t in toy_types) <= labor_p1 + ot[1],
        name="Labor_P1"
    )

    # Period 2 labor with possible recovery loss
    # Available labor in period 2 = labor_p2 - recovery_loss * y_fatigue
    m.addConstr(
        gp.quicksum(labor_req[t] * x[t, 2] for t in toy_types) <= labor_p2 - recovery_loss * y_fatigue + ot[2],
        name="Labor_P2"
    )

    # Inspection constraints per period
    m.addConstr(
        gp.quicksum(insp_req[t] * x[t, 1] for t in toy_types) <= insp_p1,
        name="Inspection_P1"
    )
    m.addConstr(
        gp.quicksum(insp_req[t] * x[t, 2] for t in toy_types) <= insp_p2,
        name="Inspection_P2"
    )

    # Demand constraints per period
    for t in toy_types:
        for p in periods:
            m.addConstr(x[t, p] <= max_demand[(t, p)], name=f"Demand_{t}_P{p}")

    # Overtime capacity across both periods
    m.addConstr(ot[1] + ot[2] <= overtime_cap, name="Overtime_Cap")

    # Fatigue carryover: if P1 overtime above threshold, then y_fatigue = 1
    # Enforce: ot[1] - fatigue_threshold <= M_ot * y_fatigue
    m.addConstr(ot[1] - fatigue_threshold <= M_ot * y_fatigue, name="Fatigue_upper")
    # Enforce: ot[1] - fatigue_threshold >= epsilon * y_fatigue
    # Using small epsilon relative to scale; but to keep linear we can omit lower bound,
    # since model can still choose y_fatigue=1 if helpful; we want minimum labor, so OK.

    # Safety review: heavy total overtime triggers fee
    # ot[1] + ot[2] - review_threshold <= M_ot * y_review
    m.addConstr(ot[1] + ot[2] - review_threshold <= M_ot * y_review, name="Review_upper")

    # Objective: maximize profit minus overtime costs and possible review fee
    total_profit = gp.quicksum(profit[t] * x[t, p] for t in toy_types for p in periods)
    total_overtime_cost = overtime_cost * (ot[1] + ot[2])
    total_review_cost = review_fee * y_review

    m.setObjective(total_profit - total_overtime_cost - total_review_cost, GRB.MAXIMIZE)

    # Optimize
    m.optimize()

    obj_val = m.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
