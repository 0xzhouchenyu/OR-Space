import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

m = int(params['m'])   # production points
n = int(params['n'])   # demand points
p = int(params['p'])   # marshaling stations

a = {i: params[f'a_{i}'] for i in range(1, m + 1)}             # production capacities
b = {j: params[f'b_{j}'] for j in range(1, n + 1)}             # demands
f_cost = {k: params[f'f_{k}'] for k in range(1, p + 1)}        # fixed costs
q = {k: params[f'q_{k}'] for k in range(1, p + 1)}             # total capacity per station
qexp = {k: params[f'qexp_{k}'] for k in range(1, p + 1)}       # express capacity per station
alpha = {j: params[f'alpha_{j}'] for j in range(1, n + 1)}     # minimum express fraction per demand point
eps = params['eps']                                            # min positive express flow to activate
M = params['M']                                                # big-M for express flow per pair

# Load transportation costs from production to marshaling stations
cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row['i'])
        k = int(row['k'])
        cR_ik[(i, k)] = float(row['cR_ik'])
        cE_ik[(i, k)] = float(row['cE_ik'])

# Load transportation costs from marshaling stations to demand points
cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, 'table_2.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row['k'])
        j = int(row['j'])
        cR_kj[(k, j)] = float(row['cR_kj'])
        cE_kj[(k, j)] = float(row['cE_kj'])

# Create model
model = gp.Model("Revised_Transportation_Problem")
model.setParam('OutputFlag', 0)

# Sets
I = range(1, m + 1)
J = range(1, n + 1)
K = range(1, p + 1)

# Decision variables

# Flows from production i to station k: regular and express
xR = model.addVars(I, K, lb=0.0, vtype=GRB.CONTINUOUS, name="xR")
xE = model.addVars(I, K, lb=0.0, vtype=GRB.CONTINUOUS, name="xE")

# Flows from station k to demand j: regular and express
yR = model.addVars(K, J, lb=0.0, vtype=GRB.CONTINUOUS, name="yR")
yE = model.addVars(K, J, lb=0.0, vtype=GRB.CONTINUOUS, name="yE")

# Station open indicator
z = model.addVars(K, vtype=GRB.BINARY, name="z")

# Express-use indicator for each station-demand pair
w = model.addVars(K, J, vtype=GRB.BINARY, name="w")

# Additional variable for total inbound flow at each station
inflow = model.addVars(K, lb=0.0, vtype=GRB.CONTINUOUS, name="inflow")

# Objective: minimize total transportation cost (regular + express, both legs) + fixed station costs
obj = gp.quicksum(cR_ik[(i, k)] * xR[i, k] + cE_ik[(i, k)] * xE[i, k] for i in I for k in K) \
      + gp.quicksum(cR_kj[(k, j)] * yR[k, j] + cE_kj[(k, j)] * yE[k, j] for k in K for j in J) \
      + gp.quicksum(f_cost[k] * z[k] for k in K)

model.setObjective(obj, GRB.MINIMIZE)

# Constraints

# 1. Supply constraints at production points
for i in I:
    model.addConstr(
        gp.quicksum(xR[i, k] + xE[i, k] for k in K) <= a[i],
        name=f"Supply_{i}"
    )

# 2. Demand constraints at demand points (total flow, regular + express)
for j in J:
    model.addConstr(
        gp.quicksum(yR[k, j] + yE[k, j] for k in K) >= b[j],
        name=f"Demand_{j}"
    )

# 3. Flow conservation at marshaling stations (per station)
for k in K:
    model.addConstr(
        gp.quicksum(xR[i, k] + xE[i, k] for i in I) ==
        gp.quicksum(yR[k, j] + yE[k, j] for j in J),
        name=f"FlowBalance_{k}"
    )

# 4. Total capacity constraints at stations
for k in K:
    model.addConstr(
        inflow[k] == gp.quicksum(xR[i, k] + xE[i, k] for i in I),
        name=f"InflowDef_{k}"
    )
    model.addConstr(
        inflow[k] <= q[k] * z[k],
        name=f"TotalCapacity_{k}"
    )

# 5. Express capacity constraints at stations (sum of all express flows in both legs)
for k in K:
    model.addConstr(
        gp.quicksum(xE[i, k] for i in I) + gp.quicksum(yE[k, j] for j in J) <= qexp[k] * z[k],
        name=f"ExpressCapacity_{k}"
    )

# 6. Linking express flows to pairwise indicator w[k,j]
for k in K:
    for j in J:
        # If w[k,j] = 0 then yE[k,j] = 0; if w[k,j] = 1 then yE[k,j] >= eps (when positive)
        model.addConstr(yE[k, j] <= M * w[k, j], name=f"ExpressBigMUpper_{k}_{j}")
        model.addConstr(yE[k, j] >= eps * w[k, j], name=f"ExpressBigMLower_{k}_{j}")

        # Express out of a closed station must be zero
        model.addConstr(w[k, j] <= z[k], name=f"w_le_z_{k}_{j}")

# 7. Diversification of express share per demand point
for j in J:
    # The total express serving j must be at least alpha_j * total demand at j
    model.addConstr(
        gp.quicksum(yE[k, j] for k in K) >= alpha[j] * b[j],
        name=f"ExpressFraction_{j}"
    )

    # Require at least two distinct station links with positive express flow
    model.addConstr(
        gp.quicksum(w[k, j] for k in K) >= 2,
        name=f"DiversifiedExpress_{j}"
    )

# 8. No flow through closed stations
for k in K:
    for i in I:
        model.addConstr(xR[i, k] + xE[i, k] <= q[k] * z[k], name=f"NoFlowClosedIn_{i}_{k}")
    for j in J:
        model.addConstr(yR[k, j] + yE[k, j] <= M * z[k], name=f"NoFlowClosedOut_{k}_{j}")

# Optimize
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: nan")
