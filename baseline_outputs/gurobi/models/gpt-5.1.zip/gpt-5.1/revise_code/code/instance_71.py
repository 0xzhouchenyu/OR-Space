import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read general parameters
    premium_cost_multiplier = 1.5
    min_premium_share = 0.4
    with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["Parameter_Name"] == "premium_cost_multiplier":
                premium_cost_multiplier = float(row["Value"])
            elif row["Parameter_Name"] == "min_premium_share":
                min_premium_share = float(row["Value"])

    # Read table_1.csv for d_ij and c_pq
    with open(os.path.join(data_dir, "table_1.csv"), "r", newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    n = len(rows)

    # d_ij matrix: transportation volume from factory i to destination location j
    d = [[0.0 for _ in range(n)] for _ in range(n)]
    # c_pq matrix: transportation cost from location p to destination location q
    c = [[0.0 for _ in range(n)] for _ in range(n)]

    for i, row in enumerate(rows):
        for j in range(n):
            d[i][j] = float(row[f"Transportation_volume_to_Location_{j+1}"])
            c[i][j] = float(row[f"Transportation_cost_to_Location_{j+1}"])

    # outbound_volume_i
    outbound = [sum(d[i][j] for j in range(n)) for i in range(n)]

    # compute c_std_ip and c_prem_ip for all i,p
    c_std = [[0.0 for _ in range(n)] for _ in range(n)]
    c_prem = [[0.0 for _ in range(n)] for _ in range(n)]

    for i in range(n):
        out_i = outbound[i]
        if out_i > 0:
            # c_std_ip = (sum_j d_ij * c_pj) / outbound_volume_i
            # Here we interpret c_pj as cost from location p to destination j, and d_ij as volume i->j
            for p in range(n):
                num = 0.0
                for j in range(n):
                    num += d[i][j] * c[p][j]
                c_std[i][p] = num / out_i
                c_prem[i][p] = premium_cost_multiplier * c_std[i][p]
        else:
            for p in range(n):
                c_std[i][p] = 0.0
                c_prem[i][p] = 0.0

    # Build MIP model
    m = gp.Model("revised_factory_assignment")
    m.setParam('OutputFlag', 0)

    I = range(n)
    P = range(n)

    # Decision variables
    x = m.addVars(I, P, vtype=GRB.BINARY, name="x")           # assignment
    y = m.addVars(I, P, vtype=GRB.BINARY, name="y")           # premium mode
    v_std = m.addVars(I, P, lb=0.0, name="v_std")             # standard volume
    v_prem = m.addVars(I, P, lb=0.0, name="v_prem")           # premium volume

    # Constraints

    # Each factory assigned to exactly one location
    for i in I:
        m.addConstr(gp.quicksum(x[i, p] for p in P) == 1, name=f"assign_factory_{i}")

    # Each location hosts at most one factory
    for p in P:
        m.addConstr(gp.quicksum(x[i, p] for i in I) <= 1, name=f"capacity_location_{p}")

    # Volume balance: for each factory, total outbound volume handled at its location
    for i in I:
        m.addConstr(
            gp.quicksum(v_std[i, p] + v_prem[i, p] for p in P) == outbound[i],
            name=f"outbound_balance_{i}"
        )

    # Volume can only be at assigned location: v_std + v_prem <= M_i * x_ip
    for i in I:
        M_i = outbound[i]
        for p in P:
            if M_i > 0:
                m.addConstr(
                    v_std[i, p] + v_prem[i, p] <= M_i * x[i, p],
                    name=f"vol_assign_{i}_{p}"
                )
            else:
                # if outbound is zero, enforce zero volumes
                m.addConstr(v_std[i, p] == 0.0, name=f"zero_std_{i}_{p}")
                m.addConstr(v_prem[i, p] == 0.0, name=f"zero_prem_{i}_{p}")

    # Premium implies minimum premium share: v_prem_ip >= min_share * M_i * y_ip
    for i in I:
        M_i = outbound[i]
        for p in P:
            if M_i > 0:
                m.addConstr(
                    v_prem[i, p] >= min_premium_share * M_i * y[i, p],
                    name=f"premium_min_share_{i}_{p}"
                )
            else:
                # if outbound is zero, no premium volume needed
                m.addConstr(v_prem[i, p] == 0.0, name=f"zero_prem_share_{i}_{p}")

    # Premium only where assignment: y_ip <= x_ip
    for i in I:
        for p in P:
            m.addConstr(y[i, p] <= x[i, p], name=f"premium_implies_assign_{i}_{p}")

    # Objective: minimize total cost = sum_i,p (v_std * c_std + v_prem * c_prem)
    obj = gp.quicksum(
        v_std[i, p] * c_std[i][p] + v_prem[i, p] * c_prem[i][p]
        for i in I for p in P
    )
    m.setObjective(obj, GRB.MINIMIZE)

    m.optimize()

    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print("FINAL_OBJ_VALUE: inf")

if __name__ == "__main__":
    main()
