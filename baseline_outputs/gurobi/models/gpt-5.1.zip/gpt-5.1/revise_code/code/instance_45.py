import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_segments(filepath):
    segments = {}
    products = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row['Product']
            if p not in segments:
                segments[p] = []
                products.append(p)
            rng = row['Sales_Volume_Range']
            profit = float(row['Profit'])
            if rng.startswith('Above_'):
                lower = float(rng.split('_')[1])
                upper = None
            else:
                parts = rng.split('_')
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({'lower': lower, 'upper': upper, 'profit': profit})
    return products, segments

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    products, segments = load_segments(os.path.join(data_dir, "table_1.csv"))

    # Map internal product keys to simple names A,B,C
    prod_name = {p: p.split('_')[1] for p in products}

    model = gp.Model("Revised_Maximize_Profit")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {}          # production quantities
    p_var = {}      # profit contribution from each product
    y = {}          # segment selection binaries

    for prod in products:
        pname = prod_name[prod]
        x[prod] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{pname}")
        p_var[prod] = model.addVar(vtype=GRB.CONTINUOUS, lb=0.0, name=f"p_{pname}")
        y[prod] = []
        for i in range(len(segments[prod])):
            y_ij = model.addVar(vtype=GRB.BINARY, name=f"y_{pname}_{i}")
            y[prod].append(y_ij)

    # Overtime variables
    ot_hours = model.addVar(vtype=GRB.CONTINUOUS, lb=0.0, name="overtime_hours")
    z_second_review = model.addVar(vtype=GRB.BINARY, name="second_review_flag")

    # Objective: sum product profits - overtime cost - second review fee
    overtime_cost_per_hour = params.get("overtime_cost_per_hour", 0.0)
    overtime_second_review_fee = params.get("overtime_second_review_fee", 0.0)

    model.setObjective(
        gp.quicksum(p_var[prod] for prod in products)
        - overtime_cost_per_hour * ot_hours
        - overtime_second_review_fee * z_second_review,
        GRB.MAXIMIZE
    )

    M = 1e5

    # Segment logic per product
    for prod in products:
        segs = segments[prod]

        # At most one segment active
        model.addConstr(gp.quicksum(y[prod]) <= 1, name=f"seg_exclusive_{prod}")

        for i, seg in enumerate(segs):
            lo = seg['lower']
            hi = seg['upper']
            profit = seg['profit']

            # Lower bound when segment active
            if lo == 0:
                model.addConstr(
                    x[prod] >= 1 - M * (1 - y[prod][i]),
                    name=f"lb_{prod}_{i}"
                )
            else:
                model.addConstr(
                    x[prod] >= (lo + 1) - M * (1 - y[prod][i]),
                    name=f"lb_{prod}_{i}"
                )

            # Upper bound when segment active (if finite)
            if hi is not None:
                model.addConstr(
                    x[prod] <= hi + M * (1 - y[prod][i]),
                    name=f"ub_{prod}_{i}"
                )

            # Profit upper bound for active segment
            model.addConstr(
                p_var[prod] <= profit * x[prod] + M * (1 - y[prod][i]),
                name=f"profit_{prod}_{i}"
            )

        # If no segment active, force x and p_var to zero
        model.addConstr(
            x[prod] <= M * gp.quicksum(y[prod]),
            name=f"x_zero_if_no_seg_{prod}"
        )
        model.addConstr(
            p_var[prod] <= M * gp.quicksum(y[prod]),
            name=f"p_zero_if_no_seg_{prod}"
        )

    # Resource constraints

    # Technical preparation time
    model.addConstr(
        gp.quicksum(
            params[f"technical_prep_time_{prod_name[prod]}"] * x[prod]
            for prod in products
        ) <= params["available_technical_prep_time"],
        name="technical_prep_cap"
    )

    # Labor time with overtime
    # total_labor = regular (<= available_labor_time) + overtime (ot_hours)
    total_labor_expr = gp.quicksum(
        params[f"labor_time_{prod_name[prod]}"] * x[prod]
        for prod in products
    )

    available_labor = params["available_labor_time"]
    overtime_cap = params["overtime_cap_hours"]

    # total_labor <= available_labor_time + ot_hours
    model.addConstr(
        total_labor_expr <= available_labor + ot_hours,
        name="labor_balance"
    )

    # Maximum overtime hours
    model.addConstr(
        ot_hours <= overtime_cap,
        name="overtime_cap"
    )

    # Materials constraint
    model.addConstr(
        gp.quicksum(
            params[f"materials_{prod_name[prod]}"] * x[prod]
            for prod in products
        ) <= params["available_materials"],
        name="materials_cap"
    )

    # Packaging capacity
    model.addConstr(
        gp.quicksum(
            params[f"pack_units_{prod_name[prod]}"] * x[prod]
            for prod in products
        ) <= params["packaging_cap_units"],
        name="packaging_cap"
    )

    # Second review tier logic
    overtime_second_review_threshold = params["overtime_second_review_threshold"]

    # ot_hours <= threshold + bigM * z
    model.addConstr(
        ot_hours <= overtime_second_review_threshold + M * z_second_review,
        name="second_review_logic"
    )

    # Solve
    model.optimize()

    obj_val = model.objVal if model.status == GRB.OPTIMAL else None
    if obj_val is None:
        print("FINAL_OBJ_VALUE: None")
    else:
        print(f"FINAL_OBJ_VALUE: {round(obj_val, 2)}")

if __name__ == "__main__":
    main()
