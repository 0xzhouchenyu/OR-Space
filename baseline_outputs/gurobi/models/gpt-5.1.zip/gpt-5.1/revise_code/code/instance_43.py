import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    return params


def main():
    # Load data
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = load_parameters(data_path)

    # Extract parameters
    min_A = params['min_raw_material_A']
    min_B = params['min_raw_material_B']
    min_C = params['min_raw_material_C']

    cap_A_a = params['warehouse_A_truck_capacity_A']
    cap_A_b = params['warehouse_A_truck_capacity_B']
    cap_A_c = params['warehouse_A_truck_capacity_C']
    cost_A_truck = params['warehouse_A_truck_cost']

    cap_B_a = params['warehouse_B_truck_capacity_A']
    cap_B_b = params['warehouse_B_truck_capacity_B']
    cap_B_c = params['warehouse_B_truck_capacity_C']
    cost_B_truck = params['warehouse_B_truck_cost']

    cost_A_fixed = params['warehouse_A_fixed_cost']
    cost_B_fixed = params['warehouse_B_fixed_cost']
    B_overflow_threshold = params['warehouse_B_overflow_threshold_trucks']
    B_overflow_cost = params['warehouse_B_overflow_coordination_cost']
    dual_trigger = params['dual_warehouse_reconciliation_trigger']
    dual_fee = params['dual_warehouse_reconciliation_fee']

    # Build model
    m = gp.Model("RevisedMinFreightCost")
    m.setParam('OutputFlag', 0)

    # Big-M for linking binary and integer variables
    M_trucks = 1000

    # Decision variables
    x = m.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_A")
    y = m.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_B")

    use_A = m.addVar(vtype=GRB.BINARY, name="use_A")
    use_B = m.addVar(vtype=GRB.BINARY, name="use_B")

    # Binary for B overflow (1 if y > threshold)
    B_overflow = m.addVar(vtype=GRB.BINARY, name="B_overflow")

    # Binary for dual-warehouse reconciliation
    dual_use = m.addVar(vtype=GRB.BINARY, name="dual_use")

    # Constraints: material requirements
    m.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
    m.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
    m.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

    # Link use_A/use_B binaries with truck counts
    m.addConstr(x <= M_trucks * use_A, "Link_use_A")
    m.addConstr(y <= M_trucks * use_B, "Link_use_B")

    # Overflow logic for warehouse B: B_overflow = 1 if y > threshold
    # y > threshold  <=>  y >= threshold + 1
    # Implement via inequalities:
    m.addConstr(y - (B_overflow_threshold + 1) >= -M_trucks * (1 - B_overflow), "Overflow_lb")
    m.addConstr(y - (B_overflow_threshold + 1) <= M_trucks * B_overflow, "Overflow_ub")

    # Dual warehouse use: dual_use = 1 if both use_A and use_B are 1
    m.addConstr(dual_use <= use_A, "dual_le_A")
    m.addConstr(dual_use <= use_B, "dual_le_B")
    m.addConstr(dual_use >= use_A + use_B - 1, "dual_ge_sum_minus1")

    # Objective
    truck_cost = cost_A_truck * x + cost_B_truck * y
    fixed_cost = cost_A_fixed * use_A + cost_B_fixed * use_B
    overflow_cost_term = B_overflow_cost * B_overflow
    dual_cost_term = dual_fee * dual_trigger * dual_use

    m.setObjective(truck_cost + fixed_cost + overflow_cost_term + dual_cost_term, GRB.MINIMIZE)

    # Optimize
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
