import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = {}
    with open(data_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            value = row["Value"].strip()
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass
            params[name] = value
    return params

def main():
    params = load_parameters()

    # Extract parameters
    profit_robot = params["profit_per_robot"]
    profit_car = params["profit_per_model_car"]
    profit_blocks = params["profit_per_building_blocks"]
    profit_doll = params["profit_per_doll"]

    plastic_avail = params["plastic_available"]
    plastic_robot = params["plastic_per_robot"]
    plastic_car = params["plastic_per_model_car"]
    plastic_blocks = params["plastic_per_building_blocks"]
    plastic_doll = params["plastic_per_doll"]

    electronics_avail = params["electronic_components_available"]
    electronics_robot = params["electronics_per_robot"]
    electronics_car = params["electronics_per_model_car"]
    electronics_blocks = params["electronics_per_building_blocks"]
    electronics_doll = params["electronics_per_doll"]

    # Big-M for linking binaries with quantities
    M = 10000

    # Create model
    model = gp.Model("ToyManufacturing")
    model.setParam('OutputFlag', 0)

    # Decision variables: integer production quantities
    x_robot = model.addVar(vtype=GRB.INTEGER, lb=0, name="robots")
    x_car = model.addVar(vtype=GRB.INTEGER, lb=0, name="model_cars")
    x_blocks = model.addVar(vtype=GRB.INTEGER, lb=0, name="building_blocks")
    x_doll = model.addVar(vtype=GRB.INTEGER, lb=0, name="dolls")

    # Binary variables: whether each product is produced
    y_robot = model.addVar(vtype=GRB.BINARY, name="y_robot")
    y_doll = model.addVar(vtype=GRB.BINARY, name="y_doll")
    y_car = model.addVar(vtype=GRB.BINARY, name="y_car")
    y_blocks = model.addVar(vtype=GRB.BINARY, name="y_blocks")

    # Objective: maximize profit
    model.setObjective(
        profit_robot * x_robot +
        profit_car * x_car +
        profit_blocks * x_blocks +
        profit_doll * x_doll,
        GRB.MAXIMIZE
    )

    # Resource constraints
    model.addConstr(
        plastic_robot * x_robot +
        plastic_car * x_car +
        plastic_blocks * x_blocks +
        plastic_doll * x_doll <= plastic_avail,
        name="Plastic"
    )

    model.addConstr(
        electronics_robot * x_robot +
        electronics_car * x_car +
        electronics_blocks * x_blocks +
        electronics_doll * x_doll <= electronics_avail,
        name="Electronics"
    )

    # Link quantities and binary indicators
    model.addConstr(x_robot <= M * y_robot, name="Link_robot_ub")
    model.addConstr(x_doll <= M * y_doll, name="Link_doll_ub")
    model.addConstr(x_car <= M * y_car, name="Link_car_ub")
    model.addConstr(x_blocks <= M * y_blocks, name="Link_blocks_ub")

    # Ensure if a product is declared produced (y=1) it has at least 1 unit
    model.addConstr(x_robot >= y_robot, name="Link_robot_lb")
    model.addConstr(x_doll >= y_doll, name="Link_doll_lb")
    model.addConstr(x_car >= y_car, name="Link_car_lb")
    model.addConstr(x_blocks >= y_blocks, name="Link_blocks_lb")

    # Business rules

    # 1) Robots and dolls are mutually exclusive
    model.addConstr(y_robot + y_doll <= 1, name="Robot_Doll_Exclusion")

    # 2) If model cars are manufactured, building blocks must also be manufactured
    model.addConstr(y_car <= y_blocks, name="Car_Blocks_Dependency")

    # 3) Dolls volume cannot exceed model cars volume
    model.addConstr(x_doll <= x_car, name="Dolls_leq_Cars")

    # 4) New mutual exclusion: model cars and building blocks cannot both be produced
    model.addConstr(y_car + y_blocks <= 1, name="Car_Blocks_Mutual_Exclusion")

    # Optimize
    model.optimize()

    obj_val = model.objVal if model.status == GRB.OPTIMAL else 0.0
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
