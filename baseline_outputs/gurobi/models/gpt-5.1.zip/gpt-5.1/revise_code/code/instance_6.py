import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Load demand data
    demand = {}
    with open(os.path.join(base_dir, 'data', 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        quarters = [int(h) for h in header[1:]]
        for row in reader:
            product = row[0].strip()
            for j, q in enumerate(quarters):
                demand[(product, q)] = int(row[j + 1])

    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, 'data', 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    products = ['I', 'II', 'III']
    quarters = [1, 2, 3, 4]

    init_inv = params['initial_inventory']
    end_inv_req = params['end_inventory_requirement']
    hours_per_quarter = params['production_hours_per_quarter']

    hours_per_unit = {
        'I': params['product_I_hours_per_unit'],
        'II': params['product_II_hours_per_unit'],
        'III': params['product_III_hours_per_unit']
    }

    delay_penalty = {
        'I': params['delay_penalty_product_I'],
        'II': params['delay_penalty_product_II'],
        'III': params['delay_penalty_product_III']
    }

    inv_cost = params['inventory_cost_per_unit']

    normal_hours_cap_fraction = {
        1: params['normal_hours_cap_fraction_q1'],
        2: params['normal_hours_cap_fraction_q2'],
        3: params['normal_hours_cap_fraction_q3'],
        4: params['normal_hours_cap_fraction_q4']
    }

    peak_hours_cap = {
        1: params['peak_hours_cap_q1'],
        2: params['peak_hours_cap_q2'],
        3: params['peak_hours_cap_q3'],
        4: params['peak_hours_cap_q4']
    }

    peak_cost_per_hour = {
        1: params['peak_cost_per_hour_q1'],
        2: params['peak_cost_per_hour_q2'],
        3: params['peak_cost_per_hour_q3'],
        4: params['peak_cost_per_hour_q4']
    }

    # Build model
    m = gp.Model("RevisedProductionScheduling")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # Production in normal hours
    x_norm = m.addVars(products, quarters, name="x_norm", vtype=GRB.INTEGER, lb=0)
    # Production in peak hours
    x_peak = m.addVars(products, quarters, name="x_peak", vtype=GRB.INTEGER, lb=0)

    # Total production for convenience
    # x_tot[p,t] = x_norm[p,t] + x_peak[p,t]
    # Inventory variables
    inv = m.addVars(products, quarters, name="inv")
    inv_pos = m.addVars(products, quarters, name="inv_pos", lb=0)
    inv_neg = m.addVars(products, quarters, name="inv_neg", lb=0)

    # Product I cannot be produced in Q2 in either normal or peak hours
    m.addConstr(x_norm['I', 2] == 0)
    m.addConstr(x_peak['I', 2] == 0)

    # Inventory balance constraints
    for p in products:
        # Quarter 1
        m.addConstr(
            inv[p, 1] == init_inv + x_norm[p, 1] + x_peak[p, 1] - demand[(p, 1)]
        )
        # Quarters 2-4
        for t in range(2, 5):
            m.addConstr(
                inv[p, t] == inv[p, t - 1] + x_norm[p, t] + x_peak[p, t] - demand[(p, t)]
            )

    # Split inventory into positive and negative parts
    for p in products:
        for t in quarters:
            m.addConstr(inv[p, t] == inv_pos[p, t] - inv_neg[p, t])

    # End of Q4: inventory must be at least end_inv_req
    for p in products:
        m.addConstr(inv[p, 4] >= end_inv_req)

    # Production hours constraints
    for t in quarters:
        # Normal hours cap
        m.addConstr(
            gp.quicksum(hours_per_unit[p] * x_norm[p, t] for p in products)
            <= normal_hours_cap_fraction[t] * hours_per_quarter
        )
        # Peak hours cap
        m.addConstr(
            gp.quicksum(hours_per_unit[p] * x_peak[p, t] for p in products)
            <= peak_hours_cap[t]
        )

    # Objective: delay penalties + inventory holding costs + peak-hour costs
    obj = gp.quicksum(
        delay_penalty[p] * inv_neg[p, t] + inv_cost * inv_pos[p, t]
        for p in products for t in quarters
    ) + gp.quicksum(
        peak_cost_per_hour[t] *
        gp.quicksum(hours_per_unit[p] * x_peak[p, t] for p in products)
        for t in quarters
    )

    m.setObjective(obj, GRB.MINIMIZE)

    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    main()
