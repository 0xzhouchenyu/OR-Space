import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_distance_matrix(filepath):
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        city_labels = header[1:]
        dist = []
        cities = []
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
    return cities, dist


def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['parameter'].strip()
            val = row['value'].strip()
            try:
                val_num = float(val)
                if val_num.is_integer():
                    val = int(val_num)
                else:
                    val = val_num
            except ValueError:
                pass
            params[key] = val
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    dist_file = os.path.join(base_dir, "data", "table_1.csv")
    param_file = os.path.join(base_dir, "data", "general_parameters.csv")

    cities, dist = load_distance_matrix(dist_file)
    params = load_general_parameters(param_file)

    n = len(cities)

    # Map city labels (1-based in data) to indices (0-based in arrays)
    label_to_index = {int(label): idx for idx, label in enumerate(cities)}

    start_label = int(params['start_city'])
    end_label = int(params['end_city'])
    prohibited_from = int(params['prohibited_from'])
    prohibited_to = int(params['prohibited_to'])
    inspection_from = int(params['inspection_arc_from'])
    inspection_to = int(params['inspection_arc_to'])
    inspection_cost = float(params['inspection_stop_cost'])

    start = label_to_index[start_label]
    end = label_to_index[end_label]
    prohib_i = label_to_index[prohibited_from]
    prohib_j = label_to_index[prohibited_to]
    insp_i = label_to_index[inspection_from]
    insp_j = label_to_index[inspection_to]

    model = gp.Model("Revised_TSP")
    model.setParam('OutputFlag', 0)

    # Decision variables x[i,j]: binary edge usage
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")

    # MTZ variables for subtour elimination (for all nodes except start)
    u = model.addVars(n, vtype=GRB.CONTINUOUS, name="u")

    # Objective: travel distance plus inspection cost on specific arc if used
    obj_expr = gp.quicksum(dist[i][j] * x[i, j] for i in range(n) for j in range(n) if i != j)
    obj_expr += inspection_cost * x[insp_i, insp_j]
    model.setObjective(obj_expr, GRB.MINIMIZE)

    # Degree constraints
    for i in range(n):
        if i == end:
            # end city: exactly one incoming, no outgoing
            model.addConstr(gp.quicksum(x[j, i] for j in range(n) if j != i) == 1, name=f"in_deg_end_{i}")
            model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 0, name=f"out_deg_end_{i}")
        elif i == start:
            # start city: exactly one outgoing, no incoming
            model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1, name=f"out_deg_start_{i}")
            model.addConstr(gp.quicksum(x[j, i] for j in range(n) if j != i) == 0, name=f"in_deg_start_{i}")
        else:
            # intermediate cities: one in, one out
            model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1, name=f"out_deg_{i}")
            model.addConstr(gp.quicksum(x[j, i] for j in range(n) if j != i) == 1, name=f"in_deg_{i}")

    # Prohibited direct arc
    model.addConstr(x[prohib_i, prohib_j] == 0, name="prohibited_arc")

    # MTZ subtour elimination for path (adapted with start and end)
    # Standard MTZ on nodes except start; fix u[start] = 0
    model.addConstr(u[start] == 0, name="u_start_fix")

    for i in range(n):
        if i == start:
            continue
        model.addConstr(u[i] >= 1, name=f"u_lb_{i}")
        model.addConstr(u[i] <= n - 1, name=f"u_ub_{i}")

    for i in range(n):
        for j in range(n):
            if i != j and i != start and j != start:
                # Only apply MTZ between non-start nodes
                model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1, name=f"mtz_{i}_{j}")

    # No self loops
    for i in range(n):
        model.addConstr(x[i, i] == 0, name=f"no_self_{i}")

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
