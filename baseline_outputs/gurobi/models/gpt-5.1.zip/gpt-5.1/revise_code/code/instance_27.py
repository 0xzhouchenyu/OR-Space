import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_table1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in ['Product_I', 'Product_II', 'Product_III']:
                val = row[p].strip() if row[p].strip() else None
                proc_times[e][p] = float(val) if val else None
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())
    return equipment, proc_times, eff_hours, op_costs

def load_general_params(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    raw_costs = {}
    prices = {}
    labor_coeff = {}
    shared_labor_hours = None
    b2_activation_fee = None

    mapping_raw = {
        'raw_material_cost_product_I': 'Product_I',
        'raw_material_cost_product_II': 'Product_II',
        'raw_material_cost_product_III': 'Product_III',
    }
    mapping_price = {
        'unit_price_product_I': 'Product_I',
        'unit_price_product_II': 'Product_II',
        'unit_price_product_III': 'Product_III',
    }

    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            if name in mapping_raw:
                raw_costs[mapping_raw[name]] = val
            if name in mapping_price:
                prices[mapping_price[name]] = val
            if name == 'shared_labor_hours':
                shared_labor_hours = val
            if name.startswith('labor_coeff_'):
                equip = name.replace('labor_coeff_', '')
                labor_coeff[equip] = val
            if name == 'b2_activation_fee':
                b2_activation_fee = val

    return raw_costs, prices, shared_labor_hours, labor_coeff, b2_activation_fee

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    equipment, proc_times, eff_hours, op_costs = load_table1(data_dir)
    raw_costs, prices, shared_labor_hours, labor_coeff, b2_activation_fee = load_general_params(data_dir)

    products = ['Product_I', 'Product_II', 'Product_III']
    A_equip = [e for e in equipment if e.startswith('A')]
    B_equip = [e for e in equipment if e.startswith('B')]

    model = gp.Model("Factory_Production_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables: production units per equipment-product
    x = {}
    for e in equipment:
        for p in products:
            if proc_times[e][p] is not None:
                x[e, p] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")

    # Binary activation variable for B2 (gate for one-time fee)
    y_B2 = model.addVar(vtype=GRB.BINARY, name="y_B2")

    model.update()

    # Capacity constraints per equipment
    for e in equipment:
        expr = gp.LinExpr()
        for p in products:
            if proc_times[e][p] is not None:
                expr += x[e, p] * proc_times[e][p]
        model.addConstr(expr <= eff_hours[e], name=f"capacity_{e}")

    # Flow balance constraints between A and B for each product
    for p in products:
        a_sum = gp.LinExpr()
        b_sum = gp.LinExpr()
        for e in A_equip:
            if proc_times[e][p] is not None:
                a_sum += x[e, p]
        for e in B_equip:
            if proc_times[e][p] is not None:
                b_sum += x[e, p]
        model.addConstr(a_sum == b_sum, name=f"balance_{p}")

    # Labor pool constraint: total operator-hours
    labor_expr = gp.LinExpr()
    for e in equipment:
        coef = labor_coeff.get(e, 0.0)
        if coef != 0.0:
            time_expr = gp.LinExpr()
            for p in products:
                if proc_times[e][p] is not None:
                    time_expr += x[e, p] * proc_times[e][p]
            labor_expr += coef * time_expr
    if shared_labor_hours is not None:
        model.addConstr(labor_expr <= shared_labor_hours, name="shared_labor")

    # Link B2 activation to any use of B2 (big-M)
    if 'B2' in equipment:
        M_B2 = eff_hours['B2']
        time_B2 = gp.LinExpr()
        for p in products:
            if proc_times['B2'][p] is not None:
                time_B2 += x['B2', p] * proc_times['B2'][p]
        model.addConstr(time_B2 <= M_B2 * y_B2, name="activate_B2")

    # Total production per product (from A-side equipment)
    total_prod = {}
    for p in products:
        total_expr = gp.LinExpr()
        for e in A_equip:
            if proc_times[e][p] is not None:
                total_expr += x[e, p]
        total_prod[p] = total_expr

    # Revenue
    revenue = gp.LinExpr()
    for p in products:
        revenue += prices[p] * total_prod[p]

    # Raw material cost
    raw_cost_total = gp.LinExpr()
    for p in products:
        raw_cost_total += raw_costs[p] * total_prod[p]

    # Operating costs proportional to machine-hour usage
    operating_cost = gp.LinExpr()
    for e in equipment:
        time_expr = gp.LinExpr()
        for p in products:
            if proc_times[e][p] is not None:
                time_expr += x[e, p] * proc_times[e][p]
        operating_cost += op_costs[e] * (time_expr / eff_hours[e])

    # B2 activation fee (gate cost)
    activation_cost = 0.0
    if b2_activation_fee is not None:
        activation_cost = b2_activation_fee * y_B2

    # Objective: maximize profit
    model.setObjective(revenue - raw_cost_total - operating_cost - activation_cost, GRB.MAXIMIZE)

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
