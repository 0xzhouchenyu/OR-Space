import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    students = []
    with open(os.path.join(base, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            s = {
                'Student_ID': int(row['Student_ID']),
                'Wage_CNY_per_hour': float(row['Wage_CNY_per_hour'])
            }
            for d in ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']:
                s[d] = float(row[d])
            students.append(s)
    
    params = {}
    with open(os.path.join(base, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = row['Value']
            try:
                params[name] = int(val)
            except ValueError:
                try:
                    params[name] = float(val)
                except ValueError:
                    params[name] = val
    return students, params

def main():
    students, params = load_data()
    
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    student_ids = [s['Student_ID'] for s in students]
    
    hours_per_day = 14  # 8AM to 10PM
    min_undergrad = params['min_undergrad_hours']
    min_grad = params['min_grad_hours']
    max_shifts = params['max_shifts_per_student']
    max_students_day = params['max_students_per_day']
    daily_open_fee = params['daily_open_fee_cny']
    min_grad_weekly_coverage = params['min_grad_weekly_coverage_hours']
    
    # Students 1-4 undergrads, 5-6 grads
    grad_students = {5, 6}
    
    wage = {s['Student_ID']: s['Wage_CNY_per_hour'] for s in students}
    avail = {(s['Student_ID'], d): s[d] for s in students for d in days}
    
    model = gp.Model("Lab_Scheduling_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i,d]: hours worked by student i on day d
    x = model.addVars(student_ids, days, lb=0.0, vtype=GRB.CONTINUOUS, name="x")
    # y[i,d]: 1 if student i works on day d
    y = model.addVars(student_ids, days, vtype=GRB.BINARY, name="y")
    # z[i,d]: binary, equals y[i,d] to track per (student,day) fee; explicitly modeled
    z = model.addVars(student_ids, days, vtype=GRB.BINARY, name="z")
    
    # Bounds: x[i,d] <= availability
    for i in student_ids:
        for d in days:
            model.addConstr(x[i, d] <= avail[i, d], name=f"avail_{i}_{d}")
    
    # Coverage: exactly 14 hours per day
    for d in days:
        model.addConstr(gp.quicksum(x[i, d] for i in student_ids) == hours_per_day,
                        name=f"daily_coverage_{d}")
    
    # Link x and y: if x[i,d] > 0 then y[i,d] = 1
    for i in student_ids:
        for d in days:
            model.addConstr(x[i, d] <= avail[i, d] * y[i, d], name=f"link_xy_{i}_{d}")
    
    # y and z must be equal (z is just a copy to track fee, as per requirement)
    for i in student_ids:
        for d in days:
            model.addConstr(z[i, d] == y[i, d], name=f"link_yz_{i}_{d}")
    
    # Max shifts per student per week
    for i in student_ids:
        model.addConstr(gp.quicksum(y[i, d] for d in days) <= max_shifts,
                        name=f"max_shifts_{i}")
    
    # Max students per day
    for d in days:
        model.addConstr(gp.quicksum(y[i, d] for i in student_ids) <= max_students_day,
                        name=f"max_students_day_{d}")
    
    # Minimum weekly hours per student
    for i in student_ids:
        min_h = min_grad if i in grad_students else min_undergrad
        model.addConstr(gp.quicksum(x[i, d] for d in days) >= min_h,
                        name=f"min_hours_{i}")
    
    # New constraint: total graduate coverage hours >= min_grad_weekly_coverage
    model.addConstr(
        gp.quicksum(x[i, d] for i in grad_students for d in days) >= min_grad_weekly_coverage,
        name="min_grad_weekly_coverage"
    )
    
    # Objective: minimize total wages + daily open fees
    wage_cost = gp.quicksum(wage[i] * x[i, d] for i in student_ids for d in days)
    open_fee_cost = gp.quicksum(daily_open_fee * z[i, d] for i in student_ids for d in days)
    
    model.setObjective(wage_cost + open_fee_cost, GRB.MINIMIZE)
    
    model.optimize()
    
    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
