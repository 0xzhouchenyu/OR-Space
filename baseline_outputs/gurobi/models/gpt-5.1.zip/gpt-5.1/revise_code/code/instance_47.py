import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filepath):
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = [row for row in reader]
    return headers, rows

def load_general_parameters():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    headers, rows = load_csv(filepath)
    params = {}
    for row in rows:
        name = row[0].strip()
        try:
            value = float(row[1].strip())
        except ValueError:
            value = row[1].strip()
        params[name] = value
    return params

def load_crop_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "table_1.csv")
    headers, rows = load_csv(filepath)
    crops = [h.strip() for h in headers[1:]]
    data = {}
    for row in rows:
        item = row[0].strip()
        values = [float(v.strip()) for v in row[1:]]
        data[item] = dict(zip(crops, values))
    return crops, data

def main():
    # Load data
    params = load_general_parameters()
    crops, crop_data = load_crop_data()

    # Extract parameters
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']

    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = params['max_chickens']
    max_dairy_cows = params['max_dairy_cows']

    fixed_cost_chicken_setup = params['fixed_cost_chicken_setup']
    min_chickens_if_coop_open = params['min_chickens_if_coop_open']
    second_biosecurity_threshold = params['second_biosecurity_threshold']
    second_biosecurity_cost = params['second_biosecurity_cost']
    biosecurity_training_aw_days = params['biosecurity_training_aw_days']
    biosecurity_training_ss_days = params['biosecurity_training_ss_days']

    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']

    # Create Gurobi model
    model = gp.Model("Farm_Optimization_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {c: model.addVar(lb=0.0, name=f"x_{c}") for c in crops}

    y_dairy = model.addVar(lb=0.0, ub=max_dairy_cows, name="dairy_cows")
    y_chicken = model.addVar(lb=0.0, ub=max_chickens, name="chickens")

    surplus_aw = model.addVar(lb=0.0, name="surplus_aw")
    surplus_ss = model.addVar(lb=0.0, name="surplus_ss")

    # Binary variables for poultry biosecurity gates
    coop_open = model.addVar(vtype=GRB.BINARY, name="coop_open")
    second_bio = model.addVar(vtype=GRB.BINARY, name="second_bio")

    # Objective: maximize net income
    revenue_crops = gp.quicksum(crop_income[c] * x[c] for c in crops)
    revenue_dairy = income_dairy * y_dairy
    revenue_chicken = income_chicken * y_chicken
    revenue_external = ext_rate_aw * surplus_aw + ext_rate_ss * surplus_ss

    # Costs: investments and fixed/inspection costs for poultry
    cost_invest = inv_dairy * y_dairy + inv_chicken * y_chicken
    cost_poultry_setup = fixed_cost_chicken_setup * coop_open
    cost_second_bio = second_biosecurity_cost * second_bio

    obj = revenue_crops + revenue_dairy + revenue_chicken + revenue_external - cost_invest - cost_poultry_setup - cost_second_bio
    model.setObjective(obj, GRB.MAXIMIZE)

    # Constraints

    # Land constraint
    model.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, name="Land")

    # Funds constraint (development funds limit investments; fixed costs are operating)
    model.addConstr(inv_dairy * y_dairy + inv_chicken * y_chicken <= funds_available, name="Funds")

    # Labor constraints with training time if coop is open
    model.addConstr(
        gp.quicksum(crop_aw[c] * x[c] for c in crops) +
        labor_aw_dairy * y_dairy +
        labor_aw_chicken * y_chicken +
        surplus_aw +
        biosecurity_training_aw_days * coop_open
        <= labor_aw,
        name="Labor_AW"
    )

    model.addConstr(
        gp.quicksum(crop_ss[c] * x[c] for c in crops) +
        labor_ss_dairy * y_dairy +
        labor_ss_chicken * y_chicken +
        surplus_ss +
        biosecurity_training_ss_days * coop_open
        <= labor_ss,
        name="Labor_SS"
    )

    # Poultry biosecurity gating

    bigM_chickens = max_chickens

    # If coop not open, no chickens
    model.addConstr(y_chicken <= bigM_chickens * coop_open, name="CoopOpen_Upper")

    # If coop open, flock must be at least min_chickens_if_coop_open
    model.addConstr(y_chicken >= min_chickens_if_coop_open * coop_open, name="CoopOpen_MinFlock")

    # Second biosecurity threshold gating
    # y_chicken cannot exceed threshold without second_bio
    model.addConstr(y_chicken <= second_biosecurity_threshold + bigM_chickens * second_bio, name="SecondBio_Upper1")
    # If second_bio=1, flock must be above threshold (commercially meaningful larger flock)
    model.addConstr(y_chicken >= second_biosecurity_threshold * second_bio, name="SecondBio_Lower")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        obj_val = 0.0

    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
