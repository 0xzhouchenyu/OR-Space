import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

    # General parameters
    product_units = params["product_units"]
    truck_pollution = params["truck_pollution"]
    van_pollution = params["van_pollution"]
    motorcycle_pollution = params["motorcycle_pollution"]
    ev_pollution = params["electric_vehicle_pollution"]
    max_total_pollution = params["max_total_pollution"]
    min_truck_trips_total = params["min_truck_trips"]

    truck_capacity = params["truck_capacity"]
    van_capacity = params["van_capacity"]
    moto_capacity = params["motorcycle_capacity"]
    ev_capacity = params["electric_vehicle_capacity"]

    sales_point_share = {
        "sp1": params["sales_point_share_sp1"],
        "sp2": params["sales_point_share_sp2"],
        "sp3": params["sales_point_share_sp3"],
    }

    min_truck_share = {
        "sp1": params["min_truck_share_sp1"],
        "sp2": params["min_truck_share_sp2"],
        "sp3": params["min_truck_share_sp3"],
    }

    M_truck = params["M_truck_sp_day"]
    M_ev = params["M_ev_sp_day"]
    M_van = params["M_van_sp_day"]
    M_moto = params["M_moto_sp_day"]

    # Sets
    sales_points = ["sp1", "sp2", "sp3"]
    days = [1, 2, 3]
    vehicles = ["truck", "ev", "van", "moto"]

    # Per sales point demand
    demand_sp = {sp: sales_point_share[sp] * product_units for sp in sales_points}

    # Capacities and pollution by vehicle
    cap = {"truck": truck_capacity, "ev": ev_capacity, "van": van_capacity, "moto": moto_capacity}
    pol = {"truck": truck_pollution, "ev": ev_pollution, "van": van_pollution, "moto": motorcycle_pollution}

    # Model
    m = gp.Model("Revised_Transportation")
    m.setParam('OutputFlag', 0)

    # Decision variables: integer trips per sales point, day, vehicle
    x = m.addVars(sales_points, days, vehicles, vtype=GRB.INTEGER, lb=0, name="trips")

    # Mode binaries per sales point-day
    y_truck_ev = m.addVars(sales_points, days, vtype=GRB.BINARY, name="mode_truck_ev")
    y_van_moto = m.addVars(sales_points, days, vtype=GRB.BINARY, name="mode_van_moto")

    # Objective: minimize total pollution
    m.setObjective(
        gp.quicksum(pol[v] * x[sp, d, v] for sp in sales_points for d in days for v in vehicles),
        GRB.MINIMIZE
    )

    # Constraint: per sales point total capacity meets its share of demand
    for sp in sales_points:
        m.addConstr(
            gp.quicksum(
                cap[v] * x[sp, d, v] for d in days for v in vehicles
            ) >= demand_sp[sp],
            name=f"demand_{sp}"
        )

    # Constraint: total pollution ceiling
    m.addConstr(
        gp.quicksum(pol[v] * x[sp, d, v] for sp in sales_points for d in days for v in vehicles)
        <= max_total_pollution,
        name="max_total_pollution"
    )

    # Global minimum truck trips
    m.addConstr(
        gp.quicksum(x[sp, d, "truck"] for sp in sales_points for d in days) >= min_truck_trips_total,
        name="min_truck_trips_total"
    )

    # Service discipline: on each sales point-day, choose exactly one family
    for sp in sales_points:
        for d in days:
            m.addConstr(y_truck_ev[sp, d] + y_van_moto[sp, d] == 1, name=f"mode_choice_{sp}_{d}")

            # Big-M linking for truck/EV family
            m.addConstr(x[sp, d, "truck"] <= M_truck * y_truck_ev[sp, d], name=f"truck_mode_{sp}_{d}")
            m.addConstr(x[sp, d, "ev"] <= M_ev * y_truck_ev[sp, d], name=f"ev_mode_{sp}_{d}")

            # Big-M linking for van/motorcycle family
            m.addConstr(x[sp, d, "van"] <= M_van * y_van_moto[sp, d], name=f"van_mode_{sp}_{d}")
            m.addConstr(x[sp, d, "moto"] <= M_moto * y_van_moto[sp, d], name=f"moto_mode_{sp}_{d}")

    # Sales-point minimum truck share of trips
    # Define total trips and truck trips per sales point
    total_trips_sp = {}
    truck_trips_sp = {}
    for sp in sales_points:
        total_trips_sp[sp] = m.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"total_trips_{sp}")
        truck_trips_sp[sp] = m.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"truck_trips_{sp}")

        # Link to x
        m.addConstr(
            total_trips_sp[sp] == gp.quicksum(x[sp, d, v] for d in days for v in vehicles),
            name=f"total_trips_def_{sp}"
        )
        m.addConstr(
            truck_trips_sp[sp] == gp.quicksum(x[sp, d, "truck"] for d in days),
            name=f"truck_trips_def_{sp}"
        )

        # Implement share constraint: truck_trips_sp[sp] >= min_truck_share[sp] * total_trips_sp[sp]
        m.addConstr(
            truck_trips_sp[sp] >= min_truck_share[sp] * total_trips_sp[sp],
            name=f"min_truck_share_{sp}"
        )

    # Optimize
    m.optimize()

    # Print final objective
    obj_val = m.objVal if m.status == GRB.OPTIMAL else float('nan')
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
