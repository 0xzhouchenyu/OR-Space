import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_restaurant_data(filepath):
    restaurants = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'standard_staff_hours': float(row['Standard_Staff_Hours'].strip()),
                'premium_staff_hours': float(row['Premium_Staff_Hours'].strip())
            })
    return restaurants


def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    return params


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')

    restaurants = load_restaurant_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    budget = params['investment_budget']
    premium_revenue_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']

    model = gp.Model("Restaurant_Investment_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {}  # 1 if restaurant acquired
    y = {}  # 1 if restaurant operated as Premium
    for r in restaurants:
        name = r['name']
        x[name] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}")
        y[name] = model.addVar(vtype=GRB.BINARY, name=f"y_{name}")

    model.update()

    # Objective: maximize total annual revenue
    obj = gp.LinExpr()
    for r in restaurants:
        name = r['name']
        base_rev = r['revenue']
        obj += base_rev * x[name] + (premium_revenue_uplift * base_rev) * y[name]
    model.setObjective(obj, GRB.MAXIMIZE)

    # Budget constraint: acquisition + premium upgrade costs within budget
    budget_expr = gp.LinExpr()
    for r in restaurants:
        name = r['name']
        budget_expr += r['cost'] * x[name] + premium_upgrade_cost * y[name]
    model.addConstr(budget_expr <= budget, name="Budget_Constraint")

    # Staff hours constraint: use Standard or Premium hours depending on operation mode
    staff_expr = gp.LinExpr()
    for r in restaurants:
        name = r['name']
        std_hours = r['standard_staff_hours']
        prem_hours = r['premium_staff_hours']
        # staff = std_hours*x + (prem_hours - std_hours)*y
        staff_expr += std_hours * x[name] + (prem_hours - std_hours) * y[name]
    model.addConstr(staff_expr <= staff_hours_cap, name="Staff_Hours_Cap")

    # Premium only if acquired: y_r <= x_r
    for r in restaurants:
        name = r['name']
        model.addConstr(y[name] <= x[name], name=f"Premium_only_if_acquired_{name}")

    # Restaurant D and A mutual exclusion: if D purchased, A cannot be purchased
    names = {r['name'] for r in restaurants}
    if 'Restaurant_D' in names and 'Restaurant_A' in names:
        model.addConstr(x['Restaurant_D'] + x['Restaurant_A'] <= 1, name="D_A_Exclusion_Constraint")

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
