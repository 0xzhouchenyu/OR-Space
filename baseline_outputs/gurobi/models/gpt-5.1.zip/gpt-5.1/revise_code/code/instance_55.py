import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_courses(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    courses = {}
    categories = set()
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            cats = [c.strip() for c in row['Category'].split(';')]
            courses[course] = cats
            for c in cats:
                categories.add(c)
    return courses, sorted(list(categories))

def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    prereq_params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if name == 'min_courses_required':
                params['min_courses_required'] = int(value)
            elif name.startswith('prerequisite_'):
                course_key = name[len('prerequisite_'):]
                prereq_params[course_key] = value
            elif name == 'mandatory_foundation_for_cs_counting':
                params['mandatory_foundation_for_cs_counting'] = value
            elif name == 'cs_category_name':
                params['cs_category_name'] = value
    return params, prereq_params

def match_prerequisite_course(prereq_key, course_list):
    key_lower = prereq_key.lower().replace('_', ' ')
    for course in course_list:
        if course.lower() == key_lower:
            return course
    return None

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    courses, all_categories = load_courses(data_dir)
    params, prereq_raw = load_parameters(data_dir)

    min_required = params['min_courses_required']
    foundation_course = params['mandatory_foundation_for_cs_counting']
    cs_category_name = params['cs_category_name']

    course_list = list(courses.keys())

    # Build prerequisite mapping: course -> list of prerequisites
    prerequisites = {}
    for prereq_key, prereq_value in prereq_raw.items():
        course_name = match_prerequisite_course(prereq_key, course_list)
        if course_name:
            if course_name not in prerequisites:
                prerequisites[course_name] = []
            prerequisites[course_name].append(prereq_value.strip())

    # Build model
    model = gp.Model("RevisedCourseSelection")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[c] = 1 if course c is taken
    x = model.addVars(course_list, vtype=GRB.BINARY, name="x")

    # y[c,k] = 1 if course c is counted toward category k
    y = {}
    for c in course_list:
        for k in courses[c]:
            y[(c, k)] = model.addVar(vtype=GRB.BINARY, name=f"y_{c.replace(' ','_')}_{k.replace(' ','_')}")

    # u[k] = 1 if category k has at least one counted course (for CS trigger)
    u = model.addVars(all_categories, vtype=GRB.BINARY, name="u")

    model.update()

    # Objective: minimize total number of courses taken
    model.setObjective(gp.quicksum(x[c] for c in course_list), GRB.MINIMIZE)

    # Category coverage constraints: distinct counted courses, no double counting to multiple categories
    for k in all_categories:
        courses_in_cat = [c for c in course_list if k in courses[c]]
        model.addConstr(gp.quicksum(y[(c, k)] for c in courses_in_cat) >= min_required,
                        name=f"Min_{k.replace(' ','_')}")
        # Link to u[k]
        model.addConstr(gp.quicksum(y[(c, k)] for c in courses_in_cat) >= u[k],
                        name=f"u_lb_{k.replace(' ','_')}")
        model.addConstr(gp.quicksum(y[(c, k)] for c in courses_in_cat) <= min_required * 10 * u[k],
                        name=f"u_ub_{k.replace(' ','_')}")

    # Each course can be counted toward at most one category
    for c in course_list:
        model.addConstr(gp.quicksum(y[(c, k)] for k in courses[c]) <= 1,
                        name=f"CountOnce_{c.replace(' ','_')}")

    # If a course is counted for a category, it must be taken
    for c in course_list:
        for k in courses[c]:
            model.addConstr(y[(c, k)] <= x[c], name=f"CountImpliesTaken_{c.replace(' ','_')}_{k.replace(' ','_')}")

    # Prerequisite constraints: if you take a course, you must take its prerequisites
    for course, prereqs in prerequisites.items():
        for prereq in prereqs:
            if prereq in course_list:
                model.addConstr(x[course] <= x[prereq],
                                name=f"Prereq_{course.replace(' ','_')}_needs_{prereq.replace(' ','_')}")

    # Programming foundation rule:
    # If any course is counted toward the CS category, the foundation course must be taken.
    if cs_category_name in all_categories and foundation_course in course_list:
        cs_courses = [c for c in course_list if cs_category_name in courses[c]]
        model.addConstr(
            gp.quicksum(y[(c, cs_category_name)] for c in cs_courses) <= len(cs_courses) * x[foundation_course],
            name="CS_foundation_requirement"
        )

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
