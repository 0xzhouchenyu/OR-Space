import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    table_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Load items and values
    items = []
    values = []
    with open(table_path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append(row["Item"].strip())
            values.append(float(row["Value"].strip()))
    n = len(items)
    total_value = sum(values)

    # Load parameters
    params = {}
    with open(params_path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val_str = row["Value"].strip()
            if val_str == "":
                continue
            try:
                val = float(val_str)
            except ValueError:
                val = val_str
            params[name] = val

    son1_min_share = float(params.get("son1_min_share", 0.0))
    high_value_threshold = float(params.get("high_value_threshold", 0.0))
    max_high_value_items_per_son = int(params.get("max_high_value_items_per_son", 0))
    deferred_diamonds_per_son = int(params.get("deferred_diamonds_per_son", 0))
    immediate_tax_weight = float(params.get("immediate_tax_weight", 1.0))
    total_tax_weight = float(params.get("total_tax_weight", 0.0))

    # Index sets
    diamond_idx = [i for i, it in enumerate(items) if "Diamond" in it]
    jr_idx = [i for i, it in enumerate(items) if "Jack Russell" in it]
    high_value_idx = [i for i, v in enumerate(values) if v > high_value_threshold]

    # Model
    m = gp.Model("Revised_Inheritance")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # Immediate ownership: 1 if son1, 0 if son2
    x = m.addVars(n, vtype=GRB.BINARY, name="x")
    # Deferred ownership: 1 if son1, 0 if son2
    y = m.addVars(n, vtype=GRB.BINARY, name="y")

    # Absolute difference variables
    diff_imm = m.addVar(lb=0.0, name="diff_immediate")
    diff_tot = m.addVar(lb=0.0, name="diff_total")

    # Expressions for values
    value_imm_son1 = gp.quicksum(values[i] * x[i] for i in range(n))
    value_imm_son2 = gp.quicksum(values[i] * (1 - x[i]) for i in range(n))

    value_tot_son1 = gp.quicksum(values[i] * (x[i] + y[i]) for i in range(n))
    value_tot_son2 = gp.quicksum(values[i] * (2 - x[i] - y[i]) for i in range(n))

    # Immediate fairness (absolute difference)
    m.addConstr(diff_imm >= value_imm_son1 - value_imm_son2)
    m.addConstr(diff_imm >= value_imm_son2 - value_imm_son1)

    # Total fairness (absolute difference)
    m.addConstr(diff_tot >= value_tot_son1 - value_tot_son2)
    m.addConstr(diff_tot >= value_tot_son2 - value_tot_son1)

    # Son1 minimum total share
    m.addConstr(value_tot_son1 >= son1_min_share * (value_tot_son1 + value_tot_son2))

    # Jack Russell dogs must not be separated (immediate and deferred)
    if len(jr_idx) == 2:
        i1, i2 = jr_idx
        m.addConstr(x[i1] == x[i2])
        m.addConstr(y[i1] == y[i2])

    # High value item concentration (immediate + deferred ownership per son)
    # Count of high-value items owned by son1: x + y > 0 => indicator
    # We approximate ownership as (x or y); linearization:
    # For each high value item i, define z1_i = 1 if son1 owns in any stage, else 0
    # Similarly z2_i for son2
    z1 = m.addVars(high_value_idx, vtype=GRB.BINARY, name="z1_high")
    z2 = m.addVars(high_value_idx, vtype=GRB.BINARY, name="z2_high")
    for i in high_value_idx:
        # son1 owns if x[i]==1 or y[i]==1
        m.addConstr(z1[i] >= x[i])
        m.addConstr(z1[i] >= y[i])
        m.addConstr(z1[i] <= x[i] + y[i])
        # son2 owns if (1-x[i])==1 or (1-y[i])==1
        # That is, if x[i]==0 or y[i]==0; but both sons may partially own over time
        # Interpret constraint as: high value items cannot be concentrated in total nominal ownership.
        # We approximate son2 ownership similarly as if (1-x[i]) or (1-y[i]) is 1:
        m.addConstr(z2[i] >= 1 - x[i])
        m.addConstr(z2[i] >= 1 - y[i])
        m.addConstr(z2[i] <= 2 - x[i] - y[i])

    m.addConstr(gp.quicksum(z1[i] for i in high_value_idx) <= max_high_value_items_per_son)
    m.addConstr(gp.quicksum(z2[i] for i in high_value_idx) <= max_high_value_items_per_son)

    # Deferred diamonds per son
    # Diamonds can be deferred; limit per son
    m.addConstr(gp.quicksum(y[i] for i in diamond_idx) <= deferred_diamonds_per_son)
    m.addConstr(gp.quicksum(1 - y[i] for i in diamond_idx) <= deferred_diamonds_per_son)

    # Objective: weighted sum of immediate and total imbalances
    m.setObjective(immediate_tax_weight * diff_imm + total_tax_weight * diff_tot, GRB.MINIMIZE)

    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
