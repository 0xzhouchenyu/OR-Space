import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_csv_data(filepath):
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")

    # Load warehouses and supply
    warehouses_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    warehouses = []
    supply = {}
    for row in warehouses_data:
        name = row['Warehouse']
        warehouses.append(name)
        supply[name] = int(row['Empty_Containers'])

    # Load ports and demand
    ports_data = load_csv_data(os.path.join(data_dir, 'table_2.csv'))
    ports = []
    demand = {}
    for row in ports_data:
        name = row['Port']
        ports.append(name)
        demand[name] = int(row['Container_Demand'])

    # Load distances
    distance_data = load_csv_data(os.path.join(data_dir, 'table_3.csv'))
    distance = {}
    for row in distance_data:
        wh = row['Warehouse']
        for p in ports:
            distance[(wh, p)] = float(row[p])

    # Load general parameters
    params_data = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    params = {}
    for row in params_data:
        params[row['Parameter_Name']] = float(row['Value'])

    cost_per_km = params['cost_per_km']
    truck_capacity = params['truck_capacity']
    adriatic_trigger = params['adriatic_pool_shortage_trigger']
    adriatic_recovery_fee = params['adriatic_pool_recovery_fee']

    # Load shortage penalty parameters
    shortage_data = load_csv_data(os.path.join(data_dir, 'shortage_penalty.csv'))
    shortage_charge = {}
    grace = {}
    recovery_fee = {}
    for row in shortage_data:
        port = row['Port']
        shortage_charge[port] = float(row['Shortage_Charge'])
        grace[port] = float(row['Grace_Containers'])
        recovery_fee[port] = float(row['Recovery_Fee'])

    # Define Adriatic ports
    adriatic_ports = ['Venice', 'Ancona', 'Bari']

    # Build model
    m = gp.Model("Revised_Container_Transportation")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # Containers shipped
    x = m.addVars(warehouses, ports, name="x", vtype=GRB.CONTINUOUS, lb=0.0)

    # Shortage at each port (continuous, >=0)
    s = m.addVars(ports, name="s", vtype=GRB.CONTINUOUS, lb=0.0)

    # Binary: whether local recovery desk is opened at port j
    y_local = m.addVars(ports, name="y_local", vtype=GRB.BINARY)

    # Binary: whether Adriatic regional recovery desk is opened
    y_adriatic = m.addVar(name="y_adriatic", vtype=GRB.BINARY)

    # Constraints

    # Supply constraints: total shipped out of warehouse <= supply
    for i in warehouses:
        m.addConstr(gp.quicksum(x[i, j] for j in ports) <= supply[i], name=f"supply_{i}")

    # Demand/shortage balance: shipped + shortage = demand
    for j in ports:
        m.addConstr(gp.quicksum(x[i, j] for i in warehouses) + s[j] == demand[j], name=f"demand_{j}")

    # Local recovery desk trigger: if shortage above grace band, desk may open.
    # Implement via big-M: s[j] - grace[j] <= M * y_local[j]
    # If y_local[j] = 0, then s[j] <= grace[j]. If s[j] > grace[j], must have y_local[j] = 1.
    bigM_local = max(demand.values())  # upper bound on possible shortage at a port
    for j in ports:
        m.addConstr(s[j] - grace[j] <= bigM_local * y_local[j], name=f"local_trigger_{j}")

    # Adriatic regional recovery trigger:
    # If combined shortage of Adriatic ports above adriatic_trigger, desk must open.
    # sum_{j in Adriatic} s[j] - trigger <= M * y_adriatic
    bigM_adriatic = sum(demand[j] for j in adriatic_ports)
    m.addConstr(
        gp.quicksum(s[j] for j in adriatic_ports) - adriatic_trigger <= bigM_adriatic * y_adriatic,
        name="adriatic_trigger"
    )

    # Objective: transport cost + per-container shortage charges + fixed recovery fees
    transport_cost = gp.quicksum(
        x[i, j] * distance[(i, j)] * cost_per_km for i in warehouses for j in ports
    )

    shortage_cost = gp.quicksum(shortage_charge[j] * s[j] for j in ports)

    local_recovery_cost = gp.quicksum(recovery_fee[j] * y_local[j] for j in ports)

    adriatic_recovery_cost = adriatic_recovery_fee * y_adriatic

    m.setObjective(transport_cost + shortage_cost + local_recovery_cost + adriatic_recovery_cost, GRB.MINIMIZE)

    # Optimize
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
