import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()

    max_children = int(params['max_children_trip'])
    min_children = int(params['min_children_trip'])
    max_distinct_children = int(params['max_distinct_children_trip'])
    total_cost_budget = float(params['total_cost_budget'])
    bonus_saving = float(params['bonus_saving'])
    min_bob_days = int(params['min_bob_days'])

    # Read table_1 for children and costs
    children = []
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Child'].strip()
            cost = float(row['Cost'].strip())
            children.append(name)
            costs[name] = cost

    # Two days
    days = [1, 2]

    # Create model
    model = gp.Model("FamilyTripTwoDays")
    model.setParam('OutputFlag', 0)

    # Decision variables:
    # x[c, d] = 1 if child c goes on day d
    x = {}
    for c in children:
        for d in days:
            x[c, d] = model.addVar(vtype=GRB.BINARY, name=f"x_{c}_day{d}")

    # y[c] = 1 if child c attends both days
    y = {}
    for c in children:
        y[c] = model.addVar(vtype=GRB.BINARY, name=f"y_{c}_both")

    # z[c] = 1 if child c attends at least one day (distinct children)
    z = {}
    for c in children:
        z[c] = model.addVar(vtype=GRB.BINARY, name=f"z_{c}_any")

    model.update()

    # Objective: minimize total two-day cost minus total bonus_saving for children attending both days
    total_cost = gp.quicksum(costs[c] * x[c, d] for c in children for d in days)
    total_bonus = gp.quicksum(bonus_saving * y[c] for c in children)
    model.setObjective(total_cost - total_bonus, GRB.MINIMIZE)

    # Daily min/max headcount
    for d in days:
        model.addConstr(
            gp.quicksum(x[c, d] for c in children) >= min_children,
            name=f"MinChildren_day{d}"
        )
        model.addConstr(
            gp.quicksum(x[c, d] for c in children) <= max_children,
            name=f"MaxChildren_day{d}"
        )

    # Distinct children over both days
    for c in children:
        for d in days:
            model.addConstr(x[c, d] <= z[c], name=f"Distinct_link_{c}_day{d}")
    model.addConstr(
        gp.quicksum(z[c] for c in children) <= max_distinct_children,
        name="MaxDistinctChildren"
    )

    # Bob minimum days
    model.addConstr(
        gp.quicksum(x['Bob', d] for d in days) >= min_bob_days,
        name="MinBobDays"
    )

    # Daily relationship constraints
    for d in days:
        # Alice and Diana cannot both be taken
        model.addConstr(
            x['Alice', d] + x['Diana', d] <= 1,
            name=f"AliceDianaConflict_day{d}"
        )
        # Bob and Charlie cannot both be taken
        model.addConstr(
            x['Bob', d] + x['Charlie', d] <= 1,
            name=f"BobCharlieConflict_day{d}"
        )
        # Charlie must be accompanied by Diana (same day)
        model.addConstr(
            x['Charlie', d] <= x['Diana', d],
            name=f"CharlieRequiresDiana_day{d}"
        )
        # Diana must be accompanied by Ella (same day)
        model.addConstr(
            x['Diana', d] <= x['Ella', d],
            name=f"DianaRequiresElla_day{d}"
        )

    # Availability constraints:
    # Charlie only day 2
    model.addConstr(x['Charlie', 1] == 0, name="CharlieOnlyDay2")
    # Diana only day 2
    model.addConstr(x['Diana', 1] == 0, name="DianaOnlyDay2")
    # Alice only day 1
    model.addConstr(x['Alice', 2] == 0, name="AliceOnlyDay1")

    # Link y[c] with attendance on both days
    for c in children:
        # y[c] <= x[c,1], y[c] <= x[c,2]
        model.addConstr(y[c] <= x[c, 1], name=f"y_leq_x1_{c}")
        model.addConstr(y[c] <= x[c, 2], name=f"y_leq_x2_{c}")
        # y[c] >= x[c,1] + x[c,2] - 1  (if both days then y=1)
        model.addConstr(
            y[c] >= x[c, 1] + x[c, 2] - 1,
            name=f"y_geq_both_{c}"
        )

    # Cost budget constraint on net cost (objective expression)
    # total_cost - total_bonus <= total_cost_budget
    model.addConstr(
        total_cost - total_bonus <= total_cost_budget,
        name="TotalCostBudget"
    )

    # Optimize
    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
