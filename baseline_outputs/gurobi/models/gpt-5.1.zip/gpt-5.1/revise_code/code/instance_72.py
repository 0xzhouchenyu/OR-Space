import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read property data
properties = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_risky_multiplier = params['scen_1_risky_multiplier']
scen_2_risky_multiplier = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = int(params['max_risky_properties'])

# Create model
model = gp.Model("RealEstateInvestmentRevised")
model.setParam('OutputFlag', 0)

# Sets and indices
prop_names = [p['name'] for p in properties]
prop_index = {p['name']: i for i, p in enumerate(properties)}

# Decision variables
# x_p: 1 if property p is purchased
x = model.addVars(prop_names, vtype=GRB.BINARY, name="x")
# r_p: fraction of property p allocated to risky tenants
r = model.addVars(prop_names, vtype=GRB.CONTINUOUS, lb=0.0, ub=1.0, name="r")
# b_p: 1 if property p hosts any risky tenants (gate variable)
b = model.addVars(prop_names, vtype=GRB.BINARY, name="b")

# Objective: maximize expected annual income
# For each property, total fraction = 1 (long-term + risky),
# Long-term income = base income * (1 - r_p)
# Risky income = base income * r_p * E[multiplier]
exp_multiplier = scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier

obj_expr = gp.LinExpr()
for p in properties:
    name = p['name']
    base_income = p['income']
    # expected income for property p
    obj_expr += base_income * ((1 - r[name]) + r[name] * exp_multiplier) * x[name]

model.setObjective(obj_expr, GRB.MAXIMIZE)

# Constraints

# Budget constraint
model.addConstr(
    gp.quicksum(p['cost'] * x[p['name']] for p in properties) <= budget,
    name="budget_constraint"
)

# Property 4 excludes Property 3
if 'Property_4' in prop_index and 'Property_3' in prop_index:
    model.addConstr(x['Property_4'] + x['Property_3'] <= 1, name="mutual_exclusion_3_4")

# Risky allocation only on purchased properties and capped per property
M = 1.0  # r is in [0,1], so 1 is sufficient as big-M

for p in properties:
    name = p['name']
    # r_p <= per_property_risky_cap
    model.addConstr(r[name] <= per_property_risky_cap, name=f"per_prop_cap_{name}")
    # r_p <= x_p (no risky on non-purchased)
    model.addConstr(r[name] <= x[name], name=f"r_only_if_bought_{name}")
    # Link r_p and b_p (gate: b_p = 1 if r_p > 0)
    model.addConstr(r[name] <= M * b[name], name=f"r_to_b_upper_{name}")
    # If b_p = 1 then property must be purchased: b_p <= x_p
    model.addConstr(b[name] <= x[name], name=f"b_only_if_bought_{name}")

# Total risky exposure budget: sum cost_p * r_p <= total_risky_budget
model.addConstr(
    gp.quicksum(p['cost'] * r[p['name']] for p in properties) <= total_risky_budget,
    name="total_risky_budget_constraint"
)

# Max number of properties that host any risky tenants
model.addConstr(
    gp.quicksum(b[p['name']] for p in properties) <= max_risky_properties,
    name="max_risky_properties_constraint"
)

# Optimize
model.optimize()

# Print final objective
obj_val = model.ObjVal if model.status == GRB.OPTIMAL else float('nan')
print(f"FINAL_OBJ_VALUE: {obj_val}")
