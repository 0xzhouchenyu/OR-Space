import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load parameters
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(data_path)
    params = {row['Parameter_Name']: row['Value'] for _, row in df.iterrows()}

    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = float(params['raw_bar_length'])
    setup_cost_per_pattern = float(params['setup_cost_per_pattern'])
    max_distinct_patterns = int(params['max_distinct_patterns'])

    len1 = 3
    len2 = 4
    len3 = 5

    # Generate all valid cutting patterns (x,y,z) for 3m,4m,5m pieces
    patterns = []
    for x in range(int(L // len1) + 1):
        for y in range(int(L // len2) + 1):
            for z in range(int(L // len3) + 1):
                total_len = len1 * x + len2 * y + len3 * z
                if total_len <= L and (x > 0 or y > 0 or z > 0):
                    patterns.append((x, y, z))

    n_patterns = len(patterns)

    # Build optimization model
    model = gp.Model("CuttingStockRevised")
    model.setParam('OutputFlag', 0)

    # Decision variables:
    # x_p: number of raw bars cut with pattern p
    x = model.addVars(n_patterns, vtype=GRB.INTEGER, name="x", lb=0)

    # y_p: binary variable = 1 if pattern p is used at least once
    y = model.addVars(n_patterns, vtype=GRB.BINARY, name="y")

    # Link x and y: if x_p > 0 then y_p = 1 (Big-M linking)
    # Upper bound on x_p: can't exceed total demand of pieces as a trivial big-M
    total_demand = q3 + q4 + q5
    M = total_demand if total_demand > 0 else 0
    if M == 0:
        M = 1  # avoid zero big-M, though in this problem demands are positive

    for p in range(n_patterns):
        model.addConstr(x[p] <= M * y[p])

    # Demand constraints (allow overproduction, counted as waste)
    model.addConstr(gp.quicksum(patterns[p][0] * x[p] for p in range(n_patterns)) >= q3, name="Demand_3m")
    model.addConstr(gp.quicksum(patterns[p][1] * x[p] for p in range(n_patterns)) >= q4, name="Demand_4m")
    model.addConstr(gp.quicksum(patterns[p][2] * x[p] for p in range(n_patterns)) >= q5, name="Demand_5m")

    # Limit on distinct patterns
    model.addConstr(gp.quicksum(y[p] for p in range(n_patterns)) <= max_distinct_patterns, name="MaxPatterns")

    # Objective:
    # Total waste = (Total raw length used) - (Total required length) + setup waste
    # Total raw length used = L * sum_p x_p
    # Total required length = 3*q3 + 4*q4 + 5*q5 (constant)
    # Setup waste = setup_cost_per_pattern * sum_p y_p
    # Minimize: L * sum_p x_p + setup_cost_per_pattern * sum_p y_p - const
    # Constant can be dropped; keep full expression for clarity.
    total_required_length = len1 * q3 + len2 * q4 + len3 * q5

    objective = (
        L * gp.quicksum(x[p] for p in range(n_patterns))
        + setup_cost_per_pattern * gp.quicksum(y[p] for p in range(n_patterns))
        - total_required_length
    )

    model.setObjective(objective, GRB.MINIMIZE)

    model.optimize()

    obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
