import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Determine data directory (script run from workspace root)
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Read time periods and minimum waiters needed
    time_periods = []
    min_waiters = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            time_periods.append(row['Time'].strip())
            min_waiters.append(int(row['Minimum_Number_of_Waiters_Needed'].strip()))

    n = len(time_periods)

    # Read general parameters
    waiter_work_hours = None
    peak = [0]*n
    quality = [0]*n
    waiter_cost_per_shift = None
    waiter_budget = None

    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()

            if name == 'waiter_work_hours':
                waiter_work_hours = int(value)
            elif name.startswith('peak_'):
                idx = int(name.split('_')[1])
                peak[idx] = int(value)
            elif name.startswith('quality_'):
                idx = int(name.split('_')[1])
                quality[idx] = float(value)
            elif name == 'waiter_cost_per_shift':
                waiter_cost_per_shift = float(value)
            elif name == 'waiter_budget':
                waiter_budget = float(value)

    # Sanity: each waiter works 8h -> 2 consecutive 4h periods
    period_length_hours = 4
    assert waiter_work_hours == 2 * period_length_hours

    # Build model
    m = gp.Model("Restaurant_Waiters_Revised")
    m.setParam('OutputFlag', 0)

    # Decision variables:
    # x_i = number of waiters starting at period i (working in i and (i+1)%n)
    x = m.addVars(n, vtype=GRB.INTEGER, lb=0, name="x")

    # Auxiliary variables for waiters working in each period j
    # w_j = total waiters working during period j
    w = m.addVars(n, vtype=GRB.CONTINUOUS, lb=0, name="w")

    # Link w_j to x: waiters in period j come from starts at j and (j-1)%n
    for j in range(n):
        prev = (j - 1) % n
        m.addConstr(w[j] == x[prev] + x[j], name=f"WorkBalance_{j}")

    # Coverage constraints: w_j >= min_waiters[j]
    for j in range(n):
        m.addConstr(w[j] >= min_waiters[j], name=f"Coverage_{j}")

    # Budget constraint: total cost of shifts within waiter_budget
    total_cost = waiter_cost_per_shift * gp.quicksum(x[i] for i in range(n))
    m.addConstr(total_cost <= waiter_budget, name="Budget")

    # Peak/off-peak tour rule:
    # Each 8h tour (two consecutive periods) must include exactly one peak and one off-peak window.
    # For a waiter starting at i, periods are i and (i+1)%n.
    for i in range(n):
        j = (i + 1) % n
        # Enforce: peak[i] != peak[j]
        # If peaks are identical, no waiter can start at i.
        if peak[i] == peak[j]:
            m.addConstr(x[i] == 0, name=f"InvalidTour_{i}")

    # Objective: maximize service_quality_score
    # service_quality_score = sum_j quality_j * w_j
    service_quality_score = gp.quicksum(quality[j] * w[j] for j in range(n))
    m.setObjective(service_quality_score, GRB.MAXIMIZE)

    # Optimize
    m.optimize()

    # Print final objective value
    obj_val = m.objVal if m.status == GRB.OPTIMAL or m.status == GRB.SUBOPTIMAL else 0.0
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
