import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def main():
    # Load data
    demand_df = pd.read_csv(get_data_path('table_4_3.csv'))
    supply_df = pd.read_csv(get_data_path('table_4_4.csv'))
    params_df = pd.read_csv(get_data_path('general_parameters.csv'))

    # Parameters
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])

    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem

    # Parse supply
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = float(row['Number_of_People'])
        suit = [int(x) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }

    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]

    # Build model
    model = gp.Model("RevisedStaffing")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[i,j,k] = number of type i assigned to city j, specialty k
    x = model.addVars(
        types, cities, specs,
        name="x",
        lb=0,
        vtype=GRB.INTEGER
    )

    # Constraints

    # Supply limits
    for i in types:
        model.addConstr(
            gp.quicksum(x[i, j, k] for j in cities for k in specs) <= supply[i]['num'],
            name=f"supply_{i}"
        )

    # Demand satisfaction (Priority 1 as hard constraint)
    for j in cities:
        for k in specs:
            model.addConstr(
                gp.quicksum(x[i, j, k] for i in types) >= demand[(j, k)],
                name=f"demand_{j}_{k}"
            )

    # Suitability constraints
    for i in types:
        for j in cities:
            for k in specs:
                if k not in supply[i]['suit']:
                    model.addConstr(x[i, j, k] == 0, name=f"unsuitable_{i}_{j}_{k}")

    # Priority 2: minimum number of personnel in their preferred specialty
    pref_spec_expr = gp.quicksum(
        x[i, j, supply[i]['pref_spec']] for i in types for j in cities
    )
    model.addConstr(
        pref_spec_expr >= p2_target,
        name="priority2_min_pref_spec"
    )

    # Objective (revised): maximize number who match both preferred specialty and preferred city
    dual_match_expr = gp.quicksum(
        x[i, supply[i]['pref_city'], supply[i]['pref_spec']] for i in types
    )

    model.setObjective(dual_match_expr, GRB.MAXIMIZE)

    # Optimize
    model.optimize()

    obj_val = model.objVal
    if abs(obj_val - round(obj_val)) <= 1e-6:
        obj_val = int(round(obj_val))

    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
