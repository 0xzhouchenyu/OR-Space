import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params


def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

    # Extract parameters
    a_p1 = params['product_a_process_1_time']
    a_p2 = params['product_a_process_2_time']
    b_p1 = params['product_b_process_1_time']
    b_p2 = params['product_b_process_2_time']

    T1_normal = params['available_time_process_1']
    T2_normal = params['available_time_process_2']
    T1_high = params['available_time_process_1_high']
    T2_high = params['available_time_process_2_high']

    c_per_b = params['byproduct_c_per_unit_b']
    max_c_sales = params['max_byproduct_c_sales']

    threshold_c = params['threshold_c']
    bigM_disposal = params['bigM_disposal']

    disposal_cost = params['disposal_cost_per_unit_c']
    disposal_cost_high = params['disposal_cost_per_unit_c_high']

    profit_a = params['profit_per_unit_a']
    profit_b = params['profit_per_unit_b']
    profit_c = params['profit_per_unit_c']

    # Create model
    model = gp.Model("RevisedMaxProfit")
    model.setParam('OutputFlag', 0)

    # Decision variables
    xA = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xA")
    xB = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="xB")

    cSold = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="cSold")
    cDisposed = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="cDisposed")

    # High-throughput mode binary variables for processes
    y1 = model.addVar(vtype=GRB.BINARY, name="y1_high")  # process 1 high-throughput?
    y2 = model.addVar(vtype=GRB.BINARY, name="y2_high")  # process 2 high-throughput?

    # Disposal cost threshold linearization
    z = model.addVar(vtype=GRB.BINARY, name="z_threshold")  # 1 if disposal beyond threshold occurs
    d_base = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="d_base")
    d_extra = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="d_extra")

    # Constraints

    # Process time capacity with high-throughput options
    # Effective capacity = T_normal if y=0, T_high if y=1
    # Implement as: a_p1*xA + b_p1*xB <= T1_normal + (T1_high - T1_normal)*y1
    model.addConstr(
        a_p1 * xA + b_p1 * xB <= T1_normal + (T1_high - T1_normal) * y1,
        name="Process1Time"
    )

    model.addConstr(
        a_p2 * xA + b_p2 * xB <= T2_normal + (T2_high - T2_normal) * y2,
        name="Process2Time"
    )

    # At most one reaction stage may use high-throughput
    model.addConstr(y1 + y2 <= 1, name="AtMostOneHighThroughput")

    # By-product C balance
    model.addConstr(cSold + cDisposed == c_per_b * xB, name="ByproductBalance")

    # Max C that can be sold
    model.addConstr(cSold <= max_c_sales, name="MaxCSales")

    # Disposal threshold modeling:
    # cDisposed = d_base + d_extra
    model.addConstr(cDisposed == d_base + d_extra, name="DisposalSplit")

    # d_base <= threshold_c
    model.addConstr(d_base <= threshold_c, name="BaseCap")

    # d_base <= cDisposed
    model.addConstr(d_base <= cDisposed, name="BaseLeqTotal")

    # d_extra <= cDisposed - threshold_c + bigM_disposal*(1 - z)
    model.addConstr(
        d_extra <= cDisposed - threshold_c + bigM_disposal * (1 - z),
        name="ExtraUpper1"
    )

    # d_extra <= bigM_disposal * z
    model.addConstr(d_extra <= bigM_disposal * z, name="ExtraUpper2")

    # Threshold gate interpretation:
    # If z = 0 -> d_extra forced to 0; disposal only in base band.
    # If z = 1 -> allows d_extra > 0 (beyond threshold).

    # Objective: maximize total profit
    # Profit from A + Profit from B + Profit from selling C
    # minus disposal costs:
    # base disposal cost for d_base, higher disposal cost for d_extra
    disposal_cost_expr = disposal_cost * d_base + disposal_cost_high * d_extra

    obj = (
        profit_a * xA
        + profit_b * xB
        + profit_c * cSold
        - disposal_cost_expr
    )

    model.setObjective(obj, GRB.MAXIMIZE)

    # Optimize
    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
