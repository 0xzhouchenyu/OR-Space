import os
import csv
import gurobipy as gp
from gurobipy import GRB

# ---------- Data loading helpers ----------

def load_csv(filepath):
    rows = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)
    return rows

base_dir = os.path.dirname(os.path.abspath(__file__))

# Load parameters
param_rows = load_csv(os.path.join(base_dir, "data", "general_parameters.csv"))
params = {}
for row in param_rows:
    name = row['Parameter_Name'].strip()
    val = row['Value'].strip()
    try:
        if '.' in val:
            params[name] = float(val)
        else:
            params[name] = int(val)
    except ValueError:
        params[name] = val

# Load demand
demand_rows = load_csv(os.path.join(base_dir, "data", "table_1.csv"))
demand_I = {}
demand_II = {}
for row in demand_rows:
    t = int(row['Week'].strip())
    demand_I[t] = float(row['I'].strip())
    demand_II[t] = float(row['II'].strip())

# ---------- Parameters ----------

T = 8
weeks = range(1, T + 1)

S0 = params['skilled_worker_count']
rate_I = params['food_I_production_rate']
rate_II = params['food_II_production_rate']
normal_hours = params['worker_weekly_hours']
overtime_hours = params['skilled_worker_overtime_hours']
train_cap = params['training_capacity']
train_period = params['training_period']  # 2
wage_skilled = params['skilled_worker_weekly_wage']
wage_trainee_during = params['trainee_weekly_wage_during_training']
wage_trainee_after = params['trainee_weekly_wage_after_training']
wage_overtime = params['skilled_worker_overtime_wage']
comp_I = params['compensation_fee_food_I']
comp_II = params['compensation_fee_food_II']
new_worker_goal = params['new_worker_training_goal']

# ---------- Model ----------

m = gp.Model("factory_training_revised")
m.setParam('OutputFlag', 0)

# ---------- Decision variables ----------

# Number of skilled workers who start training in week t
n_train = {}
for t in weeks:
    if t <= T - 1:  # can start training up to week 7
        n_train[t] = m.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_train_{t}")

# Overtime skilled workers in week t
n_overtime = {t: m.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_ot_{t}") for t in weeks}

# Production hours (continuous) for each product and worker type
h_I_s = {t: m.addVar(lb=0.0, name=f"hIs_{t}") for t in weeks}
h_II_s = {t: m.addVar(lb=0.0, name=f"hIIs_{t}") for t in weeks}
h_I_ot = {t: m.addVar(lb=0.0, name=f"hIot_{t}") for t in weeks}
h_II_ot = {t: m.addVar(lb=0.0, name=f"hIIot_{t}") for t in weeks}
h_I_g = {t: m.addVar(lb=0.0, name=f"hIg_{t}") for t in weeks}
h_II_g = {t: m.addVar(lb=0.0, name=f"hIIg_{t}") for t in weeks}

# Backlogs
backlog_I = {t: m.addVar(lb=0.0, name=f"bI_{t}") for t in weeks}
backlog_II = {t: m.addVar(lb=0.0, name=f"bII_{t}") for t in weeks}

# Binary variables for weekly product-family commitment
y_I = {t: m.addVar(vtype=GRB.BINARY, name=f"yI_{t}") for t in weeks}
y_II = {t: m.addVar(vtype=GRB.BINARY, name=f"yII_{t}") for t in weeks}
y_idle = {t: m.addVar(vtype=GRB.BINARY, name=f"yIdle_{t}") for t in weeks}

# ---------- Helper expressions ----------

def trainers_busy_expr(t):
    expr = gp.LinExpr()
    for s, var in n_train.items():
        if s <= t <= s + train_period - 1:
            expr += var
    return expr

def graduates_available_expr(t):
    expr = gp.LinExpr()
    for s, var in n_train.items():
        if s + train_period <= t:  # available from week s+2
            expr += train_cap * var
    return expr

# ---------- Constraints ----------

for t in weeks:
    # Weekly mode: exactly one of I, II, or idle
    m.addConstr(y_I[t] + y_II[t] + y_idle[t] == 1, name=f"one_mode_{t}")

    busy_t = trainers_busy_expr(t)
    grads_t = graduates_available_expr(t)

    # Available skilled workers for production (can be normal or overtime)
    # Availability must be nonnegative
    m.addConstr(S0 - busy_t >= 0, name=f"avail_nonneg_{t}")

    # Overtime workers cannot exceed available skilled workers
    m.addConstr(n_overtime[t] <= S0 - busy_t, name=f"ot_limit_{t}")

    # Normal skilled hours (non-overtime) <= (avail - overtime)*normal_hours
    m.addConstr(
        h_I_s[t] + h_II_s[t] <= (S0 - busy_t - n_overtime[t]) * normal_hours,
        name=f"skilled_normal_hours_{t}"
    )

    # Overtime hours <= n_overtime * overtime_hours
    m.addConstr(
        h_I_ot[t] + h_II_ot[t] <= n_overtime[t] * overtime_hours,
        name=f"skilled_ot_hours_{t}"
    )

    # Graduated trainees hours
    m.addConstr(
        h_I_g[t] + h_II_g[t] <= grads_t * normal_hours,
        name=f"grad_hours_{t}"
    )

    # Mutual exclusion of production by product family
    # If week committed to Food I: only Food I hours may be positive
    bigM_hours = (S0 + new_worker_goal) * overtime_hours
    m.addConstr(h_II_s[t] <= bigM_hours * (1 - y_I[t]), name=f"no_II_if_I_s_{t}")
    m.addConstr(h_II_ot[t] <= bigM_hours * (1 - y_I[t]), name=f"no_II_if_I_ot_{t}")
    m.addConstr(h_II_g[t] <= bigM_hours * (1 - y_I[t]), name=f"no_II_if_I_g_{t}")

    # If week committed to Food II: only Food II hours may be positive
    m.addConstr(h_I_s[t] <= bigM_hours * (1 - y_II[t]), name=f"no_I_if_II_s_{t}")
    m.addConstr(h_I_ot[t] <= bigM_hours * (1 - y_II[t]), name=f"no_I_if_II_ot_{t}")
    m.addConstr(h_I_g[t] <= bigM_hours * (1 - y_II[t]), name=f"no_I_if_II_g_{t}")

    # If week is idle: no production at all
    m.addConstr(h_I_s[t] + h_II_s[t] + h_I_ot[t] + h_II_ot[t] + h_I_g[t] + h_II_g[t]
                <= bigM_hours * (1 - y_idle[t]),
                name=f"no_prod_if_idle_{t}")

    # Production in week t
    prod_I_t = (h_I_s[t] + h_I_ot[t] + h_I_g[t]) * rate_I
    prod_II_t = (h_II_s[t] + h_II_ot[t] + h_II_g[t]) * rate_II

    # Backlog dynamics
    if t == 1:
        prev_bI = 0.0
        prev_bII = 0.0
    else:
        prev_bI = backlog_I[t - 1]
        prev_bII = backlog_II[t - 1]

    m.addConstr(
        backlog_I[t] >= prev_bI + demand_I[t] - prod_I_t,
        name=f"backlog_I_{t}"
    )
    m.addConstr(
        backlog_II[t] >= prev_bII + demand_II[t] - prod_II_t,
        name=f"backlog_II_{t}"
    )

# Training target: at least new_worker_goal graduates by end of week 8
total_graduates = gp.LinExpr()
for s, var in n_train.items():
    # Any start in week 1..7 finishes by week 8
    total_graduates += train_cap * var
m.addConstr(total_graduates >= new_worker_goal, name="training_goal")

# ---------- Objective ----------

obj = gp.LinExpr()

# Skilled workers: all S0 paid wage_skilled in every week (working or training)
for t in weeks:
    obj += S0 * wage_skilled

# Overtime wage: overtime workers receive wage_overtime instead of normal wage,
# but we already accounted for wage_skilled above, so add the incremental part.
incremental_ot = wage_overtime - wage_skilled
for t in weeks:
    obj += n_overtime[t] * incremental_ot

# Trainee wages during training: each trainee is paid during training weeks
for t in weeks:
    # trainees starting at t and t-1 are in training in week t
    expr_tr = gp.LinExpr()
    s1 = t
    s2 = t - 1
    if s1 in n_train:
        expr_tr += n_train[s1]
    if s2 in n_train:
        expr_tr += n_train[s2]
    obj += expr_tr * wage_trainee_during

# Graduated trainees wages after training (within horizon)
# A trainee starting in week s is in training weeks s and s+1,
# and works from week s+2 onward if within 1..T.
for t in weeks:
    grads_t = graduates_available_expr(t)
    obj += grads_t * wage_trainee_after

# Compensation costs for backlogs
for t in weeks:
    obj += comp_I * backlog_I[t]
    obj += comp_II * backlog_II[t]

m.setObjective(obj, GRB.MINIMIZE)

# ---------- Solve ----------

m.optimize()

# ---------- Output ----------

print(f"FINAL_OBJ_VALUE: {m.objVal}")
