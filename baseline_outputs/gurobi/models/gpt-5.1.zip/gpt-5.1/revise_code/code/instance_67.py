import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filepath):
    rows = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)
    return rows

def load_parameters(base_dir):
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    rows = load_csv(filepath)
    params = {}
    for row in rows:
        name = row["Parameter_Name"]
        value = float(row["Value"])
        params[name] = value
    return params

def load_demand(base_dir):
    filepath = os.path.join(base_dir, "data", "table_1.csv")
    rows = load_csv(filepath)
    demand = {}
    for row in rows:
        month = row["Month"]
        product = row["Product"]
        units = int(row["Market_Demand_Units"])
        demand[(month, product)] = units
    return demand

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Load data
    params = load_parameters(base_dir)
    demand_data = load_demand(base_dir)

    # Sets
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']

    # Production costs (June-Dec)
    prod_cost = {
        'Product_I': params['product_I_cost_jun_to_dec'],
        'Product_II': params['product_II_cost_jun_to_dec']
    }

    # Volumes
    volume = {
        'Product_I': params['product_I_volume'],
        'Product_II': params['product_II_volume']
    }

    # Warehouse
    warehouse_cap = params['warehouse_capacity']
    own_wh_cost = params['own_warehouse_cost']

    # Machine hours
    mach_hours_per_unit = {
        'Product_I': params['product_I_machine_hours'],
        'Product_II': params['product_II_machine_hours']
    }
    mach_hours_capacity = params['machine_hours_capacity_monthly']

    # Power requirements
    power_per_unit = {
        'Product_I': params['product_I_power_kwh'],
        'Product_II': params['product_II_power_kwh']
    }

    grid_cost = params['grid_electricity_cost']
    gen_cost = params['generator_electricity_cost']

    grid_quota = {
        'July': params['grid_quota_july'],
        'August': params['grid_quota_august'],
        'September': params['grid_quota_september'],
        'October': params['grid_quota_october'],
        'November': params['grid_quota_november'],
        'December': params['grid_quota_december']
    }

    gen_max = {
        'July': params['generator_max_july'],
        'August': params['generator_max_august'],
        'September': params['generator_max_september'],
        'October': params['generator_max_october'],
        'November': params['generator_max_november'],
        'December': params['generator_max_december']
    }

    # Demand subset for planning months
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]

    # Initial inventory per product at start of July
    init_inv = {
        p: params['initial_inventory_july'] for p in products
    }

    # Model
    model = gp.Model("Revised_Production_Planning")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # Production quantities
    x = model.addVars(
        months, products,
        name="prod",
        lb=0,
        vtype=GRB.CONTINUOUS
    )

    # Inventory at end of month (units)
    inv = model.addVars(
        months, products,
        name="inv",
        lb=0,
        vtype=GRB.CONTINUOUS
    )

    # Warehouse usage (cubic meters) - only own warehouse is allowed now
    own_wh = model.addVars(
        months,
        name="own_wh",
        lb=0,
        vtype=GRB.CONTINUOUS
    )

    # Electricity usage: grid and generator (kWh)
    grid_use = model.addVars(
        months,
        name="grid_use",
        lb=0,
        vtype=GRB.CONTINUOUS
    )
    gen_use = model.addVars(
        months,
        name="gen_use",
        lb=0,
        vtype=GRB.CONTINUOUS
    )

    # Objective: production cost + inventory holding cost + electricity costs
    model.setObjective(
        gp.quicksum(prod_cost[p] * x[m, p] for m in months for p in products) +
        gp.quicksum(own_wh_cost * own_wh[m] for m in months) +
        gp.quicksum(grid_cost * grid_use[m] + gen_cost * gen_use[m] for m in months),
        GRB.MINIMIZE
    )

    # Constraints
    for idx, m in enumerate(months):
        # Inventory balance per product
        for p in products:
            if idx == 0:
                prev_inv = init_inv[p]
            else:
                prev_m = months[idx - 1]
                prev_inv = inv[prev_m, p]

            model.addConstr(
                inv[m, p] == prev_inv + x[m, p] - demand[(m, p)],
                name=f"inv_bal_{m}_{p}"
            )

        # Warehouse capacity: volume of inventory <= own warehouse capacity
        model.addConstr(
            own_wh[m] == gp.quicksum(volume[p] * inv[m, p] for p in products),
            name=f"wh_vol_def_{m}"
        )
        model.addConstr(
            own_wh[m] <= warehouse_cap,
            name=f"wh_cap_{m}"
        )

        # Machine hours capacity
        model.addConstr(
            gp.quicksum(mach_hours_per_unit[p] * x[m, p] for p in products) <= mach_hours_capacity,
            name=f"mach_cap_{m}"
        )

        # Electricity balance: production power demand must be met by grid + generator
        total_power = gp.quicksum(power_per_unit[p] * x[m, p] for p in products)
        model.addConstr(
            grid_use[m] + gen_use[m] == total_power,
            name=f"power_bal_{m}"
        )

        # Grid quota
        model.addConstr(
            grid_use[m] <= grid_quota[m],
            name=f"grid_quota_{m}"
        )

        # Generator maximum
        model.addConstr(
            gen_use[m] <= gen_max[m],
            name=f"gen_max_{m}"
        )

    # Solve
    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
