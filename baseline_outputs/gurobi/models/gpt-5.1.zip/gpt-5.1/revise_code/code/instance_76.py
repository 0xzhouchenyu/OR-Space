import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}

    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())

    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()

    max_storage = float(params['max_storage_capacity'])  # m3
    storage_cost_a = float(params['storage_cost_a'])      # yuan/m3
    storage_cost_b = float(params['storage_cost_b'])      # yuan/m3/quarter

    safety_inventory_level = float(params['safety_inventory_level_10k_m3'])  # 10k m3
    terminal_inventory_value = float(params['terminal_inventory_value_per_10k_m3'])  # 10k yuan per 10k m3
    over_purchase_penalty = float(params['over_purchase_penalty_cost_per_10k_m3'])   # 10k yuan per 10k m3

    # Convert units
    # max_storage is in m3 -> convert to 10k m3
    max_storage_10k_m3 = max_storage / 10000.0

    # storage_cost_*: yuan/m3 -> 10k yuan per 10k m3
    storage_cost_a_10k = storage_cost_a  # (storage_cost_a * 10000 / 10000) = storage_cost_a
    storage_cost_b_10k = storage_cost_b

    n = len(quarters)
    idx = range(n)

    # Model
    m = gp.Model("Revised_Timber_Profit_Maximization")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # x[i,j]: volume bought in quarter i and sold in quarter j (10k m3), j >= i, j <= 3
    x = m.addVars([(i, j) for i in idx for j in idx if j >= i], lb=0, name="x")

    # end-of-autumn inventory (10k m3), i = purchase quarter (0..3)
    inv_end = m.addVars(idx, lb=0, name="inv_end")

    # over-purchase amount beyond safety inventory (10k m3)
    over_inv = m.addVar(lb=0, name="over_inv")

    # Constraints

    # Sales constraints: total sold in quarter j <= max_sales[j]
    for j in idx:
        qj = quarters[j]
        m.addConstr(gp.quicksum(x[i, j] for i in idx if j >= i) <= max_sales[qj], name=f"sales_cap_{qj}")

    # Purchase caps: total purchased in quarter i (sales plus end inventory) <= max_purchase
    for i in idx:
        qi = quarters[i]
        sold_from_i = gp.quicksum(x[i, j] for j in idx if j >= i)
        m.addConstr(sold_from_i + inv_end[i] <= max_purchase[qi], name=f"purchase_cap_{qi}")

    # Storage capacity constraints at end of Winter, Spring, Summer (t = 0,1,2)
    for t in range(n - 1):
        stored = gp.LinExpr()
        # Timber purchased up to quarter t and sold in later quarters (j > t)
        for i in idx:
            for j in idx:
                if i <= t and j > t and j >= i:
                    stored += x[i, j]
        # plus end-of-autumn inventory for purchases up to quarter t if autumn is beyond t
        # End-of-autumn inventory is held only after autumn, so it does not occupy warehouse earlier.
        # Therefore it should not be counted in intermediate storage constraints.
        m.addConstr(stored <= max_storage_10k_m3, name=f"storage_cap_q{t}")

    # Safety inventory and over-purchase relationship
    total_end_inv = gp.quicksum(inv_end[i] for i in idx)
    m.addConstr(over_inv >= total_end_inv - safety_inventory_level, name="over_inv_def")

    # Objective: maximize profit
    # base profit from flows x[i,j]
    obj = gp.LinExpr()

    for i in idx:
        qi = quarters[i]
        for j in idx:
            if j < i:
                continue
            qj = quarters[j]
            u = j - i
            revenue = sale_price[qj]
            cost = purchase_price[qi]
            if u > 0:
                s_cost = storage_cost_a_10k + storage_cost_b_10k * u
            else:
                s_cost = 0.0
            unit_profit = revenue - cost - s_cost
            obj += unit_profit * x[i, j]

    # Terminal inventory value for reserve inventory: credited for all end-of-autumn inventory
    obj += terminal_inventory_value * total_end_inv

    # Over-purchase penalty: applied to over_inv
    obj -= over_purchase_penalty * over_inv

    m.setObjective(obj, GRB.MAXIMIZE)

    m.optimize()

    final_obj = m.objVal
    print(f"FINAL_OBJ_VALUE: {final_obj}")

if __name__ == "__main__":
    main()
