import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    params = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))

    param_dict = dict(zip(params['Parameter_Name'], params['Value']))
    demand = dict(zip(table_1['stage'], table_1['tool_requirement']))

    return param_dict, demand

def solve():
    param_dict, demand = load_data()

    n = int(param_dict['n'])
    cost_new = float(param_dict['cost_new_tool'])
    cost_slow = float(param_dict['cost_slow_repair'])
    cost_fast = float(param_dict['cost_fast_repair'])
    dur_slow = int(param_dict['slow_repair_duration'])
    dur_fast = int(param_dict['fast_repair_duration'])
    max_fast_stage = float(param_dict['max_fast_stage'])
    max_slow_stage = float(param_dict['max_slow_stage'])
    emission_buy = float(param_dict['emission_buy'])
    emission_fast_repair = float(param_dict['emission_fast_repair'])
    emission_slow_repair = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_shortage = float(param_dict['penalty_shortage'])

    stages = list(range(1, n + 1))

    m = gp.Model("Revised_Tool_Repair")
    m.setParam('OutputFlag', 0)

    # Decision variables
    x = m.addVars(stages, vtype=GRB.INTEGER, lb=0, name="buy")          # new tools purchased at stage t
    y = m.addVars(stages, vtype=GRB.INTEGER, lb=0, name="fast")         # tools sent to fast repair at stage t
    z = m.addVars(stages, vtype=GRB.INTEGER, lb=0, name="slow")         # tools sent to slow repair at stage t
    c = m.addVars([0] + stages, vtype=GRB.INTEGER, lb=0, name="clean")  # clean tools at end of stage t
    d = m.addVars([0] + stages, vtype=GRB.INTEGER, lb=0, name="dirty")  # dirty tools at end of stage t
    s = m.addVars(stages, vtype=GRB.INTEGER, lb=0, name="shortage")     # unmet demand at stage t
    prebuy = m.addVar(vtype=GRB.INTEGER, lb=0, name="prebuy_clean")     # initial clean stock before stage 1

    # Initial conditions
    m.addConstr(c[0] == prebuy, name="init_clean")
    m.addConstr(d[0] == 0, name="init_dirty")

    # Stage-wise constraints
    for t in stages:
        # Tools returned from repair and ready at stage t
        fast_ready = 0
        slow_ready = 0

        # Fast repair: tools sent at stage k become ready after dur_fast stages.
        # We mimic the original indexing logic: at stage i, fast_ready = y[i - dur_fast - 1] if index >=1.
        idx_fast = t - dur_fast - 1
        if idx_fast >= 1:
            fast_ready = y[idx_fast]

        # Slow repair
        idx_slow = t - dur_slow - 1
        if idx_slow >= 1:
            slow_ready = z[idx_slow]

        # Clean balance: sources = uses
        # Sources: previous clean, new buys, repairs that just finished
        # Uses: tools used to meet demand (including unmet part), plus ending clean inventory
        # Here, tools actually used are demand[t] - s[t]
        m.addConstr(
            x[t] + c[t - 1] + fast_ready + slow_ready == (demand[t] - s[t]) + c[t],
            name=f"clean_balance_{t}"
        )

        # Dirty balance: previous dirty + tools used = tools sent to repair + remaining dirty
        m.addConstr(
            (demand[t] - s[t]) + d[t - 1] == y[t] + z[t] + d[t],
            name=f"dirty_balance_{t}"
        )

        # Stage-wise repair capacity
        m.addConstr(y[t] <= max_fast_stage, name=f"fast_cap_{t}")
        m.addConstr(z[t] <= max_slow_stage, name=f"slow_cap_{t}")

    # Carbon budget
    total_emissions = (
        emission_buy * (gp.quicksum(x[t] for t in stages) + prebuy)
        + emission_fast_repair * gp.quicksum(y[t] for t in stages)
        + emission_slow_repair * gp.quicksum(z[t] for t in stages)
    )
    m.addConstr(total_emissions <= carbon_budget, name="carbon_budget")

    # Objective: minimize cost of purchases, repairs, and shortage penalties
    total_cost = (
        cost_new * (gp.quicksum(x[t] for t in stages) + prebuy)
        + cost_fast * gp.quicksum(y[t] for t in stages)
        + cost_slow * gp.quicksum(z[t] for t in stages)
        + penalty_shortage * gp.quicksum(s[t] for t in stages)
    )
    m.setObjective(total_cost, GRB.MINIMIZE)

    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    solve()
