import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_distances(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    distances = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            yard = row['Coal_Yard'].strip()
            area = int(row['Residential_Area'].strip())
            dist = float(row['Distance_km'].strip())
            distances[(yard, area)] = dist
    return distances

def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')

    distances = load_distances(data_dir)
    params = load_parameters(data_dir)

    # Sets
    coal_yards = ['A', 'B']
    areas = [1, 2, 3]

    # Parameters
    min_supply = {
        'A': params['min_coal_yard_A'],
        'B': params['min_coal_yard_B_adjusted']
    }

    demand = {
        1: params['residential_area_1_demand'],
        2: params['residential_area_2_demand'],
        3: params['residential_area_3_demand']
    }

    min_share_area3_from_A = params['min_share_area3_from_A']
    staging_threshold = params['area3_A_staging_threshold']
    excess_staging_cost = params['area3_A_excess_staging_cost']

    # Build model
    m = gp.Model("Revised_Coal_Distribution")
    m.setParam('OutputFlag', 0)

    # Decision variables: shipped amount from yard i to area j
    x = {}
    for yard in coal_yards:
        for area in areas:
            # Some distances may be missing in the revised data (e.g., B->3)
            # If missing, treat as infeasible by not creating variable.
            if (yard, area) in distances:
                x[(yard, area)] = m.addVar(lb=0.0, name=f"x_{yard}_{area}")
    m.update()

    # Auxiliary variable for excess staging from A to Area 3
    x_A3 = x.get(('A', 3), None)
    excess_A3 = None
    if x_A3 is not None:
        excess_A3 = m.addVar(lb=0.0, name="excess_A3")
        m.update()
        # excess_A3 >= x_A3 - staging_threshold
        m.addConstr(excess_A3 >= x_A3 - staging_threshold, name="Excess_A3_def1")
        # excess_A3 <= x_A3 (non-reverse implication safeguard)
        m.addConstr(excess_A3 <= x_A3, name="Excess_A3_def2")

    # Objective: base transportation cost (distance * amount)
    obj = gp.LinExpr()
    for (yard, area), var in x.items():
        obj += distances[(yard, area)] * var

    # Add extra handling cost for A->3 above threshold
    if excess_A3 is not None:
        obj += excess_staging_cost * excess_A3

    m.setObjective(obj, GRB.MINIMIZE)

    # Constraints

    # 1. Each coal yard must supply at least its minimum requirement
    for yard in coal_yards:
        vars_for_yard = [var for (y, a), var in x.items() if y == yard]
        if vars_for_yard:
            m.addConstr(gp.quicksum(vars_for_yard) >= min_supply[yard],
                        name=f"Min_Supply_{yard}")

    # 2. Each residential area must receive exactly its demand
    for area in areas:
        vars_for_area = [var for (y, a), var in x.items() if a == area]
        m.addConstr(gp.quicksum(vars_for_area) == demand[area],
                    name=f"Demand_{area}")

    # 3. Minimum share of area 3 demand from A
    if x_A3 is not None:
        m.addConstr(x_A3 >= min_share_area3_from_A * demand[3],
                    name="Min_Share_Area3_From_A")

    # Solve
    m.optimize()

    obj_val = m.ObjVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
