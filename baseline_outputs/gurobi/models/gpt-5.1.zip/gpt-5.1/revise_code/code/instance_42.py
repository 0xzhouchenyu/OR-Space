import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_parameters(data_path)

    # Parameters
    a = params['a']  # hours per batch, method 1
    b = params['b']  # hours per batch, method 2
    k = params['k']  # tons per batch
    d = params['d']  # minimum production

    c_offpeak = params['c_offpeak']  # per-furnace off-peak hours
    c_peak = params['c_peak']        # per-furnace peak hours
    cap_offpeak = params['cap_offpeak']  # plant-wide off-peak hours
    cap_peak = params['cap_peak']        # plant-wide peak hours

    m_offpeak = params['m_offpeak']
    n_offpeak = params['n_offpeak']
    m_peak = params['m_peak']
    n_peak = params['n_peak']

    f_offpeak = params['f_offpeak']
    f_peak = params['f_peak']

    offpeak_threshold = params['offpeak_cooldown_batch_threshold']
    offpeak_fee = params['offpeak_cooldown_fee']

    # Sets
    furnaces = [1, 2]
    methods = [1, 2]
    periods = ['offpeak', 'peak']

    # Create model
    model = gp.Model("RevisedSteelFurnace")
    model.setParam('OutputFlag', 0)

    # Decision variables:
    # x[f, m, p] = number of batches on furnace f, method m, period p (continuous >= 0)
    x = {}
    for f in furnaces:
        for m in methods:
            for p in periods:
                x[f, m, p] = model.addVar(lb=0.0, name=f"x_f{f}_m{m}_{p}")

    # Activation binaries for each furnace and period
    y = {}
    for f in furnaces:
        for p in periods:
            y[f, p] = model.addVar(vtype=GRB.BINARY, name=f"y_f{f}_{p}")

    # Cooldown binary for off-peak per furnace
    z_cool = {}
    for f in furnaces:
        z_cool[f] = model.addVar(vtype=GRB.BINARY, name=f"z_cool_f{f}")

    model.update()

    # Big-M for linking activation y and usage x
    # Max possible time per furnace per period is at most plant-wide capacity plus per-furnace capacity.
    # Use a conservative large M for batches by dividing max hours by min(a,b).
    max_hours_offpeak = max(c_offpeak, cap_offpeak)
    max_hours_peak = max(c_peak, cap_peak)
    min_time_per_batch = min(a, b)
    M_batches_offpeak = max_hours_offpeak / min_time_per_batch if min_time_per_batch > 0 else 1000.0
    M_batches_peak = max_hours_peak / min_time_per_batch if min_time_per_batch > 0 else 1000.0

    # Time constraints per furnace and period
    for f in furnaces:
        # Off-peak per furnace
        model.addConstr(
            a * x[f, 1, 'offpeak'] + b * x[f, 2, 'offpeak'] <= c_offpeak,
            name=f"F{f}_OffpeakTime"
        )
        # Peak per furnace
        model.addConstr(
            a * x[f, 1, 'peak'] + b * x[f, 2, 'peak'] <= c_peak,
            name=f"F{f}_PeakTime"
        )

    # Plant-wide time capacity constraints
    model.addConstr(
        gp.quicksum(a * x[f, 1, 'offpeak'] + b * x[f, 2, 'offpeak'] for f in furnaces) <= cap_offpeak,
        name="Plant_OffpeakTime"
    )
    model.addConstr(
        gp.quicksum(a * x[f, 1, 'peak'] + b * x[f, 2, 'peak'] for f in furnaces) <= cap_peak,
        name="Plant_PeakTime"
    )

    # Activation linking: if any batch is run in a period on a furnace, pay fixed activation cost
    for f in furnaces:
        # Off-peak
        model.addConstr(
            x[f, 1, 'offpeak'] + x[f, 2, 'offpeak'] <= M_batches_offpeak * y[f, 'offpeak'],
            name=f"LinkOffpeak_f{f}"
        )
        # Peak
        model.addConstr(
            x[f, 1, 'peak'] + x[f, 2, 'peak'] <= M_batches_peak * y[f, 'peak'],
            name=f"LinkPeak_f{f}"
        )

    # Off-peak cooldown gate: a furnace may handle up to threshold batches without fee,
    # if total off-peak batches exceed threshold, pay cooldown fee (z_cool = 1).
    # Implement with:
    # total_offpeak_batches_f <= threshold + M*(z_cool_f)
    # and total_offpeak_batches_f >= threshold + epsilon - M*(1 - z_cool_f)
    # Using a small epsilon to detect "more than threshold".
    epsilon = 1e-4
    M_cool = M_batches_offpeak

    for f in furnaces:
        total_offpeak_batches = x[f, 1, 'offpeak'] + x[f, 2, 'offpeak']
        # If z_cool_f = 0 => total_offpeak_batches <= threshold
        model.addConstr(
            total_offpeak_batches <= offpeak_threshold + M_cool * z_cool[f],
            name=f"CooldownUpper_f{f}"
        )
        # If total_offpeak_batches >= threshold + epsilon then z_cool_f must be 1
        model.addConstr(
            total_offpeak_batches >= offpeak_threshold + epsilon - M_cool * (1 - z_cool[f]),
            name=f"CooldownLower_f{f}"
        )

    # Minimum production requirement
    total_batches = gp.quicksum(x[f, m, p] for f in furnaces for m in methods for p in periods)
    model.addConstr(k * total_batches >= d, name="MinProduction")

    # Objective: minimize total fuel cost + activation overheads + cooldown fees
    fuel_cost = gp.quicksum(
        m_offpeak * x[f, 1, 'offpeak'] +
        n_offpeak * x[f, 2, 'offpeak'] +
        m_peak * x[f, 1, 'peak'] +
        n_peak * x[f, 2, 'peak']
        for f in furnaces
    )

    activation_cost = gp.quicksum(
        f_offpeak * y[f, 'offpeak'] + f_peak * y[f, 'peak']
        for f in furnaces
    )

    cooldown_cost = gp.quicksum(offpeak_fee * z_cool[f] for f in furnaces)

    model.setObjective(fuel_cost + activation_cost + cooldown_cost, GRB.MINIMIZE)

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
