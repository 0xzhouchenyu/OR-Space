import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")

    params = load_general_parameters(data_path)

    # Extract parameters
    sell_price_table = params['sell_price_table']
    sell_price_chair = params['sell_price_chair']
    sell_price_bookshelf = params['sell_price_bookshelf']

    cost_table = params['manufacturing_cost_table']
    cost_chair = params['manufacturing_cost_chair']
    cost_bookshelf = params['manufacturing_cost_bookshelf']

    space_table = params['warehouse_space_table']
    space_chair = params['warehouse_space_chair']
    space_bookshelf = params['warehouse_space_bookshelf']

    max_warehouse = params['max_warehouse_space']
    min_tables = params['min_tables']
    min_bookshelves = params['min_bookshelves']
    max_total = params['max_total_items']

    labor_table = params['labor_hours_table']
    labor_chair = params['labor_hours_chair']
    labor_bookshelf = params['labor_hours_bookshelf']

    max_labor_regular = params['max_labor_hours_month_regular']
    max_labor_rush = params['max_labor_hours_month_rush']
    max_rush_items = params['max_rush_items_month']

    rush_bonus_table = params['rush_profit_bonus_table']
    rush_bonus_chair = params['rush_profit_bonus_chair']
    rush_bonus_bookshelf = params['rush_profit_bonus_bookshelf']

    # Base profit per item (selling price - manufacturing cost)
    profit_table = sell_price_table - cost_table
    profit_chair = sell_price_chair - cost_chair
    profit_bookshelf = sell_price_bookshelf - cost_bookshelf

    # Rush profit is base profit plus rush bonus
    profit_table_rush = profit_table + rush_bonus_table
    profit_chair_rush = profit_chair + rush_bonus_chair
    profit_bookshelf_rush = profit_bookshelf + rush_bonus_bookshelf

    # Build model
    m = gp.Model("Furniture_Production_Revised")
    m.setParam('OutputFlag', 0)

    # Decision variables:
    # Regular and rush quantities for each product (non-negative integers)
    x_table_reg = m.addVar(vtype=GRB.INTEGER, name="tables_regular", lb=0)
    x_chair_reg = m.addVar(vtype=GRB.INTEGER, name="chairs_regular", lb=0)
    x_bookshelf_reg = m.addVar(vtype=GRB.INTEGER, name="bookshelves_regular", lb=0)

    x_table_rush = m.addVar(vtype=GRB.INTEGER, name="tables_rush", lb=0)
    x_chair_rush = m.addVar(vtype=GRB.INTEGER, name="chairs_rush", lb=0)
    x_bookshelf_rush = m.addVar(vtype=GRB.INTEGER, name="bookshelves_rush", lb=0)

    # Objective: maximize total profit from regular + rush items
    obj = (
        profit_table * x_table_reg
        + profit_chair * x_chair_reg
        + profit_bookshelf * x_bookshelf_reg
        + profit_table_rush * x_table_rush
        + profit_chair_rush * x_chair_rush
        + profit_bookshelf_rush * x_bookshelf_rush
    )
    m.setObjective(obj, GRB.MAXIMIZE)

    # Constraints

    # Warehouse space: both regular and rush items consume warehouse space
    m.addConstr(
        space_table * (x_table_reg + x_table_rush)
        + space_chair * (x_chair_reg + x_chair_rush)
        + space_bookshelf * (x_bookshelf_reg + x_bookshelf_rush)
        <= max_warehouse,
        name="Warehouse_Space",
    )

    # Minimum production requirements (total of regular + rush)
    m.addConstr(
        x_table_reg + x_table_rush >= min_tables,
        name="Min_Tables",
    )
    m.addConstr(
        x_bookshelf_reg + x_bookshelf_rush >= min_bookshelves,
        name="Min_Bookshelves",
    )

    # Maximum total production (regular + rush)
    m.addConstr(
        (x_table_reg + x_table_rush)
        + (x_chair_reg + x_chair_rush)
        + (x_bookshelf_reg + x_bookshelf_rush)
        <= max_total,
        name="Max_Total_Items",
    )

    # Regular labor-hour cap
    m.addConstr(
        labor_table * x_table_reg
        + labor_chair * x_chair_reg
        + labor_bookshelf * x_bookshelf_reg
        <= max_labor_regular,
        name="Max_Regular_Labor",
    )

    # Rush labor-hour cap
    m.addConstr(
        labor_table * x_table_rush
        + labor_chair * x_chair_rush
        + labor_bookshelf * x_bookshelf_rush
        <= max_labor_rush,
        name="Max_Rush_Labor",
    )

    # Maximum total rush items
    m.addConstr(
        x_table_rush + x_chair_rush + x_bookshelf_rush <= max_rush_items,
        name="Max_Rush_Items",
    )

    # Optimize
    m.optimize()

    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
