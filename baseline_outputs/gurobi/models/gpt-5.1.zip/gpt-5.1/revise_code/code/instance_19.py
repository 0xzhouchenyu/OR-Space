import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            try:
                value = int(value_str)
            except ValueError:
                try:
                    value = float(value_str)
                except ValueError:
                    value = value_str
            params[name] = value
    return params


def main():
    # Paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")

    # Load parameters
    params = load_general_parameters(data_path)

    cost_A = params['cost_per_chair_A']
    cost_B = params['cost_per_chair_B']
    cost_C = params['cost_per_chair_C']

    chairs_per_order_A = params['chairs_per_order_A']
    chairs_per_order_B = params['chairs_per_order_B']
    chairs_per_order_C = params['chairs_per_order_C']

    min_total = params['min_total_chairs']
    max_total = params['max_total_chairs']
    min_chairs_B_if_A = params['min_chairs_B_if_A']
    dependency_B_C = params['dependency_B_C']

    fixed_fee_A_regular = params['fixed_fee_A_regular']
    fixed_fee_A_express = params['fixed_fee_A_express']
    fixed_fee_B_regular = params['fixed_fee_B_regular']
    fixed_fee_B_express = params['fixed_fee_B_express']
    fixed_fee_C_regular = params['fixed_fee_C_regular']
    fixed_fee_C_express = params['fixed_fee_C_express']

    weekly_order_budget = params['weekly_order_budget']

    # Big-M for linking orders and modes
    max_chairs_per_supplier = max_total
    max_orders_A = max_chairs_per_supplier // chairs_per_order_A + 1
    max_orders_B = max_chairs_per_supplier // chairs_per_order_B + 1
    max_orders_C = max_chairs_per_supplier // chairs_per_order_C + 1

    # Model
    m = gp.Model("RevisedFurnitureOrder")
    m.setParam('OutputFlag', 0)

    # Decision variables: number of orders from each manufacturer (integer, >= 0)
    x_A = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_A, name="orders_A")
    x_B = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_B, name="orders_B")
    x_C = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_C, name="orders_C")

    # Mode selection binaries for each manufacturer
    y_A_reg = m.addVar(vtype=GRB.BINARY, name="y_A_regular")
    y_A_exp = m.addVar(vtype=GRB.BINARY, name="y_A_express")
    y_B_reg = m.addVar(vtype=GRB.BINARY, name="y_B_regular")
    y_B_exp = m.addVar(vtype=GRB.BINARY, name="y_B_express")
    y_C_reg = m.addVar(vtype=GRB.BINARY, name="y_C_regular")
    y_C_exp = m.addVar(vtype=GRB.BINARY, name="y_C_express")

    # Helper: whether supplier is used at all
    y_A = m.addVar(vtype=GRB.BINARY, name="y_A")
    y_B = m.addVar(vtype=GRB.BINARY, name="y_B")
    y_C = m.addVar(vtype=GRB.BINARY, name="y_C")

    # Total chairs from each manufacturer
    chairs_A = chairs_per_order_A * x_A
    chairs_B = chairs_per_order_B * x_B
    chairs_C = chairs_per_order_C * x_C

    # Objective: minimize total cost (variable cost + fixed fees by chosen mode)
    total_cost = (
        cost_A * chairs_A +
        cost_B * chairs_B +
        cost_C * chairs_C +
        fixed_fee_A_regular * y_A_reg +
        fixed_fee_A_express * y_A_exp +
        fixed_fee_B_regular * y_B_reg +
        fixed_fee_B_express * y_B_exp +
        fixed_fee_C_regular * y_C_reg +
        fixed_fee_C_express * y_C_exp
    )
    m.setObjective(total_cost, GRB.MINIMIZE)

    # Total chairs constraints
    m.addConstr(chairs_A + chairs_B + chairs_C >= min_total, name="MinChairs")
    m.addConstr(chairs_A + chairs_B + chairs_C <= max_total, name="MaxChairs")

    # Supplier usage vs orders (big-M linking)
    M_orders = max_orders_A + max_orders_B + max_orders_C

    m.addConstr(x_A <= M_orders * y_A, name="LinkA_up")
    m.addConstr(x_A >= y_A, name="LinkA_low")

    m.addConstr(x_B <= M_orders * y_B, name="LinkB_up")
    m.addConstr(x_B >= y_B, name="LinkB_low")

    m.addConstr(x_C <= M_orders * y_C, name="LinkC_up")
    m.addConstr(x_C >= y_C, name="LinkC_low")

    # Mode selection constraints: at most one channel per supplier if used
    m.addConstr(y_A_reg + y_A_exp == y_A, name="ModeA_exclusive")
    m.addConstr(y_B_reg + y_B_exp == y_B, name="ModeB_exclusive")
    m.addConstr(y_C_reg + y_C_exp == y_C, name="ModeC_exclusive")

    # Weekly order budget: total active manufacturer-mode combinations
    m.addConstr(
        y_A_reg + y_A_exp + y_B_reg + y_B_exp + y_C_reg + y_C_exp <= weekly_order_budget,
        name="WeeklyOrderBudget"
    )

    # Original dependency: if ordering from A, must order at least min_chairs_B_if_A chairs from B
    # chairs_B >= min_chairs_B_if_A * y_A
    m.addConstr(chairs_B >= min_chairs_B_if_A * y_A, name="DepAB")

    # Dependency: if ordering from B, must also order from C (y_B <= y_C)
    if dependency_B_C:
        m.addConstr(y_B <= y_C, name="DepBC")

    # Optimize
    m.optimize()

    # Print final objective
    obj_val = m.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
