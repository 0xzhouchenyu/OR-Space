import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB


def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Load table_1.csv
    parts = []
    with open(os.path.join(base_dir, "data", "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append(
                {
                    "id": int(row["Key_Part"]),
                    "distance": float(row["Distance_from_Airport_km"]),
                    "p_heavy": float(row["Probability_of_Destruction_per_Heavy_Bomb"]),
                    "p_light": float(row["Probability_of_Destruction_per_Light_Bomb"]),
                }
            )

    # Load general_parameters.csv
    params = {}
    with open(os.path.join(base_dir, "data", "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])

    return parts, params


def fuel_per_heavy_bomb(distance, params):
    eff_heavy = params["fuel_efficiency_heavy_bomb"]
    eff_empty = params["fuel_efficiency_empty"]
    takeoff_landing = params["fuel_takeoff_landing"]
    return distance / eff_heavy + distance / eff_empty + takeoff_landing


def fuel_per_light_bomb(distance, params):
    eff_light = params["fuel_efficiency_light_bomb"]
    eff_empty = params["fuel_efficiency_empty"]
    takeoff_landing = params["fuel_takeoff_landing"]
    return distance / eff_light + distance / eff_empty + takeoff_landing


def prob_at_least_k(probs, k):
    """Probability that at least k out of n independent events occur."""
    n = len(probs)
    dp = [0.0] * (n + 1)
    dp[0] = 1.0
    for i in range(n):
        new_dp = [0.0] * (n + 1)
        for j in range(i + 2):
            new_dp[j] += dp[j] * (1.0 - probs[i])
            if j > 0:
                new_dp[j] += dp[j - 1] * probs[i]
        dp = new_dp
    return sum(dp[j] for j in range(k, n + 1))


def main():
    parts, params = load_data()

    max_heavy = int(params["max_heavy_bombs"])
    max_light = int(params["max_light_bombs"])
    fuel_limit = params["fuel_limit"]
    min_parts = int(params["min_parts_destroyed"])
    max_sorties_A = int(params["max_sorties_A"])
    max_sorties_B = int(params["max_sorties_B"])
    sortie_overhead_A = params["sortie_fuel_overhead_A"]
    sortie_overhead_B = params["sortie_fuel_overhead_B"]
    scen_prob_A = params["scenario_prob_A"]
    scen_prob_B = params["scenario_prob_B"]

    n = len(parts)

    # Precompute per-sortie fuel excluding scenario-specific overhead
    fuel_h_base = [fuel_per_heavy_bomb(p["distance"], params) for p in parts]
    fuel_l_base = [fuel_per_light_bomb(p["distance"], params) for p in parts]

    # Since heavy/light fuel functions already include fuel_takeoff_landing,
    # we only need to add the scenario-specific overhead.
    fuel_h_A = [fuel_h_base[i] + sortie_overhead_A for i in range(n)]
    fuel_l_A = [fuel_l_base[i] + sortie_overhead_A for i in range(n)]
    fuel_h_B = [fuel_h_base[i] + sortie_overhead_B for i in range(n)]
    fuel_l_B = [fuel_l_base[i] + sortie_overhead_B for i in range(n)]

    # Create model
    m = gp.Model("RobustBombAllocation")
    m.setParam("OutputFlag", 0)

    # Decision variables: integer number of heavy/light bombs (sorties) per part
    xh = m.addVars(n, vtype=GRB.INTEGER, name="xh")
    xl = m.addVars(n, vtype=GRB.INTEGER, name="xl")

    # Bomb inventory constraints
    m.addConstr(gp.quicksum(xh[i] for i in range(n)) <= max_heavy, "HeavyStock")
    m.addConstr(gp.quicksum(xl[i] for i in range(n)) <= max_light, "LightStock")

    # Robust sortie capacity: plan must fit smaller of the two pools
    max_sorties = min(max_sorties_A, max_sorties_B)
    m.addConstr(gp.quicksum(xh[i] + xl[i] for i in range(n)) <= max_sorties, "SortieCap")

    # Robust fuel constraints for both scenarios
    m.addConstr(
        gp.quicksum(xh[i] * fuel_h_A[i] + xl[i] * fuel_l_A[i] for i in range(n))
        <= fuel_limit,
        "Fuel_A",
    )
    m.addConstr(
        gp.quicksum(xh[i] * fuel_h_B[i] + xl[i] * fuel_l_B[i] for i in range(n))
        <= fuel_limit,
        "Fuel_B",
    )

    # Build nonlinear objective: expected mission success probability
    # Scenario probabilities are the same, only feasibility differs,
    # so success probability is identical across scenarios for a fixed plan.
    # Expected probability = (scen_prob_A + scen_prob_B) * P(success) = P(success)
    # We therefore just maximize P(success).
    #
    # P_destroy_part_i = 1 - (1-p_h)^xh * (1-p_l)^xl
    # P(success) = probability at least min_parts destroyed (independent parts)

    def part_success_prob_expr(i):
        p_h = parts[i]["p_heavy"]
        p_l = parts[i]["p_light"]
        # Use Gurobi's general function pow()
        term_h = (1.0 - p_h) ** xh[i]
        term_l = (1.0 - p_l) ** xl[i]
        return 1.0 - term_h * term_l

    # Compute probabilities of destroying exactly k parts via DP, using Gurobi expressions
    # dp[i][j]: expr for probability of exactly j destroyed out of first i parts
    dp = [[None for _ in range(n + 1)] for _ in range(n + 1)]
    dp[0][0] = 1.0
    for j in range(1, n + 1):
        dp[0][j] = 0.0

    for i in range(1, n + 1):
        p_i = part_success_prob_expr(i - 1)
        for j in range(0, i + 1):
            no_hit = dp[i - 1][j] * (1.0 - p_i)
            if j == 0:
                hit = 0.0
            else:
                hit = dp[i - 1][j - 1] * p_i
            dp[i][j] = no_hit + hit

    P_success = sum(dp[n][j] for j in range(min_parts, n + 1))

    m.setObjective(P_success, GRB.MAXIMIZE)

    # Optimize
    m.optimize()

    obj_val = m.objVal if m.status == GRB.OPTIMAL else float("nan")
    print(f"FINAL_OBJ_VALUE: {obj_val}")


if __name__ == "__main__":
    main()
