import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_feed_data(filepath):
    feeds = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            feed = {
                'Feed': int(row['Feed']),
                'Protein_g': float(row['Protein_g']),
                'Minerals_g': float(row['Minerals_g']),
                'Vitamins_mg': float(row['Vitamins_mg']),
                'Price_Y_per_kg': float(row['Price_Y_per_kg']),
            }
            feeds.append(feed)
    return feeds

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    feeds = load_feed_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    min_protein = params['min_protein_requirement']
    min_minerals = params['min_minerals_requirement']
    min_vitamins = params['min_vitamins_requirement']

    model = gp.Model("MinimizeFeedCost")
    model.setParam('OutputFlag', 0)

    # Decision variables: amount of each feed (kg), non-negative
    x = {}
    for f in feeds:
        x[f['Feed']] = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"x_{f['Feed']}")

    # Binary vars for mutual exclusion between Feed 4 and Feed 5
    y4 = model.addVar(vtype=GRB.BINARY, name="y_4")
    y5 = model.addVar(vtype=GRB.BINARY, name="y_5")

    model.update()

    # Objective: minimize total cost
    model.setObjective(
        gp.quicksum(f['Price_Y_per_kg'] * x[f['Feed']] for f in feeds),
        GRB.MINIMIZE
    )

    # Nutrient constraints
    model.addConstr(
        gp.quicksum(f['Protein_g'] * x[f['Feed']] for f in feeds) >= min_protein,
        name="ProteinRequirement"
    )
    model.addConstr(
        gp.quicksum(f['Minerals_g'] * x[f['Feed']] for f in feeds) >= min_minerals,
        name="MineralsRequirement"
    )
    model.addConstr(
        gp.quicksum(f['Vitamins_mg'] * x[f['Feed']] for f in feeds) >= min_vitamins,
        name="VitaminsRequirement"
    )

    # Mutual exclusion: cannot use Feed 4 and Feed 5 simultaneously
    # Big-M linking: if y4 = 0 then x_4 = 0; if y5 = 0 then x_5 = 0; and y4 + y5 <= 1
    # Use a sufficiently large M; upper bound on any single feed usage.
    M = 1e6
    if 4 in x:
        model.addConstr(x[4] <= M * y4, name="Link_4")
    if 5 in x:
        model.addConstr(x[5] <= M * y5, name="Link_5")
    model.addConstr(y4 + y5 <= 1, name="MutualExclusion_4_5")

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
