import os
from gurobipy import Model, GRB
from utils import load_general_parameters

def main():
    # Load parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    params = load_general_parameters(params_path)

    m1_liquid = params['machine_1_time_per_liquid_lot']      # minutes per lot
    m2_liquid = params['machine_2_time_per_liquid_lot']
    m1_solid = params['machine_1_time_per_solid_lot']
    m2_solid = params['machine_2_time_per_solid_lot']

    init_liquid = params['initial_liquid_inventory']
    init_solid = params['initial_solid_inventory']

    # Convert hours to minutes for base availability
    m1_avail = params['machine_1_available_time'] * 60.0
    m2_avail = params['machine_2_available_time'] * 60.0

    demand_liquid = params['forecast_liquid_demand']
    demand_solid = params['forecast_solid_demand']

    extended_extra_minutes = params['extended_extra_minutes']
    labor_hours_per_machine_extended = params['labor_hours_per_machine_extended']
    labor_budget_hours = params['labor_budget_hours']
    extended_mode_penalty = params['extended_mode_penalty']
    priority_reserve_lots = params['priority_reserve_lots']
    excess_reserve_credit = params['excess_reserve_credit']

    # Create model
    model = Model("Revised_Fertilizer_Resilience")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x_l = model.addVar(name="x_liquid", lb=0.0)  # lots of liquid produced
    x_s = model.addVar(name="x_solid", lb=0.0)   # lots of solid produced

    # Extended-mode binary variables for each machine
    e1 = model.addVar(vtype=GRB.BINARY, name="extended_m1")
    e2 = model.addVar(vtype=GRB.BINARY, name="extended_m2")

    model.update()

    # Ending inventories
    end_liquid = init_liquid + x_l - demand_liquid
    end_solid = init_solid + x_s - demand_solid

    # Reserve band variables for resilience scoring
    # For each product: priority_reserve <= priority_reserve_lots and <= end_inventory
    pr_liq = model.addVar(lb=0.0, name="priority_reserve_liquid")
    pr_sol = model.addVar(lb=0.0, name="priority_reserve_solid")
    ex_liq = model.addVar(lb=0.0, name="excess_reserve_liquid")
    ex_sol = model.addVar(lb=0.0, name="excess_reserve_solid")

    model.update()

    # Machine capacity constraints with possible extended time
    model.addConstr(m1_liquid * x_l + m1_solid * x_s <= m1_avail + extended_extra_minutes * e1,
                    name="Machine_1_Capacity")
    model.addConstr(m2_liquid * x_l + m2_solid * x_s <= m2_avail + extended_extra_minutes * e2,
                    name="Machine_2_Capacity")

    # Labor budget for extended modes
    model.addConstr(labor_hours_per_machine_extended * (e1 + e2) <= labor_budget_hours,
                    name="Labor_Budget")

    # Demand satisfaction: ending inventory cannot be negative
    model.addConstr(end_liquid >= 0.0, name="Liquid_Demand_Satisfaction")
    model.addConstr(end_solid >= 0.0, name="Solid_Demand_Satisfaction")

    # Priority reserve band constraints
    model.addConstr(pr_liq <= priority_reserve_lots, name="PR_Liq_UpperBand")
    model.addConstr(pr_sol <= priority_reserve_lots, name="PR_Sol_UpperBand")
    model.addConstr(pr_liq <= end_liquid, name="PR_Liq_InventoryLink")
    model.addConstr(pr_sol <= end_solid, name="PR_Sol_InventoryLink")

    # Excess reserve is inventory beyond priority band
    model.addConstr(ex_liq <= end_liquid - pr_liq, name="EX_Liq_Upper")
    model.addConstr(ex_sol <= end_solid - pr_sol, name="EX_Sol_Upper")

    # Nonnegativity of ending inventories implicitly handled via pr/ex linkage
    # but ensure end_liquid/end_solid are sufficient for pr/ex bounds
    # No additional constraints needed beyond those above

    # Resilience score objective:
    # For each product:
    #   priority_reserve lots count fully: coefficient 1
    #   excess lots counted at excess_reserve_credit
    # Extended mode penalty per machine: extended_mode_penalty
    resilience_score = (
        pr_liq + pr_sol
        + excess_reserve_credit * (ex_liq + ex_sol)
        - extended_mode_penalty * (e1 + e2)
    )

    model.setObjective(resilience_score, GRB.MAXIMIZE)

    # Optimize
    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
