import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_coverage_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    return areas, coverage

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)

    # Parameters (converted to appropriate types)
    distance_limit = int(params.get('distance_limit', 800))  # not used directly but loaded
    small_cost = float(params.get('small_cost', 1))
    large_cost = float(params.get('large_cost', 2))
    small_cap_areas = int(params.get('small_cap_areas', 3))
    max_large_stores = int(params.get('max_large_stores', 1))
    minimum_neighborhood_counters = int(params.get('minimum_neighborhood_counters', 6))
    small_store_counter_credit = int(params.get('small_store_counter_credit', 1))

    # Model
    m = gp.Model("RevisedChainStores")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # y_s[j] = 1 if a Small-format store is opened at j
    # y_l[j] = 1 if a Large-format store is opened at j
    y_s = m.addVars(areas, vtype=GRB.BINARY, name="y_small")
    y_l = m.addVars(areas, vtype=GRB.BINARY, name="y_large")

    # z[i,j] = 1 if area j is served by the store at i (either small or large)
    z = m.addVars(areas, areas, vtype=GRB.BINARY, name="z")

    # Objective: minimize total cost
    m.setObjective(
        gp.quicksum(small_cost * y_s[j] + large_cost * y_l[j] for j in areas),
        GRB.MINIMIZE
    )

    # Each area must be covered by at least one store whose physical coverage includes it
    for j in areas:
        covering_i = [i for i in areas if j in coverage.get(i, set())]
        if covering_i:
            m.addConstr(gp.quicksum(z[i, j] for i in covering_i) >= 1, name=f"Cover_{j}")
        else:
            # If no store can cover area j physically, problem is infeasible, but we still add a dummy constraint
            m.addConstr(gp.quicksum(z[i, j] for i in areas) >= 1, name=f"Cover_{j}_dummy")

    # Link assignment z[i,j] to store opening decisions
    for i in areas:
        for j in areas:
            if j in coverage.get(i, set()):
                # z[i,j] <= y_s[i] + y_l[i]
                m.addConstr(z[i, j] <= y_s[i] + y_l[i], name=f"Link_{i}_{j}")
            else:
                # Cannot serve j from i if j not in physical coverage list of i
                m.addConstr(z[i, j] == 0, name=f"NoCoverage_{i}_{j}")

    # Small store capacity: can serve at most small_cap_areas areas
    for i in areas:
        m.addConstr(
            gp.quicksum(z[i, j] for j in areas) <= small_cap_areas * y_s[i] + len(areas) * y_l[i],
            name=f"Cap_{i}"
        )

    # Maximum number of Large-format stores in the entire network
    m.addConstr(gp.quicksum(y_l[j] for j in areas) <= max_large_stores, name="MaxLargeStores")

    # Minimum number of neighborhood counters (small stores)
    m.addConstr(
        gp.quicksum(small_store_counter_credit * y_s[j] for j in areas) >= minimum_neighborhood_counters,
        name="MinSmallStores"
    )

    # Solve
    m.optimize()

    obj_val = m.objVal if m.status == GRB.OPTIMAL else float('nan')
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
