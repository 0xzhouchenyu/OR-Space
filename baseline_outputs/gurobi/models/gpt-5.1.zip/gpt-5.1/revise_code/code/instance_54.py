import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_table_1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    equipment_names = []
    products = []
    processing_times = {}  # (equipment, product) -> time
    effective_hours = {}   # equipment -> hours
    base_profit = {}       # product -> base profit (used as cost)

    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        products = header[1:-1]  # ['I', 'II', 'III']

        for row in reader:
            if not row:
                continue
            if row[0].startswith('Unit_Product_Profit'):
                for j, prod in enumerate(products):
                    base_profit[prod] = float(row[j + 1])
            else:
                equip = row[0]
                equipment_names.append(equip)
                effective_hours[equip] = float(row[-1])
                for j, prod in enumerate(products):
                    processing_times[(equip, prod)] = float(row[j + 1])

    return products, equipment_names, processing_times, effective_hours, base_profit

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = float(row['Value'])
            params[name] = val
    return params

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')

    products, equipment_names, processing_times, effective_hours, base_profit = load_table_1(data_dir)
    params = load_general_parameters(data_dir)

    overtime_hours_cap = params['overtime_hours_cap']
    overtime_cost_multiplier = params['overtime_cost_multiplier']
    min_prod = {
        'I': params['min_prod_I'],
        'II': params['min_prod_II'],
        'III': params['min_prod_III']
    }

    model = gp.Model("Revised_Factory_Production")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x_reg = {p: model.addVar(lb=0.0, name=f"x_reg_{p}") for p in products}
    x_ot = {p: model.addVar(lb=0.0, name=f"x_ot_{p}") for p in products}

    # Objective: minimize total cost
    regular_cost = {p: base_profit[p] for p in products}
    overtime_cost = {p: overtime_cost_multiplier * base_profit[p] for p in products}

    model.setObjective(
        gp.quicksum(regular_cost[p] * x_reg[p] + overtime_cost[p] * x_ot[p] for p in products),
        GRB.MINIMIZE
    )

    # Equipment capacity constraints
    for e in equipment_names:
        model.addConstr(
            gp.quicksum(processing_times[(e, p)] * (x_reg[p] + x_ot[p]) for p in products) <= effective_hours[e],
            name=f"Equip_{e}_cap"
        )

    # Overtime hours cap
    model.addConstr(
        gp.quicksum(
            processing_times[(e, p)] * x_ot[p]
            for e in equipment_names
            for p in products
        ) <= overtime_hours_cap,
        name="Overtime_Hours_Cap"
    )

    # Minimum production constraints per product
    for p in products:
        model.addConstr(
            x_reg[p] + x_ot[p] >= min_prod[p],
            name=f"Min_Prod_{p}"
        )

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
