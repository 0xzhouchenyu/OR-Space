import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_monthly_data(filepath):
    months = []
    purchasing_prices = {}
    selling_prices = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            purchasing_prices[m] = float(row['Purchasing_Price_Yuan'])
            selling_prices[m] = float(row['Selling_Price_Yuan'])
    return months, purchasing_prices, selling_prices

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')

    months, purchasing_prices, selling_prices = load_monthly_data(
        os.path.join(data_dir, 'table_1.csv')
    )
    params = load_general_parameters(
        os.path.join(data_dir, 'general_parameters.csv')
    )

    warehouse_capacity = params['warehouse_capacity']
    initial_stock = params['initial_stock']
    fixed_ordering_cost = params['fixed_ordering_cost']
    month2_bulk_receiving_threshold = params['month2_bulk_receiving_threshold']
    month2_bulk_receiving_fee = params['month2_bulk_receiving_fee']

    model = gp.Model("Revised_Store_Profit")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {m: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"purchase_{m}") for m in months}
    s = {m: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"sell_{m}") for m in months}
    inv = {m: model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name=f"inventory_{m}") for m in months}

    # Fixed ordering indicator: 1 if any purchase in month m
    y = {m: model.addVar(vtype=GRB.BINARY, name=f"order_indicator_{m}") for m in months}

    # February bulk receiving indicator: 1 if purchase in month 2 exceeds threshold
    z2 = model.addVar(vtype=GRB.BINARY, name="month2_bulk_indicator")

    model.update()

    # Big-M for linking x and y
    M_purchase = warehouse_capacity + initial_stock

    # Inventory balance and capacity constraints
    for m in months:
        if m == months[0]:
            prev_inv_expr = initial_stock
        else:
            prev_inv_expr = inv[m - 1]

        # Inventory balance
        model.addConstr(inv[m] == prev_inv_expr + x[m] - s[m], name=f"inventory_balance_{m}")

        # Warehouse capacity at end of month
        model.addConstr(inv[m] <= warehouse_capacity, name=f"warehouse_end_{m}")

        # Warehouse capacity after purchase (before selling)
        model.addConstr(prev_inv_expr + x[m] <= warehouse_capacity,
                        name=f"warehouse_after_purchase_{m}")

        # Cannot sell more than available
        model.addConstr(s[m] <= prev_inv_expr + x[m], name=f"sell_limit_{m}")

        # Link purchase quantity and fixed ordering indicator
        model.addConstr(x[m] <= M_purchase * y[m], name=f"purchase_upper_{m}")
        # If y[m] = 1, ensure at least a tiny positive upper link; since objective will not
        # favor unnecessary purchases, we do not need a positive lower bound tied to y[m].

    # February bulk receiving gate: if x[2] > threshold then z2 = 1, else z2 = 0
    # Implement as:
    # x[2] <= threshold + M*(z2)
    # x[2] >= threshold + epsilon - M*(1 - z2)
    if 2 in months:
        M_feb = warehouse_capacity + initial_stock
        epsilon = 1e-6

        model.addConstr(x[2] <= month2_bulk_receiving_threshold + M_feb * z2,
                        name="feb_bulk_upper")
        model.addConstr(
            x[2] >= month2_bulk_receiving_threshold + epsilon - M_feb * (1 - z2),
            name="feb_bulk_lower"
        )

    # Objective: maximize profit
    revenue = gp.quicksum(selling_prices[m] * s[m] for m in months)
    purchasing_cost = gp.quicksum(purchasing_prices[m] * x[m] for m in months)
    fixed_cost = gp.quicksum(fixed_ordering_cost * y[m] for m in months)
    bulk_fee = month2_bulk_receiving_fee * z2 if 2 in months else 0.0

    model.setObjective(revenue - purchasing_cost - fixed_cost - bulk_fee, GRB.MAXIMIZE)

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
