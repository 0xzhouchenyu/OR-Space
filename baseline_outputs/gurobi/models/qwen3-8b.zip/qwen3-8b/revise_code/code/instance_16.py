import os
import sys
from gurobipy import GRB, Model

# Add parent directory to path
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

def load_monthly_data(filepath):
    """Load monthly purchasing and selling price data."""
    months = []
    purchasing_prices = {}
    selling_prices = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            month = int(row['Month'])
            months.append(month)
            purchasing_prices[month] = float(row['Purchasing_Price_Yuan'])
            selling_prices[month] = float(row['Selling_Price_Yuan'])
    
    return months, purchasing_prices, selling_prices

def load_general_parameters(filepath):
    """Load general parameters."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

# Load data
data_dir = os.path.join(script_dir, '..', 'data')
months, purchasing_prices, selling_prices = load_monthly_data(os.path.join(data_dir, 'table_1.csv'))
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params['fixed_ordering_cost']
month2_bulk_receiving_threshold = params['month2_bulk_receiving_threshold']
month2_bulk_receiving_fee = params['month2_bulk_receiving_fee']

# Create the LP problem
prob = Model("Maximize_Profit")

# Decision variables
# x[m] = units purchased at the beginning of month m
# s[m] = units sold during month m
x = {m: prob.addVar(lb=0, name=f"purchase_{m}") for m in months}
s = {m: prob.addVar(lb=0, name=f"sell_{m}") for m in months}

# Inventory at the end of each month (auxiliary variables)
# inv[m] = inventory at end of month m
inv = {m: prob.addVar(lb=0, name=f"inventory_{m}") for m in months}

# Fixed ordering cost indicator variable for each month
fixed_cost = {m: prob.addVar(vtype=GRB.BINARY, name=f"fixed_cost_{m}") for m in months}

# Objective: maximize total profit = sum of (selling revenue - purchasing cost) - fixed ordering costs
profit = 0
for m in months:
    profit += selling_prices[m] * s[m] - purchasing_prices[m] * x[m]
    profit -= fixed_ordering_cost * fixed_cost[m]

prob.setObjective(profit, GRB.MAXIMIZE)

# Constraints
for m in months:
    # Inventory balance: inv[m] = inv[m-1] + x[m] - s[m]
    if m == months[0]:
        prev_inv = initial_stock
    else:
        prev_inv = inv[m - 1]
    
    prob.addConstr(inv[m] == prev_inv + x[m] - s[m], f"inventory_balance_{m}")
    
    # Warehouse capacity constraint: inventory after purchasing (before selling) <= warehouse_capacity
    # At the beginning of month m, we purchase x[m], so stock becomes prev_inv + x[m]
    # This must not exceed warehouse capacity
    prob.addConstr(prev_inv + x[m] <= warehouse_capacity, f"warehouse_after_purchase_{m}")
    
    # End-of-month inventory also cannot exceed warehouse capacity
    prob.addConstr(inv[m] <= warehouse_capacity, f"warehouse_end_{m}")
    
    # Can't sell more than what's available (prev_inv + x[m])
    prob.addConstr(s[m] <= prev_inv + x[m], f"sell_limit_{m}")

    # Fixed ordering cost constraint: if any units are purchased, then fixed cost is incurred
    prob.addConstr(x[m] >= 0.0001 * fixed_cost[m], f"fixed_cost_constraint_{m}")

# Special constraint for February (month 2)
# If purchase volume exceeds threshold, add bulk receiving fee
prob.addConstr(x[2] <= month2_bulk_receiving_threshold + (warehouse_capacity - month2_bulk_receiving_threshold) * fixed_cost[2], f"bulk_receiving_threshold_{2}")
prob.addConstr(x[2] >= month2_bulk_receiving_threshold + 1e-6 * fixed_cost[2], f"bulk_receiving_threshold_lower_{2}")
prob.addConstr(prob.getVarByName("fixed_cost_2") * month2_bulk_receiving_fee, GRB.LESS_EQUAL, prob.getVarByName("fixed_cost_2") * month2_bulk_receiving_fee, f"bulk_receiving_fee_{2}")

# Solve
prob.setParam('OutputFlag', 0)
prob.optimize()

# Print results
for m in months:
    print(f"Month {m}: Purchase = {x[m].x}, Sell = {s[m].x}, End Inventory = {inv[m].x}")

obj_val = prob.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
