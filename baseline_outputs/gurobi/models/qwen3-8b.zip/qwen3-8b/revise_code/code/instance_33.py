import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
general_params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        general_params[row["Parameter_Name"]] = float(row["Value"])

num_diamonds = general_params["num_diamonds"]
value_per_diamond = general_params["value_per_diamond"]
num_jack_russell_dogs = general_params["num_jack_russell_dogs"]
value_per_jack_russell_dog = general_params["value_per_jack_russell_dog"]
son1_min_share = general_params["son1_min_share"]
high_value_threshold = general_params["high_value_threshold"]
max_high_value_items_per_son = general_params["max_high_value_items_per_son"]
deferred_diamonds_per_son = general_params["deferred_diamonds_per_son"]
immediate_tax_weight = general_params["immediate_tax_weight"]
total_tax_weight = general_params["total_tax_weight"]

# Read items and values
items = []
values = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        items.append(row["Item"].strip())
        values.append(int(row["Value"].strip()))

n = len(items)
total_value = sum(values)

# Create the optimization model
model = gp.Model("Inheritance_Split")

# Binary variables: x[i] = 1 if item i goes to son 1, 0 if to son 2
x = [model.addVar(vtype=GRB.BINARY, name=f"x_{i}") for i in range(n)]

# Binary variables for deferred diamonds
d = [model.addVar(vtype=GRB.BINARY, name=f"d_{i}") for i in range(n)]

# Binary variables for high-value items
h = [model.addVar(vtype=GRB.BINARY, name=f"h_{i}") for i in range(n)]

# Immediate value for son 1
value_son1 = sum(values[i] * x[i] for i in range(n))

# Deferred value for son 1
deferred_value_son1 = sum(values[i] * d[i] for i in range(n))

# Total value for son 1
total_value_son1 = value_son1 + deferred_value_son1

# Immediate value for son 2
value_son2 = sum(values[i] * (1 - x[i]) for i in range(n))

# Deferred value for son 2
deferred_value_son2 = sum(values[i] * (1 - d[i]) for i in range(n))

# Total value for son 2
total_value_son2 = value_son2 + deferred_value_son2

# Objective function: minimize weighted difference
obj = immediate_tax_weight * abs(value_son1 - value_son2) + total_tax_weight * abs(total_value_son1 - total_value_son2)
model.setObjective(obj, GRB.MINIMIZE)

# Constraint: son1 must receive at least son1_min_share of total value
model.addConstr(total_value_son1 >= son1_min_share * total_value)

# Constraint: Jack Russell racing dogs must not be separated
jr_indices = [i for i, item in enumerate(items) if 'Jack Russell' in item]
if len(jr_indices) == 2:
    model.addConstr(x[jr_indices[0]] == x[jr_indices[1]])

# Constraint: High-value items cannot exceed max_high_value_items_per_son per son
for son in [1, 2]:
    high_value_count_son = sum(h[i] * son for i in range(n)) if son == 1 else sum(h[i] * (1 - son) for i in range(n))
    model.addConstr(high_value_count_son <= max_high_value_items_per_son)

# Constraint: Deferred diamonds per son
for son in [1, 2]:
    deferred_diamonds_count_son = sum(d[i] * son for i in range(n)) if son == 1 else sum(d[i] * (1 - son) for i in range(n))
    model.addConstr(deferred_diamonds_count_son <= deferred_diamonds_per_son)

# Constraint: High-value threshold
for i in range(n):
    model.addConstr(h[i] >= 0)
    model.addConstr(h[i] <= 1)
    model.addConstr(h[i] == 1 if values[i] > high_value_threshold else 0)

# Solve the model
model.Params.OutputFlag = 0
model.optimize()

# Print solution details
print("Status:", model.Status)
print(f"Total inheritance value: {total_value}")
print()

son1_items = []
son2_items = []
son1_val = 0
son2_val = 0
son1_deferred_val = 0
son2_deferred_val = 0
son1_high_val = 0
son2_high_val = 0

for i in range(n):
    if x[i].X > 0.5:
        son1_items.append((items[i], values[i]))
        son1_val += values[i]
    else:
        son2_items.append((items[i], values[i]))
        son2_val += values[i]

    if d[i].X > 0.5:
        son1_deferred_val += values[i]
    else:
        son2_deferred_val += values[i]

    if h[i].X > 0.5:
        son1_high_val += values[i]
    else:
        son2_high_val += values[i]

print("Son 1 receives:")
for item, val in son1_items:
    print(f"  {item}: {val}")
print(f"  Immediate Value: {son1_val}")
print(f"  Deferred Value: {son1_deferred_val}")
print(f"  High-Value Items: {son1_high_val}")
print(f"  Total: {son1_val + son1_deferred_val}")
print()
print("Son 2 receives:")
for item, val in son2_items:
    print(f"  {item}: {val}")
print(f"  Immediate Value: {son2_val}")
print(f"  Deferred Value: {son2_deferred_val}")
print(f"  High-Value Items: {son2_high_val}")
print(f"  Total: {son2_val + son2_deferred_val}")
print()
print(f"Difference (Immediate): {abs(son1_val - son2_val)}")
print(f"Difference (Total): {abs(son1_val + son1_deferred_val - son2_val - son2_deferred_val)}")
print(f"OBJECTIVE_VALUE: {model.ObjVal}")

FINAL_OBJ_VALUE: 14000.0
