import os
import csv
from utils import load_parameters

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
cow_price = params['cow_selling_price']
sheep_price = params['sheep_selling_price']
chicken_price = params['chicken_selling_price']
cow_feed = params['cow_feed_cost']
sheep_feed = params['sheep_feed_cost']
chicken_feed = params['chicken_feed_cost']
cow_manure = params['cow_manure_production']
sheep_manure = params['sheep_manure_production']
chicken_manure = params['chicken_manure_production']
max_manure = params['max_manure_capacity']
max_chickens = params['max_chickens']
min_cows = params['min_cows']
min_sheep = params['min_sheep']
max_total = params['max_total_animals']
premium_capacity_multiplier = params['premium_capacity_multiplier']
premium_manure_multiplier = params['premium_manure_multiplier']
expansion_cost = params['expansion_cost']
premium_feed_multiplier = params['premium_feed_multiplier']
base_land_usage_cow = params['base_land_usage_cow']
base_land_usage_sheep = params['base_land_usage_sheep']
base_land_usage_chicken = params['base_land_usage_chicken']
base_land_capacity = params['base_land_capacity']
expansion_land_increase = params['expansion_land_increase']

# Create model
model = gp.Model("FarmProfit")
model.setParam('OutputFlag', 0)

# Decision variables
cows = model.addVar(lb=min_cows, vtype=gp.GRB.INTEGER, name="cows")
sheep = model.addVar(lb=min_sheep, vtype=gp.GRB.INTEGER, name="sheep")
chickens = model.addVar(lb=0, ub=max_chickens, vtype=gp.GRB.INTEGER, name="chickens")
expanded = model.addVar(vtype=gp.GRB.BINARY, name="expanded")

# Objective: maximize profit
profit = (cow_price - cow_feed * premium_feed_multiplier if expanded else cow_price - cow_feed) * cows + \
         (sheep_price - sheep_feed * premium_feed_multiplier if expanded else sheep_price - sheep_feed) * sheep + \
         (chicken_price - chicken_feed * premium_feed_multiplier if expanded else chicken_price - chicken_feed) * chickens - expansion_cost * expanded
model.setObjective(profit, gp.GRB.MAXIMIZE)

# Constraints
# Manure capacity
manure_capacity = cow_manure * cows + sheep_manure * sheep + chicken_manure * chickens
if expanded:
    manure_capacity *= premium_manure_multiplier
model.addConstr(manure_capacity <= max_manure, "ManureCapacity")

# Land capacity
land_capacity = base_land_usage_cow * cows + base_land_usage_sheep * sheep + base_land_usage_chicken * chickens
if expanded:
    land_capacity += expansion_land_increase
model.addConstr(land_capacity <= base_land_capacity + expansion_land_increase, "LandCapacity")

# Total animals
model.addConstr(cows + sheep + chickens <= max_total * (1 + (expanded - 1) * (premium_capacity_multiplier - 1)), "TotalAnimals")

# Solve
model.optimize()

# Print results
print(f"Cows: {cows.x}")
print(f"Sheep: {sheep.x}")
print(f"Chickens: {chickens.x}")
print(f"Expanded: {expanded.x}")
print(f"OBJECTIVE_VALUE: {model.objVal}")

FINAL_OBJ_VALUE: 45800.0
