import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv")) as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    precedences = []
    with open(os.path.join(data_dir, "table_1.csv")) as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))

    activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    dur = {a: int(params[f'activity_{a}_duration']) for a in activities}
    work_cost = params['work_cost_per_day']
    machine_cost = params['machine_rental_cost_per_day']
    e_overtime_reduction = params['activity_E_overtime_reduction']
    e_overtime_cost = params['activity_E_overtime_cost']
    e_followup_review_trigger = params['activity_E_followup_review_trigger']
    e_followup_review_cost = params['activity_E_followup_review_cost']

    model = gp.Model("Project_Cost_Minimization")
    model.setParam('OutputFlag', 0)

    S = {a: model.addVar(lb=0, name=f'S_{a}') for a in activities}
    T = model.addVar(lb=0, name='T')
    E_overtime = model.addVar(vtype=GRB.BINARY, name='E_overtime')

    # Objective function
    model.setObjective(
        work_cost * T +
        machine_cost * (S['B'] + dur['B'] - S['A']) +
        e_overtime_cost * E_overtime +
        e_followup_review_cost * E_overtime,
        GRB.MINIMIZE
    )

    # Precedence constraints
    for pred, succ in precedences:
        model.addConstr(S[succ] >= S[pred] + dur[pred])

    # Activity E overtime constraint
    model.addConstr(S['E'] + dur['E'] - e_overtime_reduction <= S['F'] + dur['F'] - S['E'])
    model.addConstr(S['E'] + dur['E'] - e_overtime_reduction <= S['G'] + dur['G'] - S['E'])
    model.addConstr(S['E'] + dur['E'] - e_overtime_reduction <= S['D'] + dur['D'] - S['E'])

    # Time to completion
    model.addConstr(T >= S['C'] + dur['C'])
    model.addConstr(T >= S['B'] + dur['B'])

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.objVal}")

solve()
