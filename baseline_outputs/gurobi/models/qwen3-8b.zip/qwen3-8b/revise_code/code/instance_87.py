import os
import sys
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value

    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    base_fleet_a = params['base_fleet_type_a']
    base_fleet_b = params['base_fleet_type_b']
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    type_b_threshold = params['type_b_recovery_threshold']
    type_b_fee = params['type_b_recovery_fee']
    total_threshold = params['total_fleet_surge_threshold']
    total_fee = params['total_fleet_surge_fee']

    model = gp.Model("TruckRental")

    x = model.addVar(lb=0, vtype=GRB.INTEGER, name="TypeA_trucks")
    y = model.addVar(lb=0, vtype=GRB.INTEGER, name="TypeB_trucks")

    model.setObjective(
        cost_a * x + cost_b * y +
        (max(0, x - base_fleet_a) * penalty_a) +
        (max(0, y - base_fleet_b) * penalty_b),
        GRB.MINIMIZE
    )

    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedRequirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedRequirement")
    model.addConstr(x + y >= type_b_threshold, "TypeBThreshold")
    model.addConstr(x + y >= total_threshold, "TotalThreshold")

    if x + y > type_b_threshold:
        model.addConstr(gp.LinExpr(y) * type_b_fee, name="TypeBFee")
    if x + y > total_threshold:
        model.addConstr(total_fee, name="TotalFee")

    model.setParam('OutputFlag', 0)
    model.optimize()

    obj_val = model.objVal
    print(f"Type A trucks: {int(x.x)}")
    print(f"Type B trucks: {int(y.x)}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    import csv
    main()
