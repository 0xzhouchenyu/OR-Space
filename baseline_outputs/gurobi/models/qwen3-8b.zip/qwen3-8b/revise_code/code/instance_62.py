import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_restaurant_data, load_general_parameters

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, '..', 'data')
    
    restaurants = load_restaurant_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    investment_budget = params['investment_budget']
    premium_revenue_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']
    
    model = gp.Model("Restaurant_Investment")
    
    # Decision variables: binary (buy or not)
    x = {}
    for r in restaurants:
        x[r['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{r['name']}")
    
    # Binary variable for Premium operation
    y = {}
    for r in restaurants:
        y[r['name']] = model.addVar(vtype=GRB.BINARY, name=f"y_{r['name']}")
    
    # Objective: maximize total annual revenue
    total_revenue = 0
    for r in restaurants:
        base_revenue = r['Annual_Revenue']
        uplifted_revenue = base_revenue * (1 + premium_revenue_uplift)
        total_revenue += (base_revenue + (uplifted_revenue - base_revenue) * y[r['name']]) * x[r['name']]
    model.setObjective(total_revenue, GRB.MAXIMIZE)
    
    # Budget constraint: purchase cost + upgrade cost
    model.addConstr(gp.quicksum((r['Cost'] + premium_upgrade_cost) * x[r['name']] for r in restaurants) <= investment_budget, "Budget_Constraint")
    
    # Staff hours constraint: sum of premium staff hours for purchased restaurants
    model.addConstr(gp.quicksum(r['Premium_Staff_Hours'] * x[r['name']] * y[r['name']] for r in restaurants) <= staff_hours_cap, "Staff_Hours_Constraint")
    
    # If Restaurant D is purchased, Restaurant A cannot be purchased
    if 'Restaurant_D' in x and 'Restaurant_A' in x:
        model.addConstr(x['Restaurant_D'] + x['Restaurant_A'] <= 1, "D_A_Exclusion_Constraint")
    
    # Link y to x: can only operate in Premium if the restaurant is purchased
    for r in restaurants:
        model.addConstr(y[r['name']] <= x[r['name']], f"Premium_Link_{r['name']}")
    
    # Solve
    model.setParam('OutputFlag', 0)
    model.optimize()
    
    # Print results
    print(f"Status: {model.Status}")
    for r in restaurants:
        val_x = x[r['name']].x
        val_y = y[r['name']].x
        print(f"{r['name']}: {'Buy' if val_x > 0.5 else 'Do not buy'} (x={val_x}, y={val_y})")
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
