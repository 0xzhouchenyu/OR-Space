import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Extract parameters
min_A_I = params["min_proportion_crude_A_type_I"] / 100.0  # 0.50
min_A_II = params["min_proportion_crude_A_type_II"] / 100.0  # 0.60
price_I = params["selling_price_type_I"]  # 4800
price_II = params["selling_price_type_II"]  # 5600
inv_A = params["inventory_crude_A"]  # 500
inv_B = params["inventory_crude_B"]  # 1000
max_purchase_A = params["max_purchase_crude_A"]  # 1500
cost_tier1 = params["market_price_crude_A_tier_1"]  # 10000
cost_tier2 = params["market_price_crude_A_tier_2"]  # 8000
cost_tier3 = params["market_price_crude_A_tier_3"]  # 6000
processing_capacity = params["processing_capacity"]  # 2500
min_total_output = params["min_total_gasoline_output"]  # 1500
processing_cost_per_ton = params["processing_cost_per_ton"]  # 500
type_II_contract_threshold = params["type_II_contract_threshold"]  # 900
type_II_price_lift = params["type_II_price_lift"]  # 300
bulk_purchase_rebate_threshold = params["bulk_purchase_rebate_threshold"]  # 1000
bulk_purchase_rebate = params["bulk_purchase_rebate"]  # 200000

# Create model
model = gp.Model("Oil_Blending")
model.setParam("OutputFlag", 0)

# Decision variables
a1 = model.addVar(lb=0, name="crude_A_in_I")  # crude A -> gasoline I
a2 = model.addVar(lb=0, name="crude_A_in_II")  # crude A -> gasoline II
b1 = model.addVar(lb=0, name="crude_B_in_I")  # crude B -> gasoline I
b2 = model.addVar(lb=0, name="crude_B_in_II")  # crude B -> gasoline II

# Tiered purchase variables for crude A
p1 = model.addVar(lb=0, ub=500, name="purchase_tier1")   # first 500t
p2 = model.addVar(lb=0, ub=500, name="purchase_tier2")   # next 500t
p3 = model.addVar(lb=0, ub=500, name="purchase_tier3")   # last 500t

# Binary variables to enforce tiered ordering
y1 = model.addVar(vtype=GRB.BINARY, name="y1")  # 1 if tier1 is fully used
y2 = model.addVar(vtype=GRB.BINARY, name="y2")  # 1 if tier2 is fully used

# Tiered ordering constraints
model.add(p1 <= 500)
model.add(p2 <= 500 * y1)
model.add(p3 <= 500 * y2)
model.add(p1 >= 500 * y1)
model.add(p2 >= 500 * y2)

# Total crude A available = inventory + purchased
total_A_purchased = p1 + p2 + p3
model.add(a1 + a2 <= inv_A + total_A_purchased)  # crude A supply
model.add(b1 + b2 <= inv_B)  # crude B supply

# Blending constraints (minimum proportion of crude A)
# For gasoline I: a1 / (a1 + b1) >= 0.5 => a1 >= 0.5*(a1+b1) => a1 - b1 >= 0
model.add(a1 >= min_A_I * (a1 + b1))
# For gasoline II: a2 / (a2 + b2) >= 0.6
model.add(a2 >= min_A_II * (a2 + b2))

# Output constraints
output_I = a1 + b1
output_II = a2 + b2
model.add(output_I + output_II <= processing_capacity)
model.add(output_I + output_II >= min_total_output)

# Type II price lift constraint
model.add(gp.quicksum(output_II >= type_II_contract_threshold) * type_II_price_lift)

# Bulk purchase rebate constraint
model.add(gp.quicksum(total_A_purchased >= bulk_purchase_rebate_threshold) * bulk_purchase_rebate)

# Revenue and cost calculation
revenue = price_I * output_I + price_II * output_II
cost = cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3 + processing_cost_per_ton * (output_I + output_II)

# Objective: maximize revenue - cost
model.setObjective(revenue - cost, GRB.MAXIMIZE)

# Solve the model
model.optimize()

# Print results
print(f"Status: {model.Status}")
print(f"Purchase tier1: {p1.x}, tier2: {p2.x}, tier3: {p3.x}")
print(f"A in I: {a1.x}, B in I: {b1.x}")
print(f"A in II: {a2.x}, B in II: {b2.x}")
print(f"OBJECTIVE_VALUE: {model.objVal}")

FINAL_OBJ_VALUE: 12700000.0
