import gurobipy as gp
from gurobipy import GRB
import os
import sys
import csv

def load_processing_times(filepath):
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times

def load_general_parameters(filepath):
    parameters = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            parameters[row[0]] = float(row[1])
    return parameters

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    processing_times = load_processing_times(os.path.join(data_dir, "table_1.csv"))
    general_params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

    n_products = len(processing_times)
    n_machines = len(processing_times[0])

    t_ij = [[processing_times[i][j] for j in range(n_machines)] for i in range(n_products)]
    time_window = [general_params[f"time_window_{i+1}"] for i in range(n_machines)]
    overtime_window = [general_params[f"overtime_window_{i+1}"] for i in range(n_machines)]
    overtime_penalty_per_unit = general_params["overtime_penalty_per_unit"]
    M = [general_params[f"M_{i+1}"] for i in range(n_machines)]
    machine1_overtime_review_threshold = general_params["machine1_overtime_review_threshold"]
    machine1_overtime_review_fee = general_params["machine1_overtime_review_fee"]

    model = gp.Model("FlowShopScheduling")

    # Decision variables
    x = {}
    for i in range(n_products):
        for j in range(n_machines):
            x[i, j] = model.addVar(vtype=GRB.INTEGER, name=f"x_{i}_{j}")

    y = {}
    for i in range(n_products):
        for j in range(n_machines):
            y[i, j] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{j}")

    # Objective function
    obj = 0
    for i in range(n_products):
        for j in range(n_machines):
            obj += t_ij[i][j] * y[i, j]
    for i in range(n_products):
        for j in range(n_machines):
            obj += overtime_penalty_per_unit * (x[i, j] - time_window[j]) * y[i, j]
    for i in range(n_products):
        if i == 0:
            obj += machine1_overtime_review_fee * max(0, x[i, 0] - time_window[0] - machine1_overtime_review_threshold) * y[i, 0]
        else:
            obj += machine1_overtime_review_fee * max(0, x[i, 0] - time_window[0] - machine1_overtime_review_threshold) * y[i, 0]

    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    for i in range(n_products):
        for j in range(n_machines):
            model.addConstr(x[i, j] >= t_ij[i][j] * y[i, j], f"ProcessingTime_{i}_{j}")
            model.addConstr(x[i, j] <= (time_window[j] + overtime_window[j]) * y[i, j], f"OvertimeLimit_{i}_{j}")

    for i in range(n_products):
        for j in range(1, n_machines):
            model.addConstr(x[i, j] >= x[i, j-1] + t_ij[i][j-1] * y[i, j-1], f"MachineOrder_{i}_{j}")

    for i in range(n_products):
        for j in range(n_machines):
            model.addConstr(x[i, j] <= M[j] * y[i, j], f"BigMConstraint_{i}_{j}")

    for i in range(n_products):
        model.addConstr(sum(y[i, j] for j in range(n_machines)) == 1, f"JobCompletion_{i}")

    for j in range(n_machines):
        model.addConstr(sum(y[i, j] for i in range(n_products)) == 1, f"MachineUsage_{j}")

    model.setParam('OutputFlag', 0)
    model.optimize()

    final_obj_value = model.objVal
    print(f"FINAL_OBJ_VALUE: {final_obj_value}")

if __name__ == "__main__":
    main()
