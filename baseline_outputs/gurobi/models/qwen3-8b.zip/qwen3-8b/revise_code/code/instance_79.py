import os
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

# Extract parameters
sell_price_table = params["sell_price_table"]
sell_price_chair = params["sell_price_chair"]
sell_price_bookshelf = params["sell_price_bookshelf"]

manufacturing_cost_table = params["manufacturing_cost_table"]
manufacturing_cost_chair = params["manufacturing_cost_chair"]
manufacturing_cost_bookshelf = params["manufacturing_cost_bookshelf"]

warehouse_space_table = params["warehouse_space_table"]
warehouse_space_chair = params["warehouse_space_chair"]
warehouse_space_bookshelf = params["warehouse_space_bookshelf"]

max_warehouse_space = params["max_warehouse_space"]
min_tables = params["min_tables"]
min_bookshelves = params["min_bookshelves"]
max_total_items = params["max_total_items"]

labor_hours_table = params["labor_hours_table"]
labor_hours_chair = params["labor_hours_chair"]
labor_hours_bookshelf = params["labor_hours_bookshelf"]

max_labor_hours_month_regular = params["max_labor_hours_month_regular"]
max_labor_hours_month_rush = params["max_labor_hours_month_rush"]
max_rush_items_month = params["max_rush_items_month"]

rush_profit_bonus_table = params["rush_profit_bonus_table"]
rush_profit_bonus_chair = params["rush_profit_bonus_chair"]
rush_profit_bonus_bookshelf = params["rush_profit_bonus_bookshelf"]

# Profit per item (regular)
profit_table = sell_price_table - manufacturing_cost_table
profit_chair = sell_price_chair - manufacturing_cost_chair
profit_bookshelf = sell_price_bookshelf - manufacturing_cost_bookshelf

# Profit per item (rush)
rush_profit_table = profit_table + rush_profit_bonus_table
rush_profit_chair = profit_chair + rush_profit_bonus_chair
rush_profit_bookshelf = profit_bookshelf + rush_profit_bonus_bookshelf

# Create model
model = gp.Model("Furniture_Production")

# Decision variables
x_tables_reg = model.addVar(lb=0, vtype=GRB.INTEGER, name="tables_reg")
x_chairs_reg = model.addVar(lb=0, vtype=GRB.INTEGER, name="chairs_reg")
x_bookshelves_reg = model.addVar(lb=0, vtype=GRB.INTEGER, name="bookshelves_reg")

x_tables_rush = model.addVar(lb=0, vtype=GRB.INTEGER, name="tables_rush")
x_chairs_rush = model.addVar(lb=0, vtype=GRB.INTEGER, name="chairs_rush")
x_bookshelves_rush = model.addVar(lb=0, vtype=GRB.INTEGER, name="bookshelves_rush")

# Objective: maximize total profit
model.setObjective(
    (profit_table * x_tables_reg + rush_profit_table * x_tables_rush) +
    (profit_chair * x_chairs_reg + rush_profit_chair * x_chairs_rush) +
    (profit_bookshelf * x_bookshelves_reg + rush_profit_bookshelf * x_bookshelves_rush),
    GRB.MAXIMIZE
)

# Constraints
# Warehouse space constraint
model.addConstr(
    warehouse_space_table * (x_tables_reg + x_tables_rush) +
    warehouse_space_chair * (x_chairs_reg + x_chairs_rush) +
    warehouse_space_bookshelf * (x_bookshelves_reg + x_bookshelves_rush) <= max_warehouse_space,
    "Warehouse_Space"
)

# Minimum production requirements
model.addConstr(x_tables_reg + x_tables_rush >= min_tables, "Min_Tables")
model.addConstr(x_bookshelves_reg + x_bookshelves_rush >= min_bookshelves, "Min_Bookshelves")

# Maximum total production
model.addConstr(
    (x_tables_reg + x_tables_rush) + (x_chairs_reg + x_chairs_rush) + (x_bookshelves_reg + x_bookshelves_rush) <= max_total_items,
    "Max_Total_Items"
)

# Regular labor hours constraint
model.addConstr(
    labor_hours_table * (x_tables_reg) + labor_hours_chair * (x_chairs_reg) + labor_hours_bookshelf * (x_bookshelves_reg) <= max_labor_hours_month_regular,
    "Regular_Labor_Hours"
)

# Rush labor hours constraint
model.addConstr(
    labor_hours_table * (x_tables_rush) + labor_hours_chair * (x_chairs_rush) + labor_hours_bookshelf * (x_bookshelves_rush) <= max_labor_hours_month_rush,
    "Rush_Labor_Hours"
)

# Maximum rush items constraint
model.addConstr(
    (x_tables_rush + x_chairs_rush + x_bookshelves_rush) <= max_rush_items_month,
    "Max_Rush_Items"
)

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Output results
print(f"Status: {model.Status}")
print(f"Regular Tables: {int(x_tables_reg.x)}")
print(f"Rush Tables: {int(x_tables_rush.x)}")
print(f"Regular Chairs: {int(x_chairs_reg.x)}")
print(f"Rush Chairs: {int(x_chairs_rush.x)}")
print(f"Regular Bookshelves: {int(x_bookshelves_reg.x)}")
print(f"Rush Bookshelves: {int(x_bookshelves_rush.x)}")
obj_val = model.ObjVal
print(f"OBJECTIVE_VALUE: {obj_val}")

print("FINAL_OBJ_VALUE: " + str(obj_val))
