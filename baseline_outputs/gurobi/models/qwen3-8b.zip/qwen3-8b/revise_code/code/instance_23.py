import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'name': row['Product Name'].strip(),
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            })
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    available_labor = params['available_labor']
    available_material = params['available_material']
    fixed_costs = [params['fixed_cost_shirts'], params['fixed_cost_short_sleeves'], params['fixed_cost_casual_clothes']]
    
    segment_regular_discount = params['segment_regular_discount']
    segment_promo_discount = params['segment_promo_discount']
    segment_promo_labor_cap = params['segment_promo_labor_cap']
    segment_promo_material_cap = params['segment_promo_material_cap']
    
    min_batch_shirts = params['min_batch_shirts']
    min_batch_short_sleeves = params['min_batch_short_sleeves']
    min_batch_casual_clothes = params['min_batch_casual_clothes']
    
    max_prod_shirts = params['max_prod_shirts']
    max_prod_short_sleeves = params['max_prod_short_sleeves']
    max_prod_casual_clothes = params['max_prod_casual_clothes']
    
    # Create model
    model = gp.Model("clothing_production")
    model.setParam('OutputFlag', 0)
    
    n = len(products)
    
    # Decision variables
    x = [model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{i}") for i in range(n)]
    y = [model.addVar(lb=0, vtype=GRB.BINARY, name=f"y_{i}") for i in range(n)]  # 1 if equipment is activated
    
    # Objective function: maximize profit
    total_profit = 0
    
    for i in range(n):
        # Regular segment contribution
        regular_profit = (products[i]['price'] * segment_regular_discount - products[i]['var_cost']) * x[i]
        
        # Promotional segment contribution
        promo_profit = (products[i]['price'] * segment_promo_discount - products[i]['var_cost']) * x[i]
        
        total_profit += regular_profit + promo_profit
    
    # Subtract fixed costs only if equipment is activated
    for i in range(n):
        total_profit -= fixed_costs[i] * y[i]
    
    model.setObjective(total_profit, GRB.MAXIMIZE)
    
    # Constraints
    # Labor constraint
    labor_constr = model.addConstr(gp.quicksum(products[i]['labor'] * x[i] for i in range(n)) <= available_labor, "labor")
    
    # Material constraint
    material_constr = model.addConstr(gp.quicksum(products[i]['material'] * x[i] for i in range(n)) <= available_material, "material")
    
    # Promotional labor constraint
    promo_labor_constr = model.addConstr(gp.quicksum(products[i]['labor'] * x[i] for i in range(n)) <= segment_promo_labor_cap + (available_labor - segment_promo_labor_cap) * (1 - y[0]), "promo_labor")
    
    # Promotional material constraint
    promo_material_constr = model.addConstr(gp.quicksum(products[i]['material'] * x[i] for i in range(n)) <= segment_promo_material_cap + (available_material - segment_promo_material_cap) * (1 - y[0]), "promo_material")
    
    # Minimum batch constraints
    min_batch_shirts_constr = model.addConstr(x[0] >= min_batch_shirts * y[0], "min_batch_shirts")
    min_batch_short_sleeves_constr = model.addConstr(x[1] >= min_batch_short_sleeves * y[1], "min_batch_short_sleeves")
    min_batch_casual_clothes_constr = model.addConstr(x[2] >= min_batch_casual_clothes * y[2], "min_batch_casual_clothes")
    
    # Maximum production constraints
    max_prod_shirts_constr = model.addConstr(x[0] <= max_prod_shirts * y[0], "max_prod_shirts")
    max_prod_short_sleeves_constr = model.addConstr(x[1] <= max_prod_short_sleeves * y[1], "max_prod_short_sleeves")
    max_prod_casual_clothes_constr = model.addConstr(x[2] <= max_prod_casual_clothes * y[2], "max_prod_casual_clothes")
    
    # Solve the model
    model.optimize()
    
    # Print results
    for i in range(n):
        print(f"{products[i]['name']}: {x[i].x}")
    
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
