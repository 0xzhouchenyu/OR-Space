import os
import csv
from gurobipy import Model, GRB, quicksum

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

initial_fund = params["initial_fund"]  # 300000
annual_rate = params["annual_profit_rate"] / 100  # 0.20
inv_limit_y1 = params["investment_limit_year1"]  # 150000
return_rate_y1y2 = params["return_rate_year1_to_year2"] / 100  # 1.50
inv_limit_y2 = params["investment_limit_year2"]  # 200000
return_rate_y2y3 = params["return_rate_year2_to_year3"] / 100  # 1.60
inv_limit_y3 = params["investment_limit_year3"]  # 100000
profit_rate_y3 = params["profit_rate_year3"] / 100  # 0.40
fee_y1 = params["fee_year1"]  # 10000
fee_y2 = params["fee_year2"]  # 12000
fee_y3 = params["fee_year3"]  # 5000

# Create model
model = Model("Investment_Optimization")

# Decision variables
a1 = model.addVar(lb=0, name="a1")  # annual investment year 1
b1 = model.addVar(lb=0, ub=inv_limit_y1, name="b1")  # special investment year 1
a2 = model.addVar(lb=0, name="a2")  # annual investment year 2
c2 = model.addVar(lb=0, ub=inv_limit_y2, name="c2")  # special investment year 2
a3 = model.addVar(lb=0, name="a3")  # annual investment year 3
d3 = model.addVar(lb=0, ub=inv_limit_y3, name="d3")  # special investment year 3

# Binary variables for fixed fees
y1 = model.addVar(vtype=GRB.BINARY, name="y1")
y2 = model.addVar(vtype=GRB.BINARY, name="y2")
y3 = model.addVar(vtype=GRB.BINARY, name="y3")

# Budget constraint at beginning of Year 1
model.addConstr(a1 + b1 <= initial_fund, "Year1_budget")

# Budget constraint at beginning of Year 2
model.addConstr(
    a2 + c2 <= (initial_fund - a1 - b1) + a1 * (1 + annual_rate), "Year2_budget"
)

# Budget constraint at beginning of Year 3
model.addConstr(
    a3 + d3 <= (
        (initial_fund - a1 - b1) + a1 * (1 + annual_rate) - a2 - c2
        + a2 * (1 + annual_rate) + b1 * return_rate_y1y2
    ), "Year3_budget"
)

# Objective: total funds at end of year 3 minus management fees
cash_year3 = (
    (initial_fund - a1 - b1) + a1 * (1 + annual_rate) - a2 - c2
    + a2 * (1 + annual_rate) + b1 * return_rate_y1y2 - a3 - d3
)
total_end = (
    cash_year3
    + a3 * (1 + annual_rate)
    + c2 * return_rate_y2y3
    + d3 * (1 + profit_rate_y3)
    - fee_y1 * y1
    - fee_y2 * y2
    - fee_y3 * y3
)
model.setObjective(total_end, GRB.MAXIMIZE)

# Link binary variables with special investments
model.addConstr(b1 <= inv_limit_y1 * y1, "b1_link")
model.addConstr(c2 <= inv_limit_y2 * y2, "c2_link")
model.addConstr(d3 <= inv_limit_y3 * y3, "d3_link")

# Solve model
model.Params.OutputFlag = 0
model.optimize()

# Print results
print(f"Status: {model.Status}")
print(f"a1={a1.X}, b1={b1.X}, a2={a2.X}, c2={c2.X}, a3={a3.X}, d3={d3.X}")
print(f"y1={y1.X}, y2={y2.X}, y3={y3.X}")
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
