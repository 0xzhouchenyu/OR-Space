import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read device data
devices = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            'name': row['Device'].strip(),
            'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
            'max_cap': float(row['Max_Processing_Capacity_Units'].strip())
        })

# Read general parameters
general_params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        general_params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

required_units = general_params['required_units']
energy_budget_peak = general_params['energy_budget_peak']
energy_budget_offpeak = general_params['energy_budget_offpeak']
startup_budget = general_params['startup_budget']
energy_price_peak = general_params['energy_price_peak']
energy_price_offpeak = general_params['energy_price_offpeak']

# Extract energy per unit and startup energy
energy_per_unit = {
    'A': general_params['energy_per_unit_A'],
    'B': general_params['energy_per_unit_B'],
    'C': general_params['energy_per_unit_C'],
    'D': general_params['energy_per_unit_D']
}
startup_energy = {
    'A': general_params['startup_energy_A'],
    'B': general_params['startup_energy_B'],
    'C': general_params['startup_energy_C'],
    'D': general_params['startup_energy_D']
}

# Create the optimization model
model = gp.Model("MinCostProduction")

n = len(devices)

# Decision variables
x = [model.addVar(lb=0, ub=devices[i]['max_cap'], vtype=GRB.CONTINUOUS, name=f"x_{devices[i]['name']}") for i in range(n)]
y = [model.addVar(vtype=GRB.BINARY, name=f"y_{devices[i]['name']}") for i in range(n)]
z = [model.addVar(vtype=GRB.BINARY, name=f"z_{devices[i]['name']}") for i in range(n)]  # z_i: 1 if device i is used in peak period, 0 otherwise

# Objective: minimize total cost = sum of (prep_cost * y_i + unit_cost * x_i) + startup_cost * z_i + energy_cost
total_cost = 0
for i in range(n):
    total_cost += devices[i]['prep_cost'] * y[i] + devices[i]['unit_cost'] * x[i] + general_params['startup_cost'] * z[i]

# Energy cost calculation
energy_cost = 0
for i in range(n):
    # Split production into peak and off-peak periods
    # Assume that all production is done in one period (either peak or off-peak)
    # For simplicity, we'll assume that each device can be scheduled in either peak or off-peak, but not both
    # So, we split the production of device i into two parts: x_peak and x_offpeak
    x_peak = model.addVar(lb=0, ub=devices[i]['max_cap'], vtype=GRB.CONTINUOUS, name=f"x_peak_{devices[i]['name']}")
    x_offpeak = model.addVar(lb=0, ub=devices[i]['max_cap'], vtype=GRB.CONTINUOUS, name=f"x_offpeak_{devices[i]['name']}")
    model.addConstr(x[i] == x_peak + x_offpeak, f"Split_{devices[i]['name']}")

    # Energy consumption for production
    energy_cost += energy_per_unit[devices[i]['name']] * x_peak * energy_price_peak
    energy_cost += energy_per_unit[devices[i]['name']] * x_offpeak * energy_price_offpeak

    # Startup energy and cost
    model.addConstr(z[i] >= x_peak + x_offpeak, f"StartupUsage_{devices[i]['name']}")
    model.addConstr(z[i] <= (x_peak + x_offpeak) / devices[i]['max_cap'], f"StartupUsage2_{devices[i]['name']}")

# Add startup budget constraint
model.addConstr(gp.quicksum(startup_energy[devices[i]['name']] * z[i] for i in range(n)) <= startup_budget, "StartupBudget")

# Add energy budget constraints
model.addConstr(gp.quicksum(energy_per_unit[devices[i]['name']] * x[i] * energy_price_peak for i in range(n)) <= energy_budget_peak, "EnergyPeak")
model.addConstr(gp.quicksum(energy_per_unit[devices[i]['name']] * x[i] * energy_price_offpeak for i in range(n)) <= energy_budget_offpeak, "EnergyOffpeak")

# Constraint: total production must equal required units
model.addConstr(gp.quicksum(x[i] for i in range(n)) == required_units, "TotalProduction")

# Objective function
model.setObjective(total_cost + energy_cost, GRB.MINIMIZE)

# Solve the model
model.optimize()

# Print results
for i in range(n):
    print(f"Device {devices[i]['name']}: used={int(value(y[i]))}, units={value(x[i]):.1f}")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
