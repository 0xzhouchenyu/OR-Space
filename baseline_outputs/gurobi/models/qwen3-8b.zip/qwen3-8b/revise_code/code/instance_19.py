import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = row['Value']

# Extract parameters
cost_per_chair_A = float(params['cost_per_chair_A'])
cost_per_chair_B = float(params['cost_per_chair_B'])
cost_per_chair_C = float(params['cost_per_chair_C'])
chairs_per_order_A = int(params['chairs_per_order_A'])
chairs_per_order_B = int(params['chairs_per_order_B'])
chairs_per_order_C = int(params['chairs_per_order_C'])
min_total_chairs = int(params['min_total_chairs'])
max_total_chairs = int(params['max_total_chairs'])
min_chairs_B_if_A = int(params['min_chairs_B_if_A'])
dependency_B_C = params['dependency_B_C'] == '1'
fixed_fee_A_regular = float(params['fixed_fee_A_regular'])
fixed_fee_A_express = float(params['fixed_fee_A_express'])
fixed_fee_B_regular = float(params['fixed_fee_B_regular'])
fixed_fee_B_express = float(params['fixed_fee_B_express'])
fixed_fee_C_regular = float(params['fixed_fee_C_regular'])
fixed_fee_C_express = float(params['fixed_fee_C_express'])
weekly_order_budget = int(params['weekly_order_budget'])

# Create model
model = gp.Model("FurnitureOrder")

# Decision variables: number of orders from each manufacturer (integer, >= 0)
max_orders_A = max_total_chairs // chairs_per_order_A + 1
max_orders_B = max_total_chairs // chairs_per_order_B + 1
max_orders_C = max_total_chairs // chairs_per_order_C + 1

x_A = model.addVar(lb=0, ub=max_orders_A, vtype=GRB.INTEGER, name="orders_A")
x_B = model.addVar(lb=0, ub=max_orders_B, vtype=GRB.INTEGER, name="orders_B")
x_C = model.addVar(lb=0, ub=max_orders_C, vtype=GRB.INTEGER, name="orders_C")

# Binary variables to indicate if we order from each manufacturer
y_A = model.addVar(vtype=GRB.BINARY, name="y_A")
y_B = model.addVar(vtype=GRB.BINARY, name="y_B")
y_C = model.addVar(vtype=GRB.BINARY, name="y_C")

# Binary variables for channel selection
channel_A_regular = model.addVar(vtype=GRB.BINARY, name="channel_A_regular")
channel_A_express = model.addVar(vtype=GRB.BINARY, name="channel_A_express")
channel_B_regular = model.addVar(vtype=GRB.BINARY, name="channel_B_regular")
channel_B_express = model.addVar(vtype=GRB.BINARY, name="channel_B_express")
channel_C_regular = model.addVar(vtype=GRB.BINARY, name="channel_C_regular")
channel_C_express = model.addVar(vtype=GRB.BINARY, name="channel_C_express")

# Constraints: link channel variables with y variables
model.addConstr(channel_A_regular + channel_A_express <= y_A, "ChannelAConstraint")
model.addConstr(channel_B_regular + channel_B_express <= y_B, "ChannelBConstraint")
model.addConstr(channel_C_regular + channel_C_express <= y_C, "ChannelCConstraint")

# Constraint: only one channel per manufacturer
model.addConstr(channel_A_regular + channel_A_express == y_A, "SingleChannelA")
model.addConstr(channel_B_regular + channel_B_express == y_B, "SingleChannelB")
model.addConstr(channel_C_regular + channel_C_express == y_C, "SingleChannelC")

# Total chairs from each manufacturer
chairs_A = chairs_per_order_A * x_A
chairs_B = chairs_per_order_B * x_B
chairs_C = chairs_per_order_C * x_C

# Objective: minimize total cost (variable cost + fixed fee)
total_cost = (
    cost_per_chair_A * chairs_A +
    cost_per_chair_B * chairs_B +
    cost_per_chair_C * chairs_C +
    fixed_fee_A_regular * channel_A_regular +
    fixed_fee_A_express * channel_A_express +
    fixed_fee_B_regular * channel_B_regular +
    fixed_fee_B_express * channel_B_express +
    fixed_fee_C_regular * channel_C_regular +
    fixed_fee_C_express * channel_C_express
)

model.setObjective(total_cost, GRB.MINIMIZE)

# Constraint: total chairs between min and max
model.addConstr(chairs_A + chairs_B + chairs_C >= min_total_chairs, "MinChairs")
model.addConstr(chairs_A + chairs_B + chairs_C <= max_total_chairs, "MaxChairs")

# Dependency: if ordering from A, must order at least min_chairs_B_if_A chairs from B
model.addConstr(chairs_B >= min_chairs_B_if_A * y_A, "DepAB")

# Dependency: if ordering from B, must also order from C
model.addConstr(y_B <= y_C, "DepBC")

# Weekly order budget constraint
model.addConstr(
    (channel_A_regular + channel_A_express) + 
    (channel_B_regular + channel_B_express) + 
    (channel_C_regular + channel_C_express) <= weekly_order_budget,
    "WeeklyOrderBudget"
)

# Solve
model.Params.OutputFlag = 0
model.optimize()

# Extract results
obj_val = model.objVal

print(f"FINAL_OBJ_VALUE: {obj_val}")
