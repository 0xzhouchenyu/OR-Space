import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Parse general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    cost_a = params["cost_supplier_a"]       # 120 USD per table
    cost_b = params["cost_supplier_b"]       # 110 USD per table
    cost_c = params["cost_supplier_c"]       # 100 USD per table
    size_a = int(params["order_size_supplier_a"])  # 20 tables per order
    size_b = int(params["order_size_supplier_b"])  # 15 tables per order
    size_c = int(params["order_size_supplier_c"])  # 15 tables per order
    min_tables = int(params["min_tables_required"])  # 150
    max_tables = int(params["max_tables_allowed"])   # 600
    min_b_if_a = int(params["min_tables_supplier_b_if_a"])  # 30 tables from B if A is used
    b_requires_c = int(params["supplier_b_requires_c"])      # 1 (boolean)
    max_free_orders_c = int(params["max_free_orders_c"])     # 5
    penalty_per_extra_order_c = params["penalty_per_extra_order_c"]  # 600 USD
    bc_shared_inbound_trigger = int(params["supplier_bc_shared_inbound_trigger"])  # 1 (boolean)
    bc_shared_inbound_fee = params["supplier_bc_shared_inbound_fee"]  # 1000 USD
    
    M = 1000  # Big-M

    model = gp.Model("Restaurant_Tables")
    model.setParam("OutputFlag", 0)

    # Decision variables: number of orders from each supplier (integer >= 0)
    x_a = model.addVar(lb=0, vtype=GRB.INTEGER, name="orders_a")
    x_b = model.addVar(lb=0, vtype=GRB.INTEGER, name="orders_b")
    x_c = model.addVar(lb=0, vtype=GRB.INTEGER, name="orders_c")

    # Binary variables for conditional constraints
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")  # 1 if ordering from A
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")  # 1 if ordering from B

    # Objective: minimize total cost (cost per table * number of tables) + shared inbound fee
    total_cost = (
        cost_a * size_a * x_a +
        cost_b * size_b * x_b +
        cost_c * size_c * x_c
    )
    # Shared inbound fee only if both B and C are used
    shared_inbound_fee = bc_shared_inbound_fee * y_b * y_c
    # Penalty for extra orders from C
    extra_orders_c = max(0, x_c - max_free_orders_c)
    penalty_c = penalty_per_extra_order_c * extra_orders_c
    model.setObjective(total_cost + shared_inbound_fee + penalty_c, GRB.MINIMIZE)

    # Total tables constraints
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c >= min_tables)
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c <= max_tables)

    # Link binary variables to order variables
    model.addConstr(x_a <= M * y_a)
    model.addConstr(x_a >= y_a)
    model.addConstr(x_b <= M * y_b)
    model.addConstr(x_b >= y_b)

    # If ordering from A, then tables from B >= 30
    model.addConstr(size_b * x_b >= min_b_if_a * y_a)

    # If ordering from B, must order from C
    if b_requires_c:
        model.addConstr(x_c >= y_b)

    # Add binary variable for C to handle shared inbound fee
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")
    model.addConstr(x_c <= M * y_c)
    model.addConstr(x_c >= y_c)

    model.optimize()

    obj_val = model.objVal
    print(f"Orders from A: {x_a.x}, Tables: {x_a.x * size_a}")
    print(f"Orders from B: {x_b.x}, Tables: {x_b.x * size_b}")
    print(f"Orders from C: {x_c.x}, Tables: {x_c.x * size_c}")
    print(f"OBJECTIVE_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
FINAL_OBJ_VALUE: 84500.0
