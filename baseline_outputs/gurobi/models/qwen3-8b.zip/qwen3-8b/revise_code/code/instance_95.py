import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add parent directory to path if needed
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

def load_table_1(data_dir):
    """Load the weekly demand, capacity, and cost data."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    weeks = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })
    return weeks

def load_general_parameters(data_dir):
    """Load general parameters."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

# Load data
data_dir = os.path.join(script_dir, '..', 'data')
weeks_data = load_table_1(data_dir)
params = load_general_parameters(data_dir)

storage_cost = params['storage_cost_per_thousand_boxes']
fixed_setup_cost = params['fixed_setup_cost']
week2_push_threshold = params['week2_push_threshold']
week3_capacity_loss_after_week2_push = params['week3_capacity_loss_after_week2_push']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']

n_weeks = len(weeks_data)

# Create the model
model = gp.Model("Beverage_Production_Planning")

# Decision variables
x = [model.addVar(lb=0, ub=weeks_data[t]['capacity'], vtype=GRB.CONTINUOUS, name=f"x_{t+1}") for t in range(n_weeks)]
s = [model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"s_{t+1}") for t in range(n_weeks)]
setup = [model.addVar(vtype=GRB.BINARY, name=f"setup_{t+1}") for t in range(n_weeks)]
microclean = [model.addVar(vtype=GRB.BINARY, name=f"microclean_{t+1}") for t in range(n_weeks)]

# Objective: minimize total production cost + storage cost + fixed setup cost + microclean fee
objective = 0
for t in range(n_weeks):
    objective += weeks_data[t]['cost'] * x[t]
    objective += storage_cost * s[t]
    objective += fixed_setup_cost * setup[t]
    if t == 1:
        objective += week2_microclean_fee * microclean[t]

model.setObjective(objective, GRB.MINIMIZE)

# Constraints: inventory balance
for t in range(n_weeks):
    if t == 0:
        model.addConstr(x[t] - s[t] == weeks_data[t]['demand'], f"balance_week_{t+1}")
    else:
        model.addConstr(s[t-1] + x[t] - s[t] == weeks_data[t]['demand'], f"balance_week_{t+1}")

# Setup constraints
for t in range(n_weeks):
    model.addConstr(x[t] <= weeks_data[t]['capacity'] * setup[t], f"setup_constraint_{t+1}")

# Microclean constraint for Week 2
model.addConstr(x[1] >= week2_microclean_threshold * microclean[1], f"microclean_constraint_week_2")

# Capacity loss constraint for Week 3 if Week 2 production exceeds threshold
model.addConstr(x[1] >= week2_push_threshold, f"push_threshold_week_2")
model.addConstr(weeks_data[2]['capacity'] - week3_capacity_loss_after_week2_push <= weeks_data[2]['capacity'] - (x[1] - week2_push_threshold), f"capacity_loss_week_3")

# Solve
model.setParam('OutputFlag', 0)
model.optimize()

# Print results
print(f"Status: {model.Status}")
for t in range(n_weeks):
    print(f"Week {t+1}: Produce {x[t].x:.1f}, Inventory {s[t].x:.1f}")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
