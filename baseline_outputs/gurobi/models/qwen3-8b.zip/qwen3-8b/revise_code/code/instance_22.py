import gurobipy as gp
from gurobipy import GRB
import os
import pandas as pd

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    t1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    t2 = pd.read_csv(os.path.join(data_dir, "table_2.csv"))
    t3 = pd.read_csv(os.path.join(data_dir, "table_3.csv"))
    gp_params = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    
    df = t1.merge(t2, on='Product').merge(t3, on='Product')
    
    prod_days = float(gp_params[gp_params['Parameter_Name'] == 'production_days']['Value'].iloc[0])
    a1_watch_threshold = int(gp_params[gp_params['Parameter_Name'] == 'a1_watch_threshold']['Value'].iloc[0])
    a1_deep_service_threshold = int(gp_params[gp_params['Parameter_Name'] == 'a1_deep_service_threshold']['Value'].iloc[0])
    maintenance_penalty_watch = int(gp_params[gp_params['Parameter_Name'] == 'maintenance_penalty_watch']['Value'].iloc[0])
    maintenance_penalty_deep = int(gp_params[gp_params['Parameter_Name'] == 'maintenance_penalty_deep']['Value'].iloc[0])
    a1_quality_release_fee = float(gp_params[gp_params['Parameter_Name'] == 'a1_quality_release_fee']['Value'].iloc[0])
    a1_deep_service_fee = float(gp_params[gp_params['Parameter_Name'] == 'a1_deep_service_fee']['Value'].iloc[0])
    a1_priority_price_lift = float(gp_params[gp_params['Parameter_Name'] == 'a1_priority_price_lift']['Value'].iloc[0])
    
    return df, prod_days, a1_watch_threshold, a1_deep_service_threshold, maintenance_penalty_watch, maintenance_penalty_deep, a1_quality_release_fee, a1_deep_service_fee, a1_priority_price_lift

def solve():
    df, prod_days, a1_watch_threshold, a1_deep_service_threshold, maintenance_penalty_watch, maintenance_penalty_deep, a1_quality_release_fee, a1_deep_service_fee, a1_priority_price_lift = load_data()
    
    products = df['Product'].tolist()
    
    model = gp.Model("Production_Planning")
    
    # Variables
    x = model.addVars(products, name="x", lb=0)
    y = model.addVars(products, vtype=GRB.BINARY, name="y")
    w = model.addVar(name="w", vtype=GRB.BINARY)
    z = model.addVar(name="z", vtype=GRB.BINARY)
    
    # Objective
    profit = 0
    for _, row in df.iterrows():
        p = row['Product']
        profit += (row['Selling_Price'] - row['Production_Cost']) * x[p] - row['Activation_Cost'] * y[p]
        if p == 'A1':
            profit += a1_priority_price_lift * x[p] * w
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Constraints
    # All products must be produced
    for p in products:
        model.addConstr(y[p] == 1)
    
    # Production batch constraints
    for _, row in df.iterrows():
        p = row['Product']
        model.addConstr(x[p] <= row['Maximum_Demand'] * y[p])
        model.addConstr(x[p] >= row['Minimum_Batch'] * y[p])
    
    # A1 production threshold constraints
    model.addConstr(x['A1'] >= a1_watch_threshold * w)
    model.addConstr(x['A1'] >= a1_deep_service_threshold * z)
    
    # Maintenance penalty constraints
    model.addConstr(x['A1'] <= (prod_days - maintenance_penalty_watch) * y['A1'])
    model.addConstr(x['A1'] <= (prod_days - maintenance_penalty_watch - maintenance_penalty_deep) * z)
    
    # Quality release and deep service fees
    model.addConstr(gp.LinExpr([1, a1_quality_release_fee], [w, 1]) <= 0)
    model.addConstr(gp.LinExpr([1, a1_deep_service_fee], [z, 1]) <= 0)
    
    # Production days constraint
    model.addConstr(gp.quicksum(x[p] / row['Production_Quota'] for _, row in df.iterrows()) <= prod_days)
    
    # Solve
    model.setParam('OutputFlag', 0)
    model.optimize()
    
    return model.objVal

if __name__ == "__main__":
    obj = solve()
    print(f"FINAL_OBJ_VALUE: {round(obj, 4)}")
