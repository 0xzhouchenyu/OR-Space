import os
import csv
import gurobipy as gp
from gurobipy import GRB

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv")) as f:
    for row in csv.DictReader(f):
        params[row['Parameter_Name'].strip()] = float(row['Value'])

products = {}
with open(os.path.join(data_dir, "table_1.csv")) as f:
    for row in csv.DictReader(f):
        products[row['Product'].strip()] = {
            'a_hrs': float(row['Workshop_A_Hours']),
            'b_hrs': float(row['Workshop_B_Hours']),
            'insp_cost': float(row['Inspection_Sales_Cost'])
        }

microwave = products['Microwave_Oven']
water_heater = products['Water_Heater']

model = gp.Model("production")

x1 = model.addVar(lb=params['microwave_minimum_sales'], name="microwave")
x2 = model.addVar(lb=params['water_heater_minimum_sales'], name="water_heater")

y1 = model.addVar(vtype=GRB.BINARY, name="setup_microwave")
y2 = model.addVar(vtype=GRB.BINARY, name="setup_water_heater")

# Technician hours from shared pool
tech_hours_m = x1 * params['tech_rate_m']
tech_hours_w = x2 * params['tech_rate_w']
model.addConstr(tech_hours_m + tech_hours_w <= params['tech_pool_hours'], "tech_pool")

# Workshop A setup and production hours
setup_hours_a = y1 + y2
model.addConstr(setup_hours_a <= params['setup_hours_A'], "setup_hours_a")

prod_hours_a = (microwave['a_hrs'] * x1) + (water_heater['a_hrs'] * x2)
model.addConstr(prod_hours_a + setup_hours_a <= params['workshop_a_available_hours'] + params['workshop_a_overtime_limit'], "workshop_a_hours")

# Workshop B production hours
prod_hours_b = (microwave['b_hrs'] * x1) + (water_heater['b_hrs'] * x2)
model.addConstr(prod_hours_b >= params['workshop_b_available_hours'], "workshop_b_hours")

# Inspection and sales costs
insp_cost = (microwave['insp_cost'] * x1) + (water_heater['insp_cost'] * x2)
model.addConstr(insp_cost <= params['inspection_sales_cost_limit'], "inspection_sales_cost")

# Green bonus
green_bonus = (microwave['insp_cost'] * x1 * params['green_bonus_m']) + (water_heater['insp_cost'] * x2 * params['green_bonus_w'])
model.setObjective((microwave['a_hrs'] * params['workshop_a_hourly_cost'] + microwave['b_hrs'] * params['workshop_b_hourly_cost'] + microwave['insp_cost']) * x1 +
                  (water_heater['a_hrs'] * params['workshop_a_hourly_cost'] + water_heater['b_hrs'] * params['workshop_b_hourly_cost'] + water_heater['insp_cost']) * x2 + green_bonus, GRB.MAXIMIZE)

model.setParam('OutputFlag', 0)
model.optimize()

FINAL_OBJ_VALUE: {model.objVal}
