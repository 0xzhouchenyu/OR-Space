import gurobipy as gp
from gurobipy import GRB
import os
import sys
import csv

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load general parameters
    general_params_path = os.path.join(base_dir, 'general_parameters.csv')
    general_params = {}
    with open(general_params_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            param, value = row
            general_params[param] = float(value)
    
    # Load batch processing times
    table1_path = os.path.join(base_dir, 'table_1.csv')
    batches = []
    processing_times = []
    
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            batch_id = int(row[0])
            times = [float(row[1]), float(row[2]), float(row[3])]
            batches.append(batch_id)
            processing_times.append(times)
    
    return general_params, batches, processing_times

def round_up_to_time_unit(duration):
    return int(duration) if duration == int(duration) else int(duration) + 1

def solve():
    general_params, batches, processing_times = load_data()
    planning_horizon_T = general_params['planning_horizon_T']
    energy_cost_v1 = general_params['energy_cost_v1']
    energy_cost_v2 = general_params['energy_cost_v2']
    energy_cost_v3 = general_params['energy_cost_v3']
    peak_energy_multiplier = general_params['peak_energy_multiplier']
    peak_energy_cap = general_params['peak_energy_cap']
    makespan_weight = general_params['makespan_weight']
    energy_weight = general_params['energy_weight']
    
    num_batches = len(batches)
    num_vats = 3
    
    # Round up all processing times to the next full time unit
    rounded_processing_times = []
    for batch in processing_times:
        rounded_times = [round_up_to_time_unit(t) for t in batch]
        rounded_processing_times.append(rounded_times)
    
    # Create model
    model = gp.Model("Dyeing_Plant_Scheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[batch][vat][time] = 1 if batch starts on vat at time
    x = {}
    for batch in range(num_batches):
        for vat in range(num_vats):
            for time in range(planning_horizon_T):
                x[(batch, vat, time)] = model.addVar(vtype=GRB.BINARY, name=f"x_{batch}_{vat}_{time}")
    
    # Variables to track completion times
    completion = {}
    for batch in range(num_batches):
        for vat in range(num_vats):
            for time in range(planning_horizon_T):
                completion[(batch, vat, time)] = model.addVar(vtype=GRB.CONTINUOUS, name=f"completion_{batch}_{vat}_{time}")
    
    # Constraints: Each batch must be processed exactly once on each vat
    for batch in range(num_batches):
        for vat in range(num_vats):
            model.addConstr(gp.quicksum(x[(batch, vat, time)] for time in range(planning_horizon_T)) == 1,
                            name=f"batch_vat_{batch}_{vat}_once")
    
    # Constraints: Vat cannot process more than one batch at a time
    for vat in range(num_vats):
        for time in range(planning_horizon_T):
            model.addConstr(gp.quicksum(x[(batch, vat, time)] for batch in range(num_batches)) <= 1,
                            name=f"vat_time_{vat}_{time}_single_batch")
    
    # Maintenance shutdown on Vat 2 during periods 4 and 5
    for batch in range(num_batches):
        for time in range(4, 6):  # periods 4 and 5 (0-based)
            model.addConstr(x[(batch, 1, time)] == 0,
                            name=f"vat2_maintenance_{batch}_{time}")
    
    # Completion time constraints: If a batch starts on vat at time, it finishes at time + duration - 1
    for batch in range(num_batches):
        for vat in range(num_vats):
            for time in range(planning_horizon_T):
                duration = rounded_processing_times[batch][vat]
                finish_time = time + duration - 1
                if finish_time < planning_horizon_T:
                    model.addConstr(completion[(batch, vat, time)] == time + duration - 1,
                                    name=f"completion_{batch}_{vat}_{time}")
    
    # Ensure that the next vat can start immediately after the previous vat finishes
    for batch in range(num_batches):
        for vat in range(num_vats - 1):
            for time in range(planning_horizon_T):
                # If batch starts on vat at time, then it must finish by time + duration - 1
                duration = rounded_processing_times[batch][vat]
                finish_time = time + duration - 1
                if finish_time < planning_horizon_T:
                    # The next vat can start at finish_time
                    model.addConstr(gp.quicksum(x[(batch, vat + 1, t)] for t in range(finish_time + 1)) == 0,
                                    name=f"next_vat_start_{batch}_{vat}_{time}")
    
    # Calculate total energy cost
    total_energy_cost = 0.0
    for vat in range(num_vats):
        for time in range(planning_horizon_T):
            # Check if vat is active at this time
            active = 0
            for batch in range(num_batches):
                active += x[(batch, vat, time)]
            # Energy cost for this period
            if time + 1 in [6, 7, 8]:  # peak periods
                energy_rate = eval(f"energy_cost_v{vat + 1}") * peak_energy_multiplier
            else:
                energy_rate = eval(f"energy_cost_v{vat + 1}")
            total_energy_cost += active * energy_rate
    
    # Objective: minimize makespan_weight * makespan + energy_weight * total_energy_cost
    # Compute makespan as the latest completion time across all vats and batches
    makespan = model.addVar(vtype=GRB.CONTINUOUS, name="makespan")
    for batch in range(num_batches):
        for vat in range(num_vats):
            for time in range(planning_horizon_T):
                model.addConstr(makespan >= completion[(batch, vat, time)],
                                name=f"makespan_upper_bound_{batch}_{vat}_{time}")
    
    objective = makespan_weight * makespan + energy_weight * total_energy_cost
    model.setObjective(objective, GRB.MINIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Print solution details
    print(f"Number of batches: {num_batches}")
    print(f"Number of vats: {num_vats}")
    print(f"Planning horizon: {planning_horizon_T}")
    
    # Extract the best permutation based on the schedule
    batch_order = []
    for batch in range(num_batches):
        for vat in range(num_vats):
            for time in range(planning_horizon_T):
                if x[(batch, vat, time)].x > 0.5:
                    batch_order.append(batch)
                    break
    
    print(f"Best permutation (batch order): {[batches[i] for i in batch_order]}")
    
    # Print schedule details
    for batch in range(num_batches):
        for vat in range(num_vats):
            for time in range(planning_horizon_T):
                if x[(batch, vat, time)].x > 0.5:
                    print(f"Batch {batches[batch]} on Vat {vat + 1} starts at period {time}, ends at period {time + rounded_processing_times[batch][vat] - 1}")
    
    print(f"Optimal makespan: {makespan.x}")
    print(f"Total energy cost: {total_energy_cost}")
    print(f"FINAL_OBJ_VALUE: {objective.getValue()}")
