import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    table1 = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            table1.append(row)
    
    params = []
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params.append(row)
    
    # Parse parameters
    param_dict = {}
    for row in params:
        param_dict[row['Parameter_Name']] = float(row['Value'])
    
    # Parse table1
    proc_I = table1[0]
    proc_II = table1[1]
    profit_row = table1[2]
    
    a_I = float(proc_I['Model_A_hours_per_unit'])  # 4
    b_I = float(proc_I['Model_B_hours_per_unit'])  # 6
    cap_I = float(proc_I['Maximum_Weekly_Processing_Capacity'])  # 150
    
    a_II = float(proc_II['Model_A_hours_per_unit'])  # 3
    b_II = float(proc_II['Model_B_hours_per_unit'])  # 2
    cap_II = float(proc_II['Maximum_Weekly_Processing_Capacity'])  # 70
    
    profit_A = float(profit_row['Model_A_hours_per_unit'])  # 300
    profit_B = float(profit_row['Model_B_hours_per_unit'])  # 450
    
    min_profit = param_dict['min_weekly_profit']  # 10000
    min_A = param_dict['min_model_A_units']  # 10
    min_B = param_dict['min_model_B_units']  # 15
    proc_I_hours = param_dict['process_I_hours']  # 150
    max_overtime = param_dict['process_II_max_overtime']  # 30
    red_A = param_dict['model_A_overtime_profit_reduction']  # 20
    red_B = param_dict['model_B_overtime_profit_reduction']  # 25
    
    model = gp.Model("Microcomputer_Production")
    model.setParam('OutputFlag', 0)
    
    xA_r = model.addVar(lb=0, name="xA_r")  # Regular A
    xA_o = model.addVar(lb=0, name="xA_o")  # Overtime A
    xB_r = model.addVar(lb=0, name="xB_r")  # Regular B
    xB_o = model.addVar(lb=0, name="xB_o")  # Overtime B
    
    total_A = xA_r + xA_o
    total_B = xB_r + xB_o
    
    # Process I exact constraint
    model.addConstr(a_I * total_A + b_I * total_B == proc_I_hours)
    
    # Process II regular capacity
    model.addConstr(a_II * xA_r + b_II * xB_r <= cap_II)
    
    # Process II overtime capacity
    model.addConstr(a_II * xA_o + b_II * xB_o <= max_overtime)
    
    # Minimum production constraints
    model.addConstr(total_A >= min_A)
    model.addConstr(total_B >= min_B)
    
    # Profit calculation with overtime penalties
    profit = (profit_A * xA_r + profit_B * xB_r) + ((profit_A - red_A) * xA_o + (profit_B - red_B) * xB_o)
    model.addConstr(profit >= min_profit)
    
    # Objective: Maximize total units produced
    model.setObjective(total_A + total_B, GRB.MAXIMIZE)
    
    model.optimize()
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
