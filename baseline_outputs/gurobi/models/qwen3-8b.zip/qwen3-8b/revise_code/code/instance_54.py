import os
import sys
import csv
from gurobipy import GRB, Model, quicksum

# Add parent directory to path if needed
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

def load_table_1(data_dir):
    """Load and parse table_1.csv to extract equipment hours, processing times, and profits."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    equipment_names = []
    products = []
    processing_times = {}  # (equipment, product) -> time
    effective_hours = {}   # equipment -> hours
    base_profit = {}       # product -> profit
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: Equipment_Code, I, II, III, Effective_Monthly_Equipment_Hours
        products = header[1:-1]  # ['I', 'II', 'III']
        
        for row in reader:
            if row[0].startswith('Unit_Product_Profit'):
                # This is the profit row
                for j, prod in enumerate(products):
                    base_profit[prod] = float(row[j + 1])
            else:
                equip = row[0]
                equipment_names.append(equip)
                effective_hours[equip] = float(row[-1])
                for j, prod in enumerate(products):
                    processing_times[(equip, prod)] = float(row[j + 1])
    
    return products, equipment_names, processing_times, effective_hours, base_profit

def load_general_parameters(data_dir):
    """Load and parse general_parameters.csv to extract parameters."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    
    params = {}
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            if row[0] == 'overtime_hours_cap':
                params['overtime_hours_cap'] = float(row[1])
            elif row[0] == 'overtime_cost_multiplier':
                params['overtime_cost_multiplier'] = float(row[1])
            elif row[0] == 'min_prod_I':
                params['min_prod_I'] = float(row[1])
            elif row[0] == 'min_prod_II':
                params['min_prod_II'] = float(row[1])
            elif row[0] == 'min_prod_III':
                params['min_prod_III'] = float(row[1])
    
    return params

# Load data
data_dir = os.path.join(script_dir, '..', 'data')
products, equipment_names, processing_times, effective_hours, base_profit = load_table_1(data_dir)
params = load_general_parameters(data_dir)
overtime_hours_cap = params['overtime_hours_cap']
overtime_cost_multiplier = params['overtime_cost_multiplier']
min_prod_I = params['min_prod_I']
min_prod_II = params['min_prod_II']
min_prod_III = params['min_prod_III']

# Create model
model = Model("Factory_Production_Optimization")

# Decision variables
x_reg = {p: model.addVar(name=f"x_reg_{p}", lb=0) for p in products}
x_ot = {p: model.addVar(name=f"x_ot_{p}", lb=0) for p in products}

# Objective: minimize total cost
total_cost = 0
for p in products:
    regular_cost = base_profit[p]
    overtime_cost = overtime_cost_multiplier * base_profit[p]
    total_cost += regular_cost * x_reg[p] + overtime_cost * x_ot[p]

model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints: equipment capacity
for equip in equipment_names:
    model.addConstr(
        quicksum(processing_times[(equip, p)] * (x_reg[p] + x_ot[p]) for p in products) <= effective_hours[equip],
        name=f"Equipment_{equip}_capacity"
    )

# Constraint: plant-wide overtime limit
model.addConstr(
    quicksum(processing_times[(equip, p)] * x_ot[p] for equip in equipment_names for p in products) <= overtime_hours_cap,
    name="Overtime_Limit"
)

# Minimum production constraints
model.addConstr(x_reg['I'] + x_ot['I'] >= min_prod_I, name="Min_Production_I")
model.addConstr(x_reg['II'] + x_ot['II'] >= min_prod_II, name="Min_Production_II")
model.addConstr(x_reg['III'] + x_ot['III'] >= min_prod_III, name="Min_Production_III")

# Solve model
model.setParam('OutputFlag', 0)
model.optimize()

# Print objective value
FINAL_OBJ_VALUE: %.6f % model.objVal
