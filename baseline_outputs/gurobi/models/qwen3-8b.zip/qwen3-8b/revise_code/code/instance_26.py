import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    general_params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row["Parameter_Name"]] = float(row["Value"])
    
    # Read staffing requirements
    requirements = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row["Time_Period"].strip()
            req = int(row["Required_Salespeople"].strip())
            requirements[period] = req
    
    periods = list(requirements.keys())
    n = len(periods)
    req_values = list(requirements.values())
    
    # Parameters from general_parameters.csv
    full_time_cost = general_params["full_time_cost"]
    part_time_cost = general_params["part_time_cost"]
    part_time_cap_per_period = int(general_params["part_time_cap_per_period"])
    min_full_time_per_period = int(general_params["min_full_time_per_period"])
    
    # Create model
    model = gp.Model("Convenience_Store_Staffing")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    # x[i]: number of full-time salespeople starting at period i (covers i and (i+1) % n)
    x = [model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{i}") for i in range(n)]
    
    # y[j]: number of part-time salespeople assigned to period j
    y = [model.addVar(lb=0, ub=part_time_cap_per_period, vtype=GRB.INTEGER, name=f"y_{j}") for j in range(n)]
    
    # Objective: minimize total cost
    model.setObjective(
        full_time_cost * sum(x) + part_time_cost * sum(y),
        GRB.MINIMIZE
    )
    
    # Constraints
    # 1. For each period j, full-time coverage from x[j] and x[(j-1) % n]
    # plus part-time coverage y[j] must meet the required salespeople
    for j in range(n):
        model.addConstr(
            x[j] + x[(j - 1) % n] + y[j] >= req_values[j],
            f"coverage_{j}"
        )
    
    # 2. Minimum full-time coverage per period
    for j in range(n):
        model.addConstr(
            x[j] + x[(j - 1) % n] >= min_full_time_per_period,
            f"min_full_time_{j}"
        )
    
    # Solve
    model.optimize()
    
    # Print solution details
    for i in range(n):
        print(f"Full-time shift starting at period {periods[i]}: {int(x[i].x)}")
    for j in range(n):
        print(f"Part-time workers for period {periods[j]}: {int(y[j].x)}")
    
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
