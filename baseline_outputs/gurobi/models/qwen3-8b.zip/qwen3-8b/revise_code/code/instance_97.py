import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    # Get data directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, '..', 'data')
    
    # Read table_1.csv
    materials = []
    sulfur_content = {}
    purchase_price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            mat = row['Material'].strip()
            materials.append(mat)
            sulfur_content[mat] = float(row['Sulfur_Content_Percentage'].strip())
            purchase_price[mat] = float(row['Purchase_Price_Thousand_Yuan_Per_Ton'].strip())
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[param_name] = val
    
    max_sulfur_A_premium = params['max_sulfur_content_A_premium']
    max_sulfur_A_standard = params['max_sulfur_content_A_standard']
    max_sulfur_B_premium = params['max_sulfur_content_B_premium']
    max_sulfur_B_standard = params['max_sulfur_content_B_standard']
    selling_price_A_premium = params['selling_price_A_premium']
    selling_price_A_standard = params['selling_price_A_standard']
    selling_price_B_premium = params['selling_price_B_premium']
    selling_price_B_standard = params['selling_price_B_standard']
    max_supply_D = params['max_supply_D']
    market_demand_A = params['market_demand_A']
    market_demand_B = params['market_demand_B']
    min_premium_share_A = params['min_premium_share_A']
    max_premium_share_A = params['max_premium_share_A']
    min_premium_share_B = params['min_premium_share_B']
    max_premium_share_B = params['max_premium_share_B']
    
    products = ['A', 'B']
    product_types = ['premium', 'standard']
    
    # Decision variables: x[m, p, t] = tons of material m used in product p (type t)
    model = gp.Model("Mixing_Problem")
    
    x = model.addVars(materials, products, product_types, lb=0, name="x")
    
    # Total amount of each product type
    total_A_premium = model.sum(x[m, 'A', 'premium'] for m in materials)
    total_A_standard = model.sum(x[m, 'A', 'standard'] for m in materials)
    total_B_premium = model.sum(x[m, 'B', 'premium'] for m in materials)
    total_B_standard = model.sum(x[m, 'B', 'standard'] for m in materials)
    
    # Revenue
    revenue = (
        selling_price_A_premium * total_A_premium +
        selling_price_A_standard * total_A_standard +
        selling_price_B_premium * total_B_premium +
        selling_price_B_standard * total_B_standard
    )
    
    # Cost
    cost = model.sum(purchase_price[m] * (x[m, 'A', 'premium'] + x[m, 'A', 'standard'] + x[m, 'B', 'premium'] + x[m, 'B', 'standard']) for m in materials)
    
    # Objective: Maximize profit
    model.setObjective(revenue - cost, GRB.MAXIMIZE)
    
    # Sulfur content constraints for each product type
    model.addConstr(
        model.sum(sulfur_content[m] * x[m, 'A', 'premium'] for m in materials) <= max_sulfur_A_premium * total_A_premium,
        "Sulfur_A_premium"
    )
    model.addConstr(
        model.sum(sulfur_content[m] * x[m, 'A', 'standard'] for m in materials) <= max_sulfur_A_standard * total_A_standard,
        "Sulfur_A_standard"
    )
    model.addConstr(
        model.sum(sulfur_content[m] * x[m, 'B', 'premium'] for m in materials) <= max_sulfur_B_premium * total_B_premium,
        "Sulfur_B_premium"
    )
    model.addConstr(
        model.sum(sulfur_content[m] * x[m, 'B', 'standard'] for m in materials) <= max_sulfur_B_standard * total_B_standard,
        "Sulfur_B_standard"
    )
    
    # Supply limit for material D
    model.addConstr(
        model.sum(x['D', 'A', 'premium'] + x['D', 'A', 'standard'] + x['D', 'B', 'premium'] + x['D', 'B', 'standard']) <= max_supply_D,
        "Supply_D"
    )
    
    # Market demand constraints
    model.addConstr(total_A_premium + total_A_standard <= market_demand_A, "Demand_A")
    model.addConstr(total_B_premium + total_B_standard <= market_demand_B, "Demand_B")
    
    # Premium share constraints for product A
    model.addConstr(total_A_premium >= min_premium_share_A, "Min_Premium_A")
    model.addConstr(total_A_premium <= max_premium_share_A, "Max_Premium_A")
    
    # Premium share constraints for product B
    model.addConstr(total_B_premium >= min_premium_share_B, "Min_Premium_B")
    model.addConstr(total_B_premium <= max_premium_share_B, "Max_Premium_B")
    
    # Solve
    model.Params.OutputFlag = 0
    model.optimize()
    
    # Print objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
