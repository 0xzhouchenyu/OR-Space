import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read time periods and minimum waiters needed
time_periods = []
min_waiters = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        time_periods.append(row["Time"].strip())
        min_waiters.append(int(row["Minimum_Number_of_Waiters_Needed"].strip()))

# Read general parameters
general_params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        general_params[row["Parameter_Name"].strip()] = int(row["Value"].strip())

# Parameters
n = len(time_periods)  # 6 periods, each 4 hours
work_hours = general_params["waiter_work_hours"]
waiter_cost_per_shift = general_params["waiter_cost_per_shift"]
waiter_budget = general_params["waiter_budget"]

# Peak and quality indicators
peak = [general_params[f"peak_{i}"] for i in range(n)]
quality = [general_params[f"quality_{i}"] for i in range(n)]

# Decision variables: x[i] = number of waiters starting at period i
model = gp.Model("Restaurant_Waiters")
x = [model.addVar(vtype=GRB.INTEGER, name=f"x_{i}") for i in range(n)]

# Objective: minimize total cost (waiter_cost_per_shift * total shifts)
total_cost = gp.quicksum(waiter_cost_per_shift * x[i] for i in range(n))
model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints: coverage in every 4-hour window must meet the demand floor
for j in range(n):
    prev = (j - 1) % n
    model.addConstr(x[prev] + x[j] >= min_waiters[j], f"Coverage_{j}")

# Budget constraint
model.addConstr(gp.quicksum(waiter_cost_per_shift * x[i] for i in range(n)) <= waiter_budget, "Budget")

# Solve
model.setParam('OutputFlag', 0)
model.optimize()

# Print results
for i in range(n):
    print(f"Waiters starting at period {time_periods[i]}: {int(x[i].x)}")

print(f"FINAL_OBJ_VALUE: {total_cost.getValue()}")
