import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, '..', 'data')
    
    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    
    n = len(shifts)  # number of periods (6)
    required = [s['required'] for s in shifts]
    
    # Read general parameters
    general_params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row['Parameter_Name']] = row['Value']
    
    shift_duration = int(general_params['shift_duration'])
    driver_rest_gap = int(general_params['driver_rest_gap'])
    crew_rest_gap = int(general_params['crew_rest_gap'])
    max_night_driver_fraction = float(general_params['max_night_driver_fraction'])
    max_night_crew_fraction = float(general_params['max_night_crew_fraction'])
    max_overtime_shifts = int(general_params['max_overtime_shifts'])
    overtime_cost_factor = float(general_params['overtime_cost_factor'])
    
    # Each time period is 4 hours, shift_duration is 8 hours = 2 periods
    periods_per_shift = shift_duration // 4  # = 2
    
    # Define model
    model = gp.Model("Bus_Scheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x_i = regular driver starts at period i, y_i = regular crew starts at period i
    # o_x_i = overtime driver starts at period i, o_y_i = overtime crew starts at period i
    x = [model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{i+1}") for i in range(n)]
    y = [model.addVar(lb=0, vtype=GRB.INTEGER, name=f"y_{i+1}") for i in range(n)]
    o_x = [model.addVar(lb=0, vtype=GRB.INTEGER, name=f"o_x_{i+1}") for i in range(n)]
    o_y = [model.addVar(lb=0, vtype=GRB.INTEGER, name=f"o_y_{i+1}") for i in range(n)]
    
    # Objective: minimize total cost (regular + overtime)
    obj = gp.LinExpr()
    for i in range(n):
        obj += x[i] + y[i] + o_x[i] * overtime_cost_factor + o_y[i] * overtime_cost_factor
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints: coverage for each period for drivers and crew
    for j in range(n):
        covering_drivers = []
        covering_crew = []
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                covering_drivers.append(x[i])
                covering_crew.append(y[i])
                covering_drivers.append(o_x[i])
                covering_crew.append(o_y[i])
        model.addConstr(gp.quicksum(covering_drivers) >= required[j], f"Driver_demand_{j+1}")
        model.addConstr(gp.quicksum(covering_crew) >= required[j], f"Crew_demand_{j+1}")
    
    # Overtime constraint: total overtime shifts <= max_overtime_shifts
    model.addConstr(gp.quicksum(o_x) + gp.quicksum(o_y) <= max_overtime_shifts, "Overtime_limit")
    
    # Night period definition: periods 5 and 6 are considered night periods
    night_periods = [4, 5]  # indices 0-based
    
    # Driver night fraction constraint
    total_driver_starts = gp.quicksum(x) + gp.quicksum(o_x)
    night_driver_starts = gp.quicksum([x[i] + o_x[i] for i in night_periods])
    model.addConstr(night_driver_starts <= max_night_driver_fraction * total_driver_starts, "Night_driver_fraction")
    
    # Crew night fraction constraint
    total_crew_starts = gp.quicksum(y) + gp.quicksum(o_y)
    night_crew_starts = gp.quicksum([y[i] + o_y[i] for i in night_periods])
    model.addConstr(night_crew_starts <= max_night_crew_fraction * total_crew_starts, "Night_crew_fraction")
    
    # Solve the model
    model.optimize()
    
    # Print solution details
    print("Regular Drivers Starts:")
    for i in range(n):
        print(f"Period {i+1}: {x[i].x}")
    print("\nRegular Crew Starts:")
    for i in range(n):
        print(f"Period {i+1}: {y[i].x}")
    print("\nOvertime Drivers Starts:")
    for i in range(n):
        print(f"Period {i+1}: {o_x[i].x}")
    print("\nOvertime Crew Starts:")
    for i in range(n):
        print(f"Period {i+1}: {o_y[i].x}")
    
    print(f"\nFINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
