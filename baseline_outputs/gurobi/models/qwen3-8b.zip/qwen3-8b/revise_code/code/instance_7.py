import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Get the data directory path
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, '..', 'data')

# Load warehouse data
warehouses_data = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        warehouses_data.append(row)

warehouses = [row['Warehouse'] for row in warehouses_data]
supply = {row['Warehouse']: int(row['Empty_Containers']) for row in warehouses_data}

# Load port data
ports_data = []
with open(os.path.join(data_dir, 'table_2.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        ports_data.append(row)

ports = [row['Port'] for row in ports_data]
demand = {row['Port']: int(row['Container_Demand']) for row in ports_data}

# Load distance data
distance_data = []
with open(os.path.join(data_dir, 'table_3.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        distance_data.append(row)

distance = {}
for row in distance_data:
    wh = row['Warehouse']
    for port in ports:
        distance[(wh, port)] = float(row[port])

# Load general parameters
params_data = []
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params_data.append(row)

params = {row['Parameter_Name']: float(row['Value']) for row in params_data}
cost_per_km = params['cost_per_km']
truck_capacity = params['truck_capacity']
adriatic_pool_shortage_trigger = params['adriatic_pool_shortage_trigger']
adriatic_pool_recovery_fee = params['adriatic_pool_recovery_fee']

# Load shortage penalty data
shortage_penalty_data = []
with open(os.path.join(data_dir, 'shortage_penalty.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        shortage_penalty_data.append(row)

shortage_charge = {row['Port']: float(row['Shortage_Charge']) for row in shortage_penalty_data}
grace_containers = {row['Port']: int(row['Grace_Containers']) for row in shortage_penalty_data}
recovery_fee = {row['Port']: float(row['Recovery_Fee']) for row in shortage_penalty_data}

# Create model
model = gp.Model("Container_Transportation")

# Decision variables: number of containers from warehouse i to port j
x = {}
for i in warehouses:
    for j in ports:
        x[(i, j)] = model.addVar(vtype=GRB.INTEGER, name=f"x_{i}_{j}")

# Decision variable: whether recovery desk is opened for port j
recovery = {}
for j in ports:
    recovery[j] = model.addVar(vtype=GRB.BINARY, name=f"recovery_{j}")

# Decision variable: whether Adriatic regional recovery desk is opened
adriatic_recovery = model.addVar(vtype=GRB.BINARY, name="adriatic_recovery")

# Objective function: minimize total cost (transport + shortage + recovery)
total_cost = 0
for i in warehouses:
    for j in ports:
        total_cost += x[(i, j)] * distance[(i, j)] * cost_per_km

# Shortage charge for each port
for j in ports:
    uncovered_demand = demand[j] - sum(x[(i, j)] for i in warehouses)
    if uncovered_demand > 0:
        total_cost += uncovered_demand * shortage_charge[j]

# Recovery fee for each port
for j in ports:
    uncovered_demand = demand[j] - sum(x[(i, j)] for i in warehouses)
    if uncovered_demand > grace_containers[j]:
        total_cost += recovery_fee[j] * recovery[j]

# Regional recovery fee if combined uncovered demand exceeds trigger
uncovered_demand_venice = demand['Venice'] - sum(x[(i, 'Venice')] for i in warehouses)
uncovered_demand_ancona = demand['Ancona'] - sum(x[(i, 'Ancona')] for i in warehouses)
uncovered_demand_bari = demand['Bari'] - sum(x[(i, 'Bari')] for i in warehouses)
combined_uncovered_demand = uncovered_demand_venice + uncovered_demand_ancona + uncovered_demand_bari
if combined_uncovered_demand > adriatic_pool_shortage_trigger:
    total_cost += adriatic_pool_recovery_fee * adriatic_recovery

model.setObjective(total_cost, GRB.MINIMIZE)

# Supply constraints
for i in warehouses:
    model.addConstr(sum(x[(i, j)] for j in ports) <= supply[i], f"supply_{i}")

# Demand constraints
for j in ports:
    model.addConstr(sum(x[(i, j)] for i in warehouses) >= demand[j], f"demand_{j}")

# Ensure that regional recovery desk is opened if combined shortage exceeds trigger
model.addConstr(
    uncovered_demand_venice + uncovered_demand_ancona + uncovered_demand_bari >= adriatic_pool_shortage_trigger,
    "adriatic_shortage"
)

# Solve the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
