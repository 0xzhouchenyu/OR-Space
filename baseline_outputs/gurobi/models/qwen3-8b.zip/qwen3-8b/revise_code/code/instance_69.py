import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(data_path)
    
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = row['Value']
        
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = int(params['raw_bar_length'])
    setup_cost_per_pattern = float(params['setup_cost_per_pattern'])
    max_distinct_patterns = int(params['max_distinct_patterns'])
    
    len1 = 3
    len2 = 4
    len3 = 5
    
    # Generate all valid cutting patterns
    patterns = []
    for x in range(L // len1 + 1):
        for y in range(L // len2 + 1):
            for z in range(L // len3 + 1):
                if len1 * x + len2 * y + len3 * z <= L:
                    if x > 0 or y > 0 or z > 0:
                        patterns.append((x, y, z))
    
    model = gp.Model("CuttingStock")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of times each pattern is used
    pattern_vars = model.addVars(len(patterns), lb=0, vtype=GRB.INTEGER, name="Pattern")
    
    # Objective: minimize total waste (including setup cost)
    total_waste = 0
    for i in range(len(patterns)):
        x, y, z = patterns[i]
        waste = L - (len1 * x + len2 * y + len3 * z)
        total_waste += waste * pattern_vars[i]
    
    setup_waste = setup_cost_per_pattern * sum(1 for i in range(len(patterns)) if pattern_vars[i].X > 0)
    model.setObjective(total_waste + setup_waste, GRB.MINIMIZE)
    
    # Constraints: satisfy the demand for each type of steel bar
    model.addConstr(sum(patterns[i][0] * pattern_vars[i] for i in range(len(patterns))) >= q3)
    model.addConstr(sum(patterns[i][1] * pattern_vars[i] for i in range(len(patterns))) >= q4)
    model.addConstr(sum(patterns[i][2] * pattern_vars[i] for i in range(len(patterns))) >= q5)
    
    # Constraint: limit the number of distinct patterns used
    model.addConstr(sum(1 for i in range(len(patterns)) if pattern_vars[i].X > 0) <= max_distinct_patterns)
    
    model.optimize()
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    solve()
