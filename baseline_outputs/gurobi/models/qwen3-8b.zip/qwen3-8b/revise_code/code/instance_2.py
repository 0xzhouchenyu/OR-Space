import os
import csv
import gurobipy as gp
from gurobipy import GRB

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load parameters
general_params_path = os.path.join(data_dir, "general_parameters.csv")
table1_path = os.path.join(data_dir, "table_1.csv")

params = {}
with open(general_params_path, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

a1 = params['a1']
a2 = params['a2']
training_capacity_per_jet = params['training_capacity_per_jet']
training_duration = params['training_duration']
dual_use_training_efficiency = params['dual_use_training_efficiency']
training_intensity_cap = params['training_intensity_cap']
combat_jet_min_year2 = params['combat_jet_min_year2']
combat_weight = params['combat_weight']
training_weight = params['training_weight']

# Create model
model = gp.Model("FighterJetOptimization")

# Decision variables
x1 = model.addVar(name="x1", lb=0, ub=a1, vtype=GRB.CONTINUOUS)  # Training jets in year 1
x2 = model.addVar(name="x2", lb=0, ub=a1 + a2, vtype=GRB.CONTINUOUS)  # Training jets in year 2
c2 = model.addVar(name="c2", lb=0, ub=a2, vtype=GRB.CONTINUOUS)  # Combat jets in year 2
d1 = model.addVar(name="d1", lb=0, ub=a1, vtype=GRB.CONTINUOUS)  # Dual-use jets in year 1
d2 = model.addVar(name="d2", lb=0, ub=a2, vtype=GRB.CONTINUOUS)  # Dual-use jets in year 2

# Constraints
# Training intensity cap (year 1)
model.addConstr(x1 + d1 <= training_intensity_cap * a1, "TrainingIntensityCapYear1")

# Training intensity cap (year 2)
model.addConstr(x2 + d2 <= training_intensity_cap * (a1 + a2), "TrainingIntensityCapYear2")

# Year 2 combat jet minimum requirement
model.addConstr(c2 >= combat_jet_min_year2, "CombatJetMinYear2")

# Training jets in year 2 must include previous training jets
model.addConstr(x2 >= x1, "TrainingContinuity")

# Dual-use jets cannot exceed production in each year
model.addConstr(d1 <= a1, "DualUseYear1")
model.addConstr(d2 <= a2, "DualUseYear2")

# Objective function: weighted sum of combat jets and trained pilots
# Trained pilots = training_capacity_per_jet * (x1 + x2 * dual_use_training_efficiency + d1 * dual_use_training_efficiency + d2 * dual_use_training_efficiency)
trained_pilots = training_capacity_per_jet * (x1 + x2 * dual_use_training_efficiency + d1 * dual_use_training_efficiency + d2 * dual_use_training_efficiency)
objective = combat_weight * c2 + training_weight * trained_pilots
model.setObjective(objective, GRB.MAXIMIZE)

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {objective.getValue()}")
