import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, "table_1.csv")
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "general_parameters.csv")
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    machine_avail = params['machine_time_available']  # hours
    craftsman_regular_avail = params['craftsman_regular_time_available']  # hours
    craftsman_overtime_avail = params['craftsman_overtime_available']  # hours
    machine_cost = params['machine_time_cost']  # GBP per hour
    craftsman_regular_cost = params['craftsman_time_cost']  # GBP per hour
    craftsman_overtime_cost = params['craftsman_overtime_cost']  # GBP per hour
    rev_X = params['revenue_product_X']  # GBP per batch
    rev_Y = params['revenue_product_Y']  # GBP per batch
    min_X = params['min_batches_product_X']  # batches
    product_Y_QA_threshold = params['product_Y_QA_threshold']  # batches
    product_Y_QA_fee = params['product_Y_QA_fee']  # GBP
    
    # Create model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables (continuous, non-negative)
    X = model.addVar(lb=0, name="X")
    Y = model.addVar(lb=0, name="Y")
    
    # Calculate machine and craftsman time used
    machine_hours_used = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0
    craftsman_hours_used = (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0
    
    # Split craftsman hours into regular and overtime
    craftsman_regular_used = model.addVar(lb=0, name="Craftsman_Regular_Used")
    craftsman_overtime_used = model.addVar(lb=0, name="Craftsman_Overtime_Used")
    
    model.addConstr(craftsman_regular_used + craftsman_overtime_used == craftsman_hours_used)
    model.addConstr(craftsman_regular_used <= craftsman_regular_avail)
    model.addConstr(craftsman_overtime_used <= craftsman_overtime_avail)
    
    # Cost calculation
    machine_cost_total = machine_cost * machine_hours_used
    craftsman_regular_cost_total = craftsman_regular_cost * craftsman_regular_used
    craftsman_overtime_cost_total = craftsman_overtime_cost * craftsman_overtime_used
    qa_fee = product_Y_QA_fee * (Y > product_Y_QA_threshold)
    
    # Objective: maximize revenue - costs
    profit = rev_X * X + rev_Y * Y - machine_cost_total - craftsman_regular_cost_total - craftsman_overtime_cost_total - qa_fee
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Constraints
    model.addConstr(machine_hours_used <= machine_avail, "Machine_Time_Constraint")
    model.addConstr(X >= min_X, "Min_Production_X")
    
    # Solve
    model.optimize()
    
    obj_val = model.objVal
    
    print(f"FINAL_OBJ_VALUE: {obj_val:.2f}")

if __name__ == "__main__":
    main()
