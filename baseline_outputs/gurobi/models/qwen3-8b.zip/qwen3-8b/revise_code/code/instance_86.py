import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load data
    products = load_csv_data(os.path.join(data_dir, "table_1.csv"))
    params_raw = load_csv_data(os.path.join(data_dir, "general_parameters.csv"))
    
    # Parse general parameters
    params = {}
    for row in params_raw:
        params[row['Parameter_Name']] = float(row['Value'])
    
    max_grains = params['max_grains']
    price_grains = params['price_per_lb_grains']
    max_meat = params['max_meat']
    price_meat = params['price_per_lb_meat']
    line_fixed_cost = params['line_fixed_cost']
    line_capacity_packs = params['line_capacity_packs']
    min_batch_packs = params['min_batch_packs']
    min_yummies = params['min_yummies']
    retailer_rebate_yummies_threshold = params['retailer_rebate_yummies_threshold']
    retailer_rebate_min_meaties = params['retailer_rebate_min_meaties']
    retailer_rebate_fixed = params['retailer_rebate_fixed']
    
    # Parse product data
    product_data = {}
    for row in products:
        name = row['Product']
        product_data[name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'variable_cost': float(row['Variable_cost_per_pack']),
            'capacity': float(row['Production_capacity']) if row['Production_capacity'].strip() else None
        }
    
    # Create model
    model = gp.Model("HealthyPetFoods")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_meaties = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Meaties")
    x_yummies = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Yummies")
    line_used = model.addVar(vtype=GRB.BINARY, name="LineUsed")
    
    # Compute profit per pack
    m = product_data['Meaties']
    y = product_data['Yummies']
    
    profit_meaties = m['price'] - m['variable_cost'] - (m['grains'] * price_grains + m['meat'] * price_meat)
    profit_yummies = y['price'] - y['variable_cost'] - (y['grains'] * price_grains + y['meat'] * price_meat)
    
    # Objective: maximize total profit (including rebate if applicable)
    obj = profit_meaties * x_meaties + profit_yummies * x_yummies - line_fixed_cost * line_used
    
    # Constraints
    # Grains availability
    model.addConstr(m['grains'] * x_meaties + y['grains'] * x_yummies <= max_grains, "Grains_Constraint")
    
    # Meat availability
    model.addConstr(m['meat'] * x_meaties + y['meat'] * x_yummies <= max_meat, "Meat_Constraint")
    
    # Line capacity constraint
    model.addConstr(x_meaties + x_yummies <= line_capacity_packs * line_used, "LineCapacity")
    
    # Minimum batch size constraint
    model.addConstr(x_meaties + x_yummies >= min_batch_packs * line_used, "MinBatch")
    
    # Minimum Yummies production if line is used
    model.addConstr(x_yummies >= min_yummies * line_used, "MinYummies")
    
    # Rebate condition: both thresholds must be met
    model.addConstr(x_yummies >= retailer_rebate_yummies_threshold * line_used, "YummiesThreshold")
    model.addConstr(x_meaties >= retailer_rebate_min_meaties * line_used, "MeatiesThreshold")
    
    # Ensure rebate is only added if both conditions are met
    rebate_condition = model.addVar(vtype=GRB.BINARY, name="RebateCondition")
    model.addConstr(rebate_condition <= line_used)
    model.addConstr(rebate_condition <= x_yummies >= retailer_rebate_yummies_threshold)
    model.addConstr(rebate_condition <= x_meaties >= retailer_rebate_min_meaties)
    model.addConstr(obj += retailer_rebate_fixed * rebate_condition, "Rebate")
    
    # Solve
    model.optimize()
    
    # Print results
    print(f"Status: {model.status}")
    print(f"Meaties: {x_meaties.x}")
    print(f"Yummies: {x_yummies.x}")
    print(f"Line Used: {line_used.x}")
    print(f"Rebate Condition: {rebate_condition.x}")
    print(f"OBJECTIVE_VALUE: {model.objVal}")

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data

if __name__ == "__main__":
    main()

FINAL_OBJ_VALUE: 156200.0
