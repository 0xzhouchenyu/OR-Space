import os
import sys
import gurobipy as gp
from gurobipy import GRB

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils import load_parameters, load_demand

params = load_parameters()
demand = load_demand()

T = 8  # weeks
weeks = range(1, T + 1)

# Parameters
S0 = params['skilled_worker_count']  # 50
rate_I = params['food_I_production_rate']  # 10 kg/h
rate_II = params['food_II_production_rate']  # 6 kg/h
normal_hours = params['worker_weekly_hours']  # 40
overtime_hours = params['skilled_worker_overtime_hours']  # 60
train_cap = params['training_capacity']  # 3 trainees per trainer
train_period = params['training_period']  # 2 weeks
wage_skilled = params['skilled_worker_weekly_wage']  # 360
wage_trainee_during = params['trainee_weekly_wage_during_training']  # 120
wage_trainee_after = params['trainee_weekly_wage_after_training']  # 240
wage_overtime = params['skilled_worker_overtime_wage']  # 540
comp_I = params['compensation_fee_food_I']  # 0.5
comp_II = params['compensation_fee_food_II']  # 0.6
new_worker_goal = params['new_worker_training_goal']  # 50

model = gp.Model("factory_training")

# Decision variables
# n_train[t] = number of skilled workers assigned to training starting in week t
n_train = {}
for t in weeks:
    if t <= T - 1:  # Can start training in weeks 1..7 (need 2 weeks)
        n_train[t] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"n_train_{t}")

# Weekly production choice: 0 for Food I, 1 for Food II, 2 for idle
prod_choice = {}
for t in weeks:
    prod_choice[t] = model.addVar(vtype=GRB.INTEGER, lb=0, ub=2, name=f"prod_choice_{t}")

# Hours allocated to food I and II by skilled workers (normal and overtime)
h_I_s = {t: model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"hIs_{t}") for t in weeks}
h_II_s = {t: model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"hIIs_{t}") for t in weeks}
h_I_ot = {t: model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"hIot_{t}") for t in weeks}
h_II_ot = {t: model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"hIIot_{t}") for t in weeks}

# Graduated trainees hours
h_I_g = {t: model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"hIg_{t}") for t in weeks}
h_II_g = {t: model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"hIIg_{t}") for t in weeks}

# Number of skilled workers doing overtime in week t
n_overtime = {t: model.addVar(lb=0, vtype=GRB.INTEGER, name=f"n_ot_{t}") for t in weeks}

# Delayed delivery (backlog) for food I and II
backlog_I = {t: model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"bI_{t}") for t in weeks}
backlog_II = {t: model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"bII_{t}") for t in weeks}

# Objective function: minimize total cost
obj = 0

# Skilled worker wages
for t in weeks:
    # Skilled worker normal hours
    obj += wage_skilled * (normal_hours * (S0 - n_overtime[t]) * (prod_choice[t] == 0 or prod_choice[t] == 2))
    obj += wage_skilled * (normal_hours * (S0 - n_overtime[t]) * (prod_choice[t] == 1 or prod_choice[t] == 2))
    # Skilled worker overtime hours
    obj += wage_overtime * (overtime_hours * n_overtime[t] * (prod_choice[t] == 0 or prod_choice[t] == 2))
    obj += wage_overtime * (overtime_hours * n_overtime[t] * (prod_choice[t] == 1 or prod_choice[t] == 2))

# Trainee wages during training
for t in weeks:
    if t <= T - 1:
        obj += wage_trainee_during * train_cap * n_train[t]

# Graduated trainee wages after training
for t in weeks:
    grads_t = 0
    for s in n_train:
        if s + train_period <= t:
            grads_t += train_cap * n_train[s]
    obj += wage_trainee_after * normal_hours * grads_t * (prod_choice[t] == 0 or prod_choice[t] == 2)
    obj += wage_trainee_after * normal_hours * grads_t * (prod_choice[t] == 1 or prod_choice[t] == 2)

# Compensation fees
for t in weeks:
    obj += comp_I * backlog_I[t]
    obj += comp_II * backlog_II[t]

model.setObjective(obj, GRB.MINIMIZE)

# Constraints for each week
for t in weeks:
    busy_t = 0
    for s in n_train:
        if s <= t <= s + train_period - 1:
            busy_t += n_train[s]
    avail_skilled_t = S0 - busy_t
    grads_t = 0
    for s in n_train:
        if s + train_period <= t:
            grads_t += train_cap * n_train[s]

    # Skilled workers available for production
    model.addConstr(n_overtime[t] <= avail_skilled_t, f"ot_limit_{t}")

    # Mutual exclusion constraint: only one type of food can be produced in a week
    model.addConstr(h_I_s[t] + h_II_s[t] + h_I_ot[t] + h_II_ot[t] + h_I_g[t] + h_II_g[t] == 0, f"mutual_exclusion_{t}")
    model.addConstr((h_I_s[t] + h_I_ot[t] + h_I_g[t]) == 0, f"mutual_exclusion_food_I_{t}")
    model.addConstr((h_II_s[t] + h_II_ot[t] + h_II_g[t]) == 0, f"mutual_exclusion_food_II_{t}")

    # Skilled workers' hours constraints
    model.addConstr(h_I_s[t] + h_II_s[t] <= (avail_skilled_t - n_overtime[t]) * normal_hours, f"skilled_normal_hours_{t}")
    model.addConstr(h_I_ot[t] + h_II_ot[t] <= n_overtime[t] * overtime_hours, f"skilled_ot_hours_{t}")

    # Graduated trainees' hours constraints
    model.addConstr(h_I_g[t] + h_II_g[t] <= grads_t * normal_hours, f"grad_hours_{t}")

    # Production in week t
    prod_I_t = (h_I_s[t] + h_I_ot[t] + h_I_g[t]) * rate_I
    prod_II_t = (h_II_s[t] + h_II_ot[t] + h_II_g[t]) * rate_II

    # Backlog balance
    prev_bI = backlog_I[t-1] if t > 1 else 0
    prev_bII = backlog_II[t-1] if t > 1 else 0

    model.addConstr(backlog_I[t] >= prev_bI + demand[t]['I'] - prod_I_t, f"backlog_I_{t}")
    model.addConstr(backlog_II[t] >= prev_bII + demand[t]['II'] - prod_II_t, f"backlog_II_{t}")

# Training constraints
for t in weeks:
    if t <= T - 1:
        model.addConstr(n_train[t] <= S0 - sum(n_train[s] for s in weeks if s <= t and s + train_period - 1 >= t), f"train_limit_{t}")

# Ensure enough skilled workers are available for training
for t in weeks:
    busy_t = 0
    for s in n_train:
        if s <= t <= s + train_period - 1:
            busy_t += n_train[s]
    model.addConstr(S0 - busy_t >= 0, f"enough_skilled_{t}")

# Must train at least new_worker_training_goal new workers by end of week 8
total_trained = 0
for t in weeks:
    if t <= T - 1:
        total_trained += train_cap * n_train[t]
model.addConstr(total_trained >= new_worker_goal, f"new_worker_goal_{T}")

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
