import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    # Load parameters
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(csv_path)
    params = dict(zip(df['Parameter_Name'], df['Value']))

    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # Variables: Production levels for each commodity
    x = {c: gp.Model().addVar(lb=0, name=f"x_{c}") for c in commodities}
    # Variables: Import quantities for each commodity
    i = {c: gp.Model().addVar(lb=0, name=f"i_{c}") for c in commodities}

    # Model
    model = gp.Model("Maximize_GDP")
    model.setParam('OutputFlag', 0)

    # Objective: GDP = Export revenue - Import costs
    gdp = gp.LinExpr()
    for c in commodities:
        export_revenue = params[f"{c}_price"] * (x[c] - gp.quicksum(params.get(f"{c_prime}_{c}_requirement", 0.0) * x[c_prime] for c_prime in commodities))
        import_cost = params.get(f"{c}_import_cost", 0.0) * x[c] + params["import_premium_ratio"] * params[f"{c}_price"] * i[c]
        gdp += export_revenue - import_cost
    model.setObjective(gdp, GRB.MAXIMIZE)

    # Constraints
    # 1. Domestic production must satisfy domestic demand (net export >= 0)
    for c in commodities:
        model.addConstr(x[c] - gp.quicksum(params.get(f"{c_prime}_{c}_requirement", 0.0) * x[c_prime] for c_prime in commodities) >= 0, f"Domestic_Demand_{c}")

    # 2. Labor constraint (regular + overtime)
    regular_labor = gp.quicksum(params.get(f"{c}_labor_requirement", 0.0) * x[c] for c in commodities)
    overtime_labor = gp.quicksum(params.get(f"{c}_labor_requirement", 0.0) * x[c] for c in commodities)
    model.addConstr(regular_labor + overtime_labor <= params["labor_force"] + params["overtime_cap"], "Labor_Limit")

    # 3. Import quota constraint
    for c in commodities:
        model.addConstr(i[c] <= params["import_quota"], f"Import_Quota_{c}")

    # Solve the model
    model.optimize()

    return model.objVal

if __name__ == '__main__':
    result = solve()
    print(f"FINAL_OBJ_VALUE: {round(result, 3)}")
