import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Construct paths
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, '..', 'data')

# Load data
def load_feed_data(filepath):
    feeds = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            feed = {
                'Feed': int(row['Feed']),
                'Protein_g': float(row['Protein_g']),
                'Minerals_g': float(row['Minerals_g']),
                'Vitamins_mg': float(row['Vitamins_mg']),
                'Price_Y_per_kg': float(row['Price_Y_per_kg']),
            }
            feeds.append(feed)
    return feeds

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

feeds = load_feed_data(os.path.join(data_dir, 'table_1.csv'))
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

min_protein = params['min_protein_requirement']
min_minerals = params['min_minerals_requirement']
min_vitamins = params['min_vitamins_requirement']

# Create model
model = gp.Model("MinimizeFeedCost")

# Decision variables: amount of each feed (kg), non-negative
x = {}
for f in feeds:
    x[f['Feed']] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{f['Feed']}")

# Objective: minimize total cost
model.setObjective(gp.quicksum(f['Price_Y_per_kg'] * x[f['Feed']] for f in feeds), GRB.MINIMIZE)

# Constraints
# Protein constraint
model.addConstr(gp.quicksum(f['Protein_g'] * x[f['Feed']] for f in feeds) >= min_protein, "ProteinRequirement")

# Minerals constraint
model.addConstr(gp.quicksum(f['Minerals_g'] * x[f['Feed']] for f in feeds) >= min_minerals, "MineralsRequirement")

# Vitamins constraint
model.addConstr(gp.quicksum(f['Vitamins_mg'] * x[f['Feed']] for f in feeds) >= min_vitamins, "VitaminsRequirement")

# Mutual exclusion constraint between Feed 4 and Feed 5
model.addConstr(x[4] + x[5] <= 1, "MutualExclusion")

# Solve
model.setParam('OutputFlag', 0)
model.optimize()

# Print results
for f in feeds:
    val = x[f['Feed']].x
    print(f"Feed {f['Feed']}: {val:.6f} kg")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
