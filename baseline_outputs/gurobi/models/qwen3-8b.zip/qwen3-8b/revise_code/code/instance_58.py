import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load parameters
    general_params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row['Parameter_Name']] = float(row['Value'])
    
    # Initialize model
    model = gp.Model("farm_optimization")
    model.setParam('OutputFlag', 0)
    
    # Parameters
    profit_apples = general_params['profit_per_acre_apples']
    profit_pears = general_params['profit_per_acre_pears']
    profit_oranges = general_params['profit_per_acre_oranges']
    profit_lemons = general_params['profit_per_acre_lemons']
    total_area = general_params['total_farm_area']
    min_a_to_p = general_params['min_apples_to_pears_ratio']
    min_a_to_l = general_params['min_apples_to_lemons_ratio']
    o_to_l = general_params['oranges_to_lemons_ratio']
    max_types = int(general_params['max_fruit_types'])
    
    water_apples_spring = general_params['water_per_acre_apples_spring']
    water_apples_autumn = general_params['water_per_acre_apples_autumn']
    water_pears_spring = general_params['water_per_acre_pears_spring']
    water_pears_autumn = general_params['water_per_acre_pears_autumn']
    water_oranges_spring = general_params['water_per_acre_oranges_spring']
    water_oranges_autumn = general_params['water_per_acre_oranges_autumn']
    water_lemons_spring = general_params['water_per_acre_lemons_spring']
    water_lemons_autumn = general_params['water_per_acre_lemons_autumn']
    water_cap_spring = general_params['water_cap_spring']
    water_cap_autumn = general_params['water_cap_autumn']
    total_water_budget = general_params['total_water_budget']
    min_annual_water_per_fruit = general_params['min_annual_water_per_fruit']
    diversification_reward = general_params['diversification_reward']
    
    fruits = ['apples', 'pears', 'oranges', 'lemons']
    
    # Decision variables: spring and autumn acres for each fruit
    spring = {f: model.addVar(name=f"spring_{f}", lb=0) for f in fruits}
    autumn = {f: model.addVar(name=f"autumn_{f}", lb=0) for f in fruits}
    
    # Total annual acres (used for ratio constraints)
    total_apples = spring['apples'] + autumn['apples']
    total_pears = spring['pears'] + autumn['pears']
    total_oranges = spring['oranges'] + autumn['oranges']
    total_lemons = spring['lemons'] + autumn['lemons']
    
    # Constraints: seasonal land area limits
    model.addConstr(spring['apples'] + spring['pears'] + spring['oranges'] + spring['lemons'] <= total_area, "spring_land")
    model.addConstr(autumn['apples'] + autumn['pears'] + autumn['oranges'] + autumn['lemons'] <= total_area, "autumn_land")
    
    # Constraints: seasonal water usage
    spring_water = (
        water_apples_spring * spring['apples'] +
        water_pears_spring * spring['pears'] +
        water_oranges_spring * spring['oranges'] +
        water_lemons_spring * spring['lemons']
    )
    model.addConstr(spring_water <= water_cap_spring, "spring_water")
    
    autumn_water = (
        water_apples_autumn * autumn['apples'] +
        water_pears_autumn * autumn['pears'] +
        water_oranges_autumn * autumn['oranges'] +
        water_lemons_autumn * autumn['lemons']
    )
    model.addConstr(autumn_water <= water_cap_autumn, "autumn_water")
    
    # Annual water usage per fruit
    annual_water = {
        'apples': spring_water + autumn_water,
        'pears': spring_water + autumn_water,
        'oranges': spring_water + autumn_water,
        'lemons': spring_water + autumn_water
    }
    
    for f in fruits:
        model.addConstr(annual_water[f] >= min_annual_water_per_fruit * (spring[f] + autumn[f]), f"min_water_{f}")
    
    # Annual mix constraints
    model.addConstr(total_apples >= min_a_to_p * total_pears, "a_to_p_ratio")
    model.addConstr(total_apples >= min_a_to_l * total_lemons, "a_to_l_ratio")
    model.addConstr(total_oranges == o_to_l * total_lemons, "o_to_l_ratio")
    
    # Diversification reward
    used_fruits = [f for f in fruits if (spring[f] + autumn[f]) > 0]
    num_used_fruits = len(used_fruits)
    model.addGenConstrIndicator(num_used_fruits >= 2, diversification_reward, name="diversification_reward")
    
    # Objective: maximize profit + diversification reward
    profit = (
        profit_apples * (spring['apples'] + autumn['apples']) +
        profit_pears * (spring['pears'] + autumn['pears']) +
        profit_oranges * (spring['oranges'] + autumn['oranges']) +
        profit_lemons * (spring['lemons'] + autumn['lemons'])
    )
    model.setObjective(profit + diversification_reward, GRB.MAXIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Extract solution
    solution = {
        'apples': spring['apples'].x + autumn['apples'].x,
        'pears': spring['pears'].x + autumn['pears'].x,
        'oranges': spring['oranges'].x + autumn['oranges'].x,
        'lemons': spring['lemons'].x + autumn['lemons'].x
    }
    
    print(f"Optimal solution: {solution}")
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

solve()
