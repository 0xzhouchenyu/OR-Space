import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Extract parameters
min_A = params['min_raw_material_A']
min_B = params['min_raw_material_B']
min_C = params['min_raw_material_C']

cap_A_a = params['warehouse_A_truck_capacity_A']
cap_A_b = params['warehouse_A_truck_capacity_B']
cap_A_c = params['warehouse_A_truck_capacity_C']
cost_A = params['warehouse_A_truck_cost']
fixed_A = params['warehouse_A_fixed_cost']

cap_B_a = params['warehouse_B_truck_capacity_A']
cap_B_b = params['warehouse_B_truck_capacity_B']
cap_B_c = params['warehouse_B_truck_capacity_C']
cost_B = params['warehouse_B_truck_cost']
fixed_B = params['warehouse_B_fixed_cost']
overflow_threshold_B = params['warehouse_B_overflow_threshold_trucks']
overflow_coordination_cost_B = params['warehouse_B_overflow_coordination_cost']
dual_warehouse_reconciliation_fee = params['dual_warehouse_reconciliation_fee']

# Create the model
model = gp.Model("MinFreightCost")

# Decision variables: number of trucks from warehouse A and B (integers, non-negative)
x = model.addVar(vtype=GRB.INTEGER, name="trucks_from_A", lb=0)
y = model.addVar(vtype=GRB.INTEGER, name="trucks_from_B", lb=0)

# Objective function: total freight cost including fixed costs and reconciliation fee
total_cost = (
    fixed_A * x + fixed_B * y +
    cost_A * x + cost_B * y +
    overflow_coordination_cost_B * (y - overflow_threshold_B) if y > overflow_threshold_B else 0 +
    dual_warehouse_reconciliation_fee * (1 if (x > 0 and y > 0) else 0)
)

model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints: meet minimum raw material requirements
model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# Solve the model
model.Params.OutputFlag = 0
model.optimize()

# Output results
print(f"Status: {model.Status}")
print(f"Trucks from Warehouse A: {int(x.x)}")
print(f"Trucks from Warehouse B: {int(y.x)}")
print(f"OBJECTIVE_VALUE: {model.ObjVal}")

FINAL_OBJ_VALUE: 4950.0
