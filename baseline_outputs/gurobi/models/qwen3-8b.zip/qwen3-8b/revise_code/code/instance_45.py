import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])

    # Read product segments and profits
    products = []
    segments = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row["Product"]
            if p not in segments:
                segments[p] = []
                products.append(p)
            rng = row["Sales_Volume_Range"]
            profit = float(row["Profit"])
            if rng.startswith("Above_"):
                lower = float(rng.split("_")[1])
                upper = None
            else:
                parts = rng.split("_")
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({"lower": lower, "upper": upper, "profit": profit})

    model = gp.Model("Maximize_Profit")
    model.setParam("OutputFlag", 0)

    x = {}
    p_var = {}
    y = {}

    for prod in products:
        pname = prod.split("_")[1]
        x[prod] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{pname}")
        p_var[prod] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"p_{pname}")
        y[prod] = []
        for i in range(len(segments[prod])):
            yi = model.addVar(vtype=GRB.BINARY, name=f"y_{pname}_{i}")
            y[prod].append(yi)

    # Objective
    model.setObjective(gp.quicksum(p_var[prod] for prod in products), GRB.MAXIMIZE)

    for prod in products:
        segs = segments[prod]
        # Mutual exclusivity: at most one segment active
        model.addConstr(gp.quicksum(y[prod]) <= 1)

        for i, seg in enumerate(segs):
            lo = seg["lower"]
            hi = seg["upper"]
            profit = seg["profit"]

            # If y[i]=1, x must be in [lo+1, hi] (or [lo+1, inf] for last segment)
            if lo == 0:
                model.addConstr(x[prod] >= 1 - 10000 * (1 - y[prod][i]))
            else:
                model.addConstr(x[prod] >= (lo + 1) - 10000 * (1 - y[prod][i]))

            if hi is not None:
                model.addConstr(x[prod] <= hi + 10000 * (1 - y[prod][i]))

            # Profit bound
            model.addConstr(p_var[prod] <= profit * x[prod] + 10000 * (1 - y[prod][i]))

        # If no segment active (production=0), force x=0 and profit=0
        model.addConstr(x[prod] <= 10000 * gp.quicksum(y[prod]))
        model.addConstr(p_var[prod] <= 10000 * gp.quicksum(y[prod]))

    # Resource constraints
    # Labor time
    regular_labor_time = params["available_labor_time"]
    overtime_cap_hours = params["overtime_cap_hours"]
    overtime_cost_per_hour = params["overtime_cost_per_hour"]
    overtime_second_review_threshold = params["overtime_second_review_threshold"]
    overtime_second_review_fee = params["overtime_second_review_fee"]

    total_labor_time = 0
    for prod in products:
        total_labor_time += params[f"labor_time_{prod.split('_')[1]}"] * x[prod]

    regular_labor_used = min(total_labor_time, regular_labor_time)
    overtime_labor_used = max(total_labor_time - regular_labor_time, 0)

    model.addConstr(total_labor_time <= regular_labor_time + overtime_cap_hours)

    # Overtime cost
    model.addConstr(p_var["Product_A"] -= overtime_cost_per_hour * overtime_labor_used)
    model.addConstr(p_var["Product_B"] -= overtime_cost_per_hour * overtime_labor_used)
    model.addConstr(p_var["Product_C"] -= overtime_cost_per_hour * overtime_labor_used)

    # Second review fee
    if overtime_labor_used > overtime_second_review_threshold:
        model.addConstr(p_var["Product_A"] -= overtime_second_review_fee)
        model.addConstr(p_var["Product_B"] -= overtime_second_review_fee)
        model.addConstr(p_var["Product_C"] -= overtime_second_review_fee)

    # Packaging constraint
    packaging_cap_units = params["packaging_cap_units"]
    pack_units = {
        "A": params["pack_units_A"],
        "B": params["pack_units_B"],
        "C": params["pack_units_C"]
    }

    total_packaging_used = 0
    for prod in products:
        total_packaging_used += pack_units[prod.split("_")[1]] * x[prod]

    model.addConstr(total_packaging_used <= packaging_cap_units)

    # Technical preparation time
    model.addConstr(gp.quicksum(params[f"technical_prep_time_{prod.split('_')[1]}"] * x[prod] for prod in products) <= params["available_technical_prep_time"])

    # Materials
    model.addConstr(gp.quicksum(params[f"materials_{prod.split('_')[1]}"] * x[prod] for prod in products) <= params["available_materials"])

    model.optimize()

    obj = model.objVal
    print(f"FINAL_OBJ_VALUE: {round(obj, 2)}")

if __name__ == "__main__":
    solve()
