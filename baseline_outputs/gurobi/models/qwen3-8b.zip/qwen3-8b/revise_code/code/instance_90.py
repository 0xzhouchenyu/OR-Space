import os
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}

with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Extract parameters
shirts_inventory = params['shirts_inventory']
pants_inventory = params['pants_inventory']
price_a = params['package_a_price']
price_b = params['package_b_price']
price_c = params['package_c_price']

shirts_a = params['package_a_shirts']
pants_a = params['package_a_pants']
shirts_b = params['package_b_shirts']
pants_b = params['package_b_pants']
shirts_c = params['package_c_shirts']
pants_c = params['package_c_pants']

min_campaign_batch_a = params['min_campaign_batch_a']
min_campaign_batch_b = params['min_campaign_batch_b']
min_campaign_batch_c = params['min_campaign_batch_c']

activation_cost_a = params['activation_cost_a']
activation_cost_b = params['activation_cost_b']
activation_cost_c = params['activation_cost_c']

labor_hours_per_A = params['labor_hours_per_A']
labor_hours_per_B = params['labor_hours_per_B']
labor_hours_per_C = params['labor_hours_per_C']
labor_hours_total = params['labor_hours_total']

bigM_a = params['bigM_a']
bigM_b = params['bigM_b']
bigM_c = params['bigM_c']

package_b_review_threshold = params['package_b_review_threshold']
package_b_review_charge = params['package_b_review_charge']
package_c_review_threshold = params['package_c_review_threshold']
package_c_review_charge = params['package_c_review_charge']

# Create model
model = gp.Model("Maximize_Revenue")

# Decision variables
x_a = model.addVar(lb=0, vtype=GRB.INTEGER, name="Package_A")
x_b = model.addVar(lb=0, vtype=GRB.INTEGER, name="Package_B")
x_c = model.addVar(lb=0, vtype=GRB.INTEGER, name="Package_C")

y_a = model.addVar(vtype=GRB.BINARY, name="Campaign_A")
y_b = model.addVar(vtype=GRB.BINARY, name="Campaign_B")
y_c = model.addVar(vtype=GRB.BINARY, name="Campaign_C")

# Objective: maximize revenue - activation costs - review charges
revenue = price_a * x_a + price_b * x_b + price_c * x_c
activation_costs = activation_cost_a * y_a + activation_cost_b * y_b + activation_cost_c * y_c
review_charges = 0

if package_b_review_charge > 0:
    review_charges += package_b_review_charge * (x_b - package_b_review_threshold) * (x_b >= package_b_review_threshold)

if package_c_review_charge > 0:
    review_charges += package_c_review_charge * (x_c - package_c_review_threshold) * (x_c >= package_c_review_threshold)

model.setObjective(revenue - activation_costs - review_charges, GRB.MAXIMIZE)

# Constraints
# Shirts inventory constraint
model.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inventory, "Shirts_Inventory")

# Pants inventory constraint
model.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inventory, "Pants_Inventory")

# Minimum campaign batch constraints
model.addConstr(x_a >= min_campaign_batch_a * y_a, "Min_Package_A")
model.addConstr(x_b >= min_campaign_batch_b * y_b, "Min_Package_B")
model.addConstr(x_c >= min_campaign_batch_c * y_c, "Min_Package_C")

# Labor hours constraint
model.addConstr(labor_hours_per_A * x_a + labor_hours_per_B * x_b + labor_hours_per_C * x_c <= labor_hours_total, "Labor_Hours")

# Big M constraints to link x and y
model.addConstr(x_a <= bigM_a * y_a, "BigM_A")
model.addConstr(x_b <= bigM_b * y_b, "BigM_B")
model.addConstr(x_c <= bigM_c * y_c, "BigM_C")

# Solve the model
model.Params.OutputFlag = 0
model.optimize()

# Output results
print(f"Status: {model.Status}")
print(f"Package A: {int(x_a.x)}")
print(f"Package B: {int(x_b.x)}")
print(f"Package C: {int(x_c.x)}")
print(f"OBJECTIVE_VALUE: {model.ObjVal}")

FINAL_OBJ_VALUE: 1350.0
