import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    total_space = params['mall_total_space']
    rent_pct = params['rent_percentage'] / 100.0
    common_area_factor = params['common_area_factor']
    general_merchandise_third_store_concession = params['general_merchandise_third_store_concession']
    catering_third_store_security_threshold = params['catering_third_store_security_threshold']
    catering_third_store_security_cost = params['catering_third_store_security_cost']
    
    # Read store data
    stores = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            stores.append({
                'name': row['Store_Type'].strip(),
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits  # per-store profit when n stores of this type
            })
    
    model = gp.Model("Shopping_Mall_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    for i in range(len(stores)):
        x[i] = model.addVar(vtype=GRB.INTEGER, lb=stores[i]['min'], ub=stores[i]['max'], name=f"x_{i}")
    
    # Objective function: maximize total rent income
    total_profit = 0
    for i in range(len(stores)):
        n = x[i]
        if 1 in stores[i]['profits']:
            total_profit += n * stores[i]['profits'][1]
        elif 2 in stores[i]['profits']:
            total_profit += n * stores[i]['profits'][2]
        elif 3 in stores[i]['profits']:
            total_profit += n * stores[i]['profits'][3]
    
    # Apply concessions and security costs
    # General Merchandise third store concession
    if 3 in stores[2]['profits']:
        general_merchandise_concession = model.addVar(vtype=GRB.BINARY, name="general_merchandise_concession")
        model.addConstr(general_merchandise_concession <= x[2])
        model.addConstr(general_merchandise_concession >= x[2] - 2)
        model.addConstr(total_profit -= general_merchandise_concession * general_merchandise_third_store_concession)
    
    # Catering third store security cost
    catering_security = model.addVar(vtype=GRB.BINARY, name="catering_security")
    model.addConstr(catering_security <= x[4])
    model.addConstr(catering_security >= x[4] - 2)
    model.addConstr(total_profit -= catering_security * catering_third_store_security_cost)
    
    # Space constraint
    space_used = 0
    for i in range(len(stores)):
        space_used += x[i] * stores[i]['area'] * common_area_factor
    
    model.addConstr(space_used <= total_space)
    
    # Objective: maximize total rent
    model.setObjective(total_profit * rent_pct, GRB.MAXIMIZE)
    
    model.optimize()
    
    # Print results
    print(f"FINAL_OBJ_VALUE: {total_profit * rent_pct}")

if __name__ == '__main__':
    main()
