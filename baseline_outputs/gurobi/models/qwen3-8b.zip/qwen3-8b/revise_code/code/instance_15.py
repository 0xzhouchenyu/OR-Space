import gurobipy as gp
from gurobipy import GRB
import os
import pandas as pd

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params_df = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    demand_df = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))

    param_dict = dict(zip(params_df['Parameter_Name'], params_df['Value']))
    demand = dict(zip(demand_df['stage'], demand_df['tool_requirement']))

    n = int(param_dict['n'])
    cost_new = float(param_dict['cost_new_tool'])
    cost_slow = float(param_dict['cost_slow_repair'])
    cost_fast = float(param_dict['cost_fast_repair'])
    dur_slow = int(param_dict['slow_repair_duration'])
    dur_fast = int(param_dict['fast_repair_duration'])
    max_fast_stage = int(param_dict['max_fast_stage'])
    max_slow_stage = int(param_dict['max_slow_stage'])
    emission_buy = float(param_dict['emission_buy'])
    emission_fast = float(param_dict['emission_fast_repair'])
    emission_slow = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_shortage = float(param_dict['penalty_shortage'])

    model = gp.Model("Tool_Repair_Problem")

    stages = list(range(1, n + 1))

    # Variables
    x = model.addVars(stages, name="buy", lb=0, vtype=GRB.INTEGER)
    y = model.addVars(stages, name="fast", lb=0, vtype=GRB.INTEGER)
    z = model.addVars(stages, name="slow", lb=0, vtype=GRB.INTEGER)
    c = model.addVars([0] + stages, name="clean", lb=0, vtype=GRB.INTEGER)
    d = model.addVars([0] + stages, name="dirty", lb=0, vtype=GRB.INTEGER)
    s = model.addVar(name="prebuy_clean", lb=0, vtype=GRB.INTEGER)

    # Objective function
    obj = (
        cost_new * sum(x[i] for i in stages) +
        cost_fast * sum(y[i] for i in stages) +
        cost_slow * sum(z[i] for i in stages) +
        penalty_shortage * sum((demand[i] - (c[i-1] + y[i] + z[i])) for i in stages if (demand[i] - (c[i-1] + y[i] + z[i])) > 0)
    )
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    model.addConstr(c[0] == s)
    model.addConstr(d[0] == 0)

    for i in stages:
        # Clean tools available at stage i: previous clean + fast repair ready + slow repair ready
        fast_ready = y[i - dur_fast - 1] if i - dur_fast - 1 >= 1 else 0
        slow_ready = z[i - dur_slow - 1] if i - dur_slow - 1 >= 1 else 0
        model.addConstr(
            x[i] + c[i-1] + fast_ready + slow_ready == demand[i] + c[i]
        )

        # Dirty tools at stage i: previous dirty + current demand - tools used
        model.addConstr(
            demand[i] + d[i-1] == y[i] + z[i] + d[i]
        )

        # Repair capacity constraints
        model.addConstr(y[i] <= max_fast_stage)
        model.addConstr(z[i] <= max_slow_stage)

    # Carbon budget constraint
    carbon_emission = (
        emission_buy * sum(x[i] for i in stages) +
        emission_fast * sum(y[i] for i in stages) +
        emission_slow * sum(z[i] for i in stages)
    )
    model.addConstr(carbon_emission <= carbon_budget)

    model.setParam('OutputFlag', 0)
    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
