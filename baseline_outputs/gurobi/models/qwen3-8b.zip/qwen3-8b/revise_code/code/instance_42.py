import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_parameters

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    a = params['a']  # Time per furnace for method 1 in peak hours
    b = params['b']  # Time per furnace for method 2 in peak hours
    k = params['k']  # Steel production per furnace batch
    d = params['d']  # Minimum steel production requirement
    c_peak = params['c_peak']  # Max peak time per furnace
    c_offpeak = params['c_offpeak']  # Max off-peak time per furnace
    cap_peak = params['cap_peak']  # Plant-wide max peak time
    cap_offpeak = params['cap_offpeak']  # Plant-wide max off-peak time
    m_peak = params['m_peak']  # Fuel cost for method 1 in peak hours
    n_peak = params['n_peak']  # Fuel cost for method 2 in peak hours
    m_offpeak = params['m_offpeak']  # Fuel cost for method 1 in off-peak hours
    n_offpeak = params['n_offpeak']  # Fuel cost for method 2 in off-peak hours
    f_peak = params['f_peak']  # Fixed activation cost for peak use
    f_offpeak = params['f_offpeak']  # Fixed activation cost for off-peak use
    offpeak_cooldown_batch_threshold = params['offpeak_cooldown_batch_threshold']
    offpeak_cooldown_fee = params['offpeak_cooldown_fee']

    model = gp.Model("SteelFurnaceRevised")

    # Decision variables
    x1 = model.addVar(lb=0, name="x1")  # Furnace 1, method 1 (peak)
    x2 = model.addVar(lb=0, name="x2")  # Furnace 1, method 2 (peak)
    x3 = model.addVar(lb=0, name="x3")  # Furnace 1, method 1 (off-peak)
    x4 = model.addVar(lb=0, name="x4")  # Furnace 1, method 2 (off-peak)
    x5 = model.addVar(lb=0, name="x5")  # Furnace 2, method 1 (peak)
    x6 = model.addVar(lb=0, name="x6")  # Furnace 2, method 2 (peak)
    x7 = model.addVar(lb=0, name="x7")  # Furnace 2, method 1 (off-peak)
    x8 = model.addVar(lb=0, name="x8")  # Furnace 2, method 2 (off-peak)

    # Objective: minimize total fuel cost + fixed costs + cooldown fees
    model.setObjective(
        m_peak * (x1 + x5) +
        n_peak * (x2 + x6) +
        m_offpeak * (x3 + x7) +
        n_offpeak * (x4 + x8) +
        f_peak * (x1 + x2 + x5 + x6) +
        f_offpeak * (x3 + x4 + x7 + x8) +
        offpeak_cooldown_fee * (gp.quicksum([x3, x4, x7, x8]) > 2 * offpeak_cooldown_batch_threshold),
        GRB.MINIMIZE
    )

    # Peak time constraints for each furnace
    model.addConstr(a * x1 + b * x2 <= c_peak, "Furnace1_Peak_Time")
    model.addConstr(a * x5 + b * x6 <= c_peak, "Furnace2_Peak_Time")

    # Off-peak time constraints for each furnace
    model.addConstr(a * x3 + b * x4 <= c_offpeak, "Furnace1_Offpeak_Time")
    model.addConstr(a * x7 + b * x8 <= c_offpeak, "Furnace2_Offpeak_Time")

    # Plant-wide peak time constraint
    model.addConstr((a * x1 + b * x2) + (a * x5 + b * x6) <= cap_peak, "PlantPeakTime")

    # Plant-wide off-peak time constraint
    model.addConstr((a * x3 + b * x4) + (a * x7 + b * x8) <= cap_offpeak, "PlantOffpeakTime")

    # Minimum production requirement
    model.addConstr(k * (x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8) >= d, "MinProduction")

    # Cooldown fee constraint (only if off-peak batches exceed threshold)
    model.addGenConstrIndicator(offpeak_cooldown_indicator, 1,
                               gp.quicksum([x3, x4, x7, x8]) > 2 * offpeak_cooldown_batch_threshold,
                               name="CooldownFeeTrigger")

    # Additional variable for cooldown fee indicator
    offpeak_cooldown_indicator = model.addVar(vtype=GRB.BINARY, name="OffpeakCooldownIndicator")

    # Set solver parameters
    model.setParam('OutputFlag', 0)

    # Solve the model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
