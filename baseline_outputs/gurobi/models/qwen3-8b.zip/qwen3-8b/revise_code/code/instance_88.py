import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

# Extract parameters
machine_1_time_per_liquid_lot = params["machine_1_time_per_liquid_lot"]
machine_2_time_per_liquid_lot = params["machine_2_time_per_liquid_lot"]
machine_1_time_per_solid_lot = params["machine_1_time_per_solid_lot"]
machine_2_time_per_solid_lot = params["machine_2_time_per_solid_lot"]
initial_liquid_inventory = params["initial_liquid_inventory"]
initial_solid_inventory = params["initial_solid_inventory"]
machine_1_available_time = params["machine_1_available_time"] * 60
machine_2_available_time = params["machine_2_available_time"] * 60
forecast_liquid_demand = params["forecast_liquid_demand"]
forecast_solid_demand = params["forecast_solid_demand"]
extended_extra_minutes = params["extended_extra_minutes"]
labor_hours_per_machine_extended = params["labor_hours_per_machine_extended"]
labor_budget_hours = params["labor_budget_hours"]
extended_mode_penalty = params["extended_mode_penalty"]
priority_reserve_lots = params["priority_reserve_lots"]
excess_reserve_credit = params["excess_reserve_credit"]

# Create model
model = gp.Model("Fertilizer_Production")

# Decision variables
x_liquid = model.addVar(name="x_liquid", lb=0)
x_solid = model.addVar(name="x_solid", lb=0)

# Extended mode variables (binary)
y_liquid = model.addVar(name="y_liquid", vtype=GRB.BINARY)
y_solid = model.addVar(name="y_solid", vtype=GRB.BINARY)

# Compute ending inventories
end_liquid = initial_liquid_inventory + x_liquid - forecast_liquid_demand
end_solid = initial_solid_inventory + x_solid - forecast_solid_demand

# Objective function: resilience score
resilience_score = 0

# Priority reserve contribution
if end_liquid >= priority_reserve_lots:
    resilience_score += priority_reserve_lots
else:
    resilience_score += end_liquid

if end_solid >= priority_reserve_lots:
    resilience_score += priority_reserve_lots
else:
    resilience_score += end_solid

# Excess reserve contribution
if end_liquid > priority_reserve_lots:
    resilience_score += (end_liquid - priority_reserve_lots) * excess_reserve_credit

if end_solid > priority_reserve_lots:
    resilience_score += (end_solid - priority_reserve_lots) * excess_reserve_credit

# Extended mode penalty
resilience_score -= (y_liquid + y_solid) * extended_mode_penalty

model.setObjective(resilience_score, GRB.MAXIMIZE)

# Machine time constraints
model.addConstr(
    machine_1_time_per_liquid_lot * x_liquid + machine_1_time_per_solid_lot * x_solid
    + extended_extra_minutes * y_liquid + extended_extra_minutes * y_solid
    <= machine_1_available_time,
    "Machine_1_Capacity"
)

model.addConstr(
    machine_2_time_per_liquid_lot * x_liquid + machine_2_time_per_solid_lot * x_solid
    + extended_extra_minutes * y_liquid + extended_extra_minutes * y_solid
    <= machine_2_available_time,
    "Machine_2_Capacity"
)

# Labor budget constraint
model.addConstr(
    labor_hours_per_machine_extended * (y_liquid + y_solid) <= labor_budget_hours,
    "Labor_Budget"
)

# Demand satisfaction constraints
model.addConstr(end_liquid >= 0, "Liquid_Demand_Satisfaction")
model.addConstr(end_solid >= 0, "Solid_Demand_Satisfaction")

# Solve model
model.setParam("OutputFlag", 0)
model.optimize()

# Print results
print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
