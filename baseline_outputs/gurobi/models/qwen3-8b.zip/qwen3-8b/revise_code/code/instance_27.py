import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    equipment, proc_times, eff_hours, op_costs = load_table1(data_dir)
    raw_costs, prices = load_general_params(data_dir)
    
    products = ['Product_I', 'Product_II', 'Product_III']
    prod_idx = {p: i for i, p in enumerate(products)}
    
    A_equip = [e for e in equipment if e.startswith('A')]
    B_equip = [e for e in equipment if e.startswith('B')]
    
    model = gp.Model("Factory_Production")
    
    # x[e][p] = number of units of product p processed on equipment e
    x = {}
    for e in equipment:
        x[e] = {}
        for p in products:
            if proc_times[e][p] is not None:
                x[e][p] = model.addVar(lb=0, name=f"x_{e}_{p}")
    
    # y[e] = 1 if equipment e is used (for B2 activation fee)
    y = {}
    for e in equipment:
        y[e] = model.addVar(vtype=GRB.BINARY, name=f"y_{e}")
    
    # Fraction of capacity used by each equipment
    # f[e] = sum of (x[e][p] * proc_times[e][p]) / eff_hours[e]
    
    # Capacity constraints: total processing time <= effective machine hours
    for e in equipment:
        model.addConstr(
            gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None) <= eff_hours[e],
            f"capacity_{e}"
        )
    
    # Flow balance: for each product, total A-processed = total B-processed
    for p in products:
        a_sum = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
        b_sum = gp.quicksum(x[e][p] for e in B_equip if proc_times[e][p] is not None)
        model.addConstr(a_sum == b_sum, f"balance_{p}")
    
    # Shared labor hours constraint
    labor_coeff = {
        'A1': 0.6,
        'A2': 0.5,
        'B1': 0.7,
        'B2': 0.4,
        'B3': 0.8
    }
    
    labor_used = gp.quicksum(
        x[e][p] * proc_times[e][p] * labor_coeff[e] for e in equipment for p in products if proc_times[e][p] is not None
    )
    model.addConstr(labor_used <= shared_labor_hours, "labor_hours")
    
    # B2 activation fee constraint
    model.addConstr(gp.quicksum(y[e] for e in B_equip) >= 1, "b2_activation")
    model.addConstr(gp.quicksum(y[e] for e in B_equip) <= 1, "b2_activation_binary")
    model.addConstr(
        gp.quicksum(x[e][p] for e in B_equip for p in products if proc_times[e][p] is not None) <= 1000000 * y['B2'],
        "b2_usage"
    )
    
    # Total production of each product
    total_prod = {}
    for p in products:
        total_prod[p] = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
    
    # Revenue
    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)
    
    # Raw material costs
    raw_cost_total = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)
    
    # Operating costs: proportional to usage fraction
    operating_cost = gp.quicksum(
        op_costs[e] * gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None) / eff_hours[e]
        for e in equipment
    )
    
    # B2 activation fee
    b2_activation_fee = 0
    if 'B2' in y:
        b2_activation_fee = y['B2'] * b2_activation_fee_value
    
    # Objective: maximize profit
    model.setObjective(revenue - raw_cost_total - operating_cost - b2_activation_fee, GRB.MAXIMIZE)
    
    model.Params.OutputFlag = 0
    model.optimize()
    
    obj_val = model.ObjVal
    
    for e in equipment:
        for p in products:
            if proc_times[e][p] is not None:
                val = x[e][p].X
                if val and val > 1e-6:
                    print(f"  {e} -> {p}: {val:.4f} units")
    
    print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")

def load_table1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in ['Product_I', 'Product_II', 'Product_III']:
                val = row[p].strip() if row[p].strip() else None
                proc_times[e][p] = float(val) if val else None
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())
    
    return equipment, proc_times, eff_hours, op_costs

def load_general_params(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    raw_costs = {}
    prices = {}
    shared_labor_hours = 0
    b2_activation_fee_value = 0
    
    mapping_raw = {
        'raw_material_cost_product_I': 'Product_I',
        'raw_material_cost_product_II': 'Product_II',
        'raw_material_cost_product_III': 'Product_III',
    }
    mapping_price = {
        'unit_price_product_I': 'Product_I',
        'unit_price_product_II': 'Product_II',
        'unit_price_product_III': 'Product_III',
    }
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            if name == 'shared_labor_hours':
                shared_labor_hours = val
            elif name == 'b2_activation_fee':
                b2_activation_fee_value = val
            elif name in mapping_raw:
                raw_costs[mapping_raw[name]] = val
            elif name in mapping_price:
                prices[mapping_price[name]] = val
    
    return raw_costs, prices, shared_labor_hours, b2_activation_fee_value

if __name__ == "__main__":
    main()
