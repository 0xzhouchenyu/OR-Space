import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, '..', 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = float(params['fixed_order_cost'])
    august_bulk_order_threshold = int(params['august_bulk_order_threshold'])
    august_bulk_receiving_fee = float(params['august_bulk_receiving_fee'])
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = {m: model.addVar(lb=0, name=f"buy_{m}") for m in months}
    sell = {m: model.addVar(lb=0, name=f"sell_{m}") for m in months}
    stock = {m: model.addVar(lb=0, ub=warehouse_capacity, name=f"stock_{m}") for m in months}
    fixed_order = {m: model.addVar(vtype=GRB.BINARY, name=f"fixed_order_{m}") for m in months}
    august_bulk = model.addVar(vtype=GRB.BINARY, name="august_bulk")
    
    # Objective: maximize total profit (revenue - cost - fixed order costs - bulk receiving fee)
    objective = 0
    for m in months:
        objective += sell_price[m] * sell[m] - buy_price[m] * buy[m]
        if m != 8:
            objective -= fixed_order_cost * fixed_order[m]
        else:
            objective -= fixed_order_cost * fixed_order[m]
            objective -= august_bulk_receiving_fee * august_bulk
    
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Stock balance constraints
    for i, m in enumerate(months):
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_stock = stock[months[i-1]]
        
        # Stock balance: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], f"balance_{m}")
        
        # Warehouse constraint: prev_stock + buy[m] <= warehouse_capacity
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, f"warehouse_after_buy_{m}")
    
    # Fixed order cost constraint
    for m in months:
        model.addConstr(buy[m] >= 1e-6 * fixed_order[m], f"fixed_order_{m}_constraint")
    
    # August bulk receiving fee constraint
    model.addConstr(buy[8] >= (august_bulk_order_threshold + 1e-6) * august_bulk, f"august_bulk_constraint")
    
    # Solve
    model.optimize()
    
    # Print solution details
    for m in months:
        print(f"Month {m}: Buy={value(buy[m]):.1f} @ {buy_price[m]}, "
              f"Sell={value(sell[m]):.1f} @ {sell_price[m]}, "
              f"Stock={value(stock[m]):.1f}")
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
