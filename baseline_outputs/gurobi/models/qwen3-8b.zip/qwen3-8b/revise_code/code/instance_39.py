import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add parent directory to path if needed
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(script_dir, '..', 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
motorcycle_pollution = params['motorcycle_pollution']       # 40
small_truck_pollution = params['small_truck_pollution']     # 70
large_truck_pollution = params['large_truck_pollution']     # 100
max_motorcycle_trips = int(params['max_motorcycle_trips'])  # 8
motorcycle_capacity = params['motorcycle_capacity']         # 10
small_truck_capacity = params['small_truck_capacity']       # 20
large_truck_capacity = params['large_truck_capacity']       # 50
demand_peak_units = params['demand_peak_units']             # 200
demand_offpeak_units = params['demand_offpeak_units']       # 120
leasing_capacity = params['leasing_capacity']               # 200
leasing_pollution_per_unit = params['leasing_pollution_per_unit']  # 60
leasing_fixed_pollution = params['leasing_fixed_pollution']   # 100
max_leasing_fraction_peak = params['max_leasing_fraction_peak']  # 0.25
bigM_leasing = params['bigM_leasing']                       # 400
epsilon = params['epsilon']                                 # 1

# Define the model
model = gp.Model("Transport_Optimization")

# Decision variables
# Owned trips
trips_motorcycle = model.addVar(lb=0, vtype=GRB.INTEGER, name="trips_motorcycle")
trips_small_truck = model.addVar(lb=0, vtype=GRB.INTEGER, name="trips_small_truck")
trips_large_truck = model.addVar(lb=0, vtype=GRB.INTEGER, name="trips_large_truck")

# Leasing variables
leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")
leasing_quantity = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="leasing_quantity")

# Peak and off-peak capacity variables
capacity_peak_motorcycle = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="capacity_peak_motorcycle")
capacity_peak_small_truck = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="capacity_peak_small_truck")
capacity_peak_large_truck = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="capacity_peak_large_truck")
capacity_offpeak_motorcycle = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="capacity_offpeak_motorcycle")
capacity_offpeak_small_truck = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="capacity_offpeak_small_truck")
capacity_offpeak_large_truck = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="capacity_offpeak_large_truck")

# Constraints
# Capacity constraints for owned trips
model.addConstr(trips_motorcycle * motorcycle_capacity <= capacity_peak_motorcycle + capacity_offpeak_motorcycle)
model.addConstr(trips_small_truck * small_truck_capacity <= capacity_peak_small_truck + capacity_offpeak_small_truck)
model.addConstr(trips_large_truck * large_truck_capacity <= capacity_peak_large_truck + capacity_offpeak_large_truck)

# Demand constraints
model.addConstr(capacity_peak_motorcycle + capacity_peak_small_truck + capacity_peak_large_truck >= demand_peak_units)
model.addConstr(capacity_offpeak_motorcycle + capacity_offpeak_small_truck + capacity_offpeak_large_truck >= demand_offpeak_units)

# Leasing constraints
model.addConstr(leasing_quantity <= leasing_capacity)
model.addConstr(leasing_quantity <= bigM_leasing * leasing_used)
model.addConstr(leasing_quantity >= epsilon * leasing_used)

# Pollution constraints
model.addConstr(
    (trips_motorcycle * motorcycle_pollution +
     trips_small_truck * small_truck_pollution +
     trips_large_truck * large_truck_pollution +
     leasing_fixed_pollution * leasing_used +
     leasing_pollution_per_unit * leasing_quantity) <= model.objVal
)

# Max fraction of peak demand that can be satisfied by leasing
model.addConstr(
    leasing_quantity <= max_leasing_fraction_peak * demand_peak_units
)

# Max total trips constraint
model.addConstr(
    trips_motorcycle + trips_small_truck + trips_large_truck + leasing_quantity <= params['max_total_trips']
)

# Motorcycle trip limit
model.addConstr(trips_motorcycle <= max_motorcycle_trips)

# Objective: minimize total pollution
model.setObjective(
    trips_motorcycle * motorcycle_pollution +
    trips_small_truck * small_truck_pollution +
    trips_large_truck * large_truck_pollution +
    leasing_fixed_pollution * leasing_used +
    leasing_pollution_per_unit * leasing_quantity,
    GRB.MINIMIZE
)

# Solve the model
model.Params.OutputFlag = 0
model.optimize()

# Print solution details
print(f"FINAL_OBJ_VALUE: {model.objVal}")
