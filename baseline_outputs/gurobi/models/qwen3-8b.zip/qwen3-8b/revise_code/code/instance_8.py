import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read table_1.csv
    filepath = os.path.join(data_dir, "table_1.csv")
    
    workers = []
    tasks = []
    cost = {}
    fixed_cost = {}
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        tasks = header[1:-1]  # ['A', 'B', 'C', 'D']
        fixed_col = header[-1]
        
        for row in reader:
            worker = row[0].strip()
            workers.append(worker)
            for j, task in enumerate(tasks):
                cost[(worker, task)] = int(row[j + 1])
            fixed_cost[worker] = int(row[-1])
    
    # Read general_parameters.csv
    general_filepath = os.path.join(data_dir, "general_parameters.csv")
    
    shared_temp_handoff_cost = 0
    worker_II_V_pair_fee = 0
    
    with open(general_filepath, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            if row[0] == "shared_temp_handoff_cost":
                shared_temp_handoff_cost = int(row[1])
            elif row[0] == "worker_II_V_pair_fee":
                worker_II_V_pair_fee = int(row[1])
    
    # Create the optimization model
    model = gp.Model("Assignment")
    
    # Decision variables: x[i,j] = 1 if worker i is assigned to task j
    x = {}
    for w in workers:
        for t in tasks:
            x[(w, t)] = model.addVar(vtype=GRB.BINARY, name=f"x_{w}_{t}")
    
    # Objective: minimize total time + fixed costs + penalties
    objective = 0
    for w in workers:
        for t in tasks:
            objective += cost[(w, t)] * x[(w, t)]
    objective += fixed_cost["III"] + fixed_cost["V"] if "III" in workers and "V" in workers else 0
    objective += worker_II_V_pair_fee if "II" in workers and "V" in workers else 0
    model.setObjective(objective, GRB.MINIMIZE)
    
    # Each task must be assigned to exactly one worker
    for t in tasks:
        model.addConstr(gp.quicksum(x[(w, t)] for w in workers) == 1)
    
    # Each worker can be assigned to at most one task
    for w in workers:
        model.addConstr(gp.quicksum(x[(w, t)] for t in tasks) <= 1)
    
    # Set solver parameters
    model.setParam('OutputFlag', 0)
    
    # Solve
    model.optimize()
    
    # Print solution details
    print("Status:", model.Status)
    print("\nAssignment:")
    for w in workers:
        for t in tasks:
            if x[(w, t)].x > 0.5:
                print(f"  Worker {w} -> Task {t} (time: {cost[(w, t)]})")
    
    obj_val = model.objVal
    print(f"\nFINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
