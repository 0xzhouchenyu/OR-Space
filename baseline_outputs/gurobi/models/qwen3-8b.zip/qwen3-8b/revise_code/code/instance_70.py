import gurobipy as gp
from gurobipy import GRB
import os
import sys
from itertools import permutations
from utils import load_distance_matrix

def solve_tsp():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    dist_file = os.path.join(data_dir, "table_1.csv")
    general_file = os.path.join(data_dir, "general_parameters.csv")

    cities, dist = load_distance_matrix(dist_file)
    n = len(cities)

    # Load general parameters
    with open(general_file, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        param_dict = {}
        for row in reader:
            param_dict[row[0]] = float(row[1])

    start_city = int(param_dict['start_city'])
    end_city = int(param_dict['end_city'])
    prohibited_from = int(param_dict['prohibited_from'])
    prohibited_to = int(param_dict['prohibited_to'])
    inspection_arc_from = int(param_dict['inspection_arc_from'])
    inspection_arc_to = int(param_dict['inspection_arc_to'])
    inspection_stop_cost = float(param_dict['inspection_stop_cost'])

    # For small instances, solve exactly via permutation enumeration
    if n <= 12:
        best_cost = float('inf')
        best_route = None
        other_cities = list(range(1, n))

        for perm in permutations(other_cities):
            route = [start_city] + list(perm)
            if route[-1] != end_city:
                continue
            if (route.index(prohibited_from) + 1) % n == route.index(prohibited_to):
                continue
            if (route.index(inspection_arc_from) + 1) % n == route.index(inspection_arc_to):
                cost = 0
                for i in range(n):
                    cost += dist[route[i]][route[(i + 1) % n]]
                cost += inspection_stop_cost
            else:
                cost = 0
                for i in range(n):
                    cost += dist[route[i]][route[(i + 1) % n]]
            if cost < best_cost:
                best_cost = cost
                best_route = route

        print(f"Optimal route: {[cities[i] for i in best_route]}")
        print(f"FINAL_OBJ_VALUE: {best_cost}")
    else:
        model = gp.Model("TSP")

        # Decision variables
        x = {}
        for i in range(n):
            for j in range(n):
                if i != j:
                    x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")

        # MTZ variables
        u = {}
        for i in range(1, n):
            u[i] = model.addVar(lb=1, ub=n - 1, vtype=GRB.CONTINUOUS, name=f"u_{i}")

        # Objective function
        model.setObjective(gp.quicksum(dist[i][j] * x[i, j] for i in range(n) for j in range(n) if i != j), GRB.MINIMIZE)

        # Each city is left exactly once
        for i in range(n):
            model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1)

        # Each city is entered exactly once
        for j in range(n):
            model.addConstr(gp.quicksum(x[i, j] for i in range(n) if i != j) == 1)

        # Prohibited arc constraint
        model.addConstr(x[prohibited_from, prohibited_to] == 0)

        # Inspection stop constraint
        model.addConstr(x[inspection_arc_from, inspection_arc_to] * inspection_stop_cost <= 0)

        # MTZ subtour elimination constraints
        for i in range(1, n):
            for j in range(1, n):
                if i != j:
                    model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1)

        # Start and end city constraints
        model.addConstr(x[start_city, end_city] == 1)

        # Solve the model
        model.setParam('OutputFlag', 0)
        model.optimize()

        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    solve_tsp()
