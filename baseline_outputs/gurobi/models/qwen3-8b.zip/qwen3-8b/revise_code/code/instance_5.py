import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    # Load data
    table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    
    df = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)
    
    budget = float(params[params['Parameter_Name'] == 'budget']['Value'].iloc[0])
    food_intake = float(params[params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
    weekday_budget_share = float(params[params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
    max_prep_time_weekday = float(params[params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
    max_prep_time_weekend = float(params[params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
    weekend_protein_ban = int(params[params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
    veg_balance_penalty = float(params[params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])
    
    foods = df['Food'].tolist()
    types = df.set_index('Food')['Type'].to_dict()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()
    
    # Define model
    model = gp.Model("Maximize_Fiber_Weekend_Weekday")
    model.setParam('OutputFlag', 0)
    
    # Variables for weekday and weekend
    x_weekday = model.addVars(foods, lb=0, name="x_weekday")
    x_weekend = model.addVars(foods, lb=0, name="x_weekend")
    y_weekday = model.addVars(foods, vtype=GRB.BINARY, name="y_weekday")
    y_weekend = model.addVars(foods, vtype=GRB.BINARY, name="y_weekend")
    
    # Objective: maximize total fiber (weekday + weekend)
    obj = gp.quicksum(fiber[f] * (x_weekday[f] + x_weekend[f]) for f in foods)
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints for weekday dinner
    # Food intake
    model.addConstr(gp.quicksum(x_weekday[f] for f in foods) == food_intake / 100.0)
    # Budget
    model.addConstr(gp.quicksum(price[f] * x_weekday[f] for f in foods) <= weekday_budget_share * budget)
    # Prep time
    model.addConstr(gp.quicksum(prep_time[f] * x_weekday[f] for f in foods) <= max_prep_time_weekday)
    # Exactly one protein
    proteins = [f for f in foods if types[f] == 'protein']
    model.addConstr(gp.quicksum(y_weekday[f] for f in proteins) == 1)
    # At least two vegetables
    vegetables = [f for f in foods if types[f] == 'vegetable']
    model.addConstr(gp.quicksum(y_weekday[f] for f in vegetables) >= 2)
    # Linking constraints
    M = food_intake / 100.0
    for f in foods:
        model.addConstr(x_weekday[f] >= 0.1 * y_weekday[f])
        model.addConstr(x_weekday[f] <= M * y_weekday[f])
    
    # Constraints for weekend dinner
    # Food intake
    model.addConstr(gp.quicksum(x_weekend[f] for f in foods) == food_intake / 100.0)
    # Budget
    model.addConstr(gp.quicksum(price[f] * x_weekend[f] for f in foods) <= (1 - weekday_budget_share) * budget)
    # Prep time
    model.addConstr(gp.quicksum(prep_time[f] * x_weekend[f] for f in foods) <= max_prep_time_weekend)
    # Weekend protein ban
    if weekend_protein_ban == 1:
        for f in proteins:
            model.addConstr(x_weekend[f] == 0)
    # At least two vegetables
    model.addConstr(gp.quicksum(y_weekend[f] for f in vegetables) >= 2)
    # Linking constraints
    for f in foods:
        model.addConstr(x_weekend[f] >= 0.1 * y_weekend[f])
        model.addConstr(x_weekend[f] <= M * y_weekend[f])
    
    # Vegetable balance penalty
    weekday_veg = gp.quicksum(x_weekday[f] for f in vegetables)
    weekend_veg = gp.quicksum(x_weekend[f] for f in vegetables)
    model.addConstr(gp.quicksum(fiber[f] * (x_weekday[f] + x_weekend[f]) for f in foods) - veg_balance_penalty * abs(weekday_veg - weekend_veg), GRB.MINIMIZE)
    
    # Solve the problem
    model.optimize()
    
    return round(model.objVal, 4)

if __name__ == '__main__':
    print(f"FINAL_OBJ_VALUE: {solve()}")
