import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    base = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base, 'data')
    
    # Read general parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {row['Parameter_Name']: row['Value'] for row in reader}
    
    n = int(params['n'])
    premium_cost_multiplier = float(params['premium_cost_multiplier'])
    min_premium_share = float(params['min_premium_share'])
    
    # Read transportation data
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    d = []
    c = []
    outbound_volume = []
    
    for row in rows:
        d_row = [float(row[f'Transportation_volume_to_Location_{j+1}']) for j in range(n)]
        d.append(d_row)
        
        c_row = [float(row[f'Transportation_cost_to_Location_{j+1}']) for j in range(n)]
        c.append(c_row)
        
        outbound_volume.append(sum(d_row))
    
    # Create model
    model = gp.Model("Factory_Location_Assignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    y = {}
    v_std = {}
    v_prem = {}
    
    for i in range(n):
        for p in range(n):
            x[i, p] = model.binaryVar(vtype=GRB.BINARY, name=f"x_{i}_{p}")
            y[i, p] = model.binaryVar(vtype=GRB.BINARY, name=f"y_{i}_{p}")
    
    for i in range(n):
        for p in range(n):
            v_std[i, p] = model.contVar(lb=0, ub=gp.GRB.INFINITY, name=f"v_std_{i}_{p}")
            v_prem[i, p] = model.contVar(lb=0, ub=gp.GRB.INFINITY, name=f"v_prem_{i}_{p}")
    
    # Constraints
    # Each factory assigned to exactly one location
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, p] for p in range(n)) == 1, name=f"assign_factory_{i}")
    
    # No more than one factory per location
    for p in range(n):
        model.addConstr(gp.quicksum(x[i, p] for i in range(n)) <= 1, name=f"one_factory_per_location_{p}")
    
    # Premium handling implies volume share >= min_premium_share
    for i in range(n):
        for p in range(n):
            model.addConstr(v_prem[i, p] >= min_premium_share * outbound_volume[i] * x[i, p], name=f"min_premium_volume_{i}_{p}")
            model.addConstr(v_prem[i, p] <= 1.0 * outbound_volume[i] * x[i, p], name=f"max_premium_volume_{i}_{p}")
    
    # Volume split constraint
    for i in range(n):
        for p in range(n):
            model.addConstr(v_std[i, p] + v_prem[i, p] == outbound_volume[i] * x[i, p], name=f"volume_split_{i}_{p}")
    
    # Cost calculation
    total_cost = 0
    
    for i in range(n):
        for p in range(n):
            # Standard cost
            std_cost = (gp.quicksum(d[i][j] * c[p][j] for j in range(n)) / outbound_volume[i]) * v_std[i, p]
            # Premium cost
            prem_cost = premium_cost_multiplier * (gp.quicksum(d[i][j] * c[p][j] for j in range(n)) / outbound_volume[i]) * v_prem[i, p]
            total_cost += std_cost + prem_cost
    
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

solve()
