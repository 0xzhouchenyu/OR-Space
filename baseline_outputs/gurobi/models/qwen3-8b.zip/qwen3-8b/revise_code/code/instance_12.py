import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load container data
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    # Load general parameters
    general_params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row['Parameter_Name']] = float(row['Value'])

    fixed_setup_cost = general_params['fixed_setup_cost']
    energy_cost_per_kwh = general_params['energy_cost_per_kwh']
    max_total_energy_kwh = general_params['max_total_energy_kwh']
    eco_capacity_share = general_params['eco_capacity_share']
    eco_overhead_cost = general_params['eco_overhead_cost']
    regular_energy_intensity = general_params['regular_energy_intensity_kwh_per_unit']
    eco_energy_intensity = general_params['eco_energy_intensity_kwh_per_unit']

    n = len(containers)

    # Create the model
    model = gp.Model("PlasticContainers")

    # Binary setup variables for each container type
    y = {i: model.addVar(vtype=GRB.BINARY, name=f"y_{i}") for i in range(n)}

    # Variables for production of container i to fulfill demand of container j
    x = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x[(i, j)] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{i}_{j}")

    # Binary variables for eco mode usage of container type i
    eco = {i: model.addVar(vtype=GRB.BINARY, name=f"eco_{i}") for i in range(n)}

    # Objective: minimize variable costs + fixed setup costs + energy costs
    obj = 0
    for (i, j) in x:
        obj += containers[i]['cost'] * x[(i, j)]
    for i in range(n):
        obj += fixed_setup_cost * y[i]
        obj += eco_overhead_cost * eco[i]
    for (i, j) in x:
        obj += energy_cost_per_kwh * (regular_energy_intensity * x[(i, j)] * (1 - eco[i]) + eco_energy_intensity * x[(i, j)] * eco[i])
    model.setObjective(obj, GRB.MINIMIZE)

    # Demand constraints: for each type j, total supplied >= demand[j]
    for j in range(n):
        demand = 0
        for i in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                demand += x[(i, j)]
        model.addConstr(demand >= containers[j]['demand'], f"demand_{j}")

    # Linking constraints: if we produce type i, y[i] must be 1
    M = sum(c['demand'] for c in containers)
    for i in range(n):
        total_produced_i = 0
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                total_produced_i += x[(i, j)]
        model.addConstr(total_produced_i <= M * y[i], f"setup_{i}")

    # Eco capacity constraint: eco[i] cannot exceed eco_capacity_share of total production for container i
    for i in range(n):
        total_produced_i = 0
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                total_produced_i += x[(i, j)]
        model.addConstr(eco[i] <= eco_capacity_share * total_produced_i / M, f"eco_capacity_{i}")

    # Energy constraint: total energy consumption must not exceed max_total_energy_kwh
    total_energy = 0
    for (i, j) in x:
        total_energy += regular_energy_intensity * x[(i, j)] * (1 - eco[i]) + eco_energy_intensity * x[(i, j)] * eco[i]
    model.addConstr(total_energy <= max_total_energy_kwh, "total_energy")

    # Solve the model
    model.Params.OutputFlag = 0
    model.optimize()

    # Print solution details
    for i in range(n):
        total_prod = 0
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                total_prod += x[(i, j)].x
        if total_prod > 0:
            print(f"Container type {containers[i]['code']}: produce {total_prod}, setup={'Yes' if y[i].x > 0.5 else 'No'}, eco={'Yes' if eco[i].x > 0.5 else 'No'}")

    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
