import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utils import load_general_parameters, load_task_methods

# Load data
params = load_general_parameters()
task_methods = load_task_methods()

# Extract parameters
skilled_wage = params['skilled_worker_weekly_wage']  # 110
laborer_wage = params['laborer_weekly_wage']  # 80
skilled_hours = params['skilled_worker_weekly_hours']  # 42
laborer_hours = params['laborer_weekly_hours']  # 36
max_skilled = params['max_skilled_workers']  # 430
max_laborers = params['max_laborers']  # 800
min_skilled_task3_B = params['min_skilled_workers_task3_methodB']  # 20
skilled_hiring_ratio = params['skilled_worker_hiring_ratio']  # 0.6
min_skilled_share_task1 = params['min_skilled_share_task1']  # 0.30
max_skilled_share_task1 = params['max_skilled_share_task1']  # 0.70
min_skilled_share_task2 = params['min_skilled_share_task2']  # 0.10
max_skilled_share_task2 = params['max_skilled_share_task2']  # 0.50
min_skilled_share_task3 = params['min_skilled_share_task3']  # 0.20
max_skilled_share_task3 = params['max_skilled_share_task3']  # 0.60

# Organize task-method data
tasks = ['Task_1', 'Task_2', 'Task_3']
methods = ['Method_A', 'Method_B']

# Build dictionary: (task, method) -> {Effective_Hours, Fixed_Cost}
tm_data = {}
for row in task_methods:
    key = (row['Task'], row['Method'])
    tm_data[key] = row

# Create the model
model = gp.Model("WorkerAllocation")

# Decision variables

# Binary: y[task][method] = 1 if method is chosen for task
y = {}
for t in tasks:
    for m in methods:
        y[t, m] = model.addVar(vtype=GRB.BINARY, name=f"y_{t}_{m}")

# Continuous: number of skilled workers assigned to (task, method)
s = {}
for t in tasks:
    for m in methods:
        s[t, m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"s_{t}_{m}")

# Continuous: number of laborers assigned to (task, method)
l = {}
for t in tasks:
    for m in methods:
        l[t, m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"l_{t}_{m}")

# Total skilled workers and laborers
total_skilled = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_skilled")
total_laborers = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_laborers")

# Objective: minimize total weekly cost (wages + fixed costs)
model.setObjective(
    skilled_wage * total_skilled + laborer_wage * total_laborers +
    sum(tm_data[t, m]['Fixed_Cost'] * y[t, m] for t in tasks for m in methods),
    GRB.MINIMIZE
)

# Constraints

# Total skilled = sum of skilled workers across chosen methods
model.addConstr(total_skilled == sum(s[t, m] for t in tasks for m in methods), "TotalSkilledDef")
model.addConstr(total_laborers == sum(l[t, m] for t in tasks for m in methods), "TotalLaborersDef")

# Exactly one method per task
for t in tasks:
    model.addConstr(sum(y[t, m] for m in methods) == 1, f"OneMethod_{t}")

# Hours requirement: for each task, the chosen method must meet effective hours
# skilled_hours * s[t,m] + laborer_hours * l[t,m] >= Effective_Hours * y[t,m]
# Also, s[t,m] and l[t,m] can only be > 0 if y[t,m] = 1
M_big = 1000000  # Big-M

for t in tasks:
    for m in methods:
        req_hours = tm_data[t, m]['Effective_Hours']
        # Hours constraint
        model.addConstr(
            skilled_hours * s[t, m] + laborer_hours * l[t, m] >= req_hours * y[t, m],
            f"Hours_{t}_{m}"
        )
        # Linking: if y=0, then s and l must be 0
        model.addConstr(s[t, m] <= M_big * y[t, m], f"LinkS_{t}_{m}")
        model.addConstr(l[t, m] <= M_big * y[t, m], f"LinkL_{t}_{m}")

# Max constraints
model.addConstr(total_skilled <= max_skilled, "MaxSkilled")
model.addConstr(total_laborers <= max_laborers, "MaxLaborers")

# Skilled workers cannot exceed 60% of total laborers
model.addConstr(total_skilled <= skilled_hiring_ratio * total_laborers, "SkilledRatio")

# Exclusion rule: Task 1 using Method B excludes Task 3 using Method A
model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1, "ExclusionRule")

# Minimum skilled workers for Task 3 if Method B is chosen
model.addConstr(s['Task_3', 'Method_B'] >= min_skilled_task3_B * y['Task_3', 'Method_B'], "MinSkilledTask3B")

# Task-specific skill share constraints
for t in tasks:
    if t == 'Task_1':
        min_skill = min_skilled_share_task1
        max_skill = max_skilled_share_task1
    elif t == 'Task_2':
        min_skill = min_skilled_share_task2
        max_skill = max_skilled_share_task2
    else:  # Task_3
        min_skill = min_skilled_share_task3
        max_skill = max_skilled_share_task3

    total_workers = s[t, 'Method_A'] + s[t, 'Method_B'] + l[t, 'Method_A'] + l[t, 'Method_B']
    model.addConstr((s[t, 'Method_A'] + s[t, 'Method_B']) / total_workers >= min_skill, f"MinSkill_{t}")
    model.addConstr((s[t, 'Method_A'] + s[t, 'Method_B']) / total_workers <= max_skill, f"MaxSkill_{t}")

# Solve
model.Params.OutputFlag = 0
model.optimize()

# Print solution details
print(f"Status: {model.Status}")
print(f"Total Skilled Workers: {total_skilled.X}")
print(f"Total Laborers: {total_laborers.X}")

for t in tasks:
    for m in methods:
        if y[t, m].X > 0.5:
            print(f"{t}: {m}, Skilled={s[t,m].X:.1f}, Laborers={l[t,m].X:.1f}, Fixed={tm_data[t,m]['Fixed_Cost']}")

obj_val = model.ObjVal
print(f"\nFINAL_OBJ_VALUE: {obj_val}")
