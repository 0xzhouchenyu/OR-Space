import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load demand data
    demand = {}
    with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
        reader = csv.reader(f)
        header = next(reader)
        quarters = [int(h) for h in header[1:]]
        for row in reader:
            product = row[0].strip()
            for j, q in enumerate(quarters):
                demand[(product, q)] = int(row[j+1])
    
    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"])
    
    products = ["I", "II", "III"]
    quarters = [1, 2, 3, 4]
    
    init_inv = params["initial_inventory"]
    end_inv_req = params["end_inventory_requirement"]
    total_hours_per_quarter = params["production_hours_per_quarter"]
    hours_per_unit = {
        "I": params["product_I_hours_per_unit"],
        "II": params["product_II_hours_per_unit"],
        "III": params["product_III_hours_per_unit"]
    }
    delay_penalty = {
        "I": params["delay_penalty_product_I"],
        "II": params["delay_penalty_product_II"],
        "III": params["delay_penalty_product_III"]
    }
    inv_cost = params["inventory_cost_per_unit"]
    
    normal_hours_cap_fraction = {
        "q1": params["normal_hours_cap_fraction_q1"],
        "q2": params["normal_hours_cap_fraction_q2"],
        "q3": params["normal_hours_cap_fraction_q3"],
        "q4": params["normal_hours_cap_fraction_q4"]
    }
    peak_hours_cap = {
        "q1": params["peak_hours_cap_q1"],
        "q2": params["peak_hours_cap_q2"],
        "q3": params["peak_hours_cap_q3"],
        "q4": params["peak_hours_cap_q4"]
    }
    peak_cost_per_hour = {
        "q1": params["peak_cost_per_hour_q1"],
        "q2": params["peak_cost_per_hour_q2"],
        "q3": params["peak_cost_per_hour_q3"],
        "q4": params["peak_cost_per_hour_q4"]
    }
    
    model = gp.Model("ProductionScheduling")
    model.setParam("OutputFlag", 0)
    
    # Decision variables: production quantities (normal and peak hours)
    x_normal = {(p, t): model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_normal_{p}_{t}") for p in products for t in quarters}
    x_peak = {(p, t): model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_peak_{p}_{t}") for p in products for t in quarters}
    
    # Product I cannot be produced in Q2 in either normal or peak hours
    if "I" in x_normal and 2 in x_normal["I"]:
        x_normal[("I", 2)].ub = 0
    if "I" in x_peak and 2 in x_peak["I"]:
        x_peak[("I", 2)].ub = 0
    
    # Inventory variables
    inv = {(p, t): model.addVar(lb=0, vtype=GRB.INTEGER, name=f"inv_{p}_{t}") for p in products for t in quarters}
    inv_pos = {(p, t): model.addVar(lb=0, vtype=GRB.INTEGER, name=f"inv_pos_{p}_{t}") for p in products for t in quarters}
    inv_neg = {(p, t): model.addVar(lb=0, vtype=GRB.INTEGER, name=f"inv_neg_{p}_{t}") for p in products for t in quarters}
    
    # Inventory balance constraints
    for p in products:
        # Quarter 1
        model.addConstr(inv[(p, 1)] == init_inv + x_normal[(p, 1)] + x_peak[(p, 1)] - demand[(p, 1)])
        # Quarters 2-4
        for t in range(2, 5):
            model.addConstr(inv[(p, t)] == inv[(p, t-1)] + x_normal[(p, t)] + x_peak[(p, t)] - demand[(p, t)])
    
    # Split inventory into positive and negative parts
    for p in products:
        for t in quarters:
            model.addConstr(inv[(p, t)] == inv_pos[(p, t)] - inv_neg[(p, t)])
    
    # End of Q4: inventory must be at least end_inv_req
    for p in products:
        model.addConstr(inv[(p, 4)] >= end_inv_req)
    
    # Normal and peak hours constraints per quarter
    for t in quarters:
        normal_hours_available = total_hours_per_quarter * normal_hours_cap_fraction[f"q{t}"]
        model.addConstr(
            lpSum(hours_per_unit[p] * x_normal[(p, t)] for p in products) <= normal_hours_available
        )
        model.addConstr(
            lpSum(hours_per_unit[p] * x_peak[(p, t)] for p in products) <= peak_hours_cap[f"q{t}"]
        )
    
    # Calculate total cost including peak costs
    total_cost = 0
    for p in products:
        for t in quarters:
            total_cost += delay_penalty[p] * inv_neg[(p, t)]
            total_cost += inv_cost * inv_pos[(p, t)]
            total_cost += peak_cost_per_hour[f"q{t}"] * hours_per_unit[p] * x_peak[(p, t)]
    
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    model.optimize()
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
