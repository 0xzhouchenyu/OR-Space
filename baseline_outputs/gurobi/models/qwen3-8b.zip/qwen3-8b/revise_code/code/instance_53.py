import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read costs from table_1.csv
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row['Child']
            costs[child] = {
                'budget': float(row['Cost_budget']),
                'balanced': float(row['Cost_balanced']),
                'premium': float(row['Cost_premium'])
            }
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children = int(params['max_children'])
    min_children = int(params['min_children'])
    max_total_cost = float(params['max_total_cost'])
    min_children_per_mode = int(params['min_children_per_mode'])
    fairness_penalty = float(params['fairness_penalty'])
    
    children = list(costs.keys())
    
    # Create binary decision variables
    model = gp.Model("ZhangFamilyTrip")
    model.setParam('OutputFlag', 0)
    
    # Mode selection (budget, balanced, premium)
    mode = model.addVar(vtype=GRB.BINARY, name="mode")
    budget_mode = model.addVar(vtype=GRB.BINARY, name="budget_mode")
    balanced_mode = model.addVar(vtype=GRB.BINARY, name="balanced_mode")
    premium_mode = model.addVar(vtype=GRB.BINARY, name="premium_mode")
    
    # Ensure only one mode is selected
    model.addConstr(budget_mode + balanced_mode + premium_mode == 1, "OneModeSelected")
    
    # Child selection variables
    x = {child: model.addVar(vtype=GRB.BINARY, name=f"x_{child}") for child in children}
    
    # Ginny must go
    model.addConstr(x['Ginny'] == 1, "Ginny_must_go")
    
    # Group size constraints
    total_children = model.addVar(vtype=GRB.INTEGER, name="total_children")
    model.addConstr(total_children == sum(x[child] for child in children), "TotalChildren")
    model.addConstr(total_children <= max_children, "MaxChildren")
    model.addConstr(total_children >= min_children, "MinChildren")
    
    # Mode-specific minimum children constraint
    model.addConstr((balanced_mode + premium_mode) * (total_children >= min_children_per_mode), "MinChildrenPerMode")
    
    # Mode-dependent cost calculation
    cost_budget = model.addVar(vtype=GRB.CONTINUOUS, name="cost_budget")
    cost_balanced = model.addVar(vtype=GRB.CONTINUOUS, name="cost_balanced")
    cost_premium = model.addVar(vtype=GRB.CONTINUOUS, name="cost_premium")
    
    # Budget mode cost
    model.addConstr(cost_budget == sum(costs[child]['budget'] * x[child] for child in children), "CostBudget")
    model.addConstr(budget_mode == 1, "BudgetModeSelected")  # Force budget mode for now
    
    # Balanced mode cost
    model.addConstr(cost_balanced == sum(costs[child]['balanced'] * x[child] for child in children), "CostBalanced")
    
    # Premium mode cost
    model.addConstr(cost_premium == sum(costs[child]['premium'] * x[child] for child in children), "CostPremium")
    
    # Total cost constraint based on selected mode
    model.addConstr(gp.quicksum([cost_budget * budget_mode, cost_balanced * balanced_mode, cost_premium * premium_mode]) <= max_total_cost, "MaxTotalCost")
    
    # Fairness penalty calculation
    max_cost = model.addVar(vtype=GRB.CONTINUOUS, name="max_cost")
    min_cost = model.addVar(vtype=GRB.CONTINUOUS, name="min_cost")
    fairness_charge = model.addVar(vtype=GRB.CONTINUOUS, name="fairness_charge")
    
    # Calculate max and min costs based on selected mode
    model.addConstr(max_cost == gp.max_(
        [costs[child]['budget'] * x[child] for child in children] + 
        [costs[child]['balanced'] * x[child] for child in children] + 
        [costs[child]['premium'] * x[child] for child in children]
    ), "MaxCost")
    model.addConstr(min_cost == gp.min_(
        [costs[child]['budget'] * x[child] for child in children] + 
        [costs[child]['balanced'] * x[child] for child in children] + 
        [costs[child]['premium'] * x[child] for child in children]
    ), "MinCost")
    
    # Fairness charge
    model.addConstr(fairness_charge == fairness_penalty * (max_cost - min_cost), "FairnessCharge")
    
    # Objective function: total cost + fairness charge
    objective = (
        gp.quicksum([cost_budget * budget_mode, cost_balanced * balanced_mode, cost_premium * premium_mode]) +
        fairness_charge
    )
    model.setObjective(objective, GRB.MINIMIZE)
    
    # Compatibility constraints
    model.addConstr(x['Harry'] + x['Fred'] <= 1, "HarryNoFred")
    model.addConstr(x['Harry'] + x['George'] <= 1, "HarryNoGeorge")
    model.addConstr(x['George'] <= x['Fred'], "GeorgeRequiresFred")
    model.addConstr(x['George'] <= x['Hermione'], "GeorgeRequiresHermione")
    
    # Solve the model
    model.optimize()
    
    # Print solution details
    for child in children:
        if x[child].x > 0.5:
            print(f"{child}: selected (cost={costs[child][params['mode']]})")
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
