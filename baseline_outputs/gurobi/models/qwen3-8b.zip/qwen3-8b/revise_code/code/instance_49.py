import os
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    table_2_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_2.csv")
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")

    table_1 = pd.read_csv(table_1_path)
    table_2 = pd.read_csv(table_2_path)
    params = pd.read_csv(params_path)

    # Parse parameters
    min_contract_types = int(params.loc[params['Parameter_Name'] == 'min_contract_types', 'Value'].values[0])
    max_contract_types = int(params.loc[params['Parameter_Name'] == 'max_contract_types', 'Value'].values[0])
    mutual_exclusion = str(params.loc[params['Parameter_Name'] == 'mutual_exclusion_1_and_4', 'Value'].values[0]).strip().lower() == 'true'
    monthly_max_parallel_contracts = int(params.loc[params['Parameter_Name'] == 'monthly_max_parallel_contracts', 'Value'].values[0])
    min_area_per_contract_units = float(params.loc[params['Parameter_Name'] == 'min_area_per_contract_units', 'Value'].values[0])
    activation_fee_per_contract = float(params.loc[params['Parameter_Name'] == 'activation_fee_per_contract', 'Value'].values[0])
    onboarding_loss_units = float(params.loc[params['Parameter_Name'] == 'onboarding_loss_units', 'Value'].values[0])
    expedited_onboarding_fee = float(params.loc[params['Parameter_Name'] == 'expedited_onboarding_fee', 'Value'].values[0])

    # Convert required area to units of 100 ㎡
    demands = {int(row['Month']): float(row['Required_area_㎡']) / 100.0 for _, row in table_1.iterrows()}
    costs = {int(row['Contract_length_months']): float(row['Rental_fee_per_100㎡_yuan']) for _, row in table_2.iterrows()}
    contract_lengths = list(costs.keys())
    months = list(demands.keys())
    max_month = max(months)

    # Initialize model
    model = gp.Model("Warehouse_Rental")
    model.setParam('OutputFlag', 0)

    # Variables
    # x[i][j] = number of contracts starting at month i with length j
    x = {}
    for i in months:
        for j in contract_lengths:
            if i + j - 1 <= max_month:
                x[(i, j)] = model.addVar(vtype=GRB.INTEGER, name=f"x_{i}_{j}")

    # y[j] = 1 if contract length j is used, 0 otherwise
    y = {}
    for j in contract_lengths:
        y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")

    # z[i] = 1 if any contract starts in month i, 0 otherwise
    z = {}
    for i in months:
        z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{i}")

    # e[i][j] = 1 if contract (i,j) has expedited onboarding, 0 otherwise
    e = {}
    for i in months:
        for j in contract_lengths:
            if i + j - 1 <= max_month:
                e[(i, j)] = model.addVar(vtype=GRB.BINARY, name=f"e_{i}_{j}")

    # Objective: Minimize total rental cost + activation fees + onboarding loss
    obj = 0
    for (i, j) in x:
        obj += costs[j] * x[(i, j)] * (1 - e[(i, j)])  # normal rental cost
        obj += costs[j] * x[(i, j)] * e[(i, j)]       # expedited rental cost
        obj += activation_fee_per_contract * x[(i, j)]  # activation fee
        obj += onboarding_loss_units * x[(i, j)] * (1 - e[(i, j)])  # onboarding loss
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    # 1. Demand fulfillment for each month
    for m in months:
        demand = demands[m]
        model.addConstr(gp.quicksum(x[(i, j)] for (i, j) in x if i <= m and i + j - 1 >= m) >= demand)
        model.addConstr(gp.quicksum(x[(i, j)] for (i, j) in x if i <= m and i + j - 1 >= m) <= demand)

    # 2. Link continuous variables x to binary variables y
    for j in contract_lengths:
        model.addConstr(gp.quicksum(x[(i, j)] for i in months if i + j - 1 <= max_month) <= 1e9 * y[j])
        model.addConstr(gp.quicksum(x[(i, j)] for i in months if i + j - 1 <= max_month) >= y[j])

    # 3. Contract types limits
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) >= min_contract_types)
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) <= max_contract_types)

    # 4. Mutual exclusion between 1-month and 4-month contracts
    if mutual_exclusion:
        model.addConstr(y[1] + y[4] <= 1)

    # 5. Maximum parallel contracts per month
    for m in months:
        model.addConstr(gp.quicksum(x[(i, j)] for (i, j) in x if i == m) <= monthly_max_parallel_contracts)

    # 6. Minimum area per contract
    for (i, j) in x:
        model.addConstr(x[(i, j)] >= min_area_per_contract_units)

    # 7. Link x to z
    for (i, j) in x:
        model.addConstr(z[i] >= x[(i, j)])

    # Solve the problem
    model.optimize()

    # Output the objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    import pandas as pd
    solve()
