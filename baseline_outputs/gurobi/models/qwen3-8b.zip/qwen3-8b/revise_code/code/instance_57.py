import gurobipy as gp
from gurobipy import GRB
import csv
import os

def solve():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read orders
    table_1_path = os.path.join(data_path, "table_1.csv")
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        orders = []
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
    
    # Read parameters
    params_path = os.path.join(data_path, "general_parameters.csv")
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    std_widths = [params['standard_width_1'], params['standard_width_2']]
    pattern_setup_penalty = params['pattern_setup_penalty']
    wide_roll_threshold_width = params['wide_roll_threshold_width']
    wide_roll_extra_setup_penalty = params['wide_roll_extra_setup_penalty']
    
    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    
    total_required_area = sum(w * l for w, l in zip(widths, lengths))
    
    # Generate cutting patterns
    patterns_by_std_width = {}
    for idx, sw in enumerate(std_widths):
        patterns = []
        def build_pattern(index, current_pattern, current_sum):
            if index == len(widths):
                if any(c > 0 for c in current_pattern):
                    patterns.append(current_pattern)
                return
            
            max_count = int(math.floor((sw - current_sum + 1e-7) / widths[index]))
            for count in range(max_count + 1):
                build_pattern(index + 1, current_pattern + [count], current_sum + count * widths[index])
                
        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {'sw': sw, 'patterns': patterns}
    
    # Create model
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x_vars[(std_idx, pattern_idx)] = number of rolls used
    x_vars = {}
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            x_vars[(idx, i)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{idx}_{i}")
    
    # Objective function: minimize total area used + setup penalties
    obj = 0
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            sw = data['sw']
            penalty = pattern_setup_penalty
            if sw >= wide_roll_threshold_width:
                penalty += wide_roll_extra_setup_penalty
            obj += (sw + penalty) * x_vars[(idx, i)]
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints: satisfy length requirements for each order width
    for j in range(len(widths)):
        constraint_expr = 0
        for idx, data in patterns_by_std_width.items():
            for i, p in enumerate(data['patterns']):
                constraint_expr += p[j] * x_vars[(idx, i)]
        model.addConstr(constraint_expr >= lengths[j])
    
    # Solve the model
    model.optimize()
    
    # Calculate and print final objective value
    final_obj_value = model.objVal
    print(f"FINAL_OBJ_VALUE: {round(final_obj_value, 4)}")

if __name__ == "__main__":
    solve()
