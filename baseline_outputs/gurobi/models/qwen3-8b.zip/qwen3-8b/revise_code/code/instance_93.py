import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = float(row["Value"])
            params[name] = val
    
    # Extract parameters
    milk_per_barrel = params["milk_per_barrel"]
    product_A1_yield = params["product_A1_yield"]
    product_A1_time = params["product_A1_time"]
    product_A2_yield = params["product_A2_yield"]
    product_A2_time = params["product_A2_time"]
    product_A3_yield = params["product_A3_yield"]
    product_A3_time = params["product_A3_time"]
    profit_per_kg_A1 = params["profit_per_kg_A1"]
    profit_per_kg_A2 = params["profit_per_kg_A2"]
    profit_per_kg_A3 = params["profit_per_kg_A3"]
    daily_milk_supply = params["daily_milk_supply"]
    daily_labor_hours = params["daily_labor_hours"]
    type_A_capacity = params["type_A_capacity"]
    cap_A_shared = params["cap_A_shared"]
    min_A2_kg = params["min_A2_kg"]
    min_A3_kg = params["min_A3_kg"]
    type_A_cleaning_loss_if_A3 = params["type_A_cleaning_loss_if_A3"]
    cold_chain_bonus_threshold_kg = params["cold_chain_bonus_threshold_kg"]
    cold_chain_bonus_yuan = params["cold_chain_bonus_yuan"]
    
    # Decision variables
    x1 = gp.LpVariable("x1", lowBound=0)  # barrels for A1
    x2 = gp.LpVariable("x2", lowBound=0)  # barrels for A2
    x3 = gp.LpVariable("x3", lowBound=0)  # barrels for A3
    
    # Model
    model = gp.LpProblem("Dairy_Production", gp.LpMaximize)
    
    # Objective: maximize profit
    model += (product_A1_yield * profit_per_kg_A1 + product_A2_yield * profit_per_kg_A2 + product_A3_yield * profit_per_kg_A3) * (x1 + x2 + x3) - cold_chain_bonus_yuan * gp.LpBinary("cold_chain_bonus")
    
    # Constraints
    # Milk supply
    model += x1 + x2 + x3 <= daily_milk_supply, "Milk_Supply"
    
    # Labor hours
    model += product_A1_time * x1 + product_A2_time * x2 + product_A3_time * x3 <= daily_labor_hours, "Labor_Hours"
    
    # Type A capacity (shared)
    model += product_A1_yield * x1 + product_A3_yield * x3 <= cap_A_shared, "Type_A_Capacity"
    
    # Minimum A2 production
    model += product_A2_yield * x2 >= min_A2_kg, "Min_A2_Prod"
    
    # Minimum A3 production
    model += product_A3_yield * x3 >= min_A3_kg, "Min_A3_Prod"
    
    # Cold chain bonus condition
    model += product_A3_yield * x3 >= cold_chain_bonus_threshold_kg, "Cold_Chain_Bonus_Threshold"
    
    # Cold chain bonus variable
    model += cold_chain_bonus_yuan * gp.LpBinary("cold_chain_bonus")
    
    # Solve
    model.solve()
    
    obj_val = value(model.objective)
    
    print(f"Status: {model.status}")
    print(f"x1 (barrels for A1) = {value(x1)}")
    print(f"x2 (barrels for A2) = {value(x2)}")
    print(f"x3 (barrels for A3) = {value(x3)}")
    print(f"A1 produced = {value(x1) * product_A1_yield} kg")
    print(f"A2 produced = {value(x2) * product_A2_yield} kg")
    print(f"A3 produced = {value(x3) * product_A3_yield} kg")
    print(f"OBJECTIVE_VALUE: {obj_val}")

if __name__ == "__main__":
    main()

FINAL_OBJ_VALUE: 3540.0
