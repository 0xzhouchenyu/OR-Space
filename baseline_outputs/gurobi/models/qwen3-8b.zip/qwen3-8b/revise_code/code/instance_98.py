import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Create model
    model = gp.Model("Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    for p in products:
        x[p['Product']] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{p['Product']}")
    
    # Overtime variables
    overtime = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="overtime")
    audit_fee = model.addVar(vtype=GRB.BINARY, name="audit_fee")
    
    # Objective: maximize profit - overtime cost - audit fee
    objective = 0
    for p in products:
        objective += float(p['Profit_yuan']) * x[p['Product']]
    objective -= params['overtime_pay'] * overtime
    objective -= params['product_A_line_audit_fee'] * audit_fee
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Constraints
    # Steel constraint
    model.addConstr(gp.quicksum(float(p['Steel_Required_kg']) * x[p['Product']] for p in products) <= params['available_steel'], "Steel")
    
    # Aluminum constraint
    model.addConstr(gp.quicksum(float(p['Aluminum_Required_kg']) * x[p['Product']] for p in products) <= params['available_aluminum'], "Aluminum")
    
    # Labor constraint
    labor_used = gp.quicksum(float(p['Labor_Required_hours']) * x[p['Product']] for p in products)
    model.addConstr(labor_used <= params['available_labor'] + overtime, "Labor")
    model.addConstr(overtime <= params['max_overtime'], "Max_Overtime")
    
    # Overtime review threshold
    model.addConstr(labor_used >= params['overtime_review_threshold'] + 1e-6, "Overtime_Threshold", name="Overtime_Threshold")
    model.addConstr(overtime >= labor_used - params['overtime_review_threshold'] + 1e-6, "Overtime_Calculation")
    model.addConstr(overtime >= 0, "Non_Negative_Overtime")
    
    # Line audit for Product A
    a_units = x['A']
    model.addConstr(a_units <= params['product_A_line_audit_threshold'] + 1e-6, "Audit_Threshold")
    model.addConstr(a_units >= params['product_A_line_audit_threshold'] + 1e-6, "Audit_Trigger")
    model.addConstr(audit_fee >= 0, "Audit_Fee_Lower_Bound")
    model.addConstr(audit_fee <= 1, "Audit_Fee_Upper_Bound")
    
    # Solve the model
    model.optimize()
    
    # Print results
    for p in products:
        print(f"{p['Product']}: {x[p['Product']].x}")
    
    print(f"OBJECTIVE_VALUE: {model.objVal}")
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
