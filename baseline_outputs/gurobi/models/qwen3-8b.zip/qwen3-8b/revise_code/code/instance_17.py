import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_data, fuel_per_heavy_bomb, fuel_per_light_bomb, prob_destroy_part, prob_at_least_k


def main():
    parts, params = load_data()

    max_heavy = int(params['max_heavy_bombs'])
    max_light = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts = int(params['min_parts_destroyed'])
    n = len(parts)
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    sortie_fuel_overhead_A = params['sortie_fuel_overhead_A']
    sortie_fuel_overhead_B = params['sortie_fuel_overhead_B']
    scenario_prob_A = params['scenario_prob_A']
    scenario_prob_B = params['scenario_prob_B']

    # Precompute fuel per bomb type for each part
    fuel_h = [fuel_per_heavy_bomb(p['distance'], params) for p in parts]
    fuel_l = [fuel_per_light_bomb(p['distance'], params) for p in parts]

    # Create model
    model = gp.Model("BombAllocation")

    # Decision variables
    xh = [model.addVar(vtype=GRB.INTEGER, name=f"xh_{i}") for i in range(n)]
    xl = [model.addVar(vtype=GRB.INTEGER, name=f"xl_{i}") for i in range(n)]

    # Constraints: Bomb inventory limits
    model.addConstr(sum(xh) <= max_heavy, "MaxHeavyBombs")
    model.addConstr(sum(xl) <= max_light, "MaxLightBombs")

    # Constraints: Sortie limits for both scenarios
    total_sorties = [model.addVar(vtype=GRB.INTEGER, name=f"total_sorties_{i}") for i in range(n)]
    for i in range(n):
        model.addConstr(total_sorties[i] >= xh[i] + xl[i], f"Sorties_{i}_LowerBound")
        model.addConstr(total_sorties[i] <= max_sorties_A, f"Sorties_{i}_AUpperBound")
        model.addConstr(total_sorties[i] <= max_sorties_B, f"Sorties_{i}_BUpperBound")

    # Fuel constraints for both scenarios
    def compute_total_fuel(fuel_h, fuel_l, xh, xl, overhead):
        return sum((xh[i] * fuel_h[i] + xl[i] * fuel_l[i]) + overhead for i in range(n))

    fuel_A = compute_total_fuel(fuel_h, fuel_l, xh, xl, sortie_fuel_overhead_A)
    fuel_B = compute_total_fuel(fuel_h, fuel_l, xh, xl, sortie_fuel_overhead_B)

    model.addConstr(fuel_A <= fuel_limit, "FuelLimitA")
    model.addConstr(fuel_B <= fuel_limit, "FuelLimitB")

    # Objective: Maximize expected mission success probability
    probs = [prob_destroy_part(xh[i], xl[i], parts[i]['p_heavy'], parts[i]['p_light']) for i in range(n)]

    # Compute the probability of at least k parts destroyed for each scenario
    def compute_success_prob(probs):
        dp = [0.0] * (n + 1)
        dp[0] = 1.0
        for i in range(n):
            new_dp = [0.0] * (n + 1)
            for j in range(i + 2):
                new_dp[j] += dp[j] * (1.0 - probs[i])
                if j > 0:
                    new_dp[j] += dp[j - 1] * probs[i]
            dp = new_dp
        return sum(dp[j] for j in range(min_parts, n + 1))

    success_prob_A = compute_success_prob(probs)
    success_prob_B = compute_success_prob(probs)

    objective = scenario_prob_A * success_prob_A + scenario_prob_B * success_prob_B

    model.setObjective(objective, GRB.MAXIMIZE)

    model.setParam('OutputFlag', 0)
    model.optimize()

    # Print final result
    print(f"FINAL_OBJ_VALUE: {objective:.4f}")


if __name__ == '__main__':
    main()
