import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load food items
    items = []
    with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })
    
    # Load parameters
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_daily_calories = params['min_daily_calories']
    max_daily_calories = params['max_daily_calories']
    max_daily_sodium = params['max_daily_sodium']
    
    max_units = int(total_weight_limit // 100)
    max_meal_units = 3
    
    model = gp.Model("dinner_lunch_optimization")
    model.setParam('OutputFlag', 0)
    
    # Variables
    purchase_units = {i: model.addVar(vtype=GRB.INTEGER, name=f"purchase_units_{items[i]['name']}") for i in range(len(items))}
    lunch_units = {i: model.addVar(vtype=GRB.INTEGER, name=f"lunch_units_{items[i]['name']}") for i in range(len(items))}
    dinner_units = {i: model.addVar(vtype=GRB.INTEGER, name=f"dinner_units_{items[i]['name']}") for i in range(len(items))}
    select_item = {i: model.addVar(vtype=GRB.BINARY, name=f"select_item_{items[i]['name']}") for i in range(len(items))}
    
    # Vegetable selection indicators
    lunch_veg_selected = {i: model.addVar(vtype=GRB.BINARY, name=f"lunch_veg_selected_{items[i]['name']}") for i in range(len(items))}
    dinner_veg_selected = {i: model.addVar(vtype=GRB.BINARY, name=f"dinner_veg_selected_{items[i]['name']}") for i in range(len(items))}
    
    # Constraints
    # Purchase units constraints
    for i in range(len(items)):
        model.addConstr(purchase_units[i] <= max_units * select_item[i])
        model.addConstr(lunch_units[i] <= max_meal_units * select_item[i])
        model.addConstr(dinner_units[i] <= max_meal_units * select_item[i])
    
    # Link lunch and dinner veg selected to units
    for i in range(len(items)):
        if items[i]['type'] == 'Vegetable':
            model.addConstr(lunch_units[i] >= lunch_veg_selected[i])
            model.addConstr(dinner_units[i] >= dinner_veg_selected[i])
            model.addConstr(lunch_units[i] <= max_meal_units * lunch_veg_selected[i])
            model.addConstr(dinner_units[i] <= max_meal_units * dinner_veg_selected[i])
    
    # Meal vegetable type constraints
    for meal in [lunch_veg_selected, dinner_veg_selected]:
        model.addConstr(gp.quicksum(meal[i] for i in range(len(items)) if items[i]['type'] == 'Vegetable') >= min_veg_types)
    
    # Meal weight constraints
    model.addConstr(gp.quicksum(100 * lunch_units[i] for i in range(len(items))) == 300)
    model.addConstr(gp.quicksum(100 * dinner_units[i] for i in range(len(items))) == 300)
    
    # Total weight constraint
    model.addConstr(gp.quicksum(100 * purchase_units[i] for i in range(len(items))) <= total_weight_limit)
    
    # Total budget constraint
    model.addConstr(gp.quicksum(items[i]['cost'] * purchase_units[i] for i in range(len(items))) <= max_budget)
    
    # Daily calorie constraints
    total_calories = gp.quicksum(items[i]['calories'] * (lunch_units[i] + dinner_units[i]) for i in range(len(items)))
    model.addConstr(total_calories >= min_daily_calories)
    model.addConstr(total_calories <= max_daily_calories)
    
    # Daily sodium constraint
    total_sodium = gp.quicksum(items[i]['sodium'] * (lunch_units[i] + dinner_units[i]) for i in range(len(items)))
    model.addConstr(total_sodium <= max_daily_sodium)
    
    # Objective: Maximize total protein
    total_protein = gp.quicksum(items[i]['protein'] * (lunch_units[i] + dinner_units[i]) for i in range(len(items)))
    model.setObjective(total_protein, GRB.MAXIMIZE)
    
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

main()
