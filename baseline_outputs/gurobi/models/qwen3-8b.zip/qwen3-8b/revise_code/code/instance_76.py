import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, '..', 'data')
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
    
    # Read general_parameters.csv
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_storage = float(params['max_storage_capacity'])  # 200000 m³
    storage_cost_a = float(params['storage_cost_a'])      # 70 yuan/m³
    storage_cost_b = float(params['storage_cost_b'])      # 100 yuan/m³/quarter
    safety_inventory_level = float(params['safety_inventory_level_10k_m3'])  # 20 万m³
    terminal_inventory_value = float(params['terminal_inventory_value_per_10k_m3'])  # 455 万元/万m³
    over_purchase_penalty = float(params['over_purchase_penalty_cost_per_10k_m3'])  # 300 万元/万m³
    
    # Convert to 万m³ and 万元
    max_storage_wm3 = max_storage / 10000.0
    safety_inventory_level_wm3 = safety_inventory_level / 10000.0
    terminal_inventory_value_w = terminal_inventory_value / 10000.0
    over_purchase_penalty_w = over_purchase_penalty / 10000.0
    
    n = len(quarters)
    
    # Decision variables: x[i][j] = amount purchased in quarter i and sold in quarter j (万m³)
    model = gp.Model("Timber_Profit_Maximization")
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[(i, j)] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{i}_{j}")
    
    # Objective function
    objective = 0
    for i in range(n):
        for j in range(i, n):
            u = j - i
            revenue = sale_price[quarters[j]]
            cost = purchase_price[quarters[i]]
            if u > 0:
                s_cost = storage_cost_a + storage_cost_b * u
            else:
                s_cost = 0
            profit = (revenue - cost - s_cost) * x[(i, j)]
            objective += profit
    
    # Terminal inventory value
    terminal_inventory = 0
    for i in range(n):
        for j in range(i, n):
            if j == n - 1:
                terminal_inventory += x[(i, j)]
    objective += terminal_inventory_value_w * terminal_inventory
    
    # Over-purchase penalty
    excess_inventory = 0
    for i in range(n):
        for j in range(i, n):
            if j == n - 1:
                excess_inventory += x[(i, j)]
    excess_inventory -= safety_inventory_level_wm3
    if excess_inventory > 0:
        objective -= over_purchase_penalty_w * excess_inventory
    
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Sales constraints: total sold in quarter j <= max_sales[j]
    for j in range(n):
        sales = 0
        for i in range(j + 1):
            sales += x[(i, j)]
        model.addConstr(sales <= max_sales[quarters[j]])
    
    # Purchase constraints: total purchased in quarter i <= max_purchase[i]
    for i in range(n):
        purchases = 0
        for j in range(i, n):
            purchases += x[(i, j)]
        model.addConstr(purchases <= max_purchase[quarters[i]])
    
    # Storage constraints: at end of each quarter, stored timber <= max_storage
    for t in range(n - 1):
        stored = 0
        for i in range(t + 1):
            for j in range(t + 1, n):
                stored += x[(i, j)]
        model.addConstr(stored <= max_storage_wm3)
    
    # Solve the model
    model.Params.OutputFlag = 0
    model.optimize()
    
    # Print results
    for i in range(n):
        for j in range(i, n):
            val = x[(i, j)].x
            if val > 0.001:
                u = j - i
                print(f"Buy in {quarters[i]}, sell in {quarters[j]} (store {u}q): {val:.2f} 万m³")
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal:.1f}")

if __name__ == "__main__":
    main()
