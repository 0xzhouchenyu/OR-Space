import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    profit_corn = params['profit_per_acre_corn']
    profit_wheat = params['profit_per_acre_wheat']
    profit_soybeans = params['profit_per_acre_soybeans']
    profit_sorghum = params['profit_per_acre_sorghum']
    total_area = params['total_farm_area']
    corn_wheat_ratio = params['corn_wheat_ratio']
    soybeans_sorghum_ratio = params['soybeans_sorghum_ratio']
    wheat_sorghum_ratio = params['wheat_sorghum_ratio']
    
    # Create model
    model = gp.Model("Farm_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    corn = model.addVar(lb=20, name="corn")  # Minimum 20 acres of corn
    wheat = model.addVar(lb=0, name="wheat")
    soybeans = model.addVar(lb=0, name="soybeans")
    sorghum = model.addVar(lb=0, name="sorghum")
    
    # Objective: maximize profit
    model.setObjective(
        profit_corn * corn + profit_wheat * wheat + 
        profit_soybeans * soybeans + profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )
    
    # Constraints
    # Total area
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")
    
    # Corn >= 2 * wheat
    model.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio")
    
    # Soybeans >= 0.5 * sorghum
    model.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio")
    
    # Wheat = 3 * sorghum (equality constraint based on "must be three times")
    model.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_ratio")
    
    # Mutual exclusion between corn and soybeans
    model.addConstr(corn + soybeans <= total_area, "mutual_exclusion")
    
    # Solve
    model.optimize()
    
    # Print results
    print(f"Status: {model.Status}")
    print(f"Corn: {corn.x:.2f} acres")
    print(f"Wheat: {wheat.x:.2f} acres")
    print(f"Soybeans: {soybeans.x:.2f} acres")
    print(f"Sorghum: {sorghum.x:.2f} acres")
    print(f"OBJECTIVE_VALUE: {model.objVal}")
    
    # Final output
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
