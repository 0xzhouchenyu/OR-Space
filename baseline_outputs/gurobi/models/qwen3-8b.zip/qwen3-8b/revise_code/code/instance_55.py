import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load data
courses = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        course = row["Course"].strip()
        categories = [c.strip() for c in row["Category"].split(";")]
        courses[course] = categories

params = {}
prerequisites = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row["Parameter_Name"].strip()
        value = row["Value"].strip()
        if name == "min_courses_required":
            params["min_courses_required"] = int(value)
        elif name.startswith("prerequisite_"):
            course_key = name[len("prerequisite_"):]
            prerequisites[course_key] = value
        elif name == "mandatory_foundation_for_cs_counting":
            params["mandatory_foundation_for_cs_counting"] = value
        elif name == "cs_category_name":
            params["cs_category_name"] = value

# Build prerequisite mapping: course -> list of prerequisites
course_list = list(courses.keys())
prerequisites_dict = {}

for prereq_key, prereq_value in prerequisites.items():
    course_name = None
    for course in course_list:
        if course.lower() == prereq_key.lower().replace("_", " "):
            course_name = course
            break
    if course_name:
        if course_name not in prerequisites_dict:
            prerequisites_dict[course_name] = []
        prerequisites_dict[course_name].append(prereq_value.strip())

# Get all categories
all_categories = set()
for cats in courses.values():
    for c in cats:
        all_categories.add(c)

# Create optimization model
model = gp.Model("CourseSelection")
model.setParam("OutputFlag", 0)

# Decision variables: binary, whether to take each course
x = {}
for course in course_list:
    x[course] = model.addVar(vtype=GRB.BINARY, name=f"x_{course.replace(' ', '_')}")

# Objective: minimize total number of courses taken
model.setObjective(gp.quicksum(x[course] for course in course_list), GRB.MINIMIZE)

# Constraint: at least min_required courses in each category
min_required = params["min_courses_required"]
for category in all_categories:
    courses_in_cat = [course for course, cats in courses.items() if category in cats]
    model.addConstr(gp.quicksum(x[course] for course in courses_in_cat) >= min_required, f"Min_{category.replace(' ', '_')}")

# Prerequisite constraints: if you take a course, you must take its prerequisites
for course, prereqs in prerequisites_dict.items():
    for prereq in prereqs:
        model.addConstr(x[course] <= x[prereq], f"Prereq_{course.replace(' ', '_')}_needs_{prereq.replace(' ', '_')}")

# Mandatory foundation for CS category
cs_category = params["cs_category_name"]
cs_courses = [course for course, cats in courses.items() if cs_category in cats]
foundation_course = params["mandatory_foundation_for_cs_counting"]

# Add constraint: if any CS course is selected, the foundation course must be selected
model.addConstr(gp.quicksum(x[course] for course in cs_courses) <= gp.quicksum(x[course] for course in [foundation_course]), "CS_Foundation")

# Solve
model.optimize()

# Print selected courses
print("Selected courses:")
for course in course_list:
    if x[course].X > 0.5:
        print(f"  {course}: {courses[course]}")

obj_val = model.objVal
print(f"\nFINAL_OBJ_VALUE: {obj_val}")
