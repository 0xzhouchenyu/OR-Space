import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    filepath = os.path.join(data_dir, "table_1.csv")

    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        
        bandwidth = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                bandwidth[(row_node, col_node)] = bw

    source = 'A'
    intermediate = 'C'
    target = 'E'

    model = gp.Model("Network_Routing_Optimization")
    model.setParam('OutputFlag', 0)

    # Variables
    x = {}
    for u in nodes:
        for v in nodes:
            if u != v and bandwidth.get((u, v), 0) > 0:
                x[(u, v)] = model.addVar(vtype=GRB.BINARY, name=f"x_{u}_{v}")

    # Constraints
    # Flow conservation at A
    flow_A = model.addConstr(gp.quicksum(x[(source, v)] for v in nodes if v != source) == 1, name="flow_A")

    # Flow conservation at E
    flow_E = model.addConstr(gp.quicksum(x[(v, target)] for v in nodes if v != target) == 1, name="flow_E")

    # Flow conservation at C (must pass through C)
    flow_C_in = model.addConstr(gp.quicksum(x[(v, intermediate)] for v in nodes if v != intermediate) == 1, name="flow_C_in")
    flow_C_out = model.addConstr(gp.quicksum(x[(intermediate, v)] for v in nodes if v != intermediate) == 1, name="flow_C_out")

    # No loops (path must be simple)
    for u in nodes:
        for v in nodes:
            if u != v and bandwidth.get((u, v), 0) > 0:
                for w in nodes:
                    if w != u and w != v:
                        model.addConstr(x[(u, v)] + x[(v, w)] + x[(w, u)] <= 2, name=f"no_loop_{u}_{v}_{w}")

    # Objective: minimize total routing cost
    cost = {}
    for u in nodes:
        for v in nodes:
            if u != v and bandwidth.get((u, v), 0) > 0:
                cost[(u, v)] = 100 - bandwidth[(u, v)]

    model.setObjective(gp.quicksum(cost[(u, v)] * x[(u, v)] for u in nodes for v in nodes if u != v and bandwidth.get((u, v), 0) > 0), GRB.MINIMIZE)

    model.optimize()

    # Extract path
    path = []
    current = source
    while current != target:
        for v in nodes:
            if v != current and x[(current, v)].x > 0.5:
                path.append(current)
                current = v
                break
        else:
            break
    path.append(target)

    print(f"Optimal Path: {' -> '.join(path)}")
    print(f"Minimum Total Routing Cost: {model.objVal}")

    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
