import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Extract parameters
a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']
T1_normal = params['available_time_process_1']
T2_normal = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']
c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
bigM_disposal = params['bigM_disposal']
disposal_cost = params['disposal_cost_per_unit_c']
disposal_cost_high = params['disposal_cost_per_unit_c_high']
profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

# Create model
model = gp.Model("MaxProfit")

# Decision variables
xA = model.addVar(lb=0, name="xA")  # units of product A
xB = model.addVar(lb=0, name="xB")  # units of product B
cSold = model.addVar(lb=0, name="cSold")  # units of by-product C sold
cDisposed = model.addVar(lb=0, name="cDisposed")  # units of by-product C disposed
highThroughputStage = model.addVar(vtype=GRB.BINARY, name="highThroughputStage")  # 1 if high-throughput used, 0 otherwise

# Constraints: Process time constraints based on high-throughput stage
model.addConstr(a_p1 * xA + b_p1 * xB <= T1_normal + (T1_high - T1_normal) * highThroughputStage, "Process1Time")
model.addConstr(a_p2 * xA + b_p2 * xB <= T2_normal + (T2_high - T2_normal) * highThroughputStage, "Process2Time")

# By-product C balance
model.addConstr(cSold + cDisposed == c_per_b * xB, "ByproductBalance")

# Maximum C that can be sold
model.addConstr(cSold <= max_c_sales, "MaxCSales")

# Disposal cost calculation using big-M method
cBelowThreshold = model.addVar(lb=0, name="cBelowThreshold")
cAboveThreshold = model.addVar(lb=0, name="cAboveThreshold")
model.addConstr(cDisposed == cBelowThreshold + cAboveThreshold, "SplitDisposal")
model.addConstr(cBelowThreshold <= threshold_c, "CBelowThreshold")
model.addConstr(cAboveThreshold >= cDisposed - threshold_c, "CAboveThreshold")
model.addConstr(cBelowThreshold >= cDisposed - bigM_disposal * (1 - highThroughputStage), "CBelowThresholdHigh")
model.addConstr(cAboveThreshold >= cDisposed - bigM_disposal * highThroughputStage, "CAboveThresholdHigh")

# Objective function
obj = (profit_a * xA + profit_b * xB + profit_c * cSold) - (disposal_cost * cBelowThreshold + disposal_cost_high * cAboveThreshold)
model.setObjective(obj, GRB.MAXIMIZE)

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Output results
print(f"Status: {model.Status}")
print(f"xA = {xA.X}")
print(f"xB = {xB.X}")
print(f"cSold = {cSold.X}")
print(f"cDisposed = {cDisposed.X}")
print(f"highThroughputStage = {highThroughputStage.X}")
obj_val = model.objVal
print(f"OBJECTIVE_VALUE: {obj_val}")

FINAL_OBJ_VALUE: 46.0
