import os
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
toys = []
with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            'type': row['Toy_Type'].strip(),
            'profit': float(row['Profit_Per_Unit']),
            'wood': float(row['Wood_Required_Per_Unit']),
            'steel': float(row['Steel_Required_Per_Unit']),
        })

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'])

available_wood = params['available_wood']
available_steel = params['available_steel']
premium_shift_capacity = params['premium_shift_capacity']
profit_premium_bonus = params['profit_premium_bonus']
premium_steel_factor = params['premium_steel_factor']

# Create model
model = gp.Model("HausToys")

# Decision variables - quantities
x = {}
for t in toys:
    x[t['type']] = model.addVar(lb=0, name=f"x_{t['type']}")

# Binary variables - whether to manufacture
y = {}
for t in toys:
    y[t['type']] = model.addVar(vtype=GRB.BINARY, name=f"y_{t['type']}")

# Binary variables - whether to produce on premium shift
z = {}
for t in toys:
    z[t['type']] = model.addVar(vtype=GRB.BINARY, name=f"z_{t['type']}")

# Objective: maximize profit
profit = 0
for t in toys:
    profit += (t['profit'] + profit_premium_bonus * z[t['type']]) * x[t['type']]
model.setObjective(profit, GRB.MAXIMIZE)

# Resource constraints
# Wood constraint
model.addConstr(gp.quicksum(t['wood'] * x[t['type']] for t in toys) <= available_wood, "Wood_Constraint")

# Steel constraint
model.addConstr(gp.quicksum(t['steel'] * x[t['type']] * (1 if z[t['type']] == 0 else premium_steel_factor) for t in toys) <= available_steel, "Steel_Constraint")

# Premium shift capacity constraint
model.addConstr(gp.quicksum(x[t['type']] for t in toys) <= premium_shift_capacity, "Premium_Shift_Capacity")

# Linking constraints: x_i <= M * y_i
M = 1000
for t in toys:
    model.addConstr(x[t['type']] <= M * y[t['type']], f"Link_{t['type']}")

# Truck-train exclusion: if trucks manufactured, no trains
model.addConstr(y['truck'] + y['train'] <= 1, "Truck_Train_Exclusion")

# Boat-airplane dependency: if boats manufactured, airplanes must be too
model.addConstr(y['boat'] <= y['airplane'], "Boat_Airplane_Dependency")

# Boat-train limit: number of boats <= number of trains
model.addConstr(x['boat'] <= x['train'], "Boat_Train_Limit")

# Linking constraints: x_i <= M * z_i
for t in toys:
    model.addConstr(x[t['type']] <= M * z[t['type']], f"Premium_Link_{t['type']}")

# Ensure that if a toy is produced, it must be on one shift or the other
for t in toys:
    model.addConstr(y[t['type']] == z[t['type']] + (1 - y[t['type']]) * 0, f"Shift_Link_{t['type']}")

# Solve
model.Params.OutputFlag = 0
model.optimize()

# Print results
print(f"Status: {model.Status}")
for t in toys:
    print(f"{t['type']}: {x[t['type']].X:.2f} (manufacture: {y[t['type']].X})")

obj_val = model.ObjVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
