import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read property data
properties = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost']),
            'risky_cap': float(row['per_property_risky_cap']) if 'per_property_risky_cap' in row else 0.0,
            'risky_income': float(row['scen_1_prob']) * float(row['scen_1_risky_multiplier']) + float(row['scen_2_prob']) * float(row['scen_2_risky_multiplier'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

budget = params['budget']
total_risky_budget = params['total_risky_budget']
max_risky_properties = int(params['max_risky_properties'])

# Create optimization model
model = gp.Model("RealEstateInvestment")

# Decision variables: binary (buy or not)
x = {}
for p in properties:
    x[p['name']] = model.addVar(vtype=GRB.BINARY, name=p['name'])

# Decision variables: fraction of risky allocation per property
y = {}
for p in properties:
    y[p['name']] = model.addVar(vtype=GRB.CONTINUOUS, name=f"{p['name']}_risky", lb=0, ub=1)

# Objective: maximize annual income
objective = 0
for p in properties:
    # Base income from dependable tenancy
    objective += p['income'] * x[p['name']]
    # Risky income contribution
    objective += p['income'] * y[p['name']] * (params['scen_1_prob'] * params['scen_1_risky_multiplier'] + params['scen_2_prob'] * params['scen_2_risky_multiplier'])
model.setObjective(objective, GRB.MAXIMIZE)

# Budget constraint
model.addConstr(gp.quicksum(p['cost'] * x[p['name']] for p in properties) <= budget)

# Total risky budget constraint
model.addConstr(gp.quicksum(p['cost'] * y[p['name']] for p in properties) <= total_risky_budget)

# Maximum number of risky properties constraint
model.addConstr(gp.quicksum(x[p['name']] * y[p['name']] > 0 for p in properties) <= max_risky_properties)

# Per property risky cap constraint
for p in properties:
    model.addConstr(y[p['name']] <= p['risky_cap'] * x[p['name']])

# Property exclusion constraint
model.addConstr(x['Property_4'] + x['Property_3'] <= 1)

# Solve
model.Params.OutputFlag = 0
model.optimize()

# Print results
for p in properties:
    print(f"{p['name']}: {int(value(x[p['name']]))}, {value(y[p['name']])}")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
