import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load monthly prices
months = []
purchase_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        m = int(row["Month"])
        months.append(m)
        purchase_prices[m] = float(row["Purchase_Price_yuan_per_dan"])
        selling_prices[m] = float(row["Selling_Price_yuan_per_dan"])

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

warehouse_capacity = params["warehouse_capacity"]
initial_stock = params["initial_stock"]
initial_funds = params["initial_funds"]
end_inventory = params["end_of_quarter_inventory"]
buy_fast_capacity = params["buy_fast_capacity"]
fast_purchase_premium_ratio = params["fast_purchase_premium_ratio"]
credit_limit = params["credit_limit"]
monthly_interest_rate = params["monthly_interest_rate"]
min_inventory_month_1 = params["min_inventory_month_1"]
min_inventory_month_2 = params["min_inventory_month_2"]
min_inventory_month_3 = params["min_inventory_month_3"]

# Create model
model = gp.Model("Grain_Trading_Revised")

# Variables
buy_regular = {m: model.addVar(lb=0, name=f"buy_regular_{m}") for m in months}
buy_fast = {m: model.addVar(lb=0, name=f"buy_fast_{m}") for m in months}
sell = {m: model.addVar(lb=0, name=f"sell_{m}") for m in months}
stock = {m: model.addVar(lb=0, name=f"stock_{m}") for m in months}
funds = {m: model.addVar(lb=0, name=f"funds_{m}") for m in months}
credit_used = {m: model.addVar(lb=0, name=f"credit_used_{m}") for m in months}

# Objective: maximize (final funds - initial funds) - total interest
model.setObjective(
    funds[months[-1]] - initial_funds - sum(credit_used[m] * monthly_interest_rate for m in months),
    GRB.MAXIMIZE
)

# Constraints for each month
for m in months:
    prev_stock = initial_stock if m == 1 else stock[m - 1]
    prev_funds = initial_funds if m == 1 else funds[m - 1]
    prev_credit_used = 0 if m == 1 else credit_used[m - 1]

    # Stock balance
    model.addConstr(stock[m] == prev_stock - sell[m] + buy_regular[m] + buy_fast[m], f"stock_balance_{m}")

    # Funds balance
    regular_cost = buy_regular[m] * purchase_prices[m]
    fast_cost = buy_fast[m] * purchase_prices[m] * (1 + fast_purchase_premium_ratio)
    model.addConstr(
        funds[m] == prev_funds + sell[m] * selling_prices[m] - regular_cost - fast_cost,
        f"funds_balance_{m}"
    )

    # Credit usage constraint
    model.addConstr(credit_used[m] >= max(0, (regular_cost + fast_cost) - funds[m]), f"credit_usage_{m}")
    model.addConstr(credit_used[m] <= credit_limit, f"credit_limit_{m}")

    # Warehouse capacity
    model.addConstr(stock[m] <= warehouse_capacity, f"warehouse_capacity_{m}")

    # Minimum inventory constraints
    if m == 1:
        model.addConstr(stock[m] >= min_inventory_month_1, f"min_inventory_month_1")
    elif m == 2:
        model.addConstr(stock[m] >= min_inventory_month_2, f"min_inventory_month_2")
    elif m == 3:
        model.addConstr(stock[m] >= min_inventory_month_3, f"min_inventory_month_3")

# End of quarter inventory requirement
model.addConstr(stock[months[-1]] >= end_inventory, f"end_inventory")

# Solve the model
model.Params.OutputFlag = 0
model.optimize()

# Print results
print(f"Status: {model.Status}")
for m in months:
    print(f"Month {m}: Buy Regular={value(buy_regular[m]):.1f}, Buy Fast={value(buy_fast[m]):.1f}, Sell={value(sell[m]):.1f}, Stock={value(stock[m]):.1f}, Funds={value(funds[m]):.1f}, Credit Used={value(credit_used[m]):.1f}")

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
