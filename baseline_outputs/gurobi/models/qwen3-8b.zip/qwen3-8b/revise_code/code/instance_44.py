import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

m = int(params["m"])  # production points
n = int(params["n"])  # demand points
p = int(params["p"])  # marshaling stations

a = {i: params[f"a_{i}"] for i in range(1, m+1)}  # production capacities
b = {j: params[f"b_{j}"] for j in range(1, n+1)}  # demands
f_cost = {k: params[f"f_{k}"] for k in range(1, p+1)}  # fixed costs
q = {k: params[f"q_{k}"] for k in range(1, p+1)}  # max total transshipment capacity
qexp = {k: params[f"qexp_{k}"] for k in range(1, p+1)}  # max express transshipment capacity
alpha = {j: params[f"alpha_{j}"] for j in range(1, n+1)}  # min express fraction for demand points
eps = params["eps"]  # minimum strictly positive express flow to activate source indicator
M = params["M"]  # big-M upper bound on express flow per station-demand pair

# Load transportation costs from production to marshaling stations (regular and express)
cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row["i"])
        k = int(row["k"])
        cR_ik[(i, k)] = float(row["cR_ik"])
        cE_ik[(i, k)] = float(row["cE_ik"])

# Load transportation costs from marshaling stations to demand points (regular and express)
cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, "table_2.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row["k"])
        j = int(row["j"])
        cR_kj[(k, j)] = float(row["cR_kj"])
        cE_kj[(k, j)] = float(row["cE_kj"])

# Create the optimization model
model = gp.Model("Transportation_Problem")
model.setParam('OutputFlag', 0)

# Decision variables
# x_ik: amount shipped from production point i to marshaling station k via regular service
x = {}
for i in range(1, m+1):
    for k in range(1, p+1):
        x[(i, k)] = model.addVar(lb=0, name=f"x_{i}_{k}")

# y_ik: amount shipped from production point i to marshaling station k via express service
y = {}
for i in range(1, m+1):
    for k in range(1, p+1):
        y[(i, k)] = model.addVar(lb=0, name=f"y_{i}_{k}")

# z_kj: amount shipped from marshaling station k to demand point j via regular service
z = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        z[(k, j)] = model.addVar(lb=0, name=f"z_{k}_{j}")

# w_kj: amount shipped from marshaling station k to demand point j via express service
w = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        w[(k, j)] = model.addVar(lb=0, name=f"w_{k}_{j}")

# s_k: binary variable indicating whether marshaling station k is used
s = {}
for k in range(1, p+1):
    s[k] = model.addVar(vtype=GRB.BINARY, name=f"s_{k}")

# Objective: minimize total cost (regular + express) + fixed costs
total_cost = 0
for i in range(1, m+1):
    for k in range(1, p+1):
        total_cost += cR_ik[(i, k)] * x[(i, k)]
        total_cost += cE_ik[(i, k)] * y[(i, k)]

for k in range(1, p+1):
    for j in range(1, n+1):
        total_cost += cR_kj[(k, j)] * z[(k, j)]
        total_cost += cE_kj[(k, j)] * w[(k, j)]

total_fixed_cost = sum(f_cost[k] * s[k] for k in range(1, p+1))
model.setObjective(total_cost + total_fixed_cost, GRB.MINIMIZE)

# Constraints

# 1. Supply constraints: total shipped from production point i <= a_i
for i in range(1, m+1):
    model.addConstr(
        sum(x[(i, k)] for k in range(1, p+1)) + sum(y[(i, k)] for k in range(1, p+1)) <= a[i],
        f"Supply_{i}"
    )

# 2. Demand constraints: total received at demand point j >= b_j
for j in range(1, n+1):
    model.addConstr(
        sum(z[(k, j)] for k in range(1, p+1)) + sum(w[(k, j)] for k in range(1, p+1)) >= b[j],
        f"Demand_{j}"
    )

# 3. Flow conservation at marshaling stations
for k in range(1, p+1):
    model.addConstr(
        sum(x[(i, k)] for i in range(1, m+1)) + sum(y[(i, k)] for i in range(1, m+1)) ==
        sum(z[(k, j)] for j in range(1, n+1)) + sum(w[(k, j)] for j in range(1, n+1)),
        f"FlowBalance_{k}"
    )

# 4. Total capacity constraints at marshaling stations
for k in range(1, p+1):
    model.addConstr(
        sum(x[(i, k)] for i in range(1, m+1)) + sum(y[(i, k)] for i in range(1, m+1)) <= q[k] * s[k],
        f"TotalCapacity_{k}"
    )

# 5. Express capacity constraints at marshaling stations
for k in range(1, p+1):
    model.addConstr(
        sum(w[(k, j)] for j in range(1, n+1)) <= qexp[k] * s[k],
        f"ExpressCapacity_{k}"
    )

# 6. Express share constraints for demand points with more than one open station
for j in range(1, n+1):
    # Find all open stations for demand point j
    open_stations = [k for k in range(1, p+1) if sum(z[(k, j)] + w[(k, j)] for j in range(1, n+1)) > eps]
    if len(open_stations) >= 2:
        # Ensure that the express share is at least alpha_j
        model.addConstr(
            sum(w[(k, j)] for k in open_stations) / (sum(z[(k, j)] + w[(k, j)] for k in open_stations)) >= alpha[j],
            f"ExpressShare_{j}"
        )

# Solve the model
model.optimize()

# Print final objective value
FINAL_OBJ_VALUE: %.6f % (model.objVal)
