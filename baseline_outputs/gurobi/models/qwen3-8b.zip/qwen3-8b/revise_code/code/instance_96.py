import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    params = {}
    for _, row in df_params.iterrows():
        params[row['Parameter_Name']] = row['Value']

    raw_pipe_length_s1 = float(params['raw_pipe_length_supplier1'])
    raw_pipe_length_s2 = float(params['raw_pipe_length_supplier2'])
    max_patterns_s1 = int(params['max_cutting_patterns_supplier1'])
    max_patterns_s2 = int(params['max_cutting_patterns_supplier2'])
    max_cuts_s1 = int(params['max_cuts_per_pipe_supplier1'])
    max_cuts_s2 = int(params['max_cuts_per_pipe_supplier2'])
    max_leftover_s1 = float(params['max_leftover_length_supplier1'])
    max_leftover_s2 = float(params['max_leftover_length_supplier2'])
    purchase_cost_s1 = float(params['purchase_cost_per_pipe_supplier1'])
    purchase_cost_s2 = float(params['purchase_cost_per_pipe_supplier2'])
    discount_tier1_s1_max_qty = int(params['discount_tier1_supplier1_max_qty'])
    fixed_discount_tier2_s1 = float(params['fixed_discount_tier2_supplier1'])
    bigM_discount = int(params['bigM_discount'])

    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)

    # Generate patterns for each supplier
    def generate_patterns(raw_len, max_cuts, max_leftover):
        patterns = []
        def generate(current_pattern, current_length, current_cuts, item_idx):
            if item_idx == n_items:
                if current_length >= (raw_len - max_leftover) and current_length <= raw_len and current_cuts > 0:
                    patterns.append(tuple(current_pattern))
                return
            
            max_qty = min(
                int((raw_len - current_length) // lengths[item_idx]),
                max_cuts - current_cuts
            )
            
            for q in range(max_qty + 1):
                generate(
                    current_pattern + [q],
                    current_length + q * lengths[item_idx],
                    current_cuts + q,
                    item_idx + 1
                )

        generate([], 0, 0, 0)
        return patterns

    patterns_s1 = generate_patterns(raw_pipe_length_s1, max_cuts_s1, max_leftover_s1)
    patterns_s2 = generate_patterns(raw_pipe_length_s2, max_cuts_s2, max_leftover_s2)

    model = gp.Model("Pipe_Cutting_Revamped")
    model.setParam('OutputFlag', 0)

    # Variables for supplier 1
    y_s1 = model.addVars(range(len(patterns_s1)), name="y_s1", lb=0, vtype=GRB.INTEGER)
    z_s1 = model.addVars(range(len(patterns_s1)), name="z_s1", vtype=GRB.BINARY)
    u_s1 = model.addVars(range(1, max_patterns_s1 + 1), name="u_s1", vtype=GRB.BINARY)

    # Variables for supplier 2
    y_s2 = model.addVars(range(len(patterns_s2)), name="y_s2", lb=0, vtype=GRB.INTEGER)
    z_s2 = model.addVars(range(len(patterns_s2)), name="z_s2", vtype=GRB.BINARY)
    u_s2 = model.addVars(range(1, max_patterns_s2 + 1), name="u_s2", vtype=GRB.BINARY)

    # Pattern usage cost for supplier 1
    cost_rates_s1 = []
    rank_prefixes = ['most', 'second', 'third']
    for prefix in rank_prefixes:
        key = f"{prefix}_frequent_pattern_cost_rate_supplier1"
        if key in params:
            cost_rates_s1.append(float(params[key]))
        else:
            break

    extra_cost_s1 = 0
    for k in range(1, max_patterns_s1 + 1):
        if k - 1 < len(cost_rates_s1):
            extra_cost_s1 += cost_rates_s1[k - 1] * u_s1[k]

    # Pattern usage cost for supplier 2
    cost_rates_s2 = []
    for prefix in rank_prefixes:
        key = f"{prefix}_frequent_pattern_cost_rate_supplier2"
        if key in params:
            cost_rates_s2.append(float(params[key]))
        else:
            break

    extra_cost_s2 = 0
    for k in range(1, max_patterns_s2 + 1):
        if k - 1 < len(cost_rates_s2):
            extra_cost_s2 += cost_rates_s2[k - 1] * u_s2[k]

    # Total cost objective
    total_cost = (
        purchase_cost_s1 * sum(y_s1[p] for p in range(len(patterns_s1))) +
        purchase_cost_s2 * sum(y_s2[p] for p in range(len(patterns_s2))) +
        extra_cost_s1 +
        extra_cost_s2
    )

    # Discount for supplier 1
    Q_s1 = model.addVar(name="Q_s1", lb=0, vtype=GRB.INTEGER)
    discount = model.addVar(name="discount", lb=0, vtype=GRB.CONTINUOUS)
    model.addConstr(Q_s1 == sum(y_s1[p] for p in range(len(patterns_s1))))
    model.addConstr(discount == fixed_discount_tier2_s1 * (Q_s1 >= discount_tier1_s1_max_qty))

    total_cost += -discount

    model.setObjective(total_cost, GRB.MINIMIZE)

    # Demand coverage constraints
    for i in range(n_items):
        demand_i = demands[i]
        expr_s1 = sum(patterns_s1[p][i] * y_s1[p] for p in range(len(patterns_s1)))
        expr_s2 = sum(patterns_s2[p][i] * y_s2[p] for p in range(len(patterns_s2)))
        model.addConstr(expr_s1 + expr_s2 >= demand_i)

    # Link pattern usage to binary variables
    M = sum(demands)
    for p in range(len(patterns_s1)):
        model.addConstr(y_s1[p] <= M * z_s1[p])
    for p in range(len(patterns_s2)):
        model.addConstr(y_s2[p] <= M * z_s2[p])

    # Ensure number of used patterns per supplier is within limit
    model.addConstr(sum(z_s1[p] for p in range(len(patterns_s1))) <= max_patterns_s1)
    model.addConstr(sum(z_s2[p] for p in range(len(patterns_s2))) <= max_patterns_s2)

    # Order patterns by frequency
    for k in range(1, max_patterns_s1):
        model.addConstr(u_s1[k] >= u_s1[k+1])
    for k in range(1, max_patterns_s2):
        model.addConstr(u_s2[k] >= u_s2[k+1])

    # Link z to u for supplier 1
    model.addConstr(sum(z_s1[p] for p in range(len(patterns_s1))) == sum(u_s1[k] for k in range(1, max_patterns_s1 + 1)))
    # Link z to u for supplier 2
    model.addConstr(sum(z_s2[p] for p in range(len(patterns_s2))) == sum(u_s2[k] for k in range(1, max_patterns_s2 + 1)))

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
