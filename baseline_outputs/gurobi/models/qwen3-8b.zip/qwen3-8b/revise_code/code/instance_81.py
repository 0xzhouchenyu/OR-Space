import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add parent directory for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utils import load_car_data, load_parameters

# Data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

# Load data
cars = load_car_data(data_dir)
params = load_parameters(data_dir)

num_cars = int(params['num_cars'])
max_length_one_side = params['max_length_one_side']
available_party_side_count = int(params['available_party_side_count'])

car_ids = list(cars.keys())
lengths = cars

# Create model
model = gp.Model("ParkingMinStreetLength")

# Decision variables
x = {i: model.addVar(vtype=GRB.BINARY, name=f"x_{i}") for i in car_ids}

# Objective: minimize the total length used on the single usable side
total_length = sum(lengths[i] for i in car_ids)
side1 = sum(lengths[i] * x[i] for i in car_ids)

model.setObjective(side1, GRB.MINIMIZE)

# Constraint: side1 cannot exceed the maximum allowed length
model.addConstr(side1 <= max_length_one_side, "max_side_length")

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Extract solution
obj_val = model.objVal

print(f"Status: {model.Status}")
print(f"Total car length: {total_length}")
print(f"Side 1 length: {value(side1)}")
print(f"Cars on side 1: {[i for i in car_ids if value(x[i]) > 0.5]}")
print(f"OBJECTIVE_VALUE: {obj_val}")

FINAL_OBJ_VALUE: 32.4
