import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
goods = {}
with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        goods[row['Goods_Type'].strip()] = {
            'quantity': int(row['Quantity'].strip()),
            'weight': float(row['Weight_per_Unit'].strip())
        }

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

max_cap = params['max_container_capacity']
min_load = params['min_container_load']
min_d_per_container = int(params['min_d_goods_per_container'])
min_c_per_a = int(params['min_c_per_a'])

goods_types = list(goods.keys())
quantities = {g: goods[g]['quantity'] for g in goods_types}
weights = {g: goods[g]['weight'] for g in goods_types}

# Upper bound on number of containers
max_containers = 20  # Adjusted based on revised constraints

N = range(max_containers)

model = gp.Model("ContainerMinimization")

# Decision variables
x = {}
for g in goods_types:
    x[g] = model.addVars(N, lb=0, vtype=GRB.INTEGER, name=f"x_{g}")

y = model.addVars(N, vtype=GRB.BINARY, name="y")

# Objective: minimize number of containers
model.setObjective(gp.quicksum(y[j] for j in N), GRB.MINIMIZE)

# All goods must be transported
for g in goods_types:
    model.addConstr(gp.quicksum(x[g][j] for j in N) == quantities[g], f"demand_{g}")

# Container capacity constraint
for j in N:
    # If container is used, check capacity
    model.addConstr(gp.quicksum(weights[g] * x[g][j] for g in goods_types) <= max_cap * y[j], f"max_cap_{j}")

    # If container has E, use reduced capacity
    e_in_container = x['E'][j]
    model.addConstr(gp.quicksum(weights[g] * x[g][j] for g in goods_types) <= (max_cap if e_in_container == 0 else 45) * y[j], f"max_cap_with_E_{j}")

# Minimum load constraint
for j in N:
    model.addConstr(gp.quicksum(weights[g] * x[g][j] for g in goods_types) >= min_load * y[j], f"min_load_{j}")

# Minimum D goods per container (if container is used)
for j in N:
    model.addConstr(x['D'][j] >= min_d_per_container * y[j], f"min_D_{j}")

# If A goods are loaded, at least 1 C good must be loaded
M_A = quantities['A']
z = model.addVars(N, vtype=GRB.BINARY, name="z")
for j in N:
    model.addConstr(x['A'][j] <= M_A * z[j], f"A_indicator_{j}")
    model.addConstr(x['C'][j] >= min_c_per_a * z[j], f"C_if_A_{j}")

# Symmetry breaking
for j in range(len(N) - 1):
    model.addConstr(y[j] >= y[j+1], f"symmetry_{j}")

# Solve
model.setParam('OutputFlag', 0)
model.optimize()

# Print solution
print("Status:", model.status)
for j in N:
    if y[j].X > 1e-6:
        contents = {g: int(x[g][j].X) for g in goods_types if x[g][j].X > 1e-6}
        total_w = sum(weights[g] * x[g][j].X for g in goods_types)
        print(f"  Container {j}: {contents}, weight={total_w:.1f}")

FINAL_OBJ_VALUE: {model.objVal}
