import os
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Extract parameters
profit_A = params['profit_per_kg_product_A']
profit_B = params['profit_per_kg_product_B']
max_hours_week_1 = params['max_production_hours_week_1']
max_hours_week_2 = params['max_production_hours_week_2']
hours_A = params['hours_per_kg_product_A']
hours_B = params['hours_per_kg_product_B']
min_ratio_B_to_A = params['min_output_ratio_product_B_to_A']
storage_ratio_A_to_B = params['storage_space_ratio_product_A_to_B']
max_storage_A_equiv_week_1 = params['max_storage_product_A_equiv_week_1']
max_storage_A_equiv_week_2 = params['max_storage_product_A_equiv_week_2']
initial_inventory_A = params['initial_inventory_A']
initial_inventory_B = params['initial_inventory_B']
storage_cost_A = params['storage_cost_per_kg_A']
storage_cost_B = params['storage_cost_per_kg_B']
promo_bonus_A = params['promo_profit_bonus_A']
promo_bonus_B = params['promo_profit_bonus_B']
max_promotions_A = params['max_promotions_product_A']
max_promotions_B = params['max_promotions_product_B']

# Create model
model = gp.Model("Maximize_Profit")

# Decision variables
x_A_week1 = model.addVar(name="product_A_week1", lb=0)
x_B_week1 = model.addVar(name="product_B_week1", lb=0)
x_A_week2 = model.addVar(name="product_A_week2", lb=0)
x_B_week2 = model.addVar(name="product_B_week2", lb=0)

# Promotion variables
promo_A_week1 = model.addVar(vtype=GRB.BINARY, name="promo_A_week1")
promo_A_week2 = model.addVar(vtype=GRB.BINARY, name="promo_A_week2")
promo_B_week1 = model.addVar(vtype=GRB.BINARY, name="promo_B_week1")
promo_B_week2 = model.addVar(vtype=GRB.BINARY, name="promo_B_week2")

# Inventory variables
inv_A_week1 = model.addVar(name="inventory_A_week1", lb=0)
inv_B_week1 = model.addVar(name="inventory_B_week1", lb=0)
inv_A_week2 = model.addVar(name="inventory_A_week2", lb=0)
inv_B_week2 = model.addVar(name="inventory_B_week2", lb=0)

# Constraints
# Week 1 production hours
model.addConstr(hours_A * x_A_week1 + hours_B * x_B_week1 <= max_hours_week_1, "Production_Hours_Week1")

# Week 2 production hours
model.addConstr(hours_A * x_A_week2 + hours_B * x_B_week2 <= max_hours_week_2, "Production_Hours_Week2")

# Market demand: B >= 3*A in each week
model.addConstr(x_B_week1 >= min_ratio_B_to_A * x_A_week1, "Market_Demand_Week1")
model.addConstr(x_B_week2 >= min_ratio_B_to_A * x_A_week2, "Market_Demand_Week2")

# Storage capacity constraints
# Week 1 storage
storage_A_week1 = storage_ratio_A_to_B * x_A_week1 + x_B_week1
model.addConstr(storage_A_week1 <= max_storage_A_equiv_week_1, "Storage_Capacity_Week1")

# Week 2 storage
storage_A_week2 = storage_ratio_A_to_B * x_A_week2 + x_B_week2
model.addConstr(storage_A_week2 <= max_storage_A_equiv_week_2, "Storage_Capacity_Week2")

# Inventory continuity
model.addConstr(inv_A_week1 == initial_inventory_A + x_A_week1 - x_A_week2 - inv_A_week2, "Inventory_A_Continuity")
model.addConstr(inv_B_week1 == initial_inventory_B + x_B_week1 - x_B_week2 - inv_B_week2, "Inventory_B_Continuity")

# Inventory holding cost (only between weeks)
model.addConstr(inv_A_week2 >= 0, "Inventory_A_NonNegative")
model.addConstr(inv_B_week2 >= 0, "Inventory_B_NonNegative")

# Promotion constraints
model.addConstr(promo_A_week1 + promo_A_week2 <= max_promotions_A, "Promotion_Limit_A")
model.addConstr(promo_B_week1 + promo_B_week2 <= max_promotions_B, "Promotion_Limit_B")

# Objective function
# Profit calculation with promotions and inventory costs
profit = (
    (profit_A + (promo_bonus_A * promo_A_week1)) * x_A_week1 +
    (profit_B + (promo_bonus_B * promo_B_week1)) * x_B_week1 +
    (profit_A + (promo_bonus_A * promo_A_week2)) * x_A_week2 +
    (profit_B + (promo_bonus_B * promo_B_week2)) * x_B_week2 -
    storage_cost_A * inv_A_week2 -
    storage_cost_B * inv_B_week2
)

model.setObjective(profit, GRB.MAXIMIZE)

# Set solver parameters
model.setParam('OutputFlag', 0)

# Solve the model
model.optimize()

# Print results
print(f"FINAL_OBJ_VALUE: {model.objVal:.3f}")
