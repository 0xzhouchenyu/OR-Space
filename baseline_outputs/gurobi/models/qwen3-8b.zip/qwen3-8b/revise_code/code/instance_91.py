import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_parameters

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_hours = params['machine_working_time']
    machine_working_time_minutes = machine_working_time_hours * 60
    max_overtime_hours = params['max_overtime_hours']
    overtime_penalty_per_hour = params['overtime_penalty_per_hour']
    overtime_review_threshold_hours = params['overtime_review_threshold_hours']
    overtime_review_fee = params['overtime_review_fee']
    product_A_senior_batch_threshold = params['product_A_senior_batch_threshold']
    product_A_senior_batch_fee = params['product_A_senior_batch_fee']
    
    model = gp.Model("Product_Mix_Rev")
    model.setParam('OutputFlag', 0)
    
    A = model.addVar(name="Product_A", lb=0, vtype=GRB.CONTINUOUS)
    B = model.addVar(name="Product_B", lb=0, vtype=GRB.CONTINUOUS)
    
    # Objective function: maximize total profit
    # Profit = (Profit per unit) * quantity - (Overtime penalty) - (Senior batch fee if applicable)
    model.setObjective(
        profit_A * A + profit_B * B 
        - (gp.ifthen(A > product_A_senior_batch_threshold, product_A_senior_batch_fee))
        - (overtime_penalty_per_hour * max(0, (assembly_time_A * A + assembly_time_B * B - machine_working_time_minutes) / 60)),
        GRB.MAXIMIZE
    )
    
    # Constraint 1: Machine working time (including overtime)
    model.addConstr(
        assembly_time_A * A + assembly_time_B * B <= machine_working_time_minutes + max_overtime_hours * 60,
        "Machine_Time"
    )
    
    # Constraint 2: Overtime review threshold
    model.addConstr(
        (assembly_time_A * A + assembly_time_B * B - machine_working_time_minutes) <= max_overtime_hours * 60,
        "Overtime_Threshold"
    )
    
    # Constraint 3: Overtime review fee if overtime exceeds the threshold
    model.addConstr(
        (assembly_time_A * A + assembly_time_B * B - machine_working_time_minutes) >= 0,
        "Overtime_Usage"
    )
    model.addGenConstrIndicator(
        (assembly_time_A * A + assembly_time_B * B - machine_working_time_minutes) > overtime_review_threshold_hours * 60,
        overtime_review_fee,
        name="Overtime_Review_Fee"
    )
    
    # Constraint 4: Production ratio - at least 2 units of B for every 5 units of A
    model.addConstr(
        2 * A - 5 * B <= 0,
        "Production_Ratio"
    )
    
    # Solve
    model.optimize()
    
    print(f"Status: {model.Status}")
    print(f"Product A: {A.X:.4f}")
    print(f"Product B: {B.X:.4f}")
    
    obj_val = model.objVal
    print(f"OBJECTIVE_VALUE: {obj_val:.1f}")
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
