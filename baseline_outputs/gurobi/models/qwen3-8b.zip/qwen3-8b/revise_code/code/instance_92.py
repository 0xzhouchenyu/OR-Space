import os
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

num_students = int(params['num_students'])
num_buses = int(params['num_buses'])
bus_capacity = int(params['bus_capacity'])
num_minibuses = int(params['num_minibuses'])
minibus_capacity = int(params['minibus_capacity'])
num_drivers = int(params['num_drivers'])
bus_rental_cost = float(params['bus_rental_cost'])
minibus_rental_cost = float(params['minibus_rental_cost'])

# Create model
model = gp.Model("SchoolTrip")

# Decision variables
x = model.addVar(lb=0, ub=num_buses, vtype=GRB.INTEGER, name="buses")
y = model.addVar(lb=0, ub=num_minibuses, vtype=GRB.INTEGER, name="minibuses")

# Objective: minimize total rental cost
model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

# Constraints
# Must transport all students
model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, "StudentCapacity")

# Total vehicles (drivers) constraint
model.addConstr(x + y <= num_drivers, "DriverLimit")

# Safety constraint: at least two buses per minibus
model.addConstr(2 * y <= x, "SafetyConstraint")

# Minimum one minibus requirement
model.addConstr(y >= 1, "MinibusMinimum")

# Solve
model.setParam('OutputFlag', 0)
model.optimize()

# Output results
obj_val = model.objVal
print(f"Buses: {int(x.x)}")
print(f"Minibuses: {int(y.x)}")
print(f"FINAL_OBJ_VALUE: {obj_val}")
