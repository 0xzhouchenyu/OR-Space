import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    budget = params['company_budget']
    max_employees = int(params['max_employees'])
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_one_candidate_g_j = int(params['max_one_candidate_g_j'])
    lead_premium = params['lead_premium']
    min_leads = int(params['min_leads'])
    mentor_bonus = params['mentor_bonus']
    max_pairs = int(params['max_pairs'])
    
    # Create optimization model
    model = gp.Model("HiringOptimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: binary for each candidate
    x = {}
    for c in candidates:
        x[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{c['name']}")
    
    # Role assignment variables: binary for each candidate and role
    role_lead = {}
    role_engineer = {}
    for c in candidates:
        role_lead[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"role_lead_{c['name']}")
        role_engineer[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"role_engineer_{c['name']}")
    
    # Constraints: each candidate must be assigned exactly one role
    for c in candidates:
        model.addConstr(role_lead[c['name']] + role_engineer[c['name']] == 1, f"RoleAssignment_{c['name']}")
    
    # Constraint: at least min_leads must be assigned to Lead role
    model.addConstr(gp.quicksum(role_lead[c['name']] for c in candidates) >= min_leads, "MinLeads")
    
    # Constraint: at most one of G and J can be hired
    model.addConstr(x['G'] + x['J'] <= max_one_candidate_g_j, "MaxOneGJ")
    
    # Objective: minimize total net cost (salaries + lead premiums - mentor bonuses)
    total_salary = gp.quicksum(c['salary'] * x[c['name']] for c in candidates)
    total_lead_premium = gp.quicksum(c['salary'] * lead_premium * role_lead[c['name']] for c in candidates)
    total_mentor_bonus = gp.quicksum(mentor_bonus * role_lead[c['name']] * role_engineer[d['name']] for c in candidates for d in candidates if c['name'] != d['name'])
    
    model.setObjective(total_salary + total_lead_premium - total_mentor_bonus, GRB.MINIMIZE)
    
    # Budget constraint
    model.addConstr(total_salary <= budget, "Budget")
    
    # Max employees constraint
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, "MaxEmployees")
    
    # Min skill level constraint
    model.addConstr(gp.quicksum(c['skill'] * x[c['name']] for c in candidates) >= min_skill, "MinSkill")
    
    # Min project management experience constraint
    model.addConstr(gp.quicksum(c['pm_exp'] * x[c['name']] for c in candidates) >= min_pm_exp, "MinPMExp")
    
    # Mentorship pairs constraint: no more than max_pairs
    model.addConstr(gp.quicksum(role_lead[c['name']] * role_engineer[d['name']] for c in candidates for d in candidates if c['name'] != d['name']) <= max_pairs, "MaxPairs")
    
    # Solve
    model.optimize()
    
    # Print results
    print(f"Status: {model.Status}")
    for c in candidates:
        if x[c['name']].x > 0.5:
            role = "Lead" if role_lead[c['name']].x > 0.5 else "Engineer"
            print(f"Hire {c['name']}: Role={role}, Salary={c['salary']}, Skill={c['skill']}, PM_Exp={c['pm_exp']}")
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
