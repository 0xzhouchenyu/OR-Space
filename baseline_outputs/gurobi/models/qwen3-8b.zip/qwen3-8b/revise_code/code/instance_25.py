import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    W = params['initial_investment']       # 100000
    r1 = params['return_rate_option_1']    # 0.7
    r2 = params['return_rate_option_2']    # 2.0
    T = int(params['planning_horizon'])    # 3
    min_reserve_year1 = params['min_reserve_year1']  # 10000
    min_reserve_year2 = params['min_reserve_year2']  # 15000
    max_option2_start = params['max_option2_start']  # 30000
    option2_year0_late_settlement_rate = params['option2_year0_late_settlement_rate']  # 0.02
    
    model = gp.Model("Investment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x0_1 = model.addVar(name="x0_1", lb=0)
    x0_2 = model.addVar(name="x0_2", lb=0)
    x1_1 = model.addVar(name="x1_1", lb=0)
    x1_2 = model.addVar(name="x1_2", lb=0)
    x2_1 = model.addVar(name="x2_1", lb=0)
    
    # Year 0 budget constraint
    model.addConstr(x0_1 + x0_2 <= W, "year0_budget")
    
    # Year 1: money available = returns from x0_1
    model.addConstr(x1_1 + x1_2 <= x0_1 * (1 + r1), "year1_budget")
    
    # Year 2: money available = returns from x1_1 + returns from x0_2
    model.addConstr(x2_1 <= x1_1 * (1 + r1) + x0_2 * (1 + r2), "year2_budget")
    
    # Year 2 reserve constraint
    model.addConstr(x1_1 * (1 + r1) + x0_2 * (1 + r2) >= min_reserve_year2, "year2_reserve")
    
    # Year 1 reserve constraint
    model.addConstr(x0_1 * (1 + r1) >= min_reserve_year1, "year1_reserve")
    
    # Max amount allowed in two-year option at year 0
    model.addConstr(x0_2 <= max_option2_start, "max_option2_start_year0")
    
    # Late settlement adjustment for option 2 proceeds from year 0
    # These proceeds can only be used in year 3 and are reduced by the late settlement rate
    late_settlement_adj = x0_2 * (1 + r2) * option2_year0_late_settlement_rate
    adjusted_proceeds = x0_2 * (1 + r2) - late_settlement_adj
    
    # Total wealth at year 3 = proceeds from x2_1 (invested in option 1) + adjusted proceeds from x0_2 (invested in option 2)
    objective = x2_1 * (1 + r1) + adjusted_proceeds
    model.setObjective(objective, GRB.MAXIMIZE)
    
    model.optimize()
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
