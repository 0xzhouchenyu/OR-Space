import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
initial_capital = 0.0
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "initial_capital":
            initial_capital = float(row["Value"].strip())

# Load liquidity policy parameters
min_year3_reserve = 0.0
reserve_shortfall_penalty = 0.0
with open(os.path.join(data_dir, "liquidity_policy.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "min_year3_reserve":
            min_year3_reserve = float(row["Value"].strip())
        elif row["Parameter_Name"].strip() == "reserve_shortfall_penalty":
            reserve_shortfall_penalty = float(row["Value"].strip())

# Load project data
projects = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        projects.append(row)

# Create model
model = gp.Model("Investment_Maximization")

# Decision variables
x1_1 = model.addVar(lb=0, name="x1_1")
x1_2 = model.addVar(lb=0, name="x1_2")
x1_3 = model.addVar(lb=0, name="x1_3")
x2 = model.addVar(lb=0, ub=float(projects[1]["Investment_Capacity"]), name="x2")
x3 = model.addVar(lb=0, ub=float(projects[2]["Investment_Capacity"]), name="x3")
x4 = model.addVar(lb=0, ub=float(projects[3]["Investment_Capacity"]), name="x4")

# Year 1 budget constraint: x1_1 + x2 <= initial_capital
model.addConstr(x1_1 + x2 <= initial_capital, "Year1_Budget")

# Year 2 budget constraint: x1_2 + x3 <= x1_1 * 1.20
model.addConstr(x1_2 + x3 <= x1_1 * 1.20, "Year2_Budget")

# Year 3 budget constraint: x1_3 + x4 <= x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60
model.addConstr(x1_3 + x4 <= x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60, "Year3_Budget")

# Calculate cash at beginning of Year 3
cash_year3 = x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60

# Reserve constraint: cash_year3 >= min_year3_reserve
model.addConstr(cash_year3 >= min_year3_reserve, "Min_Year3_Reserve")

# Objective: total money at end of Year 3 + penalty for reserve shortfall
total_end_year3 = x1_3 * 1.20 + x4 * 1.40
penalty = max(0, (min_year3_reserve - cash_year3) * reserve_shortfall_penalty)
model.setObjective(total_end_year3 - penalty, GRB.MAXIMIZE)

# Solve the model
model.setParam("OutputFlag", 0)
model.optimize()

# Print results
print(f"Status: {model.Status}")
for v in model.getVars():
    print(f"{v.VarName} = {v.X}")

# Output final objective value
FINAL_OBJ_VALUE: {model.ObjVal}
