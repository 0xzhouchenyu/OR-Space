import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    # Read CSVs
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    # Parse Table 1
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]
    
    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    insp_a = float(row_a['Inspection_hours_per_unit'])
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])
    
    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    insp_b = float(row_b['Inspection_hours_per_unit'])
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])
    
    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp = float(row_cap['Inspection_hours_per_unit'])
    
    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])
    cost_asm = float(row_cost['Assembly_hours_per_unit'])
    cost_insp = float(row_cost['Inspection_hours_per_unit'])
    
    # Parse Parameters
    min_profit = float(df_params[df_params['Parameter_Name'] == 'min_weekly_profit']['Value'].iloc[0])
    min_a = float(df_params[df_params['Parameter_Name'] == 'min_type_a_production']['Value'].iloc[0])
    planning_horizon = int(df_params[df_params['Parameter_Name'] == 'planning_horizon_weeks']['Value'].iloc[0])
    idle_tolerance = float(df_params[df_params['Parameter_Name'] == 'idle_tolerance']['Value'].iloc[0])
    
    # Inspection parameters
    insp_a_M = float(df_params[df_params['Parameter_Name'] == 'insp_a_M']['Value'].iloc[0])
    insp_b_M = float(df_params[df_params['Parameter_Name'] == 'insp_b_M']['Value'].iloc[0])
    insp_a_E = float(df_params[df_params['Parameter_Name'] == 'insp_a_E']['Value'].iloc[0])
    insp_b_E = float(df_params[df_params['Parameter_Name'] == 'insp_b_E']['Value'].iloc[0])
    cap_ext = float(df_params[df_params['Parameter_Name'] == 'cap_ext']['Value'].iloc[0])
    cost_insp_M = float(df_params[df_params['Parameter_Name'] == 'cost_insp_M']['Value'].iloc[0])
    cost_insp_E = float(df_params[df_params['Parameter_Name'] == 'cost_insp_E']['Value'].iloc[0])
    cost_ext = float(df_params[df_params['Parameter_Name'] == 'cost_ext']['Value'].iloc[0])
    mode_fee_M = float(df_params[df_params['Parameter_Name'] == 'mode_fee_M']['Value'].iloc[0])
    mode_fee_E = float(df_params[df_params['Parameter_Name'] == 'mode_fee_E']['Value'].iloc[0])
    risk_penalty_M = float(df_params[df_params['Parameter_Name'] == 'risk_penalty_M']['Value'].iloc[0])
    cost_insp_weight = float(df_params[df_params['Parameter_Name'] == 'cost_insp_weight']['Value'].iloc[0])
    
    # Calculate Unit Profits
    cost_a = mfg_a * cost_mfg + asm_a * cost_asm + insp_a * cost_insp
    profit_a = price_a - cost_a
    
    cost_b = mfg_b * cost_mfg + asm_b * cost_asm + insp_b * cost_insp
    profit_b = price_b - cost_b
    
    # Create model
    model = gp.Model("Motorcycle_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_A = model.addVars(planning_horizon, lb=min_a, vtype=GRB.INTEGER, name='x_A')
    x_B = model.addVars(planning_horizon, lb=0, vtype=GRB.INTEGER, name='x_B')
    mode = model.addVars(planning_horizon, vtype=GRB.BINARY, name='mode')  # 0 for Manual, 1 for Enhanced
    
    # Constraints
    for t in range(planning_horizon):
        # Capacity constraints
        model.addConstr(mfg_a * x_A[t] + mfg_b * x_B[t] <= cap_mfg, f'CapMfg_{t}')
        model.addConstr(asm_a * x_A[t] + asm_b * x_B[t] <= cap_asm, f'CapAsm_{t}')
        
        # Inspection hours and costs
        if mode[t] == 0:
            insp_a_t = insp_a_M
            insp_b_t = insp_b_M
            cost_insp_t = cost_insp_M
        else:
            insp_a_t = insp_a_E
            insp_b_t = insp_b_E
            cost_insp_t = cost_insp_E
        
        model.addConstr(insp_a_t * x_A[t] + insp_b_t * x_B[t] <= cap_insp, f'CapInsp_{t}')
        
        # Mode fee and risk penalty
        model.addConstr(mode[t] * mode_fee_E + (1 - mode[t]) * mode_fee_M, f'ModeFee_{t}')
        model.addConstr(mode[t] * risk_penalty_M, f'RiskPenalty_{t}')
        
        # Profit constraint
        model.addConstr(profit_a * x_A[t] + profit_b * x_B[t] >= min_profit, f'Profit_{t}')
    
    # Objective: Minimize idle time weighted by cost and inspection risk
    idle_time = 0
    for t in range(planning_horizon):
        # Idle time for manufacturing
        idle_mfg = cap_mfg - (mfg_a * x_A[t] + mfg_b * x_B[t])
        idle_time += cost_mfg * idle_mfg
        
        # Idle time for assembly
        idle_asm = cap_asm - (asm_a * x_A[t] + asm_b * x_B[t])
        idle_time += cost_asm * idle_asm
        
        # Idle time for inspection (only if Enhanced mode is used)
        if mode[t] == 1:
            idle_insp = cap_insp - (insp_a_t * x_A[t] + insp_b_t * x_B[t])
            idle_time += cost_insp_weight * idle_insp
    
    model.setObjective(idle_time, GRB.MINIMIZE)
    
    # Solve the first stage
    model.optimize()
    
    # Extract the minimum idle time from the first stage
    min_idle_val = model.objVal
    
    # Second stage: Maximize two-week profit under the same idle time constraint
    model.setObjective(profit_a * x_A[0] + profit_b * x_B[0] + profit_a * x_A[1] + profit_b * x_B[1], GRB.MAXIMIZE)
    
    # Add constraint to enforce minimal idle time
    model.addConstr(idle_time <= min_idle_val + idle_tolerance, 'IdleConstraint')
    
    model.optimize()
    
    final_obj = model.objVal
    print(f"FINAL_OBJ_VALUE: {round(final_obj, 4)}")

if __name__ == '__main__':
    solve()
