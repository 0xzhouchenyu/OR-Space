import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    data = {}
    
    # Load general parameters
    filepath = os.path.join(base_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            data['general'][row[0]] = float(row[1])
    
    # Load table_1_7.csv
    filepath = os.path.join(base_dir, 'table_1_7.csv')
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if row[0] == 'Processing Fee (Yuan/kg)':
                data['processing_fee'] = [float(row[1]), float(row[2]), float(row[3])]
            elif row[0] == 'Selling Price (Yuan/kg)':
                data['selling_price'] = [float(row[1]), float(row[2]), float(row[3])]
            else:
                data['raw_materials'].append(row)
    
    return data

def main():
    data = load_data()
    
    # Extract parameters
    setup_cost = data['general']
    brand_ab_shared_wrapper_fee = setup_cost['BrandAB_SharedWrapper_Fee']
    
    raw_materials = data['raw_materials']
    processing_fee = data['processing_fee']
    selling_price = data['selling_price']
    
    # Raw material cost and monthly limit
    raw_cost = []
    limits = []
    for row in raw_materials:
        if row[0] == 'A':
            raw_cost.append(float(row[4]))
            limits.append(float(row[5]))
        elif row[0] == 'B':
            raw_cost.append(float(row[4]))
            limits.append(float(row[5]))
        elif row[0] == 'C':
            raw_cost.append(float(row[4]))
            limits.append(float(row[5]))
    
    # Initialize model
    model = gp.Model("CandyFactory")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i][j] = kg of raw material i used in brand j
    # Raw materials: 0=A, 1=B, 2=C
    # Brands: 0=A, 1=B, 2=C
    x = model.addVars(3, 3, lb=0, name="x")
    
    # Binary variables to indicate production of each brand
    y = model.addVars(3, vtype=GRB.BINARY, name="y")
    
    # Total production of each brand
    total_production = [model.sum(x[i, j] for i in range(3)) for j in range(3)]
    
    # Objective: maximize profit
    revenue = model.sum(selling_price[j] * total_production[j] for j in range(3))
    material_cost = model.sum(raw_cost[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = model.sum(processing_fee[j] * total_production[j] for j in range(3))
    setup_cost_total = model.sum(setup_cost[f"SetupCost_{chr(65 + j)}"] * y[j] for j in range(3))
    
    model.setObjective(revenue - material_cost - processing_cost - setup_cost_total, GRB.MAXIMIZE)
    
    # Raw material supply constraints
    for i in range(3):
        model.addConstr(model.sum(x[i, j] for j in range(3)) <= limits[i])
    
    # Composition constraints (percentage constraints)
    # Raw material A (i=0): >=60% in brand A (j=0), >=15% in brand B (j=1)
    model.addConstr(x[0, 0] >= 0.60 * total_production[0])  # RM A >= 60% of Brand A
    model.addConstr(x[0, 1] >= 0.15 * total_production[1])  # RM A >= 15% of Brand B
    
    # Raw material C (i=2): <=20% in brand A (j=0), <=60% in brand B (j=1), <=50% in brand C (j=2)
    model.addConstr(x[2, 0] <= 0.20 * total_production[0])  # RM C <= 20% of Brand A
    model.addConstr(x[2, 1] <= 0.60 * total_production[1])  # RM C <= 60% of Brand B
    model.addConstr(x[2, 2] <= 0.50 * total_production[2])  # RM C <= 50% of Brand C
    
    # Shared wrapper coordination fee constraint
    shared_wrapper = model.addVar(vtype=GRB.BINARY, name="shared_wrapper")
    model.addConstr(shared_wrapper >= y[0] + y[1] - 1)
    model.addConstr(shared_wrapper <= y[0])
    model.addConstr(shared_wrapper <= y[1])
    model.addConstr(model.sum(brand_ab_shared_wrapper_fee * shared_wrapper), GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Print results
    print(f"Status: {model.Status}")
    for j in range(3):
        print(f"Brand {chr(65 + j)} production: {total_production[j].X:.2f} kg")
    for i in range(3):
        for j in range(3):
            if x[i, j].X > 0.01:
                print(f"  RM {chr(65 + i)} in Brand {chr(65 + j)}: {x[i, j].X:.2f}")
    
    obj = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj:.1f}")

if __name__ == "__main__":
    main()
