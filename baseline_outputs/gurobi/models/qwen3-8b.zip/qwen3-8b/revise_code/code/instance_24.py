import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    product_units = params["product_units"]
    truck_pollution = params["truck_pollution"]
    van_pollution = params["van_pollution"]
    motorcycle_pollution = params["motorcycle_pollution"]
    ev_pollution = params["electric_vehicle_pollution"]
    max_total_pollution = params["max_total_pollution"]
    min_truck_trips = params["min_truck_trips"]
    truck_capacity = params["truck_capacity"]
    van_capacity = params["van_capacity"]
    motorcycle_capacity = params["motorcycle_capacity"]
    ev_capacity = params["electric_vehicle_capacity"]
    sales_point_share_sp1 = params["sales_point_share_sp1"]
    sales_point_share_sp2 = params["sales_point_share_sp2"]
    sales_point_share_sp3 = params["sales_point_share_sp3"]
    min_truck_share_sp1 = params["min_truck_share_sp1"]
    min_truck_share_sp2 = params["min_truck_share_sp2"]
    min_truck_share_sp3 = params["min_truck_share_sp3"]
    M_truck_sp_day = params["M_truck_sp_day"]
    M_ev_sp_day = params["M_ev_sp_day"]
    M_van_sp_day = params["M_van_sp_day"]
    M_moto_sp_day = params["M_moto_sp_day"]
    
    # Calculate demand per sales point
    demand_sp1 = product_units * sales_point_share_sp1
    demand_sp2 = product_units * sales_point_share_sp2
    demand_sp3 = product_units * sales_point_share_sp3
    
    model = gp.Model("Transportation_Pollution_Minimization")
    model.setParam("OutputFlag", 0)
    
    # Decision variables: trips for each vehicle type per sales point and day
    truck_trips = {}
    van_trips = {}
    moto_trips = {}
    ev_trips = {}
    
    for sp in range(1, 4):
        for day in range(1, 4):
            truck_trips[(sp, day)] = model.addVar(vtype=GRB.INTEGER, name=f"truck_trips_{sp}_{day}")
            van_trips[(sp, day)] = model.addVar(vtype=GRB.INTEGER, name=f"van_trips_{sp}_{day}")
            moto_trips[(sp, day)] = model.addVar(vtype=GRB.INTEGER, name=f"moto_trips_{sp}_{day}")
            ev_trips[(sp, day)] = model.addVar(vtype=GRB.INTEGER, name=f"ev_trips_{sp}_{day}")
    
    # Total trips for each vehicle type across all sales points and days
    total_truck_trips = model.addVar(vtype=GRB.INTEGER, name="total_truck_trips")
    total_van_trips = model.addVar(vtype=GRB.INTEGER, name="total_van_trips")
    total_moto_trips = model.addVar(vtype=GRB.INTEGER, name="total_moto_trips")
    total_ev_trips = model.addVar(vtype=GRB.INTEGER, name="total_ev_trips")
    
    # Constraints: total trips per vehicle type
    for sp in range(1, 4):
        for day in range(1, 4):
            model.addConstr(total_truck_trips == sum(truck_trips[(sp, day)] for sp in range(1, 4) for day in range(1, 4)))
            model.addConstr(total_van_trips == sum(van_trips[(sp, day)] for sp in range(1, 4) for day in range(1, 4)))
            model.addConstr(total_moto_trips == sum(moto_trips[(sp, day)] for sp in range(1, 4) for day in range(1, 4)))
            model.addConstr(total_ev_trips == sum(ev_trips[(sp, day)] for sp in range(1, 4) for day in range(1, 4)))
    
    # Constraint: total pollution must not exceed maximum
    model.addConstr(
        truck_pollution * total_truck_trips + 
        van_pollution * total_van_trips + 
        motorcycle_pollution * total_moto_trips + 
        ev_pollution * total_ev_trips <= max_total_pollution
    )
    
    # Constraint: minimum truck trips
    model.addConstr(total_truck_trips >= min_truck_trips)
    
    # Demand constraints for each sales point
    for sp in range(1, 4):
        for day in range(1, 4):
            # Truck and EV can be used on the same day
            model.addConstr(
                truck_capacity * truck_trips[(sp, day)] + 
                ev_capacity * ev_trips[(sp, day)] >= demand_sp1 if sp == 1 else (demand_sp2 if sp == 2 else demand_sp3)
            )
            
            # Van and Motorcycle can be used on the same day
            model.addConstr(
                van_capacity * van_trips[(sp, day)] + 
                motorcycle_capacity * moto_trips[(sp, day)] >= demand_sp1 if sp == 1 else (demand_sp2 if sp == 2 else demand_sp3)
            )
    
    # Minimum truck share constraints for each sales point
    for sp in range(1, 4):
        total_trips_sp = model.addVar(vtype=GRB.INTEGER, name=f"total_trips_sp{sp}")
        model.addConstr(total_trips_sp == sum([
            truck_trips[(sp, day)] + ev_trips[(sp, day)] for day in range(1, 4)
        ]) + sum([
            van_trips[(sp, day)] + moto_trips[(sp, day)] for day in range(1, 4)
        ]))
        
        min_truck_share = min_truck_share_sp1 if sp == 1 else (min_truck_share_sp2 if sp == 2 else min_truck_share_sp3)
        model.addConstr(
            truck_trips[(sp, 1)] + truck_trips[(sp, 2)] + truck_trips[(sp, 3)] + ev_trips[(sp, 1)] + ev_trips[(sp, 2)] + ev_trips[(sp, 3)] >= 
            min_truck_share * total_trips_sp
        )
    
    # Big-M constraints to enforce exclusive use of vehicle families
    for sp in range(1, 4):
        for day in range(1, 4):
            # Truck and EV cannot be used together
            model.addConstr(
                truck_trips[(sp, day)] + ev_trips[(sp, day)] <= M_truck_sp_day * (truck_trips[(sp, day)] + ev_trips[(sp, day)] > 0)
            )
            model.addConstr(
                van_trips[(sp, day)] + moto_trips[(sp, day)] <= M_van_sp_day * (van_trips[(sp, day)] + moto_trips[(sp, day)] > 0)
            )
    
    # Objective: minimize total pollution
    model.setObjective(
        truck_pollution * total_truck_trips + 
        van_pollution * total_van_trips + 
        motorcycle_pollution * total_moto_trips + 
        ev_pollution * total_ev_trips,
        GRB.MINIMIZE
    )
    
    # Solve the model
    model.optimize()
    
    # Print solution details
    print(f"Status: {model.Status}")
    print(f"Total truck trips: {total_truck_trips.X}")
    print(f"Total van trips: {total_van_trips.X}")
    print(f"Total motorcycle trips: {total_moto_trips.X}")
    print(f"Total EV trips: {total_ev_trips.X}")
    print(f"Total capacity delivered: {total_truck_trips.X * truck_capacity + total_van_trips.X * van_capacity + total_moto_trips.X * motorcycle_capacity + total_ev_trips.X * ev_capacity}")
    print(f"OBJECTIVE_VALUE: {model.objVal}")
    
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
