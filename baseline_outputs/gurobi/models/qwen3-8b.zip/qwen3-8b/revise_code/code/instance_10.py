import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_coverage_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)  # skip header
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    
    return areas, coverage

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load data
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    distance_limit = params.get('distance_limit', 800)
    small_cost = params.get('small_cost', 1)
    large_cost = params.get('large_cost', 2)
    small_cap_areas = params.get('small_cap_areas', 3)
    max_large_stores = params.get('max_large_stores', 1)
    minimum_neighborhood_counters = params.get('minimum_neighborhood_counters', 6)
    small_store_counter_credit = params.get('small_store_counter_credit', 1)
    
    # Set up model
    model = gp.Model("MinChainStores")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    small_stores = {area: model.addVar(vtype=GRB.BINARY, name=f"Small_{area}") for area in areas}
    large_stores = {area: model.addVar(vtype=GRB.BINARY, name=f"Large_{area}") for area in areas}
    
    # Objective: minimize total cost
    obj = 0
    for area in areas:
        obj += small_cost * small_stores[area] + large_cost * large_stores[area]
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    # 1. Each residential area must be covered by at least one store
    for area in areas:
        covered_by_small = sum(small_stores[j] for j in areas if area in coverage[j])
        covered_by_large = sum(large_stores[j] for j in areas if area in coverage[j])
        model.addConstr(covered_by_small + covered_by_large >= 1, f"Cover_{area}")
    
    # 2. Maximum number of Large-format stores allowed
    model.addConstr(sum(large_stores[area] for area in areas) <= max_large_stores, "MaxLargeStores")
    
    # 3. Minimum number of Small-format stores (neighborhood counters)
    model.addConstr(sum(small_stores[area] for area in areas) >= minimum_neighborhood_counters, "MinSmallStores")
    
    # 4. Each Small-format store can serve at most small_cap_areas residential areas
    for area in areas:
        served_areas = sum(small_stores[j] * len(coverage[j]) for j in areas if area in coverage[j])
        model.addConstr(served_areas <= small_cap_areas * small_stores[area], f"SmallCap_{area}")
    
    # Solve
    model.optimize()
    
    # Print results
    print(f"\nStatus: {model.Status}")
    print(f"Optimal objective value: {model.ObjVal}")
    
    # Output selected areas
    selected_small = [area for area in areas if small_stores[area].X > 1e-6]
    selected_large = [area for area in areas if large_stores[area].X > 1e-6]
    print(f"Selected Small Stores: {selected_small}")
    print(f"Selected Large Stores: {selected_large}")
    
    # Verify coverage
    covered_total = set()
    for area in selected_small:
        covered_total |= coverage[area]
    for area in selected_large:
        covered_total |= coverage[area]
    print(f"All areas covered: {set(areas).issubset(covered_total)}")
    print(f"Covered areas: {sorted(covered_total)}")
    
    print(f"\nFINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
