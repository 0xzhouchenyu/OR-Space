import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, '..', 'data')
    
    # Read general parameters
    general_params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row['Parameter_Name']] = float(row['Value'])
    
    # Read table_1.csv
    workshops = []
    capacities = {}
    rates = {}  # rates[(workshop, component)] = production rate
    
    filepath = os.path.join(data_dir, 'table_1.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    components = [1, 2, 3]
    
    # Initialize model
    model = gp.Model("Maximize_Completed_Products")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: hours each workshop allocates to each component
    x = {}
    for w in workshops:
        for c in components:
            x[(w, c)] = model.addVar(lb=0, name=f"x_{w}_{c}")
    
    # Binary variables for shift activity
    y = {}
    for w in workshops:
        y[w] = model.addVar(vtype=GRB.BINARY, name=f"y_{w}")
    
    # Continuous variable for total completed products
    z = model.addVar(lb=0, name="z")
    
    # Objective: maximize z (total completed products) while minimizing penalties
    # Penalty for night work (regular time only)
    penalty_night_hour = general_params['penalty_night_hour']
    # Penalty for overtime
    penalty_overtime_hour = general_params['penalty_overtime_hour']
    # Penalty for shortage per unit
    penalty_shortage_per_unit = general_params['penalty_shortage_per_unit']
    # Target number of completed products
    z_target = general_params['z_target']
    
    # Calculate total units produced for each component
    total_component_1 = sum(rates[(w, 1)] * x[(w, 1)] for w in workshops)
    total_component_2 = sum(rates[(w, 2)] * x[(w, 2)] for w in workshops)
    total_component_3 = sum(rates[(w, 3)] * x[(w, 3)] for w in workshops)
    
    # Total completed products is the minimum of the three components
    model.addConstr(z <= total_component_1)
    model.addConstr(z <= total_component_2)
    model.addConstr(z <= total_component_3)
    
    # Constraints for regular and overtime hours per shift
    for w in workshops:
        # Regular day hours
        reg_day_hours = model.addVar(lb=0, name=f"reg_day_hours_{w}")
        model.addConstr(reg_day_hours <= general_params[f'regular_hours_limit_day_{w}'])
        # Overtime day hours
        over_day_hours = model.addVar(lb=0, name=f"over_day_hours_{w}")
        model.addConstr(over_day_hours <= general_params[f'overtime_capacity_day_{w}'])
        # Regular night hours
        reg_night_hours = model.addVar(lb=0, name=f"reg_night_hours_{w}")
        model.addConstr(reg_night_hours <= general_params[f'regular_hours_limit_night_{w}'])
        # Overtime night hours
        over_night_hours = model.addVar(lb=0, name=f"over_night_hours_{w}")
        model.addConstr(over_night_hours <= general_params[f'overtime_capacity_night_{w}'])
        
        # Link regular and overtime hours to shift activity
        model.addConstr(reg_day_hours + over_day_hours <= general_params[f'regular_hours_limit_day_{w}'] + general_params[f'overtime_capacity_day_{w}'] * y[w])
        model.addConstr(reg_night_hours + over_night_hours <= general_params[f'regular_hours_limit_night_{w}'] + general_params[f'overtime_capacity_night_{w}'] * y[w])
        
        # Link hours to activity indicator using big-M
        model.addConstr(reg_day_hours <= general_params[f'bigM_shift_{w}'] * y[w])
        model.addConstr(over_day_hours <= general_params[f'bigM_shift_{w}'] * y[w])
        model.addConstr(reg_night_hours <= general_params[f'bigM_shift_{w}'] * y[w])
        model.addConstr(over_night_hours <= general_params[f'bigM_shift_{w}'] * y[w])
        
        # Total hours per workshop
        total_hours = reg_day_hours + over_day_hours + reg_night_hours + over_night_hours
        model.addConstr(total_hours <= capacities[w])
    
    # Constraint on maximum two workshops active in the same shift
    # Create binary variables for day and night shifts
    day_shift_active = model.addVar(vtype=GRB.INTEGER, name="day_shift_active")
    night_shift_active = model.addVar(vtype=GRB.INTEGER, name="night_shift_active")
    
    model.addConstr(day_shift_active <= 2)
    model.addConstr(night_shift_active <= 2)
    
    # Link day shift activity to workshop activity
    for w in workshops:
        model.addConstr(day_shift_active >= y[w])
        model.addConstr(night_shift_active >= y[w])
    
    # Penalty for night work (regular time only)
    model.addConstr(z <= total_component_1)
    model.addConstr(z <= total_component_2)
    model.addConstr(z <= total_component_3)
    
    # Penalty for night work
    night_work_penalty = penalty_night_hour * (reg_night_hours)
    model.addConstr(model.setObjective(z - night_work_penalty - penalty_overtime_hour * (over_day_hours + over_night_hours) - penalty_shortage_per_unit * (z_target - z), GRB.MAXIMIZE))
    
    # Solve the model
    model.optimize()
    
    # Print solution details
    print(f"Status: {model.Status}")
    for w in workshops:
        for c in components:
            val = x[(w, c)].x
            if val > 1e-6:
                print(f"Workshop {w}, Component {c}: {val:.2f} hours -> {rates[(w,c)] * val:.2f} units")
    
    for c in components:
        total = sum(rates[(w, c)] * x[(w, c)].x for w in workshops)
        print(f"Total Component {c}: {total:.2f} units")
    
    obj_val = model.objVal
    print(f"\nFINAL_OBJ_VALUE: {obj_val:.1f}")

if __name__ == "__main__":
    main()
