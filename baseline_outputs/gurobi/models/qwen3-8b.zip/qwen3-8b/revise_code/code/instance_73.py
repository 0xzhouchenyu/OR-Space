import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children_per_day = int(params['max_children_trip'])
    min_children_per_day = int(params['min_children_trip'])
    max_distinct_children = int(params['max_distinct_children_trip'])
    total_cost_budget = int(params['total_cost_budget'])
    bonus_saving = int(params['bonus_saving'])
    min_bob_days = int(params['min_bob_days'])
    
    # Read table_1 for children and costs
    children = []
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Child'].strip()
            cost = int(row['Cost'].strip())
            children.append(name)
            costs[name] = cost
    
    # Create the optimization model
    model = gp.Model("FamilyTripTwoDays")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: binary for each child on day 1 and day 2
    x1 = {child: model.addVar(vtype=GRB.BINARY, name=f"x1_{child}") for child in children}
    x2 = {child: model.addVar(vtype=GRB.BINARY, name=f"x2_{child}") for child in children}
    
    # Binary variable to indicate if a child is present on both days
    b = {child: model.addVar(vtype=GRB.BINARY, name=f"b_{child}") for child in children}
    
    # Objective: minimize total two-day cost minus total bonus saving
    total_cost = 0
    for child in children:
        total_cost += costs[child] * (x1[child] + x2[child])
    total_bonus = gp.quicksum(b[child] * bonus_saving for child in children)
    model.setObjective(total_cost - total_bonus, GRB.MINIMIZE)
    
    # Constraint: daily min and max children
    for day in [1, 2]:
        if day == 1:
            day_vars = x1
        else:
            day_vars = x2
        model.addConstr(gp.quicksum(day_vars[child] for child in children) >= min_children_per_day, f"MinChildrenDay{day}")
        model.addConstr(gp.quicksum(day_vars[child] for child in children) <= max_children_per_day, f"MaxChildrenDay{day}")
    
    # Constraint: max distinct children over both days
    model.addConstr(gp.quicksum(x1[child] + x2[child] for child in children) <= max_distinct_children * 2, "MaxDistinctChildren")
    
    # Constraint: Bob must attend at least min_bob_days
    model.addConstr(gp.quicksum(x1['Bob'] + x2['Bob']) >= min_bob_days, "MinBobDays")
    
    # Constraint: Alice can only be on day 1
    model.addConstr(x2['Alice'] == 0, "AliceOnlyDay1")
    
    # Constraint: Charlie and Diana can only be on day 2
    model.addConstr(x1['Charlie'] == 0, "CharlieOnlyDay2")
    model.addConstr(x1['Diana'] == 0, "DianaOnlyDay2")
    
    # Constraint: Alice and Diana cannot be on the same day
    model.addConstr(x1['Alice'] + x1['Diana'] <= 1, "AliceDianaConflictDay1")
    model.addConstr(x2['Alice'] + x2['Diana'] <= 1, "AliceDianaConflictDay2")
    
    # Constraint: Bob and Charlie cannot be on the same day
    model.addConstr(x1['Bob'] + x1['Charlie'] <= 1, "BobCharlieConflictDay1")
    model.addConstr(x2['Bob'] + x2['Charlie'] <= 1, "BobCharlieConflictDay2")
    
    # Constraint: Charlie must be accompanied by Diana on the same day
    model.addConstr(x1['Charlie'] <= x1['Diana'], "CharlieRequiresDianaDay1")
    model.addConstr(x2['Charlie'] <= x2['Diana'], "CharlieRequiresDianaDay2")
    
    # Constraint: Diana must be accompanied by Ella on the same day
    model.addConstr(x1['Diana'] <= x1['Ella'], "DianaRequiresEllaDay1")
    model.addConstr(x2['Diana'] <= x2['Ella'], "DianaRequiresEllaDay2")
    
    # Constraint: b[child] = 1 only if child is present on both days
    for child in children:
        model.addConstr(b[child] <= x1[child], f"b_{child}_1")
        model.addConstr(b[child] <= x2[child], f"b_{child}_2")
    
    # Solve
    model.optimize()
    
    # Print solution details
    print(f"Status: {model.Status}")
    for child in children:
        if x1[child].X > 0.5:
            print(f"  Day 1: {child}: taken (cost={costs[child]})")
        if x2[child].X > 0.5:
            print(f"  Day 2: {child}: taken (cost={costs[child]})")
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
