import gurobipy as gp
from gurobipy import GRB
import os
import sys
from itertools import product

# Add parent directory to path if needed
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utils import load_general_parameters, load_reliability_table

def solve():
    # Load data
    params = load_general_parameters()
    reliability = load_reliability_table()
    
    # Extract parameters
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    total_budget_A = params['total_budget_scenario_A']
    total_budget_B = params['total_budget_scenario_B']
    weight_limit_A = params['weight_limit_scenario_A']
    weight_limit_B = params['weight_limit_scenario_B']
    
    # Get max number of spares
    max_spares = max(reliability.keys())
    
    # Create model
    model = gp.Model("reliability_optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: s1, s2, s3 (number of spares for each component)
    s1 = model.addVar(vtype=GRB.INTEGER, name="s1", lb=0, ub=max_spares)
    s2 = model.addVar(vtype=GRB.INTEGER, name="s2", lb=0, ub=max_spares)
    s3 = model.addVar(vtype=GRB.INTEGER, name="s3", lb=0, ub=max_spares)
    
    # Cost constraints
    cost_A = s1 * unit_price[0] + s2 * unit_price[1] + s3 * unit_price[2]
    cost_B = cost_A  # Same cost for both scenarios
    model.addConstr(cost_A <= total_budget_A, "Budget_A")
    model.addConstr(cost_B <= total_budget_B, "Budget_B")
    
    # Weight constraints
    weight_A = s1 * unit_weight[0] + s2 * unit_weight[1] + s3 * unit_weight[2]
    weight_B = weight_A  # Same weight for both scenarios
    model.addConstr(weight_A <= weight_limit_A, "Weight_A")
    model.addConstr(weight_B <= weight_limit_B, "Weight_B")
    
    # Objective: Expected reliability = 0.5 * (SysRel_A + SysRel_B) = 0.5 * (R1*s1 * R2*s2 * R3*s3 + R1*s1 * R2*s2 * R3*s3) = R1*s1 * R2*s2 * R3*s3
    # Since SysRel_A = SysRel_B for fixed s1, s2, s3
    r1 = reliability[s1][0]
    r2 = reliability[s2][1]
    r3 = reliability[s3][2]
    expected_reliability = r1 * r2 * r3
    
    # Set objective
    model.setObjective(expected_reliability, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    # Print result
    print(f"Optimal spare parts allocation: Component 1: {s1.x}, Component 2: {s2.x}, Component 3: {s3.x}")
    print(f"Total cost: {s1.x * unit_price[0] + s2.x * unit_price[1] + s3.x * unit_price[2]}")
    print(f"Total weight: {s1.x * unit_weight[0] + s2.x * unit_weight[1] + s3.x * unit_weight[2]}")
    
    r1_val = reliability[int(s1.x)][0]
    r2_val = reliability[int(s2.x)][1]
    r3_val = reliability[int(s3.x)][2]
    print(f"Component reliabilities: {r1_val}, {r2_val}, {r3_val}")
    print(f"OBJECTIVE_VALUE: {expected_reliability}")
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {expected_reliability}")

if __name__ == '__main__':
    solve()
