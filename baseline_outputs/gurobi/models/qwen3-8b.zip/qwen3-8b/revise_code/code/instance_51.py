import os
import csv
from gurobipy import GRB, Model

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load data
def load_demand(filepath):
    """Load nurse demand per time period from CSV."""
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand

def load_parameters(filepath):
    """Load general parameters from CSV."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    return params

demand = load_demand(os.path.join(data_dir, 'table_1.csv'))
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

shift_start_times = params['shift_start_times'].split(';')
shift_duration = int(params['shift_duration'])
regular_pay = float(params['regular_nurse_pay'])
contract_pay = float(params['contract_nurse_pay'])
outsourced_regular_start_index = int(params['outsourced_regular_start_index'])
banned_contract_start_index = int(params['banned_contract_start_index'])
max_total_contract_starts = int(params['max_total_contract_starts'])
min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])
daytime_period_indices = list(map(int, params['daytime_period_indices'].split(';')))

num_periods = len(demand)
periods_per_shift = shift_duration // 4  # Each shift covers 2 periods

# Create model
model = Model("NurseScheduling")

# Decision variables: regular and contract nurses starting at each shift
x = [model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{j}") for j in range(num_periods)]
y = [model.addVar(lb=0, vtype=GRB.INTEGER, name=f"y_{j}") for j in range(num_periods)]

# Objective: minimize total cost
total_cost = 0
for j in range(num_periods):
    total_cost += (regular_pay * shift_duration) * x[j] + (contract_pay * shift_duration) * y[j]
model.setObjective(total_cost, GRB.MINIMIZE)

# Coverage constraints: for each time period i, sum of nurses from shifts that cover period i >= demand[i]
for i in range(num_periods):
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(sum(x[j] + y[j] for j in covering_shifts) >= demand[i], f"Demand_period_{i}")

# Contract nurses cannot start the overnight 22:00 shift
model.addConstr(y[banned_contract_start_index] == 0, "Banned_contract_start")

# Daytime period coverage constraint: minimum regular nurses required
for i in daytime_period_indices:
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(sum(x[j] for j in covering_shifts) >= min_regular_daytime_coverage, f"Min_regular_daytime_{i}")

# Total contract starts capped
model.addConstr(sum(y[j] for j in range(num_periods)) <= max_total_contract_starts, "Max_total_contract_starts")

# Set solver parameters
model.setParam('OutputFlag', 0)

# Solve model
model.optimize()

# Print solution details
for j in range(num_periods):
    print(f"Shift {j}: Regular={int(x[j].x)}, Contract={int(y[j].x)}")

print(f"FINAL_OBJ_VALUE: {model.objVal}")
