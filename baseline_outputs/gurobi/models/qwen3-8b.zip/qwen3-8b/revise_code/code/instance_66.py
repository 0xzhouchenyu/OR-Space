import os
import csv
from gurobipy import Model, GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read table_1.csv
toys = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            'type': row['Toy_Type'],
            'labor': float(row['Manufacturing_Labor_Hours']),
            'inspection': float(row['Inspection_Hours']),
            'profit': float(row['Profit_Per_Unit'])
        })

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Extract parameters
available_labor_period1 = params['available_labor_hours_period1']
available_labor_period2 = params['available_labor_hours_period2']
available_inspection_period1 = params['available_inspection_hours_period1']
available_inspection_period2 = params['available_inspection_hours_period2']

max_demand_high_end_period1 = params['max_demand_high_end_period1']
max_demand_mid_range_period1 = params['max_demand_mid_range_period1']
max_demand_low_end_period1 = params['max_demand_low_end_period1']

max_demand_high_end_period2 = params['max_demand_high_end_period2']
max_demand_mid_range_period2 = params['max_demand_mid_range_period2']
max_demand_low_end_period2 = params['max_demand_low_end_period2']

overtime_labor_cap = params['overtime_labor_cap']
overtime_labor_cost = params['overtime_labor_cost']
period1_overtime_fatigue_threshold = params['period1_overtime_fatigue_threshold']
period2_labor_recovery_loss = params['period2_labor_recovery_loss']
overtime_review_threshold = params['overtime_review_threshold']
seasonal_safety_review_fee = params['seasonal_safety_review_fee']

# Create model
model = Model("ToyProduction")

# Decision variables
x = {}
for toy in toys:
    x[toy['type'] + "_period1"] = model.addVar(lb=0, name=f"x_{toy['type']}_period1")
    x[toy['type'] + "_period2"] = model.addVar(lb=0, name=f"x_{toy['type']}_period2")

# Objective: maximize profit
total_profit = 0
for toy in toys:
    total_profit += toy['profit'] * (x[toy['type'] + "_period1"] + x[toy['type'] + "_period2"])
model.setObjective(total_profit, GRB.MAXIMIZE)

# Constraints
# Period 1 labor hours
total_labor_period1 = 0
for toy in toys:
    total_labor_period1 += toy['labor'] * x[toy['type'] + "_period1"]
model.addConstr(total_labor_period1 <= available_labor_period1, "Labor_Hours_Period1")

# Period 2 labor hours
total_labor_period2 = 0
for toy in toys:
    total_labor_period2 += toy['labor'] * x[toy['type'] + "_period2"]
model.addConstr(total_labor_period2 <= available_labor_period2 - period2_labor_recovery_loss * (total_labor_period1 > period1_overtime_fatigue_threshold), "Labor_Hours_Period2")

# Period 1 inspection hours
total_inspection_period1 = 0
for toy in toys:
    total_inspection_period1 += toy['inspection'] * x[toy['type'] + "_period1"]
model.addConstr(total_inspection_period1 <= available_inspection_period1, "Inspection_Hours_Period1")

# Period 2 inspection hours
total_inspection_period2 = 0
for toy in toys:
    total_inspection_period2 += toy['inspection'] * x[toy['type'] + "_period2"]
model.addConstr(total_inspection_period2 <= available_inspection_period2, "Inspection_Hours_Period2")

# Period 1 demand constraints
for toy in toys:
    model.addConstr(x[toy['type'] + "_period1"] <= max_demand_high_end_period1 if toy['type'] == "High-End" else
                    (max_demand_mid_range_period1 if toy['type'] == "Mid-Range" else max_demand_low_end_period1), f"Demand_{toy['type']}_Period1")

# Period 2 demand constraints
for toy in toys:
    model.addConstr(x[toy['type'] + "_period2"] <= max_demand_high_end_period2 if toy['type'] == "High-End" else
                    (max_demand_mid_range_period2 if toy['type'] == "Mid-Range" else max_demand_low_end_period2), f"Demand_{toy['type']}_Period2")

# Overtime labor constraint
total_overtime_labor = 0
for toy in toys:
    total_overtime_labor += toy['labor'] * (x[toy['type'] + "_period1"] - available_labor_period1) if x[toy['type'] + "_period1"] > available_labor_period1 else 0
    total_overtime_labor += toy['labor'] * (x[toy['type'] + "_period2"] - available_labor_period2) if x[toy['type'] + "_period2"] > available_labor_period2 else 0
model.addConstr(total_overtime_labor <= overtime_labor_cap, "Overtime_Labor_Cap")

# Safety review cost constraint
model.addConstr(total_overtime_labor >= overtime_review_threshold, "Safety_Review_Cost")

# Solve
model.Params.OutputFlag = 0
model.optimize()

# Print results
for toy in toys:
    print(f"{toy['type']}_period1: {x[toy['type'] + '_period1'].x}")
    print(f"{toy['type']}_period2: {x[toy['type'] + '_period2'].x}")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
