import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Read parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {row['Parameter_Name']: row['Value'] for row in reader}

    num_customers = int(params['num_customers'])
    max_route_length_day = float(params['max_route_length_day'])
    route_cost_day = float(params['route_cost_day'])

    # Read distance matrix
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        lines = f.readlines()
        D = [[0] * num_customers for _ in range(num_customers)]
        for line in lines[1:]:
            nums = list(map(int, re.findall(r'\d+', line)))
            if not nums:
                continue
            row_idx = nums[0] - 1
            for j, val in enumerate(nums[1:]):
                col_idx = row_idx + 1 + j
                if col_idx < num_customers:
                    D[row_idx][col_idx] = val
                    D[col_idx][row_idx] = val

    model = gp.Model("TSP_Day_Split")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # y[i][d]: customer i is assigned to day d (0 or 1)
    y = model.addVars(range(num_customers), range(2), vtype=GRB.BINARY, name="y")
    # x[i][j][d]: edge from i to j on day d
    x = model.addVars(range(num_customers), range(num_customers), range(2), vtype=GRB.BINARY, name="x")
    # u[i][d]: subtour elimination variable for day d
    u = model.addVars(range(num_customers), range(2), lb=1, ub=num_customers-1, vtype=GRB.CONTINUOUS, name="u")
    # day_used[d]: binary indicating if day d is used
    day_used = model.addVars(range(2), vtype=GRB.BINARY, name="day_used")

    # Objective function
    total_cost = 0
    for d in range(2):
        # Travel cost
        travel_cost = gp.quicksum(D[i][j] * x[i][j][d] for i in range(num_customers) for j in range(num_customers) if i != j)
        # Fixed cost
        fixed_cost = route_cost_day * day_used[d]
        total_cost += travel_cost + fixed_cost

    model.setObjective(total_cost, GRB.MINIMIZE)

    # Constraints
    # Each customer must be assigned to exactly one day
    for i in range(1, num_customers):  # Skip depot
        model.addConstr(gp.quicksum(y[i][d] for d in range(2)) == 1)

    # For each day, if used, form a valid TSP tour starting and ending at depot
    for d in range(2):
        # If day is used, then the depot is included in the tour
        model.addConstr(gp.quicksum(x[0][j][d] for j in range(num_customers) if j != 0) == day_used[d])
        model.addConstr(gp.quicksum(x[i][0][d] for i in range(num_customers) if i != 0) == day_used[d])

        # Flow conservation for each customer
        for i in range(1, num_customers):
            model.addConstr(gp.quicksum(x[i][j][d] for j in range(num_customers) if j != i) == day_used[d])
            model.addConstr(gp.quicksum(x[j][i][d] for j in range(num_customers) if j != i) == day_used[d])

        # Subtour elimination constraints
        for i in range(1, num_customers):
            for j in range(1, num_customers):
                if i != j:
                    model.addConstr(u[i][d] - u[j][d] + (num_customers - 1) * x[i][j][d] <= num_customers - 2)

        # Route length constraint
        model.addConstr(gp.quicksum(D[i][j] * x[i][j][d] for i in range(num_customers) for j in range(num_customers) if i != j) <= max_route_length_day * day_used[d])

        # Link y and x: if customer i is assigned to day d, it must be part of the tour
        for i in range(1, num_customers):
            model.addConstr(gp.quicksum(x[i][j][d] for j in range(num_customers) if j != i) >= y[i][d])
            model.addConstr(gp.quicksum(x[j][i][d] for j in range(num_customers) if j != i) >= y[i][d])

    # Solve the model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
