import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Read setup costs
    setup_costs = {}
    with open(os.path.join(data_dir, "setup_costs.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row["Equipment"]
            setup_costs[equip] = float(row["Fixed_Setup_Cost"])

    # Read table_1.csv
    proc_time = {}  # (equipment, product) -> hours per unit
    capacity = {}   # equipment -> available hours
    cost_rate = {}  # equipment -> cost per machine hour
    raw_cost = {}   # product -> raw material cost
    price = {}      # product -> unit price

    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row["Equipment"].strip()
            if equip == "Raw_Material_Cost":
                raw_cost["I"] = float(row["Product_I"])
                raw_cost["II"] = float(row["Product_II"])
                raw_cost["III"] = float(row["Product_III"])
            elif equip == "Unit_Price":
                price["I"] = float(row["Product_I"])
                price["II"] = float(row["Product_II"])
                price["III"] = float(row["Product_III"])
            else:
                for prod in ["I", "II", "III"]:
                    val = row[f"Product_{prod}"].strip()
                    if val != "-":
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row["Effective_Machine_Hours"])
                cost_rate[equip] = float(row["Processing_Cost_per_Machine_Hour"])

    # Equipment assignments from general_parameters
    stage_A_equip = {"I": ["A1", "A2"], "II": ["A1", "A2"], "III": ["A2"]}
    stage_B_equip = {"I": ["B1", "B2", "B3"], "II": ["B1"], "III": ["B2"]}

    # Joint calibration parameters
    joint_calibration_trigger = False
    joint_calibration_fee = 0
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["Parameter_Name"] == "A2_B2_joint_calibration_trigger":
                joint_calibration_trigger = row["Value"].strip() == "1"
            elif row["Parameter_Name"] == "A2_B2_joint_calibration_fee":
                joint_calibration_fee = float(row["Value"])

    # Create model
    model = gp.Model("Factory_Production")
    model.setParam("OutputFlag", 0)

    # Decision variables: x[(equip, prod)] = units of product processed on equipment
    x = {}
    for prod in ["I", "II", "III"]:
        for equip in stage_A_equip[prod]:
            x[(equip, prod)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{equip}_{prod}")
        for equip in stage_B_equip[prod]:
            x[(equip, prod)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{equip}_{prod}")

    # Binary variables for setup costs
    setup = {}
    for equip in ["A1", "A2", "B1", "B2", "B3"]:
        setup[equip] = model.addVar(vtype=GRB.BINARY, name=f"setup_{equip}")

    # Total production of each product (defined by stage A flow = stage B flow)
    total = {}
    for prod in ["I", "II", "III"]:
        total[prod] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"total_{prod}")
        model.addConstr(total[prod] == sum(x[(e, prod)] for e in stage_A_equip[prod]))
        model.addConstr(total[prod] == sum(x[(e, prod)] for e in stage_B_equip[prod]))

    # Capacity constraints
    for equip in ["A1", "A2", "B1", "B2", "B3"]:
        relevant = [(equip, prod) for prod in ["I", "II", "III"] if (equip, prod) in x]
        if relevant:
            model.addConstr(sum(proc_time[(equip, prod)] * x[(equip, prod)] for (equip, prod) in relevant) <= capacity[equip])

    # Setup cost constraints
    for equip in ["A1", "A2", "B1", "B2", "B3"]:
        model.addConstr(sum(x[(equip, prod)] for prod in ["I", "II", "III"] if (equip, prod) in x) >= setup[equip] * 1e-6)
        model.addConstr(model.getVarByName(f"setup_{equip}") * setup_costs[equip] <= model.getVarByName(f"setup_{equip}") * 1e6)

    # Joint calibration constraint
    a2_active = model.addVar(vtype=GRB.BINARY, name="a2_active")
    b2_active = model.addVar(vtype=GRB.BINARY, name="b2_active")
    model.addConstr(a2_active == sum(x[(e, p)] for e in ["A2"] for p in ["I", "II", "III"] if (e, p) in x))
    model.addConstr(b2_active == sum(x[(e, p)] for e in ["B2"] for p in ["I", "II", "III"] if (e, p) in x))
    model.addConstr((a2_active + b2_active) >= 2, name="joint_calibration_gate")
    model.addConstr(joint_calibration_fee * (a2_active * b2_active) <= model.getVarByName("objective"))

    # Objective: profit = revenue - raw material - processing cost - joint calibration fee
    revenue = sum(price[p] * total[p] for p in ["I", "II", "III"])
    raw_mat = sum(raw_cost[p] * total[p] for p in ["I", "II", "III"])
    proc_cost = sum(cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x)
    joint_calibration = joint_calibration_fee * (a2_active * b2_active)

    model.setObjective(revenue - raw_mat - proc_cost - joint_calibration, GRB.MAXIMIZE)

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")

main()
