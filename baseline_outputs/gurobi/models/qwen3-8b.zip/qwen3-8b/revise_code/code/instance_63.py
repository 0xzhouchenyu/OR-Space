import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

produce = params["produce_to_transport"]
horse_poll = params["horse_pollution_per_trip"]
bike_poll = params["bicycle_pollution_per_trip"]
cart_poll = params["handcart_pollution_per_trip"]
max_poll = params["max_total_pollution"]
min_horse = params["min_horse_trips"]
horse_cap = params["horse_capacity_per_trip"]
bike_cap = params["bicycle_capacity_per_trip"]
cart_cap = params["handcart_capacity_per_trip"]
min_produce = params["min_total_produce"]
horse_cost = params["horse_cost_per_trip"]
bike_cost = params["bicycle_cost_per_trip"]
cart_cost = params["handcart_cost_per_trip"]
horse_fixed = params["horse_fixed_cost"]
bike_fixed = params["bicycle_fixed_cost"]
cart_fixed = params["handcart_fixed_cost"]
poll_penalty = params["pollution_penalty_per_unit"]
horse_perm_threshold = params["horse_pollution_permit_threshold"]
horse_perm_fee = params["horse_pollution_permit_fee"]

# Model
model = gp.Model("FarmTransport")

# Decision variables
x_horse = model.addVar(lb=0, vtype=GRB.INTEGER, name="horse_trips")
x_bike = model.addVar(lb=0, vtype=GRB.INTEGER, name="bike_trips")
x_cart = model.addVar(lb=0, vtype=GRB.INTEGER, name="cart_trips")

# Binary variable: y=1 means bicycle chosen, y=0 means handcart chosen
y = model.addVar(vtype=GRB.BINARY, name="choose_bike")

M = 10000  # Big-M

# Objective: minimize total cost (variable + fixed + pollution penalty)
total_pollution = horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart
total_cost = (
    horse_cost * x_horse + bike_cost * x_bike + cart_cost * x_cart
    + (horse_fixed * (x_horse > 0)) + (bike_fixed * y) + (cart_fixed * (1 - y))
    + poll_penalty * total_pollution
)

if total_pollution > horse_perm_threshold:
    total_cost += horse_perm_fee

model.setObjective(total_cost, GRB.MINIMIZE)

# Must transport at least min_produce
model.addConstr(
    horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce
)

# Pollution constraint
model.addConstr(
    horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart <= max_poll
)

# Minimum horse trips
model.addConstr(x_horse >= min_horse)

# Either bicycle or handcart, not both
model.addConstr(x_bike <= M * y)
model.addConstr(x_cart <= M * (1 - y))

# Solve
model.setParam('OutputFlag', 0)
model.optimize()

obj_val = model.objVal

print(f"Horse trips: {x_horse.x}")
print(f"Bicycle trips: {x_bike.x}")
print(f"Handcart trips: {x_cart.x}")
print(f"Choose bicycle: {y.x}")
print(f"Total produce: {horse_cap * x_horse.x + bike_cap * x_bike.x + cart_cap * x_cart.x}")
print(f"Total pollution: {horse_poll * x_horse.x + bike_poll * x_bike.x + cart_poll * x_cart.x}")
print(f"Total cost: {obj_val}")
print(f"FINAL_OBJ_VALUE: {obj_val}")
