import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

weekly_production_time = params["weekly_production_time"]  # 110 hours
fabric_production_rate = params["fabric_production_rate"]  # 1000 meters/hour
min_curtain_fabric_sales = params["min_curtain_fabric_sales"]  # 70000 meters
curtain_fabric_profit = params["curtain_fabric_profit"]  # 2.5 yuan/meter
min_clothing_fabric_sales = params["min_clothing_fabric_sales"]  # 45000 meters
clothing_fabric_profit = params["clothing_fabric_profit"]  # 1.5 yuan/meter
day_shift_regular_capacity = params["day_shift_regular_capacity"]  # 60 hours
night_shift_regular_capacity = params["night_shift_regular_capacity"]  # 60 hours
day_overtime_limit = params["day_overtime_limit"]  # 3 hours
night_overtime_limit = params["night_overtime_limit"]  # 3 hours
day_overtime_penalty = params["day_overtime_penalty"]  # 1.0 yuan/hour
night_overtime_penalty = params["night_overtime_penalty"]  # 1.5 yuan/hour
day_min_utilization_ratio = params["day_min_utilization_ratio"]  # 0.45
night_min_utilization_ratio = params["night_min_utilization_ratio"]  # 0.45

# Convert sales requirements to hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate  # 70 hours
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate  # 45 hours

# Create model
model = gp.Model("Textile_Factory_Optimization")

# Decision variables
day_clothing_hours = model.addVar(lb=0, name="day_clothing_hours")
day_curtain_hours = model.addVar(lb=0, name="day_curtain_hours")
night_clothing_hours = model.addVar(lb=0, name="night_clothing_hours")
night_curtain_hours = model.addVar(lb=0, name="night_curtain_hours")
day_overtime = model.addVar(lb=0, ub=day_overtime_limit, name="day_overtime")
night_overtime = model.addVar(lb=0, ub=night_overtime_limit, name="night_overtime")

# Objective: maximize profit minus overtime penalties
profit = (
    (day_clothing_hours + night_clothing_hours) * clothing_fabric_profit +
    (day_curtain_hours + night_curtain_hours) * curtain_fabric_profit
)
overtime_cost = day_overtime * day_overtime_penalty + night_overtime * night_overtime_penalty
model.setObjective(profit - overtime_cost, GRB.MAXIMIZE)

# Constraints
# Total regular hours per shift
model.addConstr(day_clothing_hours + day_curtain_hours <= day_shift_regular_capacity, "Day_Regular_Hours")
model.addConstr(night_clothing_hours + night_curtain_hours <= night_shift_regular_capacity, "Night_Regular_Hours")

# Total production time
model.addConstr(
    (day_clothing_hours + day_curtain_hours + night_clothing_hours + night_curtain_hours) + day_overtime + night_overtime == weekly_production_time,
    "Total_Production_Time"
)

# Minimum sales requirements
model.addConstr(day_clothing_hours + night_clothing_hours >= min_clothing_hours, "Clothing_Min_Sales")
model.addConstr(day_curtain_hours + night_curtain_hours >= min_curtain_hours, "Curtain_Min_Sales")

# Utilization ratios
total_regular_hours = day_shift_regular_capacity + night_shift_regular_capacity
model.addConstr(
    (day_clothing_hours + day_curtain_hours) >= day_min_utilization_ratio * total_regular_hours,
    "Day_Utilization_Ratio"
)
model.addConstr(
    (night_clothing_hours + night_curtain_hours) >= night_min_utilization_ratio * total_regular_hours,
    "Night_Utilization_Ratio"
)

# Solve
model.Params.OutputFlag = 0
model.optimize()

# Print results
print(f"Status: {model.Status}")
print(f"Day Clothing Hours: {day_clothing_hours.x}")
print(f"Day Curtain Hours: {day_curtain_hours.x}")
print(f"Night Clothing Hours: {night_clothing_hours.x}")
print(f"Night Curtain Hours: {night_curtain_hours.x}")
print(f"Day Overtime: {day_overtime.x}")
print(f"Night Overtime: {night_overtime.x}")
print(f"Total Clothing Produced: {(day_clothing_hours.x + night_clothing_hours.x) * fabric_production_rate} meters")
print(f"Total Curtain Produced: {(day_curtain_hours.x + night_curtain_hours.x) * fabric_production_rate} meters")
print(f"OBJECTIVE_VALUE: {model.ObjVal}")

FINAL_OBJ_VALUE: 148500.0
