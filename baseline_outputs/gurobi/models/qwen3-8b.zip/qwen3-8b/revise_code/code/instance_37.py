import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, "table_1.csv")
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    
    # Parse process data
    a_I = float(rows[0][1])  # Model A hours for Process I
    b_I = float(rows[0][2])  # Model B hours for Process I
    cap_I = float(rows[0][3])  # Max weekly capacity Process I
    
    a_II = float(rows[1][1])  # Model A hours for Process II
    b_II = float(rows[1][2])  # Model B hours for Process II
    cap_II = float(rows[1][3])  # Max weekly capacity Process II
    
    profit_A = float(rows[2][1])  # Profit per unit Model A
    profit_B = float(rows[2][2])  # Profit per unit Model B
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "general_parameters.csv")
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    min_profit = params['min_weekly_profit']
    min_A_total = params['min_model_A_units']
    min_B_total = params['min_model_B_units']
    week1_min_A = params['week1_min_model_A_units']
    week1_min_B = params['week1_min_model_B_units']
    week2_min_A = params['week2_min_model_A_units']
    week2_min_B = params['week2_min_model_B_units']
    process_I_hours = params['process_I_hours']
    process_II_hours = params['process_II_hours']
    max_overtime_I_per_week = params['max_overtime_I_per_week']
    max_overtime_II_per_week = params['max_overtime_II_per_week']
    overtime_premium_I = params['overtime_premium_I']
    overtime_premium_II = params['overtime_premium_II']
    min_avg_utilization_I = params['min_avg_utilization_I']
    min_avg_utilization_II = params['min_avg_utilization_II']
    week1_overtime_fatigue_threshold_I = params['week1_overtime_fatigue_threshold_I']
    week1_overtime_fatigue_threshold_II = params['week1_overtime_fatigue_threshold_II']
    week2_recovery_loss_I = params['week2_recovery_loss_I']
    week2_recovery_loss_II = params['week2_recovery_loss_II']
    
    # Create model
    model = gp.Model("Microcomputer_Production_Revamped")
    model.setParam('OutputFlag', 0)
    
    # Decision variables for each week
    x_A1 = model.addVar(name="x_A1", lb=0)  # Model A units in week 1
    x_B1 = model.addVar(name="x_B1", lb=0)  # Model B units in week 1
    x_A2 = model.addVar(name="x_A2", lb=0)  # Model A units in week 2
    x_B2 = model.addVar(name="x_B2", lb=0)  # Model B units in week 2
    
    # Overtime variables
    ovt_I1 = model.addVar(name="ovt_I1", lb=0)  # Overtime for Process I in week 1
    ovt_I2 = model.addVar(name="ovt_I2", lb=0)  # Overtime for Process I in week 2
    ovt_II1 = model.addVar(name="ovt_II1", lb=0)  # Overtime for Process II in week 1
    ovt_II2 = model.addVar(name="ovt_II2", lb=0)  # Overtime for Process II in week 2
    
    # Constraints: Weekly production requirements
    model.addConstr(x_A1 >= week1_min_A, "Week1_Min_Model_A")
    model.addConstr(x_B1 >= week1_min_B, "Week1_Min_Model_B")
    model.addConstr(x_A2 >= week2_min_A, "Week2_Min_Model_A")
    model.addConstr(x_B2 >= week2_min_B, "Week2_Min_Model_B")
    
    # Total production requirements
    model.addConstr(x_A1 + x_A2 >= min_A_total, "Min_Model_A")
    model.addConstr(x_B1 + x_B2 >= min_B_total, "Min_Model_B")
    
    # Process I capacity constraints (with overtime)
    model.addConstr(a_I * x_A1 + b_I * x_B1 <= process_I_hours + ovt_I1, "Process_I_Capacity_Week1")
    model.addConstr(a_I * x_A2 + b_I * x_B2 <= process_I_hours + ovt_I2, "Process_I_Capacity_Week2")
    
    # Process II capacity constraints (with overtime)
    model.addConstr(a_II * x_A1 + b_II * x_B1 <= process_II_hours + ovt_II1, "Process_II_Capacity_Week1")
    model.addConstr(a_II * x_A2 + b_II * x_B2 <= process_II_hours + ovt_II2, "Process_II_Capacity_Week2")
    
    # Overtime limits
    model.addConstr(ovt_I1 <= max_overtime_I_per_week, "Max_Overtime_I_Week1")
    model.addConstr(ovt_I2 <= max_overtime_I_per_week, "Max_Overtime_I_Week2")
    model.addConstr(ovt_II1 <= max_overtime_II_per_week, "Max_Overtime_II_Week1")
    model.addConstr(ovt_II2 <= max_overtime_II_per_week, "Max_Overtime_II_Week2")
    
    # Recovery rule for Process I
    model.addConstr(ovt_I1 <= week1_overtime_fatigue_threshold_I, "Overtime_I_Threshold_Week1")
    model.addConstr(process_I_hours - week2_recovery_loss_I <= process_I_hours - ovt_I1, "Recovery_Loss_I_Week2")
    
    # Recovery rule for Process II
    model.addConstr(ovt_II1 <= week1_overtime_fatigue_threshold_II, "Overtime_II_Threshold_Week1")
    model.addConstr(process_II_hours - week2_recovery_loss_II <= process_II_hours - ovt_II1, "Recovery_Loss_II_Week2")
    
    # Average utilization constraints
    total_regular_I = 2 * process_I_hours
    total_regular_II = 2 * process_II_hours
    total_used_I = a_I * (x_A1 + x_A2) + b_I * (x_B1 + x_B2)
    total_used_II = a_II * (x_A1 + x_A2) + b_II * (x_B1 + x_B2)
    model.addConstr(total_used_I / total_regular_I >= min_avg_utilization_I, "Min_Utilization_I")
    model.addConstr(total_used_II / total_regular_II >= min_avg_utilization_II, "Min_Utilization_II")
    
    # Objective: Maximize profit minus overtime cost
    profit = profit_A * (x_A1 + x_A2) + profit_B * (x_B1 + x_B2)
    overtime_cost = ovt_I1 * overtime_premium_I + ovt_I2 * overtime_premium_I + ovt_II1 * overtime_premium_II + ovt_II2 * overtime_premium_II
    model.setObjective(profit - overtime_cost, GRB.MAXIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
