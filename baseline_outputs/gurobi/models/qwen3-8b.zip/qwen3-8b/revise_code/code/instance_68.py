import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add parent directory to path
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

# Load data
data_dir = os.path.join(script_dir, '..', 'data')
distances = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        yard = row['Coal_Yard'].strip()
        area = int(row['Residential_Area'].strip())
        dist = float(row['Distance_km'].strip())
        distances[(yard, area)] = dist

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
min_supply = {
    'A': params['min_coal_yard_A'],
    'B': params['min_coal_yard_B_adjusted']
}

demand = {
    1: params['residential_area_1_demand'],
    2: params['residential_area_2_demand'],
    3: params['residential_area_3_demand']
}

min_share_area3_from_A = params['min_share_area3_from_A']
area3_A_staging_threshold = params['area3_A_staging_threshold']
area3_A_excess_staging_cost = params['area3_A_excess_staging_cost']

coal_yards = ['A', 'B']
areas = [1, 2, 3]

# Create the model
model = gp.Model("Coal_Distribution")

# Decision variables: amount of coal shipped from yard i to area j
x = {}
for yard in coal_yards:
    for area in areas:
        x[(yard, area)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{yard}_{area}")

# Objective: minimize total transportation cost (distance * amount + excess staging cost)
total_cost = 0
for yard in coal_yards:
    for area in areas:
        if yard == 'A' and area == 3:
            # Split into normal and excess
            normal = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"normal_{yard}_{area}")
            excess = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"excess_{yard}_{area}")
            model.addConstr(normal + excess == x[(yard, area)])
            total_cost += distances[(yard, area)] * normal + distances[(yard, area)] * excess + area3_A_excess_staging_cost * excess
        else:
            total_cost += distances[(yard, area)] * x[(yard, area)]

model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints:
# 1. Each coal yard must supply at least its minimum requirement
for yard in coal_yards:
    model.addConstr(gp.quicksum(x[(yard, area)] for area in areas) >= min_supply[yard], f"Min_Supply_{yard}")

# 2. Each residential area must receive exactly its demand
for area in areas:
    model.addConstr(gp.quicksum(x[(yard, area)] for yard in coal_yards) == demand[area], f"Demand_{area}")

# 3. Minimum share of Area 3 demand from Coal Yard A
model.addConstr(x[('A', 3)] >= min_share_area3_from_A * demand[3], "Min_Share_Area3_from_A")

# Solve
model.setParam('OutputFlag', 0)
model.optimize()

# Print solution details
print(f"Status: {model.Status}")
print()
for yard in coal_yards:
    for area in areas:
        val = x[(yard, area)].X
        if val > 0:
            print(f"Coal Yard {yard} -> Area {area}: {val} tons (distance: {distances[(yard, area)]} km)")

print()
total_supply = {yard: sum(x[(yard, area)].X for area in areas) for yard in coal_yards}
for yard in coal_yards:
    print(f"Coal Yard {yard} total supply: {total_supply[yard]} tons (min: {min_supply[yard]})")

obj_val = model.objVal
print(f"\nFINAL_OBJ_VALUE: {obj_val}")
