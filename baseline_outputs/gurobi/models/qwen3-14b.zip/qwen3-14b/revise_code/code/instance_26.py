import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    general_params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row["Parameter_Name"]] = row["Value"]
    
    shift_duration = int(general_params["shift_duration"])
    full_time_cost = float(general_params["full_time_cost"])
    part_time_cost = float(general_params["part_time_cost"])
    part_time_cap_per_period = int(general_params["part_time_cap_per_period"])
    min_full_time_per_period = int(general_params["min_full_time_per_period"])
    
    # Read staffing requirements
    requirements = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row["Time_Period"].strip()
            req = int(row["Required_Salespeople"].strip())
            requirements[period] = req
    
    # Periods: 0: 2-6, 1: 6-10, 2: 10-14, 3: 14-18, 4: 18-22, 5: 22-2
    periods = list(requirements.keys())
    req_values = list(requirements.values())
    n = len(periods)  # 6 periods
    
    # Create model
    model = gp.Model("MinLaborCost")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i]: number of full-time salespeople starting at period i
    x = model.addVars(n, name="full_time", vtype=gp.GRB.INTEGER, lb=0)
    # y[j]: number of part-time salespeople working in period j
    y = model.addVars(n, name="part_time", vtype=gp.GRB.INTEGER, lb=0)
    
    # Objective: minimize total daily labor cost
    model.setObjective(
        gp.quicksum(x[i] * full_time_cost for i in range(n)) +
        gp.quicksum(y[j] * part_time_cost for j in range(n)),
        GRB.MINIMIZE
    )
    
    # Constraints
    # 1. Coverage constraint: For each period j, the sum of full-time and part-time workers must be >= Required_Salespeople[j]
    for j in range(n):
        full_time_workers = x[j] + x[(j - 1) % n]
        model.addConstr(full_time_workers + y[j] >= req_values[j], name=f"coverage_{j}")
    
    # 2. Part-time cap constraint: No more than part_time_cap_per_period part-time workers in any period
    for j in range(n):
        model.addConstr(y[j] <= part_time_cap_per_period, name=f"part_time_cap_{j}")
    
    # 3. Minimum full-time per period constraint: Full-time workers in period j must be >= min_full_time_per_period
    for j in range(n):
        full_time_workers = x[j] + x[(j - 1) % n]
        model.addConstr(full_time_workers >= min_full_time_per_period, name=f"min_full_time_{j}")
    
    # Optimize model
    model.optimize()
    
    # Print solution details
    for i in range(n):
        print(f"Full-time starts at period {periods[i]}: {int(x[i].x)} salespeople")
        print(f"Part-time workers in period {periods[i]}: {int(y[i].x)} salespeople")
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
