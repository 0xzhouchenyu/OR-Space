import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_parameters

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    a = params['a']  # hours per furnace for method 1
    b = params['b']  # hours per furnace for method 2
    k = params['k']  # tons per batch
    d = params['d']  # minimum production requirement
    c_offpeak = params['c_offpeak']  # max off-peak time per furnace
    c_peak = params['c_peak']  # max peak time per furnace
    cap_offpeak = params['cap_offpeak']  # plant-wide max off-peak time
    cap_peak = params['cap_peak']  # plant-wide max peak time
    m_offpeak = params['m_offpeak']  # fuel cost for method 1 in off-peak
    n_offpeak = params['n_offpeak']  # fuel cost for method 2 in off-peak
    m_peak = params['m_peak']  # fuel cost for method 1 in peak
    n_peak = params['n_peak']  # fuel cost for method 2 in peak
    f_offpeak = params['f_offpeak']  # fixed activation overhead for off-peak
    f_peak = params['f_peak']  # fixed activation overhead for peak
    offpeak_cooldown_batch_threshold = params['offpeak_cooldown_batch_threshold']
    offpeak_cooldown_fee = params['offpeak_cooldown_fee']

    model = gp.Model("SteelFurnaceRevised")
    model.setParam('OutputFlag', 0)

    # Decision variables: x_ij = number of times furnace i uses method j in off-peak or peak
    # Furnace 1
    x1_offpeak = model.addVar(vtype=GRB.INTEGER, name="x1_offpeak")  # method 1, off-peak
    x2_offpeak = model.addVar(vtype=GRB.INTEGER, name="x2_offpeak")  # method 2, off-peak
    x1_peak = model.addVar(vtype=GRB.INTEGER, name="x1_peak")  # method 1, peak
    x2_peak = model.addVar(vtype=GRB.INTEGER, name="x2_peak")  # method 2, peak

    # Furnace 2
    x3_offpeak = model.addVar(vtype=GRB.INTEGER, name="x3_offpeak")  # method 1, off-peak
    x4_offpeak = model.addVar(vtype=GRB.INTEGER, name="x4_offpeak")  # method 2, off-peak
    x3_peak = model.addVar(vtype=GRB.INTEGER, name="x3_peak")  # method 1, peak
    x4_peak = model.addVar(vtype=GRB.INTEGER, name="x4_peak")  # method 2, peak

    # Objective function: minimize total cost
    # Fuel costs
    fuel_cost = (
        m_offpeak * (x1_offpeak + x3_offpeak) +
        n_offpeak * (x2_offpeak + x4_offpeak) +
        m_peak * (x1_peak + x3_peak) +
        n_peak * (x2_peak + x4_peak)
    )

    # Fixed activation overhead
    activation_cost = (
        f_offpeak * (gp.quicksum([x1_offpeak, x2_offpeak, x3_offpeak, x4_offpeak]) > 0) +
        f_peak * (gp.quicksum([x1_peak, x2_peak, x3_peak, x4_peak]) > 0)
    )

    # Cooldown fee if any furnace has more than 2 off-peak batches
    cooldown_fee = (
        offpeak_cooldown_fee * (gp.quicksum([x1_offpeak, x2_offpeak]) > offpeak_cooldown_batch_threshold) +
        offpeak_cooldown_fee * (gp.quicksum([x3_offpeak, x4_offpeak]) > offpeak_cooldown_batch_threshold)
    )

    model.setObjective(fuel_cost + activation_cost + cooldown_fee, GRB.MINIMIZE)

    # Time constraints for each furnace
    # Furnace 1
    model.addConstr(a * x1_offpeak + b * x2_offpeak <= c_offpeak, "Furnace1_Offpeak_Time")
    model.addConstr(a * x1_peak + b * x2_peak <= c_peak, "Furnace1_Peak_Time")

    # Furnace 2
    model.addConstr(a * x3_offpeak + b * x4_offpeak <= c_offpeak, "Furnace2_Offpeak_Time")
    model.addConstr(a * x3_peak + b * x4_peak <= c_peak, "Furnace2_Peak_Time")

    # Plant-wide time constraints
    model.addConstr(
        a * (x1_offpeak + x3_offpeak) + b * (x2_offpeak + x4_offpeak) <= cap_offpeak,
        "Plant_Offpeak_Time"
    )
    model.addConstr(
        a * (x1_peak + x3_peak) + b * (x2_peak + x4_peak) <= cap_peak,
        "Plant_Peak_Time"
    )

    # Minimum production requirement
    model.addConstr(k * (x1_offpeak + x2_offpeak + x3_offpeak + x4_offpeak + x1_peak + x2_peak + x3_peak + x4_peak) >= d, "MinProduction")

    model.optimize()

    final_obj_value = model.objVal
    print(f"FINAL_OBJ_VALUE: {final_obj_value}")

if __name__ == "__main__":
    main()
