import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row["Quarter"].strip()
            quarters.append(q)
            purchase_price[q] = float(row["Purchase_Price_10k_yuan_per_10k_m2"].strip())
            sale_price[q] = float(row["Sale_Price_10k_yuan_per_10k_m2"].strip())
            max_sales[q] = float(row["Estimated_Max_Sales_Volume_10k_m3"].strip())
            max_purchase[q] = float(row["max_purchase_10k_m3"].strip())
    
    # Read general_parameters.csv
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    
    max_storage = float(params["max_storage_capacity"])  # 200000 m³
    storage_cost_a = float(params["storage_cost_a"])      # 70 yuan/m³
    storage_cost_b = float(params["storage_cost_b"])      # 100 yuan/m³/quarter
    safety_inventory_level = float(params["safety_inventory_level_10k_m3"])  # 20 万m³
    terminal_inventory_value = float(params["terminal_inventory_value_per_10k_m3"])  # 455 万元/万m³
    over_purchase_penalty = float(params["over_purchase_penalty_cost_per_10k_m3"])  # 300 万元/万m³
    
    # Convert storage capacity to 万m³
    max_storage_wm3 = max_storage / 10000.0  # 20 万m³
    
    # Convert storage costs to 万元/万m³
    storage_cost_a_w = storage_cost_a * 10000.0 / 10000.0  # 70 万元/万m³
    storage_cost_b_w = storage_cost_b * 10000.0 / 10000.0  # 100 万元/万m³/quarter
    
    n = len(quarters)
    
    # Decision variables: x[i][j] = amount purchased in quarter i and sold in quarter j (万m³)
    model = gp.Model("Timber_Profit_Maximization")
    model.setParam('OutputFlag', 0)
    
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(name=f"x_{i}_{j}", lb=0)
    
    # Objective function
    obj = gp.QuadExpr()
    
    for i in range(n):
        for j in range(i, n):
            u = j - i  # quarters stored
            revenue = sale_price[quarters[j]]
            cost = purchase_price[quarters[i]]
            if u > 0:
                s_cost = storage_cost_a_w + storage_cost_b_w * u
            else:
                s_cost = 0
            profit_term = (revenue - cost - s_cost) * x[i, j]
            obj += profit_term
    
    # Terminal inventory value and penalty
    end_of_autumn_inventory = gp.LinExpr()
    for i in range(n - 1):  # Winter, Spring, Summer
        for j in range(i, n - 1):  # Sold before Autumn
            end_of_autumn_inventory += x[i, j]
    for i in range(n - 1):  # Winter, Spring, Summer
        end_of_autumn_inventory += x[i, n - 1]  # Sold in Autumn
    
    # Terminal inventory value
    terminal_value = terminal_inventory_value * (end_of_autumn_inventory - safety_inventory_level)
    # Over-purchase penalty
    over_purchase_penalty_term = over_purchase_penalty * max(end_of_autumn_inventory - safety_inventory_level, 0)
    
    obj += terminal_value - over_purchase_penalty_term
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Sales constraints: total sold in quarter j <= max_sales[j]
    for j in range(n):
        sales_expr = gp.LinExpr()
        for i in range(j + 1):
            sales_expr += x[i, j]
        model.addConstr(sales_expr <= max_sales[quarters[j]], name=f"Sales_Cap_{j}")
    
    # Purchase constraints: total purchased in quarter i <= max_purchase[i]
    for i in range(n):
        purchase_expr = gp.LinExpr()
        for j in range(i, n):
            purchase_expr += x[i, j]
        model.addConstr(purchase_expr <= max_purchase[quarters[i]], name=f"Purchase_Cap_{i}")
    
    # Storage constraints: at end of each quarter, stored timber <= max_storage
    for t in range(n - 1):
        stored_expr = gp.LinExpr()
        for i in range(t + 1):
            for j in range(t + 1, n):
                stored_expr += x[i, j]
        model.addConstr(stored_expr <= max_storage_wm3, name=f"Storage_Cap_{t}")
    
    model.optimize()
    
    # Print results
    for i in range(n):
        for j in range(i, n):
            val = x[i, j].x
            if val > 0.001:
                u = j - i
                print(f"Buy in {quarters[i]}, sell in {quarters[j]} (store {u}q): {val:.2f} 万m³")
    
    final_obj_value = model.objVal
    print(f"FINAL_OBJ_VALUE: {final_obj_value:.1f}")

if __name__ == "__main__":
    main()
