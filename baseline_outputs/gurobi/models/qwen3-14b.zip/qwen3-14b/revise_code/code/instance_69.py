import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(data_path)
    
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = row['Value']
        
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = int(params['raw_bar_length'])
    setup_cost = float(params['setup_cost_per_pattern'])
    max_patterns = int(params['max_distinct_patterns'])
    
    # Lengths of the three types of steel bars
    len1 = 3
    len2 = 4
    len3 = 5
    
    # Generate all valid cutting patterns
    patterns = []
    for x in range(L // len1 + 1):
        for y in range(L // len2 + 1):
            for z in range(L // len3 + 1):
                if len1 * x + len2 * y + len3 * z <= L:
                    if x > 0 or y > 0 or z > 0:
                        patterns.append((x, y, z))
    
    # Create a model
    model = gp.Model("CuttingStockRevised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of times each pattern is used
    num_patterns = len(patterns)
    vars = model.addVars(num_patterns, name="Pattern", vtype=GRB.INTEGER, lb=0)
    
    # Objective: minimize total waste (including setup cost per distinct pattern)
    # Total waste = (Total length of raw bars used) - (Total length of required pieces) + (setup_cost * number of distinct patterns used)
    total_required_length = len1 * q3 + len2 * q4 + len3 * q5
    total_raw_used = gp.quicksum(L * vars[i] for i in range(num_patterns))
    
    # Count the number of distinct patterns used
    distinct_patterns_used = gp.quicksum(vars[i] > 0 for i in range(num_patterns))
    
    model.setObjective(total_raw_used - total_required_length + setup_cost * distinct_patterns_used, GRB.MINIMIZE)
    
    # Constraints: satisfy the demand for each type of steel bar
    model.addConstr(gp.quicksum(patterns[i][0] * vars[i] for i in range(num_patterns)) >= q3, "Demand_3m")
    model.addConstr(gp.quicksum(patterns[i][1] * vars[i] for i in range(num_patterns)) >= q4, "Demand_4m")
    model.addConstr(gp.quicksum(patterns[i][2] * vars[i] for i in range(num_patterns)) >= q5, "Demand_5m")
    
    # Constraint: maximum number of distinct patterns allowed
    model.addConstr(distinct_patterns_used <= max_patterns, "MaxDistinctPatterns")
    
    # Optimize the model
    model.optimize()
    
    # Calculate and print the final objective value
    final_obj_value = model.objVal
    print(f"FINAL_OBJ_VALUE: {final_obj_value}")

if __name__ == "__main__":
    solve()
