import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, "table_1.csv")
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    
    # Parse process data
    a_I = float(rows[0][1])  # Model A hours for Process I
    b_I = float(rows[0][2])  # Model B hours for Process I
    cap_I = float(rows[0][3])  # Max weekly capacity Process I
    
    a_II = float(rows[1][1])  # Model A hours for Process II
    b_II = float(rows[1][2])  # Model B hours for Process II
    cap_II = float(rows[1][3])  # Max weekly capacity Process II
    
    profit_A = float(rows[2][1])  # Profit per unit Model A
    profit_B = float(rows[2][2])  # Profit per unit Model B
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "general_parameters.csv")
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    min_profit = params['min_weekly_profit']
    min_A_total = params['min_model_A_units']
    min_B_total = params['min_model_B_units']
    week1_min_A = params['week1_min_model_A_units']
    week1_min_B = params['week1_min_model_B_units']
    week2_min_A = params['week2_min_model_A_units']
    week2_min_B = params['week2_min_model_B_units']
    
    normal_hours_I = params['process_I_hours']
    normal_hours_II = params['process_II_hours']
    max_overtime_I = params['max_overtime_I_per_week']
    max_overtime_II = params['max_overtime_II_per_week']
    overtime_cost_I = params['overtime_premium_I']
    overtime_cost_II = params['overtime_premium_II']
    min_avg_utilization_I = params['min_avg_utilization_I']
    min_avg_utilization_II = params['min_avg_utilization_II']
    week1_overtime_threshold_I = params['week1_overtime_fatigue_threshold_I']
    week1_overtime_threshold_II = params['week1_overtime_fatigue_threshold_II']
    week2_recovery_I = params['week2_recovery_loss_I']
    week2_recovery_II = params['week2_recovery_loss_II']
    
    # Create model
    model = gp.Model("Microcomputer_Production_Two_Weeks")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_A1 = model.addVar(name="x_A1", lb=0)  # Week 1 Model A
    x_B1 = model.addVar(name="x_B1", lb=0)  # Week 1 Model B
    x_A2 = model.addVar(name="x_A2", lb=0)  # Week 2 Model A
    x_B2 = model.addVar(name="x_B2", lb=0)  # Week 2 Model B
    
    ovt_I1 = model.addVar(name="ovt_I1", lb=0, ub=max_overtime_I)  # Overtime I Week 1
    ovt_II1 = model.addVar(name="ovt_II1", lb=0, ub=max_overtime_II)  # Overtime II Week 1
    ovt_I2 = model.addVar(name="ovt_I2", lb=0, ub=max_overtime_I)  # Overtime I Week 2
    ovt_II2 = model.addVar(name="ovt_II2", lb=0, ub=max_overtime_II)  # Overtime II Week 2
    
    # Objective: Maximize total profit - overtime costs
    model.setObjective(
        (profit_A * x_A1 + profit_B * x_B1 + profit_A * x_A2 + profit_B * x_B2) 
        - (ovt_I1 * overtime_cost_I + ovt_II1 * overtime_cost_II + ovt_I2 * overtime_cost_I + ovt_II2 * overtime_cost_II),
        GRB.MAXIMIZE
    )
    
    # Constraints
    # Week 1 production constraints
    model.addConstr(a_I * x_A1 + b_I * x_B1 + ovt_I1 <= normal_hours_I + max_overtime_I, "Process_I_Capacity_Week1")
    model.addConstr(a_II * x_A1 + b_II * x_B1 + ovt_II1 <= normal_hours_II + max_overtime_II, "Process_II_Capacity_Week1")
    model.addConstr(x_A1 >= week1_min_A, "Min_Model_A_Week1")
    model.addConstr(x_B1 >= week1_min_B, "Min_Model_B_Week1")
    
    # Week 2 production constraints
    model.addConstr(a_I * x_A2 + b_I * x_B2 + ovt_I2 <= normal_hours_I - (ovt_I1 >= week1_overtime_threshold_I) * week2_recovery_I + max_overtime_I, "Process_I_Capacity_Week2")
    model.addConstr(a_II * x_A2 + b_II * x_B2 + ovt_II2 <= normal_hours_II - (ovt_II1 >= week1_overtime_threshold_II) * week2_recovery_II + max_overtime_II, "Process_II_Capacity_Week2")
    model.addConstr(x_A2 >= week2_min_A, "Min_Model_A_Week2")
    model.addConstr(x_B2 >= week2_min_B, "Min_Model_B_Week2")
    
    # Total minimum production over two weeks
    model.addConstr(x_A1 + x_A2 >= min_A_total, "Min_Model_A_Total")
    model.addConstr(x_B1 + x_B2 >= min_B_total, "Min_Model_B_Total")
    
    # Minimum average utilization over two weeks
    model.addConstr((a_I * x_A1 + b_I * x_B1 + a_I * x_A2 + b_I * x_B2) / (normal_hours_I * 2) >= min_avg_utilization_I, "Min_Utilization_I")
    model.addConstr((a_II * x_A1 + b_II * x_B1 + a_II * x_A2 + b_II * x_B2) / (normal_hours_II * 2) >= min_avg_utilization_II, "Min_Utilization_II")
    
    # Min profit constraint
    model.addConstr((profit_A * x_A1 + profit_B * x_B1 + profit_A * x_A2 + profit_B * x_B2) >= min_profit, "Min_Profit")
    
    # Solve the model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
