import os
import sys
import gurobipy as gp
from gurobipy import GRB
import csv

# Add parent directory to path if needed
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(script_dir, "data")
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
motorcycle_pollution = params['motorcycle_pollution']       # 40
small_truck_pollution = params['small_truck_pollution']     # 70
large_truck_pollution = params['large_truck_pollution']     # 100
max_motorcycle_trips = int(params['max_motorcycle_trips'])  # 8
motorcycle_capacity = params['motorcycle_capacity']         # 10
small_truck_capacity = params['small_truck_capacity']       # 20
large_truck_capacity = params['large_truck_capacity']       # 50
demand_peak_units = params['demand_peak_units']             # 200
demand_offpeak_units = params['demand_offpeak_units']       # 120
leasing_capacity = params['leasing_capacity']               # 200
leasing_pollution_per_unit = params['leasing_pollution_per_unit']  # 60
leasing_fixed_pollution = params['leasing_fixed_pollution']      # 100
max_leasing_fraction_peak = params['max_leasing_fraction_peak']  # 0.25
bigM_leasing = params['bigM_leasing']                       # 400
epsilon = params['epsilon']                                 # 1

methods = ['motorcycle', 'small_truck', 'large_truck']

pollution = {
    'motorcycle': motorcycle_pollution,
    'small_truck': small_truck_pollution,
    'large_truck': large_truck_pollution
}

capacity = {
    'motorcycle': motorcycle_capacity,
    'small_truck': small_truck_capacity,
    'large_truck': large_truck_capacity
}

# Create model
model = gp.Model("Transport_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables: number of trips for each method (integer, non-negative)
trips = {}
for m in methods:
    trips[m] = model.addVar(vtype=GRB.INTEGER, name=f"trips_{m}", lb=0)

# Leasing decision variables
leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")
leasing_units = model.addVar(vtype=GRB.CONTINUOUS, name="leasing_units", lb=0)

# Objective: minimize total pollution
obj = gp.quicksum(pollution[m] * trips[m] for m in methods) + leasing_fixed_pollution * leasing_used + leasing_pollution_per_unit * leasing_units
model.setObjective(obj, GRB.MINIMIZE)

# Constraints
# Minimum transport requirement in peak period
peak_transport = gp.quicksum(capacity[m] * trips[m] for m in methods if m in ['motorcycle', 'small_truck', 'large_truck'])
model.addConstr(peak_transport + leasing_units >= demand_peak_units, "peak_demand")

# Minimum transport requirement in off-peak period
offpeak_transport = gp.quicksum(capacity[m] * trips[m] for m in methods if m in ['motorcycle', 'small_truck', 'large_truck'])
model.addConstr(offpeak_transport + leasing_units >= demand_offpeak_units, "offpeak_demand")

# Maximum total trips allowed across both periods
model.addConstr(gp.quicksum(trips[m] for m in methods) <= params['max_total_trips'], "max_total_trips")

# Motorcycle trips limit
model.addConstr(trips['motorcycle'] <= max_motorcycle_trips, "max_motorcycle_trips")

# Leasing constraints
model.addConstr(leasing_units <= leasing_capacity, "leasing_capacity_limit")
model.addConstr(leasing_units <= max_leasing_fraction_peak * demand_peak_units, "leasing_peak_fraction")
model.addConstr(leasing_units >= epsilon * leasing_used, "leasing_activation")
model.addConstr(leasing_units <= bigM_leasing * leasing_used, "leasing_deactivation")

# Solve the model
model.optimize()

# Print solution details
if model.status == GRB.OPTIMAL:
    best_obj = model.objVal
    print(f"FINAL_OBJ_VALUE: {best_obj}")
else:
    print("No optimal solution found.")
