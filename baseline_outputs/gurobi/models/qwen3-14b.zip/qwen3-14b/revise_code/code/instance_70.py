import os
import gurobipy as gp
from gurobipy import GRB
from itertools import permutations
from utils import load_distance_matrix

def solve_tsp():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    dist_file = os.path.join(data_dir, "table_1.csv")
    param_file = os.path.join(data_dir, "general_parameters.csv")

    # Load distance matrix
    cities, dist = load_distance_matrix(dist_file)

    # Load general parameters
    with open(param_file, 'r') as f:
        reader = csv.DictReader(f)
        params = next(reader)
    
    start_city = int(params['start_city']) - 1
    end_city = int(params['end_city']) - 1
    prohibited_from = int(params['prohibited_from']) - 1
    prohibited_to = int(params['prohibited_to']) - 1
    inspection_arc_from = int(params['inspection_arc_from']) - 1
    inspection_arc_to = int(params['inspection_arc_to']) - 1
    inspection_stop_cost = float(params['inspection_stop_cost'])

    n = len(cities)

    # Create Gurobi model
    model = gp.Model("TSP")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[i][j] = 1 if the route goes from city i to city j
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")

    # MTZ variables for subtour elimination
    u = model.addVars(n, lb=1, ub=n-1, vtype=GRB.CONTINUOUS, name="u")

    # Objective function
    obj = gp.quicksum(dist[i][j] * x[i, j] for i in range(n) for j in range(n) if i != j)
    # Add inspection stop cost for arc from 2 to 3
    obj += inspection_stop_cost * x[inspection_arc_from, inspection_arc_to]
    model.setObjective(obj, GRB.MINIMIZE)

    # Each city is left exactly once
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1, name=f"leave_{i}")

    # Each city is entered exactly once
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(n) if i != j) == 1, name=f"enter_{j}")

    # Subtour elimination constraints (MTZ formulation)
    for i in range(n):
        for j in range(n):
            if i != j and i != 0 and j != 0:
                model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1, name=f"subtour_elim_{i}_{j}")

    # Prohibition of direct move from city 1 to city 3
    model.addConstr(x[prohibited_from, prohibited_to] == 0, name="prohibition")

    # Start at city 1 and end at city 4
    for j in range(n):
        if j == start_city:
            model.addConstr(x[start_city, j] == 0, name=f"start_{start_city}")
        elif j == end_city:
            model.addConstr(x[end_city, j] == 0, name=f"end_{end_city}")

    # Ensure that the route starts at city 1 and ends at city 4
    model.addConstr(gp.quicksum(x[i, start_city] for i in range(n) if i != start_city) == 0, name="start")
    model.addConstr(gp.quicksum(x[end_city, j] for j in range(n) if j != end_city) == 0, name="end")

    # Optimize the model
    model.optimize()

    # Extract the optimal route
    if model.status == GRB.OPTIMAL:
        route = [start_city]
        current = start_city
        while True:
            next_city = None
            for j in range(n):
                if x[current, j].x > 0.5:
                    next_city = j
                    break
            if next_city is None:
                break
            route.append(next_city)
            current = next_city
            if current == end_city:
                break
        route.append(end_city)
        print(f"Optimal route: {[cities[i] for i in route]}")
    else:
        print("No optimal solution found.")

    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_tsp()
