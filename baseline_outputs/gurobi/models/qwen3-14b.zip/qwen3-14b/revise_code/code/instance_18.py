import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

weekly_production_time = params["weekly_production_time"]  # 110 hours
fabric_production_rate = params["fabric_production_rate"]  # 1000 meters/hour
min_curtain_fabric_sales = params["min_curtain_fabric_sales"]  # 70000 meters
curtain_fabric_profit = params["curtain_fabric_profit"]  # 2.5 yuan/meter
min_clothing_fabric_sales = params["min_clothing_fabric_sales"]  # 45000 meters
clothing_fabric_profit = params["clothing_fabric_profit"]  # 1.5 yuan/meter

day_shift_regular_capacity = params["day_shift_regular_capacity"]  # 60 hours
night_shift_regular_capacity = params["night_shift_regular_capacity"]  # 60 hours
day_overtime_limit = params["day_overtime_limit"]  # 3 hours
night_overtime_limit = params["night_overtime_limit"]  # 3 hours
day_overtime_penalty = params["day_overtime_penalty"]  # 1.0 yuan/hour
night_overtime_penalty = params["night_overtime_penalty"]  # 1.5 yuan/hour
day_min_utilization_ratio = params["day_min_utilization_ratio"]  # 0.45
night_min_utilization_ratio = params["night_min_utilization_ratio"]  # 0.45

# Convert sales requirements to hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate  # 70 hours
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate  # 45 hours

# Create model
model = gp.Model("Textile_Factory_Overtime_Minimization")
model.setParam("OutputFlag", 0)

# Decision variables
# Regular hours in day and night shifts
day_regular = model.addVar(name="day_regular", lb=0, ub=day_shift_regular_capacity)
night_regular = model.addVar(name="night_regular", lb=0, ub=night_shift_regular_capacity)

# Overtime hours in day and night shifts
day_overtime = model.addVar(name="day_overtime", lb=0, ub=day_overtime_limit)
night_overtime = model.addVar(name="night_overtime", lb=0, ub=night_overtime_limit)

# Total production hours per fabric type
clothing_hours = model.addVar(name="clothing_hours", lb=min_clothing_hours)
curtain_hours = model.addVar(name="curtain_hours", lb=min_curtain_hours)

# Objective: minimize total overtime cost
model.setObjective(
    day_overtime * day_overtime_penalty + night_overtime * night_overtime_penalty,
    GRB.MINIMIZE
)

# Constraints
# Total regular hours must meet utilization ratios
total_regular_hours = day_regular + night_regular
model.addConstr(day_regular >= day_min_utilization_ratio * total_regular_hours, "day_utilization")
model.addConstr(night_regular >= night_min_utilization_ratio * total_regular_hours, "night_utilization")

# Total production time (regular + overtime) must be at least the required hours for each fabric
model.addConstr(clothing_hours == (day_regular + day_overtime) * fabric_production_rate, "clothing_production")
model.addConstr(curtain_hours == (night_regular + night_overtime) * fabric_production_rate, "curtain_production")

# Ensure that the total production hours meet the minimum sales requirements
model.addConstr(clothing_hours >= min_clothing_fabric_sales, "clothing_sales")
model.addConstr(curtain_hours >= min_curtain_fabric_sales, "curtain_sales")

# Solve the model
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
