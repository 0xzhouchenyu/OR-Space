import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read property data
properties = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_risky_multiplier = params['scen_1_risky_multiplier']
scen_2_risky_multiplier = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = int(params['max_risky_properties'])

# Create optimization model
model = gp.Model("RealEstateInvestment")
model.setParam('OutputFlag', 0)

# Decision variables: binary (buy or not)
x = {}
for p in properties:
    x[p['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{p['name']}")

# Decision variables: fraction of property allocated to risky tenants
y = {}
for p in properties:
    y[p['name']] = model.addVar(vtype=GRB.CONTINUOUS, lb=0.0, ub=1.0, name=f"y_{p['name']}")

# Objective: maximize expected annual income
expected_income = 0.0
for p in properties:
    # Dependable income is always the full Annual_Income
    dependable_income = p['income']
    
    # Risky income depends on scenario probabilities and multiplier
    risky_income = y[p['name']] * p['income'] * (scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier)
    
    expected_income += dependable_income + risky_income

model.setObjective(expected_income, GRB.MAXIMIZE)

# Budget constraint
model.addConstr(gp.quicksum(p['cost'] * x[p['name']] for p in properties) <= budget, "BudgetConstraint")

# If Property 4 is purchased, Property 3 cannot be purchased
model.addConstr(x['Property_4'] + x['Property_3'] <= 1, "PropertyExclusionConstraint")

# Total risky exposure must stay within total_risky_budget
model.addConstr(gp.quicksum(p['cost'] * y[p['name']] * x[p['name']] for p in properties) <= total_risky_budget, "TotalRiskyBudgetConstraint")

# Each individual property has its own per_property_risky_cap
for p in properties:
    model.addConstr(y[p['name']] <= per_property_risky_cap, f"PerPropertyRiskyCap_{p['name']}")

# Maximum number of properties that may have any risky tenants
model.addConstr(gp.quicksum(x[p['name']] * (y[p['name']] > 0) for p in properties) <= max_risky_properties, "MaxRiskyPropertiesConstraint")

# Solve
model.optimize()

# Print results
for p in properties:
    print(f"{p['name']}: {int(x[p['name']].X)}")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
