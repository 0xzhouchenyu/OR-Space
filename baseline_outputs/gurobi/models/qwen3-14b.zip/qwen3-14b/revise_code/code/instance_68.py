import os
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def load_distances(data_dir):
    """Load distance data from table_1.csv"""
    filepath = os.path.join(data_dir, 'table_1.csv')
    distances = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            yard = row['Coal_Yard'].strip()
            area = int(row['Residential_Area'].strip())
            dist = float(row['Distance_km'].strip())
            distances[(yard, area)] = dist
    return distances

def load_parameters(data_dir):
    """Load general parameters from general_parameters.csv"""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
distances = load_distances(data_dir)
params = load_parameters(data_dir)

# Extract parameters
min_supply = {
    'A': params['min_coal_yard_A'],
    'B': params['min_coal_yard_B_adjusted']
}

demand = {
    1: params['residential_area_1_demand'],
    2: params['residential_area_2_demand'],
    3: params['residential_area_3_demand']
}

coal_yards = ['A', 'B']
areas = [1, 2, 3]

area3_A_staging_threshold = params['area3_A_staging_threshold']
area3_A_excess_staging_cost = params['area3_A_excess_staging_cost']
min_share_area3_from_A = params['min_share_area3_from_A']

# Create the model
model = gp.Model("Coal_Distribution")
model.setParam('OutputFlag', 0)

# Decision variables: amount of coal shipped from yard i to area j
x = model.addVars(coal_yards, areas, name="x", lb=0)

# Objective: minimize total transportation cost (distance * amount) + extra handling cost for A->3 > 40 tons
obj = gp.quicksum(distances[(yard, area)] * x[yard, area] for yard in coal_yards for area in areas)
# Add extra handling cost for A -> Area 3 beyond 40 tons
obj += area3_A_excess_staging_cost * gp.quicksum(x['A', 3] - area3_A_staging_threshold for _ in range(1) if x['A', 3] > area3_A_staging_threshold)
model.setObjective(obj, GRB.MINIMIZE)

# Constraints:
# 1. Each coal yard must supply at least its minimum requirement
for yard in coal_yards:
    model.addConstr(gp.quicksum(x[yard, area] for area in areas) >= min_supply[yard], name=f"Min_Supply_{yard}")

# 2. Each residential area must receive exactly its demand
for area in areas:
    model.addConstr(gp.quicksum(x[yard, area] for yard in coal_yards) == demand[area], name=f"Demand_{area}")

# 3. Minimum share of Area 3 demand must be supplied by Coal Yard A
model.addConstr(x['A', 3] >= min_share_area3_from_A * demand[3], name="Min_Share_Area3_from_A")

# Solve
model.optimize()

# Print solution details
print(f"Status: {model.status}")
print()
for yard in coal_yards:
    for area in areas:
        val = x[yard, area].X
        if val > 0:
            print(f"Coal Yard {yard} -> Area {area}: {val} tons (distance: {distances[(yard, area)]} km)")

print()
total_supply = {yard: sum(x[yard, area].X for area in areas) for yard in coal_yards}
for yard in coal_yards:
    print(f"Coal Yard {yard} total supply: {total_supply[yard]} tons (min: {min_supply[yard]})")

final_obj_value = model.objVal
print(f"\nFINAL_OBJ_VALUE: {final_obj_value}")
