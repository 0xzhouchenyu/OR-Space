import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Read general parameters
    num_customers = 7
    max_route_length_day = 1000
    route_cost_day = 20
    start_location = 1
    end_location = 1

    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'num_customers':
                num_customers = int(row['Value'])
            elif row['Parameter_Name'] == 'max_route_length_day':
                max_route_length_day = float(row['Value'])
            elif row['Parameter_Name'] == 'route_cost_day':
                route_cost_day = float(row['Value'])

    # Read distance matrix
    D = [[0] * num_customers for _ in range(num_customers)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:
            parts = line.strip().split(',')
            location = int(parts[0]) - 1
            for j in range(1, len(parts)):
                if parts[j] != '-':
                    D[location][j - 1] = int(parts[j])

    # Create model
    model = gp.Model("TwoDayTSP")
    model.setParam('OutputFlag', 0)

    # Binary variables: y[i, d] = 1 if customer i is assigned to day d (d=1 or 2)
    y = model.addVars(range(num_customers), [1, 2], vtype=GRB.BINARY, name="y")

    # Binary variables: x[i, j, d] = 1 if the route on day d goes from i to j
    x = model.addVars(range(num_customers), range(num_customers), [1, 2], vtype=GRB.BINARY, name="x")

    # Continuous variables: u[i, d] for subtour elimination constraints
    u = model.addVars(range(num_customers), [1, 2], vtype=GRB.CONTINUOUS, name="u")

    # Objective function
    obj = gp.quicksum(route_cost_day * gp.quicksum(x[i, j, d] for i in range(num_customers) for j in range(num_customers) if i != j) for d in [1, 2]) + \
          gp.quicksum(D[i][j] * x[i, j, d] for i in range(num_customers) for j in range(num_customers) if i != j for d in [1, 2])
    model.setObjective(obj, GRB.MINIMIZE)

    # Each customer must be assigned to exactly one day
    for i in range(num_customers):
        if i == 0:  # Skip depot
            continue
        model.addConstr(gp.quicksum(y[i, d] for d in [1, 2]) == 1, name=f"Assign_{i}")

    # For each day, if any customer is assigned, then the route starts and ends at depot
    for d in [1, 2]:
        # If no customers are assigned to this day, skip
        model.addConstr(gp.quicksum(y[i, d] for i in range(1, num_customers)) >= 0, name=f"Day_{d}_Active")

        # Route starts at depot
        model.addConstr(gp.quicksum(x[0, j, d] for j in range(num_customers) if j != 0) == gp.quicksum(y[i, d] for i in range(1, num_customers)), name=f"Start_{d}")

        # Route ends at depot
        model.addConstr(gp.quicksum(x[i, 0, d] for i in range(num_customers) if i != 0) == gp.quicksum(y[i, d] for i in range(1, num_customers)), name=f"End_{d}")

        # Each customer assigned to this day is visited exactly once
        for i in range(1, num_customers):
            model.addConstr(gp.quicksum(x[i, j, d] for j in range(num_customers) if j != i) == y[i, d], name=f"Out_{i}_{d}")
            model.addConstr(gp.quicksum(x[j, i, d] for j in range(num_customers) if j != i) == y[i, d], name=f"In_{i}_{d}")

        # Subtour elimination constraints
        for i in range(1, num_customers):
            for j in range(1, num_customers):
                if i != j:
                    model.addConstr(u[i, d] - u[j, d] + (num_customers - 1) * x[i, j, d] <= num_customers - 2, name=f"Subtour_{i}_{j}_{d}")

        # Daily route length constraint
        model.addConstr(gp.quicksum(D[i][j] * x[i, j, d] for i in range(num_customers) for j in range(num_customers) if i != j) <= max_route_length_day, name=f"MaxRoute_{d}")

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
