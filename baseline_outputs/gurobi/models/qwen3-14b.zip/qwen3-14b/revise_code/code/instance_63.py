import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

produce = params["produce_to_transport"]
horse_poll = params["horse_pollution_per_trip"]
bike_poll = params["bicycle_pollution_per_trip"]
cart_poll = params["handcart_pollution_per_trip"]
max_poll = params["max_total_pollution"]
min_horse = params["min_horse_trips"]
horse_cap = params["horse_capacity_per_trip"]
bike_cap = params["bicycle_capacity_per_trip"]
cart_cap = params["handcart_capacity_per_trip"]
min_produce = params["min_total_produce"]
horse_cost = params["horse_cost_per_trip"]
bike_cost = params["bicycle_cost_per_trip"]
cart_cost = params["handcart_cost_per_trip"]
horse_fixed = params["horse_fixed_cost"]
bike_fixed = params["bicycle_fixed_cost"]
cart_fixed = params["handcart_fixed_cost"]
pollution_penalty = params["pollution_penalty_per_unit"]
pollution_threshold = params["horse_pollution_permit_threshold"]
pollution_fee = params["horse_pollution_permit_fee"]

# Create model
model = gp.Model("FarmTransport")
model.setParam("OutputFlag", 0)

# Decision variables
x_horse = model.addVar(vtype=GRB.INTEGER, name="horse_trips")
x_bike = model.addVar(vtype=GRB.INTEGER, name="bike_trips")
x_cart = model.addVar(vtype=GRB.INTEGER, name="cart_trips")

# Binary variable: y=1 means bicycle chosen, y=0 means handcart chosen
y = model.addVar(vtype=GRB.BINARY, name="choose_bike")

M = 10000  # Big-M

# Objective function
# Total cost includes:
# - Variable costs for trips
# - Fixed setup costs if the transport is used
# - Pollution penalty per unit
# - One-time permit fee if pollution exceeds threshold
model.setObjective(
    (horse_cost * x_horse + bike_cost * x_bike + cart_cost * x_cart) +
    (horse_fixed * (x_horse > 0) + bike_fixed * y + cart_fixed * (1 - y)) +
    (horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart) * pollution_penalty +
    pollution_fee * (gp.quicksum([horse_poll * x_horse, bike_poll * x_bike, cart_poll * x_cart]) > pollution_threshold),
    GRB.MINIMIZE
)

# Constraints
# Must transport at least min_produce
model.addConstr(horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce, "min_produce")

# Pollution constraint (must not exceed max_total_pollution)
model.addConstr(horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart <= max_poll, "max_pollution")

# Minimum horse trips
model.addConstr(x_horse >= min_horse, "min_horse_trips")

# Either bicycle or handcart, not both
model.addConstr(x_bike <= M * y, "bike_choice")
model.addConstr(x_cart <= M * (1 - y), "cart_choice")

# Solve
model.optimize()

# Print results
print(f"Horse trips: {x_horse.X}")
print(f"Bicycle trips: {x_bike.X}")
print(f"Handcart trips: {x_cart.X}")
print(f"Choose bicycle: {y.X}")
print(f"Total produce: {horse_cap * x_horse.X + bike_cap * x_bike.X + cart_cap * x_cart.X}")
print(f"Total pollution: {horse_poll * x_horse.X + bike_poll * x_bike.X + cart_poll * x_cart.X}")
print(f"FINAL_OBJ_VALUE: {model.objVal}")
