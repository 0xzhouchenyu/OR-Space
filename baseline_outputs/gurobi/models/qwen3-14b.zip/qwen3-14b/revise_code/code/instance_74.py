import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv")) as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

    precedences = []
    with open(os.path.join(data_dir, "table_1.csv")) as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row["Predecessor"].strip(), row["Successor"].strip()))

    activities = ["A", "B", "C", "D", "E", "F", "G"]
    dur = {a: int(params[f"activity_{a}_duration"]) for a in activities}
    work_cost = params["work_cost_per_day"]
    machine_cost = params["machine_rental_cost_per_day"]
    e_overtime_reduction = params["activity_E_overtime_reduction"]
    e_overtime_cost = params["activity_E_overtime_cost"]
    e_followup_review_cost = params["activity_E_followup_review_cost"]

    model = gp.Model("Project_Cost_Minimization")
    model.setParam("OutputFlag", 0)

    S = model.addVars(activities, name="S", lb=0)
    T = model.addVar(name="T", lb=0)
    use_overtime_E = model.addVar(vtype=GRB.BINARY, name="use_overtime_E")

    # Objective function
    model.setObjective(
        work_cost * T +
        machine_cost * (S["B"] + dur["B"] - S["A"]) +
        e_overtime_cost * use_overtime_E +
        e_followup_review_cost * use_overtime_E,
        GRB.MINIMIZE
    )

    # Precedence constraints
    for pred, succ in precedences:
        model.addConstr(S[succ] >= S[pred] + dur[pred])

    # Duration of E with overtime
    model.addConstr(dur["E"] - e_overtime_reduction * use_overtime_E <= S["E"] + dur["E"] - S["E"])

    # Completion time of project
    model.addConstr(T >= S["C"] + dur["C"])
    model.addConstr(T >= S["B"] + dur["B"])

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.objVal}")

solve()
