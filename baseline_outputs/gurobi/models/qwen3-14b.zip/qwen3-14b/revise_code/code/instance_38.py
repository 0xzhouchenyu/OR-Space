import os
import gurobipy as gp
from gurobipy import GRB
from itertools import permutations
from utils import load_processing_times

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    processing_times = load_processing_times(os.path.join(data_dir, "table_1.csv"))
    
    # Load general parameters
    general_params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row["Parameter_Name"]] = float(row["Value"])
    
    n_products = len(processing_times)
    n_machines = len(processing_times[0])
    
    # Create Gurobi model
    model = gp.Model("flow_shop_scheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: sequence of products (permutation)
    # We will use binary variables to represent the permutation
    x = model.addVars(n_products, n_products, vtype=GRB.BINARY, name="x")
    
    # Ensure each product is scheduled exactly once
    for i in range(n_products):
        model.addConstr(gp.quicksum(x[i, j] for j in range(n_products)) == 1, name=f"assign_{i}")
    
    for j in range(n_products):
        model.addConstr(gp.quicksum(x[i, j] for i in range(n_products)) == 1, name=f"assign_to_{j}")
    
    # Compute completion times for each job on each machine
    # We need to compute the makespan and overtime penalties
    # First, define variables for completion times
    C = model.addVars(n_products, n_machines, name="C")
    
    # Define variables for overtime usage on each machine
    O = model.addVars(n_machines, name="O")
    
    # Define variable for the review fee if Machine 1's overtime exceeds threshold
    review_fee = model.addVar(name="review_fee", lb=0, ub=general_params["machine1_overtime_review_fee"], vtype=GRB.CONTINUOUS)
    
    # Objective function: minimize makespan + overtime penalty + review fee
    objective = C[n_products - 1, n_machines - 1]
    
    for m in range(n_machines):
        objective += general_params["overtime_penalty_per_unit"] * O[m]
    
    objective += review_fee
    
    model.setObjective(objective, GRB.MINIMIZE)
    
    # Constraints for completion times
    for i in range(n_products):
        for j in range(n_machines):
            # Start time for job i on machine j
            start_time = 0
            if i > 0:
                start_time = max(start_time, C[i - 1, j])  # previous job on same machine
            if j > 0:
                start_time = max(start_time, C[i, j - 1])  # same job on previous machine
            
            # Completion time for job i on machine j
            model.addConstr(C[i, j] == start_time + processing_times[i][j], name=f"C_{i}_{j}")
    
    # Constraints for overtime usage
    for m in range(n_machines):
        # Regular availability limit
        regular_limit = general_params[f"time_window_{m + 1}"]
        # Total time used on machine m
        total_time_used = gp.quicksum(
            processing_times[i][m] for i in range(n_products)
        )
        
        # Overtime usage is max(0, total_time_used - regular_limit)
        model.addConstr(O[m] >= total_time_used - regular_limit, name=f"overtime_{m}")
        model.addConstr(O[m] >= 0, name=f"overtime_non_negative_{m}")
    
    # Constraint for review fee on Machine 1
    # If overtime on Machine 1 exceeds 1 second, add the review fee
    model.addConstr(review_fee >= general_params["machine1_overtime_review_fee"] * (O[0] - general_params["machine1_overtime_review_threshold"]), name="review_fee_constraint")
    model.addConstr(review_fee <= general_params["machine1_overtime_review_fee"] * (O[0] - general_params["machine1_overtime_review_threshold"] + general_params["M_1"]), name="review_fee_upper_bound")
    
    # Solve the model
    model.optimize()
    
    # Extract the optimal sequence from the solution
    sequence = [i for i in range(n_products)]
    for i in range(n_products):
        for j in range(n_products):
            if x[i, j].x > 0.5:
                sequence[j] = i
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
