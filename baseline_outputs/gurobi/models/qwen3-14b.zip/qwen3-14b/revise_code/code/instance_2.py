import os
import csv
import gurobipy as gp
from gurobipy import GRB
from utils import load_parameters

# Load parameters from CSV files
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")
params = load_parameters(params_file)

a1 = params['a1']
a2 = params['a2']
training_capacity = params['training_capacity_per_jet']
dual_use_training_efficiency = params['dual_use_training_efficiency']
training_intensity_cap = params['training_intensity_cap']
combat_jet_min_year2 = params['combat_jet_min_year2']
combat_weight = params['combat_weight']
training_weight = params['training_weight']

# Create a Gurobi model
model = gp.Model("fighter_jet_allocation")

# Decision variables
# x1: number of training-only jets in year 1
# y1: number of dual-use jets in year 1
# x2: number of training-only jets in year 2
# y2: number of dual-use jets in year 2
# c1: number of combat-only jets in year 1
# c2: number of combat-only jets in year 2

x1 = model.addVar(name="x1", lb=0)
y1 = model.addVar(name="y1", lb=0)
x2 = model.addVar(name="x2", lb=0)
y2 = model.addVar(name="y2", lb=0)
c1 = model.addVar(name="c1", lb=0)
c2 = model.addVar(name="c2", lb=0)

# Total jets available each year
model.addConstr(x1 + y1 + c1 <= a1, name="year1_total_jets")
model.addConstr(x2 + y2 + c2 <= a2, name="year2_total_jets")

# Training intensity constraints (fraction of jets in training or dual-use)
model.addConstr((x1 + y1) / (x1 + y1 + c1) <= training_intensity_cap, name="year1_training_intensity")
model.addConstr((x2 + y2) / (x2 + y2 + c2) <= training_intensity_cap, name="year2_training_intensity")

# Combat jet minimum in year 2
model.addConstr(c2 >= combat_jet_min_year2, name="year2_combat_min")

# Objective function: maximize weighted sum of combat jets and trained pilots
# Combat jets: c1 + c2
# Trained pilots:
# Year 1: training-only jets (x1 * training_capacity) + dual-use jets (y1 * training_capacity * dual_use_training_efficiency)
# Year 2: training-only jets (x2 * training_capacity) + dual-use jets (y2 * training_capacity * dual_use_training_efficiency)
# But training duration is 2 years, so pilots trained in year 1 can be used in year 2
# So total trained pilots = (x1 + y1 * dual_use_training_efficiency) * training_capacity + (x2 + y2 * dual_use_training_efficiency) * training_capacity

objective = combat_weight * (c1 + c2) + training_weight * training_capacity * (
    (x1 + y1 * dual_use_training_efficiency) + (x2 + y2 * dual_use_training_efficiency)
)

model.setObjective(objective, GRB.MAXIMIZE)

# Optimize the model
model.setParam('OutputFlag', 0)
model.optimize()

# Print the final objective value
final_obj_value = model.objVal
print(f"FINAL_OBJ_VALUE: {final_obj_value}")
