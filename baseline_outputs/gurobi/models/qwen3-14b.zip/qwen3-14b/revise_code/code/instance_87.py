import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_file = os.path.join(data_dir, "general_parameters.csv")
    params = load_parameters(params_file)

    # Extract parameters
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    base_fleet_a = params['base_fleet_type_a']
    base_fleet_b = params['base_fleet_type_b']
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    type_b_threshold = params['type_b_recovery_threshold']
    type_b_fee = params['type_b_recovery_fee']
    total_threshold = params['total_fleet_surge_threshold']
    total_fee = params['total_fleet_surge_fee']

    # Create the optimization model
    model = gp.Model("TruckRentalRevised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = model.addVar(vtype=GRB.INTEGER, name="TypeA_trucks", lb=0)
    y = model.addVar(vtype=GRB.INTEGER, name="TypeB_trucks", lb=0)

    # Objective function
    obj = (
        cost_a * x + cost_b * y +
        penalty_a * max(0, x - base_fleet_a) +
        penalty_b * max(0, y - base_fleet_b) +
        gp.quicksum(type_b_fee if y > type_b_threshold else 0) +
        (total_fee if (x + y) > total_threshold else 0)
    )
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedRequirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedRequirement")

    # Optimize the model
    model.optimize()

    # Print results
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
