import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']
T1_normal = params['available_time_process_1']
T2_normal = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']
c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
bigM_disposal = params['bigM_disposal']
disposal_cost_base = params['disposal_cost_per_unit_c']
disposal_cost_high = params['disposal_cost_per_unit_c_high']
profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

# Create the model
model = gp.Model("MaxProfit")
model.setParam('OutputFlag', 0)

# Decision variables
xA = model.addVar(name="xA", lb=0)  # units of product A
xB = model.addVar(name="xB", lb=0)  # units of product B
cSold = model.addVar(name="cSold", lb=0)  # units of by-product C sold
cDisposed = model.addVar(name="cDisposed", lb=0)  # units of by-product C disposed

# Binary variables for high-throughput mode
highThroughput1 = model.addVar(vtype=GRB.BINARY, name="highThroughput1")
highThroughput2 = model.addVar(vtype=GRB.BINARY, name="highThroughput2")

# Objective: maximize total profit
# Profit from A + Profit from B + Profit from selling C - Cost of disposing C
# Disposal cost is base up to threshold_c, then higher cost beyond that
# Use big-M method to model the piecewise disposal cost
# Introduce auxiliary variables for the two parts of the disposal cost
cDisposedBase = model.addVar(lb=0, ub=threshold_c, name="cDisposedBase")
cDisposedHigh = model.addVar(lb=0, name="cDisposedHigh")

# Total disposal is cDisposedBase + cDisposedHigh = cDisposed
model.addConstr(cDisposedBase + cDisposedHigh == cDisposed, "TotalDisposal")

# Ensure cDisposedBase <= threshold_c
model.addConstr(cDisposedBase <= threshold_c, "MaxBaseDisposal")

# Ensure cDisposedHigh >= cDisposed - threshold_c (if cDisposed > threshold_c)
model.addConstr(cDisposedHigh >= cDisposed - threshold_c, "MinHighDisposal")
model.addConstr(cDisposedHigh >= 0, "NonNegativeHighDisposal")

# Objective function
model.setObjective(
    profit_a * xA +
    profit_b * xB +
    profit_c * cSold -
    disposal_cost_base * cDisposedBase -
    disposal_cost_high * cDisposedHigh,
    GRB.MAXIMIZE
)

# Constraints
# Process time constraints with high-throughput selection
# Process 1 time constraint
model.addConstr(
    a_p1 * xA + b_p1 * xB <= T1_normal * (1 - highThroughput1) + T1_high * highThroughput1,
    "Process1Time"
)

# Process 2 time constraint
model.addConstr(
    a_p2 * xA + b_p2 * xB <= T2_normal * (1 - highThroughput2) + T2_high * highThroughput2,
    "Process2Time"
)

# At most one reaction stage may use high-throughput setting
model.addConstr(highThroughput1 + highThroughput2 <= 1, "SingleHighThroughput")

# By-product C balance: total C produced = C sold + C disposed
model.addConstr(cSold + cDisposed == c_per_b * xB, "ByproductBalance")

# Maximum C that can be sold
model.addConstr(cSold <= max_c_sales, "MaxCSales")

# Optimize the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
