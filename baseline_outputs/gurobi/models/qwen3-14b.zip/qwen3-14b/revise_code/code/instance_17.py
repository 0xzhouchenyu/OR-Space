import os
import gurobipy as gp
from gurobipy import GRB
import csv


def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    parts = []
    with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
    
    # Load general_parameters.csv
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    return parts, params


def fuel_per_heavy_bomb(distance, params):
    eff_heavy = params['fuel_efficiency_heavy_bomb']
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    return distance / eff_heavy + distance / eff_empty + takeoff_landing


def fuel_per_light_bomb(distance, params):
    eff_light = params['fuel_efficiency_light_bomb']
    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    return distance / eff_light + distance / eff_empty + takeoff_landing


def prob_destroy_part(x_heavy, x_light, p_heavy, p_light):
    return 1.0 - (1.0 - p_heavy) ** x_heavy * (1.0 - p_light) ** x_light


def prob_at_least_k(probs, k):
    n = len(probs)
    dp = [0.0] * (n + 1)
    dp[0] = 1.0
    for i in range(n):
        new_dp = [0.0] * (n + 1)
        for j in range(i + 2):
            new_dp[j] += dp[j] * (1.0 - probs[i])
            if j > 0:
                new_dp[j] += dp[j - 1] * probs[i]
        dp = new_dp
    return sum(dp[j] for j in range(k, n + 1))


def main():
    parts, params = load_data()
    n = len(parts)

    max_heavy = int(params['max_heavy_bombs'])
    max_light = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts = int(params['min_parts_destroyed'])
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    sortie_fuel_overhead_A = params['sortie_fuel_overhead_A']
    sortie_fuel_overhead_B = params['sortie_fuel_overhead_B']
    scenario_prob_A = params['scenario_prob_A']
    scenario_prob_B = params['scenario_prob_B']

    fuel_h = [fuel_per_heavy_bomb(p['distance'], params) for p in parts]
    fuel_l = [fuel_per_light_bomb(p['distance'], params) for p in parts]

    model = gp.Model("BombAllocationRobust")
    model.setParam('OutputFlag', 0)

    # Decision variables: xh[i] = number of heavy bombs on part i, xl[i] = number of light bombs on part i
    xh = model.addVars(n, name="xh", vtype=GRB.INTEGER, lb=0, ub=max_heavy)
    xl = model.addVars(n, name="xl", vtype=GRB.INTEGER, lb=0, ub=max_light)

    # Total sorties is the sum of all bombing runs
    total_sorties = gp.quicksum(xh[i] + xl[i] for i in range(n))
    model.addConstr(total_sorties <= max_sorties_A, "SortiesA")
    model.addConstr(total_sorties <= max_sorties_B, "SortiesB")

    # Fuel constraints for both scenarios
    fuel_used_A = gp.quicksum((fuel_h[i] + sortie_fuel_overhead_A) * xh[i] + (fuel_l[i] + sortie_fuel_overhead_A) * xl[i] for i in range(n))
    fuel_used_B = gp.quicksum((fuel_h[i] + sortie_fuel_overhead_B) * xh[i] + (fuel_l[i] + sortie_fuel_overhead_B) * xl[i] for i in range(n))
    model.addConstr(fuel_used_A <= fuel_limit, "FuelA")
    model.addConstr(fuel_used_B <= fuel_limit, "FuelB")

    # Compute probabilities of destroying each part
    p_destroy = []
    for i in range(n):
        p = prob_destroy_part(xh[i], xl[i], parts[i]['p_heavy'], parts[i]['p_light'])
        p_destroy.append(p)

    # Compute probability of at least min_parts destroyed
    prob_success = prob_at_least_k(p_destroy, min_parts)

    # Objective function: maximize weighted expected success probability
    model.setObjective(prob_success, GRB.MAXIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        best_obj = model.objVal
        print(f"FINAL_OBJ_VALUE: {best_obj:.4f}")
    else:
        print("No optimal solution found.")


if __name__ == "__main__":
    main()
