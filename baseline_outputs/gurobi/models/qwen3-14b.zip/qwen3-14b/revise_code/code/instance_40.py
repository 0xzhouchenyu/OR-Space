import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    # Load parameters from CSV
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(csv_path)
    params = dict(zip(df['Parameter_Name'], df['Value']))

    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # Create model
    model = gp.Model("Maximize_GDP")
    model.setParam('OutputFlag', 0)

    # Decision variables: production levels for each commodity
    x = {c: model.addVar(name=f"x_{c}", lb=0) for c in commodities}

    # Apply production upper bounds if they exist
    for c in commodities:
        for suffix in ['_production_limit', '_limit', '_capacity']:
            key = f"{c}{suffix}"
            if key in params:
                x[c].UB = params[key]

    # Decision variables: overtime labor used
    overtime_used = model.addVar(name="overtime_used", lb=0, ub=params['overtime_cap'])

    # Decision variables: imports for each commodity
    import_vars = {c: model.addVar(name=f"import_{c}", lb=0, ub=params['import_quota']) for c in commodities}

    # Net export of each commodity = Production - Domestic Consumption
    # Domestic consumption of commodity c = sum over all other commodities c' of (c'_c_requirement * x[c'])
    net_export = {}
    for c in commodities:
        consumed = gp.quicksum(
            params.get(f"{c_prime}_{c}_requirement", 0.0) * x[c_prime]
            for c_prime in commodities
        )
        net_export[c] = x[c] - consumed

    # Import costs
    imports_cost = gp.quicksum(
        params[f"{c}_price"] * import_premium_ratio * import_vars[c] for c in commodities
    )

    # Labor cost: regular + overtime
    regular_labor_cost = gp.quicksum(
        params.get(f"{c}_labor_requirement", 0.0) * x[c] * params[f"{c}_price"] for c in commodities
    )
    overtime_labor_cost = overtime_used * params['overtime_wage']

    # Objective: GDP = Export revenue - Import costs - Labor costs
    export_revenue = gp.quicksum(params[f"{c}_price"] * net_export[c] for c in commodities)
    total_cost = imports_cost + regular_labor_cost + overtime_labor_cost
    gdp = export_revenue - total_cost
    model.setObjective(gdp, GRB.MAXIMIZE)

    # Constraints:

    # 1. Net export >= 0 for each commodity (domestic production must satisfy domestic demand)
    for c in commodities:
        model.addConstr(net_export[c] >= -import_vars[c], f"Domestic_Demand_{c}")

    # 2. Labor constraint: regular + overtime
    labor_used = gp.quicksum(
        params.get(f"{c}_labor_requirement", 0.0) * x[c] for c in commodities
    )
    model.addConstr(labor_used + overtime_used <= params['labor_force'] + params['overtime_cap'], "Labor_Limit")

    # 3. Import constraints: cannot exceed quota
    for c in commodities:
        model.addConstr(import_vars[c] <= params['import_quota'], f"Import_Quota_{c}")

    # Solve the model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {round(model.objVal, 3)}")

if __name__ == '__main__':
    solve()
