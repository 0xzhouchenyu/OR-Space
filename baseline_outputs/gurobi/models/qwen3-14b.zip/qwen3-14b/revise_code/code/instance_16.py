import os
import gurobipy as gp
from gurobipy import GRB

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

def load_monthly_data(filepath):
    """Load monthly purchasing and selling price data."""
    months = []
    purchasing_prices = {}
    selling_prices = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            month = int(row['Month'])
            months.append(month)
            purchasing_prices[month] = float(row['Purchasing_Price_Yuan'])
            selling_prices[month] = float(row['Selling_Price_Yuan'])
    
    return months, purchasing_prices, selling_prices

def load_general_parameters(filepath):
    """Load general parameters."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

# Load data files
months, purchasing_prices, selling_prices = load_monthly_data(os.path.join(data_dir, 'table_1.csv'))
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params['fixed_ordering_cost']
month2_bulk_receiving_threshold = params['month2_bulk_receiving_threshold']
month2_bulk_receiving_fee = params['month2_bulk_receiving_fee']

# Create the LP problem
model = gp.Model("Maximize_Profit")
model.setParam('OutputFlag', 0)

# Decision variables
# x[m] = units purchased at the beginning of month m
# s[m] = units sold during month m
x = {m: model.addVar(name=f"purchase_{m}", lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS) for m in months}
s = {m: model.addVar(name=f"sell_{m}", lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS) for m in months}

# Inventory at the end of each month (auxiliary variables)
# inv[m] = inventory at end of month m
inv = {m: model.addVar(name=f"inventory_{m}", lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS) for m in months}

# Objective: maximize total profit = sum of (selling revenue - purchasing cost) - fixed ordering costs - bulk receiving fee
objective = gp.quicksum(selling_prices[m] * s[m] - purchasing_prices[m] * x[m] for m in months)
objective -= gp.quicksum(fixed_ordering_cost * gp.quicksum(x[m] > 0 for m in months) for m in months)
# Special handling for February bulk receiving fee
objective -= month2_bulk_receiving_fee * (x[2] > month2_bulk_receiving_threshold)

model.setObjective(objective, GRB.MAXIMIZE)

# Constraints
for m in months:
    # Inventory balance: inv[m] = inv[m-1] + x[m] - s[m]
    if m == months[0]:
        prev_inv = initial_stock
    else:
        prev_inv = inv[m - 1]
    
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], name=f"inventory_balance_{m}")
    
    # Warehouse capacity constraint: inventory after purchasing (before selling) <= warehouse_capacity
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, name=f"warehouse_after_purchase_{m}")
    
    # End-of-month inventory also cannot exceed warehouse capacity
    model.addConstr(inv[m] <= warehouse_capacity, name=f"warehouse_end_{m}")
    
    # Can't sell more than what's available (prev_inv + x[m])
    model.addConstr(s[m] <= prev_inv + x[m], name=f"sell_limit_{m}")

# Solve
model.optimize()

# Print results
for m in months:
    print(f"Month {m}: Purchase = {x[m].X}, Sell = {s[m].X}, End Inventory = {inv[m].X}")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
