import os
import gurobipy as gp
from gurobipy import GRB

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

def load_table_1(data_dir):
    """Load the weekly demand, capacity, and cost data."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    weeks = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })
    return weeks

def load_general_parameters(data_dir):
    """Load general parameters."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

# Load data
weeks_data = load_table_1(data_dir)
params = load_general_parameters(data_dir)

storage_cost = params['storage_cost_per_thousand_boxes']
fixed_setup_cost = params['fixed_setup_cost']
week2_push_threshold = params['week2_push_threshold']
week3_capacity_loss_after_week2_push = params['week3_capacity_loss_after_week2_push']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']

n_weeks = len(weeks_data)

# Create the model
model = gp.Model("Beverage_Production_Planning")
model.setParam('OutputFlag', 0)

# Decision variables
# x[t] = production in week t (in thousand boxes)
# s[t] = inventory at end of week t (in thousand boxes)
x = [model.addVar(name=f"x_{t+1}", lb=0, ub=weeks_data[t]['capacity']) for t in range(n_weeks)]
s = [model.addVar(name=f"s_{t+1}", lb=0) for t in range(n_weeks)]

# Binary variable to indicate if production occurs in a week
y = [model.addVar(vtype=GRB.BINARY, name=f"y_{t+1}") for t in range(n_weeks)]

# Objective: minimize total production cost + storage cost + fixed setup cost + micro-clean fee
obj = gp.quicksum(weeks_data[t]['cost'] * x[t] for t in range(n_weeks)) + \
      gp.quicksum(storage_cost * s[t] for t in range(n_weeks)) + \
      gp.quicksum(fixed_setup_cost * y[t] for t in range(n_weeks))

# Add micro-clean fee for Week 2 if production exceeds threshold
obj += week2_microclean_fee * (gp.quicksum([1 for t in range(n_weeks) if t == 1 and x[t] > week2_microclean_threshold]) >= 1)

model.setObjective(obj, GRB.MINIMIZE)

# Constraints: inventory balance
# Assume initial inventory is 0
for t in range(n_weeks):
    if t == 0:
        model.addConstr(x[t] - s[t] == weeks_data[t]['demand'], name=f"balance_week_{t+1}")
    else:
        model.addConstr(s[t-1] + x[t] - s[t] == weeks_data[t]['demand'], name=f"balance_week_{t+1}")

# Ensure that production can only occur if y[t] is 1
for t in range(n_weeks):
    model.addConstr(x[t] <= weeks_data[t]['capacity'] * y[t], name=f"production_if_setup_week_{t+1}")

# Week 2-to-Week 3 recovery rule: if Week 2 production exceeds push threshold, reduce Week 3 capacity
if n_weeks >= 3:
    model.addConstr(x[1] <= week2_push_threshold + (weeks_data[2]['capacity'] - week3_capacity_loss_after_week2_push) * (1 - y[1]), name="week3_capacity_recovery")

# Solve
model.optimize()

# Print results
final_obj_value = model.objVal
print(f"FINAL_OBJ_VALUE: {final_obj_value}")
