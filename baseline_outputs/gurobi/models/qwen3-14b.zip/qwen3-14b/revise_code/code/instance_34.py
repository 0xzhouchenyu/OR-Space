import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_goods_data, load_parameters

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
goods = load_goods_data(os.path.join(data_dir, "table_1.csv"))
params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

max_container_capacity = params["max_container_capacity"]
min_container_load = params["min_container_load"]
min_d_per_container = int(params["min_d_goods_per_container"])
min_c_per_a = int(params["min_c_per_a"])

goods_types = list(goods.keys())
quantities = {g: goods[g]["quantity"] for g in goods_types}
weights = {g: goods[g]["weight"] for g in goods_types}

# Upper bound on number of containers
# We need at least enough containers to supply 10 D goods each
# D has 90 units, so max containers from D constraint: ceil(90/10) = 9
# But we also have E which may require more containers due to fragility
max_containers = 20  # generous upper bound

N = range(max_containers)

model = gp.Model("ContainerMinimization")
model.setParam('OutputFlag', 0)

# Decision variables
# x[g][j] = number of units of goods type g in container j
x = {}
for g in goods_types:
    x[g] = {}
    for j in N:
        x[g][j] = model.addVar(vtype=GRB.INTEGER, name=f"x_{g}_{j}", lb=0)

# y[j] = 1 if container j is used
y = {}
for j in N:
    y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")

# Objective: minimize number of containers
model.setObjective(gp.quicksum(y[j] for j in N), GRB.MINIMIZE)

# All goods must be transported
for g in goods_types:
    model.addConstr(gp.quicksum(x[g][j] for j in N) == quantities[g], name=f"demand_{g}")

# Container capacity constraint
for j in N:
    # If container j contains E, its capacity is 45 tons; otherwise, it's 60 tons
    e_in_container = gp.quicksum(x["E"][j]) > 0
    capacity = gp.quicksum(weights[g] * x[g][j] for g in goods_types)
    model.addConstr(capacity <= (45 if e_in_container else 60) * y[j], name=f"max_cap_{j}")

# Minimum load constraint
for j in N:
    total_weight = gp.quicksum(weights[g] * x[g][j] for g in goods_types)
    model.addConstr(total_weight >= min_container_load * y[j], name=f"min_load_{j}")

# Minimum D goods per container (if container is used)
for j in N:
    model.addConstr(x["D"][j] >= min_d_per_container * y[j], name=f"min_D_{j}")

# If A goods are loaded, at least 1 C good must be loaded
M_A = quantities["A"]
z = {}
for j in N:
    z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{j}")
    model.addConstr(x["A"][j] <= M_A * z[j], name=f"A_indicator_{j}")
    model.addConstr(x["C"][j] >= min_c_per_a * z[j], name=f"C_if_A_{j}")

# Symmetry breaking
for j in range(len(N) - 1):
    model.addConstr(y[j] >= y[j + 1], name=f"symmetry_{j}")

# Solve
model.optimize()

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
