import os
import gurobipy as gp
from gurobipy import GRB
import csv

def load_parameters(filepath):
    """Load general parameters from CSV into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

num_students = int(params['num_students'])
num_buses = int(params['num_buses'])
bus_capacity = int(params['bus_capacity'])
num_minibuses = int(params['num_minibuses'])
minibus_capacity = int(params['minibus_capacity'])
num_drivers = int(params['num_drivers'])
bus_rental_cost = float(params['bus_rental_cost'])
minibus_rental_cost = float(params['minibus_rental_cost'])

# Create the optimization model
model = gp.Model("SchoolTrip")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVar(name="buses", vtype=GRB.INTEGER, lb=0, ub=num_buses)
y = model.addVar(name="minibuses", vtype=GRB.INTEGER, lb=0, ub=num_minibuses)

# Objective: minimize total rental cost
model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

# Constraints
# Must transport all students
model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, "StudentCapacity")

# Total vehicles (drivers) constraint
model.addConstr(x + y <= num_drivers, "DriverLimit")

# At least two buses per minibus
model.addConstr(x >= 2 * y, "BusPerMinibus")

# Minimum of one minibus
model.addConstr(y >= 1, "MinMinibus")

# Optimize the model
model.optimize()

# Output results
obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
