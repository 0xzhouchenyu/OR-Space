import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load the bandwidth table
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    filepath = os.path.join(data_dir, "table_1.csv")
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        
        bandwidth = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                bandwidth[(row_node, col_node)] = bw
    
    source = 'A'
    intermediate = 'C'
    target = 'E'
    
    # Create a Gurobi model
    model = gp.Model("min_total_cost")
    model.setParam('OutputFlag', 0)
    
    # Create variables for each edge (i, j) indicating whether it is used in the path
    edges = [(i, j) for i in nodes for j in nodes if i != j and bandwidth.get((i, j), 0) > 0]
    x = model.addVars(edges, vtype=GRB.BINARY, name="x")
    
    # Define cost of each edge as 100 - bandwidth
    edge_cost = {(i, j): 100 - bandwidth[(i, j)] for i, j in edges}
    
    # Objective: minimize total routing cost
    model.setObjective(gp.quicksum(edge_cost[i, j] * x[i, j] for i, j in edges), GRB.MINIMIZE)
    
    # Constraints to ensure a valid path from A to E through C without loops
    
    # Flow conservation at intermediate node C
    # Inflow to C must equal outflow from C
    inflow_to_C = gp.quicksum(x[i, intermediate] for i in nodes if i != intermediate)
    outflow_from_C = gp.quicksum(x[intermediate, j] for j in nodes if j != intermediate)
    model.addConstr(inflow_to_C == outflow_from_C, "flow_conservation_C")
    
    # Flow conservation at all other nodes except A and E
    for node in nodes:
        if node == source or node == target or node == intermediate:
            continue
        inflow = gp.quicksum(x[i, node] for i in nodes if i != node)
        outflow = gp.quicksum(x[node, j] for j in nodes if j != node)
        model.addConstr(inflow == outflow, f"flow_conservation_{node}")
    
    # Flow conservation at source A: outflow must be 1
    outflow_from_A = gp.quicksum(x[source, j] for j in nodes if j != source)
    model.addConstr(outflow_from_A == 1, "flow_conservation_A")
    
    # Flow conservation at target E: inflow must be 1
    inflow_to_E = gp.quicksum(x[i, target] for i in nodes if i != target)
    model.addConstr(inflow_to_E == 1, "flow_conservation_E")
    
    # Ensure that the path goes through C
    # All paths from A to E must pass through C
    # This is enforced by flow conservation constraints above
    
    # Solve the model
    model.optimize()
    
    # Extract the optimal path
    path = []
    current = source
    while current != target:
        for j in nodes:
            if j != current and x[current, j].x > 0.5:
                path.append((current, j))
                current = j
                break
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
