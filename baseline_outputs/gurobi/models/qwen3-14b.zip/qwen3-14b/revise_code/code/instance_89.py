import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

# Load general parameters
params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
profit_A = params['profit_per_kg_product_A']
profit_B = params['profit_per_kg_product_B']
hours_A = params['hours_per_kg_product_A']
hours_B = params['hours_per_kg_product_B']
min_ratio_B_to_A = params['min_output_ratio_product_B_to_A']
storage_ratio_A_to_B = params['storage_space_ratio_product_A_to_B']
max_storage_A_week1 = params['max_storage_product_A_equiv_week_1']
max_storage_A_week2 = params['max_storage_product_A_equiv_week_2']
initial_inventory_A = params['initial_inventory_A']
initial_inventory_B = params['initial_inventory_B']
storage_cost_A = params['storage_cost_per_kg_A']
storage_cost_B = params['storage_cost_per_kg_B']
promo_bonus_A = params['promo_profit_bonus_A']
promo_bonus_B = params['promo_profit_bonus_B']
max_promo_A = params['max_promotions_product_A']
max_promo_B = params['max_promotions_product_B']

# Production hours per week
max_hours_week1 = params['max_production_hours_week_1']
max_hours_week2 = params['max_production_hours_week_2']

# Create the model
model = gp.Model("Two_Week_Production_Plan")
model.setParam('OutputFlag', 0)

# Decision variables
# Production quantities (kg) for each product in each week
prod_A_week1 = model.addVar(name="prod_A_week1", lb=0)
prod_B_week1 = model.addVar(name="prod_B_week1", lb=0)
prod_A_week2 = model.addVar(name="prod_A_week2", lb=0)
prod_B_week2 = model.addVar(name="prod_B_week2", lb=0)

# Inventory at end of each week
inv_A_week1 = model.addVar(name="inv_A_week1", lb=0)
inv_B_week1 = model.addVar(name="inv_B_week1", lb=0)
inv_A_week2 = model.addVar(name="inv_A_week2", lb=0)
inv_B_week2 = model.addVar(name="inv_B_week2", lb=0)

# Promotions: binary variables indicating if a promotion is applied in a week
promo_A_week1 = model.addVar(vtype=GRB.BINARY, name="promo_A_week1")
promo_A_week2 = model.addVar(vtype=GRB.BINARY, name="promo_A_week2")
promo_B_week1 = model.addVar(vtype=GRB.BINARY, name="promo_B_week1")
promo_B_week2 = model.addVar(vtype=GRB.BINARY, name="promo_B_week2")

# Objective function: maximize total profit
obj = (
    (profit_A + promo_bonus_A * promo_A_week1) * prod_A_week1 +
    (profit_B + promo_bonus_B * promo_B_week1) * prod_B_week1 +
    (profit_A + promo_bonus_A * promo_A_week2) * prod_A_week2 +
    (profit_B + promo_bonus_B * promo_B_week2) * prod_B_week2 -
    storage_cost_A * inv_A_week1 -
    storage_cost_B * inv_B_week1 -
    storage_cost_A * inv_A_week2 -
    storage_cost_B * inv_B_week2
)

model.setObjective(obj, GRB.MAXIMIZE)

# Constraints

# Week 1 production time constraint
model.addConstr(hours_A * prod_A_week1 + hours_B * prod_B_week1 <= max_hours_week1, "Production_Hours_Week1")

# Week 2 production time constraint
model.addConstr(hours_A * prod_A_week2 + hours_B * prod_B_week2 <= max_hours_week2, "Production_Hours_Week2")

# Market demand ratio in each week
model.addConstr(prod_B_week1 >= min_ratio_B_to_A * prod_A_week1, "Market_Demand_Week1")
model.addConstr(prod_B_week2 >= min_ratio_B_to_A * prod_A_week2, "Market_Demand_Week2")

# Storage capacity constraints (week 1 and week 2)
# Storage space for A is 4 times that of B per kg
# Max storage capacity expressed in terms of product A is 4 kg per week
# So, 4 * x_A + x_B <= 16 units of space per week
model.addConstr(
    storage_ratio_A_to_B * prod_A_week1 + prod_B_week1 <= max_storage_A_week1 * storage_ratio_A_to_B,
    "Storage_Capacity_Week1"
)
model.addConstr(
    storage_ratio_A_to_B * prod_A_week2 + prod_B_week2 <= max_storage_A_week2 * storage_ratio_A_to_B,
    "Storage_Capacity_Week2"
)

# Inventory balance equations
# Week 1 inventory: initial + produced - sold = inventory at end of week 1
model.addConstr(
    initial_inventory_A + prod_A_week1 - inv_A_week1 == 0,
    "Inventory_A_Week1"
)
model.addConstr(
    initial_inventory_B + prod_B_week1 - inv_B_week1 == 0,
    "Inventory_B_Week1"
)

# Week 2 inventory: previous inventory + produced - sold = inventory at end of week 2
model.addConstr(
    inv_A_week1 + prod_A_week2 - inv_A_week2 == 0,
    "Inventory_A_Week2"
)
model.addConstr(
    inv_B_week1 + prod_B_week2 - inv_B_week2 == 0,
    "Inventory_B_Week2"
)

# Promotion limits
model.addConstr(promo_A_week1 + promo_A_week2 <= max_promo_A, "Max_Promo_A")
model.addConstr(promo_B_week1 + promo_B_week2 <= max_promo_B, "Max_Promo_B")

# Optimize the model
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal:.3f}")
