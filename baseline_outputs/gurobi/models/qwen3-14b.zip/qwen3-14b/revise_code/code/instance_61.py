import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read device data
devices = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            'name': row['Device'].strip(),
            'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
            'max_cap': float(row['Max_Processing_Capacity_Units'].strip())
        })

# Read general parameters
general_params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        general_params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

required_units = general_params['required_units']
energy_budget_peak = general_params['energy_budget_peak']
energy_budget_offpeak = general_params['energy_budget_offpeak']
startup_budget = general_params['startup_budget']

# Energy per unit and startup energy per device
energy_per_unit = {
    'A': general_params['energy_per_unit_A'],
    'B': general_params['energy_per_unit_B'],
    'C': general_params['energy_per_unit_C'],
    'D': general_params['energy_per_unit_D']
}

startup_energy = {
    'A': general_params['startup_energy_A'],
    'B': general_params['startup_energy_B'],
    'C': general_params['startup_energy_C'],
    'D': general_params['startup_energy_D']
}

energy_price = {
    'peak': general_params['energy_price_peak'],
    'offpeak': general_params['energy_price_offpeak']
}

startup_cost = general_params['startup_cost']

# Create the optimization model
model = gp.Model("MinCostProduction")
model.setParam('OutputFlag', 0)

n = len(devices)

# Decision variables
# x_i: number of units produced on device i (continuous)
# y_i: binary variable indicating whether device i is used
x = {}
y = {}
for i in range(n):
    dev_name = devices[i]['name']
    x[dev_name] = model.addVar(name=f"x_{dev_name}", lb=0, ub=devices[i]['max_cap'], vtype=GRB.CONTINUOUS)
    y[dev_name] = model.addVar(name=f"y_{dev_name}", vtype=GRB.BINARY)

# Objective: minimize total cost = sum of (prep_cost * y_i + unit_cost * x_i) + energy costs + startup costs
obj = gp.LinExpr()
for i in range(n):
    dev_name = devices[i]['name']
    obj += devices[i]['prep_cost'] * y[dev_name]
    obj += devices[i]['unit_cost'] * x[dev_name]

# Energy costs
for dev_name in energy_per_unit:
    # Assume all production on a device is done in one period (either peak or offpeak)
    # For simplicity, we assume that all production on a device is in the same period.
    # This can be extended to multiple periods if needed.
    # Here, we use offpeak for all devices unless specified otherwise.
    # If more detailed period assignment is required, additional variables would be needed.
    energy_cost = energy_per_unit[dev_name] * energy_price['offpeak'] * x[dev_name]
    obj += energy_cost

# Startup costs
for dev_name in startup_energy:
    obj += startup_cost * y[dev_name]

model.setObjective(obj, GRB.MINIMIZE)

# Constraint: total production must equal required units
model.addConstr(gp.quicksum(x.values()) == required_units, "TotalProduction")

# Linking constraints: x_i <= max_cap * y_i (if device not used, no production)
for dev_name in x:
    model.addConstr(x[dev_name] <= devices[i]['max_cap'] * y[dev_name], f"Link_{dev_name}")

# Energy budget constraints
# Total energy consumption in peak and offpeak periods
peak_energy_used = gp.LinExpr()
offpeak_energy_used = gp.LinExpr()

for dev_name in energy_per_unit:
    # Assume all production on a device is in offpeak for this example
    offpeak_energy_used += energy_per_unit[dev_name] * x[dev_name]

model.addConstr(offpeak_energy_used <= energy_budget_offpeak, "OffpeakEnergyBudget")
model.addConstr(peak_energy_used <= energy_budget_peak, "PeakEnergyBudget")

# Startup energy budget constraint
startup_energy_used = gp.LinExpr()
for dev_name in startup_energy:
    startup_energy_used += startup_energy[dev_name] * y[dev_name]

model.addConstr(startup_energy_used <= startup_budget, "StartupEnergyBudget")

# Solve
model.optimize()

# Print results
for dev_name in x:
    print(f"Device {dev_name}: used={int(y[dev_name].X)}, units={x[dev_name].X:.1f}")

final_obj_value = model.objVal
print(f"FINAL_OBJ_VALUE: {final_obj_value}")
