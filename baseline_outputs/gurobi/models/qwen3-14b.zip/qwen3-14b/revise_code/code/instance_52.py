import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, "table_1_2.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    
    n = len(shifts)  # number of periods (6)
    required = [s['required'] for s in shifts]
    
    # Read general parameters
    general_params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row['Parameter_Name']] = float(row['Value'])
    
    shift_duration = general_params['shift_duration']
    driver_rest_gap = general_params['driver_rest_gap']
    crew_rest_gap = general_params['crew_rest_gap']
    max_night_driver_fraction = general_params['max_night_driver_fraction']
    max_night_crew_fraction = general_params['max_night_crew_fraction']
    max_overtime_shifts = int(general_params['max_overtime_shifts'])
    overtime_cost_factor = general_params['overtime_cost_factor']
    
    periods_per_shift = shift_duration // 4  # 8 hours / 4 hours per period = 2
    
    # Define late-night periods (5 and 6)
    night_periods = [4, 5]  # zero-based index: 4 is period 5 (22:00-2:00), 5 is period 6 (2:00-6:00)
    
    # Create model
    model = gp.Model("MinimumWorkers")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_d[i]: number of regular driver starts at period i
    # x_c[i]: number of regular crew starts at period i
    # y_d[i]: number of overtime driver starts at period i
    # y_c[i]: number of overtime crew starts at period i
    x_d = [model.addVar(vtype=GRB.INTEGER, name=f"x_d_{i+1}") for i in range(n)]
    x_c = [model.addVar(vtype=GRB.INTEGER, name=f"x_c_{i+1}") for i in range(n)]
    y_d = [model.addVar(vtype=GRB.INTEGER, name=f"y_d_{i+1}") for i in range(n)]
    y_c = [model.addVar(vtype=GRB.INTEGER, name=f"y_c_{i+1}") for i in range(n)]
    
    # Objective: minimize total cost (regular + overtime)
    model.setObjective(
        gp.quicksum(x_d) + gp.quicksum(x_c) + 
        overtime_cost_factor * (gp.quicksum(y_d) + gp.quicksum(y_c)),
        GRB.MINIMIZE
    )
    
    # Constraints: coverage for each period for drivers and crew
    for j in range(n):
        # Drivers: sum of workers starting at periods that cover j >= required[j]
        covering_drivers = []
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                covering_drivers.append(x_d[i])
                covering_drivers.append(y_d[i])
        model.addConstr(gp.quicksum(covering_drivers) >= required[j], name=f"Driver_Coverage_{j+1}")
        
        # Crew: same logic
        covering_crew = []
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                covering_crew.append(x_c[i])
                covering_crew.append(y_c[i])
        model.addConstr(gp.quicksum(covering_crew) >= required[j], name=f"Crew_Coverage_{j+1}")
    
    # Rest gap constraints for drivers and crew
    # For drivers: the number of starts in late-night periods must be <= rest_gap
    # This is a proxy for ensuring sufficient rest between late-night shifts
    for i in range(n):
        if i in night_periods:
            model.addConstr(gp.quicksum([x_d[i]] + [x_d[(i - k) % n] for k in range(1, driver_rest_gap + 1)]) <= 1,
                            name=f"Driver_Rest_Gap_{i+1}")
    
    for i in range(n):
        if i in night_periods:
            model.addConstr(gp.quicksum([x_c[i]] + [x_c[(i - k) % n] for k in range(1, crew_rest_gap + 1)]) <= 1,
                            name=f"Crew_Rest_Gap_{i+1}")
    
    # Night shift fraction constraints for drivers and crew
    total_driver_starts = gp.quicksum(x_d)
    night_driver_starts = gp.quicksum(x_d[i] for i in night_periods)
    model.addConstr(night_driver_starts / total_driver_starts <= max_night_driver_fraction,
                    name="Max_Night_Driver_Fraction")
    
    total_crew_starts = gp.quicksum(x_c)
    night_crew_starts = gp.quicksum(x_c[i] for i in night_periods)
    model.addConstr(night_crew_starts / total_crew_starts <= max_night_crew_fraction,
                    name="Max_Night_Crew_Fraction")
    
    # Overtime constraint: total overtime shifts across both groups <= max_overtime_shifts
    model.addConstr(gp.quicksum(y_d) + gp.quicksum(y_c) <= max_overtime_shifts, name="Max_Overtime_Shifts")
    
    # Solve the model
    model.optimize()
    
    # Print solution details
    for i in range(n):
        print(f"Regular Driver Starts at Period {i+1}: {x_d[i].X}")
        print(f"Regular Crew Starts at Period {i+1}: {x_c[i].X}")
        print(f"Overtime Driver Starts at Period {i+1}: {y_d[i].X}")
        print(f"Overtime Crew Starts at Period {i+1}: {y_c[i].X}")
    
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
