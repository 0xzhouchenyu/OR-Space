import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    product_units = params["product_units"]
    truck_pollution = params["truck_pollution"]
    van_pollution = params["van_pollution"]
    motorcycle_pollution = params["motorcycle_pollution"]
    ev_pollution = params["electric_vehicle_pollution"]
    max_total_pollution = params["max_total_pollution"]
    min_truck_trips = params["min_truck_trips"]
    truck_capacity = params["truck_capacity"]
    van_capacity = params["van_capacity"]
    motorcycle_capacity = params["motorcycle_capacity"]
    ev_capacity = params["electric_vehicle_capacity"]
    sales_point_share_sp1 = params["sales_point_share_sp1"]
    sales_point_share_sp2 = params["sales_point_share_sp2"]
    sales_point_share_sp3 = params["sales_point_share_sp3"]
    min_truck_share_sp1 = params["min_truck_share_sp1"]
    min_truck_share_sp2 = params["min_truck_share_sp2"]
    min_truck_share_sp3 = params["min_truck_share_sp3"]
    M_truck_sp_day = params["M_truck_sp_day"]
    M_ev_sp_day = params["M_ev_sp_day"]
    M_van_sp_day = params["M_van_sp_day"]
    M_moto_sp_day = params["M_moto_sp_day"]

    # Sales point demand
    sp1_demand = product_units * sales_point_share_sp1
    sp2_demand = product_units * sales_point_share_sp2
    sp3_demand = product_units * sales_point_share_sp3

    # Create model
    model = gp.Model("Transportation_Pollution_Minimization")
    model.setParam('OutputFlag', 0)

    # Decision variables: number of trips per vehicle type per sales point and day
    # Vehicle types: truck, electric vehicle, van, motorcycle
    # Sales points: sp1, sp2, sp3
    # Days: day1, day2, day3

    # Binary variables to indicate if a vehicle type is used on a sales point-day
    use_truck_sp1d1 = model.addVar(vtype=GRB.BINARY, name="use_truck_sp1d1")
    use_ev_sp1d1 = model.addVar(vtype=GRB.BINARY, name="use_ev_sp1d1")
    use_van_sp1d1 = model.addVar(vtype=GRB.BINARY, name="use_van_sp1d1")
    use_moto_sp1d1 = model.addVar(vtype=GRB.BINARY, name="use_moto_sp1d1")

    use_truck_sp1d2 = model.addVar(vtype=GRB.BINARY, name="use_truck_sp1d2")
    use_ev_sp1d2 = model.addVar(vtype=GRB.BINARY, name="use_ev_sp1d2")
    use_van_sp1d2 = model.addVar(vtype=GRB.BINARY, name="use_van_sp1d2")
    use_moto_sp1d2 = model.addVar(vtype=GRB.BINARY, name="use_moto_sp1d2")

    use_truck_sp1d3 = model.addVar(vtype=GRB.BINARY, name="use_truck_sp1d3")
    use_ev_sp1d3 = model.addVar(vtype=GRB.BINARY, name="use_ev_sp1d3")
    use_van_sp1d3 = model.addVar(vtype=GRB.BINARY, name="use_van_sp1d3")
    use_moto_sp1d3 = model.addVar(vtype=GRB.BINARY, name="use_moto_sp1d3")

    use_truck_sp2d1 = model.addVar(vtype=GRB.BINARY, name="use_truck_sp2d1")
    use_ev_sp2d1 = model.addVar(vtype=GRB.BINARY, name="use_ev_sp2d1")
    use_van_sp2d1 = model.addVar(vtype=GRB.BINARY, name="use_van_sp2d1")
    use_moto_sp2d1 = model.addVar(vtype=GRB.BINARY, name="use_moto_sp2d1")

    use_truck_sp2d2 = model.addVar(vtype=GRB.BINARY, name="use_truck_sp2d2")
    use_ev_sp2d2 = model.addVar(vtype=GRB.BINARY, name="use_ev_sp2d2")
    use_van_sp2d2 = model.addVar(vtype=GRB.BINARY, name="use_van_sp2d2")
    use_moto_sp2d2 = model.addVar(vtype=GRB.BINARY, name="use_moto_sp2d2")

    use_truck_sp2d3 = model.addVar(vtype=GRB.BINARY, name="use_truck_sp2d3")
    use_ev_sp2d3 = model.addVar(vtype=GRB.BINARY, name="use_ev_sp2d3")
    use_van_sp2d3 = model.addVar(vtype=GRB.BINARY, name="use_van_sp2d3")
    use_moto_sp2d3 = model.addVar(vtype=GRB.BINARY, name="use_moto_sp2d3")

    use_truck_sp3d1 = model.addVar(vtype=GRB.BINARY, name="use_truck_sp3d1")
    use_ev_sp3d1 = model.addVar(vtype=GRB.BINARY, name="use_ev_sp3d1")
    use_van_sp3d1 = model.addVar(vtype=GRB.BINARY, name="use_van_sp3d1")
    use_moto_sp3d1 = model.addVar(vtype=GRB.BINARY, name="use_moto_sp3d1")

    use_truck_sp3d2 = model.addVar(vtype=GRB.BINARY, name="use_truck_sp3d2")
    use_ev_sp3d2 = model.addVar(vtype=GRB.BINARY, name="use_ev_sp3d2")
    use_van_sp3d2 = model.addVar(vtype=GRB.BINARY, name="use_van_sp3d2")
    use_moto_sp3d2 = model.addVar(vtype=GRB.BINARY, name="use_moto_sp3d2")

    use_truck_sp3d3 = model.addVar(vtype=GRB.BINARY, name="use_truck_sp3d3")
    use_ev_sp3d3 = model.addVar(vtype=GRB.BINARY, name="use_ev_sp3d3")
    use_van_sp3d3 = model.addVar(vtype=GRB.BINARY, name="use_van_sp3d3")
    use_moto_sp3d3 = model.addVar(vtype=GRB.BINARY, name="use_moto_sp3d3")

    # Integer variables for the number of trips per vehicle type per sales point and day
    truck_sp1d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_truck_sp_day, name="truck_sp1d1")
    ev_sp1d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_ev_sp_day, name="ev_sp1d1")
    van_sp1d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_van_sp_day, name="van_sp1d1")
    moto_sp1d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_moto_sp_day, name="moto_sp1d1")

    truck_sp1d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_truck_sp_day, name="truck_sp1d2")
    ev_sp1d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_ev_sp_day, name="ev_sp1d2")
    van_sp1d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_van_sp_day, name="van_sp1d2")
    moto_sp1d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_moto_sp_day, name="moto_sp1d2")

    truck_sp1d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_truck_sp_day, name="truck_sp1d3")
    ev_sp1d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_ev_sp_day, name="ev_sp1d3")
    van_sp1d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_van_sp_day, name="van_sp1d3")
    moto_sp1d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_moto_sp_day, name="moto_sp1d3")

    truck_sp2d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_truck_sp_day, name="truck_sp2d1")
    ev_sp2d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_ev_sp_day, name="ev_sp2d1")
    van_sp2d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_van_sp_day, name="van_sp2d1")
    moto_sp2d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_moto_sp_day, name="moto_sp2d1")

    truck_sp2d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_truck_sp_day, name="truck_sp2d2")
    ev_sp2d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_ev_sp_day, name="ev_sp2d2")
    van_sp2d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_van_sp_day, name="van_sp2d2")
    moto_sp2d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_moto_sp_day, name="moto_sp2d2")

    truck_sp2d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_truck_sp_day, name="truck_sp2d3")
    ev_sp2d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_ev_sp_day, name="ev_sp2d3")
    van_sp2d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_van_sp_day, name="van_sp2d3")
    moto_sp2d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_moto_sp_day, name="moto_sp2d3")

    truck_sp3d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_truck_sp_day, name="truck_sp3d1")
    ev_sp3d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_ev_sp_day, name="ev_sp3d1")
    van_sp3d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_van_sp_day, name="van_sp3d1")
    moto_sp3d1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_moto_sp_day, name="moto_sp3d1")

    truck_sp3d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_truck_sp_day, name="truck_sp3d2")
    ev_sp3d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_ev_sp_day, name="ev_sp3d2")
    van_sp3d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_van_sp_day, name="van_sp3d2")
    moto_sp3d2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_moto_sp_day, name="moto_sp3d2")

    truck_sp3d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_truck_sp_day, name="truck_sp3d3")
    ev_sp3d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_ev_sp_day, name="ev_sp3d3")
    van_sp3d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_van_sp_day, name="van_sp3d3")
    moto_sp3d3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=M_moto_sp_day, name="moto_sp3d3")

    # Linking binary and integer variables
    model.addConstr(truck_sp1d1 <= M_truck_sp_day * use_truck_sp1d1)
    model.addConstr(ev_sp1d1 <= M_ev_sp_day * use_ev_sp1d1)
    model.addConstr(van_sp1d1 <= M_van_sp_day * use_van_sp1d1)
    model.addConstr(moto_sp1d1 <= M_moto_sp_day * use_moto_sp1d1)

    model.addConstr(truck_sp1d2 <= M_truck_sp_day * use_truck_sp1d2)
    model.addConstr(ev_sp1d2 <= M_ev_sp_day * use_ev_sp1d2)
    model.addConstr(van_sp1d2 <= M_van_sp_day * use_van_sp1d2)
    model.addConstr(moto_sp1d2 <= M_moto_sp_day * use_moto_sp1d2)

    model.addConstr(truck_sp1d3 <= M_truck_sp_day * use_truck_sp1d3)
    model.addConstr(ev_sp1d3 <= M_ev_sp_day * use_ev_sp1d3)
    model.addConstr(van_sp1d3 <= M_van_sp_day * use_van_sp1d3)
    model.addConstr(moto_sp1d3 <= M_moto_sp_day * use_moto_sp1d3)

    model.addConstr(truck_sp2d1 <= M_truck_sp_day * use_truck_sp2d1)
    model.addConstr(ev_sp2d1 <= M_ev_sp_day * use_ev_sp2d1)
    model.addConstr(van_sp2d1 <= M_van_sp_day * use_van_sp2d1)
    model.addConstr(moto_sp2d1 <= M_moto_sp_day * use_moto_sp2d1)

    model.addConstr(truck_sp2d2 <= M_truck_sp_day * use_truck_sp2d2)
    model.addConstr(ev_sp2d2 <= M_ev_sp_day * use_ev_sp2d2)
    model.addConstr(van_sp2d2 <= M_van_sp_day * use_van_sp2d2)
    model.addConstr(moto_sp2d2 <= M_moto_sp_day * use_moto_sp2d2)

    model.addConstr(truck_sp2d3 <= M_truck_sp_day * use_truck_sp2d3)
    model.addConstr(ev_sp2d3 <= M_ev_sp_day * use_ev_sp2d3)
    model.addConstr(van_sp2d3 <= M_van_sp_day * use_van_sp2d3)
    model.addConstr(moto_sp2d3 <= M_moto_sp_day * use_moto_sp2d3)

    model.addConstr(truck_sp3d1 <= M_truck_sp_day * use_truck_sp3d1)
    model.addConstr(ev_sp3d1 <= M_ev_sp_day * use_ev_sp3d1)
    model.addConstr(van_sp3d1 <= M_van_sp_day * use_van_sp3d1)
    model.addConstr(moto_sp3d1 <= M_moto_sp_day * use_moto_sp3d1)

    model.addConstr(truck_sp3d2 <= M_truck_sp_day * use_truck_sp3d2)
    model.addConstr(ev_sp3d2 <= M_ev_sp_day * use_ev_sp3d2)
    model.addConstr(van_sp3d2 <= M_van_sp_day * use_van_sp3d2)
    model.addConstr(moto_sp3d2 <= M_moto_sp_day * use_moto_sp3d2)

    model.addConstr(truck_sp3d3 <= M_truck_sp_day * use_truck_sp3d3)
    model.addConstr(ev_sp3d3 <= M_ev_sp_day * use_ev_sp3d3)
    model.addConstr(van_sp3d3 <= M_van_sp_day * use_van_sp3d3)
    model.addConstr(moto_sp3d3 <= M_moto_sp_day * use_moto_sp3d3)

    # Constraint: On each sales point-day, deliveries must come from either the truck/electric-vehicle family or the van/motorcycle family
    # For sp1d1
    model.addConstr(use_truck_sp1d1 + use_ev_sp1d1 >= use_van_sp1d1 + use_moto_sp1d1)
    model.addConstr(use_van_sp1d1 + use_moto_sp1d1 >= use_truck_sp1d1 + use_ev_sp1d1)

    # For sp1d2
    model.addConstr(use_truck_sp1d2 + use_ev_sp1d2 >= use_van_sp1d2 + use_moto_sp1d2)
    model.addConstr(use_van_sp1d2 + use_moto_sp1d2 >= use_truck_sp1d2 + use_ev_sp1d2)

    # For sp1d3
    model.addConstr(use_truck_sp1d3 + use_ev_sp1d3 >= use_van_sp1d3 + use_moto_sp1d3)
    model.addConstr(use_van_sp1d3 + use_moto_sp1d3 >= use_truck_sp1d3 + use_ev_sp1d3)

    # For sp2d1
    model.addConstr(use_truck_sp2d1 + use_ev_sp2d1 >= use_van_sp2d1 + use_moto_sp2d1)
    model.addConstr(use_van_sp2d1 + use_moto_sp2d1 >= use_truck_sp2d1 + use_ev_sp2d1)

    # For sp2d2
    model.addConstr(use_truck_sp2d2 + use_ev_sp2d2 >= use_van_sp2d2 + use_moto_sp2d2)
    model.addConstr(use_van_sp2d2 + use_moto_sp2d2 >= use_truck_sp2d2 + use_ev_sp2d2)

    # For sp2d3
    model.addConstr(use_truck_sp2d3 + use_ev_sp2d3 >= use_van_sp2d3 + use_moto_sp2d3)
    model.addConstr(use_van_sp2d3 + use_moto_sp2d3 >= use_truck_sp2d3 + use_ev_sp2d3)

    # For sp3d1
    model.addConstr(use_truck_sp3d1 + use_ev_sp3d1 >= use_van_sp3d1 + use_moto_sp3d1)
    model.addConstr(use_van_sp3d1 + use_moto_sp3d1 >= use_truck_sp3d1 + use_ev_sp3d1)

    # For sp3d2
    model.addConstr(use_truck_sp3d2 + use_ev_sp3d2 >= use_van_sp3d2 + use_moto_sp3d2)
    model.addConstr(use_van_sp3d2 + use_moto_sp3d2 >= use_truck_sp3d2 + use_ev_sp3d2)

    # For sp3d3
    model.addConstr(use_truck_sp3d3 + use_ev_sp3d3 >= use_van_sp3d3 + use_moto_sp3d3)
    model.addConstr(use_van_sp3d3 + use_moto_sp3d3 >= use_truck_sp3d3 + use_ev_sp3d3)

    # Constraint: Each sales point's demand must be met
    model.addConstr(
        truck_sp1d1 * truck_capacity + ev_sp1d1 * ev_capacity + van_sp1d1 * van_capacity + moto_sp1d1 * motorcycle_capacity
        >= sp1_demand
    )
    model.addConstr(
        truck_sp1d2 * truck_capacity + ev_sp1d2 * ev_capacity + van_sp1d2 * van_capacity + moto_sp1d2 * motorcycle_capacity
        >= sp1_demand
    )
    model.addConstr(
        truck_sp1d3 * truck_capacity + ev_sp1d3 * ev_capacity + van_sp1d3 * van_capacity + moto_sp1d3 * motorcycle_capacity
        >= sp1_demand
    )

    model.addConstr(
        truck_sp2d1 * truck_capacity + ev_sp2d1 * ev_capacity + van_sp2d1 * van_capacity + moto_sp2d1 * motorcycle_capacity
        >= sp2_demand
    )
    model.addConstr(
        truck_sp2d2 * truck_capacity + ev_sp2d2 * ev_capacity + van_sp2d2 * van_capacity + moto_sp2d2 * motorcycle_capacity
        >= sp2_demand
    )
    model.addConstr(
        truck_sp2d3 * truck_capacity + ev_sp2d3 * ev_capacity + van_sp2d3 * van_capacity + moto_sp2d3 * motorcycle_capacity
        >= sp2_demand
    )

    model.addConstr(
        truck_sp3d1 * truck_capacity + ev_sp3d1 * ev_capacity + van_sp3d1 * van_capacity + moto_sp3d1 * motorcycle_capacity
        >= sp3_demand
    )
    model.addConstr(
        truck_sp3d2 * truck_capacity + ev_sp3d2 * ev_capacity + van_sp3d2 * van_capacity + moto_sp3d2 * motorcycle_capacity
        >= sp3_demand
    )
    model.addConstr(
        truck_sp3d3 * truck_capacity + ev_sp3d3 * ev_capacity + van_sp3d3 * van_capacity + moto_sp3d3 * motorcycle_capacity
        >= sp3_demand
    )

    # Constraint: Minimum fraction of trips that must be truck trips for each sales point
    # For sp1
    total_truck_sp1 = truck_sp1d1 + truck_sp1d2 + truck_sp1d3
    total_truck_ev_sp1 = truck_sp1d1 + truck_sp1d2 + truck_sp1d3 + ev_sp1d1 + ev_sp1d2 + ev_sp1d3
    model.addConstr(total_truck_sp1 >= min_truck_share_sp1 * total_truck_ev_sp1)

    # For sp2
    total_truck_sp2 = truck_sp2d1 + truck_sp2d2 + truck_sp2d3
    total_truck_ev_sp2 = truck_sp2d1 + truck_sp2d2 + truck_sp2d3 + ev_sp2d1 + ev_sp2d2 + ev_sp2d3
    model.addConstr(total_truck_sp2 >= min_truck_share_sp2 * total_truck_ev_sp2)

    # For sp3
    total_truck_sp3 = truck_sp3d1 + truck_sp3d2 + truck_sp3d3
    total_truck_ev_sp3 = truck_sp3d1 + truck_sp3d2 + truck_sp3d3 + ev_sp3d1 + ev_sp3d2 + ev_sp3d3
    model.addConstr(total_truck_sp3 >= min_truck_share_sp3 * total_truck_ev_sp3)

    # Constraint: Total pollution must not exceed maximum
    total_pollution = (
        truck_pollution * (truck_sp1d1 + truck_sp1d2 + truck_sp1d3 + truck_sp2d1 + truck_sp2d2 + truck_sp2d3 + truck_sp3d1 + truck_sp3d2 + truck_sp3d3)
        + van_pollution * (van_sp1d1 + van_sp1d2 + van_sp1d3 + van_sp2d1 + van_sp2d2 + van_sp2d3 + van_sp3d1 + van_sp3d2 + van_sp3d3)
        + motorcycle_pollution * (moto_sp1d1 + moto_sp1d2 + moto_sp1d3 + moto_sp2d1 + moto_sp2d2 + moto_sp2d3 + moto_sp3d1 + moto_sp3d2 + moto_sp3d3)
        + ev_pollution * (ev_sp1d1 + ev_sp1d2 + ev_sp1d3 + ev_sp2d1 + ev_sp2d2 + ev_sp2d3 + ev_sp3d1 + ev_sp3d2 + ev_sp3d3)
    )
    model.addConstr(total_pollution <= max_total_pollution)

    # Constraint: Minimum total number of truck trips across all sales points and days
    total_truck_trips = (
        truck_sp1d1 + truck_sp1d2 + truck_sp1d3 + truck_sp2d1 + truck_sp2d2 + truck_sp2d3 + truck_sp3d1 + truck_sp3d2 + truck_sp3d3
    )
    model.addConstr(total_truck_trips >= min_truck_trips)

    # Objective: minimize total pollution
    model.setObjective(total_pollution, GRB.MINIMIZE)

    # Solve
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
