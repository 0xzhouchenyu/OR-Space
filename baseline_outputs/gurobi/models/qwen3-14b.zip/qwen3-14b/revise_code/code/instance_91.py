import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_parameters

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_hours = params['machine_working_time']
    machine_working_time_minutes = machine_working_time_hours * 60  # convert to minutes
    
    max_overtime_hours = params['max_overtime_hours']
    overtime_penalty_per_hour = params['overtime_penalty_per_hour']
    overtime_review_threshold_hours = params['overtime_review_threshold_hours']
    overtime_review_fee = params['overtime_review_fee']
    
    product_A_senior_batch_threshold = params['product_A_senior_batch_threshold']
    product_A_senior_batch_fee = params['product_A_senior_batch_fee']
    
    ratio_A, ratio_B = params['production_ratio_A_to_B']
    
    # Define the model
    model = gp.Model("Product_Mix_Rev")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    A = model.addVar(name="Product_A", lb=0, vtype=GRB.CONTINUOUS)
    B = model.addVar(name="Product_B", lb=0, vtype=GRB.CONTINUOUS)
    O = model.addVar(name="Overtime_Hours", lb=0, vtype=GRB.CONTINUOUS)
    
    # Objective function: maximize profit - costs
    objective = (profit_A * A) + (profit_B * B) - (overtime_penalty_per_hour * O)
    
    # Senior assembler fee for Product A
    if product_A_senior_batch_threshold > 0:
        senior_fee = model.addVar(name="Senior_Assembler_Fee", lb=0, vtype=GRB.BINARY)
        model.addConstr(A - product_A_senior_batch_threshold <= 100000 * (1 - senior_fee), name="Senior_Fee_Trigger")
        model.addConstr(A - product_A_senior_batch_threshold >= -100000 * senior_fee, name="Senior_Fee_Trigger2")
        objective -= product_A_senior_batch_fee * senior_fee
    
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Constraint 1: Machine working time
    total_time = assembly_time_A * A + assembly_time_B * B
    model.addConstr(total_time <= machine_working_time_minutes + 60 * O, name="Machine_Time")
    
    # Constraint 2: Overtime limit
    model.addConstr(O <= max_overtime_hours * 60, name="Max_Overtime")
    
    # Constraint 3: Overtime review fee
    if overtime_review_threshold_hours > 0:
        review_fee = model.addVar(name="Overtime_Review_Fee", lb=0, vtype=GRB.BINARY)
        model.addConstr(O - overtime_review_threshold_hours * 60 <= 100000 * (1 - review_fee), name="Review_Fee_Trigger")
        model.addConstr(O - overtime_review_threshold_hours * 60 >= -100000 * review_fee, name="Review_Fee_Trigger2")
        objective -= overtime_review_fee * review_fee
    
    # Constraint 4: Production ratio - at least 2 units of B for every 5 units of A
    model.addConstr(ratio_B * A - ratio_A * B <= 0, name="Production_Ratio")
    
    # Optimize
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")

if __name__ == "__main__":
    main()
