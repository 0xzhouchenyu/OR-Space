import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Extract parameters
min_A_I = params["min_proportion_crude_A_type_I"] / 100.0  # 0.50
min_A_II = params["min_proportion_crude_A_type_II"] / 100.0  # 0.60
price_I = params["selling_price_type_I"]  # 4800
price_II = params["selling_price_type_II"]  # 5600
inv_A = params["inventory_crude_A"]  # 500
inv_B = params["inventory_crude_B"]  # 1000
max_purchase_A = params["max_purchase_crude_A"]  # 1500
cost_tier1 = params["market_price_crude_A_tier_1"]  # 10000
cost_tier2 = params["market_price_crude_A_tier_2"]  # 8000
cost_tier3 = params["market_price_crude_A_tier_3"]  # 6000
processing_capacity = params["processing_capacity"]  # 2500
min_total_gasoline_output = params["min_total_gasoline_output"]  # 1500
processing_cost_per_ton = params["processing_cost_per_ton"]  # 500
type_II_contract_threshold = params["type_II_contract_threshold"]  # 900
type_II_price_lift = params["type_II_price_lift"]  # 300
bulk_purchase_rebate_threshold = params["bulk_purchase_rebate_threshold"]  # 1000
bulk_purchase_rebate = params["bulk_purchase_rebate"]  # 200000

# Create model
model = gp.Model("Oil_Blending")
model.setParam("OutputFlag", 0)

# Decision variables
# Gasoline production
gas_I = model.addVar(name="gas_I", lb=0)
gas_II = model.addVar(name="gas_II", lb=0)

# Crude A used in gasoline I and II
a1 = model.addVar(name="crude_A_in_I", lb=0)
a2 = model.addVar(name="crude_A_in_II", lb=0)

# Crude B used in gasoline I and II
b1 = model.addVar(name="crude_B_in_I", lb=0)
b2 = model.addVar(name="crude_B_in_II", lb=0)

# Tiered purchase variables for crude A
p1 = model.addVar(name="purchase_tier1", lb=0, ub=500)   # first 500t
p2 = model.addVar(name="purchase_tier2", lb=0, ub=500)   # next 500t
p3 = model.addVar(name="purchase_tier3", lb=0, ub=500)   # last 500t

# Binary variables to enforce tiered ordering
y1 = model.addVar(vtype=GRB.BINARY, name="y1")  # 1 if tier1 is fully used
y2 = model.addVar(vtype=GRB.BINARY, name="y2")  # 1 if tier2 is fully used

# Binary variable for type II price lift
z = model.addVar(vtype=GRB.BINARY, name="z")  # 1 if type_II output >= threshold

# Total crude A available = inventory + purchased
total_A_purchased = p1 + p2 + p3

# Constraints
# Blending constraints (minimum proportion of crude A)
model.addConstr(a1 >= min_A_I * (a1 + b1), name="blend_I")
model.addConstr(a2 >= min_A_II * (a2 + b2), name="blend_II")

# Gasoline production equals sum of crude used
model.addConstr(gas_I == a1 + b1, name="gas_I_eq")
model.addConstr(gas_II == a2 + b2, name="gas_II_eq")

# Crude supply constraints
model.addConstr(a1 + a2 <= inv_A + total_A_purchased, name="crude_A_supply")
model.addConstr(b1 + b2 <= inv_B, name="crude_B_supply")

# Processing capacity constraint
model.addConstr(gas_I + gas_II <= processing_capacity, name="processing_capacity")
model.addConstr(gas_I + gas_II >= min_total_gasoline_output, name="min_output")

# Tiered ordering constraints
model.addConstr(p2 <= 500 * y1, name="tier2_y1")
model.addConstr(p3 <= 500 * y2, name="tier3_y2")
model.addConstr(p1 >= 500 * y1, name="tier1_y1")
model.addConstr(p2 >= 500 * y2, name="tier2_y2")

# Type II contract threshold constraint
model.addConstr(gas_II >= type_II_contract_threshold * z, name="type_II_threshold")

# Objective function
revenue = price_I * gas_I + price_II * gas_II + type_II_price_lift * gas_II * z
cost = cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3
processing_cost = processing_cost_per_ton * (gas_I + gas_II)
rebate = bulk_purchase_rebate * (1 if (p1 + p2 + p3) >= bulk_purchase_rebate_threshold else 0)

# Use indicator constraints for rebate
model.addConstr((p1 + p2 + p3) >= bulk_purchase_rebate_threshold, name="bulk_rebate_condition")
model.addConstr(rebate == bulk_purchase_rebate, name="bulk_rebate_value")

# Final objective: revenue - cost - processing cost + rebate
model.setObjective(revenue - cost - processing_cost + rebate, GRB.MAXIMIZE)

# Optimize the model
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
