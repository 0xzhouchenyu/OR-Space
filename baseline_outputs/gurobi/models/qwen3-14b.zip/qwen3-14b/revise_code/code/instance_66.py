import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read table_1.csv
toys = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            'type': row['Toy_Type'],
            'labor': float(row['Manufacturing_Labor_Hours']),
            'inspection': float(row['Inspection_Hours']),
            'profit': float(row['Profit_Per_Unit'])
        })

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

available_labor_period1 = params['available_labor_hours_period1']
available_labor_period2 = params['available_labor_hours_period2']
available_inspection_period1 = params['available_inspection_hours_period1']
available_inspection_period2 = params['available_inspection_hours_period2']

max_demand_period1 = {
    'High-End': params['max_demand_high_end_period1'],
    'Mid-Range': params['max_demand_mid_range_period1'],
    'Low-End': params['max_demand_low_end_period1']
}

max_demand_period2 = {
    'High-End': params['max_demand_high_end_period2'],
    'Mid-Range': params['max_demand_mid_range_period2'],
    'Low-End': params['max_demand_low_end_period2']
}

overtime_labor_cap = params['overtime_labor_cap']
overtime_labor_cost = params['overtime_labor_cost']
period1_overtime_fatigue_threshold = params['period1_overtime_fatigue_threshold']
period2_labor_recovery_loss = params['period2_labor_recovery_loss']
overtime_review_threshold = params['overtime_review_threshold']
seasonal_safety_review_fee = params['seasonal_safety_review_fee']

# Create model
model = gp.Model("ToyProductionTwoPeriod")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}  # Production quantity per toy type per period
overtime_period1 = model.addVar(name="overtime_period1", lb=0, ub=overtime_labor_cap)
overtime_period2 = model.addVar(name="overtime_period2", lb=0, ub=overtime_labor_cap)
safety_review = model.addVar(vtype=GRB.BINARY, name="safety_review")

for toy in toys:
    x[(toy['type'], 1)] = model.addVar(name=f"x_{toy['type']}_p1", lb=0)
    x[(toy['type'], 2)] = model.addVar(name=f"x_{toy['type']}_p2", lb=0)

# Objective: maximize profit - overtime cost - safety review fee
objective = gp.quicksum(toy['profit'] * x[(toy['type'], p)] for toy in toys for p in [1, 2]) \
            - overtime_labor_cost * (overtime_period1 + overtime_period2) \
            - seasonal_safety_review_fee * safety_review

model.setObjective(objective, GRB.MAXIMIZE)

# Constraints
# Period 1 labor constraint
model.addConstr(gp.quicksum(toy['labor'] * x[(toy['type'], 1)] for toy in toys) + overtime_period1 <= available_labor_period1, "Labor_p1")

# Period 2 labor constraint
model.addConstr(gp.quicksum(toy['labor'] * x[(toy['type'], 2)] for toy in toys) + overtime_period2 <= available_labor_period2, "Labor_p2")

# Period 1 inspection constraint
model.addConstr(gp.quicksum(toy['inspection'] * x[(toy['type'], 1)] for toy in toys) <= available_inspection_period1, "Inspection_p1")

# Period 2 inspection constraint
model.addConstr(gp.quicksum(toy['inspection'] * x[(toy['type'], 2)] for toy in toys) <= available_inspection_period2, "Inspection_p2")

# Demand constraints for period 1
for toy in toys:
    model.addConstr(x[(toy['type'], 1)] <= max_demand_period1[toy['type']], f"Demand_p1_{toy['type']}")

# Demand constraints for period 2
for toy in toys:
    model.addConstr(x[(toy['type'], 2)] <= max_demand_period2[toy['type']], f"Demand_p2_{toy['type']}")

# Overtime fatigue constraint
model.addConstr(overtime_period1 >= period1_overtime_fatigue_threshold, "Fatigue_Threshold", sense=GRB.GREATER_EQUAL)
model.addConstr(available_labor_period2 - period2_labor_recovery_loss <= gp.quicksum(toy['labor'] * x[(toy['type'], 2)] for toy in toys) + overtime_period2, "Recovery_Loss")

# Safety review constraint
model.addConstr(overtime_period1 + overtime_period2 >= overtime_review_threshold, "Safety_Review_Threshold", sense=GRB.GREATER_EQUAL)
model.addConstr(safety_review >= (overtime_period1 + overtime_period2 - overtime_review_threshold) / (overtime_review_threshold), "Safety_Review_Activation")

# Solve the model
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
