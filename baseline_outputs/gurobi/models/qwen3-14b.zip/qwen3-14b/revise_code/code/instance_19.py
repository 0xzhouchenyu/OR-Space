import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            # Try to convert to numeric
            try:
                value = int(value_str)
            except ValueError:
                try:
                    value = float(value_str)
                except ValueError:
                    value = value_str
            params[name] = value
    return params

params = load_general_parameters(params_file)

# Extract parameters
cost_A = params['cost_per_chair_A']       # 50 USD per chair
cost_B = params['cost_per_chair_B']       # 45 USD per chair
cost_C = params['cost_per_chair_C']       # 40 USD per chair
chairs_per_order_A = params['chairs_per_order_A']  # 15 chairs per order
chairs_per_order_B = params['chairs_per_order_B']  # 10 chairs per order
chairs_per_order_C = params['chairs_per_order_C']  # 10 chairs per order
min_total = params['min_total_chairs']    # 100
max_total = params['max_total_chairs']    # 500
min_chairs_B_if_A = params['min_chairs_B_if_A']  # 10 chairs from B if ordering from A
dependency_B_C = params['dependency_B_C']  # if B ordered, must also order C
fixed_fee_A_regular = params['fixed_fee_A_regular']
fixed_fee_A_express = params['fixed_fee_A_express']
fixed_fee_B_regular = params['fixed_fee_B_regular']
fixed_fee_B_express = params['fixed_fee_B_express']
fixed_fee_C_regular = params['fixed_fee_C_regular']
fixed_fee_C_express = params['fixed_fee_C_express']
weekly_order_budget = params['weekly_order_budget']

# Create the problem
model = gp.Model("FurnitureOrder")
model.setParam('OutputFlag', 0)

# Decision variables: number of orders from each manufacturer (integer, >= 0)
# We need upper bounds. Max total chairs is 500.
max_orders_A = max_total // int(chairs_per_order_A) + 1
max_orders_B = max_total // int(chairs_per_order_B) + 1
max_orders_C = max_total // int(chairs_per_order_C) + 1

x_A = model.addVar(name="orders_A", lb=0, ub=max_orders_A, vtype=GRB.INTEGER)
x_B = model.addVar(name="orders_B", lb=0, ub=max_orders_B, vtype=GRB.INTEGER)
x_C = model.addVar(name="orders_C", lb=0, ub=max_orders_C, vtype=GRB.INTEGER)

# Binary variables to indicate if we order from each manufacturer
y_A = model.addVar(name="y_A", vtype=GRB.BINARY)
y_B = model.addVar(name="y_B", vtype=GRB.BINARY)
y_C = model.addVar(name="y_C", vtype=GRB.BINARY)

# Binary variables to indicate channel choice for each manufacturer
channel_A_regular = model.addVar(name="channel_A_regular", vtype=GRB.BINARY)
channel_A_express = model.addVar(name="channel_A_express", vtype=GRB.BINARY)
channel_B_regular = model.addVar(name="channel_B_regular", vtype=GRB.BINARY)
channel_B_express = model.addVar(name="channel_B_express", vtype=GRB.BINARY)
channel_C_regular = model.addVar(name="channel_C_regular", vtype=GRB.BINARY)
channel_C_express = model.addVar(name="channel_C_express", vtype=GRB.BINARY)

# Link channel choices to whether a manufacturer is used
model.addConstr(channel_A_regular <= y_A, "LinkARegular1")
model.addConstr(channel_A_express <= y_A, "LinkAExpress1")
model.addConstr(channel_B_regular <= y_B, "LinkBRegular1")
model.addConstr(channel_B_express <= y_B, "LinkBExpress1")
model.addConstr(channel_C_regular <= y_C, "LinkCRegular1")
model.addConstr(channel_C_express <= y_C, "LinkCExpress1")

# Ensure only one channel is selected per manufacturer
model.addConstr(channel_A_regular + channel_A_express <= y_A, "OneChannelA")
model.addConstr(channel_B_regular + channel_B_express <= y_B, "OneChannelB")
model.addConstr(channel_C_regular + channel_C_express <= y_C, "OneChannelC")

# Total chairs from each manufacturer
chairs_A = chairs_per_order_A * x_A
chairs_B = chairs_per_order_B * x_B
chairs_C = chairs_per_order_C * x_C

# Objective: minimize total cost
# Cost is per chair, plus fixed fees
total_cost = (cost_A * chairs_A + cost_B * chairs_B + cost_C * chairs_C +
              fixed_fee_A_regular * channel_A_regular + fixed_fee_A_express * channel_A_express +
              fixed_fee_B_regular * channel_B_regular + fixed_fee_B_express * channel_B_express +
              fixed_fee_C_regular * channel_C_regular + fixed_fee_C_express * channel_C_express)
model.setObjective(total_cost, GRB.MINIMIZE)

# Constraint: total chairs between min and max
model.addConstr(chairs_A + chairs_B + chairs_C >= min_total, "MinChairs")
model.addConstr(chairs_A + chairs_B + chairs_C <= max_total, "MaxChairs")

# Big M for linking
M = max_total + 1

# Link y variables to x variables
# If x_A > 0 then y_A = 1
model.addConstr(x_A <= M * y_A, "LinkA1")
model.addConstr(x_A >= y_A, "LinkA2")  # if y_A=1 then at least 1 order

model.addConstr(x_B <= M * y_B, "LinkB1")
model.addConstr(x_B >= y_B, "LinkB2")

model.addConstr(x_C <= M * y_C, "LinkC1")
model.addConstr(x_C >= y_C, "LinkC2")

# Dependency: if ordering from A, must order at least min_chairs_B_if_A chairs from B
model.addConstr(chairs_B >= min_chairs_B_if_A * y_A, "DepAB")

# Dependency: if ordering from B, must also order from C
model.addConstr(y_B <= y_C, "DepBC")

# Weekly order budget constraint: at most weekly_order_budget active manufacturer-mode combinations
active_channels = (channel_A_regular + channel_A_express +
                   channel_B_regular + channel_B_express +
                   channel_C_regular + channel_C_express)
model.addConstr(active_channels <= weekly_order_budget, "WeeklyBudget")

# Solve
model.optimize()

# Extract results
obj_val = model.objVal

print(f"FINAL_OBJ_VALUE: {obj_val}")
