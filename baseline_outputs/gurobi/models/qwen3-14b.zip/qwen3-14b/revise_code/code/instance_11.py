import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Read CSVs
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    # Parse Table 1
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]

    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])

    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])

    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp = float(row_cap['Inspection_hours_per_unit'])

    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])
    cost_asm = float(row_cost['Assembly_hours_per_unit'])
    cost_insp = float(row_cost['Inspection_hours_per_unit'])

    # Parse Parameters
    min_profit = float(df_params[df_params['Parameter_Name'] == 'min_weekly_profit']['Value'].iloc[0])
    min_a = float(df_params[df_params['Parameter_Name'] == 'min_type_a_production']['Value'].iloc[0])
    insp_a_M = float(df_params[df_params['Parameter_Name'] == 'insp_a_M']['Value'].iloc[0])
    insp_b_M = float(df_params[df_params['Parameter_Name'] == 'insp_b_M']['Value'].iloc[0])
    insp_a_E = float(df_params[df_params['Parameter_Name'] == 'insp_a_E']['Value'].iloc[0])
    insp_b_E = float(df_params[df_params['Parameter_Name'] == 'insp_b_E']['Value'].iloc[0])
    cap_ext = float(df_params[df_params['Parameter_Name'] == 'cap_ext']['Value'].iloc[0])
    cost_insp_M = float(df_params[df_params['Parameter_Name'] == 'cost_insp_M']['Value'].iloc[0])
    cost_insp_E = float(df_params[df_params['Parameter_Name'] == 'cost_insp_E']['Value'].iloc[0])
    cost_ext = float(df_params[df_params['Parameter_Name'] == 'cost_ext']['Value'].iloc[0])
    mode_fee_M = float(df_params[df_params['Parameter_Name'] == 'mode_fee_M']['Value'].iloc[0])
    mode_fee_E = float(df_params[df_params['Parameter_Name'] == 'mode_fee_E']['Value'].iloc[0])
    risk_penalty_M = float(df_params[df_params['Parameter_Name'] == 'risk_penalty_M']['Value'].iloc[0])
    cost_insp_weight = float(df_params[df_params['Parameter_Name'] == 'cost_insp_weight']['Value'].iloc[0])
    planning_horizon_weeks = int(df_params[df_params['Parameter_Name'] == 'planning_horizon_weeks']['Value'].iloc[0])
    idle_tolerance = float(df_params[df_params['Parameter_Name'] == 'idle_tolerance']['Value'].iloc[0])

    # Calculate Unit Profits
    cost_a = mfg_a * cost_mfg + asm_a * cost_asm
    profit_a = price_a - cost_a

    cost_b = mfg_b * cost_mfg + asm_b * cost_asm
    profit_b = price_b - cost_b

    # Create model
    model = gp.Model("Two_Week_Production_Plan")
    model.setParam('OutputFlag', 0)

    # Decision variables for production quantities
    x_A = model.addVars(planning_horizon_weeks, name="x_A", lb=min_a, vtype=GRB.INTEGER)
    x_B = model.addVars(planning_horizon_weeks, name="x_B", lb=0, vtype=GRB.INTEGER)

    # Decision variables for inspection modes (0: Manual, 1: Enhanced)
    mode = model.addVars(planning_horizon_weeks, name="mode", vtype=GRB.BINARY)

    # Decision variables for external inspection hours
    ext_inspection = model.addVars(planning_horizon_weeks, name="ext_inspection", lb=0, ub=cap_ext, vtype=GRB.CONTINUOUS)

    # Objective function: minimize weighted idle time with risk penalty
    obj = gp.QuadExpr()

    for week in range(planning_horizon_weeks):
        # Manufacturing idle time
        mfg_used = mfg_a * x_A[week] + mfg_b * x_B[week]
        mfg_idle = cap_mfg - mfg_used
        obj += cost_mfg * mfg_idle

        # Assembly idle time
        asm_used = asm_a * x_A[week] + asm_b * x_B[week]
        asm_idle = cap_asm - asm_used
        obj += cost_asm * asm_idle

        # Inspection idle time
        if mode[week] == 0:
            # Manual inspection
            insp_used = insp_a_M * x_A[week] + insp_b_M * x_B[week]
            insp_idle = cap_insp - insp_used
            obj += cost_insp_weight * insp_idle
            obj += risk_penalty_M
            obj += mode_fee_M
        else:
            # Enhanced inspection
            insp_used = insp_a_E * x_A[week] + insp_b_E * x_B[week]
            insp_idle = cap_insp - insp_used
            obj += cost_insp_weight * insp_idle
            obj += mode_fee_E
            obj += cost_ext * ext_inspection[week]

    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    for week in range(planning_horizon_weeks):
        # Manufacturing capacity constraint
        model.addConstr(mfg_a * x_A[week] + mfg_b * x_B[week] <= cap_mfg, name=f"mfg_cap_{week}")

        # Assembly capacity constraint
        model.addConstr(asm_a * x_A[week] + asm_b * x_B[week] <= cap_asm, name=f"asm_cap_{week}")

        # Inspection capacity constraints
        if mode[week] == 0:
            # Manual inspection
            model.addConstr(insp_a_M * x_A[week] + insp_b_M * x_B[week] <= cap_insp, name=f"insp_cap_M_{week}")
        else:
            # Enhanced inspection
            model.addConstr(insp_a_E * x_A[week] + insp_b_E * x_B[week] + ext_inspection[week] <= cap_insp, name=f"insp_cap_E_{week}")

        # Weekly profit constraint
        model.addConstr(profit_a * x_A[week] + profit_b * x_B[week] >= min_profit, name=f"profit_min_{week}")

    # Solve the model
    model.optimize()

    # Extract solution
    total_profit = 0
    for week in range(planning_horizon_weeks):
        total_profit += profit_a * x_A[week].x + profit_b * x_B[week].x

    print(f"FINAL_OBJ_VALUE: {round(total_profit, 4)}")

if __name__ == '__main__':
    solve()
