import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    
    warehouse_capacity = int(params["warehouse_capacity"])
    initial_stock = int(params["initial_stock"])
    fixed_order_cost = params["fixed_order_cost"]
    august_bulk_order_threshold = int(params["august_bulk_order_threshold"])
    august_bulk_receiving_fee = params["august_bulk_receiving_fee"]
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row["Month"])
            months.append(m)
            buy_price[m] = float(row["Buy"])
            sell_price[m] = float(row["Sell"])
    
    # Create Gurobi model
    model = gp.Model("MaxRevenue")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    buy = {m: model.addVar(name=f"buy_{m}", lb=0) for m in months}
    sell = {m: model.addVar(name=f"sell_{m}", lb=0) for m in months}
    stock = {m: model.addVar(name=f"stock_{m}", lb=0, ub=warehouse_capacity) for m in months}
    purchase_made = {m: model.addVar(vtype=GRB.BINARY, name=f"purchase_made_{m}") for m in months}
    august_special_receiving = model.addVar(vtype=GRB.BINARY, name="august_special_receiving")
    
    # Objective: maximize total profit (revenue - cost)
    obj = gp.quicksum(sell_price[m] * sell[m] - buy_price[m] * buy[m] for m in months)
    obj -= fixed_order_cost * gp.quicksum(purchase_made[m] for m in months)
    obj -= august_bulk_receiving_fee * august_special_receiving
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Stock balance constraints
    for i, m in enumerate(months):
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_stock = stock[months[i-1]]
        
        # Stock balance: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], name=f"balance_{m}")
        
        # After buying, before selling, warehouse constraint:
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, name=f"warehouse_after_buy_{m}")
        
        # Purchase made indicator
        model.addConstr(buy[m] >= 0.001 * purchase_made[m], name=f"purchase_made_lower_{m}")
        model.addConstr(buy[m] <= 100000 * purchase_made[m], name=f"purchase_made_upper_{m}")
    
    # August special receiving constraint
    model.addConstr(buy[8] >= august_bulk_order_threshold * august_special_receiving, name="august_special_receiving_lower")
    model.addConstr(buy[8] <= 100000 * august_special_receiving, name="august_special_receiving_upper")
    
    # Solve the model
    model.optimize()
    
    # Print solution details
    for m in months:
        print(f"Month {m}: Buy={buy[m].X:.1f} @ {buy_price[m]}, "
              f"Sell={sell[m].X:.1f} @ {sell_price[m]}, "
              f"Stock={stock[m].X:.1f}")
    
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
