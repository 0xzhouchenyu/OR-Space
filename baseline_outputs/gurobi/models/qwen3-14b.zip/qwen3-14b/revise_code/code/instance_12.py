import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load container data
    containers = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    # Load general parameters
    fixed_setup_cost = None
    energy_cost_per_kwh = None
    max_total_energy_kwh = None
    eco_capacity_share = None
    eco_overhead_cost = None
    regular_energy_intensity = None
    eco_energy_intensity = None

    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'fixed_setup_cost':
                fixed_setup_cost = float(row['Value'])
            elif row['Parameter_Name'] == 'energy_cost_per_kwh':
                energy_cost_per_kwh = float(row['Value'])
            elif row['Parameter_Name'] == 'max_total_energy_kwh':
                max_total_energy_kwh = float(row['Value'])
            elif row['Parameter_Name'] == 'eco_capacity_share':
                eco_capacity_share = float(row['Value'])
            elif row['Parameter_Name'] == 'eco_overhead_cost':
                eco_overhead_cost = float(row['Value'])
            elif row['Parameter_Name'] == 'regular_energy_intensity_kwh_per_unit':
                regular_energy_intensity = float(row['Value'])
            elif row['Parameter_Name'] == 'eco_energy_intensity_kwh_per_unit':
                eco_energy_intensity = float(row['Value'])

    n = len(containers)

    # Create the model
    model = gp.Model("PlasticContainers")
    model.setParam('OutputFlag', 0)

    # Binary setup variables: y[i] = 1 if container type i is produced (in any mode)
    y = model.addVars(n, vtype=GRB.BINARY, name="y")

    # Binary eco mode variables: z[i] = 1 if eco mode is used for container type i
    z = model.addVars(n, vtype=GRB.BINARY, name="z")

    # x[i][j] = units of type i produced to fulfill demand of type j
    x = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x[(i, j)] = model.addVar(lb=0, ub=GRB.INFINITY, vtype=GRB.INTEGER, name=f"x_{i}_{j}")

    # Objective function: minimize total cost (production + setup + energy)
    obj = gp.quicksum(containers[i]['cost'] * x[i, j] for (i, j) in x) \
          + gp.quicksum(fixed_setup_cost * y[i] for i in range(n)) \
          + gp.quicksum(eco_overhead_cost * z[i] for i in range(n)) \
          + energy_cost_per_kwh * (
              gp.quicksum(regular_energy_intensity * x[i, j] for (i, j) in x if z[i] == 0) +
              gp.quicksum(eco_energy_intensity * x[i, j] for (i, j) in x if z[i] == 1)
          )

    model.setObjective(obj, GRB.MINIMIZE)

    # Demand constraints: for each type j, total supplied >= demand[j]
    for j in range(n):
        model.addConstr(
            gp.quicksum(x[i, j] for i in range(n) if (i, j) in x) >= containers[j]['demand'],
            name=f"demand_{j}"
        )

    # Linking constraint: if we produce type i, y[i] must be 1
    M = sum(c['demand'] for c in containers)
    for i in range(n):
        total_produced_i = gp.quicksum(x[i, j] for j in range(n) if (i, j) in x)
        model.addConstr(total_produced_i <= M * y[i], name=f"setup_{i}")

    # Eco capacity constraint: if eco mode is used, production in eco mode cannot exceed eco_capacity_share of total production
    for i in range(n):
        total_prod = gp.quicksum(x[i, j] for j in range(n) if (i, j) in x)
        eco_prod = gp.quicksum(x[i, j] for j in range(n) if (i, j) in x)
        model.addConstr(eco_prod <= eco_capacity_share * total_prod, name=f"eco_capacity_{i}")

    # Energy consumption constraint: total energy used <= max_total_energy_kwh
    energy_used = gp.quicksum(
        regular_energy_intensity * x[i, j] for (i, j) in x if z[i] == 0
    ) + gp.quicksum(
        eco_energy_intensity * x[i, j] for (i, j) in x if z[i] == 1
    )
    model.addConstr(energy_used <= max_total_energy_kwh, name="total_energy")

    # Solve the model
    model.optimize()

    # Print solution details
    for i in range(n):
        total_prod = sum(x[i, j].X for j in range(n) if (i, j) in x)
        if total_prod > 0:
            print(f"Container type {containers[i]['code']}: produce {total_prod}, setup={'Yes' if y[i].X > 0.5 else 'No'}, eco={'Yes' if z[i].X > 0.5 else 'No'}")

    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
