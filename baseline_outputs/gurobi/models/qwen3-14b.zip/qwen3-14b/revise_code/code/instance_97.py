import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    # Get data directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read table_1.csv
    materials = []
    sulfur_content = {}
    purchase_price = {}
    
    with open(os.path.join(data_dir, "table_1.csv"), "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            mat = row["Material"].strip()
            materials.append(mat)
            sulfur_content[mat] = float(row["Sulfur_Content_Percentage"].strip())
            purchase_price[mat] = float(row["Purchase_Price_Thousand_Yuan_Per_Ton"].strip())
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row["Parameter_Name"].strip()
            val = float(row["Value"].strip())
            params[param_name] = val
    
    max_sulfur_A_premium = params["max_sulfur_content_A_premium"]
    max_sulfur_A_standard = params["max_sulfur_content_A_standard"]
    max_sulfur_B_premium = params["max_sulfur_content_B_premium"]
    max_sulfur_B_standard = params["max_sulfur_content_B_standard"]
    selling_price_A_premium = params["selling_price_A_premium"]
    selling_price_A_standard = params["selling_price_A_standard"]
    selling_price_B_premium = params["selling_price_B_premium"]
    selling_price_B_standard = params["selling_price_B_standard"]
    max_supply_D = params["max_supply_D"]
    market_demand_A = params["market_demand_A"]
    market_demand_B = params["market_demand_B"]
    min_premium_share_A = params["min_premium_share_A"]
    max_premium_share_A = params["max_premium_share_A"]
    min_premium_share_B = params["min_premium_share_B"]
    max_premium_share_B = params["max_premium_share_B"]
    
    products = ["A_premium", "A_standard", "B_premium", "B_standard"]
    
    # Create model
    model = gp.Model("Blending_Problem")
    model.setParam("OutputFlag", 0)
    
    # Decision variables: x[m, p] = tons of material m used in product p
    x = {}
    for m in materials:
        for p in products:
            x[m, p] = model.addVar(name=f"x_{m}_{p}", lb=0)
    
    # Total amount of each product family
    total_A = gp.quicksum(x[m, "A_premium"] + x[m, "A_standard"] for m in materials)
    total_B = gp.quicksum(x[m, "B_premium"] + x[m, "B_standard"] for m in materials)
    
    # Revenue - Cost
    revenue = (
        selling_price_A_premium * gp.quicksum(x[m, "A_premium"] for m in materials) +
        selling_price_A_standard * gp.quicksum(x[m, "A_standard"] for m in materials) +
        selling_price_B_premium * gp.quicksum(x[m, "B_premium"] for m in materials) +
        selling_price_B_standard * gp.quicksum(x[m, "B_standard"] for m in materials)
    )
    
    cost = gp.quicksum(purchase_price[m] * (x[m, p] for p in products) for m in materials)
    
    model.setObjective(revenue - cost, GRB.MAXIMIZE)
    
    # Sulfur content constraints for each product stream
    # Product A Premium
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, "A_premium"] for m in materials) <= max_sulfur_A_premium * gp.quicksum(x[m, "A_premium"] for m in materials),
        name="Sulfur_A_premium"
    )
    
    # Product A Standard
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, "A_standard"] for m in materials) <= max_sulfur_A_standard * gp.quicksum(x[m, "A_standard"] for m in materials),
        name="Sulfur_A_standard"
    )
    
    # Product B Premium
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, "B_premium"] for m in materials) <= max_sulfur_B_premium * gp.quicksum(x[m, "B_premium"] for m in materials),
        name="Sulfur_B_premium"
    )
    
    # Product B Standard
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, "B_standard"] for m in materials) <= max_sulfur_B_standard * gp.quicksum(x[m, "B_standard"] for m in materials),
        name="Sulfur_B_standard"
    )
    
    # Supply limit for material D
    model.addConstr(gp.quicksum(x["D", p] for p in products) <= max_supply_D, name="Supply_D")
    
    # Market demand constraints
    model.addConstr(total_A <= market_demand_A, name="Demand_A")
    model.addConstr(total_B <= market_demand_B, name="Demand_B")
    
    # Premium share constraints for product A
    premium_A = gp.quicksum(x[m, "A_premium"] for m in materials)
    model.addConstr(premium_A >= min_premium_share_A, name="Min_Premium_A")
    model.addConstr(premium_A <= max_premium_share_A, name="Max_Premium_A")
    
    # Premium share constraints for product B
    premium_B = gp.quicksum(x[m, "B_premium"] for m in materials)
    model.addConstr(premium_B >= min_premium_share_B, name="Min_Premium_B")
    model.addConstr(premium_B <= max_premium_share_B, name="Max_Premium_B")
    
    # Optimize model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
    
if __name__ == "__main__":
    main()
