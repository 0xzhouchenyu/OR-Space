import os
import gurobipy as gp
from gurobipy import GRB
import csv

def load_demand():
    """Load demand data from table_1.csv."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "table_1.csv")
    demand = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            month = row['Month']
            product = row['Product']
            units = int(row['Market_Demand_Units'])
            demand[(month, product)] = units
    return demand

def load_parameters():
    """Load general parameters."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            value = float(row['Value'])
            params[name] = value
    return params

def main():
    demand_data = load_demand()
    params = load_parameters()

    # Planning months: July to December
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']

    # Parameters
    cost_I = params['product_I_cost_jun_to_dec']  # 4.5 for June-Dec
    cost_II = params['product_II_cost_jun_to_dec']  # 7 for June-Dec
    prod_cost = {'Product_I': cost_I, 'Product_II': cost_II}

    vol_I = params['product_I_volume']  # 0.2
    vol_II = params['product_II_volume']  # 0.4
    volume = {'Product_I': vol_I, 'Product_II': vol_II}

    warehouse_cap = params['warehouse_capacity']  # 30,000 cubic meters
    own_cost = params['own_warehouse_cost']  # 1 yuan/m³/month

    machine_hours_I = params['product_I_machine_hours']  # 0.8
    machine_hours_II = params['product_II_machine_hours']  # 1.6
    machine_hours_capacity = params['machine_hours_capacity_monthly']  # 120,000

    grid_electricity_cost = params['grid_electricity_cost']  # 0.6
    generator_electricity_cost = params['generator_electricity_cost']  # 0.9

    power_I = params['product_I_power_kwh']  # 2
    power_II = params['product_II_power_kwh']  # 3

    grid_quota = {
        'July': params['grid_quota_july'],
        'August': params['grid_quota_august'],
        'September': params['grid_quota_september'],
        'October': params['grid_quota_october'],
        'November': params['grid_quota_november'],
        'December': params['grid_quota_december']
    }

    generator_max = {
        'July': params['generator_max_july'],
        'August': params['generator_max_august'],
        'September': params['generator_max_september'],
        'October': params['generator_max_october'],
        'November': params['generator_max_november'],
        'December': params['generator_max_december']
    }

    # Demand for planning months
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]

    # Model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # Production quantities
    x = model.addVars([(m, p) for m in months for p in products], name="prod", lb=0)

    # Inventory at end of month
    inv = model.addVars([(m, p) for m in months for p in products], name="inv", lb=0)

    # Grid electricity used
    grid_used = model.addVars(months, name="grid_used", lb=0)

    # Generator electricity used
    gen_used = model.addVars(months, name="gen_used", lb=0)

    # Objective: minimize production cost + inventory holding cost + electricity cost
    obj = gp.quicksum(prod_cost[p] * x[m, p] for m in months for p in products) + \
          gp.quicksum(own_cost * gp.quicksum(volume[p] * inv[m, p] for p in products) for m in months) + \
          gp.quicksum(grid_electricity_cost * grid_used[m] + generator_electricity_cost * gen_used[m] for m in months)

    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    for i, m in enumerate(months):
        # Inventory balance
        for p in products:
            if i == 0:
                model.addConstr(inv[m, p] == 0 + x[m, p] - demand[m, p], name=f"inv_balance_{m}_{p}")
            else:
                prev_m = months[i - 1]
                model.addConstr(inv[m, p] == inv[prev_m, p] + x[m, p] - demand[m, p], name=f"inv_balance_{m}_{p}")

        # Machine hours capacity
        model.addConstr(gp.quicksum(machine_hours_I * x[m, 'Product_I'] + machine_hours_II * x[m, 'Product_II']) <= machine_hours_capacity, name=f"machine_hours_{m}")

        # Electricity consumption
        total_power = power_I * x[m, 'Product_I'] + power_II * x[m, 'Product_II']
        model.addConstr(grid_used[m] + gen_used[m] == total_power, name=f"total_power_{m}")
        model.addConstr(grid_used[m] <= grid_quota[m], name=f"grid_limit_{m}")
        model.addConstr(gen_used[m] <= generator_max[m], name=f"gen_limit_{m}")

        # Warehouse capacity
        total_vol = gp.quicksum(volume[p] * inv[m, p] for p in products)
        model.addConstr(total_vol <= warehouse_cap, name=f"warehouse_capacity_{m}")

    # Solve
    model.optimize()

    # Print results
    for m in months:
        for p in products:
            print(f"{m} {p}: produce={x[m, p].X:.0f}, inv={inv[m, p].X:.0f}, demand={demand[(m, p)]}")
        print(f"  Grid Used: {grid_used[m].X:.0f}, Gen Used: {gen_used[m].X:.0f}")

    print(f"FINAL_OBJ_VALUE: {model.objVal}")
