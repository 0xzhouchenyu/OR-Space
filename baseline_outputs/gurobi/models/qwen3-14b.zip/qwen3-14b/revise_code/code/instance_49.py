import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    table_2_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_2.csv")
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")

    table_1 = pd.read_csv(table_1_path)
    table_2 = pd.read_csv(table_2_path)
    params = pd.read_csv(params_path)

    # Parse parameters
    min_contract_types = int(params.loc[params['Parameter_Name'] == 'min_contract_types', 'Value'].values[0])
    max_contract_types = int(params.loc[params['Parameter_Name'] == 'max_contract_types', 'Value'].values[0])
    mutual_exclusion = str(params.loc[params['Parameter_Name'] == 'mutual_exclusion_1_and_4', 'Value'].values[0]).strip().lower() == 'true'
    monthly_max_parallel_contracts = int(params.loc[params['Parameter_Name'] == 'monthly_max_parallel_contracts', 'Value'].values[0])
    min_area_per_contract_units = int(params.loc[params['Parameter_Name'] == 'min_area_per_contract_units', 'Value'].values[0])
    activation_fee_per_contract = float(params.loc[params['Parameter_Name'] == 'activation_fee_per_contract', 'Value'].values[0])
    onboarding_loss_units = int(params.loc[params['Parameter_Name'] == 'onboarding_loss_units', 'Value'].values[0])
    expedited_onboarding_fee = float(params.loc[params['Parameter_Name'] == 'expedited_onboarding_fee', 'Value'].values[0])

    # Convert required area to units of 100 ㎡
    demands = {int(row['Month']): float(row['Required_area_㎡']) / 100.0 for _, row in table_1.iterrows()}
    costs = {int(row['Contract_length_months']): float(row['Rental_fee_per_100㎡_yuan']) for _, row in table_2.iterrows()}

    months = list(demands.keys())
    max_month = max(months)

    # Initialize model
    model = gp.Model("Warehouse_Rental")
    model.setParam('OutputFlag', 0)

    # Variables
    # x[i, j] = number of 100 sqm units rented starting at month i for j months
    x = model.addVars([(i, j) for i in months for j in costs.keys() if i + j - 1 <= max_month], name="x", vtype=gp.GRB.INTEGER, lb=0)

    # y[j] = 1 if contract length j is used, 0 otherwise
    y = model.addVars(costs.keys(), name="y", vtype=gp.GRB.BINARY)

    # z[i, j] = 1 if expedited onboarding is bought for contract starting at i with length j, 0 otherwise
    z = model.addVars([(i, j) for i in months for j in costs.keys() if i + j - 1 <= max_month], name="z", vtype=gp.GRB.BINARY)

    # Objective: Minimize total rental cost
    obj = gp.quicksum(costs[j] * x[i, j] for (i, j) in x) + gp.quicksum(activation_fee_per_contract * x[i, j] for (i, j) in x) + gp.quicksum(expedited_onboarding_fee * z[i, j] for (i, j) in z)
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    # 1. Demand fulfillment for each month
    for m in months:
        demand_expr = gp.quicksum(x[i, j] for (i, j) in x if i <= m and i + j - 1 >= m)
        # Adjust for onboarding loss
        onboarding_loss_expr = gp.quicksum((1 - z[i, j]) * onboarding_loss_units * x[i, j] for (i, j) in x if i <= m and i + j - 1 >= m and i == m)
        model.addConstr(demand_expr - onboarding_loss_expr == demands[m], name=f"demand_{m}")

    # 2. Link continuous variables x to binary variables y
    M = sum(demands.values())
    for j in costs.keys():
        model.addConstr(gp.quicksum(x[i, j] for i in months if (i, j) in x) <= M * y[j], name=f"link_upper_{j}")
        model.addConstr(gp.quicksum(x[i, j] for i in months if (i, j) in x) >= y[j], name=f"link_lower_{j}")

    # 3. Contract types limits
    model.addConstr(gp.quicksum(y[j] for j in costs.keys()) >= min_contract_types, name="min_contract_types")
    model.addConstr(gp.quicksum(y[j] for j in costs.keys()) <= max_contract_types, name="max_contract_types")

    # 4. Mutual exclusion between 1-month and 4-month contracts
    if mutual_exclusion:
        if 1 in y and 4 in y:
            model.addConstr(y[1] + y[4] <= 1, name="mutual_exclusion")

    # 5. Monthly parallel contract limit
    for m in months:
        active_contracts = gp.quicksum(x[i, j] for (i, j) in x if i <= m and i + j - 1 >= m)
        model.addConstr(active_contracts <= monthly_max_parallel_contracts, name=f"parallel_contracts_{m}")

    # 6. Minimum area per contract
    for (i, j) in x:
        model.addConstr(x[i, j] * min_area_per_contract_units <= gp.quicksum(x[i, j] for (i, j) in x), name=f"min_area_{i}_{j}")

    # Solve the problem
    model.optimize()

    # Output the objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
