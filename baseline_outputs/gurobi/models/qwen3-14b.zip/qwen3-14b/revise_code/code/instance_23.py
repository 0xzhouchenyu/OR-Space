import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'name': row['Product Name'].strip(),
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            })
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    available_labor = params['available_labor']
    available_material = params['available_material']
    fixed_costs = [params['fixed_cost_shirts'], params['fixed_cost_short_sleeves'], params['fixed_cost_casual_clothes']]
    segment_regular_discount = params['segment_regular_discount']
    segment_promo_discount = params['segment_promo_discount']
    segment_promo_labor_cap = params['segment_promo_labor_cap']
    segment_promo_material_cap = params['segment_promo_material_cap']
    min_batch_shirts = params['min_batch_shirts']
    min_batch_short_sleeves = params['min_batch_short_sleeves']
    min_batch_casual_clothes = params['min_batch_casual_clothes']
    max_prod_shirts = params['max_prod_shirts']
    max_prod_short_sleeves = params['max_prod_short_sleeves']
    max_prod_casual_clothes = params['max_prod_casual_clothes']
    
    n = len(products)
    
    # Create model
    model = gp.Model("clothing_production")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i] is total production of product i (regular + promo)
    x = [model.addVar(name=f"x_{i}", lb=0, ub=max_prod_shirts if i == 0 else (max_prod_short_sleeves if i == 1 else max_prod_casual_clothes), vtype=GRB.INTEGER) for i in range(n)]
    
    # Binary variables to indicate whether equipment is used for regular or promotional segments
    y_reg = [model.addVar(vtype=GRB.BINARY, name=f"y_reg_{i}") for i in range(n)]
    y_promo = [model.addVar(vtype=GRB.BINARY, name=f"y_promo_{i}") for i in range(n)]
    
    # Regular and promotional quantities for each product
    x_reg = [model.addVar(name=f"x_reg_{i}", lb=0, vtype=GRB.INTEGER) for i in range(n)]
    x_promo = [model.addVar(name=f"x_promo_{i}", lb=0, vtype=GRB.INTEGER) for i in range(n)]
    
    # Constraints: x[i] = x_reg[i] + x_promo[i]
    for i in range(n):
        model.addConstr(x[i] == x_reg[i] + x_promo[i], name=f"x_eq_{i}")
    
    # Constraints: If x_reg[i] > 0, then y_reg[i] = 1
    for i in range(n):
        model.addConstr(x_reg[i] <= max_prod_shirts * y_reg[i] if i == 0 else (x_reg[i] <= max_prod_short_sleeves * y_reg[i] if i == 1 else x_reg[i] <= max_prod_casual_clothes * y_reg[i]), name=f"reg_activation_{i}")
    
    # Constraints: If x_promo[i] > 0, then y_promo[i] = 1
    for i in range(n):
        model.addConstr(x_promo[i] <= max_prod_shirts * y_promo[i] if i == 0 else (x_promo[i] <= max_prod_short_sleeves * y_promo[i] if i == 1 else x_promo[i] <= max_prod_casual_clothes * y_promo[i]), name=f"promo_activation_{i}")
    
    # Minimum batch size constraints
    for i in range(n):
        model.addConstr(x[i] >= min_batch_shirts * (y_reg[i] + y_promo[i]) if i == 0 else (x[i] >= min_batch_short_sleeves * (y_reg[i] + y_promo[i]) if i == 1 else x[i] >= min_batch_casual_clothes * (y_reg[i] + y_promo[i])), name=f"min_batch_{i}")
    
    # Labor and material constraints for regular and promotional segments
    labor_total = gp.quicksum(products[i]['labor'] * x_reg[i] for i in range(n)) + gp.quicksum(products[i]['labor'] * x_promo[i] for i in range(n))
    model.addConstr(labor_total <= available_labor, name="total_labor")
    
    material_total = gp.quicksum(products[i]['material'] * x_reg[i] for i in range(n)) + gp.quicksum(products[i]['material'] * x_promo[i] for i in range(n))
    model.addConstr(material_total <= available_material, name="total_material")
    
    # Promotional segment labor and material caps
    labor_promo = gp.quicksum(products[i]['labor'] * x_promo[i] for i in range(n))
    model.addConstr(labor_promo <= segment_promo_labor_cap, name="promo_labor")
    
    material_promo = gp.quicksum(products[i]['material'] * x_promo[i] for i in range(n))
    model.addConstr(material_promo <= segment_promo_material_cap, name="promo_material")
    
    # Objective function
    profit = 0
    for i in range(n):
        reg_profit = (products[i]['price'] * segment_regular_discount - products[i]['var_cost']) * x_reg[i]
        promo_profit = (products[i]['price'] * segment_promo_discount - products[i]['var_cost']) * x_promo[i]
        profit += reg_profit + promo_profit
    
    # Subtract fixed costs only if equipment is used
    for i in range(n):
        model.addConstr(fixed_costs[i] <= fixed_costs[i] * (y_reg[i] + y_promo[i]), name=f"fixed_cost_{i}")
    
    model.setObjective(profit - gp.quicksum(fixed_costs[i] for i in range(n)), GRB.MAXIMIZE)
    
    # Optimize model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
