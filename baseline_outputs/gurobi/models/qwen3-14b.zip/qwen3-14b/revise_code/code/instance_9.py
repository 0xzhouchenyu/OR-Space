import os
import gurobipy as gp
from gurobipy import GRB
import csv

def load_toy_data(filepath):
    toys = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                'type': row['Toy_Type'].strip(),
                'profit': float(row['Profit_Per_Unit']),
                'wood': float(row['Wood_Required_Per_Unit']),
                'steel': float(row['Steel_Required_Per_Unit']),
            })
    return toys

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    toys = load_toy_data(os.path.join(data_dir, "table_1.csv"))
    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

    available_wood = params['available_wood']
    available_steel = params['available_steel']
    profit_premium_bonus = params['profit_premium_bonus']
    premium_steel_factor = params['premium_steel_factor']
    premium_shift_capacity = params['premium_shift_capacity']

    # Create model
    model = gp.Model("HausToys_Rev")
    model.setParam('OutputFlag', 0)

    # Decision variables: x_t is the quantity of toy type t produced on standard shift
    # y_t is the quantity of toy type t produced on premium shift
    x = {}
    y = {}
    for t in toys:
        x[t['type']] = model.addVar(name=f"x_{t['type']}", lb=0, ub=GRB.INFINITY)
        y[t['type']] = model.addVar(name=f"y_{t['type']}", lb=0, ub=GRB.INFINITY)

    # Binary variables: z_t indicates if toy type t is produced (either shift)
    z = {}
    for t in toys:
        z[t['type']] = model.addVar(vtype=GRB.BINARY, name=f"z_{t['type']}")

    # Objective: maximize total profit
    obj = gp.quicksum(
        (t['profit'] * x[t['type']] + (t['profit'] + profit_premium_bonus) * y[t['type']])
        for t in toys
    )
    model.setObjective(obj, GRB.MAXIMIZE)

    # Resource constraints: wood and steel
    model.addConstr(gp.quicksum(t['wood'] * (x[t['type']] + y[t['type']]) for t in toys) <= available_wood, "Wood_Constraint")
    model.addConstr(gp.quicksum(t['steel'] * x[t['type']] + t['steel'] * premium_steel_factor * y[t['type']] for t in toys) <= available_steel, "Steel_Constraint")

    # Premium shift capacity constraint
    model.addConstr(gp.quicksum(y[t['type']] for t in toys) <= premium_shift_capacity, "Premium_Shift_Capacity")

    # Linking variables: if a toy is produced, either on standard or premium shift
    for t in toys:
        model.addConstr(x[t['type']] <= z[t['type']] * GRB.INFINITY, f"x_link_{t['type']}")
        model.addConstr(y[t['type']] <= z[t['type']] * GRB.INFINITY, f"y_link_{t['type']}")

    # Truck-train exclusion: if trucks are produced (any shift), trains cannot be produced (any shift)
    model.addConstr(z['truck'] + z['train'] <= 1, "Truck_Train_Exclusion")

    # Boat-airplane dependency: if boats are produced (any shift), airplanes must be too
    model.addConstr(z['boat'] <= z['airplane'], "Boat_Airplane_Dependency")

    # Boat-train limit: total boats produced (both shifts) <= total trains produced (both shifts)
    model.addConstr(gp.quicksum(x[t['type']] + y[t['type']] for t in toys if t['type'] == 'boat') <= 
                    gp.quicksum(x[t['type']] + y[t['type']] for t in toys if t['type'] == 'train'), "Boat_Train_Limit")

    # Optimize model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
