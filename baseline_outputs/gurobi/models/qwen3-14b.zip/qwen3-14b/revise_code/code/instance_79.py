import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
sell_price_table = params['sell_price_table']
sell_price_chair = params['sell_price_chair']
sell_price_bookshelf = params['sell_price_bookshelf']

cost_table = params['manufacturing_cost_table']
cost_chair = params['manufacturing_cost_chair']
cost_bookshelf = params['manufacturing_cost_bookshelf']

space_table = params['warehouse_space_table']
space_chair = params['warehouse_space_chair']
space_bookshelf = params['warehouse_space_bookshelf']

max_warehouse = params['max_warehouse_space']
min_tables = params['min_tables']
min_bookshelves = params['min_bookshelves']
max_total = params['max_total_items']

labor_hours_table = params['labor_hours_table']
labor_hours_chair = params['labor_hours_chair']
labor_hours_bookshelf = params['labor_hours_bookshelf']

max_labor_regular = params['max_labor_hours_month_regular']
max_labor_rush = params['max_labor_hours_month_rush']
max_rush_items = params['max_rush_items_month']

rush_profit_table = params['rush_profit_bonus_table']
rush_profit_chair = params['rush_profit_bonus_chair']
rush_profit_bookshelf = params['rush_profit_bonus_bookshelf']

# Create the model
model = gp.Model("Furniture_Production")
model.setParam('OutputFlag', 0)

# Decision variables: regular and rush production for each item type
x_tables_reg = model.addVar(vtype=GRB.INTEGER, name="tables_reg")
x_tables_rush = model.addVar(vtype=GRB.INTEGER, name="tables_rush")
x_chairs_reg = model.addVar(vtype=GRB.INTEGER, name="chairs_reg")
x_chairs_rush = model.addVar(vtype=GRB.INTEGER, name="chairs_rush")
x_bookshelves_reg = model.addVar(vtype=GRB.INTEGER, name="bookshelves_reg")
x_bookshelves_rush = model.addVar(vtype=GRB.INTEGER, name="bookshelves_rush")

# Objective function: maximize profit
profit_table_reg = sell_price_table - cost_table
profit_chair_reg = sell_price_chair - cost_chair
profit_bookshelf_reg = sell_price_bookshelf - cost_bookshelf

profit_table_rush = profit_table_reg + rush_profit_table
profit_chair_rush = profit_chair_reg + rush_profit_chair
profit_bookshelf_rush = profit_bookshelf_reg + rush_profit_bookshelf

model.setObjective(
    (profit_table_reg * x_tables_reg) +
    (profit_table_rush * x_tables_rush) +
    (profit_chair_reg * x_chairs_reg) +
    (profit_chair_rush * x_chairs_rush) +
    (profit_bookshelf_reg * x_bookshelves_reg) +
    (profit_bookshelf_rush * x_bookshelves_rush),
    GRB.MAXIMIZE
)

# Constraints
# Warehouse space constraint
model.addConstr(
    (space_table * (x_tables_reg + x_tables_rush)) +
    (space_chair * (x_chairs_reg + x_chairs_rush)) +
    (space_bookshelf * (x_bookshelves_reg + x_bookshelves_rush)) <= max_warehouse,
    "Warehouse_Space"
)

# Minimum production requirements
model.addConstr(x_tables_reg + x_tables_rush >= min_tables, "Min_Tables")
model.addConstr(x_bookshelves_reg + x_bookshelves_rush >= min_bookshelves, "Min_Bookshelves")

# Maximum total production
model.addConstr(
    (x_tables_reg + x_tables_rush) +
    (x_chairs_reg + x_chairs_rush) +
    (x_bookshelves_reg + x_bookshelves_rush) <= max_total,
    "Max_Total_Items"
)

# Labor constraints for regular and rush items
model.addConstr(
    (labor_hours_table * (x_tables_reg + x_tables_rush)) +
    (labor_hours_chair * (x_chairs_reg + x_chairs_rush)) +
    (labor_hours_bookshelf * (x_bookshelves_reg + x_bookshelves_rush)) <= max_labor_regular,
    "Max_Labor_Regular"
)

model.addConstr(
    (labor_hours_table * x_tables_rush) +
    (labor_hours_chair * x_chairs_rush) +
    (labor_hours_bookshelf * x_bookshelves_rush) <= max_labor_rush,
    "Max_Labor_Rush"
)

model.addConstr(
    (x_tables_rush + x_chairs_rush + x_bookshelves_rush) <= max_rush_items,
    "Max_Rush_Items"
)

# Optimize the model
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
