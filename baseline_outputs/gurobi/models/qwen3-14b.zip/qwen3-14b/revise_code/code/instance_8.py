import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read table_1.csv
    filepath = os.path.join(data_dir, "table_1.csv")
    
    workers = []
    tasks = []
    cost = {}
    fixed_cost = {}

    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        tasks = header[1:-1]  # ['A', 'B', 'C', 'D']
        
        for row in reader:
            worker = row[0].strip()
            workers.append(worker)
            for j, task in enumerate(tasks):
                cost[(worker, task)] = int(row[j + 1])
            fixed_cost[worker] = int(row[-1])
    
    # Read general_parameters.csv
    general_params_file = os.path.join(data_dir, "general_parameters.csv")
    shared_temp_handoff_cost = 0
    worker_II_V_pair_fee = 0

    with open(general_params_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'shared_temp_handoff_cost':
                shared_temp_handoff_cost = int(row['Value'])
            elif row['Parameter_Name'] == 'worker_II_V_pair_fee':
                worker_II_V_pair_fee = int(row['Value'])

    # Create the optimization model
    model = gp.Model("Assignment")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[i,j] = 1 if worker i is assigned to task j
    x = model.addVars(workers, tasks, vtype=gp.GRB.BINARY, name="x")

    # Objective: minimize total cost (task time + fixed cost + penalties)
    obj = gp.quicksum(cost[(w, t)] * x[w, t] for w in workers for t in tasks) + \
          gp.quicksum(fixed_cost[w] * gp.quicksum(x[w, t] for t in tasks) for w in workers)

    # Penalty for using both III and V
    penalty_III_V = model.addVar(vtype=gp.GRB.CONTINUOUS, name="penalty_III_V")
    model.addGenConstrIndicator(gp.quicksum(x["III", t] for t in tasks) >= 1, 
                                True, penalty_III_V >= shared_temp_handoff_cost)
    model.addGenConstrIndicator(gp.quicksum(x["V", t] for t in tasks) >= 1, 
                                True, penalty_III_V >= shared_temp_handoff_cost)
    obj += penalty_III_V

    # Penalty for using both II and V
    penalty_II_V = model.addVar(vtype=gp.GRB.CONTINUOUS, name="penalty_II_V")
    model.addGenConstrIndicator(gp.quicksum(x["II", t] for t in tasks) >= 1, 
                                True, penalty_II_V >= worker_II_V_pair_fee)
    model.addGenConstrIndicator(gp.quicksum(x["V", t] for t in tasks) >= 1, 
                                True, penalty_II_V >= worker_II_V_pair_fee)
    obj += penalty_II_V

    model.setObjective(obj, GRB.MINIMIZE)

    # Each task must be assigned to exactly one worker
    for t in tasks:
        model.addConstr(gp.quicksum(x[w, t] for w in workers) == 1)

    # Each worker can be assigned to at most one task
    for w in workers:
        model.addConstr(gp.quicksum(x[w, t] for t in tasks) <= 1)

    # Solve
    model.optimize()

    # Print solution details
    print("Status:", model.status)
    print("\nAssignment:")
    for w in workers:
        for t in tasks:
            if x[w, t].x > 0.5:
                print(f"  Worker {w} -> Task {t} (time: {cost[(w, t)]})")

    obj_val = model.objVal
    print(f"\nFINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
