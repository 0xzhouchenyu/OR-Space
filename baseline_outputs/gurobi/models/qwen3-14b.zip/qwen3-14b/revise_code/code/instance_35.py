import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load general parameters
    general_params_path = os.path.join(base_dir, "general_parameters.csv")
    general_params = {}
    with open(general_params_path, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            if row[0] != 'parameter':
                general_params[row[0]] = float(row[1])
    
    # Load table 1 data
    table_1_path = os.path.join(base_dir, "table_1.csv")
    batches = []
    processing_times = []
    with open(table_1_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        num_vats = len(header) - 1  # exclude Batch column
        
        for row in reader:
            batch_id = int(row[0])
            times = [float(row[j+1]) for j in range(num_vats)]
            batches.append(batch_id)
            processing_times.append(times)
    
    return general_params, batches, processing_times, num_vats

def solve():
    general_params, batches, processing_times, num_vats = load_data()
    
    planning_horizon_T = int(general_params['planning_horizon_T'])
    energy_cost_v1 = general_params['energy_cost_v1']
    energy_cost_v2 = general_params['energy_cost_v2']
    energy_cost_v3 = general_params['energy_cost_v3']
    peak_energy_multiplier = general_params['peak_energy_multiplier']
    peak_energy_cap = general_params['peak_energy_cap']
    makespan_weight = general_params['makespan_weight']
    energy_weight = general_params['energy_weight']
    
    n = len(batches)
    
    # Create a new model
    model = gp.Model("fabric_dyeing_scheduling")
    model.setParam('OutputFlag', 0)
    
    # Binary variables: x[batch][vat][time] = 1 if batch starts at time on vat
    x = {}
    for batch in range(n):
        for vat in range(num_vats):
            for time in range(planning_horizon_T):
                x[(batch, vat, time)] = model.addVar(vtype=GRB.BINARY, name=f"x_{batch}_{vat}_{time}")
    
    # Binary variables: y[vat][time] = 1 if vat is active at time
    y = {}
    for vat in range(num_vats):
        for time in range(planning_horizon_T):
            y[(vat, time)] = model.addVar(vtype=GRB.BINARY, name=f"y_{vat}_{time}")
    
    # Ensure each batch is processed exactly once on each vat
    for batch in range(n):
        for vat in range(num_vats):
            model.addConstr(gp.quicksum(x[(batch, vat, time)] for time in range(planning_horizon_T)) == 1, 
                            name=f"batch_{batch}_vat_{vat}_once")
    
    # Ensure no overlapping on vats
    for vat in range(num_vats):
        for time in range(planning_horizon_T):
            model.addConstr(gp.quicksum(x[(batch, vat, time)] for batch in range(n)) <= 1, 
                            name=f"vat_{vat}_no_overlap_time_{time}")
    
    # Vat 2 maintenance shutdown during periods 4 and 5
    for batch in range(n):
        for time in range(4, 6):  # periods 4 and 5 (0-indexed)
            model.addConstr(x[(batch, 1, time)] == 0, name=f"vat2_maintenance_{batch}_{time}")
    
    # Ensure that the processing duration is respected
    for batch in range(n):
        for vat in range(num_vats):
            duration = int(round(processing_times[batch][vat] + 1e-9))  # round up to nearest integer
            for time in range(planning_horizon_T - duration + 1):
                model.addConstr(gp.quicksum(x[(batch, vat, t)] for t in range(time, time + duration)) <= 1, 
                                name=f"batch_{batch}_vat_{vat}_duration_{time}")
    
    # Ensure that the start of Vat 2 is after Vat 1 completes
    for batch in range(n):
        for time1 in range(planning_horizon_T):
            if x[(batch, 0, time1)].varName in model.getVars():
                duration1 = int(round(processing_times[batch][0] + 1e-9))
                end_time1 = time1 + duration1
                for time2 in range(end_time1, planning_horizon_T):
                    model.addConstr(x[(batch, 1, time2)] >= x[(batch, 0, time1)], 
                                    name=f"seq_batch_{batch}_vat1_to_vat2_{time1}_{time2}")
    
    # Ensure that the start of Vat 3 is after Vat 2 completes
    for batch in range(n):
        for time2 in range(planning_horizon_T):
            if x[(batch, 1, time2)].varName in model.getVars():
                duration2 = int(round(processing_times[batch][1] + 1e-9))
                end_time2 = time2 + duration2
                for time3 in range(end_time2, planning_horizon_T):
                    model.addConstr(x[(batch, 2, time3)] >= x[(batch, 1, time2)], 
                                    name=f"seq_batch_{batch}_vat2_to_vat3_{time2}_{time3}")
    
    # Link y[vat][time] to x[batch][vat][time]
    for vat in range(num_vats):
        for time in range(planning_horizon_T):
            model.addConstr(y[(vat, time)] >= gp.quicksum(x[(batch, vat, time)] for batch in range(n)), 
                            name=f"y_link_{vat}_{time}")
    
    # Compute makespan
    makespan = model.addVar(name="makespan", lb=0, ub=planning_horizon_T)
    for batch in range(n):
        for time in range(planning_horizon_T):
            if x[(batch, 2, time)].varName in model.getVars():
                duration3 = int(round(processing_times[batch][2] + 1e-9))
                end_time3 = time + duration3
                model.addConstr(makespan >= end_time3, name=f"makespan_constr_{batch}_{time}")
    
    # Compute energy cost
    energy_cost = model.addVar(name="energy_cost", lb=0)
    for vat in range(num_vats):
        for time in range(planning_horizon_T):
            if vat == 0:
                cost = energy_cost_v1
            elif vat == 1:
                cost = energy_cost_v2
            else:
                cost = energy_cost_v3
            
            if 6 <= time <= 8:
                cost *= peak_energy_multiplier
            
            model.addConstr(energy_cost >= y[(vat, time)] * cost, name=f"energy_cost_constr_{vat}_{time}")
    
    # Peak energy cap constraint
    peak_energy_usage = model.addVar(name="peak_energy_usage", lb=0)
    for vat in range(num_vats):
        for time in range(6, 9):
            model.addConstr(peak_energy_usage >= y[(vat, time)] * (energy_cost_v1 if vat == 0 else energy_cost_v2 if vat == 1 else energy_cost_v3) * peak_energy_multiplier, 
                            name=f"peak_energy_usage_constr_{vat}_{time}")
    
    model.addConstr(peak_energy_usage <= peak_energy_cap, name="peak_energy_cap")
    
    # Objective function
    model.setObjective(makespan_weight * makespan + energy_weight * energy_cost, GRB.MINIMIZE)
    
    # Optimize model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    solve()
