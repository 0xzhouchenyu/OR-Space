import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[name] = value

# Extract parameters
m1_liquid = params['machine_1_time_per_liquid_lot']  # 50 min per lot
m2_liquid = params['machine_2_time_per_liquid_lot']  # 30 min per lot
m1_solid = params['machine_1_time_per_solid_lot']    # 24 min per lot
m2_solid = params['machine_2_time_per_solid_lot']    # 33 min per lot

init_liquid = params['initial_liquid_inventory']  # 30 lots
init_solid = params['initial_solid_inventory']    # 90 lots

m1_avail = params['machine_1_available_time'] * 60  # 40 hours -> 2400 minutes
m2_avail = params['machine_2_available_time'] * 60  # 35 hours -> 2100 minutes

demand_liquid = params['forecast_liquid_demand']  # 75 lots
demand_solid = params['forecast_solid_demand']    # 95 lots

extended_extra_minutes = params['extended_extra_minutes']
labor_hours_per_machine_extended = params['labor_hours_per_machine_extended']
labor_budget_hours = params['labor_budget_hours']
extended_mode_penalty = params['extended_mode_penalty']
priority_reserve_lots = params['priority_reserve_lots']
excess_reserve_credit = params['excess_reserve_credit']

# Decision variables
model = gp.Model("Fertilizer_Production")
model.setParam('OutputFlag', 0)

x_l = model.addVar(name="x_liquid", lb=0)
x_s = model.addVar(name="x_solid", lb=0)

# Ending inventories
end_liquid = init_liquid + x_l - demand_liquid
end_solid = init_solid + x_s - demand_solid

# Resilience score components
# Priority reserve lots count fully, excess counts at excess_reserve_credit
resilience_score = 0

# Liquid resilience
if end_liquid >= priority_reserve_lots:
    resilience_score += priority_reserve_lots + (end_liquid - priority_reserve_lots) * excess_reserve_credit
else:
    resilience_score += end_liquid

# Solid resilience
if end_solid >= priority_reserve_lots:
    resilience_score += priority_reserve_lots + (end_solid - priority_reserve_lots) * excess_reserve_credit
else:
    resilience_score += end_solid

# Extended machine usage
# Check if extended time is used on either machine
extended_m1 = gp.quicksum(m1_liquid * x_l + m1_solid * x_s) > m1_avail
extended_m2 = gp.quicksum(m2_liquid * x_l + m2_solid * x_s) > m2_avail

# Calculate labor hours consumed by extended machines
extended_labor_hours = (gp.ifThen(extended_m1, labor_hours_per_machine_extended) +
                        gp.ifThen(extended_m2, labor_hours_per_machine_extended))

# Labor budget constraint
model.addConstr(extended_labor_hours <= labor_budget_hours, "Labor_Budget")

# Machine constraints
model.addConstr(m1_liquid * x_l + m1_solid * x_s <= m1_avail, "Machine_1_Capacity")
model.addConstr(m2_liquid * x_l + m2_solid * x_s <= m2_avail, "Machine_2_Capacity")

# Demand satisfaction: ending inventory >= 0
model.addConstr(end_liquid >= 0, "Liquid_Demand_Satisfaction")
model.addConstr(end_solid >= 0, "Solid_Demand_Satisfaction")

# Objective: maximize resilience score minus penalty for extended mode
penalty = (gp.ifThen(extended_m1, extended_mode_penalty) +
           gp.ifThen(extended_m2, extended_mode_penalty))
model.setObjective(resilience_score - penalty, GRB.MAXIMIZE)

model.optimize()

# Print final objective value
FINAL_OBJ_VALUE: {:.2f}".format(model.objVal)
print("FINAL_OBJ_VALUE: {:.2f}".format(model.objVal))
