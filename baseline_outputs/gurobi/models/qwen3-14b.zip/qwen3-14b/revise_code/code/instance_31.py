import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Parse data files
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load processing times, capacities, and cost rates from table_1.csv
    proc_time = {}
    capacity = {}
    cost_rate = {}
    raw_cost = {}
    price = {}

    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row["Equipment"].strip()
            if equip == "Raw_Material_Cost":
                raw_cost["I"] = float(row["Product_I"])
                raw_cost["II"] = float(row["Product_II"])
                raw_cost["III"] = float(row["Product_III"])
            elif equip == "Unit_Price":
                price["I"] = float(row["Product_I"])
                price["II"] = float(row["Product_II"])
                price["III"] = float(row["Product_III"])
            else:
                for prod, col in [("I", "Product_I"), ("II", "Product_II"), ("III", "Product_III")]:
                    val = row[col].strip()
                    if val != "-":
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row["Effective_Machine_Hours"])
                cost_rate[equip] = float(row["Processing_Cost_per_Machine_Hour"])

    # Load setup costs from setup_costs.csv
    setup_cost = {}
    with open(os.path.join(data_dir, "setup_costs.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            setup_cost[row["Equipment"]] = float(row["Fixed_Setup_Cost"])

    # Equipment assignments from general_parameters.csv
    stage_A_equip = {
        "I": ["A1", "A2"],
        "II": ["A1", "A2"],
        "III": ["A2"]
    }
    stage_B_equip = {
        "I": ["B1", "B2", "B3"],
        "II": ["B1"],
        "III": ["B2"]
    }

    # Read joint calibration parameters
    A2_B2_joint_calibration_trigger = False
    A2_B2_joint_calibration_fee = 0
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["Parameter_Name"] == "A2_B2_joint_calibration_trigger":
                A2_B2_joint_calibration_trigger = row["Value"] == "1"
            elif row["Parameter_Name"] == "A2_B2_joint_calibration_fee":
                A2_B2_joint_calibration_fee = float(row["Value"])

    # Create Gurobi model
    model = gp.Model("Factory_Production")
    model.setParam("OutputFlag", 0)

    # Decision variables: x[(equip, prod)] = units of product processed on equipment
    x = {}
    for prod in ["I", "II", "III"]:
        for equip in stage_A_equip[prod]:
            x[(equip, prod)] = model.addVar(name=f"x_{equip}_{prod}", lb=0)
        for equip in stage_B_equip[prod]:
            x[(equip, prod)] = model.addVar(name=f"x_{equip}_{prod}", lb=0)

    # Total production of each product (defined by stage A flow = stage B flow)
    total = {}
    for prod in ["I", "II", "III"]:
        total[prod] = gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod])
        # Flow conservation: stage A total == stage B total
        model.addConstr(gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod]) == gp.quicksum(x[(e, prod)] for e in stage_B_equip[prod]))

    # Capacity constraints
    for equip in ["A1", "A2", "B1", "B2", "B3"]:
        relevant = [(equip, prod) for prod in ["I", "II", "III"] if (equip, prod) in x]
        if relevant:
            model.addConstr(
                gp.quicksum(proc_time[(equip, prod)] * x[(equip, prod)] for (equip2, prod) in relevant if equip2 == equip) <= capacity[equip]
            )

    # Setup cost variables: y[e] = 1 if equipment e is used, 0 otherwise
    y = {}
    for equip in ["A1", "A2", "B1", "B2", "B3"]:
        y[equip] = model.addVar(vtype=GRB.BINARY, name=f"y_{equip}")

    # Link setup cost variables to production variables
    for equip in ["A1", "A2", "B1", "B2", "B3"]:
        for prod in ["I", "II", "III"]:
            if (equip, prod) in x:
                model.addConstr(x[(equip, prod)] <= y[equip] * 1e9)  # Big-M constraint

    # Joint calibration constraint: if both A2 and B2 are active, charge a one-time fee
    if A2_B2_joint_calibration_trigger:
        model.addConstr(y["A2"] + y["B2"] >= 1, name="joint_calibration_activation")
        model.addConstr(y["A2"] + y["B2"] <= 2, name="joint_calibration_deactivation")

    # Objective: profit = revenue - raw material - processing cost - setup cost - joint calibration fee
    revenue = gp.quicksum(price[p] * total[p] for p in ["I", "II", "III"])
    raw_mat = gp.quicksum(raw_cost[p] * total[p] for p in ["I", "II", "III"])
    proc_cost = gp.quicksum(cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x)
    setup_cost_total = gp.quicksum(setup_cost[e] * y[e] for e in ["A1", "A2", "B1", "B2", "B3"])
    joint_calibration_fee = A2_B2_joint_calibration_fee * y["A2"] * y["B2"]

    model.setObjective(revenue - raw_mat - proc_cost - setup_cost_total - joint_calibration_fee, GRB.MAXIMIZE)

    # Optimize the model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")

if __name__ == "__main__":
    main()
