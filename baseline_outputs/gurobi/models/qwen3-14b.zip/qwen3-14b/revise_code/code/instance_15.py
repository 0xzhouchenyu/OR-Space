import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    params = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    
    param_dict = dict(zip(params["Parameter_Name"], params["Value"]))
    demand = dict(zip(table_1["stage"], table_1["tool_requirement"]))
    
    return param_dict, demand

def solve():
    param_dict, demand = load_data()
    
    n = int(param_dict["n"])
    cost_new = float(param_dict["cost_new_tool"])
    cost_slow = float(param_dict["cost_slow_repair"])
    cost_fast = float(param_dict["cost_fast_repair"])
    dur_slow = int(param_dict["slow_repair_duration"])
    dur_fast = int(param_dict["fast_repair_duration"])
    max_fast_stage = int(param_dict["max_fast_stage"])
    max_slow_stage = int(param_dict["max_slow_stage"])
    emission_buy = float(param_dict["emission_buy"])
    emission_fast = float(param_dict["emission_fast_repair"])
    emission_slow = float(param_dict["emission_slow_repair"])
    carbon_budget = float(param_dict["carbon_budget"])
    penalty_shortage = float(param_dict["penalty_shortage"])
    
    stages = list(range(1, n + 1))
    
    # Variables
    model = gp.Model("Tool_Repair_Problem")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(stages, name="buy", lb=0, vtype=GRB.INTEGER)  # New tools bought at each stage
    y = model.addVars(stages, name="fast", lb=0, vtype=GRB.INTEGER)  # Tools sent to fast repair at each stage
    z = model.addVars(stages, name="slow", lb=0, vtype=GRB.INTEGER)  # Tools sent to slow repair at each stage
    c = model.addVars([0] + stages, name="clean", lb=0, vtype=GRB.INTEGER)  # Clean tools available at each stage
    d = model.addVars([0] + stages, name="dirty", lb=0, vtype=GRB.INTEGER)  # Dirty tools waiting for repair at each stage
    s = model.addVars(stages, name="shortage", lb=0, vtype=GRB.INTEGER)  # Shortage at each stage
    
    # Initial clean stock (prebuy_clean at stage 0)
    prebuy_clean = model.addVar(name="prebuy_clean", lb=0, vtype=GRB.INTEGER)
    c[0] = prebuy_clean
    
    # Objective function: minimize total cost including shortage penalties and emissions
    obj = (
        gp.quicksum(cost_new * x[i] for i in stages) +
        gp.quicksum(cost_fast * y[i] for i in stages) +
        gp.quicksum(cost_slow * z[i] for i in stages) +
        gp.quicksum(penalty_shortage * s[i] for i in stages)
    )
    
    # Emission constraint
    emission = (
        gp.quicksum(emission_buy * x[i] for i in stages) +
        gp.quicksum(emission_fast * y[i] for i in stages) +
        gp.quicksum(emission_slow * z[i] for i in stages)
    )
    model.addConstr(emission <= carbon_budget, name="carbon_budget")
    
    # Stage-wise repair capacity constraints
    for i in stages:
        model.addConstr(y[i] <= max_fast_stage, name=f"max_fast_{i}")
        model.addConstr(z[i] <= max_slow_stage, name=f"max_slow_{i}")
    
    # Flow balance for clean tools
    for i in stages:
        # Clean tools at stage i = previous clean tools + new tools - tools used in stage i
        model.addConstr(
            c[i] == c[i - 1] + x[i] - demand[i] + s[i],
            name=f"clean_balance_{i}"
        )
    
    # Flow balance for dirty tools
    for i in stages:
        # Dirty tools at stage i = previous dirty tools + tools used in stage i - tools sent to repair
        model.addConstr(
            d[i] == d[i - 1] + demand[i] - s[i] - y[i] - z[i],
            name=f"dirty_balance_{i}"
        )
    
    # Repair availability constraints
    for i in stages:
        if i - dur_fast >= 1:
            model.addConstr(c[i] >= c[i - dur_fast] + y[i - dur_fast], name=f"fast_available_{i}")
        if i - dur_slow >= 1:
            model.addConstr(c[i] >= c[i - dur_slow] + z[i - dur_slow], name=f"slow_available_{i}")
    
    # Ensure that the number of tools used in a stage does not exceed available clean tools
    for i in stages:
        model.addConstr(demand[i] - s[i] <= c[i], name=f"tool_usage_limit_{i}")
    
    model.setObjective(obj, GRB.MINIMIZE)
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
