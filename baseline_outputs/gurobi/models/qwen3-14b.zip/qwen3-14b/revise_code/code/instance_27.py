import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load general parameters
    general_params_path = os.path.join(data_dir, "general_parameters.csv")
    raw_costs = {}
    prices = {}
    shared_labor_hours = 0
    labor_coeff = {}
    b2_activation_fee = 0
    
    with open(general_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            if name == 'shared_labor_hours':
                shared_labor_hours = value
            elif name.startswith('labor_coeff_'):
                equipment = name.split('_')[2]
                labor_coeff[equipment] = value
            elif name == 'b2_activation_fee':
                b2_activation_fee = value
            else:
                if name in ['raw_material_cost_product_I', 'raw_material_cost_product_II', 'raw_material_cost_product_III']:
                    product = name.split('_')[3]
                    raw_costs[product] = value
                elif name in ['unit_price_product_I', 'unit_price_product_II', 'unit_price_product_III']:
                    product = name.split('_')[2]
                    prices[product] = value

    # Load table 1
    table1_path = os.path.join(data_dir, "table_1.csv")
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}

    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in ['Product_I', 'Product_II', 'Product_III']:
                val = row[p].strip() if row[p].strip() else None
                proc_times[e][p] = float(val) if val else None
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())

    products = ['Product_I', 'Product_II', 'Product_III']
    prod_idx = {p: i for i, p in enumerate(products)}
    A_equip = [e for e in equipment if e.startswith('A')]
    B_equip = [e for e in equipment if e.startswith('B')]

    model = gp.Model("Factory_Production")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[e][p] = number of units of product p processed on equipment e
    x = {}
    for e in equipment:
        x[e] = {}
        for p in products:
            if proc_times[e][p] is not None:
                x[e][p] = model.addVar(name=f"x_{e}_{p}", lb=0)

    # Binary variable to indicate whether B2 is used
    use_B2 = model.addVar(vtype=GRB.BINARY, name="use_B2")

    # Capacity constraints: total processing time <= effective machine hours
    for e in equipment:
        model.addConstr(
            gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None) <= eff_hours[e],
            name=f"capacity_{e}"
        )

    # Flow balance: for each product, total A-processed = total B-processed
    for p in products:
        a_sum = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
        b_sum = gp.quicksum(x[e][p] for e in B_equip if proc_times[e][p] is not None)
        model.addConstr(a_sum == b_sum, name=f"balance_{p}")

    # Labor constraint: total operator-hours consumed <= shared_labor_hours
    labor_used = gp.quicksum(
        x[e][p] * proc_times[e][p] * labor_coeff[e] for e in equipment for p in products if proc_times[e][p] is not None
    )
    model.addConstr(labor_used <= shared_labor_hours, name="labor_constraint")

    # Activation fee for B2
    model.addConstr(use_B2 >= gp.quicksum(x["B2"][p] for p in products if proc_times["B2"][p] is not None), name="b2_activation")

    # Total production of each product
    total_prod = {}
    for p in products:
        total_prod[p] = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)

    # Revenue
    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)

    # Raw material costs
    raw_cost_total = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)

    # Operating costs: proportional to usage fraction
    operating_cost = gp.quicksum(
        op_costs[e] * gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None) / eff_hours[e]
        for e in equipment
    )

    # Activation fee for B2
    activation_cost = use_B2 * b2_activation_fee

    # Objective: maximize profit
    model.setObjective(revenue - raw_cost_total - operating_cost - activation_cost, GRB.MAXIMIZE)

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")

if __name__ == "__main__":
    main()
