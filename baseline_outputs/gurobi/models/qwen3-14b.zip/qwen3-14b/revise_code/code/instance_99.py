import os
import gurobipy as gp
from gurobipy import GRB
from itertools import product

# Load data
def load_general_parameters(filename='data/general_parameters.csv'):
    """Load general parameters into a dictionary."""
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_reliability_table(filename='data/table_1.csv'):
    """Load reliability table. Returns dict: {num_spares: [r1, r2, r3]}"""
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    reliability = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            n_spares = int(row['Number_of_Spares'])
            r1 = float(row['Component_1_Reliability'])
            r2 = float(row['Component_2_Reliability'])
            r3 = float(row['Component_3_Reliability'])
            reliability[n_spares] = [r1, r2, r3]
    return reliability

def solve():
    # Load parameters
    params = load_general_parameters()
    reliability = load_reliability_table()

    # Extract parameters
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    total_budget_A = params['total_budget_scenario_A']
    total_budget_B = params['total_budget_scenario_B']
    weight_limit_A = params['weight_limit_scenario_A']
    weight_limit_B = params['weight_limit_scenario_B']

    max_spares = max(reliability.keys())

    # Create Gurobi model
    model = gp.Model("spare_allocation")
    model.setParam('OutputFlag', 0)

    # Decision variables: number of spares for each component
    s1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_spares, name="s1")
    s2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_spares, name="s2")
    s3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_spares, name="s3")

    # Objective function: maximize expected system reliability
    # Since SysRel_A and SysRel_B are the same, ExpectedReliability = SysRel_A
    # We use the reliability values based on s1, s2, s3
    # To handle this, we need to express the objective using the reliability table

    # Create a list of possible spare counts
    possible_spares = list(range(max_spares + 1))

    # Add constraints for budget and weight limits (must satisfy both scenarios)
    model.addConstr(s1 * unit_price[0] + s2 * unit_price[1] + s3 * unit_price[2] <= total_budget_A, "budget_A")
    model.addConstr(s1 * unit_price[0] + s2 * unit_price[1] + s3 * unit_price[2] <= total_budget_B, "budget_B")
    model.addConstr(s1 * unit_weight[0] + s2 * unit_weight[1] + s3 * unit_weight[2] <= weight_limit_A, "weight_A")
    model.addConstr(s1 * unit_weight[0] + s2 * unit_weight[1] + s3 * unit_weight[2] <= weight_limit_B, "weight_B")

    # Define the reliability expressions
    # Use piecewise linear functions or binary variables to represent the reliability
    # Since the reliability is stepwise, we can use binary variables to select the correct reliability value

    # For each component, create binary variables to indicate which spare count is selected
    # And then compute the reliability accordingly

    # Component 1 reliability
    comp1_rel = gp.quicksum(
        reliability[n][0] * gp.bilinear(1, (s1 == n)) for n in possible_spares
    )

    # Component 2 reliability
    comp2_rel = gp.quicksum(
        reliability[n][1] * gp.bilinear(1, (s2 == n)) for n in possible_spares
    )

    # Component 3 reliability
    comp3_rel = gp.quicksum(
        reliability[n][2] * gp.bilinear(1, (s3 == n)) for n in possible_spares
    )

    # System reliability
    sys_rel = comp1_rel * comp2_rel * comp3_rel

    # Set the objective
    model.setObjective(sys_rel, GRB.MAXIMIZE)

    # Optimize the model
    model.optimize()

    # Retrieve the optimal solution
    if model.status == GRB.OPTIMAL:
        s1_val = int(s1.x)
        s2_val = int(s2.x)
        s3_val = int(s3.x)

        # Calculate the reliabilities
        r1 = reliability[s1_val][0]
        r2 = reliability[s2_val][1]
        r3 = reliability[s3_val][2]
        obj_value = r1 * r2 * r3

        print(f"Optimal spare parts allocation: Component 1: {s1_val}, Component 2: {s2_val}, Component 3: {s3_val}")
        print(f"Total cost: {s1_val * unit_price[0] + s2_val * unit_price[1] + s3_val * unit_price[2]}")
        print(f"Total weight: {s1_val * unit_weight[0] + s2_val * unit_weight[1] + s3_val * unit_weight[2]}")
        print(f"Component reliabilities: {r1}, {r2}, {r3}")
        print(f"OBJECTIVE_VALUE: {obj_value}")

        print(f"FINAL_OBJ_VALUE: {obj_value}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    import csv
    solve()
