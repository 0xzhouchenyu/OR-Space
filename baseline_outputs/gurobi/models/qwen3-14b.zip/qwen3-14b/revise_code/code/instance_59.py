import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    data = {}
    
    # Load general_parameters.csv
    filepath = os.path.join(base_dir, "general_parameters.csv")
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data[row["Parameter_Name"]] = float(row["Value"])
    
    # Load table_1_7.csv
    filepath = os.path.join(base_dir, "table_1_7.csv")
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        data_table = {}
        for row in reader:
            item = row[0]
            data_table[item] = {
                "A": row[1],
                "B": row[2],
                "C": row[3],
                "RawMaterialCost": float(row[4]),
                "MonthlyLimit": int(row[5])
            }
        data["table"] = data_table
    
    return data

def main():
    data = load_data()
    
    # Extract parameters from data
    setup_cost_A = data.get("SetupCost_A", 0)
    setup_cost_B = data.get("SetupCost_B", 0)
    setup_cost_C = data.get("SetupCost_C", 0)
    brand_ab_shared_wrapper_trigger = data.get("BrandAB_SharedWrapper_Trigger", 0)
    brand_ab_shared_wrapper_fee = data.get("BrandAB_SharedWrapper_Fee", 0)
    
    table = data["table"]
    
    # Raw material cost and monthly limits
    raw_materials = ["A", "B", "C"]
    raw_costs = [table[rm]["RawMaterialCost"] for rm in raw_materials]
    monthly_limits = [table[rm]["MonthlyLimit"] for rm in raw_materials]
    
    # Processing fee and selling price
    brands = ["A", "B", "C"]
    processing_fees = []
    selling_prices = []
    for brand in brands:
        processing_fees.append(float(table[brand]["Processing Fee (Yuan/kg)"]))
        selling_prices.append(float(table[brand]["Selling Price (Yuan/kg)"]))
    
    # Composition constraints
    composition_constraints = {}
    for item in table:
        if item not in ["Processing Fee (Yuan/kg)", "Selling Price (Yuan/kg)"]:
            constraints = table[item]
            composition_constraints[item] = {
                "A": constraints["A"],
                "B": constraints["B"],
                "C": constraints["C"]
            }
    
    # Create model
    model = gp.Model("CandyFactory")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i][j] = kg of raw material i used in brand j
    x = {}
    for i in range(3):
        for j in range(3):
            x[i, j] = model.addVar(name=f"x_{raw_materials[i]}_{brands[j]}", lb=0)
    
    # Total production of each brand
    y = {}
    for j in range(3):
        y[j] = model.addVar(name=f"y_{brands[j]}", lb=0)
    
    # Link total production to raw material usage
    for j in range(3):
        model.addConstr(y[j] == gp.quicksum(x[i, j] for i in range(3)))
    
    # Objective function
    revenue = gp.quicksum(selling_prices[j] * y[j] for j in range(3))
    material_cost = gp.quicksum(raw_costs[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(processing_fees[j] * y[j] for j in range(3))
    
    # Setup costs
    setup_cost = 0
    produce_A = model.addVar(vtype=GRB.BINARY, name="produce_A")
    produce_B = model.addVar(vtype=GRB.BINARY, name="produce_B")
    produce_C = model.addVar(vtype=GRB.BINARY, name="produce_C")
    
    model.addConstr(produce_A >= (y[0] > 1e-6))
    model.addConstr(produce_B >= (y[1] > 1e-6))
    model.addConstr(produce_C >= (y[2] > 1e-6))
    
    setup_cost += setup_cost_A * produce_A
    setup_cost += setup_cost_B * produce_B
    setup_cost += setup_cost_C * produce_C
    
    # Shared wrapper coordination pass for A and B
    shared_wrapper = model.addVar(vtype=GRB.BINARY, name="shared_wrapper")
    model.addConstr(shared_wrapper >= produce_A + produce_B - 1)
    model.addConstr(shared_wrapper <= produce_A)
    model.addConstr(shared_wrapper <= produce_B)
    setup_cost += brand_ab_shared_wrapper_fee * shared_wrapper
    
    # Raw material supply constraints
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= monthly_limits[i])
    
    # Composition constraints
    for item in composition_constraints:
        for j in range(3):
            constraint = composition_constraints[item]
            value = constraint[brands[j]]
            if value:
                if value.startswith(">="):
                    lower_bound = float(value[2:])
                    model.addConstr(x[raw_materials.index(item), j] >= lower_bound * y[j])
                elif value.startswith("<="):
                    upper_bound = float(value[2:])
                    model.addConstr(x[raw_materials.index(item), j] <= upper_bound * y[j])
    
    # Set objective
    model.setObjective(revenue - material_cost - processing_cost - setup_cost, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    # Print results
    print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")

if __name__ == "__main__":
    main()
