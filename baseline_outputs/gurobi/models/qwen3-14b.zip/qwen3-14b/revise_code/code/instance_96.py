import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    params = {}
    for _, row in df_params.iterrows():
        params[row['Parameter_Name']] = row['Value']

    # Supplier 1 parameters
    raw_pipe_length_s1 = float(params['raw_pipe_length_supplier1'])
    max_patterns_s1 = int(params['max_cutting_patterns_supplier1'])
    most_freq_cost_rate_s1 = float(params['most_frequent_pattern_cost_rate_supplier1'])
    second_freq_cost_rate_s1 = float(params['second_frequent_pattern_cost_rate_supplier1'])
    third_freq_cost_rate_s1 = float(params['third_frequent_pattern_cost_rate_supplier1'])
    max_cuts_s1 = int(params['max_cuts_per_pipe_supplier1'])
    max_leftover_s1 = float(params['max_leftover_length_supplier1'])
    purchase_cost_s1 = float(params['purchase_cost_per_pipe_supplier1'])
    discount_tier1_max_qty_s1 = int(params['discount_tier1_supplier1_max_qty'])
    fixed_discount_tier2_s1 = float(params['fixed_discount_tier2_supplier1'])
    bigM_discount = int(params['bigM_discount'])

    # Supplier 2 parameters
    raw_pipe_length_s2 = float(params['raw_pipe_length_supplier2'])
    max_patterns_s2 = int(params['max_cutting_patterns_supplier2'])
    most_freq_cost_rate_s2 = float(params['most_frequent_pattern_cost_rate_supplier2'])
    second_freq_cost_rate_s2 = float(params['second_frequent_pattern_cost_rate_supplier2'])
    third_freq_cost_rate_s2 = float(params['third_frequent_pattern_cost_rate_supplier2'])
    max_cuts_s2 = int(params['max_cuts_per_pipe_supplier2'])
    max_leftover_s2 = float(params['max_leftover_length_supplier2'])
    purchase_cost_s2 = float(params['purchase_cost_per_pipe_supplier2'])

    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)

    # Generate patterns for supplier 1
    def generate_patterns_s1():
        patterns = []
        min_length_s1 = raw_pipe_length_s1 - max_leftover_s1

        def recursive_generate(current_pattern, current_length, current_cuts, item_idx):
            if item_idx == n_items:
                if current_length >= min_length_s1 and current_length <= raw_pipe_length_s1 and current_cuts > 0:
                    patterns.append(tuple(current_pattern))
                return

            max_qty = min(
                int((raw_pipe_length_s1 - current_length) // lengths[item_idx]),
                max_cuts_s1 - current_cuts
            )

            for q in range(max_qty + 1):
                recursive_generate(
                    current_pattern + [q],
                    current_length + q * lengths[item_idx],
                    current_cuts + q,
                    item_idx + 1
                )

        recursive_generate([], 0, 0, 0)
        return patterns

    patterns_s1 = generate_patterns_s1()

    # Generate patterns for supplier 2
    def generate_patterns_s2():
        patterns = []
        min_length_s2 = raw_pipe_length_s2 - max_leftover_s2

        def recursive_generate(current_pattern, current_length, current_cuts, item_idx):
            if item_idx == n_items:
                if current_length >= min_length_s2 and current_length <= raw_pipe_length_s2 and current_cuts > 0:
                    patterns.append(tuple(current_pattern))
                return

            max_qty = min(
                int((raw_pipe_length_s2 - current_length) // lengths[item_idx]),
                max_cuts_s2 - current_cuts
            )

            for q in range(max_qty + 1):
                recursive_generate(
                    current_pattern + [q],
                    current_length + q * lengths[item_idx],
                    current_cuts + q,
                    item_idx + 1
                )

        recursive_generate([], 0, 0, 0)
        return patterns

    patterns_s2 = generate_patterns_s2()

    model = gp.Model("Pipe_Cutting_With_Suppliers")
    model.setParam('OutputFlag', 0)

    # Variables for supplier 1
    y_s1 = model.addVars(range(len(patterns_s1)), name="y_s1", vtype=GRB.INTEGER, lb=0)
    z_s1 = model.addVars(range(len(patterns_s1)), name="z_s1", vtype=GRB.BINARY)
    u_s1 = model.addVars(range(1, max_patterns_s1 + 1), name="u_s1", vtype=GRB.BINARY)

    # Variables for supplier 2
    y_s2 = model.addVars(range(len(patterns_s2)), name="y_s2", vtype=GRB.INTEGER, lb=0)
    z_s2 = model.addVars(range(len(patterns_s2)), name="z_s2", vtype=GRB.BINARY)
    u_s2 = model.addVars(range(1, max_patterns_s2 + 1), name="u_s2", vtype=GRB.BINARY)

    # Variables for number of pipes purchased from each supplier
    x_s1 = model.addVar(name="x_s1", vtype=GRB.INTEGER, lb=0)
    x_s2 = model.addVar(name="x_s2", vtype=GRB.INTEGER, lb=0)

    # Discount tier activation variable for supplier 1
    t_s1 = model.addVar(name="t_s1", vtype=GRB.BINARY)

    # Objective function
    obj = (purchase_cost_s1 * x_s1) + (purchase_cost_s2 * x_s2)

    # Pattern frequency cost for supplier 1
    cost_rates_s1 = [most_freq_cost_rate_s1, second_freq_cost_rate_s1, third_freq_cost_rate_s1]
    for k in range(1, max_patterns_s1 + 1):
        if k - 1 < len(cost_rates_s1):
            obj += cost_rates_s1[k - 1] * u_s1[k]

    # Pattern frequency cost for supplier 2
    cost_rates_s2 = [most_freq_cost_rate_s2, second_freq_cost_rate_s2, third_freq_cost_rate_s2]
    for k in range(1, max_patterns_s2 + 1):
        if k - 1 < len(cost_rates_s2):
            obj += cost_rates_s2[k - 1] * u_s2[k]

    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints for supplier 1
    for i in range(n_items):
        model.addConstr(gp.quicksum(patterns_s1[p][i] * y_s1[p] for p in range(len(patterns_s1))) >= demands[i])

    M = sum(demands)
    for p in range(len(patterns_s1)):
        model.addConstr(y_s1[p] <= M * z_s1[p])

    model.addConstr(gp.quicksum(z_s1[p] for p in range(len(patterns_s1))) == gp.quicksum(u_s1[k] for k in range(1, max_patterns_s1 + 1)))

    for k in range(1, max_patterns_s1):
        model.addConstr(u_s1[k] >= u_s1[k+1])

    model.addConstr(gp.quicksum(z_s1[p] for p in range(len(patterns_s1))) <= max_patterns_s1)

    # Constraints for supplier 2
    for i in range(n_items):
        model.addConstr(gp.quicksum(patterns_s2[p][i] * y_s2[p] for p in range(len(patterns_s2))) >= demands[i])

    for p in range(len(patterns_s2)):
        model.addConstr(y_s2[p] <= M * z_s2[p])

    model.addConstr(gp.quicksum(z_s2[p] for p in range(len(patterns_s2))) == gp.quicksum(u_s2[k] for k in range(1, max_patterns_s2 + 1)))

    for k in range(1, max_patterns_s2):
        model.addConstr(u_s2[k] >= u_s2[k+1])

    model.addConstr(gp.quicksum(z_s2[p] for p in range(len(patterns_s2))) <= max_patterns_s2)

    # Linking variables to the number of pipes used
    model.addConstr(x_s1 >= gp.quicksum(y_s1[p] for p in range(len(patterns_s1))))
    model.addConstr(x_s2 >= gp.quicksum(y_s2[p] for p in range(len(patterns_s2))))

    # Discount logic for supplier 1
    model.addConstr(x_s1 - bigM_discount * t_s1 <= discount_tier1_max_qty_s1 - 1)
    model.addConstr(x_s1 - bigM_discount * (1 - t_s1) >= discount_tier1_max_qty_s1)
    model.addConstr(obj >= (purchase_cost_s1 * x_s1) - fixed_discount_tier2_s1 * t_s1)

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
