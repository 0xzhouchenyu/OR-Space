import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read general parameters
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    total_space = params["mall_total_space"]
    rent_pct = params["rent_percentage"] / 100.0
    common_area_factor = params["common_area_factor"]
    catering_third_store_security_threshold = int(params["catering_third_store_security_threshold"])
    catering_third_store_security_cost = params["catering_third_store_security_cost"]
    
    # Read store data
    stores = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            area = int(row["Area_per_Shop_m2"].strip())
            min_n = int(row["Min"].strip())
            max_n = int(row["Max"].strip())
            profits = {}
            for k in range(1, 4):
                key = f"Profit_{k}_Store" if k == 1 else f"Profit_{k}_Stores"
                val = row.get(key, "-").strip()
                if val and val != "-":
                    profits[k] = float(val)
            stores.append({
                "name": row["Store_Type"].strip(),
                "area": area,
                "min": min_n,
                "max": max_n,
                "profits": profits  # per-store profit when n stores of this type
            })
    
    # Create Gurobi model
    model = gp.Model("Optimal_Store_Allocation")
    model.setParam("OutputFlag", 0)
    
    # Decision variables: number of stores for each type
    num_stores = len(stores)
    x = model.addVars(num_stores, vtype=GRB.INTEGER, name="x", lb=[s["min"] for s in stores], ub=[s["max"] for s in stores])
    
    # Calculate total effective area used (including common area factor)
    total_area_used = gp.quicksum(x[i] * stores[i]["area"] * common_area_factor for i in range(num_stores))
    model.addConstr(total_area_used <= total_space, "Space_Constraint")
    
    # Objective function: maximize total rental income
    total_profit = gp.quicksum(0)  # Initialize
    
    for i in range(num_stores):
        for k in stores[i]["profits"]:
            # If exactly k stores of this type are chosen, use the corresponding profit
            model.addConstr(x[i] == k, name=f"Profit_{i}_k_{k}", rhs=k, sense=GRB.EQUAL)
            total_profit += x[i] * stores[i]["profits"][k]
    
    # Catering third store security cost
    catering_index = next(i for i, s in enumerate(stores) if s["name"] == "Catering")
    model.addConstr(x[catering_index] >= catering_third_store_security_threshold + 1, name="Catering_Third_Store")
    total_profit -= catering_third_store_security_cost
    
    # Maximize total rental income (rent percentage of total profit)
    model.setObjective(rent_pct * total_profit, GRB.MAXIMIZE)
    
    # Optimize model
    model.optimize()
    
    # Extract solution
    best_combo = [int(x[i].X) for i in range(num_stores)]
    total_area = sum(best_combo[i] * stores[i]["area"] for i in range(num_stores)) * common_area_factor
    total_profit_value = 0
    valid = True
    
    for i, n in enumerate(best_combo):
        if n == 0:
            continue
        if n in stores[i]["profits"]:
            total_profit_value += n * stores[i]["profits"][n]
        else:
            valid = False
    
    if valid:
        total_rent = rent_pct * total_profit_value
        if best_combo[catering_index] > catering_third_store_security_threshold:
            total_rent -= rent_pct * catering_third_store_security_cost
    else:
        total_rent = 0
    
    print(f"FINAL_OBJ_VALUE: {total_rent}")

if __name__ == "__main__":
    main()
