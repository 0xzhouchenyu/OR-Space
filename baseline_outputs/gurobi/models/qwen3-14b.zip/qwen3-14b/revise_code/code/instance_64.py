import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    budget = params['company_budget']
    max_employees = int(params['max_employees'])
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_gj = int(params['max_one_candidate_g_j'])
    lead_premium = params['lead_premium']
    min_leads = int(params['min_leads'])
    mentor_bonus = params['mentor_bonus']
    max_pairs = int(params['max_pairs'])
    
    # Create optimization model
    model = gp.Model("HiringOptimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: binary for each candidate (hired or not)
    x = model.addVars([c['name'] for c in candidates], vtype=GRB.BINARY, name="x")
    
    # Decision variables: binary for each candidate's role (Lead or Engineer)
    is_lead = model.addVars([c['name'] for c in candidates], vtype=GRB.BINARY, name="is_lead")
    
    # Objective: minimize total net cost
    # Total salary + lead premium - mentor bonus
    total_salary = gp.quicksum(c['salary'] * x[c['name']] for c in candidates)
    total_lead_premium = gp.quicksum(lead_premium * is_lead[c['name']] for c in candidates)
    
    # Count the number of Lead-Engineer pairs
    num_leads = gp.quicksum(is_lead[c['name']] * x[c['name']] for c in candidates)
    num_engineers = gp.quicksum((1 - is_lead[c['name']]) * x[c['name']] for c in candidates)
    num_pairs = gp.min_(num_leads, num_engineers)
    num_pairs = gp.min_(num_pairs, max_pairs)
    
    total_mentor_bonus = mentor_bonus * num_pairs
    
    model.setObjective(total_salary + total_lead_premium - total_mentor_bonus, GRB.MINIMIZE)
    
    # Constraints
    # Budget constraint
    model.addConstr(gp.quicksum(c['salary'] * x[c['name']] for c in candidates) + 
                    gp.quicksum(lead_premium * is_lead[c['name']] for c in candidates) <= budget, "Budget")
    
    # Max employees constraint
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, "MaxEmployees")
    
    # Min skill level constraint
    model.addConstr(gp.quicksum(c['skill'] * x[c['name']] for c in candidates) >= min_skill, "MinSkill")
    
    # Min project management experience constraint
    model.addConstr(gp.quicksum(c['pm_exp'] * x[c['name']] for c in candidates) >= min_pm_exp, "MinPMExp")
    
    # At most one of G and J can be hired
    model.addConstr(x['G'] + x['J'] <= max_gj, "MaxOneGJ")
    
    # Each hired candidate must have exactly one role
    for c in candidates:
        model.addConstr(is_lead[c['name']] + (1 - is_lead[c['name']]) == 1, f"Role_{c['name']}")
    
    # Minimum number of leads
    model.addConstr(gp.quicksum(is_lead[c['name']] * x[c['name']] for c in candidates) >= min_leads, "MinLeads")
    
    # Ensure that a candidate cannot be a lead if not hired
    for c in candidates:
        model.addConstr(is_lead[c['name']] <= x[c['name']], f"LeadIfHired_{c['name']}")
    
    # Solve
    model.optimize()
    
    # Print results
    print(f"Status: {model.status}")
    for c in candidates:
        if x[c['name']].X > 0.5:
            print(f"Hire {c['name']}: Role={'Lead' if is_lead[c['name']].X > 0.5 else 'Engineer'}, Salary={c['salary']}, Skill={c['skill']}, PM_Exp={c['pm_exp']}")
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
