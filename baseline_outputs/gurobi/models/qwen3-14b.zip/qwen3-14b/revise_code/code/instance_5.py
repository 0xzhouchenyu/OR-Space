import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    # Load data
    table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    
    df = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)
    
    budget = float(params[params['Parameter_Name'] == 'budget']['Value'].iloc[0])
    food_intake = float(params[params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
    weekday_budget_share = float(params[params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
    max_prep_time_weekday = float(params[params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
    max_prep_time_weekend = float(params[params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
    weekend_protein_ban = int(params[params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
    veg_balance_penalty = float(params[params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])
    
    # Fill missing fiber content with 0
    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)
    
    foods = df['Food'].tolist()
    types = df.set_index('Food')['Type'].to_dict()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()
    
    # Create problem
    model = gp.Model("Maximize_Fiber_Two_Dinners")
    model.setParam('OutputFlag', 0)
    
    # Variables: x is amount in 100g units for weekday and weekend
    x_weekday = model.addVars(foods, name="x_weekday", lb=0)
    x_weekend = model.addVars(foods, name="x_weekend", lb=0)
    
    y_weekday = model.addVars(foods, vtype=GRB.BINARY, name="y_weekday")
    y_weekend = model.addVars(foods, vtype=GRB.BINARY, name="y_weekend")
    
    # Objective: maximize fiber
    obj = gp.quicksum(fiber[f] * x_weekday[f] + fiber[f] * x_weekend[f] for f in foods)
    
    # Veg balance penalty
    veg_total_weekday = gp.quicksum(x_weekday[f] for f in foods if types[f] == 'vegetable')
    veg_total_weekend = gp.quicksum(x_weekend[f] for f in foods if types[f] == 'vegetable')
    obj -= veg_balance_penalty * abs(veg_total_weekday - veg_total_weekend)
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints
    # Total food intake per dinner
    for f in foods:
        model.addConstr(x_weekday[f] == food_intake / 100.0 * y_weekday[f])
        model.addConstr(x_weekend[f] == food_intake / 100.0 * y_weekend[f])
    
    # Budget constraint
    weekday_budget = budget * weekday_budget_share
    weekend_budget = budget - weekday_budget
    
    model.addConstr(gp.quicksum(price[f] * x_weekday[f] for f in foods) <= weekday_budget)
    model.addConstr(gp.quicksum(price[f] * x_weekend[f] for f in foods) <= weekend_budget)
    
    # Prep time constraints
    model.addConstr(gp.quicksum(prep_time[f] * x_weekday[f] for f in foods) <= max_prep_time_weekday)
    model.addConstr(gp.quicksum(prep_time[f] * x_weekend[f] for f in foods) <= max_prep_time_weekend)
    
    # Exactly one protein source per dinner
    proteins = [f for f in foods if types[f] == 'protein']
    for p in proteins:
        model.addConstr(y_weekday[p] + y_weekend[p] <= 1)
    
    # At least two kinds of vegetables per dinner
    vegetables = [f for f in foods if types[f] == 'vegetable']
    model.addConstr(gp.quicksum(y_weekday[v] for v in vegetables) >= 2)
    model.addConstr(gp.quicksum(y_weekend[v] for v in vegetables) >= 2)
    
    # Weekend protein ban
    if weekend_protein_ban == 1:
        for p in proteins:
            model.addConstr(x_weekend[p] == 0)
    
    # Protein labels only if used in at least one meal
    for p in proteins:
        model.addConstr(y_weekday[p] + y_weekend[p] >= 0.5 * (y_weekday[p] + y_weekend[p]))
    
    # Solve the problem
    model.optimize()
    
    return round(model.objVal, 4)

if __name__ == '__main__':
    print(f"FINAL_OBJ_VALUE: {solve()}")
