import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_restaurant_data, load_general_parameters

def main():
    # Determine data directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Load data
    restaurants = load_restaurant_data(os.path.join(data_dir, "table_1.csv"))
    params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    investment_budget = params['investment_budget']
    premium_revenue_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']
    
    # Create the optimization problem
    model = gp.Model("Restaurant_Investment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: binary (buy or not)
    x = {}
    for r in restaurants:
        x[r['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{r['name']}")
    
    # Decision variables: binary (Premium or Standard mode)
    y = {}
    for r in restaurants:
        y[r['name']] = model.addVar(vtype=GRB.BINARY, name=f"y_{r['name']}")
    
    # Objective: maximize total annual revenue
    obj = gp.quicksum(
        (r['revenue'] * (1 + premium_revenue_uplift) * y[r['name']] + r['revenue'] * (1 - y[r['name']])) * x[r['name']]
        for r in restaurants
    )
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Budget constraint: purchase cost + premium upgrade cost if selected for Premium
    model.addConstr(
        gp.quicksum((r['cost'] + y[r['name']] * premium_upgrade_cost) * x[r['name']] for r in restaurants) <= investment_budget,
        "Budget_Constraint"
    )
    
    # Staff hours constraint: only Premium mode consumes staff hours
    model.addConstr(
        gp.quicksum(r['Premium_Staff_Hours'] * y[r['name']] * x[r['name']] for r in restaurants) <= staff_hours_cap,
        "Staff_Hours_Constraint"
    )
    
    # If Restaurant D is purchased, Restaurant A cannot be purchased
    if 'Restaurant_D' in x and 'Restaurant_A' in x:
        model.addConstr(x['Restaurant_D'] + x['Restaurant_A'] <= 1, "D_A_Exclusion_Constraint")
    
    # Solve
    model.optimize()
    
    # Print results
    print(f"Status: {model.status}")
    for r in restaurants:
        val_x = x[r['name']].X
        val_y = y[r['name']].X
        print(f"{r['name']}: {'Buy' if val_x > 0.5 else 'Do not buy'}, {'Premium' if val_y > 0.5 else 'Standard'} (x={val_x}, y={val_y})")
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
