import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read costs from table_1.csv
    children = []
    cost_budget = {}
    cost_balanced = {}
    cost_premium = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row['Child'].strip()
            children.append(child)
            cost_budget[child] = float(row['Cost_budget'].strip())
            cost_balanced[child] = float(row['Cost_balanced'].strip())
            cost_premium[child] = float(row['Cost_premium'].strip())
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children = int(params['max_children'])
    min_children = int(params['min_children'])
    fairness_penalty = float(params['fairness_penalty'])
    max_total_cost = float(params['max_total_cost'])
    min_children_per_mode = int(params['min_children_per_mode'])
    
    # Create model
    model = gp.Model("ZhangFamilyTrip")
    model.setParam('OutputFlag', 0)
    
    # Binary variables for each child (whether they are selected)
    x = model.addVars(children, vtype=GRB.BINARY, name="x")
    
    # Binary variables for mode selection: budget, balanced, premium
    mode = model.addVars(3, vtype=GRB.BINARY, name="mode")
    
    # Objective function: minimize total cost + fairness penalty
    # First, calculate the total cost based on the selected mode
    total_cost = gp.quicksum(
        (x[child] * cost_budget[child] * mode[0] +
         x[child] * cost_balanced[child] * mode[1] +
         x[child] * cost_premium[child] * mode[2]) for child in children
    )
    
    # Calculate the spread between max and min child cost under the selected mode
    # We need to find the max and min cost of selected children per mode
    # This is done using auxiliary variables and constraints
    
    # For each mode, define max and min cost among selected children
    # Use big-M method to enforce these relationships
    
    M = 1000000  # A large enough constant
    
    # Define max and min cost for each mode
    max_cost_budget = model.addVars(1, lb=0, ub=10000, name="max_cost_budget")
    min_cost_budget = model.addVars(1, lb=0, ub=10000, name="min_cost_budget")
    max_cost_balanced = model.addVars(1, lb=0, ub=10000, name="max_cost_balanced")
    min_cost_balanced = model.addVars(1, lb=0, ub=10000, name="min_cost_balanced")
    max_cost_premium = model.addVars(1, lb=0, ub=10000, name="max_cost_premium")
    min_cost_premium = model.addVars(1, lb=0, ub=10000, name="min_cost_premium")
    
    # Constraints to compute max and min cost for budget mode
    for child in children:
        model.addConstr(max_cost_budget[0] >= x[child] * cost_budget[child])
        model.addConstr(min_cost_budget[0] <= x[child] * cost_budget[child])
    
    # Constraints to compute max and min cost for balanced mode
    for child in children:
        model.addConstr(max_cost_balanced[0] >= x[child] * cost_balanced[child])
        model.addConstr(min_cost_balanced[0] <= x[child] * cost_balanced[child])
    
    # Constraints to compute max and min cost for premium mode
    for child in children:
        model.addConstr(max_cost_premium[0] >= x[child] * cost_premium[child])
        model.addConstr(min_cost_premium[0] <= x[child] * cost_premium[child])
    
    # Compute the spread for each mode
    spread_budget = max_cost_budget[0] - min_cost_budget[0]
    spread_balanced = max_cost_balanced[0] - min_cost_balanced[0]
    spread_premium = max_cost_premium[0] - min_cost_premium[0]
    
    # Add fairness penalty based on the selected mode
    fairness_penalty_term = (
        fairness_penalty * (spread_budget * mode[0] +
                            spread_balanced * mode[1] +
                            spread_premium * mode[2])
    )
    
    # Total objective: total cost + fairness penalty
    model.setObjective(total_cost + fairness_penalty_term, GRB.MINIMIZE)
    
    # Constraints
    
    # Ginny must go
    model.addConstr(x['Ginny'] == 1, "Ginny_must_go")
    
    # At most max_children
    model.addConstr(gp.quicksum(x[child] for child in children) <= max_children, "Max_children")
    
    # At least min_children
    model.addConstr(gp.quicksum(x[child] for child in children) >= min_children, "Min_children")
    
    # If Harry is taken, Fred cannot be taken
    model.addConstr(x['Harry'] + x['Fred'] <= 1, "Harry_no_Fred")
    
    # If Harry is taken, George cannot be taken
    model.addConstr(x['Harry'] + x['George'] <= 1, "Harry_no_George")
    
    # If George is taken, Fred must also be taken
    model.addConstr(x['George'] <= x['Fred'], "George_requires_Fred")
    
    # If George is taken, Hermione must also be taken
    model.addConstr(x['George'] <= x['Hermione'], "George_requires_Hermione")
    
    # Mode constraints: only one mode can be selected
    model.addConstr(mode[0] + mode[1] + mode[2] == 1, "One_mode_selected")
    
    # Budget mode: no additional constraint on group size
    # Balanced and Premium modes require at least min_children_per_mode
    model.addConstr(gp.quicksum(x[child] for child in children) >= min_children_per_mode * (mode[1] + mode[2]), "Min_children_per_mode")
    
    # Total cost must not exceed max_total_cost
    model.addConstr(total_cost <= max_total_cost, "Max_total_cost")
    
    # Solve the model
    model.optimize()
    
    # Print solution details
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
