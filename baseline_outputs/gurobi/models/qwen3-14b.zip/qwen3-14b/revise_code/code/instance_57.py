import csv
import math
import gurobipy as gp
from gurobipy import GRB
import os

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def solve():
    # Load order data
    table_1_path = get_data_path('table_1.csv')
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
    
    # Load general parameters
    params_path = get_data_path('general_parameters.csv')
    std_widths = []
    pattern_setup_penalty = 0
    wide_roll_threshold_width = 0
    wide_roll_extra_setup_penalty = 0
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'standard_width_1':
                std_widths.append(float(row['Value']))
            elif row['Parameter_Name'] == 'standard_width_2':
                std_widths.append(float(row['Value']))
            elif row['Parameter_Name'] == 'pattern_setup_penalty':
                pattern_setup_penalty = float(row['Value'])
            elif row['Parameter_Name'] == 'wide_roll_threshold_width':
                wide_roll_threshold_width = float(row['Value'])
            elif row['Parameter_Name'] == 'wide_roll_extra_setup_penalty':
                wide_roll_extra_setup_penalty = float(row['Value'])

    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    total_required_area = sum(w * l for w, l in zip(widths, lengths))

    # Generate cutting patterns for each standard width
    patterns_by_std_width = {}
    for idx, sw in enumerate(std_widths):
        patterns = []
        def build_pattern(index, current_pattern, current_sum):
            if index == len(widths):
                if any(c > 0 for c in current_pattern):
                    patterns.append(current_pattern)
                return
            
            max_count = int(math.floor((sw - current_sum + 1e-7) / widths[index]))
            for count in range(max_count + 1):
                build_pattern(index + 1, current_pattern + [count], current_sum + count * widths[index])
                
        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {'sw': sw, 'patterns': patterns}
    
    # Create Gurobi model
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)

    # Variables: x_vars[(std_idx, pattern_idx)] = number of times this pattern is used
    x_vars = {}
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            x_vars[(idx, i)] = model.addVar(name=f"x_{idx}_{i}", lb=0, vtype=GRB.CONTINUOUS)

    # Objective: Minimize total area used (waste = total area used - required area)
    total_area_used = gp.quicksum(data['sw'] * x_vars[(idx, i)] for idx, data in patterns_by_std_width.items() for i, p in enumerate(data['patterns']))
    model.setObjective(total_area_used - total_required_area, GRB.MINIMIZE)

    # Constraints: Satisfy length requirements for each order width
    for j in range(len(widths)):
        model.addConstr(gp.quicksum(p[j] * x_vars[(idx, i)] for idx, data in patterns_by_std_width.items() for i, p in enumerate(data['patterns'])) >= lengths[j])

    # Add setup penalties
    used_patterns = set()
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            if any(c > 0 for c in p):
                used_patterns.add((idx, i))
    
    # Track unique patterns and apply penalties
    pattern_penalty = model.addVar(name="pattern_penalty", lb=0, vtype=GRB.CONTINUOUS)
    wide_roll_penalty = model.addVar(name="wide_roll_penalty", lb=0, vtype=GRB.CONTINUOUS)

    # Count the number of unique patterns used
    num_unique_patterns = 0
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            if any(c > 0 for c in p):
                num_unique_patterns += 1

    # Apply pattern setup penalty
    model.addConstr(pattern_penalty == pattern_setup_penalty * num_unique_patterns)

    # Apply wide roll extra setup penalty
    wide_roll_count = 0
    for idx, data in patterns_by_std_width.items():
        if data['sw'] >= wide_roll_threshold_width:
            for i, p in enumerate(data['patterns']):
                if any(c > 0 for c in p):
                    wide_roll_count += 1
    model.addConstr(wide_roll_penalty == wide_roll_extra_setup_penalty * wide_roll_count)

    # Update objective to include penalties
    model.setObjective(total_area_used - total_required_area + pattern_penalty + wide_roll_penalty, GRB.MINIMIZE)

    # Optimize the model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {round(model.objVal, 4)}")

if __name__ == "__main__":
    solve()
