import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Read general parameters
    params = {}
    with open(params_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('Parameter_Name'):
                continue
            parts = line.split(',')
            params[parts[0]] = ','.join(parts[1:-2]) if len(parts) > 4 else parts[1]

    num_customers = int(params['num_customers'])
    max_trucks = int(params['max_trucks'])
    truck_capacity = float(params['truck_capacity'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])
    depot_str = params.get('depot_coordinates', '(40,50)').strip('()')
    depot_x, depot_y = map(float, depot_str.split(','))
    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])
    fixed_service_time = float(params['fixed_service_time'])

    # Read customer data
    coords = [(depot_x, depot_y)]
    demands_list = [0]
    tw_list = [(depot_tw_start, depot_tw_end)]
    svc_list = [0]
    outsource_cost = [0]
    mandatory_external = [0]

    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((float(row['Coordinates_X']), float(row['Coordinates_Y'])))
            demands_list.append(float(row['Demand']))
            tw_list.append((float(row['Time_Window_Start']), float(row['Time_Window_End'])))
            svc_list.append(float(row['Service_Duration']))
            outsource_cost.append(float(row['Outsource_Cost']))
            mandatory_external.append(int(row['Mandatory_External']))

    n = len(coords)
    N = list(range(1, n))
    V = list(range(n))

    dist = {}
    for i in V:
        for j in V:
            dist[i, j] = calculate_distance(coords[i], coords[j])

    # Filter out customers that are mandatory external
    filtered_N = []
    filtered_demands = []
    filtered_tw = []
    filtered_svc = []
    filtered_outsource = []

    for idx in range(1, n):
        if mandatory_external[idx] == 1:
            filtered_outsource.append(outsource_cost[idx])
        else:
            filtered_N.append(idx)
            filtered_demands.append(demands_list[idx])
            filtered_tw.append(tw_list[idx])
            filtered_svc.append(svc_list[idx])
            filtered_outsource.append(0)

    N_filtered = filtered_N
    n_filtered = len(N_filtered)
    demands_list = filtered_demands
    tw_list = filtered_tw
    svc_list = filtered_svc
    outsource_cost = filtered_outsource

    # Create model
    model = gp.Model("VRPHTW_Rev")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = model.addVars([(i, j) for i in V for j in V if i != j], vtype=GRB.BINARY, name="x")
    t = model.addVars(V, lb=0, ub=GRB.INFINITY, name="t")
    y = model.addVars(N_filtered, vtype=GRB.BINARY, name="y")  # 1 if customer is served by in-house truck, 0 if outsourced

    # Objective: minimize total in-house travel distance + outsourcing cost
    obj = gp.quicksum(dist[i, j] * x[i, j] for i in V for j in V if i != j) + gp.quicksum(outsource_cost[i-1] * (1 - y[i]) for i in N_filtered)
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    # Each customer is either served by a truck or outsourced
    for i in N_filtered:
        model.addConstr(y[i] + (1 - y[i]) == 1)

    # Each customer served by a truck must be visited exactly once
    for i in N_filtered:
        model.addConstr(gp.quicksum(x[j, i] for j in V if j != i) == y[i])
        model.addConstr(gp.quicksum(x[i, j] for j in V if j != i) == y[i])

    # Depot must be the start and end of each route
    model.addConstr(gp.quicksum(x[0, j] for j in N_filtered) <= inhouse_truck_limit)

    # Time window constraints for depot
    model.addConstr(t[0] >= depot_tw_start)
    model.addConstr(t[0] <= depot_tw_end)

    # Time window constraints for customers
    for i in N_filtered:
        model.addConstr(t[i] >= tw_list[i - 1][0])
        model.addConstr(t[i] <= tw_list[i - 1][1])

    # Time consistency constraints
    M_val = depot_tw_end + max(svc_list)
    for i in V:
        for j in V:
            if i != j:
                model.addConstr(t[i] + svc_list[i] + dist[i, j] - t[j] <= M_val * (1 - x[i, j]))

    # Capacity constraints
    for i in V:
        for j in V:
            if i != j and i != 0 and j != 0:
                model.addConstr(gp.quicksum(demands_list[k - 1] * x[i, k] for k in N_filtered if k != i) + gp.quicksum(demands_list[k - 1] * x[k, j] for k in N_filtered if k != j) <= truck_capacity * (1 - x[i, j]))

    # Solve the model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {round(model.objVal, 2)}")

solve()
