import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    base = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base, 'data')
    
    # Read general parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = next(reader)
        n = int(params['Value'])
        premium_cost_multiplier = float(params['Value']) if params['Parameter_Name'] == 'premium_cost_multiplier' else 1.5
        min_premium_share = float(params['Value']) if params['Parameter_Name'] == 'min_premium_share' else 0.4
    
    # Read transportation volume and cost data
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    n_factories = len(rows)
    d = []
    c = []
    for row in rows:
        d.append([float(row[f'Transportation_volume_to_Location_{j+1}']) for j in range(n_factories)])
        c.append([float(row[f'Transportation_cost_to_Location_{j+1}']) for j in range(n_factories)])
    
    # Compute outbound volumes for each factory
    outbound_volumes = [sum(d[i]) for i in range(n_factories)]
    
    # Create Gurobi model
    model = gp.Model("Factory_Location_Assignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i][p] = 1 if factory i is assigned to location p
    x = model.addVars(n_factories, n_factories, vtype=GRB.BINARY, name="x")
    
    # Decision variables: y[i][p] = 1 if factory i at location p uses premium handling
    y = model.addVars(n_factories, n_factories, vtype=GRB.BINARY, name="y")
    
    # Decision variables: v_std[i][p] = volume handled in standard mode at location p for factory i
    v_std = model.addVars(n_factories, n_factories, lb=0, name="v_std")
    
    # Decision variables: v_prem[i][p] = volume handled in premium mode at location p for factory i
    v_prem = model.addVars(n_factories, n_factories, lb=0, name="v_prem")
    
    # Each factory must be assigned to exactly one location
    for i in range(n_factories):
        model.addConstr(gp.quicksum(x[i, p] for p in range(n_factories)) == 1, name=f"Assign_Factory_{i}")
    
    # No more than one factory can be assigned to a location
    for p in range(n_factories):
        model.addConstr(gp.quicksum(x[i, p] for i in range(n_factories)) <= 1, name=f"One_Factory_Per_Location_{p}")
    
    # If a factory is assigned to a location, its total outbound volume is split between standard and premium
    for i in range(n_factories):
        for p in range(n_factories):
            model.addConstr(v_std[i, p] + v_prem[i, p] == x[i, p] * outbound_volumes[i], name=f"Outbound_Volume_Split_{i}_{p}")
    
    # Premium handling implies at least 40% of the factory's outbound volume is handled in premium mode
    for i in range(n_factories):
        for p in range(n_factories):
            model.addConstr(v_prem[i, p] >= y[i, p] * min_premium_share * outbound_volumes[i], name=f"Premium_Min_Share_{i}_{p}")
    
    # Objective function: minimize total transportation and handling cost
    obj = 0
    
    # Transportation cost: sum over all factories i, locations p, and destinations q of d[i][q] * c[p][q] * x[i][p]
    for i in range(n_factories):
        for p in range(n_factories):
            for q in range(n_factories):
                obj += d[i][q] * c[p][q] * x[i, p]
    
    # Handling cost: standard and premium costs based on service mode
    for i in range(n_factories):
        for p in range(n_factories):
            # Standard handling cost per unit
            if outbound_volumes[i] > 0:
                c_std_ip = sum(d[i][q] * c[p][q] for q in range(n_factories)) / outbound_volumes[i]
                c_prem_ip = c_std_ip * premium_cost_multiplier
            else:
                c_std_ip = 0
                c_prem_ip = 0
            
            # Add standard and premium handling costs
            obj += c_std_ip * v_std[i, p] + c_prem_ip * v_prem[i, p]
    
    model.setObjective(obj, GRB.MINIMIZE)
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

solve()
