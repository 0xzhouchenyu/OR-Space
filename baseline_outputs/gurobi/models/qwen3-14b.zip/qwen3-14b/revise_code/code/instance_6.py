import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load demand data
    demand = {}
    with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
        reader = csv.reader(f)
        header = next(reader)
        quarters = [int(h) for h in header[1:]]
        for row in reader:
            product = row[0].strip()
            for j, q in enumerate(quarters):
                demand[(product, q)] = int(row[j + 1])
    
    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"])
    
    products = ["I", "II", "III"]
    quarters = [1, 2, 3, 4]
    
    init_inv = params["initial_inventory"]
    end_inv_req = params["end_inventory_requirement"]
    hours_per_quarter = params["production_hours_per_quarter"]
    hours_per_unit = {
        "I": params["product_I_hours_per_unit"],
        "II": params["product_II_hours_per_unit"],
        "III": params["product_III_hours_per_unit"],
    }
    delay_penalty = {
        "I": params["delay_penalty_product_I"],
        "II": params["delay_penalty_product_II"],
        "III": params["delay_penalty_product_III"],
    }
    inv_cost = params["inventory_cost_per_unit"]
    
    # Peak and normal hour parameters
    normal_hours_cap_fraction = {
        1: params["normal_hours_cap_fraction_q1"],
        2: params["normal_hours_cap_fraction_q2"],
        3: params["normal_hours_cap_fraction_q3"],
        4: params["normal_hours_cap_fraction_q4"],
    }
    peak_hours_cap = {
        1: params["peak_hours_cap_q1"],
        2: params["peak_hours_cap_q2"],
        3: params["peak_hours_cap_q3"],
        4: params["peak_hours_cap_q4"],
    }
    peak_cost_per_hour = {
        1: params["peak_cost_per_hour_q1"],
        2: params["peak_cost_per_hour_q2"],
        3: params["peak_cost_per_hour_q3"],
        4: params["peak_cost_per_hour_q4"],
    }
    
    # Create model
    model = gp.Model("ProductionScheduling")
    model.setParam("OutputFlag", 0)
    
    # Decision variables: production quantities
    x = model.addVars(products, quarters, name="x", lb=0, vtype=gp.GRB.INTEGER)
    
    # Product I cannot be produced in Q2
    x["I", 2].UB = 0
    
    # Inventory variables
    inv = model.addVars(products, quarters, name="inv")
    inv_pos = model.addVars(products, quarters, name="inv_pos", lb=0)
    inv_neg = model.addVars(products, quarters, name="inv_neg", lb=0)
    
    # Normal and peak production hours per quarter
    normal_hours = model.addVars(quarters, name="normal_hours", lb=0)
    peak_hours = model.addVars(quarters, name="peak_hours", lb=0)
    
    # Inventory balance constraints
    for p in products:
        # Quarter 1
        model.addConstr(inv[p, 1] == init_inv + x[p, 1] - demand[p, 1])
        # Quarters 2-4
        for t in range(2, 5):
            model.addConstr(inv[p, t] == inv[p, t - 1] + x[p, t] - demand[p, t])
    
    # Split inventory into positive and negative parts
    for p in products:
        for t in quarters:
            model.addConstr(inv[p, t] == inv_pos[p, t] - inv_neg[p, t])
    
    # End of Q4: inventory must be at least end_inv_req
    for p in products:
        model.addConstr(inv[p, 4] >= end_inv_req)
    
    # Production hours constraint per quarter (normal and peak)
    for t in quarters:
        normal_cap = hours_per_quarter * normal_hours_cap_fraction[t]
        model.addConstr(normal_hours[t] <= normal_cap)
        model.addConstr(peak_hours[t] <= peak_hours_cap[t])
        model.addConstr(
            gp.quicksum(hours_per_unit[p] * x[p, t] for p in products)
            <= normal_hours[t] + peak_hours[t]
        )
    
    # Objective: minimize delay penalties + inventory holding costs + peak cost
    obj = gp.quicksum(
        delay_penalty[p] * inv_neg[p, t] + inv_cost * inv_pos[p, t]
        for p in products
        for t in quarters
    ) + gp.quicksum(peak_cost_per_hour[t] * peak_hours[t] for t in quarters)
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Optimize the model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
