import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")
table1_file = os.path.join(data_dir, "table_1.csv")

# Load general parameters
def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

params = load_parameters(params_file)

# Extract parameters
cow_price = params['cow_selling_price']
sheep_price = params['sheep_selling_price']
chicken_price = params['chicken_selling_price']
cow_feed = params['cow_feed_cost']
sheep_feed = params['sheep_feed_cost']
chicken_feed = params['chicken_feed_cost']
cow_manure = params['cow_manure_production']
sheep_manure = params['sheep_manure_production']
chicken_manure = params['chicken_manure_production']
max_manure = params['max_manure_capacity']
max_chickens = params['max_chickens']
min_cows = params['min_cows']
min_sheep = params['min_sheep']
max_total = params['max_total_animals']
premium_capacity_multiplier = params['premium_capacity_multiplier']
premium_manure_multiplier = params['premium_manure_multiplier']
expansion_cost = params['expansion_cost']
premium_feed_multiplier = params['premium_feed_multiplier']
base_land_usage_cow = params['base_land_usage_cow']
base_land_usage_sheep = params['base_land_usage_sheep']
base_land_usage_chicken = params['base_land_usage_chicken']
base_land_capacity = params['base_land_capacity']
expansion_land_increase = params['expansion_land_increase']

# Create model
model = gp.Model("FarmProfit")
model.setParam('OutputFlag', 0)

# Decision variables
cows = model.addVar(name="cows", lb=min_cows, vtype=GRB.INTEGER)
sheep = model.addVar(name="sheep", lb=min_sheep, vtype=GRB.INTEGER)
chickens = model.addVar(name="chickens", lb=0, ub=max_chickens, vtype=GRB.INTEGER)
expanded_mode = model.addVar(name="expanded_mode", vtype=GRB.BINARY)

# Premium animal indicators
is_premium_cow = model.addVar(name="is_premium_cow", vtype=GRB.BINARY)
is_premium_sheep = model.addVar(name="is_premium_sheep", vtype=GRB.BINARY)
is_premium_chicken = model.addVar(name="is_premium_chicken", vtype=GRB.BINARY)

# Link premium animals to expanded mode
model.addConstr(is_premium_cow <= expanded_mode)
model.addConstr(is_premium_sheep <= expanded_mode)
model.addConstr(is_premium_chicken <= expanded_mode)

# Objective function
profit_cow = (cow_price - cow_feed * (1 + premium_feed_multiplier * is_premium_cow))
profit_sheep = (sheep_price - sheep_feed * (1 + premium_feed_multiplier * is_premium_sheep))
profit_chicken = (chicken_price - chicken_feed * (1 + premium_feed_multiplier * is_premium_chicken))

model.setObjective(
    profit_cow * cows + profit_sheep * sheep + profit_chicken * chickens - expansion_cost * expanded_mode,
    GRB.MAXIMIZE
)

# Constraints
# Manure capacity
manure_used = cow_manure * cows + sheep_manure * sheep + chicken_manure * chickens
manure_capacity = max_manure * (1 + premium_manure_multiplier * expanded_mode)
model.addConstr(manure_used <= manure_capacity)

# Total animals capacity
total_animals_capacity = max_total * (1 + premium_capacity_multiplier * expanded_mode)
model.addConstr(cows + sheep + chickens <= total_animals_capacity)

# Land usage constraint
land_used = (
    base_land_usage_cow * cows +
    base_land_usage_sheep * sheep +
    base_land_usage_chicken * chickens
)
land_capacity = base_land_capacity + expansion_land_increase * expanded_mode
model.addConstr(land_used <= land_capacity)

# Solve the model
model.optimize()

# Print final objective value
final_obj_value = model.objVal
print(f"FINAL_OBJ_VALUE: {final_obj_value}")
