import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load general parameters
    general_params_path = os.path.join(data_dir, "general_parameters.csv")
    with open(general_params_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        general_params = {row['Parameter_Name']: float(row['Value']) for row in reader}
    
    # Load table 1
    table1_path = os.path.join(data_dir, "table_1.csv")
    with open(table1_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        table1 = list(reader)
    
    # Parse table1
    proc_I = table1[0]
    proc_II = table1[1]
    profit_row = table1[2]
    
    a_I = float(proc_I['Model_A_hours_per_unit'])  # 4
    b_I = float(proc_I['Model_B_hours_per_unit'])  # 6
    cap_I = float(proc_I['Maximum_Weekly_Processing_Capacity'])  # 150
    
    a_II = float(proc_II['Model_A_hours_per_unit'])  # 3
    b_II = float(proc_II['Model_B_hours_per_unit'])  # 2
    cap_II = float(proc_II['Maximum_Weekly_Processing_Capacity'])  # 70
    
    profit_A = float(profit_row['Model_A_hours_per_unit'])  # 300
    profit_B = float(profit_row['Model_B_hours_per_unit'])  # 450
    
    min_profit = general_params['min_weekly_profit']  # 10000
    min_A = general_params['min_model_A_units']  # 10
    min_B = general_params['min_model_B_units']  # 15
    proc_I_hours = general_params['process_I_hours']  # 150
    max_overtime = general_params['process_II_max_overtime']  # 30
    red_A = general_params['model_A_overtime_profit_reduction']  # 20
    red_B = general_params['model_B_overtime_profit_reduction']  # 25
    
    # Create model
    model = gp.Model("Microcomputer_Production")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    xA_r = model.addVar(name="xA_r", lb=0)  # Regular production of A
    xA_o = model.addVar(name="xA_o", lb=0)  # Overtime production of A
    xB_r = model.addVar(name="xB_r", lb=0)  # Regular production of B
    xB_o = model.addVar(name="xB_o", lb=0)  # Overtime production of B
    
    total_A = xA_r + xA_o
    total_B = xB_r + xB_o
    
    # Process I constraint: exact hours
    model.addConstr(a_I * total_A + b_I * total_B == proc_I_hours, name="Process_I")
    
    # Process II regular capacity
    model.addConstr(a_II * xA_r + b_II * xB_r <= cap_II, name="Process_II_regular")
    
    # Process II overtime capacity
    model.addConstr(a_II * xA_o + b_II * xB_o <= max_overtime, name="Process_II_overtime")
    
    # Minimum production constraints
    model.addConstr(total_A >= min_A, name="Min_A")
    model.addConstr(total_B >= min_B, name="Min_B")
    
    # Profit constraint (minimum weekly profit)
    profit = (profit_A * xA_r + profit_B * xB_r + (profit_A - red_A) * xA_o + (profit_B - red_B) * xB_o)
    model.addConstr(profit >= min_profit, name="Min_Profit")
    
    # Objective: maximize total number of units produced
    model.setObjective(total_A + total_B, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    # Print results
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
