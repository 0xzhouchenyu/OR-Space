import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    
    max_children_per_day = int(params["max_children_trip"])
    min_children_per_day = int(params["min_children_trip"])
    max_distinct_children = int(params["max_distinct_children_trip"])
    total_cost_budget = int(params["total_cost_budget"])
    bonus_saving = int(params["bonus_saving"])
    min_bob_days = int(params["min_bob_days"])
    
    # Read table_1 for children and costs
    children = []
    costs = {}
    availability = {}
    constraints = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Child"].strip()
            cost = int(row["Cost"].strip())
            children.append(name)
            costs[name] = cost
            availability[name] = []
            if "Only available on day 2" in row["Relationship_Constraint"]:
                availability[name].append(2)
            elif "Must be taken on at least one day" in row["Relationship_Constraint"]:
                availability[name] = [1, 2]
            else:
                availability[name] = [1, 2]
            constraints[name] = row["Relationship_Constraint"]
    
    # Create the optimization model
    model = gp.Model("FamilyTripTwoDays")
    model.setParam("OutputFlag", 0)
    
    # Decision variables: binary for each child on each day
    x = {}
    for child in children:
        for day in [1, 2]:
            x[(child, day)] = model.addVar(vtype=GRB.BINARY, name=f"x_{child}_day{day}")
    
    # Objective: minimize total two-day cost minus bonus savings
    total_cost = 0
    bonus = 0
    for child in children:
        for day in [1, 2]:
            total_cost += costs[child] * x[(child, day)]
        # Bonus is applied once per child if present on both days
        bonus += bonus_saving * (x[(child, 1)] + x[(child, 2)] - 1)  # 1 if both days, 0 otherwise
    model.setObjective(total_cost - bonus, GRB.MINIMIZE)
    
    # Constraint: min and max children per day
    for day in [1, 2]:
        model.addConstr(gp.quicksum(x[(child, day)] for child in children) >= min_children_per_day, f"MinChildrenDay{day}")
        model.addConstr(gp.quicksum(x[(child, day)] for child in children) <= max_children_per_day, f"MaxChildrenDay{day}")
    
    # Constraint: Bob must attend at least min_bob_days days
    model.addConstr(gp.quicksum(x[("Bob", day)] for day in [1, 2]) >= min_bob_days, "MinBobDays")
    
    # Constraint: Charlie and Diana only on day 2
    for child in ["Charlie", "Diana"]:
        for day in [1]:
            model.addConstr(x[(child, day)] == 0, f"{child}NotOnDay{day}")
    
    # Constraint: Alice only on day 1
    for day in [2]:
        model.addConstr(x[("Alice", day)] == 0, f"AliceNotOnDay{day}")
    
    # Constraint: Alice and Diana cannot be on the same day
    for day in [1, 2]:
        model.addConstr(x[("Alice", day)] + x[("Diana", day)] <= 1, f"AliceDianaConflictDay{day}")
    
    # Constraint: Bob and Charlie cannot be on the same day
    for day in [1, 2]:
        model.addConstr(x[("Bob", day)] + x[("Charlie", day)] <= 1, f"BobCharlieConflictDay{day}")
    
    # Constraint: Charlie must be accompanied by Diana on the same day
    for day in [1, 2]:
        model.addConstr(x[("Charlie", day)] <= x[("Diana", day)], f"CharlieRequiresDianaDay{day}")
    
    # Constraint: Diana must be accompanied by Ella on the same day
    for day in [1, 2]:
        model.addConstr(x[("Diana", day)] <= x[("Ella", day)], f"DianaRequiresEllaDay{day}")
    
    # Constraint: Max distinct children over both days
    distinct_children = gp.quicksum(
        x[(child, 1)] + x[(child, 2)] >= 1 for child in children
    )
    model.addConstr(distinct_children <= max_distinct_children, "MaxDistinctChildren")
    
    # Constraint: Total cost must not exceed budget
    model.addConstr(total_cost <= total_cost_budget, "TotalCostBudget")
    
    # Optimize the model
    model.optimize()
    
    # Print solution details
    print("Status:", model.status)
    for child in children:
        day1 = x[(child, 1)].X > 0.5
        day2 = x[(child, 2)].X > 0.5
        if day1 or day2:
            print(f"  {child}: Day 1={day1}, Day 2={day2}, Cost={costs[child]}")
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
