import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, "table_1.csv")
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "general_parameters.csv")
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    machine_avail = params['machine_time_available']  # hours
    craftsman_regular_avail = params['craftsman_regular_time_available']  # hours
    craftsman_overtime_avail = params['craftsman_overtime_available']  # hours
    machine_cost = params['machine_time_cost']  # GBP per hour
    craftsman_cost = params['craftsman_time_cost']  # GBP per hour
    craftsman_overtime_cost = params['craftsman_overtime_cost']  # GBP per hour
    rev_X = params['revenue_product_X']  # GBP per batch
    rev_Y = params['revenue_product_Y']  # GBP per batch
    min_X = params['min_batches_product_X']  # batches
    y_qa_threshold = params['product_Y_QA_threshold']  # batches
    y_qa_fee = params['product_Y_QA_fee']  # GBP
    
    # Create model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    X = model.addVar(name="X", lb=0)
    Y = model.addVar(name="Y", lb=0)
    
    # Machine time used (in hours)
    machine_hours_used = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0
    
    # Craftsman time used (in hours)
    craftsman_hours_used = (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0
    
    # Split craftsman time into regular and overtime
    craftsman_regular_used = gp.quicksum([craftsman_hours_used])  # Placeholder for actual split logic
    craftsman_overtime_used = gp.quicksum([craftsman_hours_used])  # Placeholder for actual split logic
    
    # Correctly split craftsman time between regular and overtime
    craftsman_regular_used = gp.min_(craftsman_hours_used, craftsman_regular_avail)
    craftsman_overtime_used = gp.max_(craftsman_hours_used - craftsman_regular_avail, 0)
    
    # Objective: maximize profit
    profit = rev_X * X + rev_Y * Y - machine_cost * machine_hours_used - craftsman_cost * craftsman_regular_used - craftsman_overtime_cost * craftsman_overtime_used
    
    # QA fee if Y exceeds threshold
    y_qa_fee_var = gp.quicksum([y_qa_fee * gp.ifThen(Y > y_qa_threshold, 1, 0)])
    profit -= y_qa_fee_var
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Constraints
    model.addConstr(machine_hours_used <= machine_avail, "Machine_Time_Constraint")
    model.addConstr(craftsman_regular_used <= craftsman_regular_avail, "Craftsman_Regular_Time_Constraint")
    model.addConstr(craftsman_overtime_used <= craftsman_overtime_avail, "Craftsman_Overtime_Time_Constraint")
    model.addConstr(X >= min_X, "Min_Production_X")
    
    # Optimize model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")

if __name__ == "__main__":
    main()
