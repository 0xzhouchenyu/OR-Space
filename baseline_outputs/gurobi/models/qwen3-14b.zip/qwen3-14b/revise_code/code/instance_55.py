import os
import gurobipy as gp
from gurobipy import GRB
import csv

def load_courses(data_dir):
    """Load course data from table_1.csv"""
    filepath = os.path.join(data_dir, 'table_1.csv')
    courses = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            categories = [c.strip() for c in row['Category'].split(';')]
            courses[course] = categories
    return courses

def load_parameters(data_dir):
    """Load general parameters from general_parameters.csv"""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    prerequisites = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if name == 'min_courses_required':
                params['min_courses_required'] = int(value)
            elif name.startswith('prerequisite_'):
                course_key = name[len('prerequisite_'):]
                prerequisites[course_key] = value
            elif name == 'mandatory_foundation_for_cs_counting':
                params['mandatory_foundation_for_cs_counting'] = value
            elif name == 'cs_category_name':
                params['cs_category_name'] = value
    return params, prerequisites

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    courses = load_courses(data_dir)
    params, prereq_raw = load_parameters(data_dir)

    min_required = params['min_courses_required']
    cs_category = params['cs_category_name']
    mandatory_cs_foundation = params['mandatory_foundation_for_cs_counting']

    # Build prerequisite mapping: course -> list of prerequisites
    course_list = list(courses.keys())
    prerequisites = {}

    for prereq_key, prereq_value in prereq_raw.items():
        course_name = None
        for course in course_list:
            if course.lower() == prereq_key.replace('_', ' ').lower():
                course_name = course
                break
        if course_name:
            if course_name not in prerequisites:
                prerequisites[course_name] = []
            prerequisites[course_name].append(prereq_value.strip())

    # Create optimization model
    model = gp.Model("CourseSelection")
    model.setParam('OutputFlag', 0)

    # Decision variables: binary, whether to take each course
    x = model.addVars(course_list, vtype=GRB.BINARY, name="x")

    # Objective: minimize total number of courses taken
    model.setObjective(gp.quicksum(x[course] for course in course_list), GRB.MINIMIZE)

    # Constraint: at least min_required courses in each category
    all_categories = set()
    for cats in courses.values():
        for c in cats:
            all_categories.add(c)

    for category in all_categories:
        courses_in_cat = [course for course, cats in courses.items() if category in cats]
        model.addConstr(gp.quicksum(x[course] for course in courses_in_cat) >= min_required, name=f"Min_{category}")

    # Prerequisite constraints: if you take a course, you must take its prerequisites
    for course, prereqs in prerequisites.items():
        for prereq in prereqs:
            model.addConstr(x[course] <= x[prereq], name=f"Prereq_{course.replace(' ', '_')}_needs_{prereq.replace(' ', '_')}")

    # Mandatory foundation for Computer Science
    if cs_category in all_categories:
        cs_courses = [course for course, cats in courses.items() if cs_category in cats]
        model.addConstr(gp.quicksum(x[course] for course in cs_courses) <= gp.quicksum(x[mandatory_cs_foundation]) * min_required,
                        name="MandatoryCSFoundation")

    # Solve
    model.optimize()

    print("\nStatus: {}".format(model.status))
    print("\nSelected courses:")
    selected_courses = [course for course in course_list if x[course].x > 0.5]
    for course in selected_courses:
        print(f"  {course}: {courses[course]}")

    obj_val = model.objVal
    print(f"\nFINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
