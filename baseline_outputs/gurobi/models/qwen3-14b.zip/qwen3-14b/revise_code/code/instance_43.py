import os
import sys
import gurobipy as gp
from gurobipy import GRB
from utils import load_parameters

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
min_A = params['min_raw_material_A']
min_B = params['min_raw_material_B']
min_C = params['min_raw_material_C']

cap_A_a = params['warehouse_A_truck_capacity_A']
cap_A_b = params['warehouse_A_truck_capacity_B']
cap_A_c = params['warehouse_A_truck_capacity_C']
cost_A = params['warehouse_A_truck_cost']
fixed_cost_A = params['warehouse_A_fixed_cost']

cap_B_a = params['warehouse_B_truck_capacity_A']
cap_B_b = params['warehouse_B_truck_capacity_B']
cap_B_c = params['warehouse_B_truck_capacity_C']
cost_B = params['warehouse_B_truck_cost']
fixed_cost_B = params['warehouse_B_fixed_cost']
overflow_threshold_B = params['warehouse_B_overflow_threshold_trucks']
overflow_coordination_cost_B = params['warehouse_B_overflow_coordination_cost']
dual_reconciliation_trigger = params['dual_warehouse_reconciliation_trigger']
dual_reconciliation_fee = params['dual_warehouse_reconciliation_fee']

# Create the MIP problem
model = gp.Model("MinFreightCost")
model.setParam('OutputFlag', 0)

# Decision variables: number of trucks from warehouse A and B (integers, non-negative)
x = model.addVar(name="trucks_from_A", vtype=GRB.INTEGER, lb=0)
y = model.addVar(name="trucks_from_B", vtype=GRB.INTEGER, lb=0)

# Objective: minimize total freight cost
obj = (
    cost_A * x + fixed_cost_A * gp.quicksum(1 for _ in range(1) if x > 0) +
    cost_B * y + fixed_cost_B * gp.quicksum(1 for _ in range(1) if y > 0) +
    overflow_coordination_cost_B * gp.quicksum(1 for _ in range(1) if y > overflow_threshold_B) +
    dual_reconciliation_fee * gp.quicksum(1 for _ in range(1) if x > 0 and y > 0)
)
model.setObjective(obj, GRB.MINIMIZE)

# Constraints: meet minimum raw material requirements
model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# Optimize the model
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
