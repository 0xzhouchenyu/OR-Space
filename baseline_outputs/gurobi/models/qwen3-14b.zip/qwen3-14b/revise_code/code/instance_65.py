import os
import csv
import gurobipy as gp
from gurobipy import GRB

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv")) as f:
    for row in csv.DictReader(f):
        params[row["Parameter_Name"].strip()] = float(row["Value"])

products = {}
with open(os.path.join(data_dir, "table_1.csv")) as f:
    for row in csv.DictReader(f):
        products[row["Product"].strip()] = {
            "a_hrs": float(row["Workshop_A_Hours"]),
            "b_hrs": float(row["Workshop_B_Hours"]),
            "insp_cost": float(row["Inspection_Sales_Cost"]),
        }

m = products["Microwave_Oven"]
w = products["Water_Heater"]

model = gp.Model("production")
model.setParam("OutputFlag", 0)

# Decision variables
x1 = model.addVar(name="microwave", lb=params["microwave_minimum_sales"])
x2 = model.addVar(name="water_heater", lb=params["water_heater_minimum_sales"])

# Binary variables to indicate if a product uses workshop A
y1 = model.addVar(vtype=GRB.BINARY, name="microwave_use_A")
y2 = model.addVar(vtype=GRB.BINARY, name="water_heater_use_A")

# Setup hours for workshop A (only if product uses workshop A)
setup_hours_A = params["setup_hours_A"]
tech_pool_hours = params["tech_pool_hours"]
tech_rate_m = params["tech_rate_m"]
tech_rate_w = params["tech_rate_w"]
green_bonus_m = params["green_bonus_m"]
green_bonus_w = params["green_bonus_w"]

# Objective function: maximize profit
profit_m = (
    m["a_hrs"] * params["workshop_a_hourly_cost"]
    + m["b_hrs"] * params["workshop_b_hourly_cost"]
    + m["insp_cost"]
    + green_bonus_m
)
profit_w = (
    w["a_hrs"] * params["workshop_a_hourly_cost"]
    + w["b_hrs"] * params["workshop_b_hourly_cost"]
    + w["insp_cost"]
    + green_bonus_w
)

model.setObjective(
    (profit_m - m["insp_cost"]) * x1 + (profit_w - w["insp_cost"]) * x2,
    GRB.MAXIMIZE,
)

# Constraints
# Workshop A available hours including setup and overtime
model.addConstr(
    y1 * setup_hours_A + m["a_hrs"] * x1
    + y2 * setup_hours_A + w["a_hrs"] * x2
    <= params["workshop_a_available_hours"] + params["workshop_a_overtime_limit"],
    name="workshop_a_capacity"
)

# Workshop B available hours
model.addConstr(
    m["b_hrs"] * x1 + w["b_hrs"] * x2 >= params["workshop_b_available_hours"],
    name="workshop_b_capacity"
)

# Inspection and sales cost limit
model.addConstr(
    m["insp_cost"] * x1 + w["insp_cost"] * x2 <= params["inspection_sales_cost_limit"],
    name="inspection_sales_cost"
)

# Technician pool constraint
model.addConstr(
    (y1 * tech_rate_m + (1 - y1) * 0) * x1
    + (y2 * tech_rate_w + (1 - y2) * 0) * x2
    <= tech_pool_hours,
    name="technician_pool"
)

# Linking constraints: if product is produced, it must use workshop A or not
model.addConstr(x1 <= params["bigM"] * y1, name="microwave_use_A_link")
model.addConstr(x1 >= y1 * params["microwave_minimum_sales"], name="microwave_use_A_link2")
model.addConstr(x2 <= params["bigM"] * y2, name="water_heater_use_A_link")
model.addConstr(x2 >= y2 * params["water_heater_minimum_sales"], name="water_heater_use_A_link2")

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.objVal}")
