import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load general parameters
    general_params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r", newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row["Parameter_Name"].strip()
            value = float(row["Value"].strip())
            general_params[key] = value
    
    max_grains = general_params["max_grains"]
    price_grains = general_params["price_per_lb_grains"]
    max_meat = general_params["max_meat"]
    price_meat = general_params["price_per_lb_meat"]
    line_fixed_cost = general_params["line_fixed_cost"]
    line_capacity_packs = general_params["line_capacity_packs"]
    min_batch_packs = general_params["min_batch_packs"]
    min_yummies = general_params["min_yummies"]
    retailer_rebate_yummies_threshold = general_params["retailer_rebate_yummies_threshold"]
    retailer_rebate_min_meaties = general_params["retailer_rebate_min_meaties"]
    retailer_rebate_fixed = general_params["retailer_rebate_fixed"]

    # Load product data
    product_data = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r", newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Product"].strip()
            product_data[name] = {
                "price": float(row["Price_per_pack"].strip()),
                "grains": float(row["Grains_per_pack"].strip()),
                "meat": float(row["Meat_per_pack"].strip()),
                "variable_cost": float(row["Variable_cost_per_pack"].strip()),
                "production_capacity": float(row["Production_capacity"].strip()) if row["Production_capacity"].strip() else None
            }

    # Create Gurobi model
    model = gp.Model("HealthyPetFoods")
    model.setParam('OutputFlag', 0)

    # Decision variables: number of packs produced
    x_meaties = model.addVar(name="Meaties", lb=0)
    x_yummies = model.addVar(name="Yummies", lb=0)

    # Binary variable to indicate whether the co-packing line is used
    use_line = model.addVar(vtype=GRB.BINARY, name="UseLine")

    # Calculate profit per pack (excluding rebate and line cost)
    m = product_data["Meaties"]
    y = product_data["Yummies"]

    profit_meaties = m["price"] - m["variable_cost"] - (m["grains"] * price_grains + m["meat"] * price_meat)
    profit_yummies = y["price"] - y["variable_cost"] - (y["grains"] * price_grains + y["meat"] * price_meat)

    # Objective function
    total_profit = profit_meaties * x_meaties + profit_yummies * x_yummies
    rebate_condition = (x_yummies >= retailer_rebate_yummies_threshold) & (x_meaties >= retailer_rebate_min_meaties)
    rebate = retailer_rebate_fixed * gp.quicksum(rebate_condition)
    line_cost = line_fixed_cost * use_line

    model.setObjective(total_profit + rebate - line_cost, GRB.MAXIMIZE)

    # Constraints
    # Grains availability
    model.addConstr(m["grains"] * x_meaties + y["grains"] * x_yummies <= max_grains, "Grains_Constraint")

    # Meat availability
    model.addConstr(m["meat"] * x_meaties + y["meat"] * x_yummies <= max_meat, "Meat_Constraint")

    # Production capacity for Meaties
    if m["production_capacity"] is not None:
        model.addConstr(x_meaties <= m["production_capacity"], "Meaties_Capacity")

    # Production capacity for Yummies
    if y["production_capacity"] is not None:
        model.addConstr(x_yummies <= y["production_capacity"], "Yummies_Capacity")

    # Co-packing line constraints
    model.addConstr(x_meaties + x_yummies <= line_capacity_packs * use_line, "Line_Capacity")
    model.addConstr(x_meaties + x_yummies >= min_batch_packs * use_line, "Min_Batch")
    model.addConstr(x_yummies >= min_yummies * use_line, "Min_Yummies")

    # Solve the model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
