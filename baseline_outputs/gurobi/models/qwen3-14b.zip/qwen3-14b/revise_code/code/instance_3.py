import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load demand forecast
demand = {}
with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for i, row in enumerate(reader):
        demand[i] = float(row["Demand_Forecast"])

T = len(demand)  # 6 months

# Load general parameters
params = {}
with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

W0 = int(params["initial_workforce"])
I0 = params["initial_inventory"]
sp = params["sales_price"]
rmc = params["raw_material_cost"]
oc = params["outsourcing_cost"]
hc = params["inventory_holding_cost"]
bc = params["backorder_cost"]
lr = params["labor_requirement"]
rh = params["regular_labor_hours"]
rw = params["regular_wage"]
otl = params["overtime_hours_limit"]
ow = params["overtime_wage"]
hire_cost = params["hiring_cost"]
fire_cost = params["firing_cost"]
term_inv = params["terminal_inventory"]
term_bo = params["terminal_backorders"]
contract_min_units = params["contract_min_units"]
contract_bigM = params["contract_bigM"]

# Create model
model = gp.Model("FoldableTableProduction")
model.setParam("OutputFlag", 0)

# Decision variables
W = [model.addVar(lb=0, name=f"W_{t}") for t in range(T)]  # workforce
H = [model.addVar(lb=0, name=f"H_{t}") for t in range(T)]  # hired
F = [model.addVar(lb=0, name=f"F_{t}") for t in range(T)]  # fired
P = [model.addVar(lb=0, name=f"P_{t}") for t in range(T)]  # in-house production
OT_total = [model.addVar(lb=0, name=f"OT_{t}") for t in range(T)]  # total overtime hours
O = [model.addVar(lb=0, name=f"O_{t}") for t in range(T)]  # outsourced units
Inv = [model.addVar(lb=0, name=f"Inv_{t}") for t in range(T)]  # inventory
B = [model.addVar(lb=0, name=f"B_{t}") for t in range(T)]  # backorders
y = [model.addVar(vtype=GRB.BINARY, name=f"y_{t}") for t in range(T)]  # binary indicator for contract months

# Constraints
for t in range(T):
    # Workforce balance
    if t == 0:
        model.addConstr(W[t] == W0 + H[t] - F[t], name=f"Workforce_Balance_{t}")
    else:
        model.addConstr(W[t] == W[t-1] + H[t] - F[t], name=f"Workforce_Balance_{t}")

    # Production limited by total labor hours (regular + overtime)
    model.addConstr(P[t] * lr <= W[t] * rh + OT_total[t], name=f"Production_Limit_{t}")

    # Overtime limit
    model.addConstr(OT_total[t] <= W[t] * otl, name=f"Overtime_Limit_{t}")

    # Inventory balance: Inv[t] - B[t] = (Inv[t-1] - B[t-1]) + P[t] + O[t] - demand[t]
    prev_inv = I0 if t == 0 else Inv[t-1]
    prev_b = 0 if t == 0 else B[t-1]
    model.addConstr(Inv[t] - B[t] == prev_inv - prev_b + P[t] + O[t] - demand[t], name=f"Inventory_Balance_{t}")

    # Contract constraints for April to June (months 3, 4, 5)
    if t >= 3:
        # Define the required minimum in-house regular-time production
        min_inhouse = contract_min_units
        # The amount of in-house production that can be fulfilled with regular time
        reg_time_prod = W[t] * rh / lr
        # Ensure that at least min_inhouse is produced using regular time
        model.addConstr(P[t] >= min_inhouse - contract_bigM * y[t], name=f"Contract_Min_{t}_1")
        model.addConstr(P[t] <= reg_time_prod + contract_bigM * (1 - y[t]), name=f"Contract_Min_{t}_2")
        model.addConstr(P[t] >= min_inhouse - contract_bigM * (1 - y[t]), name=f"Contract_Min_{t}_3")
        model.addConstr(P[t] <= reg_time_prod + contract_bigM * y[t], name=f"Contract_Min_{t}_4")

# Terminal conditions
model.addConstr(Inv[T-1] >= term_inv, name="Terminal_Inventory")
model.addConstr(B[T-1] <= term_bo, name="Terminal_Backorders")

# Objective: maximize net profit
# Revenue = sales_price * total units sold
total_demand = sum(demand[t] for t in range(T))
revenue = sp * total_demand

# Costs
material_cost = sum(rmc * P[t] for t in range(T))
outsource_cost = sum(oc * O[t] for t in range(T))
holding_cost = sum(hc * Inv[t] for t in range(T))
backorder_cost_total = sum(bc * B[t] for t in range(T))
regular_labor_cost = sum(rw * rh * W[t] for t in range(T))
overtime_cost = sum(ow * OT_total[t] for t in range(T))
hiring_cost_total = sum(hire_cost * H[t] for t in range(T))
firing_cost_total = sum(fire_cost * F[t] for t in range(T))

total_cost = (material_cost + outsource_cost + holding_cost + backorder_cost_total +
              regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total)

model.setObjective(revenue - total_cost, GRB.MAXIMIZE)

# Solve
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
