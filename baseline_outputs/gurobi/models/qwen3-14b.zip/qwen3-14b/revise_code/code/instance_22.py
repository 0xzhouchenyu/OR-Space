import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    t1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    t2 = pd.read_csv(os.path.join(data_dir, "table_2.csv"))
    t3 = pd.read_csv(os.path.join(data_dir, "table_3.csv"))
    gp = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    
    # Merge product data
    df = t1.merge(t2, on='Product').merge(t3, on='Product')
    
    # Parse general parameters
    prod_days = float(gp[gp['Parameter_Name'] == 'production_days']['Value'].iloc[0])
    a1_watch_threshold = int(gp[gp['Parameter_Name'] == 'a1_watch_threshold']['Value'].iloc[0])
    a1_deep_service_threshold = int(gp[gp['Parameter_Name'] == 'a1_deep_service_threshold']['Value'].iloc[0])
    maintenance_penalty_watch = int(gp[gp['Parameter_Name'] == 'maintenance_penalty_watch']['Value'].iloc[0])
    maintenance_penalty_deep = int(gp[gp['Parameter_Name'] == 'maintenance_penalty_deep']['Value'].iloc[0])
    a1_quality_release_fee = float(gp[gp['Parameter_Name'] == 'a1_quality_release_fee']['Value'].iloc[0])
    a1_deep_service_fee = float(gp[gp['Parameter_Name'] == 'a1_deep_service_fee']['Value'].iloc[0])
    a1_priority_price_lift = float(gp[gp['Parameter_Name'] == 'a1_priority_price_lift']['Value'].iloc[0])
    
    return df, prod_days, a1_watch_threshold, a1_deep_service_threshold, maintenance_penalty_watch, maintenance_penalty_deep, a1_quality_release_fee, a1_deep_service_fee, a1_priority_price_lift

def solve():
    df, prod_days, a1_watch_threshold, a1_deep_service_threshold, maintenance_penalty_watch, maintenance_penalty_deep, a1_quality_release_fee, a1_deep_service_fee, a1_priority_price_lift = load_data()
    
    # Create model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    products = df['Product'].tolist()
    
    # Variables
    x = model.addVars(products, name="x", lb=0)
    y = model.addVars(products, vtype=GRB.BINARY, name="y")
    
    # Objective function
    obj = gp.quicksum((row['Selling_Price'] - row['Production_Cost']) * x[row['Product']] for _, row in df.iterrows())
    
    # Apply priority price lift for A1 units above watch threshold
    a1_row = df[df['Product'] == 'A1'].iloc[0]
    obj += a1_priority_price_lift * (x['A1'] - a1_watch_threshold).ifElse(0, x['A1'] - a1_watch_threshold)
    
    # Subtract activation costs
    obj -= gp.quicksum(row['Activation_Cost'] * y[row['Product']] for _, row in df.iterrows())
    
    # Subtract quality release and deep service fees if applicable
    a1_above_watch = x['A1'] >= a1_watch_threshold
    a1_above_deep = x['A1'] >= a1_deep_service_threshold
    
    obj -= a1_quality_release_fee * a1_above_watch
    obj -= a1_deep_service_fee * a1_above_deep
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints
    # All products must be produced
    for p in products:
        model.addConstr(y[p] == 1)
    
    # Maximum demand constraint
    for _, row in df.iterrows():
        p = row['Product']
        model.addConstr(x[p] <= row['Maximum_Demand'] * y[p])
        model.addConstr(x[p] >= row['Minimum_Batch'] * y[p])
    
    # Production days constraint
    # Calculate total production days used
    total_prod_days_used = gp.quicksum(x[row['Product']] / row['Production_Quota'] for _, row in df.iterrows())
    
    # Subtract maintenance penalties
    total_prod_days_used -= maintenance_penalty_watch * a1_above_watch
    total_prod_days_used -= maintenance_penalty_deep * a1_above_deep
    
    model.addConstr(total_prod_days_used <= prod_days)
    
    # Optimize
    model.optimize()
    
    return model.objVal

if __name__ == "__main__":
    obj = solve()
    print(f"FINAL_OBJ_VALUE: {round(obj, 4)}")
