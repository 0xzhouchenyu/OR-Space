import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = params['min_manager_experience']
    manager_bonus_per_candidate = params['manager_bonus_per_candidate']

    # Create optimization model
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0)

    # Decision variables: binary for each candidate
    x = {}
    role = {}
    for c in candidates:
        x[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{c['name']}")
        role[c['name']] = model.addVar(vtype=GRB.BINARY, name=f"role_{c['name']}")

    # Objective: minimize total salary + manager bonus
    model.setObjective(gp.quicksum(c['salary'] * x[c['name']] for c in candidates) + 
                       manager_bonus_per_candidate * gp.quicksum(role[c['name']] for c in candidates), GRB.MINIMIZE)

    # Constraint 1: max employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, "max_employees")

    # Constraint 2: budget (only base salaries)
    model.addConstr(gp.quicksum(c['salary'] * x[c['name']] for c in candidates) <= budget_limit, "budget_limit")

    # Constraint 3: at least one with Master's or Doctoral degree
    advanced_candidates = [c for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(x[c['name']] for c in advanced_candidates) >= min_advanced, "min_advanced_degree")

    # Constraint 4: minimum total work experience
    model.addConstr(gp.quicksum(c['experience'] * x[c['name']] for c in candidates) >= min_experience, "min_total_experience")

    # Constraint 5: at most one from pair A and E
    model.addConstr(x['A'] + x['E'] <= max_equivalent, "max_equivalent_pair")

    # Constraint 6: minimum employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) >= min_employees, "min_employees")

    # Constraint 7: role assignment (each hired candidate must be assigned to a role)
    for c in candidates:
        model.addConstr(x[c['name']] <= role[c['name']], f"role_assign_{c['name']}")
        model.addConstr(role[c['name']] <= x[c['name']], f"role_assign_rev_{c['name']}")

    # Constraint 8: manager headcount limits
    model.addConstr(gp.quicksum(role[c['name']] for c in candidates) >= min_managers, "min_managers")
    model.addConstr(gp.quicksum(role[c['name']] for c in candidates) <= max_managers, "max_managers")

    # Constraint 9: managers must meet experience floor
    model.addConstr(gp.quicksum(c['experience'] * role[c['name']] for c in candidates) >= min_manager_experience, "min_manager_experience")

    # Optimize the model
    model.optimize()

    # Print selected candidates and roles
    for c in candidates:
        if x[c['name']].x > 0.5:
            print(f"Selected: {c['name']} (Role: {'Manager' if role[c['name']].x > 0.5 else 'Specialist'}, Salary: {c['salary']})")

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
