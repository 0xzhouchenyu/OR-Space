import os
import gurobipy as gp
from gurobipy import GRB

# Load data
def load_csv(filename):
    """Load a CSV file and return a list of dictionaries."""
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

def load_general_parameters():
    """Load general parameters into a dictionary."""
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = row['Value']
        # Try to convert to numeric
        try:
            if '.' in value:
                params[name] = float(value)
            else:
                params[name] = int(value)
        except ValueError:
            params[name] = value
    return params

def load_task_methods():
    """Load task-method data."""
    rows = load_csv('table_1.csv')
    data = []
    for row in rows:
        data.append({
            'Task': row['Task'],
            'Method': row['Method'],
            'Effective_Hours': float(row['Effective_Hours']),
            'Fixed_Cost': float(row['Fixed_Cost'])
        })
    return data

# Main script
def main():
    params = load_general_parameters()
    task_methods = load_task_methods()

    # Extract parameters
    skilled_wage = params['skilled_worker_weekly_wage']  # 110
    laborer_wage = params['laborer_weekly_wage']  # 80
    skilled_hours = params['skilled_worker_weekly_hours']  # 42
    laborer_hours = params['laborer_weekly_hours']  # 36
    max_skilled = params['max_skilled_workers']  # 430
    max_laborers = params['max_laborers']  # 800
    min_skilled_task3_B = params['min_skilled_workers_task3_methodB']  # 20
    skilled_hiring_ratio = params['skilled_worker_hiring_ratio']  # 0.6
    min_skilled_share_task1 = params['min_skilled_share_task1']  # 0.30
    max_skilled_share_task1 = params['max_skilled_share_task1']  # 0.70
    min_skilled_share_task2 = params['min_skilled_share_task2']  # 0.10
    max_skilled_share_task2 = params['max_skilled_share_task2']  # 0.50
    min_skilled_share_task3 = params['min_skilled_share_task3']  # 0.20
    max_skilled_share_task3 = params['max_skilled_share_task3']  # 0.60

    tasks = ['Task_1', 'Task_2', 'Task_3']
    methods = ['Method_A', 'Method_B']

    # Build dictionary: (task, method) -> {Effective_Hours, Fixed_Cost}
    tm_data = {}
    for row in task_methods:
        key = (row['Task'], row['Method'])
        tm_data[key] = row

    # Create the problem
    model = gp.Model("WorkerAllocation")
    model.setParam('OutputFlag', 0)

    # Decision variables
    y = model.addVars(tasks, methods, vtype=gp.GRB.BINARY, name="y")
    s = model.addVars(tasks, methods, lb=0, name="s")
    l = model.addVars(tasks, methods, lb=0, name="l")

    total_skilled = model.addVar(lb=0, name="total_skilled")
    total_laborers = model.addVar(lb=0, name="total_laborers")

    # Objective: minimize total weekly cost (wages + fixed costs)
    model.setObjective(
        skilled_wage * total_skilled + laborer_wage * total_laborers +
        gp.quicksum(tm_data[t, m]['Fixed_Cost'] * y[t, m] for t in tasks for m in methods),
        GRB.MINIMIZE
    )

    # Constraints
    # Total skilled and laborers
    model.addConstr(total_skilled == gp.quicksum(s[t, m] for t in tasks for m in methods), "TotalSkilledDef")
    model.addConstr(total_laborers == gp.quicksum(l[t, m] for t in tasks for m in methods), "TotalLaborersDef")

    # Exactly one method per task
    for t in tasks:
        model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1, f"OneMethod_{t}")

    # Hours requirement: for each task, the chosen method must meet effective hours
    M_big = 10000  # Big-M

    for t in tasks:
        for m in methods:
            req_hours = tm_data[t, m]['Effective_Hours']
            # Hours constraint
            model.addConstr(
                skilled_hours * s[t, m] + laborer_hours * l[t, m] >= req_hours * y[t, m],
                f"Hours_{t}_{m}"
            )
            # Linking: if y=0, then s and l must be 0
            model.addConstr(s[t, m] <= M_big * y[t, m], f"LinkS_{t}_{m}")
            model.addConstr(l[t, m] <= M_big * y[t, m], f"LinkL_{t}_{m}")

    # Max constraints
    model.addConstr(total_skilled <= max_skilled, "MaxSkilled")
    model.addConstr(total_laborers <= max_laborers, "MaxLaborers")

    # Skilled workers cannot exceed 60% of total laborers
    model.addConstr(total_skilled <= skilled_hiring_ratio * total_laborers, "SkilledRatio")

    # Exclusion rule: Task 1 using Method B excludes Task 3 using Method A
    model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1, "ExclusionRule")

    # Minimum skilled workers for Task 3 if Method B is chosen
    model.addConstr(s['Task_3', 'Method_B'] >= min_skilled_task3_B * y['Task_3', 'Method_B'], "MinSkilledTask3B")

    # Task-level skill balance bands
    for t in tasks:
        for m in methods:
            # Total workers for this task
            total_workers = s[t, m] + l[t, m]
            # Skilled share constraint
            if total_workers > 0:
                model.addConstr(
                    (s[t, m] / total_workers) >= min_skilled_share_task1 if t == 'Task_1' else
                    (s[t, m] / total_workers) >= min_skilled_share_task2 if t == 'Task_2' else
                    (s[t, m] / total_workers) >= min_skilled_share_task3,
                    f"MinSkilledShare_{t}_{m}"
                )
                model.addConstr(
                    (s[t, m] / total_workers) <= max_skilled_share_task1 if t == 'Task_1' else
                    (s[t, m] / total_workers) <= max_skilled_share_task2 if t == 'Task_2' else
                    (s[t, m] / total_workers) <= max_skilled_share_task3,
                    f"MaxSkilledShare_{t}_{m}"
                )

    # Solve
    model.optimize()

    # Print solution details
    print(f"Status: {model.status}")
    print(f"Total Skilled Workers: {model.getVarByName('total_skilled').X}")
    print(f"Total Laborers: {model.getVarByName('total_laborers').X}")

    for t in tasks:
        for m in methods:
            if model.getVarByName(f"y_{t}_{m}").X > 0.5:
                print(f"{t}: {m}, Skilled={model.getVarByName(f's_{t}_{m}').X:.1f}, "
                      f"Laborers={model.getVarByName(f'l_{t}_{m}').X:.1f}, "
                      f"Fixed={tm_data[t, m]['Fixed_Cost']}")

    obj_val = model.objVal
    print(f"\nFINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    import csv
    main()
