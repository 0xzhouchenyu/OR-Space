import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load food items
    items = []
    with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })
    
    # Load parameters
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_daily_calories = params['min_daily_calories']
    max_daily_calories = params['max_daily_calories']
    max_daily_sodium = params['max_daily_sodium']
    
    max_units = int(total_weight_limit // 100)  # max 100g units per item
    max_meal_units = 3  # 300 grams per meal / 100 grams per unit
    
    model = gp.Model("dinner_lunch")
    model.setParam('OutputFlag', 0)
    
    # Variables
    purchase_units = model.addVars(len(items), name="purchase_units", vtype=GRB.INTEGER, lb=0, ub=max_units)
    lunch_units = model.addVars(len(items), name="lunch_units", vtype=GRB.INTEGER, lb=0, ub=max_meal_units)
    dinner_units = model.addVars(len(items), name="dinner_units", vtype=GRB.INTEGER, lb=0, ub=max_meal_units)
    select_item = model.addVars(len(items), name="select_item", vtype=GRB.BINARY)
    lunch_veg_selected = model.addVars(len(items), name="lunch_veg_selected", vtype=GRB.BINARY)
    dinner_veg_selected = model.addVars(len(items), name="dinner_veg_selected", vtype=GRB.BINARY)
    
    # Objective: maximize total protein from both meals
    total_protein = gp.quicksum(items[i]['protein'] * (lunch_units[i] + dinner_units[i]) for i in range(len(items)))
    model.setObjective(total_protein, GRB.MAXIMIZE)
    
    # Constraints
    # 1. Total daily budget constraint
    model.addConstr(gp.quicksum(items[i]['cost'] * purchase_units[i] for i in range(len(items))) <= max_budget, "budget_constraint")
    
    # 2. Total daily weight limit constraint
    model.addConstr(gp.quicksum(purchase_units[i] for i in range(len(items))) * 100 <= total_weight_limit, "weight_limit_constraint")
    
    # 3. Purchase and meal assignment linkage
    for i in range(len(items)):
        model.addConstr(purchase_units[i] <= max_units * select_item[i], f"purchase_link_{i}")
        model.addConstr(lunch_units[i] <= max_meal_units * select_item[i], f"lunch_link_{i}")
        model.addConstr(dinner_units[i] <= max_meal_units * select_item[i], f"dinner_link_{i}")
    
    # 4. Per-meal weight balance
    model.addConstr(gp.quicksum(lunch_units[i] for i in range(len(items))) * 100 == 300, "lunch_weight")
    model.addConstr(gp.quicksum(dinner_units[i] for i in range(len(items))) * 100 == 300, "dinner_weight")
    
    # 5. Linking lunch_units and lunch_veg_selected
    for i in range(len(items)):
        if items[i]['type'] == 'Vegetable':
            model.addConstr(lunch_units[i] >= lunch_veg_selected[i], f"lunch_veg_lower_{i}")
            model.addConstr(lunch_units[i] <= max_meal_units * lunch_veg_selected[i], f"lunch_veg_upper_{i}")
    
    # 6. Linking dinner_units and dinner_veg_selected
    for i in range(len(items)):
        if items[i]['type'] == 'Vegetable':
            model.addConstr(dinner_units[i] >= dinner_veg_selected[i], f"dinner_veg_lower_{i}")
            model.addConstr(dinner_units[i] <= max_meal_units * dinner_veg_selected[i], f"dinner_veg_upper_{i}")
    
    # 7. Minimum vegetable types per meal
    veg_indices = [i for i in range(len(items)) if items[i]['type'] == 'Vegetable']
    model.addConstr(gp.quicksum(lunch_veg_selected[i] for i in veg_indices) >= min_veg_types, "lunch_veg_count")
    model.addConstr(gp.quicksum(dinner_veg_selected[i] for i in veg_indices) >= min_veg_types, "dinner_veg_count")
    
    # 8. Daily calorie intake bounds
    total_calories = gp.quicksum(items[i]['calories'] * (lunch_units[i] + dinner_units[i]) for i in range(len(items)))
    model.addConstr(total_calories >= min_daily_calories, "min_calories")
    model.addConstr(total_calories <= max_daily_calories, "max_calories")
    
    # 9. Daily sodium intake bound
    total_sodium = gp.quicksum(items[i]['sodium'] * (lunch_units[i] + dinner_units[i]) for i in range(len(items)))
    model.addConstr(total_sodium <= max_daily_sodium, "max_sodium")
    
    # 10. Purchase units must be at least the sum of lunch and dinner units
    for i in range(len(items)):
        model.addConstr(purchase_units[i] >= lunch_units[i] + dinner_units[i], f"purchase_coverage_{i}")
    
    # Optimize model
    model.optimize()
    
    # Print results
    obj_value = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_value}")

if __name__ == "__main__":
    main()
