import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general_parameters.csv
    general_params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            general_params[param_name] = value
    
    # Read table_1.csv
    workshops = []
    capacities = {}
    rates = {}  # rates[(workshop, component)] = production rate
    
    filepath = os.path.join(data_dir, 'table_1.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    components = [1, 2, 3]
    shifts = ['day', 'night']
    
    # Create model
    model = gp.Model("Maximize_Completed_Products")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: hours each workshop allocates to each component in each shift
    x = {}
    for w in workshops:
        for c in components:
            for s in shifts:
                x[(w, c, s)] = model.addVar(name=f"x_{w}_{c}_{s}", lb=0)
    
    # Binary variables indicating if a workshop is active in a shift
    active = {}
    for w in workshops:
        for s in shifts:
            active[(w, s)] = model.addVar(vtype=GRB.BINARY, name=f"active_{w}_{s}")
    
    # z = number of completed products
    z = model.addVar(name="z", lb=0)
    
    # Objective: maximize z - penalties
    obj = z
    penalty_shortage = general_params['penalty_shortage_per_unit'] * (general_params['z_target'] - z)
    obj -= penalty_shortage
    
    # Add penalties for night hours and overtime
    for w in workshops:
        for c in components:
            for s in shifts:
                if s == 'night':
                    penalty = general_params['penalty_night_hour'] * x[(w, c, s)]
                    obj += penalty
                else:
                    # Overtime is any hour beyond regular hours
                    reg_hours = general_params[f'regular_hours_limit_{s}_{w}']
                    overtime_hours = x[(w, c, s)] - reg_hours
                    model.addConstr(x[(w, c, s)] <= reg_hours + general_params[f'overtime_capacity_{s}_{w}'], 
                                    name=f"overtime_limit_{w}_{c}_{s}")
                    model.addConstr(overtime_hours >= 0, name=f"non_negative_overtime_{w}_{c}_{s}")
                    penalty = general_params['penalty_overtime_hour'] * max(0, x[(w, c, s)] - reg_hours)
                    obj += penalty
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Capacity constraints: total hours per workshop across all components and shifts
    for w in workshops:
        model.addConstr(
            gp.quicksum(x[(w, c, s)] for c in components for s in shifts) <= capacities[w],
            name=f"total_capacity_{w}"
        )
    
    # Linking active indicator to hours
    for w in workshops:
        for s in shifts:
            reg_hours = general_params[f'regular_hours_limit_{s}_{w}']
            overtime_hours = general_params[f'overtime_capacity_{s}_{w}']
            bigM = general_params[f'bigM_shift_{w}']
            model.addConstr(
                x[(w, 1, s)] + x[(w, 2, s)] + x[(w, 3, s)] <= bigM * active[(w, s)],
                name=f"active_link_{w}_{s}_1"
            )
            model.addConstr(
                x[(w, 1, s)] + x[(w, 2, s)] + x[(w, 3, s)] >= reg_hours * active[(w, s)],
                name=f"active_link_{w}_{s}_2"
            )
    
    # Shift constraint: no more than two workshops active in the same shift
    for s in shifts:
        model.addConstr(
            gp.quicksum(active[(w, s)] for w in workshops) <= 2,
            name=f"shift_limit_{s}"
        )
    
    # z <= total production of each component
    for c in components:
        model.addConstr(
            z <= gp.quicksum(rates[(w, c)] * x[(w, c, s)] for w in workshops for s in shifts),
            name=f"min_component_{c}"
        )
    
    # Solve
    model.optimize()
    
    # Print solution details
    print(f"Status: {model.status}")
    for w in workshops:
        for c in components:
            for s in shifts:
                val = x[(w, c, s)].X
                if val > 1e-6:
                    print(f"Workshop {w}, Component {c}, Shift {s}: {val:.2f} hours -> {rates[(w,c)] * val:.2f} units")
    
    for c in components:
        total = sum(rates[(w, c)] * x[(w, c, s)].X for w in workshops for s in shifts)
        print(f"Total Component {c}: {total:.2f} units")
    
    obj_val = model.objVal
    print(f"\nFINAL_OBJ_VALUE: {obj_val:.1f}")

if __name__ == "__main__":
    main()
