import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_coverage_data(data_dir):
    """Load the coverage data from table_1.csv.
    
    Returns:
        areas: list of all area codes
        coverage: dict mapping each area to the set of areas it can cover
    """
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)  # skip header
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            # The covered areas are in the second column onwards, but they might be split across columns
            # because the CSV has commas within the coverage list
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    
    return areas, coverage


def load_general_parameters(data_dir):
    """Load general parameters from general_parameters.csv."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    return params


def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load data
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    distance_limit = int(params.get('distance_limit', 800))
    small_cost = int(params.get('small_cost', 1))
    large_cost = int(params.get('large_cost', 2))
    small_cap_areas = int(params.get('small_cap_areas', 3))
    max_large_stores = int(params.get('max_large_stores', 1))
    minimum_neighborhood_counters = int(params.get('minimum_neighborhood_counters', 6))
    
    # Create the model
    model = gp.Model("MinChainStoresRevised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_j: 1 if we build a Small-format store in area j, 0 otherwise
    x_small = model.addVars(areas, vtype=GRB.BINARY, name="x_small")
    
    # y_j: 1 if we build a Large-format store in area j, 0 otherwise
    y_large = model.addVars(areas, vtype=GRB.BINARY, name="y_large")
    
    # Objective: minimize total cost
    model.setObjective(
        gp.quicksum(small_cost * x_small[j] for j in areas) +
        gp.quicksum(large_cost * y_large[j] for j in areas),
        GRB.MINIMIZE
    )
    
    # Constraints
    
    # Constraint 1: Each area must be covered by at least one store (Small or Large)
    for i in areas:
        covering_small = [j for j in areas if i in coverage.get(j, set())]
        covering_large = [j for j in areas if i in coverage.get(j, set())]
        
        model.addConstr(
            gp.quicksum(x_small[j] for j in covering_small) +
            gp.quicksum(y_large[j] for j in covering_large) >= 1,
            name=f"Cover_{i}"
        )
    
    # Constraint 2: Each Small-format store can serve at most small_cap_areas areas
    for j in areas:
        model.addConstr(
            gp.quicksum(x_small[j] * len(coverage.get(j, set()))) <= small_cap_areas,
            name=f"Small_Capacity_{j}"
        )
    
    # Constraint 3: Maximum number of Large-format stores allowed
    model.addConstr(
        gp.quicksum(y_large[j] for j in areas) <= max_large_stores,
        name="Max_Large_Stores"
    )
    
    # Constraint 4: Minimum number of Small-format stores (neighborhood counters)
    model.addConstr(
        gp.quicksum(x_small[j] for j in areas) >= minimum_neighborhood_counters,
        name="Min_Neighborhood_Counters"
    )
    
    # Optimize the model
    model.optimize()
    
    # Extract results
    selected_small = [j for j in areas if x_small[j].x > 0.5]
    selected_large = [j for j in areas if y_large[j].x > 0.5]
    
    print(f"Optimal number of Small-format stores: {len(selected_small)}")
    print(f"Optimal number of Large-format stores: {len(selected_large)}")
    print(f"Total cost: {model.objVal}")
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")


if __name__ == "__main__":
    main()
