import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

    profits = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons'],
    }

    water_spring = {
        'apples': params['water_per_acre_apples_spring'],
        'pears': params['water_per_acre_pears_spring'],
        'oranges': params['water_per_acre_oranges_spring'],
        'lemons': params['water_per_acre_lemons_spring'],
    }

    water_autumn = {
        'apples': params['water_per_acre_apples_autumn'],
        'pears': params['water_per_acre_pears_autumn'],
        'oranges': params['water_per_acre_oranges_autumn'],
        'lemons': params['water_per_acre_lemons_autumn'],
    }

    total_area = params['total_farm_area']
    min_a_to_p = params['min_apples_to_pears_ratio']
    min_a_to_l = params['min_apples_to_lemons_ratio']
    o_to_l = params['oranges_to_lemons_ratio']
    max_types = int(params['max_fruit_types'])
    water_cap_spring = params['water_cap_spring']
    water_cap_autumn = params['water_cap_autumn']
    total_water_budget = params['total_water_budget']
    min_annual_water_per_fruit = params['min_annual_water_per_fruit']
    diversification_reward = params['diversification_reward']

    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']

    model = gp.Model("farm_optimization")
    model.setParam('OutputFlag', 0)

    # Variables: x[f][s] = acres of fruit f in season s
    x = model.addVars(fruits, seasons, name="x", lb=0)

    # Annual land used for each fruit
    annual_land = model.addVars(fruits, name="annual_land", lb=0)
    for f in fruits:
        model.addConstr(annual_land[f] == x[f, 'spring'] + x[f, 'autumn'], name=f"annual_land_{f}")

    # Seasonal land constraints
    for s in seasons:
        model.addConstr(gp.quicksum(x[f, s] for f in fruits) <= total_area, name=f"seasonal_land_{s}")

    # Water usage per season
    water_spring_usage = model.addVar(name="water_spring_usage", lb=0)
    water_autumn_usage = model.addVar(name="water_autumn_usage", lb=0)
    total_water_usage = model.addVar(name="total_water_usage", lb=0)

    model.addConstr(water_spring_usage == gp.quicksum(x[f, 'spring'] * water_spring[f] for f in fruits), name="water_spring")
    model.addConstr(water_autumn_usage == gp.quicksum(x[f, 'autumn'] * water_autumn[f] for f in fruits), name="water_autumn")
    model.addConstr(total_water_usage == water_spring_usage + water_autumn_usage, name="total_water")

    # Water caps
    model.addConstr(water_spring_usage <= water_cap_spring, name="water_cap_spring")
    model.addConstr(water_autumn_usage <= water_cap_autumn, name="water_cap_autumn")
    model.addConstr(total_water_usage <= total_water_budget, name="total_water_budget")

    # Annual ratio constraints
    model.addConstr(annual_land['apples'] >= min_a_to_p * annual_land['pears'], name="apples_pears_ratio")
    model.addConstr(annual_land['apples'] >= min_a_to_l * annual_land['lemons'], name="apples_lemons_ratio")
    model.addConstr(annual_land['oranges'] == o_to_l * annual_land['lemons'], name="oranges_lemons_ratio")

    # Fruit type count constraint
    num_fruit_types = model.addVar(vtype=GRB.INTEGER, name="num_fruit_types", lb=0, ub=max_types)
    for f in fruits:
        model.addConstr(num_fruit_types >= (annual_land[f] > 0).astype(int), name=f"fruit_type_count_{f}")

    # Minimum annual water per fruit
    for f in fruits:
        model.addConstr(annual_land[f] * (water_spring[f] + water_autumn[f]) >= min_annual_water_per_fruit * (annual_land[f] > 0).astype(int), name=f"min_water_{f}")

    # Objective function
    profit = gp.quicksum(x[f, s] * profits[f] for f in fruits for s in seasons)
    model.addConstr(profit >= 0, name="non_negative_profit")

    # Diversification reward
    model.addConstr(num_fruit_types >= 2, name="diversification_condition")
    model.addConstr(profit += diversification_reward, name="diversification_reward")

    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_value = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_value}")
    else:
        print("No optimal solution found.")

solve()
