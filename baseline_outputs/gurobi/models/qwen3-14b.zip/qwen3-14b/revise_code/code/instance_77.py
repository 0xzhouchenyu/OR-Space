import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load processing costs from table_1.csv
    cost = {}  # cost[(machine, part)] = value
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p) for p in header[1:]]
        for row in reader:
            machine = row[0].strip()
            for j, p in enumerate(parts):
                cost[(machine, p)] = float(row[j + 1])

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    d = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    max_C = int(params['max_parts_on_C'])
    overtime_threshold = int(params['overtime_threshold'])
    overtime_penalty = params['overtime_penalty']

    machines = ['A', 'B', 'C']
    parts = list(range(1, 11))

    # Create a Gurobi model
    model = gp.Model("MachineAssignment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = model.addVars(machines, parts, vtype=GRB.BINARY, name="x")
    y = model.addVars(machines, vtype=GRB.BINARY, name="y")
    z = model.addVars(machines, vtype=GRB.BINARY, name="z")

    # Objective: minimize processing costs + setup costs + overtime penalties
    obj = gp.quicksum(cost[(m, p)] * x[m, p] for m in machines for p in parts) \
          + gp.quicksum(d[m] * y[m] for m in machines) \
          + gp.quicksum(overtime_penalty * z[m] for m in machines)

    model.setObjective(obj, GRB.MINIMIZE)

    # Each part assigned to exactly one machine
    for p in parts:
        model.addConstr(gp.quicksum(x[m, p] for m in machines) == 1)

    # Linking y to x: if any part on machine m, y[m] = 1
    for m in machines:
        for p in parts:
            model.addConstr(x[m, p] <= y[m])

    # Constraint 2: Parts 1 and 2 - if part1 on A then part2 on B or C, and vice versa
    model.addConstr(x['A', 1] + x['A', 2] == 1)

    # Constraint 3: Fixed assignments
    model.addConstr(x['A', 3] == 1)
    model.addConstr(x['B', 4] == 1)
    model.addConstr(x['C', 5] == 1)

    # Constraint 4: At most 3 parts on machine C
    model.addConstr(gp.quicksum(x['C', p] for p in parts) <= max_C)

    # Constraint 5: Overtime penalty if a machine processes more than the threshold number of parts
    for m in machines:
        model.addConstr(gp.quicksum(x[m, p] for p in parts) <= overtime_threshold + (1 - z[m]) * 1000)
        model.addConstr(gp.quicksum(x[m, p] for p in parts) >= overtime_threshold + 1 - (1 - z[m]) * 1000)

    # Optimize the model
    model.optimize()

    # Print assignments for debugging
    for p in parts:
        for m in machines:
            if x[m, p].x > 0.5:
                print(f"Part {p} -> Machine {m} (cost={cost[(m,p)]})")
    for m in machines:
        if y[m].x > 0.5:
            print(f"Machine {m} used, setup cost={d[m]}")

    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
