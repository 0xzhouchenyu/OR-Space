import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

# Get the data directory path
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load warehouse data
warehouses_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
warehouses = []
supply = {}
for row in warehouses_data:
    name = row['Warehouse']
    warehouses.append(name)
    supply[name] = int(row['Empty_Containers'])

# Load port data
ports_data = load_csv_data(os.path.join(data_dir, 'table_2.csv'))
ports = []
demand = {}
for row in ports_data:
    name = row['Port']
    ports.append(name)
    demand[name] = int(row['Container_Demand'])

# Load distance data
distance_data = load_csv_data(os.path.join(data_dir, 'table_3.csv'))
distance = {}
for row in distance_data:
    wh = row['Warehouse']
    for port in ports:
        distance[(wh, port)] = float(row[port])

# Load general parameters
params_data = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
params = {}
for row in params_data:
    params[row['Parameter_Name']] = float(row['Value'])

cost_per_km = params['cost_per_km']
truck_capacity = params['truck_capacity']
adriatic_pool_shortage_trigger = params['adriatic_pool_shortage_trigger']
adriatic_pool_recovery_fee = params['adriatic_pool_recovery_fee']

# Load shortage penalty data
shortage_penalty_data = load_csv_data(os.path.join(data_dir, 'shortage_penalty.csv'))
shortage_charge = {}
grace_containers = {}
recovery_fee = {}
for row in shortage_penalty_data:
    port = row['Port']
    shortage_charge[port] = float(row['Shortage_Charge'])
    grace_containers[port] = int(row['Grace_Containers'])
    recovery_fee[port] = float(row['Recovery_Fee'])

# Create Gurobi model
model = gp.Model("Container_Transportation")
model.setParam('OutputFlag', 0)

# Decision variables: number of containers from warehouse i to port j
x = {}
for i in warehouses:
    for j in ports:
        x[(i, j)] = model.addVar(name=f"x_{i}_{j}", lb=0, ub=supply[i], vtype=GRB.INTEGER)

# Objective function components
# Transport cost
transport_cost = gp.quicksum(x[(i, j)] * distance[(i, j)] * cost_per_km for i in warehouses for j in ports)

# Shortage charge
shortage_charge_total = 0
for j in ports:
    shortage = gp.quicksum(demand[j] - gp.quicksum(x[(i, j)] for i in warehouses), name=f"shortage_{j}")
    # Apply shortage charge per container beyond grace band
    shortage_charge_total += gp.quicksum(
        (gp.max_(0, shortage - grace_containers[j])) * shortage_charge[j]
        for _ in range(1)
    )

# Recovery fee
adriatic_ports = ['Venice', 'Ancona', 'Bari']
adriatic_shortage = gp.quicksum(gp.quicksum(demand[j] - gp.quicksum(x[(i, j)] for i in warehouses), name=f"shortage_{j}") for j in adriatic_ports)
adriatic_recovery_fee = gp.quicksum(
    adriatic_pool_recovery_fee * gp.quicksum(1 for _ in range(1)) if adriatic_shortage >= adriatic_pool_shortage_trigger else 0
)

# Total objective
model.setObjective(transport_cost + shortage_charge_total + adriatic_recovery_fee, GRB.MINIMIZE)

# Supply constraints
for i in warehouses:
    model.addConstr(gp.quicksum(x[(i, j)] for j in ports) <= supply[i], name=f"supply_{i}")

# Demand constraints
for j in ports:
    model.addConstr(gp.quicksum(x[(i, j)] for i in warehouses) >= demand[j], name=f"demand_{j}")

# Optimize model
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
