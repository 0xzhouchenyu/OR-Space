import os
import sys
import gurobipy as gp
from gurobipy import GRB
from csv import reader

# Add parent directory to path if needed
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

def load_table_1(data_dir):
    """Load and parse table_1.csv to extract equipment hours, processing times, and profits."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    equipment_names = []
    products = []
    processing_times = {}  # (equipment, product) -> time
    effective_hours = {}   # equipment -> hours
    base_profit = {}       # product -> profit
    
    with open(filepath, 'r') as f:
        csv_reader = reader(f)
        header = next(csv_reader)
        # header: Equipment_Code, I, II, III, Effective_Monthly_Equipment_Hours
        products = header[1:-1]  # ['I', 'II', 'III']
        
        for row in csv_reader:
            if row[0].startswith('Unit_Product_Profit'):
                # This is the profit row
                for j, prod in enumerate(products):
                    base_profit[prod] = float(row[j + 1])
            else:
                equip = row[0]
                equipment_names.append(equip)
                effective_hours[equip] = float(row[-1])
                for j, prod in enumerate(products):
                    processing_times[(equip, prod)] = float(row[j + 1])
    
    return products, equipment_names, processing_times, effective_hours, base_profit

def load_general_parameters(data_dir):
    """Load general parameters from general_parameters.csv."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    
    overtime_hours_cap = None
    overtime_cost_multiplier = None
    min_prod_I = None
    min_prod_II = None
    min_prod_III = None
    
    with open(filepath, 'r') as f:
        csv_reader = reader(f)
        for row in csv_reader:
            if row[0] == 'overtime_hours_cap':
                overtime_hours_cap = float(row[1])
            elif row[0] == 'overtime_cost_multiplier':
                overtime_cost_multiplier = float(row[1])
            elif row[0] == 'min_prod_I':
                min_prod_I = float(row[1])
            elif row[0] == 'min_prod_II':
                min_prod_II = float(row[1])
            elif row[0] == 'min_prod_III':
                min_prod_III = float(row[1])
    
    return {
        'overtime_hours_cap': overtime_hours_cap,
        'overtime_cost_multiplier': overtime_cost_multiplier,
        'min_prod_I': min_prod_I,
        'min_prod_II': min_prod_II,
        'min_prod_III': min_prod_III
    }

def main():
    data_dir = os.path.join(script_dir, '..', 'data')
    
    # Load data
    products, equipment_names, processing_times, effective_hours, base_profit = load_table_1(data_dir)
    general_params = load_general_parameters(data_dir)
    
    overtime_hours_cap = general_params['overtime_hours_cap']
    overtime_cost_multiplier = general_params['overtime_cost_multiplier']
    min_prod_I = general_params['min_prod_I']
    min_prod_II = general_params['min_prod_II']
    min_prod_III = general_params['min_prod_III']
    
    # Create the model
    model = gp.Model("Factory_Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: regular and overtime production for each product
    x_reg = {p: model.addVar(name=f"x_reg_{p}", lb=0) for p in products}
    x_ot = {p: model.addVar(name=f"x_ot_{p}", lb=0) for p in products}
    
    # Objective: minimize total cost
    total_cost = 0
    for p in products:
        regular_cost = base_profit[p] * x_reg[p]
        overtime_cost = base_profit[p] * overtime_cost_multiplier * x_ot[p]
        total_cost += regular_cost + overtime_cost
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Constraints: equipment capacity
    for equip in equipment_names:
        lhs = gp.LinExpr()
        for p in products:
            lhs += processing_times[(equip, p)] * (x_reg[p] + x_ot[p])
        model.addConstr(lhs <= effective_hours[equip], name=f"Equipment_{equip}_capacity")
    
    # Constraint: overtime hours cap
    lhs = gp.LinExpr()
    for p in products:
        lhs += processing_times[(equip, p)] * x_ot[p] for equip in equipment_names
    model.addConstr(lhs <= overtime_hours_cap, name="Overtime_hours_cap")
    
    # Constraints: minimum production levels
    model.addConstr(x_reg['I'] + x_ot['I'] >= min_prod_I, name="Min_prod_I")
    model.addConstr(x_reg['II'] + x_ot['II'] >= min_prod_II, name="Min_prod_II")
    model.addConstr(x_reg['III'] + x_ot['III'] >= min_prod_III, name="Min_prod_III")
    
    # Optimize
    model.optimize()
    
    # Print objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
