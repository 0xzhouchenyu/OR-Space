import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "initial_capital":
            initial_capital = float(row["Value"].strip())

# Load liquidity policy parameters
with open(os.path.join(data_dir, "liquidity_policy.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "min_year3_reserve":
            min_year3_reserve = float(row["Value"].strip())
        elif row["Parameter_Name"].strip() == "reserve_shortfall_penalty":
            reserve_shortfall_penalty = float(row["Value"].strip())

# Load project data
projects = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        projects.append(row)

# Create Gurobi model
model = gp.Model("Investment_Maximization")
model.setParam("OutputFlag", 0)

# Decision variables
# x1_t: amount invested in Project 1 at beginning of Year t (t=1,2,3)
x1_1 = model.addVar(name="x1_1", lb=0)
x1_2 = model.addVar(name="x1_2", lb=0)
x1_3 = model.addVar(name="x1_3", lb=0)

# x2: amount invested in Project 2 at beginning of Year 1
x2 = model.addVar(name="x2", lb=0, ub=120000)

# x3: amount invested in Project 3 at beginning of Year 2
x3 = model.addVar(name="x3", lb=0, ub=150000)

# x4: amount invested in Project 4 at beginning of Year 3
x4 = model.addVar(name="x4", lb=0, ub=100000)

# Year 1 budget constraint: x1_1 + x2 <= initial_capital
model.addConstr(x1_1 + x2 <= initial_capital, name="Year1_Budget")

# Year 2 budget constraint: available cash = proceeds from x1_1 (matured same year = end of year 1)
# x1_1 * 1.20 is available at beginning of Year 2
# x1_2 + x3 <= x1_1 * 1.20
model.addConstr(x1_2 + x3 <= x1_1 * 1.20, name="Year2_Budget")

# Year 3 budget constraint: proceeds from x1_2 (matures same year = end of year 2) + x2 matures end of year 2
# Available at beginning of Year 3: x1_2 * 1.20 + x2 * 1.50
# Also include x3 * 1.60 which matures at end of Year 2
available_cash_y3_start = x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60

# Amount reserved for liquidity cushion
reserved_cash_y3 = model.addVar(name="reserved_cash_y3", lb=0, ub=available_cash_y3_start)

# Cash used for investments in Year 3
cash_used_y3 = x1_3 + x4

# Constraint to ensure that reserved cash plus cash used equals available cash
model.addConstr(reserved_cash_y3 + cash_used_y3 == available_cash_y3_start, name="Year3_Cash_Allocation")

# Objective function: total money at end of Year 3 minus penalty for shortfall in Year 3 reserve
# x1_3 matures end of Year 3: x1_3 * 1.20
# x4 matures end of Year 3: x4 * 1.40
# reserved_cash_y3 remains as cash at the end of Year 3
total_end_wealth = x1_3 * 1.20 + x4 * 1.40 + reserved_cash_y3

# Penalty for shortfall in Year 3 reserve
penalty = max(0, min_year3_reserve - reserved_cash_y3) * reserve_shortfall_penalty

# Final objective: maximize total_end_wealth - penalty
model.setObjective(total_end_wealth - penalty, GRB.MAXIMIZE)

# Optimize the model
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
