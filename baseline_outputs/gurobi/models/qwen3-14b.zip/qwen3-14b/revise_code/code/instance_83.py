import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read time periods and minimum waiters needed
time_periods = []
min_waiters = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        time_periods.append(row["Time"].strip())
        min_waiters.append(int(row["Minimum_Number_of_Waiters_Needed"].strip()))

# Read general parameters
general_params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row["Parameter_Name"].strip()
        if param_name == "waiter_work_hours":
            general_params[param_name] = int(row["Value"].strip())
        elif param_name.startswith("peak_"):
            general_params[param_name] = int(row["Value"].strip())
        elif param_name.startswith("quality_"):
            general_params[param_name] = int(row["Value"].strip())
        elif param_name == "waiter_cost_per_shift":
            general_params[param_name] = int(row["Value"].strip())
        elif param_name == "waiter_budget":
            general_params[param_name] = int(row["Value"].strip())

# Number of periods
n = len(time_periods)  # 6 periods, each 4 hours

# Each waiter works 8 hours = 2 consecutive 4-hour periods
# Periods indexed 0..5:
# 0: 2-6
# 1: 6-10
# 2: 10-14
# 3: 14-18
# 4: 18-22
# 5: 22-2

# x_i = number of waiters starting work at the beginning of period i
# Each waiter starting at period i works during periods i and (i+1) mod 6

model = gp.Model("Restaurant_Waiters")
model.setParam("OutputFlag", 0)

# Decision variables
x = model.addVars(n, name="x", vtype=gp.GRB.INTEGER, lb=0)

# Objective: minimize total number of waiters
model.setObjective(gp.quicksum(x[i] for i in range(n)) * general_params["waiter_cost_per_shift"], GRB.MINIMIZE)

# Constraints: for each period j, the number of waiters working >= min_waiters[j]
# Waiters working in period j are those who started in period j or period (j-1) mod n
for j in range(n):
    prev = (j - 1) % n
    model.addConstr(x[prev] + x[j] >= min_waiters[j], name=f"Period_{j}_{time_periods[j]}")

# Additional constraint: total staffing spend must stay within waiter_budget
model.addConstr(gp.quicksum(x[i] for i in range(n)) * general_params["waiter_cost_per_shift"] <= general_params["waiter_budget"], name="Budget_Constraint")

# Solve
model.optimize()

# Print results
total = model.objVal
print(f"FINAL_OBJ_VALUE: {total}")
