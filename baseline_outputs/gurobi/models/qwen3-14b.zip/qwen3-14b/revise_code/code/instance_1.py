import os
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            rows.append(row)
    return rows

def load_parameters():
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name'].strip()
        val = row['Value'].strip()
        try:
            if '.' in val:
                params[name] = float(val)
            else:
                params[name] = int(val)
        except ValueError:
            params[name] = val
    return params

def load_demand():
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        week = int(row['Week'].strip())
        demand[week] = {
            'I': int(row['I'].strip()),
            'II': int(row['II'].strip())
        }
    return demand

params = load_parameters()
demand = load_demand()

T = 8  # weeks
weeks = list(range(1, T + 1))

# Parameters
S0 = params['skilled_worker_count']  # 50
rate_I = params['food_I_production_rate']  # 10 kg/h
rate_II = params['food_II_production_rate']  # 6 kg/h
normal_hours = params['worker_weekly_hours']  # 40
overtime_hours = params['skilled_worker_overtime_hours']  # 60
train_cap = params['training_capacity']  # 3 trainees per trainer
train_period = params['training_period']  # 2 weeks
wage_skilled = params['skilled_worker_weekly_wage']  # 360
wage_trainee_during = params['trainee_weekly_wage_during_training']  # 120
wage_trainee_after = params['trainee_weekly_wage_after_training']  # 240
wage_overtime = params['skilled_worker_overtime_wage']  # 540
comp_I = params['compensation_fee_food_I']  # 0.5
comp_II = params['compensation_fee_food_II']  # 0.6
new_worker_goal = params['new_worker_training_goal']  # 50

model = gp.Model("factory_training")
model.setParam('OutputFlag', 0)

# Decision variables
# n_train[t] = number of skilled workers assigned to training starting in week t
n_train = {}
for t in weeks:
    if t <= T - 1:  # Can start training in weeks 1..7 (need 2 weeks)
        n_train[t] = model.addVar(vtype=gp.GRB.INTEGER, name=f"n_train_{t}", lb=0)

# Binary variable indicating whether the week is dedicated to Food I or II or idle
# 0: idle, 1: Food I, 2: Food II
prod_choice = {}
for t in weeks:
    prod_choice[t] = model.addVar(vtype=gp.GRB.INTEGER, name=f"prod_choice_{t}", lb=0, ub=2)

# Hours allocated to food by skilled workers (normal and overtime)
# and by graduated trainees
h_s = {}  # skilled hours
h_ot = {}  # overtime hours
h_g = {}  # graduated trainees hours
for t in weeks:
    h_s[t] = model.addVar(vtype=gp.GRB.CONTINUOUS, name=f"h_s_{t}", lb=0)
    h_ot[t] = model.addVar(vtype=gp.GRB.CONTINUOUS, name=f"h_ot_{t}", lb=0)
    h_g[t] = model.addVar(vtype=gp.GRB.CONTINUOUS, name=f"h_g_{t}", lb=0)

# Number of skilled workers doing overtime in week t
n_overtime = {t: model.addVar(vtype=gp.GRB.INTEGER, name=f"n_ot_{t}", lb=0) for t in weeks}

# Delayed delivery (backlog) for food I and II
backlog_I = {t: model.addVar(vtype=gp.GRB.CONTINUOUS, name=f"bI_{t}", lb=0) for t in weeks}
backlog_II = {t: model.addVar(vtype=gp.GRB.CONTINUOUS, name=f"bII_{t}", lb=0) for t in weeks}

# Objective function
obj = gp.LinExpr()

# Skilled worker wages
for t in weeks:
    obj += wage_skilled * S0  # All skilled workers are paid regardless of activity

# Overtime wages
for t in weeks:
    obj += wage_overtime * n_overtime[t]

# Trainee wages during training
for t in weeks:
    if t <= T - 1:
        obj += wage_trainee_during * n_train[t] * train_period

# Graduated trainees wages after training
grads_total = 0
for s in n_train:
    if s + train_period <= T:
        grads_total += train_cap * n_train[s]
obj += wage_trainee_after * grads_total

# Compensation costs
for t in weeks:
    obj += comp_I * backlog_I[t]
    obj += comp_II * backlog_II[t]

model.setObjective(obj, GRB.MINIMIZE)

# Constraints
# Constraint: Each week can only produce one type of food or be idle
for t in weeks:
    model.addConstr(prod_choice[t] >= 0)
    model.addConstr(prod_choice[t] <= 2)

# Constraint: If a week is not idle, it must be dedicated to exactly one product
for t in weeks:
    model.addConstr(prod_choice[t] * (prod_choice[t] - 1) == 0)

# Constraint: Training cannot exceed available skilled workers
for t in weeks:
    if t <= T - 1:
        # Trainers busy in week t
        expr = 0
        for s in n_train:
            if s <= t <= s + train_period - 1:
                expr += n_train[s]
        model.addConstr(expr <= S0)

# Constraint: Available skilled workers for production in week t
for t in weeks:
    expr = 0
    for s in n_train:
        if s <= t <= s + train_period - 1:
            expr += n_train[s]
    avail_skilled_t = S0 - expr
    model.addConstr(n_overtime[t] <= avail_skilled_t)

# Constraint: Skilled workers' normal and overtime hours
for t in weeks:
    model.addConstr(h_s[t] + h_ot[t] <= (S0 - n_overtime[t]) * normal_hours)
    model.addConstr(h_ot[t] <= n_overtime[t] * overtime_hours)

# Constraint: Graduated trainees' hours
for t in weeks:
    expr = 0
    for s in n_train:
        if s + train_period <= t:
            expr += train_cap * n_train[s]
    model.addConstr(h_g[t] <= expr * normal_hours)

# Constraint: Production choice affects which hours are used
for t in weeks:
    # If week is idle, no production
    model.addConstr(h_s[t] <= h_s[t] * (1 - (prod_choice[t] == 0)))
    model.addConstr(h_ot[t] <= h_ot[t] * (1 - (prod_choice[t] == 0)))
    model.addConstr(h_g[t] <= h_g[t] * (1 - (prod_choice[t] == 0)))

    # If week is for Food I, all hours go to Food I
    model.addConstr(h_s[t] <= h_s[t] * (prod_choice[t] == 1))
    model.addConstr(h_ot[t] <= h_ot[t] * (prod_choice[t] == 1))
    model.addConstr(h_g[t] <= h_g[t] * (prod_choice[t] == 1))

    # If week is for Food II, all hours go to Food II
    model.addConstr(h_s[t] <= h_s[t] * (prod_choice[t] == 2))
    model.addConstr(h_ot[t] <= h_ot[t] * (prod_choice[t] == 2))
    model.addConstr(h_g[t] <= h_g[t] * (prod_choice[t] == 2))

# Constraint: Backlog balance
for t in weeks:
    prev_bI = backlog_I[t-1] if t > 1 else 0
    prev_bII = backlog_II[t-1] if t > 1 else 0

    prod_I_t = (h_s[t] + h_ot[t] + h_g[t]) * rate_I if prod_choice[t] == 1 else 0
    prod_II_t = (h_s[t] + h_ot[t] + h_g[t]) * rate_II if prod_choice[t] == 2 else 0

    model.addConstr(backlog_I[t] >= prev_bI + demand[t]['I'] - prod_I_t)
    model.addConstr(backlog_II[t] >= prev_bII + demand[t]['II'] - prod_II_t)

# Constraint: At least new_worker_goal trained by end of week 8
total_trained = 0
for s in n_train:
    if s + train_period <= T:
        total_trained += train_cap * n_train[s]
model.addConstr(total_trained >= new_worker_goal)

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.objVal}")
