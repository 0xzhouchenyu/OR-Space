import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
general_params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        general_params[row["Parameter_Name"]] = row["Value"]

# Read items and values
items = []
values = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        items.append(row["Item"].strip())
        values.append(int(row["Value"].strip()))

n = len(items)
total_value = sum(values)

# Parse parameters
son1_min_share = float(general_params["son1_min_share"])
high_value_threshold = int(general_params["high_value_threshold"])
max_high_value_items_per_son = int(general_params["max_high_value_items_per_son"])
deferred_diamonds_per_son = int(general_params["deferred_diamonds_per_son"])
immediate_tax_weight = float(general_params["immediate_tax_weight"])
total_tax_weight = float(general_params["total_tax_weight"])

# Identify high-value items
high_value_items = [i for i in range(n) if values[i] > high_value_threshold]

# Identify diamonds (based on item names)
diamond_indices = [i for i, item in enumerate(items) if "Diamond" in item]
jr_indices = [i for i, item in enumerate(items) if "Jack Russell" in item]

# Create the optimization model
model = gp.Model("Inheritance_Split")
model.setParam('OutputFlag', 0)

# Binary variables: x[i] = 1 if item i goes to son 1, 0 if to son 2
x = model.addVars(n, vtype=GRB.BINARY, name="x")

# Variables for immediate and deferred values
immediate_value_son1 = gp.quicksum(values[i] * x[i] for i in range(n))
deferred_value_son1 = gp.quicksum(values[i] * (1 - x[i]) for i in range(n))

# Variable for the absolute difference
diff_immediate = model.addVar(name="diff_immediate", lb=0)
diff_total = model.addVar(name="diff_total", lb=0)

# Constraints for absolute difference
model.addConstr(diff_immediate >= 2 * immediate_value_son1 - total_value)
model.addConstr(diff_immediate >= total_value - 2 * immediate_value_son1)
model.addConstr(diff_total >= 2 * immediate_value_son1 - total_value)
model.addConstr(diff_total >= total_value - 2 * immediate_value_son1)

# Son 1 must receive at least son1_min_share of total value
model.addConstr(immediate_value_son1 >= son1_min_share * total_value)

# High-value items concentration constraint
high_value_count_son1 = gp.quicksum(x[i] for i in high_value_items)
high_value_count_son2 = gp.quicksum(1 - x[i] for i in high_value_items)
model.addConstr(high_value_count_son1 <= max_high_value_items_per_son)
model.addConstr(high_value_count_son2 <= max_high_value_items_per_son)

# Deferred diamonds per son constraint
deferred_diamonds_son1 = gp.quicksum((1 - x[i]) for i in diamond_indices)
deferred_diamonds_son2 = gp.quicksum(x[i] for i in diamond_indices)
model.addConstr(deferred_diamonds_son1 <= deferred_diamonds_per_son)
model.addConstr(deferred_diamonds_son2 <= deferred_diamonds_per_son)

# Jack Russell dogs must not be separated
if len(jr_indices) == 2:
    model.addConstr(x[jr_indices[0]] == x[jr_indices[1]])

# Objective function: minimize weighted sum of imbalances
objective = immediate_tax_weight * diff_immediate + total_tax_weight * diff_total
model.setObjective(objective, GRB.MINIMIZE)

# Solve the model
model.optimize()

# Extract solution
son1_items = []
son2_items = []
son1_val = 0
son2_val = 0
for i in range(n):
    if x[i].x > 0.5:
        son1_items.append((items[i], values[i]))
        son1_val += values[i]
    else:
        son2_items.append((items[i], values[i]))
        son2_val += values[i]

# Print solution details
print("Status:", model.status)
print(f"Total inheritance value: {total_value}")
print()

print("Son 1 receives:")
for item, val in son1_items:
    print(f"  {item}: {val}")
print(f"  Total: {son1_val}")
print()
print("Son 2 receives:")
for item, val in son2_items:
    print(f"  {item}: {val}")
print(f"  Total: {son2_val}")
print()
print(f"Difference: {abs(son1_val - son2_val)}")

print(f"FINAL_OBJ_VALUE: {model.objVal}")
