import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Construct paths
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load data
def load_feed_data(filepath):
    feeds = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            feed = {
                'Feed': int(row['Feed']),
                'Protein_g': float(row['Protein_g']),
                'Minerals_g': float(row['Minerals_g']),
                'Vitamins_mg': float(row['Vitamins_mg']),
                'Price_Y_per_kg': float(row['Price_Y_per_kg']),
            }
            feeds.append(feed)
    return feeds

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

feeds = load_feed_data(os.path.join(data_dir, "table_1.csv"))
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

min_protein = params['min_protein_requirement']
min_minerals = params['min_minerals_requirement']
min_vitamins = params['min_vitamins_requirement']

# Create LP problem
model = gp.Model("MinimizeFeedCost")
model.setParam('OutputFlag', 0)

# Decision variables: amount of each feed (kg), non-negative
x = {}
for f in feeds:
    x[f['Feed']] = model.addVar(name=f"x_{f['Feed']}", lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS)

# Objective: minimize total cost
model.setObjective(gp.quicksum(f['Price_Y_per_kg'] * x[f['Feed']] for f in feeds), GRB.MINIMIZE)

# Constraints
# Protein constraint
model.addConstr(gp.quicksum(f['Protein_g'] * x[f['Feed']] for f in feeds) >= min_protein, "ProteinRequirement")

# Minerals constraint
model.addConstr(gp.quicksum(f['Minerals_g'] * x[f['Feed']] for f in feeds) >= min_minerals, "MineralsRequirement")

# Vitamins constraint
model.addConstr(gp.quicksum(f['Vitamins_mg'] * x[f['Feed']] for f in feeds) >= min_vitamins, "VitaminsRequirement")

# Mutual exclusion constraint between Feed 4 and Feed 5
feed4 = next(f for f in feeds if f['Feed'] == 4)
feed5 = next(f for f in feeds if f['Feed'] == 5)
model.addConstr(x[feed4['Feed']] * x[feed5['Feed']] == 0, "MutualExclusion")

# Solve
model.optimize()

# Print results
for f in feeds:
    val = x[f['Feed']].X
    print(f"Feed {f['Feed']}: {val:.6f} kg")

obj_val = model.objVal
print(f"FINAL_OBJ_VALUE: {obj_val}")
