import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    
    # Create MIP model
    model = gp.Model("Production_Optimization")
    model.setParam("OutputFlag", 0)
    
    # Decision variables: number of units to produce for each product
    x = {}
    for p in products:
        x[p["Product"]] = model.addVar(name=f"x_{p['Product']}", lb=0, vtype=GRB.CONTINUOUS)
    
    # Binary variable to indicate if line audit fee is triggered for Product A
    audit_fee_A = model.addVar(vtype=GRB.BINARY, name="audit_fee_A")
    
    # Objective function: maximize profit minus any additional costs
    obj = gp.quicksum(float(p["Profit_yuan"]) * x[p["Product"]] for p in products)
    
    # Subtract setup costs
    obj -= float(products[0]["Setup_Cost_yuan"]) * x["A"]
    obj -= float(products[1]["Setup_Cost_yuan"]) * x["B"]
    
    # Subtract line audit fee if applicable
    obj -= params["product_A_line_audit_fee"] * audit_fee_A
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints
    # Steel constraint
    model.addConstr(gp.quicksum(float(p["Steel_Required_kg"]) * x[p["Product"]] for p in products) <= params["available_steel"], "Steel")
    
    # Aluminum constraint
    model.addConstr(gp.quicksum(float(p["Aluminum_Required_kg"]) * x[p["Product"]] for p in products) <= params["available_aluminum"], "Aluminum")
    
    # Labor constraint
    labor_used = gp.quicksum(float(p["Labor_Required_hours"]) * x[p["Product"]] for p in products)
    model.addConstr(labor_used <= params["available_labor"], "Labor")
    
    # Overtime constraint
    overtime_used = max(0, labor_used - params["available_labor"])
    model.addConstr(overtime_used <= params["max_overtime"], "Max_Overtime")
    
    # Overtime review fee constraint
    overtime_review_fee = model.addVar(name="overtime_review_fee", lb=0)
    model.addConstr(overtime_used >= params["overtime_review_threshold"] * overtime_review_fee, "Overtime_Review_Fee")
    model.addConstr(overtime_review_fee <= 1, "Overtime_Review_Fee_Binary")
    obj -= params["overtime_review_fee"] * overtime_review_fee
    
    # Line audit fee constraint for Product A
    model.addConstr(x["A"] >= params["product_A_line_audit_threshold"] * audit_fee_A, "Audit_Fee_Trigger_A")
    model.addConstr(audit_fee_A <= 1, "Audit_Fee_Binary_A")
    
    # Optimize the model
    model.optimize()
    
    # Print results
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
