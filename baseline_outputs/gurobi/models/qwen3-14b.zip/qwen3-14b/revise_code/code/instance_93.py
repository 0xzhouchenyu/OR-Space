import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = row["Value"].strip()
            params[name] = val
    
    # Extract parameters
    milk_per_barrel = float(params["milk_per_barrel"])
    product_A1_yield = float(params["product_A1_yield"])
    product_A1_time = float(params["product_A1_time"])
    product_A2_yield = float(params["product_A2_yield"])
    product_A2_time = float(params["product_A2_time"])
    product_A3_yield = float(params["product_A3_yield"])
    product_A3_time = float(params["product_A3_time"])
    profit_per_kg_A1 = float(params["profit_per_kg_A1"])
    profit_per_kg_A2 = float(params["profit_per_kg_A2"])
    profit_per_kg_A3 = float(params["profit_per_kg_A3"])
    daily_milk_supply = float(params["daily_milk_supply"])
    daily_labor_hours = float(params["daily_labor_hours"])
    type_A_capacity = float(params["type_A_capacity"])
    cap_A_shared = float(params["cap_A_shared"])
    min_A2_kg = float(params["min_A2_kg"])
    min_A3_kg = float(params["min_A3_kg"])
    type_A_cleaning_loss_if_A3 = float(params["type_A_cleaning_loss_if_A3"])
    cold_chain_bonus_threshold_kg = float(params["cold_chain_bonus_threshold_kg"])
    cold_chain_bonus_yuan = float(params["cold_chain_bonus_yuan"])

    # Decision variables: x1, x2, x3 = barrels of milk for A1, A2, A3
    model = gp.Model("Dairy_Production_Rev")
    model.setParam('OutputFlag', 0)

    x1 = model.addVar(name="x1", lb=0, ub=daily_milk_supply, vtype=GRB.CONTINUOUS)  # barrels for A1
    x2 = model.addVar(name="x2", lb=0, ub=daily_milk_supply, vtype=GRB.CONTINUOUS)  # barrels for A2
    x3 = model.addVar(name="x3", lb=0, ub=daily_milk_supply, vtype=GRB.CONTINUOUS)  # barrels for A3

    # Objective: maximize profit
    profit_A1 = product_A1_yield * profit_per_kg_A1
    profit_A2 = product_A2_yield * profit_per_kg_A2
    profit_A3 = product_A3_yield * profit_per_kg_A3

    model.setObjective(
        (profit_A1 * x1) + (profit_A2 * x2) + (profit_A3 * x3) + 
        gp.quicksum(cold_chain_bonus_yuan if product_A3_yield * x3 >= cold_chain_bonus_threshold_kg else 0),
        GRB.MAXIMIZE
    )

    # Constraints
    # Milk supply constraint
    model.addConstr(x1 + x2 + x3 <= daily_milk_supply, "Milk_Supply")

    # Labor hours constraint
    model.addConstr(
        (product_A1_time * x1) + (product_A2_time * x2) + (product_A3_time * x3) <= daily_labor_hours,
        "Labor_Hours"
    )

    # Type A equipment capacity constraint (shared between A1 and A3)
    model.addConstr(
        (product_A1_yield * x1) + (product_A3_yield * x3) <= cap_A_shared - (type_A_cleaning_loss_if_A3 * gp.quicksum(1 if x3 > 0 else 0)),
        "Type_A_Capacity"
    )

    # Minimum A2 production constraint
    model.addConstr(product_A2_yield * x2 >= min_A2_kg, "Min_A2_Production")

    # Minimum A3 production constraint
    model.addConstr(product_A3_yield * x3 >= min_A3_kg, "Min_A3_Production")

    # Solve the model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
