import os
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    demand_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_4_3.csv")
    supply_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_4_4.csv")
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")

    demand_df = pd.read_csv(demand_path)
    supply_df = pd.read_csv(supply_path)
    params_df = pd.read_csv(params_path)

    # Parse parameters
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])

    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem

    # Parse supply
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = float(row['Number_of_People'])
        suit = [int(x) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }

    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]

    # Create model
    model = gp.Model("staffing_optimization")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[i][j][k] = number of type i assigned to city j with specialty k
    x = model.addVars(types, cities, specs, name="x", lb=0, vtype=GRB.INTEGER)

    # Decision variable: d2_minus = shortfall in priority 2 (preferred specialty)
    d2_minus = model.addVar(name="d2_minus", lb=0, vtype=GRB.INTEGER)

    # Decision variable: dual_match = number of recruits who get both preferred specialty and city
    dual_match = model.addVar(name="dual_match", lb=0, vtype=GRB.INTEGER)

    # Constraint 1: Supply constraints
    for i in types:
        model.addConstr(gp.quicksum(x[i, j, k] for j in cities for k in specs) <= supply[i]['num'], name=f"supply_{i}")

    # Constraint 2: Demand constraints
    for j in cities:
        for k in specs:
            model.addConstr(gp.quicksum(x[i, j, k] for i in types) >= demand[(j, k)], name=f"demand_{j}_{k}")

    # Constraint 3: Only assign people to specialties they are suitable for
    for i in types:
        for j in cities:
            for k in specs:
                if k not in supply[i]['suit']:
                    model.addConstr(x[i, j, k] == 0, name=f"suitability_{i}_{j}_{k}")

    # Constraint 4: Priority 2 - At least p2_target people get their preferred specialty
    p2_expr = gp.quicksum(x[i, j, supply[i]['pref_spec']] for i in types for j in cities)
    model.addConstr(p2_expr >= p2_target, name="priority_2")

    # Constraint 5: Count dual matches (both preferred specialty and city)
    dual_match_expr = gp.quicksum(x[i, supply[i]['pref_city'], supply[i]['pref_spec']] for i in types)
    model.addConstr(dual_match == dual_match_expr, name="dual_match")

    # Objective: Maximize the number of dual matches
    model.setObjective(dual_match, GRB.MAXIMIZE)

    # Optimize
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {int(model.objVal)}")

if __name__ == '__main__':
    import pandas as pd
    solve()
