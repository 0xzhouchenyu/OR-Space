import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    W = params['initial_investment']       # 100000
    r1 = params['return_rate_option_1']    # 0.7
    r2 = params['return_rate_option_2']    # 2.0
    T = int(params['planning_horizon'])    # 3
    min_reserve_year1 = params['min_reserve_year1']
    min_reserve_year2 = params['min_reserve_year2']
    max_option2_start = params['max_option2_start']
    option2_late_settlement_rate = params['option2_year0_late_settlement_rate']

    model = gp.Model("Investment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x0_1 = model.addVar(name="x0_1", lb=0)
    x0_2 = model.addVar(name="x0_2", lb=0, ub=max_option2_start)
    x1_1 = model.addVar(name="x1_1", lb=0)
    x1_2 = model.addVar(name="x1_2", lb=0, ub=max_option2_start)
    x2_1 = model.addVar(name="x2_1", lb=0)

    # Year 0 budget constraint
    model.addConstr(x0_1 + x0_2 <= W, name="year0_budget")

    # Year 1: money available = returns from x0_1 = x0_1 * (1 + r1)
    model.addConstr(x1_1 + x1_2 <= x0_1 * (1 + r1), name="year1_budget")
    model.addConstr(x1_1 + x1_2 >= min_reserve_year1, name="year1_min_reserve")

    # Year 2: money available = returns from x1_1 + returns from x0_2 adjusted for late settlement
    model.addConstr(x2_1 <= x1_1 * (1 + r1) + x0_2 * (1 + r2) * (1 - option2_late_settlement_rate), name="year2_budget")
    model.addConstr(x2_1 >= min_reserve_year2, name="year2_min_reserve")

    # Objective: maximize total wealth at year 3
    objective = x2_1 * (1 + r1) + x1_2 * (1 + r2) * (1 - option2_late_settlement_rate)
    model.setObjective(objective, GRB.MAXIMIZE)

    model.optimize()

    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
