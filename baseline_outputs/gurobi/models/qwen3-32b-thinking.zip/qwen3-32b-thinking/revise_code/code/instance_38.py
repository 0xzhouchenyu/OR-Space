import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_processing_times(filepath):
    """Load processing times from CSV file.
    Returns a list of lists: processing_times[i][j] = time for product i on machine j.
    """
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # Skip header
        for row in reader:
            # First column is product name, rest are processing times
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times

def load_parameters(filepath):
    """Load general parameters from CSV file."""
    parameters = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            parameter_name = row['Parameter_Name']
            value = float(row['Value'])
            parameters[parameter_name] = value
    return parameters

def main():
    # Load data
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    processing_times = load_processing_times(os.path.join(data_dir, "table_1.csv"))
    parameters = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    n_products = len(processing_times)
    n_machines = len(processing_times[0])
    
    # Extract relevant parameters
    time_windows = [parameters[f"time_window_{j+1}"] for j in range(n_machines)]
    overtime_windows = [parameters[f"overtime_window_{j+1}"] for j in range(n_machines)]
    overtime_penalty_per_unit = parameters["overtime_penalty_per_unit"]
    M_values = [parameters[f"M_{j+1}"] for j in range(n_machines)]
    machine1_overtime_review_threshold = parameters["machine1_overtime_review_threshold"]
    machine1_overtime_review_fee = parameters["machine1_overtime_review_fee"]
    
    # Create Gurobi model
    model = gp.Model("FlowShopScheduling")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    # Completion time of job i on machine j
    C = model.addVars(n_products, n_machines, name="C", lb=0)
    
    # Overtime usage for each machine
    OT = model.addVars(n_machines, name="OT", lb=0)
    
    # Binary variable to indicate if Machine 1 overtime exceeds threshold
    Z = model.addVar(vtype=GRB.BINARY, name="Z")
    
    # Sequence variables (permutation matrix)
    x = model.addVars(n_products, n_products, vtype=GRB.BINARY, name="x")
    
    # Objective function: minimize makespan + overtime cost + review fee
    makespan = C[n_products-1, n_machines-1]
    overtime_cost = sum(OT[j] * overtime_penalty_per_unit for j in range(n_machines))
    review_fee = Z * machine1_overtime_review_fee
    
    model.setObjective(makespan + overtime_cost + review_fee, GRB.MINIMIZE)
    
    # Constraints
    
    # Each job is assigned to exactly one position in the sequence
    for i in range(n_products):
        model.addConstr(gp.quicksum(x[i, p] for p in range(n_products)) == 1)
    
    # Each position has exactly one job
    for p in range(n_products):
        model.addConstr(gp.quicksum(x[i, p] for i in range(n_products)) == 1)
    
    # Completion time constraints for machine 1
    for i in range(n_products):
        for j in range(n_products):
            if i != j:
                model.addConstr(C[i, 0] >= C[j, 0] - M_values[0] * (1 - x[i, j]))
    
    # Completion time constraints for machines 2 and 3
    for m in range(1, n_machines):
        for i in range(n_products):
            for j in range(n_products):
                if i != j:
                    model.addConstr(C[i, m] >= C[j, m] - M_values[m] * (1 - x[i, j]))
    
    # Processing time constraints
    for i in range(n_products):
        model.addConstr(C[i, 0] >= processing_times[i][0])
        
        for m in range(1, n_machines):
            model.addConstr(C[i, m] >= C[i, m-1] + processing_times[i][m])
    
    # Overtime constraints
    for m in range(n_machines):
        model.addConstr(OT[m] >= C[n_products-1, m] - (time_windows[m] + overtime_windows[m]))
        model.addConstr(OT[m] <= C[n_products-1, m] - time_windows[m])
        model.addConstr(OT[m] >= 0)
    
    # Special constraint for Machine 1 review fee
    model.addConstr(OT[0] - machine1_overtime_review_threshold <= M_values[0] * Z)
    model.addConstr(machine1_overtime_review_threshold + 1e-6 <= OT[0] + M_values[0] * (1 - Z))
    
    # Optimize the model
    model.optimize()
    
    # Output results
    if model.status == GRB.OPTIMAL:
        final_obj_value = model.objVal
        print(f"FINAL_OBJ_VALUE: {final_obj_value}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
