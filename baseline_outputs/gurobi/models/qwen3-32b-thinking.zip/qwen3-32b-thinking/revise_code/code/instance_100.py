import os
import csv
from gurobipy import GRB, Model

def main():
    # Load the bandwidth table
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # Strip whitespace from headers
        nodes = [h.strip() for h in header[1:]]
        
        bandwidth = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                if bw > 0:  # Only consider links with positive bandwidth
                    bandwidth[(row_node, col_node)] = bw
    
    # Define source, intermediate, and target nodes
    source = 'A'
    intermediate = 'C'
    target = 'E'
    
    # Create Gurobi model
    model = Model("network_routing")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: x[i,j] = 1 if link (i,j) is used in the path
    x = {}
    for i, j in bandwidth:
        x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
    
    # Objective: minimize total routing cost
    model.setObjective(gp.quicksum((100 - bandwidth[i, j]) * x[i, j] for i, j in bandwidth), GRB.MINIMIZE)
    
    # Constraints
    # Flow conservation at each node
    for node in nodes:
        inflow = gp.LinExpr(0)
        outflow = gp.LinExpr(0)
        for i, j in bandwidth:
            if j == node:
                inflow += x[i, j]
            if i == node:
                outflow += x[i, j]
        
        if node == source:
            model.addConstr(outflow - inflow == 1, f"flow_conserv_{node}")
        elif node == target:
            model.addConstr(inflow - outflow == 1, f"flow_conserv_{node}")
        else:
            model.addConstr(inflow - outflow == 0, f"flow_conserv_{node}")
    
    # Ensure path goes through intermediate node C
    # Outflow from C must equal inflow to C
    outflow_from_C = gp.LinExpr(0)
    inflow_to_C = gp.LinExpr(0)
    for i, j in bandwidth:
        if i == intermediate:
            outflow_from_C += x[i, j]
        if j == intermediate:
            inflow_to_C += x[i, j]
    model.addConstr(outflow_from_C == inflow_to_C, "intermediate_flow")
    
    # Ensure that we actually go through C
    model.addConstr(outflow_from_C >= 1, "must_pass_through_C")
    
    # Solve the model
    model.optimize()
    
    # Extract solution
    optimal_cost = model.objVal
    selected_links = [(i, j) for i, j in bandwidth if x[i, j].x > 0.5]
    
    print(f"\nSelected links: {selected_links}")
    print(f"Minimum total routing cost: {optimal_cost}")
    
    print(f"FINAL_OBJ_VALUE: {optimal_cost}")

if __name__ == '__main__':
    main()
