import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read property data
properties = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_risky_multiplier = params['scen_1_risky_multiplier']
scen_2_risky_multiplier = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = params['max_risky_properties']

# Create optimization model
model = gp.Model("RevisedRealEstateInvestment")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}  # Binary variable: 1 if property is purchased, 0 otherwise
y = {}  # Continuous variable: fraction of property allocated to risky tenants (0 <= y <= 1 if x=1)
for p in properties:
    prop_name = p['name']
    x[prop_name] = model.addVar(vtype=GRB.BINARY, name=f"x_{prop_name}")
    y[prop_name] = model.addVar(lb=0.0, ub=1.0, vtype=GRB.CONTINUOUS, name=f"y_{prop_name}")

# Objective function: maximize expected annual income
# Expected income = sum(Annual_Income * x) + sum(y * Annual_Income * [scen_1_prob*scen_1_risky_multiplier + scen_2_prob*scen_2_risky_multiplier])
expected_income = (
    gp.quicksum(p['income'] * x[p['name']] for p in properties) +
    gp.quicksum(
        y[p['name']] * p['income'] * 
        (scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier) 
        for p in properties
    )
)
model.setObjective(expected_income, GRB.MAXIMIZE)

# Budget constraint: total cost of purchased properties <= budget
model.addConstr(gp.quicksum(p['cost'] * x[p['name']] for p in properties) <= budget, "BudgetConstraint")

# Property exclusion constraint: If Property 4 is purchased, Property 3 cannot be purchased
model.addConstr(x["Property_4"] + x["Property_3"] <= 1, "PropertyExclusionConstraint")

# Risky allocation constraints
# 1. Total risky exposure must stay within total_risky_budget
model.addConstr(gp.quicksum(p['cost'] * x[p['name']] * y[p['name']] for p in properties) <= total_risky_budget, "TotalRiskyBudgetConstraint")

# 2. Each individual property has its own per_property_risky_cap
for p in properties:
    model.addConstr(y[p['name']] <= per_property_risky_cap * x[p['name']], f"PerPropertyRiskyCap_{p['name']}")

# 3. Maximum number of properties that may have any risky tenants
model.addConstr(gp.quicksum(x[p['name']] * y[p['name']] > 0 for p in properties) <= max_risky_properties, "MaxRiskyPropertiesConstraint")

# Optimize the model
model.optimize()

# Print results
for p in properties:
    print(f"{p['name']}: {int(x[p['name']].X)} (Risky Fraction: {y[p['name']].X:.2f})")

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
