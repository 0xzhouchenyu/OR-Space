import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Extract parameters
min_A_I = params["min_proportion_crude_A_type_I"] / 100.0  # Minimum crude A share in Type I
min_A_II = params["min_proportion_crude_A_type_II"] / 100.0  # Minimum crude A share in Type II
price_I = params["selling_price_type_I"]  # Selling price of Type I
price_II = params["selling_price_type_II"]  # Selling price of Type II
inv_A = params["inventory_crude_A"]  # Current inventory of crude A
inv_B = params["inventory_crude_B"]  # Current inventory of crude B
max_purchase_A = params["max_purchase_crude_A"]  # Maximum crude A market purchase
cost_tier1 = params["market_price_crude_A_tier_1"]  # Crude A first block price
cost_tier2 = params["market_price_crude_A_tier_2"]  # Crude A second block price
cost_tier3 = params["market_price_crude_A_tier_3"]  # Crude A third block price
processing_capacity = params["processing_capacity"]  # Maximum total gasoline output
min_total_gasoline_output = params["min_total_gasoline_output"]  # Minimum total gasoline output
processing_cost_per_ton = params["processing_cost_per_ton"]  # Variable processing cost per ton
type_II_contract_threshold = params["type_II_contract_threshold"]  # Type II output required for the uplift
type_II_price_lift = params["type_II_price_lift"]  # Additional Type II revenue if threshold is met
bulk_purchase_rebate_threshold = params["bulk_purchase_rebate_threshold"]  # Crude A purchase level required for rebate
bulk_purchase_rebate = params["bulk_purchase_rebate"]  # Fixed crude A bulk-purchase rebate

# Create a new model
model = gp.Model("Oil_Blending_Rev")
model.setParam('OutputFlag', 0)  # Suppress Gurobi output

# Decision variables
# Amount of crude A used in gasoline I and II
a1 = model.addVar(name="crude_A_in_I", lb=0)  # crude A -> gasoline I
a2 = model.addVar(name="crude_A_in_II", lb=0)  # crude A -> gasoline II
b1 = model.addVar(name="crude_B_in_I", lb=0)  # crude B -> gasoline I
b2 = model.addVar(name="crude_B_in_II", lb=0)  # crude B -> gasoline II

# Tiered purchase variables for crude A
p1 = model.addVar(name="purchase_tier1", lb=0, ub=500)   # first 500t
p2 = model.addVar(name="purchase_tier2", lb=0, ub=500)   # next 500t
p3 = model.addVar(name="purchase_tier3", lb=0, ub=500)   # last 500t

# Binary variables to enforce tiered ordering
y1 = model.addVar(vtype=GRB.BINARY, name="y1")  # 1 if tier1 is fully used
y2 = model.addVar(vtype=GRB.BINARY, name="y2")  # 1 if tier2 is fully used

# Binary variable for type II contract threshold
z = model.addVar(vtype=GRB.BINARY, name="z")  # 1 if type II output meets threshold

# Update the model
model.update()

# Tiered ordering constraints
model.addConstr(p2 <= 500 * y1, "tier_ordering_1")
model.addConstr(p3 <= 500 * y2, "tier_ordering_2")
model.addConstr(p1 >= 500 * y1, "tier_ordering_3")
model.addConstr(p2 >= 500 * y2, "tier_ordering_4")

# Total crude A available = inventory + purchased
total_A_purchased = p1 + p2 + p3
model.addConstr(a1 + a2 <= inv_A + total_A_purchased, "crude_A_supply")
model.addConstr(b1 + b2 <= inv_B, "crude_B_supply")

# Blending constraints (minimum proportion of crude A)
model.addConstr(a1 >= min_A_I * (a1 + b1), "blend_I")
model.addConstr(a2 >= min_A_II * (a2 + b2), "blend_II")

# Total gasoline output constraints
total_output = (a1 + b1) + (a2 + b2)
model.addConstr(total_output <= processing_capacity, "max_output")
model.addConstr(total_output >= min_total_gasoline_output, "min_output")

# Type II contract threshold constraint
model.addConstr((a2 + b2) >= type_II_contract_threshold - 1e6 * (1 - z), "type_II_threshold_1")
model.addConstr((a2 + b2) <= type_II_contract_threshold + 1e6 * z, "type_II_threshold_2")

# Objective function: Revenue - Cost
revenue = price_I * (a1 + b1) + price_II * (a2 + b2) + type_II_price_lift * (a2 + b2) * z
cost = cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3 + processing_cost_per_ton * total_output
rebate = bulk_purchase_rebate * gp.if_then(total_A_purchased >= bulk_purchase_rebate_threshold, 1, 0)

model.setObjective(revenue - cost + rebate, GRB.MAXIMIZE)

# Optimize the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
