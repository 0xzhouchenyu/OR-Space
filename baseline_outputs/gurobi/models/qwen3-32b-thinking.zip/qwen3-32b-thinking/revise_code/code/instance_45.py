import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])

    # Read product segments and profits
    products = []
    segments = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row["Product"]
            if p not in segments:
                segments[p] = []
                products.append(p)
            rng = row["Sales_Volume_Range"]
            profit = float(row["Profit"])
            if rng.startswith("Above_"):
                lower = float(rng.split("_")[1])
                upper = None
            else:
                parts = rng.split("_")
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({"lower": lower, "upper": upper, "profit": profit})

    model = gp.Model("Maximize_Profit")
    model.setParam("OutputFlag", 0)

    M = 10000  # Big-M value for constraints

    x = {}  # Production quantity of each product
    p_var = {}  # Profit contribution of each product
    y = {}  # Binary variables to select the correct profit segment

    for prod in products:
        x[prod] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{prod}")
        p_var[prod] = model.addVar(lb=0, name=f"p_{prod}")
        y[prod] = []
        for i in range(len(segments[prod])):
            y[prod].append(model.addVar(vtype=GRB.BINARY, name=f"y_{prod}_{i}"))

    # Objective: Maximize total profit minus overtime cost and second review fee
    model.setObjective(gp.quicksum(p_var[prod] for prod in products), GRB.MAXIMIZE)

    # Constraints for selecting the correct profit segment
    for prod in products:
        segs = segments[prod]
        # Mutual exclusivity: at most one segment active
        model.addConstr(gp.quicksum(y[prod]) <= 1, name=f"mutual_exclusivity_{prod}")

        for i, seg in enumerate(segs):
            lo = seg["lower"]
            hi = seg["upper"]
            profit = seg["profit"]

            # If y[i]=1, x must be in [lo+1, hi] (or [lo+1, inf] for last segment)
            if lo == 0:
                model.addConstr(x[prod] >= 1 - M * (1 - y[prod][i]), name=f"lower_bound_{prod}_{i}")
            else:
                model.addConstr(x[prod] >= (lo + 1) - M * (1 - y[prod][i]), name=f"lower_bound_{prod}_{i}")

            if hi is not None:
                model.addConstr(x[prod] <= hi + M * (1 - y[prod][i]), name=f"upper_bound_{prod}_{i}")

            # Profit bound
            model.addConstr(p_var[prod] <= profit * x[prod] + M * (1 - y[prod][i]), name=f"profit_bound_{prod}_{i}")

        # If no segment active (production=0), force x=0 and profit=0
        model.addConstr(x[prod] <= M * gp.quicksum(y[prod]), name=f"force_zero_production_{prod}")
        model.addConstr(p_var[prod] <= M * gp.quicksum(y[prod]), name=f"force_zero_profit_{prod}")

    # Resource constraints
    # Technical preparation time constraint
    model.addConstr(
        gp.quicksum(params[f"technical_prep_time_{prod}"] * x[prod] for prod in products) 
        <= params["available_technical_prep_time"],
        name="technical_prep_time"
    )

    # Labor time constraint (regular + overtime)
    labor_used = gp.quicksum(params[f"labor_time_{prod}"] * x[prod] for prod in products)
    regular_labor = params["available_labor_time"]
    overtime_hours = model.addVar(lb=0, ub=params["overtime_cap_hours"], name="overtime_hours")
    model.addConstr(labor_used <= regular_labor + overtime_hours, name="labor_time")

    # Overtime second review constraint
    second_review_fee = model.addVar(vtype=GRB.BINARY, name="second_review_fee")
    model.addConstr(overtime_hours <= params["overtime_second_review_threshold"] + M * (1 - second_review_fee), name="first_tier_overtime")
    model.addConstr(overtime_hours >= params["overtime_second_review_threshold"] + 1 - M * second_review_fee, name="second_tier_overtime")

    # Update objective to subtract overtime cost and second review fee
    model.setObjective(
        gp.quicksum(p_var[prod] for prod in products) 
        - params["overtime_cost_per_hour"] * overtime_hours 
        - params["overtime_second_review_fee"] * second_review_fee,
        GRB.MAXIMIZE
    )

    # Packaging line capacity constraint
    model.addConstr(
        gp.quicksum(params[f"pack_units_{prod}"] * x[prod] for prod in products) 
        <= params["packaging_cap_units"],
        name="packaging_capacity"
    )

    # Optimize the model
    model.optimize()

    # Output the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
