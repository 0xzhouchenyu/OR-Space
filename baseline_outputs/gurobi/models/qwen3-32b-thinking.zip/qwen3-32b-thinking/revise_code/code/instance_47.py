import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils import load_general_parameters, load_crop_data
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    params = load_general_parameters()
    crops, crop_data = load_crop_data()
    
    # Extract parameters
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']
    
    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = params['max_chickens']
    max_dairy_cows = params['max_dairy_cows']
    fixed_cost_chicken_setup = params['fixed_cost_chicken_setup']
    min_chickens_if_coop_open = params['min_chickens_if_coop_open']
    second_biosecurity_threshold = params['second_biosecurity_threshold']
    second_biosecurity_cost = params['second_biosecurity_cost']
    biosecurity_training_aw_days = params['biosecurity_training_aw_days']
    biosecurity_training_ss_days = params['biosecurity_training_ss_days']
    
    # Crop data
    # Person-days (Autumn/Winter), Person-days (Spring/Summer), Annual Net Income (Yuan/hectare)
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']
    
    # Create Gurobi model
    model = gp.Model("Farm_Optimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    # Crop areas
    x = {}
    for c in crops:
        x[c] = model.addVar(name=f"x_{c}", lb=0)
    
    # Number of dairy cows and chickens
    y_dairy = model.addVar(name="dairy_cows", lb=0, ub=max_dairy_cows)
    y_chicken = model.addVar(name="chickens", lb=0, ub=max_chickens)
    
    # Surplus labor for external work
    surplus_aw = model.addVar(name="surplus_aw", lb=0)
    surplus_ss = model.addVar(name="surplus_ss", lb=0)
    
    # Binary variable to indicate if coop is open (1 if chickens > 0, 0 otherwise)
    z_coop_open = model.addVar(vtype=GRB.BINARY, name="z_coop_open")
    
    # Binary variable to indicate if flock exceeds second threshold (1 if chickens >= second threshold, 0 otherwise)
    z_second_inspection = model.addVar(vtype=GRB.BINARY, name="z_second_inspection")
    
    # Update the model
    model.update()
    
    # Objective: maximize net income from crops + animals + external work - fixed costs
    obj = (
        sum(crop_income[c] * x[c] for c in crops) +
        income_dairy * y_dairy +
        income_chicken * y_chicken +
        ext_rate_aw * surplus_aw +
        ext_rate_ss * surplus_ss -
        fixed_cost_chicken_setup * z_coop_open -
        second_biosecurity_cost * z_second_inspection
    )
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Land constraint
    model.addConstr(sum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, "Land")
    
    # Funds constraint
    model.addConstr(inv_dairy * y_dairy + inv_chicken * y_chicken <= funds_available, "Funds")
    
    # Labor autumn/winter constraint
    model.addConstr(
        sum(crop_aw[c] * x[c] for c in crops) +
        labor_aw_dairy * y_dairy +
        labor_aw_chicken * y_chicken +
        biosecurity_training_aw_days * z_coop_open +
        surplus_aw <= labor_aw,
        "Labor_AW"
    )
    
    # Labor spring/summer constraint
    model.addConstr(
        sum(crop_ss[c] * x[c] for c in crops) +
        labor_ss_dairy * y_dairy +
        labor_ss_chicken * y_chicken +
        biosecurity_training_ss_days * z_coop_open +
        surplus_ss <= labor_ss,
        "Labor_SS"
    )
    
    # Coop open condition: If any chickens are raised, then z_coop_open = 1
    model.addConstr(y_chicken >= 0.001 * z_coop_open, "Coop_Open_1")
    model.addConstr(y_chicken <= max_chickens * z_coop_open, "Coop_Open_2")
    
    # Minimum flock size if coop is open
    model.addConstr(y_chicken >= min_chickens_if_coop_open * z_coop_open, "Min_Flock_Size")
    
    # Second inspection condition: If chickens exceed threshold, then z_second_inspection = 1
    model.addConstr(y_chicken <= second_biosecurity_threshold + (max_chickens - second_biosecurity_threshold) * z_second_inspection, "Second_Inspection_1")
    model.addConstr(y_chicken >= second_biosecurity_threshold * z_second_inspection, "Second_Inspection_2")
    
    # Optimize the model
    model.optimize()
    
    # Output results
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
