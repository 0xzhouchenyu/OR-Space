import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            
            # Handle ratio values like "5:2"
            if ':' in value_str:
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params_file = os.path.join(data_dir, "general_parameters.csv")
    params = load_parameters(params_file)
    
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_hours = params['machine_working_time']
    machine_working_time_minutes = machine_working_time_hours * 60  # convert to minutes
    max_overtime_hours = params['max_overtime_hours']
    overtime_penalty_per_hour = params['overtime_penalty_per_hour']
    overtime_review_threshold_hours = params['overtime_review_threshold_hours']
    overtime_review_fee = params['overtime_review_fee']
    production_ratio_A_to_B = params['production_ratio_A_to_B']
    product_A_senior_batch_threshold = params['product_A_senior_batch_threshold']
    product_A_senior_batch_fee = params['product_A_senior_batch_fee']
    
    # Convert production ratio to integers
    ratio_A, ratio_B = map(int, production_ratio_A_to_B.split(':'))
    
    # Create model
    model = gp.Model("Revised_Product_Mix")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    A = model.addVar(name="Product_A", lb=0, vtype=GRB.CONTINUOUS)
    B = model.addVar(name="Product_B", lb=0, vtype=GRB.CONTINUOUS)
    
    # Overtime variables
    regular_time_used = model.addVar(name="Regular_Time_Used", lb=0, vtype=GRB.CONTINUOUS)
    overtime_used = model.addVar(name="Overtime_Used", lb=0, vtype=GRB.CONTINUOUS)
    overtime_fee_applied = model.addVar(name="Overtime_Fee_Applied", vtype=GRB.BINARY)
    
    # Senior batch fee variable
    senior_batch_fee_applied = model.addVar(name="Senior_Batch_Fee_Applied", vtype=GRB.BINARY)
    
    # Objective function: maximize profit
    objective = (
        profit_A * A + 
        profit_B * B - 
        overtime_penalty_per_hour * overtime_used - 
        overtime_review_fee * overtime_fee_applied - 
        product_A_senior_batch_fee * senior_batch_fee_applied
    )
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Constraint 1: Machine working time (regular + overtime)
    model.addConstr(assembly_time_A * A + assembly_time_B * B == regular_time_used + overtime_used, "Total_Time_Used")
    
    # Constraint 2: Regular time cannot exceed base working time
    model.addConstr(regular_time_used <= machine_working_time_minutes, "Regular_Time_Limit")
    
    # Constraint 3: Overtime limit
    model.addConstr(overtime_used <= max_overtime_hours * 60, "Overtime_Limit")
    
    # Constraint 4: Overtime review fee is applied only if overtime exceeds threshold
    model.addConstr(overtime_used >= (overtime_review_threshold_hours * 60 + 1) * (1 - overtime_fee_applied), "Overtime_Review_Fee_Trigger")
    
    # Constraint 5: Senior batch fee is applied only if A > 100
    model.addConstr(A <= product_A_senior_batch_threshold + (1e6) * (1 - senior_batch_fee_applied), "Senior_Batch_Fee_Trigger_Upper")
    model.addConstr(A >= product_A_senior_batch_threshold + 1 - (1e6) * senior_batch_fee_applied, "Senior_Batch_Fee_Trigger_Lower")
    
    # Constraint 6: Production ratio - at least 2 units of B for every 5 units of A
    # B >= (2/5) * A  =>  2A - 5B <= 0
    model.addConstr(ratio_B * A - ratio_A * B <= 0, "Production_Ratio")
    
    # Optimize the model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal:.1f}")

if __name__ == "__main__":
    main()
