import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv")) as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            if param_name.endswith('_overtime_reduction') or param_name.endswith('_duration'):
                params[param_name] = int(row['Value'].strip())
            else:
                params[param_name] = float(row['Value'].strip())

    # Read precedence relationships
    precedences = []
    with open(os.path.join(data_dir, "table_1.csv")) as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))

    activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    
    # Create model
    model = gp.Model("Project_Cost_Minimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    S = {a: model.addVar(name=f'S_{a}', lb=0) for a in activities}  # Start times
    T = model.addVar(name='T', lb=0)  # Project makespan
    y_E = model.addVar(vtype=GRB.BINARY, name='y_E')  # Binary variable for overtime on E
    
    # Objective function
    work_cost = params['work_cost_per_day']
    machine_cost = params['machine_rental_cost_per_day']
    overtime_cost_E = params['activity_E_overtime_cost']
    followup_review_cost_E = params['activity_E_followup_review_cost']
    
    model.setObjective(
        work_cost * T + 
        machine_cost * (S['B'] + params['activity_B_duration'] - S['A']) +
        overtime_cost_E * y_E +
        followup_review_cost_E * y_E,
        GRB.MINIMIZE
    )
    
    # Precedence constraints
    for pred, succ in precedences:
        model.addConstr(S[succ] >= S[pred] + params[f'activity_{pred}_duration'])
    
    # Makespan constraints
    model.addConstr(T >= S['C'] + params['activity_C_duration'])
    model.addConstr(T >= S['B'] + params['activity_B_duration'])
    
    # Overtime constraint for Activity E
    model.addConstr(S['F'] >= S['E'] + params['activity_E_duration'] - params['activity_E_overtime_reduction'] * y_E)
    
    # Optimize the model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
