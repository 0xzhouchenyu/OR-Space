import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

m = int(params["m"])  # production points
n = int(params["n"])  # demand points
p = int(params["p"])  # marshaling stations

a = {i: params[f"a_{i}"] for i in range(1, m + 1)}  # production capacities
b = {j: params[f"b_{j}"] for j in range(1, n + 1)}  # demands
f_cost = {k: params[f"f_{k}"] for k in range(1, p + 1)}  # fixed costs
q = {k: params[f"q_{k}"] for k in range(1, p + 1)}  # max total transshipment capacity
qexp = {k: params[f"qexp_{k}"] for k in range(1, p + 1)}  # max express transshipment capacity
alpha = {j: params[f"alpha_{j}"] for j in range(1, n + 1)}  # minimum express fraction per demand point
eps = params["eps"]  # minimum strictly positive express flow to activate source indicator
M = params["M"]  # Big-M upper bound on express flow yE_kj per station-demand pair

# Load transportation costs from production to marshaling stations (regular and express)
cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row["i"])
        k = int(row["k"])
        cR_ik[(i, k)] = float(row["cR_ik"])
        cE_ik[(i, k)] = float(row["cE_ik"])

# Load transportation costs from marshaling stations to demand points (regular and express)
cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, "table_2.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row["k"])
        j = int(row["j"])
        cR_kj[(k, j)] = float(row["cR_kj"])
        cE_kj[(k, j)] = float(row["cE_kj"])

# Create the optimization model
model = gp.Model("Transportation_Problem")
model.setParam('OutputFlag', 0)

# Decision variables
# xR_ik: amount shipped via regular service from production point i to marshaling station k
xR = {}
for i in range(1, m + 1):
    for k in range(1, p + 1):
        xR[(i, k)] = model.addVar(name=f"xR_{i}_{k}", lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS)

# xE_ik: amount shipped via express service from production point i to marshaling station k
xE = {}
for i in range(1, m + 1):
    for k in range(1, p + 1):
        xE[(i, k)] = model.addVar(name=f"xE_{i}_{k}", lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS)

# yR_kj: amount shipped via regular service from marshaling station k to demand point j
yR = {}
for k in range(1, p + 1):
    for j in range(1, n + 1):
        yR[(k, j)] = model.addVar(name=f"yR_{k}_{j}", lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS)

# yE_kj: amount shipped via express service from marshaling station k to demand point j
yE = {}
for k in range(1, p + 1):
    for j in range(1, n + 1):
        yE[(k, j)] = model.addVar(name=f"yE_{k}_{j}", lb=0, ub=GRB.INFINITY, vtype=GRB.CONTINUOUS)

# z_k: binary variable indicating whether marshaling station k is used
z = {}
for k in range(1, p + 1):
    z[k] = model.addVar(name=f"z_{k}", vtype=GRB.BINARY)

# w_kj: binary variable indicating if at least one express shipment is sent to demand point j through station k
w = {}
for k in range(1, p + 1):
    for j in range(1, n + 1):
        w[(k, j)] = model.addVar(name=f"w_{k}_{j}", vtype=GRB.BINARY)

# Objective: minimize total transportation cost + fixed costs
obj = (
    gp.quicksum(cR_ik[(i, k)] * xR[(i, k)] for i in range(1, m + 1) for k in range(1, p + 1)) +
    gp.quicksum(cE_ik[(i, k)] * xE[(i, k)] for i in range(1, m + 1) for k in range(1, p + 1)) +
    gp.quicksum(cR_kj[(k, j)] * yR[(k, j)] for k in range(1, p + 1) for j in range(1, n + 1)) +
    gp.quicksum(cE_kj[(k, j)] * yE[(k, j)] for k in range(1, p + 1) for j in range(1, n + 1)) +
    gp.quicksum(f_cost[k] * z[k] for k in range(1, p + 1))
)
model.setObjective(obj, GRB.MINIMIZE)

# Constraints

# 1. Supply constraints: total shipped from production point i <= a_i
for i in range(1, m + 1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for k in range(1, p + 1)) <= a[i],
        name=f"Supply_{i}"
    )

# 2. Demand constraints: total received at demand point j >= b_j
for j in range(1, n + 1):
    model.addConstr(
        gp.quicksum(yR[(k, j)] + yE[(k, j)] for k in range(1, p + 1)) >= b[j],
        name=f"Demand_{j}"
    )

# 3. Flow conservation at marshaling stations
for k in range(1, p + 1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for i in range(1, m + 1)) ==
        gp.quicksum(yR[(k, j)] + yE[(k, j)] for j in range(1, n + 1)),
        name=f"FlowBalance_{k}"
    )

# 4. Total throughput capacity at marshaling stations
for k in range(1, p + 1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for i in range(1, m + 1)) <= q[k] * z[k],
        name=f"TotalCapacity_{k}"
    )

# 5. Express throughput capacity at marshaling stations
for k in range(1, p + 1):
    model.addConstr(
        gp.quicksum(xE[(i, k)] for i in range(1, m + 1)) <= qexp[k],
        name=f"ExpressCapacity_{k}"
    )
    model.addConstr(
        gp.quicksum(yE[(k, j)] for j in range(1, n + 1)) <= qexp[k],
        name=f"ExpressCapacityOut_{k}"
    )

# 6. Linking w_kj with yE_kj using big-M formulation
for k in range(1, p + 1):
    for j in range(1, n + 1):
        model.addConstr(yE[(k, j)] <= M * w[(k, j)], name=f"Link_w_yE_upper_{k}_{j}")
        model.addConstr(yE[(k, j)] >= eps * w[(k, j)], name=f"Link_w_yE_lower_{k}_{j}")

# 7. Diversified express share constraint for demand points with more than one open station
for j in range(1, n + 1):
    expr = gp.LinExpr()
    for k in range(1, p + 1):
        expr += yE[(k, j)]
    
    # Count number of open stations for demand point j
    num_open_stations_expr = gp.LinExpr()
    for k in range(1, p + 1):
        num_open_stations_expr += z[k]
    
    # If there are more than one open station, enforce diversified express share
    model.addConstr(expr >= alpha[j] * gp.quicksum(yR[(k, j)] + yE[(k, j)] for k in range(1, p + 1)) - 
                    (1 - (num_open_stations_expr > 1).getAttr(GRB.Attr.X) * M), 
                    name=f"DiversifiedExpress_{j}")

# Optimize the model
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
