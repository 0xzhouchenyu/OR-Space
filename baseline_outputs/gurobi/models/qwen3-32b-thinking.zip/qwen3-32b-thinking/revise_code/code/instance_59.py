import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load general parameters
    general_params = {}
    filepath = os.path.join(data_dir, "general_parameters.csv")
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            general_params[row["Parameter_Name"]] = float(row["Value"])
    
    # Load table 1.7
    table_1_7 = []
    filepath = os.path.join(data_dir, "table_1_7.csv")
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)  # Skip header
        for row in reader:
            table_1_7.append(row)
    
    return general_params, table_1_7

def main():
    general_params, table_1_7 = load_data()
    
    # Extract relevant parameters from the data
    raw_cost = [2.00, 1.50, 1.00]  # A, B, C
    limits = [2000, 2500, 1200]    # Monthly limits for raw materials A, B, C
    proc_fee = [0.50, 0.40, 0.30]  # Processing fees per brand A, B, C
    sell_price = [3.40, 2.85, 2.25]  # Selling prices per brand A, B, C
    
    setup_costs = [
        general_params.get("SetupCost_A", 0),
        general_params.get("SetupCost_B", 0),
        general_params.get("SetupCost_C", 0)
    ]
    
    shared_wrapper_fee = general_params.get("BrandAB_SharedWrapper_Fee", 0)
    
    # Create model
    model = gp.Model("CandyFactory")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = {}  # x[i][j]: amount of raw material i used in brand j
    y = {}  # y[j]: total production quantity of brand j
    z = {}  # z[j]: binary variable indicating if brand j is produced (1) or not (0)
    
    raw_materials = ['A', 'B', 'C']
    brands = ['A', 'B', 'C']
    
    for i in range(3):  # Raw materials A, B, C
        for j in range(3):  # Brands A, B, C
            x[i, j] = model.addVar(lb=0, name=f"x_{raw_materials[i]}_{brands[j]}")
    
    for j in range(3):  # Brands A, B, C
        y[j] = model.addVar(lb=0, name=f"y_{brands[j]}")
        z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{brands[j]}")
    
    # Update model to integrate new variables
    model.update()
    
    # Total production of each brand equals sum of raw materials used
    for j in range(3):
        model.addConstr(y[j] == gp.quicksum(x[i, j] for i in range(3)), name=f"production_{brands[j]}")
    
    # Raw material supply constraints
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= limits[i], name=f"raw_limit_{raw_materials[i]}")
    
    # Composition constraints
    # Brand A: RM A >= 60%, RM C <= 20%
    model.addConstr(x[0, 0] >= 0.60 * y[0], name="brandA_RM_A_min")
    model.addConstr(x[2, 0] <= 0.20 * y[0], name="brandA_RM_C_max")
    
    # Brand B: RM A >= 15%, RM C <= 60%
    model.addConstr(x[0, 1] >= 0.15 * y[1], name="brandB_RM_A_min")
    model.addConstr(x[2, 1] <= 0.60 * y[1], name="brandB_RM_C_max")
    
    # Brand C: RM C <= 50%
    model.addConstr(x[2, 2] <= 0.50 * y[2], name="brandC_RM_C_max")
    
    # Link production quantity to binary variable (if y > 0, then z = 1)
    for j in range(3):
        model.addConstr(y[j] <= 1e6 * z[j], name=f"link_y_z_{brands[j]}")
    
    # Objective function
    revenue = gp.quicksum(sell_price[j] * y[j] for j in range(3))
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in range(3))
    setup_cost = gp.quicksum(setup_costs[j] * z[j] for j in range(3))
    
    # Shared wrapper coordination cost for producing both A and B
    shared_wrapper_cost = shared_wrapper_fee * z[0] * z[1]
    
    model.setObjective(revenue - material_cost - processing_cost - setup_cost - shared_wrapper_cost, GRB.MAXIMIZE)
    
    # Optimize model
    model.optimize()
    
    # Print results
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
