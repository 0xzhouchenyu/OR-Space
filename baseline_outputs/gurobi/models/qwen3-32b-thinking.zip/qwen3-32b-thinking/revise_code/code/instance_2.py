import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

# Set up file paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

# Load parameters
params = load_parameters(params_file)

a1 = params['a1']  # Annual production of fighter jets in year 1
a2 = params['a2']  # Annual production of fighter jets in year 2
training_capacity = params['training_capacity_per_jet']
dual_use_efficiency = params['dual_use_training_efficiency']
training_intensity_cap = params['training_intensity_cap']
combat_min_year2 = params['combat_jet_min_year2']
combat_weight = params['combat_weight']
training_weight = params['training_weight']

# Create optimization model
model = gp.Model("FighterJetAllocation")

# Decision variables
# x1: number of jets allocated to training-only in year 1
# y1: number of jets allocated to dual-use (training + combat) in year 1
# x2: number of jets allocated to training-only in year 2
# y2: number of jets allocated to dual-use (training + combat) in year 2
# c2: number of jets allocated to combat-only in year 2

x1 = model.addVar(name="x1", vtype=GRB.CONTINUOUS, lb=0)
y1 = model.addVar(name="y1", vtype=GRB.CONTINUOUS, lb=0)
x2 = model.addVar(name="x2", vtype=GRB.CONTINUOUS, lb=0)
y2 = model.addVar(name="y2", vtype=GRB.CONTINUOUS, lb=0)
c2 = model.addVar(name="c2", vtype=GRB.CONTINUOUS, lb=0)

# Total jets available in each year
total_jets_y1 = a1
total_jets_y2 = a1 + a2

# Constraints
# 1. Total jets used in year 1 cannot exceed total production
model.addConstr(x1 + y1 <= total_jets_y1, name="year1_total")

# 2. Total jets used in year 2 cannot exceed total production
model.addConstr(x2 + y2 + c2 <= total_jets_y2, name="year2_total")

# 3. Training intensity cap in year 1 (fraction of fleet in training modes)
model.addConstr((x1 + y1) / total_jets_y1 <= training_intensity_cap, name="year1_training_intensity")

# 4. Training intensity cap in year 2 (fraction of fleet in training modes)
model.addConstr((x2 + y2) / total_jets_y2 <= training_intensity_cap, name="year2_training_intensity")

# 5. Minimum required combat jets in year 2
model.addConstr(c2 + y2 >= combat_min_year2, name="year2_combat_min")

# Objective function
# Maximize weighted sum of combat jets in year 2 and trained pilots over 2 years
# Trained pilots = training_capacity * (x1 + x2 + dual_use_efficiency * y1 + dual_use_efficiency * y2)
# Combat jets in year 2 = c2 + y2
objective = (
    combat_weight * (c2 + y2) +
    training_weight * training_capacity * (x1 + x2 + dual_use_efficiency * y1 + dual_use_efficiency * y2)
)

model.setObjective(objective, GRB.MAXIMIZE)

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
