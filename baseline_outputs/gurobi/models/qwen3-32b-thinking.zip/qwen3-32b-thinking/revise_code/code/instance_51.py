import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Set up file paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
demand_filepath = os.path.join(data_dir, "table_1.csv")
params_filepath = os.path.join(data_dir, "general_parameters.csv")

# Load demand data
def load_demand(filepath):
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand

# Load parameters
def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            value = row['Value']
            if ',' in value or ';' in value:
                # Handle list values
                separator = ';' if ';' in value else ','
                params[param_name] = [int(x.strip()) for x in value.split(separator)]
            else:
                try:
                    params[param_name] = int(value)
                except ValueError:
                    try:
                        params[param_name] = float(value)
                    except ValueError:
                        params[param_name] = value
    return params

# Load data
demand = load_demand(demand_filepath)
params = load_parameters(params_filepath)

# Extract parameters
shift_start_times = params['shift_start_times']  # Not used directly but for context
shift_duration = int(params['shift_duration'])  # 8 hours
regular_pay = float(params['regular_nurse_pay'])  # 10 yuan/hour
contract_pay = float(params['contract_nurse_pay'])  # 15 yuan/hour
outsourced_regular_start_index = int(params['outsourced_regular_start_index'])  # 2 (10:00 shift)
banned_contract_start_index = int(params['banned_contract_start_index'])  # 5 (22:00 shift)
max_total_contract_starts = int(params['max_total_contract_starts'])  # 20
min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])  # 8
daytime_period_indices = params['daytime_period_indices']  # [1, 2, 3, 4]

num_periods = len(demand)  # 6 periods, each 4 hours
periods_per_shift = shift_duration // 4  # 2 periods per shift

# Create model
model = gp.Model("NurseScheduling")

# Decision variables: regular and contract nurses starting at each shift
x = model.addVars(num_periods, vtype=GRB.INTEGER, name="x", lb=0)  # Regular nurses
y = model.addVars(num_periods, vtype=GRB.INTEGER, name="y", lb=0)  # Contract nurses

# Objective: minimize total cost
model.setObjective(
    gp.quicksum((regular_pay * shift_duration) * x[j] + (contract_pay * shift_duration) * y[j] for j in range(num_periods)),
    GRB.MINIMIZE
)

# Coverage constraints: for each time period i, sum of nurses from shifts that cover period i >= demand[i]
for i in range(num_periods):
    covering_shifts = []
    for j in range(num_periods):
        # Shift j covers periods j and (j+1) % num_periods
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i], f"Demand_period_{i}")

# Constraint: Contract nurses cannot start the banned shift (index 5)
model.addConstr(y[banned_contract_start_index] == 0, "Contract_Banned_Shift")

# Constraint: Regular nurses cannot start the outsourced shift (index 2)
model.addConstr(x[outsourced_regular_start_index] == 0, "Regular_Outsourced_Shift")

# Constraint: Total contract starts are capped
model.addConstr(gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts, "Max_Contract_Starts")

# Constraint: Minimum regular coverage during daytime periods
for i in daytime_period_indices:
    covering_shifts = []
    for j in range(num_periods):
        # Shift j covers periods j and (j+1) % num_periods
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(gp.quicksum(x[j] for j in covering_shifts) >= min_regular_daytime_coverage, f"Min_Regular_Coverage_{i}")

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
