import os
import csv

import gurobipy as gp
from gurobipy import GRB


def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    return params


# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
min_A = params['min_raw_material_A']
min_B = params['min_raw_material_B']
min_C = params['min_raw_material_C']

cap_A_a = params['warehouse_A_truck_capacity_A']
cap_A_b = params['warehouse_A_truck_capacity_B']
cap_A_c = params['warehouse_A_truck_capacity_C']
cost_A = params['warehouse_A_truck_cost']
fixed_cost_A = params['warehouse_A_fixed_cost']

cap_B_a = params['warehouse_B_truck_capacity_A']
cap_B_b = params['warehouse_B_truck_capacity_B']
cap_B_c = params['warehouse_B_truck_capacity_C']
cost_B = params['warehouse_B_truck_cost']
fixed_cost_B = params['warehouse_B_fixed_cost']
overflow_threshold_B = params['warehouse_B_overflow_threshold_trucks']
overflow_coordination_cost_B = params['warehouse_B_overflow_coordination_cost']
dual_reconciliation_fee = params['dual_warehouse_reconciliation_fee']

# Create the optimization model
model = gp.Model("MinFreightCostWithConstraints")

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_A")  # Number of trucks from warehouse A
y = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_B")  # Number of trucks from warehouse B

# Binary variables for fixed costs and overflow coordination
use_A = model.addVar(vtype=GRB.BINARY, name="use_A")
use_B = model.addVar(vtype=GRB.BINARY, name="use_B")
overflow_B = model.addVar(vtype=GRB.BINARY, name="overflow_B")
dual_use = model.addVar(vtype=GRB.BINARY, name="dual_use")

# Objective: minimize total cost (freight + fixed + overflow + dual reconciliation)
model.setObjective(
    cost_A * x + cost_B * y + 
    fixed_cost_A * use_A + fixed_cost_B * use_B +
    overflow_coordination_cost_B * overflow_B +
    dual_reconciliation_fee * dual_use,
    GRB.MINIMIZE
)

# Constraints for raw material requirements
model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# Fixed cost constraints - if any trucks are dispatched, the fixed cost applies
model.addConstr(x >= 1e-6 * use_A)  # If x > 0, then use_A = 1
model.addConstr(x <= 1000 * use_A)  # Upper bound to ensure use_A = 1 when x > 0
model.addConstr(y >= 1e-6 * use_B)
model.addConstr(y <= 1000 * use_B)

# Overflow constraint for warehouse B
model.addConstr(y <= overflow_threshold_B + 1000 * overflow_B)  # If y > threshold, then overflow_B = 1
model.addConstr(y >= overflow_threshold_B + 1 - 1000 * (1 - overflow_B))  # Ensure overflow_B = 1 when y > threshold

# Dual use constraint - if both warehouses are used, apply the reconciliation fee
model.addConstr(dual_use >= use_A + use_B - 1)  # If both use_A and use_B are 1, then dual_use = 1
model.addConstr(dual_use <= use_A)
model.addConstr(dual_use <= use_B)

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
