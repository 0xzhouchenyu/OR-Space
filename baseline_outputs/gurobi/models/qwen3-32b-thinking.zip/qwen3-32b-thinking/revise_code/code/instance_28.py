import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

initial_fund = params["initial_fund"]  # 300000
annual_rate = params["annual_profit_rate"] / 100  # 0.20
inv_limit_y1 = params["investment_limit_year1"]  # 150000
return_rate_y1y2 = params["return_rate_year1_to_year2"] / 100  # 1.50
inv_limit_y2 = params["investment_limit_year2"]  # 200000
return_rate_y2y3 = params["return_rate_year2_to_year3"] / 100  # 1.60
inv_limit_y3 = params["investment_limit_year3"]  # 100000
profit_rate_y3 = params["profit_rate_year3"] / 100  # 0.40
fee_y1 = params["fee_year1"]  # 10000
fee_y2 = params["fee_year2"]  # 12000
fee_y3 = params["fee_year3"]  # 5000

# Create model
model = gp.Model("Investment_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
a1 = model.addVar(name="a1", lb=0)  # Annual investment at beginning of year 1
a2 = model.addVar(name="a2", lb=0)  # Annual investment at beginning of year 2
a3 = model.addVar(name="a3", lb=0)  # Annual investment at beginning of year 3
b1 = model.addVar(name="b1", lb=0, ub=inv_limit_y1)  # 2-year investment at beginning of year 1
c2 = model.addVar(name="c2", lb=0, ub=inv_limit_y2)  # 2-year investment at beginning of year 2
d3 = model.addVar(name="d3", lb=0, ub=inv_limit_y3)  # Special 1-year investment at beginning of year 3

# Binary variables for fixed fees
use_b1 = model.addVar(vtype=GRB.BINARY, name="use_b1")
use_c2 = model.addVar(vtype=GRB.BINARY, name="use_c2")
use_d3 = model.addVar(vtype=GRB.BINARY, name="use_d3")

# Budget constraint at beginning of Year 1
model.addConstr(a1 + b1 <= initial_fund, "Year1_budget")

# Budget constraint at beginning of Year 2
model.addConstr(
    a2 + c2 <= (initial_fund - a1 - b1) + a1 * (1 + annual_rate),
    "Year2_budget"
)

# Budget constraint at beginning of Year 3
model.addConstr(
    a3 + d3 <= (
        (initial_fund - a1 - b1) 
        + a1 * (1 + annual_rate) 
        - a2 - c2 
        + a2 * (1 + annual_rate) 
        + b1 * return_rate_y1y2
    ),
    "Year3_budget"
)

# Link binary variables to special investments
model.addConstr(b1 <= inv_limit_y1 * use_b1, "Link_b1")
model.addConstr(c2 <= inv_limit_y2 * use_c2, "Link_c2")
model.addConstr(d3 <= inv_limit_y3 * use_d3, "Link_d3")

# Objective: total funds at end of year 3 minus management fees
total_end = (
    (initial_fund - a1 - b1) 
    + a1 * (1 + annual_rate) 
    - a2 - c2 
    + a2 * (1 + annual_rate) 
    + b1 * return_rate_y1y2 
    - a3 - d3 
    + a3 * (1 + annual_rate) 
    + c2 * return_rate_y2y3 
    + d3 * (1 + profit_rate_y3)
)

objective = total_end - (use_b1 * fee_y1 + use_c2 * fee_y2 + use_d3 * fee_y3)
model.setObjective(objective, GRB.MAXIMIZE)

# Optimize the model
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
