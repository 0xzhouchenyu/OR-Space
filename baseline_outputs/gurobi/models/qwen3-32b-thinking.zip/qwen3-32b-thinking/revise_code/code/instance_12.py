import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load container data
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    # Load general parameters
    fixed_setup_cost = None
    energy_cost_per_kwh = None
    max_total_energy_kwh = None
    eco_capacity_share = None
    eco_overhead_cost = None
    regular_energy_intensity = None
    eco_energy_intensity = None
    
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'].strip() == 'fixed_setup_cost':
                fixed_setup_cost = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'energy_cost_per_kwh':
                energy_cost_per_kwh = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'max_total_energy_kwh':
                max_total_energy_kwh = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'eco_capacity_share':
                eco_capacity_share = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'eco_overhead_cost':
                eco_overhead_cost = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'regular_energy_intensity_kwh_per_unit':
                regular_energy_intensity = float(row['Value'])
            elif row['Parameter_Name'].strip() == 'eco_energy_intensity_kwh_per_unit':
                eco_energy_intensity = float(row['Value'])

    n = len(containers)

    # Create the model
    model = gp.Model("PlasticContainers")
    model.setParam('OutputFlag', 0)  # Suppress output

    # Binary setup variables for each mode (Regular and Eco)
    y_regular = {i: model.addVar(vtype=GRB.BINARY, name=f"y_regular_{i}") for i in range(n)}
    y_eco = {i: model.addVar(vtype=GRB.BINARY, name=f"y_eco_{i}") for i in range(n)}

    # Production quantities for each container type i to fulfill demand of type j in Regular and Eco modes
    x_regular = {}
    x_eco = {}
    
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x_regular[i, j] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_regular_{i}_{j}")
                x_eco[i, j] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_eco_{i}_{j}")

    # Objective function: minimize total cost
    variable_cost = sum(
        containers[i]['cost'] * x_regular[i, j] + 
        containers[i]['cost'] * x_eco[i, j]
        for (i, j) in x_regular
    )
    
    fixed_setup_cost_regular = sum(
        fixed_setup_cost * y_regular[i] for i in range(n)
    )
    
    fixed_setup_cost_eco = sum(
        eco_overhead_cost * y_eco[i] for i in range(n)
    )
    
    energy_cost = sum(
        regular_energy_intensity * x_regular[i, j] * energy_cost_per_kwh +
        eco_energy_intensity * x_eco[i, j] * energy_cost_per_kwh
        for (i, j) in x_regular
    )

    model.setObjective(variable_cost + fixed_setup_cost_regular + fixed_setup_cost_eco + energy_cost, GRB.MINIMIZE)

    # Demand constraints: for each type j, total supplied >= demand[j]
    for j in range(n):
        total_supplied = sum(x_regular[i, j] + x_eco[i, j] for i in range(n) if (i, j) in x_regular)
        model.addConstr(total_supplied >= containers[j]['demand'], f"demand_{j}")

    # Linking constraints: if we produce in Regular mode, y_regular[i] must be 1
    M = sum(c['demand'] for c in containers)
    for i in range(n):
        total_produced_regular_i = sum(x_regular[i, j] for j in range(n) if (i, j) in x_regular)
        model.addConstr(total_produced_regular_i <= M * y_regular[i], f"setup_regular_{i}")

    # If we produce in Eco mode, y_eco[i] must be 1
    for i in range(n):
        total_produced_eco_i = sum(x_eco[i, j] for j in range(n) if (i, j) in x_regular)
        model.addConstr(total_produced_eco_i <= M * y_eco[i], f"setup_eco_{i}")

    # Eco capacity constraint: Eco production cannot exceed eco_capacity_share of total production
    for i in range(n):
        total_produced_regular_i = sum(x_regular[i, j] for j in range(n) if (i, j) in x_regular)
        total_produced_eco_i = sum(x_eco[i, j] for j in range(n) if (i, j) in x_regular)
        model.addConstr(total_produced_eco_i <= eco_capacity_share * (total_produced_regular_i + total_produced_eco_i), f"eco_capacity_{i}")

    # Total energy consumption constraint
    total_energy_consumption = sum(
        regular_energy_intensity * x_regular[i, j] +
        eco_energy_intensity * x_eco[i, j]
        for (i, j) in x_regular
    )
    model.addConstr(total_energy_consumption <= max_total_energy_kwh, "total_energy")

    # Optimize the model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
