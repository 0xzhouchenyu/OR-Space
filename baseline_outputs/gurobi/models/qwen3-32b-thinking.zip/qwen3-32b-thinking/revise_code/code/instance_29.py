import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    demand_df = pd.read_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_4_3.csv"))
    supply_df = pd.read_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_4_4.csv"))
    params_df = pd.read_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv"))
    
    # Parse parameters
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])
    
    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem
        
    # Parse supply
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = float(row['Number_of_People'])
        suit = [int(x) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }
        
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]
    
    # Create model
    model = gp.Model("PersonnelAssignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of people of type i assigned to city j with specialty k
    x = model.addVars(types, cities, specs, vtype=GRB.INTEGER, name="x", lb=0)
    
    # Priority 1: Meet all demands
    for city in cities:
        for spec in specs:
            model.addConstr(gp.quicksum(x[i, city, spec] for i in types) >= demand[(city, spec)], f"Demand_{city}_{spec}")
            
    # Priority 2: At least the target number of people get their preferred specialty
    pref_spec_count = gp.LinExpr()
    for i in types:
        for city in cities:
            pref_spec_count += x[i, city, supply[i]['pref_spec']]
    model.addConstr(pref_spec_count >= p2_target, "Priority2")
    
    # Suitable specialty constraints
    for i in types:
        for city in cities:
            for spec in specs:
                if spec not in supply[i]['suit']:
                    model.addConstr(x[i, city, spec] == 0, f"Suitability_{i}_{city}_{spec}")
                    
    # Total people per type constraint
    for i in types:
        model.addConstr(gp.quicksum(x[i, city, spec] for city in cities for spec in specs) <= supply[i]['num'], f"Supply_{i}")
    
    # Objective: Maximize number of people who get both preferred specialty and preferred city
    dual_match = gp.LinExpr()
    for i in types:
        pref_city_i = supply[i]['pref_city']
        pref_spec_i = supply[i]['pref_spec']
        dual_match += x[i, pref_city_i, pref_spec_i]
    model.setObjective(dual_match, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    # Output result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    solve()
