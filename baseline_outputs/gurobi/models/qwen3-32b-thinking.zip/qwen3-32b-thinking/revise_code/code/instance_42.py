import os
import gurobipy as gp
from gurobipy import GRB
import csv

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    # Extract parameters
    a = params['a']  # Time per furnace for method 1
    b = params['b']  # Time per furnace for method 2
    k = params['k']  # Steel production per batch
    d = params['d']  # Minimum steel production requirement
    
    c_offpeak = params['c_offpeak']  # Max off-peak time per furnace
    c_peak = params['c_peak']  # Max peak time per furnace
    cap_offpeak = params['cap_offpeak']  # Plant-wide max off-peak time
    cap_peak = params['cap_peak']  # Plant-wide max peak time
    
    m_offpeak = params['m_offpeak']  # Fuel cost for method 1 (off-peak)
    n_offpeak = params['n_offpeak']  # Fuel cost for method 2 (off-peak)
    m_peak = params['m_peak']  # Fuel cost for method 1 (peak)
    n_peak = params['n_peak']  # Fuel cost for method 2 (peak)
    
    f_offpeak = params['f_offpeak']  # Fixed activation cost (off-peak)
    f_peak = params['f_peak']  # Fixed activation cost (peak)
    
    offpeak_cooldown_batch_threshold = params['offpeak_cooldown_batch_threshold']
    offpeak_cooldown_fee = params['offpeak_cooldown_fee']
    
    # Create model
    model = gp.Model("SteelFurnaceRevised")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: x_ijt = number of times furnace i uses method j in period t
    # i = 1,2 (furnaces), j = 1,2 (methods), t = offpeak, peak (periods)
    x1_offpeak = model.addVar(name="x1_offpeak", lb=0, vtype=GRB.CONTINUOUS)
    x1_peak = model.addVar(name="x1_peak", lb=0, vtype=GRB.CONTINUOUS)
    x2_offpeak = model.addVar(name="x2_offpeak", lb=0, vtype=GRB.CONTINUOUS)
    x2_peak = model.addVar(name="x2_peak", lb=0, vtype=GRB.CONTINUOUS)
    x3_offpeak = model.addVar(name="x3_offpeak", lb=0, vtype=GRB.CONTINUOUS)
    x3_peak = model.addVar(name="x3_peak", lb=0, vtype=GRB.CONTINUOUS)
    x4_offpeak = model.addVar(name="x4_offpeak", lb=0, vtype=GRB.CONTINUOUS)
    x4_peak = model.addVar(name="x4_peak", lb=0, vtype=GRB.CONTINUOUS)
    
    # Binary variables to indicate if a furnace is used in off-peak or peak
    y1_offpeak = model.addVar(name="y1_offpeak", vtype=GRB.BINARY)
    y1_peak = model.addVar(name="y1_peak", vtype=GRB.BINARY)
    y2_offpeak = model.addVar(name="y2_offpeak", vtype=GRB.BINARY)
    y2_peak = model.addVar(name="y2_peak", vtype=GRB.BINARY)
    
    # Binary variables to indicate if cooldown fee applies to each furnace
    z1 = model.addVar(name="z1", vtype=GRB.BINARY)
    z2 = model.addVar(name="z2", vtype=GRB.BINARY)
    
    # Objective function: minimize total fuel and fixed costs + cooldown fees
    obj = (
        # Fuel costs
        m_offpeak * (x1_offpeak + x3_offpeak) +
        n_offpeak * (x2_offpeak + x4_offpeak) +
        m_peak * (x1_peak + x3_peak) +
        n_peak * (x2_peak + x4_peak) +
        
        # Fixed activation costs
        f_offpeak * (y1_offpeak + y2_offpeak) +
        f_peak * (y1_peak + y2_peak) +
        
        # Cooldown fees
        offpeak_cooldown_fee * (z1 + z2)
    )
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    
    # Furnace 1 time constraints
    model.addConstr(a * x1_offpeak + b * x2_offpeak <= c_offpeak, "Furnace1_Offpeak_Time")
    model.addConstr(a * x1_peak + b * x2_peak <= c_peak, "Furnace1_Peak_Time")
    
    # Furnace 2 time constraints
    model.addConstr(a * x3_offpeak + b * x4_offpeak <= c_offpeak, "Furnace2_Offpeak_Time")
    model.addConstr(a * x3_peak + b * x4_peak <= c_peak, "Furnace2_Peak_Time")
    
    # Plant-wide time constraints
    model.addConstr(
        a * (x1_offpeak + x3_offpeak) + b * (x2_offpeak + x4_offpeak) <= cap_offpeak,
        "Plant_Offpeak_Time"
    )
    model.addConstr(
        a * (x1_peak + x3_peak) + b * (x2_peak + x4_peak) <= cap_peak,
        "Plant_Peak_Time"
    )
    
    # Minimum production requirement
    model.addConstr(
        k * (x1_offpeak + x2_offpeak + x3_offpeak + x4_offpeak + 
             x1_peak + x2_peak + x3_peak + x4_peak) >= d,
        "MinProduction"
    )
    
    # Link binary variables to usage
    M = 1000  # Big-M value for constraints
    
    # Furnace 1 off-peak usage
    model.addConstr(x1_offpeak + x2_offpeak <= M * y1_offpeak, "Furnace1_Offpeak_Usage")
    model.addConstr(x1_offpeak + x2_offpeak >= 0.001 * y1_offpeak, "Furnace1_Offpeak_Usage_Lower")
    
    # Furnace 1 peak usage
    model.addConstr(x1_peak + x2_peak <= M * y1_peak, "Furnace1_Peak_Usage")
    model.addConstr(x1_peak + x2_peak >= 0.001 * y1_peak, "Furnace1_Peak_Usage_Lower")
    
    # Furnace 2 off-peak usage
    model.addConstr(x3_offpeak + x4_offpeak <= M * y2_offpeak, "Furnace2_Offpeak_Usage")
    model.addConstr(x3_offpeak + x4_offpeak >= 0.001 * y2_offpeak, "Furnace2_Offpeak_Usage_Lower")
    
    # Furnace 2 peak usage
    model.addConstr(x3_peak + x4_peak <= M * y2_peak, "Furnace2_Peak_Usage")
    model.addConstr(x3_peak + x4_peak >= 0.001 * y2_peak, "Furnace2_Peak_Usage_Lower")
    
    # Cooldown rule for off-peak batches
    # For furnace 1: if off-peak batches > threshold, apply cooldown fee
    model.addConstr((x1_offpeak + x2_offpeak) <= offpeak_cooldown_batch_threshold + M * (1 - z1), "Furnace1_Cooldown_UnderThreshold")
    model.addConstr((x1_offpeak + x2_offpeak) >= offpeak_cooldown_batch_threshold + 0.001 * z1, "Furnace1_Cooldown_OverThreshold")
    
    # For furnace 2: if off-peak batches > threshold, apply cooldown fee
    model.addConstr((x3_offpeak + x4_offpeak) <= offpeak_cooldown_batch_threshold + M * (1 - z2), "Furnace2_Cooldown_UnderThreshold")
    model.addConstr((x3_offpeak + x4_offpeak) >= offpeak_cooldown_batch_threshold + 0.001 * z2, "Furnace2_Cooldown_OverThreshold")
    
    # Optimize the model
    model.optimize()
    
    # Output the result
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
