import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, "data", "table_1.csv")
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    machine_avail = params['machine_time_available']  # hours
    craftsman_regular = params['craftsman_regular_time_available']  # regular hours
    craftsman_overtime = params['craftsman_overtime_time_available']  # overtime hours
    machine_cost = params['machine_time_cost']  # GBP per hour
    craftsman_cost = params['craftsman_time_cost']  # GBP per hour (regular)
    overtime_cost = params['craftsman_overtime_cost']  # GBP per hour (overtime)
    rev_X = params['revenue_product_X']  # GBP per batch
    rev_Y = params['revenue_product_Y']  # GBP per batch
    min_X = params['min_batches_product_X']  # batches
    y_qa_threshold = params['product_Y_QA_threshold']  # batches
    y_qa_fee = params['product_Y_QA_fee']  # GBP
    
    # Create Gurobi model
    model = gp.Model("Production_Planning_Rev")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    X = model.addVar(name="X", lb=0)  # Batches of product X
    Y = model.addVar(name="Y", lb=0)  # Batches of product Y
    
    # Craftsman time split into regular and overtime
    craftsman_regular_used = model.addVar(name="Craftsman_Regular_Used", lb=0)
    craftsman_overtime_used = model.addVar(name="Craftsman_Overtime_Used", lb=0)
    
    # QA fee variable (binary indicator if Y > threshold)
    y_exceeds_threshold = model.addVar(vtype=GRB.BINARY, name="Y_Exceeds_Threshold")
    
    # Total machine time used (in hours)
    machine_hours_used = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0
    
    # Total craftsman time used (in hours)
    craftsman_hours_used = (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0
    
    # Objective: maximize profit = revenue - costs - QA fee
    profit = rev_X * X + rev_Y * Y - machine_cost * machine_hours_used \
             - craftsman_cost * craftsman_regular_used - overtime_cost * craftsman_overtime_used \
             - y_qa_fee * y_exceeds_threshold
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Constraints
    # Machine time constraint
    model.addConstr(machine_hours_used <= machine_avail, "Machine_Time_Constraint")
    
    # Craftsman time constraints
    model.addConstr(craftsman_regular_used + craftsman_overtime_used == craftsman_hours_used, 
                    "Craftsman_Total_Time")
    model.addConstr(craftsman_regular_used <= craftsman_regular, "Craftsman_Regular_Time_Limit")
    model.addConstr(craftsman_overtime_used <= craftsman_overtime, "Craftsman_Overtime_Time_Limit")
    
    # Minimum production of X
    model.addConstr(X >= min_X, "Min_Production_X")
    
    # QA fee constraint: if Y > threshold, then y_exceeds_threshold = 1
    model.addConstr(Y <= y_qa_threshold + (1 - y_exceeds_threshold) * 1e5, "QA_Fee_Upper_Bound")
    model.addConstr(Y >= y_qa_threshold + y_exceeds_threshold * 1e-3, "QA_Fee_Lower_Bound")
    
    # Optimize the model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal:.2f}")

if __name__ == "__main__":
    main()
