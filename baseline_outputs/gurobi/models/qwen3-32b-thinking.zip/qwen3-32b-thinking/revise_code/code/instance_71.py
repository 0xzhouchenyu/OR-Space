import os
import csv
import gurobipy as gp
from gurobipy import GRB

def read_table_1():
    base = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base, 'data')
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    n = len(rows)
    d = []
    c = []
    for row in rows:
        d.append([
            float(row[f'Transportation_volume_to_Location_{j+1}']) 
            for j in range(n)
        ])
        c.append([
            float(row[f'Transportation_cost_to_Location_{j+1}']) 
            for j in range(n)
        ])
    
    return n, d, c

def read_general_parameters():
    base = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base, 'data')
    
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {row['Parameter_Name']: float(row['Value']) for row in reader}
    
    return params

def solve():
    # Read input data
    n, d, c = read_table_1()
    params = read_general_parameters()
    premium_cost_multiplier = params['premium_cost_multiplier']
    min_premium_share = params['min_premium_share']
    
    # Calculate outbound volumes for each factory
    outbound_volume = [sum(d[i][j] for j in range(n)) for i in range(n)]
    
    # Calculate standard unit costs for each factory-location pair
    c_std = [[0.0]*n for _ in range(n)]
    for i in range(n):
        for p in range(n):
            if outbound_volume[i] > 0:
                c_std[i][p] = sum(d[i][j] * c[p][j] for j in range(n)) / outbound_volume[i]
            else:
                c_std[i][p] = 0.0
    
    # Create Gurobi model
    model = gp.Model("FactoryAssignmentWithServiceChoice")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")  # x[i,p] = 1 if factory i is assigned to location p
    y = model.addVars(n, n, vtype=GRB.BINARY, name="y")  # y[i,p] = 1 if premium service is selected for factory i at location p
    v_std = model.addVars(n, n, lb=0.0, ub=gp.GRB.INFINITY, name="v_std")  # Standard volume handled for factory i at location p
    v_prem = model.addVars(n, n, lb=0.0, ub=gp.GRB.INFINITY, name="v_prem")  # Premium volume handled for factory i at location p
    
    # Objective: minimize total cost (transportation + handling)
    obj = 0
    for i in range(n):
        for p in range(n):
            obj += v_std[i, p] * c_std[i][p] + v_prem[i, p] * c_std[i][p] * premium_cost_multiplier
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    
    # Each factory must be assigned to exactly one location
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, p] for p in range(n)) == 1, f"AssignFactory_{i}")
    
    # No location should host more than one factory
    for p in range(n):
        model.addConstr(gp.quicksum(x[i, p] for i in range(n)) <= 1, f"UniqueLocation_{p}")
    
    # If a factory is not assigned to a location, no volume can be handled there
    for i in range(n):
        for p in range(n):
            model.addConstr(v_std[i, p] <= x[i, p] * outbound_volume[i], f"VStdUB_{i}_{p}")
            model.addConstr(v_prem[i, p] <= x[i, p] * outbound_volume[i], f"VPremUB_{i}_{p}")
    
    # Total volume from a factory to its location equals its outbound volume
    for i in range(n):
        model.addConstr(gp.quicksum(v_std[i, p] + v_prem[i, p] for p in range(n)) == outbound_volume[i], f"OutboundVolume_{i}")
    
    # Premium mode implies handled volume share ≥ min_premium_share
    for i in range(n):
        for p in range(n):
            model.addConstr(v_prem[i, p] >= min_premium_share * outbound_volume[i] * y[i, p], f"MinPremShare_{i}_{p}")
            model.addConstr(y[i, p] <= x[i, p], f"YImplyX_{i}_{p}")
    
    # Optimize the model
    model.optimize()
    
    # Print the optimal objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
