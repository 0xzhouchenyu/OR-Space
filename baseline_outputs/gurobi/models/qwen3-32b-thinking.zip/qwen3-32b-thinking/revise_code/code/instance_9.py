import os
import gurobipy as gp
from gurobipy import GRB

def load_toy_data(filepath):
    toys = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                'type': row['Toy_Type'].strip(),
                'profit': float(row['Profit_Per_Unit']),
                'wood': float(row['Wood_Required_Per_Unit']),
                'steel': float(row['Steel_Required_Per_Unit']),
            })
    return toys

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
toys = load_toy_data(os.path.join(data_dir, "table_1.csv"))
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

available_wood = params['available_wood']
available_steel = params['available_steel']
profit_premium_bonus = params['profit_premium_bonus']
premium_steel_factor = params['premium_steel_factor']
premium_shift_capacity = params['premium_shift_capacity']

# Create model
model = gp.Model("HausToys_Rev")

# Decision variables - quantities on standard and premium shifts
x_std = {}
x_prem = {}
for t in toys:
    x_std[t['type']] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_std_{t['type']}", lb=0)
    x_prem[t['type']] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_prem_{t['type']}", lb=0)

# Binary variables - whether to manufacture each toy type
y = {}
for t in toys:
    y[t['type']] = model.addVar(vtype=GRB.BINARY, name=f"y_{t['type']}")

# Linking constraints: if a toy is produced (on either shift), y_i = 1
for t in toys:
    model.addConstr(x_std[t['type']] + x_prem[t['type']] <= 1000 * y[t['type']], f"Link_{t['type']}")

# Objective: maximize profit
profit_expr = gp.LinExpr()
for t in toys:
    profit_expr += t['profit'] * (x_std[t['type']] + x_prem[t['type']])
    profit_expr += profit_premium_bonus * x_prem[t['type']]
model.setObjective(profit_expr, GRB.MAXIMIZE)

# Resource constraints
wood_expr = gp.LinExpr()
steel_expr = gp.LinExpr()
for t in toys:
    wood_expr += t['wood'] * (x_std[t['type']] + x_prem[t['type']])
    steel_expr += t['steel'] * x_std[t['type']] + (t['steel'] * premium_steel_factor) * x_prem[t['type']]
model.addConstr(wood_expr <= available_wood, "Wood_Constraint")
model.addConstr(steel_expr <= available_steel, "Steel_Constraint")

# Premium shift capacity constraint
prem_expr = gp.LinExpr()
for t in toys:
    prem_expr += x_prem[t['type']]
model.addConstr(prem_expr <= premium_shift_capacity, "Premium_Shift_Capacity")

# Truck-train exclusion: if trucks manufactured (any shift), no trains (any shift)
model.addConstr(y['truck'] + y['train'] <= 1, "Truck_Train_Exclusion")

# Boat-airplane dependency: if boats manufactured (any shift), airplanes must be too
model.addConstr(y['boat'] <= y['airplane'], "Boat_Airplane_Dependency")

# Boat-train limit: total boats produced cannot exceed total trains produced
model.addConstr((x_std['boat'] + x_prem['boat']) <= (x_std['train'] + x_prem['train']), "Boat_Train_Limit")

# Optimize
model.setParam('OutputFlag', 0)
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
