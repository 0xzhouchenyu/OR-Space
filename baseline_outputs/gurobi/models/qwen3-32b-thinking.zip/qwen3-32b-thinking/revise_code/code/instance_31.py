import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Parse table_1.csv for processing times, capacities, and costs
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    proc_time = {}  # (equipment, product) -> hours per unit
    capacity = {}   # equipment -> available hours
    cost_rate = {}  # equipment -> cost per machine hour
    price = {}      # product -> unit price
    raw_cost = {}   # product -> raw material cost
    
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            if equip == 'Raw_Material_Cost':
                raw_cost['I'] = float(row['Product_I'])
                raw_cost['II'] = float(row['Product_II'])
                raw_cost['III'] = float(row['Product_III'])
            elif equip == 'Unit_Price':
                price['I'] = float(row['Product_I'])
                price['II'] = float(row['Product_II'])
                price['III'] = float(row['Product_III'])
            else:
                for prod, col in [('I', 'Product_I'), ('II', 'Product_II'), ('III', 'Product_III')]:
                    val = row[col].strip()
                    if val != '-':
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row['Effective_Machine_Hours'])
                cost_rate[equip] = float(row['Processing_Cost_per_Machine_Hour'])
    
    # Parse setup_costs.csv
    setup_cost = {}
    with open(os.path.join(data_dir, "setup_costs.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            setup_cost[equip] = float(row['Fixed_Setup_Cost'])
    
    # Parse general_parameters.csv for equipment assignments and calibration fee
    stage_A_equip = {'I': ['A1', 'A2'], 'II': ['A1', 'A2'], 'III': ['A2']}
    stage_B_equip = {'I': ['B1', 'B2', 'B3'], 'II': ['B1'], 'III': ['B2']}
    A2_B2_joint_calibration_fee = 100
    
    # Create Gurobi model
    model = gp.Model("Factory_Production")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: x[(equip, prod)] = units of product processed on equipment
    x = {}
    y = {}  # Binary variable indicating whether equipment is used
    for prod in ['I', 'II', 'III']:
        for equip in stage_A_equip[prod]:
            x[(equip, prod)] = model.addVar(name=f"x_{equip}_{prod}", lb=0)
            y[(equip, prod)] = model.addVar(vtype=GRB.BINARY, name=f"y_{equip}_{prod}")
        for equip in stage_B_equip[prod]:
            x[(equip, prod)] = model.addVar(name=f"x_{equip}_{prod}", lb=0)
            y[(equip, prod)] = model.addVar(vtype=GRB.BINARY, name=f"y_{equip}_{prod}")
    
    # Total production of each product (defined by stage A flow = stage B flow)
    total = {}
    for prod in ['I', 'II', 'III']:
        total[prod] = sum(x[(e, prod)] for e in stage_A_equip[prod])
        # Flow conservation: stage A total == stage B total
        model.addConstr(sum(x[(e, prod)] for e in stage_A_equip[prod]) == sum(x[(e, prod)] for e in stage_B_equip[prod]))
    
    # Capacity constraints
    for equip in ['A1', 'A2', 'B1', 'B2', 'B3']:
        relevant = [(equip, prod) for prod in ['I', 'II', 'III'] if (equip, prod) in x]
        if relevant:
            model.addConstr(gp.quicksum(proc_time[(equip, prod)] * x[(equip, prod)] for equip2, prod in relevant) <= capacity[equip])
    
    # Link binary variables to production quantities
    for (equip, prod) in x:
        model.addConstr(x[(equip, prod)] <= 1000000 * y[(equip, prod)])  # Big-M constraint
    
    # Objective: profit = revenue - raw material - processing cost - setup cost - joint calibration fee
    revenue = sum(price[p] * total[p] for p in ['I', 'II', 'III'])
    raw_mat = sum(raw_cost[p] * total[p] for p in ['I', 'II', 'III'])
    proc_cost = sum(cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x)
    setup_cost_total = sum(setup_cost[e] * y[(e, p)] for (e, p) in y)
    
    # Joint calibration fee between A2 and B2
    a2_active = sum(y[('A2', p)] for p in ['I', 'II', 'III'] if ('A2', p) in y)
    b2_active = sum(y[('B2', p)] for p in ['I', 'II', 'III'] if ('B2', p) in y)
    z = model.addVar(vtype=GRB.BINARY, name="z")  # Binary variable for joint calibration
    model.addConstr(a2_active + b2_active <= 2 * z + 1)  # If both are active, z = 1
    model.addConstr(z <= a2_active)
    model.addConstr(z <= b2_active)
    
    model.setObjective(revenue - raw_mat - proc_cost - setup_cost_total - A2_B2_joint_calibration_fee * z, GRB.MAXIMIZE)
    
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal:.2f}")

main()
