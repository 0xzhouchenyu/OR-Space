import os
import gurobipy as gp
from gurobipy import GRB

def load_table_1(data_dir):
    """Load and parse table_1.csv to extract equipment hours, processing times, and profits."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    equipment_names = []
    products = []
    processing_times = {}  # (equipment, product) -> time
    effective_hours = {}   # equipment -> hours
    profit = {}            # product -> profit
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: Equipment_Code, I, II, III, Effective_Monthly_Equipment_Hours
        products = header[1:-1]  # ['I', 'II', 'III']
        
        for row in reader:
            if row[0].startswith('Unit_Product_Profit'):
                # This is the profit row
                for j, prod in enumerate(products):
                    profit[prod] = float(row[j + 1])
            else:
                equip = row[0]
                equipment_names.append(equip)
                effective_hours[equip] = float(row[-1])
                for j, prod in enumerate(products):
                    processing_times[(equip, prod)] = float(row[j + 1])
    
    return products, equipment_names, processing_times, effective_hours, profit

def load_general_parameters(data_dir):
    """Load general parameters from general_parameters.csv"""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    
    params = {}
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # Skip header
        for row in reader:
            param_name = row[0]
            param_value = float(row[1])
            params[param_name] = param_value
    
    return params

# Get the script directory
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load data
products, equipment_names, processing_times, effective_hours, base_profit = load_table_1(data_dir)
general_params = load_general_parameters(data_dir)

overtime_hours_cap = general_params["overtime_hours_cap"]
overtime_cost_multiplier = general_params["overtime_cost_multiplier"]
min_prod_I = general_params["min_prod_I"]
min_prod_II = general_params["min_prod_II"]
min_prod_III = general_params["min_prod_III"]

min_production = {
    "I": min_prod_I,
    "II": min_prod_II,
    "III": min_prod_III
}

# Create a new model
model = gp.Model("Factory_Production_Optimization_With_Overtime")

# Decision variables
x_reg = {p: model.addVar(name=f"x_reg_{p}", lb=0) for p in products}
x_ot = {p: model.addVar(name=f"x_ot_{p}", lb=0) for p in products}

# Overtime hours used by each equipment
overtime_hours_used = {e: model.addVar(name=f"overtime_hours_{e}", lb=0) for e in equipment_names}

# Update the model
model.update()

# Objective function: minimize total cost
total_cost = gp.LinExpr()
for p in products:
    total_cost += x_reg[p] * base_profit[p]  # Regular production cost
    total_cost += x_ot[p] * base_profit[p] * overtime_cost_multiplier  # Overtime production cost

model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints

# 1. Equipment capacity constraints (regular + overtime)
for e in equipment_names:
    lhs = gp.LinExpr()
    for p in products:
        lhs += processing_times[(e, p)] * (x_reg[p] + x_ot[p])
    model.addConstr(lhs <= effective_hours[e], name=f"Equipment_{e}_capacity")

# 2. Overtime hours cap constraint
lhs = gp.LinExpr()
for e in equipment_names:
    lhs += overtime_hours_used[e]
model.addConstr(lhs <= overtime_hours_cap, name="Overtime_hours_cap")

# 3. Overtime hours calculation for each equipment
for e in equipment_names:
    lhs = gp.LinExpr()
    for p in products:
        lhs += processing_times[(e, p)] * x_ot[p]
    model.addConstr(lhs == overtime_hours_used[e], name=f"Overtime_hours_{e}")

# 4. Minimum production quantity for each product
model.addConstr(x_reg["I"] + x_ot["I"] >= min_production["I"], name="Min_prod_I")
model.addConstr(x_reg["II"] + x_ot["II"] >= min_production["II"], name="Min_prod_II")
model.addConstr(x_reg["III"] + x_ot["III"] >= min_production["III"], name="Min_prod_III")

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
