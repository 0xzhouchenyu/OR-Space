import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = params['fixed_order_cost']
    august_threshold = int(params['august_bulk_order_threshold'])
    august_fee = params['august_bulk_receiving_fee']
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create Gurobi model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    buy = {m: model.addVar(name=f"buy_{m}", lb=0) for m in months}
    sell = {m: model.addVar(name=f"sell_{m}", lb=0) for m in months}
    stock = {m: model.addVar(name=f"stock_{m}", lb=0, ub=warehouse_capacity) for m in months}
    is_purchased = {m: model.addVar(name=f"is_purchased_{m}", vtype=GRB.BINARY) for m in months}
    
    # August specific binary variable for bulk receiving fee
    august_bulk = model.addVar(name="august_bulk", vtype=GRB.BINARY)
    
    # Objective: maximize total profit (revenue - cost)
    objective = gp.LinExpr()
    for m in months:
        objective += sell_price[m] * sell[m] - buy_price[m] * buy[m]
        objective -= fixed_order_cost * is_purchased[m]
    objective -= august_fee * august_bulk
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Stock balance constraints
    for i, m in enumerate(months):
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_stock = stock[months[i-1]]
        
        # Stock balance: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], name=f"balance_{m}")
        
        # After buying, before selling, warehouse constraint:
        # prev_stock + buy[m] <= warehouse_capacity
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, name=f"warehouse_after_buy_{m}")
        
        # If any purchase is made in month m, is_purchased[m] = 1
        model.addConstr(buy[m] <= 1000000 * is_purchased[m], name=f"purchase_binary_{m}")
        model.addConstr(buy[m] >= 0.001 * is_purchased[m], name=f"purchase_binary2_{m}")
    
    # August bulk receiving constraint
    model.addConstr(buy[8] <= august_threshold + 1000000 * august_bulk, name="august_bulk_upper")
    model.addConstr(buy[8] >= august_threshold + 0.001 * (1 - august_bulk), name="august_bulk_lower")
    
    # Optimize the model
    model.optimize()
    
    # Print solution details
    for m in months:
        print(f"Month {m}: Buy={buy[m].x:.1f} @ {buy_price[m]}, "
              f"Sell={sell[m].x:.1f} @ {sell_price[m]}, "
              f"Stock={stock[m].x:.1f}, "
              f"IsPurchased={is_purchased[m].x:.0f}")
    
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
