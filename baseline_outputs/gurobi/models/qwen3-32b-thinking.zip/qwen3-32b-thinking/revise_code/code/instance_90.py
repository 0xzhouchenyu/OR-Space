import os
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
shirts_inventory = params['shirts_inventory']
pants_inventory = params['pants_inventory']
price_a = params['package_a_price']
price_b = params['package_b_price']
price_c = params['package_c_price']
min_a = params['min_campaign_batch_a']
min_b = params['min_campaign_batch_b']
min_c = params['min_campaign_batch_c']
activation_cost_a = params['activation_cost_a']
activation_cost_b = params['activation_cost_b']
activation_cost_c = params['activation_cost_c']
labor_hours_per_A = params['labor_hours_per_A']
labor_hours_per_B = params['labor_hours_per_B']
labor_hours_per_C = params['labor_hours_per_C']
labor_hours_total = params['labor_hours_total']
bigM_a = params['bigM_a']
bigM_b = params['bigM_b']
bigM_c = params['bigM_c']
b_threshold = params['package_b_review_threshold']
b_charge = params['package_b_review_charge']
c_threshold = params['package_c_review_threshold']
c_charge = params['package_c_review_charge']

# Create the optimization model
model = gp.Model("Maximize_Revenue_Rev")

# Decision variables
x_a = model.addVar(vtype=GRB.INTEGER, lb=0, ub=bigM_a, name="Package_A")
x_b = model.addVar(vtype=GRB.INTEGER, lb=0, ub=bigM_b, name="Package_B")
x_c = model.addVar(vtype=GRB.INTEGER, lb=0, ub=bigM_c, name="Package_C")

y_a = model.addVar(vtype=GRB.BINARY, name="Activate_A")
y_b = model.addVar(vtype=GRB.BINARY, name="Activate_B")
y_c = model.addVar(vtype=GRB.BINARY, name="Activate_C")

z_b = model.addVar(vtype=GRB.BINARY, name="B_Review_Charge")
z_c = model.addVar(vtype=GRB.BINARY, name="C_Review_Charge")

# Objective: maximize revenue minus activation costs and review charges
model.setObjective(
    price_a * x_a + price_b * x_b + price_c * x_c 
    - activation_cost_a * y_a - activation_cost_b * y_b - activation_cost_c * y_c 
    - b_charge * z_b - c_charge * z_c,
    GRB.MAXIMIZE
)

# Constraints
# Inventory constraints
model.addConstr(package_a_shirts * x_a + package_b_shirts * x_b + package_c_shirts * x_c <= shirts_inventory, "Shirts_Inventory")
model.addConstr(package_a_pants * x_a + package_b_pants * x_b + package_c_pants * x_c <= pants_inventory, "Pants_Inventory")

# Labor hours constraint
model.addConstr(labor_hours_per_A * x_a + labor_hours_per_B * x_b + labor_hours_per_C * x_c <= labor_hours_total, "Labor_Hours")

# Minimum sales requirements linked to campaign activation
model.addConstr(x_a >= min_a * y_a, "Min_Package_A")
model.addConstr(x_b >= min_b * y_b, "Min_Package_B")
model.addConstr(x_c >= min_c * y_c, "Min_Package_C")

# Linking review charge to volume exceeding threshold
model.addConstr(x_b > b_threshold - 1e-6 >> z_b == 1, "B_Review_Charge_Link")
model.addConstr(x_c > c_threshold - 1e-6 >> z_c == 1, "C_Review_Charge_Link")

# Solve the model
model.setParam('OutputFlag', 0)
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
