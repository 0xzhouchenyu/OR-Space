import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

    # Profit per acre
    profit_per_acre = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons'],
    }

    # Water usage per acre by season
    water_per_acre_spring = {
        'apples': params['water_per_acre_apples_spring'],
        'pears': params['water_per_acre_pears_spring'],
        'oranges': params['water_per_acre_oranges_spring'],
        'lemons': params['water_per_acre_lemons_spring'],
    }
    water_per_acre_autumn = {
        'apples': params['water_per_acre_apples_autumn'],
        'pears': params['water_per_acre_pears_autumn'],
        'oranges': params['water_per_acre_oranges_autumn'],
        'lemons': params['water_per_acre_lemons_autumn'],
    }

    total_farm_area = params['total_farm_area']
    min_a_to_p = params['min_apples_to_pears_ratio']
    min_a_to_l = params['min_apples_to_lemons_ratio']
    o_to_l = params['oranges_to_lemons_ratio']
    max_fruit_types = int(params['max_fruit_types'])
    water_cap_spring = params['water_cap_spring']
    water_cap_autumn = params['water_cap_autumn']
    total_water_budget = params['total_water_budget']
    min_annual_water_per_fruit = params['min_annual_water_per_fruit']
    diversification_reward = params['diversification_reward']

    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']

    model = gp.Model("farm_optimization")

    # Decision variables: acres planted for each fruit in each season
    x = {}
    for fruit in fruits:
        for season in seasons:
            x[(fruit, season)] = model.addVar(name=f"x_{fruit}_{season}", lb=0)

    # Binary variable to indicate if a fruit is grown (used for counting types and enforcing minimum water)
    y = {}
    for fruit in fruits:
        y[fruit] = model.addVar(vtype=GRB.BINARY, name=f"y_{fruit}")

    # Total annual land used for each fruit
    annual_land = {fruit: model.addVar(lb=0) for fruit in fruits}
    for fruit in fruits:
        model.addConstr(annual_land[fruit] == x[(fruit, 'spring')] + x[(fruit, 'autumn')], name=f"annual_land_{fruit}")

    # Objective function: maximize total profit plus diversification reward
    total_profit = sum(profit_per_acre[fruit] * annual_land[fruit] for fruit in fruits)
    num_fruits = sum(y[fruit] for fruit in fruits)
    model.setObjective(total_profit + diversification_reward * (num_fruits >= 2), GRB.MAXIMIZE)

    # Seasonal land constraints: cannot exceed total farm area in any season
    for season in seasons:
        model.addConstr(sum(x[(fruit, season)] for fruit in fruits) <= total_farm_area, name=f"seasonal_land_{season}")

    # Annual mix constraints
    model.addConstr(annual_land['apples'] >= min_a_to_p * annual_land['pears'], name="apples_to_pears")
    model.addConstr(annual_land['apples'] >= min_a_to_l * annual_land['lemons'], name="apples_to_lemons")
    model.addConstr(annual_land['oranges'] == o_to_l * annual_land['lemons'], name="oranges_to_lemons")

    # Max number of fruit types constraint
    model.addConstr(sum(y[fruit] for fruit in fruits) <= max_fruit_types, name="max_fruit_types")

    # Link binary variables to actual planting: if a fruit is grown, it must meet the minimum water threshold
    for fruit in fruits:
        annual_water = water_per_acre_spring[fruit] * x[(fruit, 'spring')] + water_per_acre_autumn[fruit] * x[(fruit, 'autumn')]
        model.addConstr(annual_water >= min_annual_water_per_fruit - (1 - y[fruit]) * 1e6, name=f"min_water_{fruit}")
        model.addConstr(annual_water <= (1 - y[fruit]) * 1e6, name=f"zero_water_{fruit}")

    # Seasonal water constraints
    spring_water = sum(water_per_acre_spring[fruit] * x[(fruit, 'spring')] for fruit in fruits)
    autumn_water = sum(water_per_acre_autumn[fruit] * x[(fruit, 'autumn')] for fruit in fruits)
    model.addConstr(spring_water <= water_cap_spring, name="spring_water")
    model.addConstr(autumn_water <= water_cap_autumn, name="autumn_water")

    # Annual water budget constraint
    model.addConstr(spring_water + autumn_water <= total_water_budget, name="total_water_budget")

    # Solve the model
    model.setParam('OutputFlag', 0)
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

solve()
