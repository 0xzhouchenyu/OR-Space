import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    parts = []
    with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
    
    # Load general_parameters.csv
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    return parts, params


def fuel_per_bomb(distance, params, bomb_type):
    """Calculate fuel consumption for a single sortie carrying a specific bomb type."""
    if bomb_type == "heavy":
        eff_bomb = params['fuel_efficiency_heavy_bomb']
    elif bomb_type == "light":
        eff_bomb = params['fuel_efficiency_light_bomb']
    else:
        raise ValueError("Invalid bomb type")

    eff_empty = params['fuel_efficiency_empty']
    takeoff_landing = params['fuel_takeoff_landing']
    
    fuel_outbound = distance / eff_bomb
    fuel_return = distance / eff_empty
    fuel_total = fuel_outbound + fuel_return + takeoff_landing
    
    return fuel_total


def prob_at_least_k(probs, k):
    """Compute the probability that at least k out of n independent events occur."""
    n = len(probs)
    dp = [0.0] * (n + 1)
    dp[0] = 1.0
    for i in range(n):
        new_dp = [0.0] * (n + 1)
        for j in range(i + 2):
            # Event i does not occur
            new_dp[j] += dp[j] * (1.0 - probs[i])
            # Event i occurs
            if j > 0:
                new_dp[j] += dp[j - 1] * probs[i]
        dp = new_dp
    return sum(dp[k:])


def main():
    parts, params = load_data()
    n_parts = len(parts)

    max_heavy = int(params['max_heavy_bombs'])
    max_light = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts = int(params['min_parts_destroyed'])
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    overhead_A = params['sortie_fuel_overhead_A']
    overhead_B = params['sortie_fuel_overhead_B']
    prob_A = params['scenario_prob_A']
    prob_B = params['scenario_prob_B']

    # Calculate fuel per heavy/light bomb for each part
    fuel_heavy = [fuel_per_bomb(part['distance'], params, "heavy") for part in parts]
    fuel_light = [fuel_per_bomb(part['distance'], params, "light") for part in parts]

    # Create Gurobi model
    model = gp.Model("BombAllocationOptimization")
    model.setParam('OutputFlag', 0)  # Suppress output

    # Decision variables: xh[i] = number of heavy bombs allocated to part i
    #                      xl[i] = number of light bombs allocated to part i
    xh = model.addVars(n_parts, vtype=GRB.INTEGER, name="xh", lb=0)
    xl = model.addVars(n_parts, vtype=GRB.INTEGER, name="xl", lb=0)

    # Total heavy and light bombs used
    total_heavy = model.addVar(vtype=GRB.INTEGER, name="total_heavy")
    total_light = model.addVar(vtype=GRB.INTEGER, name="total_light")
    model.addConstr(total_heavy == gp.quicksum(xh), "TotalHeavyConstraint")
    model.addConstr(total_light == gp.quicksum(xl), "TotalLightConstraint")

    # Constraints on total bombs available
    model.addConstr(total_heavy <= max_heavy, "MaxHeavyConstraint")
    model.addConstr(total_light <= max_light, "MaxLightConstraint")

    # Fuel constraints for both scenarios
    fuel_used_A = model.addVar(name="FuelUsedA")
    fuel_used_B = model.addVar(name="FuelUsedB")
    
    # Compute fuel used for each scenario
    expr_fuel_A = 0
    expr_fuel_B = 0
    for i in range(n_parts):
        expr_fuel_A += xh[i] * (fuel_heavy[i] + overhead_A) + xl[i] * (fuel_light[i] + overhead_A)
        expr_fuel_B += xh[i] * (fuel_heavy[i] + overhead_B) + xl[i] * (fuel_light[i] + overhead_B)
    
    model.addConstr(fuel_used_A == expr_fuel_A, "FuelUsedAExpr")
    model.addConstr(fuel_used_B == expr_fuel_B, "FuelUsedBExpr")
    
    model.addConstr(fuel_used_A <= fuel_limit, "FuelLimitA")
    model.addConstr(fuel_used_B <= fuel_limit, "FuelLimitB")

    # Sortie constraints for both scenarios
    sorties_used_A = model.addVar(vtype=GRB.INTEGER, name="SortiesUsedA")
    sorties_used_B = model.addVar(vtype=GRB.INTEGER, name="SortiesUsedB")
    
    model.addConstr(sorties_used_A == total_heavy + total_light, "SortiesUsedA")
    model.addConstr(sorties_used_B == total_heavy + total_light, "SortiesUsedB")
    
    model.addConstr(sorties_used_A <= max_sorties_A, "MaxSortiesA")
    model.addConstr(sorties_used_B <= max_sorties_B, "MaxSortiesB")

    # Objective: maximize expected mission success probability
    # First, calculate the probability of destroying each part
    p_destroy = [1.0 - (1.0 - parts[i]['p_heavy'])**xh[i] * (1.0 - parts[i]['p_light'])**xl[i] for i in range(n_parts)]
    
    # Then, calculate the probability of mission success (at least min_parts destroyed)
    # This is a non-linear constraint; we'll use a piecewise linear approximation
    # We'll create binary variables y[i] indicating whether part i is destroyed
    y = model.addVars(n_parts, vtype=GRB.BINARY, name="y")
    
    # Link y[i] to p_destroy[i]
    epsilon = 1e-6  # Small value to avoid division by zero
    for i in range(n_parts):
        model.addConstr(y[i] >= p_destroy[i] - (1 - epsilon))
        model.addConstr(y[i] <= p_destroy[i] / epsilon)
    
    # Count the number of destroyed parts
    num_destroyed = model.addVar(vtype=GRB.INTEGER, name="NumDestroyed")
    model.addConstr(num_destroyed == gp.quicksum(y), "NumDestroyedConstraint")
    
    # Mission success if at least min_parts are destroyed
    mission_success = model.addVar(vtype=GRB.BINARY, name="MissionSuccess")
    model.addConstr(mission_success >= (num_destroyed >= min_parts).indicator(), "MissionSuccessConstraint")
    
    # Expected mission success probability
    expected_success = prob_A * mission_success + prob_B * mission_success
    
    # Set objective
    model.setObjective(expected_success, GRB.MAXIMIZE)

    # Optimize the model
    model.optimize()

    # Extract solution
    if model.status == GRB.OPTIMAL:
        best_obj = model.objVal
        print(f"FINAL_OBJ_VALUE: {best_obj:.4f}")
    else:
        print("No optimal solution found")


if __name__ == "__main__":
    main()
