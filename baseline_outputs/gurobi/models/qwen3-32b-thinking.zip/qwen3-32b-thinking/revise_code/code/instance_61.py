import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read device data from table_1.csv
devices = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            'name': row['Device'].strip(),
            'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
            'max_cap': float(row['Max_Processing_Capacity_Units'].strip())
        })

# Read general parameters
general_params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        general_params[param_name] = float(row['Value'].strip())

# Extract relevant parameters
required_units = general_params["required_units"]
energy_budget_peak = general_params["energy_budget_peak"]
energy_budget_offpeak = general_params["energy_budget_offpeak"]
startup_budget = general_params["startup_budget"]
energy_price_peak = general_params["energy_price_peak"]
energy_price_offpeak = general_params["energy_price_offpeak"]

# Energy per unit and startup energy for each device
energy_per_unit = {
    "A": general_params.get("energy_per_unit_A", 0),
    "B": general_params.get("energy_per_unit_B", 0),
    "C": general_params.get("energy_per_unit_C", 0),
    "D": general_params.get("energy_per_unit_D", 0),
}

startup_energy = {
    "A": general_params.get("startup_energy_A", 0),
    "B": general_params.get("startup_energy_B", 0),
    "C": general_params.get("startup_energy_C", 0),
    "D": general_params.get("startup_energy_D", 0),
}

startup_cost_value = general_params["startup_cost"]

# Create the optimization model
model = gp.Model("MinCostProductionWithEnergyConstraints")
model.setParam('OutputFlag', 0)  # Suppress Gurobi output

# Decision variables
n_devices = len(devices)
x = {}  # x[i]: number of units produced on device i
y = {}  # y[i]: binary variable indicating whether device i is used
z_peak = {}  # z_peak[i]: binary variable indicating if device i is used in peak period
z_offpeak = {}  # z_offpeak[i]: binary variable indicating if device i is used in off-peak period

for i in range(n_devices):
    dev_name = devices[i]["name"]
    x[dev_name] = model.addVar(
        lb=0,
        ub=devices[i]["max_cap"],
        vtype=GRB.CONTINUOUS,
        name=f"x_{dev_name}"
    )
    y[dev_name] = model.addVar(vtype=GRB.BINARY, name=f"y_{dev_name}")
    z_peak[dev_name] = model.addVar(vtype=GRB.BINARY, name=f"z_peak_{dev_name}")
    z_offpeak[dev_name] = model.addVar(vtype=GRB.BINARY, name=f"z_offpeak_{dev_name}")

# Objective: minimize total cost
# Total cost = sum(prep_cost * y_i + unit_cost * x_i + startup_cost * (z_peak_i + z_offpeak_i))
#             + energy_cost_peak + energy_cost_offpeak
obj_expr = gp.LinExpr()

for dev_name in devices:
    obj_expr += devices[dev_name]["prep_cost"] * y[dev_name]
    obj_expr += devices[dev_name]["unit_cost"] * x[dev_name]
    obj_expr += startup_cost_value * (z_peak[dev_name] + z_offpeak[dev_name])

# Add energy costs
energy_cost_peak = gp.LinExpr()
energy_cost_offpeak = gp.LinExpr()

for dev_name in devices:
    energy_cost_peak += energy_per_unit[dev_name] * x[dev_name] * energy_price_peak
    energy_cost_offpeak += energy_per_unit[dev_name] * x[dev_name] * energy_price_offpeak

obj_expr += energy_cost_peak
obj_expr += energy_cost_offpeak

model.setObjective(obj_expr, GRB.MINIMIZE)

# Constraints

# 1. Total production must equal required units
model.addConstr(gp.quicksum(x[dev_name] for dev_name in devices) == required_units, "TotalProduction")

# 2. Linking constraints: x_i <= max_cap * y_i
for dev_name in devices:
    model.addConstr(x[dev_name] <= devices[dev_name]["max_cap"] * y[dev_name], f"Link_{dev_name}")

# 3. A device can be used in either peak or off-peak period, not both
for dev_name in devices:
    model.addConstr(z_peak[dev_name] + z_offpeak[dev_name] <= y[dev_name], f"SinglePeriodUse_{dev_name}")

# 4. If a device is used, it must be assigned to at least one period
for dev_name in devices:
    model.addConstr(y[dev_name] <= z_peak[dev_name] + z_offpeak[dev_name], f"AssignToPeriod_{dev_name}")

# 5. Startup energy budget constraint
startup_energy_peak = gp.LinExpr()
startup_energy_offpeak = gp.LinExpr()

for dev_name in devices:
    startup_energy_peak += startup_energy[dev_name] * z_peak[dev_name]
    startup_energy_offpeak += startup_energy[dev_name] * z_offpeak[dev_name]

model.addConstr(startup_energy_peak <= energy_budget_peak, "StartupEnergyPeakConstraint")
model.addConstr(startup_energy_offpeak <= energy_budget_offpeak, "StartupEnergyOffpeakConstraint")

# 6. Production energy budget constraint
production_energy_peak = gp.LinExpr()
production_energy_offpeak = gp.LinExpr()

for dev_name in devices:
    production_energy_peak += energy_per_unit[dev_name] * x[dev_name] * energy_price_peak
    production_energy_offpeak += energy_per_unit[dev_name] * x[dev_name] * energy_price_offpeak

model.addConstr(production_energy_peak <= energy_budget_peak, "ProductionEnergyPeakConstraint")
model.addConstr(production_energy_offpeak <= energy_budget_offpeak, "ProductionEnergyOffpeakConstraint")

# 7. Startup budget constraint
startup_cost_total = gp.LinExpr()
for dev_name in devices:
    startup_cost_total += startup_cost_value * (z_peak[dev_name] + z_offpeak[dev_name])

model.addConstr(startup_cost_total <= startup_budget, "StartupBudgetConstraint")

# Optimize the model
model.optimize()

# Output the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
