import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def solve():
    table_1_path = get_data_path("table_1.csv")
    orders = []
    with open(table_1_path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                "width": float(row["Width_meters"]),
                "length": float(row["Length_meters"])
            })
            
    params_path = get_data_path("general_parameters.csv")
    std_widths = []
    pattern_setup_penalty = 0
    wide_roll_threshold_width = 0
    wide_roll_extra_setup_penalty = 0
    
    with open(params_path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if "standard_width" in row["Parameter_Name"]:
                std_widths.append(float(row["Value"]))
            elif row["Parameter_Name"] == "pattern_setup_penalty":
                pattern_setup_penalty = float(row["Value"])
            elif row["Parameter_Name"] == "wide_roll_threshold_width":
                wide_roll_threshold_width = float(row["Value"])
            elif row["Parameter_Name"] == "wide_roll_extra_setup_penalty":
                wide_roll_extra_setup_penalty = float(row["Value"])
                
    widths = [o["width"] for o in orders]
    lengths = [o["length"] for o in orders]
    
    total_required_area = sum(w * l for w, l in zip(widths, lengths))
    
    patterns_by_std_width = {}
    for idx, sw in enumerate(std_widths):
        patterns = []
        def build_pattern(index, current_pattern, current_sum):
            if index == len(widths):
                if any(c > 0 for c in current_pattern):
                    patterns.append(current_pattern)
                return
            
            max_count = int(math.floor((sw - current_sum + 1e-7) / widths[index]))
            for count in range(max_count + 1):
                build_pattern(index + 1, current_pattern + [count], current_sum + count * widths[index])
                
        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {"sw": sw, "patterns": patterns}
        
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)
    
    x_vars = {}
    y_vars = {}  # Binary variable indicating if a pattern is used
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data["patterns"]):
            var_name = f"x_{idx}_{i}"
            x_vars[(idx, i)] = model.addVar(name=var_name, vtype=GRB.CONTINUOUS, lb=0)
            y_vars[(idx, i)] = model.addVar(name=f"y_{idx}_{i}", vtype=GRB.BINARY)
            
    # Objective: Minimize total area used plus setup penalties
    obj = 0
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data["patterns"]):
            sw = data["sw"]
            obj += sw * x_vars[(idx, i)]
            # Pattern setup penalty
            obj += pattern_setup_penalty * y_vars[(idx, i)]
            # Wide roll extra setup penalty if applicable
            if sw >= wide_roll_threshold_width:
                obj += wide_roll_extra_setup_penalty * y_vars[(idx, i)]
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints: Satisfy length requirements for each order width
    for j in range(len(widths)):
        lhs = 0
        for idx, data in patterns_by_std_width.items():
            for i, p in enumerate(data["patterns"]):
                lhs += p[j] * x_vars[(idx, i)]
        model.addConstr(lhs >= lengths[j], name=f"order_{j}")
        
    # Link x and y variables (if x > 0, then y = 1)
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data["patterns"]):
            model.addConstr(x_vars[(idx, i)] <= 1e6 * y_vars[(idx, i)], name=f"link_{idx}_{i}")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        waste = model.objVal - total_required_area
        print(f"FINAL_OBJ_VALUE: {round(waste, 4)}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
