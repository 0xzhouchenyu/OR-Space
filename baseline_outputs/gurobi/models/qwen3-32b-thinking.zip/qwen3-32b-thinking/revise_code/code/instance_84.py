import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = params['min_manager_experience']
    manager_bonus_per_candidate = params['manager_bonus_per_candidate']

    # Create optimization model
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0)

    # Decision variables: binary for each candidate and their role (Manager or Specialist)
    x = {}  # Binary variable indicating if a candidate is selected
    m = {}  # Binary variable indicating if a candidate is selected as a Manager
    s = {}  # Binary variable indicating if a candidate is selected as a Specialist

    for c in candidates:
        name = c['name']
        x[name] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}")
        m[name] = model.addVar(vtype=GRB.BINARY, name=f"m_{name}")
        s[name] = model.addVar(vtype=GRB.BINARY, name=f"s_{name}")

    # Link x, m, and s: A candidate can be either a Manager or a Specialist, not both
    for c in candidates:
        name = c['name']
        model.addConstr(x[name] == m[name] + s[name], name=f"role_link_{name}")

    # Objective: minimize total salary plus manager bonus
    obj = (
        gp.quicksum(c['salary'] * x[c['name']] for c in candidates) +
        gp.quicksum(manager_bonus_per_candidate * m[c['name']] for c in candidates)
    )
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraint 1: Max employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, "max_employees")

    # Constraint 2: Budget limit (base salary only, excluding manager bonus)
    model.addConstr(gp.quicksum(c['salary'] * x[c['name']] for c in candidates) <= budget_limit, "budget_limit")

    # Constraint 3: At least one with Master's or Doctoral degree
    advanced_candidates = [c for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(x[c['name']] for c in advanced_candidates) >= min_advanced, "min_advanced_degree")

    # Constraint 4: Minimum total work experience
    model.addConstr(gp.quicksum(c['experience'] * x[c['name']] for c in candidates) >= min_experience, "min_total_experience")

    # Constraint 5: At most one from pair A and E
    model.addConstr(x['A'] + x['E'] <= max_equivalent, "max_equivalent_pair")

    # Constraint 6: Minimum number of employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) >= min_employees, "min_employees")

    # Constraint 7: Minimum number of managers
    model.addConstr(gp.quicksum(m[c['name']] for c in candidates) >= min_managers, "min_managers")

    # Constraint 8: Maximum number of managers
    model.addConstr(gp.quicksum(m[c['name']] for c in candidates) <= max_managers, "max_managers")

    # Constraint 9: Minimum work experience for managers
    model.addConstr(gp.quicksum(c['experience'] * m[c['name']] for c in candidates) >= min_manager_experience, "min_manager_experience")

    # Optimize the model
    model.optimize()

    # Output the objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
