import os
import gurobipy as gp
from gurobipy import GRB
import csv

def load_restaurant_data(filepath):
    """Load restaurant data from CSV file."""
    restaurants = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'standard_staff_hours': float(row['Standard_Staff_Hours'].strip()),
                'premium_staff_hours': float(row['Premium_Staff_Hours'].strip())
            })
    return restaurants

def load_general_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    return params

def main():
    # Determine data directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load data
    restaurants = load_restaurant_data(os.path.join(script_dir, "data", "table_1.csv"))
    params = load_general_parameters(os.path.join(script_dir, "data", "general_parameters.csv"))
    
    budget = params['investment_budget']
    premium_revenue_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']
    
    # Create the optimization model
    model = gp.Model("Restaurant_Investment")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = {}  # Binary variable indicating if a restaurant is purchased
    y = {}  # Binary variable indicating if a restaurant is operated in Premium mode
    
    for r in restaurants:
        x[r['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{r['name']}")
        y[r['name']] = model.addVar(vtype=GRB.BINARY, name=f"y_{r['name']}")
    
    # Objective: maximize total annual revenue
    objective = gp.LinExpr()
    for r in restaurants:
        base_revenue = r['revenue']
        uplifted_revenue = base_revenue * (1 + premium_revenue_uplift)
        objective += (base_revenue * (1 - y[r['name']]) + uplifted_revenue * y[r['name']]) * x[r['name']]
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Budget constraint: purchase cost + premium upgrade cost
    budget_expr = gp.LinExpr()
    for r in restaurants:
        budget_expr += r['cost'] * x[r['name']]
        budget_expr += premium_upgrade_cost * y[r['name']] * x[r['name']]
    model.addConstr(budget_expr <= budget, "Budget_Constraint")
    
    # Staff hours constraint for Premium operations
    staff_hours_expr = gp.LinExpr()
    for r in restaurants:
        staff_hours_expr += r['premium_staff_hours'] * y[r['name']] * x[r['name']]
    model.addConstr(staff_hours_expr <= staff_hours_cap, "Staff_Hours_Constraint")
    
    # If Restaurant D is purchased, Restaurant A cannot be purchased
    if 'Restaurant_D' in x and 'Restaurant_A' in x:
        model.addConstr(x['Restaurant_D'] + x['Restaurant_A'] <= 1, "D_A_Exclusion_Constraint")
    
    # Ensure that a restaurant can only be upgraded to Premium if it's purchased
    for r in restaurants:
        model.addConstr(y[r['name']] <= x[r['name']], f"Upgrade_Only_If_Purchased_{r['name']}")
    
    # Optimize the model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
