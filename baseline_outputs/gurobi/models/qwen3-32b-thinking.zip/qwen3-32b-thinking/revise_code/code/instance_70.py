import os
import sys
import gurobipy as gp
from gurobipy import GRB
import csv

def load_distance_matrix(filepath):
    """Load distance matrix from CSV file.
    
    Returns:
        cities: list of city labels
        dist: 2D list of distances (dist[i][j] = distance from city i to city j)
    """
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: ['City', '1', '2', '3', '4', ...]
        city_labels = header[1:]
        
        dist = []
        cities = []
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
    
    return cities, dist

def load_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            for key, value in row.items():
                if key != "parameter":
                    params[key] = value
    return params

def solve_tsp():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Load distance matrix
    dist_file = os.path.join(data_dir, "table_1.csv")
    cities, dist = load_distance_matrix(dist_file)
    n = len(cities)
    
    # Load general parameters
    param_file = os.path.join(data_dir, "general_parameters.csv")
    params = load_parameters(param_file)
    
    start_city = int(params["start_city"]) - 1  # Convert to 0-based index
    end_city = int(params["end_city"]) - 1      # Convert to 0-based index
    prohibited_from = int(params["prohibited_from"]) - 1
    prohibited_to = int(params["prohibited_to"]) - 1
    inspection_arc_from = int(params["inspection_arc_from"]) - 1
    inspection_arc_to = int(params["inspection_arc_to"]) - 1
    inspection_stop_cost = float(params["inspection_stop_cost"])
    
    # Create model
    model = gp.Model("TSP")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")
    
    # MTZ variables for subtour elimination
    u = model.addVars(n, lb=1, ub=n-1, vtype=GRB.CONTINUOUS, name="u")
    
    # Objective function
    obj = gp.QuadExpr()
    for i in range(n):
        for j in range(n):
            if i != j:
                cost = dist[i][j]
                # Add inspection stop cost if applicable
                if i == inspection_arc_from and j == inspection_arc_to:
                    cost += inspection_stop_cost
                obj += cost * x[i, j]
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    
    # Each city is left exactly once
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1)
    
    # Each city is entered exactly once
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(n) if i != j) == 1)
    
    # Subtour elimination constraints (MTZ formulation)
    for i in range(1, n):  # Skip the first city (start city)
        for j in range(1, n):  # Skip the first city (start city)
            if i != j:
                model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1)
    
    # Start at specified start city
    model.addConstr(gp.quicksum(x[start_city, j] for j in range(n) if j != start_city) == 1)
    
    # End at specified end city
    model.addConstr(gp.quicksum(x[i, end_city] for i in range(n) if i != end_city) == 1)
    
    # Prohibit direct move from start city to prohibited city
    model.addConstr(x[prohibited_from, prohibited_to] == 0)
    
    # Optimize model
    model.optimize()
    
    # Extract solution
    if model.status == GRB.OPTIMAL:
        best_cost = model.objVal
        print(f"FINAL_OBJ_VALUE: {best_cost}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_tsp()
