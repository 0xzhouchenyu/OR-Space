import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    
    n = len(shifts)  # number of periods (6)
    required = [s['required'] for s in shifts]
    late_night_periods = [4, 5]  # Shifts 5 and 6 (0-indexed: 4 and 5)
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value']) if '.' in row['Value'] else int(row['Value'])
    
    shift_duration = params['shift_duration']
    driver_rest_gap = params['driver_rest_gap']
    crew_rest_gap = params['crew_rest_gap']
    max_night_driver_fraction = params['max_night_driver_fraction']
    max_night_crew_fraction = params['max_night_crew_fraction']
    max_overtime_shifts = params['max_overtime_shifts']
    overtime_cost_factor = params['overtime_cost_factor']
    
    # Each time period is 4 hours, shift_duration is 8 hours = 2 periods
    periods_per_shift = shift_duration // 4  # = 2
    
    # Create model
    model = gp.Model("BusScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x_d[i]: number of drivers starting at period i
    x_d = model.addVars(n, vtype=GRB.INTEGER, name="x_d", lb=0)
    # x_c[i]: number of crew members starting at period i
    x_c = model.addVars(n, vtype=GRB.INTEGER, name="x_c", lb=0)
    # y_d[i]: number of overtime drivers starting at period i
    y_d = model.addVars(n, vtype=GRB.INTEGER, name="y_d", lb=0)
    # y_c[i]: number of overtime crew members starting at period i
    y_c = model.addVars(n, vtype=GRB.INTEGER, name="y_c", lb=0)
    
    # Objective: minimize total cost (regular + overtime * factor)
    model.setObjective(
        gp.quicksum(x_d[i] + x_c[i] for i in range(n)) +
        overtime_cost_factor * gp.quicksum(y_d[i] + y_c[i] for i in range(n)),
        GRB.MINIMIZE
    )
    
    # Constraints: coverage for each period
    for j in range(n):
        covering_d = []
        covering_c = []
        covering_yd = []
        covering_yc = []
        
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                covering_d.append(x_d[i])
                covering_c.append(x_c[i])
                covering_yd.append(y_d[i])
                covering_yc.append(y_c[i])
        
        model.addConstr(gp.quicksum(covering_d) + gp.quicksum(covering_yd) >= required[j], f"Driver_coverage_{j+1}")
        model.addConstr(gp.quicksum(covering_c) + gp.quicksum(covering_yc) >= required[j], f"Crew_coverage_{j+1}")
    
    # Constraints: night shift fraction limits
    model.addConstr(
        gp.quicksum(x_d[i] for i in late_night_periods) / gp.quicksum(x_d[i] for i in range(n)) <= max_night_driver_fraction,
        "Max_night_driver_fraction"
    )
    model.addConstr(
        gp.quicksum(x_c[i] for i in late_night_periods) / gp.quicksum(x_c[i] for i in range(n)) <= max_night_crew_fraction,
        "Max_night_crew_fraction"
    )
    
    # Constraint: maximum total overtime shifts
    model.addConstr(
        gp.quicksum(y_d[i] + y_c[i] for i in range(n)) <= max_overtime_shifts,
        "Max_overtime_shifts"
    )
    
    # Optimize the model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
