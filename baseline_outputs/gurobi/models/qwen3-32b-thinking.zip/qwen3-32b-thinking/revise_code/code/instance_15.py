import os
import gurobipy as gp
from gurobipy import GRB
import pandas as pd

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    table_1 = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)

    param_dict = dict(zip(params['Parameter_Name'], params['Value']))
    demand = dict(zip(table_1['stage'], table_1['tool_requirement']))

    return param_dict, demand

def solve():
    param_dict, demand = load_data()

    n = int(param_dict['n'])
    cost_new = float(param_dict['cost_new_tool'])
    cost_fast = float(param_dict['cost_fast_repair'])
    cost_slow = float(param_dict['cost_slow_repair'])
    dur_fast = int(param_dict['fast_repair_duration'])
    dur_slow = int(param_dict['slow_repair_duration'])
    max_fast_stage = int(param_dict['max_fast_stage'])
    max_slow_stage = int(param_dict['max_slow_stage'])
    emission_buy = float(param_dict['emission_buy'])
    emission_fast = float(param_dict['emission_fast_repair'])
    emission_slow = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_shortage = float(param_dict['penalty_shortage'])

    stages = list(range(1, n + 1))
    model = gp.Model("Tool_Repair_Problem")

    # Decision variables
    x = model.addVars(stages, vtype=GRB.INTEGER, name="buy", lb=0)  # New tools bought at each stage
    y = model.addVars(stages, vtype=GRB.INTEGER, name="fast", lb=0, ub=max_fast_stage)  # Tools sent to fast repair
    z = model.addVars(stages, vtype=GRB.INTEGER, name="slow", lb=0, ub=max_slow_stage)  # Tools sent to slow repair
    c = model.addVars([0] + stages, vtype=GRB.INTEGER, name="clean", lb=0)  # Clean tools available at the start of each stage
    d = model.addVars([0] + stages, vtype=GRB.INTEGER, name="dirty", lb=0)  # Dirty tools waiting for repair after each stage
    s = model.addVars(stages, vtype=GRB.INTEGER, name="shortage", lb=0)  # Shortage in meeting tool requirements

    prebuy_clean = model.addVar(vtype=GRB.INTEGER, name="prebuy_clean", lb=0)  # Initial clean stock before stage 1
    c[0].lb = prebuy_clean.lb  # Ensure initial clean stock is non-negative

    # Objective function: minimize total cost (purchase + repair + shortage penalties)
    obj = (
        gp.quicksum(cost_new * x[i] for i in stages) +
        gp.quicksum(cost_fast * y[i] for i in stages) +
        gp.quicksum(cost_slow * z[i] for i in stages) +
        gp.quicksum(penalty_shortage * s[i] for i in stages)
    )
    model.setObjective(obj, GRB.MINIMIZE)

    # Carbon emissions constraint
    carbon_emissions = (
        gp.quicksum(emission_buy * x[i] for i in stages) +
        gp.quicksum(emission_fast * y[i] for i in stages) +
        gp.quicksum(emission_slow * z[i] for i in stages) +
        emission_buy * prebuy_clean
    )
    model.addConstr(carbon_emissions <= carbon_budget, "Carbon_Budget")

    # Initial clean stock
    model.addConstr(c[0] == prebuy_clean, "Initial_Clean_Stock")

    # Flow constraints for each stage
    for i in stages:
        # Fast and slow repair availability from previous stages
        fast_ready = 0
        if i - dur_fast >= 1:
            fast_ready = y[i - dur_fast]
        slow_ready = 0
        if i - dur_slow >= 1:
            slow_ready = z[i - dur_slow]

        # Clean tools balance: incoming clean tools = outgoing clean tools + new shortages
        model.addConstr(
            c[i - 1] + fast_ready + slow_ready + x[i] == demand[i] + c[i] + s[i],
            f"Clean_Tools_Balance_{i}"
        )

        # Dirty tools balance: incoming dirty tools = outgoing dirty tools
        model.addConstr(
            d[i - 1] + demand[i] == y[i] + z[i] + d[i],
            f"Dirty_Tools_Balance_{i}"
        )

    model.setParam('OutputFlag', 0)
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
