import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data files
    table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    
    df_foods = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    # Extract parameters
    budget = float(df_params[df_params['Parameter_Name'] == 'budget']['Value'].iloc[0])
    food_intake = float(df_params[df_params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
    weekday_budget_share = float(df_params[df_params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
    max_prep_time_weekday = float(df_params[df_params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
    max_prep_time_weekend = float(df_params[df_params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
    weekend_protein_ban = int(df_params[df_params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
    veg_balance_penalty = float(df_params[df_params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])
    
    # Fill missing fiber content with 0
    df_foods['Fiber_Content_per_100g'] = df_foods['Fiber_Content_per_100g'].fillna(0)
    
    foods = df_foods['Food'].tolist()
    types = df_foods.set_index('Food')['Type'].to_dict()
    fiber = df_foods.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df_foods.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df_foods.set_index('Food')['prep_time_per_100g'].to_dict()
    
    proteins = [f for f in foods if types[f] == 'protein']
    vegetables = [f for f in foods if types[f] == 'vegetable']
    
    # Create model
    model = gp.Model("Marys_Dinners_Optimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x_weekday = model.addVars(foods, name="x_weekday", lb=0, ub=food_intake/100.0, vtype=GRB.CONTINUOUS)
    x_weekend = model.addVars(foods, name="x_weekend", lb=0, ub=food_intake/100.0, vtype=GRB.CONTINUOUS)
    y_weekday = model.addVars(foods, name="y_weekday", vtype=GRB.BINARY)
    y_weekend = model.addVars(foods, name="y_weekend", vtype=GRB.BINARY)
    z_protein = model.addVars(proteins, name="z_protein", vtype=GRB.BINARY)
    
    # Objective: maximize total fiber - penalty for vegetable imbalance
    obj = (
        gp.quicksum(fiber[f] * x_weekday[f] for f in foods) +
        gp.quicksum(fiber[f] * x_weekend[f] for f in foods) -
        veg_balance_penalty * gp.abs_(gp.quicksum(x_weekday[v] for v in vegetables) - gp.quicksum(x_weekend[v] for v in vegetables))
    )
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints
    # Total food intake per dinner
    model.addConstr(gp.quicksum(x_weekday[f] for f in foods) == food_intake / 100.0, "Weekday_Food_Intake")
    model.addConstr(gp.quicksum(x_weekend[f] for f in foods) == food_intake / 100.0, "Weekend_Food_Intake")
    
    # Budget constraints
    model.addConstr(gp.quicksum(price[f] * x_weekday[f] for f in foods) <= budget * weekday_budget_share, "Weekday_Budget")
    model.addConstr(gp.quicksum(price[f] * x_weekend[f] for f in foods) <= budget * (1 - weekday_budget_share), "Weekend_Budget")
    
    # Prep time constraints
    model.addConstr(gp.quicksum(prep_time[f] * x_weekday[f] for f in foods) <= max_prep_time_weekday, "Weekday_Prep_Time")
    model.addConstr(gp.quicksum(prep_time[f] * x_weekend[f] for f in foods) <= max_prep_time_weekend, "Weekend_Prep_Time")
    
    # Protein selection constraints
    if weekend_protein_ban:
        model.addConstrs((x_weekend[p] == 0 for p in proteins), "Weekend_Protein_Ban")
    else:
        # Exactly one protein in each meal
        model.addConstr(gp.quicksum(y_weekday[p] for p in proteins) == 1, "One_Protein_Weekday")
        model.addConstr(gp.quicksum(y_weekend[p] for p in proteins) == 1, "One_Protein_Weekend")
        
        # Linking constraints between y and x for proteins
        M = food_intake / 100.0
        for p in proteins:
            model.addConstr(x_weekday[p] >= 0.1 * y_weekday[p], f"Min_Protein_Amount_Weekday_{p}")
            model.addConstr(x_weekday[p] <= M * y_weekday[p], f"Max_Protein_Amount_Weekday_{p}")
            model.addConstr(x_weekend[p] >= 0.1 * y_weekend[p], f"Min_Protein_Amount_Weekend_{p}")
            model.addConstr(x_weekend[p] <= M * y_weekend[p], f"Max_Protein_Amount_Weekend_{p}")
            
        # At least two kinds of vegetables in each meal
        model.addConstr(gp.quicksum(y_weekday[v] for v in vegetables) >= 2, "Min_Vegetables_Weekday")
        model.addConstr(gp.quicksum(y_weekend[v] for v in vegetables) >= 2, "Min_Vegetables_Weekend")
        
        # Linking constraints between y and x for vegetables
        for v in vegetables:
            model.addConstr(x_weekday[v] >= 0.1 * y_weekday[v], f"Min_Veg_Amount_Weekday_{v}")
            model.addConstr(x_weekday[v] <= M * y_weekday[v], f"Max_Veg_Amount_Weekday_{v}")
            model.addConstr(x_weekend[v] >= 0.1 * y_weekend[v], f"Min_Veg_Amount_Weekend_{v}")
            model.addConstr(x_weekend[v] <= M * y_weekend[v], f"Max_Veg_Amount_Weekend_{v}")
            
        # Ensure a protein is used in at least one of the meals
        model.addConstrs((z_protein[p] >= y_weekday[p] for p in proteins), "Protein_Used_Weekday")
        model.addConstrs((z_protein[p] >= y_weekend[p] for p in proteins), "Protein_Used_Weekend")
    
    # Optimize the model
    model.optimize()
    
    # Return objective value
    return round(model.ObjVal, 4)

if __name__ == '__main__':
    print(f"FINAL_OBJ_VALUE: {solve()}")
