import os
import gurobipy as gp
from gurobipy import GRB
import pandas as pd

def solve():
    # Read data
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(csv_path)
    params = dict(zip(df['Parameter_Name'], df['Value']))

    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # Create a new model
    model = gp.Model("Maximize_GDP")

    # Variables: Production levels for each commodity
    x = {c: model.addVar(name=f"x_{c}", lb=0) for c in commodities}

    # Apply production upper bounds if they exist
    for c in commodities:
        for suffix in ['_production_limit', '_limit', '_capacity']:
            key = f"{c}{suffix}"
            if key in params:
                model.addConstr(x[c] <= params[key], name=f"Production_Limit_{c}")

    # Import variables (amount imported for each commodity)
    import_amount = {c: model.addVar(name=f"import_{c}", lb=0, ub=params['import_quota']) for c in commodities}

    # Domestic consumption of each commodity by other commodities
    domestic_consumption = {}
    for c in commodities:
        consumed = sum(params.get(f"{c_prime}_{c}_requirement", 0.0) * x[c_prime] for c_prime in commodities)
        domestic_consumption[c] = consumed

    # Net export = Production - Domestic Consumption
    net_export = {c: x[c] - domestic_consumption[c] for c in commodities}

    # Objective function components
    # Export revenue = sum(price * max(net_export, 0))
    export_revenue = sum(params[f"{c}_price"] * gp.max_(net_export[c], 0) for c in commodities)

    # Import costs = sum(import_cost + world_price * import_premium_ratio) * import_amount
    import_costs = sum((params[f"{c}_import_cost"] + params[f"{c}_price"] * params['import_premium_ratio']) * import_amount[c] for c in commodities)

    # Regular labor cost is zero (assumed to be already accounted for in the production process)
    # Overtime labor cost
    total_labor_used = sum(params.get(f"{c}_labor_requirement", 0.0) * x[c] for c in commodities)
    overtime_labor_used = gp.max_(total_labor_used - params['labor_force'], 0)
    overtime_cost = overtime_labor_used * params['overtime_wage']

    # Objective: GDP = Export revenue - (Import costs + Overtime costs)
    model.setObjective(export_revenue - (import_costs + overtime_cost), GRB.MAXIMIZE)

    # Constraints:
    # 1. Meet domestic demand with either production or imports
    for c in commodities:
        model.addConstr(x[c] + import_amount[c] >= domestic_consumption[c], name=f"Domestic_Demand_{c}")

    # 2. Labor constraint (regular + overtime)
    model.addConstr(total_labor_used <= params['labor_force'] + params['overtime_cap'], name="Total_Labor_Constraint")

    # Optimize model
    model.setParam('OutputFlag', 0)
    model.optimize()

    if model.status == GRB.OPTIMAL:
        return model.ObjVal
    else:
        return None

if __name__ == '__main__':
    result = solve()
    if result is not None:
        print(f"FINAL_OBJ_VALUE: {round(result, 3)}")
    else:
        print("FINAL_OBJ_VALUE: None")
