import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general_parameters.csv
    general_params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            value = float(row['Value'])
            general_params[param_name] = value
    
    # Read table_1.csv
    workshops = []
    capacities = {}
    rates = {}  # rates[(workshop, component)] = production rate
    
    filepath = os.path.join(data_dir, 'table_1.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    components = [1, 2, 3]
    shifts = ['day', 'night']
    
    # Create Gurobi model
    model = gp.Model("Maximize_Completed_Products_with_Shift_Constraints")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: hours each workshop allocates to each component in each shift
    x = {}
    for w in workshops:
        for c in components:
            for s in shifts:
                var_name = f"x_{w}_{c}_{s}"
                x[var_name] = model.addVar(name=var_name, lb=0, ub=capacities[w], vtype=GRB.CONTINUOUS)
    
    # Overtime variables
    overtime = {}
    for w in workshops:
        for s in shifts:
            var_name = f"overtime_{w}_{s}"
            overtime[var_name] = model.addVar(name=var_name, lb=0, vtype=GRB.CONTINUOUS)
    
    # Binary variables indicating if a workshop is active in a shift
    active = {}
    for w in workshops:
        for s in shifts:
            var_name = f"active_{w}_{s}"
            active[var_name] = model.addVar(name=var_name, vtype=GRB.BINARY)
    
    # z = number of completed products (min of total units per component)
    z = model.addVar(name="z", lb=0, vtype=GRB.CONTINUOUS)
    
    # Objective function: maximize z - minimize penalties
    obj = z
    
    # Add penalty terms for night work and overtime
    for w in workshops:
        for s in shifts:
            reg_hours_day = general_params.get(f'regular_hours_limit_{s}_A'.replace('A', w), 0)
            ot_cap_day = general_params.get(f'overtime_capacity_{s}_A'.replace('A', w), 0)
            
            # Penalty for night work (regular time only)
            if s == 'night':
                reg_hours_night = general_params.get(f'regular_hours_limit_{s}_A'.replace('A', w), 0)
                model.addConstr(gp.quicksum(x[f"x_{w}_{c}_{s}"] for c in components) <= reg_hours_night + overtime[f"overtime_{w}_{s}"])
                model.addConstr(overtime[f"overtime_{w}_{s}"] <= ot_cap_day)
                obj -= general_params['penalty_night_hour'] * (gp.quicksum(x[f"x_{w}_{c}_{s}"] for c in components) - overtime[f"overtime_{w}_{s}"])
            
            # Penalty for overtime
            model.addConstr(overtime[f"overtime_{w}_{s}"] <= ot_cap_day)
            obj -= general_params['penalty_overtime_hour'] * overtime[f"overtime_{w}_{s}"]
    
    # Shortage penalty
    obj -= general_params['penalty_shortage_per_unit'] * max(general_params['z_target'] - z, 0)
    
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Capacity constraints: regular hours + overtime <= total capacity
    for w in workshops:
        for s in shifts:
            reg_hours = general_params.get(f'regular_hours_limit_{s}_A'.replace('A', w), 0)
            ot_cap = general_params.get(f'overtime_capacity_{s}_A'.replace('A', w), 0)
            model.addConstr(gp.quicksum(x[f"x_{w}_{c}_{s}"] for c in components) <= reg_hours + overtime[f"overtime_{w}_{s}"])
    
    # Linking constraint between activity indicator and hours worked
    for w in workshops:
        for s in shifts:
            bigM = general_params.get(f'bigM_shift_A'.replace('A', w), 100)
            model.addConstr(gp.quicksum(x[f"x_{w}_{c}_{s}"] for c in components) <= bigM * active[f"active_{w}_{s}"])
    
    # No more than two workshops should be active in the same shift
    for s in shifts:
        model.addConstr(gp.quicksum(active[f"active_{w}_{s}"] for w in workshops) <= 2)
    
    # z <= total production of each component
    for c in components:
        total_production = gp.LinExpr(0)
        for w in workshops:
            for s in shifts:
                total_production += rates[(w, c)] * x[f"x_{w}_{c}_{s}"]
        model.addConstr(z <= total_production)
    
    # Optimize the model
    model.optimize()
    
    # Print solution details
    if model.status == GRB.OPTIMAL:
        print(f"\nStatus: {model.status}")
        for w in workshops:
            for c in components:
                for s in shifts:
                    val = x[f"x_{w}_{c}_{s}"].x
                    if val > 1e-6:
                        print(f"Workshop {w}, Component {c}, Shift {s}: {val:.2f} hours -> {rates[(w,c)] * val:.2f} units")
        
        for c in components:
            total = sum(rates[(w, c)] * x[f"x_{w}_{c}_{s}"].x for w in workshops for s in shifts)
            print(f"Total Component {c}: {total:.2f} units")
        
        obj_val = model.objVal
        print(f"\nFINAL_OBJ_VALUE: {obj_val:.1f}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
