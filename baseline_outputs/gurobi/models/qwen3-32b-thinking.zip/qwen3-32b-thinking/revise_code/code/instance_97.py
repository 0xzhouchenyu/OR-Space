import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Get data directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    materials = []
    sulfur_content = {}
    purchase_price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            mat = row['Material'].strip()
            materials.append(mat)
            sulfur_content[mat] = float(row['Sulfur_Content_Percentage'].strip())
            purchase_price[mat] = float(row['Purchase_Price_Thousand_Yuan_Per_Ton'].strip())
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[param_name] = val
    
    # Extract parameters
    max_sulfur_A_premium = params['max_sulfur_content_A_premium']
    max_sulfur_A_standard = params['max_sulfur_content_A_standard']
    max_sulfur_B_premium = params['max_sulfur_content_B_premium']
    max_sulfur_B_standard = params['max_sulfur_content_B_standard']
    
    selling_price_A_premium = params['selling_price_A_premium']
    selling_price_A_standard = params['selling_price_A_standard']
    selling_price_B_premium = params['selling_price_B_premium']
    selling_price_B_standard = params['selling_price_B_standard']
    
    max_supply_D = params['max_supply_D']
    market_demand_A = params['market_demand_A']
    market_demand_B = params['market_demand_B']
    min_premium_share_A = params['min_premium_share_A']
    max_premium_share_A = params['max_premium_share_A']
    min_premium_share_B = params['min_premium_share_B']
    max_premium_share_B = params['max_premium_share_B']
    
    products = ['A_premium', 'A_standard', 'B_premium', 'B_standard']
    
    # Create model
    model = gp.Model("Blending_Optimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: x[m, p] = tons of material m used in product p
    x = {}
    for m in materials:
        for p in products:
            x[m, p] = model.addVar(name=f"x_{m}_{p}", lb=0)
    
    # Total amount of each product
    total_A_premium = sum(x[m, 'A_premium'] for m in materials)
    total_A_standard = sum(x[m, 'A_standard'] for m in materials)
    total_B_premium = sum(x[m, 'B_premium'] for m in materials)
    total_B_standard = sum(x[m, 'B_standard'] for m in materials)
    
    # Revenue - Cost
    revenue = (
        selling_price_A_premium * total_A_premium +
        selling_price_A_standard * total_A_standard +
        selling_price_B_premium * total_B_premium +
        selling_price_B_standard * total_B_standard
    )
    
    cost = sum(
        purchase_price[m] * (x[m, 'A_premium'] + x[m, 'A_standard'] + x[m, 'B_premium'] + x[m, 'B_standard'])
        for m in materials
    )
    
    model.setObjective(revenue - cost, GRB.MAXIMIZE)
    
    # Sulfur content constraints for each product stream
    model.addConstr(sum(sulfur_content[m] * x[m, 'A_premium'] for m in materials) <= max_sulfur_A_premium * total_A_premium, "Sulfur_A_premium")
    model.addConstr(sum(sulfur_content[m] * x[m, 'A_standard'] for m in materials) <= max_sulfur_A_standard * total_A_standard, "Sulfur_A_standard")
    model.addConstr(sum(sulfur_content[m] * x[m, 'B_premium'] for m in materials) <= max_sulfur_B_premium * total_B_premium, "Sulfur_B_premium")
    model.addConstr(sum(sulfur_content[m] * x[m, 'B_standard'] for m in materials) <= max_sulfur_B_standard * total_B_standard, "Sulfur_B_standard")
    
    # Supply limit for material D
    model.addConstr(sum(x['D', p] for p in products) <= max_supply_D, "Supply_D")
    
    # Market demand constraints at the product family level
    model.addConstr(total_A_premium + total_A_standard <= market_demand_A, "Demand_A")
    model.addConstr(total_B_premium + total_B_standard <= market_demand_B, "Demand_B")
    
    # Premium share constraints for A-type and B-type products
    model.addConstr(min_premium_share_A <= total_A_premium, "Min_Premium_Share_A")
    model.addConstr(total_A_premium <= max_premium_share_A, "Max_Premium_Share_A")
    model.addConstr(min_premium_share_B <= total_B_premium, "Min_Premium_Share_B")
    model.addConstr(total_B_premium <= max_premium_share_B, "Max_Premium_Share_B")
    
    # Optimize the model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
