import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Get the directory of the current script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    
    # Create Gurobi model
    model = gp.Model("Production_Optimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = {}  # Production quantity for each product
    y_overtime = gp.GRB.CONTINUOUS  # Overtime hours used
    z_overtime_review = None  # Binary variable for overtime review
    z_line_audit_A = None  # Binary variable for line audit for Product A
    
    # Create decision variables
    x["A"] = model.addVar(name="x_A", lb=0, vtype=GRB.CONTINUOUS)
    x["B"] = model.addVar(name="x_B", lb=0, vtype=GRB.CONTINUOUS)
    overtime_hours = model.addVar(name="overtime_hours", lb=0, ub=params["max_overtime"], vtype=GRB.CONTINUOUS)
    
    # Binary variables for fixed costs
    z_overtime_review = model.addVar(name="z_overtime_review", vtype=GRB.BINARY)
    z_line_audit_A = model.addVar(name="z_line_audit_A", vtype=GRB.BINARY)
    
    # Objective: Maximize profit - costs (overtime + overtime review + line audit)
    objective = (
        float(products[0]["Profit_yuan"]) * x["A"] +
        float(products[1]["Profit_yuan"]) * x["B"] -
        params["overtime_pay"] * overtime_hours -
        params["overtime_review_fee"] * z_overtime_review -
        params["product_A_line_audit_fee"] * z_line_audit_A -
        float(products[0]["Setup_Cost_yuan"]) -
        float(products[1]["Setup_Cost_yuan"])
    )
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Constraints
    # Steel constraint
    model.addConstr(
        float(products[0]["Steel_Required_kg"]) * x["A"] + 
        float(products[1]["Steel_Required_kg"]) * x["B"] <= 
        params["available_steel"], "Steel"
    )
    
    # Aluminum constraint
    model.addConstr(
        float(products[0]["Aluminum_Required_kg"]) * x["A"] + 
        float(products[1]["Aluminum_Required_kg"]) * x["B"] <= 
        params["available_aluminum"], "Aluminum"
    )
    
    # Labor constraint (regular + overtime)
    model.addConstr(
        float(products[0]["Labor_Required_hours"]) * x["A"] + 
        float(products[1]["Labor_Required_hours"]) * x["B"] <= 
        params["available_labor"] + overtime_hours, "Labor"
    )
    
    # Overtime review constraint (if overtime exceeds threshold)
    model.addConstr(overtime_hours - params["overtime_review_threshold"] <= 
                    (params["max_overtime"] - params["overtime_review_threshold"]) * z_overtime_review, 
                    "Overtime_Review")
    
    # Line audit constraint for Product A (if production exceeds threshold)
    model.addConstr(x["A"] - params["product_A_line_audit_threshold"] <= 
                    (1000 - params["product_A_line_audit_threshold"]) * z_line_audit_A, 
                    "Line_Audit_A")
    
    # Optimize the model
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
