import os
import csv
import gurobipy as gp
from gurobipy import GRB


def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data


# Set up paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load warehouse data
table_1_path = os.path.join(data_dir, "table_1.csv")
warehouses_data = load_csv_data(table_1_path)
warehouses = [row["Warehouse"] for row in warehouses_data]
supply = {row["Warehouse"]: int(row["Empty_Containers"]) for row in warehouses_data}

# Load port demand data
table_2_path = os.path.join(data_dir, "table_2.csv")
ports_data = load_csv_data(table_2_path)
ports = [row["Port"] for row in ports_data]
demand = {row["Port"]: int(row["Container_Demand"]) for row in ports_data}

# Load distance data
table_3_path = os.path.join(data_dir, "table_3.csv")
distance_data = load_csv_data(table_3_path)
distances = {}
for row in distance_data:
    warehouse = row["Warehouse"]
    for port in ports:
        distances[(warehouse, port)] = float(row[port])

# Load general parameters
general_params_path = os.path.join(data_dir, "general_parameters.csv")
general_params = load_csv_data(general_params_path)
cost_per_km = float(next(p["Value"] for p in general_params if p["Parameter_Name"] == "cost_per_km"))
truck_capacity = int(next(p["Value"] for p in general_params if p["Parameter_Name"] == "truck_capacity"))
adriatic_pool_shortage_trigger = int(next(p["Value"] for p in general_params if p["Parameter_Name"] == "adriatic_pool_shortage_trigger"))
adriatic_pool_recovery_fee = float(next(p["Value"] for p in general_params if p["Parameter_Name"] == "adriatic_pool_recovery_fee"))

# Load shortage penalty data
shortage_penalty_path = os.path.join(data_dir, "shortage_penalty.csv")
shortage_penalty_data = load_csv_data(shortage_penalty_path)

# Process shortage penalties
shortage_charge = {}
grace_containers = {}
recovery_fee = {}

for row in shortage_penalty_data:
    port = row["Port"]
    shortage_charge[port] = float(row["Shortage_Charge"])
    grace_containers[port] = int(row["Grace_Containers"])
    recovery_fee[port] = float(row["Recovery_Fee"])

# Adriatic ports (Venice, Ancona, Bari)
adriatic_ports = ["Venice", "Ancona", "Bari"]

# Create optimization model
model = gp.Model("Container_Transportation_With_Penalties")
model.setParam('OutputFlag', 0)  # Suppress output

# Decision variables
x = {}  # x[i,j]: number of containers shipped from warehouse i to port j
s = {}  # s[j]: shortage at port j (unmet demand)

for i in warehouses:
    for j in ports:
        x[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}")

for j in ports:
    s[j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"s_{j}")

# Update model
model.update()

# Objective function: minimize total cost (transport + shortage + recovery fees)
obj = gp.QuadExpr()

# Transport cost
for i in warehouses:
    for j in ports:
        obj += x[i, j] * distances[(i, j)] * cost_per_km

# Shortage charge
for j in ports:
    obj += s[j] * shortage_charge[j]

# Recovery fee for individual ports
for j in ports:
    r = model.addVar(vtype=GRB.BINARY, name=f"r_{j}")
    model.addConstr((s[j] - grace_containers[j]) >= -1e6 * (1 - r))  # If s[j] > grace_containers[j], then r = 1
    model.addConstr((s[j] - grace_containers[j]) <= 1e6 * r)         # If s[j] <= grace_containers[j], then r = 0
    obj += r * recovery_fee[j]

# Recovery fee for the Adriatic pool
adriatic_s = sum(s[j] for j in adriatic_ports)
adriatic_r = model.addVar(vtype=GRB.BINARY, name="adriatic_r")
model.addConstr(adriatic_s - adriatic_pool_shortage_trigger >= -1e6 * (1 - adriatic_r))
model.addConstr(adriatic_s - adriatic_pool_shortage_trigger <= 1e6 * adriatic_r)
obj += adriatic_r * adriatic_pool_recovery_fee

model.setObjective(obj, GRB.MINIMIZE)

# Constraints
# Supply constraints
for i in warehouses:
    model.addConstr(gp.quicksum(x[i, j] for j in ports) <= supply[i])

# Demand constraints and shortage definitions
for j in ports:
    model.addConstr(gp.quicksum(x[i, j] for i in warehouses) + s[j] == demand[j])

# Optimize model
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
