import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    total_space = params['mall_total_space']
    rent_pct = params['rent_percentage'] / 100.0
    common_area_factor = params['common_area_factor']
    catering_third_store_security_threshold = int(params['catering_third_store_security_threshold'])
    catering_third_store_security_cost = params['catering_third_store_security_cost']
    
    # Read store data
    stores = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            stores.append({
                'name': row['Store_Type'].strip(),
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits  # per-store profit when n stores of this type
            })
    
    # Create Gurobi model
    model = gp.Model("ShoppingMallOptimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: number of stores for each type
    x = {}
    for i, store in enumerate(stores):
        x[i] = model.addVar(vtype=GRB.INTEGER, name=f"x_{i}", lb=store['min'], ub=store['max'])
    
    # Calculate effective area used (including common area factor)
    effective_area = 0
    for i, store in enumerate(stores):
        effective_area += x[i] * store['area'] * common_area_factor
    
    # Add constraint: total effective area <= mall total space
    model.addConstr(effective_area <= total_space, "Total_Area_Constraint")
    
    # Calculate total profit
    total_profit = 0
    for i, store in enumerate(stores):
        # Use piecewise linear functions to represent the profit based on number of stores
        if len(store['profits']) > 0:
            points = sorted(store['profits'].items())  # Sort by number of stores
            x_vals = [k for k, _ in points]
            y_vals = [v for _, v in points]
            
            # Add piecewise linear function for this store's profit
            profit_var = model.addVar(name=f"profit_{i}")
            model.addGenConstrPWL(x[i], profit_var, x_vals, y_vals, f"PWLC_{i}")
            total_profit += profit_var
    
    # Handle the Catering third store security cost
    catering_index = 4  # Index of Catering store
    catering_count = x[catering_index]
    
    # Binary variable indicating if there are 3 Catering stores
    is_third_catering = model.addVar(vtype=GRB.BINARY, name="is_third_catering")
    
    # If catering_count >= 3, then is_third_catering = 1
    model.addConstr(catering_count >= 3 - (1 - is_third_catering) * 1000, "Catering_Third_Store_1")
    model.addConstr(catering_count <= 2 + is_third_catering * 1000, "Catering_Third_Store_2")
    
    # Subtract the security cost if there are 3 Catering stores
    total_profit -= is_third_catering * catering_third_store_security_cost
    
    # Set objective: maximize total rent income
    model.setObjective(rent_pct * total_profit, GRB.MAXIMIZE)
    
    # Optimize the model
    model.optimize()
    
    # Print results
    if model.status == GRB.OPTIMAL:
        print("Optimal solution found:")
        for i, store in enumerate(stores):
            print(f"  {store['name']}: {x[i].x} stores")
        
        # Calculate total area used
        total_area_used = sum(x[i].x * store['area'] * common_area_factor for i, store in enumerate(stores))
        print(f"Total effective area used: {total_area_used}")
        
        # Calculate total profit
        total_profit_value = 0
        for i, store in enumerate(stores):
            if x[i].x in store['profits']:
                total_profit_value += x[i].x * store['profits'][int(x[i].x)]
        
        # Adjust for Catering third store security cost
        if x[catering_index].x >= 3:
            total_profit_value -= catering_third_store_security_cost
        
        print(f"Total profit: {total_profit_value}")
        print(f"Total rent (objective): {rent_pct * total_profit_value}")
        print(f"FINAL_OBJ_VALUE: {rent_pct * total_profit_value}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()
