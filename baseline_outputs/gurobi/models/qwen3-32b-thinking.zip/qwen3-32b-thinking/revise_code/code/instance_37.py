import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load table_1.csv
    table1_path = os.path.join(data_dir, "table_1.csv")
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    
    # Parse process data
    a_I = float(rows[0][1])  # Model A hours for Process I
    b_I = float(rows[0][2])  # Model B hours for Process I
    
    a_II = float(rows[1][1])  # Model A hours for Process II
    b_II = float(rows[1][2])  # Model B hours for Process II
    
    profit_A = float(rows[2][1])  # Profit per unit Model A
    profit_B = float(rows[2][2])  # Profit per unit Model B
    
    # Load general_parameters.csv
    params_path = os.path.join(data_dir, "general_parameters.csv")
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    min_profit = params['min_weekly_profit']
    min_total_A = params['min_model_A_units']
    min_total_B = params['min_model_B_units']
    
    week1_min_A = params['week1_min_model_A_units']
    week1_min_B = params['week1_min_model_B_units']
    week2_min_A = params['week2_min_model_A_units']
    week2_min_B = params['week2_min_model_B_units']
    
    normal_hours_I = params['process_I_hours']
    normal_hours_II = params['process_II_hours']
    
    max_overtime_I = params['max_overtime_I_per_week']
    max_overtime_II = params['max_overtime_II_per_week']
    
    overtime_cost_I = params['overtime_premium_I']
    overtime_cost_II = params['overtime_premium_II']
    
    min_avg_utilization_I = params['min_avg_utilization_I']
    min_avg_utilization_II = params['min_avg_utilization_II']
    
    fatigue_threshold_I = params['week1_overtime_fatigue_threshold_I']
    fatigue_threshold_II = params['week1_overtime_fatigue_threshold_II']
    
    recovery_loss_I = params['week2_recovery_loss_I']
    recovery_loss_II = params['week2_recovery_loss_II']
    
    # Create Gurobi model
    model = gp.Model("Microcomputer_Production_Two_Weeks")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    xA1 = model.addVar(name="xA1", lb=0)  # Model A units in Week 1
    xB1 = model.addVar(name="xB1", lb=0)  # Model B units in Week 1
    xA2 = model.addVar(name="xA2", lb=0)  # Model A units in Week 2
    xB2 = model.addVar(name="xB2", lb=0)  # Model B units in Week 2
    
    oI1 = model.addVar(name="oI1", lb=0, ub=max_overtime_I)  # Overtime for Process I in Week 1
    oII1 = model.addVar(name="oII1", lb=0, ub=max_overtime_II)  # Overtime for Process II in Week 1
    oI2 = model.addVar(name="oI2", lb=0, ub=max_overtime_I)  # Overtime for Process I in Week 2
    oII2 = model.addVar(name="oII2", lb=0, ub=max_overtime_II)  # Overtime for Process II in Week 2
    
    # Binary variable to indicate if Process I exceeded fatigue threshold in Week 1
    yI = model.addVar(vtype=GRB.BINARY, name="yI")
    # Binary variable to indicate if Process II exceeded fatigue threshold in Week 1
    yII = model.addVar(vtype=GRB.BINARY, name="yII")
    
    # Objective: Maximize total profit after overtime costs
    model.setObjective(
        (profit_A * xA1 + profit_B * xB1 + profit_A * xA2 + profit_B * xB2) 
        - (overtime_cost_I * oI1 + overtime_cost_II * oII1 + overtime_cost_I * oI2 + overtime_cost_II * oII2),
        GRB.MAXIMIZE
    )
    
    # Constraints
    
    # Weekly delivery promises must be met in their own week
    model.addConstr(xA1 >= week1_min_A, "Week1_Min_Model_A")
    model.addConstr(xB1 >= week1_min_B, "Week1_Min_Model_B")
    model.addConstr(xA2 >= week2_min_A, "Week2_Min_Model_A")
    model.addConstr(xB2 >= week2_min_B, "Week2_Min_Model_B")
    
    # Total production requirements over both weeks
    model.addConstr(xA1 + xA2 >= min_total_A, "Total_Min_Model_A")
    model.addConstr(xB1 + xB2 >= min_total_B, "Total_Min_Model_B")
    
    # Minimum net profit over two weeks
    model.addConstr(
        (profit_A * xA1 + profit_B * xB1 + profit_A * xA2 + profit_B * xB2) 
        - (overtime_cost_I * oI1 + overtime_cost_II * oII1 + overtime_cost_I * oI2 + overtime_cost_II * oII2) 
        >= min_profit,
        "Min_Net_Profit"
    )
    
    # Process I capacity constraints with overtime and recovery rule
    model.addConstr(a_I * xA1 + b_I * xB1 <= normal_hours_I + oI1, "Process_I_Capacity_Week1")
    model.addConstr(a_I * xA2 + b_I * xB2 <= normal_hours_I - recovery_loss_I * yI + oI2, "Process_I_Capacity_Week2")
    
    # Process II capacity constraints with overtime and recovery rule
    model.addConstr(a_II * xA1 + b_II * xB1 <= normal_hours_II + oII1, "Process_II_Capacity_Week1")
    model.addConstr(a_II * xA2 + b_II * xB2 <= normal_hours_II - recovery_loss_II * yII + oII2, "Process_II_Capacity_Week2")
    
    # Fatigue threshold triggers for recovery loss
    model.addConstr(oI1 >= fatigue_threshold_I - 1e6 * yI, "Fatigue_Threshold_I")
    model.addConstr(oI1 <= fatigue_threshold_I + 1e6 * (1 - yI), "Fatigue_Threshold_I")
    
    model.addConstr(oII1 >= fatigue_threshold_II - 1e6 * yII, "Fatigue_Threshold_II")
    model.addConstr(oII1 <= fatigue_threshold_II + 1e6 * (1 - yII), "Fatigue_Threshold_II")
    
    # Minimum average utilization of regular hours over two weeks
    model.addConstr(
        (a_I * xA1 + b_I * xB1 - oI1 + a_I * xA2 + b_I * xB2 - oI2) / (2 * normal_hours_I) >= min_avg_utilization_I,
        "Min_Utilization_I"
    )
    
    model.addConstr(
        (a_II * xA1 + b_II * xB1 - oII1 + a_II * xA2 + b_II * xB2 - oII2) / (2 * normal_hours_II) >= min_avg_utilization_II,
        "Min_Utilization_II"
    )
    
    # Optimize the model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
