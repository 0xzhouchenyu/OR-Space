import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load batch processing times
    table1_path = os.path.join(base_dir, "data", "table_1.csv")
    batches = []
    processing_times = []
    
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        
        for row in reader:
            batch_id = int(row[0])
            times = [float(row[j+1]) for j in range(1, len(row))]
            # Round up to the next full time unit
            rounded_times = [int(t) + (1 if t % 1 != 0 else 0) for t in times]
            batches.append(batch_id)
            processing_times.append(rounded_times)
    
    # Load general parameters
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    
    with open(params_path, 'r') as f:
        reader = csv.reader(f)
        for key, value in reader:
            if key == "planning_horizon_T":
                params[key] = int(value)
            elif key in ["energy_cost_v1", "energy_cost_v2", "energy_cost_v3",
                         "peak_energy_multiplier", "peak_energy_cap",
                         "makespan_weight", "energy_weight"]:
                params[key] = float(value)
    
    return batches, processing_times, params

def solve():
    batches, processing_times, params = load_data()
    n_batches = len(batches)
    n_vats = len(processing_times[0])
    T = params["planning_horizon_T"]
    
    # Create model
    model = gp.Model("Dyeing_Scheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[b,v,t] = 1 if batch b starts on vat v at time t
    x = {}
    for b in range(n_batches):
        for v in range(n_vats):
            for t in range(T - processing_times[b][v] + 1):
                x[(b, v, t)] = model.addVar(vtype=GRB.BINARY, name=f"x_{b}_{v}_{t}")
    
    # y[v,t] = 1 if vat v is active at time t
    y = {}
    for v in range(n_vats):
        for t in range(T):
            y[(v, t)] = model.addVar(vtype=GRB.BINARY, name=f"y_{v}_{t}")
    
    # z[t] = 1 if any vat is active at time t (for makespan calculation)
    z = {}
    for t in range(T):
        z[t] = model.addVar(vtype=GRB.BINARY, name=f"z_{t}")
    
    # Objective function
    makespan_weight = params["makespan_weight"]
    energy_weight = params["energy_weight"]
    energy_cost_v1 = params["energy_cost_v1"]
    energy_cost_v2 = params["energy_cost_v2"]
    energy_cost_v3 = params["energy_cost_v3"]
    peak_energy_multiplier = params["peak_energy_multiplier"]
    
    obj = 0
    
    # Makespan component: finish time of last batch on Vat 3
    for b in range(n_batches):
        for t in range(T - processing_times[b][2] + 1):
            finish_time = t + processing_times[b][2] - 1
            if finish_time < T:
                obj += makespan_weight * (T - finish_time) * x[(b, 2, t)]
    
    # Energy cost component
    for b in range(n_batches):
        for v in range(n_vats):
            for t in range(T - processing_times[b][v] + 1):
                duration = processing_times[b][v]
                energy_cost = [energy_cost_v1, energy_cost_v2, energy_cost_v3][v]
                
                # Calculate energy cost for this operation
                cost = 0
                for dt in range(duration):
                    period = t + dt
                    if 5 < period < 9:  # Peak periods 6-8 (0-indexed 5-7)
                        cost += energy_cost * peak_energy_multiplier
                    else:
                        cost += energy_cost
                
                obj += energy_weight * cost * x[(b, v, t)]
    
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    
    # 1. Each batch must be processed exactly once on each vat
    for b in range(n_batches):
        for v in range(n_vats):
            model.addConstr(gp.quicksum(x[(b, v, t)] 
                                      for t in range(T - processing_times[b][v] + 1)) == 1,
                          f"Batch_{b}_Vat_{v}_Once")
    
    # 2. Processing order constraint: Batch must go through Vat 1 -> Vat 2 -> Vat 3
    for b in range(n_batches):
        for v in range(n_vats - 1):  # For all but last vat
            next_vat = v + 1
            for t1 in range(T - processing_times[b][v] + 1):
                for t2 in range(T - processing_times[b][next_vat] + 1):
                    # Vat v finishes at t1 + p - 1
                    # Vat next_vat can start at t2 >= t1 + p - 1
                    if t2 < t1 + processing_times[b][v]:
                        model.addConstr(x[(b, v, t1)] + x[(b, next_vat, t2)] <= 1,
                                      f"Order_{b}_{v}_{t1}_{next_vat}_{t2}")
    
    # 3. No overlapping operations on the same vat
    for v in range(n_vats):
        for t in range(T):
            # Find all possible operations that would overlap with time t
            overlapping_ops = []
            for b in range(n_batches):
                for start in range(max(0, t - processing_times[b][v] + 1), min(T - processing_times[b][v] + 1, t + 1)):
                    duration = processing_times[b][v]
                    if t < start + duration:
                        overlapping_ops.append(x[(b, v, start)])
            model.addConstr(gp.quicksum(overlapping_ops) <= 1, f"NoOverlap_Vat{v}_Time{t}")
    
    # 4. Maintenance shutdown on Vat 2 during periods 4-5 (0-indexed 3-4)
    for b in range(n_batches):
        duration = processing_times[b][1]  # Vat 2
        for t in range(T - duration + 1):
            # Check if the operation would overlap with maintenance window
            start = t
            end = t + duration - 1
            if (start <= 3 and end >= 3) or (start <= 4 and end >= 4):
                model.addConstr(x[(b, 1, t)] == 0, f"Maintenance_Vat2_Batch{b}_Start{t}")
    
    # 5. Link y[v,t] to x[b,v,t]
    for v in range(n_vats):
        for t in range(T):
            # A vat is active at time t if any batch is being processed at that time
            active_at_t = 0
            for b in range(n_batches):
                for start in range(max(0, t - processing_times[b][v] + 1), min(T - processing_times[b][v] + 1, t + 1)):
                    duration = processing_times[b][v]
                    if t < start + duration:
                        active_at_t += x[(b, v, start)]
            model.addConstr(y[(v, t)] == active_at_t, f"ActiveStatus_Vat{v}_Time{t}")
    
    # 6. Link z[t] to y[v,t]
    for t in range(T):
        model.addConstr(z[t] == gp.quicksum(y[(v, t)] for v in range(n_vats)), f"AnyActive_Time{t}")
    
    # 7. Peak energy cap constraint
    peak_energy_cap = params["peak_energy_cap"]
    peak_energy_usage = 0
    for v in range(n_vats):
        energy_cost = [energy_cost_v1, energy_cost_v2, energy_cost_v3][v]
        for t in range(5, 8):  # Peak periods 6-8 (0-indexed 5-7)
            peak_energy_usage += energy_cost * peak_energy_multiplier * y[(v, t)]
    
    model.addConstr(peak_energy_usage <= peak_energy_cap, "PeakEnergyCap")
    
    # Optimize
    model.optimize()
    
    # Extract solution
    if model.status == GRB.OPTIMAL:
        final_obj_value = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {final_obj_value}")
    else:
        print("No optimal solution found")

if __name__ == '__main__':
    solve()
