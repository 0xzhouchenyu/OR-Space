import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Read general parameters
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            for key, value in row.items():
                if key == "Parameter_Name":
                    continue
                params[key] = value

    num_customers = int(params['num_customers'])
    max_trucks = int(params['max_trucks'])
    truck_capacity = float(params['truck_capacity'])
    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])

    # Parse depot coordinates
    depot_str = params.get('depot_coordinates', '(40,50)').strip('()')
    if ',' in depot_str:
        depot_x, depot_y = map(float, depot_str.split(','))
    else:
        depot_x, depot_y = map(float, depot_str.split())

    coords = [(depot_x, depot_y)]
    demands_list = [0]
    tw_list = [(depot_tw_start, depot_tw_end)]
    svc_list = [0]
    outsource_cost = [0]
    mandatory_external = [0]

    # Read customer data
    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            customer_id = int(row['Customer_ID'])
            coords.append((float(row['Coordinates_X']), float(row['Coordinates_Y'])))
            demands_list.append(float(row['Demand']))
            tw_list.append((float(row['Time_Window_Start']), float(row['Time_Window_End'])))
            svc_list.append(float(row['Service_Duration']))
            outsource_cost.append(float(row['Outsource_Cost']))
            mandatory_external.append(int(row['Mandatory_External']))

    n = len(coords)  # Total number of nodes including depot
    N = list(range(1, n))  # All customers
    V = list(range(n))   # All nodes (including depot)

    # Filter out mandatory external customers
    non_mandatory_customers = [i for i in range(1, n) if mandatory_external[i] == 0]
    mandatory_customers = [i for i in range(1, n) if mandatory_external[i] == 1]

    # Calculate distance matrix
    dist = {}
    for i in V:
        for j in V:
            dist[i, j] = calculate_distance(coords[i], coords[j])

    # Create Gurobi model
    model = gp.Model("VRPHTW_Revision")

    # Set parameter to suppress output
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = model.addVars([(i, j) for i in V for j in V if i != j], vtype=GRB.BINARY, name="x")
    t = model.addVars(V, lb=0, name="t")  # Time at each node
    y = model.addVars(non_mandatory_customers, vtype=GRB.BINARY, name="y")  # Outsourcing decision

    # Objective: minimize total in-house travel distance plus outsourcing cost
    model.setObjective(
        gp.quicksum(dist[i, j] * x[i, j] for i in V for j in V if i != j) +
        gp.quicksum(outsource_cost[i] * y[i] for i in non_mandatory_customers),
        GRB.MINIMIZE
    )

    # Constraints

    # 1. Each customer is either served by an in-house truck or outsourced
    for i in non_mandatory_customers:
        model.addConstr(gp.quicksum(x[j, i] for j in V if j != i) + y[i] == 1)

    # 2. Customers that must be outsourced are not included in the routing plan
    for i in mandatory_customers:
        model.addConstr(gp.quicksum(x[j, i] for j in V if j != i) == 0)

    # 3. Flow conservation for in-house customers (not outsourced)
    for i in non_mandatory_customers:
        model.addConstr(gp.quicksum(x[i, j] for j in V if j != i and (1 - y[i]) > 0) == 
                        gp.quicksum(x[j, i] for j in V if j != i and (1 - y[i]) > 0))

    # 4. Fleet size limit for in-house trucks
    model.addConstr(gp.quicksum(x[0, j] for j in non_mandatory_customers if (1 - y[j]) > 0) <= inhouse_truck_limit)

    # 5. Time window constraints
    for i in non_mandatory_customers:
        model.addConstr(t[i] >= tw_list[i][0])
        model.addConstr(t[i] <= tw_list[i][1])

    # 6. Time constraints for arcs
    M_val = tw_list[0][1] + max(svc_list)
    for i in V:
        for j in V:
            if i != j and (1 - y[j]) > 0:
                model.addConstr(t[i] + svc_list[i] + dist[i, j] - t[j] <= M_val * (1 - x[i, j]))

    # 7. Capacity constraints
    for i in V:
        for j in V:
            if i != j and (1 - y[j]) > 0:
                model.addConstr(demands_list[i] + demands_list[j] <= truck_capacity + truck_capacity * (1 - x[i, j]))

    # Solve the model
    model.optimize()

    # Output the objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
