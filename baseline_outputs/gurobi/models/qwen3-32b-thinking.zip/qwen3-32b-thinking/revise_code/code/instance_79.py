import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters from CSV file
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Define paths
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params_file = os.path.join(data_dir, "general_parameters.csv")

# Load parameters
params = load_general_parameters(params_file)

# Extract profit and cost data
sell_price_table = params['sell_price_table']
sell_price_chair = params['sell_price_chair']
sell_price_bookshelf = params['sell_price_bookshelf']

cost_table = params['manufacturing_cost_table']
cost_chair = params['manufacturing_cost_chair']
cost_bookshelf = params['manufacturing_cost_bookshelf']

profit_table = sell_price_table - cost_table  # 80
profit_chair = sell_price_chair - cost_chair    # 30
profit_bookshelf = sell_price_bookshelf - cost_bookshelf  # 60

# Rush profit bonuses
rush_profit_bonus_table = params['rush_profit_bonus_table']  # 20
rush_profit_bonus_chair = params['rush_profit_bonus_chair']    # 10
rush_profit_bonus_bookshelf = params['rush_profit_bonus_bookshelf']  # 15

# Warehouse space
space_table = params['warehouse_space_table']  # 5
space_chair = params['warehouse_space_chair']    # 2
space_bookshelf = params['warehouse_space_bookshelf']  # 3
max_warehouse = params['max_warehouse_space']  # 500

# Labor hours
labor_hours_table = params['labor_hours_table']  # 4
labor_hours_chair = params['labor_hours_chair']    # 1
labor_hours_bookshelf = params['labor_hours_bookshelf']  # 3
max_labor_regular = params['max_labor_hours_month_regular']  # 400
max_labor_rush = params['max_labor_hours_month_rush']  # 150
max_rush_items = params['max_rush_items_month']  # 40

# Minimum production requirements
min_tables = params['min_tables']  # 10
min_bookshelves = params['min_bookshelves']  # 20
max_total = params['max_total_items']  # 200

# Create the Gurobi model
model = gp.Model("Furniture_Production_Revision")

# Decision variables
# Regular production
x_tables_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="tables_reg")
x_chairs_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="chairs_reg")
x_bookshelves_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="bookshelves_reg")

# Rush production
x_tables_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="tables_rush")
x_chairs_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="chairs_rush")
x_bookshelves_rush = model.addVar(vtype=GRB.INTEGER, lb=0, name="bookshelves_rush")

# Objective function: maximize total profit
model.setObjective(
    (profit_table * x_tables_reg + profit_chair * x_chairs_reg + profit_bookshelf * x_bookshelves_reg) +
    ((profit_table + rush_profit_bonus_table) * x_tables_rush + 
     (profit_chair + rush_profit_bonus_chair) * x_chairs_rush + 
     (profit_bookshelf + rush_profit_bonus_bookshelf) * x_bookshelves_rush),
    GRB.MAXIMIZE
)

# Constraints
# Warehouse space constraint (shared between regular and rush)
model.addConstr(
    space_table * (x_tables_reg + x_tables_rush) +
    space_chair * (x_chairs_reg + x_chairs_rush) +
    space_bookshelf * (x_bookshelves_reg + x_bookshelves_rush) <= max_warehouse,
    "Warehouse_Space"
)

# Minimum production requirements (applies to regular only)
model.addConstr(x_tables_reg >= min_tables, "Min_Tables")
model.addConstr(x_bookshelves_reg >= min_bookshelves, "Min_Bookshelves")

# Maximum total items (regular + rush)
model.addConstr(
    (x_tables_reg + x_chairs_reg + x_bookshelves_reg + 
     x_tables_rush + x_chairs_rush + x_bookshelves_rush) <= max_total,
    "Max_Total_Items"
)

# Labor hour constraints
model.addConstr(
    labor_hours_table * x_tables_reg + 
    labor_hours_chair * x_chairs_reg + 
    labor_hours_bookshelf * x_bookshelves_reg <= max_labor_regular,
    "Regular_Labor_Hours"
)

model.addConstr(
    labor_hours_table * x_tables_rush + 
    labor_hours_chair * x_chairs_rush + 
    labor_hours_bookshelf * x_bookshelves_rush <= max_labor_rush,
    "Rush_Labor_Hours"
)

# Maximum rush items
model.addConstr(
    x_tables_rush + x_chairs_rush + x_bookshelves_rush <= max_rush_items,
    "Max_Rush_Items"
)

# Optimize the model
model.setParam('OutputFlag', 0)
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
