import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read staffing requirements
    requirements = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row["Time_Period"].strip()
            req = int(row["Required_Salespeople"].strip())
            requirements[period] = req
    
    # Read general parameters
    general_params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row["Parameter_Name"].strip()
            value = row["Value"].strip()
            if param_name == "shift_start_times":
                general_params[param_name] = value.split(";")
            elif param_name in ["full_time_cost", "part_time_cost", "part_time_cap_per_period", "min_full_time_per_period"]:
                general_params[param_name] = float(value) if "cost" in param_name else int(value)
            else:
                general_params[param_name] = value
    
    # Extract parameters
    periods = list(requirements.keys())
    req_values = list(requirements.values())
    n = len(periods)  # 6 periods
    full_time_cost = general_params["full_time_cost"]
    part_time_cost = general_params["part_time_cost"]
    part_time_cap_per_period = general_params["part_time_cap_per_period"]
    min_full_time_per_period = general_params["min_full_time_per_period"]
    
    # Create model
    model = gp.Model("StaffingOptimization")
    model.setParam('OutputFlag', 0)  # Suppress Gurobi output
    
    # Decision variables
    x = model.addVars(n, vtype=GRB.INTEGER, name="x", lb=0)  # Full-time starts at each period
    y = model.addVars(n, vtype=GRB.INTEGER, name="y", lb=0, ub=part_time_cap_per_period)  # Part-time workers per period
    
    # Objective: minimize total daily labor cost
    model.setObjective(full_time_cost * gp.quicksum(x[i] for i in range(n)) + 
                       part_time_cost * gp.quicksum(y[j] for j in range(n)), GRB.MINIMIZE)
    
    # Constraints
    # 1. Coverage constraint: For each period j, the sum of full-time staff working during that period and part-time workers must meet the required salespeople
    for j in range(n):
        full_time_in_period_j = x[j] + x[(j - 1) % n]
        model.addConstr(full_time_in_period_j + y[j] >= req_values[j], f"coverage_{j}")
    
    # 2. Minimum full-time per period constraint: The number of full-time staff present in each period must be at least min_full_time_per_period
    for j in range(n):
        full_time_in_period_j = x[j] + x[(j - 1) % n]
        model.addConstr(full_time_in_period_j >= min_full_time_per_period, f"min_full_time_{j}")
    
    # Optimize the model
    model.optimize()
    
    # Print solution details (if needed)
    # for i in range(n):
    #     print(f"Full-time starts at period {periods[i]}: {int(x[i].x)}")
    #     print(f"Part-time workers in period {periods[i]}: {int(y[i].x)}")
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
