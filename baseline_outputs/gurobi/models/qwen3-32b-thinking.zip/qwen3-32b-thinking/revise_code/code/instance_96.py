import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define data file paths
    current_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(current_dir, "data", "table_1.csv")
    params_path = os.path.join(current_dir, "data", "general_parameters.csv")

    # Load data
    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    # Extract parameters for Supplier 1
    raw_pipe_length_s1 = float(df_params[df_params['Parameter_Name'] == 'raw_pipe_length_supplier1']['Value'].values[0])
    max_cutting_patterns_s1 = int(df_params[df_params['Parameter_Name'] == 'max_cutting_patterns_supplier1']['Value'].values[0])
    max_cuts_per_pipe_s1 = int(df_params[df_params['Parameter_Name'] == 'max_cuts_per_pipe_supplier1']['Value'].values[0])
    max_leftover_length_s1 = float(df_params[df_params['Parameter_Name'] == 'max_leftover_length_supplier1']['Value'].values[0])
    min_length_s1 = raw_pipe_length_s1 - max_leftover_length_s1
    most_freq_cost_rate_s1 = float(df_params[df_params['Parameter_Name'] == 'most_frequent_pattern_cost_rate_supplier1']['Value'].values[0])
    second_freq_cost_rate_s1 = float(df_params[df_params['Parameter_Name'] == 'second_frequent_pattern_cost_rate_supplier1']['Value'].values[0])
    third_freq_cost_rate_s1 = float(df_params[df_params['Parameter_Name'] == 'third_frequent_pattern_cost_rate_supplier1']['Value'].values[0])
    purchase_cost_per_pipe_s1 = float(df_params[df_params['Parameter_Name'] == 'purchase_cost_per_pipe_supplier1']['Value'].values[0])
    discount_tier1_s1_max_qty = int(df_params[df_params['Parameter_Name'] == 'discount_tier1_supplier1_max_qty']['Value'].values[0])
    fixed_discount_tier2_s1 = float(df_params[df_params['Parameter_Name'] == 'fixed_discount_tier2_supplier1']['Value'].values[0])

    # Extract parameters for Supplier 2
    raw_pipe_length_s2 = float(df_params[df_params['Parameter_Name'] == 'raw_pipe_length_supplier2']['Value'].values[0])
    max_cutting_patterns_s2 = int(df_params[df_params['Parameter_Name'] == 'max_cutting_patterns_supplier2']['Value'].values[0])
    max_cuts_per_pipe_s2 = int(df_params[df_params['Parameter_Name'] == 'max_cuts_per_pipe_supplier2']['Value'].values[0])
    max_leftover_length_s2 = float(df_params[df_params['Parameter_Name'] == 'max_leftover_length_supplier2']['Value'].values[0])
    min_length_s2 = raw_pipe_length_s2 - max_leftover_length_s2
    most_freq_cost_rate_s2 = float(df_params[df_params['Parameter_Name'] == 'most_frequent_pattern_cost_rate_supplier2']['Value'].values[0])
    second_freq_cost_rate_s2 = float(df_params[df_params['Parameter_Name'] == 'second_frequent_pattern_cost_rate_supplier2']['Value'].values[0])
    third_freq_cost_rate_s2 = float(df_params[df_params['Parameter_Name'] == 'third_frequent_pattern_cost_rate_supplier2']['Value'].values[0])
    purchase_cost_per_pipe_s2 = float(df_params[df_params['Parameter_Name'] == 'purchase_cost_per_pipe_supplier2']['Value'].values[0])

    # Extract customer order requirements
    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)

    # Generate cutting patterns for each supplier
    def generate_patterns(raw_pipe_length, max_cuts, max_leftover, min_length):
        patterns = []
        def recursive_pattern_generation(current_pattern, current_length, current_cuts, item_idx):
            if item_idx == n_items:
                if current_length >= min_length and current_length <= raw_pipe_length and current_cuts > 0:
                    patterns.append(tuple(current_pattern))
                return
            
            max_qty = min(
                int((raw_pipe_length - current_length) // lengths[item_idx]),
                max_cuts - current_cuts
            )
            
            for q in range(max_qty + 1):
                recursive_pattern_generation(
                    current_pattern + [q],
                    current_length + q * lengths[item_idx],
                    current_cuts + q,
                    item_idx + 1
                )

        recursive_pattern_generation([], 0, 0, 0)
        return patterns

    patterns_s1 = generate_patterns(raw_pipe_length_s1, max_cuts_per_pipe_s1, max_leftover_length_s1, min_length_s1)
    patterns_s2 = generate_patterns(raw_pipe_length_s2, max_cuts_per_pipe_s2, max_leftover_length_s2, min_length_s2)

    # Create Gurobi model
    model = gp.Model("Pipe_Cutting_Rev")
    model.setParam('OutputFlag', 0)

    # Decision variables
    y_s1 = model.addVars(len(patterns_s1), vtype=GRB.INTEGER, name="y_s1")
    z_s1 = model.addVars(len(patterns_s1), vtype=GRB.BINARY, name="z_s1")
    u_s1 = model.addVars(range(1, max_cutting_patterns_s1 + 1), vtype=GRB.BINARY, name="u_s1")

    y_s2 = model.addVars(len(patterns_s2), vtype=GRB.INTEGER, name="y_s2")
    z_s2 = model.addVars(len(patterns_s2), vtype=GRB.BINARY, name="z_s2")
    u_s2 = model.addVars(range(1, max_cutting_patterns_s2 + 1), vtype=GRB.BINARY, name="u_s2")

    # Binary variable to indicate whether the discount applies for Supplier 1
    delta_s1 = model.addVar(vtype=GRB.BINARY, name="delta_s1")

    # Total number of pipes used from each supplier
    total_pipes_s1 = model.addVar(vtype=GRB.INTEGER, name="total_pipes_s1")
    total_pipes_s2 = model.addVar(vtype=GRB.INTEGER, name="total_pipes_s2")

    # Objective function: minimize total cost
    obj = (
        purchase_cost_per_pipe_s1 * total_pipes_s1 
        - fixed_discount_tier2_s1 * delta_s1
        + purchase_cost_per_pipe_s2 * total_pipes_s2
        + most_freq_cost_rate_s1 * (u_s1[1] + u_s1[2] + u_s1[3]) 
        + second_freq_cost_rate_s1 * (u_s1[2] + u_s1[3]) 
        + third_freq_cost_rate_s1 * u_s1[3]
        + most_freq_cost_rate_s2 * (u_s2[1] + u_s2[2]) 
        + second_freq_cost_rate_s2 * u_s2[2]
    )
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints for demand coverage
    for i in range(n_items):
        lhs_s1 = gp.LinExpr()
        for p in range(len(patterns_s1)):
            lhs_s1 += patterns_s1[p][i] * y_s1[p]
        
        lhs_s2 = gp.LinExpr()
        for p in range(len(patterns_s2)):
            lhs_s2 += patterns_s2[p][i] * y_s2[p]

        model.addConstr(lhs_s1 + lhs_s2 >= demands[i], f"Demand_{i}")

    # Link y and z variables
    M = sum(demands)
    for p in range(len(patterns_s1)):
        model.addConstr(y_s1[p] <= M * z_s1[p], f"Link_y_z_s1_{p}")
    for p in range(len(patterns_s2)):
        model.addConstr(y_s2[p] <= M * z_s2[p], f"Link_y_z_s2_{p}")

    # Count total pipes used from each supplier
    model.addConstr(total_pipes_s1 == gp.quicksum(y_s1), "Total_Pipes_Supplier1")
    model.addConstr(total_pipes_s2 == gp.quicksum(y_s2), "Total_Pipes_Supplier2")

    # Limit number of patterns used per supplier
    model.addConstr(gp.quicksum(z_s1) == gp.quicksum(u_s1), "Pattern_Count_Link_Supplier1")
    model.addConstr(gp.quicksum(z_s2) == gp.quicksum(u_s2), "Pattern_Count_Link_Supplier2")

    # Enforce pattern usage frequency ranking for Supplier 1
    for k in range(1, max_cutting_patterns_s1):
        model.addConstr(u_s1[k] >= u_s1[k+1], f"Pattern_Frequency_Ordering_S1_{k}")

    # Enforce pattern usage frequency ranking for Supplier 2
    for k in range(1, max_cutting_patterns_s2):
        model.addConstr(u_s2[k] >= u_s2[k+1], f"Pattern_Frequency_Ordering_S2_{k}")

    # Enforce maximum number of patterns per supplier
    model.addConstr(gp.quicksum(z_s1) <= max_cutting_patterns_s1, "Max_Patterns_Supplier1")
    model.addConstr(gp.quicksum(z_s2) <= max_cutting_patterns_s2, "Max_Patterns_Supplier2")

    # Nonlinear tiered discount modeling for Supplier 1
    bigM = int(df_params[df_params['Parameter_Name'] == 'bigM_discount']['Value'].values[0])
    model.addConstr(total_pipes_s1 >= discount_tier1_s1_max_qty - bigM * (1 - delta_s1), "Discount_Activation_Lower_Bound")
    model.addConstr(total_pipes_s1 <= discount_tier1_s1_max_qty + bigM * delta_s1, "Discount_Activation_Upper_Bound")

    # Optimize the model
    model.optimize()

    # Output the objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
