import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read time periods and minimum waiters needed
time_periods = []
min_waiters = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        time_periods.append(row["Time"].strip())
        min_waiters.append(int(row["Minimum_Number_of_Waiters_Needed"].strip()))

# Read general parameters
peak = [0] * len(time_periods)
quality = [0] * len(time_periods)
waiter_cost_per_shift = 0
waiter_budget = 0

with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row["Parameter_Name"].strip()
        if param_name.startswith("peak_"):
            period_idx = int(param_name.split("_")[1])
            peak[period_idx] = int(row["Value"].strip())
        elif param_name.startswith("quality_"):
            period_idx = int(param_name.split("_")[1])
            quality[period_idx] = float(row["Value"].strip())
        elif param_name == "waiter_cost_per_shift":
            waiter_cost_per_shift = float(row["Value"].strip())
        elif param_name == "waiter_budget":
            waiter_budget = float(row["Value"].strip())

# Number of periods
n = len(time_periods)  # 6 periods, each 4 hours

# Create model
model = gp.Model("Restaurant_Waiters_Revision")

# Decision variables: x[i] = number of waiters starting at the beginning of period i
x = model.addVars(n, vtype=GRB.INTEGER, name="x", lb=0)

# Objective: minimize total number of waiters
model.setObjective(gp.quicksum(x), GRB.MINIMIZE)

# Constraints: For each period j, the number of waiters working >= min_waiters[j]
# Waiters working in period j are those who started in period j or period (j-1) mod n
for j in range(n):
    prev = (j - 1) % n
    model.addConstr(x[prev] + x[j] >= min_waiters[j], f"Period_{j}_{time_periods[j]}")

# Constraint: Total staffing spend must stay within waiter_budget
model.addConstr(
    waiter_cost_per_shift * gp.quicksum(x) <= waiter_budget,
    "Total_Staffing_Budget"
)

# Solve
model.setParam('OutputFlag', 0)
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
