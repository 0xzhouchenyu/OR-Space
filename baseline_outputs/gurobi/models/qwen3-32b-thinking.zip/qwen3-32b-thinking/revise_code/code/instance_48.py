import os
import csv

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

def main():
    # Define paths to the data files
    script_dir = os.path.dirname(os.path.abspath(__file__))
    table1_path = os.path.join(script_dir, "data", "table_1.csv")
    params_path = os.path.join(script_dir, "data", "general_parameters.csv")

    # Load data from CSV files
    table1 = load_csv_data(table1_path)
    params = load_csv_data(params_path)

    # Parse parameters
    param_dict = {}
    for row in params:
        param_dict[row['Parameter_Name']] = float(row['Value'])

    # Parse table1
    proc_I = table1[0]
    proc_II = table1[1]
    profit_row = table1[2]

    a_I = float(proc_I['Model_A_hours_per_unit'])  # 4
    b_I = float(proc_I['Model_B_hours_per_unit'])  # 6
    cap_I = float(proc_I['Maximum_Weekly_Processing_Capacity'])  # 150

    a_II = float(proc_II['Model_A_hours_per_unit'])  # 3
    b_II = float(proc_II['Model_B_hours_per_unit'])  # 2
    cap_II = float(proc_II['Maximum_Weekly_Processing_Capacity'])  # 70

    profit_A = float(profit_row['Model_A_hours_per_unit'])  # 300
    profit_B = float(profit_row['Model_B_hours_per_unit'])  # 450

    min_profit = param_dict['min_weekly_profit']  # 10000
    min_A = param_dict['min_model_A_units']  # 10
    min_B = param_dict['min_model_B_units']  # 15
    proc_I_hours = param_dict['process_I_hours']  # 150
    max_overtime = param_dict['process_II_max_overtime']  # 30
    red_A = param_dict['model_A_overtime_profit_reduction']  # 20
    red_B = param_dict['model_B_overtime_profit_reduction']  # 25

    # Create Gurobi model
    import gurobipy as gp
    from gurobipy import GRB

    model = gp.Model("Microcomputer_Production")

    # Decision variables
    xA_r = model.addVar(name="xA_r", lb=0)  # Regular production of A
    xA_o = model.addVar(name="xA_o", lb=0)  # Overtime production of A
    xB_r = model.addVar(name="xB_r", lb=0)  # Regular production of B
    xB_o = model.addVar(name="xB_o", lb=0)  # Overtime production of B

    # Objective: Maximize total number of units produced
    total_units = (xA_r + xA_o) + (xB_r + xB_o)
    model.setObjective(total_units, GRB.MAXIMIZE)

    # Constraints
    # Process I exact constraint
    model.addConstr(a_I * (xA_r + xA_o) + b_I * (xB_r + xB_o) == proc_I_hours, "Process_I")

    # Process II regular capacity
    model.addConstr(a_II * xA_r + b_II * xB_r <= cap_II, "Process_II_regular")

    # Process II overtime capacity
    model.addConstr(a_II * xA_o + b_II * xB_o <= max_overtime, "Process_II_overtime")

    # Minimum production requirements
    model.addConstr(xA_r + xA_o >= min_A, "Min_A")
    model.addConstr(xB_r + xB_o >= min_B, "Min_B")

    # Profit constraint (minimum weekly profit)
    total_profit = (profit_A * xA_r + (profit_A - red_A) * xA_o +
                    profit_B * xB_r + (profit_B - red_B) * xB_o)
    model.addConstr(total_profit >= min_profit, "Min_Profit")

    # Optimize the model
    model.setParam('OutputFlag', 0)
    model.optimize()

    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
