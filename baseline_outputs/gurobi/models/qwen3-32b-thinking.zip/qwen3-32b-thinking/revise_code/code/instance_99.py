import os
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    """Load a CSV file and return headers and rows."""
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    return rows

def load_general_parameters():
    """Load general parameters into a dictionary."""
    rows = load_csv("general_parameters.csv")
    params = {}
    for row in rows:
        params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_reliability_table():
    """Load reliability table. Returns dict: {num_spares: [r1, r2, r3]}"""
    rows = load_csv("table_1.csv")
    reliability = {}
    for row in rows:
        n_spares = int(row['Number_of_Spares'])
        r1 = float(row['Component_1_Reliability'])
        r2 = float(row['Component_2_Reliability'])
        r3 = float(row['Component_3_Reliability'])
        reliability[n_spares] = [r1, r2, r3]
    return reliability

def solve():
    # Load data
    params = load_general_parameters()
    reliability = load_reliability_table()
    
    # Extract parameters
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    budget_A = params['total_budget_scenario_A']
    budget_B = params['total_budget_scenario_B']
    weight_A = params['weight_limit_scenario_A']
    weight_B = params['weight_limit_scenario_B']
    
    # Get max number of spares
    max_spares = max(reliability.keys())
    
    # Create Gurobi model
    model = gp.Model("Reliability_Optimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: s_i is the number of spares for component i (i=0,1,2)
    s = []
    for i in range(3):
        s.append(model.addVar(vtype=GRB.INTEGER, name=f"s_{i}", lb=0, ub=max_spares))
    
    # Calculate total cost and weight
    total_cost = sum(s[i] * unit_price[i] for i in range(3))
    total_weight = sum(s[i] * unit_weight[i] for i in range(3))
    
    # Add constraints to satisfy both scenarios' budgets and weights
    model.addConstr(total_cost <= budget_A, "budget_A")
    model.addConstr(total_cost <= budget_B, "budget_B")
    model.addConstr(total_weight <= weight_A, "weight_A")
    model.addConstr(total_weight <= weight_B, "weight_B")
    
    # Define system reliability as product of component reliabilities
    # Since we're maximizing the product, we need to use logarithms to convert it to a sum
    # We'll use auxiliary variables to represent log(reliability) for each component
    
    # First, create a mapping from spare count to log reliability for each component
    log_reliability = [[], [], []]  # log_reliability[component][spares]
    for n in range(max_spares + 1):
        if n not in reliability:
            continue
        log_reliability[0].append(gp.quicksum([gp.log(reliability[n][0])]))
        log_reliability[1].append(gp.quicksum([gp.log(reliability[n][1])]))
        log_reliability[2].append(gp.quicksum([gp.log(reliability[n][2])]))
    
    # Now, define piecewise linear functions for log reliability vs spares
    # We'll use binary variables to select the correct value based on the number of spares
    z = []
    for i in range(3):
        z.append([])
        for n in range(max_spares + 1):
            z[i].append(model.addVar(vtype=GRB.BINARY, name=f"z_{i}_{n}"))
    
    # Ensure exactly one z variable is selected per component
    for i in range(3):
        model.addConstr(gp.quicksum(z[i]) == 1, f"select_one_{i}")
    
    # Link z variables to s variables
    for i in range(3):
        for n in range(max_spares + 1):
            model.addConstr(s[i] == gp.quicksum(n * z[i][n] for n in range(max_spares + 1)), f"link_s_z_{i}_{n}")
    
    # Calculate log reliability for each component
    log_r = []
    for i in range(3):
        log_r.append(model.addVar(lb=-GRB.INFINITY, name=f"log_r_{i}"))
        model.addConstr(log_r[i] == gp.quicksum(log_reliability[i][n] * z[i][n] for n in range(max_spares + 1)), f"log_reliability_{i}")
    
    # System reliability is the product of component reliabilities
    # Since we're maximizing the average of two equal scenario reliabilities,
    # and they are the same for any fixed configuration, we just maximize the single reliability
    system_log_reliability = log_r[0] + log_r[1] + log_r[2]
    model.setObjective(system_log_reliability, GRB.MAXIMIZE)
    
    # Optimize the model
    model.optimize()
    
    # Extract solution
    if model.status == GRB.OPTIMAL:
        s_values = [int(s[i].x + 0.5) for i in range(3)]
        
        # Calculate objective value
        r1 = reliability[s_values[0]][0]
        r2 = reliability[s_values[1]][1]
        r3 = reliability[s_values[2]][2]
        obj_value = 0.5 * r1 * r2 * r3 + 0.5 * r1 * r2 * r3
        
        print(f"Optimal spare parts allocation: Component 1: {s_values[0]}, Component 2: {s_values[1]}, Component 3: {s_values[2]}")
        print(f"Total cost: {s_values[0]*unit_price[0] + s_values[1]*unit_price[1] + s_values[2]*unit_price[2]}")
        print(f"Total weight: {s_values[0]*unit_weight[0] + s_values[1]*unit_weight[1] + s_values[2]*unit_weight[2]}")
        print(f"Component reliabilities: {r1}, {r2}, {r3}")
        print(f"OBJECTIVE_VALUE: {obj_value}")
        print(f"FINAL_OBJ_VALUE: {obj_value}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    import csv
    solve()
