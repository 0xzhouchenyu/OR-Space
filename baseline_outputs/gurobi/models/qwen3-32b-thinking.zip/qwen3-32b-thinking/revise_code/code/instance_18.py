import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Extract relevant parameters
fabric_production_rate = params["fabric_production_rate"]  # meters per hour
min_curtain_fabric_sales = params["min_curtain_fabric_sales"]  # meters
min_clothing_fabric_sales = params["min_clothing_fabric_sales"]  # meters

day_shift_regular_capacity = params["day_shift_regular_capacity"]  # hours
night_shift_regular_capacity = params["night_shift_regular_capacity"]  # hours
day_overtime_limit = params["day_overtime_limit"]  # hours
night_overtime_limit = params["night_overtime_limit"]  # hours
day_overtime_penalty = params["day_overtime_penalty"]  # yuan per hour
night_overtime_penalty = params["night_overtime_penalty"]  # yuan per hour
day_min_utilization_ratio = params["day_min_utilization_ratio"]
night_min_utilization_ratio = params["night_min_utilization_ratio"]

# Convert sales requirements to hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

# Create Gurobi model
model = gp.Model("Textile_Factory_Shift_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
# Regular hours for each fabric type in each shift
x_clothing_day = model.addVar(name="clothing_day", lb=0)
x_curtain_day = model.addVar(name="curtain_day", lb=0)
x_clothing_night = model.addVar(name="clothing_night", lb=0)
x_curtain_night = model.addVar(name="curtain_night", lb=0)

# Overtime hours for each shift
overtime_day = model.addVar(name="overtime_day", lb=0, ub=day_overtime_limit)
overtime_night = model.addVar(name="overtime_night", lb=0, ub=night_overtime_limit)

# Total regular hours in each shift
total_regular_day = x_clothing_day + x_curtain_day
total_regular_night = x_clothing_night + x_curtain_night

# Objective: minimize total overtime cost
model.setObjective(
    day_overtime_penalty * overtime_day + night_overtime_penalty * overtime_night,
    GRB.MINIMIZE
)

# Constraints

# 1. Sales requirements (in hours)
model.addConstr(x_clothing_day + x_clothing_night >= min_clothing_hours, "Clothing_Sales_Requirement")
model.addConstr(x_curtain_day + x_curtain_night >= min_curtain_hours, "Curtain_Sales_Requirement")

# 2. Shift capacity constraints (regular hours)
model.addConstr(total_regular_day <= day_shift_regular_capacity, "Day_Shift_Capacity")
model.addConstr(total_regular_night <= night_shift_regular_capacity, "Night_Shift_Capacity")

# 3. Utilization ratio constraints
model.addConstr(total_regular_day >= day_min_utilization_ratio * day_shift_regular_capacity, "Day_Utilization_Ratio")
model.addConstr(total_regular_night >= night_min_utilization_ratio * night_shift_regular_capacity, "Night_Utilization_Ratio")

# 4. Total production time balance
model.addConstr(
    total_regular_day + overtime_day + total_regular_night + overtime_night == 
    (x_clothing_day + x_curtain_day + x_clothing_night + x_curtain_night) + 
    (overtime_day + overtime_night),
    "Total_Production_Time_Balance"
)

# Optimize the model
model.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
