import os
import csv
import re
import gurobipy as gp
from gurobipy import GRB

def get_data_dir():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def solve():
    data_dir = get_data_dir()
    
    # Read general parameters
    num_customers = 7
    max_route_length_day = 1000
    route_cost_day = 20
    
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'num_customers':
                num_customers = int(row['Value'])
            elif row['Parameter_Name'] == 'max_route_length_day':
                max_route_length_day = float(row['Value'])
            elif row['Parameter_Name'] == 'route_cost_day':
                route_cost_day = float(row['Value'])

    # Read distance matrix
    D = [[0] * num_customers for _ in range(num_customers)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:
            nums = re.findall(r'\d+', line)
            if not nums:
                continue
            row_idx = int(nums[0]) - 1
            for j, val in enumerate(nums[1:]):
                col_idx = row_idx + 1 + j
                if col_idx < num_customers:
                    D[row_idx][col_idx] = int(val)
                    D[col_idx][row_idx] = int(val)

    # Create model
    model = gp.Model("TwoDayTSP")
    model.setParam('OutputFlag', 0)  # Suppress output

    # Sets
    customers = list(range(1, num_customers))  # Customer locations (excluding depot)
    days = [1, 2]
    
    # Decision variables
    y = {}  # y[i,d] = 1 if customer i is assigned to day d
    x = {}  # x[i,j,d] = 1 if we travel from i to j on day d
    u = {}  # Subtour elimination variable for each customer on each day
    z = {}  # z[d] = 1 if day d is used
    
    # Day assignment variables
    for i in customers:
        for d in days:
            y[i, d] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{d}")
    
    # Route variables
    for d in days:
        for i in range(num_customers):
            for j in range(num_customers):
                if i != j:
                    x[i, j, d] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}_{d}")
        
        # Subtour elimination variables for day d
        for i in customers:
            u[i, d] = model.addVar(vtype=GRB.CONTINUOUS, lb=1, ub=num_customers-1, name=f"u_{i}_{d}")
    
    # Day usage indicator
    for d in days:
        z[d] = model.addVar(vtype=GRB.BINARY, name=f"z_{d}")

    # Objective function: minimize total cost (travel distance + fixed costs for used days)
    obj = gp.LinExpr()
    for d in days:
        obj += route_cost_day * z[d]  # Fixed cost for using day d
        for i in range(num_customers):
            for j in range(num_customers):
                if i != j:
                    obj += D[i][j] * x[i, j, d]  # Travel cost on day d
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    # 1. Each customer must be assigned to exactly one day
    for i in customers:
        model.addConstr(gp.quicksum(y[i, d] for d in days) == 1, f"c_assign_{i}")
    
    # 2. If a customer is assigned to a day, it must appear in that day's route
    for d in days:
        for i in customers:
            model.addConstr(y[i, d] <= gp.quicksum(x[i, j, d] for j in range(num_customers) if j != i), f"c_in_out_{i}_{d}")
            model.addConstr(y[i, d] <= gp.quicksum(x[j, i, d] for j in range(num_custometers) if j != i), f"c_in_out2_{i}_{d}")
    
    # 3. Flow conservation constraints for each day
    for d in days:
        for i in range(num_customers):
            if i == 0:  # Depot
                model.addConstr(gp.quicksum(x[0, j, d] for j in range(1, num_customers)) == 1, f"c_flow_start_{d}")
                model.addConstr(gp.quicksum(x[j, 0, d] for j in range(1, num_customers)) == 1, f"c_flow_end_{d}")
            else:  # Customers
                model.addConstr(gp.quicksum(x[i, j, d] for j in range(num_customers) if j != i) 
                               == gp.quicksum(x[j, i, d] for j in range(num_customers) if j != i), 
                               f"c_flow_balance_{i}_{d}")
    
    # 4. Subtour elimination constraints for each day
    for d in days:
        for i in customers:
            for j in customers:
                if i != j:
                    model.addConstr(u[i, d] - u[j, d] + (num_customers - 1) * x[i, j, d] <= num_customers - 2, 
                                   f"c_subtour_{i}_{j}_{d}")
    
    # 5. Daily route length constraint
    for d in days:
        route_length = gp.LinExpr()
        for i in range(num_customers):
            for j in range(num_customers):
                if i != j:
                    route_length += D[i][j] * x[i, j, d]
        model.addConstr(route_length <= max_route_length_day * z[d], f"c_max_route_length_{d}")
    
    # 6. Link day usage to customer assignments
    for d in days:
        model.addConstr(gp.quicksum(y[i, d] for i in customers) <= (num_customers - 1) * z[d], f"c_day_usage_{d}")
    
    # Optimize the model
    model.optimize()

    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
