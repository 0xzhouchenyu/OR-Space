import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read costs from table_1.csv
    costs_budget = {}
    costs_balanced = {}
    costs_premium = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row["Child"].strip()
            costs_budget[child] = float(row["Cost_budget"].strip())
            costs_balanced[child] = float(row["Cost_balanced"].strip())
            costs_premium[child] = float(row["Cost_premium"].strip())
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    
    max_children = int(params["max_children"])
    min_children = int(params["min_children"])
    min_children_per_mode = int(params["min_children_per_mode"])
    fairness_penalty = float(params["fairness_penalty"])
    max_total_cost = float(params["max_total_cost"])
    
    children = list(costs_budget.keys())
    
    # Create Gurobi model
    model = gp.Model("ZhangFamilyTrip")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    x = {child: model.addVar(vtype=GRB.BINARY, name=f"x_{child}") for child in children}  # Child selection
    y = {
        "budget": model.addVar(vtype=GRB.BINARY, name="y_budget"),
        "balanced": model.addVar(vtype=GRB.BINARY, name="y_balanced"),
        "premium": model.addVar(vtype=GRB.BINARY, name="y_premium")
    }  # Mode selection
    
    # Enforce exactly one mode is selected
    model.addConstr(y["budget"] + y["balanced"] + y["premium"] == 1, "One_Mode_Selected")
    
    # Ginny must go
    model.addConstr(x["Ginny"] == 1, "Ginny_must_go")
    
    # Group size constraints
    model.addConstr(gp.quicksum(x[child] for child in children) <= max_children, "Max_children")
    model.addConstr(gp.quicksum(x[child] for child in children) >= min_children, "Min_children")
    
    # Minimum children per mode constraints
    for mode in ["balanced", "premium"]:
        model.addConstr(
            gp.quicksum(x[child] for child in children) >= min_children_per_mode * y[mode],
            f"Min_Children_for_{mode}"
        )
    
    # Compatibility constraints
    model.addConstr(x["Harry"] + x["Fred"] <= 1, "Harry_no_Fred")
    model.addConstr(x["Harry"] + x["George"] <= 1, "Harry_no_George")
    model.addConstr(x["George"] <= x["Fred"], "George_requires_Fred")
    model.addConstr(x["George"] <= x["Hermione"], "George_requires_Hermione")
    
    # Calculate cost based on selected mode
    cost = model.addVar(name="Total_Cost")
    model.addConstr(
        cost == 
        y["budget"] * gp.quicksum(costs_budget[child] * x[child] for child in children) +
        y["balanced"] * gp.quicksum(costs_balanced[child] * x[child] for child in children) +
        y["premium"] * gp.quicksum(costs_premium[child] * x[child] for child in children),
        "Calculate_Total_Cost"
    )
    
    # Budget constraint
    model.addConstr(cost <= max_total_cost, "Budget_Constraint")
    
    # Fairness penalty calculation
    # For each child, calculate their cost under the selected mode
    child_costs = {child: model.addVar(name=f"cost_{child}") for child in children}
    for child in children:
        model.addConstr(
            child_costs[child] == 
            y["budget"] * costs_budget[child] * x[child] +
            y["balanced"] * costs_balanced[child] * x[child] +
            y["premium"] * costs_premium[child] * x[child],
            f"Child_Cost_{child}"
        )
    
    # Max and min child costs
    max_child_cost = model.addVar(name="Max_Child_Cost")
    min_child_cost = model.addVar(name="Min_Child_Cost")
    
    # Set up constraints to find max and min child costs
    for child in children:
        model.addConstr(max_child_cost >= child_costs[child], f"Max_Cost_{child}")
        model.addConstr(min_child_cost <= child_costs[child], f"Min_Cost_{child}")
    
    # Objective function: total cost + fairness penalty * (max - min)
    obj = cost + fairness_penalty * (max_child_cost - min_child_cost)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Optimize
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
