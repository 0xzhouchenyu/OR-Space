import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Get the data directory path
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = row["Value"].strip()
    
    max_children_per_day = int(params["max_children_trip"])
    min_children_per_day = int(params["min_children_trip"])
    max_distinct_children = int(params["max_distinct_children_trip"])
    total_cost_budget = int(params["total_cost_budget"])
    bonus_saving = int(params["bonus_saving"])
    min_bob_days = int(params["min_bob_days"])
    
    # Read child costs and constraints
    children = []
    costs = {}
    availability = {}  # day 1 or day 2 or both
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Child"].strip()
            cost = int(row["Cost"].strip())
            constraint = row["Relationship_Constraint"].strip()
            
            children.append(name)
            costs[name] = cost
            
            # Determine availability based on constraints
            if "Only available on day 1" in constraint:
                availability[name] = [1]
            elif "Only available on day 2" in constraint:
                availability[name] = [2]
            else:
                availability[name] = [1, 2]
    
    # Create a Gurobi model
    model = gp.Model("FamilyTripTwoDay")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables: x[child][day] = 1 if child is selected on that day, 0 otherwise
    x = {}
    for child in children:
        for day in [1, 2]:
            if day in availability[child]:
                x[(child, day)] = model.addVar(vtype=GRB.BINARY, name=f"x_{child}_day{day}")
            else:
                x[(child, day)] = 0  # Not available on this day
    
    # Binary variable to indicate if a child is present on both days (for bonus saving)
    both_days = {}
    for child in children:
        both_days[child] = model.addVar(vtype=GRB.BINARY, name=f"both_days_{child}")
    
    # Objective: minimize total cost minus bonus savings for children attending both days
    total_cost = gp.LinExpr()
    for child in children:
        for day in [1, 2]:
            total_cost += costs[child] * x[(child, day)]
    
    total_bonus_saving = gp.LinExpr()
    for child in children:
        total_bonus_saving += bonus_saving * both_days[child]
    
    model.setObjective(total_cost - total_bonus_saving, GRB.MINIMIZE)
    
    # Constraints
    
    # Day 1: minimum and maximum number of children
    model.addConstr(gp.quicksum(x[(child, 1)] for child in children) >= min_children_per_day, "MinChildrenDay1")
    model.addConstr(gp.quicksum(x[(child, 1)] for child in children) <= max_children_per_day, "MaxChildrenDay1")
    
    # Day 2: minimum and maximum number of children
    model.addConstr(gp.quicksum(x[(child, 2)] for child in children) >= min_children_per_day, "MinChildrenDay2")
    model.addConstr(gp.quicksum(x[(child, 2)] for child in children) <= max_children_per_day, "MaxChildrenDay2")
    
    # Bob must attend at least min_bob_days
    model.addConstr(gp.quicksum(x[("Bob", day)] for day in [1, 2]) >= min_bob_days, "MinBobDays")
    
    # Alice and Diana cannot be together on the same day
    for day in [1, 2]:
        model.addConstr(x[("Alice", day)] + x[("Diana", day)] <= 1, f"AliceDianaConflictDay{day}")
    
    # Bob and Charlie cannot be together on the same day
    for day in [1, 2]:
        model.addConstr(x[("Bob", day)] + x[("Charlie", day)] <= 1, f"BobCharlieConflictDay{day}")
    
    # Charlie must be accompanied by Diana on the same day
    for day in [1, 2]:
        model.addConstr(x[("Charlie", day)] <= x[("Diana", day)], f"CharlieRequiresDianaDay{day}")
    
    # Diana must be accompanied by Ella on the same day
    for day in [1, 2]:
        model.addConstr(x[("Diana", day)] <= x[("Ella", day)], f"DianaRequiresEllaDay{day}")
    
    # Max distinct children over both days
    model.addConstr(gp.quicksum(gp.quicksum(x[(child, day)] for day in [1, 2]) > 0 for child in children) <= max_distinct_children, "MaxDistinctChildren")
    
    # Total cost budget constraint
    model.addConstr(total_cost - total_bonus_saving <= total_cost_budget, "TotalCostBudget")
    
    # Link both_days variable to attendance on both days
    for child in children:
        model.addConstr(both_days[child] <= x[(child, 1)])
        model.addConstr(both_days[child] <= x[(child, 2)])
        model.addConstr(both_days[child] >= x[(child, 1)] + x[(child, 2)] - 1)
    
    # Optimize the model
    model.optimize()
    
    # Print solution details
    if model.status == GRB.OPTIMAL:
        print("Optimal solution found:")
        for day in [1, 2]:
            print(f"\nDay {day}:")
            for child in children:
                if x[(child, day)].x > 0.5:
                    print(f"  {child} (cost={costs[child]})")
        
        # Print objective value
        final_obj_value = model.objVal
        print(f"FINAL_OBJ_VALUE: {final_obj_value}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
