import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load demand forecast
demand = {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for i, row in enumerate(reader):
        demand[i] = float(row["Demand_Forecast"])

T = len(demand)  # 6 months

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

W0 = int(params["initial_workforce"])
I0 = params["initial_inventory"]
sp = params["sales_price"]
rmc = params["raw_material_cost"]
oc = params["outsourcing_cost"]
hc = params["inventory_holding_cost"]
bc = params["backorder_cost"]
lr = params["labor_requirement"]
rh = params["regular_labor_hours"]
rw = params["regular_wage"]
otl = params["overtime_hours_limit"]
ow = params["overtime_wage"]
hire_cost = params["hiring_cost"]
fire_cost = params["firing_cost"]
term_inv = params["terminal_inventory"]
term_bo = params["terminal_backorders"]
contract_min_units = params["contract_min_units"]
contract_bigM = params["contract_bigM"]

# Create model
model = gp.Model("FoldableTableProduction")
model.setParam('OutputFlag', 0)

# Decision variables
W = model.addVars(T, name="Workforce", lb=0)
H = model.addVars(T, name="Hired", lb=0)
F = model.addVars(T, name="Fired", lb=0)
P = model.addVars(T, name="InHouseProduction", lb=0)
OT_total = model.addVars(T, name="OvertimeTotal", lb=0)
O = model.addVars(T, name="Outsourced", lb=0)
Inv = model.addVars(T, name="Inventory", lb=0)
B = model.addVars(T, name="Backorders", lb=0)

# Binary indicators for contract months (April to June: t=3,4,5)
y = model.addVars(3, vtype=GRB.BINARY, name="ContractBinary")

# Regular-time production capacity (without overtime)
RegularCapacity = model.addVars(3, name="RegularCapacity", lb=0)

# Contract-qualified production (must be at least contract_min_units and <= regular capacity)
CQ = model.addVars(3, name="ContractQualified", lb=0)

# Objective function
revenue = sp * sum(demand[t] for t in range(T))

material_cost = rmc * sum(P[t] for t in range(T))
outsource_cost = oc * sum(O[t] for t in range(T))
holding_cost = hc * sum(Inv[t] for t in range(T))
backorder_cost_total = bc * sum(B[t] for t in range(T))
regular_labor_cost = rw * rh * sum(W[t] for t in range(T))
overtime_cost = ow * sum(OT_total[t] for t in range(T))
hiring_cost_total = hire_cost * sum(H[t] for t in range(T))
firing_cost_total = fire_cost * sum(F[t] for t in range(T))

total_cost = (
    material_cost + outsource_cost + holding_cost + backorder_cost_total +
    regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total
)

model.setObjective(revenue - total_cost, GRB.MAXIMIZE)

# Constraints
for t in range(T):
    # Workforce balance
    if t == 0:
        model.addConstr(W[t] == W0 + H[t] - F[t], name=f"WorkforceBalance_{t}")
    else:
        model.addConstr(W[t] == W[t-1] + H[t] - F[t], name=f"WorkforceBalance_{t}")

    # Production limited by total labor hours (regular + overtime)
    model.addConstr(P[t] * lr <= W[t] * rh + OT_total[t], name=f"ProductionCapacity_{t}")

    # Overtime limit
    model.addConstr(OT_total[t] <= W[t] * otl, name=f"OvertimeLimit_{t}")

    # Inventory balance: Inv[t] - B[t] = (Inv[t-1] - B[t-1]) + P[t] + O[t] - demand[t]
    prev_inv = I0 if t == 0 else Inv[t-1]
    prev_b = 0 if t == 0 else B[t-1]
    model.addConstr(
        Inv[t] - B[t] == prev_inv - prev_b + P[t] + O[t] - demand[t],
        name=f"InventoryBalance_{t}"
    )

# Terminal conditions
model.addConstr(Inv[T-1] >= term_inv, name="TerminalInventory")
model.addConstr(B[T-1] <= term_bo, name="TerminalBackorders")

# Contract constraints for April to June (t=3,4,5)
for i in range(3):  # i corresponds to t=3,4,5
    t = i + 3
    
    # Regular-time capacity is workforce * regular hours / labor requirement
    model.addConstr(RegularCapacity[i] == W[t] * rh / lr, name=f"RegularCapacity_{t}")
    
    # Contract-qualified production must be at least contract_min_units if the month is a contract month
    model.addConstr(CQ[i] >= contract_min_units * y[i], name=f"ContractMin_{t}")
    
    # Contract-qualified production cannot exceed regular-time capacity
    model.addConstr(CQ[i] <= RegularCapacity[i], name=f"ContractCapacity_{t}")
    
    # Contract-qualified production cannot exceed demand plus backorders from previous month
    prev_b = B[t-1] if t > 0 else 0
    model.addConstr(CQ[i] <= demand[t] + prev_b, name=f"ContractDemand_{t}")
    
    # If it's a contract month, then CQ must be at least contract_min_units
    model.addConstr(CQ[i] >= contract_min_units * y[i], name=f"ContractMinEnforce_{t}")
    
    # Link CQ with in-house production using big-M constraint
    model.addConstr(CQ[i] <= P[t], name=f"ContractLink1_{t}")
    model.addConstr(CQ[i] >= P[t] - contract_bigM * (1 - y[i]), name=f"ContractLink2_{t}")

# Optimize
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
