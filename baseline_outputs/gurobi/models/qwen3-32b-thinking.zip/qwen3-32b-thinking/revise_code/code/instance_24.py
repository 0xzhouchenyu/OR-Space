import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    product_units = params['product_units']
    truck_pollution = params['truck_pollution']
    van_pollution = params['van_pollution']
    motorcycle_pollution = params['motorcycle_pollution']
    ev_pollution = params['electric_vehicle_pollution']
    max_total_pollution = params['max_total_pollution']
    min_truck_trips = params['min_truck_trips']
    truck_capacity = params['truck_capacity']
    van_capacity = params['van_capacity']
    motorcycle_capacity = params['motorcycle_capacity']
    ev_capacity = params['electric_vehicle_capacity']
    sales_point_share_sp1 = params['sales_point_share_sp1']
    sales_point_share_sp2 = params['sales_point_share_sp2']
    sales_point_share_sp3 = params['sales_point_share_sp3']
    min_truck_share_sp1 = params['min_truck_share_sp1']
    min_truck_share_sp2 = params['min_truck_share_sp2']
    min_truck_share_sp3 = params['min_truck_share_sp3']
    M_truck_sp_day = params['M_truck_sp_day']
    M_ev_sp_day = params['M_ev_sp_day']
    M_van_sp_day = params['M_van_sp_day']
    M_moto_sp_day = params['M_moto_sp_day']
    
    # Calculate demand per sales point
    sp1_demand = product_units * sales_point_share_sp1
    sp2_demand = product_units * sales_point_share_sp2
    sp3_demand = product_units * sales_point_share_sp3
    
    # Create model
    model = gp.Model("Transportation_Pollution_Minimization")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Define sets
    sales_points = ['sp1', 'sp2', 'sp3']
    days = [1, 2, 3]
    vehicle_types = ['truck', 'ev', 'van', 'moto']
    
    # Decision variables: number of trips for each vehicle type at each sales point and day
    trips = {}
    for sp in sales_points:
        for d in days:
            for v in vehicle_types:
                var_name = f"{v}_trips_{sp}_day{d}"
                trips[(sp, d, v)] = model.addVar(vtype=GRB.INTEGER, name=var_name, lb=0)
    
    # Binary variables to enforce the service discipline constraint
    is_truck_ev_family = {}
    for sp in sales_points:
        for d in days:
            var_name = f"truck_ev_family_{sp}_day{d}"
            is_truck_ev_family[(sp, d)] = model.addVar(vtype=GRB.BINARY, name=var_name)
    
    # Objective: minimize total pollution
    obj_expr = 0
    for sp in sales_points:
        for d in days:
            obj_expr += truck_pollution * trips[(sp, d, 'truck')]
            obj_expr += van_pollution * trips[(sp, d, 'van')]
            obj_expr += motorcycle_pollution * trips[(sp, d, 'moto')]
            obj_expr += ev_pollution * trips[(sp, d, 'ev')]
    
    model.setObjective(obj_expr, GRB.MINIMIZE)
    
    # Constraint: all products must be delivered (per sales point)
    for sp in sales_points:
        if sp == 'sp1':
            demand = sp1_demand
        elif sp == 'sp2':
            demand = sp2_demand
        else:  # sp3
            demand = sp3_demand
        
        expr = 0
        for d in days:
            expr += truck_capacity * trips[(sp, d, 'truck')]
            expr += van_capacity * trips[(sp, d, 'van')]
            expr += motorcycle_capacity * trips[(sp, d, 'moto')]
            expr += ev_capacity * trips[(sp, d, 'ev')]
        
        model.addConstr(expr >= demand, f"Demand_{sp}")
    
    # Constraint: total pollution must not exceed maximum
    total_pollution_expr = 0
    for sp in sales_points:
        for d in days:
            total_pollution_expr += truck_pollution * trips[(sp, d, 'truck')]
            total_pollution_expr += van_pollution * trips[(sp, d, 'van')]
            total_pollution_expr += motorcycle_pollution * trips[(sp, d, 'moto')]
            total_pollution_expr += ev_pollution * trips[(sp, d, 'ev')]
    
    model.addConstr(total_pollution_expr <= max_total_pollution, "Max_Pollution")
    
    # Constraint: minimum total number of truck trips across all sales points and days
    total_truck_trips_expr = 0
    for sp in sales_points:
        for d in days:
            total_truck_trips_expr += trips[(sp, d, 'truck')]
    
    model.addConstr(total_truck_trips_expr >= min_truck_trips, "Min_Truck_Trips")
    
    # Constraint: service discipline - on a given sales point-day, deliveries must come from either 
    # the truck/electric-vehicle family or the van/motorcycle family
    for sp in sales_points:
        for d in days:
            # If using truck or EV, then don't use van or motorcycle
            model.addConstr(trips[(sp, d, 'van')] <= (1 - is_truck_ev_family[(sp, d)]) * M_van_sp_day, 
                            f"Van_Exclusion_{sp}_day{d}")
            model.addConstr(trips[(sp, d, 'moto')] <= (1 - is_truck_ev_family[(sp, d)]) * M_moto_sp_day, 
                            f"Motorcycle_Exclusion_{sp}_day{d}")
            
            # If using van or motorcycle, then don't use truck or EV
            model.addConstr(trips[(sp, d, 'truck')] <= is_truck_ev_family[(sp, d)] * M_truck_sp_day, 
                            f"Truck_Inclusion_{sp}_day{d}")
            model.addConstr(trips[(sp, d, 'ev')] <= is_truck_ev_family[(sp, d)] * M_ev_sp_day, 
                            f"EV_Inclusion_{sp}_day{d}")
    
    # Constraint: minimum truck share for each sales point
    for sp in sales_points:
        if sp == 'sp1':
            min_truck_share = min_truck_share_sp1
        elif sp == 'sp2':
            min_truck_share = min_truck_share_sp2
        else:  # sp3
            min_truck_share = min_truck_share_sp3
        
        total_truck_trips_sp = 0
        total_trips_sp = 0
        for d in days:
            total_truck_trips_sp += trips[(sp, d, 'truck')]
            total_trips_sp += trips[(sp, d, 'truck')] + trips[(sp, d, 'van')] + trips[(sp, d, 'moto')] + trips[(sp, d, 'ev')]
        
        # To avoid division by zero, we add a small epsilon to the denominator
        epsilon = 1e-6
        model.addConstr((total_truck_trips_sp) >= min_truck_share * (total_trips_sp + epsilon), 
                        f"Min_Truck_Share_{sp}")
    
    # Optimize the model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
