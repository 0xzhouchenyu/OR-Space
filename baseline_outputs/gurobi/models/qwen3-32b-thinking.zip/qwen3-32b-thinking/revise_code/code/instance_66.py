import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read table_1.csv
toys = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            "type": row["Toy_Type"],
            "labor": float(row["Manufacturing_Labor_Hours"]),
            "inspection": float(row["Inspection_Hours"]),
            "profit": float(row["Profit_Per_Unit"])
        })

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

# Extract parameters
available_labor_period1 = params["available_labor_hours_period1"]
available_labor_period2 = params["available_labor_hours_period2"]
available_inspection_period1 = params["available_inspection_hours_period1"]
available_inspection_period2 = params["available_inspection_hours_period2"]

max_demand_period1 = {
    "High-End": params["max_demand_high_end_period1"],
    "Mid-Range": params["max_demand_mid_range_period1"],
    "Low-End": params["max_demand_low_end_period1"]
}

max_demand_period2 = {
    "High-End": params["max_demand_high_end_period2"],
    "Mid-Range": params["max_demand_mid_range_period2"],
    "Low-End": params["max_demand_low_end_period2"]
}

overtime_labor_cap = params["overtime_labor_cap"]
overtime_labor_cost = params["overtime_labor_cost"]
period1_overtime_fatigue_threshold = params["period1_overtime_fatigue_threshold"]
period2_labor_recovery_loss = params["period2_labor_recovery_loss"]
overtime_review_threshold = params["overtime_review_threshold"]
seasonal_safety_review_fee = params["seasonal_safety_review_fee"]

# Build optimization model
model = gp.Model("RevisedToyProduction")
model.setParam('OutputFlag', 0)

# Decision variables
x_period1 = {}
x_period2 = {}
for toy in toys:
    x_period1[toy["type"]] = model.addVar(
        name=f"x_{toy['type']}_P1", lb=0, vtype=GRB.CONTINUOUS
    )
    x_period2[toy["type"]] = model.addVar(
        name=f"x_{toy['type']}_P2", lb=0, vtype=GRB.CONTINUOUS
    )

# Overtime labor variables
overtime_period1 = model.addVar(name="Overtime_P1", lb=0, ub=overtime_labor_cap, vtype=GRB.CONTINUOUS)
overtime_period2 = model.addVar(name="Overtime_P2", lb=0, ub=overtime_labor_cap, vtype=GRB.CONTINUOUS)

# Total overtime
total_overtime = model.addVar(name="Total_Overtime", lb=0, vtype=GRB.CONTINUOUS)
model.addConstr(total_overtime == overtime_period1 + overtime_period2, name="Total_Overtime_Calculation")

# Objective: maximize profit - overtime cost - safety review fee if applicable
profit = sum(toy["profit"] * (x_period1[toy["type"]] + x_period2[toy["type"]]) for toy in toys)
overtime_cost = overtime_labor_cost * (overtime_period1 + overtime_period2)
safety_review_cost = seasonal_safety_review_fee * gp.if_then(total_overtime > overtime_review_threshold, 1, 0)

model.setObjective(profit - overtime_cost - safety_review_cost, GRB.MAXIMIZE)

# Constraints
# Period 1 labor hours (regular + overtime)
model.addConstr(
    gp.quicksum(toy["labor"] * x_period1[toy["type"]] for toy in toys) <= available_labor_period1 + overtime_period1,
    name="Period1_Labor"
)

# Period 2 labor hours (regular + overtime), with fatigue carryover
fatigue_carryover_effect = period2_labor_recovery_loss * gp.if_then(overtime_period1 > period1_overtime_fatigue_threshold, 1, 0)
model.addConstr(
    gp.quicksum(toy["labor"] * x_period2[toy["type"]] for toy in toys) <= available_labor_period2 + overtime_period2 - fatigue_carryover_effect,
    name="Period2_Labor"
)

# Inspection hours per period
model.addConstr(
    gp.quicksum(toy["inspection"] * x_period1[toy["type"]] for toy in toys) <= available_inspection_period1,
    name="Period1_Inspection"
)
model.addConstr(
    gp.quicksum(toy["inspection"] * x_period2[toy["type"]] for toy in toys) <= available_inspection_period2,
    name="Period2_Inspection"
)

# Demand constraints per period
for toy in toys:
    model.addConstr(x_period1[toy["type"]] <= max_demand_period1[toy["type"]], name=f"Period1_Demand_{toy['type']}")
    model.addConstr(x_period2[toy["type"]] <= max_demand_period2[toy["type"]], name=f"Period2_Demand_{toy['type']}")

# Optimize the model
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("No optimal solution found.")
