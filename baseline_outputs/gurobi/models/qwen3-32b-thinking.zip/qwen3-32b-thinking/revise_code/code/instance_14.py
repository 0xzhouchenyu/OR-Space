import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load food items
    items = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })
    
    # Load parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    min_vegetable_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_daily_calories = params['min_daily_calories']
    max_daily_calories = params['max_daily_calories']
    max_daily_sodium = params['max_daily_sodium']
    
    num_items = len(items)
    max_units = int(total_weight_limit // 100)  # Max purchase units per item
    max_meal_units = 3  # Each meal is exactly 300g (3 * 100g units)

    # Create Gurobi model
    model = gp.Model("dinner_lunch_planning")
    model.setParam('OutputFlag', 0)  # Suppress output
    
    # Decision variables
    purchase_units = model.addVars(num_items, vtype=GRB.INTEGER, name="purchase_units", lb=0)
    lunch_units = model.addVars(num_items, vtype=GRB.INTEGER, name="lunch_units", lb=0)
    dinner_units = model.addVars(num_items, vtype=GRB.INTEGER, name="dinner_units", lb=0)
    select_item = model.addVars(num_items, vtype=GRB.BINARY, name="select_item")
    
    # Binary indicators for vegetable selection in each meal
    veg_indices = [i for i in range(num_items) if items[i]['type'] == 'Vegetable']
    lunch_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg_selected")
    dinner_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg_selected")
    
    # Objective: maximize total protein from both meals
    model.setObjective(gp.quicksum(items[i]['protein'] * (lunch_units[i] + dinner_units[i]) for i in range(num_items)), GRB.MAXIMIZE)
    
    # Constraints
    # 1. Total daily budget constraint
    model.addConstr(gp.quicksum(items[i]['cost'] * purchase_units[i] for i in range(num_items)) <= max_budget, "budget")
    
    # 2. Total weight limit constraint
    model.addConstr(gp.quicksum(purchase_units[i] for i in range(num_items)) <= total_weight_limit / 100, "weight_limit")
    
    # 3. Per-meal weight balance constraints
    model.addConstr(gp.quicksum(lunch_units[i] for i in range(num_items)) == 3, "lunch_weight")
    model.addConstr(gp.quicksum(dinner_units[i] for i in range(num_items)) == 3, "dinner_weight")
    
    # 4. Daily calorie intake bounds
    model.addConstr(gp.quicksum(items[i]['calories'] * (lunch_units[i] + dinner_units[i]) for i in range(num_items)) >= min_daily_calories, "min_calories")
    model.addConstr(gp.quicksum(items[i]['calories'] * (lunch_units[i] + dinner_units[i]) for i in range(num_items)) <= max_daily_calories, "max_calories")
    
    # 5. Daily sodium intake bound
    model.addConstr(gp.quicksum(items[i]['sodium'] * (lunch_units[i] + dinner_units[i]) for i in range(num_items)) <= max_daily_sodium, "max_sodium")
    
    # 6. Purchase selection linkage constraints
    for i in range(num_items):
        model.addConstr(purchase_units[i] <= max_units * select_item[i], f"purchase_link_{i}")
        model.addConstr(lunch_units[i] <= max_meal_units * select_item[i], f"lunch_link_{i}")
        model.addConstr(dinner_units[i] <= max_meal_units * select_item[i], f"dinner_link_{i}")
        model.addConstr(purchase_units[i] >= lunch_units[i] + dinner_units[i], f"purchase_min_{i}")
    
    # 7. Minimum number of vegetable types per meal
    model.addConstr(gp.quicksum(lunch_veg_selected[i] for i in veg_indices) >= min_vegetable_types, "min_veg_lunch")
    model.addConstr(gp.quicksum(dinner_veg_selected[i] for i in veg_indices) >= min_vegetable_types, "min_veg_dinner")
    
    # Linking binary indicators to actual usage
    for i in veg_indices:
        model.addConstr(lunch_units[i] >= lunch_veg_selected[i], f"lunch_veg_lower_{i}")
        model.addConstr(dinner_units[i] >= dinner_veg_selected[i], f"dinner_veg_lower_{i}")
        model.addConstr(lunch_units[i] <= max_meal_units * lunch_veg_selected[i], f"lunch_veg_upper_{i}")
        model.addConstr(dinner_units[i] <= max_meal_units * dinner_veg_selected[i], f"dinner_veg_upper_{i}")
    
    # Optimize the model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
