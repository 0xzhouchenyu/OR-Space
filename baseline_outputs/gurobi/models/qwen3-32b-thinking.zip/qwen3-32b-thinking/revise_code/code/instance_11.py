import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Read CSVs
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    # Parse Table 1
    row_a = df1[df1["Type"] == "Type_A"].iloc[0]
    row_b = df1[df1["Type"] == "Type_B"].iloc[0]
    row_cap = df1[df1["Type"] == "Max_weekly_capacity"].iloc[0]
    row_cost = df1[df1["Type"] == "Process_cost_Yuan_per_hour"].iloc[0]

    mfg_a = float(row_a["Manufacturing_hours_per_unit"])
    asm_a = float(row_a["Assembly_hours_per_unit"])
    price_a = float(row_a["Selling_Price_Yuan_per_unit"])

    mfg_b = float(row_b["Manufacturing_hours_per_unit"])
    asm_b = float(row_b["Assembly_hours_per_unit"])
    price_b = float(row_b["Selling_Price_Yuan_per_unit"])

    cap_mfg = float(row_cap["Manufacturing_hours_per_unit"])
    cap_asm = float(row_cap["Assembly_hours_per_unit"])
    cap_insp = float(row_cap["Inspection_hours_per_unit"])

    cost_mfg = float(row_cost["Manufacturing_hours_per_unit"])
    cost_asm = float(row_cost["Assembly_hours_per_unit"])

    # Parse Parameters
    min_profit = float(df_params[df_params["Parameter_Name"] == "min_weekly_profit"]["Value"].iloc[0])
    min_a = float(df_params[df_params["Parameter_Name"] == "min_type_a_production"]["Value"].iloc[0])
    insp_a_M = float(df_params[df_params["Parameter_Name"] == "insp_a_M"]["Value"].iloc[0])
    insp_b_M = float(df_params[df_params["Parameter_Name"] == "insp_b_M"]["Value"].iloc[0])
    insp_a_E = float(df_params[df_params["Parameter_Name"] == "insp_a_E"]["Value"].iloc[0])
    insp_b_E = float(df_params[df_params["Parameter_Name"] == "insp_b_E"]["Value"].iloc[0])
    cap_ext = float(df_params[df_params["Parameter_Name"] == "cap_ext"]["Value"].iloc[0])
    cost_insp_M = float(df_params[df_params["Parameter_Name"] == "cost_insp_M"]["Value"].iloc[0])
    cost_insp_E = float(df_params[df_params["Parameter_Name"] == "cost_insp_E"]["Value"].iloc[0])
    cost_ext = float(df_params[df_params["Parameter_Name"] == "cost_ext"]["Value"].iloc[0])
    mode_fee_M = float(df_params[df_params["Parameter_Name"] == "mode_fee_M"]["Value"].iloc[0])
    mode_fee_E = float(df_params[df_params["Parameter_Name"] == "mode_fee_E"]["Value"].iloc[0])
    risk_penalty_M = float(df_params[df_params["Parameter_Name"] == "risk_penalty_M"]["Value"].iloc[0])
    cost_insp_weight = float(df_params[df_params["Parameter_Name"] == "cost_insp_weight"]["Value"].iloc[0])
    planning_horizon_weeks = int(df_params[df_params["Parameter_Name"] == "planning_horizon_weeks"]["Value"].iloc[0])
    idle_tolerance = float(df_params[df_params["Parameter_Name"] == "idle_tolerance"]["Value"].iloc[0])

    # Calculate unit profits
    cost_a = mfg_a * cost_mfg + asm_a * cost_asm
    profit_a = price_a - cost_a

    cost_b = mfg_b * cost_mfg + asm_b * cost_asm
    profit_b = price_b - cost_b

    # Create model
    model = gp.Model("TwoWeekMotorcycleProduction")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x_A = model.addVars(planning_horizon_weeks, vtype=GRB.INTEGER, name="x_A", lb=min_a)
    x_B = model.addVars(planning_horizon_weeks, vtype=GRB.INTEGER, name="x_B", lb=0)
    mode_M = model.addVars(planning_horizon_weeks, vtype=GRB.BINARY, name="mode_M")
    mode_E = model.addVars(planning_horizon_weeks, vtype=GRB.BINARY, name="mode_E")
    ext_insp = model.addVars(planning_horizon_weeks, vtype=GRB.CONTINUOUS, name="ext_insp", lb=0)

    # Constraints: Each week must use one inspection protocol
    for t in range(planning_horizon_weeks):
        model.addConstr(mode_M[t] + mode_E[t] == 1, f"Single_Mode_Selection_{t}")

    # Manufacturing and assembly capacity constraints (weekly)
    for t in range(planning_horizon_weeks):
        model.addConstr(mfg_a * x_A[t] + mfg_b * x_B[t] <= cap_mfg, f"Manufacturing_Capacity_{t}")
        model.addConstr(asm_a * x_A[t] + asm_b * x_B[t] <= cap_asm, f"Assembly_Capacity_{t}")

    # Inspection constraints (weekly)
    for t in range(planning_horizon_weeks):
        if mode_M[t]:
            model.addConstr(
                insp_a_M * x_A[t] + insp_b_M * x_B[t] + ext_insp[t] <= cap_insp,
                f"Insp_Capacity_M_{t}"
            )
        else:
            model.addConstr(
                insp_a_E * x_A[t] + insp_b_E * x_B[t] + ext_insp[t] <= cap_insp,
                f"Insp_Capacity_E_{t}"
            )

    # External inspection capacity constraint
    for t in range(planning_horizon_weeks):
        model.addConstr(ext_insp[t] <= cap_ext, f"External_Insp_Capacity_{t}")

    # Minimum weekly profit constraint
    for t in range(planning_horizon_weeks):
        model.addConstr(profit_a * x_A[t] + profit_b * x_B[t] >= min_profit, f"Min_Profit_{t}")

    # Objective function components
    total_profit = sum(profit_a * x_A[t] + profit_b * x_B[t] for t in range(planning_horizon_weeks))
    mode_fees = sum(mode_M[t] * mode_fee_M + mode_E[t] * mode_fee_E for t in range(planning_horizon_weeks))
    risk_penalties = sum(mode_M[t] * risk_penalty_M for t in range(planning_horizon_weeks))
    external_inspection_costs = sum(ext_insp[t] * cost_ext for t in range(planning_horizon_weeks))

    # In-house inspection costs
    in_house_inspection_costs = 0
    for t in range(planning_horizon_weeks):
        in_house_inspection_costs += (
            mode_M[t] * (insp_a_M * x_A[t] + insp_b_M * x_B[t]) * cost_insp_M +
            mode_E[t] * (insp_a_E * x_A[t] + insp_b_E * x_B[t]) * cost_insp_E
        )

    # Idle time calculation and weighted idle cost
    idle_time_cost = 0
    for t in range(planning_horizon_weeks):
        idle_mfg = cap_mfg - (mfg_a * x_A[t] + mfg_b * x_B[t])
        idle_asm = cap_asm - (asm_a * x_A[t] + asm_b * x_B[t])
        idle_insp = cap_insp - (
            mode_M[t] * (insp_a_M * x_A[t] + insp_b_M * x_B[t]) +
            mode_E[t] * (insp_a_E * x_A[t] + insp_b_E * x_B[t])
        )
        idle_time_cost += cost_mfg * idle_mfg + cost_asm * idle_asm + cost_insp_weight * idle_insp

    # Objective function: minimize idle time cost first, then maximize profit
    model.setObjectiveN(idle_time_cost, index=0, priority=2, weight=1.0)
    model.setObjectiveN(-total_profit, index=1, priority=1, weight=1.0)

    # Optimize the model
    model.optimize()

    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {round(total_profit.getValue(), 4)}")

if __name__ == "__main__":
    solve()
