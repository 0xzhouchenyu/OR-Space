import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add parent directory to path if needed
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Load data
    data_dir = os.path.join(script_dir, "data")
    params_file = os.path.join(data_dir, "general_parameters.csv")
    params = load_general_parameters(params_file)

    # Extract parameters
    motorcycle_pollution = params['motorcycle_pollution']
    small_truck_pollution = params['small_truck_pollution']
    large_truck_pollution = params['large_truck_pollution']
    max_motorcycle_trips = int(params['max_motorcycle_trips'])
    motorcycle_capacity = params['motorcycle_capacity']
    small_truck_capacity = params['small_truck_capacity']
    large_truck_capacity = params['large_truck_capacity']
    demand_peak_units = params['demand_peak_units']
    demand_offpeak_units = params['demand_offpeak_units']
    leasing_capacity = params['leasing_capacity']
    leasing_pollution_per_unit = params['leasing_pollution_per_unit']
    leasing_fixed_pollution = params['leasing_fixed_pollution']
    max_leasing_fraction_peak = params['max_leasing_fraction_peak']
    bigM_leasing = params['bigM_leasing']
    epsilon = params['epsilon']
    max_total_trips = int(params['max_total_trips'])

    methods = ['motorcycle', 'small_truck', 'large_truck']
    pollution = {
        'motorcycle': motorcycle_pollution,
        'small_truck': small_truck_pollution,
        'large_truck': large_truck_pollution
    }
    capacity = {
        'motorcycle': motorcycle_capacity,
        'small_truck': small_truck_capacity,
        'large_truck': large_truck_capacity
    }

    best_obj = float('inf')
    best_solution = None
    best_combo = None

    # Enumerate all combinations of 2 transportation methods
    for combo in combinations(methods, 2):
        model = gp.Model("Transport_Optimization")
        model.setParam('OutputFlag', 0)  # Suppress output

        # Decision variables: number of trips for each method (integer, non-negative)
        trips = {}
        for m in combo:
            trips[m] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"trips_{m}")

        # Leasing decision variables
        leasing_peak = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=bigM_leasing, name="leasing_peak")
        leasing_offpeak = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=bigM_leasing, name="leasing_offpeak")
        leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")

        # Objective: minimize total pollution
        obj = (
            sum(pollution[m] * trips[m] for m in combo) +
            leasing_pollution_per_unit * (leasing_peak + leasing_offpeak) +
            leasing_fixed_pollution * leasing_used
        )
        model.setObjective(obj, GRB.MINIMIZE)

        # Constraints
        # Total transport requirement in peak period
        model.addConstr(
            sum(capacity[m] * trips[m] for m in combo) + leasing_peak >= demand_peak_units,
            "peak_demand"
        )

        # Total transport requirement in off-peak period
        model.addConstr(
            sum(capacity[m] * trips[m] for m in combo) + leasing_offpeak >= demand_offpeak_units,
            "offpeak_demand"
        )

        # Maximum total trips constraint
        model.addConstr(sum(trips[m] for m in combo) <= max_total_trips, "total_trips")

        # Motorcycle trip limit
        if 'motorcycle' in combo:
            model.addConstr(trips['motorcycle'] <= max_motorcycle_trips, "max_motorcycle_trips")

        # Leasing constraints
        model.addConstr(leasing_peak + leasing_offpeak <= leasing_capacity, "leasing_capacity")
        model.addConstr(leasing_peak <= max_leasing_fraction_peak * demand_peak_units, "peak_leasing_limit")
        
        # Link leasing_used to leasing activity
        model.addConstr(leasing_peak + leasing_offpeak >= epsilon * leasing_used, "leasing_activation")
        model.addConstr(leasing_peak + leasing_offpeak <= bigM_leasing * leasing_used, "leasing_deactivation")

        # Optimize the model
        model.optimize()

        if model.status == GRB.OPTIMAL:
            obj_val = model.objVal
            if obj_val < best_obj:
                best_obj = obj_val
                best_solution = {m: trips[m].x for m in combo}
                best_solution["leasing_peak"] = leasing_peak.x
                best_solution["leasing_offpeak"] = leasing_offpeak.x
                best_solution["leasing_used"] = leasing_used.x
                best_combo = combo

    # Print solution details
    if best_solution is not None:
        print(f"Best combination: {best_combo}")
        for m in best_combo:
            print(f"  {m}: {best_solution[m]} trips")
        print(f"Leasing (peak): {best_solution['leasing_peak']} units")
        print(f"Leasing (off-peak): {best_solution['leasing_offpeak']} units")
        print(f"Total pollution: {best_obj}")

    print(f"FINAL_OBJ_VALUE: {best_obj}")

if __name__ == "__main__":
    import csv
    main()
