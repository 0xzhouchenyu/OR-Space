import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils import load_demand, load_parameters
import gurobipy as gp
from gurobipy import GRB

def main():
    demand_data = load_demand()
    params = load_parameters()
    
    # Planning months: July to December
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']
    
    # Parameters
    cost_I = params['product_I_cost_jun_to_dec']  # 4.5 for June-Dec
    cost_II = params['product_II_cost_jun_to_dec']  # 7 for June-Dec
    prod_cost = {'Product_I': cost_I, 'Product_II': cost_II}
    
    vol_I = params['product_I_volume']  # 0.2
    vol_II = params['product_II_volume']  # 0.4
    volume = {'Product_I': vol_I, 'Product_II': vol_II}
    
    warehouse_cap = params['warehouse_capacity']  # 30,000 cubic meters
    own_cost = params['own_warehouse_cost']  # 1 yuan/m³/month
    
    machine_hours_I = params['product_I_machine_hours']  # 0.8
    machine_hours_II = params['product_II_machine_hours']  # 1.6
    machine_hours = {'Product_I': machine_hours_I, 'Product_II': machine_hours_II}
    machine_hours_cap = params['machine_hours_capacity_monthly']  # 120,000
    
    grid_electricity_cost = params['grid_electricity_cost']  # 0.6 yuan/kWh
    generator_electricity_cost = params['generator_electricity_cost']  # 0.9 yuan/kWh
    
    power_I = params['product_I_power_kwh']  # 2 kWh/unit
    power_II = params['product_II_power_kwh']  # 3 kWh/unit
    power_consumption = {'Product_I': power_I, 'Product_II': power_II}
    
    grid_quota = {
        'July': params['grid_quota_july'],
        'August': params['grid_quota_august'],
        'September': params['grid_quota_september'],
        'October': params['grid_quota_october'],
        'November': params['grid_quota_november'],
        'December': params['grid_quota_december']
    }
    
    generator_max = {
        'July': params['generator_max_july'],
        'August': params['generator_max_august'],
        'September': params['generator_max_september'],
        'October': params['generator_max_october'],
        'November': params['generator_max_november'],
        'December': params['generator_max_december']
    }
    
    # Demand for planning months
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]
    
    # Model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)  # Suppress Gurobi output
    
    # Decision variables
    # Production quantities
    x = model.addVars(months, products, name="prod", lb=0)
    
    # Inventory at end of month
    inv = model.addVars(months, products, name="inv", lb=0)
    
    # Own warehouse usage (cubic meters)
    own_wh = model.addVars(months, name="own_wh", lb=0)
    
    # Electricity from grid and generator
    grid_electricity = model.addVars(months, name="grid_electricity", lb=0)
    generator_electricity = model.addVars(months, name="generator_electricity", lb=0)
    
    # Objective: minimize production cost + inventory holding cost + electricity cost
    obj = (
        sum(prod_cost[p] * x[m, p] for m in months for p in products) +
        sum(own_cost * own_wh[m] for m in months) +
        sum(grid_electricity_cost * grid_electricity[m] for m in months) +
        sum(generator_electricity_cost * generator_electricity[m] for m in months)
    )
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    for i, m in enumerate(months):
        # Inventory balance
        for p in products:
            if i == 0:
                model.addConstr(inv[m, p] == 0 + x[m, p] - demand[(m, p)], f"inventory_balance_{m}_{p}")
            else:
                prev_m = months[i - 1]
                model.addConstr(inv[m, p] == inv[prev_m, p] + x[m, p] - demand[(m, p)], f"inventory_balance_{m}_{p}")
        
        # Machine hours constraint
        model.addConstr(sum(machine_hours[p] * x[m, p] for p in products) <= machine_hours_cap, f"machine_hours_{m}")
        
        # Warehouse capacity constraint
        total_vol = sum(volume[p] * inv[m, p] for p in products)
        model.addConstr(own_wh[m] >= total_vol, f"warehouse_usage_{m}")
        model.addConstr(own_wh[m] <= warehouse_cap, f"warehouse_capacity_{m}")
        
        # Electricity consumption constraint
        total_power = sum(power_consumption[p] * x[m, p] for p in products)
        model.addConstr(total_power == grid_electricity[m] + generator_electricity[m], f"electricity_balance_{m}")
        model.addConstr(grid_electricity[m] <= grid_quota[m], f"grid_quota_{m}")
        model.addConstr(generator_electricity[m] <= generator_max[m], f"generator_max_{m}")
    
    # Optimize the model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
