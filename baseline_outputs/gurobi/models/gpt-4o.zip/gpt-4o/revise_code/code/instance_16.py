import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_monthly_data(filepath):
    """Load monthly purchasing and selling price data."""
    months = []
    purchasing_prices = {}
    selling_prices = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            month = int(row['Month'])
            months.append(month)
            purchasing_prices[month] = float(row['Purchasing_Price_Yuan'])
            selling_prices[month] = float(row['Selling_Price_Yuan'])
    
    return months, purchasing_prices, selling_prices

def load_general_parameters(filepath):
    """Load general parameters."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")
months, purchasing_prices, selling_prices = load_monthly_data(os.path.join(data_dir, "table_1.csv"))
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params['fixed_ordering_cost']
month2_bulk_receiving_threshold = params['month2_bulk_receiving_threshold']
month2_bulk_receiving_fee = params['month2_bulk_receiving_fee']

# Create the model
model = gp.Model("Maximize_Profit")
model.setParam('OutputFlag', 0)

# Decision variables
x = {m: model.addVar(vtype=GRB.CONTINUOUS, name=f"purchase_{m}", lb=0) for m in months}
s = {m: model.addVar(vtype=GRB.CONTINUOUS, name=f"sell_{m}", lb=0) for m in months}
inv = {m: model.addVar(vtype=GRB.CONTINUOUS, name=f"inventory_{m}", lb=0) for m in months}
order_flag = {m: model.addVar(vtype=GRB.BINARY, name=f"order_flag_{m}") for m in months}
bulk_receiving_flag = model.addVar(vtype=GRB.BINARY, name="bulk_receiving_flag_2")

# Objective: maximize total profit
model.setObjective(
    gp.quicksum(selling_prices[m] * s[m] - purchasing_prices[m] * x[m] - fixed_ordering_cost * order_flag[m] for m in months) 
    - month2_bulk_receiving_fee * bulk_receiving_flag,
    GRB.MAXIMIZE
)

# Constraints
for m in months:
    if m == months[0]:
        prev_inv = initial_stock
    else:
        prev_inv = inv[m - 1]
    
    # Inventory balance
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], name=f"inventory_balance_{m}")
    
    # Warehouse capacity constraints
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, name=f"warehouse_after_purchase_{m}")
    model.addConstr(inv[m] <= warehouse_capacity, name=f"warehouse_end_{m}")
    
    # Selling limit
    model.addConstr(s[m] <= prev_inv + x[m], name=f"sell_limit_{m}")
    
    # Fixed ordering cost flag
    model.addConstr(x[m] <= warehouse_capacity * order_flag[m], name=f"order_flag_constraint_{m}")

# February bulk receiving constraint
model.addConstr(x[2] <= month2_bulk_receiving_threshold + warehouse_capacity * bulk_receiving_flag, name="bulk_receiving_constraint_2")

# Solve the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
