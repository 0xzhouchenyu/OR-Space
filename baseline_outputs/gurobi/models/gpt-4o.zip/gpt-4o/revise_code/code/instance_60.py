import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # General parameters
    num_customers = 7
    max_route_length_day = 1000
    route_cost_day = 20
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'num_customers':
                num_customers = int(row['Value'])
            elif row['Parameter_Name'] == 'max_route_length_day':
                max_route_length_day = int(row['Value'])
            elif row['Parameter_Name'] == 'route_cost_day':
                route_cost_day = int(row['Value'])
    
    # Distance matrix
    D = [[0] * num_customers for _ in range(num_customers)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:
            nums = [int(x) if x.isdigit() else 0 for x in line.strip().split(',')[1:]]
            row_idx = lines.index(line) - 1
            for col_idx, val in enumerate(nums):
                if val > 0:
                    D[row_idx][col_idx] = val
                    D[col_idx][row_idx] = val
    
    # Create model
    model = gp.Model("Two-Day_TSP")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(num_customers, num_customers, 2, vtype=GRB.BINARY, name="x")  # x[i, j, d]: edge (i, j) used on day d
    y = model.addVars(num_customers, 2, vtype=GRB.BINARY, name="y")  # y[i, d]: customer i assigned to day d
    u = model.addVars(num_customers, 2, vtype=GRB.CONTINUOUS, name="u")  # u[i, d]: subtour elimination variable
    
    # Objective: minimize total cost
    model.setObjective(
        gp.quicksum(D[i][j] * x[i, j, d] for i in range(num_customers) for j in range(num_customers) for d in range(2) if i != j) +
        gp.quicksum(route_cost_day * gp.quicksum(y[i, d] for i in range(num_customers)) for d in range(2)),
        GRB.MINIMIZE
    )
    
    # Constraints
    # Each customer is visited exactly once across both days
    for i in range(1, num_customers):
        model.addConstr(gp.quicksum(y[i, d] for d in range(2)) == 1)
    
    # Depot is always assigned to both days
    for d in range(2):
        model.addConstr(y[0, d] == 1)
    
    # Flow conservation: each customer has one incoming and one outgoing edge on its assigned day
    for i in range(num_customers):
        for d in range(2):
            model.addConstr(gp.quicksum(x[i, j, d] for j in range(num_customers) if i != j) == y[i, d])
            model.addConstr(gp.quicksum(x[j, i, d] for j in range(num_customers) if i != j) == y[i, d])
    
    # Subtour elimination constraints
    for d in range(2):
        for i in range(1, num_customers):
            for j in range(1, num_customers):
                if i != j:
                    model.addConstr(u[i, d] - u[j, d] + (num_customers - 1) * x[i, j, d] <= num_customers - 2)
    
    # Daily route length constraint
    for d in range(2):
        model.addConstr(
            gp.quicksum(D[i][j] * x[i, j, d] for i in range(num_customers) for j in range(num_customers) if i != j) <= max_route_length_day
        )
    
    # Solve model
    model.optimize()
    
    # Output result
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
