import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, "table_1.csv")
    products = {}
    with open(table1_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row["Item"].strip()
            products[item] = {
                "machine_time": float(row["Machine_Time_minutes"].strip()),
                "craftsman_time": float(row["Craftsman_Time_minutes"].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "general_parameters.csv")
    params = {}
    with open(params_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    # Extract parameters
    machine_avail = params["machine_time_available"]  # hours
    craftsman_regular_avail = params["craftsman_regular_time_available"]  # hours
    craftsman_overtime_avail = params["craftsman_overtime_available"]  # hours
    machine_cost = params["machine_time_cost"]  # GBP per hour
    craftsman_regular_cost = params["craftsman_time_cost"]  # GBP per hour
    craftsman_overtime_cost = params["craftsman_overtime_cost"]  # GBP per hour
    rev_X = params["revenue_product_X"]  # GBP per batch
    rev_Y = params["revenue_product_Y"]  # GBP per batch
    min_X = params["min_batches_product_X"]  # batches
    Y_QA_threshold = params["product_Y_QA_threshold"]  # batches
    Y_QA_fee = params["product_Y_QA_fee"]  # GBP
    
    # Convert time from minutes to hours
    products["X"]["machine_time"] /= 60.0
    products["X"]["craftsman_time"] /= 60.0
    products["Y"]["machine_time"] /= 60.0
    products["Y"]["craftsman_time"] /= 60.0
    
    # Create Gurobi model
    model = gp.Model("Production_Planning")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    X = model.addVar(lb=0, name="X")
    Y = model.addVar(lb=0, name="Y")
    Y_QA_trigger = model.addVar(vtype=GRB.BINARY, name="Y_QA_trigger")
    
    # Constraints
    model.addConstr(products["X"]["machine_time"] * X + products["Y"]["machine_time"] * Y <= machine_avail, "Machine_Time_Constraint")
    model.addConstr(products["X"]["craftsman_time"] * X + products["Y"]["craftsman_time"] * Y <= craftsman_regular_avail + craftsman_overtime_avail, "Craftsman_Time_Constraint")
    model.addConstr(products["X"]["craftsman_time"] * X + products["Y"]["craftsman_time"] * Y - craftsman_regular_avail <= craftsman_overtime_avail, "Craftsman_Overtime_Constraint")
    model.addConstr(X >= min_X, "Min_Production_X")
    model.addConstr(Y - Y_QA_threshold <= Y_QA_trigger * 1e6, "Y_QA_Trigger_Upper")
    model.addConstr(Y_QA_trigger <= 1, "Y_QA_Trigger_Binary")
    
    # Objective: maximize profit
    machine_hours_used = products["X"]["machine_time"] * X + products["Y"]["machine_time"] * Y
    craftsman_hours_used = products["X"]["craftsman_time"] * X + products["Y"]["craftsman_time"] * Y
    craftsman_overtime_used = gp.max_(0, craftsman_hours_used - craftsman_regular_avail)
    craftsman_regular_used = craftsman_hours_used - craftsman_overtime_used
    
    profit = (
        rev_X * X +
        rev_Y * Y -
        machine_cost * machine_hours_used -
        craftsman_regular_cost * craftsman_regular_used -
        craftsman_overtime_cost * craftsman_overtime_used -
        Y_QA_fee * Y_QA_trigger
    )
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Solve model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")

if __name__ == "__main__":
    main()
