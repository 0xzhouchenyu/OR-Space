import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data files
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load food items
    items = []
    with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                "name": row["Item"].strip(),
                "protein": float(row["Protein_Content_per_100g"].strip()),
                "cost": float(row["Cost_per_100g"].strip()),
                "type": row["Type"].strip(),
                "calories": float(row["Calories_per_100g"].strip()),
                "sodium": float(row["Sodium_mg_per_100g"].strip())
            })
    
    # Load parameters
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    min_veg_types = int(params["min_vegetable_types"])
    max_budget = params["max_budget"]
    total_weight_limit = params["total_weight_limit"]
    min_daily_calories = params["min_daily_calories"]
    max_daily_calories = params["max_daily_calories"]
    max_daily_sodium = params["max_daily_sodium"]
    
    max_units = int(total_weight_limit // 100)
    max_meal_units = 3  # 300 grams per meal / 100 grams per unit
    
    # Create model
    model = gp.Model("meal_planning")
    model.setParam("OutputFlag", 0)
    
    # Variables
    purchase_units = {i: model.addVar(vtype=GRB.INTEGER, name=f"purchase_units_{items[i]['name']}") for i in range(len(items))}
    lunch_units = {i: model.addVar(vtype=GRB.INTEGER, name=f"lunch_units_{items[i]['name']}") for i in range(len(items))}
    dinner_units = {i: model.addVar(vtype=GRB.INTEGER, name=f"dinner_units_{items[i]['name']}") for i in range(len(items))}
    select_item = {i: model.addVar(vtype=GRB.BINARY, name=f"select_item_{items[i]['name']}") for i in range(len(items))}
    lunch_veg_selected = {i: model.addVar(vtype=GRB.BINARY, name=f"lunch_veg_selected_{items[i]['name']}") for i in range(len(items)) if items[i]["type"] == "Vegetable"}
    dinner_veg_selected = {i: model.addVar(vtype=GRB.BINARY, name=f"dinner_veg_selected_{items[i]['name']}") for i in range(len(items)) if items[i]["type"] == "Vegetable"}
    
    # Objective: Maximize total protein intake
    model.setObjective(gp.quicksum(items[i]["protein"] * (lunch_units[i] + dinner_units[i]) for i in range(len(items))), GRB.MAXIMIZE)
    
    # Constraints
    # Total daily budget
    model.addConstr(gp.quicksum(items[i]["cost"] * purchase_units[i] for i in range(len(items))) <= max_budget)
    
    # Total daily weight limit
    model.addConstr(gp.quicksum(100 * purchase_units[i] for i in range(len(items))) <= total_weight_limit)
    
    # Per-meal weight balance
    model.addConstr(gp.quicksum(100 * lunch_units[i] for i in range(len(items))) == 300)
    model.addConstr(gp.quicksum(100 * dinner_units[i] for i in range(len(items))) == 300)
    
    # Daily calorie intake bounds
    model.addConstr(gp.quicksum(items[i]["calories"] * (lunch_units[i] + dinner_units[i]) for i in range(len(items))) >= min_daily_calories)
    model.addConstr(gp.quicksum(items[i]["calories"] * (lunch_units[i] + dinner_units[i]) for i in range(len(items))) <= max_daily_calories)
    
    # Daily sodium intake bound
    model.addConstr(gp.quicksum(items[i]["sodium"] * (lunch_units[i] + dinner_units[i]) for i in range(len(items))) <= max_daily_sodium)
    
    # Purchase selection linkage
    for i in range(len(items)):
        model.addConstr(purchase_units[i] <= max_units * select_item[i])
        model.addConstr(lunch_units[i] <= max_meal_units * select_item[i])
        model.addConstr(dinner_units[i] <= max_meal_units * select_item[i])
        model.addConstr(purchase_units[i] >= lunch_units[i] + dinner_units[i])
    
    # Minimum vegetable types per meal
    model.addConstr(gp.quicksum(lunch_veg_selected[i] for i in lunch_veg_selected) >= min_veg_types)
    model.addConstr(gp.quicksum(dinner_veg_selected[i] for i in dinner_veg_selected) >= min_veg_types)
    
    # Vegetable selection linkage
    for i in lunch_veg_selected:
        model.addConstr(lunch_units[i] >= lunch_veg_selected[i])
        model.addConstr(lunch_units[i] <= max_meal_units * lunch_veg_selected[i])
    for i in dinner_veg_selected:
        model.addConstr(dinner_units[i] >= dinner_veg_selected[i])
        model.addConstr(dinner_units[i] <= max_meal_units * dinner_veg_selected[i])
    
    # Solve model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

main()
