import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read time periods and minimum waiters needed
time_periods = []
min_waiters = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        time_periods.append(row["Time"].strip())
        min_waiters.append(int(row["Minimum_Number_of_Waiters_Needed"].strip()))

# Read general parameters
work_hours = 8
peak = []
quality = []
waiter_cost_per_shift = 0
waiter_budget = 0
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        param = row["Parameter_Name"].strip()
        value = float(row["Value"].strip())
        if param.startswith("peak_"):
            peak.append(int(value))
        elif param.startswith("quality_"):
            quality.append(value)
        elif param == "waiter_cost_per_shift":
            waiter_cost_per_shift = value
        elif param == "waiter_budget":
            waiter_budget = value

# Number of periods
n = len(time_periods)

# Model
model = gp.Model("Revised_Restaurant_Waiters")
model.setParam("OutputFlag", 0)

# Decision variables
x = [model.addVar(vtype=GRB.INTEGER, name=f"x_{i}") for i in range(n)]

# Objective: maximize service quality score
model.setObjective(
    gp.quicksum((quality[i] + quality[(i + 1) % n]) * x[i] for i in range(n)),
    GRB.MAXIMIZE,
)

# Constraints: coverage in every 4-hour window
for j in range(n):
    prev = (j - 1) % n
    model.addConstr(x[prev] + x[j] >= min_waiters[j], f"Coverage_{j}")

# Constraint: peak and off-peak pairing
for i in range(n):
    model.addConstr(
        peak[i] + peak[(i + 1) % n] == 1, f"Peak_OffPeak_Pairing_{i}"
    )  # Ensure one peak and one off-peak per shift

# Constraint: total staffing cost within budget
model.addConstr(
    gp.quicksum(x[i] * waiter_cost_per_shift for i in range(n)) <= waiter_budget,
    "Budget_Constraint",
)

# Optimize
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
