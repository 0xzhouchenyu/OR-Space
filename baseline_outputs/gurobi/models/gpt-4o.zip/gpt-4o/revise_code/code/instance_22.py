import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    t1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    t2 = pd.read_csv(os.path.join(data_dir, "table_2.csv"))
    t3 = pd.read_csv(os.path.join(data_dir, "table_3.csv"))
    gp = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    
    # Merge product data
    df = t1.merge(t2, on="Product").merge(t3, on="Product")
    
    # Parse general parameters
    params = {row["Parameter_Name"]: row["Value"] for _, row in gp.iterrows()}
    
    return df, params

def solve():
    df, params = load_data()
    
    # Extract parameters
    prod_days = params["production_days"]
    a1_watch_threshold = params["a1_watch_threshold"]
    a1_deep_service_threshold = params["a1_deep_service_threshold"]
    maintenance_penalty_watch = params["maintenance_penalty_watch"]
    maintenance_penalty_deep = params["maintenance_penalty_deep"]
    a1_quality_release_fee = params["a1_quality_release_fee"]
    a1_deep_service_fee = params["a1_deep_service_fee"]
    a1_priority_price_lift = params["a1_priority_price_lift"]
    
    # Create model
    model = gp.Model("Production_Planning")
    model.setParam("OutputFlag", 0)
    
    # Variables
    products = df["Product"].tolist()
    x = {p: model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{p}") for p in products}
    y = {p: model.addVar(vtype=GRB.BINARY, name=f"y_{p}") for p in products}
    
    # Objective
    profit = gp.quicksum(
        (row["Selling_Price"] - row["Production_Cost"]) * x[row["Product"]] 
        - row["Activation_Cost"] * y[row["Product"]]
        for _, row in df.iterrows()
    )
    
    # A1-specific adjustments
    a1_units_above_watch = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="a1_units_above_watch")
    a1_watch_trigger = model.addVar(vtype=GRB.BINARY, name="a1_watch_trigger")
    a1_deep_trigger = model.addVar(vtype=GRB.BINARY, name="a1_deep_trigger")
    
    # Add priority price uplift for A1 units above watch threshold
    profit += a1_units_above_watch * a1_priority_price_lift
    
    # Add quality release and deep service fees
    profit -= a1_watch_trigger * a1_quality_release_fee
    profit -= a1_deep_trigger * a1_deep_service_fee
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Constraints
    for _, row in df.iterrows():
        p = row["Product"]
        model.addConstr(x[p] <= row["Maximum_Demand"] * y[p], name=f"max_demand_{p}")
        model.addConstr(x[p] >= row["Minimum_Batch"] * y[p], name=f"min_batch_{p}")
    
    # Production days constraint
    model.addConstr(
        gp.quicksum(x[row["Product"]] / row["Production_Quota"] for _, row in df.iterrows()) 
        + maintenance_penalty_watch * a1_watch_trigger 
        + maintenance_penalty_deep * a1_deep_trigger 
        <= prod_days, 
        name="production_days"
    )
    
    # A1-specific constraints
    model.addConstr(x["A1"] >= a1_watch_threshold * a1_watch_trigger, name="a1_watch_trigger_min")
    model.addConstr(x["A1"] <= a1_watch_threshold + (1 - a1_watch_trigger) * 1e6, name="a1_watch_trigger_max")
    model.addConstr(x["A1"] >= a1_deep_service_threshold * a1_deep_trigger, name="a1_deep_trigger_min")
    model.addConstr(x["A1"] <= a1_deep_service_threshold + (1 - a1_deep_trigger) * 1e6, name="a1_deep_trigger_max")
    model.addConstr(a1_units_above_watch == gp.max_(0, x["A1"] - a1_watch_threshold), name="a1_units_above_watch")
    
    # Solve
    model.optimize()
    
    # Return objective value
    return model.objVal

if __name__ == "__main__":
    obj = solve()
    print(f"FINAL_OBJ_VALUE: {round(obj, 4)}")
