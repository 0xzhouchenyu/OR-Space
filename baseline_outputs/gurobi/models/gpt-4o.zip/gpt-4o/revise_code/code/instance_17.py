import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    parts = []
    with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                "id": int(row["Key_Part"]),
                "distance": float(row["Distance_from_Airport_km"]),
                "p_heavy": float(row["Probability_of_Destruction_per_Heavy_Bomb"]),
                "p_light": float(row["Probability_of_Destruction_per_Light_Bomb"]),
            })
    
    # Load general_parameters.csv
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    
    return parts, params

# Fuel calculation functions
def fuel_per_heavy_bomb(distance, params, overhead):
    eff_heavy = params["fuel_efficiency_heavy_bomb"]
    eff_empty = params["fuel_efficiency_empty"]
    takeoff_landing = params["fuel_takeoff_landing"]
    return distance / eff_heavy + distance / eff_empty + takeoff_landing + overhead

def fuel_per_light_bomb(distance, params, overhead):
    eff_light = params["fuel_efficiency_light_bomb"]
    eff_empty = params["fuel_efficiency_empty"]
    takeoff_landing = params["fuel_takeoff_landing"]
    return distance / eff_light + distance / eff_empty + takeoff_landing + overhead

# Load data
parts, params = load_data()

# Extract parameters
max_heavy = int(params["max_heavy_bombs"])
max_light = int(params["max_light_bombs"])
fuel_limit = params["fuel_limit"]
min_parts = int(params["min_parts_destroyed"])
max_sorties_A = int(params["max_sorties_A"])
max_sorties_B = int(params["max_sorties_B"])
sortie_fuel_overhead_A = params["sortie_fuel_overhead_A"]
sortie_fuel_overhead_B = params["sortie_fuel_overhead_B"]
scenario_prob_A = params["scenario_prob_A"]
scenario_prob_B = params["scenario_prob_B"]

# Create model
model = gp.Model()
model.setParam("OutputFlag", 0)

n = len(parts)

# Decision variables
x_heavy = model.addVars(n, vtype=GRB.INTEGER, name="x_heavy")
x_light = model.addVars(n, vtype=GRB.INTEGER, name="x_light")

# Constraints
# Bomb stockpile limits
model.addConstr(gp.quicksum(x_heavy[i] for i in range(n)) <= max_heavy, "HeavyBombLimit")
model.addConstr(gp.quicksum(x_light[i] for i in range(n)) <= max_light, "LightBombLimit")

# Sortie limits
model.addConstr(gp.quicksum(x_heavy[i] + x_light[i] for i in range(n)) <= max_sorties_A, "SortieLimitA")
model.addConstr(gp.quicksum(x_heavy[i] + x_light[i] for i in range(n)) <= max_sorties_B, "SortieLimitB")

# Fuel limits
fuel_A = gp.quicksum(
    x_heavy[i] * fuel_per_heavy_bomb(parts[i]["distance"], params, sortie_fuel_overhead_A) +
    x_light[i] * fuel_per_light_bomb(parts[i]["distance"], params, sortie_fuel_overhead_A)
    for i in range(n)
)
fuel_B = gp.quicksum(
    x_heavy[i] * fuel_per_heavy_bomb(parts[i]["distance"], params, sortie_fuel_overhead_B) +
    x_light[i] * fuel_per_light_bomb(parts[i]["distance"], params, sortie_fuel_overhead_B)
    for i in range(n)
)
model.addConstr(fuel_A <= fuel_limit, "FuelLimitA")
model.addConstr(fuel_B <= fuel_limit, "FuelLimitB")

# Objective: Maximize weighted mission success probability
probs = [
    1 - (1 - parts[i]["p_heavy"]) ** x_heavy[i] * (1 - parts[i]["p_light"]) ** x_light[i]
    for i in range(n)
]

def prob_at_least_k(probs, k):
    dp = [0.0] * (len(probs) + 1)
    dp[0] = 1.0
    for p in probs:
        for j in range(len(probs), 0, -1):
            dp[j] = dp[j] * (1 - p) + dp[j - 1] * p
        dp[0] *= (1 - p)
    return sum(dp[j] for j in range(k, len(probs) + 1))

prob_A = prob_at_least_k(probs, min_parts)
prob_B = prob_at_least_k(probs, min_parts)
model.setObjective(scenario_prob_A * prob_A + scenario_prob_B * prob_B, GRB.MAXIMIZE)

# Solve model
model.optimize()

# Output result
print(f"FINAL_OBJ_VALUE: {model.ObjVal:.4f}")
