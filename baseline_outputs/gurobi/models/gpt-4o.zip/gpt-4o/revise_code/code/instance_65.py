import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, "general_parameters.csv")) as f:
    for row in csv.DictReader(f):
        params[row["Parameter_Name"].strip()] = float(row["Value"])

# Load product data
products = {}
with open(os.path.join(data_dir, "table_1.csv")) as f:
    for row in csv.DictReader(f):
        products[row["Product"].strip()] = {
            "a_hrs": float(row["Workshop_A_Hours"]),
            "b_hrs": float(row["Workshop_B_Hours"]),
            "insp_cost": float(row["Inspection_Sales_Cost"]),
        }

# Extract product-specific data
m = products["Microwave_Oven"]
w = products["Water_Heater"]

# Create model
model = gp.Model("production")
model.setParam("OutputFlag", 0)

# Decision variables
x1 = model.addVar(vtype=GRB.CONTINUOUS, lb=params["microwave_minimum_sales"], name="microwave")
x2 = model.addVar(vtype=GRB.CONTINUOUS, lb=params["water_heater_minimum_sales"], name="water_heater")
y1 = model.addVar(vtype=GRB.BINARY, name="activate_microwave_A")
y2 = model.addVar(vtype=GRB.BINARY, name="activate_water_heater_A")

# Objective function
green_bonus_m = params["green_bonus_m"]
green_bonus_w = params["green_bonus_w"]
rev_m = m["a_hrs"] * params["workshop_a_hourly_cost"] + m["b_hrs"] * params["workshop_b_hourly_cost"] + m["insp_cost"]
rev_w = w["a_hrs"] * params["workshop_a_hourly_cost"] + w["b_hrs"] * params["workshop_b_hourly_cost"] + w["insp_cost"]
model.setObjective(
    (rev_m + green_bonus_m * y1) * x1 + (rev_w + green_bonus_w * y2) * x2, GRB.MAXIMIZE
)

# Constraints
model.addConstr(m["a_hrs"] * x1 + w["a_hrs"] * x2 + params["setup_hours_A"] * (y1 + y2) <= params["workshop_a_available_hours"] + params["workshop_a_overtime_limit"], "workshop_A_hours")
model.addConstr(m["b_hrs"] * x1 + w["b_hrs"] * x2 <= params["workshop_b_available_hours"], "workshop_B_hours")
model.addConstr(m["insp_cost"] * x1 + w["insp_cost"] * x2 <= params["inspection_sales_cost_limit"], "inspection_sales_cost")
model.addConstr(params["tech_rate_m"] * x1 + params["tech_rate_w"] * x2 <= params["tech_pool_hours"], "technician_hours")
model.addConstr(x1 <= params["bigM"] * y1, "activation_link_microwave_A")
model.addConstr(x2 <= params["bigM"] * y2, "activation_link_water_heater_A")

# Solve model
model.optimize()

# Output result
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
