import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general parameters
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    total_space = params['mall_total_space']
    rent_pct = params['rent_percentage'] / 100.0
    common_area_factor = params['common_area_factor']
    catering_security_threshold = int(params['catering_third_store_security_threshold'])
    catering_security_cost = params['catering_third_store_security_cost']
    gm_third_store_concession = params['general_merchandise_third_store_concession']
    
    # Read store data
    stores = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            stores.append({
                'name': row['Store_Type'].strip(),
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits
            })
    
    # Create optimization model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of stores for each type
    x = []
    for i, store in enumerate(stores):
        x.append(model.addVar(vtype=GRB.INTEGER, lb=store['min'], ub=store['max'], name=f"x_{i}"))
    
    # Auxiliary variable for catering security cost
    catering_security = model.addVar(vtype=GRB.BINARY, name="catering_security")
    
    # Constraints
    # Total space constraint
    model.addConstr(
        gp.quicksum(x[i] * stores[i]['area'] * common_area_factor for i in range(len(stores))) <= total_space,
        name="space_constraint"
    )
    
    # Catering security constraint
    model.addConstr(
        x[4] - catering_security_threshold <= catering_security * 1000,  # Large constant to enforce binary logic
        name="catering_security_logic"
    )
    
    # Objective function: maximize total rent income
    total_profit = gp.quicksum(
        x[i] * stores[i]['profits'][x[i]] for i in range(len(stores)) if x[i] in stores[i]['profits']
    )
    total_rent = rent_pct * total_profit
    total_rent -= catering_security * catering_security_cost  # Subtract catering security cost if applicable
    if 3 in stores[2]['profits']:
        total_rent += (x[2] == 3) * gm_third_store_concession  # Add concession for 3rd General Merchandise store
    
    model.setObjective(total_rent, GRB.MAXIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
