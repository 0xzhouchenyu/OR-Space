import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
sell_price_table = params['sell_price_table']
sell_price_chair = params['sell_price_chair']
sell_price_bookshelf = params['sell_price_bookshelf']

cost_table = params['manufacturing_cost_table']
cost_chair = params['manufacturing_cost_chair']
cost_bookshelf = params['manufacturing_cost_bookshelf']

space_table = params['warehouse_space_table']
space_chair = params['warehouse_space_chair']
space_bookshelf = params['warehouse_space_bookshelf']

max_warehouse = params['max_warehouse_space']
min_tables = params['min_tables']
min_bookshelves = params['min_bookshelves']
max_total = params['max_total_items']

labor_table = params['labor_hours_table']
labor_chair = params['labor_hours_chair']
labor_bookshelf = params['labor_hours_bookshelf']

max_labor_regular = params['max_labor_hours_month_regular']
max_labor_rush = params['max_labor_hours_month_rush']
max_rush_items = params['max_rush_items_month']

rush_bonus_table = params['rush_profit_bonus_table']
rush_bonus_chair = params['rush_profit_bonus_chair']
rush_bonus_bookshelf = params['rush_profit_bonus_bookshelf']

# Profit per item
profit_table = sell_price_table - cost_table
profit_chair = sell_price_chair - cost_chair
profit_bookshelf = sell_price_bookshelf - cost_bookshelf

# Create the model
model = gp.Model("Furniture_Production")
model.setParam('OutputFlag', 0)

# Decision variables
x_tables_regular = model.addVar(vtype=GRB.INTEGER, name="tables_regular", lb=0)
x_chairs_regular = model.addVar(vtype=GRB.INTEGER, name="chairs_regular", lb=0)
x_bookshelves_regular = model.addVar(vtype=GRB.INTEGER, name="bookshelves_regular", lb=0)

x_tables_rush = model.addVar(vtype=GRB.INTEGER, name="tables_rush", lb=0)
x_chairs_rush = model.addVar(vtype=GRB.INTEGER, name="chairs_rush", lb=0)
x_bookshelves_rush = model.addVar(vtype=GRB.INTEGER, name="bookshelves_rush", lb=0)

# Objective: maximize profit
model.setObjective(
    profit_table * (x_tables_regular + x_tables_rush) +
    profit_chair * (x_chairs_regular + x_chairs_rush) +
    profit_bookshelf * (x_bookshelves_regular + x_bookshelves_rush) +
    rush_bonus_table * x_tables_rush +
    rush_bonus_chair * x_chairs_rush +
    rush_bonus_bookshelf * x_bookshelves_rush,
    GRB.MAXIMIZE
)

# Constraints
# Warehouse space constraint
model.addConstr(
    space_table * (x_tables_regular + x_tables_rush) +
    space_chair * (x_chairs_regular + x_chairs_rush) +
    space_bookshelf * (x_bookshelves_regular + x_bookshelves_rush) <= max_warehouse,
    "Warehouse_Space"
)

# Minimum production requirements
model.addConstr(x_tables_regular + x_tables_rush >= min_tables, "Min_Tables")
model.addConstr(x_bookshelves_regular + x_bookshelves_rush >= min_bookshelves, "Min_Bookshelves")

# Maximum total production
model.addConstr(
    x_tables_regular + x_tables_rush +
    x_chairs_regular + x_chairs_rush +
    x_bookshelves_regular + x_bookshelves_rush <= max_total,
    "Max_Total_Items"
)

# Regular labor hours constraint
model.addConstr(
    labor_table * x_tables_regular +
    labor_chair * x_chairs_regular +
    labor_bookshelf * x_bookshelves_regular <= max_labor_regular,
    "Regular_Labor"
)

# Rush labor hours constraint
model.addConstr(
    labor_table * x_tables_rush +
    labor_chair * x_chairs_rush +
    labor_bookshelf * x_bookshelves_rush <= max_labor_rush,
    "Rush_Labor"
)

# Maximum rush items constraint
model.addConstr(
    x_tables_rush + x_chairs_rush + x_bookshelves_rush <= max_rush_items,
    "Max_Rush_Items"
)

# Solve the model
model.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
