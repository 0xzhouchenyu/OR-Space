import os
import gurobipy as gp
from gurobipy import GRB
import csv

# Utility functions
def load_goods_data(filepath):
    goods = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            goods[row['Goods_Type'].strip()] = {
                'quantity': int(row['Quantity'].strip()),
                'weight': float(row['Weight_per_Unit'].strip())
            }
    return goods

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
goods = load_goods_data(os.path.join(data_dir, 'table_1.csv'))
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

max_cap = params['max_container_capacity']
min_load = params['min_container_load']
min_d_per_container = int(params['min_d_goods_per_container'])
min_c_per_a = int(params['min_c_per_a'])
fragile_cap = 45  # Reduced capacity for containers with Goods E

goods_types = list(goods.keys())
quantities = {g: goods[g]['quantity'] for g in goods_types}
weights = {g: goods[g]['weight'] for g in goods_types}

# Upper bound on number of containers
max_containers = 15

# Model
model = gp.Model("ContainerMinimization")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVars(goods_types, range(max_containers), vtype=GRB.INTEGER, name="x")
y = model.addVars(range(max_containers), vtype=GRB.BINARY, name="y")
z = model.addVars(range(max_containers), vtype=GRB.BINARY, name="z")  # Indicator for Goods E in container

# Objective: minimize number of containers
model.setObjective(gp.quicksum(y[j] for j in range(max_containers)), GRB.MINIMIZE)

# Constraints
# All goods must be transported
for g in goods_types:
    model.addConstr(gp.quicksum(x[g, j] for j in range(max_containers)) == quantities[g], f"demand_{g}")

# Container capacity constraints
for j in range(max_containers):
    model.addConstr(gp.quicksum(weights[g] * x[g, j] for g in goods_types) <= max_cap * y[j], f"max_cap_{j}")
    model.addConstr(gp.quicksum(weights[g] * x[g, j] for g in goods_types) >= min_load * y[j], f"min_load_{j}")

# Minimum D goods per container (if container is used)
for j in range(max_containers):
    model.addConstr(x['D', j] >= min_d_per_container * y[j], f"min_D_{j}")

# If A goods are loaded, at least 1 C good must be loaded
for j in range(max_containers):
    model.addConstr(x['A', j] <= quantities['A'] * z[j], f"A_indicator_{j}")
    model.addConstr(x['C', j] >= min_c_per_a * z[j], f"C_if_A_{j}")

# Reduced capacity for containers with Goods E
for j in range(max_containers):
    model.addConstr(gp.quicksum(weights[g] * x[g, j] for g in goods_types) <= fragile_cap * z[j] + max_cap * (1 - z[j]), f"fragile_cap_{j}")
    model.addConstr(x['E', j] <= quantities['E'] * z[j], f"E_indicator_{j}")

# Symmetry breaking
for j in range(max_containers - 1):
    model.addConstr(y[j] >= y[j + 1], f"symmetry_{j}")

# Solve
model.optimize()

# Output
print(f"FINAL_OBJ_VALUE: {int(model.objVal)}")
