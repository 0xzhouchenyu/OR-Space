import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])

    # Read product segments and profits
    products = []
    segments = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row["Product"]
            if p not in segments:
                segments[p] = []
                products.append(p)
            rng = row["Sales_Volume_Range"]
            profit = float(row["Profit"])
            if rng.startswith("Above_"):
                lower = float(rng.split("_")[1])
                upper = None
            else:
                parts = rng.split("_")
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({"lower": lower, "upper": upper, "profit": profit})

    # Initialize model
    model = gp.Model("Maximize_Profit")
    model.setParam("OutputFlag", 0)

    M = 10000

    # Decision variables
    x = {}
    p_var = {}
    y = {}
    for prod in products:
        x[prod] = model.addVar(vtype=GRB.INTEGER, name=f"x_{prod}", lb=0)
        p_var[prod] = model.addVar(vtype=GRB.CONTINUOUS, name=f"p_{prod}", lb=0)
        y[prod] = []
        for i in range(len(segments[prod])):
            y[prod].append(model.addVar(vtype=GRB.BINARY, name=f"y_{prod}_{i}"))

    # Overtime variables
    overtime_hours = model.addVar(vtype=GRB.CONTINUOUS, name="overtime_hours", lb=0)
    overtime_fee = model.addVar(vtype=GRB.BINARY, name="overtime_fee")

    # Objective function
    model.setObjective(
        gp.quicksum(p_var[prod] for prod in products)
        - params["overtime_cost_per_hour"] * overtime_hours
        - params["overtime_second_review_fee"] * overtime_fee,
        GRB.MAXIMIZE,
    )

    # Constraints for product segments
    for prod in products:
        segs = segments[prod]
        model.addConstr(gp.quicksum(y[prod]) <= 1)
        for i, seg in enumerate(segs):
            lo = seg["lower"]
            hi = seg["upper"]
            profit = seg["profit"]
            if lo == 0:
                model.addConstr(x[prod] >= 1 - M * (1 - y[prod][i]))
            else:
                model.addConstr(x[prod] >= (lo + 1) - M * (1 - y[prod][i]))
            if hi is not None:
                model.addConstr(x[prod] <= hi + M * (1 - y[prod][i]))
            model.addConstr(p_var[prod] <= profit * x[prod] + M * (1 - y[prod][i]))
        model.addConstr(x[prod] <= M * gp.quicksum(y[prod]))
        model.addConstr(p_var[prod] <= M * gp.quicksum(y[prod]))

    # Resource constraints
    model.addConstr(
        gp.quicksum(params[f"technical_prep_time_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params["available_technical_prep_time"]
    )
    model.addConstr(
        gp.quicksum(params[f"labor_time_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params["available_labor_time"] + overtime_hours
    )
    model.addConstr(
        gp.quicksum(params[f"materials_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params["available_materials"]
    )
    model.addConstr(
        gp.quicksum(params[f"pack_units_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params["packaging_cap_units"]
    )

    # Overtime constraints
    model.addConstr(overtime_hours <= params["overtime_cap_hours"])
    model.addConstr(overtime_fee >= (overtime_hours - params["overtime_second_review_threshold"]) / M)
    model.addConstr(overtime_fee <= 1)

    # Solve the model
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
