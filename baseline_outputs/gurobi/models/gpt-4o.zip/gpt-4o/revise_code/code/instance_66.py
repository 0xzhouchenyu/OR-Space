import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read table_1.csv
toys = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            "type": row["Toy_Type"],
            "labor": float(row["Manufacturing_Labor_Hours"]),
            "inspection": float(row["Inspection_Hours"]),
            "profit": float(row["Profit_Per_Unit"])
        })

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

# Extract parameters
labor_period1 = params["available_labor_hours_period1"]
labor_period2 = params["available_labor_hours_period2"]
inspection_period1 = params["available_inspection_hours_period1"]
inspection_period2 = params["available_inspection_hours_period2"]
max_demand_period1 = {
    "High-End": params["max_demand_high_end_period1"],
    "Mid-Range": params["max_demand_mid_range_period1"],
    "Low-End": params["max_demand_low_end_period1"]
}
max_demand_period2 = {
    "High-End": params["max_demand_high_end_period2"],
    "Mid-Range": params["max_demand_mid_range_period2"],
    "Low-End": params["max_demand_low_end_period2"]
}
overtime_cap = params["overtime_labor_cap"]
overtime_cost = params["overtime_labor_cost"]
fatigue_threshold = params["period1_overtime_fatigue_threshold"]
recovery_loss = params["period2_labor_recovery_loss"]
review_threshold = params["overtime_review_threshold"]
safety_review_fee = params["seasonal_safety_review_fee"]

# Build optimization model
model = gp.Model("RevisedToyProduction")
model.setParam('OutputFlag', 0)

# Decision variables
x_period1 = {toy["type"]: model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{toy['type']}_period1") for toy in toys}
x_period2 = {toy["type"]: model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{toy['type']}_period2") for toy in toys}
overtime_period1 = model.addVar(vtype=GRB.CONTINUOUS, name="overtime_period1", lb=0)
overtime_period2 = model.addVar(vtype=GRB.CONTINUOUS, name="overtime_period2", lb=0)

# Objective: maximize profit minus costs
profit_period1 = gp.quicksum(toy["profit"] * x_period1[toy["type"]] for toy in toys)
profit_period2 = gp.quicksum(toy["profit"] * x_period2[toy["type"]] for toy in toys)
overtime_cost_total = overtime_cost * (overtime_period1 + overtime_period2)
safety_review_cost = safety_review_fee * (overtime_period1 + overtime_period2 >= review_threshold)
model.setObjective(profit_period1 + profit_period2 - overtime_cost_total - safety_review_cost, GRB.MAXIMIZE)

# Constraints
# Labor hours
model.addConstr(gp.quicksum(toy["labor"] * x_period1[toy["type"]] for toy in toys) <= labor_period1 + overtime_period1, "Labor_Period1")
model.addConstr(gp.quicksum(toy["labor"] * x_period2[toy["type"]] for toy in toys) <= labor_period2 + overtime_period2 - (recovery_loss if overtime_period1 > fatigue_threshold else 0), "Labor_Period2")

# Inspection hours
model.addConstr(gp.quicksum(toy["inspection"] * x_period1[toy["type"]] for toy in toys) <= inspection_period1, "Inspection_Period1")
model.addConstr(gp.quicksum(toy["inspection"] * x_period2[toy["type"]] for toy in toys) <= inspection_period2, "Inspection_Period2")

# Demand constraints
for toy in toys:
    model.addConstr(x_period1[toy["type"]] <= max_demand_period1[toy["type"]], f"Demand_{toy['type']}_Period1")
    model.addConstr(x_period2[toy["type"]] <= max_demand_period2[toy["type"]], f"Demand_{toy['type']}_Period2")

# Overtime cap
model.addConstr(overtime_period1 + overtime_period2 <= overtime_cap, "Overtime_Cap")

# Solve
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
