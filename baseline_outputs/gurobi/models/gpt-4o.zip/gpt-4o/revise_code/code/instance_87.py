import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Load parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = load_parameters(data_dir)
    
    # Extract parameters
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    base_a = params['base_fleet_type_a']
    base_b = params['base_fleet_type_b']
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    recovery_threshold_b = params['type_b_recovery_threshold']
    recovery_fee_b = params['type_b_recovery_fee']
    surge_threshold = params['total_fleet_surge_threshold']
    surge_fee = params['total_fleet_surge_fee']
    
    # Create the optimization model
    model = gp.Model("TruckRental")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVar(vtype=GRB.INTEGER, name="TypeA_trucks", lb=0)
    y = model.addVar(vtype=GRB.INTEGER, name="TypeB_trucks", lb=0)
    
    # Objective function components
    base_cost = cost_a * x + cost_b * y
    penalty_cost_a = penalty_a * gp.max_(0, x - base_a)
    penalty_cost_b = penalty_b * gp.max_(0, y - base_b)
    recovery_cost_b = recovery_fee_b * (y > recovery_threshold_b)
    surge_cost = surge_fee * ((x + y) > surge_threshold)
    
    # Objective: minimize total cost
    model.setObjective(base_cost + penalty_cost_a + penalty_cost_b + recovery_cost_b + surge_cost, GRB.MINIMIZE)
    
    # Constraints
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedRequirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedRequirement")
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
