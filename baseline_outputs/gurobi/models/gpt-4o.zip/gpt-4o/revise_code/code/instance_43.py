import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters from CSV
def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
min_A = params['min_raw_material_A']
min_B = params['min_raw_material_B']
min_C = params['min_raw_material_C']

cap_A_a = params['warehouse_A_truck_capacity_A']
cap_A_b = params['warehouse_A_truck_capacity_B']
cap_A_c = params['warehouse_A_truck_capacity_C']
cost_A = params['warehouse_A_truck_cost']
fixed_cost_A = params['warehouse_A_fixed_cost']

cap_B_a = params['warehouse_B_truck_capacity_A']
cap_B_b = params['warehouse_B_truck_capacity_B']
cap_B_c = params['warehouse_B_truck_capacity_C']
cost_B = params['warehouse_B_truck_cost']
fixed_cost_B = params['warehouse_B_fixed_cost']
overflow_threshold_B = params['warehouse_B_overflow_threshold_trucks']
overflow_cost_B = params['warehouse_B_overflow_coordination_cost']

dual_warehouse_trigger = params['dual_warehouse_reconciliation_trigger']
dual_warehouse_fee = params['dual_warehouse_reconciliation_fee']

# Create the optimization model
model = gp.Model("MinFreightCost")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, name="trucks_from_A", lb=0)
y = model.addVar(vtype=GRB.INTEGER, name="trucks_from_B", lb=0)
use_A = model.addVar(vtype=GRB.BINARY, name="use_A")
use_B = model.addVar(vtype=GRB.BINARY, name="use_B")
overflow_B = model.addVar(vtype=GRB.BINARY, name="overflow_B")
dual_reconciliation = model.addVar(vtype=GRB.BINARY, name="dual_reconciliation")

# Objective: minimize total cost
model.setObjective(
    cost_A * x + cost_B * y +
    fixed_cost_A * use_A + fixed_cost_B * use_B +
    overflow_cost_B * overflow_B +
    dual_warehouse_fee * dual_reconciliation,
    GRB.MINIMIZE
)

# Constraints: meet minimum raw material requirements
model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# Constraints: link binary variables to truck usage
model.addConstr(use_A >= (x > 0), "UseA")
model.addConstr(use_B >= (y > 0), "UseB")

# Constraint: overflow condition for warehouse B
model.addConstr(overflow_B >= (y > overflow_threshold_B), "OverflowB")

# Constraint: dual warehouse reconciliation
model.addConstr(dual_reconciliation >= (use_A + use_B >= 2), "DualReconciliation")

# Solve the model
model.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
