import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load container data
    containers = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                "code": int(row["Container_Type_Code"]),
                "volume": int(row["Volume_cm3"]),
                "demand": int(row["Market_Demand_units"]),
                "cost": float(row["Unit_Variable_Production_Cost_Yuan_per_unit"])
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"])

    fixed_cost = params["fixed_setup_cost"]
    energy_cost_per_kwh = params["energy_cost_per_kwh"]
    max_total_energy_kwh = params["max_total_energy_kwh"]
    eco_capacity_share = params["eco_capacity_share"]
    eco_overhead_cost = params["eco_overhead_cost"]
    regular_energy_intensity = params["regular_energy_intensity_kwh_per_unit"]
    eco_energy_intensity = params["eco_energy_intensity_kwh_per_unit"]

    n = len(containers)

    # Create the model
    model = gp.Model("PlasticContainers")
    model.setParam("OutputFlag", 0)

    # Decision variables
    y_regular = {i: model.addVar(vtype=GRB.BINARY, name=f"y_regular_{i}") for i in range(n)}
    y_eco = {i: model.addVar(vtype=GRB.BINARY, name=f"y_eco_{i}") for i in range(n)}
    x_regular = {(i, j): model.addVar(vtype=GRB.INTEGER, name=f"x_regular_{i}_{j}")
                 for i in range(n) for j in range(n) if containers[i]["volume"] >= containers[j]["volume"]}
    x_eco = {(i, j): model.addVar(vtype=GRB.INTEGER, name=f"x_eco_{i}_{j}")
             for i in range(n) for j in range(n) if containers[i]["volume"] >= containers[j]["volume"]}

    # Objective: minimize total cost
    model.setObjective(
        gp.quicksum(containers[i]["cost"] * x_regular[i, j] for (i, j) in x_regular) +
        gp.quicksum(containers[i]["cost"] * x_eco[i, j] for (i, j) in x_eco) +
        gp.quicksum(fixed_cost * y_regular[i] for i in range(n)) +
        gp.quicksum((fixed_cost + eco_overhead_cost) * y_eco[i] for i in range(n)) +
        gp.quicksum(energy_cost_per_kwh * regular_energy_intensity * x_regular[i, j] for (i, j) in x_regular) +
        gp.quicksum(energy_cost_per_kwh * eco_energy_intensity * x_eco[i, j] for (i, j) in x_eco),
        GRB.MINIMIZE
    )

    # Demand constraints: for each type j, total supplied >= demand[j]
    for j in range(n):
        model.addConstr(
            gp.quicksum(x_regular[i, j] for i in range(n) if (i, j) in x_regular) +
            gp.quicksum(x_eco[i, j] for i in range(n) if (i, j) in x_eco) >= containers[j]["demand"],
            name=f"demand_{j}"
        )

    # Linking constraints: if we produce type i in regular or eco mode, y_regular[i] or y_eco[i] must be 1
    M = sum(c["demand"] for c in containers)
    for i in range(n):
        total_regular_i = gp.quicksum(x_regular[i, j] for j in range(n) if (i, j) in x_regular)
        total_eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(total_regular_i <= M * y_regular[i], name=f"setup_regular_{i}")
        model.addConstr(total_eco_i <= M * y_eco[i], name=f"setup_eco_{i}")
        model.addConstr(total_eco_i <= eco_capacity_share * (total_regular_i + total_eco_i), name=f"eco_capacity_{i}")

    # Energy constraint: total energy consumption <= max_total_energy_kwh
    model.addConstr(
        gp.quicksum(regular_energy_intensity * x_regular[i, j] for (i, j) in x_regular) +
        gp.quicksum(eco_energy_intensity * x_eco[i, j] for (i, j) in x_eco) <= max_total_energy_kwh,
        name="energy_limit"
    )

    # Solve the model
    model.optimize()

    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
