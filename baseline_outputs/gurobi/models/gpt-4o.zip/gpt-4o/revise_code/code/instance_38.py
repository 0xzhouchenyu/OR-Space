import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_processing_times(filepath):
    """Load processing times from CSV file."""
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times

def load_general_parameters(filepath):
    """Load general parameters from CSV file."""
    parameters = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            parameters[row[0]] = float(row[1])
    return parameters

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    processing_times = load_processing_times(os.path.join(data_dir, "table_1.csv"))
    parameters = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    n_products = len(processing_times)
    n_machines = len(processing_times[0])
    
    # Create model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(n_products, n_products, vtype=GRB.BINARY, name="x")  # Sequencing variables
    s = model.addVars(n_products, n_machines, vtype=GRB.CONTINUOUS, name="s")  # Start times
    c = model.addVars(n_products, n_machines, vtype=GRB.CONTINUOUS, name="c")  # Completion times
    overtime = model.addVars(n_machines, vtype=GRB.CONTINUOUS, name="overtime")  # Overtime usage
    
    # Objective: Minimize makespan + overtime penalties
    machine1_overtime_review_fee = parameters["machine1_overtime_review_fee"]
    machine1_overtime_review_threshold = parameters["machine1_overtime_review_threshold"]
    overtime_penalty_per_unit = parameters["overtime_penalty_per_unit"]
    
    makespan = model.addVar(vtype=GRB.CONTINUOUS, name="makespan")
    model.setObjective(
        makespan + gp.quicksum(overtime_penalty_per_unit * overtime[j] for j in range(n_machines)) +
        gp.ifThen(overtime[0] > machine1_overtime_review_threshold, machine1_overtime_review_fee, 0),
        GRB.MINIMIZE
    )
    
    # Constraints
    # Sequencing constraints
    for i in range(n_products):
        model.addConstr(gp.quicksum(x[i, j] for j in range(n_products)) == 1, name=f"seq_row_{i}")
        model.addConstr(gp.quicksum(x[j, i] for j in range(n_products)) == 1, name=f"seq_col_{i}")
    
    # Start and completion time constraints
    for i in range(n_products):
        for j in range(n_machines):
            model.addConstr(c[i, j] == s[i, j] + processing_times[i][j], name=f"completion_{i}_{j}")
            if j > 0:
                model.addConstr(s[i, j] >= c[i, j - 1], name=f"machine_sequence_{i}_{j}")
    
    # Machine availability constraints
    for j in range(n_machines):
        model.addConstr(
            gp.quicksum(processing_times[i][j] for i in range(n_products)) <= parameters[f"time_window_{j + 1}"] + overtime[j],
            name=f"machine_availability_{j}"
        )
        model.addConstr(overtime[j] <= parameters[f"overtime_window_{j + 1}"], name=f"overtime_limit_{j}")
    
    # Makespan definition
    for i in range(n_products):
        model.addConstr(makespan >= c[i, n_machines - 1], name=f"makespan_{i}")
    
    # Solve model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
