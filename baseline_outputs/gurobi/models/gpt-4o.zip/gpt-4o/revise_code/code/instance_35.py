import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    
    # Load batch processing times
    batches = []
    processing_times = []
    with open(table_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        num_vats = len(header) - 1  # exclude Batch column
        for row in reader:
            batch_id = int(row[0])
            times = [math.ceil(float(row[j+1])) for j in range(num_vats)]
            batches.append(batch_id)
            processing_times.append(times)
    
    # Load general parameters
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            params[row[0]] = float(row[1])
    
    return batches, processing_times, num_vats, params

def solve():
    # Load data
    batches, processing_times, num_vats, params = load_data()
    n = len(batches)
    T = int(params["planning_horizon_T"])
    energy_costs = [params["energy_cost_v1"], params["energy_cost_v2"], params["energy_cost_v3"]]
    peak_multiplier = params["peak_energy_multiplier"]
    peak_cap = params["peak_energy_cap"]
    makespan_weight = params["makespan_weight"]
    energy_weight = params["energy_weight"]
    
    # Create model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(n, num_vats, T, vtype=GRB.BINARY, name="x")
    y = model.addVars(num_vats, T, vtype=GRB.BINARY, name="y")
    makespan = model.addVar(vtype=GRB.CONTINUOUS, name="makespan")
    
    # Constraints
    for i in range(n):
        for j in range(num_vats):
            model.addConstr(gp.quicksum(x[i, j, t] for t in range(T)) == 1, name=f"batch_once_{i}_{j}")
    
    for j in range(num_vats):
        for t in range(T):
            model.addConstr(gp.quicksum(x[i, j, t] for i in range(n)) <= 1, name=f"vat_capacity_{j}_{t}")
    
    for i in range(n):
        for j in range(num_vats - 1):
            for t in range(T):
                if t + processing_times[i][j] < T:
                    model.addConstr(
                        gp.quicksum(x[i, j, t_prime] for t_prime in range(t, t + processing_times[i][j])) ==
                        processing_times[i][j] * x[i, j, t], name=f"uninterrupted_{i}_{j}_{t}"
                    )
                    model.addConstr(
                        gp.quicksum(x[i, j + 1, t_prime] for t_prime in range(t + processing_times[i][j], T)) >=
                        x[i, j, t], name=f"handoff_{i}_{j}_{t}"
                    )
    
    for i in range(n):
        for t in range(T):
            if t + processing_times[i][num_vats - 1] < T:
                model.addConstr(
                    gp.quicksum(x[i, num_vats - 1, t_prime] for t_prime in range(t, t + processing_times[i][num_vats - 1])) ==
                    processing_times[i][num_vats - 1] * x[i, num_vats - 1, t], name=f"uninterrupted_last_{i}_{t}"
                )
    
    for t in range(4, 6):
        model.addConstr(gp.quicksum(x[i, 1, t_prime] for i in range(n) for t_prime in range(t)) == 0, name=f"maintenance_{t}")
    
    for j in range(num_vats):
        for t in range(T):
            model.addConstr(y[j, t] == gp.quicksum(x[i, j, t_prime] for i in range(n) for t_prime in range(max(0, t - processing_times[i][j] + 1), t + 1)), name=f"active_indicator_{j}_{t}")
    
    for t in range(6, 9):
        model.addConstr(gp.quicksum(y[j, t] * energy_costs[j] * peak_multiplier for j in range(num_vats)) <= peak_cap, name=f"peak_cap_{t}")
    
    for i in range(n):
        for j in range(num_vats):
            for t in range(T):
                if t + processing_times[i][j] <= T:
                    model.addConstr(makespan >= t + processing_times[i][j] * x[i, j, t], name=f"makespan_{i}_{j}_{t}")
    
    # Objective
    energy_cost = gp.quicksum(
        y[j, t] * energy_costs[j] * (peak_multiplier if 6 <= t <= 8 else 1.0)
        for j in range(num_vats) for t in range(T)
    )
    model.setObjective(makespan_weight * makespan + energy_weight * energy_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Output result
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
