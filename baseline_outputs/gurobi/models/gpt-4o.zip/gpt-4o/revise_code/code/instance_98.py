import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Create Gurobi model
    model = gp.Model("Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    for p in products:
        x[p['Product']] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{p['Product']}", lb=0)
    
    # Binary variable for Product A line audit fee
    y_audit = model.addVar(vtype=GRB.BINARY, name="y_audit")
    
    # Binary variable for overtime review fee
    y_overtime = model.addVar(vtype=GRB.BINARY, name="y_overtime")
    
    # Objective: maximize profit
    profit_expr = gp.quicksum(
        (float(p['Profit_yuan']) - float(p['Setup_Cost_yuan'])) * x[p['Product']] for p in products
    )
    audit_cost_expr = y_audit * params['product_A_line_audit_fee']
    overtime_cost_expr = y_overtime * params['overtime_review_fee']
    model.setObjective(profit_expr - audit_cost_expr - overtime_cost_expr, GRB.MAXIMIZE)
    
    # Constraints
    # Steel constraint
    model.addConstr(
        gp.quicksum(float(p['Steel_Required_kg']) * x[p['Product']] for p in products) <= params['available_steel'],
        "Steel"
    )
    
    # Aluminum constraint
    model.addConstr(
        gp.quicksum(float(p['Aluminum_Required_kg']) * x[p['Product']] for p in products) <= params['available_aluminum'],
        "Aluminum"
    )
    
    # Labor constraint (including overtime)
    total_labor = gp.quicksum(float(p['Labor_Required_hours']) * x[p['Product']] for p in products)
    model.addConstr(total_labor <= params['available_labor'] + params['max_overtime'], "Labor")
    
    # Overtime review fee constraint
    model.addConstr(
        total_labor - params['available_labor'] <= params['max_overtime'] * y_overtime,
        "Overtime_Review_Trigger"
    )
    model.addConstr(
        total_labor - params['available_labor'] <= params['overtime_review_threshold'] + 
        (params['max_overtime'] - params['overtime_review_threshold']) * y_overtime,
        "Overtime_Threshold"
    )
    
    # Product A line audit fee constraint
    model.addConstr(
        x['A'] <= params['product_A_line_audit_threshold'] + 
        (gp.GRB.INFINITY * y_audit),
        "Line_Audit_Trigger"
    )
    model.addConstr(
        x['A'] > params['product_A_line_audit_threshold'] - 
        (gp.GRB.INFINITY * (1 - y_audit)),
        "Line_Audit_Threshold"
    )
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
