import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load the bandwidth table
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    filepath = os.path.join(data_dir, "table_1.csv")
    
    with open(filepath, "r") as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        
        bandwidth = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                bandwidth[(row_node, col_node)] = bw

    # Define the cost as 100 - bandwidth
    cost = {(i, j): 100 - bw for (i, j), bw in bandwidth.items() if bw > 0}

    # Create Gurobi model
    model = gp.Model()
    model.setParam('OutputFlag', 0)

    # Variables: x[i, j] = 1 if edge (i, j) is used, 0 otherwise
    x = model.addVars(cost.keys(), vtype=GRB.BINARY, name="x")

    # Objective: Minimize total routing cost
    model.setObjective(gp.quicksum(cost[i, j] * x[i, j] for i, j in cost), GRB.MINIMIZE)

    # Constraints
    # Flow conservation constraints
    nodes_set = set(nodes)
    for node in nodes_set:
        if node == "A":
            model.addConstr(gp.quicksum(x[i, j] for i, j in cost if i == node) - 
                            gp.quicksum(x[j, i] for j, i in cost if i == node) == 1)
        elif node == "E":
            model.addConstr(gp.quicksum(x[i, j] for i, j in cost if i == node) - 
                            gp.quicksum(x[j, i] for j, i in cost if i == node) == -1)
        else:
            model.addConstr(gp.quicksum(x[i, j] for i, j in cost if i == node) - 
                            gp.quicksum(x[j, i] for j, i in cost if i == node) == 0)

    # Path must pass through C
    model.addConstr(gp.quicksum(x[i, "C"] for i in nodes_set if (i, "C") in cost) == 1)
    model.addConstr(gp.quicksum(x["C", j] for j in nodes_set if ("C", j) in cost) == 1)

    # Solve the model
    model.optimize()

    # Output the result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: No solution found")

if __name__ == "__main__":
    main()
