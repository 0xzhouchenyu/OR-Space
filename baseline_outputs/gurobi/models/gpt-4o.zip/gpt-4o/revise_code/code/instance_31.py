import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Parse data files
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Processing times, capacities, and costs from table_1.csv
    proc_time = {}  # (equipment, product) -> hours per unit
    capacity = {}   # equipment -> available hours
    cost_rate = {}  # equipment -> cost per machine hour
    raw_cost = {}   # product -> raw material cost
    price = {}      # product -> unit price
    
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row["Equipment"].strip()
            if equip == "Raw_Material_Cost":
                raw_cost = {"I": float(row["Product_I"]), "II": float(row["Product_II"]), "III": float(row["Product_III"])}
            elif equip == "Unit_Price":
                price = {"I": float(row["Product_I"]), "II": float(row["Product_II"]), "III": float(row["Product_III"])}
            else:
                for prod, col in [("I", "Product_I"), ("II", "Product_II"), ("III", "Product_III")]:
                    val = row[col].strip()
                    if val != "-":
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row["Effective_Machine_Hours"])
                cost_rate[equip] = float(row["Processing_Cost_per_Machine_Hour"])
    
    # Setup costs from setup_costs.csv
    setup_cost = {}
    with open(os.path.join(data_dir, "setup_costs.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            setup_cost[row["Equipment"].strip()] = float(row["Fixed_Setup_Cost"])
    
    # Equipment assignments from general_parameters.csv
    stage_A_equip = {"I": ["A1", "A2"], "II": ["A1", "A2"], "III": ["A2"]}
    stage_B_equip = {"I": ["B1", "B2", "B3"], "II": ["B1"], "III": ["B2"]}
    joint_calibration_trigger = 1
    joint_calibration_fee = 100
    
    # Create optimization model
    model = gp.Model("Factory_Production")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    x = {}  # x[(equip, prod)] = units of product processed on equipment
    for prod in ["I", "II", "III"]:
        for equip in stage_A_equip[prod]:
            x[(equip, prod)] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{equip}_{prod}", lb=0)
        for equip in stage_B_equip[prod]:
            x[(equip, prod)] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{equip}_{prod}", lb=0)
    
    # Binary variables for setup costs
    y = {}  # y[equip] = 1 if equipment is used, 0 otherwise
    for equip in ["A1", "A2", "B1", "B2", "B3"]:
        y[equip] = model.addVar(vtype=GRB.BINARY, name=f"y_{equip}")
    
    # Total production of each product
    total = {}
    for prod in ["I", "II", "III"]:
        total[prod] = gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod])
        # Flow conservation: stage A total == stage B total
        model.addConstr(
            gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod]) == 
            gp.quicksum(x[(e, prod)] for e in stage_B_equip[prod])
        )
    
    # Capacity constraints
    for equip in ["A1", "A2", "B1", "B2", "B3"]:
        relevant = [(equip, prod) for prod in ["I", "II", "III"] if (equip, prod) in x]
        if relevant:
            model.addConstr(
                gp.quicksum(proc_time[(equip, prod)] * x[(equip, prod)] for equip2, prod in relevant) <= capacity[equip]
            )
            # Link binary setup variable to usage
            model.addConstr(
                gp.quicksum(x[(equip, prod)] for equip2, prod in relevant) <= capacity[equip] * y[equip]
            )
    
    # Joint calibration constraint for A2 and B2
    model.addConstr(y["A2"] + y["B2"] <= 2)  # Both can be active
    joint_calibration_penalty = joint_calibration_fee * gp.and_(y["A2"], y["B2"])
    
    # Objective: profit = revenue - raw material - processing cost - setup cost - joint calibration fee
    revenue = gp.quicksum(price[p] * total[p] for p in ["I", "II", "III"])
    raw_mat = gp.quicksum(raw_cost[p] * total[p] for p in ["I", "II", "III"])
    proc_cost = gp.quicksum(cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x)
    setup_cost_total = gp.quicksum(setup_cost[e] * y[e] for e in y)
    
    model.setObjective(revenue - raw_mat - proc_cost - setup_cost_total - joint_calibration_penalty, GRB.MAXIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")

main()
