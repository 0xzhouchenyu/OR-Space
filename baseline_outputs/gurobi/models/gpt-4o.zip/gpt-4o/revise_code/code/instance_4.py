import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
cow_price = params['cow_selling_price']
sheep_price = params['sheep_selling_price']
chicken_price = params['chicken_selling_price']
cow_feed = params['cow_feed_cost']
sheep_feed = params['sheep_feed_cost']
chicken_feed = params['chicken_feed_cost']
cow_manure = params['cow_manure_production']
sheep_manure = params['sheep_manure_production']
chicken_manure = params['chicken_manure_production']
max_manure = params['max_manure_capacity']
max_chickens = params['max_chickens']
min_cows = params['min_cows']
min_sheep = params['min_sheep']
max_total = params['max_total_animals']
premium_capacity_multiplier = params['premium_capacity_multiplier']
premium_manure_multiplier = params['premium_manure_multiplier']
expansion_cost = params['expansion_cost']
premium_feed_multiplier = params['premium_feed_multiplier']
base_land_cow = params['base_land_usage_cow']
base_land_sheep = params['base_land_usage_sheep']
base_land_chicken = params['base_land_usage_chicken']
base_land_capacity = params['base_land_capacity']
expansion_land_increase = params['expansion_land_increase']

# Create model
model = gp.Model("FarmProfit")
model.setParam('OutputFlag', 0)

# Decision variables
cows = model.addVar(vtype=GRB.INTEGER, lb=min_cows, name="cows")
sheep = model.addVar(vtype=GRB.INTEGER, lb=min_sheep, name="sheep")
chickens = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_chickens, name="chickens")
premium_mode = model.addVar(vtype=GRB.BINARY, name="premium_mode")

# Adjusted parameters for premium mode
effective_max_total = max_total + premium_mode * (premium_capacity_multiplier * max_total - max_total)
effective_max_manure = max_manure + premium_mode * (premium_manure_multiplier * max_manure - max_manure)
effective_land_capacity = base_land_capacity + premium_mode * expansion_land_increase

# Objective: maximize profit
profit_regular = (cow_price - cow_feed) * cows + (sheep_price - sheep_feed) * sheep + (chicken_price - chicken_feed) * chickens
profit_premium = premium_mode * (-expansion_cost + 
    (cow_price - premium_feed_multiplier * cow_feed) * cows + 
    (sheep_price - premium_feed_multiplier * sheep_feed) * sheep + 
    (chicken_price - premium_feed_multiplier * chicken_feed) * chickens)
model.setObjective(profit_regular + profit_premium, GRB.MAXIMIZE)

# Constraints
model.addConstr(cow_manure * cows + sheep_manure * sheep + chicken_manure * chickens <= effective_max_manure, "ManureCapacity")
model.addConstr(cows + sheep + chickens <= effective_max_total, "TotalAnimals")
model.addConstr(base_land_cow * cows + base_land_sheep * sheep + base_land_chicken * chickens <= effective_land_capacity, "LandCapacity")
model.addConstr(premium_mode * (cows + sheep + chickens) >= premium_mode * (min_cows + min_sheep), "PremiumEligibility")

# Solve
model.optimize()

# Output result
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
