import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

    # Extract parameters
    profits = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons'],
    }
    water_spring = {
        'apples': params['water_per_acre_apples_spring'],
        'pears': params['water_per_acre_pears_spring'],
        'oranges': params['water_per_acre_oranges_spring'],
        'lemons': params['water_per_acre_lemons_spring'],
    }
    water_autumn = {
        'apples': params['water_per_acre_apples_autumn'],
        'pears': params['water_per_acre_pears_autumn'],
        'oranges': params['water_per_acre_oranges_autumn'],
        'lemons': params['water_per_acre_lemons_autumn'],
    }
    total_area = params['total_farm_area']
    min_a_to_p = params['min_apples_to_pears_ratio']
    min_a_to_l = params['min_apples_to_lemons_ratio']
    o_to_l = params['oranges_to_lemons_ratio']
    max_types = int(params['max_fruit_types'])
    water_cap_spring = params['water_cap_spring']
    water_cap_autumn = params['water_cap_autumn']
    total_water_budget = params['total_water_budget']
    min_annual_water = params['min_annual_water_per_fruit']
    diversification_reward = params['diversification_reward']

    fruits = ['apples', 'pears', 'oranges', 'lemons']

    # Create model
    model = gp.Model("farm_optimization")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x_spring = {f: model.addVar(lb=0, name=f"x_spring_{f}") for f in fruits}
    x_autumn = {f: model.addVar(lb=0, name=f"x_autumn_{f}") for f in fruits}
    y = {f: model.addVar(vtype=GRB.BINARY, name=f"y_{f}") for f in fruits}  # Binary for fruit selection

    # Objective function
    profit_spring = gp.quicksum(profits[f] * x_spring[f] for f in fruits)
    profit_autumn = gp.quicksum(profits[f] * x_autumn[f] for f in fruits)
    diversification = diversification_reward * gp.quicksum(y[f] for f in fruits) >= 2
    model.setObjective(profit_spring + profit_autumn + diversification_reward * diversification, GRB.MAXIMIZE)

    # Constraints
    # Seasonal land constraints
    model.addConstr(gp.quicksum(x_spring[f] for f in fruits) <= total_area, "spring_land")
    model.addConstr(gp.quicksum(x_autumn[f] for f in fruits) <= total_area, "autumn_land")

    # Seasonal water constraints
    model.addConstr(gp.quicksum(water_spring[f] * x_spring[f] for f in fruits) <= water_cap_spring, "spring_water")
    model.addConstr(gp.quicksum(water_autumn[f] * x_autumn[f] for f in fruits) <= water_cap_autumn, "autumn_water")

    # Annual water constraint
    model.addConstr(
        gp.quicksum(water_spring[f] * x_spring[f] + water_autumn[f] * x_autumn[f] for f in fruits) <= total_water_budget,
        "annual_water"
    )

    # Minimum annual water per fruit
    for f in fruits:
        model.addConstr(
            water_spring[f] * x_spring[f] + water_autumn[f] * x_autumn[f] >= min_annual_water * y[f],
            f"min_water_{f}"
        )

    # Fruit type limit
    model.addConstr(gp.quicksum(y[f] for f in fruits) <= max_types, "max_fruit_types")

    # Annual land ratio constraints
    model.addConstr(
        gp.quicksum(x_spring['apples'] + x_autumn['apples']) >= min_a_to_p * gp.quicksum(x_spring['pears'] + x_autumn['pears']),
        "apples_pears_ratio"
    )
    model.addConstr(
        gp.quicksum(x_spring['apples'] + x_autumn['apples']) >= min_a_to_l * gp.quicksum(x_spring['lemons'] + x_autumn['lemons']),
        "apples_lemons_ratio"
    )
    model.addConstr(
        gp.quicksum(x_spring['oranges'] + x_autumn['oranges']) == o_to_l * gp.quicksum(x_spring['lemons'] + x_autumn['lemons']),
        "oranges_lemons_ratio"
    )

    # Binary activation for fruit types
    for f in fruits:
        model.addConstr(x_spring[f] + x_autumn[f] <= total_area * y[f], f"binary_activation_{f}")

    # Solve model
    model.optimize()

    # Output result
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

solve()
