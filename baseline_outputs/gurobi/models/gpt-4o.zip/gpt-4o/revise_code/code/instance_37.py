import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, "table_1.csv")
    with open(table1_path, "r") as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = [row for row in reader]
    
    # Parse process data
    a_I = float(rows[0][1])  # Model A hours for Process I
    b_I = float(rows[0][2])  # Model B hours for Process I
    a_II = float(rows[1][1])  # Model A hours for Process II
    b_II = float(rows[1][2])  # Model B hours for Process II
    profit_A = float(rows[2][1])  # Profit per unit Model A
    profit_B = float(rows[2][2])  # Profit per unit Model B
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "general_parameters.csv")
    params = {}
    with open(params_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"])
    
    # Extract parameters
    min_profit = params["min_weekly_profit"]
    min_A = params["min_model_A_units"]
    min_B = params["min_model_B_units"]
    week1_min_A = params["week1_min_model_A_units"]
    week1_min_B = params["week1_min_model_B_units"]
    week2_min_A = params["week2_min_model_A_units"]
    week2_min_B = params["week2_min_model_B_units"]
    reg_I = params["process_I_hours"]
    reg_II = params["process_II_hours"]
    max_ot_I = params["max_overtime_I_per_week"]
    max_ot_II = params["max_overtime_II_per_week"]
    ot_premium_I = params["overtime_premium_I"]
    ot_premium_II = params["overtime_premium_II"]
    min_util_I = params["min_avg_utilization_I"]
    min_util_II = params["min_avg_utilization_II"]
    fatigue_I = params["week1_overtime_fatigue_threshold_I"]
    fatigue_II = params["week1_overtime_fatigue_threshold_II"]
    recovery_I = params["week2_recovery_loss_I"]
    recovery_II = params["week2_recovery_loss_II"]
    
    # Create model
    model = gp.Model("Two_Week_Microcomputer_Production")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    x_A1 = model.addVar(lb=0, name="x_A1")  # Model A units in week 1
    x_B1 = model.addVar(lb=0, name="x_B1")  # Model B units in week 1
    x_A2 = model.addVar(lb=0, name="x_A2")  # Model A units in week 2
    x_B2 = model.addVar(lb=0, name="x_B2")  # Model B units in week 2
    ot_I1 = model.addVar(lb=0, ub=max_ot_I, name="ot_I1")  # Overtime Process I week 1
    ot_II1 = model.addVar(lb=0, ub=max_ot_II, name="ot_II1")  # Overtime Process II week 1
    ot_I2 = model.addVar(lb=0, ub=max_ot_I, name="ot_I2")  # Overtime Process I week 2
    ot_II2 = model.addVar(lb=0, ub=max_ot_II, name="ot_II2")  # Overtime Process II week 2
    
    # Objective: Maximize profit over two weeks minus overtime costs
    profit_week1 = profit_A * x_A1 + profit_B * x_B1 - ot_premium_I * ot_I1 - ot_premium_II * ot_II1
    profit_week2 = profit_A * x_A2 + profit_B * x_B2 - ot_premium_I * ot_I2 - ot_premium_II * ot_II2
    model.setObjective(profit_week1 + profit_week2, GRB.MAXIMIZE)
    
    # Constraints
    # Process I capacity
    model.addConstr(a_I * x_A1 + b_I * x_B1 <= reg_I + ot_I1, "Process_I_Week1")
    model.addConstr(a_I * x_A2 + b_I * x_B2 <= reg_I + ot_I2 - (recovery_I if ot_I1 > fatigue_I else 0), "Process_I_Week2")
    # Process II capacity
    model.addConstr(a_II * x_A1 + b_II * x_B1 <= reg_II + ot_II1, "Process_II_Week1")
    model.addConstr(a_II * x_A2 + b_II * x_B2 <= reg_II + ot_II2 - (recovery_II if ot_II1 > fatigue_II else 0), "Process_II_Week2")
    # Weekly delivery requirements
    model.addConstr(x_A1 >= week1_min_A, "Week1_Min_Model_A")
    model.addConstr(x_B1 >= week1_min_B, "Week1_Min_Model_B")
    model.addConstr(x_A2 >= week2_min_A, "Week2_Min_Model_A")
    model.addConstr(x_B2 >= week2_min_B, "Week2_Min_Model_B")
    # Total production requirements
    model.addConstr(x_A1 + x_A2 >= min_A, "Total_Min_Model_A")
    model.addConstr(x_B1 + x_B2 >= min_B, "Total_Min_Model_B")
    # Minimum profit
    model.addConstr(profit_week1 + profit_week2 >= min_profit, "Min_Profit")
    # Minimum average utilization
    model.addConstr((a_I * (x_A1 + x_A2) + b_I * (x_B1 + x_B2)) / (2 * reg_I) >= min_util_I, "Min_Util_I")
    model.addConstr((a_II * (x_A1 + x_A2) + b_II * (x_B1 + x_B2)) / (2 * reg_II) >= min_util_II, "Min_Util_II")
    
    # Solve model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
