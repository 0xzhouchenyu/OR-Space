import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    base = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base, 'data')
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {row['Parameter_Name']: float(row['Value']) for row in reader}
    
    n = int(params['n'])
    premium_cost_multiplier = params['premium_cost_multiplier']
    min_premium_share = params['min_premium_share']
    
    d = []
    c = []
    for row in rows:
        d.append([float(row[f'Transportation_volume_to_Location_{j+1}']) for j in range(n)])
        c.append([float(row[f'Transportation_cost_to_Location_{j+1}']) for j in range(n)])
    
    # Calculate outbound volumes and standard costs
    outbound_volume = [sum(d[i]) for i in range(n)]
    c_std = [[(sum(d[i][j] * c[p][j] for j in range(n)) / outbound_volume[i]) if outbound_volume[i] > 0 else 0
              for p in range(n)] for i in range(n)]
    c_prem = [[premium_cost_multiplier * c_std[i][p] for p in range(n)] for i in range(n)]
    
    # Create model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")  # x[i,p]: factory i assigned to location p
    y = model.addVars(n, n, vtype=GRB.BINARY, name="y")  # y[i,p]: premium mode for factory i at location p
    v_std = model.addVars(n, n, vtype=GRB.CONTINUOUS, name="v_std")  # v_std[i,p]: standard volume
    v_prem = model.addVars(n, n, vtype=GRB.CONTINUOUS, name="v_prem")  # v_prem[i,p]: premium volume
    
    # Constraints
    # Each factory is assigned to exactly one location
    model.addConstrs((gp.quicksum(x[i, p] for p in range(n)) == 1 for i in range(n)), name="assign_factory")
    
    # Each location hosts at most one factory
    model.addConstrs((gp.quicksum(x[i, p] for i in range(n)) <= 1 for p in range(n)), name="assign_location")
    
    # Total volume from a factory equals its outbound volume
    model.addConstrs((gp.quicksum(v_std[i, p] + v_prem[i, p] for p in range(n)) == outbound_volume[i]
                      for i in range(n)), name="total_volume")
    
    # Premium volume is at least min_premium_share if premium is selected
    model.addConstrs((v_prem[i, p] >= min_premium_share * outbound_volume[i] * y[i, p]
                      for i in range(n) for p in range(n)), name="min_premium_share")
    
    # Premium volume is zero if premium is not selected
    model.addConstrs((v_prem[i, p] <= outbound_volume[i] * y[i, p]
                      for i in range(n) for p in range(n)), name="premium_volume_zero")
    
    # Standard volume is zero if factory is not assigned to location
    model.addConstrs((v_std[i, p] <= outbound_volume[i] * x[i, p]
                      for i in range(n) for p in range(n)), name="standard_volume_zero")
    
    # Premium volume is zero if factory is not assigned to location
    model.addConstrs((v_prem[i, p] <= outbound_volume[i] * x[i, p]
                      for i in range(n) for p in range(n)), name="premium_volume_zero_assignment")
    
    # Objective: Minimize total cost
    total_cost = gp.quicksum(
        v_std[i, p] * c_std[i][p] + v_prem[i, p] * c_prem[i][p]
        for i in range(n) for p in range(n)
    )
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Solve model
    model.optimize()
    
    # Output result
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

solve()
