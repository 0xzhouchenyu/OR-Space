import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    
    df = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)
    
    # Extract parameters
    budget = float(params[params['Parameter_Name'] == 'budget']['Value'].iloc[0])
    food_intake = float(params[params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
    weekday_budget_share = float(params[params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
    max_prep_time_weekday = float(params[params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
    max_prep_time_weekend = float(params[params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
    weekend_protein_ban = int(params[params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
    veg_balance_penalty = float(params[params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])
    
    # Fill missing fiber content with 0
    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)
    
    foods = df['Food'].tolist()
    types = df.set_index('Food')['Type'].to_dict()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()
    
    # Create model
    model = gp.Model("Maximize_Fiber")
    model.setParam('OutputFlag', 0)
    
    # Variables: x is amount in 100g units for weekday and weekend
    x_weekday = model.addVars(foods, lb=0, name="x_weekday")
    x_weekend = model.addVars(foods, lb=0, name="x_weekend")
    y = model.addVars(foods, vtype=GRB.BINARY, name="y")
    
    # Objective: maximize fiber intake minus vegetable balance penalty
    total_fiber_weekday = gp.quicksum(fiber[f] * x_weekday[f] for f in foods)
    total_fiber_weekend = gp.quicksum(fiber[f] * x_weekend[f] for f in foods)
    veg_balance = gp.quicksum((x_weekday[f] - x_weekend[f]).abs() for f in foods if types[f] == 'vegetable')
    model.setObjective(total_fiber_weekday + total_fiber_weekend - veg_balance_penalty * veg_balance, GRB.MAXIMIZE)
    
    # Constraints
    # Total food intake for each day
    model.addConstr(gp.quicksum(x_weekday[f] for f in foods) == food_intake / 100.0, "FoodIntake_Weekday")
    model.addConstr(gp.quicksum(x_weekend[f] for f in foods) == food_intake / 100.0, "FoodIntake_Weekend")
    
    # Budget constraints
    weekday_budget = budget * weekday_budget_share
    weekend_budget = budget * (1 - weekday_budget_share)
    model.addConstr(gp.quicksum(price[f] * x_weekday[f] for f in foods) <= weekday_budget, "Budget_Weekday")
    model.addConstr(gp.quicksum(price[f] * x_weekend[f] for f in foods) <= weekend_budget, "Budget_Weekend")
    
    # Prep time constraints
    model.addConstr(gp.quicksum(prep_time[f] * x_weekday[f] for f in foods) <= max_prep_time_weekday, "PrepTime_Weekday")
    model.addConstr(gp.quicksum(prep_time[f] * x_weekend[f] for f in foods) <= max_prep_time_weekend, "PrepTime_Weekend")
    
    # Protein constraints
    proteins = [f for f in foods if types[f] == 'protein']
    model.addConstr(gp.quicksum(y[f] for f in proteins) >= 1, "Protein_Used")
    model.addConstr(gp.quicksum(x_weekend[f] for f in proteins) == 0 if weekend_protein_ban else GRB.INFINITY, "Protein_Ban_Weekend")
    
    # At least two kinds of vegetables per day
    vegetables = [f for f in foods if types[f] == 'vegetable']
    model.addConstr(gp.quicksum(y[f] for f in vegetables) >= 2, "Vegetables_Weekday")
    model.addConstr(gp.quicksum(y[f] for f in vegetables) >= 2, "Vegetables_Weekend")
    
    # Linking constraints and minimum inclusion amount (0.1 units of 100g = 10g)
    M = food_intake / 100.0
    for f in foods:
        model.addConstr(x_weekday[f] >= 0.1 * y[f], f"Linking_Weekday_{f}")
        model.addConstr(x_weekday[f] <= M * y[f], f"Linking_Weekday_{f}_Max")
        model.addConstr(x_weekend[f] >= 0.1 * y[f], f"Linking_Weekend_{f}")
        model.addConstr(x_weekend[f] <= M * y[f], f"Linking_Weekend_{f}_Max")
    
    # Solve the model
    model.optimize()
    
    # Output the result
    print(f"FINAL_OBJ_VALUE: {round(model.objVal, 4)}")

if __name__ == '__main__':
    solve()
