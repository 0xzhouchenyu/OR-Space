import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load parameters
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(csv_path)
    params = dict(zip(df['Parameter_Name'], df['Value']))

    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # Create model
    model = gp.Model("Maximize_GDP")
    model.setParam('OutputFlag', 0)

    # Variables: Production levels, imports, and overtime labor
    x = {c: model.addVar(lb=0, ub=params.get(f"{c}_production_limit", GRB.INFINITY), name=f"x_{c}") for c in commodities}
    imports = {c: model.addVar(lb=0, ub=params['import_quota'], name=f"import_{c}") for c in commodities}
    overtime_labor = model.addVar(lb=0, ub=params['overtime_cap'], name="overtime_labor")

    # Net export of each commodity = Production - Domestic Consumption
    net_export = {}
    for c in commodities:
        consumed = gp.quicksum(
            params.get(f"{c_prime}_{c}_requirement", 0.0) * x[c_prime]
            for c_prime in commodities
        )
        net_export[c] = x[c] - consumed

    # Regular labor usage
    regular_labor = gp.quicksum(
        params.get(f"{c}_labor_requirement", 0.0) * x[c] for c in commodities
    )

    # Total labor usage
    total_labor = regular_labor + overtime_labor

    # Import costs
    import_costs = gp.quicksum(
        params['import_premium_ratio'] * params[f"{c}_price"] * imports[c] for c in commodities
    )

    # Overtime labor costs
    overtime_costs = params['overtime_wage'] * overtime_labor

    # Objective: GDP = Export revenue - Import costs - Overtime labor costs
    gdp = gp.quicksum(params[f"{c}_price"] * net_export[c] for c in commodities) - import_costs - overtime_costs
    model.setObjective(gdp, GRB.MAXIMIZE)

    # Constraints:
    # 1. Domestic production + imports must satisfy domestic demand
    for c in commodities:
        model.addConstr(net_export[c] + imports[c] >= 0, name=f"Domestic_Demand_{c}")

    # 2. Total labor usage must not exceed available labor
    model.addConstr(total_labor <= params['labor_force'] + params['overtime_cap'], name="Labor_Limit")

    # Solve the model
    model.optimize()

    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 3)}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == '__main__':
    solve()
