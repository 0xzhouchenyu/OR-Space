import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read device data
devices = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            "name": row["Device"].strip(),
            "prep_cost": float(row["Prep_Completion_Cost_Yuan"].strip()),
            "unit_cost": float(row["Unit_Production_Cost_Yuan_per_Unit"].strip()),
            "max_cap": float(row["Max_Processing_Capacity_Units"].strip())
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

required_units = params["required_units"]
energy_budget_peak = params["energy_budget_peak"]
energy_budget_offpeak = params["energy_budget_offpeak"]
startup_budget = params["startup_budget"]
energy_price_peak = params["energy_price_peak"]
energy_price_offpeak = params["energy_price_offpeak"]
startup_cost = params["startup_cost"]

energy_per_unit = {
    "A": params["energy_per_unit_A"],
    "B": params["energy_per_unit_B"],
    "C": params["energy_per_unit_C"],
    "D": params["energy_per_unit_D"]
}

startup_energy = {
    "A": params["startup_energy_A"],
    "B": params["startup_energy_B"],
    "C": params["startup_energy_C"],
    "D": params["startup_energy_D"]
}

# Create the optimization model
model = gp.Model("MinCostProduction")
model.setParam('OutputFlag', 0)

n = len(devices)

# Decision variables
x_peak = {d["name"]: model.addVar(lb=0, ub=d["max_cap"], vtype=GRB.CONTINUOUS, name=f"x_peak_{d['name']}") for d in devices}
x_offpeak = {d["name"]: model.addVar(lb=0, ub=d["max_cap"], vtype=GRB.CONTINUOUS, name=f"x_offpeak_{d['name']}") for d in devices}
y_peak = {d["name"]: model.addVar(vtype=GRB.BINARY, name=f"y_peak_{d['name']}") for d in devices}
y_offpeak = {d["name"]: model.addVar(vtype=GRB.BINARY, name=f"y_offpeak_{d['name']}") for d in devices}

# Objective: minimize total cost
model.setObjective(
    gp.quicksum(
        d["prep_cost"] * (y_peak[d["name"]] + y_offpeak[d["name"]]) +
        d["unit_cost"] * (x_peak[d["name"]] + x_offpeak[d["name"]]) +
        startup_cost * (y_peak[d["name"]] + y_offpeak[d["name"]]) +
        energy_price_peak * energy_per_unit[d["name"]] * x_peak[d["name"]] +
        energy_price_offpeak * energy_per_unit[d["name"]] * x_offpeak[d["name"]]
        for d in devices
    ),
    GRB.MINIMIZE
)

# Constraints
# Total production must equal required units
model.addConstr(
    gp.quicksum(x_peak[d["name"]] + x_offpeak[d["name"]] for d in devices) == required_units,
    "TotalProduction"
)

# Linking constraints: x_i <= max_cap * y_i
for d in devices:
    model.addConstr(x_peak[d["name"]] <= d["max_cap"] * y_peak[d["name"]], f"Link_Peak_{d['name']}")
    model.addConstr(x_offpeak[d["name"]] <= d["max_cap"] * y_offpeak[d["name"]], f"Link_Offpeak_{d['name']}")

# Energy budget constraints
model.addConstr(
    gp.quicksum(
        energy_per_unit[d["name"]] * x_peak[d["name"]] +
        startup_energy[d["name"]] * y_peak[d["name"]]
        for d in devices
    ) <= energy_budget_peak,
    "EnergyBudgetPeak"
)

model.addConstr(
    gp.quicksum(
        energy_per_unit[d["name"]] * x_offpeak[d["name"]] +
        startup_energy[d["name"]] * y_offpeak[d["name"]]
        for d in devices
    ) <= energy_budget_offpeak,
    "EnergyBudgetOffpeak"
)

# Startup budget constraint
model.addConstr(
    gp.quicksum(
        startup_cost * (y_peak[d["name"]] + y_offpeak[d["name"]])
        for d in devices
    ) <= startup_budget,
    "StartupBudget"
)

# Solve the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
