import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read items and values
items = []
values = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        items.append(row["Item"].strip())
        values.append(int(row["Value"].strip()))

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Extract parameters
total_value = sum(values)
son1_min_share = params["son1_min_share"]
high_value_threshold = params["high_value_threshold"]
max_high_value_items_per_son = int(params["max_high_value_items_per_son"])
deferred_diamonds_per_son = int(params["deferred_diamonds_per_son"])
immediate_tax_weight = params["immediate_tax_weight"]
total_tax_weight = params["total_tax_weight"]

# Identify high-value items and diamonds
high_value_indices = [i for i, v in enumerate(values) if v > high_value_threshold]
diamond_indices = [i for i, item in enumerate(items) if "Diamond" in item]
jr_indices = [i for i, item in enumerate(items) if "Jack Russell" in item]

# Create the optimization model
model = gp.Model("Inheritance_Split")
model.setParam("OutputFlag", 0)

n = len(items)

# Binary variables for immediate assignment: x[i] = 1 if item i goes to son 1, 0 if to son 2
x = model.addVars(n, vtype=GRB.BINARY, name="x")

# Binary variables for deferred assignment: d[i] = 1 if item i is deferred to son 1, 0 if to son 2
d = model.addVars(n, vtype=GRB.BINARY, name="d")

# Variables for absolute differences
immediate_diff = model.addVar(lb=0, name="immediate_diff")
total_diff = model.addVar(lb=0, name="total_diff")

# Immediate and total values for son 1
immediate_value_son1 = gp.quicksum(values[i] * x[i] for i in range(n))
total_value_son1 = gp.quicksum(values[i] * (x[i] + d[i]) for i in range(n))

# Constraints for absolute differences
model.addConstr(immediate_diff >= immediate_value_son1 - (total_value - immediate_value_son1))
model.addConstr(immediate_diff >= (total_value - immediate_value_son1) - immediate_value_son1)
model.addConstr(total_diff >= total_value_son1 - (total_value - total_value_son1))
model.addConstr(total_diff >= (total_value - total_value_son1) - total_value_son1)

# Son 1 must receive at least the minimum share of the total value
model.addConstr(total_value_son1 >= son1_min_share * total_value)

# Jack Russell racing dogs must not be separated
if len(jr_indices) == 2:
    model.addConstr(x[jr_indices[0]] == x[jr_indices[1]])
    model.addConstr(d[jr_indices[0]] == d[jr_indices[1]])

# High-value item concentration limits
model.addConstr(gp.quicksum(x[i] for i in high_value_indices) <= max_high_value_items_per_son)
model.addConstr(gp.quicksum(1 - x[i] for i in high_value_indices) <= max_high_value_items_per_son)
model.addConstr(gp.quicksum(d[i] for i in high_value_indices) <= max_high_value_items_per_son)
model.addConstr(gp.quicksum(1 - d[i] for i in high_value_indices) <= max_high_value_items_per_son)

# Deferred diamond limits
model.addConstr(gp.quicksum(d[i] for i in diamond_indices) <= deferred_diamonds_per_son)
model.addConstr(gp.quicksum(1 - d[i] for i in diamond_indices) <= deferred_diamonds_per_son)

# Objective: minimize weighted sum of immediate and total differences
model.setObjective(immediate_tax_weight * immediate_diff + total_tax_weight * total_diff, GRB.MINIMIZE)

# Solve the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
