import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = float(params['fixed_order_cost'])
    august_bulk_order_threshold = int(params['august_bulk_order_threshold'])
    august_bulk_receiving_fee = float(params['august_bulk_receiving_fee'])
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create optimization model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = {m: model.addVar(lb=0, name=f"buy_{m}") for m in months}
    sell = {m: model.addVar(lb=0, name=f"sell_{m}") for m in months}
    stock = {m: model.addVar(lb=0, ub=warehouse_capacity, name=f"stock_{m}") for m in months}
    august_bulk_fee = model.addVar(vtype=GRB.BINARY, name="august_bulk_fee")
    
    # Objective: maximize total profit (revenue - cost)
    model.setObjective(
        gp.quicksum(sell_price[m] * sell[m] - buy_price[m] * buy[m] for m in months) -
        gp.quicksum(fixed_order_cost * (buy[m] > 0) for m in months) -
        august_bulk_fee * august_bulk_receiving_fee,
        GRB.MAXIMIZE
    )
    
    # Stock balance constraints
    for i, m in enumerate(months):
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_stock = stock[months[i-1]]
        
        # Stock balance: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], f"balance_{m}")
        
        # After buying, before selling, warehouse constraint:
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, f"warehouse_after_buy_{m}")
    
    # August bulk order constraint
    model.addConstr(buy[8] <= august_bulk_order_threshold + august_bulk_fee * warehouse_capacity, "august_bulk_limit")
    model.addConstr(august_bulk_fee >= (buy[8] - august_bulk_order_threshold) / warehouse_capacity, "august_bulk_fee_logic")
    
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
