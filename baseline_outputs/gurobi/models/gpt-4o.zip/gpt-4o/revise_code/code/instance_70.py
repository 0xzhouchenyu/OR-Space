import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_distance_matrix(filepath):
    """Load distance matrix from CSV file."""
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        city_labels = header[1:]
        dist = []
        cities = []
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
    return cities, dist

def load_general_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['parameter']] = int(row['value'])
    return params

def solve_tsp():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    dist_file = os.path.join(data_dir, "table_1.csv")
    params_file = os.path.join(data_dir, "general_parameters.csv")
    
    cities, dist = load_distance_matrix(dist_file)
    params = load_general_parameters(params_file)
    
    n = len(cities)
    start_city = params['start_city'] - 1
    end_city = params['end_city'] - 1
    prohibited_from = params['prohibited_from'] - 1
    prohibited_to = params['prohibited_to'] - 1
    inspection_arc_from = params['inspection_arc_from'] - 1
    inspection_arc_to = params['inspection_arc_to'] - 1
    inspection_stop_cost = params['inspection_stop_cost']
    
    # Adjust distance matrix for inspection stop cost
    dist[inspection_arc_from][inspection_arc_to] += inspection_stop_cost
    
    # Create Gurobi model
    model = gp.Model("TSP")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")
    u = model.addVars(n, vtype=GRB.CONTINUOUS, lb=0, ub=n-1, name="u")
    
    # Objective function
    model.setObjective(gp.quicksum(dist[i][j] * x[i, j] for i in range(n) for j in range(n) if i != j), GRB.MINIMIZE)
    
    # Constraints
    # Each city is left exactly once
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1)
    
    # Each city is entered exactly once
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(n) if i != j) == 1)
    
    # Subtour elimination (MTZ constraints)
    for i in range(1, n):
        for j in range(1, n):
            if i != j:
                model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1)
    
    # Prohibited arc
    model.addConstr(x[prohibited_from, prohibited_to] == 0)
    
    # Start and end city constraints
    model.addConstr(gp.quicksum(x[start_city, j] for j in range(n) if j != start_city) == 1)
    model.addConstr(gp.quicksum(x[i, end_city] for i in range(n) if i != end_city) == 1)
    
    # Solve the model
    model.optimize()
    
    # Output the result
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve_tsp()
