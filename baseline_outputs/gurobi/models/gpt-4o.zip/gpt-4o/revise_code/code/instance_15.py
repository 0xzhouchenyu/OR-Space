import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    params = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    
    param_dict = dict(zip(params["Parameter_Name"], params["Value"]))
    demand = dict(zip(table_1["stage"], table_1["tool_requirement"]))
    
    return param_dict, demand

def solve():
    param_dict, demand = load_data()
    
    n = int(param_dict["n"])
    cost_new = float(param_dict["cost_new_tool"])
    cost_slow = float(param_dict["cost_slow_repair"])
    cost_fast = float(param_dict["cost_fast_repair"])
    dur_slow = int(param_dict["slow_repair_duration"])
    dur_fast = int(param_dict["fast_repair_duration"])
    max_fast = int(param_dict["max_fast_stage"])
    max_slow = int(param_dict["max_slow_stage"])
    emission_buy = float(param_dict["emission_buy"])
    emission_fast = float(param_dict["emission_fast_repair"])
    emission_slow = float(param_dict["emission_slow_repair"])
    carbon_budget = float(param_dict["carbon_budget"])
    penalty_shortage = float(param_dict["penalty_shortage"])
    
    model = gp.Model("Tool_Repair_Problem")
    model.setParam("OutputFlag", 0)
    
    stages = list(range(1, n + 1))
    x = model.addVars(stages, vtype=GRB.INTEGER, name="buy")
    y = model.addVars(stages, vtype=GRB.INTEGER, name="fast")
    z = model.addVars(stages, vtype=GRB.INTEGER, name="slow")
    c = model.addVars([0] + stages, vtype=GRB.INTEGER, name="clean")
    d = model.addVars([0] + stages, vtype=GRB.INTEGER, name="dirty")
    s = model.addVars(stages, vtype=GRB.INTEGER, name="shortage")
    prebuy_clean = model.addVar(vtype=GRB.INTEGER, name="prebuy_clean")
    
    # Initial conditions
    model.addConstr(c[0] == prebuy_clean, "initial_clean")
    model.addConstr(d[0] == 0, "initial_dirty")
    
    # Stage constraints
    for i in stages:
        fast_ready = y[i - dur_fast - 1] if i - dur_fast - 1 >= 1 else 0
        slow_ready = z[i - dur_slow - 1] if i - dur_slow - 1 >= 1 else 0
        
        model.addConstr(x[i] + c[i - 1] + fast_ready + slow_ready + s[i] == demand[i] + c[i], f"clean_balance_{i}")
        model.addConstr(demand[i] + d[i - 1] == y[i] + z[i] + d[i], f"dirty_balance_{i}")
        model.addConstr(y[i] <= max_fast, f"fast_cap_{i}")
        model.addConstr(z[i] <= max_slow, f"slow_cap_{i}")
    
    # Carbon budget constraint
    total_emissions = (
        gp.quicksum(emission_buy * x[i] for i in stages) +
        gp.quicksum(emission_fast * y[i] for i in stages) +
        gp.quicksum(emission_slow * z[i] for i in stages) +
        emission_buy * prebuy_clean
    )
    model.addConstr(total_emissions <= carbon_budget, "carbon_budget")
    
    # Objective function
    total_cost = (
        gp.quicksum(cost_new * x[i] for i in stages) +
        gp.quicksum(cost_fast * y[i] for i in stages) +
        gp.quicksum(cost_slow * z[i] for i in stages) +
        gp.quicksum(penalty_shortage * s[i] for i in stages) +
        cost_new * prebuy_clean
    )
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
