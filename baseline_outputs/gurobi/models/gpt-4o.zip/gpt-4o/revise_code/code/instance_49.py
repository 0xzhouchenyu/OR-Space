import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    """
    Returns the absolute path to a file in the data directory.
    """
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def solve():
    # Load data
    table_1 = pd.read_csv(get_data_path('table_1.csv'))
    table_2 = pd.read_csv(get_data_path('table_2.csv'))
    params = pd.read_csv(get_data_path('general_parameters.csv'))

    # Parse parameters
    min_contract_types = int(params.loc[params['Parameter_Name'] == 'min_contract_types', 'Value'].values[0])
    max_contract_types = int(params.loc[params['Parameter_Name'] == 'max_contract_types', 'Value'].values[0])
    mutual_exclusion = str(params.loc[params['Parameter_Name'] == 'mutual_exclusion_1_and_4', 'Value'].values[0]).strip().lower() == 'true'
    onboarding_loss_units = int(params.loc[params['Parameter_Name'] == 'onboarding_loss_units', 'Value'].values[0])
    expedited_onboarding_fee = int(params.loc[params['Parameter_Name'] == 'expedited_onboarding_fee', 'Value'].values[0])
    activation_fee_per_contract = int(params.loc[params['Parameter_Name'] == 'activation_fee_per_contract', 'Value'].values[0])
    monthly_max_parallel_contracts = int(params.loc[params['Parameter_Name'] == 'monthly_max_parallel_contracts', 'Value'].values[0])

    # Convert required area to units of 100 ㎡
    demands = {int(row['Month']): float(row['Required_area_㎡']) / 100.0 for _, row in table_1.iterrows()}
    costs = {int(row['Contract_length_months']): float(row['Rental_fee_per_100㎡_yuan']) for _, row in table_2.iterrows()}

    months = list(demands.keys())
    max_month = max(months)

    # Initialize model
    model = gp.Model("Warehouse_Rental")
    model.setParam('OutputFlag', 0)

    # Variables
    x = model.addVars(
        [(i, j) for i in months for j in costs.keys() if i + j - 1 <= max_month],
        vtype=GRB.INTEGER, name="x"
    )
    y = model.addVars(costs.keys(), vtype=GRB.BINARY, name="y")
    z = model.addVars(
        [(i, j) for i in months for j in costs.keys() if i + j - 1 <= max_month],
        vtype=GRB.BINARY, name="z"
    )

    # Objective: Minimize total rental cost
    model.setObjective(
        gp.quicksum(costs[j] * x[i, j] for (i, j) in x) +
        gp.quicksum(expedited_onboarding_fee * z[i, j] for (i, j) in z) +
        gp.quicksum(activation_fee_per_contract * y[j] for j in y),
        GRB.MINIMIZE
    )

    # Constraints
    # 1. Demand fulfillment for each month
    for m in months:
        model.addConstr(
            gp.quicksum(
                (x[i, j] - onboarding_loss_units * (1 - z[i, j])) 
                for (i, j) in x if i <= m and i + j - 1 >= m
            ) == demands[m]
        )

    # 2. Link x and y
    M = sum(demands.values())
    for j in costs.keys():
        model.addConstr(gp.quicksum(x[i, j] for i in months if (i, j) in x) <= M * y[j])
        model.addConstr(gp.quicksum(x[i, j] for i in months if (i, j) in x) >= y[j])

    # 3. Contract types limits
    model.addConstr(gp.quicksum(y[j] for j in costs.keys()) >= min_contract_types)
    model.addConstr(gp.quicksum(y[j] for j in costs.keys()) <= max_contract_types)

    # 4. Mutual exclusion between 1-month and 4-month contracts
    if mutual_exclusion:
        model.addConstr(y[1] + y[4] <= 1)

    # 5. Limit on parallel contracts
    for m in months:
        model.addConstr(
            gp.quicksum(
                y[j] for j in costs.keys() for i in months if (i, j) in x and i <= m and i + j - 1 >= m
            ) <= monthly_max_parallel_contracts
        )

    # Solve the model
    model.optimize()

    # Output the objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
