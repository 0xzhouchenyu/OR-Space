import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    
    n = len(shifts)  # number of periods (6)
    required = [s['required'] for s in shifts]
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    shift_duration = int(params['shift_duration'])  # 8 hours
    driver_rest_gap = int(params['driver_rest_gap'])
    crew_rest_gap = int(params['crew_rest_gap'])
    max_night_driver_fraction = params['max_night_driver_fraction']
    max_night_crew_fraction = params['max_night_crew_fraction']
    max_overtime_shifts = int(params['max_overtime_shifts'])
    overtime_cost_factor = params['overtime_cost_factor']
    
    periods_per_shift = shift_duration // 4  # = 2
    night_periods = [4, 5]  # Periods 5 and 6 (0-indexed: 4, 5)
    
    # Create model
    model = gp.Model("RevisedBusStaffing")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_driver = [model.addVar(vtype=GRB.INTEGER, name=f"x_driver_{i+1}") for i in range(n)]
    x_crew = [model.addVar(vtype=GRB.INTEGER, name=f"x_crew_{i+1}") for i in range(n)]
    y_driver = [model.addVar(vtype=GRB.INTEGER, name=f"y_driver_{i+1}") for i in range(n)]
    y_crew = [model.addVar(vtype=GRB.INTEGER, name=f"y_crew_{i+1}") for i in range(n)]
    
    # Objective: minimize total cost
    model.setObjective(
        gp.quicksum(x_driver[i] + x_crew[i] for i in range(n)) +
        overtime_cost_factor * gp.quicksum(y_driver[i] + y_crew[i] for i in range(n)),
        GRB.MINIMIZE
    )
    
    # Constraints: coverage for each period
    for j in range(n):
        covering_driver = []
        covering_crew = []
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                covering_driver.append(x_driver[i] + y_driver[i])
                covering_crew.append(x_crew[i] + y_crew[i])
        model.addConstr(gp.quicksum(covering_driver) >= required[j], f"Driver_demand_period_{j+1}")
        model.addConstr(gp.quicksum(covering_crew) >= required[j], f"Crew_demand_period_{j+1}")
    
    # Constraints: night shift fraction limits
    model.addConstr(
        gp.quicksum(x_driver[i] for i in night_periods) <= max_night_driver_fraction * gp.quicksum(x_driver),
        "Max_night_driver_fraction"
    )
    model.addConstr(
        gp.quicksum(x_crew[i] for i in night_periods) <= max_night_crew_fraction * gp.quicksum(x_crew),
        "Max_night_crew_fraction"
    )
    
    # Constraints: total overtime shifts
    model.addConstr(
        gp.quicksum(y_driver) + gp.quicksum(y_crew) <= max_overtime_shifts,
        "Max_overtime_shifts"
    )
    
    # Non-negativity constraints (implicitly handled by Gurobi)
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
