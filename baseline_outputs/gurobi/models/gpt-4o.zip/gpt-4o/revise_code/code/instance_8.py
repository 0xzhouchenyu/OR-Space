import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read table_1.csv
    filepath = os.path.join(data_dir, "table_1.csv")
    workers = []
    tasks = []
    cost = {}
    fixed_cost = {}
    
    with open(filepath, "r") as f:
        reader = csv.reader(f)
        header = next(reader)
        tasks = header[1:-1]  # ['A', 'B', 'C', 'D']
        
        for row in reader:
            worker = row[0].strip()
            workers.append(worker)
            for j, task in enumerate(tasks):
                cost[(worker, task)] = int(row[j + 1])
            fixed_cost[worker] = int(row[-1])
    
    # Read general_parameters.csv
    filepath = os.path.join(data_dir, "general_parameters.csv")
    params = {}
    
    with open(filepath, "r") as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            params[row[0].strip()] = int(row[1])
    
    # Extract parameters
    shared_temp_handoff_cost = params["shared_temp_handoff_cost"]
    worker_II_V_pair_fee = params["worker_II_V_pair_fee"]
    
    # Create the optimization model
    model = gp.Model("Revised_Assignment")
    model.setParam("OutputFlag", 0)
    
    # Decision variables: x[i,j] = 1 if worker i is assigned to task j
    x = model.addVars(workers, tasks, vtype=GRB.BINARY, name="x")
    
    # Decision variable: y[i] = 1 if worker i is selected
    y = model.addVars(workers, vtype=GRB.BINARY, name="y")
    
    # Objective: minimize total cost
    model.setObjective(
        gp.quicksum(cost[(w, t)] * x[(w, t)] for w in workers for t in tasks) +
        gp.quicksum(fixed_cost[w] * y[w] for w in workers) +
        shared_temp_handoff_cost * y["III"] * y["V"] +
        worker_II_V_pair_fee * y["II"] * y["V"],
        GRB.MINIMIZE
    )
    
    # Each task must be assigned to exactly one worker
    model.addConstrs((gp.quicksum(x[(w, t)] for w in workers) == 1 for t in tasks), name="task_assignment")
    
    # Each worker can be assigned to at most one task
    model.addConstrs((gp.quicksum(x[(w, t)] for t in tasks) <= 1 for w in workers), name="worker_assignment")
    
    # Link x and y: if a worker is assigned to a task, they must be selected
    model.addConstrs((x[(w, t)] <= y[w] for w in workers for t in tasks), name="link_x_y")
    
    # Exactly 4 workers must be selected
    model.addConstr(gp.quicksum(y[w] for w in workers) == 4, name="select_4_workers")
    
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
