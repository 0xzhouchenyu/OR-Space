import os
import gurobipy as gp
from gurobipy import GRB
import csv

def load_csv(filename):
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    return rows

def load_general_parameters(filename='general_parameters.csv'):
    rows = load_csv(filename)
    params = {}
    for row in rows:
        params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_reliability_table(filename='table_1.csv'):
    rows = load_csv(filename)
    reliability = {}
    for row in rows:
        n_spares = int(row['Number_of_Spares'])
        r1 = float(row['Component_1_Reliability'])
        r2 = float(row['Component_2_Reliability'])
        r3 = float(row['Component_3_Reliability'])
        reliability[n_spares] = [r1, r2, r3]
    return reliability

def solve():
    # Load data
    params = load_general_parameters()
    reliability = load_reliability_table()
    
    # Extract parameters
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    budget_A = params['total_budget_scenario_A']
    budget_B = params['total_budget_scenario_B']
    weight_A = params['weight_limit_scenario_A']
    weight_B = params['weight_limit_scenario_B']
    
    max_spares = max(reliability.keys())
    
    # Create optimization model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of spares for each component
    s = model.addVars(3, vtype=GRB.INTEGER, lb=0, ub=max_spares, name="s")
    
    # Component reliabilities
    r1 = model.addVar(vtype=GRB.CONTINUOUS, name="r1")
    r2 = model.addVar(vtype=GRB.CONTINUOUS, name="r2")
    r3 = model.addVar(vtype=GRB.CONTINUOUS, name="r3")
    
    # Constraints for reliability lookup
    model.addConstr(r1 == gp.quicksum(reliability[i][0] * (s[0] == i) for i in range(max_spares + 1)), "r1_lookup")
    model.addConstr(r2 == gp.quicksum(reliability[i][1] * (s[1] == i) for i in range(max_spares + 1)), "r2_lookup")
    model.addConstr(r3 == gp.quicksum(reliability[i][2] * (s[2] == i) for i in range(max_spares + 1)), "r3_lookup")
    
    # Budget constraints
    model.addConstr(gp.quicksum(s[i] * unit_price[i] for i in range(3)) <= budget_A, "budget_A")
    model.addConstr(gp.quicksum(s[i] * unit_price[i] for i in range(3)) <= budget_B, "budget_B")
    
    # Weight constraints
    model.addConstr(gp.quicksum(s[i] * unit_weight[i] for i in range(3)) <= weight_A, "weight_A")
    model.addConstr(gp.quicksum(s[i] * unit_weight[i] for i in range(3)) <= weight_B, "weight_B")
    
    # Objective: Maximize expected reliability
    system_reliability = r1 * r2 * r3
    model.setObjective(system_reliability, GRB.MAXIMIZE)
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == '__main__':
    solve()
