import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Parameter_Name"].strip()
            val = row["Value"].strip()
            params[name] = float(val)
    
    # Extract parameters
    a1_yield = params["product_A1_yield"]
    a1_time = params["product_A1_time"]
    a2_yield = params["product_A2_yield"]
    a2_time = params["product_A2_time"]
    a3_yield = params["product_A3_yield"]
    a3_time = params["product_A3_time"]
    profit_a1 = params["profit_per_kg_A1"]
    profit_a2 = params["profit_per_kg_A2"]
    profit_a3 = params["profit_per_kg_A3"]
    milk_supply = params["daily_milk_supply"]
    labor_hours = params["daily_labor_hours"]
    type_a_capacity = params["type_A_capacity"]
    cap_a_shared = params["cap_A_shared"]
    min_a2_kg = params["min_A2_kg"]
    min_a3_kg = params["min_A3_kg"]
    cleaning_loss_a3 = params["type_A_cleaning_loss_if_A3"]
    cold_chain_threshold = params["cold_chain_bonus_threshold_kg"]
    cold_chain_bonus = params["cold_chain_bonus_yuan"]
    
    # Create model
    model = gp.Model("Dairy_Production")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    x1 = model.addVar(lb=0, name="x1")  # barrels for A1
    x2 = model.addVar(lb=0, name="x2")  # barrels for A2
    x3 = model.addVar(lb=0, name="x3")  # barrels for A3
    cold_chain_bonus_active = model.addVar(vtype=GRB.BINARY, name="cold_chain_bonus_active")
    
    # Objective: maximize profit
    profit = (
        profit_a1 * a1_yield * x1 +
        profit_a2 * a2_yield * x2 +
        profit_a3 * a3_yield * x3 +
        cold_chain_bonus * cold_chain_bonus_active
    )
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Constraints
    # Milk supply
    model.addConstr(x1 + x2 + x3 <= milk_supply, "Milk_Supply")
    
    # Labor hours
    model.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours, "Labor_Hours")
    
    # Type A equipment capacity
    model.addConstr(a1_yield * x1 + a3_yield * x3 <= cap_a_shared - cleaning_loss_a3 * (x3 > 0), "Type_A_Shared_Capacity")
    model.addConstr(a1_yield * x1 <= type_a_capacity, "Type_A_Legacy_Capacity")
    
    # Minimum production requirements
    model.addConstr(a2_yield * x2 >= min_a2_kg, "Min_A2_Production")
    model.addConstr(a3_yield * x3 >= min_a3_kg, "Min_A3_Production")
    
    # Cold-chain bonus activation
    model.addConstr(a3_yield * x3 >= cold_chain_threshold * cold_chain_bonus_active, "Cold_Chain_Bonus_Activation")
    
    # Solve model
    model.optimize()
    
    # Output result
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
