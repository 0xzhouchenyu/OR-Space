import os
import gurobipy as gp
from gurobipy import GRB
import csv

# Load distances
def load_distances(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    distances = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            yard = row['Coal_Yard'].strip()
            area = int(row['Residential_Area'].strip())
            dist = float(row['Distance_km'].strip())
            distances[(yard, area)] = dist
    return distances

# Load parameters
def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
distances = load_distances(data_dir)
params = load_parameters(data_dir)

# Extract parameters
min_supply = {
    'A': params['min_coal_yard_A'],
    'B': params['min_coal_yard_B_adjusted']
}

demand = {
    1: params['residential_area_1_demand'],
    2: params['residential_area_2_demand'],
    3: params['residential_area_3_demand']
}

min_share_area3_from_A = params['min_share_area3_from_A']
area3_A_staging_threshold = params['area3_A_staging_threshold']
area3_A_excess_staging_cost = params['area3_A_excess_staging_cost']

coal_yards = ['A', 'B']
areas = [1, 2, 3]

# Create the model
model = gp.Model("Coal_Distribution")
model.setParam('OutputFlag', 0)

# Decision variables: amount of coal shipped from yard i to area j
x = model.addVars(coal_yards, areas, lb=0, name="x")

# Additional variable for excess tonnage from A to Area 3
excess_area3_A = model.addVar(lb=0, name="excess_area3_A")

# Objective: minimize total transportation cost
model.setObjective(
    gp.quicksum(distances[(yard, area)] * x[yard, area] for yard in coal_yards for area in areas) +
    area3_A_excess_staging_cost * excess_area3_A,
    GRB.MINIMIZE
)

# Constraints:
# 1. Each coal yard must supply at least its minimum requirement
for yard in coal_yards:
    model.addConstr(gp.quicksum(x[yard, area] for area in areas) >= min_supply[yard], f"Min_Supply_{yard}")

# 2. Each residential area must receive exactly its demand
for area in areas:
    model.addConstr(gp.quicksum(x[yard, area] for yard in coal_yards) == demand[area], f"Demand_{area}")

# 3. Minimum share of Area 3 demand must come from Coal Yard A
model.addConstr(x['A', 3] >= min_share_area3_from_A * demand[3], "Min_Share_Area3_From_A")

# 4. Excess tonnage from A to Area 3
model.addConstr(x['A', 3] - area3_A_staging_threshold == excess_area3_A, "Excess_Area3_A")
model.addConstr(excess_area3_A >= 0, "Non_Negative_Excess_Area3_A")

# Solve the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
