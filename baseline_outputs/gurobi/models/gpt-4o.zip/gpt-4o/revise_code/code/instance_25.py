import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    # Parameters
    W = params['initial_investment']  # 100000
    r1 = params['return_rate_option_1']  # 0.7
    r2 = params['return_rate_option_2']  # 2.0
    T = int(params['planning_horizon'])  # 3
    min_reserve_year1 = params['min_reserve_year1']  # 10000
    min_reserve_year2 = params['min_reserve_year2']  # 15000
    max_option2_start = params['max_option2_start']  # 30000
    late_settlement_rate = params['option2_year0_late_settlement_rate']  # 0.02
    
    # Model
    model = gp.Model("Investment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x0_1 = model.addVar(lb=0, name="x0_1")  # Option 1 at year 0
    x0_2 = model.addVar(lb=0, name="x0_2")  # Option 2 at year 0
    x1_1 = model.addVar(lb=0, name="x1_1")  # Option 1 at year 1
    x1_2 = model.addVar(lb=0, name="x1_2")  # Option 2 at year 1
    x2_1 = model.addVar(lb=0, name="x2_1")  # Option 1 at year 2
    reserve1 = model.addVar(lb=min_reserve_year1, name="reserve1")  # Reserve at year 1
    reserve2 = model.addVar(lb=min_reserve_year2, name="reserve2")  # Reserve at year 2
    
    # Constraints
    # Year 0 budget constraint
    model.addConstr(x0_1 + x0_2 <= W, "year0_budget")
    
    # Maximum investment in Option 2 at year 0
    model.addConstr(x0_2 <= max_option2_start, "max_option2_year0")
    
    # Year 1 budget constraint
    model.addConstr(x1_1 + x1_2 + reserve1 <= x0_1 * (1 + r1), "year1_budget")
    
    # Maximum investment in Option 2 at year 1
    model.addConstr(x1_2 <= max_option2_start, "max_option2_year1")
    
    # Year 2 budget constraint
    model.addConstr(x2_1 + reserve2 <= x1_1 * (1 + r1) + x0_2 * (1 + r2) * (1 - late_settlement_rate), "year2_budget")
    
    # Objective: Maximize wealth at year 3
    objective = (
        x2_1 * (1 + r1) + x1_2 * (1 + r2) + reserve2
    )
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
