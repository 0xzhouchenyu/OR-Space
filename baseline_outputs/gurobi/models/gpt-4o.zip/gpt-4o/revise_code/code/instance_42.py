import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    # Extract parameters
    a = params['a']
    b = params['b']
    k = params['k']
    d = params['d']
    c_offpeak = params['c_offpeak']
    c_peak = params['c_peak']
    cap_offpeak = params['cap_offpeak']
    cap_peak = params['cap_peak']
    m_offpeak = params['m_offpeak']
    n_offpeak = params['n_offpeak']
    m_peak = params['m_peak']
    n_peak = params['n_peak']
    f_offpeak = params['f_offpeak']
    f_peak = params['f_peak']
    offpeak_cooldown_batch_threshold = params['offpeak_cooldown_batch_threshold']
    offpeak_cooldown_fee = params['offpeak_cooldown_fee']
    
    # Create model
    model = gp.Model("SteelFurnace")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x1_offpeak = model.addVar(lb=0, name="x1_offpeak")  # Furnace 1, Method 1, Off-peak
    x2_offpeak = model.addVar(lb=0, name="x2_offpeak")  # Furnace 1, Method 2, Off-peak
    x3_offpeak = model.addVar(lb=0, name="x3_offpeak")  # Furnace 2, Method 1, Off-peak
    x4_offpeak = model.addVar(lb=0, name="x4_offpeak")  # Furnace 2, Method 2, Off-peak
    
    x1_peak = model.addVar(lb=0, name="x1_peak")        # Furnace 1, Method 1, Peak
    x2_peak = model.addVar(lb=0, name="x2_peak")        # Furnace 1, Method 2, Peak
    x3_peak = model.addVar(lb=0, name="x3_peak")        # Furnace 2, Method 1, Peak
    x4_peak = model.addVar(lb=0, name="x4_peak")        # Furnace 2, Method 2, Peak
    
    y1_offpeak = model.addVar(vtype=GRB.BINARY, name="y1_offpeak")  # Furnace 1 used in off-peak
    y2_offpeak = model.addVar(vtype=GRB.BINARY, name="y2_offpeak")  # Furnace 2 used in off-peak
    y1_peak = model.addVar(vtype=GRB.BINARY, name="y1_peak")        # Furnace 1 used in peak
    y2_peak = model.addVar(vtype=GRB.BINARY, name="y2_peak")        # Furnace 2 used in peak
    
    z1_offpeak = model.addVar(vtype=GRB.BINARY, name="z1_offpeak")  # Furnace 1 cooldown
    z2_offpeak = model.addVar(vtype=GRB.BINARY, name="z2_offpeak")  # Furnace 2 cooldown
    
    # Objective: Minimize total cost
    model.setObjective(
        m_offpeak * (x1_offpeak + x3_offpeak) + n_offpeak * (x2_offpeak + x4_offpeak) +
        m_peak * (x1_peak + x3_peak) + n_peak * (x2_peak + x4_peak) +
        f_offpeak * (y1_offpeak + y2_offpeak) + f_peak * (y1_peak + y2_peak) +
        offpeak_cooldown_fee * (z1_offpeak + z2_offpeak),
        GRB.MINIMIZE
    )
    
    # Constraints
    # Time constraints for each furnace
    model.addConstr(a * x1_offpeak + b * x2_offpeak <= c_offpeak * y1_offpeak, "Furnace1_Offpeak_Time")
    model.addConstr(a * x3_offpeak + b * x4_offpeak <= c_offpeak * y2_offpeak, "Furnace2_Offpeak_Time")
    model.addConstr(a * x1_peak + b * x2_peak <= c_peak * y1_peak, "Furnace1_Peak_Time")
    model.addConstr(a * x3_peak + b * x4_peak <= c_peak * y2_peak, "Furnace2_Peak_Time")
    
    # Plant-wide time constraints
    model.addConstr(a * (x1_offpeak + x3_offpeak) + b * (x2_offpeak + x4_offpeak) <= cap_offpeak, "Plant_Offpeak_Time")
    model.addConstr(a * (x1_peak + x3_peak) + b * (x2_peak + x4_peak) <= cap_peak, "Plant_Peak_Time")
    
    # Minimum production requirement
    model.addConstr(k * (x1_offpeak + x2_offpeak + x3_offpeak + x4_offpeak +
                         x1_peak + x2_peak + x3_peak + x4_peak) >= d, "MinProduction")
    
    # Cooldown constraints
    model.addConstr(x1_offpeak + x2_offpeak <= offpeak_cooldown_batch_threshold + z1_offpeak * GRB.INFINITY, "Furnace1_Cooldown")
    model.addConstr(x3_offpeak + x4_offpeak <= offpeak_cooldown_batch_threshold + z2_offpeak * GRB.INFINITY, "Furnace2_Cooldown")
    model.addConstr(z1_offpeak >= (x1_offpeak + x2_offpeak - offpeak_cooldown_batch_threshold) / GRB.INFINITY, "Furnace1_Cooldown_Trigger")
    model.addConstr(z2_offpeak >= (x3_offpeak + x4_offpeak - offpeak_cooldown_batch_threshold) / GRB.INFINITY, "Furnace2_Cooldown_Trigger")
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
