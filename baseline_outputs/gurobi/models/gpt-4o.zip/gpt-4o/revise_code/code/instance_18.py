import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Extract parameters
fabric_production_rate = params["fabric_production_rate"]
min_curtain_fabric_sales = params["min_curtain_fabric_sales"]
curtain_fabric_profit = params["curtain_fabric_profit"]
min_clothing_fabric_sales = params["min_clothing_fabric_sales"]
clothing_fabric_profit = params["clothing_fabric_profit"]
day_shift_regular_capacity = params["day_shift_regular_capacity"]
night_shift_regular_capacity = params["night_shift_regular_capacity"]
day_overtime_limit = params["day_overtime_limit"]
night_overtime_limit = params["night_overtime_limit"]
day_overtime_penalty = params["day_overtime_penalty"]
night_overtime_penalty = params["night_overtime_penalty"]
day_min_utilization_ratio = params["day_min_utilization_ratio"]
night_min_utilization_ratio = params["night_min_utilization_ratio"]

# Convert sales requirements to hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

# Create model
model = gp.Model("Textile_Factory_Optimization")
model.setParam("OutputFlag", 0)

# Decision variables
day_regular_hours = model.addVar(lb=0, ub=day_shift_regular_capacity, name="day_regular_hours")
night_regular_hours = model.addVar(lb=0, ub=night_shift_regular_capacity, name="night_regular_hours")
day_overtime_hours = model.addVar(lb=0, ub=day_overtime_limit, name="day_overtime_hours")
night_overtime_hours = model.addVar(lb=0, ub=night_overtime_limit, name="night_overtime_hours")

# Total hours for clothing and curtain production
clothing_hours = model.addVar(lb=min_clothing_hours, name="clothing_hours")
curtain_hours = model.addVar(lb=min_curtain_hours, name="curtain_hours")

# Objective: Minimize overtime penalties
model.setObjective(
    day_overtime_hours * day_overtime_penalty + night_overtime_hours * night_overtime_penalty,
    GRB.MINIMIZE
)

# Constraints
# Total production time balance
model.addConstr(
    clothing_hours + curtain_hours ==
    day_regular_hours + night_regular_hours + day_overtime_hours + night_overtime_hours,
    "Production_Time_Balance"
)

# Day and night shift utilization constraints
model.addConstr(
    day_regular_hours >= day_min_utilization_ratio * (day_regular_hours + night_regular_hours),
    "Day_Min_Utilization"
)
model.addConstr(
    night_regular_hours >= night_min_utilization_ratio * (day_regular_hours + night_regular_hours),
    "Night_Min_Utilization"
)

# Solve the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
