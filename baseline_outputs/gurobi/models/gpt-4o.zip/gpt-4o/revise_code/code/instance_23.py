import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                "name": row["Product Name"].strip(),
                "labor": float(row["Labor per unit"].strip()),
                "material": float(row["Material per unit"].strip()),
                "price": float(row["Selling Price"].strip()),
                "var_cost": float(row["Variable Cost"].strip())
            })
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    # Extract parameters
    available_labor = params["available_labor"]
    available_material = params["available_material"]
    fixed_costs = [params["fixed_cost_shirts"], params["fixed_cost_short_sleeves"], params["fixed_cost_casual_clothes"]]
    segment_regular_discount = params["segment_regular_discount"]
    segment_promo_discount = params["segment_promo_discount"]
    segment_promo_labor_cap = params["segment_promo_labor_cap"]
    segment_promo_material_cap = params["segment_promo_material_cap"]
    min_batches = [params["min_batch_shirts"], params["min_batch_short_sleeves"], params["min_batch_casual_clothes"]]
    max_productions = [params["max_prod_shirts"], params["max_prod_short_sleeves"], params["max_prod_casual_clothes"]]
    
    # Model
    model = gp.Model("clothing_production")
    model.setParam("OutputFlag", 0)
    
    n = len(products)
    
    # Decision variables
    x_regular = [model.addVar(vtype=GRB.INTEGER, name=f"x_regular_{i}") for i in range(n)]
    x_promo = [model.addVar(vtype=GRB.INTEGER, name=f"x_promo_{i}") for i in range(n)]
    y_active = [model.addVar(vtype=GRB.BINARY, name=f"y_active_{i}") for i in range(n)]
    
    # Objective: maximize profit
    unit_profit_regular = [(p["price"] * segment_regular_discount - p["var_cost"]) for p in products]
    unit_profit_promo = [(p["price"] * segment_promo_discount - p["var_cost"]) for p in products]
    total_fixed_cost = gp.quicksum(fixed_costs[i] * y_active[i] for i in range(n))
    total_profit = (
        gp.quicksum(unit_profit_regular[i] * x_regular[i] for i in range(n)) +
        gp.quicksum(unit_profit_promo[i] * x_promo[i] for i in range(n)) -
        total_fixed_cost
    )
    model.setObjective(total_profit, GRB.MAXIMIZE)
    
    # Constraints
    # Labor and material constraints
    model.addConstr(
        gp.quicksum(products[i]["labor"] * (x_regular[i] + x_promo[i]) for i in range(n)) <= available_labor,
        "labor"
    )
    model.addConstr(
        gp.quicksum(products[i]["material"] * (x_regular[i] + x_promo[i]) for i in range(n)) <= available_material,
        "material"
    )
    model.addConstr(
        gp.quicksum(products[i]["labor"] * x_promo[i] for i in range(n)) <= segment_promo_labor_cap,
        "promo_labor"
    )
    model.addConstr(
        gp.quicksum(products[i]["material"] * x_promo[i] for i in range(n)) <= segment_promo_material_cap,
        "promo_material"
    )
    
    # Minimum batch size constraints
    for i in range(n):
        model.addConstr(x_regular[i] + x_promo[i] >= min_batches[i] * y_active[i], f"min_batch_{i}")
    
    # Maximum production constraints
    for i in range(n):
        model.addConstr(x_regular[i] + x_promo[i] <= max_productions[i], f"max_prod_{i}")
    
    # Activation constraints
    for i in range(n):
        model.addConstr(x_regular[i] + x_promo[i] <= max_productions[i] * y_active[i], f"activation_{i}")
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
