import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_restaurant_data, load_general_parameters

def main():
    # Determine data directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load data
    restaurants = load_restaurant_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    budget = params['investment_budget']
    premium_revenue_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']
    
    # Create the optimization model
    model = gp.Model("Restaurant_Investment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}  # Binary: whether to buy a restaurant
    y = {}  # Binary: whether to operate a restaurant in Premium mode
    for r in restaurants:
        x[r['name']] = model.addVar(vtype=GRB.BINARY, name=f"x_{r['name']}")
        y[r['name']] = model.addVar(vtype=GRB.BINARY, name=f"y_{r['name']}")
    
    # Objective: maximize total annual revenue
    model.setObjective(
        gp.quicksum(
            (r['revenue'] * (1 + premium_revenue_uplift) * y[r['name']] +
             r['revenue'] * (1 - y[r['name']])) * x[r['name']]
            for r in restaurants
        ),
        GRB.MAXIMIZE
    )
    
    # Budget constraint
    model.addConstr(
        gp.quicksum(
            (r['cost'] + premium_upgrade_cost * y[r['name']]) * x[r['name']]
            for r in restaurants
        ) <= budget,
        "Budget_Constraint"
    )
    
    # Staff hours constraint
    model.addConstr(
        gp.quicksum(
            (r['Standard_Staff_Hours'] * (1 - y[r['name']]) +
             r['Premium_Staff_Hours'] * y[r['name']]) * x[r['name']]
            for r in restaurants
        ) <= staff_hours_cap,
        "Staff_Hours_Constraint"
    )
    
    # Premium mode only if restaurant is purchased
    for r in restaurants:
        model.addConstr(y[r['name']] <= x[r['name']], f"Premium_Only_If_Bought_{r['name']}")
    
    # Restaurant D and A mutual exclusion constraint
    if 'Restaurant_D' in x and 'Restaurant_A' in x:
        model.addConstr(x['Restaurant_D'] + x['Restaurant_A'] <= 1, "D_A_Exclusion_Constraint")
    
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
