import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    # Extract parameters
    product_units = params["product_units"]
    truck_pollution = params["truck_pollution"]
    van_pollution = params["van_pollution"]
    motorcycle_pollution = params["motorcycle_pollution"]
    ev_pollution = params["electric_vehicle_pollution"]
    max_total_pollution = params["max_total_pollution"]
    min_truck_trips = params["min_truck_trips"]
    truck_capacity = params["truck_capacity"]
    van_capacity = params["van_capacity"]
    motorcycle_capacity = params["motorcycle_capacity"]
    ev_capacity = params["electric_vehicle_capacity"]
    sales_point_shares = [params["sales_point_share_sp1"], params["sales_point_share_sp2"], params["sales_point_share_sp3"]]
    min_truck_shares = [params["min_truck_share_sp1"], params["min_truck_share_sp2"], params["min_truck_share_sp3"]]
    M_truck = params["M_truck_sp_day"]
    M_ev = params["M_ev_sp_day"]
    M_van = params["M_van_sp_day"]
    M_moto = params["M_moto_sp_day"]
    
    # Derived parameters
    sales_point_demands = [product_units * share for share in sales_point_shares]
    num_sales_points = len(sales_point_shares)
    num_days = 3
    
    # Model
    model = gp.Model("Revised_Transportation_Pollution_Minimization")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    x_truck = model.addVars(num_sales_points, num_days, vtype=GRB.INTEGER, name="truck_trips")
    x_ev = model.addVars(num_sales_points, num_days, vtype=GRB.INTEGER, name="ev_trips")
    x_van = model.addVars(num_sales_points, num_days, vtype=GRB.INTEGER, name="van_trips")
    x_moto = model.addVars(num_sales_points, num_days, vtype=GRB.INTEGER, name="motorcycle_trips")
    
    y_truck_ev = model.addVars(num_sales_points, num_days, vtype=GRB.BINARY, name="truck_ev_mode")
    y_van_moto = model.addVars(num_sales_points, num_days, vtype=GRB.BINARY, name="van_moto_mode")
    
    # Objective: Minimize total pollution
    model.setObjective(
        gp.quicksum(
            truck_pollution * x_truck[sp, d] +
            ev_pollution * x_ev[sp, d] +
            van_pollution * x_van[sp, d] +
            motorcycle_pollution * x_moto[sp, d]
            for sp in range(num_sales_points) for d in range(num_days)
        ),
        GRB.MINIMIZE
    )
    
    # Constraints
    # 1. All products must be delivered
    for sp in range(num_sales_points):
        model.addConstr(
            gp.quicksum(
                truck_capacity * x_truck[sp, d] +
                ev_capacity * x_ev[sp, d] +
                van_capacity * x_van[sp, d] +
                motorcycle_capacity * x_moto[sp, d]
                for d in range(num_days)
            ) >= sales_point_demands[sp],
            name=f"Demand_sp{sp+1}"
        )
    
    # 2. Total pollution must not exceed maximum
    model.addConstr(
        gp.quicksum(
            truck_pollution * x_truck[sp, d] +
            ev_pollution * x_ev[sp, d] +
            van_pollution * x_van[sp, d] +
            motorcycle_pollution * x_moto[sp, d]
            for sp in range(num_sales_points) for d in range(num_days)
        ) <= max_total_pollution,
        name="Max_Pollution"
    )
    
    # 3. Minimum truck trips across all sales points and days
    model.addConstr(
        gp.quicksum(x_truck[sp, d] for sp in range(num_sales_points) for d in range(num_days)) >= min_truck_trips,
        name="Min_Truck_Trips"
    )
    
    # 4. Minimum truck share per sales point
    for sp in range(num_sales_points):
        model.addConstr(
            gp.quicksum(x_truck[sp, d] for d in range(num_days)) >= 
            min_truck_shares[sp] * gp.quicksum(
                x_truck[sp, d] + x_ev[sp, d] + x_van[sp, d] + x_moto[sp, d]
                for d in range(num_days)
            ),
            name=f"Min_Truck_Share_sp{sp+1}"
        )
    
    # 5. Mode constraints: Either truck/ev or van/moto per sales point-day
    for sp in range(num_sales_points):
        for d in range(num_days):
            model.addConstr(x_truck[sp, d] + x_ev[sp, d] <= M_truck * y_truck_ev[sp, d], name=f"Truck_EV_Mode_sp{sp+1}_d{d+1}")
            model.addConstr(x_van[sp, d] + x_moto[sp, d] <= M_van * y_van_moto[sp, d], name=f"Van_Moto_Mode_sp{sp+1}_d{d+1}")
            model.addConstr(y_truck_ev[sp, d] + y_van_moto[sp, d] == 1, name=f"Mode_Selection_sp{sp+1}_d{d+1}")
    
    # Solve model
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
