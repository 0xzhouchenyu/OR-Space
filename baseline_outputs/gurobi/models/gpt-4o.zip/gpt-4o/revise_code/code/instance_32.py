import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    workshops = []
    capacities = {}
    rates = {}  # rates[(workshop, component)] = production rate
    
    filepath = os.path.join(data_dir, 'table_1.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    components = [1, 2, 3]
    
    # Read general_parameters.csv
    params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Create model
    model = gp.Model("Revised_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}  # Regular hours
    y = {}  # Overtime hours
    active_day = {}  # Active indicator for day shift
    active_night = {}  # Active indicator for night shift
    for w in workshops:
        for c in components:
            x[(w, 'day', c)] = model.addVar(lb=0, name=f"x_{w}_day_{c}")
            x[(w, 'night', c)] = model.addVar(lb=0, name=f"x_{w}_night_{c}")
            y[(w, 'day', c)] = model.addVar(lb=0, name=f"y_{w}_day_{c}")
            y[(w, 'night', c)] = model.addVar(lb=0, name=f"y_{w}_night_{c}")
        active_day[w] = model.addVar(vtype=GRB.BINARY, name=f"active_day_{w}")
        active_night[w] = model.addVar(vtype=GRB.BINARY, name=f"active_night_{w}")
    
    z = model.addVar(lb=0, name="z")  # Number of completed products
    shortage_penalty = model.addVar(lb=0, name="shortage_penalty")  # Shortage penalty
    
    # Objective: maximize z while minimizing penalties
    model.setObjective(
        z - params['penalty_night_hour'] * gp.quicksum(x[(w, 'night', c)] for w in workshops for c in components)
        - params['penalty_overtime_hour'] * gp.quicksum(y[(w, shift, c)] for w in workshops for shift in ['day', 'night'] for c in components)
        - params['penalty_shortage_per_unit'] * shortage_penalty,
        GRB.MAXIMIZE
    )
    
    # Capacity constraints
    for w in workshops:
        model.addConstr(
            gp.quicksum(x[(w, 'day', c)] + x[(w, 'night', c)] + y[(w, 'day', c)] + y[(w, 'night', c)] for c in components) <= capacities[w],
            f"Capacity_{w}"
        )
    
    # Regular hours limits
    for w in workshops:
        model.addConstr(
            gp.quicksum(x[(w, 'day', c)] for c in components) <= params[f"regular_hours_limit_day_{w}"],
            f"Regular_hours_day_{w}"
        )
        model.addConstr(
            gp.quicksum(x[(w, 'night', c)] for c in components) <= params[f"regular_hours_limit_night_{w}"],
            f"Regular_hours_night_{w}"
        )
    
    # Overtime limits
    for w in workshops:
        model.addConstr(
            gp.quicksum(y[(w, 'day', c)] for c in components) <= params[f"overtime_capacity_day_{w}"],
            f"Overtime_day_{w}"
        )
        model.addConstr(
            gp.quicksum(y[(w, 'night', c)] for c in components) <= params[f"overtime_capacity_night_{w}"],
            f"Overtime_night_{w}"
        )
    
    # Active shift constraints
    for w in workshops:
        model.addConstr(
            gp.quicksum(x[(w, 'day', c)] + y[(w, 'day', c)] for c in components) <= params[f"bigM_shift_{w}"] * active_day[w],
            f"Active_day_{w}"
        )
        model.addConstr(
            gp.quicksum(x[(w, 'night', c)] + y[(w, 'night', c)] for c in components) <= params[f"bigM_shift_{w}"] * active_night[w],
            f"Active_night_{w}"
        )
    
    # No more than two workshops active per shift
    model.addConstr(gp.quicksum(active_day[w] for w in workshops) <= 2, "Max_active_day")
    model.addConstr(gp.quicksum(active_night[w] for w in workshops) <= 2, "Max_active_night")
    
    # z constraints
    for c in components:
        model.addConstr(
            z <= gp.quicksum(rates[(w, c)] * (x[(w, 'day', c)] + x[(w, 'night', c)] + y[(w, 'day', c)] + y[(w, 'night', c)]) for w in workshops),
            f"Min_component_{c}"
        )
    
    # Shortage penalty
    model.addConstr(shortage_penalty >= params['z_target'] - z, "Shortage_penalty")
    
    # Solve
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")

if __name__ == "__main__":
    main()
