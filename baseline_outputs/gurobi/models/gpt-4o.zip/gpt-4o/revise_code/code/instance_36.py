import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    params = {}
    with open(params_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("Parameter_Name"):
                continue
            parts = line.split(",")
            params[parts[0]] = parts[1]

    num_customers = int(params["num_customers"])
    max_trucks = int(params["max_trucks"])
    truck_capacity = float(params["truck_capacity"])
    inhouse_truck_limit = int(params["inhouse_truck_limit"])

    depot_str = params.get("depot_coordinates", "(40,50)").strip("()")
    depot_x, depot_y = map(float, depot_str.split(","))
    depot_tw_start = float(params["depot_time_window_start"])
    depot_tw_end = float(params["depot_time_window_end"])

    coords = [(depot_x, depot_y)]
    demands_list = [0]
    tw_list = [(depot_tw_start, depot_tw_end)]
    svc_list = [0]
    outsource_costs = [0]
    mandatory_external = [0]

    with open(table_1_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((float(row["Coordinates_X"]), float(row["Coordinates_Y"])))
            demands_list.append(float(row["Demand"]))
            tw_list.append((float(row["Time_Window_Start"]), float(row["Time_Window_End"]))
            svc_list.append(float(row["Service_Duration"]))
            outsource_costs.append(float(row["Outsource_Cost"]))
            mandatory_external.append(int(row["Mandatory_External"]))

    n = len(coords)
    N = list(range(1, n))
    V = list(range(n))

    dist = {}
    for i in V:
        for j in V:
            dist[i, j] = calculate_distance(coords[i], coords[j])

    A = []
    for i in V:
        for j in V:
            if i == j:
                continue
            if i != 0 and j != 0:
                if tw_list[i][0] + svc_list[i] + dist[i, j] > tw_list[j][1]:
                    continue
            if i == 0 and j != 0:
                if tw_list[0][0] + dist[0, j] > tw_list[j][1]:
                    continue
            if i != 0 and j == 0:
                if tw_list[i][0] + svc_list[i] + dist[i, 0] > tw_list[0][1]:
                    continue
            A.append((i, j))

    A_set = set(A)

    model = gp.Model("VRPHTW")
    model.setParam("OutputFlag", 0)

    x = model.addVars(A, vtype=GRB.BINARY, name="x")
    t = model.addVars(V, lb=0, name="t")
    y = model.addVars(N, vtype=GRB.BINARY, name="y")

    model.setObjective(
        gp.quicksum(dist[i, j] * x[i, j] for i, j in A) +
        gp.quicksum(outsource_costs[i] * y[i] for i in N),
        GRB.MINIMIZE
    )

    model.addConstr(gp.quicksum(x[0, j] for j in N if (0, j) in A_set) <= inhouse_truck_limit)

    for i in N:
        model.addConstr(gp.quicksum(x[j, i] for j in V if (j, i) in A_set) == 1 - y[i])
        model.addConstr(gp.quicksum(x[i, j] for j in V if (i, j) in A_set) == 1 - y[i])

    for i in N:
        model.addConstr(t[i] >= tw_list[i][0])
        model.addConstr(t[i] <= tw_list[i][1])

    t[0].setAttr("Start", 0)
    model.addConstr(t[0] >= tw_list[0][0])
    model.addConstr(t[0] <= tw_list[0][1])

    M_val = tw_list[0][1] + max(svc_list)
    for i, j in A:
        if j != 0:
            model.addConstr(t[i] + svc_list[i] + dist[i, j] - t[j] <= M_val * (1 - x[i, j]))

    for i, j in A:
        if i != 0 and j != 0:
            model.addConstr(demands_list[i] + demands_list[j] <= truck_capacity + truck_capacity * (1 - x[i, j]))

    for i in N:
        if mandatory_external[i] == 1:
            model.addConstr(y[i] == 1)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

solve()
