import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_general_parameters, load_crop_data

def main():
    # Load data
    params = load_general_parameters()
    crops, crop_data = load_crop_data()
    
    # Extract parameters
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']
    
    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = params['max_chickens']
    max_dairy_cows = params['max_dairy_cows']
    fixed_cost_chicken_setup = params['fixed_cost_chicken_setup']
    min_chickens_if_coop_open = params['min_chickens_if_coop_open']
    second_biosecurity_threshold = params['second_biosecurity_threshold']
    second_biosecurity_cost = params['second_biosecurity_cost']
    biosecurity_training_aw_days = params['biosecurity_training_aw_days']
    biosecurity_training_ss_days = params['biosecurity_training_ss_days']
    
    # Crop data
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']
    
    # Create Gurobi model
    model = gp.Model("Farm_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {c: model.addVar(lb=0, name=f"x_{c}") for c in crops}  # Crop areas
    y_dairy = model.addVar(lb=0, ub=max_dairy_cows, name="dairy_cows")  # Dairy cows
    y_chicken = model.addVar(lb=0, ub=max_chickens, name="chickens")  # Chickens
    coop_open = model.addVar(vtype=GRB.BINARY, name="coop_open")  # Binary for coop open
    surplus_aw = model.addVar(lb=0, name="surplus_aw")  # Surplus labor autumn/winter
    surplus_ss = model.addVar(lb=0, name="surplus_ss")  # Surplus labor spring/summer
    
    # Objective: maximize net income
    obj = gp.quicksum(crop_income[c] * x[c] for c in crops) + \
          income_dairy * y_dairy + income_chicken * y_chicken - \
          fixed_cost_chicken_setup * coop_open - \
          second_biosecurity_cost * (y_chicken >= second_biosecurity_threshold) + \
          ext_rate_aw * surplus_aw + ext_rate_ss * surplus_ss
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints
    # Land constraint
    model.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, "Land")
    
    # Funds constraint
    model.addConstr(inv_dairy * y_dairy + inv_chicken * y_chicken <= funds_available, "Funds")
    
    # Labor autumn/winter constraint
    model.addConstr(gp.quicksum(crop_aw[c] * x[c] for c in crops) + 
                    labor_aw_dairy * y_dairy + labor_aw_chicken * y_chicken + 
                    biosecurity_training_aw_days * coop_open + surplus_aw <= labor_aw, "Labor_AW")
    
    # Labor spring/summer constraint
    model.addConstr(gp.quicksum(crop_ss[c] * x[c] for c in crops) + 
                    labor_ss_dairy * y_dairy + labor_ss_chicken * y_chicken + 
                    biosecurity_training_ss_days * coop_open + surplus_ss <= labor_ss, "Labor_SS")
    
    # Chicken coop constraints
    model.addConstr(y_chicken >= min_chickens_if_coop_open * coop_open, "Min_Chickens_If_Coop_Open")
    model.addConstr(y_chicken <= max_chickens, "Max_Chickens")
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
