import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load demand forecast
demand = []
with open(os.path.join(base_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        demand.append(float(row["Demand_Forecast"]))

T = len(demand)  # 6 months

# Load general parameters
params = {}
with open(os.path.join(base_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

# Extract parameters
W0 = int(params["initial_workforce"])
I0 = params["initial_inventory"]
sp = params["sales_price"]
rmc = params["raw_material_cost"]
oc = params["outsourcing_cost"]
hc = params["inventory_holding_cost"]
bc = params["backorder_cost"]
lr = params["labor_requirement"]
rh = params["regular_labor_hours"]
rw = params["regular_wage"]
otl = params["overtime_hours_limit"]
ow = params["overtime_wage"]
hire_cost = params["hiring_cost"]
fire_cost = params["firing_cost"]
term_inv = params["terminal_inventory"]
term_bo = params["terminal_backorders"]
contract_min_units = params["contract_min_units"]
contract_bigM = params["contract_bigM"]

# Model
model = gp.Model("FoldableTableProduction")
model.setParam("OutputFlag", 0)

# Decision variables
W = model.addVars(T, vtype=GRB.CONTINUOUS, name="W")  # workforce
H = model.addVars(T, vtype=GRB.CONTINUOUS, name="H")  # hired
F = model.addVars(T, vtype=GRB.CONTINUOUS, name="F")  # fired
P = model.addVars(T, vtype=GRB.CONTINUOUS, name="P")  # in-house production
OT_total = model.addVars(T, vtype=GRB.CONTINUOUS, name="OT")  # total overtime hours
O = model.addVars(T, vtype=GRB.CONTINUOUS, name="O")  # outsourced units
Inv = model.addVars(T, vtype=GRB.CONTINUOUS, name="Inv")  # inventory
B = model.addVars(T, vtype=GRB.CONTINUOUS, name="B")  # backorders
ContractSatisfied = model.addVars(T, vtype=GRB.BINARY, name="ContractSatisfied")  # binary for contract satisfaction
ContractUnits = model.addVars(T, vtype=GRB.CONTINUOUS, name="ContractUnits")  # contract-qualified production

# Constraints
for t in range(T):
    # Workforce balance
    if t == 0:
        model.addConstr(W[t] == W0 + H[t] - F[t])
    else:
        model.addConstr(W[t] == W[t - 1] + H[t] - F[t])

    # Production limited by total labor hours (regular + overtime)
    model.addConstr(P[t] * lr <= W[t] * rh + OT_total[t])

    # Overtime limit
    model.addConstr(OT_total[t] <= W[t] * otl)

    # Inventory balance
    prev_inv = I0 if t == 0 else Inv[t - 1]
    prev_b = 0 if t == 0 else B[t - 1]
    model.addConstr(Inv[t] - B[t] == prev_inv - prev_b + P[t] + O[t] - demand[t])

    # Contract constraints for April to June (t = 3, 4, 5)
    if t >= 3:
        model.addConstr(ContractUnits[t] <= W[t] * rh / lr)  # Limited by regular-time production
        model.addConstr(ContractUnits[t] <= demand[t] + (B[t - 1] if t > 0 else 0))  # Limited by net demand
        model.addConstr(ContractUnits[t] >= contract_min_units * ContractSatisfied[t])  # Enforce minimum if satisfied
        model.addConstr(ContractUnits[t] <= contract_bigM * ContractSatisfied[t])  # Big-M constraint

# Terminal conditions
model.addConstr(Inv[T - 1] >= term_inv)
model.addConstr(B[T - 1] <= term_bo)

# Objective: maximize net profit
# Revenue
total_demand = sum(demand)
revenue = sp * total_demand

# Costs
material_cost = gp.quicksum(rmc * P[t] for t in range(T))
outsource_cost = gp.quicksum(oc * O[t] for t in range(T))
holding_cost = gp.quicksum(hc * Inv[t] for t in range(T))
backorder_cost_total = gp.quicksum(bc * B[t] for t in range(T))
regular_labor_cost = gp.quicksum(rw * rh * W[t] for t in range(T))
overtime_cost = gp.quicksum(ow * OT_total[t] for t in range(T))
hiring_cost_total = gp.quicksum(hire_cost * H[t] for t in range(T))
firing_cost_total = gp.quicksum(fire_cost * F[t] for t in range(T))

total_cost = (material_cost + outsource_cost + holding_cost + backorder_cost_total +
              regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total)

model.setObjective(revenue - total_cost, GRB.MAXIMIZE)

# Solve
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
