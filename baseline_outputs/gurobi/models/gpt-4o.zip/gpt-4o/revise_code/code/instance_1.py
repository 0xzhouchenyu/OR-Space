import os
import gurobipy as gp
from gurobipy import GRB
import csv

def load_csv(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            rows.append(row)
    return rows

def load_parameters():
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name'].strip()
        val = row['Value'].strip()
        try:
            if '.' in val:
                params[name] = float(val)
            else:
                params[name] = int(val)
        except ValueError:
            params[name] = val
    return params

def load_demand():
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        week = int(row['Week'].strip())
        demand[week] = {
            'I': int(row['I'].strip()),
            'II': int(row['II'].strip())
        }
    return demand

params = load_parameters()
demand = load_demand()

T = 8  # weeks
weeks = range(1, T + 1)

# Parameters
S0 = params['skilled_worker_count']
rate_I = params['food_I_production_rate']
rate_II = params['food_II_production_rate']
normal_hours = params['worker_weekly_hours']
overtime_hours = params['skilled_worker_overtime_hours']
train_cap = params['training_capacity']
train_period = params['training_period']
wage_skilled = params['skilled_worker_weekly_wage']
wage_trainee_during = params['trainee_weekly_wage_during_training']
wage_trainee_after = params['trainee_weekly_wage_after_training']
wage_overtime = params['skilled_worker_overtime_wage']
comp_I = params['compensation_fee_food_I']
comp_II = params['compensation_fee_food_II']
new_worker_goal = params['new_worker_training_goal']

model = gp.Model("factory_training")
model.setParam('OutputFlag', 0)

# Decision variables
n_train = {t: model.addVar(vtype=GRB.INTEGER, name=f"n_train_{t}") for t in weeks if t <= T - 1}
n_overtime = {t: model.addVar(vtype=GRB.INTEGER, name=f"n_ot_{t}") for t in weeks}
backlog_I = {t: model.addVar(lb=0, name=f"bI_{t}") for t in weeks}
backlog_II = {t: model.addVar(lb=0, name=f"bII_{t}") for t in weeks}
h_I_s = {t: model.addVar(lb=0, name=f"hIs_{t}") for t in weeks}
h_II_s = {t: model.addVar(lb=0, name=f"hIIs_{t}") for t in weeks}
h_I_ot = {t: model.addVar(lb=0, name=f"hIot_{t}") for t in weeks}
h_II_ot = {t: model.addVar(lb=0, name=f"hIIot_{t}") for t in weeks}
h_I_g = {t: model.addVar(lb=0, name=f"hIg_{t}") for t in weeks}
h_II_g = {t: model.addVar(lb=0, name=f"hIIg_{t}") for t in weeks}
produce_I = {t: model.addVar(vtype=GRB.BINARY, name=f"produce_I_{t}") for t in weeks}
produce_II = {t: model.addVar(vtype=GRB.BINARY, name=f"produce_II_{t}") for t in weeks}

# Mutual exclusion constraint
for t in weeks:
    model.addConstr(produce_I[t] + produce_II[t] <= 1, f"mutual_exclusion_{t}")

# Helper functions
def trainers_busy(t):
    return gp.quicksum(n_train[s] for s in weeks if s <= t <= s + train_period - 1)

def graduates_available(t):
    return gp.quicksum(train_cap * n_train[s] for s in weeks if s + train_period <= t)

# Constraints
for t in weeks:
    busy_t = trainers_busy(t)
    avail_skilled_t = S0 - busy_t
    grads_t = graduates_available(t)

    model.addConstr(n_overtime[t] <= avail_skilled_t, f"ot_limit_{t}")
    model.addConstr(h_I_s[t] + h_II_s[t] <= (avail_skilled_t - n_overtime[t]) * normal_hours, f"skilled_normal_hours_{t}")
    model.addConstr(h_I_ot[t] + h_II_ot[t] <= n_overtime[t] * overtime_hours, f"skilled_ot_hours_{t}")
    model.addConstr(h_I_g[t] + h_II_g[t] <= grads_t * normal_hours, f"grad_hours_{t}")

    prod_I_t = (h_I_s[t] + h_I_ot[t] + h_I_g[t]) * rate_I
    prod_II_t = (h_II_s[t] + h_II_ot[t] + h_II_g[t]) * rate_II

    prev_bI = backlog_I[t-1] if t > 1 else 0
    prev_bII = backlog_II[t-1] if t > 1 else 0

    model.addConstr(backlog_I[t] >= prev_bI + demand[t]['I'] - prod_I_t, f"backlog_I_{t}")
    model.addConstr(backlog_II[t] >= prev_bII + demand[t]['II'] - prod_II_t, f"backlog_II_{t}")

    model.addConstr(h_I_s[t] + h_I_ot[t] + h_I_g[t] <= produce_I[t] * (avail_skilled_t * normal_hours + n_overtime[t] * overtime_hours + grads_t * normal_hours), f"produce_I_hours_{t}")
    model.addConstr(h_II_s[t] + h_II_ot[t] + h_II_g[t] <= produce_II[t] * (avail_skilled_t * normal_hours + n_overtime[t] * overtime_hours + grads_t * normal_hours), f"produce_II_hours_{t}")

model.addConstr(gp.quicksum(train_cap * n_train[t] for t in weeks if t <= T - 1) >= new_worker_goal, "training_goal")

# Objective
total_cost = gp.quicksum(
    wage_skilled * (S0 - trainers_busy(t)) +
    wage_overtime * n_overtime[t] +
    wage_skilled * trainers_busy(t) +
    wage_trainee_during * gp.quicksum(n_train[s] for s in weeks if s <= t <= s + train_period - 1) +
    wage_trainee_after * graduates_available(t) +
    comp_I * backlog_I[t] +
    comp_II * backlog_II[t]
    for t in weeks
)
model.setObjective(total_cost, GRB.MINIMIZE)

# Solve
model.optimize()

# Output
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
