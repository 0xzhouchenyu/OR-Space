import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    budget = params['company_budget']
    max_employees = int(params['max_employees'])
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_gj = int(params['max_one_candidate_g_j'])
    lead_premium = params['lead_premium']
    min_leads = int(params['min_leads'])
    mentor_bonus = params['mentor_bonus']
    max_pairs = int(params['max_pairs'])
    
    # Create optimization model
    model = gp.Model("HiringOptimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {c['name']: model.addVar(vtype=GRB.BINARY, name=f"x_{c['name']}") for c in candidates}
    lead = {c['name']: model.addVar(vtype=GRB.BINARY, name=f"lead_{c['name']}") for c in candidates}
    engineer = {c['name']: model.addVar(vtype=GRB.BINARY, name=f"engineer_{c['name']}") for c in candidates}
    
    # Objective: minimize net cost
    total_salary = gp.quicksum((c['salary'] + lead_premium * lead[c['name']]) * x[c['name']] for c in candidates)
    total_mentorship_bonus = mentor_bonus * gp.min_(gp.quicksum(lead[c['name']] for c in candidates), 
                                                    gp.quicksum(engineer[c['name']] for c in candidates), 
                                                    max_pairs)
    model.setObjective(total_salary - total_mentorship_bonus, GRB.MINIMIZE)
    
    # Constraints
    # Budget constraint
    model.addConstr(gp.quicksum((c['salary'] + lead_premium * lead[c['name']]) * x[c['name']] for c in candidates) <= budget, "Budget")
    
    # Max employees constraint
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, "MaxEmployees")
    
    # Min skill level constraint
    model.addConstr(gp.quicksum(c['skill'] * x[c['name']] for c in candidates) >= min_skill, "MinSkill")
    
    # Min project management experience constraint
    model.addConstr(gp.quicksum(c['pm_exp'] * x[c['name']] for c in candidates) >= min_pm_exp, "MinPMExp")
    
    # At most one of G and J can be hired
    model.addConstr(x['G'] + x['J'] <= max_gj, "MaxOneGJ")
    
    # Each hire must be assigned exactly one role
    for c in candidates:
        model.addConstr(lead[c['name']] + engineer[c['name']] == x[c['name']], f"RoleAssignment_{c['name']}")
    
    # Minimum number of leads
    model.addConstr(gp.quicksum(lead[c['name']] for c in candidates) >= min_leads, "MinLeads")
    
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
