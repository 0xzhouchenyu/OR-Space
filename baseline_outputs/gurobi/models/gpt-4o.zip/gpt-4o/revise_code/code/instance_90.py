import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_general_parameters

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
shirts_inventory = params["shirts_inventory"]
pants_inventory = params["pants_inventory"]
price_a = params["package_a_price"]
price_b = params["package_b_price"]
price_c = params["package_c_price"]
shirts_a = params["package_a_shirts"]
pants_a = params["package_a_pants"]
shirts_b = params["package_b_shirts"]
pants_b = params["package_b_pants"]
shirts_c = params["package_c_shirts"]
pants_c = params["package_c_pants"]
min_a = params["min_campaign_batch_a"]
min_b = params["min_campaign_batch_b"]
min_c = params["min_campaign_batch_c"]
activation_cost_a = params["activation_cost_a"]
activation_cost_b = params["activation_cost_b"]
activation_cost_c = params["activation_cost_c"]
labor_a = params["labor_hours_per_A"]
labor_b = params["labor_hours_per_B"]
labor_c = params["labor_hours_per_C"]
labor_total = params["labor_hours_total"]
bigM_a = params["bigM_a"]
bigM_b = params["bigM_b"]
bigM_c = params["bigM_c"]
review_threshold_b = params["package_b_review_threshold"]
review_charge_b = params["package_b_review_charge"]
review_threshold_c = params["package_c_review_threshold"]
review_charge_c = params["package_c_review_charge"]

# Create the model
model = gp.Model("Revised_Optimization")
model.setParam("OutputFlag", 0)

# Decision variables
x_a = model.addVar(vtype=GRB.INTEGER, name="x_a")
x_b = model.addVar(vtype=GRB.INTEGER, name="x_b")
x_c = model.addVar(vtype=GRB.INTEGER, name="x_c")
y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
y_c = model.addVar(vtype=GRB.BINARY, name="y_c")
z_b = model.addVar(vtype=GRB.BINARY, name="z_b")
z_c = model.addVar(vtype=GRB.BINARY, name="z_c")

# Objective: Maximize revenue minus costs
revenue = price_a * x_a + price_b * x_b + price_c * x_c
activation_costs = activation_cost_a * y_a + activation_cost_b * y_b + activation_cost_c * y_c
review_costs = review_charge_b * z_b + review_charge_c * z_c
model.setObjective(revenue - activation_costs - review_costs, GRB.MAXIMIZE)

# Constraints
# Inventory constraints
model.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inventory, "Shirts_Inventory")
model.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inventory, "Pants_Inventory")

# Labor constraint
model.addConstr(labor_a * x_a + labor_b * x_b + labor_c * x_c <= labor_total, "Labor_Constraint")

# Minimum sales constraints
model.addConstr(x_a >= min_a * y_a, "Min_Sales_A")
model.addConstr(x_b >= min_b * y_b, "Min_Sales_B")
model.addConstr(x_c >= min_c * y_c, "Min_Sales_C")

# Linking constraints for activation
model.addConstr(x_a <= bigM_a * y_a, "Link_A")
model.addConstr(x_b <= bigM_b * y_b, "Link_B")
model.addConstr(x_c <= bigM_c * y_c, "Link_C")

# Review charge constraints
model.addConstr(x_b <= review_threshold_b + bigM_b * (1 - z_b), "Review_B_Threshold")
model.addConstr(x_b >= review_threshold_b + 1 - bigM_b * z_b, "Review_B_Charge")
model.addConstr(x_c <= review_threshold_c + bigM_c * (1 - z_c), "Review_C_Threshold")
model.addConstr(x_c >= review_threshold_c + 1 - bigM_c * z_c, "Review_C_Charge")

# Solve the model
model.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
