import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"]] = float(row["Value"]) if row["Unit"] != "N/A" else row["Value"].split(";")
    
    shift_duration = int(params["shift_duration"])
    shift_start_times = params["shift_start_times"]
    full_time_cost = params["full_time_cost"]
    part_time_cost = params["part_time_cost"]
    part_time_cap_per_period = int(params["part_time_cap_per_period"])
    min_full_time_per_period = int(params["min_full_time_per_period"])
    
    # Read staffing requirements
    requirements = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            requirements.append(int(row["Required_Salespeople"]))
    
    n_periods = len(requirements)  # 6 periods
    
    # Create model
    model = gp.Model("RevisedStaffing")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    full_time_starts = model.addVars(n_periods, vtype=GRB.INTEGER, name="full_time_starts")
    part_time_assignments = model.addVars(n_periods, vtype=GRB.INTEGER, name="part_time_assignments")
    
    # Objective: Minimize total cost
    model.setObjective(
        gp.quicksum(full_time_cost * full_time_starts[i] for i in range(n_periods)) +
        gp.quicksum(part_time_cost * part_time_assignments[j] for j in range(n_periods)),
        GRB.MINIMIZE
    )
    
    # Constraints
    for j in range(n_periods):
        # Coverage constraint: full-time + part-time must meet or exceed required salespeople
        model.addConstr(
            full_time_starts[j] + full_time_starts[(j - 1) % n_periods] + part_time_assignments[j] >= requirements[j],
            name=f"coverage_{j}"
        )
        
        # Part-time cap constraint
        model.addConstr(
            part_time_assignments[j] <= part_time_cap_per_period,
            name=f"part_time_cap_{j}"
        )
        
        # Minimum full-time presence constraint
        model.addConstr(
            full_time_starts[j] + full_time_starts[(j - 1) % n_periods] >= min_full_time_per_period,
            name=f"min_full_time_{j}"
        )
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
