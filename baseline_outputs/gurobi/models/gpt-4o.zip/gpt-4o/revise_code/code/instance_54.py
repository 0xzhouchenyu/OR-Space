import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    """Load and parse data files."""
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    table_1_path = os.path.join(data_dir, "table_1.csv")
    equipment_names = []
    products = []
    processing_times = {}  # (equipment, product) -> time
    effective_hours = {}   # equipment -> hours
    base_profit = {}       # product -> profit
    
    with open(table_1_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        products = header[1:-1]  # ['I', 'II', 'III']
        
        for row in reader:
            if row[0].startswith('Unit_Product_Profit'):
                for j, prod in enumerate(products):
                    base_profit[prod] = float(row[j + 1])
            else:
                equip = row[0]
                equipment_names.append(equip)
                effective_hours[equip] = float(row[-1])
                for j, prod in enumerate(products):
                    processing_times[(equip, prod)] = float(row[j + 1])
    
    # Load general_parameters.csv
    general_params_path = os.path.join(data_dir, "general_parameters.csv")
    params = {}
    with open(general_params_path, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            params[row[0]] = float(row[1])
    
    return products, equipment_names, processing_times, effective_hours, base_profit, params

def main():
    # Load data
    products, equipment_names, processing_times, effective_hours, base_profit, params = load_data()
    
    # Extract parameters
    overtime_hours_cap = params["overtime_hours_cap"]
    overtime_cost_multiplier = params["overtime_cost_multiplier"]
    min_prod = {p: params[f"min_prod_{p}"] for p in products}
    
    # Create model
    model = gp.Model("Factory_Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_reg = {p: model.addVar(lb=0, name=f"x_reg_{p}") for p in products}
    x_ot = {p: model.addVar(lb=0, name=f"x_ot_{p}") for p in products}
    
    # Objective: minimize total production cost
    model.setObjective(
        gp.quicksum(base_profit[p] * x_reg[p] + overtime_cost_multiplier * base_profit[p] * x_ot[p] for p in products),
        GRB.MINIMIZE
    )
    
    # Constraints: equipment capacity
    for equip in equipment_names:
        model.addConstr(
            gp.quicksum(processing_times[(equip, p)] * (x_reg[p] + x_ot[p]) for p in products) <= effective_hours[equip],
            name=f"Equipment_{equip}_capacity"
        )
    
    # Constraint: overtime hours cap
    model.addConstr(
        gp.quicksum(processing_times[(equip, p)] * x_ot[p] for equip in equipment_names for p in products) <= overtime_hours_cap,
        name="Overtime_hours_cap"
    )
    
    # Constraints: minimum production levels
    for p in products:
        model.addConstr(x_reg[p] + x_ot[p] >= min_prod[p], name=f"Min_prod_{p}")
    
    # Solve model
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal:.6f}")

if __name__ == "__main__":
    main()
