import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = int(params['min_manager_experience'])
    manager_bonus = int(params['manager_bonus_per_candidate'])

    # Create optimization model
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {c['name']: model.addVar(vtype=GRB.BINARY, name=f"x_{c['name']}") for c in candidates}
    manager = {c['name']: model.addVar(vtype=GRB.BINARY, name=f"manager_{c['name']}") for c in candidates}
    specialist = {c['name']: model.addVar(vtype=GRB.BINARY, name=f"specialist_{c['name']}") for c in candidates}

    # Objective: minimize total salary + manager bonuses
    model.setObjective(
        gp.quicksum(c['salary'] * x[c['name']] for c in candidates) +
        gp.quicksum(manager[c['name']] * manager_bonus for c in candidates),
        GRB.MINIMIZE
    )

    # Constraint 1: max employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees)

    # Constraint 2: budget
    model.addConstr(
        gp.quicksum(c['salary'] * x[c['name']] for c in candidates) +
        gp.quicksum(manager[c['name']] * manager_bonus for c in candidates) <= budget_limit
    )

    # Constraint 3: at least one with Master's or Doctoral degree
    advanced_candidates = [c for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(x[c['name']] for c in advanced_candidates) >= min_advanced)

    # Constraint 4: minimum total work experience
    model.addConstr(gp.quicksum(c['experience'] * x[c['name']] for c in candidates) >= min_experience)

    # Constraint 5: at most one from pair A and E
    model.addConstr(x['A'] + x['E'] <= max_equivalent)

    # Constraint 6: minimum employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) >= min_employees)

    # Constraint 7: role assignment (each candidate can be either manager or specialist, or not hired)
    for c in candidates:
        model.addConstr(manager[c['name']] + specialist[c['name']] == x[c['name']])

    # Constraint 8: manager headcount limits
    model.addConstr(gp.quicksum(manager[c['name']] for c in candidates) >= min_managers)
    model.addConstr(gp.quicksum(manager[c['name']] for c in candidates) <= max_managers)

    # Constraint 9: minimum manager experience
    model.addConstr(gp.quicksum(c['experience'] * manager[c['name']] for c in candidates) >= min_manager_experience)

    # Solve the model
    model.optimize()

    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
