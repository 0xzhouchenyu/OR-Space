import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
    
    # Read general_parameters.csv
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    max_storage = params['max_storage_capacity'] / 10000.0  # Convert to 万m³
    storage_cost_a = params['storage_cost_a'] * 10000.0 / 10000.0  # Convert to 万元/万m³
    storage_cost_b = params['storage_cost_b'] * 10000.0 / 10000.0  # Convert to 万元/万m³/quarter
    safety_inventory = params['safety_inventory_level_10k_m3']
    terminal_value = params['terminal_inventory_value_per_10k_m3']
    over_purchase_penalty = params['over_purchase_penalty_cost_per_10k_m3']
    
    n = len(quarters)
    
    # Create model
    model = gp.Model("Timber_Profit_Maximization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(n, n, lb=0, name="x")  # x[i, j]: amount purchased in quarter i and sold in quarter j (万m³)
    end_inventory = model.addVar(lb=0, name="end_inventory")  # End-of-autumn inventory (万m³)
    
    # Objective: maximize profit
    profit_terms = gp.quicksum(
        (sale_price[quarters[j]] - purchase_price[quarters[i]] - 
         (storage_cost_a + storage_cost_b * (j - i)) * (j > i)) * x[i, j]
        for i in range(n) for j in range(i, n)
    )
    terminal_value_term = terminal_value * end_inventory
    over_purchase_penalty_term = over_purchase_penalty * gp.max_(0, end_inventory - safety_inventory)
    model.setObjective(profit_terms + terminal_value_term - over_purchase_penalty_term, GRB.MAXIMIZE)
    
    # Constraints
    # Sales constraints: total sold in quarter j <= max_sales[j]
    model.addConstrs(
        gp.quicksum(x[i, j] for i in range(j + 1)) <= max_sales[quarters[j]]
        for j in range(n)
    )
    
    # Storage constraints: at end of each quarter, stored timber <= max_storage
    model.addConstrs(
        gp.quicksum(x[i, j] for i in range(t + 1) for j in range(t + 1, n)) <= max_storage
        for t in range(n - 1)
    )
    
    # Purchase constraints: total purchased in quarter i <= max_purchase[i]
    model.addConstrs(
        gp.quicksum(x[i, j] for j in range(i, n)) <= max_purchase[quarters[i]]
        for i in range(n)
    )
    
    # End-of-autumn inventory constraint
    model.addConstr(
        gp.quicksum(x[i, j] for i in range(n) for j in range(n - 1, n)) == end_inventory
    )
    
    # Solve model
    model.optimize()
    
    # Output result
    print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")

if __name__ == "__main__":
    main()
