import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load monthly prices
months = []
purchase_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        m = int(row['Month'])
        months.append(m)
        purchase_prices[m] = float(row['Purchase_Price_yuan_per_dan'])
        selling_prices[m] = float(row['Selling_Price_yuan_per_dan'])

# Load general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
initial_funds = params['initial_funds']
end_inventory = params['end_of_quarter_inventory']
buy_fast_capacity = params['buy_fast_capacity']
fast_purchase_premium_ratio = params['fast_purchase_premium_ratio']
credit_limit = params['credit_limit']
monthly_interest_rate = params['monthly_interest_rate']
min_inventory = {
    1: params['min_inventory_month_1'],
    2: params['min_inventory_month_2'],
    3: params['min_inventory_month_3']
}

# Create model
model = gp.Model("Grain_Trading")
model.setParam('OutputFlag', 0)

# Decision variables
buy_regular = {m: model.addVar(lb=0, name=f"buy_regular_{m}") for m in months}
buy_fast = {m: model.addVar(lb=0, ub=buy_fast_capacity, name=f"buy_fast_{m}") for m in months}
sell = {m: model.addVar(lb=0, name=f"sell_{m}") for m in months}
stock = {m: model.addVar(lb=0, name=f"stock_{m}") for m in months}
funds = {m: model.addVar(lb=0, name=f"funds_{m}") for m in months}
credit_used = {m: model.addVar(lb=0, ub=credit_limit, name=f"credit_used_{m}") for m in months}

# Objective: maximize final funds - initial funds - total interest
total_interest = gp.quicksum(monthly_interest_rate * credit_used[m] for m in months)
model.setObjective(funds[months[-1]] - initial_funds - total_interest, GRB.MAXIMIZE)

# Constraints
for m in months:
    prev_stock = initial_stock if m == 1 else stock[m - 1]
    prev_funds = initial_funds if m == 1 else funds[m - 1]
    prev_credit = 0 if m == 1 else credit_used[m - 1]

    # Stock balance
    model.addConstr(stock[m] == prev_stock - sell[m] + buy_regular[m] + buy_fast[m], f"stock_balance_{m}")

    # Funds and credit balance
    regular_cost = buy_regular[m] * purchase_prices[m]
    fast_cost = buy_fast[m] * purchase_prices[m] * (1 + fast_purchase_premium_ratio)
    sales_revenue = sell[m] * selling_prices[m]
    interest_payment = monthly_interest_rate * prev_credit
    model.addConstr(funds[m] + credit_used[m] == prev_funds + prev_credit + sales_revenue - regular_cost - fast_cost - interest_payment, f"funds_balance_{m}")

    # Credit limit
    model.addConstr(credit_used[m] <= credit_limit, f"credit_limit_{m}")

    # Warehouse capacity
    model.addConstr(stock[m] <= warehouse_capacity, f"warehouse_capacity_{m}")

    # Minimum inventory
    model.addConstr(stock[m] >= min_inventory[m], f"min_inventory_{m}")

    # Can only sell what was in stock before this month's purchase
    model.addConstr(sell[m] <= prev_stock, f"sell_limit_{m}")

# End of quarter inventory requirement
model.addConstr(stock[months[-1]] >= end_inventory, "end_inventory")

# Solve
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
