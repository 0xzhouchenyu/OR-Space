import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters from CSV
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
motorcycle_pollution = params['motorcycle_pollution']
small_truck_pollution = params['small_truck_pollution']
large_truck_pollution = params['large_truck_pollution']
max_motorcycle_trips = int(params['max_motorcycle_trips'])
motorcycle_capacity = params['motorcycle_capacity']
small_truck_capacity = params['small_truck_capacity']
large_truck_capacity = params['large_truck_capacity']
demand_peak = params['demand_peak_units']
demand_offpeak = params['demand_offpeak_units']
max_total_trips = int(params['max_total_trips'])
leasing_capacity = params['leasing_capacity']
leasing_pollution_per_unit = params['leasing_pollution_per_unit']
leasing_fixed_pollution = params['leasing_fixed_pollution']
max_leasing_fraction_peak = params['max_leasing_fraction_peak']
bigM_leasing = params['bigM_leasing']
epsilon = params['epsilon']

# Methods and their parameters
methods = ['motorcycle', 'small_truck', 'large_truck']
pollution = {
    'motorcycle': motorcycle_pollution,
    'small_truck': small_truck_pollution,
    'large_truck': large_truck_pollution
}
capacity = {
    'motorcycle': motorcycle_capacity,
    'small_truck': small_truck_capacity,
    'large_truck': large_truck_capacity
}

# Initialize model
model = gp.Model("Revised_Transport")
model.setParam('OutputFlag', 0)

# Decision variables
trips_peak = {m: model.addVar(vtype=GRB.INTEGER, name=f"trips_peak_{m}") for m in methods}
trips_offpeak = {m: model.addVar(vtype=GRB.INTEGER, name=f"trips_offpeak_{m}") for m in methods}
leasing_peak = model.addVar(vtype=GRB.CONTINUOUS, name="leasing_peak")
leasing_offpeak = model.addVar(vtype=GRB.CONTINUOUS, name="leasing_offpeak")
leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")

# Objective: Minimize total pollution
model.setObjective(
    gp.quicksum(pollution[m] * (trips_peak[m] + trips_offpeak[m]) for m in methods) +
    leasing_pollution_per_unit * (leasing_peak + leasing_offpeak) +
    leasing_fixed_pollution * leasing_used,
    GRB.MINIMIZE
)

# Constraints
# Peak and off-peak demand requirements
model.addConstr(
    gp.quicksum(capacity[m] * trips_peak[m] for m in methods) + leasing_peak >= demand_peak,
    "peak_demand"
)
model.addConstr(
    gp.quicksum(capacity[m] * trips_offpeak[m] for m in methods) + leasing_offpeak >= demand_offpeak,
    "offpeak_demand"
)

# Total trips limit
model.addConstr(
    gp.quicksum(trips_peak[m] + trips_offpeak[m] for m in methods) <= max_total_trips,
    "total_trips"
)

# Motorcycle trips limit
model.addConstr(trips_peak['motorcycle'] + trips_offpeak['motorcycle'] <= max_motorcycle_trips, "motorcycle_limit")

# Leasing capacity limit
model.addConstr(leasing_peak + leasing_offpeak <= leasing_capacity, "leasing_capacity")

# Leasing fraction limit for peak
model.addConstr(leasing_peak <= max_leasing_fraction_peak * demand_peak, "leasing_fraction_peak")

# Leasing activation constraints
model.addConstr(leasing_peak + leasing_offpeak <= bigM_leasing * leasing_used, "leasing_activation_upper")
model.addConstr(leasing_peak + leasing_offpeak >= epsilon * leasing_used, "leasing_activation_lower")

# Only two methods can be active
active_methods = {m: model.addVar(vtype=GRB.BINARY, name=f"active_{m}") for m in methods}
for m in methods:
    model.addConstr(trips_peak[m] + trips_offpeak[m] <= bigM_leasing * active_methods[m], f"active_{m}_upper")
model.addConstr(gp.quicksum(active_methods[m] for m in methods) == 2, "active_methods_limit")

# Solve the model
model.optimize()

# Output the result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: infeasible")
