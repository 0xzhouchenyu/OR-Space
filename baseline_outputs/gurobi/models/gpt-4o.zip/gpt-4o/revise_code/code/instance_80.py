import os
import gurobipy as gp
from gurobipy import GRB
import csv

# Utility functions to load data
def load_csv(filename):
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

def load_general_parameters(filename='general_parameters.csv'):
    rows = load_csv(filename)
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = row['Value']
        try:
            if '.' in value:
                params[name] = float(value)
            else:
                params[name] = int(value)
        except ValueError:
            params[name] = value
    return params

def load_task_methods(filename='table_1.csv'):
    rows = load_csv(filename)
    data = []
    for row in rows:
        data.append({
            'Task': row['Task'],
            'Method': row['Method'],
            'Effective_Hours': float(row['Effective_Hours']),
            'Fixed_Cost': float(row['Fixed_Cost'])
        })
    return data

# Load data
params = load_general_parameters()
task_methods = load_task_methods()

# Extract parameters
skilled_wage = params['skilled_worker_weekly_wage']
laborer_wage = params['laborer_weekly_wage']
skilled_hours = params['skilled_worker_weekly_hours']
laborer_hours = params['laborer_weekly_hours']
max_skilled = params['max_skilled_workers']
max_laborers = params['max_laborers']
min_skilled_task3_B = params['min_skilled_workers_task3_methodB']
skilled_hiring_ratio = params['skilled_worker_hiring_ratio']
min_skilled_share = {
    'Task_1': params['min_skilled_share_task1'],
    'Task_2': params['min_skilled_share_task2'],
    'Task_3': params['min_skilled_share_task3']
}
max_skilled_share = {
    'Task_1': params['max_skilled_share_task1'],
    'Task_2': params['max_skilled_share_task2'],
    'Task_3': params['max_skilled_share_task3']
}

# Organize task-method data
tasks = ['Task_1', 'Task_2', 'Task_3']
methods = ['Method_A', 'Method_B']
tm_data = {(row['Task'], row['Method']): row for row in task_methods}

# Create the model
model = gp.Model("WorkerAllocation")
model.setParam('OutputFlag', 0)

# Decision variables
y = model.addVars(tasks, methods, vtype=GRB.BINARY, name="y")
s = model.addVars(tasks, methods, lb=0, vtype=GRB.CONTINUOUS, name="s")
l = model.addVars(tasks, methods, lb=0, vtype=GRB.CONTINUOUS, name="l")
total_skilled = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_skilled")
total_laborers = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_laborers")

# Objective: Minimize total weekly cost
model.setObjective(
    skilled_wage * total_skilled + laborer_wage * total_laborers +
    gp.quicksum(tm_data[t, m]['Fixed_Cost'] * y[t, m] for t in tasks for m in methods),
    GRB.MINIMIZE
)

# Constraints
model.addConstr(total_skilled == gp.quicksum(s[t, m] for t in tasks for m in methods), "TotalSkilledDef")
model.addConstr(total_laborers == gp.quicksum(l[t, m] for t in tasks for m in methods), "TotalLaborersDef")

for t in tasks:
    model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1, f"OneMethod_{t}")
    for m in methods:
        req_hours = tm_data[t, m]['Effective_Hours']
        model.addConstr(skilled_hours * s[t, m] + laborer_hours * l[t, m] >= req_hours * y[t, m], f"Hours_{t}_{m}")
        model.addConstr(s[t, m] <= 10000 * y[t, m], f"LinkS_{t}_{m}")
        model.addConstr(l[t, m] <= 10000 * y[t, m], f"LinkL_{t}_{m}")
    model.addConstr(
        gp.quicksum(s[t, m] for m in methods) >= min_skilled_share[t] * gp.quicksum(s[t, m] + l[t, m] for m in methods),
        f"MinSkilledShare_{t}"
    )
    model.addConstr(
        gp.quicksum(s[t, m] for m in methods) <= max_skilled_share[t] * gp.quicksum(s[t, m] + l[t, m] for m in methods),
        f"MaxSkilledShare_{t}"
    )

model.addConstr(total_skilled <= max_skilled, "MaxSkilled")
model.addConstr(total_laborers <= max_laborers, "MaxLaborers")
model.addConstr(total_skilled <= skilled_hiring_ratio * total_laborers, "SkilledRatio")
model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1, "ExclusionRule")
model.addConstr(s['Task_3', 'Method_B'] >= min_skilled_task3_B * y['Task_3', 'Method_B'], "MinSkilledTask3B")

# Solve the model
model.optimize()

# Output the result
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
