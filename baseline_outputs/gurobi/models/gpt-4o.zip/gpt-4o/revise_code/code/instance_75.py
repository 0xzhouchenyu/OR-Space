import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters from CSV
def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']
T1 = params['available_time_process_1']
T2 = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']
c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
bigM = params['bigM_disposal']
disposal_cost = params['disposal_cost_per_unit_c']
disposal_cost_high = params['disposal_cost_per_unit_c_high']
profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

# Create the model
model = gp.Model("MaxProfit")
model.setParam('OutputFlag', 0)

# Decision variables
xA = model.addVar(lb=0, name="xA")  # units of product A
xB = model.addVar(lb=0, name="xB")  # units of product B
cSold = model.addVar(lb=0, name="cSold")  # units of by-product C sold
cDisposed = model.addVar(lb=0, name="cDisposed")  # units of by-product C disposed
z1 = model.addVar(vtype=GRB.BINARY, name="z1")  # high-throughput mode for process 1
z2 = model.addVar(vtype=GRB.BINARY, name="z2")  # high-throughput mode for process 2
cDisposedHigh = model.addVar(lb=0, name="cDisposedHigh")  # units of C disposed at higher cost

# Objective: maximize total profit
model.setObjective(
    profit_a * xA + profit_b * xB + profit_c * cSold
    - disposal_cost * (cDisposed - cDisposedHigh)
    - disposal_cost_high * cDisposedHigh,
    GRB.MAXIMIZE
)

# Constraints
# Process 1 time constraint
model.addConstr(a_p1 * xA + b_p1 * xB <= T1 + (T1_high - T1) * z1, "Process1Time")

# Process 2 time constraint
model.addConstr(a_p2 * xA + b_p2 * xB <= T2 + (T2_high - T2) * z2, "Process2Time")

# At most one process can use high-throughput mode
model.addConstr(z1 + z2 <= 1, "HighThroughputLimit")

# By-product C balance: total C produced = C sold + C disposed
model.addConstr(cSold + cDisposed == c_per_b * xB, "ByproductBalance")

# Maximum C that can be sold
model.addConstr(cSold <= max_c_sales, "MaxCSales")

# Threshold for higher disposal cost
model.addConstr(cDisposedHigh >= cDisposed - threshold_c, "HighDisposalStart")
model.addConstr(cDisposedHigh <= bigM * (cDisposed - threshold_c), "HighDisposalLimit")

# Solve the model
model.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
