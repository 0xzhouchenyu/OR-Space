import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    params = {}
    for _, row in df_params.iterrows():
        params[row['Parameter_Name']] = float(row['Value'])

    # Extract parameters
    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)

    raw_pipe_length_supplier1 = params['raw_pipe_length_supplier1']
    raw_pipe_length_supplier2 = params['raw_pipe_length_supplier2']
    max_cuts_supplier1 = int(params['max_cuts_per_pipe_supplier1'])
    max_cuts_supplier2 = int(params['max_cuts_per_pipe_supplier2'])
    max_leftover_supplier1 = params['max_leftover_length_supplier1']
    max_leftover_supplier2 = params['max_leftover_length_supplier2']
    max_patterns_supplier1 = int(params['max_cutting_patterns_supplier1'])
    max_patterns_supplier2 = int(params['max_cutting_patterns_supplier2'])
    purchase_cost_supplier1 = params['purchase_cost_per_pipe_supplier1']
    purchase_cost_supplier2 = params['purchase_cost_per_pipe_supplier2']
    discount_tier1_max_qty_supplier1 = int(params['discount_tier1_supplier1_max_qty'])
    fixed_discount_tier2_supplier1 = params['fixed_discount_tier2_supplier1']
    bigM_discount = int(params['bigM_discount'])

    cost_rates_supplier1 = [
        params['most_frequent_pattern_cost_rate_supplier1'],
        params['second_frequent_pattern_cost_rate_supplier1'],
        params['third_frequent_pattern_cost_rate_supplier1']
    ]
    cost_rates_supplier2 = [
        params['most_frequent_pattern_cost_rate_supplier2'],
        params['second_frequent_pattern_cost_rate_supplier2'],
        params['third_frequent_pattern_cost_rate_supplier2']
    ]

    # Generate cutting patterns for each supplier
    def generate_patterns(raw_pipe_length, max_cuts, max_leftover):
        patterns = []
        min_length = raw_pipe_length - max_leftover

        def helper(current_pattern, current_length, current_cuts, item_idx):
            if item_idx == n_items:
                if min_length <= current_length <= raw_pipe_length and current_cuts > 0:
                    patterns.append(tuple(current_pattern))
                return

            max_qty = min(
                int((raw_pipe_length - current_length) // lengths[item_idx]),
                max_cuts - current_cuts
            )

            for q in range(max_qty + 1):
                helper(
                    current_pattern + [q],
                    current_length + q * lengths[item_idx],
                    current_cuts + q,
                    item_idx + 1
                )

        helper([], 0, 0, 0)
        return patterns

    patterns_supplier1 = generate_patterns(raw_pipe_length_supplier1, max_cuts_supplier1, max_leftover_supplier1)
    patterns_supplier2 = generate_patterns(raw_pipe_length_supplier2, max_cuts_supplier2, max_leftover_supplier2)

    # Create optimization model
    model = gp.Model("Pipe_Cutting")
    model.setParam('OutputFlag', 0)

    # Variables
    y1 = model.addVars(len(patterns_supplier1), vtype=GRB.INTEGER, name="y1")
    y2 = model.addVars(len(patterns_supplier2), vtype=GRB.INTEGER, name="y2")
    z1 = model.addVars(len(patterns_supplier1), vtype=GRB.BINARY, name="z1")
    z2 = model.addVars(len(patterns_supplier2), vtype=GRB.BINARY, name="z2")
    u1 = model.addVars(max_patterns_supplier1, vtype=GRB.BINARY, name="u1")
    u2 = model.addVars(max_patterns_supplier2, vtype=GRB.BINARY, name="u2")
    x1 = model.addVar(vtype=GRB.INTEGER, name="x1")
    x2 = model.addVar(vtype=GRB.INTEGER, name="x2")
    d1 = model.addVar(vtype=GRB.BINARY, name="d1")

    # Objective
    purchase_cost = x1 * purchase_cost_supplier1 + x2 * purchase_cost_supplier2
    discount = fixed_discount_tier2_supplier1 * d1
    extra_cost_supplier1 = gp.quicksum(cost_rates_supplier1[k] * u1[k] for k in range(max_patterns_supplier1))
    extra_cost_supplier2 = gp.quicksum(cost_rates_supplier2[k] * u2[k] for k in range(max_patterns_supplier2))
    model.setObjective(purchase_cost - discount + extra_cost_supplier1 + extra_cost_supplier2, GRB.MINIMIZE)

    # Constraints
    for i in range(n_items):
        model.addConstr(
            gp.quicksum(patterns_supplier1[p][i] * y1[p] for p in range(len(patterns_supplier1))) +
            gp.quicksum(patterns_supplier2[p][i] * y2[p] for p in range(len(patterns_supplier2))) >= demands[i]
        )

    M = sum(demands)
    for p in range(len(patterns_supplier1)):
        model.addConstr(y1[p] <= M * z1[p])
    for p in range(len(patterns_supplier2)):
        model.addConstr(y2[p] <= M * z2[p])

    model.addConstr(gp.quicksum(z1[p] for p in range(len(patterns_supplier1))) == gp.quicksum(u1[k] for k in range(max_patterns_supplier1)))
    model.addConstr(gp.quicksum(z2[p] for p in range(len(patterns_supplier2))) == gp.quicksum(u2[k] for k in range(max_patterns_supplier2)))

    for k in range(max_patterns_supplier1 - 1):
        model.addConstr(u1[k] >= u1[k + 1])
    for k in range(max_patterns_supplier2 - 1):
        model.addConstr(u2[k] >= u2[k + 1])

    model.addConstr(gp.quicksum(z1[p] for p in range(len(patterns_supplier1))) <= max_patterns_supplier1)
    model.addConstr(gp.quicksum(z2[p] for p in range(len(patterns_supplier2))) <= max_patterns_supplier2)

    model.addConstr(x1 == gp.quicksum(y1[p] for p in range(len(patterns_supplier1))))
    model.addConstr(x2 == gp.quicksum(y2[p] for p in range(len(patterns_supplier2))))

    model.addConstr(x1 <= discount_tier1_max_qty_supplier1 + bigM_discount * d1)
    model.addConstr(x1 >= discount_tier1_max_qty_supplier1 * d1)

    # Solve
    model.optimize()

    # Output result
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
