import os
import gurobipy as gp
from gurobipy import GRB
import csv

# Utility functions to load data
def load_car_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    cars = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            i = int(row['i'])
            length = float(row['lambda_i'])
            cars[i] = length
    return cars

def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'])
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
cars = load_car_data(data_dir)
params = load_parameters(data_dir)

num_cars = int(params['num_cars'])
max_length_one_side = params['max_length_one_side']

car_ids = list(cars.keys())
lengths = cars

# Gurobi model
model = gp.Model("RevisedParkingMinStreetLength")
model.setParam('OutputFlag', 0)

# Decision variables
x = {i: model.addVar(vtype=GRB.BINARY, name=f"x_{i}") for i in car_ids}

# Objective: minimize total length of cars parked
model.setObjective(gp.quicksum(lengths[i] * x[i] for i in car_ids), GRB.MINIMIZE)

# Constraint: total length of cars on the usable side <= max_length_one_side
model.addConstr(gp.quicksum(lengths[i] * x[i] for i in car_ids) <= max_length_one_side, "max_side_length")

# Solve the model
model.optimize()

# Output the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: No optimal solution found")
