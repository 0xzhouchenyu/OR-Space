import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load courses data
def load_courses(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    courses = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            categories = [c.strip() for c in row['Category'].split(';')]
            courses[course] = categories
    return courses

# Load parameters data
def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    prerequisites = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if name == 'min_courses_required':
                params['min_courses_required'] = int(value)
            elif name == 'mandatory_foundation_for_cs_counting':
                params['mandatory_foundation_for_cs_counting'] = value
            elif name == 'cs_category_name':
                params['cs_category_name'] = value
            elif name.startswith('prerequisite_'):
                course_key = name[len('prerequisite_'):]
                prerequisites[course_key] = value
    return params, prerequisites

# Match prerequisite course
def match_prerequisite_course(prereq_key, course_list):
    key_lower = prereq_key.lower().replace('_', ' ')
    for course in course_list:
        if course.lower() == key_lower:
            return course
    return None

# Main script
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
courses = load_courses(data_dir)
params, prereq_raw = load_parameters(data_dir)

min_required = params['min_courses_required']
mandatory_foundation = params['mandatory_foundation_for_cs_counting']
cs_category_name = params['cs_category_name']

course_list = list(courses.keys())
prerequisites = {}

for prereq_key, prereq_value in prereq_raw.items():
    course_name = match_prerequisite_course(prereq_key, course_list)
    if course_name:
        if course_name not in prerequisites:
            prerequisites[course_name] = []
        prerequisites[course_name].append(prereq_value.strip())

# Create optimization model
model = gp.Model("CourseSelection")
model.setParam('OutputFlag', 0)

# Decision variables: binary, whether to take each course
x = {course: model.addVar(vtype=GRB.BINARY, name=f"x_{course.replace(' ', '_')}") for course in course_list}

# Objective: minimize total number of courses taken
model.setObjective(gp.quicksum(x[course] for course in course_list), GRB.MINIMIZE)

# Constraint: at least min_required distinct courses in each category
all_categories = set()
for cats in courses.values():
    for c in cats:
        all_categories.add(c)

for category in all_categories:
    courses_in_cat = [course for course, cats in courses.items() if category in cats]
    model.addConstr(gp.quicksum(x[course] for course in courses_in_cat) >= min_required, f"Min_{category.replace(' ', '_')}")

# Constraint: cross-listed courses cannot satisfy multiple category minima simultaneously
for course, cats in courses.items():
    if len(cats) > 1:
        for cat in cats:
            model.addConstr(x[course] <= gp.quicksum(x[c] for c in courses if cat in courses[c]), f"Crosslist_{course.replace(' ', '_')}_{cat.replace(' ', '_')}")

# Prerequisite constraints: if you take a course, you must take its prerequisites
for course, prereqs in prerequisites.items():
    for prereq in prereqs:
        model.addConstr(x[course] <= x[prereq], f"Prereq_{course.replace(' ', '_')}_needs_{prereq.replace(' ', '_')}")

# Constraint: mandatory foundation course for Computer Science category
cs_courses = [course for course, cats in courses.items() if cs_category_name in cats]
model.addConstr(gp.quicksum(x[course] for course in cs_courses) <= x[mandatory_foundation], "Mandatory_CS_Foundation")

# Solve the model
model.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
