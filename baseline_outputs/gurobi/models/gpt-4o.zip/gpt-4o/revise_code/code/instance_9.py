import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_toy_data, load_general_parameters

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
toys = load_toy_data(os.path.join(data_dir, "table_1.csv"))
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Parameters
available_wood = params["available_wood"]
available_steel = params["available_steel"]
profit_premium_bonus = params["profit_premium_bonus"]
premium_steel_factor = params["premium_steel_factor"]
premium_shift_capacity = params["premium_shift_capacity"]

# Create model
model = gp.Model("HausToys")
model.setParam("OutputFlag", 0)

# Decision variables
x_std = {t["type"]: model.addVar(vtype=GRB.CONTINUOUS, name=f"x_std_{t['type']}") for t in toys}
x_prem = {t["type"]: model.addVar(vtype=GRB.CONTINUOUS, name=f"x_prem_{t['type']}") for t in toys}
y = {t["type"]: model.addVar(vtype=GRB.BINARY, name=f"y_{t['type']}") for t in toys}

# Objective: maximize profit
model.setObjective(
    gp.quicksum(
        t["profit"] * x_std[t["type"]] + (t["profit"] + profit_premium_bonus) * x_prem[t["type"]]
        for t in toys
    ),
    GRB.MAXIMIZE,
)

# Resource constraints
model.addConstr(
    gp.quicksum(t["wood"] * (x_std[t["type"]] + x_prem[t["type"]]) for t in toys) <= available_wood,
    "Wood_Constraint",
)
model.addConstr(
    gp.quicksum(
        t["steel"] * x_std[t["type"]] + premium_steel_factor * t["steel"] * x_prem[t["type"]]
        for t in toys
    )
    <= available_steel,
    "Steel_Constraint",
)

# Premium shift capacity constraint
model.addConstr(
    gp.quicksum(x_prem[t["type"]] for t in toys) <= premium_shift_capacity, "Premium_Shift_Capacity"
)

# Linking constraints: x_std_i + x_prem_i <= M * y_i
for t in toys:
    model.addConstr(x_std[t["type"]] + x_prem[t["type"]] <= 1000 * y[t["type"]], f"Link_{t['type']}")

# Truck-train exclusion: if trucks manufactured, no trains
model.addConstr(y["truck"] + y["train"] <= 1, "Truck_Train_Exclusion")

# Boat-airplane dependency: if boats manufactured, airplanes must be too
model.addConstr(y["boat"] <= y["airplane"], "Boat_Airplane_Dependency")

# Boat-train limit: total boats <= total trains
model.addConstr(
    gp.quicksum(x_std["boat"] + x_prem["boat"]) <= gp.quicksum(x_std["train"] + x_prem["train"]),
    "Boat_Train_Limit",
)

# Solve
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
