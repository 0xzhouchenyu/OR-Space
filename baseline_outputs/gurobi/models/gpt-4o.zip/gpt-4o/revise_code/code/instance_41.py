import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "initial_capital":
            initial_capital = float(row["Value"].strip())

# Load liquidity policy
with open(os.path.join(data_dir, "liquidity_policy.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "min_year3_reserve":
            min_year3_reserve = float(row["Value"].strip())
        elif row["Parameter_Name"].strip() == "reserve_shortfall_penalty":
            reserve_shortfall_penalty = float(row["Value"].strip())

# Load project data
projects = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        projects.append(row)

# Create Gurobi model
model = gp.Model("Investment_Maximization")
model.setParam("OutputFlag", 0)

# Decision variables
x1_1 = model.addVar(lb=0, name="x1_1")
x1_2 = model.addVar(lb=0, name="x1_2")
x1_3 = model.addVar(lb=0, name="x1_3")
x2 = model.addVar(lb=0, ub=120000, name="x2")
x3 = model.addVar(lb=0, ub=150000, name="x3")
x4 = model.addVar(lb=0, ub=100000, name="x4")
reserve_shortfall = model.addVar(lb=0, name="reserve_shortfall")

# Year 1 budget constraint
model.addConstr(x1_1 + x2 <= initial_capital, "Year1_Budget")

# Year 2 budget constraint
model.addConstr(x1_2 + x3 <= x1_1 * 1.20, "Year2_Budget")

# Year 3 budget constraint
model.addConstr(x1_3 + x4 + reserve_shortfall >= min_year3_reserve, "Year3_Reserve")
model.addConstr(x1_3 + x4 <= x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60, "Year3_Budget")

# Objective: maximize net profit at end of Year 3
# Total wealth at end of Year 3: x1_3 * 1.20 + x4 * 1.40 + reserve_shortfall
# Penalty for reserve shortfall: reserve_shortfall * reserve_shortfall_penalty
model.setObjective(
    x1_3 * 1.20 + x4 * 1.40 + (min_year3_reserve - reserve_shortfall) - reserve_shortfall * reserve_shortfall_penalty,
    GRB.MAXIMIZE,
)

# Solve the model
model.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
