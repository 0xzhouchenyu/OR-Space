import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
profit_A = params['profit_per_kg_product_A']
profit_B = params['profit_per_kg_product_B']
hours_A = params['hours_per_kg_product_A']
hours_B = params['hours_per_kg_product_B']
min_ratio_B_to_A = params['min_output_ratio_product_B_to_A']
storage_ratio_A_to_B = params['storage_space_ratio_product_A_to_B']
max_storage_A_week_1 = params['max_storage_product_A_equiv_week_1']
max_storage_A_week_2 = params['max_storage_product_A_equiv_week_2']
max_hours_week_1 = params['max_production_hours_week_1']
max_hours_week_2 = params['max_production_hours_week_2']
initial_inventory_A = params['initial_inventory_A']
initial_inventory_B = params['initial_inventory_B']
storage_cost_A = params['storage_cost_per_kg_A']
storage_cost_B = params['storage_cost_per_kg_B']
promo_bonus_A = params['promo_profit_bonus_A']
promo_bonus_B = params['promo_profit_bonus_B']
max_promotions_A = params['max_promotions_product_A']
max_promotions_B = params['max_promotions_product_B']

# Create the model
model = gp.Model("Two_Week_Production_Plan")
model.setParam('OutputFlag', 0)

# Decision variables
x_A_week_1 = model.addVar(lb=0, name="x_A_week_1")
x_B_week_1 = model.addVar(lb=0, name="x_B_week_1")
x_A_week_2 = model.addVar(lb=0, name="x_A_week_2")
x_B_week_2 = model.addVar(lb=0, name="x_B_week_2")
inventory_A_week_1 = model.addVar(lb=0, name="inventory_A_week_1")
inventory_B_week_1 = model.addVar(lb=0, name="inventory_B_week_1")
promo_A_week_1 = model.addVar(vtype=GRB.BINARY, name="promo_A_week_1")
promo_B_week_1 = model.addVar(vtype=GRB.BINARY, name="promo_B_week_1")
promo_A_week_2 = model.addVar(vtype=GRB.BINARY, name="promo_A_week_2")
promo_B_week_2 = model.addVar(vtype=GRB.BINARY, name="promo_B_week_2")

# Objective function: maximize profit
profit_week_1 = (profit_A + promo_bonus_A * promo_A_week_1) * x_A_week_1 + \
                (profit_B + promo_bonus_B * promo_B_week_1) * x_B_week_1
profit_week_2 = (profit_A + promo_bonus_A * promo_A_week_2) * x_A_week_2 + \
                (profit_B + promo_bonus_B * promo_B_week_2) * x_B_week_2
storage_cost = storage_cost_A * inventory_A_week_1 + storage_cost_B * inventory_B_week_1
model.setObjective(profit_week_1 + profit_week_2 - storage_cost, GRB.MAXIMIZE)

# Constraints
# Week 1 production time
model.addConstr(hours_A * x_A_week_1 + hours_B * x_B_week_1 <= max_hours_week_1, "Production_Hours_Week_1")
# Week 2 production time
model.addConstr(hours_A * x_A_week_2 + hours_B * x_B_week_2 <= max_hours_week_2, "Production_Hours_Week_2")

# Market demand constraints
model.addConstr(x_B_week_1 >= min_ratio_B_to_A * x_A_week_1, "Market_Demand_Week_1")
model.addConstr(x_B_week_2 >= min_ratio_B_to_A * x_A_week_2, "Market_Demand_Week_2")

# Storage capacity constraints
max_storage_units_week_1 = max_storage_A_week_1 * storage_ratio_A_to_B
max_storage_units_week_2 = max_storage_A_week_2 * storage_ratio_A_to_B
model.addConstr(storage_ratio_A_to_B * x_A_week_1 + x_B_week_1 <= max_storage_units_week_1, "Storage_Capacity_Week_1")
model.addConstr(storage_ratio_A_to_B * x_A_week_2 + x_B_week_2 + 
                storage_ratio_A_to_B * inventory_A_week_1 + inventory_B_week_1 <= max_storage_units_week_2, 
                "Storage_Capacity_Week_2")

# Inventory balance constraints
model.addConstr(inventory_A_week_1 == initial_inventory_A + x_A_week_1 - x_A_week_2, "Inventory_Balance_A_Week_1")
model.addConstr(inventory_B_week_1 == initial_inventory_B + x_B_week_1 - x_B_week_2, "Inventory_Balance_B_Week_1")

# Promotion constraints
model.addConstr(promo_A_week_1 + promo_A_week_2 <= max_promotions_A, "Max_Promotions_A")
model.addConstr(promo_B_week_1 + promo_B_week_2 <= max_promotions_B, "Max_Promotions_B")

# Solve the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal:.3f}")
