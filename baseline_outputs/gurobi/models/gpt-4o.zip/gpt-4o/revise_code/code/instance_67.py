import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    """Load a CSV file and return list of dictionaries."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return [row for row in reader]

def load_demand():
    """Load demand data from table_1.csv."""
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        month = row['Month']
        product = row['Product']
        units = int(row['Market_Demand_Units'])
        demand[(month, product)] = units
    return demand

def load_parameters():
    """Load general parameters."""
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = float(row['Value'])
        params[name] = value
    return params

def main():
    demand_data = load_demand()
    params = load_parameters()
    
    # Planning months: July to December
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']
    
    # Parameters
    prod_cost = {
        'Product_I': params['product_I_cost_jun_to_dec'],
        'Product_II': params['product_II_cost_jun_to_dec']
    }
    volume = {
        'Product_I': params['product_I_volume'],
        'Product_II': params['product_II_volume']
    }
    machine_hours = {
        'Product_I': params['product_I_machine_hours'],
        'Product_II': params['product_II_machine_hours']
    }
    power_kwh = {
        'Product_I': params['product_I_power_kwh'],
        'Product_II': params['product_II_power_kwh']
    }
    warehouse_cap = params['warehouse_capacity']
    own_cost = params['own_warehouse_cost']
    grid_cost = params['grid_electricity_cost']
    gen_cost = params['generator_electricity_cost']
    machine_hours_cap = params['machine_hours_capacity_monthly']
    
    grid_quota = {month: params[f'grid_quota_{month.lower()}'] for month in months}
    generator_max = {month: params[f'generator_max_{month.lower()}'] for month in months}
    
    # Demand for planning months
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]
    
    # Model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars([(m, p) for m in months for p in products], lb=0, vtype=GRB.CONTINUOUS, name="prod")
    inv = model.addVars([(m, p) for m in months for p in products], lb=0, vtype=GRB.CONTINUOUS, name="inv")
    own_wh = model.addVars(months, lb=0, vtype=GRB.CONTINUOUS, name="own_wh")
    grid_usage = model.addVars(months, lb=0, vtype=GRB.CONTINUOUS, name="grid_usage")
    gen_usage = model.addVars(months, lb=0, vtype=GRB.CONTINUOUS, name="gen_usage")
    
    # Objective: minimize production cost + inventory holding cost + electricity cost
    model.setObjective(
        gp.quicksum(prod_cost[p] * x[(m, p)] for m in months for p in products) +
        gp.quicksum(own_cost * own_wh[m] for m in months) +
        gp.quicksum(grid_cost * grid_usage[m] + gen_cost * gen_usage[m] for m in months),
        GRB.MINIMIZE
    )
    
    # Constraints
    for i, m in enumerate(months):
        # Inventory balance
        for p in products:
            if i == 0:
                model.addConstr(inv[(m, p)] == params['initial_inventory_july'] + x[(m, p)] - demand[(m, p)])
            else:
                prev_m = months[i - 1]
                model.addConstr(inv[(m, p)] == inv[(prev_m, p)] + x[(m, p)] - demand[(m, p)])
        
        # Machine hours capacity
        model.addConstr(gp.quicksum(machine_hours[p] * x[(m, p)] for p in products) <= machine_hours_cap)
        
        # Electricity constraints
        total_power = gp.quicksum(power_kwh[p] * x[(m, p)] for p in products)
        model.addConstr(grid_usage[m] + gen_usage[m] >= total_power)
        model.addConstr(grid_usage[m] <= grid_quota[m])
        model.addConstr(gen_usage[m] <= generator_max[m])
        
        # Warehouse capacity
        total_vol = gp.quicksum(volume[p] * inv[(m, p)] for p in products)
        model.addConstr(own_wh[m] >= total_vol)
        model.addConstr(own_wh[m] <= warehouse_cap)
    
    # Solve
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
