import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

m = int(params["m"])  # production points
n = int(params["n"])  # demand points
p = int(params["p"])  # marshaling stations

a = {i: params[f"a_{i}"] for i in range(1, m + 1)}  # production capacities
b = {j: params[f"b_{j}"] for j in range(1, n + 1)}  # demands
f_cost = {k: params[f"f_{k}"] for k in range(1, p + 1)}  # fixed costs
q = {k: params[f"q_{k}"] for k in range(1, p + 1)}  # max total transshipment capacity
qexp = {k: params[f"qexp_{k}"] for k in range(1, p + 1)}  # max express capacity
alpha = {j: params[f"alpha_{j}"] for j in range(1, n + 1)}  # min express fraction
eps = params["eps"]  # minimum strictly positive express flow
M = params["M"]  # Big-M upper bound

# Load transportation costs from production to marshaling stations
cR_ik, cE_ik = {}, {}
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        i, k = int(row["i"]), int(row["k"])
        cR_ik[(i, k)] = float(row["cR_ik"])
        cE_ik[(i, k)] = float(row["cE_ik"])

# Load transportation costs from marshaling stations to demand points
cR_kj, cE_kj = {}, {}
with open(os.path.join(data_dir, "table_2.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        k, j = int(row["k"]), int(row["j"])
        cR_kj[(k, j)] = float(row["cR_kj"])
        cE_kj[(k, j)] = float(row["cE_kj"])

# Create the optimization model
model = gp.Model("Revised_Transportation_Problem")
model.setParam("OutputFlag", 0)

# Decision variables
xR = model.addVars([(i, k) for i in range(1, m + 1) for k in range(1, p + 1)], lb=0, name="xR")
xE = model.addVars([(i, k) for i in range(1, m + 1) for k in range(1, p + 1)], lb=0, name="xE")
yR = model.addVars([(k, j) for k in range(1, p + 1) for j in range(1, n + 1)], lb=0, name="yR")
yE = model.addVars([(k, j) for k in range(1, p + 1) for j in range(1, n + 1)], lb=0, name="yE")
z = model.addVars(range(1, p + 1), vtype=GRB.BINARY, name="z")

# Objective: minimize total transportation cost + fixed costs
model.setObjective(
    gp.quicksum(cR_ik[i, k] * xR[i, k] + cE_ik[i, k] * xE[i, k] for i in range(1, m + 1) for k in range(1, p + 1))
    + gp.quicksum(cR_kj[k, j] * yR[k, j] + cE_kj[k, j] * yE[k, j] for k in range(1, p + 1) for j in range(1, n + 1))
    + gp.quicksum(f_cost[k] * z[k] for k in range(1, p + 1)),
    GRB.MINIMIZE,
)

# Constraints

# 1. Supply constraints: total shipped from production point i <= a_i
for i in range(1, m + 1):
    model.addConstr(gp.quicksum(xR[i, k] + xE[i, k] for k in range(1, p + 1)) <= a[i], f"Supply_{i}")

# 2. Demand constraints: total received at demand point j >= b_j
for j in range(1, n + 1):
    model.addConstr(gp.quicksum(yR[k, j] + yE[k, j] for k in range(1, p + 1)) >= b[j], f"Demand_{j}")

# 3. Flow conservation at marshaling stations
for k in range(1, p + 1):
    model.addConstr(
        gp.quicksum(xR[i, k] + xE[i, k] for i in range(1, m + 1))
        == gp.quicksum(yR[k, j] + yE[k, j] for j in range(1, n + 1)),
        f"FlowBalance_{k}",
    )

# 4. Capacity constraints at marshaling stations (regular + express)
for k in range(1, p + 1):
    model.addConstr(gp.quicksum(xR[i, k] + xE[i, k] for i in range(1, m + 1)) <= q[k] * z[k], f"Capacity_{k}")
    model.addConstr(gp.quicksum(xE[i, k] for i in range(1, m + 1)) <= qexp[k], f"ExpressCapacity_{k}")

# 5. Diversified express share constraints
for j in range(1, n + 1):
    model.addConstr(
        gp.quicksum(yE[k, j] for k in range(1, p + 1)) >= alpha[j] * b[j], f"ExpressFraction_{j}"
    )
    model.addConstr(
        gp.quicksum(yE[k, j] for k in range(1, p + 1)) <= M, f"BigM_{j}"
    )
    model.addConstr(
        gp.quicksum(yE[k, j] for k in range(1, p + 1)) >= eps, f"PositiveExpress_{j}"
    )

# Solve the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
