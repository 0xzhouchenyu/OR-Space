import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            try:
                value = int(value_str)
            except ValueError:
                try:
                    value = float(value_str)
                except ValueError:
                    value = value_str
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
cost_A = params['cost_per_chair_A']
cost_B = params['cost_per_chair_B']
cost_C = params['cost_per_chair_C']
chairs_per_order_A = params['chairs_per_order_A']
chairs_per_order_B = params['chairs_per_order_B']
chairs_per_order_C = params['chairs_per_order_C']
min_total = params['min_total_chairs']
max_total = params['max_total_chairs']
min_chairs_B_if_A = params['min_chairs_B_if_A']
dependency_B_C = params['dependency_B_C']
fixed_fee_A_regular = params['fixed_fee_A_regular']
fixed_fee_A_express = params['fixed_fee_A_express']
fixed_fee_B_regular = params['fixed_fee_B_regular']
fixed_fee_B_express = params['fixed_fee_B_express']
fixed_fee_C_regular = params['fixed_fee_C_regular']
fixed_fee_C_express = params['fixed_fee_C_express']
weekly_order_budget = params['weekly_order_budget']

# Create model
model = gp.Model("FurnitureOrder")
model.setParam('OutputFlag', 0)

# Decision variables
x_A = model.addVar(vtype=GRB.INTEGER, name="orders_A", lb=0)
x_B = model.addVar(vtype=GRB.INTEGER, name="orders_B", lb=0)
x_C = model.addVar(vtype=GRB.INTEGER, name="orders_C", lb=0)

y_A_regular = model.addVar(vtype=GRB.BINARY, name="y_A_regular")
y_A_express = model.addVar(vtype=GRB.BINARY, name="y_A_express")
y_B_regular = model.addVar(vtype=GRB.BINARY, name="y_B_regular")
y_B_express = model.addVar(vtype=GRB.BINARY, name="y_B_express")
y_C_regular = model.addVar(vtype=GRB.BINARY, name="y_C_regular")
y_C_express = model.addVar(vtype=GRB.BINARY, name="y_C_express")

# Total chairs from each manufacturer
chairs_A = chairs_per_order_A * x_A
chairs_B = chairs_per_order_B * x_B
chairs_C = chairs_per_order_C * x_C

# Objective: minimize total cost
model.setObjective(
    cost_A * chairs_A + cost_B * chairs_B + cost_C * chairs_C +
    fixed_fee_A_regular * y_A_regular + fixed_fee_A_express * y_A_express +
    fixed_fee_B_regular * y_B_regular + fixed_fee_B_express * y_B_express +
    fixed_fee_C_regular * y_C_regular + fixed_fee_C_express * y_C_express,
    GRB.MINIMIZE
)

# Constraints
model.addConstr(chairs_A + chairs_B + chairs_C >= min_total, "MinChairs")
model.addConstr(chairs_A + chairs_B + chairs_C <= max_total, "MaxChairs")

# Channel exclusivity for each manufacturer
model.addConstr(y_A_regular + y_A_express <= 1, "ChannelA")
model.addConstr(y_B_regular + y_B_express <= 1, "ChannelB")
model.addConstr(y_C_regular + y_C_express <= 1, "ChannelC")

# Weekly order budget
model.addConstr(
    y_A_regular + y_A_express +
    y_B_regular + y_B_express +
    y_C_regular + y_C_express <= weekly_order_budget,
    "WeeklyBudget"
)

# Link y variables to x variables
M = max_total + 1
model.addConstr(x_A <= M * (y_A_regular + y_A_express), "LinkA1")
model.addConstr(x_A >= (y_A_regular + y_A_express), "LinkA2")
model.addConstr(x_B <= M * (y_B_regular + y_B_express), "LinkB1")
model.addConstr(x_B >= (y_B_regular + y_B_express), "LinkB2")
model.addConstr(x_C <= M * (y_C_regular + y_C_express), "LinkC1")
model.addConstr(x_C >= (y_C_regular + y_C_express), "LinkC2")

# Dependency: if ordering from A, must order at least min_chairs_B_if_A chairs from B
model.addConstr(chairs_B >= min_chairs_B_if_A * (y_A_regular + y_A_express), "DepAB")

# Dependency: if ordering from B, must also order from C
model.addConstr((y_B_regular + y_B_express) <= (y_C_regular + y_C_express), "DepBC")

# Solve
model.optimize()

# Output result
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
