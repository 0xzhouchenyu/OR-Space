import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    max_children = int(params["max_children_trip"])
    min_children = int(params["min_children_trip"])
    max_distinct_children = int(params["max_distinct_children_trip"])
    total_cost_budget = params["total_cost_budget"]
    bonus_saving = params["bonus_saving"]
    min_bob_days = int(params["min_bob_days"])
    
    # Read table_1 for children and costs
    children = []
    costs = {}
    constraints = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["Child"].strip()
            cost = int(row["Cost"].strip())
            constraint = row["Relationship_Constraint"].strip()
            children.append(name)
            costs[name] = cost
            constraints[name] = constraint
    
    # Create the optimization model
    model = gp.Model("TwoDayFamilyTrip")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    x = {child: {day: model.addVar(vtype=GRB.BINARY, name=f"x_{child}_day{day}") for day in [1, 2]} for child in children}
    y = {child: model.addVar(vtype=GRB.BINARY, name=f"y_{child}_both_days") for child in children}
    
    # Objective: minimize total cost minus bonus savings
    total_cost = gp.quicksum(costs[child] * (x[child][1] + x[child][2]) for child in children)
    total_bonus = gp.quicksum(bonus_saving * y[child] for child in children)
    model.setObjective(total_cost - total_bonus, GRB.MINIMIZE)
    
    # Constraints
    # Daily min/max children constraints
    for day in [1, 2]:
        model.addConstr(gp.quicksum(x[child][day] for child in children) >= min_children, f"MinChildren_day{day}")
        model.addConstr(gp.quicksum(x[child][day] for child in children) <= max_children, f"MaxChildren_day{day}")
    
    # Max distinct children over both days
    model.addConstr(gp.quicksum(gp.max_(x[child][1], x[child][2]) for child in children) <= max_distinct_children, "MaxDistinctChildren")
    
    # Total cost budget
    model.addConstr(total_cost - total_bonus <= total_cost_budget, "TotalCostBudget")
    
    # Bob must attend at least min_bob_days
    model.addConstr(x["Bob"][1] + x["Bob"][2] >= min_bob_days, "MinBobDays")
    
    # Relationship constraints
    for day in [1, 2]:
        model.addConstr(x["Alice"][day] + x["Diana"][day] <= 1, f"AliceDianaConflict_day{day}")
        model.addConstr(x["Bob"][day] + x["Charlie"][day] <= 1, f"BobCharlieConflict_day{day}")
        model.addConstr(x["Charlie"][day] <= x["Diana"][day], f"CharlieRequiresDiana_day{day}")
        model.addConstr(x["Diana"][day] <= x["Ella"][day], f"DianaRequiresElla_day{day}")
    
    # Availability constraints
    model.addConstr(x["Charlie"][1] == 0, "CharlieDay1Unavailable")
    model.addConstr(x["Diana"][1] == 0, "DianaDay1Unavailable")
    model.addConstr(x["Alice"][2] == 0, "AliceDay2Unavailable")
    
    # Bonus savings indicator
    for child in children:
        model.addConstr(y[child] <= x[child][1], f"BonusIndicator_day1_{child}")
        model.addConstr(y[child] <= x[child][2], f"BonusIndicator_day2_{child}")
        model.addConstr(y[child] >= x[child][1] + x[child][2] - 1, f"BonusIndicator_both_days_{child}")
    
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
