import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_parameters

def main():
    # Load parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    # Extract parameters
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_hours = params['machine_working_time']
    machine_working_time_minutes = machine_working_time_hours * 60
    ratio_A = 5
    ratio_B = 2
    max_overtime_minutes = params['max_overtime_hours'] * 60
    overtime_penalty_per_minute = params['overtime_penalty_per_hour'] / 60
    overtime_review_threshold_minutes = params['overtime_review_threshold_hours'] * 60
    overtime_review_fee = params['overtime_review_fee']
    senior_batch_threshold = params['product_A_senior_batch_threshold']
    senior_batch_fee = params['product_A_senior_batch_fee']
    
    # Create model
    model = gp.Model("Revised_Product_Mix")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    A = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_A")
    B = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_B")
    overtime = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Overtime")
    senior_fee_trigger = model.addVar(vtype=GRB.BINARY, name="Senior_Fee_Trigger")
    overtime_fee_trigger = model.addVar(vtype=GRB.BINARY, name="Overtime_Fee_Trigger")
    
    # Objective function: maximize profit
    model.setObjective(
        profit_A * A + profit_B * B 
        - senior_batch_fee * senior_fee_trigger 
        - overtime_penalty_per_minute * overtime 
        - overtime_review_fee * overtime_fee_trigger,
        GRB.MAXIMIZE
    )
    
    # Constraints
    # Machine working time + overtime
    model.addConstr(assembly_time_A * A + assembly_time_B * B <= machine_working_time_minutes + overtime, "Machine_Time")
    
    # Production ratio: B >= (2/5) * A
    model.addConstr(ratio_B * A - ratio_A * B <= 0, "Production_Ratio")
    
    # Senior assembler fee trigger
    model.addConstr(A - senior_batch_threshold <= senior_fee_trigger * 1e6, "Senior_Fee_Trigger_Upper")
    model.addConstr(A - senior_batch_threshold >= 1 - senior_fee_trigger * 1e6, "Senior_Fee_Trigger_Lower")
    
    # Overtime fee trigger
    model.addConstr(overtime - overtime_review_threshold_minutes <= overtime_fee_trigger * 1e6, "Overtime_Fee_Trigger_Upper")
    model.addConstr(overtime - overtime_review_threshold_minutes >= 1 - overtime_fee_trigger * 1e6, "Overtime_Fee_Trigger_Lower")
    
    # Overtime limit
    model.addConstr(overtime <= max_overtime_minutes, "Overtime_Limit")
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal:.1f}")

if __name__ == "__main__":
    main()
