import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_coverage_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    
    return areas, coverage

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load data
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    distance_limit = params['distance_limit']
    small_cost = params['small_cost']
    large_cost = params['large_cost']
    small_cap_areas = int(params['small_cap_areas'])
    max_large_stores = int(params['max_large_stores'])
    min_neighborhood_counters = int(params['minimum_neighborhood_counters'])
    small_store_counter_credit = int(params['small_store_counter_credit'])
    
    # Create the optimization model
    model = gp.Model("RevisedChainStores")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_small = {j: model.addVar(vtype=GRB.BINARY, name=f"x_small_{j}") for j in areas}
    x_large = {j: model.addVar(vtype=GRB.BINARY, name=f"x_large_{j}") for j in areas}
    
    # Objective: Minimize total cost
    model.setObjective(
        gp.quicksum(small_cost * x_small[j] for j in areas) +
        gp.quicksum(large_cost * x_large[j] for j in areas),
        GRB.MINIMIZE
    )
    
    # Constraints: Each area must be covered by at least one store
    for i in areas:
        covering_stores = [j for j in areas if i in coverage.get(j, set())]
        model.addConstr(
            gp.quicksum(x_small[j] for j in covering_stores) +
            gp.quicksum(x_large[j] for j in covering_stores) >= 1,
            name=f"Cover_{i}"
        )
    
    # Constraint: Small-format stores can cover at most `small_cap_areas` areas
    for j in areas:
        model.addConstr(
            gp.quicksum(1 for i in coverage[j]) * x_small[j] <= small_cap_areas,
            name=f"SmallCap_{j}"
        )
    
    # Constraint: At least `min_neighborhood_counters` small-format stores
    model.addConstr(
        gp.quicksum(x_small[j] for j in areas) >= min_neighborhood_counters,
        name="MinSmallStores"
    )
    
    # Constraint: At most `max_large_stores` large-format stores
    model.addConstr(
        gp.quicksum(x_large[j] for j in areas) <= max_large_stores,
        name="MaxLargeStores"
    )
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
