import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Parse general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    # Extract parameters
    cost_a = params["cost_supplier_a"]
    cost_b = params["cost_supplier_b"]
    cost_c = params["cost_supplier_c"]
    size_a = int(params["order_size_supplier_a"])
    size_b = int(params["order_size_supplier_b"])
    size_c = int(params["order_size_supplier_c"])
    min_tables = int(params["min_tables_required"])
    max_tables = int(params["max_tables_allowed"])
    min_b_if_a = int(params["min_tables_supplier_b_if_a"])
    b_requires_c = int(params["supplier_b_requires_c"])
    max_free_orders_c = int(params["max_free_orders_c"])
    penalty_per_extra_c = params["penalty_per_extra_order_c"]
    bc_shared_trigger = int(params["supplier_bc_shared_inbound_trigger"])
    bc_shared_fee = params["supplier_bc_shared_inbound_fee"]
    
    M = 1000  # Big-M constant
    
    # Create model
    model = gp.Model("Revised_Restaurant_Tables")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_a = model.addVar(vtype=GRB.INTEGER, name="orders_a", lb=0)
    x_b = model.addVar(vtype=GRB.INTEGER, name="orders_b", lb=0)
    x_c = model.addVar(vtype=GRB.INTEGER, name="orders_c", lb=0)
    
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")  # 1 if ordering from A
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")  # 1 if ordering from B
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")  # 1 if ordering from C
    
    # Auxiliary variable for penalty on Supplier C orders
    extra_orders_c = model.addVar(vtype=GRB.INTEGER, name="extra_orders_c", lb=0)
    
    # Objective: minimize total cost
    model.setObjective(
        cost_a * size_a * x_a +
        cost_b * size_b * x_b +
        cost_c * size_c * x_c +
        penalty_per_extra_c * extra_orders_c +
        (bc_shared_fee if bc_shared_trigger and y_b.x + y_c.x >= 2 else 0),
        GRB.MINIMIZE
    )
    
    # Constraints
    # Total tables constraints
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c >= min_tables, "min_tables")
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c <= max_tables, "max_tables")
    
    # Link binary variables to order variables
    model.addConstr(x_a <= M * y_a, "link_a")
    model.addConstr(x_a >= y_a, "link_a_min")
    model.addConstr(x_b <= M * y_b, "link_b")
    model.addConstr(x_b >= y_b, "link_b_min")
    model.addConstr(x_c <= M * y_c, "link_c")
    model.addConstr(x_c >= y_c, "link_c_min")
    
    # If ordering from A, then tables from B >= 30
    model.addConstr(size_b * x_b >= min_b_if_a * y_a, "min_b_if_a")
    
    # If ordering from B, must order from C
    if b_requires_c:
        model.addConstr(y_c >= y_b, "b_requires_c")
    
    # Penalty for extra orders from Supplier C
    model.addConstr(extra_orders_c >= x_c - max_free_orders_c, "extra_orders_c")
    
    # Shared inbound desk fee for Supplier B and C
    if bc_shared_trigger:
        model.addConstr(y_b + y_c <= 2, "shared_inbound_trigger")
    
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
