import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read costs from table_1.csv
    costs = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row["Child"].strip()
            costs[child] = {
                "budget": float(row["Cost_budget"].strip()),
                "balanced": float(row["Cost_balanced"].strip()),
                "premium": float(row["Cost_premium"].strip())
            }
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    max_children = int(params["max_children"])
    min_children = int(params["min_children"])
    min_children_per_mode = int(params["min_children_per_mode"])
    fairness_penalty = params["fairness_penalty"]
    max_total_cost = params["max_total_cost"]
    
    children = list(costs.keys())
    
    # Create model
    model = gp.Model("ZhangFamilyTrip")
    model.setParam("OutputFlag", 0)
    
    # Decision variables
    x = {child: model.addVar(vtype=GRB.BINARY, name=f"x_{child}") for child in children}
    modes = ["budget", "balanced", "premium"]
    y = {mode: model.addVar(vtype=GRB.BINARY, name=f"y_{mode}") for mode in modes}
    z_max = model.addVar(vtype=GRB.CONTINUOUS, name="z_max")
    z_min = model.addVar(vtype=GRB.CONTINUOUS, name="z_min")
    
    # Objective: minimize total cost + fairness penalty
    total_cost = gp.quicksum(
        costs[child][mode] * x[child] * y[mode]
        for child in children for mode in modes
    )
    fairness_cost = fairness_penalty * (z_max - z_min)
    model.setObjective(total_cost + fairness_cost, GRB.MINIMIZE)
    
    # Constraints
    # Ginny must go
    model.addConstr(x["Ginny"] == 1, "Ginny_must_go")
    
    # At most max_children
    model.addConstr(gp.quicksum(x[child] for child in children) <= max_children, "Max_children")
    
    # At least min_children
    model.addConstr(gp.quicksum(x[child] for child in children) >= min_children, "Min_children")
    
    # Mode selection constraints
    model.addConstr(gp.quicksum(y[mode] for mode in modes) == 1, "One_mode")
    model.addConstr(
        y["balanced"] * min_children_per_mode <= gp.quicksum(x[child] for child in children),
        "Balanced_min_children"
    )
    model.addConstr(
        y["premium"] * min_children_per_mode <= gp.quicksum(x[child] for child in children),
        "Premium_min_children"
    )
    
    # Compatibility constraints
    model.addConstr(x["Harry"] + x["Fred"] <= 1, "Harry_no_Fred")
    model.addConstr(x["Harry"] + x["George"] <= 1, "Harry_no_George")
    model.addConstr(x["George"] <= x["Fred"], "George_requires_Fred")
    model.addConstr(x["George"] <= x["Hermione"], "George_requires_Hermione")
    
    # Fairness constraints
    for mode in modes:
        model.addConstr(
            z_max >= gp.quicksum(costs[child][mode] * x[child] for child in children) * y[mode],
            f"Fairness_max_{mode}"
        )
        model.addConstr(
            z_min <= gp.quicksum(costs[child][mode] * x[child] for child in children) * y[mode],
            f"Fairness_min_{mode}"
        )
    
    # Total cost constraint
    model.addConstr(total_cost <= max_total_cost, "Max_total_cost")
    
    # Solve
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
