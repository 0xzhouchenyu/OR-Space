import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    def get_data_path(filename):
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

    table_1_path = get_data_path('table_1.csv')
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })

    params_path = get_data_path('general_parameters.csv')
    params = {}
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    std_widths = [params['standard_width_1'], params['standard_width_2']]
    pattern_setup_penalty = params['pattern_setup_penalty']
    wide_roll_threshold_width = params['wide_roll_threshold_width']
    wide_roll_extra_setup_penalty = params['wide_roll_extra_setup_penalty']

    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    total_required_area = sum(w * l for w, l in zip(widths, lengths))

    # Generate cutting patterns
    patterns_by_std_width = {}
    for idx, sw in enumerate(std_widths):
        patterns = []
        def build_pattern(index, current_pattern, current_sum):
            if index == len(widths):
                if any(c > 0 for c in current_pattern):
                    patterns.append(current_pattern)
                return
            max_count = int(math.floor((sw - current_sum + 1e-7) / widths[index]))
            for count in range(max_count + 1):
                build_pattern(index + 1, current_pattern + [count], current_sum + count * widths[index])
        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {'sw': sw, 'patterns': patterns}

    # Build optimization model
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)

    x_vars = {}
    for idx, data in patterns_by_std_width.items():
        for i, p in enumerate(data['patterns']):
            x_vars[(idx, i)] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{idx}_{i}")

    # Objective: Minimize total area used + penalties
    model.setObjective(
        gp.quicksum(
            data['sw'] * x_vars[(idx, i)] +
            pattern_setup_penalty +
            (wide_roll_extra_setup_penalty if data['sw'] >= wide_roll_threshold_width else 0)
            for idx, data in patterns_by_std_width.items()
            for i, p in enumerate(data['patterns'])
        ),
        GRB.MINIMIZE
    )

    # Constraints: Satisfy length requirements for each order width
    for j in range(len(widths)):
        model.addConstr(
            gp.quicksum(
                p[j] * x_vars[(idx, i)]
                for idx, data in patterns_by_std_width.items()
                for i, p in enumerate(data['patterns'])
            ) >= lengths[j]
        )

    # Solve model
    model.optimize()

    # Calculate waste
    total_area_used = model.objVal
    waste = total_area_used - total_required_area

    print(f"FINAL_OBJ_VALUE: {round(waste, 4)}")

if __name__ == "__main__":
    solve()
