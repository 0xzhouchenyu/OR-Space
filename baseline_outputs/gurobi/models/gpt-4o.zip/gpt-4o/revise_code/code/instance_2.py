import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_parameters

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
a1 = int(params["a1"])
a2 = int(params["a2"])
training_capacity = params["training_capacity_per_jet"]
dual_use_efficiency = params["dual_use_training_efficiency"]
training_intensity_cap = params["training_intensity_cap"]
combat_min_year2 = int(params["combat_jet_min_year2"])
combat_weight = params["combat_weight"]
training_weight = params["training_weight"]

# Model
model = gp.Model()
model.setParam("OutputFlag", 0)

# Decision variables
x1_train = model.addVar(vtype=GRB.INTEGER, name="x1_train")  # Year 1 training-only jets
x1_dual = model.addVar(vtype=GRB.INTEGER, name="x1_dual")    # Year 1 dual-use jets
x1_combat = model.addVar(vtype=GRB.INTEGER, name="x1_combat")  # Year 1 combat-only jets

x2_train = model.addVar(vtype=GRB.INTEGER, name="x2_train")  # Year 2 training-only jets
x2_dual = model.addVar(vtype=GRB.INTEGER, name="x2_dual")    # Year 2 dual-use jets
x2_combat = model.addVar(vtype=GRB.INTEGER, name="x2_combat")  # Year 2 combat-only jets

# Constraints
# Year 1 total jets
model.addConstr(x1_train + x1_dual + x1_combat == a1, "year1_total")
# Year 2 total jets
model.addConstr(x2_train + x2_dual + x2_combat == a2 + x1_combat + x1_dual, "year2_total")
# Training intensity cap
model.addConstr(x1_train + x1_dual <= training_intensity_cap * a1, "year1_training_cap")
model.addConstr(x2_train + x2_dual <= training_intensity_cap * (a2 + x1_combat + x1_dual), "year2_training_cap")
# Combat minimum in year 2
model.addConstr(x2_combat + x2_dual >= combat_min_year2, "year2_combat_min")

# Objective: Maximize weighted sum of trained pilots and combat jets
trained_pilots = training_capacity * (x1_train + dual_use_efficiency * x1_dual +
                                      x2_train + dual_use_efficiency * x2_dual)
combat_jets_year2 = x2_combat + x2_dual
objective = training_weight * trained_pilots + combat_weight * combat_jets_year2
model.setObjective(objective, GRB.MAXIMIZE)

# Solve
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
