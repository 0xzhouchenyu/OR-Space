import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    data = {}
    filepath = os.path.join(base_dir, "table_1_7.csv")
    with open(filepath, "r") as f:
        reader = csv.reader(f)
        for row in reader:
            data.setdefault("table", []).append(row)
    general_params_path = os.path.join(base_dir, "general_parameters.csv")
    with open(general_params_path, "r") as f:
        reader = csv.reader(f)
        for row in reader:
            data.setdefault("general_params", []).append(row)
    return data

def main():
    # Load data
    data = load_data()
    
    # Extract parameters
    raw_cost = [2.00, 1.50, 1.00]
    proc_fee = [0.50, 0.40, 0.30]
    sell_price = [3.40, 2.85, 2.25]
    limits = [2000, 2500, 1200]
    setup_cost = [300, 500, 200]
    shared_wrapper_trigger = 1
    shared_wrapper_fee = 300
    
    # Create model
    model = gp.Model("CandyFactory")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(3, 3, lb=0, name="x")  # x[i, j]: amount of raw material i in brand j
    y = model.addVars(3, lb=0, name="y")     # y[j]: total production of brand j
    z = model.addVars(3, vtype=GRB.BINARY, name="z")  # z[j]: binary variable for brand j production
    w = model.addVar(vtype=GRB.BINARY, name="w")      # w: binary variable for shared wrapper cost
    
    # Objective: maximize profit
    revenue = gp.quicksum(sell_price[j] * y[j] for j in range(3))
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in range(3))
    setup_cost_total = gp.quicksum(setup_cost[j] * z[j] for j in range(3))
    shared_wrapper_cost = shared_wrapper_fee * w
    model.setObjective(revenue - material_cost - processing_cost - setup_cost_total - shared_wrapper_cost, GRB.MAXIMIZE)
    
    # Constraints
    # Raw material supply constraints
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= limits[i])
    
    # Composition constraints
    model.addConstr(x[0, 0] >= 0.60 * y[0])  # RM A >= 60% of Brand A
    model.addConstr(x[0, 1] >= 0.15 * y[1])  # RM A >= 15% of Brand B
    model.addConstr(x[2, 0] <= 0.20 * y[0])  # RM C <= 20% of Brand A
    model.addConstr(x[2, 1] <= 0.60 * y[1])  # RM C <= 60% of Brand B
    model.addConstr(x[2, 2] <= 0.50 * y[2])  # RM C <= 50% of Brand C
    
    # Link production and raw material usage
    for j in range(3):
        model.addConstr(gp.quicksum(x[i, j] for i in range(3)) == y[j])
    
    # Link production and setup cost
    for j in range(3):
        model.addConstr(y[j] <= z[j] * GRB.INFINITY)
        model.addConstr(y[j] >= z[j] * 1e-6)  # To ensure z[j] = 1 if y[j] > 0
    
    # Shared wrapper cost constraint
    model.addConstr(w >= z[0] + z[1] - 1)  # w = 1 if both A and B are produced
    
    # Solve model
    model.optimize()
    
    # Output result
    print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")

if __name__ == "__main__":
    main()
