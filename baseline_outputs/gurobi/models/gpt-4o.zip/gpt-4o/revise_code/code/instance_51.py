import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Utility functions
def load_demand(filepath):
    """Load nurse demand per time period from CSV."""
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand

def load_parameters(filepath):
    """Load general parameters from CSV."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
demand = load_demand(os.path.join(data_dir, "table_1.csv"))
params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
shift_start_times = params['shift_start_times'].split(';')
shift_duration = int(params['shift_duration'])  # 8 hours
regular_pay = float(params['regular_nurse_pay'])  # 10 yuan/hour
contract_pay = float(params['contract_nurse_pay'])  # 15 yuan/hour
outsourced_regular_start_index = int(params['outsourced_regular_start_index'])  # 10:00 shift
banned_contract_start_index = int(params['banned_contract_start_index'])  # 22:00 shift
max_total_contract_starts = int(params['max_total_contract_starts'])  # 20 nurses/day
min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])  # 8 nurses/period
daytime_period_indices = list(map(int, params['daytime_period_indices'].split(';')))  # 6:00-22:00

num_periods = len(demand)  # 6 periods, each 4 hours
periods_per_shift = shift_duration // 4  # 2 periods per shift

# Create model
model = gp.Model("NurseScheduling")
model.setParam('OutputFlag', 0)

# Decision variables
x = [model.addVar(vtype=GRB.INTEGER, name=f"x_{j}") for j in range(num_periods)]  # Regular nurses
y = [model.addVar(vtype=GRB.INTEGER, name=f"y_{j}") for j in range(num_periods)]  # Contract nurses

# Objective: minimize total cost
model.setObjective(
    gp.quicksum((regular_pay * shift_duration) * x[j] + (contract_pay * shift_duration) * y[j] for j in range(num_periods)),
    GRB.MINIMIZE
)

# Coverage constraints: for each time period i, sum of nurses from shifts that cover period i >= demand[i]
for i in range(num_periods):
    covering_shifts = []
    for j in range(num_periods):
        # Shift j covers periods j and (j+1) % num_periods
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i], f"Demand_period_{i}")

# Contract nurse restrictions
model.addConstr(y[banned_contract_start_index] == 0, "No_contract_22:00")
model.addConstr(gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts, "Max_contract_starts")

# Regular nurse restrictions
model.addConstr(x[outsourced_regular_start_index] == 0, "No_regular_10:00")
for i in daytime_period_indices:
    covering_shifts = []
    for j in range(num_periods):
        # Shift j covers periods j and (j+1) % num_periods
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(gp.quicksum(x[j] for j in covering_shifts) >= min_regular_daytime_coverage, f"Min_regular_daytime_{i}")

# Solve the model
model.optimize()

# Output the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
