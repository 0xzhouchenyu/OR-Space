import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
def load_table_1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    weeks = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })
    return weeks

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

# Paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load data
weeks_data = load_table_1(data_dir)
params = load_general_parameters(data_dir)

# Parameters
storage_cost = params['storage_cost_per_thousand_boxes']
fixed_setup_cost = params['fixed_setup_cost']
week2_push_threshold = params['week2_push_threshold']
week3_capacity_loss = params['week3_capacity_loss_after_week2_push']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']
n_weeks = len(weeks_data)

# Model
model = gp.Model("Beverage_Production_Planning")
model.setParam('OutputFlag', 0)

# Decision variables
x = [model.addVar(lb=0, ub=weeks_data[t]['capacity'], name=f"x_{t+1}") for t in range(n_weeks)]
s = [model.addVar(lb=0, name=f"s_{t+1}") for t in range(n_weeks)]
z_setup = [model.addVar(vtype=GRB.BINARY, name=f"z_setup_{t+1}") for t in range(n_weeks)]
z_microclean = model.addVar(vtype=GRB.BINARY, name="z_microclean")

# Objective: minimize total production cost + storage cost + fixed setup cost + micro-clean cost
model.setObjective(
    gp.quicksum(weeks_data[t]['cost'] * x[t] for t in range(n_weeks)) +
    gp.quicksum(storage_cost * s[t] for t in range(n_weeks)) +
    gp.quicksum(fixed_setup_cost * z_setup[t] for t in range(n_weeks)) +
    week2_microclean_fee * z_microclean,
    GRB.MINIMIZE
)

# Constraints: inventory balance
for t in range(n_weeks):
    if t == 0:
        model.addConstr(x[t] - s[t] == weeks_data[t]['demand'], f"balance_week_{t+1}")
    else:
        model.addConstr(s[t-1] + x[t] - s[t] == weeks_data[t]['demand'], f"balance_week_{t+1}")

# Constraints: setup cost activation
for t in range(n_weeks):
    model.addConstr(x[t] <= weeks_data[t]['capacity'] * z_setup[t], f"setup_activation_week_{t+1}")

# Week 2 micro-clean constraint
model.addConstr(x[1] <= week2_microclean_threshold + (weeks_data[1]['capacity'] * (1 - z_microclean)), "microclean_trigger")

# Week 3 capacity adjustment if Week 2 exceeds push threshold
model.addConstr(x[2] <= weeks_data[2]['capacity'] - week3_capacity_loss * (x[1] > week2_push_threshold), "week3_capacity_adjustment")

# Solve
model.optimize()

# Output result
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
