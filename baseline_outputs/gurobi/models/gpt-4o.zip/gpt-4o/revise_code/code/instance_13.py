import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    profit_corn = params["profit_per_acre_corn"]
    profit_wheat = params["profit_per_acre_wheat"]
    profit_soybeans = params["profit_per_acre_soybeans"]
    profit_sorghum = params["profit_per_acre_sorghum"]
    total_area = params["total_farm_area"]
    corn_wheat_ratio = params["corn_wheat_ratio"]
    soybeans_sorghum_ratio = params["soybeans_sorghum_ratio"]
    wheat_sorghum_ratio = params["wheat_sorghum_ratio"]
    
    # Create model
    model = gp.Model("Farm_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    corn = model.addVar(lb=0, name="corn")
    wheat = model.addVar(lb=0, name="wheat")
    soybeans = model.addVar(lb=0, name="soybeans")
    sorghum = model.addVar(lb=0, name="sorghum")
    corn_active = model.addVar(vtype=GRB.BINARY, name="corn_active")
    soybeans_active = model.addVar(vtype=GRB.BINARY, name="soybeans_active")
    
    # Objective: maximize profit
    model.setObjective(
        profit_corn * corn + profit_wheat * wheat + profit_soybeans * soybeans + profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )
    
    # Constraints
    # Total area
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")
    
    # Corn >= 2 * wheat
    model.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio")
    
    # Soybeans >= 0.5 * sorghum
    model.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio")
    
    # Wheat = 3 * sorghum
    model.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_ratio")
    
    # Corn and soybeans mutual exclusion
    model.addConstr(corn_active + soybeans_active <= 1, "mutual_exclusion")
    model.addConstr(corn <= total_area * corn_active, "corn_active_constraint")
    model.addConstr(soybeans <= total_area * soybeans_active, "soybeans_active_constraint")
    
    # Minimum 20 acres of corn
    model.addConstr(corn >= 20, "min_corn")
    
    # Solve model
    model.optimize()
    
    # Output result
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
