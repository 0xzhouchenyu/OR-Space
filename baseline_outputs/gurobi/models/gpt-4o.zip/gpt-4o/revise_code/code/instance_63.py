import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Parameters
produce = params["produce_to_transport"]
horse_poll = params["horse_pollution_per_trip"]
bike_poll = params["bicycle_pollution_per_trip"]
cart_poll = params["handcart_pollution_per_trip"]
max_poll = params["max_total_pollution"]
min_horse = params["min_horse_trips"]
horse_cap = params["horse_capacity_per_trip"]
bike_cap = params["bicycle_capacity_per_trip"]
cart_cap = params["handcart_capacity_per_trip"]
min_produce = params["min_total_produce"]
horse_cost = params["horse_cost_per_trip"]
bike_cost = params["bicycle_cost_per_trip"]
cart_cost = params["handcart_cost_per_trip"]
horse_fixed = params["horse_fixed_cost"]
bike_fixed = params["bicycle_fixed_cost"]
cart_fixed = params["handcart_fixed_cost"]
poll_penalty = params["pollution_penalty_per_unit"]
poll_threshold = params["horse_pollution_permit_threshold"]
permit_fee = params["horse_pollution_permit_fee"]

# Model
model = gp.Model("FarmTransport")
model.setParam("OutputFlag", 0)

# Decision variables
x_horse = model.addVar(vtype=GRB.INTEGER, name="horse_trips")
x_bike = model.addVar(vtype=GRB.INTEGER, name="bike_trips")
x_cart = model.addVar(vtype=GRB.INTEGER, name="cart_trips")
y_bike = model.addVar(vtype=GRB.BINARY, name="choose_bike")
z_permit = model.addVar(vtype=GRB.BINARY, name="permit_fee_trigger")

# Constraints
# Transport at least the required produce
model.addConstr(horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce, "produce_constraint")

# Pollution constraint
total_pollution = horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart
model.addConstr(total_pollution <= max_poll, "pollution_constraint")

# Minimum horse trips
model.addConstr(x_horse >= min_horse, "min_horse_trips")

# Either bicycle or handcart, not both
M = 10000  # Big-M
model.addConstr(x_bike <= M * y_bike, "bike_constraint")
model.addConstr(x_cart <= M * (1 - y_bike), "cart_constraint")

# Permit fee trigger
model.addConstr(total_pollution - poll_threshold <= M * z_permit, "permit_trigger_upper")
model.addConstr(total_pollution - poll_threshold >= 1 - M * (1 - z_permit), "permit_trigger_lower")

# Objective: Minimize total cost
total_cost = (
    horse_cost * x_horse
    + bike_cost * x_bike
    + cart_cost * x_cart
    + horse_fixed * (x_horse > 0)
    + bike_fixed * (x_bike > 0)
    + cart_fixed * (x_cart > 0)
    + poll_penalty * total_pollution
    + permit_fee * z_permit
)
model.setObjective(total_cost, GRB.MINIMIZE)

# Solve
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
