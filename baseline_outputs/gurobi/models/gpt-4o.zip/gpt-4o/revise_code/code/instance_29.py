import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    demand_df = pd.read_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_4_3.csv"))
    supply_df = pd.read_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_4_4.csv"))
    params_df = pd.read_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv"))
    
    # Parse parameters
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])
    
    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem
        
    # Parse supply
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = float(row['Number_of_People'])
        suit = [int(x) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }
        
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]
    
    # Create model
    model = gp.Model("Revised_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(types, cities, specs, vtype=GRB.INTEGER, name="x")
    d2_minus = model.addVar(vtype=GRB.INTEGER, name="d2_minus")
    d2_plus = model.addVar(vtype=GRB.INTEGER, name="d2_plus")
    
    # Objective: Maximize dual-match placements
    dual_match = gp.quicksum(
        x[i, supply[i]['pref_city'], supply[i]['pref_spec']] 
        for i in types if supply[i]['pref_spec'] in supply[i]['suit']
    )
    model.setObjective(dual_match, GRB.MAXIMIZE)
    
    # Constraints
    # Supply constraints
    for i in types:
        model.addConstr(gp.quicksum(x[i, j, k] for j in cities for k in specs) <= supply[i]['num'])
    
    # Demand constraints
    for j in cities:
        for k in specs:
            model.addConstr(gp.quicksum(x[i, j, k] for i in types) >= demand[(j, k)])
    
    # Suitability constraints
    for i in types:
        for j in cities:
            for k in specs:
                if k not in supply[i]['suit']:
                    model.addConstr(x[i, j, k] == 0)
    
    # Priority 2 constraint
    p2_expr = gp.quicksum(x[i, j, supply[i]['pref_spec']] for i in types for j in cities)
    model.addConstr(p2_expr + d2_minus - d2_plus == p2_target)
    
    # Solve model
    model.optimize()
    
    # Output result
    print(f"FINAL_OBJ_VALUE: {int(model.objVal)}")

if __name__ == '__main__':
    solve()
