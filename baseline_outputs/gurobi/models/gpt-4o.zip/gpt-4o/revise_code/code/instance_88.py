import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load general parameters
def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
m1_liquid = params['machine_1_time_per_liquid_lot']
m2_liquid = params['machine_2_time_per_liquid_lot']
m1_solid = params['machine_1_time_per_solid_lot']
m2_solid = params['machine_2_time_per_solid_lot']

init_liquid = params['initial_liquid_inventory']
init_solid = params['initial_solid_inventory']

m1_avail = params['machine_1_available_time'] * 60
m2_avail = params['machine_2_available_time'] * 60

demand_liquid = params['forecast_liquid_demand']
demand_solid = params['forecast_solid_demand']

extended_extra_minutes = params['extended_extra_minutes']
labor_hours_per_machine_extended = params['labor_hours_per_machine_extended']
labor_budget_hours = params['labor_budget_hours']
extended_mode_penalty = params['extended_mode_penalty']
priority_reserve_lots = params['priority_reserve_lots']
excess_reserve_credit = params['excess_reserve_credit']

# Create model
model = gp.Model("Fertilizer_Production")
model.setParam('OutputFlag', 0)

# Decision variables
x_l = model.addVar(lb=0, name="x_liquid")  # Lots of liquid fertilizer produced
x_s = model.addVar(lb=0, name="x_solid")   # Lots of solid fertilizer produced
m1_extended = model.addVar(vtype=GRB.BINARY, name="m1_extended")  # Machine 1 extended mode
m2_extended = model.addVar(vtype=GRB.BINARY, name="m2_extended")  # Machine 2 extended mode

# Derived variables
end_liquid = init_liquid + x_l - demand_liquid
end_solid = init_solid + x_s - demand_solid

# Resilience score components
liquid_reserve_score = gp.min_(end_liquid, priority_reserve_lots) + \
                       gp.max_(0, end_liquid - priority_reserve_lots) * excess_reserve_credit
solid_reserve_score = gp.min_(end_solid, priority_reserve_lots) + \
                      gp.max_(0, end_solid - priority_reserve_lots) * excess_reserve_credit
extended_penalty = (m1_extended + m2_extended) * extended_mode_penalty

# Objective: maximize resilience score
model.setObjective(liquid_reserve_score + solid_reserve_score - extended_penalty, GRB.MAXIMIZE)

# Machine time constraints
model.addConstr(m1_liquid * x_l + m1_solid * x_s <= m1_avail + m1_extended * extended_extra_minutes, "Machine_1_Time")
model.addConstr(m2_liquid * x_l + m2_solid * x_s <= m2_avail + m2_extended * extended_extra_minutes, "Machine_2_Time")

# Skilled labor constraint
model.addConstr((m1_extended + m2_extended) * labor_hours_per_machine_extended <= labor_budget_hours, "Labor_Budget")

# Demand satisfaction constraints
model.addConstr(end_liquid >= 0, "Liquid_Demand_Satisfaction")
model.addConstr(end_solid >= 0, "Solid_Demand_Satisfaction")

# Solve the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal:.4f}")
