import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read property data
properties = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            "name": row["Property"],
            "income": float(row["Annual_Income"]),
            "cost": float(row["Cost"])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

# Extract parameters
budget = params["budget"]
scen_1_prob = params["scen_1_prob"]
scen_2_prob = params["scen_2_prob"]
scen_1_risky_multiplier = params["scen_1_risky_multiplier"]
scen_2_risky_multiplier = params["scen_2_risky_multiplier"]
total_risky_budget = params["total_risky_budget"]
per_property_risky_cap = params["per_property_risky_cap"]
max_risky_properties = int(params["max_risky_properties"])

# Create optimization model
model = gp.Model("RevisedRealEstateInvestment")
model.setParam("OutputFlag", 0)

# Decision variables
x = {p["name"]: model.addVar(vtype=GRB.BINARY, name=f"x_{p['name']}") for p in properties}
risky_fraction = {p["name"]: model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=per_property_risky_cap, name=f"risky_{p['name']}") for p in properties}
risky_indicator = {p["name"]: model.addVar(vtype=GRB.BINARY, name=f"risky_ind_{p['name']}") for p in properties}

# Objective: maximize expected annual income
model.setObjective(
    gp.quicksum(
        p["income"] * (1 - risky_fraction[p["name"]]) * x[p["name"]] +
        p["income"] * risky_fraction[p["name"]] * (
            scen_1_prob * scen_1_risky_multiplier +
            scen_2_prob * scen_2_risky_multiplier
        ) * x[p["name"]]
        for p in properties
    ),
    GRB.MAXIMIZE
)

# Budget constraint
model.addConstr(
    gp.quicksum(p["cost"] * x[p["name"]] for p in properties) <= budget,
    "BudgetConstraint"
)

# Risky exposure constraints
model.addConstr(
    gp.quicksum(p["cost"] * risky_indicator[p["name"]] for p in properties) <= total_risky_budget,
    "TotalRiskyBudget"
)
model.addConstr(
    gp.quicksum(risky_indicator[p["name"]] for p in properties) <= max_risky_properties,
    "MaxRiskyProperties"
)
for p in properties:
    model.addConstr(
        risky_fraction[p["name"]] <= risky_indicator[p["name"]],
        f"RiskyFractionIndicator_{p['name']}"
    )
    model.addConstr(
        risky_fraction[p["name"]] * p["cost"] <= per_property_risky_cap * p["cost"] * x[p["name"]],
        f"PerPropertyRiskyCap_{p['name']}"
    )

# Mutual exclusivity constraint
model.addConstr(
    x["Property_4"] + x["Property_3"] <= 1,
    "MutualExclusivity"
)

# Solve the model
model.optimize()

# Print the final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
