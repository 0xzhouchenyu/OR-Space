import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(data_path)
    
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = float(row['Value'])
    
    # Extract parameters
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = int(params['raw_bar_length'])
    setup_cost = params['setup_cost_per_pattern']
    max_patterns = int(params['max_distinct_patterns'])
    
    # Lengths of the steel bars
    len1 = 3
    len2 = 4
    len3 = 5
    
    # Generate all valid cutting patterns
    patterns = []
    for x in range(L // len1 + 1):
        for y in range(L // len2 + 1):
            for z in range(L // len3 + 1):
                if len1 * x + len2 * y + len3 * z <= L:
                    if x > 0 or y > 0 or z > 0:
                        patterns.append((x, y, z))
    
    # Create optimization model
    model = gp.Model("CuttingStock")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    vars = model.addVars(len(patterns), vtype=GRB.INTEGER, name="Pattern")
    use_pattern = model.addVars(len(patterns), vtype=GRB.BINARY, name="UsePattern")
    
    # Objective: minimize total waste
    total_waste = gp.quicksum(L * vars[i] for i in range(len(patterns))) - (len1 * q3 + len2 * q4 + len3 * q5)
    setup_waste = gp.quicksum(setup_cost * use_pattern[i] for i in range(len(patterns)))
    model.setObjective(total_waste + setup_waste, GRB.MINIMIZE)
    
    # Constraints: satisfy the demand for each type of steel bar
    model.addConstr(gp.quicksum(patterns[i][0] * vars[i] for i in range(len(patterns))) >= q3, "Demand3m")
    model.addConstr(gp.quicksum(patterns[i][1] * vars[i] for i in range(len(patterns))) >= q4, "Demand4m")
    model.addConstr(gp.quicksum(patterns[i][2] * vars[i] for i in range(len(patterns))) >= q5, "Demand5m")
    
    # Constraint: link use_pattern with vars
    for i in range(len(patterns)):
        model.addConstr(vars[i] <= use_pattern[i] * GRB.INFINITY, f"Link_{i}")
    
    # Constraint: limit the number of distinct patterns
    model.addConstr(gp.quicksum(use_pattern[i] for i in range(len(patterns))) <= max_patterns, "MaxPatterns")
    
    # Solve the model
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
