import os
import gurobipy as gp
from gurobipy import GRB
import csv
import math

# Utility function to load CSV data
def load_csv_data(filepath):
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# General parameters
params_data = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
params = {row['Parameter_Name']: float(row['Value']) for row in params_data}
cost_per_km = params['cost_per_km']
truck_capacity = params['truck_capacity']
adriatic_pool_shortage_trigger = params['adriatic_pool_shortage_trigger']
adriatic_pool_recovery_fee = params['adriatic_pool_recovery_fee']

# Warehouses and supply
warehouses_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
warehouses = [row['Warehouse'] for row in warehouses_data]
supply = {row['Warehouse']: int(row['Empty_Containers']) for row in warehouses_data}

# Ports and demand
ports_data = load_csv_data(os.path.join(data_dir, 'table_2.csv'))
ports = [row['Port'] for row in ports_data]
demand = {row['Port']: int(row['Container_Demand']) for row in ports_data}

# Distances
distance_data = load_csv_data(os.path.join(data_dir, 'table_3.csv'))
distance = {}
for row in distance_data:
    wh = row['Warehouse']
    for port in ports:
        distance[(wh, port)] = float(row[port])

# Shortage penalties
shortage_data = load_csv_data(os.path.join(data_dir, 'shortage_penalty.csv'))
shortage_penalty = {row['Port']: float(row['Shortage_Charge']) for row in shortage_data}
grace_containers = {row['Port']: int(row['Grace_Containers']) for row in shortage_data}
recovery_fee = {row['Port']: float(row['Recovery_Fee']) for row in shortage_data}

# Model
model = gp.Model("Revised_Container_Transportation")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVars(warehouses, ports, vtype=GRB.INTEGER, name="x")  # Containers shipped
shortage = model.addVars(ports, vtype=GRB.INTEGER, name="shortage")  # Shortage at each port
adriatic_recovery = model.addVar(vtype=GRB.BINARY, name="adriatic_recovery")  # Adriatic recovery desk

# Objective: Minimize total cost
transport_cost = gp.quicksum(x[i, j] * distance[i, j] * cost_per_km for i in warehouses for j in ports)
shortage_cost = gp.quicksum(shortage[j] * shortage_penalty[j] for j in ports)
recovery_cost = gp.quicksum((shortage[j] > grace_containers[j]) * recovery_fee[j] for j in ports)
adriatic_cost = adriatic_recovery * adriatic_pool_recovery_fee
model.setObjective(transport_cost + shortage_cost + recovery_cost + adriatic_cost, GRB.MINIMIZE)

# Constraints
# Supply constraints
model.addConstrs((gp.quicksum(x[i, j] for j in ports) <= supply[i] for i in warehouses), name="supply")

# Demand constraints
model.addConstrs((gp.quicksum(x[i, j] for i in warehouses) + shortage[j] >= demand[j] for j in ports), name="demand")

# Shortage non-negativity
model.addConstrs((shortage[j] >= 0 for j in ports), name="shortage_nonnegativity")

# Adriatic recovery desk trigger
adriatic_ports = ['Venice', 'Ancona', 'Bari']
model.addConstr(gp.quicksum(shortage[j] for j in adriatic_ports) >= adriatic_pool_shortage_trigger * adriatic_recovery, name="adriatic_trigger")

# Solve
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
