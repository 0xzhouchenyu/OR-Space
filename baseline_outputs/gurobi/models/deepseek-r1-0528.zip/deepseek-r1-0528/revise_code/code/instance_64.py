import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load candidate data
    candidates = []
    cand_data = {}
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cand = row['Candidate'].strip()
            salary = int(row['Salary'].strip())
            skill = int(row['Skill_Level'].strip())
            pm_exp = int(row['Project_Management_Experience'].strip())
            candidates.append(cand)
            cand_data[cand] = {'salary': salary, 'skill': skill, 'pm_exp': pm_exp}
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    
    # Extract parameters
    budget = params['company_budget']
    max_employees = int(params['max_employees'])
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_gj = int(params['max_one_candidate_g_j'])
    lead_premium = params['lead_premium']
    min_leads = int(params['min_leads'])
    mentor_bonus = params['mentor_bonus']
    max_pairs = int(params['max_pairs'])
    
    # Create model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(candidates, vtype=GRB.BINARY, name="x")  # Hire candidate
    l = model.addVars(candidates, vtype=GRB.BINARY, name="l")  # Assign as Lead
    p = model.addVar(vtype=GRB.INTEGER, lb=0, name="p")        # Number of mentorship pairs
    
    # Objective: minimize net cost = base salaries + lead premiums - mentorship bonus
    base_salaries = gp.quicksum(cand_data[c]['salary'] * x[c] for c in candidates)
    lead_costs = gp.quicksum(lead_premium * l[c] for c in candidates)
    mentorship_savings = mentor_bonus * p
    model.setObjective(base_salaries + lead_costs - mentorship_savings, GRB.MINIMIZE)
    
    # Constraints
    ## Budget
    model.addConstr(base_salaries + lead_costs - mentorship_savings <= budget, "Budget")
    
    ## Max employees
    model.addConstr(x.sum() <= max_employees, "MaxEmployees")
    
    ## Min skill level
    model.addConstr(gp.quicksum(cand_data[c]['skill'] * x[c] for c in candidates) >= min_skill, "MinSkill")
    
    ## Min project management experience
    model.addConstr(gp.quicksum(cand_data[c]['pm_exp'] * x[c] for c in candidates) >= min_pm_exp, "MinPMExp")
    
    ## At most one of G or J
    model.addConstr(x['G'] + x['J'] <= max_gj, "MaxOneGJ")
    
    ## Role assignment: if hired, exactly one role (Lead or Engineer)
    for c in candidates:
        model.addConstr(l[c] <= x[c], f"LeadIfHired_{c}")
    
    ## Minimum number of Leads
    model.addConstr(l.sum() >= min_leads, "MinLeads")
    
    ## Mentorship pairs: bounded by Leads, Engineers, and max pairs
    engineers = gp.quicksum(x[c] - l[c] for c in candidates)
    model.addConstr(p <= l.sum(), "PairsBoundByLeads")
    model.addConstr(p <= engineers, "PairsBoundByEngineers")
    model.addConstr(p <= max_pairs, "MaxPairs")
    
    # Solve
    model.optimize()
    
    # Output final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
