import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    df = pd.read_csv(data_path)
    
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = row['Value']
        
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = int(params['raw_bar_length'])
    setup_cost = float(params['setup_cost_per_pattern'])
    max_patterns = int(params['max_distinct_patterns'])
    
    bar_lengths = [3, 4, 5]
    patterns = []
    for a in range(L // bar_lengths[0] + 1):
        for b in range(L // bar_lengths[1] + 1):
            for c in range(L // bar_lengths[2] + 1):
                total_length = bar_lengths[0] * a + bar_lengths[1] * b + bar_lengths[2] * c
                if 0 < total_length <= L:
                    patterns.append((a, b, c))
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    n = len(patterns)
    x = model.addVars(n, vtype=GRB.INTEGER, name="x", lb=0)
    y = model.addVars(n, vtype=GRB.BINARY, name="y")
    
    model.addConstr(gp.quicksum(patterns[i][0] * x[i] for i in range(n)) >= q3)
    model.addConstr(gp.quicksum(patterns[i][1] * x[i] for i in range(n)) >= q4)
    model.addConstr(gp.quicksum(patterns[i][2] * x[i] for i in range(n)) >= q5)
    
    M = 10000
    for i in range(n):
        model.addConstr(x[i] <= M * y[i])
    
    model.addConstr(gp.quicksum(y[i] for i in range(n)) <= max_patterns)
    
    total_raw_bars = gp.quicksum(x[i] for i in range(n))
    required_length = 3*q3 + 4*q4 + 5*q5
    physical_waste = total_raw_bars * L - required_length
    setup_waste = gp.quicksum(y[i] for i in range(n)) * setup_cost
    model.setObjective(physical_waste + setup_waste, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
