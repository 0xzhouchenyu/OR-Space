import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_csv_data

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load data
    products = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params_raw = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Parse general parameters
    params = {}
    for row in params_raw:
        params[row['Parameter_Name']] = float(row['Value'])
    
    max_grains = params['max_grains']
    price_grains = params['price_per_lb_grains']
    max_meat = params['max_meat']
    price_meat = params['price_per_lb_meat']
    line_fixed_cost = params['line_fixed_cost']
    line_capacity = params['line_capacity_packs']
    min_batch = params['min_batch_packs']
    min_yummies = params['min_yummies']
    rebate_threshold_y = params['retailer_rebate_yummies_threshold']
    rebate_threshold_m = params['retailer_rebate_min_meaties']
    rebate_fixed = params['retailer_rebate_fixed']
    
    # Parse product data
    product_data = {}
    for row in products:
        name = row['Product']
        product_data[name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'variable_cost': float(row['Variable_cost_per_pack']),
            'capacity': float(row['Production_capacity']) if row['Production_capacity'].strip() else None
        }
    
    m = product_data['Meaties']
    y = product_data['Yummies']
    
    # Calculate profit per pack
    profit_meaties = m['price'] - m['variable_cost'] - (m['grains'] * price_grains + m['meat'] * price_meat)
    profit_yummies = y['price'] - y['variable_cost'] - (y['grains'] * price_grains + y['meat'] * price_meat)
    
    # Create Gurobi model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    M = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Meaties")
    Y = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Yummies")
    z = model.addVar(vtype=GRB.BINARY, name="Line_Active")
    r = model.addVar(vtype=GRB.BINARY, name="Rebate")
    
    # Objective function
    total_profit = (profit_meaties * M + profit_yummies * Y - 
                    line_fixed_cost * z + rebate_fixed * r)
    model.setObjective(total_profit, GRB.MAXIMIZE)
    
    # Constraints
    # Resource constraints
    model.addConstr(m['grains'] * M + y['grains'] * Y <= max_grains, "Grains_Constraint")
    model.addConstr(m['meat'] * M + y['meat'] * Y <= max_meat, "Meat_Constraint")
    
    # Meaties capacity constraint
    if m['capacity'] is not None:
        model.addConstr(M <= m['capacity'], "Meaties_Capacity")
    
    # Line activation constraints
    model.addConstr(M + Y <= line_capacity * z, "Line_Capacity")
    model.addConstr(M + Y >= min_batch * z, "Min_Batch")
    model.addConstr(Y >= min_yummies * z, "Min_Yummies")
    
    # Rebate eligibility constraints
    model.addConstr(M >= rebate_threshold_m * r, "Rebate_Meaties_Threshold")
    model.addConstr(Y >= rebate_threshold_y * r, "Rebate_Yummies_Threshold")
    
    # Solve the model
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print(f"FINAL_OBJ_VALUE: {-999999999}")

if __name__ == "__main__":
    main()
