import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

# Read property data
properties = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Extract parameters
budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_mult = params['scen_1_risky_multiplier']
scen_2_mult = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = int(params['max_risky_properties'])

# Calculate risk bonus coefficient
avg_risky_mult = scen_1_prob * scen_1_mult + scen_2_prob * scen_2_mult
risk_bonus = avg_risky_mult - 1.0

# Create optimization model
model = gp.Model("RealEstateInvestment")
model.setParam('OutputFlag', 0)

# Create variables
x = {}  # Binary: 1 if property is purchased
y = {}  # Continuous: fraction allocated to risky leasing
z = {}  # Binary: 1 if property has any risky leasing

for prop in properties:
    name = prop['name']
    x[name] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}")
    y[name] = model.addVar(lb=0.0, ub=per_property_risky_cap, name=f"y_{name}")
    z[name] = model.addVar(vtype=GRB.BINARY, name=f"z_{name}")

# Set objective
objective = gp.quicksum(
    prop['income'] * x[prop['name']] + 
    prop['income'] * risk_bonus * y[prop['name']]
    for prop in properties
)
model.setObjective(objective, GRB.MAXIMIZE)

# Budget constraint
model.addConstr(
    gp.quicksum(prop['cost'] * x[prop['name']] for prop in properties) <= budget,
    "budget"
)

# Property exclusion constraint
model.addConstr(x['Property_4'] + x['Property_3'] <= 1, "exclusion")

# Risky allocation constraints
for prop in properties:
    name = prop['name']
    # If no risky allocation, z must be 0; if risky, z must be 1
    model.addConstr(y[name] <= per_property_risky_cap * z[name], f"risky_cap_{name}")
    # Can only have risky if purchased
    model.addConstr(z[name] <= x[name], f"risky_if_purchased_{name}")
    # Link y to purchase: y can only be >0 if purchased (implied by z constraint)

# Total risky exposure constraint
model.addConstr(
    gp.quicksum(prop['cost'] * z[prop['name']] for prop in properties) <= total_risky_budget,
    "total_risky_exposure"
)

# Max properties with risky leasing
model.addConstr(
    gp.quicksum(z[prop['name']] for prop in properties) <= max_risky_properties,
    "max_risky_properties"
)

# Solve the model
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: 0")
