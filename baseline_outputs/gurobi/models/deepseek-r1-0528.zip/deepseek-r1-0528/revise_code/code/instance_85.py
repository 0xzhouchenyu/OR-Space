import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'table_1.csv')
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    machine_avail = params['machine_time_available']
    reg_craftsman_avail = params['craftsman_regular_time_available']
    ovt_craftsman_avail = params['craftsman_overtime_available']
    machine_cost = params['machine_time_cost']
    reg_craftsman_cost = params['craftsman_time_cost']
    ovt_craftsman_cost = params['craftsman_overtime_cost']
    rev_X = params['revenue_product_X']
    rev_Y = params['revenue_product_Y']
    min_X = params['min_batches_product_X']
    qa_threshold = params['product_Y_QA_threshold']
    qa_fee = params['product_Y_QA_fee']
    
    # Create model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    X = model.addVar(lb=min_X, vtype=GRB.CONTINUOUS, name="X")
    Y = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Y")
    R = model.addVar(lb=0, ub=reg_craftsman_avail, vtype=GRB.CONTINUOUS, name="R")
    O = model.addVar(lb=0, ub=ovt_craftsman_avail, vtype=GRB.CONTINUOUS, name="O")
    Z = model.addVar(vtype=GRB.BINARY, name="Z")
    
    # Calculate resource usage
    machine_time = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0
    craftsman_time = (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0
    
    # Objective: maximize profit
    revenue = rev_X * X + rev_Y * Y
    machine_costs = machine_cost * machine_time
    craftsman_costs = reg_craftsman_cost * R + ovt_craftsman_cost * O
    qa_costs = qa_fee * Z
    profit = revenue - machine_costs - craftsman_costs - qa_costs
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Constraints
    model.addConstr(machine_time <= machine_avail, "Machine_Time_Constraint")
    model.addConstr(R + O == craftsman_time, "Craftsman_Time_Constraint")
    model.addConstr(Y <= qa_threshold + 1000 * Z, "QA_Trigger")
    
    # Optimize
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal:.2f}")

if __name__ == "__main__":
    main()
