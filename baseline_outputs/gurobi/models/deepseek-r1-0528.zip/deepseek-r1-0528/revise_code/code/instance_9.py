import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_toy_data, load_general_parameters

# Load data
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")
toys = load_toy_data(os.path.join(data_dir, "table_1.csv"))
params = load_general_parameters(os.path.join(data_dir, "general_parameters.csv"))

# Extract parameters
available_wood = params["available_wood"]
available_steel = params["available_steel"]
truck_train_exclusion = params["truck_train_exclusion"]
boat_airplane_dependency = params["boat_airplane_dependency"]
boat_train_limit = params["boat_train_limit"]
profit_premium_bonus = params["profit_premium_bonus"]
premium_steel_factor = params["premium_steel_factor"]
premium_shift_capacity = params["premium_shift_capacity"]

# Big M for quantity bounds
M = 1000

# Create model
model = gp.Model("HausToysRevised")
model.setParam('OutputFlag', 0)

# Create decision variables
toy_types = [t["type"] for t in toys]
x_std = model.addVars(toy_types, lb=0, vtype=GRB.CONTINUOUS, name="std")
x_prem = model.addVars(toy_types, lb=0, vtype=GRB.CONTINUOUS, name="prem")
y_std = model.addVars(toy_types, vtype=GRB.BINARY, name="y_std")
y_prem = model.addVars(toy_types, vtype=GRB.BINARY, name="y_prem")

# Objective: maximize total profit
obj = gp.quicksum(
    t["profit"] * x_std[t["type"]] + 
    (t["profit"] + profit_premium_bonus) * x_prem[t["type"]] 
    for t in toys
)
model.setObjective(obj, GRB.MAXIMIZE)

# Resource constraints
model.addConstr(
    gp.quicksum(t["wood"] * (x_std[t["type"]] + x_prem[t["type"]]) for t in toys) <= available_wood,
    "Wood_Constraint"
)
model.addConstr(
    gp.quicksum(
        t["steel"] * x_std[t["type"]] + 
        t["steel"] * premium_steel_factor * x_prem[t["type"]] 
        for t in toys
    ) <= available_steel,
    "Steel_Constraint"
)

# Shift assignment constraints
for t in toy_types:
    model.addConstr(x_std[t] <= M * y_std[t], f"Link_std_{t}")
    model.addConstr(x_prem[t] <= M * y_prem[t], f"Link_prem_{t}")
    model.addConstr(y_std[t] + y_prem[t] <= 1, f"Shift_Exclusive_{t}")

# Premium shift capacity
model.addConstr(gp.quicksum(x_prem[t] for t in toy_types) <= premium_shift_capacity, "Premium_Capacity")

# Logical constraints
# Truck-train exclusion (any shift)
model.addConstr(
    (y_std["truck"] + y_prem["truck"]) + (y_std["train"] + y_prem["train"]) <= 1, 
    "Truck_Train_Exclusion"
)

# Boat-airplane dependency (any shift)
model.addConstr(
    (y_std["boat"] + y_prem["boat"]) <= (y_std["airplane"] + y_prem["airplane"]), 
    "Boat_Airplane_Dependency"
)

# Boat-train production limit (total units)
model.addConstr(
    (x_std["boat"] + x_prem["boat"]) <= (x_std["train"] + x_prem["train"]), 
    "Boat_Train_Limit"
)

# Solve the model
model.optimize()

# Output the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: 0.0")
