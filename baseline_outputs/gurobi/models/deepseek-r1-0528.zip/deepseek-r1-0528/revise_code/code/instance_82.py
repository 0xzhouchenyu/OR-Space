import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    total_space = params['mall_total_space']
    rent_pct = params['rent_percentage'] / 100.0
    common_area_factor = params['common_area_factor']
    gm_concession = params['general_merchandise_third_store_concession']
    cat_cost = params['catering_third_store_security_cost']
    
    stores = []
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            store_type = row['Store_Type'].strip()
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val != '-':
                    profits[k] = float(val)
            stores.append({
                'name': store_type,
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits
            })
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    x = []
    for i, store in enumerate(stores):
        x.append(model.addVar(vtype=GRB.INTEGER, lb=store['min'], ub=store['max'], name=store['name']))
    
    total_area = sum(x[i] * store['area'] * common_area_factor for i, store in enumerate(stores))
    model.addConstr(total_area <= total_space, "TotalSpace")
    
    p_total = 0
    for i, store in enumerate(stores):
        min_val = store['min']
        max_val = store['max']
        possible_vals = list(range(min_val, max_val + 1))
        profits_for_val = []
        for k in possible_vals:
            if k == 0:
                profits_for_val.append(0.0)
            else:
                profits_for_val.append(k * store['profits'][k])
        
        b_i = model.addVars(len(possible_vals), vtype=GRB.BINARY, name=f"b_{store['name']}")
        model.addConstr(sum(b_i) == 1, f"store_{i}_select_one")
        model.addConstr(x[i] == sum(k * b_i[j] for j, k in enumerate(possible_vals)), f"store_{i}_x")
        p_total += sum(profits_for_val[j] * b_i[j] for j in range(len(possible_vals)))
    
    concession_ind = model.addVar(vtype=GRB.BINARY, name="concession_ind")
    model.addConstr((x[2] == 3) >> (concession_ind == 1))
    model.addConstr((x[2] != 3) >> (concession_ind == 0))
    
    security_ind = model.addVar(vtype=GRB.BINARY, name="security_ind")
    model.addConstr((x[4] == 3) >> (security_ind == 1))
    model.addConstr((x[4] != 3) >> (security_ind == 0))
    
    total_rent = rent_pct * p_total - concession_ind * gm_concession - security_ind * cat_cost
    model.setObjective(total_rent, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: -inf")

if __name__ == '__main__':
    main()
