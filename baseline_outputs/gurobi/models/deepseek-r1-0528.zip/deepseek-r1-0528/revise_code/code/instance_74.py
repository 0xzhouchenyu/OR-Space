import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv")) as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row["Parameter_Name"].strip()] = float(row["Value"].strip())
    
    precedences = []
    with open(os.path.join(data_dir, "table_1.csv")) as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row["Predecessor"].strip(), row["Successor"].strip()))
    
    activities = ["A", "B", "C", "D", "E", "F", "G"]
    base_dur = {
        a: int(params[f"activity_{a}_duration"]) 
        for a in activities
    }
    work_cost = params["work_cost_per_day"]
    machine_cost = params["machine_rental_cost_per_day"]
    e_red = int(params["activity_E_overtime_reduction"])
    e_ot_cost = params["activity_E_overtime_cost"]
    e_review_cost = params["activity_E_followup_review_cost"]
    
    model = gp.Model("Project_Cost_Minimization")
    model.setParam("OutputFlag", 0)
    
    S = model.addVars(activities, name="S", lb=0)
    T = model.addVar(name="T", lb=0)
    overtime_E = model.addVar(vtype=GRB.BINARY, name="overtime_E")
    
    for pred, succ in precedences:
        if pred == "E":
            model.addConstr(S[succ] >= S[pred] + base_dur["E"] - e_red * overtime_E)
        else:
            model.addConstr(S[succ] >= S[pred] + base_dur[pred])
    
    model.addConstr(T >= S["B"] + base_dur["B"])
    model.addConstr(T >= S["C"] + base_dur["C"])
    
    machine_rental_duration = S["B"] + base_dur["B"] - S["A"]
    overtime_and_review_cost = (e_ot_cost + e_review_cost) * overtime_E
    model.setObjective(
        work_cost * T + machine_cost * machine_rental_duration + overtime_and_review_cost,
        GRB.MINIMIZE
    )
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
