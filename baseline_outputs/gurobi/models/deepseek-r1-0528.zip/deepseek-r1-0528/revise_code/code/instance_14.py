import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load food items
    items = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })
    
    # Load parameters
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_calories = params['min_daily_calories']
    max_calories = params['max_daily_calories']
    max_sodium = params['max_daily_sodium']
    
    max_units = int(total_weight_limit // 100)
    max_meal_units = 3
    veg_indices = [i for i in range(len(items)) if items[i]['type'] == 'Vegetable']
    
    model = gp.Model("meal_planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    purchase = model.addVars(len(items), vtype=GRB.INTEGER, lb=0, name="purchase")
    lunch = model.addVars(len(items), vtype=GRB.INTEGER, lb=0, name="lunch")
    dinner = model.addVars(len(items), vtype=GRB.INTEGER, lb=0, name="dinner")
    select = model.addVars(len(items), vtype=GRB.BINARY, name="select")
    lunch_veg = model.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg")
    dinner_veg = model.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg")
    
    # Objective: maximize total protein from both meals
    model.setObjective(
        gp.quicksum(items[i]['protein'] * (lunch[i] + dinner[i]) for i in range(len(items))),
        GRB.MAXIMIZE
    )
    
    # Budget constraint
    model.addConstr(
        gp.quicksum(items[i]['cost'] * purchase[i] for i in range(len(items))) <= max_budget,
        "budget"
    )
    
    # Total weight constraint
    model.addConstr(
        gp.quicksum(100 * purchase[i] for i in range(len(items))) <= total_weight_limit,
        "total_weight"
    )
    
    # Meal portion weights
    model.addConstr(gp.quicksum(lunch[i] for i in range(len(items))) == max_meal_units, "lunch_weight")
    model.addConstr(gp.quicksum(dinner[i] for i in range(len(items))) == max_meal_units, "dinner_weight")
    
    # Purchase vs allocation
    for i in range(len(items)):
        model.addConstr(lunch[i] + dinner[i] <= purchase[i], f"alloc_purchase_{i}")
        model.addConstr(purchase[i] <= max_units * select[i], f"select_purchase_{i}")
        model.addConstr(lunch[i] <= max_meal_units * select[i], f"select_lunch_{i}")
        model.addConstr(dinner[i] <= max_meal_units * select[i], f"select_dinner_{i}")
    
    # Vegetable selection indicators
    for idx, i in enumerate(veg_indices):
        model.addConstr(lunch[i] >= lunch_veg[idx], f"veg_lunch_min_{i}")
        model.addConstr(lunch[i] <= max_meal_units * lunch_veg[idx], f"veg_lunch_max_{i}")
        model.addConstr(dinner[i] >= dinner_veg[idx], f"veg_dinner_min_{i}")
        model.addConstr(dinner[i] <= max_meal_units * dinner_veg[idx], f"veg_dinner_max_{i}")
    
    # Vegetable type constraints
    model.addConstr(gp.quicksum(lunch_veg[idx] for idx in range(len(veg_indices))) >= min_veg_types, "lunch_veg_types")
    model.addConstr(gp.quicksum(dinner_veg[idx] for idx in range(len(veg_indices))) >= min_veg_types, "dinner_veg_types")
    
    # Calorie constraints
    total_calories = gp.quicksum(items[i]['calories'] * (lunch[i] + dinner[i]) for i in range(len(items)))
    model.addConstr(total_calories >= min_calories, "min_calories")
    model.addConstr(total_calories <= max_calories, "max_calories")
    
    # Sodium constraint
    total_sodium = gp.quicksum(items[i]['sodium'] * (lunch[i] + dinner[i]) for i in range(len(items)))
    model.addConstr(total_sodium <= max_sodium, "max_sodium")
    
    # Optimize
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
