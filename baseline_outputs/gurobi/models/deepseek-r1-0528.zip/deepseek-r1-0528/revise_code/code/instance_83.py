import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Read time periods and minimum waiters needed
min_waiters = []
with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        min_waiters.append(int(row['Minimum_Number_of_Waiters_Needed'].strip()))

# Read general parameters
peak = [0] * 6
quality = [0] * 6
waiter_cost_per_shift = 0
waiter_budget = 0

with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        pname = row['Parameter_Name'].strip()
        val = int(row['Value'].strip())
        if pname.startswith('peak_'):
            idx = int(pname.split('_')[1])
            peak[idx] = val
        elif pname.startswith('quality_'):
            idx = int(pname.split('_')[1])
            quality[idx] = val
        elif pname == 'waiter_cost_per_shift':
            waiter_cost_per_shift = val
        elif pname == 'waiter_budget':
            waiter_budget = val

# Precompute valid shifts (one peak + one off-peak)
valid_shifts = []
for i in range(6):
    j = (i + 1) % 6
    if peak[i] + peak[j] == 1:
        valid_shifts.append(i)

# Create model
model = gp.Model()
model.setParam('OutputFlag', 0)

# Decision variables for valid shifts
x = model.addVars(valid_shifts, vtype=GRB.INTEGER, name="x")

# Coverage constraints for each period
for j in range(6):
    covering_shifts = []
    for i in valid_shifts:
        if j == i or j == (i + 1) % 6:
            covering_shifts.append(i)
    model.addConstr(gp.quicksum(x[i] for i in covering_shifts) >= min_waiters[j], f"Coverage_Period_{j}")

# Budget constraint
total_waiters = gp.quicksum(x[i] for i in valid_shifts)
model.addConstr(total_waiters * waiter_cost_per_shift <= waiter_budget, "Budget")

# Objective: maximize service quality score
obj = gp.quicksum((quality[i] + quality[(i + 1) % 6]) * x[i] for i in valid_shifts)
model.setObjective(obj, GRB.MAXIMIZE)

# Solve
model.optimize()

# Output
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
