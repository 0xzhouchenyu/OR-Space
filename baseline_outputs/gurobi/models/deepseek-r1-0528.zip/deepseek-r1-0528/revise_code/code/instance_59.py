import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Read data from CSV files
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read table_1_7.csv
    table_path = os.path.join(base_dir, "table_1_7.csv")
    with open(table_path, 'r') as f:
        reader = csv.reader(f)
        rows = list(reader)
    
    raw_material_limits = [float(rows[1][5]), float(rows[2][5]), float(rows[3][5])]  # A, B, C
    raw_material_costs = [float(rows[1][4]), float(rows[2][4]), float(rows[3][4])]    # A, B, C
    processing_fees = [float(rows[4][1]), float(rows[4][2]), float(rows[4][3])]       # A, B, C
    selling_prices = [float(rows[5][1]), float(rows[5][2]), float(rows[5][3])]        # A, B, C
    
    # Read general_parameters.csv
    gen_path = os.path.join(base_dir, "general_parameters.csv")
    setup_costs = {}
    shared_wrapper_fee = 0
    with open(gen_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if not row:
                continue
            param = row[0]
            value = float(row[1])
            if param == "SetupCost_A":
                setup_costs["A"] = value
            elif param == "SetupCost_B":
                setup_costs["B"] = value
            elif param == "SetupCost_C":
                setup_costs["C"] = value
            elif param == "BrandAB_SharedWrapper_Fee":
                shared_wrapper_fee = value
    
    # Create model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    for i in range(3):  # Raw materials: 0=A, 1=B, 2=C
        for j in range(3):  # Brands: 0=A, 1=B, 2=C
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    y = [model.addVar(lb=0, name=f"y_{j}") for j in range(3)]  # Production per brand
    
    # Binary variables for setup costs and shared wrapper
    z = [model.addVar(vtype=GRB.BINARY, name=f"z_{j}") for j in range(3)]  # z0=A, z1=B, z2=C
    z_AB = model.addVar(vtype=GRB.BINARY, name="z_AB")  # Shared wrapper indicator
    
    # Big M for production (total raw materials)
    M = sum(raw_material_limits)
    
    # Define production quantities
    for j in range(3):
        model.addConstr(y[j] == gp.quicksum(x[i, j] for i in range(3)), f"prod_def_{j}")
    
    # Setup cost activation constraints
    for j in range(3):
        model.addConstr(y[j] <= M * z[j], f"setup_activation_{j}")
    
    # Shared wrapper constraint (if both A and B are produced)
    model.addConstr(z_AB >= z[0] + z[1] - 1, "shared_lb")
    model.addConstr(z_AB <= z[0], "shared_ub0")
    model.addConstr(z_AB <= z[1], "shared_ub1")
    
    # Raw material availability
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= raw_material_limits[i], f"rm_limit_{i}")
    
    # Composition constraints
    model.addConstr(x[0, 0] >= 0.60 * y[0], "comp_A_A_min")
    model.addConstr(x[0, 1] >= 0.15 * y[1], "comp_A_B_min")
    model.addConstr(x[2, 0] <= 0.20 * y[0], "comp_C_A_max")
    model.addConstr(x[2, 1] <= 0.60 * y[1], "comp_C_B_max")
    model.addConstr(x[2, 2] <= 0.50 * y[2], "comp_C_C_max")
    
    # Objective components
    revenue = gp.quicksum(selling_prices[j] * y[j] for j in range(3))
    material_cost = gp.quicksum(raw_material_costs[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(processing_fees[j] * y[j] for j in range(3))
    setup_cost = setup_costs["A"] * z[0] + setup_costs["B"] * z[1] + setup_costs["C"] * z[2]
    shared_fee = shared_wrapper_fee * z_AB
    
    profit = revenue - material_cost - processing_cost - setup_cost - shared_fee
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    # Output final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")
    else:
        print(f"FINAL_OBJ_VALUE: 0.0")

if __name__ == "__main__":
    main()
