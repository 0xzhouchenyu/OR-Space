import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = params['fixed_order_cost']
    august_threshold = params['august_bulk_order_threshold']
    august_fee = params['august_bulk_receiving_fee']
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create Gurobi model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = model.addVars(months, lb=0, name="buy")
    sell = model.addVars(months, lb=0, name="sell")
    stock = model.addVars(months, lb=0, ub=warehouse_capacity, name="stock")
    order_indicator = model.addVars(months, vtype=GRB.BINARY, name="order_indicator")
    august_bulk_indicator = model.addVar(vtype=GRB.BINARY, name="august_bulk_indicator")
    
    # Objective: maximize profit (revenue - costs)
    revenue = gp.quicksum(sell_price[m] * sell[m] for m in months)
    purchase_cost = gp.quicksum(buy_price[m] * buy[m] for m in months)
    fixed_costs = fixed_order_cost * gp.quicksum(order_indicator[m] for m in months)
    model.setObjective(revenue - purchase_cost - fixed_costs - august_fee * august_bulk_indicator, GRB.MAXIMIZE)
    
    # Stock balance constraints
    prev_stock = initial_stock
    for m in sorted(months):
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], f"balance_{m}")
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, f"warehouse_{m}")
        prev_stock = stock[m]
    
    # Fixed order cost indicators
    for m in months:
        model.addConstr(buy[m] <= warehouse_capacity * order_indicator[m], f"order_indicator_{m}")
    
    # August bulk receiving logic
    august = 8
    model.addConstr(buy[august] <= august_threshold + (warehouse_capacity - august_threshold) * august_bulk_indicator, 
                   "august_upper_bound")
    model.addConstr(buy[august] >= (august_threshold + 1e-5) * august_bulk_indicator, 
                   "august_lower_bound")
    
    # Optimize
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
