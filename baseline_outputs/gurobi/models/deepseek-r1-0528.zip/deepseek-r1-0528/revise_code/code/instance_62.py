import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_restaurant_data(filepath):
    restaurants = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'standard_staff': float(row['Standard_Staff_Hours'].strip()),
                'premium_staff': float(row['Premium_Staff_Hours'].strip())
            })
    return restaurants

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    return params

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    restaurants = load_restaurant_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    model = gp.Model("RestaurantInvestment")
    model.setParam('OutputFlag', 0)
    
    x = {}  # Purchase decision
    y = {}  # Premium operation
    for r in restaurants:
        name = r['name']
        x[name] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}")
        y[name] = model.addVar(vtype=GRB.BINARY, name=f"y_{name}")
    
    for r in restaurants:
        model.addConstr(y[r['name']] <= x[r['name']], f"PremiumRequiresPurchase_{r['name']}")
    
    if 'Restaurant_D' in x and 'Restaurant_A' in x:
        model.addConstr(x['Restaurant_D'] + x['Restaurant_A'] <= 1, "D_A_Exclusion")
    
    total_cost = gp.quicksum(r['cost'] * x[r['name']] + params['premium_upgrade_cost'] * y[r['name']] for r in restaurants)
    model.addConstr(total_cost <= params['investment_budget'], "BudgetLimit")
    
    staff_hours = gp.quicksum(r['premium_staff'] * y[r['name']] for r in restaurants)
    model.addConstr(staff_hours <= params['staff_hours_cap'], "StaffHoursLimit")
    
    revenue = gp.quicksum(r['revenue'] * x[r['name']] + r['revenue'] * params['premium_revenue_uplift'] * y[r['name']] for r in restaurants)
    model.setObjective(revenue, GRB.MAXIMIZE)
    
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
