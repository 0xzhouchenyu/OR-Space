import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_storage = float(params['max_storage_capacity']) / 10000.0  # Convert to 10k m³
    storage_cost_a = float(params['storage_cost_a']) * 10000.0 / 10000.0  # Convert to 10k yuan/10k m³
    storage_cost_b = float(params['storage_cost_b']) * 10000.0 / 10000.0  # Convert to 10k yuan/10k m³/quarter
    safety_inventory = float(params['safety_inventory_level_10k_m3'])
    terminal_value = float(params['terminal_inventory_value_per_10k_m3'])
    penalty_rate = float(params['over_purchase_penalty_cost_per_10k_m3'])
    
    # Quarter indices: 0=Winter, 1=Spring, 2=Summer, 3=Autumn
    n = len(quarters)
    q_index = {q: i for i, q in enumerate(quarters)}
    purchase_price_list = [purchase_price[q] for q in quarters]
    sale_price_list = [sale_price[q] for q in quarters]
    max_sales_list = [max_sales[q] for q in quarters]
    max_purchase_list = [max_purchase[q] for q in quarters]
    
    # Create model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}  # x[i,j]: timber purchased in i, sold in j (i<=j<=3)
    for i in range(n):
        for j in range(i, n):
            x[i,j] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{i}_{j}")
    
    y = {}  # y[i]: timber purchased in i, held as terminal inventory
    for i in range(n):
        y[i] = model.addVar(vtype=GRB.CONTINUOUS, name=f"y_{i}")
    
    total_terminal = model.addVar(vtype=GRB.CONTINUOUS, name="total_terminal")
    excess = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="excess")
    
    # Objective: maximize profit
    revenue_sales = gp.quicksum(sale_price_list[j] * x[i,j] for i in range(n) for j in range(i, n))
    revenue_terminal = terminal_value * total_terminal
    
    cost_purchase = gp.quicksum(purchase_price_list[i] * (gp.quicksum(x[i,j] for j in range(i, n)) + y[i]) for i in range(n))
    
    storage_cost_x = gp.quicksum((storage_cost_a + storage_cost_b * (j-i)) * x[i,j] for i in range(n) for j in range(i+1, n))
    storage_cost_y = gp.quicksum((storage_cost_a + storage_cost_b * (n-1 - i)) * y[i] for i in range(n))
    
    cost_penalty = penalty_rate * excess
    
    profit = revenue_sales + revenue_terminal - cost_purchase - storage_cost_x - storage_cost_y - cost_penalty
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Purchase capacity constraints
    for i in range(n):
        model.addConstr(gp.quicksum(x[i,j] for j in range(i, n)) + y[i] <= max_purchase_list[i], 
                       f"purchase_cap_{i}")
    
    # Sales volume constraints
    for j in range(n):
        model.addConstr(gp.quicksum(x[i,j] for i in range(0, j+1)) <= max_sales_list[j], 
                       f"sales_cap_{j}")
    
    # Storage capacity constraints (end of Winter, Spring, Summer)
    for t in range(n-1):  # t: end of quarter index (0,1,2)
        inventory = gp.quicksum(
            gp.quicksum(x[i,j] for j in range(t+1, n)) + y[i] for i in range(t+1)
        )
        model.addConstr(inventory <= max_storage, f"storage_cap_{t}")
    
    # Terminal inventory and excess
    model.addConstr(total_terminal == gp.quicksum(y[i] for i in range(n)), "total_terminal_def")
    model.addConstr(excess >= total_terminal - safety_inventory, "excess_def")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.1f}")
    else:
        print("FINAL_OBJ_VALUE: 0.0")  # In case of infeasibility

if __name__ == "__main__":
    main()
