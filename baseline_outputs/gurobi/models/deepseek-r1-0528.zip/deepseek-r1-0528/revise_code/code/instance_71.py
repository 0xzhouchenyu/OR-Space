import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    premium_cost_multiplier = 1.5
    min_premium_share = 0.4
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'premium_cost_multiplier':
                premium_cost_multiplier = float(row['Value'])
            elif row['Parameter_Name'] == 'min_premium_share':
                min_premium_share = float(row['Value'])
    
    n = 0
    d = []
    c_data = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            factory = row['Factory']
            n += 1
            vol_row = [float(row[f'Transportation_volume_to_Location_{j+1}']) for j in range(2)]
            d.append(vol_row)
            cost_row = [float(row[f'Transportation_cost_to_Location_{j+1}']) for j in range(2)]
            c_data.append(cost_row)
    
    premium_factor = 1 + (premium_cost_multiplier - 1) * min_premium_share
    
    base_cost = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for p in range(n):
            total = 0.0
            for j in range(n):
                total += d[i][j] * c_data[p][j]
            base_cost[i][p] = total
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    z = model.addVars(n, n, 2, vtype=GRB.BINARY, name='z')
    
    for i in range(n):
        model.addConstr(gp.quicksum(z[i, p, m] for p in range(n) for m in range(2)) == 1)
    
    for p in range(n):
        model.addConstr(gp.quicksum(z[i, p, m] for i in range(n) for m in range(2)) == 1)
    
    obj = gp.QuadExpr()
    for i in range(n):
        for p in range(n):
            obj += z[i, p, 0] * base_cost[i][p]
            obj += z[i, p, 1] * (base_cost[i][p] * premium_factor)
    
    model.setObjective(obj, GRB.MINIMIZE)
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
