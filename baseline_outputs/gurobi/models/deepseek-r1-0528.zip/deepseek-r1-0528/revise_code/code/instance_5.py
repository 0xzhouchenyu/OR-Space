import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(base_dir, "data", "table_1.csv")
    params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    
    df = pd.read_csv(table_1_path)
    params_df = pd.read_csv(params_path)
    
    # Extract parameters
    params = {row['Parameter_Name']: float(row['Value']) for _, row in params_df.iterrows()}
    budget = params['budget']
    food_intake = params['food_intake'] / 100.0  # Convert grams to 100g units
    weekday_budget_share = params['weekday_budget_share']
    max_prep_weekday = params['max_prep_time_weekday']
    max_prep_weekend = params['max_prep_time_weekend']
    weekend_protein_ban = params['weekend_protein_ban']
    veg_penalty = params['veg_balance_penalty']
    
    # Process food data
    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)
    foods = df['Food'].tolist()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()
    types = df.set_index('Food')['Type'].to_dict()
    
    vegetables = [f for f in foods if types[f] == 'vegetable']
    proteins = [f for f in foods if types[f] == 'protein']
    meals = ['weekday', 'weekend']
    
    # Create Gurobi model
    model = gp.Model("DinnerPlanning")
    model.setParam('OutputFlag', 0)
    
    # Variables
    x = model.addVars(foods, meals, lb=0, name="x")  # Amount in 100g units
    y = model.addVars(foods, meals, vtype=GRB.BINARY, name="y")  # Usage indicator
    d = model.addVar(lb=0, name="d")  # Absolute difference in vegetable amounts
    
    # Objective: maximize total fiber intake
    total_fiber = gp.quicksum(fiber[f] * x[f, meal] for f in foods for meal in meals)
    model.setObjective(total_fiber, GRB.MAXIMIZE)
    
    # Constraints
    # Total food intake per meal
    for meal in meals:
        model.addConstr(gp.quicksum(x[f, meal] for f in foods) == food_intake, f"food_intake_{meal}")
    
    # Budget constraint including vegetable balance penalty
    food_cost = gp.quicksum(price[f] * x[f, meal] for f in foods for meal in meals)
    model.addConstr(food_cost + veg_penalty * d <= budget, "total_budget")
    
    # Preparation time constraints
    model.addConstr(gp.quicksum(prep_time[f] * x[f, 'weekday'] for f in foods) <= max_prep_weekday, "prep_weekday")
    model.addConstr(gp.quicksum(prep_time[f] * x[f, 'weekend'] for f in foods) <= max_prep_weekend, "prep_weekend")
    
    # Protein constraints per meal
    model.addConstr(gp.quicksum(y[p, 'weekday'] for p in proteins) == 1, "weekday_protein")
    if weekend_protein_ban == 1:
        model.addConstr(gp.quicksum(y[p, 'weekend'] for p in proteins) == 0, "weekend_protein_ban")
    else:
        model.addConstr(gp.quicksum(y[p, 'weekend'] for p in proteins) == 1, "weekend_protein")
    
    # At least two vegetables per meal
    for meal in meals:
        model.addConstr(gp.quicksum(y[v, meal] for v in vegetables) >= 2, f"min_vegetables_{meal}")
    
    # Linking constraints (minimum and maximum amounts)
    M = food_intake
    for f in foods:
        for meal in meals:
            model.addConstr(x[f, meal] >= 0.1 * y[f, meal], f"min_include_{f}_{meal}")
            model.addConstr(x[f, meal] <= M * y[f, meal], f"max_include_{f}_{meal}")
    
    # Vegetable balance constraints
    veg_weekday = gp.quicksum(x[v, 'weekday'] for v in vegetables)
    veg_weekend = gp.quicksum(x[v, 'weekend'] for v in vegetables)
    model.addConstr(d >= veg_weekday - veg_weekend, "veg_diff1")
    model.addConstr(d >= veg_weekend - veg_weekday, "veg_diff2")
    
    # Optimize
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 4)}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
