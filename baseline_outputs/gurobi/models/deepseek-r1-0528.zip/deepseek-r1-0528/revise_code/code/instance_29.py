import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    params_df = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    demand_df = pd.read_csv(os.path.join(data_dir, "table_4_3.csv"))
    supply_df = pd.read_csv(os.path.join(data_dir, "table_4_4.csv"))
    
    # Extract parameters
    p2_target = int(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])
    
    # Preprocess demand data
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split()[0]
        spec = int(row['Specialty'])
        dem = int(row['Demand'])
        demand[(city, spec)] = dem
    
    # Preprocess supply data
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        supply[t] = {
            'num': int(row['Number_of_People']),
            'suit': [int(x) for x in str(row['Suitable_Specialty']).split(',')],
            'pref_spec': int(row['Preferred_Specialty']),
            'pref_city': row['Preferred_City']
        }
    
    # Define sets
    types = list(supply.keys())
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    
    # Create model
    model = gp.Model("Personnel_Assignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(types, cities, specs, vtype=GRB.INTEGER, name="x")
    
    # Supply constraints
    for i in types:
        model.addConstr(gp.quicksum(x[i, j, k] for j in cities for k in specs) <= supply[i]['num'])
    
    # Demand constraints
    for (j, k), dem_val in demand.items():
        model.addConstr(gp.quicksum(x[i, j, k] for i in types) >= dem_val)
    
    # Suitable specialty constraints
    for i in types:
        for j in cities:
            for k in specs:
                if k not in supply[i]['suit']:
                    model.addConstr(x[i, j, k] == 0)
    
    # Priority 2: Preferred specialty target
    pref_spec_count = gp.quicksum(
        x[i, j, supply[i]['pref_spec']] 
        for i in types 
        for j in cities
    )
    model.addConstr(pref_spec_count >= p2_target, "Priority2")
    
    # Objective: Maximize dual-match placements
    obj = gp.quicksum(
        x[i, supply[i]['pref_city'], supply[i]['pref_spec']] 
        for i in types
    )
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {int(model.objVal)}")
    else:
        print("FINAL_OBJ_VALUE: -1")  # Indicate infeasibility

if __name__ == '__main__':
    main()
