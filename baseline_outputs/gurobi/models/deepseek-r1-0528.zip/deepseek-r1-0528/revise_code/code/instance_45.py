import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    segments = {}
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row['Product']
            base_name = p.split('_')[1]
            if base_name not in segments:
                segments[base_name] = []
                products.append(base_name)
            rng = row['Sales_Volume_Range']
            profit = float(row['Profit'])
            if rng.startswith('Above_'):
                lower = float(rng.split('_')[1])
                upper = None
            else:
                parts = rng.split('_')
                lower = float(parts[0])
                upper = float(parts[1])
            segments[base_name].append({'lower': lower, 'upper': upper, 'profit': profit})
    
    M = 10000
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    x = {}
    p_var = {}
    y = {}
    for prod in products:
        x[prod] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{prod}")
        p_var[prod] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"p_{prod}")
        y[prod] = []
        for i in range(len(segments[prod])):
            y[prod].append(model.addVar(vtype=GRB.BINARY, name=f"y_{prod}_{i}"))
    
    total_labor = gp.quicksum(params[f"labor_time_{prod}"] * x[prod] for prod in products)
    o = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=params['overtime_cap_hours'], name="o")
    z = model.addVar(vtype=GRB.BINARY, name="z")
    
    for prod in products:
        model.addConstr(gp.quicksum(y[prod]) <= 1, name=f"mutex_{prod}")
        
        for i, seg in enumerate(segments[prod]):
            lo = seg['lower']
            hi = seg['upper']
            profit = seg['profit']
            
            if lo == 0:
                model.addConstr(x[prod] >= 1 - M * (1 - y[prod][i]), name=f"{prod}_seg{i}_lb")
            else:
                model.addConstr(x[prod] >= (lo + 1) - M * (1 - y[prod][i]), name=f"{prod}_seg{i}_lb")
            
            if hi is not None:
                model.addConstr(x[prod] <= hi + M * (1 - y[prod][i]), name=f"{prod}_seg{i}_ub")
            
            model.addConstr(p_var[prod] <= profit * x[prod] + M * (1 - y[prod][i]), name=f"{prod}_seg{i}_profit")
        
        model.addConstr(x[prod] <= M * gp.quicksum(y[prod]), name=f"{prod}_force_x0")
        model.addConstr(p_var[prod] <= M * gp.quicksum(y[prod]), name=f"{prod}_force_p0")
    
    model.addConstr(o >= total_labor - params['available_labor_time'], name="overtime_def")
    model.addConstr(20 * z >= o - params['overtime_second_review_threshold'], name="review_trigger")
    
    model.addConstr(
        gp.quicksum(params[f"technical_prep_time_{prod}"] * x[prod] for prod in products)
        <= params['available_technical_prep_time'], name="tech_time"
    )
    model.addConstr(
        gp.quicksum(params[f"materials_{prod}"] * x[prod] for prod in products)
        <= params['available_materials'], name="materials"
    )
    model.addConstr(
        gp.quicksum(params[f"pack_units_{prod}"] * x[prod] for prod in products)
        <= params['packaging_cap_units'], name="packaging"
    )
    
    total_profit = gp.quicksum(p_var[prod] for prod in products)
    overtime_cost = params['overtime_cost_per_hour'] * o
    review_fee = params['overtime_second_review_fee'] * z
    model.setObjective(total_profit - overtime_cost - review_fee, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.ObjVal, 2)}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
