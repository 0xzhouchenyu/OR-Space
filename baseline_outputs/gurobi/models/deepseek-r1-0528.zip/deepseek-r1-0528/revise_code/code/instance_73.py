import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            params[param_name] = float(row['Value'].strip()) if '.' in row['Value'] else int(row['Value'].strip())
    
    # Extract parameters
    min_children = params['min_children_trip']
    max_children = params['max_children_trip']
    max_distinct = params['max_distinct_children_trip']
    total_budget = params['total_cost_budget']
    bonus_saving = params['bonus_saving']
    min_bob_days = params['min_bob_days']
    
    # Read table_1.csv for child costs
    children = []
    costs = {}
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row['Child'].strip()
            children.append(child)
            costs[child] = int(row['Cost'].strip())
    
    # Create model
    model = gp.Model("FamilyTrip")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}  # x[child, day] = 1 if child attends on day (1 or 2)
    y = {}  # y[child] = 1 if child attends both days
    d = {}  # d[child] = 1 if child attends at least one day
    
    # Create variables
    for child in children:
        for day in [1, 2]:
            # Enforce availability constraints by fixing variables
            if (child == 'Alice' and day == 2) or (child in ['Charlie', 'Diana'] and day == 1):
                x[child, day] = model.addVar(vtype=GRB.BINARY, lb=0, ub=0, name=f"x_{child}_{day}")
            else:
                x[child, day] = model.addVar(vtype=GRB.BINARY, name=f"x_{child}_{day}")
        
        y[child] = model.addVar(vtype=GRB.BINARY, name=f"y_{child}")
        d[child] = model.addVar(vtype=GRB.BINARY, name=f"d_{child}")
    
    # Objective: minimize total net cost
    total_cost = gp.quicksum(costs[child] * x[child, day] for child in children for day in [1, 2])
    total_savings = gp.quicksum(bonus_saving * y[child] for child in children)
    model.setObjective(total_cost - total_savings, GRB.MINIMIZE)
    
    # Per-day headcount constraints
    for day in [1, 2]:
        model.addConstr(
            gp.quicksum(x[child, day] for child in children) >= min_children,
            f"MinPerDay_{day}"
        )
        model.addConstr(
            gp.quicksum(x[child, day] for child in children) <= max_children,
            f"MaxPerDay_{day}"
        )
    
    # Day 2 relationship constraints
    model.addConstr(x['Bob', 2] + x['Charlie', 2] <= 1, "BobCharlieConflict_Day2")
    model.addConstr(x['Charlie', 2] <= x['Diana', 2], "CharlieRequiresDiana")
    model.addConstr(x['Diana', 2] <= x['Ella', 2], "DianaRequiresElla")
    
    # Bob minimum days constraint
    model.addConstr(x['Bob', 1] + x['Bob', 2] >= min_bob_days, "BobMinDays")
    
    # Distinct children constraint
    for child in children:
        model.addConstr(d[child] >= x[child, 1], f"Distinct_{child}_day1")
        model.addConstr(d[child] >= x[child, 2], f"Distinct_{child}_day2")
    model.addConstr(gp.quicksum(d[child] for child in children) <= max_distinct, "MaxDistinct")
    
    # Both-days indicator constraints
    for child in children:
        model.addConstr(y[child] <= x[child, 1], f"BothDays_{child}_day1")
        model.addConstr(y[child] <= x[child, 2], f"BothDays_{child}_day2")
        model.addConstr(y[child] >= x[child, 1] + x[child, 2] - 1, f"BothDays_{child}_indicator")
    
    # Total budget constraint
    model.addConstr(total_cost - total_savings <= total_budget, "TotalBudget")
    
    # Optimize
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
