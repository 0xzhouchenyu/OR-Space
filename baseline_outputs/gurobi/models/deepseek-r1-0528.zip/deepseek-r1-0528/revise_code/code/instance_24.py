import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Extract parameters
    product_units = params['product_units']
    truck_pollution = params['truck_pollution']
    van_pollution = params['van_pollution']
    motorcycle_pollution = params['motorcycle_pollution']
    ev_pollution = params['electric_vehicle_pollution']
    max_total_pollution = params['max_total_pollution']
    min_truck_trips = params['min_truck_trips']
    truck_capacity = params['truck_capacity']
    van_capacity = params['van_capacity']
    motorcycle_capacity = params['motorcycle_capacity']
    ev_capacity = params['electric_vehicle_capacity']
    sp_shares = [
        params['sales_point_share_sp1'],
        params['sales_point_share_sp2'],
        params['sales_point_share_sp3']
    ]
    min_truck_shares = [
        params['min_truck_share_sp1'],
        params['min_truck_share_sp2'],
        params['min_truck_share_sp3']
    ]
    M_truck = params['M_truck_sp_day']
    M_ev = params['M_ev_sp_day']
    M_van = params['M_van_sp_day']
    M_moto = params['M_moto_sp_day']
    
    # Calculate demand per sales point
    demands = [sp_shares[i] * product_units for i in range(3)]
    
    # Create model
    m = gp.Model()
    m.setParam('OutputFlag', 0)
    
    # Create variables
    truck = m.addVars(3, 3, vtype=GRB.INTEGER, name="truck")  # [sales_point, day]
    ev = m.addVars(3, 3, vtype=GRB.INTEGER, name="ev")
    van = m.addVars(3, 3, vtype=GRB.INTEGER, name="van")
    moto = m.addVars(3, 3, vtype=GRB.INTEGER, name="moto")
    z = m.addVars(3, 3, vtype=GRB.BINARY, name="z")
    
    # Set objective: minimize total pollution
    total_pollution = gp.quicksum(
        truck_pollution * truck[s,d] + ev_pollution * ev[s,d] + 
        van_pollution * van[s,d] + motorcycle_pollution * moto[s,d] 
        for s in range(3) for d in range(3)
    )
    m.setObjective(total_pollution, GRB.MINIMIZE)
    
    # Demand constraints per sales point
    for s in range(3):
        sp_capacity = gp.quicksum(
            truck_capacity * truck[s,d] + ev_capacity * ev[s,d] +
            van_capacity * van[s,d] + motorcycle_capacity * moto[s,d]
            for d in range(3)
        )
        m.addConstr(sp_capacity >= demands[s], f"demand_sp{s+1}")
    
    # Vehicle family constraints per sales point-day
    for s in range(3):
        for d in range(3):
            m.addConstr(van[s,d] <= M_van * (1 - z[s,d]), f"van_family_{s}_{d}")
            m.addConstr(moto[s,d] <= M_moto * (1 - z[s,d]), f"moto_family_{s}_{d}")
            m.addConstr(truck[s,d] <= M_truck * z[s,d], f"truck_family_{s}_{d}")
            m.addConstr(ev[s,d] <= M_ev * z[s,d], f"ev_family_{s}_{d}")
    
    # Minimum truck share per sales point
    for s in range(3):
        total_trips_sp = gp.quicksum(
            truck[s,d] + ev[s,d] + van[s,d] + moto[s,d] for d in range(3)
        )
        truck_trips_sp = gp.quicksum(truck[s,d] for d in range(3))
        m.addConstr(truck_trips_sp >= min_truck_shares[s] * total_trips_sp, 
                   f"min_truck_share_sp{s+1}")
    
    # Minimum total truck trips
    total_truck = gp.quicksum(truck[s,d] for s in range(3) for d in range(3))
    m.addConstr(total_truck >= min_truck_trips, "min_total_truck_trips")
    
    # Total pollution constraint
    m.addConstr(total_pollution <= max_total_pollution, "max_pollution")
    
    # Solve
    m.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {m.objVal}")

if __name__ == "__main__":
    main()
