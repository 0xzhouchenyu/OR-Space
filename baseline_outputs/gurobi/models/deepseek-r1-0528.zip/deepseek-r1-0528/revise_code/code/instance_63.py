import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")
params = {}

with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

produce = params['produce_to_transport']
horse_poll = params['horse_pollution_per_trip']
bike_poll = params['bicycle_pollution_per_trip']
cart_poll = params['handcart_pollution_per_trip']
max_poll = params['max_total_pollution']
min_horse = params['min_horse_trips']
horse_cap = params['horse_capacity_per_trip']
bike_cap = params['bicycle_capacity_per_trip']
cart_cap = params['handcart_capacity_per_trip']
min_produce = params['min_total_produce']
horse_cost = params['horse_cost_per_trip']
bike_cost = params['bicycle_cost_per_trip']
cart_cost = params['handcart_cost_per_trip']
horse_fixed = params['horse_fixed_cost']
bike_fixed = params['bicycle_fixed_cost']
cart_fixed = params['handcart_fixed_cost']
poll_penalty = params['pollution_penalty_per_unit']
poll_threshold = params['horse_pollution_permit_threshold']
permit_fee = params['horse_pollution_permit_fee']

# Create model
model = gp.Model("FarmTransport")
model.setParam('OutputFlag', 0)

# Variables
x_horse = model.addVar(vtype=GRB.INTEGER, lb=0, name="horse_trips")
x_bike = model.addVar(vtype=GRB.INTEGER, lb=0, name="bike_trips")
x_cart = model.addVar(vtype=GRB.INTEGER, lb=0, name="cart_trips")
y = model.addVar(vtype=GRB.BINARY, name="choose_bike")
z = model.addVar(vtype=GRB.BINARY, name="permit_fee_trigger")

# Constraints
model.addConstr(horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce, "produce_req")
model.addConstr(horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart <= max_poll, "pollution_limit")
model.addConstr(x_horse >= min_horse, "min_horse")

M = 10000
model.addConstr(x_bike <= M * y, "bike_choice")
model.addConstr(x_cart <= M * (1 - y), "cart_choice")

total_pollution = horse_poll * x_horse
model.addConstr(total_pollution <= poll_threshold + max_poll * z, "pollution_upper_bound")
model.addConstr(total_pollution >= poll_threshold + 1 - max_poll * (1-z), "pollution_lower_bound")

# Objective components
variable_costs = horse_cost * x_horse + bike_cost * x_bike + cart_cost * x_cart
fixed_costs = horse_fixed + bike_fixed * y + cart_fixed * (1 - y)
pollution_costs = poll_penalty * total_pollution
permit_costs = permit_fee * z

total_cost = variable_costs + fixed_costs + pollution_costs + permit_costs
model.setObjective(total_cost, GRB.MINIMIZE)

# Solve
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: inf")
