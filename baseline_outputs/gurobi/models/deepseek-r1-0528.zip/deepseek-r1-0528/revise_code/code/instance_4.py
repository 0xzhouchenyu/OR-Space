import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

current_dir = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(current_dir, "data", "general_parameters.csv")
params = load_parameters(data_path)

model = gp.Model("FarmProfit")
model.setParam('OutputFlag', 0)

cows = model.addVar(vtype=GRB.INTEGER, lb=params['min_cows'], name="cows")
sheep = model.addVar(vtype=GRB.INTEGER, lb=params['min_sheep'], name="sheep")
chickens = model.addVar(vtype=GRB.INTEGER, lb=0, ub=params['max_chickens'], name="chickens")
expanded = model.addVar(vtype=GRB.BINARY, name="expanded")

revenue = (
    params['cow_selling_price'] * cows +
    params['sheep_selling_price'] * sheep +
    params['chicken_selling_price'] * chickens
)

feed_cost = (
    params['cow_feed_cost'] * cows * (1 + (params['premium_feed_multiplier'] - 1) * expanded) +
    params['sheep_feed_cost'] * sheep * (1 + (params['premium_feed_multiplier'] - 1) * expanded) +
    params['chicken_feed_cost'] * chickens * (1 + (params['premium_feed_multiplier'] - 1) * expanded)
)

fixed_cost = params['expansion_cost'] * expanded
profit = revenue - feed_cost - fixed_cost
model.setObjective(profit, GRB.MAXIMIZE)

model.addConstr(
    params['base_land_usage_cow'] * cows +
    params['base_land_usage_sheep'] * sheep +
    params['base_land_usage_chicken'] * chickens <=
    params['base_land_capacity'] + params['expansion_land_increase'] * expanded,
    "land_constraint"
)

model.addConstr(
    params['cow_manure_production'] * cows +
    params['sheep_manure_production'] * sheep +
    params['chicken_manure_production'] * chickens <=
    params['max_manure_capacity'] * (1 + (params['premium_manure_multiplier'] - 1) * expanded),
    "manure_constraint"
)

model.addConstr(
    cows + sheep + chickens <=
    params['max_total_animals'] * (1 + (params['premium_capacity_multiplier'] - 1) * expanded),
    "total_animals_constraint"
)

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: 0")
