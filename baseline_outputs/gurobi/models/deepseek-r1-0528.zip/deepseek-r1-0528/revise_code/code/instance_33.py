import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load general parameters
    gen_params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row["Parameter_Name"].strip()
            value_str = row["Value"].strip()
            if value_str:
                try:
                    gen_params[param_name] = float(value_str)
                except:
                    gen_params[param_name] = value_str
            else:
                gen_params[param_name] = None
    
    # Load items and values
    items = []
    values = []
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append(row["Item"].strip())
            values.append(float(row["Value"].strip()))
    
    return gen_params, items, values

def main():
    gen_params, items, values = load_data()
    n = len(items)
    total_value = sum(values)
    
    # Extract parameters
    son1_min_share = gen_params["son1_min_share"]
    high_value_threshold = gen_params["high_value_threshold"]
    max_high_value_items = gen_params["max_high_value_items_per_son"]
    deferred_diamonds_limit = gen_params["deferred_diamonds_per_son"]
    imm_tax_weight = gen_params["immediate_tax_weight"]
    total_tax_weight = gen_params["total_tax_weight"]
    
    # Identify special items
    diamond_indices = [i for i, item in enumerate(items) if "Diamond" in item]
    jr_indices = [i for i, item in enumerate(items) if "Jack Russell" in item]
    high_value_indices = [i for i, v in enumerate(values) if v >= high_value_threshold]
    
    # Create model
    model = gp.Model("InheritanceSplit")
    model.setParam('OutputFlag', 0)
    
    # Variables
    son1_imm = model.addVars(n, vtype=GRB.BINARY, name="son1_imm")
    son1_def = model.addVars(n, vtype=GRB.BINARY, name="son1_def")
    son2_imm = model.addVars(n, vtype=GRB.BINARY, name="son2_imm")
    son2_def = model.addVars(n, vtype=GRB.BINARY, name="son2_def")
    
    imm_diff = model.addVar(vtype=GRB.CONTINUOUS, name="imm_diff", lb=0)
    tot_diff = model.addVar(vtype=GRB.CONTINUOUS, name="tot_diff", lb=0)
    
    # Assignment constraints
    model.addConstrs((son1_imm[i] + son1_def[i] + son2_imm[i] + son2_def[i] == 1 for i in range(n)), "Assignment")
    
    # Jack Russell dogs must be together
    if len(jr_indices) == 2:
        i, j = jr_indices
        model.addConstr(son1_imm[i] + son1_def[i] == son1_imm[j] + son1_def[j], "JR_Together")
    
    # Son1 minimum share
    son1_total = gp.quicksum(values[i] * (son1_imm[i] + son1_def[i]) for i in range(n))
    model.addConstr(son1_total >= son1_min_share * total_value, "Son1_Min_Share")
    
    # High-value item limits
    son1_high = gp.quicksum(son1_imm[i] + son1_def[i] for i in high_value_indices)
    son2_high = gp.quicksum(son2_imm[i] + son2_def[i] for i in high_value_indices)
    model.addConstr(son1_high <= max_high_value_items, "Son1_High_Value_Limit")
    model.addConstr(son2_high <= max_high_value_items, "Son2_High_Value_Limit")
    
    # Deferred diamond limits
    son1_def_diamonds = gp.quicksum(son1_def[i] for i in diamond_indices)
    son2_def_diamonds = gp.quicksum(son2_def[i] for i in diamond_indices)
    model.addConstr(son1_def_diamonds <= deferred_diamonds_limit, "Son1_Def_Diamonds")
    model.addConstr(son2_def_diamonds <= deferred_diamonds_limit, "Son2_Def_Diamonds")
    
    # Immediate and total values
    imm_son1 = gp.quicksum(values[i] * son1_imm[i] for i in range(n))
    imm_son2 = gp.quicksum(values[i] * son2_imm[i] for i in range(n))
    tot_son1 = gp.quicksum(values[i] * (son1_imm[i] + son1_def[i]) for i in range(n))
    tot_son2 = gp.quicksum(values[i] * (son2_imm[i] + son2_def[i]) for i in range(n))
    
    # Absolute differences
    model.addConstr(imm_diff >= imm_son1 - imm_son2, "Imm_Diff1")
    model.addConstr(imm_diff >= imm_son2 - imm_son1, "Imm_Diff2")
    model.addConstr(tot_diff >= tot_son1 - tot_son2, "Tot_Diff1")
    model.addConstr(tot_diff >= tot_son2 - tot_son1, "Tot_Diff2")
    
    # Objective
    model.setObjective(imm_tax_weight * imm_diff + total_tax_weight * tot_diff, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Output final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
