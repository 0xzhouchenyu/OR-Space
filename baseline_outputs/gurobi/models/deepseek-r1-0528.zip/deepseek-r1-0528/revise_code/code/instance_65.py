import os
import csv
import gurobipy as gp
from gurobipy import GRB

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
    for row in csv.DictReader(f):
        params[row['Parameter_Name'].strip()] = float(row['Value'])

products = {}
with open(os.path.join(data_dir, 'table_1.csv')) as f:
    for row in csv.DictReader(f):
        products[row['Product'].strip()] = {
            'a_hrs': float(row['Workshop_A_Hours']),
            'b_hrs': float(row['Workshop_B_Hours']),
            'insp_cost': float(row['Inspection_Sales_Cost'])
        }

m = products['Microwave_Oven']
w = products['Water_Heater']

model = gp.Model("production")
model.setParam('OutputFlag', 0)

x1 = model.addVar(lb=params['microwave_minimum_sales'], name="microwave")
x2 = model.addVar(lb=params['water_heater_minimum_sales'], name="water_heater")
y1 = model.addVar(vtype=GRB.BINARY, name="activate_microwave")
y2 = model.addVar(vtype=GRB.BINARY, name="activate_water_heater")

rev_m = m['a_hrs'] * params['workshop_a_hourly_cost'] + m['b_hrs'] * params['workshop_b_hourly_cost'] + m['insp_cost'] + params['green_bonus_m']
rev_w = w['a_hrs'] * params['workshop_a_hourly_cost'] + w['b_hrs'] * params['workshop_b_hourly_cost'] + w['insp_cost'] + params['green_bonus_w']

model.setObjective(rev_m * x1 + rev_w * x2, GRB.MAXIMIZE)

model.addConstr(m['a_hrs'] * x1 + w['a_hrs'] * x2 + params['setup_hours_A'] * (y1 + y2) <= 
                params['workshop_a_available_hours'] + params['workshop_a_overtime_limit'], "workshop_A_capacity")
model.addConstr(m['b_hrs'] * x1 + w['b_hrs'] * x2 >= params['workshop_b_available_hours'], "workshop_B_min_usage")
model.addConstr(m['insp_cost'] * x1 + w['insp_cost'] * x2 <= params['inspection_sales_cost_limit'], "inspection_sales_cost")
model.addConstr(params['tech_rate_m'] * x1 + params['tech_rate_w'] * x2 <= params['tech_pool_hours'], "technician_pool")
model.addConstr(x1 <= params['bigM'] * y1, "activate_microwave_link")
model.addConstr(x2 <= params['bigM'] * y2, "activate_water_heater_link")

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
