import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

current_dir = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(current_dir, "data", "general_parameters.csv")
params = load_general_parameters(data_path)

profit_A = params['profit_per_kg_product_A']
profit_B = params['profit_per_kg_product_B']
max_hours_w1 = params['max_production_hours_week_1']
max_hours_w2 = params['max_production_hours_week_2']
hours_A = params['hours_per_kg_product_A']
hours_B = params['hours_per_kg_product_B']
min_ratio = params['min_output_ratio_product_B_to_A']
storage_ratio = params['storage_space_ratio_product_A_to_B']
max_storage_w1 = params['max_storage_product_A_equiv_week_1']
max_storage_w2 = params['max_storage_product_A_equiv_week_2']
init_inv_A = params['initial_inventory_A']
init_inv_B = params['initial_inventory_B']
storage_cost_A = params['storage_cost_per_kg_A']
storage_cost_B = params['storage_cost_per_kg_B']
promo_bonus_A = params['promo_profit_bonus_A']
promo_bonus_B = params['promo_profit_bonus_B']
max_promo_A = int(params['max_promotions_product_A'])
max_promo_B = int(params['max_promotions_product_B'])

model = gp.Model("Two_Week_Production_Planning")
model.setParam('OutputFlag', 0)

prod_A1 = model.addVar(lb=0, name="prod_A1")
prod_A2 = model.addVar(lb=0, name="prod_A2")
prod_B1 = model.addVar(lb=0, name="prod_B1")
prod_B2 = model.addVar(lb=0, name="prod_B2")

sales_A1 = model.addVar(lb=0, name="sales_A1")
sales_A2 = model.addVar(lb=0, name="sales_A2")
sales_B1 = model.addVar(lb=0, name="sales_B1")
sales_B2 = model.addVar(lb=0, name="sales_B2")

inv_A1 = model.addVar(lb=0, name="inv_A1")
inv_B1 = model.addVar(lb=0, name="inv_B1")
inv_A2 = model.addVar(lb=0, name="inv_A2")
inv_B2 = model.addVar(lb=0, name="inv_B2")

promo_A1 = model.addVar(vtype=GRB.BINARY, name="promo_A1")
promo_A2 = model.addVar(vtype=GRB.BINARY, name="promo_A2")
promo_B1 = model.addVar(vtype=GRB.BINARY, name="promo_B1")
promo_B2 = model.addVar(vtype=GRB.BINARY, name="promo_B2")

model.addConstr(hours_A * prod_A1 + hours_B * prod_B1 <= max_hours_w1, "ProdHoursW1")
model.addConstr(hours_A * prod_A2 + hours_B * prod_B2 <= max_hours_w2, "ProdHoursW2")

model.addConstr(sales_B1 >= min_ratio * sales_A1, "DemandRatioW1")
model.addConstr(sales_B2 >= min_ratio * sales_A2, "DemandRatioW2")

model.addConstr(storage_ratio * inv_A1 + inv_B1 <= storage_ratio * max_storage_w1, "StorageW1")
model.addConstr(storage_ratio * inv_A2 + inv_B2 <= storage_ratio * max_storage_w2, "StorageW2")

model.addConstr(inv_A1 == init_inv_A + prod_A1 - sales_A1, "InvBalanceA1")
model.addConstr(inv_B1 == init_inv_B + prod_B1 - sales_B1, "InvBalanceB1")
model.addConstr(inv_A2 == inv_A1 + prod_A2 - sales_A2, "InvBalanceA2")
model.addConstr(inv_B2 == inv_B1 + prod_B2 - sales_B2, "InvBalanceB2")

model.addConstr(sales_A1 <= init_inv_A + prod_A1, "SalesLimitA1")
model.addConstr(sales_B1 <= init_inv_B + prod_B1, "SalesLimitB1")
model.addConstr(sales_A2 <= inv_A1 + prod_A2, "SalesLimitA2")
model.addConstr(sales_B2 <= inv_B1 + prod_B2, "SalesLimitB2")

model.addConstr(promo_A1 + promo_A2 <= max_promo_A, "MaxPromoA")
model.addConstr(promo_B1 + promo_B2 <= max_promo_B, "MaxPromoB")

profit_w1 = (profit_A + promo_bonus_A * promo_A1) * sales_A1 + (profit_B + promo_bonus_B * promo_B1) * sales_B1
profit_w2 = (profit_A + promo_bonus_A * promo_A2) * sales_A2 + (profit_B + promo_bonus_B * promo_B2) * sales_B2
holding_cost = storage_cost_A * inv_A1 + storage_cost_B * inv_B1
total_profit = profit_w1 + profit_w2 - holding_cost

model.setObjective(total_profit, GRB.MAXIMIZE)
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal:.3f}")
else:
    print("FINAL_OBJ_VALUE: 0.000")
