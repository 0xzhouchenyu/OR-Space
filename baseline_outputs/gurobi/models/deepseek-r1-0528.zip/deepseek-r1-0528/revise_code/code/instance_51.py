import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_demand(filepath):
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    return params

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
demand = load_demand(os.path.join(data_dir, 'table_1.csv'))
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

shift_duration = int(params['shift_duration'])
regular_pay = float(params['regular_nurse_pay'])
contract_pay = float(params['contract_nurse_pay'])
outsourced_regular_idx = int(params['outsourced_regular_start_index'])
banned_contract_idx = int(params['banned_contract_start_index'])
max_contract = int(params['max_total_contract_starts'])
min_regular_day = int(params['min_regular_daytime_coverage'])
daytime_periods = [int(i) for i in params['daytime_period_indices'].split(';')]

num_periods = len(demand)
model = gp.Model()
model.setParam('OutputFlag', 0)

x = model.addVars(num_periods, vtype=GRB.INTEGER, name="x")
y = model.addVars(num_periods, vtype=GRB.INTEGER, name="y")

model.addConstr(x[outsourced_regular_idx] == 0, "ban_regular_shift")
model.addConstr(y[banned_contract_idx] == 0, "ban_contract_shift")

for i in range(num_periods):
    covering_shifts = [j for j in range(num_periods) if i in [j, (j+1) % num_periods]]
    model.addConstr(gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i], f"coverage_{i}")

for i in daytime_periods:
    covering_shifts = [j for j in range(num_periods) if i in [j, (j+1) % num_periods]]
    model.addConstr(gp.quicksum(x[j] for j in covering_shifts) >= min_regular_day, f"min_regular_{i}")

model.addConstr(gp.quicksum(y[j] for j in range(num_periods)) <= max_contract, "contract_cap")

total_cost = gp.quicksum(x[j] * regular_pay * shift_duration + y[j] * contract_pay * shift_duration for j in range(num_periods))
model.setObjective(total_cost, GRB.MINIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
elif model.SolCount > 0:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: -1")
