import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            if val.lower() != 'unlimited':
                try:
                    params[name] = float(val)
                except:
                    params[name] = val
    
    # Extract parameters
    a1_yield = params['product_A1_yield']
    a1_time = params['product_A1_time']
    a2_yield = params['product_A2_yield']
    a2_time = params['product_A2_time']
    a3_yield = params['product_A3_yield']
    a3_time = params['product_A3_time']
    profit_a1 = params['profit_per_kg_A1']
    profit_a2 = params['profit_per_kg_A2']
    profit_a3 = params['profit_per_kg_A3']
    milk_supply = params['daily_milk_supply']
    labor_hours = params['daily_labor_hours']
    min_a2_kg = params['min_A2_kg']
    min_a3_kg = params['min_A3_kg']
    cap_a_shared = params['cap_A_shared']
    cleaning_loss = params['type_A_cleaning_loss_if_A3']
    bonus_threshold = params['cold_chain_bonus_threshold_kg']
    bonus_amount = params['cold_chain_bonus_yuan']
    
    # Create model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x1 = model.addVar(name="x1", lb=0)  # barrels for A1
    x2 = model.addVar(name="x2", lb=0)  # barrels for A2
    x3 = model.addVar(name="x3", lb=0)  # barrels for A3
    z = model.addVar(name="z", vtype=GRB.BINARY)  # bonus indicator
    
    # Objective function: maximize profit
    total_profit = (
        (a1_yield * profit_a1) * x1 + 
        (a2_yield * profit_a2) * x2 + 
        (a3_yield * profit_a3) * x3 + 
        bonus_amount * z
    )
    model.setObjective(total_profit, GRB.MAXIMIZE)
    
    # Constraints
    # Milk supply
    model.addConstr(x1 + x2 + x3 <= milk_supply, "Milk_Supply")
    
    # Labor hours
    model.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours, "Labor_Hours")
    
    # Minimum A2 production (kg)
    model.addConstr(a2_yield * x2 >= min_a2_kg, "Min_A2")
    
    # Minimum A3 production (kg)
    model.addConstr(a3_yield * x3 >= min_a3_kg, "Min_A3")
    
    # Shared Type A capacity with cleaning loss (kg)
    model.addConstr(a1_yield * x1 + a3_yield * x3 <= cap_a_shared - cleaning_loss, "Type_A_Capacity")
    
    # Cold-chain bonus condition
    model.addConstr(a3_yield * x3 >= bonus_threshold * z, "Bonus_Threshold")
    
    # Solve
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: 0.0")  # Fallback if no solution found

if __name__ == "__main__":
    main()
