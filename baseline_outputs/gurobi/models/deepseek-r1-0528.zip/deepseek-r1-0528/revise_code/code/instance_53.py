import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Set up paths
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, 'data')
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass
            params[param_name] = value

    # Read table_1.csv
    cost_data = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row['Child'].strip()
            cost_data[child] = {
                'budget': float(row['Cost_budget']),
                'balanced': float(row['Cost_balanced']),
                'premium': float(row['Cost_premium'])
            }
    
    # Extract parameters
    max_children = params['max_children']
    min_children = params['min_children']
    fairness_penalty = params['fairness_penalty']
    max_total_cost = params['max_total_cost']
    min_children_per_mode = params['min_children_per_mode']
    
    children = list(cost_data.keys())
    modes = ['budget', 'balanced', 'premium']
    
    # Create model
    model = gp.Model("ZhangFamilyTrip")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(children, vtype=GRB.BINARY, name="x")
    y = model.addVars(modes, vtype=GRB.BINARY, name="y")
    w = model.addVars(children, modes, vtype=GRB.BINARY, name="w")
    max_cost = model.addVar(vtype=GRB.CONTINUOUS, name="max_cost")
    min_cost = model.addVar(vtype=GRB.CONTINUOUS, name="min_cost")
    
    # Constraints
    # Ginny must be selected
    model.addConstr(x['Ginny'] == 1, "Ginny_must_go")
    
    # Group size constraints
    total_children = gp.quicksum(x[child] for child in children)
    model.addConstr(total_children >= min_children, "Min_children")
    model.addConstr(total_children <= max_children, "Max_children")
    
    # Exactly one mode selected
    model.addConstr(y.sum() == 1, "exactly_one_mode")
    
    # Compatibility constraints
    model.addConstr(x['Harry'] + x['Fred'] <= 1, "Harry_no_Fred")
    model.addConstr(x['Harry'] + x['George'] <= 1, "Harry_no_George")
    model.addConstr(x['George'] <= x['Fred'], "George_requires_Fred")
    model.addConstr(x['George'] <= x['Hermione'], "George_requires_Hermione")
    
    # Linearization constraints for w
    for child in children:
        for mode in modes:
            model.addConstr(w[child, mode] <= x[child], f"w_{child}_{mode}_le_x")
            model.addConstr(w[child, mode] <= y[mode], f"w_{child}_{mode}_le_y")
            model.addConstr(w[child, mode] >= x[child] + y[mode] - 1, f"w_{child}_{mode}_ge")
    
    # Mode-dependent minimum children constraint
    model.addConstr(total_children >= min_children_per_mode * (y['balanced'] + y['premium']), 
                   "min_children_per_mode")
    
    # Total base cost constraint
    base_cost = gp.quicksum(cost_data[child][mode] * w[child, mode] 
                           for child in children for mode in modes)
    model.addConstr(base_cost <= max_total_cost, "max_total_cost")
    
    # Max-min cost spread constraints
    M = 2000  # Upper bound on individual costs
    for child in children:
        child_cost = gp.quicksum(cost_data[child][mode] * w[child, mode] for mode in modes)
        model.addConstr(max_cost >= child_cost, f"max_cost_{child}")
        model.addConstr(min_cost <= child_cost + M * (1 - x[child]), f"min_cost_{child}")
    
    # Objective function
    spread = max_cost - min_cost
    total_cost = base_cost + fairness_penalty * spread
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Output final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
