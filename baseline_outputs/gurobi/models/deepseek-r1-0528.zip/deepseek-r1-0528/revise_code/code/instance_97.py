import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    materials = []
    sulfur_content = {}
    purchase_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            mat = row['Material'].strip()
            materials.append(mat)
            sulfur_content[mat] = float(row['Sulfur_Content_Percentage'].strip())
            purchase_price[mat] = float(row['Purchase_Price_Thousand_Yuan_Per_Ton'].strip())
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            params[param_name] = float(row['Value'].strip())
    
    tiers = ['premium', 'standard']
    families = ['A', 'B']
    streams = [f"{fam}_{tier}" for fam in families for tier in tiers]
    
    model = gp.Model("Revised_Mixing_Problem")
    model.setParam('OutputFlag', 0)
    
    x = model.addVars(materials, streams, name="x", lb=0)
    
    total_stream = {}
    for fam in families:
        for tier in tiers:
            stream = f"{fam}_{tier}"
            total_stream[stream] = gp.quicksum(x[m, stream] for m in materials)
    
    total_family = {}
    for fam in families:
        total_family[fam] = gp.quicksum(total_stream[f"{fam}_{tier}"] for tier in tiers)
    
    revenue = (
        params['selling_price_A_premium'] * total_stream['A_premium'] +
        params['selling_price_A_standard'] * total_stream['A_standard'] +
        params['selling_price_B_premium'] * total_stream['B_premium'] +
        params['selling_price_B_standard'] * total_stream['B_standard']
    )
    
    cost = gp.quicksum(
        purchase_price[m] * x[m, stream] for m in materials for stream in streams
    )
    
    model.setObjective(revenue - cost, GRB.MAXIMIZE)
    
    # Sulfur constraints per stream
    for stream in streams:
        fam = stream.split('_')[0]
        max_sulfur = params[f'max_sulfur_content_{stream}']
        lhs = gp.quicksum(sulfur_content[m] * x[m, stream] for m in materials)
        model.addConstr(lhs <= max_sulfur * total_stream[stream], f"sulfur_{stream}")
    
    # Material D supply constraint
    model.addConstr(gp.quicksum(x['D', stream] for stream in streams) <= params['max_supply_D'], "supply_D")
    
    # Family demand constraints
    model.addConstr(total_family['A'] <= params['market_demand_A'], "demand_A")
    model.addConstr(total_family['B'] <= params['market_demand_B'], "demand_B")
    
    # Premium tier volume constraints
    model.addConstr(total_stream['A_premium'] >= params['min_premium_share_A'], "min_premium_A")
    model.addConstr(total_stream['A_premium'] <= params['max_premium_share_A'], "max_premium_A")
    model.addConstr(total_stream['B_premium'] >= params['min_premium_share_B'], "min_premium_B")
    model.addConstr(total_stream['B_premium'] <= params['max_premium_share_B'], "max_premium_B")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal:.4f}")
    else:
        print("FINAL_OBJ_VALUE: 0.0000")

if __name__ == "__main__":
    main()
