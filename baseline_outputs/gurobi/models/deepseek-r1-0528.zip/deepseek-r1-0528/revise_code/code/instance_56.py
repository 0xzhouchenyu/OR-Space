import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
initial_funds = params['initial_funds']
end_inventory = params['end_of_quarter_inventory']
buy_fast_capacity = params['buy_fast_capacity']
fast_premium_ratio = params['fast_purchase_premium_ratio']
credit_limit = params['credit_limit']
interest_rate = params['monthly_interest_rate']
min_inv_1 = params['min_inventory_month_1']
min_inv_2 = params['min_inventory_month_2']
min_inv_3 = params['min_inventory_month_3']

# Read monthly prices
purchase_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        m = int(row['Month'])
        purchase_prices[m] = float(row['Purchase_Price_yuan_per_dan'])
        selling_prices[m] = float(row['Selling_Price_yuan_per_dan'])

months = [1, 2, 3]

# Create Gurobi model
model = gp.Model("Grain_Trading_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
buy_regular = model.addVars(months, lb=0, name="buy_regular")
buy_fast = model.addVars(months, lb=0, ub=buy_fast_capacity, name="buy_fast")
sell = model.addVars(months, lb=0, name="sell")
stock = model.addVars(months, lb=0, name="stock")
funds = model.addVars(months, lb=0, name="funds")
credit_used = model.addVars(months, lb=0, ub=credit_limit, name="credit_used")

# Stock balance constraints
model.addConstr(stock[1] == initial_stock - sell[1] + buy_regular[1] + buy_fast[1], "stock_balance_1")
model.addConstr(stock[2] == stock[1] - sell[2] + buy_regular[2] + buy_fast[2], "stock_balance_2")
model.addConstr(stock[3] == stock[2] - sell[3] + buy_regular[3] + buy_fast[3], "stock_balance_3")

# Sales constraints (can only sell previous month's stock)
model.addConstr(sell[1] <= initial_stock, "sell_limit_1")
model.addConstr(sell[2] <= stock[1], "sell_limit_2")
model.addConstr(sell[3] <= stock[2], "sell_limit_3")

# Warehouse capacity constraints
model.addConstrs((stock[m] <= warehouse_capacity for m in months), "warehouse_capacity")

# Minimum inventory constraints
model.addConstr(stock[1] >= min_inv_1, "min_inv_1")
model.addConstr(stock[2] >= min_inv_2, "min_inv_2")
model.addConstr(stock[3] >= min_inv_3, "min_inv_3")
model.addConstr(stock[3] >= end_inventory, "end_inventory")

# Cash flow and credit constraints
model.addConstr(
    funds[1] == initial_funds + selling_prices[1]*sell[1] - 
    (buy_regular[1]*purchase_prices[1] + buy_fast[1]*purchase_prices[1]*(1+fast_premium_ratio)) - 
    interest_rate*credit_used[1] + (credit_used[1] - 0),
    "cash_credit_1"
)

model.addConstr(
    funds[2] == funds[1] + selling_prices[2]*sell[2] - 
    (buy_regular[2]*purchase_prices[2] + buy_fast[2]*purchase_prices[2]*(1+fast_premium_ratio)) - 
    interest_rate*credit_used[2] + (credit_used[2] - credit_used[1]),
    "cash_credit_2"
)

model.addConstr(
    funds[3] == funds[2] + selling_prices[3]*sell[3] - 
    (buy_regular[3]*purchase_prices[3] + buy_fast[3]*purchase_prices[3]*(1+fast_premium_ratio)) - 
    interest_rate*credit_used[3] + (credit_used[3] - credit_used[2]),
    "cash_credit_3"
)

# Objective: (funds_3 - initial_funds) - total interest paid
total_interest = interest_rate * (credit_used[1] + credit_used[2] + credit_used[3])
model.setObjective(funds[3] - initial_funds - total_interest, GRB.MAXIMIZE)

# Solve
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: No solution found")
