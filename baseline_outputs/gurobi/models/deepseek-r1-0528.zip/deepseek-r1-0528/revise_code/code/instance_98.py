import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read product data
    products = {}
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products[row['Product']] = {
                'steel': float(row['Steel_Required_kg']),
                'aluminum': float(row['Aluminum_Required_kg']),
                'labor': float(row['Labor_Required_hours']),
                'profit': float(row['Profit_yuan']),
                'setup_cost': float(row['Setup_Cost_yuan'])
            }
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Create model
    model = gp.Model("Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    y = {}  # Setup indicators
    for prod in products:
        x[prod] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{prod}", lb=0)
        y[prod] = model.addVar(vtype=GRB.BINARY, name=f"y_{prod}")
    
    z_A = model.addVar(vtype=GRB.BINARY, name="z_A")  # Audit indicator for A
    w = model.addVar(vtype=GRB.BINARY, name="w")      # Overtime fee indicator
    overtime_used = model.addVar(vtype=GRB.CONTINUOUS, name="overtime_used", lb=0, ub=params['max_overtime'])
    
    # Objective function: maximize profit
    revenue = gp.quicksum(products[prod]['profit'] * x[prod] for prod in products)
    setup_costs = gp.quicksum(products[prod]['setup_cost'] * y[prod] for prod in products)
    audit_fee = params['product_A_line_audit_fee'] * z_A
    overtime_fee = params['overtime_review_fee'] * w
    overtime_pay = params['overtime_pay'] * overtime_used
    
    model.setObjective(revenue - setup_costs - audit_fee - overtime_fee - overtime_pay, GRB.MAXIMIZE)
    
    # Resource constraints
    steel_used = gp.quicksum(products[prod]['steel'] * x[prod] for prod in products)
    model.addConstr(steel_used <= params['available_steel'], "Steel")
    
    aluminum_used = gp.quicksum(products[prod]['aluminum'] * x[prod] for prod in products)
    model.addConstr(aluminum_used <= params['available_aluminum'], "Aluminum")
    
    # Labor and overtime constraints
    labor_used = gp.quicksum(products[prod]['labor'] * x[prod] for prod in products)
    model.addConstr(labor_used <= params['available_labor'] + overtime_used, "Labor_Capacity")
    model.addConstr(overtime_used >= labor_used - params['available_labor'], "Overtime_Definition")
    
    # Setup cost activation constraints
    M_A = min(
        params['available_steel'] / products['A']['steel'],
        params['available_aluminum'] / products['A']['aluminum'],
        (params['available_labor'] + params['max_overtime']) / products['A']['labor']
    )
    model.addConstr(x['A'] <= M_A * y['A'], "Setup_A")
    
    M_B = min(
        params['available_steel'] / products['B']['steel'],
        params['available_aluminum'] / products['B']['aluminum'],
        (params['available_labor'] + params['max_overtime']) / products['B']['labor']
    )
    model.addConstr(x['B'] <= M_B * y['B'], "Setup_B")
    
    # Product A audit constraint
    model.addConstr(x['A'] <= params['product_A_line_audit_threshold'] + (M_A - params['product_A_line_audit_threshold']) * z_A, "Audit_A")
    
    # Overtime fee constraint
    model.addConstr(overtime_used <= params['overtime_review_threshold'] + 
                    (params['max_overtime'] - params['overtime_review_threshold']) * w, "Overtime_Fee")
    
    # Solve
    model.optimize()
    
    # Print the final objective value as required
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
