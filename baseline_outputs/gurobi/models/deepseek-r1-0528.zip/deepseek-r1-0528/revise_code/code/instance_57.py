import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(current_dir, "data", filename)

def main():
    orders = []
    table_1_path = get_data_path('table_1.csv')
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
    
    std_widths = []
    params = {}
    general_params_path = get_data_path('general_parameters.csv')
    with open(general_params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if 'standard_width' in row['Parameter_Name']:
                std_widths.append(float(row['Value']))
            else:
                params[row['Parameter_Name']] = float(row['Value'])
    
    pattern_setup_penalty = params['pattern_setup_penalty']
    wide_roll_threshold = params['wide_roll_threshold_width']
    wide_roll_penalty = params['wide_roll_extra_setup_penalty']
    
    total_required_area = sum(o['width'] * o['length'] for o in orders)
    max_length = max(o['length'] for o in orders)
    
    patterns_by_width = {}
    for sw in std_widths:
        patterns = []
        def generate_patterns(idx, current, current_sum):
            if idx == len(orders):
                if any(c > 0 for c in current):
                    patterns.append(tuple(current))
                return
            max_count = int(math.floor((sw - current_sum) / orders[idx]['width'] + 1e-7))
            for count in range(max_count + 1):
                new_sum = current_sum + count * orders[idx]['width']
                if new_sum <= sw + 1e-7:
                    generate_patterns(idx + 1, current + [count], new_sum)
        generate_patterns(0, [], 0.0)
        patterns_by_width[sw] = list(set(patterns))
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    x_vars = {}
    y_vars = {}
    for sw in std_widths:
        patterns = patterns_by_width[sw]
        for i, p in enumerate(patterns):
            x_vars[(sw, i)] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{sw}_{i}")
            y_vars[(sw, i)] = model.addVar(vtype=GRB.BINARY, name=f"y_{sw}_{i}")
            model.addConstr(x_vars[(sw, i)] <= max_length * y_vars[(sw, i)])
    
    for j, order in enumerate(orders):
        expr = gp.LinExpr()
        for sw in std_widths:
            patterns = patterns_by_width[sw]
            for i, p in enumerate(patterns):
                if j < len(p) and p[j] > 0:
                    expr.addTerms(p[j], x_vars[(sw, i)])
        model.addConstr(expr >= order['length'])
    
    total_area = gp.LinExpr()
    for sw in std_widths:
        patterns = patterns_by_width[sw]
        for i, p in enumerate(patterns):
            total_area.addTerms(sw, x_vars[(sw, i)])
    
    setup_penalty = pattern_setup_penalty * gp.quicksum(y_vars.values())
    wide_penalty = wide_roll_penalty * gp.quicksum(
        y_vars[(sw, i)] 
        for sw in std_widths 
        if sw >= wide_roll_threshold 
        for i in range(len(patterns_by_width[sw]))
    )
    
    model.setObjective(total_area - total_required_area + setup_penalty + wide_penalty, GRB.MINIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        total_waste = model.objVal
        print(f"FINAL_OBJ_VALUE: {round(total_waste, 4)}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
