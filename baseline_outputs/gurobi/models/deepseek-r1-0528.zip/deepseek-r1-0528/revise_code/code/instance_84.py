import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    candidates = []
    with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })
    
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_exp = params['min_manager_experience']
    manager_bonus = params['manager_bonus_per_candidate']
    
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0)
    
    y = {}  # Manager assignment
    z = {}  # Specialist assignment
    for c in candidates:
        name = c['name']
        y[name] = model.addVar(vtype=GRB.BINARY, name=f"y_{name}")
        z[name] = model.addVar(vtype=GRB.BINARY, name=f"z_{name}")
    
    total_base = gp.quicksum(c['salary'] * (y[c['name']] + z[c['name']]) for c in candidates)
    num_managers = gp.quicksum(y[c['name']] for c in candidates)
    total_cost = total_base + manager_bonus * num_managers
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    total_hired = gp.quicksum(y[c['name']] + z[c['name']] for c in candidates)
    model.addConstr(total_hired >= min_employees, "min_employees")
    model.addConstr(total_hired <= max_employees, "max_employees")
    model.addConstr(total_base <= budget_limit, "budget")
    
    advanced_candidates = [c for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(y[c['name']] + z[c['name']] for c in advanced_candidates) >= min_advanced, "advanced_degree")
    
    model.addConstr(gp.quicksum(c['experience'] * (y[c['name']] + z[c['name']]) for c in candidates) >= min_experience, "total_experience")
    
    model.addConstr(y['A'] + z['A'] + y['E'] + z['E'] <= max_equivalent, "equivalent_pair")
    
    model.addConstr(num_managers >= min_managers, "min_managers")
    model.addConstr(num_managers <= max_managers, "max_managers")
    
    for c in candidates:
        model.addConstr(y[c['name']] + z[c['name']] <= 1, f"role_excl_{c['name']}")
        if c['experience'] < min_manager_exp:
            model.addConstr(y[c['name']] == 0, f"manager_exp_{c['name']}")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == '__main__':
    main()
