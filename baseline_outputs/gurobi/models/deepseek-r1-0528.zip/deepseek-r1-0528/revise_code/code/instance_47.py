import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    def load_general_parameters():
        filepath = os.path.join(base_dir, 'data', 'general_parameters.csv')
        params = {}
        with open(filepath, 'r') as f:
            reader = csv.reader(f)
            next(reader)
            for row in reader:
                param_name = row[0].strip()
                try:
                    value = float(row[1].strip())
                except:
                    value = row[1].strip()
                params[param_name] = value
        return params
    
    def load_crop_data():
        filepath = os.path.join(base_dir, 'data', 'table_1.csv')
        with open(filepath, 'r') as f:
            reader = csv.reader(f)
            headers = [h.strip() for h in next(reader)]
            crops = headers[1:]
            rows = []
            for row in reader:
                rows.append([x.strip() for x in row])
            data = {}
            for row in rows:
                item = row[0]
                values = [float(x) for x in row[1:]]
                data[item] = dict(zip(crops, values))
        return crops, data

    params = load_general_parameters()
    crops, crop_data = load_crop_data()
    
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']
    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = params['max_chickens']
    max_dairy_cows = params['max_dairy_cows']
    fixed_cost_setup = params['fixed_cost_chicken_setup']
    min_chickens = params['min_chickens_if_coop_open']
    sec_threshold = params['second_biosecurity_threshold']
    sec_cost = params['second_biosecurity_cost']
    training_aw = params['biosecurity_training_aw_days']
    training_ss = params['biosecurity_training_ss_days']
    
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    x = {}
    for c in crops:
        x[c] = model.addVar(lb=0, name=f"x_{c}")
    
    y_dairy = model.addVar(lb=0, ub=max_dairy_cows, name="dairy_cows")
    y_chicken = model.addVar(lb=0, ub=max_chickens, name="chickens")
    z = model.addVar(vtype=GRB.BINARY, name="z")
    w = model.addVar(vtype=GRB.BINARY, name="w")
    surplus_aw = model.addVar(lb=0, name="surplus_aw")
    surplus_ss = model.addVar(lb=0, name="surplus_ss")
    
    obj = gp.quicksum(crop_income[c] * x[c] for c in crops)
    obj += income_dairy * y_dairy
    obj += income_chicken * y_chicken - fixed_cost_setup * z - sec_cost * w
    obj += ext_rate_aw * surplus_aw + ext_rate_ss * surplus_ss
    model.setObjective(obj, GRB.MAXIMIZE)
    
    model.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, "Land")
    model.addConstr(inv_dairy * y_dairy + inv_chicken * y_chicken <= funds_available, "Funds")
    
    model.addConstr(
        gp.quicksum(crop_aw[c] * x[c] for c in crops) + 
        labor_aw_dairy * y_dairy + 
        labor_aw_chicken * y_chicken + 
        training_aw * z + 
        surplus_aw <= labor_aw, "Labor_AW"
    )
    
    model.addConstr(
        gp.quicksum(crop_ss[c] * x[c] for c in crops) + 
        labor_ss_dairy * y_dairy + 
        labor_ss_chicken * y_chicken + 
        training_ss * z + 
        surplus_ss <= labor_ss, "Labor_SS"
    )
    
    model.addConstr(y_chicken >= min_chickens * z, "MinChickens")
    model.addConstr(y_chicken <= max_chickens * z, "MaxChickens")
    model.addConstr(y_chicken >= sec_threshold * w, "SecThresholdLB")
    model.addConstr(y_chicken <= sec_threshold - 1e-5 + (max_chickens - sec_threshold + 1e-5) * w, "SecThresholdUB")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
