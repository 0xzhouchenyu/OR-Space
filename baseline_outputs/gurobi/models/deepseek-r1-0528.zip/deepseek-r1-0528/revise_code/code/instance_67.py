import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_demand():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "table_1.csv")
    demand = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            month = row['Month']
            product = row['Product']
            units = int(row['Market_Demand_Units'])
            demand[(month, product)] = units
    return demand

def load_parameters():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", "general_parameters.csv")
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            value = float(row['Value'])
            params[name] = value
    return params

def main():
    demand_data = load_demand()
    params = load_parameters()
    
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']
    
    prod_cost = {'Product_I': params['product_I_cost_jun_to_dec'], 
                 'Product_II': params['product_II_cost_jun_to_dec']}
    volume = {'Product_I': params['product_I_volume'], 
              'Product_II': params['product_II_volume']}
    machine_hours = {'Product_I': params['product_I_machine_hours'], 
                     'Product_II': params['product_II_machine_hours']}
    power_kwh = {'Product_I': params['product_I_power_kwh'], 
                 'Product_II': params['product_II_power_kwh']}
    
    machine_cap = params['machine_hours_capacity_monthly']
    warehouse_cap = params['warehouse_capacity']
    own_wh_cost = params['own_warehouse_cost']
    grid_cost = params['grid_electricity_cost']
    gen_cost = params['generator_electricity_cost']
    
    grid_quota = {m: params[f"grid_quota_{m.lower()}"] for m in months}
    gen_max = {m: params[f"generator_max_{m.lower()}"] for m in months}
    
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]
    
    model = gp.Model("Revised_Production_Planning")
    model.setParam('OutputFlag', 0)
    
    x = model.addVars(months, products, name="prod", lb=0)
    inv = model.addVars(months, products, name="inv", lb=0)
    grid_elec = model.addVars(months, name="grid", lb=0)
    gen_elec = model.addVars(months, name="gen", lb=0)
    
    total_prod_cost = gp.quicksum(prod_cost[p] * x[m, p] for m in months for p in products)
    total_elec_cost = gp.quicksum(grid_cost * grid_elec[m] + gen_cost * gen_elec[m] for m in months)
    total_inv_cost = gp.quicksum(own_wh_cost * (volume[p] * inv[m, p]) for m in months for p in products)
    
    model.setObjective(total_prod_cost + total_elec_cost + total_inv_cost, GRB.MINIMIZE)
    
    for idx, m in enumerate(months):
        for p in products:
            if idx == 0:
                model.addConstr(inv[m, p] == x[m, p] - demand[(m, p)], f"inv_bal_{m}_{p}")
            else:
                prev_m = months[idx-1]
                model.addConstr(inv[m, p] == inv[prev_m, p] + x[m, p] - demand[(m, p)], f"inv_bal_{m}_{p}")
        
        model.addConstr(gp.quicksum(machine_hours[p] * x[m, p] for p in products) <= machine_cap, f"machine_cap_{m}")
        
        total_elec = gp.quicksum(power_kwh[p] * x[m, p] for p in products)
        model.addConstr(total_elec == grid_elec[m] + gen_elec[m], f"elec_bal_{m}")
        model.addConstr(grid_elec[m] <= grid_quota[m], f"grid_limit_{m}")
        model.addConstr(gen_elec[m] <= gen_max[m], f"gen_limit_{m}")
        
        total_vol = gp.quicksum(volume[p] * inv[m, p] for p in products)
        model.addConstr(total_vol <= warehouse_cap, f"warehouse_cap_{m}")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: No solution found")

if __name__ == "__main__":
    main()
