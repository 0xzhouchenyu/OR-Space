import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Read initial capital
initial_capital = 0
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "initial_capital":
            initial_capital = float(row["Value"].strip())

# Read liquidity policy parameters
min_reserve = 0
penalty_factor = 0.0
with open(os.path.join(data_dir, "liquidity_policy.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["Parameter_Name"].strip() == "min_year3_reserve":
            min_reserve = float(row["Value"].strip())
        elif row["Parameter_Name"].strip() == "reserve_shortfall_penalty":
            penalty_factor = float(row["Value"].strip())

# Read project data
projects = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        projects.append(row)

# Create model
model = gp.Model()
model.setParam('OutputFlag', 0)

# Decision variables
x1_1 = model.addVar(name="x1_1", lb=0)
x1_2 = model.addVar(name="x1_2", lb=0)
x1_3 = model.addVar(name="x1_3", lb=0)
x2 = model.addVar(name="x2", lb=0, ub=120000)
x3 = model.addVar(name="x3", lb=0, ub=150000)
x4 = model.addVar(name="x4", lb=0, ub=100000)
s = model.addVar(name="shortfall", lb=0)  # Shortfall variable

# Year 1 budget constraint
model.addConstr(x1_1 + x2 <= initial_capital, "Year1_Budget")

# Year 2 budget constraint
model.addConstr(x1_2 + x3 <= 1.20 * x1_1, "Year2_Budget")

# Cash available at beginning of Year 3
C3 = 1.20 * x1_2 + 1.50 * x2 + 1.60 * x3

# Shortfall constraint
model.addConstr(s >= min_reserve - C3, "Shortfall_Definition")

# Year 3 investment constraint (after setting aside reserve)
model.addConstr(x1_3 + x4 <= C3 - min_reserve + s, "Year3_Investment")

# Objective: terminal wealth = returns from Year3 investments + reserve amount - penalty
# Reserve amount = min_reserve - s
# Penalty = penalty_factor * s
# So total: (1.20*x1_3 + 1.40*x4) + (min_reserve - s) - penalty_factor * s
obj = 1.20 * x1_3 + 1.40 * x4 + min_reserve - (1 + penalty_factor) * s
model.setObjective(obj, GRB.MAXIMIZE)

# Solve
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
