import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def generate_patterns(lengths, raw_pipe_length, max_cuts, max_leftover):
    min_length = raw_pipe_length - max_leftover
    patterns = []
    n_items = len(lengths)
    
    def dfs(current_pattern, current_length, current_cuts, idx):
        if idx == n_items:
            if current_cuts > 0 and current_length >= min_length and current_length <= raw_pipe_length:
                patterns.append(tuple(current_pattern))
            return
        
        max_qty = min(
            int((raw_pipe_length - current_length) // lengths[idx]),
            max_cuts - current_cuts
        )
        for q in range(0, max_qty + 1):
            new_pattern = current_pattern + [q]
            new_length = current_length + q * lengths[idx]
            new_cuts = current_cuts + q
            dfs(new_pattern, new_length, new_cuts, idx + 1)
    
    dfs([], 0, 0, 0)
    return patterns

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    
    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    params = {}
    for _, row in df_params.iterrows():
        params[row['Parameter_Name']] = row['Value']
    
    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)
    
    raw_pipe_length1 = float(params['raw_pipe_length_supplier1'])
    raw_pipe_length2 = float(params['raw_pipe_length_supplier2'])
    max_cuts1 = int(params['max_cuts_per_pipe_supplier1'])
    max_cuts2 = int(params['max_cuts_per_pipe_supplier2'])
    max_leftover1 = float(params['max_leftover_length_supplier1'])
    max_leftover2 = float(params['max_leftover_length_supplier2'])
    max_patterns1 = int(params['max_cutting_patterns_supplier1'])
    max_patterns2 = int(params['max_cutting_patterns_supplier2'])
    cost_per_pipe1 = float(params['purchase_cost_per_pipe_supplier1'])
    cost_per_pipe2 = float(params['purchase_cost_per_pipe_supplier2'])
    discount_tier = int(params['discount_tier1_supplier1_max_qty'])
    fixed_discount = float(params['fixed_discount_tier2_supplier1'])
    bigM_discount = float(params['bigM_discount'])
    
    rank_prefixes = ['most', 'second', 'third']
    cost_rates1 = []
    cost_rates2 = []
    for prefix in rank_prefixes:
        key1 = f"{prefix}_frequent_pattern_cost_rate_supplier1"
        key2 = f"{prefix}_frequent_pattern_cost_rate_supplier2"
        cost_rates1.append(float(params[key1]))
        cost_rates2.append(float(params[key2]))
    
    patterns1 = generate_patterns(lengths, raw_pipe_length1, max_cuts1, max_leftover1)
    patterns2 = generate_patterns(lengths, raw_pipe_length2, max_cuts2, max_leftover2)
    
    model = gp.Model("Pipe_Cutting")
    model.setParam('OutputFlag', 0)
    
    y1 = model.addVars(len(patterns1), vtype=GRB.INTEGER, name="y1")
    y2 = model.addVars(len(patterns2), vtype=GRB.INTEGER, name="y2")
    z1 = model.addVars(len(patterns1), vtype=GRB.BINARY, name="z1")
    z2 = model.addVars(len(patterns2), vtype=GRB.BINARY, name="z2")
    u1 = model.addVars(max_patterns1, vtype=GRB.BINARY, name="u1")
    u2 = model.addVars(max_patterns2, vtype=GRB.BINARY, name="u2")
    discount_var = model.addVar(vtype=GRB.BINARY, name="discount")
    
    Q1 = gp.quicksum(y1)
    Q2 = gp.quicksum(y2)
    
    for i in range(n_items):
        total_pieces = gp.quicksum(
            patterns1[p][i] * y1[p] for p in range(len(patterns1))
        ) + gp.quicksum(
            patterns2[p][i] * y2[p] for p in range(len(patterns2))
        )
        model.addConstr(total_pieces >= demands[i], f"demand_{i}")
    
    M = sum(demands)
    for p in range(len(patterns1)):
        model.addConstr(y1[p] <= M * z1[p], f"y1_z1_{p}")
    for p in range(len(patterns2)):
        model.addConstr(y2[p] <= M * z2[p], f"y2_z2_{p}")
    
    total_patterns1 = gp.quicksum(z1)
    total_patterns2 = gp.quicksum(z2)
    model.addConstr(total_patterns1 <= max_patterns1, "max_patterns1")
    model.addConstr(total_patterns2 <= max_patterns2, "max_patterns2")
    
    model.addConstr(total_patterns1 == gp.quicksum(u1[k] for k in range(max_patterns1)), "u1_sum")
    model.addConstr(total_patterns2 == gp.quicksum(u2[k] for k in range(max_patterns2)), "u2_sum")
    
    for k in range(max_patterns1 - 1):
        model.addConstr(u1[k] >= u1[k + 1], f"u1_order_{k}")
    for k in range(max_patterns2 - 1):
        model.addConstr(u2[k] >= u2[k + 1], f"u2_order_{k}")
    
    model.addConstr(Q1 >= discount_tier + 1 - bigM_discount * (1 - discount_var), "discount_lower")
    model.addConstr(Q1 <= discount_tier + bigM_discount * discount_var, "discount_upper")
    
    extra_cost1 = gp.quicksum(cost_rates1[k] * u1[k] for k in range(min(max_patterns1, len(cost_rates1))))
    extra_cost2 = gp.quicksum(cost_rates2[k] * u2[k] for k in range(min(max_patterns2, len(cost_rates2))))
    
    base_cost = cost_per_pipe1 * Q1 + cost_per_pipe2 * Q2
    discount_amount = fixed_discount * discount_var
    total_cost = base_cost + extra_cost1 + extra_cost2 - discount_amount
    
    model.setObjective(total_cost, GRB.MINIMIZE)
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
