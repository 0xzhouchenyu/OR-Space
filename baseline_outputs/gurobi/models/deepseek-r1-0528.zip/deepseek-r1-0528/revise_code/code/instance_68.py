import os
import sys
import gurobipy as gp
from gurobipy import GRB

script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from utils import load_distances, load_parameters

data_dir = os.path.join(script_dir, 'data')
distances = load_distances(data_dir)
params = load_parameters(data_dir)

min_supply = {
    'A': params['min_coal_yard_A'],
    'B': params['min_coal_yard_B_adjusted']
}

demand = {
    1: params['residential_area_1_demand'],
    2: params['residential_area_2_demand'],
    3: params['residential_area_3_demand']
}

staging_threshold = params['area3_A_staging_threshold']
excess_cost = params['area3_A_excess_staging_cost']
min_share = params['min_share_area3_from_A'] * demand[3]

model = gp.Model("Coal_Distribution")
model.setParam('OutputFlag', 0)

x = {}
for (yard, area) in distances:
    if yard == 'A' and area == 3:
        continue
    x[(yard, area)] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{yard}_{area}")

x_A3_normal = model.addVar(ub=staging_threshold, vtype=GRB.CONTINUOUS, name="x_A3_normal")
x_A3_excess = model.addVar(vtype=GRB.CONTINUOUS, name="x_A3_excess")

model.setObjective(
    gp.quicksum(distances[route] * x[route] for route in x) +
    distances[('A',3)] * x_A3_normal +
    (distances[('A',3)] + excess_cost) * x_A3_excess,
    GRB.MINIMIZE
)

model.addConstr(
    gp.quicksum(x.get(('A', area), 0) for area in [1,2]) + 
    x_A3_normal + x_A3_excess >= min_supply['A'],
    "Min_Supply_A"
)

model.addConstr(
    gp.quicksum(x.get(('B', area), 0) for area in [1,2]) >= min_supply['B'],
    "Min_Supply_B"
)

model.addConstr(
    x.get(('A',1),0) + x.get(('B',1),0) == demand[1],
    "Demand_1"
)

model.addConstr(
    x.get(('A',2),0) + x.get(('B',2),0) == demand[2],
    "Demand_2"
)

model.addConstr(
    x_A3_normal + x_A3_excess == demand[3],
    "Demand_3"
)

model.addConstr(
    x_A3_normal + x_A3_excess >= min_share,
    "Min_Share_A3"
)

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: infeasible")
