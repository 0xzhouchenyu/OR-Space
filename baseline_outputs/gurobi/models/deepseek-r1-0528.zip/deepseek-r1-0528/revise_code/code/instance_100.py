import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load the bandwidth table
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    nodes = []
    bandwidth = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw_val = val.strip()
                bw = int(bw_val) if bw_val else 0
                bandwidth[(row_node, col_node)] = bw

    # Create cost dictionary: cost = 100 - bandwidth (only for edges with bandwidth>0)
    cost = {}
    edges = []
    for i in nodes:
        for j in nodes:
            if bandwidth.get((i,j), 0) > 0:
                cost[(i,j)] = 100 - bandwidth[(i,j)]
                edges.append((i,j))
    
    # Create model
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Variables: two sets for A->C and C->E segments
    x1 = model.addVars(edges, vtype=GRB.BINARY, name="x1")  # A->C segment
    x2 = model.addVars(edges, vtype=GRB.BINARY, name="x2")  # C->E segment
    
    # Objective: minimize total routing cost
    total_cost = gp.quicksum(cost[e] * (x1[e] + x2[e]) for e in edges)
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Segment 1: A -> C
    model.addConstr(gp.quicksum(x1[('A', j)] for j in nodes if ('A', j) in edges) == 1, "source1")
    model.addConstr(gp.quicksum(x1[(i, 'C')] for i in nodes if (i, 'C') in edges) == 1, "sink1")
    for k in nodes:
        if k == 'A' or k == 'C':
            continue
        in_flow = gp.quicksum(x1[(i, k)] for i in nodes if (i, k) in edges)
        out_flow = gp.quicksum(x1[(k, j)] for j in nodes if (k, j) in edges)
        model.addConstr(in_flow == out_flow, f"flow1_{k}")
        model.addConstr(in_flow <= 1, f"node1_{k}")
    
    # Segment 2: C -> E
    model.addConstr(gp.quicksum(x2[('C', j)] for j in nodes if ('C', j) in edges) == 1, "source2")
    model.addConstr(gp.quicksum(x2[(i, 'E')] for i in nodes if (i, 'E') in edges) == 1, "sink2")
    for k in nodes:
        if k == 'C' or k == 'E':
            continue
        in_flow = gp.quicksum(x2[(i, k)] for i in nodes if (i, k) in edges)
        out_flow = gp.quicksum(x2[(k, j)] for j in nodes if (k, j) in edges)
        model.addConstr(in_flow == out_flow, f"flow2_{k}")
        model.addConstr(in_flow <= 1, f"node2_{k}")
    
    # Node-disjointness (except C, A, E)
    intermediate_nodes = set(nodes) - {'A', 'C', 'E'}
    for k in intermediate_nodes:
        in_flow1 = gp.quicksum(x1[(i, k)] for i in nodes if (i, k) in edges)
        in_flow2 = gp.quicksum(x2[(i, k)] for i in nodes if (i, k) in edges)
        model.addConstr(in_flow1 + in_flow2 <= 1, f"disjoint_{k}")
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: inf")

if __name__ == '__main__':
    main()
