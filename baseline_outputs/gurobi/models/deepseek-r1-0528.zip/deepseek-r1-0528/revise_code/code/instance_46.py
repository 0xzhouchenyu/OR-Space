import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, 'data')
    
    students = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            s = {'Student_ID': int(row['Student_ID']),
                 'Wage_CNY_per_hour': float(row['Wage_CNY_per_hour'])}
            for d in ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']:
                s[d] = float(row[d])
            students.append(s)
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = row['Value']
            try:
                params[name] = int(val)
            except ValueError:
                try:
                    params[name] = float(val)
                except ValueError:
                    params[name] = val
    return students, params

if __name__ == '__main__':
    students, params = load_data()
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    student_ids = [s['Student_ID'] for s in students]
    grad_students = {5, 6}
    
    min_undergrad = params['min_undergrad_hours']
    min_grad = params['min_grad_hours']
    max_shifts = params['max_shifts_per_student']
    max_students_day = params['max_students_per_day']
    daily_open_fee = params['daily_open_fee_cny']
    min_grad_total = params['min_grad_weekly_coverage_hours']
    hours_per_day = 14
    
    avail = {}
    for s in students:
        sid = s['Student_ID']
        for d in days:
            avail[sid, d] = s[d]
    
    wage = {s['Student_ID']: s['Wage_CNY_per_hour'] for s in students}
    
    m = gp.Model()
    m.setParam('OutputFlag', 0)
    
    x = {}
    y = {}
    for i in student_ids:
        for d in days:
            x[i, d] = m.addVar(lb=0, ub=avail[i, d], name=f"x_{i}_{d}")
            y[i, d] = m.addVar(vtype=GRB.BINARY, name=f"y_{i}_{d}")
            if avail[i, d] == 0:
                y[i, d].lb = 0
                y[i, d].ub = 0
    
    total_wage = gp.quicksum(wage[i] * x[i, d] for i in student_ids for d in days)
    total_fixed = daily_open_fee * gp.quicksum(y[i, d] for i in student_ids for d in days)
    m.setObjective(total_wage + total_fixed, GRB.MINIMIZE)
    
    for d in days:
        m.addConstr(gp.quicksum(x[i, d] for i in student_ids) == hours_per_day, f"coverage_{d}")
    
    for i in student_ids:
        for d in days:
            if avail[i, d] > 0:
                m.addConstr(x[i, d] <= avail[i, d] * y[i, d], f"link_{i}_{d}")
    
    for i in student_ids:
        m.addConstr(gp.quicksum(y[i, d] for d in days) <= max_shifts, f"max_shifts_{i}")
    
    for d in days:
        m.addConstr(gp.quicksum(y[i, d] for i in student_ids) <= max_students_day, f"max_students_{d}")
    
    for i in student_ids:
        min_h = min_grad if i in grad_students else min_undergrad
        m.addConstr(gp.quicksum(x[i, d] for d in days) >= min_h, f"min_hours_{i}")
    
    m.addConstr(gp.quicksum(x[i, d] for i in grad_students for d in days) >= min_grad_total, "min_grad_total")
    
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")
