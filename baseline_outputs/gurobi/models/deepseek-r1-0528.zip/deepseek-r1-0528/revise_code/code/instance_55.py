import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load courses
    courses = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            categories = [c.strip() for c in row['Category'].split(';')]
            courses[course] = categories

    # Load parameters
    min_required = 2
    prerequisites_raw = {}
    foundation_course = None
    cs_category = None
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if name == 'min_courses_required':
                min_required = int(value)
            elif name.startswith('prerequisite_'):
                course_key = name[len('prerequisite_'):]
                prerequisites_raw[course_key] = value
            elif name == 'mandatory_foundation_for_cs_counting':
                foundation_course = value
            elif name == 'cs_category_name':
                cs_category = value

    # Match prerequisite keys to course names
    def match_prerequisite_course(prereq_key, course_list):
        key_lower = prereq_key.lower().replace('_', ' ')
        for course in course_list:
            if course.lower() == key_lower:
                return course
        return None

    course_list = list(courses.keys())
    prerequisites = {}
    for prereq_key, prereq_value in prerequisites_raw.items():
        course_name = match_prerequisite_course(prereq_key, course_list)
        if course_name:
            if course_name not in prerequisites:
                prerequisites[course_name] = []
            prerequisites[course_name].append(prereq_value.strip())

    # Create model
    model = gp.Model("CourseSelection")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {}  # x[c]: 1 if course c is taken, else 0
    z = {}  # z[c, cat]: 1 if course c is assigned to category cat, else 0
    for course in courses:
        x[course] = model.addVar(vtype=GRB.BINARY, name=f"x_{course}")
        for cat in courses[course]:
            z[course, cat] = model.addVar(vtype=GRB.BINARY, name=f"z_{course}_{cat}")

    # Objective: minimize total courses taken
    model.setObjective(gp.quicksum(x[course] for course in courses), GRB.MINIMIZE)

    # Constraint: meet minimum requirements per category
    all_categories = set()
    for cats in courses.values():
        all_categories.update(cats)
    for cat in all_categories:
        model.addConstr(
            gp.quicksum(z[course, cat] for course in courses if cat in courses[course]) >= min_required,
            f"min_{cat}"
        )

    # Constraint: each course assigned to at most one category
    for course in courses:
        model.addConstr(
            gp.quicksum(z[course, cat] for cat in courses[course]) <= 1,
            f"assign_once_{course}"
        )

    # Constraint: can only assign if course is taken
    for course in courses:
        for cat in courses[course]:
            model.addConstr(
                z[course, cat] <= x[course],
                f"assign_only_if_taken_{course}_{cat}"
            )

    # Constraint: prerequisites
    for course, prereqs in prerequisites.items():
        for prereq in prereqs:
            if prereq in courses:  # Ensure prerequisite exists
                model.addConstr(
                    x[course] <= x[prereq],
                    f"prereq_{course}_{prereq}"
                )

    # Constraint: foundation for CS counting
    if foundation_course and cs_category:
        for course in courses:
            if cs_category in courses[course]:
                model.addConstr(
                    x[foundation_course] >= z[course, cs_category],
                    f"foundation_{course}"
                )

    # Solve
    model.optimize()

    # Output objective value
    if model.status == GRB.OPTIMAL:
        obj_val = int(model.objVal)
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    main()
