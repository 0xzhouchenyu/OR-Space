import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, "general_parameters.csv")
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    min_profit = params['min_weekly_profit']
    min_A_total = params['min_model_A_units']
    min_B_total = params['min_model_B_units']
    min_A1 = params['week1_min_model_A_units']
    min_B1 = params['week1_min_model_B_units']
    min_A2 = params['week2_min_model_A_units']
    min_B2 = params['week2_min_model_B_units']
    reg_cap_I = params['process_I_hours']
    reg_cap_II = params['process_II_hours']
    max_ot_I = params['max_overtime_I_per_week']
    max_ot_II = params['max_overtime_II_per_week']
    ot_cost_I = params['overtime_premium_I']
    ot_cost_II = params['overtime_premium_II']
    min_util_I = params['min_avg_utilization_I']
    min_util_II = params['min_avg_utilization_II']
    thresh_ot_I = params['week1_overtime_fatigue_threshold_I']
    thresh_ot_II = params['week1_overtime_fatigue_threshold_II']
    loss_I = params['week2_recovery_loss_I']
    loss_II = params['week2_recovery_loss_II']
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, "table_1.csv")
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    
    a_I = float(rows[0][1])
    b_I = float(rows[0][2])
    a_II = float(rows[1][1])
    b_II = float(rows[1][2])
    profit_A = float(rows[2][1])
    profit_B = float(rows[2][2])
    
    # Create Gurobi model
    model = gp.Model("Microcomputer_Production_Two_Week")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    xA1 = model.addVar(vtype=GRB.CONTINUOUS, name="xA1")
    xA2 = model.addVar(vtype=GRB.CONTINUOUS, name="xA2")
    xB1 = model.addVar(vtype=GRB.CONTINUOUS, name="xB1")
    xB2 = model.addVar(vtype=GRB.CONTINUOUS, name="xB2")
    
    ot_I1 = model.addVar(vtype=GRB.CONTINUOUS, name="ot_I1", ub=max_ot_I)
    ot_I2 = model.addVar(vtype=GRB.CONTINUOUS, name="ot_I2", ub=max_ot_I)
    ot_II1 = model.addVar(vtype=GRB.CONTINUOUS, name="ot_II1", ub=max_ot_II)
    ot_II2 = model.addVar(vtype=GRB.CONTINUOUS, name="ot_II2", ub=max_ot_II)
    
    z_I = model.addVar(vtype=GRB.BINARY, name="z_I")
    z_II = model.addVar(vtype=GRB.BINARY, name="z_II")
    
    # Objective: maximize total profit minus overtime costs
    total_profit = profit_A * (xA1 + xA2) + profit_B * (xB1 + xB2)
    total_ot_cost = ot_cost_I * (ot_I1 + ot_I2) + ot_cost_II * (ot_II1 + ot_II2)
    model.setObjective(total_profit - total_ot_cost, GRB.MAXIMIZE)
    
    # Process constraints - Week 1
    model.addConstr(a_I * xA1 + b_I * xB1 <= reg_cap_I + ot_I1, "Process_I_Week1")
    model.addConstr(a_II * xA1 + b_II * xB1 <= reg_cap_II + ot_II1, "Process_II_Week1")
    
    # Process constraints - Week 2 (with potential recovery loss)
    model.addConstr(a_I * xA2 + b_I * xB2 <= reg_cap_I - loss_I * z_I + ot_I2, "Process_I_Week2")
    model.addConstr(a_II * xA2 + b_II * xB2 <= reg_cap_II - loss_II * z_II + ot_II2, "Process_II_Week2")
    
    # Recovery trigger constraints
    model.addConstr(ot_I1 >= thresh_ot_I * z_I, "Trigger_I_Lower")
    model.addConstr(ot_I1 <= thresh_ot_I - 0.001 + (max_ot_I - thresh_ot_I + 0.001) * z_I, "Trigger_I_Upper")
    model.addConstr(ot_II1 >= thresh_ot_II * z_II, "Trigger_II_Lower")
    model.addConstr(ot_II1 <= thresh_ot_II - 0.001 + (max_ot_II - thresh_ot_II + 0.001) * z_II, "Trigger_II_Upper")
    
    # Production requirements
    model.addConstr(xA1 + xA2 >= min_A_total, "Min_A_Total")
    model.addConstr(xB1 + xB2 >= min_B_total, "Min_B_Total")
    model.addConstr(xA1 >= min_A1, "Min_A_Week1")
    model.addConstr(xB1 >= min_B1, "Min_B_Week1")
    model.addConstr(xA2 >= min_A2, "Min_A_Week2")
    model.addConstr(xB2 >= min_B2, "Min_B_Week2")
    
    # Minimum profit constraint
    model.addConstr(total_profit - total_ot_cost >= min_profit, "Min_Profit")
    
    # Utilization constraints
    reg_used_I = (reg_cap_I + (reg_cap_I - loss_I * z_I)) - (ot_I1 + ot_I2)
    model.addConstr(reg_used_I >= min_util_I * (2 * reg_cap_I), "Util_I")
    reg_used_II = (reg_cap_II + (reg_cap_II - loss_II * z_II)) - (ot_II1 + ot_II2)
    model.addConstr(reg_used_II >= min_util_II * (2 * reg_cap_II), "Util_II")
    
    # Solve
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
