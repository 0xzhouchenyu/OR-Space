import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load general parameters
    gp_df = pd.read_csv(os.path.join(data_dir, "general_parameters.csv"))
    params = {row['Parameter_Name']: float(row['Value']) for _, row in gp_df.iterrows()}
    
    # Load product data
    t1 = pd.read_csv(os.path.join(data_dir, "table_1.csv"))
    t2 = pd.read_csv(os.path.join(data_dir, "table_2.csv"))
    t3 = pd.read_csv(os.path.join(data_dir, "table_3.csv"))
    df = t1.merge(t2, on='Product').merge(t3, on='Product')
    
    # Extract parameters
    production_days = params['production_days']
    a1_watch_threshold = params['a1_watch_threshold']
    a1_deep_service_threshold = params['a1_deep_service_threshold']
    maint_penalty_watch = params['maintenance_penalty_watch']
    maint_penalty_deep = params['maintenance_penalty_deep']
    quality_release_fee = params['a1_quality_release_fee']
    deep_service_fee = params['a1_deep_service_fee']
    priority_price_lift = params['a1_priority_price_lift']
    
    # Total fixed activation cost
    activation_cost_total = df['Activation_Cost'].sum()
    
    # Create model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Product variables
    products = df['Product'].tolist()
    x = model.addVars(products, name="x", lb=0)
    
    # Threshold binary variables for A1
    z1 = model.addVar(vtype=GRB.BINARY, name="z1")
    z2 = model.addVar(vtype=GRB.BINARY, name="z2")
    
    # Auxiliary variable for A1 units above watch threshold
    w = model.addVar(name="w", lb=0)
    
    # Set objective
    revenue = gp.quicksum(
        (row['Selling_Price'] - row['Production_Cost']) * x[row['Product']] 
        for _, row in df.iterrows()
    )
    uplift = priority_price_lift * w
    fees = quality_release_fee * z1 + deep_service_fee * z2
    model.setObjective(revenue + uplift - activation_cost_total - fees, GRB.MAXIMIZE)
    
    # Production bounds
    for _, row in df.iterrows():
        p = row['Product']
        model.addConstr(x[p] >= row['Minimum_Batch'], f"min_batch_{p}")
        model.addConstr(x[p] <= row['Maximum_Demand'], f"max_demand_{p}")
    
    # Threshold constraints for A1
    model.addConstr(x['A1'] >= a1_watch_threshold * z1, "watch_lower")
    model.addConstr(x['A1'] <= (a1_watch_threshold - 1) + (df[df['Product']=='A1']['Maximum_Demand'].iloc[0]) * (1 - z1), "watch_upper")
    model.addConstr(x['A1'] >= a1_deep_service_threshold * z2, "deep_lower")
    model.addConstr(x['A1'] <= (a1_deep_service_threshold - 1) + (df[df['Product']=='A1']['Maximum_Demand'].iloc[0]) * (1 - z2), "deep_upper")
    model.addConstr(z2 <= z1, "threshold_order")
    
    # Auxiliary variable constraints for w
    model.addConstr(w >= x['A1'] - a1_watch_threshold, "w_lower")
    model.addConstr(w <= x['A1'] - a1_watch_threshold * z1, "w_upper1")
    max_above = df[df['Product']=='A1']['Maximum_Demand'].iloc[0] - a1_watch_threshold
    model.addConstr(w <= max_above * z1, "w_upper2")
    
    # Production days constraint
    production_time = gp.quicksum(
        x[row['Product']] / row['Production_Quota'] 
        for _, row in df.iterrows()
    )
    lost_days = maint_penalty_watch * z1 + maint_penalty_deep * z2
    model.addConstr(production_time <= production_days - lost_days, "production_days")
    
    # Solve
    model.optimize()
    
    # Print result
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.objVal, 4)}")
    else:
        print("FINAL_OBJ_VALUE: 0.0000")

if __name__ == "__main__":
    main()
