import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Define base directory and data paths
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Read general parameters
general_params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row["Parameter_Name"].strip()
        general_params[param_name] = float(row["Value"].strip())

required_units = general_params["required_units"]
energy_budget_peak = general_params["energy_budget_peak"]
energy_budget_offpeak = general_params["energy_budget_offpeak"]
startup_cost_val = general_params["startup_cost"]
startup_budget_val = general_params["startup_budget"]
energy_price_peak = general_params["energy_price_peak"]
energy_price_offpeak = general_params["energy_price_offpeak"]

# Extract per-device parameters
device_energy_per_unit = {}
device_startup_energy = {}
for dev in ["A", "B", "C", "D"]:
    device_energy_per_unit[dev] = general_params[f"energy_per_unit_{dev}"]
    device_startup_energy[dev] = general_params[f"startup_energy_{dev}"]

# Read device data
devices = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        dev_name = row["Device"].strip()
        devices.append({
            "name": dev_name,
            "unit_cost": float(row["Unit_Production_Cost_Yuan_per_Unit"].strip()),
            "max_cap": float(row["Max_Processing_Capacity_Units"].strip()),
            "energy_per_unit": device_energy_per_unit[dev_name],
            "startup_energy": device_startup_energy[dev_name]
        })

periods = ["peak", "offpeak"]

# Create model
model = gp.Model()
model.setParam("OutputFlag", 0)

# Decision variables
x = {}
y = {}
for dev in devices:
    for p in periods:
        x[dev["name"], p] = model.addVar(lb=0, name=f"x_{dev['name']}_{p}")
        y[dev["name"], p] = model.addVar(vtype=GRB.BINARY, name=f"y_{dev['name']}_{p}")

# Objective function: startup costs + production costs + energy costs
total_cost = startup_cost_val * sum(y[dev["name"], p] for dev in devices for p in periods)
for dev in devices:
    for p in periods:
        energy_price = energy_price_peak if p == "peak" else energy_price_offpeak
        total_cost += dev["unit_cost"] * x[dev["name"], p]
        total_cost += energy_price * dev["energy_per_unit"] * x[dev["name"], p]
model.setObjective(total_cost, GRB.MINIMIZE)

# Total production constraint
model.addConstr(
    sum(x[dev["name"], p] for dev in devices for p in periods) == required_units,
    "TotalProduction"
)

# Device capacity constraints
for dev in devices:
    model.addConstr(
        x[dev["name"], "peak"] + x[dev["name"], "offpeak"] <= dev["max_cap"],
        f"Cap_{dev['name']}"
    )

# Peak energy constraint
peak_energy = gp.quicksum(
    dev["startup_energy"] * y[dev["name"], "peak"] + 
    dev["energy_per_unit"] * x[dev["name"], "peak"] 
    for dev in devices
)
model.addConstr(peak_energy <= energy_budget_peak, "EnergyPeak")

# Off-peak energy constraint
offpeak_energy = gp.quicksum(
    dev["startup_energy"] * y[dev["name"], "offpeak"] + 
    dev["energy_per_unit"] * x[dev["name"], "offpeak"] 
    for dev in devices
)
model.addConstr(offpeak_energy <= energy_budget_offpeak, "EnergyOffpeak")

# Startup budget constraint
total_startups = sum(y[dev["name"], p] for dev in devices for p in periods)
model.addConstr(
    startup_cost_val * total_startups <= startup_budget_val,
    "StartupBudget"
)

# Linking constraints
for dev in devices:
    for p in periods:
        model.addConstr(
            x[dev["name"], p] <= dev["max_cap"] * y[dev["name"], p],
            f"Link_{dev['name']}_{p}"
        )

# Solve the model
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
