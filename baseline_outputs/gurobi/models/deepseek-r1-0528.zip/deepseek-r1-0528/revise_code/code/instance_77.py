import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load processing costs
    cost = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p.strip()) for p in header[1:]]
        for row in reader:
            machine = row[0].strip()
            for j, part in enumerate(parts):
                cost[(machine, part)] = float(row[j+1])
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    
    d = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    max_parts_on_C = int(params['max_parts_on_C'])
    overtime_threshold = int(params['overtime_threshold'])
    overtime_penalty = params['overtime_penalty']
    
    machines = ['A', 'B', 'C']
    model = gp.Model("MachineAssignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(machines, parts, vtype=GRB.BINARY, name="x")
    y = model.addVars(machines, vtype=GRB.BINARY, name="y")
    z = model.addVars(machines, vtype=GRB.BINARY, name="z")
    
    # Objective: minimize total cost
    processing_cost = gp.quicksum(cost[(m, p)] * x[m, p] for m in machines for p in parts)
    setup_cost = gp.quicksum(d[m] * y[m] for m in machines)
    overtime_cost = overtime_penalty * gp.quicksum(z[m] for m in machines)
    model.setObjective(processing_cost + setup_cost + overtime_cost, GRB.MINIMIZE)
    
    # Each part assigned to exactly one machine
    for p in parts:
        model.addConstr(gp.quicksum(x[m, p] for m in machines) == 1, f"part_{p}_assignment")
    
    # Setup cost linking
    for m in machines:
        for p in parts:
            model.addConstr(x[m, p] <= y[m], f"setup_link_{m}_{p}")
    
    # Constraint for parts 1 and 2
    model.addConstr(x['A', 1] + x['A', 2] == 1, "parts_1_2_relation")
    
    # Fixed assignments
    model.addConstr(x['A', 3] == 1, "fix_part3_A")
    model.addConstr(x['B', 4] == 1, "fix_part4_B")
    model.addConstr(x['C', 5] == 1, "fix_part5_C")
    
    # Max parts on machine C
    model.addConstr(gp.quicksum(x['C', p] for p in parts) <= max_parts_on_C, "max_parts_C")
    
    # Overtime constraints
    for m in machines:
        total_parts = len(parts)
        model.addConstr(
            gp.quicksum(x[m, p] for p in parts) <= overtime_threshold + (total_parts - overtime_threshold) * z[m],
            f"overtime_{m}"
        )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    main()
