import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(base_dir, 'data', filename)
    data = []
    with open(file_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

def load_general_parameters():
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        key = row['Parameter_Name']
        val = row['Value']
        try:
            if '.' in val:
                params[key] = float(val)
            else:
                params[key] = int(val)
        except ValueError:
            params[key] = val
    return params

def load_task_methods():
    rows = load_csv('table_1.csv')
    data = {}
    for row in rows:
        task = row['Task']
        method = row['Method']
        data[(task, method)] = {
            'Effective_Hours': float(row['Effective_Hours']),
            'Fixed_Cost': float(row['Fixed_Cost'])
        }
    return data

params = load_general_parameters()
tm_data = load_task_methods()

skilled_wage = params['skilled_worker_weekly_wage']
laborer_wage = params['laborer_weekly_wage']
skilled_hours = params['skilled_worker_weekly_hours']
laborer_hours = params['laborer_weekly_hours']
max_skilled = params['max_skilled_workers']
max_laborers = params['max_laborers']
min_skilled_task3_B = params['min_skilled_workers_task3_methodB']
skilled_ratio = params['skilled_worker_hiring_ratio']

min_share = {
    'Task_1': params['min_skilled_share_task1'],
    'Task_2': params['min_skilled_share_task2'],
    'Task_3': params['min_skilled_share_task3']
}
max_share = {
    'Task_1': params['max_skilled_share_task1'],
    'Task_2': params['max_skilled_share_task2'],
    'Task_3': params['max_skilled_share_task3']
}

tasks = ['Task_1', 'Task_2', 'Task_3']
methods = ['Method_A', 'Method_B']

model = gp.Model("WorkerAllocation")
model.setParam('OutputFlag', 0)

y = {}
s = {}
l = {}
for t in tasks:
    for m in methods:
        y[t, m] = model.addVar(vtype=GRB.BINARY, name=f"y_{t}_{m}")
        s[t, m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"s_{t}_{m}")
        l[t, m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"l_{t}_{m}")

total_skilled = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_skilled")
total_laborers = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_laborers")

fixed_costs = gp.quicksum(tm_data[t, m]['Fixed_Cost'] * y[t, m] for t in tasks for m in methods)
wage_costs = skilled_wage * total_skilled + laborer_wage * total_laborers
model.setObjective(wage_costs + fixed_costs, GRB.MINIMIZE)

model.addConstr(total_skilled == gp.quicksum(s[t, m] for t in tasks for m in methods), "TotalSkilledDef")
model.addConstr(total_laborers == gp.quicksum(l[t, m] for t in tasks for m in methods), "TotalLaborersDef")

for t in tasks:
    model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1, f"OneMethod_{t}")

M = 10000
for t in tasks:
    for m in methods:
        req_hours = tm_data[t, m]['Effective_Hours']
        model.addConstr(skilled_hours * s[t, m] + laborer_hours * l[t, m] >= req_hours * y[t, m], f"Hours_{t}_{m}")
        model.addConstr(s[t, m] <= M * y[t, m], f"LinkS_{t}_{m}")
        model.addConstr(l[t, m] <= M * y[t, m], f"LinkL_{t}_{m}")

model.addConstr(total_skilled <= max_skilled, "MaxSkilled")
model.addConstr(total_laborers <= max_laborers, "MaxLaborers")
model.addConstr(total_skilled <= skilled_ratio * total_laborers, "SkilledRatio")
model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1, "ExclusionRule")
model.addConstr(s['Task_3', 'Method_B'] >= min_skilled_task3_B * y['Task_3', 'Method_B'], "MinSkilledTask3B")

for t in tasks:
    for m in methods:
        model.addConstr(s[t, m] >= min_share[t] * (s[t, m] + l[t, m]), f"MinShare_{t}_{m}")
        model.addConstr(s[t, m] <= max_share[t] * (s[t, m] + l[t, m]), f"MaxShare_{t}_{m}")

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: inf")
