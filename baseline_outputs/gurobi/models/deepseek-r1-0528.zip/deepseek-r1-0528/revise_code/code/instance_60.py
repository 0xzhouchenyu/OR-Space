import os
import re
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, 'data')
    
    n = 7
    max_route_length_day = 1000
    route_cost_day = 20
    
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'max_route_length_day':
                max_route_length_day = float(row['Value'])
            elif row['Parameter_Name'] == 'route_cost_day':
                route_cost_day = float(row['Value'])
    
    D = [[0] * n for _ in range(n)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:
            nums = re.findall(r'\d+', line)
            if not nums:
                continue
            row_idx = int(nums[0]) - 1
            for j, val in enumerate(nums[1:]):
                col_idx = row_idx + 1 + j
                if col_idx < n:
                    D[row_idx][col_idx] = int(val)
                    D[col_idx][row_idx] = int(val)
    
    model = gp.Model("TwoDayTSP")
    model.setParam('OutputFlag', 0)
    
    days = [0, 1]
    nodes = list(range(n))
    customers = nodes[1:]
    
    y = {}
    for i in customers:
        for d in days:
            y[i, d] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{d}")
    
    z = {}
    for d in days:
        z[d] = model.addVar(vtype=GRB.BINARY, name=f"z_{d}")
    
    x = {}
    for d in days:
        for i in nodes:
            for j in nodes:
                if i != j:
                    x[d, i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{d}_{i}_{j}")
    
    u = {}
    for d in days:
        for i in customers:
            u[d, i] = model.addVar(lb=1.0, ub=6.0, vtype=GRB.CONTINUOUS, name=f"u_{d}_{i}")
    
    for i in customers:
        model.addConstr(gp.quicksum(y[i, d] for d in days) == 1)
    
    for d in days:
        for i in customers:
            model.addConstr(z[d] >= y[i, d])
        model.addConstr(z[d] <= gp.quicksum(y[i, d] for i in customers))
    
    for d in days:
        for i in nodes:
            out_arcs = [x[d, i, j] for j in nodes if j != i]
            in_arcs = [x[d, j, i] for j in nodes if j != i]
            if i == 0:
                model.addConstr(gp.quicksum(out_arcs) == z[d])
                model.addConstr(gp.quicksum(in_arcs) == z[d])
            else:
                model.addConstr(gp.quicksum(out_arcs) == y[i, d])
                model.addConstr(gp.quicksum(in_arcs) == y[i, d])
    
    for d in days:
        for i in customers:
            for j in customers:
                if i != j:
                    model.addConstr(u[d, i] - u[d, j] + 6 * x[d, i, j] <= 5)
    
    for d in days:
        total_dist = gp.quicksum(D[i][j] * x[d, i, j] for i in nodes for j in nodes if i != j)
        model.addConstr(total_dist <= max_route_length_day)
    
    total_dist = gp.quicksum(D[i][j] * x[d, i, j] for d in days for i in nodes for j in nodes if i != j)
    total_fixed = route_cost_day * (z[0] + z[1])
    model.setObjective(total_dist + total_fixed, GRB.MINIMIZE)
    
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
