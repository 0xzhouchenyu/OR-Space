import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'name': row['Product Name'].strip(),
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            })
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    # Extract parameters
    available_labor = params['available_labor']
    available_material = params['available_material']
    fixed_costs = [
        params['fixed_cost_shirts'], 
        params['fixed_cost_short_sleeves'], 
        params['fixed_cost_casual_clothes']
    ]
    min_batches = [
        params['min_batch_shirts'],
        params['min_batch_short_sleeves'],
        params['min_batch_casual_clothes']
    ]
    max_prods = [
        params['max_prod_shirts'],
        params['max_prod_short_sleeves'],
        params['max_prod_casual_clothes']
    ]
    regular_discount = params['segment_regular_discount']
    promo_discount = params['segment_promo_discount']
    promo_labor_cap = params['segment_promo_labor_cap']
    promo_material_cap = params['segment_promo_material_cap']
    
    # Create model
    model = gp.Model("revised_clothing_production")
    model.setParam('OutputFlag', 0)
    
    n = len(products)
    
    # Create variables
    r = model.addVars(n, vtype=GRB.INTEGER, name="regular")
    p = model.addVars(n, vtype=GRB.INTEGER, name="promo")
    z = model.addVars(n, vtype=GRB.BINARY, name="activate")
    
    # Objective: maximize profit
    revenue = gp.quicksum(
        (products[i]['price'] * regular_discount * r[i] +
         products[i]['price'] * promo_discount * p[i] -
         products[i]['var_cost'] * (r[i] + p[i])) 
        for i in range(n)
    )
    fixed_cost = gp.quicksum(fixed_costs[i] * z[i] for i in range(n))
    model.setObjective(revenue - fixed_cost, GRB.MAXIMIZE)
    
    # Resource constraints
    model.addConstr(
        gp.quicksum(products[i]['labor'] * (r[i] + p[i]) for i in range(n)) <= available_labor,
        "labor"
    )
    model.addConstr(
        gp.quicksum(products[i]['material'] * (r[i] + p[i]) for i in range(n)) <= available_material,
        "material"
    )
    
    # Promo segment caps
    model.addConstr(
        gp.quicksum(products[i]['labor'] * p[i] for i in range(n)) <= promo_labor_cap,
        "promo_labor"
    )
    model.addConstr(
        gp.quicksum(products[i]['material'] * p[i] for i in range(n)) <= promo_material_cap,
        "promo_material"
    )
    
    # Activation and min-batch constraints
    for i in range(n):
        total_prod = r[i] + p[i]
        model.addConstr(total_prod >= min_batches[i] * z[i], f"min_batch_{i}")
        model.addConstr(total_prod <= max_prods[i] * z[i], f"max_prod_{i}")
    
    # Solve
    model.optimize()
    
    # Print final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
