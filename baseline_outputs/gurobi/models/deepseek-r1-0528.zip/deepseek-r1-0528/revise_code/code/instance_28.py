import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

initial_fund = params['initial_fund']  # 300000
annual_rate = params['annual_profit_rate'] / 100  # 0.20
inv_limit_y1 = params['investment_limit_year1']  # 150000
return_rate_y1y2 = params['return_rate_year1_to_year2'] / 100  # 1.50
inv_limit_y2 = params['investment_limit_year2']  # 200000
return_rate_y2y3 = params['return_rate_year2_to_year3'] / 100  # 1.60
inv_limit_y3 = params['investment_limit_year3']  # 100000
profit_rate_y3 = params['profit_rate_year3'] / 100  # 0.40
fee_y1 = params['fee_year1']  # 10000
fee_y2 = params['fee_year2']  # 12000
fee_y3 = params['fee_year3']  # 5000

# Create model
model = gp.Model("Investment_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables
a1 = model.addVar(lb=0, name="a1")
a2 = model.addVar(lb=0, name="a2")
a3 = model.addVar(lb=0, name="a3")
b1 = model.addVar(lb=0, ub=inv_limit_y1, name="b1")
c2 = model.addVar(lb=0, ub=inv_limit_y2, name="c2")
d3 = model.addVar(lb=0, ub=inv_limit_y3, name="d3")
use_b1 = model.addVar(vtype=GRB.BINARY, name="use_b1")
use_c2 = model.addVar(vtype=GRB.BINARY, name="use_c2")
use_d3 = model.addVar(vtype=GRB.BINARY, name="use_d3")

# Year 1 budget constraint
model.addConstr(a1 + b1 + fee_y1 * use_b1 <= initial_fund, "Year1_budget")

# Year 2 budget constraint
model.addConstr(
    a2 + c2 + fee_y2 * use_c2 <= 
    initial_fund - a1 - b1 - fee_y1 * use_b1 + a1 * (1 + annual_rate),
    "Year2_budget"
)

# Year 3 budget constraint
model.addConstr(
    a3 + d3 + fee_y3 * use_d3 <= 
    initial_fund - a1 - b1 - fee_y1 * use_b1 + a1 * (1 + annual_rate) 
    - a2 - c2 - fee_y2 * use_c2 + a2 * (1 + annual_rate) + b1 * return_rate_y1y2,
    "Year3_budget"
)

# Linking constraints for fixed fees
model.addConstr(b1 <= inv_limit_y1 * use_b1, "link_b1")
model.addConstr(c2 <= inv_limit_y2 * use_c2, "link_c2")
model.addConstr(d3 <= inv_limit_y3 * use_d3, "link_d3")

# Objective function: maximize net total at end of year 3
obj = (
    initial_fund 
    + annual_rate * (a1 + a2 + a3) 
    + (return_rate_y1y2 - 1) * b1 
    + (return_rate_y2y3 - 1) * c2 
    + profit_rate_y3 * d3 
    - fee_y1 * use_b1 
    - fee_y2 * use_c2 
    - fee_y3 * use_d3
)
model.setObjective(obj, GRB.MAXIMIZE)

# Solve
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")  # Fallback if not optimal
