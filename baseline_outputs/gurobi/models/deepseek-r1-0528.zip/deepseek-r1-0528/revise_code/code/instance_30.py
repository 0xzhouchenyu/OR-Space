import os
import csv
import gurobipy as gp
from gurobipy import GRB

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

feeds = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        feeds.append({
            "Feed": int(row["Feed"]),
            "Protein_g": float(row["Protein_g"]),
            "Minerals_g": float(row["Minerals_g"]),
            "Vitamins_mg": float(row["Vitamins_mg"]),
            "Price_Y_per_kg": float(row["Price_Y_per_kg"])
        })

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

min_protein = params["min_protein_requirement"]
min_minerals = params["min_minerals_requirement"]
min_vitamins = params["min_vitamins_requirement"]

model = gp.Model("FeedBlend")
model.setParam("OutputFlag", 0)

x = {}
for feed in feeds:
    feed_id = feed["Feed"]
    x[feed_id] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"x_{feed_id}")

y4 = model.addVar(vtype=GRB.BINARY, name="y4")
y5 = model.addVar(vtype=GRB.BINARY, name="y5")

total_cost = gp.quicksum(feed["Price_Y_per_kg"] * x[feed["Feed"]] for feed in feeds)
model.setObjective(total_cost, GRB.MINIMIZE)

protein = gp.quicksum(feed["Protein_g"] * x[feed["Feed"]] for feed in feeds)
model.addConstr(protein >= min_protein, "ProteinRequirement")

minerals = gp.quicksum(feed["Minerals_g"] * x[feed["Feed"]] for feed in feeds)
model.addConstr(minerals >= min_minerals, "MineralsRequirement")

vitamins = gp.quicksum(feed["Vitamins_mg"] * x[feed["Feed"]] for feed in feeds)
model.addConstr(vitamins >= min_vitamins, "VitaminsRequirement")

M = 1000
model.addConstr(x[4] <= M * y4, "Feed4_Activation")
model.addConstr(x[5] <= M * y5, "Feed5_Activation")
model.addConstr(y4 + y5 <= 1, "MutualExclusion")

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal:.6f}")
else:
    print("FINAL_OBJ_VALUE: inf")
