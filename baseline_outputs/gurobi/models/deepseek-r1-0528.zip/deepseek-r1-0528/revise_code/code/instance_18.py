import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Get the current script directory and data directory
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load parameters from CSV
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"].strip()] = float(row["Value"].strip())

# Extract parameters
fabric_production_rate = params["fabric_production_rate"]
min_curtain_fabric_sales = params["min_curtain_fabric_sales"]
min_clothing_fabric_sales = params["min_clothing_fabric_sales"]
weekly_production_time = params["weekly_production_time"]
day_shift_regular_capacity = params["day_shift_regular_capacity"]
night_shift_regular_capacity = params["night_shift_regular_capacity"]
day_overtime_limit = params["day_overtime_limit"]
night_overtime_limit = params["night_overtime_limit"]
day_overtime_penalty = params["day_overtime_penalty"]
night_overtime_penalty = params["night_overtime_penalty"]
day_min_utilization_ratio = params["day_min_utilization_ratio"]
night_min_utilization_ratio = params["night_min_utilization_ratio"]

# Convert sales to production hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

# Minimum regular hours per shift
min_day_regular = day_min_utilization_ratio * weekly_production_time
min_night_regular = night_min_utilization_ratio * weekly_production_time

# Create model
model = gp.Model()
model.setParam("OutputFlag", 0)

# Decision variables
R_day = model.addVar(lb=0, ub=day_shift_regular_capacity, name="R_day")
R_night = model.addVar(lb=0, ub=night_shift_regular_capacity, name="R_night")
O_day = model.addVar(lb=0, ub=day_overtime_limit, name="O_day")
O_night = model.addVar(lb=0, ub=night_overtime_limit, name="O_night")

CD = model.addVar(lb=0, name="CD")
CN = model.addVar(lb=0, name="CN")
TD = model.addVar(lb=0, name="TD")
TN = model.addVar(lb=0, name="TN")

# Constraints
model.addConstr(R_day + R_night == weekly_production_time, "Total_regular_hours")
model.addConstr(R_day >= min_day_regular, "Min_day_utilization")
model.addConstr(R_night >= min_night_regular, "Min_night_utilization")
model.addConstr(CD + TD == R_day + O_day, "Day_shift_total")
model.addConstr(CN + TN == R_night + O_night, "Night_shift_total")
model.addConstr(CD + CN >= min_clothing_hours, "Min_clothing")
model.addConstr(TD + TN >= min_curtain_hours, "Min_curtain")

# Objective: minimize overtime penalty
model.setObjective(day_overtime_penalty * O_day + night_overtime_penalty * O_night, GRB.MINIMIZE)

# Solve
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: -1")
