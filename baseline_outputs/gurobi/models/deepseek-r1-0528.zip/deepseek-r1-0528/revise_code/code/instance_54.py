import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

# Setup paths
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

# Import utility function from original
from utils import load_table_1

# Helper function to load general parameters
def load_general_parameters(data_dir):
    params = {}
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            value = row['Value']
            if param_name == 'overtime_hours_cap':
                params['overtime_hours_cap'] = float(value)
            elif param_name == 'overtime_cost_multiplier':
                params['overtime_cost_multiplier'] = float(value)
            elif param_name == 'min_prod_I':
                params['min_prod_I'] = float(value)
            elif param_name == 'min_prod_II':
                params['min_prod_II'] = float(value)
            elif param_name == 'min_prod_III':
                params['min_prod_III'] = float(value)
    return params

# Load data
data_dir = os.path.join(script_dir, '..', 'data')
products, equipment_names, processing_times, effective_hours, base_profit = load_table_1(data_dir)
gen_params = load_general_parameters(data_dir)

# Extract parameters
overtime_hours_cap = gen_params['overtime_hours_cap']
overtime_cost_multiplier = gen_params['overtime_cost_multiplier']
min_prod = {
    'I': gen_params['min_prod_I'],
    'II': gen_params['min_prod_II'],
    'III': gen_params['min_prod_III']
}

# Create model
model = gp.Model("Revised_Production_Plan")
model.setParam('OutputFlag', 0)

# Decision variables
x_reg = model.addVars(products, name="x_reg", lb=0)
x_ot = model.addVars(products, name="x_ot", lb=0)

# Objective: minimize total cost
total_cost = gp.quicksum(base_profit[p] * x_reg[p] for p in products) + \
             gp.quicksum(overtime_cost_multiplier * base_profit[p] * x_ot[p] for p in products)
model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints: Equipment capacity
for e in equipment_names:
    model.addConstr(
        gp.quicksum(processing_times[(e, p)] * (x_reg[p] + x_ot[p]) for p in products) <= effective_hours[e],
        f"eq_cap_{e}"
    )

# Constraint: Plant-wide overtime hours cap
total_ot_hours = gp.quicksum(
    processing_times[(e, p)] * x_ot[p] 
    for e in equipment_names 
    for p in products
)
model.addConstr(total_ot_hours <= overtime_hours_cap, "overtime_cap")

# Constraints: Minimum production levels
for p in products:
    model.addConstr(x_reg[p] + x_ot[p] >= min_prod[p], f"min_prod_{p}")

# Solve
model.optimize()

# Output optimal objective value
print(f"FINAL_OBJ_VALUE: {model.objVal}")
