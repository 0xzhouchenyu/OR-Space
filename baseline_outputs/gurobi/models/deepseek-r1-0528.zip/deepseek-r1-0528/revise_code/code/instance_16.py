import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Get script directory
script_dir = os.path.dirname(os.path.abspath(__file__))

# Load general parameters
params = {}
with open(os.path.join(script_dir, 'data', 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params['fixed_ordering_cost']
month2_bulk_threshold = params['month2_bulk_receiving_threshold']
month2_bulk_fee = params['month2_bulk_receiving_fee']

# Load monthly data
months = []
purchasing_prices = {}
selling_prices = {}
with open(os.path.join(script_dir, 'data', 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        month = int(row['Month'])
        months.append(month)
        purchasing_prices[month] = float(row['Purchasing_Price_Yuan'])
        selling_prices[month] = float(row['Selling_Price_Yuan'])

# Create model
model = gp.Model("Revised_Model")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}  # purchase in month m
s = {}  # sales in month m
inv = {}  # end inventory in month m
z = {}  # fixed order indicator for month m

for m in months:
    x[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"purchase_{m}")
    s[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"sell_{m}")
    inv[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"inventory_{m}")
    z[m] = model.addVar(vtype=GRB.BINARY, name=f"order_flag_{m}")

# Binary for Feb bulk fee
w = model.addVar(vtype=GRB.BINARY, name="feb_bulk_flag")

# Objective: total profit
revenue = gp.quicksum(selling_prices[m] * s[m] for m in months)
purchase_cost = gp.quicksum(purchasing_prices[m] * x[m] for m in months)
fixed_costs = fixed_ordering_cost * gp.quicksum(z[m] for m in months)
feb_fee = month2_bulk_fee * w
model.setObjective(revenue - purchase_cost - fixed_costs - feb_fee, GRB.MAXIMIZE)

# Constraints
for m in months:
    if m == 1:
        prev_inv = initial_stock
    else:
        prev_inv = inv[m-1]
    
    # Inventory balance
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], f"inventory_balance_{m}")
    
    # Warehouse capacity after purchase
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, f"warehouse_after_purchase_{m}")
    
    # End inventory capacity
    model.addConstr(inv[m] <= warehouse_capacity, f"warehouse_end_{m}")
    
    # Sales limit
    model.addConstr(s[m] <= prev_inv + x[m], f"sell_limit_{m}")
    
    # Fixed ordering cost activation
    model.addConstr(x[m] <= warehouse_capacity * z[m], f"fixed_ordering_activation_{m}")

# February bulk fee activation
model.addConstr(x[2] - month2_bulk_threshold <= warehouse_capacity * w, "feb_bulk_fee_activation")

# Solve
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
