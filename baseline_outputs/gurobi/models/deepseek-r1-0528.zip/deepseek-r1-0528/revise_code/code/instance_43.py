import os
import sys
from gurobipy import GRB
import gurobipy as gp
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from utils import load_parameters

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))
    
    min_A = params['min_raw_material_A']
    min_B = params['min_raw_material_B']
    min_C = params['min_raw_material_C']
    
    cap_A_a = params['warehouse_A_truck_capacity_A']
    cap_A_b = params['warehouse_A_truck_capacity_B']
    cap_A_c = params['warehouse_A_truck_capacity_C']
    cost_A = params['warehouse_A_truck_cost']
    fixed_cost_A = params['warehouse_A_fixed_cost']
    
    cap_B_a = params['warehouse_B_truck_capacity_A']
    cap_B_b = params['warehouse_B_truck_capacity_B']
    cap_B_c = params['warehouse_B_truck_capacity_C']
    cost_B = params['warehouse_B_truck_cost']
    fixed_cost_B = params['warehouse_B_fixed_cost']
    B_threshold = params['warehouse_B_overflow_threshold_trucks']
    B_overflow_cost = params['warehouse_B_overflow_coordination_cost']
    reconciliation_fee = params['dual_warehouse_reconciliation_fee']
    
    model = gp.Model("RevisedFreightCost")
    model.setParam('OutputFlag', 0)
    
    x = model.addVar(vtype=GRB.INTEGER, name="trucks_from_A", lb=0)
    y = model.addVar(vtype=GRB.INTEGER, name="trucks_from_B", lb=0)
    uA = model.addVar(vtype=GRB.BINARY, name="use_A")
    uB = model.addVar(vtype=GRB.BINARY, name="use_B")
    v = model.addVar(vtype=GRB.BINARY, name="overflow_B")
    w = model.addVar(vtype=GRB.BINARY, name="both_used")
    
    model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
    model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
    model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")
    
    M = 10000
    model.addConstr(x <= M * uA, "Link_x_uA")
    model.addConstr(y <= M * uB, "Link_y_uB")
    
    model.addConstr(y >= (B_threshold + 1) * v, "B_overflow_lower")
    model.addConstr(y <= B_threshold + M * v, "B_overflow_upper")
    
    model.addConstr(w >= uA + uB - 1, "BothUsed_lower")
    model.addConstr(w <= uA, "BothUsed_upperA")
    model.addConstr(w <= uB, "BothUsed_upperB")
    
    total_cost = (
        cost_A * x + cost_B * y +
        fixed_cost_A * uA + fixed_cost_B * uB +
        B_overflow_cost * v +
        reconciliation_fee * w
    )
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
