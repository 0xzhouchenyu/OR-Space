import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, 'data')
    
    # Read table_1.csv
    proc_time = {}
    capacity = {}
    cost_rate = {}
    raw_cost = {}
    price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            if equip == 'Raw_Material_Cost':
                raw_cost['I'] = float(row['Product_I'])
                raw_cost['II'] = float(row['Product_II'])
                raw_cost['III'] = float(row['Product_III'])
            elif equip == 'Unit_Price':
                price['I'] = float(row['Product_I'])
                price['II'] = float(row['Product_II'])
                price['III'] = float(row['Product_III'])
            else:
                for prod, col in [('I', 'Product_I'), ('II', 'Product_II'), ('III', 'Product_III')]:
                    val = row[col].strip()
                    if val != '-':
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row['Effective_Machine_Hours'])
                cost_rate[equip] = float(row['Processing_Cost_per_Machine_Hour'])
    
    # Read setup_costs.csv
    setup_cost = {}
    with open(os.path.join(data_dir, 'setup_costs.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            setup_cost[equip] = float(row['Fixed_Setup_Cost'])
    
    # Read general_parameters.csv for joint calibration fee
    joint_fee_value = 100.0
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            if param_name == 'A2_B2_joint_calibration_fee':
                joint_fee_value = float(row['Value'])
    
    # Equipment assignments
    stage_A_equip = {'I': ['A1', 'A2'], 'II': ['A1', 'A2'], 'III': ['A2']}
    stage_B_equip = {'I': ['B1', 'B2', 'B3'], 'II': ['B1'], 'III': ['B2']}
    equipments = ['A1', 'A2', 'B1', 'B2', 'B3']
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    for p in ['I', 'II', 'III']:
        for e in stage_A_equip[p]:
            x[(e, p)] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")
        for e in stage_B_equip[p]:
            x[(e, p)] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}")
    
    y = model.addVars(equipments, vtype=GRB.BINARY, name="y")
    z = model.addVar(vtype=GRB.BINARY, name="z")
    
    # Flow conservation constraints
    for p in ['I', 'II', 'III']:
        total_A = gp.quicksum(x[(e, p)] for e in stage_A_equip[p])
        total_B = gp.quicksum(x[(e, p)] for e in stage_B_equip[p])
        model.addConstr(total_A == total_B, f"flow_{p}")
    
    # Capacity constraints with equipment usage indicators
    for e in equipments:
        time_e = gp.quicksum(proc_time[(e, p)] * x[(e, p)] for p in ['I', 'II', 'III'] if (e, p) in x)
        model.addConstr(time_e <= capacity[e] * y[e], f"cap_{e}")
    
    # Joint calibration constraints
    model.addConstr(z <= y['A2'], "z_A2")
    model.addConstr(z <= y['B2'], "z_B2")
    model.addConstr(z >= y['A2'] + y['B2'] - 1, "z_joint")
    
    # Objective components
    revenue = gp.quicksum(price[p] * gp.quicksum(x[(e, p)] for e in stage_A_equip[p]) for p in ['I', 'II', 'III'])
    raw_mat = gp.quicksum(raw_cost[p] * gp.quicksum(x[(e, p)] for e in stage_A_equip[p]) for p in ['I', 'II', 'III'])
    proc_cost = gp.quicksum(cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x)
    setup_costs = gp.quicksum(setup_cost[e] * y[e] for e in equipments)
    joint_fee = joint_fee_value * z
    
    model.setObjective(revenue - raw_mat - proc_cost - setup_costs - joint_fee, GRB.MAXIMIZE)
    
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")

if __name__ == '__main__':
    main()
