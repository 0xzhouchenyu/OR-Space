import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load parameters
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    param_file = os.path.join(data_dir, 'general_parameters.csv')
    df = pd.read_csv(param_file)
    params = dict(zip(df['Parameter_Name'], df['Value']))
    
    commodities = ['steel', 'engine', 'electronics', 'plastic']
    model = gp.Model("Carelland_GDP_Maximization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    production = model.addVars(commodities, name="prod", lb=0)
    imports = model.addVars(commodities, name="import", lb=0, ub=params['import_quota'])
    exports = model.addVars(commodities, name="export", lb=0)
    overtime = model.addVar(name="overtime", lb=0, ub=params['overtime_cap'])
    
    # Apply production limits
    production['engine'].ub = params['engine_production_limit']
    production['plastic'].ub = params['plastic_production_limit']
    
    # Supply-demand constraints
    for c in commodities:
        input_use = gp.quicksum(
            params.get(f"{other}_{c}_requirement", 0) * production[other]
            for other in commodities
        )
        model.addConstr(production[c] + imports[c] == input_use + exports[c], f"supply_demand_{c}")
    
    # Labor constraint
    total_labor = gp.quicksum(
        params[f"{c}_labor_requirement"] * production[c] for c in commodities
    )
    model.addConstr(total_labor <= params['labor_force'] + overtime, "labor_capacity")
    
    # Objective components
    export_revenue = gp.quicksum(
        params[f"{c}_price"] * exports[c] for c in commodities
    )
    import_cost = gp.quicksum(
        params['import_premium_ratio'] * params[f"{c}_price"] * imports[c] for c in commodities
    )
    input_import_cost = gp.quicksum(
        params.get(f"{c}_import_cost", 0) * production[c] for c in commodities
    )
    overtime_cost = params['overtime_wage'] * overtime
    
    gdp = export_revenue - import_cost - input_import_cost - overtime_cost
    model.setObjective(gdp, GRB.MAXIMIZE)
    
    # Solve and output
    model.optimize()
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.ObjVal, 3)}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == '__main__':
    main()
