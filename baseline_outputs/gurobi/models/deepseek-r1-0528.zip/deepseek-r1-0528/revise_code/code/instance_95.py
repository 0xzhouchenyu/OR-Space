import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_table_1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    weeks = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })
    return weeks

def load_general_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

weeks_data = load_table_1(data_dir)
params = load_general_parameters(data_dir)

storage_cost = params['storage_cost_per_thousand_boxes']
fixed_setup_cost = params['fixed_setup_cost']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']
week2_push_threshold = params['week2_push_threshold']
week3_capacity_loss = params['week3_capacity_loss_after_week2_push']

n_weeks = len(weeks_data)
week_demands = [w['demand'] for w in weeks_data]
week_capacities = [w['capacity'] for w in weeks_data]
week_costs = [w['cost'] for w in weeks_data]

model = gp.Model("Beverage_Production_Planning")
model.setParam('OutputFlag', 0)

x = model.addVars(n_weeks, lb=0, name="x")
s = model.addVars(n_weeks, lb=0, name="s")
y = model.addVars(n_weeks, vtype=GRB.BINARY, name="y")

z = model.addVar(vtype=GRB.BINARY, name="z")
w = model.addVar(vtype=GRB.BINARY, name="w")

total_cost = gp.quicksum(week_costs[t] * x[t] for t in range(n_weeks))
total_cost += storage_cost * s.sum()
total_cost += fixed_setup_cost * y.sum()
total_cost += week2_microclean_fee * z
model.setObjective(total_cost, GRB.MINIMIZE)

for t in range(n_weeks):
    cap = week_capacities[t]
    if t == 0:
        model.addConstr(x[t] - s[t] == week_demands[t], f"balance_week_{t+1}")
    else:
        model.addConstr(s[t-1] + x[t] - s[t] == week_demands[t], f"balance_week_{t+1}")
    
    if t != 2:
        model.addConstr(x[t] <= cap * y[t], f"setup_week_{t+1}")
    else:
        model.addConstr(x[t] <= (cap - week3_capacity_loss * w) * y[t], f"setup_week_{t+1}")

week2_idx = 1
model.addConstr(x[week2_idx] <= week2_microclean_threshold + (week_capacities[week2_idx] - week2_microclean_threshold) * z, 
                "microclean_trigger")
model.addConstr(x[week2_idx] <= week2_push_threshold + (week_capacities[week2_idx] - week2_push_threshold) * w, 
                "push_trigger")

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: inf")
