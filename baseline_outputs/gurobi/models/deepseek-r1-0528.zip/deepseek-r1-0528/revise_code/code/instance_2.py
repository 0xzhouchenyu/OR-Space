import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

current_dir = os.path.dirname(os.path.abspath(__file__))
data_file = os.path.join(current_dir, "data", "general_parameters.csv")
params = load_parameters(data_file)

a1 = params['a1']
a2 = params['a2']
training_capacity = params['training_capacity_per_jet']
dual_use_eff = params['dual_use_training_efficiency']
training_cap_frac = params['training_intensity_cap']
combat_min = params['combat_jet_min_year2']
combat_weight = params['combat_weight']
training_weight = params['training_weight']

m = gp.Model()
m.setParam('OutputFlag', 0)

T1 = m.addVar(vtype=GRB.INTEGER, name="T1")
C1 = m.addVar(vtype=GRB.INTEGER, name="C1")
D1 = m.addVar(vtype=GRB.INTEGER, name="D1")
T2 = m.addVar(vtype=GRB.INTEGER, name="T2")
C2 = m.addVar(vtype=GRB.INTEGER, name="C2")
D2 = m.addVar(vtype=GRB.INTEGER, name="D2")

m.addConstr(T1 + C1 + D1 == a1, "year1_alloc")
m.addConstr(T2 + C2 + D2 == a1 + a2, "year2_alloc")
m.addConstr(T1 + D1 <= training_cap_frac * a1, "train_cap_year1")
m.addConstr(T2 + D2 <= training_cap_frac * (a1 + a2), "train_cap_year2")
m.addConstr(C2 + D2 >= combat_min, "min_combat_year2")

combat_jets_year2 = C2 + D2
pilots_trained = training_capacity * (T1 + T2 + dual_use_eff * (D1 + D2))

total_obj = combat_weight * combat_jets_year2 + training_weight * pilots_trained
m.setObjective(total_obj, GRB.MAXIMIZE)

m.optimize()

if m.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {m.objVal}")
else:
    print(f"FINAL_OBJ_VALUE: {None}")
