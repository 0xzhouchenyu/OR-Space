import os
import csv
import itertools
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

script_dir = os.path.dirname(os.path.abspath(__file__))
data_file = os.path.join(script_dir, "data", "general_parameters.csv")
params = load_general_parameters(data_file)

motorcycle_pollution = params['motorcycle_pollution']
small_truck_pollution = params['small_truck_pollution']
large_truck_pollution = params['large_truck_pollution']
max_motorcycle_trips = int(params['max_motorcycle_trips'])
motorcycle_capacity = params['motorcycle_capacity']
small_truck_capacity = params['small_truck_capacity']
large_truck_capacity = params['large_truck_capacity']
max_total_trips = int(params['max_total_trips'])
demand_peak = params['demand_peak_units']
demand_offpeak = params['demand_offpeak_units']
leasing_capacity = params['leasing_capacity']
leasing_pollution_per_unit = params['leasing_pollution_per_unit']
leasing_fixed_pollution = params['leasing_fixed_pollution']
max_leasing_peak = params['max_leasing_fraction_peak'] * demand_peak
bigM_leasing = params['bigM_leasing']
epsilon = params['epsilon']

methods = ['motorcycle', 'small_truck', 'large_truck']
periods = ['peak', 'offpeak']
pollution = {
    'motorcycle': motorcycle_pollution,
    'small_truck': small_truck_pollution,
    'large_truck': large_truck_pollution
}
capacity = {
    'motorcycle': motorcycle_capacity,
    'small_truck': small_truck_capacity,
    'large_truck': large_truck_capacity
}

best_obj = float('inf')

for combo in itertools.combinations(methods, 2):
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Variables for owned trips
    trips = {}
    for m in combo:
        for p in periods:
            trips[(m, p)] = model.addVar(vtype=GRB.INTEGER, name=f"trips_{m}_{p}", lb=0)
    
    # Leasing variables
    L_peak = model.addVar(vtype=GRB.CONTINUOUS, name="L_peak", lb=0)
    L_offpeak = model.addVar(vtype=GRB.CONTINUOUS, name="L_offpeak", lb=0)
    z = model.addVar(vtype=GRB.BINARY, name="z")
    
    # Objective: minimize total pollution
    owned_pollution = gp.quicksum(pollution[m] * (trips[(m, 'peak')] + trips[(m, 'offpeak')]) for m in combo)
    leasing_pollution = leasing_pollution_per_unit * (L_peak + L_offpeak) + leasing_fixed_pollution * z
    model.setObjective(owned_pollution + leasing_pollution, GRB.MINIMIZE)
    
    # Demand constraints
    model.addConstr(gp.quicksum(capacity[m] * trips[(m, 'peak')] for m in combo) + L_peak >= demand_peak, "peak_demand")
    model.addConstr(gp.quicksum(capacity[m] * trips[(m, 'offpeak')] for m in combo) + L_offpeak >= demand_offpeak, "offpeak_demand")
    
    # Leasing constraints
    model.addConstr(L_peak + L_offpeak <= leasing_capacity, "leasing_cap")
    model.addConstr(L_peak <= max_leasing_peak, "leasing_peak_limit")
    model.addConstr(L_peak + L_offpeak <= bigM_leasing * z, "leasing_activation")
    model.addConstr(L_peak + L_offpeak >= epsilon * z, "leasing_min")
    
    # Owned trips constraints
    total_trips = gp.quicksum(trips[(m, p)] for m in combo for p in periods)
    model.addConstr(total_trips <= max_total_trips, "max_trips")
    
    if 'motorcycle' in combo:
        mc_trips = trips[('motorcycle', 'peak')] + trips[('motorcycle', 'offpeak')]
        model.addConstr(mc_trips <= max_motorcycle_trips, "mc_max")
    
    # Unused methods set to zero implicitly by variable bounds
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.ObjVal
        if obj_val < best_obj:
            best_obj = obj_val

print(f"FINAL_OBJ_VALUE: {best_obj}")
