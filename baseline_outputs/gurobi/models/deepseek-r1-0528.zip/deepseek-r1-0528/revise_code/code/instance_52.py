import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read shift requirements
    required = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            required.append(int(row['Required_number']))
    
    n = len(required)  # number of periods (6)
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            value = row['Value']
            if param_name in ['max_night_driver_fraction', 'max_night_crew_fraction', 'overtime_cost_factor']:
                params[param_name] = float(value)
            else:
                params[param_name] = int(value) if value.isdigit() else value
    
    # Create model
    model = gp.Model("BusStaffing")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = model.addVars(n, vtype=GRB.INTEGER, name="driver_reg")  # regular drivers
    y = model.addVars(n, vtype=GRB.INTEGER, name="crew_reg")    # regular crew
    dx = model.addVars(n, vtype=GRB.INTEGER, name="driver_ot")  # overtime drivers
    dy = model.addVars(n, vtype=GRB.INTEGER, name="crew_ot")    # overtime crew
    
    # Coverage constraints for each period
    for j in range(n):
        # Period j is covered by shifts starting at j and (j-1) mod n
        cover_drivers = x[j] + x[(j-1) % n] + dx[j] + dx[(j-1) % n]
        cover_crew = y[j] + y[(j-1) % n] + dy[j] + dy[(j-1) % n]
        model.addConstr(cover_drivers >= required[j], f"drivers_cov_period_{j+1}")
        model.addConstr(cover_crew >= required[j], f"crew_cov_period_{j+1}")
    
    # Night shift fraction constraints
    night_periods = [4, 5]  # periods 5 and 6 (0-indexed 4 and 5)
    total_drivers = sum(x[i] + dx[i] for i in range(n))
    total_crew = sum(y[i] + dy[i] for i in range(n))
    model.addConstr(sum(x[i] + dx[i] for i in night_periods) <= params['max_night_driver_fraction'] * total_drivers, "driver_night_frac")
    model.addConstr(sum(y[i] + dy[i] for i in night_periods) <= params['max_night_crew_fraction'] * total_crew, "crew_night_frac")
    
    # Overtime cap
    model.addConstr(sum(dx[i] + dy[i] for i in range(n)) <= params['max_overtime_shifts'], "total_overtime_cap")
    
    # Objective: minimize total cost (regular shifts cost 1, overtime cost 1.5)
    obj = sum(x[i] + y[i] for i in range(n)) + params['overtime_cost_factor'] * sum(dx[i] + dy[i] for i in range(n))
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Output final objective value
    print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
