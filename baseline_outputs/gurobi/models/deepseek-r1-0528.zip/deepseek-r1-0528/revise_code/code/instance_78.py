import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    # Get data paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    gen_params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    table_path = os.path.join(base_dir, "data", "table_3_3.csv")
    
    # Load data
    params_df = pd.read_csv(gen_params_path)
    df = pd.read_csv(table_path)
    
    # Extract parameters
    sales_goal = float(params_df.loc[params_df['Parameter_Name'] == 'monthly_sales_goal', 'Value'].iloc[0])
    overtime_ratio = float(params_df.loc[params_df['Parameter_Name'] == 'pt_ft_overtime_ratio', 'Value'].iloc[0])
    
    # Extract clerk data
    ft_row = df[df['Role'] == 'Full-time'].iloc[0]
    pt_row = df[df['Role'] == 'Part-time'].iloc[0]
    
    # Determine number of clerks (using classic values as fallback)
    num_ft, num_pt = 5, 4
    for col in df.columns:
        if any(kw in col.lower() for kw in ['num', 'clerks', 'employees', 'count', '人员', '数量']):
            num_ft = int(ft_row[col])
            num_pt = int(pt_row[col])
            break
    
    # Calculate normal sales
    normal_sales_ft = num_ft * ft_row['Monthly_Working_Hours'] * ft_row['Sales_Volume_Pairs_Per_Hour']
    normal_sales_pt = num_pt * pt_row['Monthly_Working_Hours'] * pt_row['Sales_Volume_Pairs_Per_Hour']
    total_normal_sales = normal_sales_ft + normal_sales_pt
    
    # Create Gurobi model
    model = gp.Model("Overtime_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables for overtime hours
    y_ft = model.addVar(lb=0, name="y_ft")
    y_pt = model.addVar(lb=0, name="y_pt")
    
    # Objective: minimize total overtime hours
    model.setObjective(y_ft + y_pt, GRB.MINIMIZE)
    
    # Sales constraint: overtime must cover deficit
    model.addConstr(
        y_ft * ft_row['Sales_Volume_Pairs_Per_Hour'] + 
        y_pt * pt_row['Sales_Volume_Pairs_Per_Hour'] >= 
        sales_goal - total_normal_sales,
        "Sales_Goal"
    )
    
    # Revised constraint: part-time overtime >= ratio * full-time overtime
    model.addConstr(y_pt >= overtime_ratio * y_ft, "Overtime_Ratio")
    
    # Solve model
    model.optimize()
    
    # Output objective value
    print(f"FINAL_OBJ_VALUE: {round(model.ObjVal, 4)}")

if __name__ == '__main__':
    main()
