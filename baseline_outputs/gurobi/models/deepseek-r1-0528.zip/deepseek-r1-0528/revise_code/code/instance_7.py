import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, 'data')

warehouses_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
ports_data = load_csv_data(os.path.join(data_dir, 'table_2.csv'))
distance_data = load_csv_data(os.path.join(data_dir, 'table_3.csv'))
general_params = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
shortage_penalty_data = load_csv_data(os.path.join(data_dir, 'shortage_penalty.csv'))

warehouses = [row['Warehouse'] for row in warehouses_data]
supply = {row['Warehouse']: int(row['Empty_Containers']) for row in warehouses_data}

ports = [row['Port'] for row in ports_data]
demand = {row['Port']: int(row['Container_Demand']) for row in ports_data}

distance = {}
for row in distance_data:
    wh = row['Warehouse']
    for port in ports:
        distance[(wh, port)] = float(row[port])

params = {}
for row in general_params:
    params[row['Parameter_Name']] = float(row['Value'])
cost_per_km = params['cost_per_km']
adriatic_trigger = params['adriatic_pool_shortage_trigger']
adriatic_fee = params['adriatic_pool_recovery_fee']

shortage_charge = {}
grace_containers = {}
recovery_fee = {}
for row in shortage_penalty_data:
    port = row['Port']
    shortage_charge[port] = float(row['Shortage_Charge'])
    grace_containers[port] = float(row['Grace_Containers'])
    recovery_fee[port] = float(row['Recovery_Fee'])

adriatic_ports = ['Venice', 'Ancona', 'Bari']
total_adriatic_demand = sum(demand[j] for j in adriatic_ports)

model = gp.Model()
model.setParam('OutputFlag', 0)

x = {}
for i in warehouses:
    for j in ports:
        x[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}")

s = {}
for j in ports:
    s[j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"s_{j}")

y = {}
for j in ports:
    y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")

z = model.addVar(vtype=GRB.BINARY, name="z")

for i in warehouses:
    model.addConstr(gp.quicksum(x[i, j] for j in ports) <= supply[i], f"supply_{i}")

for j in ports:
    model.addConstr(s[j] >= demand[j] - gp.quicksum(x[i, j] for i in warehouses), f"shortage_def_{j}")

for j in ports:
    model.addConstr(s[j] <= grace_containers[j] + demand[j] * y[j], f"trigger_{j}")

model.addConstr(gp.quicksum(s[j] for j in adriatic_ports) <= adriatic_trigger + total_adriatic_demand * (1 - z), "adriatic_trigger")

transport_cost = gp.quicksum(x[i, j] * distance[i, j] * cost_per_km for i in warehouses for j in ports)
shortage_penalty = gp.quicksum(s[j] * shortage_charge[j] for j in ports)
port_recovery_fee = gp.quicksum(recovery_fee[j] * y[j] for j in ports)
adriatic_recovery_fee = adriatic_fee * z

model.setObjective(transport_cost + shortage_penalty + port_recovery_fee + adriatic_recovery_fee, GRB.MINIMIZE)
model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
