import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, 'data', filename)

def main():
    # Load general parameters
    params_df = pd.read_csv(get_data_path('general_parameters.csv'))
    params = {}
    for _, row in params_df.iterrows():
        name = row['Parameter_Name']
        value = row['Value']
        if value == 'True':
            value = True
        elif value == 'False':
            value = False
        elif value.replace('.', '', 1).isdigit():
            if '.' in value:
                value = float(value)
            else:
                value = int(value)
        elif value == 'Unlimited':
            value = None
        params[name] = value

    min_contract_types = params['min_contract_types']
    max_contract_types = params['max_contract_types']
    mutual_exclusion = params['mutual_exclusion_1_and_4']
    min_area_per_contract = params['min_area_per_contract_units']
    activation_fee = params['activation_fee_per_contract']
    onboarding_loss = params['onboarding_loss_units']
    expedited_fee = params['expedited_onboarding_fee']
    max_parallel = params['monthly_max_parallel_contracts']

    # Load demands and costs
    demands_df = pd.read_csv(get_data_path('table_1.csv'))
    demands = {row['Month']: row['Required_area_㎡'] / 100.0 for _, row in demands_df.iterrows()}
    
    costs_df = pd.read_csv(get_data_path('table_2.csv'))
    costs = {row['Contract_length_months']: row['Rental_fee_per_100㎡_yuan'] for _, row in costs_df.iterrows()}

    months = [1, 2, 3, 4]
    contract_lengths = [1, 2, 3, 4]

    model = gp.Model()
    model.setParam('OutputFlag', 0)

    # Variables
    area_vars = {}
    n_reg_vars = {}
    n_exp_vars = {}
    for i in months:
        for j in contract_lengths:
            if i + j - 1 <= 4:
                area_vars[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"area_{i}_{j}")
                n_reg_vars[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_reg_{i}_{j}")
                n_exp_vars[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_exp_{i}_{j}")

    # Binary variables for contract length usage
    y = {j: model.addVar(vtype=GRB.BINARY, name=f"y_{j}") for j in contract_lengths}

    # Constraints
    # Minimum area per contract
    for (i, j) in area_vars:
        model.addConstr(area_vars[i, j] >= min_area_per_contract * (n_reg_vars[i, j] + n_exp_vars[i, j]), 
                       f"min_area_{i}_{j}")

    # Demand fulfillment
    for m in months:
        total_area = gp.quicksum(area_vars[i, j] for (i, j) in area_vars if i <= m and i+j-1 >= m)
        loss = gp.quicksum(n_reg_vars[m, j] for j in contract_lengths if (m, j) in n_reg_vars)
        model.addConstr(total_area - loss == demands[m], f"demand_{m}")

    # Active contracts per month
    for m in months:
        active = gp.quicksum(n_reg_vars[i, j] + n_exp_vars[i, j] 
                            for (i, j) in area_vars if i <= m and i+j-1 >= m)
        model.addConstr(active <= max_parallel, f"active_{m}")

    # Contract type usage
    M = 100  # Big M constant
    for j in contract_lengths:
        total_contracts = gp.quicksum(n_reg_vars[i, j] + n_exp_vars[i, j] for i in months if (i, j) in area_vars)
        model.addConstr(total_contracts >= y[j], f"y_lb_{j}")
        model.addConstr(total_contracts <= M * y[j], f"y_ub_{j}")

    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) >= min_contract_types, "min_types")
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) <= max_contract_types, "max_types")

    if mutual_exclusion:
        model.addConstr(y[1] + y[4] <= 1, "mutual_exclusion")

    # Objective
    rental_cost = gp.quicksum(area_vars[i, j] * costs[j] for (i, j) in area_vars)
    activation_cost = gp.quicksum((n_reg_vars[i, j] + n_exp_vars[i, j]) * activation_fee for (i, j) in area_vars)
    expedited_cost = gp.quicksum(n_exp_vars[i, j] * expedited_fee for (i, j) in area_vars)
    total_cost = rental_cost + activation_cost + expedited_cost
    model.setObjective(total_cost, GRB.MINIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
