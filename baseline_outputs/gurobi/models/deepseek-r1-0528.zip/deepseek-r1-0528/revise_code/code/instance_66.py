import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Define paths
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row["Parameter_Name"]] = float(row["Value"])

# Read toy data
toys = []
with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            "type": row["Toy_Type"],
            "labor": float(row["Manufacturing_Labor_Hours"]),
            "inspection": float(row["Inspection_Hours"]),
            "profit": float(row["Profit_Per_Unit"])
        })

# Extract parameters
available_labor1 = params["available_labor_hours_period1"]
available_labor2 = params["available_labor_hours_period2"]
available_insp1 = params["available_inspection_hours_period1"]
available_insp2 = params["available_inspection_hours_period2"]
overtime_cost = params["overtime_labor_cost"]
safety_fee = params["seasonal_safety_review_fee"]

# Extract demand parameters
max_demand = {
    "High-End": {"period1": params["max_demand_high_end_period1"], "period2": params["max_demand_high_end_period2"]},
    "Mid-Range": {"period1": params["max_demand_mid_range_period1"], "period2": params["max_demand_mid_range_period2"]},
    "Low-End": {"period1": params["max_demand_low_end_period1"], "period2": params["max_demand_low_end_period2"]}
}

# Create model
model = gp.Model("ToyProduction")
model.setParam("OutputFlag", 0)

# Decision variables
x = {}  # Production quantities: (toy_type, period)
for toy in toys:
    ttype = toy["type"]
    x[ttype, 1] = model.addVar(lb=0, name=f"x_{ttype}_period1")
    x[ttype, 2] = model.addVar(lb=0, name=f"x_{ttype}_period2")

o1 = model.addVar(lb=0, name="overtime1")  # Overtime in period 1
o2 = model.addVar(lb=0, name="overtime2")  # Overtime in period 2
f = model.addVar(vtype=GRB.BINARY, name="fatigue_indicator")  # 1 if period1 overtime > threshold
s = model.addVar(vtype=GRB.BINARY, name="safety_indicator")   # 1 if total overtime > threshold

# Objective: maximize profit
total_profit = gp.quicksum(toy["profit"] * (x[toy["type"], 1] + x[toy["type"], 2]) for toy in toys)
total_profit -= overtime_cost * (o1 + o2)
total_profit -= safety_fee * s
model.setObjective(total_profit, GRB.MAXIMIZE)

# Labor constraints
labor1 = gp.quicksum(toy["labor"] * x[toy["type"], 1] for toy in toys)
model.addConstr(labor1 <= available_labor1 + o1, "LaborPeriod1")

labor2 = gp.quicksum(toy["labor"] * x[toy["type"], 2] for toy in toys)
model.addConstr(labor2 <= available_labor2 + o2 - 25 * f, "LaborPeriod2")

# Inspection constraints
insp1 = gp.quicksum(toy["inspection"] * x[toy["type"], 1] for toy in toys)
model.addConstr(insp1 <= available_insp1, "InspectionPeriod1")

insp2 = gp.quicksum(toy["inspection"] * x[toy["type"], 2] for toy in toys)
model.addConstr(insp2 <= available_insp2, "InspectionPeriod2")

# Demand constraints
for toy in toys:
    ttype = toy["type"]
    model.addConstr(x[ttype, 1] <= max_demand[ttype]["period1"], f"Demand_{ttype}_period1")
    model.addConstr(x[ttype, 2] <= max_demand[ttype]["period2"], f"Demand_{ttype}_period2")

# Overtime cap
model.addConstr(o1 + o2 <= 60, "TotalOvertimeCap")

# Fatigue carryover constraints
model.addConstr((f == 1) >> (o1 >= 20.0001), "FatigueTrigger")
model.addConstr((f == 0) >> (o1 <= 20), "NoFatigue")

# Safety review constraints
model.addConstr((s == 1) >> (o1 + o2 >= 45.0001), "SafetyTrigger")
model.addConstr((s == 0) >> (o1 + o2 <= 45), "NoSafetyFee")

# Solve
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
