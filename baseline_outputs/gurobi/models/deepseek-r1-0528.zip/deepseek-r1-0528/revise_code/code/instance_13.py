import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_file = os.path.join(base_dir, 'data', 'general_parameters.csv')
    
    params = {}
    with open(data_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[key] = value

    profit_corn = params['profit_per_acre_corn']
    profit_wheat = params['profit_per_acre_wheat']
    profit_soybeans = params['profit_per_acre_soybeans']
    profit_sorghum = params['profit_per_acre_sorghum']
    total_area = params['total_farm_area']
    corn_wheat_ratio = params['corn_wheat_ratio']
    soybeans_sorghum_ratio = params['soybeans_sorghum_ratio']
    wheat_sorghum_ratio = params['wheat_sorghum_ratio']
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    corn = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="corn")
    wheat = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="wheat")
    soybeans = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="soybeans")
    sorghum = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="sorghum")
    
    model.setObjective(
        profit_corn * corn +
        profit_wheat * wheat +
        profit_soybeans * soybeans +
        profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )
    
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")
    model.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio")
    model.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio")
    model.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_ratio")
    model.addConstr(corn >= 20, "min_corn")
    model.addConstr(soybeans == 0, "soybeans_exclusion")
    
    model.optimize()
    
    if model.SolCount > 0:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        fallback_obj = profit_corn * total_area
        print(f"FINAL_OBJ_VALUE: {fallback_obj}")

if __name__ == "__main__":
    main()
