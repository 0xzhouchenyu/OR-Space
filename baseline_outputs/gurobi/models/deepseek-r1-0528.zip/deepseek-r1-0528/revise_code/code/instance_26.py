import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, "general_parameters.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row["Parameter_Name"].strip()
            params[param_name] = float(row["Value"].strip())
    
    # Read staffing requirements
    requirements = {}
    with open(os.path.join(data_dir, "table_1.csv"), "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row["Time_Period"].strip()
            req = int(row["Required_Salespeople"].strip())
            requirements[period] = req
    
    # Periods in order
    periods = [
        "2:00-6:00", "6:00-10:00", "10:00-14:00", 
        "14:00-18:00", "18:00-22:00", "22:00-2:00"
    ]
    req_values = [requirements[p] for p in periods]
    n = len(periods)
    
    # Extract parameters
    full_time_cost = params["full_time_cost"]
    part_time_cost = params["part_time_cost"]
    part_time_cap = int(params["part_time_cap_per_period"])
    min_full_time = int(params["min_full_time_per_period"])
    
    # Create model
    model = gp.Model("StaffScheduling")
    model.setParam('OutputFlag', 0)
    
    # Variables
    x = model.addVars(n, vtype=GRB.INTEGER, name="x")  # Full-time shifts
    y = model.addVars(n, vtype=GRB.INTEGER, name="y")  # Part-time workers
    
    # Objective: minimize total cost
    model.setObjective(
        full_time_cost * gp.quicksum(x[i] for i in range(n)) +
        part_time_cost * gp.quicksum(y[i] for i in range(n)),
        GRB.MINIMIZE
    )
    
    # Constraints
    for j in range(n):
        prev = (j - 1) % n
        # Coverage requirement
        model.addConstr(
            x[j] + x[prev] + y[j] >= req_values[j],
            f"coverage_{j}"
        )
        # Part-time cap
        model.addConstr(
            y[j] <= part_time_cap,
            f"part_time_cap_{j}"
        )
        # Minimum full-time presence
        model.addConstr(
            x[j] + x[prev] >= min_full_time,
            f"min_full_time_{j}"
        )
    
    # Optimize
    model.optimize()
    
    # Output objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
