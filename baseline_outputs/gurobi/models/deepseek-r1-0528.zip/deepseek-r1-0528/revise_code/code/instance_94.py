import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

def main():
    params = load_parameters()
    
    # Extract parameters
    min_A_I = params['min_proportion_crude_A_type_I'] / 100.0
    min_A_II = params['min_proportion_crude_A_type_II'] / 100.0
    price_I = params['selling_price_type_I']
    price_II = params['selling_price_type_II']
    inv_A = params['inventory_crude_A']
    inv_B = params['inventory_crude_B']
    max_purchase_A = params['max_purchase_crude_A']
    cost_tier1 = params['market_price_crude_A_tier_1']
    cost_tier2 = params['market_price_crude_A_tier_2']
    cost_tier3 = params['market_price_crude_A_tier_3']
    proc_cap = params['processing_capacity']
    min_total_output = params['min_total_gasoline_output']
    proc_cost_per_ton = params['processing_cost_per_ton']
    type_II_threshold = params['type_II_contract_threshold']
    type_II_lift = params['type_II_price_lift']
    rebate_threshold = params['bulk_purchase_rebate_threshold']
    bulk_rebate = params['bulk_purchase_rebate']

    model = gp.Model("Oil_Blending")
    model.setParam('OutputFlag', 0)

    # Decision variables
    a1 = model.addVar(name="crude_A_in_I", lb=0)
    a2 = model.addVar(name="crude_A_in_II", lb=0)
    b1 = model.addVar(name="crude_B_in_I", lb=0)
    b2 = model.addVar(name="crude_B_in_II", lb=0)
    
    # Tiered purchase variables
    p1 = model.addVar(name="purchase_tier1", lb=0, ub=500)
    p2 = model.addVar(name="purchase_tier2", lb=0, ub=500)
    p3 = model.addVar(name="purchase_tier3", lb=0, ub=500)
    
    # Binary variables for tiered purchasing
    y1 = model.addVar(name="y1", vtype=GRB.BINARY)
    y2 = model.addVar(name="y2", vtype=GRB.BINARY)
    
    # Binary variables for commercial thresholds
    z1 = model.addVar(name="type_II_threshold_flag", vtype=GRB.BINARY)
    z2 = model.addVar(name="bulk_purchase_rebate_flag", vtype=GRB.BINARY)

    # Total crude A purchased and gasoline outputs
    total_purchase = p1 + p2 + p3
    total_gasoline = (a1 + b1) + (a2 + b2)
    total_II = a2 + b2
    
    # Tiered purchasing constraints
    model.addConstr(p1 <= 500)
    model.addConstr(p2 <= 500 * y1)
    model.addConstr(p3 <= 500 * y2)
    model.addConstr(p1 >= 500 * y1)
    model.addConstr(p2 >= 500 * y2)
    
    # Material balance
    model.addConstr(a1 + a2 <= inv_A + total_purchase)
    model.addConstr(b1 + b2 <= inv_B)
    
    # Blending constraints
    model.addConstr(a1 >= min_A_I * (a1 + b1))
    model.addConstr(a2 >= min_A_II * (a2 + b2))
    
    # Processing capacity constraints
    model.addConstr(total_gasoline <= proc_cap)
    model.addConstr(total_gasoline >= min_total_output)
    
    # Type II threshold constraints
    M = proc_cap  # Large enough constant
    model.addConstr(total_II >= type_II_threshold * z1)
    model.addConstr(total_II <= type_II_threshold - 1e-5 + M * z1)
    
    # Bulk purchase rebate constraints
    model.addConstr(total_purchase >= rebate_threshold * z2)
    model.addConstr(total_purchase <= rebate_threshold - 1e-5 + max_purchase_A * z2)
    
    # Objective components
    revenue_I = price_I * (a1 + b1)
    revenue_II = price_II * total_II + type_II_lift * total_II * z1
    purchase_cost = cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3
    processing_cost = proc_cost_per_ton * total_gasoline
    rebate = bulk_rebate * z2
    
    profit = revenue_I + revenue_II - purchase_cost - processing_cost + rebate
    model.setObjective(profit, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
