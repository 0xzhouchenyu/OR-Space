import os
import sys
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'src'))
from utils import load_general_parameters
import gurobipy as gp
from gurobipy import GRB

# Load parameters
current_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(current_dir, "data")
params_file = os.path.join(data_dir, "general_parameters.csv")
params = load_general_parameters(params_file)

# Extract parameters
cost_A = params['cost_per_chair_A']
cost_B = params['cost_per_chair_B']
cost_C = params['cost_per_chair_C']
chairs_A_per_order = params['chairs_per_order_A']
chairs_B_per_order = params['chairs_per_order_B']
chairs_C_per_order = params['chairs_per_order_C']
min_total = params['min_total_chairs']
max_total = params['max_total_chairs']
min_B_if_A = params['min_chairs_B_if_A']
dep_BC = params['dependency_B_C']
fee_A_reg = params['fixed_fee_A_regular']
fee_A_exp = params['fixed_fee_A_express']
fee_B_reg = params['fixed_fee_B_regular']
fee_B_exp = params['fixed_fee_B_express']
fee_C_reg = params['fixed_fee_C_regular']
fee_C_exp = params['fixed_fee_C_express']
max_combos = params['weekly_order_budget']

# Calculate maximum possible orders
max_orders_A = max_total // chairs_A_per_order
max_orders_B = max_total // chairs_B_per_order
max_orders_C = max_total // chairs_C_per_order

# Create model
model = gp.Model()
model.setParam('OutputFlag', 0)

# Decision variables: orders per manufacturer
x_A = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_A, name="orders_A")
x_B = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_B, name="orders_B")
x_C = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_C, name="orders_C")

# Binary variables: manufacturer usage
y_A = model.addVar(vtype=GRB.BINARY, name="use_A")
y_B = model.addVar(vtype=GRB.BINARY, name="use_B")
y_C = model.addVar(vtype=GRB.BINARY, name="use_C")

# Binary variables: channel selection
y_A_reg = model.addVar(vtype=GRB.BINARY, name="A_reg")
y_A_exp = model.addVar(vtype=GRB.BINARY, name="A_exp")
y_B_reg = model.addVar(vtype=GRB.BINARY, name="B_reg")
y_B_exp = model.addVar(vtype=GRB.BINARY, name="B_exp")
y_C_reg = model.addVar(vtype=GRB.BINARY, name="C_reg")
y_C_exp = model.addVar(vtype=GRB.BINARY, name="C_exp")

# Total chairs calculation
total_chairs = chairs_A_per_order * x_A + chairs_B_per_order * x_B + chairs_C_per_order * x_C

# Constraints
model.addConstr(total_chairs >= min_total, "MinChairs")
model.addConstr(total_chairs <= max_total, "MaxChairs")

# Manufacturer usage constraints
model.addConstr(x_A <= max_orders_A * y_A, "LinkA_upper")
model.addConstr(x_A >= y_A, "LinkA_lower")
model.addConstr(x_B <= max_orders_B * y_B, "LinkB_upper")
model.addConstr(x_B >= y_B, "LinkB_lower")
model.addConstr(x_C <= max_orders_C * y_C, "LinkC_upper")
model.addConstr(x_C >= y_C, "LinkC_lower")

# Channel selection constraints
model.addConstr(y_A_reg + y_A_exp == y_A, "ChannelA")
model.addConstr(y_B_reg + y_B_exp == y_B, "ChannelB")
model.addConstr(y_C_reg + y_C_exp == y_C, "ChannelC")

# Dependency constraints
model.addConstr(chairs_B_per_order * x_B >= min_B_if_A * y_A, "MinBifA")
if dep_BC:
    model.addConstr(y_B <= y_C, "DepBC")

# Manufacturer-mode combination limit
model.addConstr(y_A + y_B + y_C <= max_combos, "ComboLimit")

# Objective function
variable_cost = cost_A * chairs_A_per_order * x_A + cost_B * chairs_B_per_order * x_B + cost_C * chairs_C_per_order * x_C
fixed_cost = fee_A_reg * y_A_reg + fee_A_exp * y_A_exp + fee_B_reg * y_B_reg + fee_B_exp * y_B_exp + fee_C_reg * y_C_reg + fee_C_exp * y_C_exp
total_cost = variable_cost + fixed_cost
model.setObjective(total_cost, GRB.MINIMIZE)

# Solve
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
