import os
import sys
import gurobipy as gp
from gurobipy import GRB
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from utils import load_parameters

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    base_a = params['base_fleet_type_a']
    base_b = params['base_fleet_type_b']
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    thresh_b = params['type_b_recovery_threshold']
    fee_b = params['type_b_recovery_fee']
    thresh_total = params['total_fleet_surge_threshold']
    fee_total = params['total_fleet_surge_fee']
    
    M = 10000
    
    model = gp.Model("TruckRental")
    model.setParam('OutputFlag', 0)
    
    x = model.addVar(name="TypeA_trucks", vtype=GRB.INTEGER)
    y = model.addVar(name="TypeB_trucks", vtype=GRB.INTEGER)
    z1 = model.addVar(name="Excess_A", lb=0)
    z2 = model.addVar(name="Excess_B", lb=0)
    b1 = model.addVar(name="Trigger_TypeB_Recovery", vtype=GRB.BINARY)
    b2 = model.addVar(name="Trigger_Total_Surge", vtype=GRB.BINARY)
    
    model.setObjective(
        cost_a * x + cost_b * y + 
        penalty_a * z1 + penalty_b * z2 + 
        fee_b * b1 + fee_total * b2, 
        GRB.MINIMIZE
    )
    
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedRequirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedRequirement")
    model.addConstr(z1 >= x - base_a, "Excess_A_def")
    model.addConstr(z2 >= y - base_b, "Excess_B_def")
    model.addConstr(y <= thresh_b + M * b1, "Trigger_TypeB_Recovery_constr")
    model.addConstr(x + y <= thresh_total + M * b2, "Trigger_Total_Surge_constr")
    
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
