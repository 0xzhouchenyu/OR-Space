import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, 'data')
    
    cars = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cars[int(row['i'])] = float(row['lambda_i'])
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    
    max_length = params['max_length_one_side']
    car_ids = list(cars.keys())
    
    m = gp.Model()
    m.setParam('OutputFlag', 0)
    
    x = m.addVars(car_ids, vtype=GRB.BINARY, name="x")
    total_parked = gp.quicksum(cars[i] * x[i] for i in car_ids)
    
    for i in car_ids:
        x[i].LB = 1
        x[i].UB = 1
    
    m.addConstr(total_parked <= max_length, "max_side")
    m.setObjective(total_parked, GRB.MINIMIZE)
    
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
