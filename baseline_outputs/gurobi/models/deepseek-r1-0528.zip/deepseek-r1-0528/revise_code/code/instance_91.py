import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            if ':' in value_str:
                params[name + '_raw'] = value_str
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time = params['machine_working_time']
    base_machine_time_minutes = machine_working_time * 60
    max_overtime_minutes = params['max_overtime_hours'] * 60
    overtime_penalty_per_minute = params['overtime_penalty_per_hour'] / 60.0
    overtime_threshold_minutes = params['overtime_review_threshold_hours'] * 60
    overtime_review_fee = params['overtime_review_fee']
    senior_batch_threshold = params['product_A_senior_batch_threshold']
    senior_batch_fee = params['product_A_senior_batch_fee']
    ratio_constraint = params['production_ratio_A_to_B']
    ratio_A = ratio_constraint[0]
    ratio_B = ratio_constraint[1]
    
    model = gp.Model("Revised_Product_Mix")
    model.setParam('OutputFlag', 0)
    
    A = model.addVar(name="Product_A", lb=0.0, vtype=GRB.CONTINUOUS)
    B = model.addVar(name="Product_B", lb=0.0, vtype=GRB.CONTINUOUS)
    overtime_minutes = model.addVar(name="Overtime", lb=0.0, ub=max_overtime_minutes, vtype=GRB.CONTINUOUS)
    overtime_fee_flag = model.addVar(name="OvertimeFeeFlag", vtype=GRB.BINARY)
    senior_fee_flag = model.addVar(name="SeniorFeeFlag", vtype=GRB.BINARY)
    
    total_machine_time = base_machine_time_minutes + overtime_minutes
    assembly_time_constraint = assembly_time_A * A + assembly_time_B * B <= total_machine_time
    model.addConstr(assembly_time_constraint, "Machine_Time")
    
    ratio_constraint = ratio_B * A <= ratio_A * B
    model.addConstr(ratio_constraint, "Production_Ratio")
    
    model.addConstr(A <= senior_batch_threshold + (total_machine_time / assembly_time_A - senior_batch_threshold) * senior_fee_flag, "Senior_Batch_Upper")
    model.addConstr(A >= senior_batch_threshold * senior_fee_flag + 1e-5 * senior_fee_flag, "Senior_Batch_Lower")
    
    model.addConstr(overtime_minutes <= overtime_threshold_minutes + (max_overtime_minutes - overtime_threshold_minutes) * overtime_fee_flag, "Overtime_Upper")
    model.addConstr(overtime_minutes >= overtime_threshold_minutes * overtime_fee_flag + 1e-5 * overtime_fee_flag, "Overtime_Lower")
    
    revenue = profit_A * A + profit_B * B
    overtime_cost = overtime_penalty_per_minute * overtime_minutes
    total_fees = overtime_review_fee * overtime_fee_flag + senior_batch_fee * senior_fee_flag
    total_profit = revenue - overtime_cost - total_fees
    
    model.setObjective(total_profit, GRB.MAXIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal:.1f}")
    else:
        print("FINAL_OBJ_VALUE: 0.0")

if __name__ == "__main__":
    main()
