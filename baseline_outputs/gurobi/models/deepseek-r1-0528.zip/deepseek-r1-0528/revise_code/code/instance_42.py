import os
import gurobipy as gp
from gurobipy import GRB
import csv
import sys

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    param_file = os.path.join(data_dir, 'general_parameters.csv')
    params = load_parameters(param_file)
    
    a = params['a']
    m_offpeak = params['m_offpeak']
    b = params['b']
    n_offpeak = params['n_offpeak']
    k = params['k']
    d = params['d']
    c_offpeak = params['c_offpeak']
    c_peak = params['c_peak']
    cap_offpeak = params['cap_offpeak']
    cap_peak = params['cap_peak']
    m_peak = params['m_peak']
    n_peak = params['n_peak']
    f_offpeak = params['f_offpeak']
    f_peak = params['f_peak']
    cooldown_threshold = params['offpeak_cooldown_batch_threshold']
    cooldown_fee = params['offpeak_cooldown_fee']
    
    model = gp.Model("SteelFurnace")
    model.setParam('OutputFlag', 0)
    
    # Variables: x_{furnace}_{method}_{period}
    x111 = model.addVar(vtype=GRB.INTEGER, name="x111")  # furnace1, method1, peak
    x112 = model.addVar(vtype=GRB.INTEGER, name="x112")  # furnace1, method1, offpeak
    x121 = model.addVar(vtype=GRB.INTEGER, name="x121")  # furnace1, method2, peak
    x122 = model.addVar(vtype=GRB.INTEGER, name="x122")  # furnace1, method2, offpeak
    x211 = model.addVar(vtype=GRB.INTEGER, name="x211")  # furnace2, method1, peak
    x212 = model.addVar(vtype=GRB.INTEGER, name="x212")  # furnace2, method1, offpeak
    x221 = model.addVar(vtype=GRB.INTEGER, name="x221")  # furnace2, method2, peak
    x222 = model.addVar(vtype=GRB.INTEGER, name="x222")  # furnace2, method2, offpeak
    
    # Activation variables (binary)
    y1p = model.addVar(vtype=GRB.BINARY, name="y1p")  # furnace1 used in peak
    y1o = model.addVar(vtype=GRB.BINARY, name="y1o")  # furnace1 used in offpeak
    y2p = model.addVar(vtype=GRB.BINARY, name="y2p")  # furnace2 used in peak
    y2o = model.addVar(vtype=GRB.BINARY, name="y2o")  # furnace2 used in offpeak
    
    # Cooldown indicators
    w1 = model.addVar(vtype=GRB.BINARY, name="w1")  # furnace1 exceeds offpeak batch threshold
    w2 = model.addVar(vtype=GRB.BINARY, name="w2")  # furnace2 exceeds offpeak batch threshold
    
    # Furnace time constraints
    model.addConstr(a*x111 + b*x121 <= c_peak, "Furnace1_Peak_Time")
    model.addConstr(a*x112 + b*x122 <= c_offpeak, "Furnace1_Offpeak_Time")
    model.addConstr(a*x211 + b*x221 <= c_peak, "Furnace2_Peak_Time")
    model.addConstr(a*x212 + b*x222 <= c_offpeak, "Furnace2_Offpeak_Time")
    
    # Plant-wide time caps
    model.addConstr((a*x111 + b*x121) + (a*x211 + b*x221) <= cap_peak, "Plant_Peak_Time")
    model.addConstr((a*x112 + b*x122) + (a*x212 + b*x222) <= cap_offpeak, "Plant_Offpeak_Time")
    
    # Production requirement
    model.addConstr(k*(x111 + x112 + x121 + x122 + x211 + x212 + x221 + x222) >= d, "Min_Production")
    
    # Activation constraints
    model.addConstr(x111 + x121 <= 4 * y1p, "Activate_Furnace1_Peak")
    model.addConstr(x112 + x122 <= 6 * y1o, "Activate_Furnace1_Offpeak")
    model.addConstr(x211 + x221 <= 4 * y2p, "Activate_Furnace2_Peak")
    model.addConstr(x212 + x222 <= 6 * y2o, "Activate_Furnace2_Offpeak")
    
    # Cooldown constraints
    z1 = x112 + x122
    z2 = x212 + x222
    model.addConstr(z1 <= cooldown_threshold + (6 - cooldown_threshold) * w1, "Furnace1_Cooldown_Upper")
    model.addConstr(z1 >= (cooldown_threshold + 1) * w1, "Furnace1_Cooldown_Lower")
    model.addConstr(z2 <= cooldown_threshold + (6 - cooldown_threshold) * w2, "Furnace2_Cooldown_Upper")
    model.addConstr(z2 >= (cooldown_threshold + 1) * w2, "Furnace2_Cooldown_Lower")
    
    # Objective: minimize total cost
    fuel_cost = (m_peak * (x111 + x211) + m_offpeak * (x112 + x212) +
                 n_peak * (x121 + x221) + n_offpeak * (x122 + x222))
    fixed_cost = f_peak * (y1p + y2p) + f_offpeak * (y1o + y2o)
    cooldown_cost = cooldown_fee * (w1 + w2)
    total_cost = fuel_cost + fixed_cost + cooldown_cost
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
