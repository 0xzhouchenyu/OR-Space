import os
import csv
import gurobipy as gp
from gurobipy import GRB

current_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(current_dir, "data")

params = {}
with open(os.path.join(data_dir, "general_parameters.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

m = int(params['m'])
n = int(params['n'])
p = int(params['p'])
a = {i: params[f'a_{i}'] for i in range(1, m+1)}
b = {j: params[f'b_{j}'] for j in range(1, n+1)}
f_cost = {k: params[f'f_{k}'] for k in range(1, p+1)}
q = {k: params[f'q_{k}'] for k in range(1, p+1)}
qexp = {k: params[f'qexp_{k}'] for k in range(1, p+1)}
alpha = {j: params[f'alpha_{j}'] for j in range(1, n+1)}
eps = params['eps']
M_val = params['M']

cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, "table_1.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row['i'])
        k = int(row['k'])
        cR_ik[(i, k)] = float(row['cR_ik'])
        cE_ik[(i, k)] = float(row['cE_ik'])

cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, "table_2.csv"), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row['k'])
        j = int(row['j'])
        cR_kj[(k, j)] = float(row['cR_kj'])
        cE_kj[(k, j)] = float(row['cE_kj'])

model = gp.Model()
model.setParam('OutputFlag', 0)

xR = {}
xE = {}
for i in range(1, m+1):
    for k in range(1, p+1):
        xR[(i, k)] = model.addVar(lb=0, name=f"xR_{i}_{k}")
        xE[(i, k)] = model.addVar(lb=0, name=f"xE_{i}_{k}")

yR = {}
yE = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        yR[(k, j)] = model.addVar(lb=0, name=f"yR_{k}_{j}")
        yE[(k, j)] = model.addVar(lb=0, name=f"yE_{k}_{j}")

z = {}
for k in range(1, p+1):
    z[k] = model.addVar(vtype=GRB.BINARY, name=f"z_{k}")

v = {}
for k in range(1, p+1):
    for j in range(1, n+1):
        v[(k, j)] = model.addVar(vtype=GRB.BINARY, name=f"v_{k}_{j}")

s = {}
for j in range(1, n+1):
    s[j] = model.addVar(vtype=GRB.BINARY, name=f"s_{j}")

model.setObjective(
    gp.quicksum(cR_ik[(i, k)] * xR[(i, k)] for (i, k) in cR_ik) +
    gp.quicksum(cE_ik[(i, k)] * xE[(i, k)] for (i, k) in cE_ik) +
    gp.quicksum(cR_kj[(k, j)] * yR[(k, j)] for (k, j) in cR_kj) +
    gp.quicksum(cE_kj[(k, j)] * yE[(k, j)] for (k, j) in cE_kj) +
    gp.quicksum(f_cost[k] * z[k] for k in range(1, p+1)),
    GRB.MINIMIZE
)

for i in range(1, m+1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for k in range(1, p+1)) <= a[i],
        f"Supply_{i}"
    )

for j in range(1, n+1):
    model.addConstr(
        gp.quicksum(yR[(k, j)] + yE[(k, j)] for k in range(1, p+1)) >= b[j],
        f"Demand_{j}"
    )

for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for i in range(1, m+1)) == 
        gp.quicksum(yR[(k, j)] + yE[(k, j)] for j in range(1, n+1)),
        f"FlowBalance_{k}"
    )

for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xR[(i, k)] + xE[(i, k)] for i in range(1, m+1)) <= q[k] * z[k],
        f"TotalCap_{k}"
    )

for k in range(1, p+1):
    model.addConstr(
        gp.quicksum(xE[(i, k)] for i in range(1, m+1)) <= qexp[k],
        f"ExpressCap_{k}"
    )

for k in range(1, p+1):
    for j in range(1, n+1):
        w_kj = yR[(k, j)] + yE[(k, j)]
        model.addConstr(w_kj <= M_val * v[(k, j)], f"FlowIndicatorUB_{k}_{j}")
        model.addConstr(w_kj >= eps * v[(k, j)], f"FlowIndicatorLB_{k}_{j}")

for j in range(1, n+1):
    t_j = gp.quicksum(v[(k, j)] for k in range(1, p+1))
    model.addConstr(t_j >= 2 * s[j], f"MinStations_{j}_1")
    model.addConstr(t_j <= 1 + (p-1) * s[j], f"MinStations_{j}_2")

for j in range(1, n+1):
    model.addConstr(
        gp.quicksum(yE[(k, j)] for k in range(1, p+1)) >= alpha[j] * b[j] * s[j],
        f"ExpressShare_{j}"
    )

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
