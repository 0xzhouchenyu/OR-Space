import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Get current script directory and load parameters
script_dir = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(script_dir, 'data', 'general_parameters.csv')
params = load_general_parameters(data_path)

# Extract and convert parameters
m1_liquid = params['machine_1_time_per_liquid_lot']
m2_liquid = params['machine_2_time_per_liquid_lot']
m1_solid = params['machine_1_time_per_solid_lot']
m2_solid = params['machine_2_time_per_solid_lot']
init_liquid = params['initial_liquid_inventory']
init_solid = params['initial_solid_inventory']
m1_base = params['machine_1_available_time'] * 60
m2_base = params['machine_2_available_time'] * 60
demand_liquid = params['forecast_liquid_demand']
demand_solid = params['forecast_solid_demand']
extended_minutes = params['extended_extra_minutes']
labor_per_extended = params['labor_hours_per_machine_extended']
labor_budget = params['labor_budget_hours']
penalty_per_extended = params['extended_mode_penalty']
priority_reserve = params['priority_reserve_lots']
excess_credit = params['excess_reserve_credit']

# Calculate net production requirements
min_liquid = demand_liquid - init_liquid
min_solid = demand_solid - init_solid

# Create model
model = gp.Model("Fertilizer_Production")
model.setParam('OutputFlag', 0)

# Decision variables
x_l = model.addVar(lb=min_liquid, name="x_liquid")
x_s = model.addVar(lb=min_solid, name="x_solid")
e1 = model.addVar(vtype=GRB.BINARY, name="extend_machine1")
e2 = model.addVar(vtype=GRB.BINARY, name="extend_machine2")

# Reserve allocation variables
r_l1 = model.addVar(ub=priority_reserve, name="liquid_priority_reserve")
r_l2 = model.addVar(name="liquid_excess_reserve")
r_s1 = model.addVar(ub=priority_reserve, name="solid_priority_reserve")
r_s2 = model.addVar(name="solid_excess_reserve")

# Ending inventory constraints
model.addConstr(r_l1 + r_l2 == x_l - min_liquid, "liquid_inventory_allocation")
model.addConstr(r_s1 + r_s2 == x_s - min_solid, "solid_inventory_allocation")
model.addConstr(r_l1 >= 0)
model.addConstr(r_l2 >= 0)
model.addConstr(r_s1 >= 0)
model.addConstr(r_s2 >= 0)

# Machine time constraints
model.addConstr(m1_liquid*x_l + m1_solid*x_s <= m1_base + extended_minutes*e1, "machine1_capacity")
model.addConstr(m2_liquid*x_l + m2_solid*x_s <= m2_base + extended_minutes*e2, "machine2_capacity")

# Labor constraint
model.addConstr(labor_per_extended*(e1 + e2) <= labor_budget, "labor_budget")

# Objective: maximize total score
score_liquid = r_l1 + excess_credit * r_l2
score_solid = r_s1 + excess_credit * r_s2
extended_penalty = penalty_per_extended * (e1 + e2)
total_score = score_liquid + score_solid - extended_penalty
model.setObjective(total_score, GRB.MAXIMIZE)

# Solve
model.optimize()

# Output final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal:.2f}")
