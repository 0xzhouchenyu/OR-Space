import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Adjust path to import utils from src
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(current_dir, 'src'))
from utils import load_parameters

# Load parameters
data_file = os.path.join(current_dir, 'data', 'general_parameters.csv')
params = load_parameters(data_file)

# Extract and convert parameters
num_students = int(params['num_students'])
num_buses = int(params['num_buses'])
bus_capacity = int(params['bus_capacity'])
num_minibuses = int(params['num_minibuses'])
minibus_capacity = int(params['minibus_capacity'])
num_drivers = int(params['num_drivers'])
bus_rental_cost = float(params['bus_rental_cost'])
minibus_rental_cost = float(params['minibus_rental_cost'])

# Initialize Gurobi model
model = gp.Model()
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, lb=0, ub=num_buses, name="buses")
y = model.addVar(vtype=GRB.INTEGER, lb=0, ub=num_minibuses, name="minibuses")

# Objective function: minimize total cost
model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

# Constraints
model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, "StudentCapacity")
model.addConstr(x + y <= num_drivers, "DriverLimit")
model.addConstr(x >= 2 * y, "SafetyConstraint")
model.addConstr(y >= 1, "MinMinibus")

# Solve the model
model.optimize()

# Extract and print final objective value
obj_val = model.ObjVal if model.status == GRB.OPTIMAL else 1e100
print(f"FINAL_OBJ_VALUE: {obj_val}")
