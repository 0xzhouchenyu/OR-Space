import os
import sys
import gurobipy as gp
from gurobipy import GRB

current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, 'src')
sys.path.append(src_dir)
from utils import load_data

def main():
    param_dict, demand_dict = load_data()
    
    n = int(param_dict['n'])
    cost_new = float(param_dict['cost_new_tool'])
    cost_fast = float(param_dict['cost_fast_repair'])
    cost_slow = float(param_dict['cost_slow_repair'])
    dur_slow = int(param_dict['slow_repair_duration'])
    dur_fast = int(param_dict['fast_repair_duration'])
    max_fast = int(param_dict['max_fast_stage'])
    max_slow = int(param_dict['max_slow_stage'])
    emission_buy = float(param_dict['emission_buy'])
    emission_fast = float(param_dict['emission_fast_repair'])
    emission_slow = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_short = float(param_dict['penalty_shortage'])
    
    stages = list(range(1, n + 1))
    demand = {t: demand_dict[t] for t in stages}
    
    model = gp.Model("Tool_Repair_Revised")
    model.setParam('OutputFlag', 0)
    
    prebuy_clean = model.addVar(name="prebuy_clean", vtype=GRB.INTEGER)
    clean = model.addVars([0] + stages, name="clean", vtype=GRB.INTEGER)
    dirty = model.addVars([0] + stages, name="dirty", vtype=GRB.INTEGER)
    buy = model.addVars(stages, name="buy", vtype=GRB.INTEGER)
    fast = model.addVars(stages, name="fast", vtype=GRB.INTEGER)
    slow = model.addVars(stages, name="slow", vtype=GRB.INTEGER)
    short = model.addVars(stages, name="short", vtype=GRB.INTEGER)
    
    model.addConstr(clean[0] == prebuy_clean, "init_clean")
    model.addConstr(dirty[0] == 0, "init_dirty")
    
    for t in stages:
        expr = clean[t - 1] + buy[t] - (demand[t] - short[t])
        k_fast = t - dur_fast - 1
        if k_fast >= 1 and k_fast <= n:
            expr += fast[k_fast]
        k_slow = t - dur_slow - 1
        if k_slow >= 1 and k_slow <= n:
            expr += slow[k_slow]
        model.addConstr(clean[t] == expr, f"clean_balance_{t}")
        
        model.addConstr(dirty[t] == dirty[t - 1] + (demand[t] - short[t]) - fast[t] - slow[t], f"dirty_balance_{t}")
        model.addConstr(fast[t] + slow[t] <= dirty[t - 1] + (demand[t] - short[t]), f"repair_assign_{t}")
        model.addConstr(fast[t] <= max_fast, f"fast_cap_{t}")
        model.addConstr(slow[t] <= max_slow, f"slow_cap_{t}")
        model.addConstr(short[t] <= demand[t], f"short_ub_{t}")
    
    total_emission = (
        emission_buy * (prebuy_clean + gp.quicksum(buy[t] for t in stages)) +
        emission_fast * gp.quicksum(fast[t] for t in stages) +
        emission_slow * gp.quicksum(slow[t] for t in stages)
    )
    model.addConstr(total_emission <= carbon_budget, "carbon_budget")
    
    total_cost = (
        cost_new * (prebuy_clean + gp.quicksum(buy[t] for t in stages)) +
        cost_fast * gp.quicksum(fast[t] for t in stages) +
        cost_slow * gp.quicksum(slow[t] for t in stages) +
        penalty_short * gp.quicksum(short[t] for t in stages)
    )
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: inf")

if __name__ == '__main__':
    main()
