import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read worker-task costs and fixed costs
    workers = []
    tasks = []
    cost_matrix = {}
    fixed_costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        tasks = header[1:-1]  # Skip 'Worker' and 'Fixed_Cost'
        for row in reader:
            worker = row[0].strip()
            workers.append(worker)
            for j, task in enumerate(tasks):
                cost_matrix[(worker, task)] = int(row[j+1])
            fixed_costs[worker] = int(row[-1])
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    # Assignment variables
    x = model.addVars(workers, tasks, vtype=GRB.BINARY, name="x")
    
    # Worker selection variables
    z = model.addVars(workers, vtype=GRB.BINARY, name="z")
    
    # Pair indicator variables
    p1 = model.addVar(vtype=GRB.BINARY, name="p1")  # III and V together
    p2 = model.addVar(vtype=GRB.BINARY, name="p2")  # II and V together
    
    # Each task assigned to exactly one worker
    for t in tasks:
        model.addConstr(gp.quicksum(x[w, t] for w in workers) == 1, f"Task_{t}")
    
    # Worker assignment constraints
    for w in workers:
        model.addConstr(z[w] == gp.quicksum(x[w, t] for t in tasks), f"Assign_{w}")
        model.addConstr(gp.quicksum(x[w, t] for t in tasks) <= 1, f"OneTask_{w}")
    
    # Exactly 4 workers selected
    model.addConstr(gp.quicksum(z[w] for w in workers) == 4, "Select_4")
    
    # Pair constraints
    model.addConstr(p1 >= z['III'] + z['V'] - 1, "Pair_III_V_lb")
    model.addConstr(p1 <= z['III'], "Pair_III_V_ub1")
    model.addConstr(p1 <= z['V'], "Pair_III_V_ub2")
    
    model.addConstr(p2 >= z['II'] + z['V'] - 1, "Pair_II_V_lb")
    model.addConstr(p2 <= z['II'], "Pair_II_V_ub1")
    model.addConstr(p2 <= z['V'], "Pair_II_V_ub2")
    
    # Objective components
    assignment_cost = gp.quicksum(cost_matrix[w, t] * x[w, t] for w in workers for t in tasks)
    fixed_cost_total = gp.quicksum(fixed_costs[w] * z[w] for w in workers)
    pair_costs = params['shared_temp_handoff_cost'] * p1 + params['worker_II_V_pair_fee'] * p2
    
    total_cost = assignment_cost + fixed_cost_total + pair_costs
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
