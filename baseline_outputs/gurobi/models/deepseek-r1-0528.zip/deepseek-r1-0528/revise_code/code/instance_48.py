import os
import csv
import gurobipy as gp
from gurobipy import GRB

current_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(current_dir, "data")

param_file = os.path.join(data_dir, "general_parameters.csv")
table1_file = os.path.join(data_dir, "table_1.csv")

param_dict = {}
with open(param_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_dict[row['Parameter_Name']] = float(row['Value'])

table1 = []
with open(table1_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        table1.append(row)

proc_I = table1[0]
proc_II = table1[1]
profit_row = table1[2]

a_I = float(proc_I['Model_A_hours_per_unit'])
b_I = float(proc_I['Model_B_hours_per_unit'])
a_II = float(proc_II['Model_A_hours_per_unit'])
b_II = float(proc_II['Model_B_hours_per_unit'])
profit_A = float(profit_row['Model_A_hours_per_unit'])
profit_B = float(profit_row['Model_B_hours_per_unit'])

min_profit = param_dict['min_weekly_profit']
min_A = param_dict['min_model_A_units']
min_B = param_dict['min_model_B_units']
proc_I_hours = param_dict['process_I_hours']
max_overtime = param_dict['process_II_max_overtime']
red_A = param_dict['model_A_overtime_profit_reduction']
red_B = param_dict['model_B_overtime_profit_reduction']

model = gp.Model("Microcomputer_Production")
model.setParam('OutputFlag', 0)

xA_r = model.addVar(vtype=GRB.CONTINUOUS, name="xA_r")
xA_o = model.addVar(vtype=GRB.CONTINUOUS, name="xA_o")
xB_r = model.addVar(vtype=GRB.CONTINUOUS, name="xB_r")
xB_o = model.addVar(vtype=GRB.CONTINUOUS, name="xB_o")

total_units = xA_r + xA_o + xB_r + xB_o
model.setObjective(total_units, GRB.MAXIMIZE)

model.addConstr(a_I*(xA_r + xA_o) + b_I*(xB_r + xB_o) == proc_I_hours, "Process_I")
model.addConstr(a_II*xA_r + b_II*xB_r <= float(proc_II['Maximum_Weekly_Processing_Capacity']), "Process_II_regular")
model.addConstr(a_II*xA_o + b_II*xB_o <= max_overtime, "Process_II_overtime")
model.addConstr(xA_r + xA_o >= min_A, "Min_A")
model.addConstr(xB_r + xB_o >= min_B, "Min_B")

profit = profit_A*xA_r + profit_B*xB_r + (profit_A - red_A)*xA_o + (profit_B - red_B)*xB_o
model.addConstr(profit >= min_profit, "Min_Profit")

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: 0")
