import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass
            params[name] = value
    return params

def main():
    params = load_parameters()
    M = 10000
    model = gp.Model("ToyManufacturing")
    model.setParam('OutputFlag', 0)

    x_robot = model.addVar(vtype=GRB.INTEGER, lb=0, name="robots")
    x_car = model.addVar(vtype=GRB.INTEGER, lb=0, name="model_cars")
    x_blocks = model.addVar(vtype=GRB.INTEGER, lb=0, name="building_blocks")
    x_doll = model.addVar(vtype=GRB.INTEGER, lb=0, name="dolls")

    y_robot = model.addVar(vtype=GRB.BINARY, name="y_robot")
    y_car = model.addVar(vtype=GRB.BINARY, name="y_car")
    y_blocks = model.addVar(vtype=GRB.BINARY, name="y_blocks")
    y_doll = model.addVar(vtype=GRB.BINARY, name="y_doll")

    model.setObjective(
        params['profit_per_robot'] * x_robot +
        params['profit_per_model_car'] * x_car +
        params['profit_per_building_blocks'] * x_blocks +
        params['profit_per_doll'] * x_doll,
        GRB.MAXIMIZE
    )

    model.addConstr(
        params['plastic_per_robot'] * x_robot +
        params['plastic_per_model_car'] * x_car +
        params['plastic_per_building_blocks'] * x_blocks +
        params['plastic_per_doll'] * x_doll <= params['plastic_available'],
        "Plastic"
    )

    model.addConstr(
        params['electronics_per_robot'] * x_robot +
        params['electronics_per_model_car'] * x_car +
        params['electronics_per_building_blocks'] * x_blocks +
        params['electronics_per_doll'] * x_doll <= params['electronic_components_available'],
        "Electronics"
    )

    model.addConstr(x_robot <= M * y_robot, "Link_robot_upper")
    model.addConstr(x_car <= M * y_car, "Link_car_upper")
    model.addConstr(x_blocks <= M * y_blocks, "Link_blocks_upper")
    model.addConstr(x_doll <= M * y_doll, "Link_doll_upper")

    model.addConstr(y_robot <= x_robot, "Link_robot_lower")
    model.addConstr(y_car <= x_car, "Link_car_lower")
    model.addConstr(y_blocks <= x_blocks, "Link_blocks_lower")
    model.addConstr(y_doll <= x_doll, "Link_doll_lower")

    model.addConstr(y_robot + y_doll <= 1, "Robot_Doll_Exclusion")
    model.addConstr(y_car <= y_blocks, "Car_Blocks_Dependency")
    model.addConstr(y_car + y_blocks <= 1, "Car_Blocks_Mutual_Exclusion")
    model.addConstr(x_doll <= x_car, "Dolls_leq_Cars")

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
