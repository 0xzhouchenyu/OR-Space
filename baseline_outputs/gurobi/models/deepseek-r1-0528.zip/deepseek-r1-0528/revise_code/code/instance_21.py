import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    cost_a = params['cost_supplier_a']
    cost_b = params['cost_supplier_b']
    cost_c = params['cost_supplier_c']
    size_a = int(params['order_size_supplier_a'])
    size_b = int(params['order_size_supplier_b'])
    size_c = int(params['order_size_supplier_c'])
    min_tables = int(params['min_tables_required'])
    max_tables = int(params['max_tables_allowed'])
    min_b_if_a = int(params['min_tables_supplier_b_if_a'])
    b_requires_c = int(params['supplier_b_requires_c'])
    max_free_orders_c = int(params['max_free_orders_c'])
    penalty_per_extra = params['penalty_per_extra_order_c']
    shared_trigger = int(params['supplier_bc_shared_inbound_trigger'])
    shared_fee = params['supplier_bc_shared_inbound_fee']
    
    M = 1000
    model = gp.Model("Restaurant_Tables")
    model.setParam('OutputFlag', 0)
    
    x_a = model.addVar(vtype=GRB.INTEGER, name="orders_a", lb=0)
    x_b = model.addVar(vtype=GRB.INTEGER, name="orders_b", lb=0)
    x_c = model.addVar(vtype=GRB.INTEGER, name="orders_c", lb=0)
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")
    extra_orders = model.addVar(vtype=GRB.CONTINUOUS, name="extra_orders", lb=0)
    
    if shared_trigger:
        z_bc = model.addVar(vtype=GRB.BINARY, name="z_bc")
    
    total_cost = (
        cost_a * size_a * x_a +
        cost_b * size_b * x_b +
        cost_c * size_c * x_c +
        penalty_per_extra * extra_orders
    )
    if shared_trigger:
        total_cost += shared_fee * z_bc
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    total_tables = size_a*x_a + size_b*x_b + size_c*x_c
    model.addConstr(total_tables >= min_tables, "min_tables")
    model.addConstr(total_tables <= max_tables, "max_tables")
    
    model.addConstr(x_a <= M * y_a, "link_xa_ya_upper")
    model.addConstr(x_a >= y_a, "link_xa_ya_lower")
    model.addConstr(x_b <= M * y_b, "link_xb_yb_upper")
    model.addConstr(x_b >= y_b, "link_xb_yb_lower")
    model.addConstr(x_c <= M * y_c, "link_xc_yc_upper")
    model.addConstr(x_c >= y_c, "link_xc_yc_lower")
    
    model.addConstr(size_b * x_b >= min_b_if_a * y_a, "min_B_if_A")
    
    if b_requires_c:
        model.addConstr(x_c >= y_b, "B_requires_C")
    
    model.addConstr(extra_orders >= x_c - max_free_orders_c, "penalty_C")
    
    if shared_trigger:
        model.addConstr(z_bc >= y_b + y_c - 1, "z_bc_lower")
        model.addConstr(z_bc <= y_b, "z_bc_upper1")
        model.addConstr(z_bc <= y_c, "z_bc_upper2")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    elif model.SolCount > 0:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: Infeasible")

if __name__ == "__main__":
    main()
