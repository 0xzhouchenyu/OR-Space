import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load coverage data
    coverage_dict = {}
    areas = []
    coverage_file = os.path.join(data_dir, "table_1.csv")
    with open(coverage_file, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage_dict[area_code] = set(covered_areas)
    
    # Load parameters
    params_file = os.path.join(data_dir, "general_parameters.csv")
    params = {}
    with open(params_file, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    small_cost = int(params['small_cost'])
    large_cost = int(params['large_cost'])
    small_cap_areas = int(params['small_cap_areas'])
    max_large_stores = int(params['max_large_stores'])
    min_small_stores = int(params['minimum_neighborhood_counters'])
    
    # Precompute reverse coverage
    reverse_coverage = {area: set() for area in areas}
    for j in areas:
        for i in coverage_dict[j]:
            reverse_coverage[i].add(j)
    
    return areas, coverage_dict, reverse_coverage, small_cost, large_cost, small_cap_areas, max_large_stores, min_small_stores

def main():
    areas, coverage_dict, reverse_coverage, small_cost, large_cost, small_cap, max_large, min_small = load_data()
    
    model = gp.Model("StoreLocation")
    model.setParam('OutputFlag', 0)
    
    # Variables
    y = model.addVars(areas, vtype=GRB.BINARY, name="y")  # Small stores
    z = model.addVars(areas, vtype=GRB.BINARY, name="z")  # Large stores
    
    # Create list of valid (i,j) pairs for x
    pairs = []
    for j in areas:
        for i in coverage_dict[j]:
            pairs.append((i, j))
    x = model.addVars(pairs, vtype=GRB.BINARY, name="x")
    
    # Objective: minimize total cost
    model.setObjective(
        gp.quicksum(small_cost * y[j] + large_cost * z[j] for j in areas),
        GRB.MINIMIZE
    )
    
    # Coverage constraints
    for i in areas:
        model.addConstr(
            gp.quicksum(x[i, j] for j in reverse_coverage[i] if (i, j) in x) +
            gp.quicksum(z[j] for j in reverse_coverage[i]) >= 1,
            f"cover_{i}"
        )
    
    # Small store capacity constraints
    for j in areas:
        model.addConstr(
            gp.quicksum(x[i, j] for i in coverage_dict[j]) <= small_cap * y[j],
            f"small_cap_{j}"
        )
    
    # Minimum small stores
    model.addConstr(y.sum() >= min_small, "min_small_stores")
    
    # Maximum large stores
    model.addConstr(z.sum() <= max_large, "max_large_stores")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
