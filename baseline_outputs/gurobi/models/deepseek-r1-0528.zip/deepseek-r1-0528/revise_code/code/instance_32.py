import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    workshops = []
    capacities_total = {}
    rates = {}  # rates[(workshop, component)] = production rate
    
    table1_path = os.path.join(data_dir, 'table_1.csv')
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities_total[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    components = [1, 2, 3]
    shifts = ['day', 'night']
    
    # Read general_parameters.csv
    params = {}
    gen_params_path = os.path.join(data_dir, 'general_parameters.csv')
    with open(gen_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    
    # Extract parameters into dictionaries
    regular_limits = {}
    overtime_caps = {}
    bigM_vals = {}
    for w in workshops:
        regular_limits[(w, 'day')] = params[f'regular_hours_limit_day_{w}']
        regular_limits[(w, 'night')] = params[f'regular_hours_limit_night_{w}']
        overtime_caps[(w, 'day')] = params[f'overtime_capacity_day_{w}']
        overtime_caps[(w, 'night')] = params[f'overtime_capacity_night_{w}']
        bigM_vals[w] = params[f'bigM_shift_{w}']
    
    penalty_night = params['penalty_night_hour']
    penalty_overtime = params['penalty_overtime_hour']
    penalty_shortage = params['penalty_shortage_per_unit']
    z_target = params['z_target']
    
    # Create Gurobi model
    model = gp.Model("Revised_Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    r = {}  # Regular hours: r[(w, s)] for workshop w and shift s
    o = {}  # Overtime hours: o[(w, s)]
    a = {}  # Active indicator: binary a[(w, s)]
    for w in workshops:
        for s in shifts:
            r[(w, s)] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"r_{w}_{s}")
            o[(w, s)] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"o_{w}_{s}")
            a[(w, s)] = model.addVar(vtype=GRB.BINARY, name=f"a_{w}_{s}")
    
    z = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="z")  # Completed products
    shortfall = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="shortfall")  # Shortfall below target
    
    # Objective: Minimize total penalty
    total_night_hours = gp.quicksum(r[(w, 'night')] for w in workshops)
    total_overtime_hours = gp.quicksum(o[(w, s)] for w in workshops for s in shifts)
    total_penalty = penalty_night * total_night_hours + penalty_overtime * total_overtime_hours + penalty_shortage * shortfall
    model.setObjective(total_penalty, GRB.MINIMIZE)
    
    # Production constraints: z <= total production for each component
    for c in components:
        total_comp = gp.quicksum((r[(w, s)] + o[(w, s)]) * rates[(w, c)] for w in workshops for s in shifts)
        model.addConstr(total_comp >= z, f"min_component_{c}")
    
    # Shortfall constraint: shortfall >= z_target - z
    model.addConstr(shortfall >= z_target - z, "shortfall_def")
    
    # Regular hour limits per workshop and shift
    for w in workshops:
        for s in shifts:
            model.addConstr(r[(w, s)] <= regular_limits[(w, s)], f"regular_limit_{w}_{s}")
            model.addConstr(o[(w, s)] <= overtime_caps[(w, s)], f"overtime_cap_{w}_{s}")
    
    # Total capacity per workshop (across shifts)
    for w in workshops:
        total_hours = gp.quicksum(r[(w, s)] + o[(w, s)] for s in shifts)
        model.addConstr(total_hours <= capacities_total[w], f"total_capacity_{w}")
    
    # Active indicator linking: if any hours (regular or overtime) >0 then a=1
    for w in workshops:
        for s in shifts:
            model.addConstr(r[(w, s)] + o[(w, s)] <= bigM_vals[w] * a[(w, s)], f"active_link_{w}_{s}")
    
    # Supervision constraint: max 2 workshops active per shift
    for s in shifts:
        model.addConstr(gp.quicksum(a[(w, s)] for w in workshops) <= 2, f"max_active_{s}")
    
    # Solve
    model.optimize()
    
    # Output the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: infeasible")

if __name__ == "__main__":
    main()
