import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Get current script directory and load parameters
script_dir = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(script_dir, "data", "general_parameters.csv")
params = load_general_parameters(data_path)

# Extract all parameters
sell_price_table = params['sell_price_table']
sell_price_chair = params['sell_price_chair']
sell_price_bookshelf = params['sell_price_bookshelf']
cost_table = params['manufacturing_cost_table']
cost_chair = params['manufacturing_cost_chair']
cost_bookshelf = params['manufacturing_cost_bookshelf']
space_table = params['warehouse_space_table']
space_chair = params['warehouse_space_chair']
space_bookshelf = params['warehouse_space_bookshelf']
max_warehouse = params['max_warehouse_space']
min_tables = params['min_tables']
min_bookshelves = params['min_bookshelves']
max_total = params['max_total_items']
labor_table = params['labor_hours_table']
labor_chair = params['labor_hours_chair']
labor_bookshelf = params['labor_hours_bookshelf']
max_labor_regular = params['max_labor_hours_month_regular']
max_labor_rush = params['max_labor_hours_month_rush']
max_rush_items = params['max_rush_items_month']
rush_bonus_table = params['rush_profit_bonus_table']
rush_bonus_chair = params['rush_profit_bonus_chair']
rush_bonus_bookshelf = params['rush_profit_bonus_bookshelf']

# Calculate profit components
profit_regular_table = sell_price_table - cost_table
profit_regular_chair = sell_price_chair - cost_chair
profit_regular_bookshelf = sell_price_bookshelf - cost_bookshelf

# Initialize Gurobi model
model = gp.Model("Furniture_Production")
model.setParam('OutputFlag', 0)

# Create variables - regular and rush for each product
t_reg = model.addVar(vtype=GRB.INTEGER, name="tables_regular")
t_rush = model.addVar(vtype=GRB.INTEGER, name="tables_rush")
c_reg = model.addVar(vtype=GRB.INTEGER, name="chairs_regular")
c_rush = model.addVar(vtype=GRB.INTEGER, name="chairs_rush")
b_reg = model.addVar(vtype=GRB.INTEGER, name="bookshelves_regular")
b_rush = model.addVar(vtype=GRB.INTEGER, name="bookshelves_rush")

# Set objective: maximize total profit
total_profit = (
    (profit_regular_table * t_reg) + 
    ((profit_regular_table + rush_bonus_table) * t_rush) +
    (profit_regular_chair * c_reg) + 
    ((profit_regular_chair + rush_bonus_chair) * c_rush) +
    (profit_regular_bookshelf * b_reg) + 
    ((profit_regular_bookshelf + rush_bonus_bookshelf) * b_rush)
)
model.setObjective(total_profit, GRB.MAXIMIZE)

# Warehouse space constraint
model.addConstr(
    (space_table * (t_reg + t_rush) + 
     space_chair * (c_reg + c_rush) + 
     space_bookshelf * (b_reg + b_rush)) <= max_warehouse,
    "Warehouse_Space"
)

# Minimum production requirements
model.addConstr(t_reg + t_rush >= min_tables, "Min_Tables")
model.addConstr(b_reg + b_rush >= min_bookshelves, "Min_Bookshelves")

# Maximum total production
model.addConstr(
    t_reg + t_rush + c_reg + c_rush + b_reg + b_rush <= max_total,
    "Max_Total_Items"
)

# Regular labor constraint
model.addConstr(
    (labor_table * t_reg) + 
    (labor_chair * c_reg) + 
    (labor_bookshelf * b_reg) <= max_labor_regular,
    "Regular_Labor"
)

# Rush labor constraint
model.addConstr(
    (labor_table * t_rush) + 
    (labor_chair * c_rush) + 
    (labor_bookshelf * b_rush) <= max_labor_rush,
    "Rush_Labor"
)

# Rush items limit
model.addConstr(
    t_rush + c_rush + b_rush <= max_rush_items,
    "Max_Rush_Items"
)

# Optimize model
model.optimize()

# Print final objective value
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
