import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

current_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(current_dir, "data")
params = load_parameters(os.path.join(data_dir, "general_parameters.csv"))

a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']
T1_normal = params['available_time_process_1']
T2_normal = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']
c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
base_disposal_cost = params['disposal_cost_per_unit_c']
high_disposal_cost = params['disposal_cost_per_unit_c_high']
profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

model = gp.Model("MaxProfit")
model.setParam('OutputFlag', 0)

xA = model.addVar(name="xA", lb=0)
xB = model.addVar(name="xB", lb=0)
cSold = model.addVar(name="cSold", lb=0)
d1 = model.addVar(name="d1", lb=0)
d2 = model.addVar(name="d2", lb=0)
y1 = model.addVar(name="y1", vtype=GRB.BINARY)
y2 = model.addVar(name="y2", vtype=GRB.BINARY)

model.setObjective(
    profit_a * xA + 
    profit_b * xB + 
    profit_c * cSold - 
    (base_disposal_cost * d1 + high_disposal_cost * d2), 
    GRB.MAXIMIZE
)

model.addConstr(a_p1 * xA + b_p1 * xB <= T1_normal + y1 * (T1_high - T1_normal), "Process1Time")
model.addConstr(a_p2 * xA + b_p2 * xB <= T2_normal + y2 * (T2_high - T2_normal), "Process2Time")
model.addConstr(y1 + y2 <= 1, "AtMostOneHighThroughput")
model.addConstr(cSold + d1 + d2 == c_per_b * xB, "ByproductBalance")
model.addConstr(cSold <= max_c_sales, "MaxCSales")
model.addConstr(d1 <= threshold_c, "BaseDisposalCap")

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
