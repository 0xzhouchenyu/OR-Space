import os
import sys
import gurobipy as gp
from gurobipy import GRB

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))
from utils import load_general_parameters, load_reliability_table

def main():
    params = load_general_parameters()
    reliability_data = load_reliability_table()
    
    p1 = params['unit_price_component_1']
    p2 = params['unit_price_component_2']
    p3 = params['unit_price_component_3']
    w1 = params['unit_weight_component_1']
    w2 = params['unit_weight_component_2']
    w3 = params['unit_weight_component_3']
    budget_A = params['total_budget_scenario_A']
    budget_B = params['total_budget_scenario_B']
    weight_A = params['weight_limit_scenario_A']
    weight_B = params['weight_limit_scenario_B']
    
    r1 = [reliability_data[i][0] for i in range(6)]
    r2 = [reliability_data[i][1] for i in range(6)]
    r3 = [reliability_data[i][2] for i in range(6)]
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    s1 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=5, name="s1")
    s2 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=5, name="s2")
    s3 = model.addVar(vtype=GRB.INTEGER, lb=0, ub=5, name="s3")
    
    cost_expr = p1 * s1 + p2 * s2 + p3 * s3
    weight_expr = w1 * s1 + w2 * s2 + w3 * s3
    
    model.addConstr(cost_expr <= budget_A, "cost_A")
    model.addConstr(cost_expr <= budget_B, "cost_B")
    model.addConstr(weight_expr <= weight_A, "weight_A")
    model.addConstr(weight_expr <= weight_B, "weight_B")
    
    r1_val = model.addVar(lb=0.0, ub=1.0, name="r1_val")
    r2_val = model.addVar(lb=0.0, ub=1.0, name="r2_val")
    r3_val = model.addVar(lb=0.0, ub=1.0, name="r3_val")
    
    for i in range(6):
        model.addGenConstrIndicator(r1_val, (s1 == i), r1[i], name="r1_%d" % i)
        model.addGenConstrIndicator(r2_val, (s2 == i), r2[i], name="r2_%d" % i)
        model.addGenConstrIndicator(r3_val, (s3 == i), r3[i], name="r3_%d" % i)
    
    obj_expr = r1_val * r2_val * r3_val
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == '__main__':
    main()
