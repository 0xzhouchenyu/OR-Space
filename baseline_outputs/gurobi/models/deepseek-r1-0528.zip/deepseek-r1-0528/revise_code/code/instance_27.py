import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_table1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in ['Product_I', 'Product_II', 'Product_III']:
                val = row[p].strip() if row[p].strip() else None
                proc_times[e][p] = float(val) if val else None
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())
    
    return equipment, proc_times, eff_hours, op_costs

def load_all_general_params(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
            
    raw_costs = {
        'Product_I': params['raw_material_cost_product_I'],
        'Product_II': params['raw_material_cost_product_II'],
        'Product_III': params['raw_material_cost_product_III']
    }
    prices = {
        'Product_I': params['unit_price_product_I'],
        'Product_II': params['unit_price_product_II'],
        'Product_III': params['unit_price_product_III']
    }
    shared_labor_hours = params['shared_labor_hours']
    labor_coeff = {
        'A1': params['labor_coeff_A1'],
        'A2': params['labor_coeff_A2'],
        'B1': params['labor_coeff_B1'],
        'B2': params['labor_coeff_B2'],
        'B3': params['labor_coeff_B3']
    }
    b2_activation_fee = params['b2_activation_fee']
    
    return raw_costs, prices, shared_labor_hours, labor_coeff, b2_activation_fee

def main():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, "data")
    
    equipment, proc_times, eff_hours, op_costs = load_table1(data_dir)
    raw_costs, prices, shared_labor_hours, labor_coeff, b2_activation_fee = load_all_general_params(data_dir)
    
    products = ['Product_I', 'Product_II', 'Product_III']
    A_equip = [e for e in equipment if e.startswith('A')]
    B_equip = [e for e in equipment if e.startswith('B')]
    
    model = gp.Model("Factory_Production")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: production quantities
    x = {}
    for e in equipment:
        for p in products:
            if proc_times[e][p] is not None:
                x[e, p] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{e}_{p}", lb=0.0)
    
    # Binary activation variable for B2
    z_B2 = model.addVar(vtype=GRB.BINARY, name="z_B2")
    
    # Machine hours used per equipment
    machine_hours = {}
    for e in equipment:
        machine_hours[e] = gp.quicksum(
            x[e, p] * proc_times[e][p] for p in products if proc_times[e][p] is not None
        )
    
    # Capacity constraints
    for e in equipment:
        model.addConstr(machine_hours[e] <= eff_hours[e], f"capacity_{e}")
    
    # Flow balance constraints
    for p in products:
        a_sum = gp.quicksum(
            x[e, p] for e in A_equip if proc_times[e][p] is not None
        )
        b_sum = gp.quicksum(
            x[e, p] for e in B_equip if proc_times[e][p] is not None
        )
        model.addConstr(a_sum == b_sum, f"balance_{p}")
    
    # Shared labor constraint
    labor_used = gp.quicksum(
        labor_coeff[e] * machine_hours[e] for e in equipment
    )
    model.addConstr(labor_used <= shared_labor_hours, "shared_labor")
    
    # B2 activation constraint
    model.addConstr(machine_hours['B2'] <= eff_hours['B2'] * z_B2, "B2_activation")
    
    # Total production per product
    total_prod = {}
    for p in products:
        total_prod[p] = gp.quicksum(
            x[e, p] for e in A_equip if proc_times[e][p] is not None
        )
    
    # Revenue
    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)
    
    # Raw material costs
    raw_cost_total = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)
    
    # Operating costs (proportional to machine hours)
    operating_cost = gp.quicksum(
        (op_costs[e] / eff_hours[e]) * machine_hours[e] for e in equipment
    )
    
    # Activation fee for B2
    activation_fee = b2_activation_fee * z_B2
    
    # Objective: maximize profit
    model.setObjective(
        revenue - raw_cost_total - operating_cost - activation_fee,
        GRB.MAXIMIZE
    )
    
    # Solve the model
    model.optimize()
    
    # Print the final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal:.4f}")

if __name__ == "__main__":
    main()
