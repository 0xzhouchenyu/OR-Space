import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    param_file = os.path.join(data_dir, "general_parameters.csv")
    params = load_parameters(param_file)
    
    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']
    
    profit = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons']
    }
    
    water_coeff = {}
    for f in fruits:
        water_coeff[f] = {
            'spring': params[f'water_per_acre_{f}_spring'],
            'autumn': params[f'water_per_acre_{f}_autumn']
        }
    
    total_farm_area = params['total_farm_area']
    min_a_to_p = params['min_apples_to_pears_ratio']
    min_a_to_l = params['min_apples_to_lemons_ratio']
    o_to_l = params['oranges_to_lemons_ratio']
    max_types = int(params['max_fruit_types'])
    min_water_per_fruit = params['min_annual_water_per_fruit']
    div_reward = params['diversification_reward']
    water_cap_spring = params['water_cap_spring']
    water_cap_autumn = params['water_cap_autumn']
    total_water_budget = params['total_water_budget']
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    x = {}
    for f in fruits:
        x[f] = {}
        for s in seasons:
            x[f][s] = model.addVar(lb=0, name=f'x_{f}_{s}')
    
    z = {f: model.addVar(vtype=GRB.BINARY, name=f'z_{f}') for f in fruits}
    d = model.addVar(vtype=GRB.BINARY, name='d')
    
    model.addConstr(gp.quicksum(x[f]['spring'] for f in fruits) <= total_farm_area, "land_spring")
    model.addConstr(gp.quicksum(x[f]['autumn'] for f in fruits) <= total_farm_area, "land_autumn")
    
    water_spring = gp.quicksum(water_coeff[f]['spring'] * x[f]['spring'] for f in fruits)
    water_autumn = gp.quicksum(water_coeff[f]['autumn'] * x[f]['autumn'] for f in fruits)
    model.addConstr(water_spring <= water_cap_spring, "cap_spring")
    model.addConstr(water_autumn <= water_cap_autumn, "cap_autumn")
    model.addConstr(water_spring + water_autumn <= total_water_budget, "total_water")
    
    total_apple = x['apples']['spring'] + x['apples']['autumn']
    total_pear = x['pears']['spring'] + x['pears']['autumn']
    total_lemon = x['lemons']['spring'] + x['lemons']['autumn']
    total_orange = x['oranges']['spring'] + x['oranges']['autumn']
    
    model.addConstr(total_apple >= min_a_to_p * total_pear, "ratio_apples_pears")
    model.addConstr(total_apple >= min_a_to_l * total_lemon, "ratio_apples_lemons")
    model.addConstr(total_orange == o_to_l * total_lemon, "ratio_oranges_lemons")
    
    for f in fruits:
        W_f = water_coeff[f]['spring'] * x[f]['spring'] + water_coeff[f]['autumn'] * x[f]['autumn']
        model.addConstr(W_f >= min_water_per_fruit * z[f], f"water_threshold_lb_{f}")
        model.addConstr(W_f <= min_water_per_fruit - 1e-5 + total_water_budget * z[f], f"water_threshold_ub_{f}")
    
    model.addConstr(gp.quicksum(z[f] for f in fruits) <= max_types, "max_fruit_types")
    
    model.addConstr(d <= gp.quicksum(z[f] for f in fruits) / 2.0, "d_ub")
    model.addConstr(d >= gp.quicksum(z[f] for f in fruits) - 1, "d_lb")
    
    total_profit = gp.quicksum(profit[f] * (x[f]['spring'] + x[f]['autumn']) for f in fruits) + div_reward * d
    model.setObjective(total_profit, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.SolCount > 0:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
