import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_parameters(data_path)
    
    W = params['initial_investment']
    r1 = params['return_rate_option_1']
    r2 = params['return_rate_option_2']
    T = int(params['planning_horizon'])
    min_r1 = params['min_reserve_year1']
    min_r2 = params['min_reserve_year2']
    max_opt2 = params['max_option2_start']
    late_rate = params['option2_year0_late_settlement_rate']

    model = gp.Model("Investment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x01 = model.addVar(name="x01", lb=0)
    x02 = model.addVar(name="x02", lb=0)
    x11 = model.addVar(name="x11", lb=0)
    x12 = model.addVar(name="x12", lb=0)
    x21 = model.addVar(name="x21", lb=0)
    reserve1 = model.addVar(name="reserve1", lb=min_r1)
    reserve2 = model.addVar(name="reserve2", lb=min_r2)

    # Year 0 constraints
    model.addConstr(x01 + x02 <= W, "year0_budget")
    model.addConstr(x02 <= max_opt2, "max_option2_start0")

    # Year 1 constraints
    model.addConstr(x11 + x12 + reserve1 == x01 * (1 + r1), "year1_budget")
    model.addConstr(x12 <= max_opt2, "max_option2_start1")

    # Year 2 constraints
    model.addConstr(x21 + reserve2 == reserve1 + x11 * (1 + r1), "year2_budget")

    # Objective: Year 3 total wealth
    wealth = (
        x21 * (1 + r1) + 
        x12 * (1 + r2) + 
        x02 * (1 + r2) * (1 - late_rate) + 
        reserve2
    )
    model.setObjective(wealth, GRB.MAXIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
