import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_general_parameters

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
shirts_inv = params['shirts_inventory']
pants_inv = params['pants_inventory']
price_a = params['package_a_price']
price_b = params['package_b_price']
price_c = params['package_c_price']
shirts_a = params['package_a_shirts']
pants_a = params['package_a_pants']
shirts_b = params['package_b_shirts']
pants_b = params['package_b_pants']
shirts_c = params['package_c_shirts']
pants_c = params['package_c_pants']
min_a = params['min_campaign_batch_a']
min_b = params['min_campaign_batch_b']
min_c = params['min_campaign_batch_c']
act_cost_a = params['activation_cost_a']
act_cost_b = params['activation_cost_b']
act_cost_c = params['activation_cost_c']
labor_a = params['labor_hours_per_A']
labor_b = params['labor_hours_per_B']
labor_c = params['labor_hours_per_C']
labor_total = params['labor_hours_total']
bigM_a = params['bigM_a']
bigM_b = params['bigM_b']
bigM_c = params['bigM_c']
rev_thresh_b = params['package_b_review_threshold']
rev_charge_b = params['package_b_review_charge']
rev_thresh_c = params['package_c_review_threshold']
rev_charge_c = params['package_c_review_charge']

model = gp.Model()
model.setParam('OutputFlag', 0)

# Variables
x_a = model.addVar(vtype=GRB.INTEGER, name="x_a", lb=0)
x_b = model.addVar(vtype=GRB.INTEGER, name="x_b", lb=0)
x_c = model.addVar(vtype=GRB.INTEGER, name="x_c", lb=0)
y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
y_c = model.addVar(vtype=GRB.BINARY, name="y_c")
z_b = model.addVar(vtype=GRB.BINARY, name="z_b")
z_c = model.addVar(vtype=GRB.BINARY, name="z_c")

# Activation constraints
model.addConstr(x_a >= min_a * y_a, "activate_a")
model.addConstr(x_a <= bigM_a * y_a, "max_a")
model.addConstr(x_b >= min_b * y_b, "activate_b")
model.addConstr(x_b <= bigM_b * y_b, "max_b")
model.addConstr(x_c >= min_c * y_c, "activate_c")
model.addConstr(x_c <= bigM_c * y_c, "max_c")

# Resource constraints
model.addConstr(shirts_a*x_a + shirts_b*x_b + shirts_c*x_c <= shirts_inv, "shirts")
model.addConstr(pants_a*x_a + pants_b*x_b + pants_c*x_c <= pants_inv, "pants")
model.addConstr(labor_a*x_a + labor_b*x_b + labor_c*x_c <= labor_total, "labor")

# Review charge constraints
model.addConstr((z_b == 1) >> (x_b >= rev_thresh_b + 1))
model.addConstr((z_b == 0) >> (x_b <= rev_thresh_b))
model.addConstr((z_c == 1) >> (x_c >= rev_thresh_c + 1))
model.addConstr((z_c == 0) >> (x_c <= rev_thresh_c))

# Objective
revenue = price_a*x_a + price_b*x_b + price_c*x_c
costs = act_cost_a*y_a + act_cost_b*y_b + act_cost_c*y_c + rev_charge_b*z_b + rev_charge_c*z_c
model.setObjective(revenue - costs, GRB.MAXIMIZE)

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.objVal if model.status == GRB.OPTIMAL else 0}")
