import os
import sys
import gurobipy as gp
from gurobipy import GRB

current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(current_dir, 'src'))
from utils import load_goods_data, load_parameters

data_dir = os.path.join(current_dir, 'data')
goods = load_goods_data(os.path.join(data_dir, 'table_1.csv'))
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

max_cap = params['max_container_capacity']
min_load = params['min_container_load']
min_d_per_container = int(params['min_d_goods_per_container'])
min_c_per_a = int(params['min_c_per_a'])

goods_types = list(goods.keys())
quantities = {g: goods[g]['quantity'] for g in goods_types}
weights = {g: goods[g]['weight'] for g in goods_types}

max_containers = 20
N = range(max_containers)

model = gp.Model("ContainerMinimization")
model.setParam('OutputFlag', 0)
model.setParam('TimeLimit', 120)

x = {}
for g in goods_types:
    x[g] = model.addVars(N, vtype=GRB.INTEGER, lb=0, name=f"x_{g}")

y = model.addVars(N, vtype=GRB.BINARY, name="y")
e = model.addVars(N, vtype=GRB.BINARY, name="e")
z = model.addVars(N, vtype=GRB.BINARY, name="z")

model.setObjective(y.sum(), GRB.MINIMIZE)

for g in goods_types:
    model.addConstr(gp.quicksum(x[g][j] for j in N) == quantities[g], f"demand_{g}")

for j in N:
    total_weight = gp.quicksum(weights[g] * x[g][j] for g in goods_types)
    model.addConstr(total_weight <= 60 * y[j] - 15 * e[j], f"capacity_{j}")
    model.addConstr(total_weight >= min_load * y[j], f"min_load_{j}")
    model.addConstr(e[j] <= y[j], f"e_leq_y_{j}")
    model.addConstr(x['D'][j] >= min_d_per_container * y[j], f"min_D_{j}")
    model.addConstr(x['A'][j] <= quantities['A'] * z[j], f"A_indicator_{j}")
    model.addConstr(x['C'][j] >= min_c_per_a * z[j], f"C_if_A_{j}")
    model.addConstr(x['E'][j] <= quantities['E'] * e[j], f"E_indicator_{j}")

for j in range(max_containers-1):
    model.addConstr(y[j] >= y[j+1], f"symmetry_{j}")

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {int(model.ObjVal)}")
elif model.status == GRB.TIME_LIMIT and model.SolCount > 0:
    print(f"FINAL_OBJ_VALUE: {int(model.ObjVal)}")
else:
    print("FINAL_OBJ_VALUE: -1")
