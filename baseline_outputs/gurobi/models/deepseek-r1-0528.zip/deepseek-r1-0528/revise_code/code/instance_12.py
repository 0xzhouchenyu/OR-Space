import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load container data
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })
    
    # Load general parameters
    general_params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            general_params[param_name] = float(row['Value'])
    
    fixed_setup_cost = general_params['fixed_setup_cost']
    max_total_energy = general_params['max_total_energy_kwh']
    eco_capacity_share = general_params['eco_capacity_share']
    eco_overhead_cost = general_params['eco_overhead_cost']
    reg_energy = general_params['regular_energy_intensity_kwh_per_unit']
    eco_energy = general_params['eco_energy_intensity_kwh_per_unit']
    energy_cost = general_params['energy_cost_per_kwh']
    
    # Calculate electricity cost components
    reg_elec_cost = energy_cost * reg_energy
    eco_elec_cost = energy_cost * eco_energy
    
    n = len(containers)
    total_demand = sum(c['demand'] for c in containers)
    
    # Create model
    m = gp.Model("PlasticContainers")
    m.setParam('OutputFlag', 0)
    
    # Decision variables
    y = m.addVars(n, vtype=GRB.BINARY, name="y")  # Setup activation
    z = m.addVars(n, vtype=GRB.BINARY, name="z")  # Eco mode activation
    
    # Production variables: xR[i,j] for regular, xE[i,j] for eco
    xR = {}
    xE = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                xR[i,j] = m.addVar(vtype=GRB.INTEGER, lb=0, name=f"xR_{i}_{j}")
                xE[i,j] = m.addVar(vtype=GRB.INTEGER, lb=0, name=f"xE_{i}_{j}")
    
    # Production expressions
    pR = {i: gp.quicksum(xR[i,j] for j in range(n) if (i,j) in xR) for i in range(n)}
    pE = {i: gp.quicksum(xE[i,j] for j in range(n) if (i,j) in xE) for i in range(n)}
    total_prod = {i: pR[i] + pE[i] for i in range(n)}
    
    # Objective function
    fixed_costs = fixed_setup_cost * gp.quicksum(y[i] for i in range(n)) + eco_overhead_cost * gp.quicksum(z[i] for i in range(n))
    var_costs = gp.quicksum((containers[i]['cost'] + reg_elec_cost) * pR[i] + (containers[i]['cost'] + eco_elec_cost) * pE[i] for i in range(n))
    m.setObjective(fixed_costs + var_costs, GRB.MINIMIZE)
    
    # Demand constraints
    for j in range(n):
        supply = gp.quicksum(xR[i,j] for i in range(n) if (i,j) in xR) + gp.quicksum(xE[i,j] for i in range(n) if (i,j) in xE)
        m.addConstr(supply >= containers[j]['demand'], f"demand_{j}")
    
    # Eco capacity constraints
    for i in range(n):
        m.addConstr(pE[i] <= eco_capacity_share * total_prod[i], f"eco_share_{i}")
    
    # Setup linking constraints
    for i in range(n):
        m.addConstr(total_prod[i] <= total_demand * y[i], f"setup_{i}")
    
    # Eco activation constraints
    for i in range(n):
        m.addConstr(pE[i] <= total_demand * z[i], f"eco_activation_{i}")
        m.addConstr(z[i] <= y[i], f"eco_link_{i}")
    
    # Energy constraint
    total_energy = gp.quicksum(reg_energy * pR[i] + eco_energy * pE[i] for i in range(n))
    m.addConstr(total_energy <= max_total_energy, "energy_limit")
    
    # Solve
    m.optimize()
    
    # Output final objective value
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == "__main__":
    main()
