import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read staffing requirements
    requirements = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            period = row['Time_Period'].strip()
            req = int(row['Required_Salespeople'].strip())
            requirements[period] = req
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            # Try to convert to int or float as appropriate
            try:
                if '.' in value_str:
                    value = float(value_str)
                else:
                    value = int(value_str)
            except ValueError:
                # For shift_start_times, keep as string
                value = value_str
            params[param_name] = value

    # Extract parameters
    full_time_cost = params['full_time_cost']
    part_time_cost = params['part_time_cost']
    part_time_cap_per_period = params['part_time_cap_per_period']
    min_full_time_per_period = params['min_full_time_per_period']
    
    # The time periods and their requirements in order
    periods = list(requirements.keys())  # ['2:00-6:00', '6:00-10:00', ...]
    req_values = [requirements[p] for p in periods]
    n = len(periods)  # 6 periods

    # Create model
    model = gp.Model("MinCostStaffing")
    model.setParam('OutputFlag', 0)

    # Decision variables:
    # x[i] = number of full-time salespeople starting at period i (8-hour shift covering period i and (i+1)%n)
    x = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="full_time_start")
    
    # y[j] = number of part-time salespeople working in period j (4-hour shift only in period j)
    y = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="part_time")

    # Objective: minimize total daily labor cost
    model.setObjective(
        full_time_cost * gp.quicksum(x[i] for i in range(n)) +
        part_time_cost * gp.quicksum(y[j] for j in range(n)),
        GRB.MINIMIZE
    )

    # Constraints:
    # 1. Coverage constraint: for each period j, total staff >= required
    # Full-time staff in period j come from shifts starting at j and (j-1)%n
    for j in range(n):
        model.addConstr(
            x[j] + x[(j - 1) % n] + y[j] >= req_values[j],
            name=f"coverage_{j}"
        )
    
    # 2. Part-time cap per period
    for j in range(n):
        model.addConstr(
            y[j] <= part_time_cap_per_period,
            name=f"part_time_cap_{j}"
        )
    
    # 3. Minimum full-time staff present in each period
    for j in range(n):
        model.addConstr(
            x[j] + x[(j - 1) % n] >= min_full_time_per_period,
            name=f"min_full_time_{j}"
        )

    # Optimize
    model.optimize()

    # Output the objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case no optimal solution found, but problem should be feasible
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
