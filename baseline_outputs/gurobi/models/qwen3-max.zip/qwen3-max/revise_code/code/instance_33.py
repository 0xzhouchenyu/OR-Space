import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name']
        value = row['Value']
        if value == '':
            params[param_name] = None
        else:
            # Try to convert to int or float
            try:
                if '.' in value:
                    params[param_name] = float(value)
                else:
                    params[param_name] = int(value)
            except ValueError:
                params[param_name] = value

# Read items and values
items = []
values = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        items.append(row['Item'].strip())
        values.append(int(row['Value'].strip()))

n = len(items)
total_value = sum(values)

# Identify special items
diamond_indices = [i for i, item in enumerate(items) if 'Diamond' in item]
jr_indices = [i for i, item in enumerate(items) if 'Jack Russell' in item]
high_value_threshold = params['high_value_threshold']
high_value_indices = [i for i, val in enumerate(values) if val >= high_value_threshold]

# Create the optimization model
model = gp.Model("Inheritance_Split")
model.setParam('OutputFlag', 0)

# Binary variables: x[i] = 1 if item i goes to son 1, 0 if to son 2
x = model.addVars(n, vtype=GRB.BINARY, name="x")

# Variables for immediate and deferred assignments for diamonds
# Since diamonds can be deferred, we need to decide which diamonds are immediate and which are deferred.
# However, the problem states that the inheritance plan separates immediate transfers from deferred transfers.
# But note: the requirement says "deferred diamonds are limited by `deferred_diamonds_per_son`", meaning each son can have at most `deferred_diamonds_per_son` deferred diamonds.
# However, the problem does not specify which items are deferred vs immediate beyond diamonds. 
# The revision brief implies that only diamonds can be deferred? Because the parameter is named `deferred_diamonds_per_son`.
# And the original problem had all items assigned immediately. Now, for diamonds, we have an option to defer.

# But wait: the problem says "The inheritance plan now separates immediate transfers from deferred transfers." and then gives constraints on deferred diamonds.
# This suggests that non-diamond items are always immediate, and diamonds can be either immediate or deferred.

# However, the objective is about "immediate tax-weighted value" and "total value". 
# Total value includes both immediate and deferred. Immediate value only includes non-deferred items.

# Therefore, we need to decide for each diamond whether it is immediate or deferred, and to which son.

# Let's redefine:
# For non-diamond items: they are always immediate, and assigned to a son (so one binary variable per non-diamond item).
# For diamonds: we need two decisions: 
#   (1) which son gets the diamond (in total ownership, including deferred), and 
#   (2) whether the transfer is immediate or deferred.

# However, note the constraint: "deferred_diamonds_per_son" -> maximum number of deferred diamond items per son.
# This implies that the assignment of the diamond to a son is fixed (total ownership), but the timing (immediate/deferred) is separate.

# But the problem does not say that a diamond can be split between sons. So each diamond is owned entirely by one son, but the transfer might be deferred.

# Therefore, we can model:
#   y[i] = 1 if diamond i is assigned to son 1 (for total ownership), 0 if to son 2. (This is the total ownership assignment)
#   z[i] = 1 if diamond i is transferred immediately, 0 if deferred.

# However, note: the non-diamond items are always immediate and assigned to a son. So for non-diamond items, we have an assignment variable that also indicates immediate transfer.

# But the problem states: "The sons' current shares must satisfy `son1_min_share`" — what does "current shares" mean? 
# The revision says: "the estate split to remain fair when immediate tax-weighted value and total value are both considered".
# And the constraint `son1_min_share` is described as: "Minimum fraction of total value that son 1 must receive in total ownership"

# So `son1_min_share` applies to total ownership (including deferred). Therefore, the total value assigned to son1 (including deferred diamonds) must be at least son1_min_share * total_value.

# Now, for the objective: 
#   We have two imbalances:
#     imbalance_immediate = | (immediate value of son1) - (immediate value of son2) |
#     imbalance_total = | (total value of son1) - (total value of son2) |
#   And the objective is: immediate_tax_weight * imbalance_immediate + total_tax_weight * imbalance_total

# How to model absolute values? We can use auxiliary variables and constraints.

# Steps:

# 1. Define assignment for non-diamond items: they are immediate and assigned to a son. So for non-diamond item i, let a[i] = 1 if to son1, 0 to son2.
# 2. For diamonds: 
#      Let d_assign[i] = 1 if diamond i is assigned to son1 (total ownership), 0 to son2.
#      Let d_immediate[i] = 1 if diamond i is transferred immediately, 0 if deferred.
#    Note: if a diamond is deferred, then it does not count in the immediate value, but it does count in the total value.

# However, note: the problem does not require us to decide the timing for non-diamonds — they are immediate. Only diamonds can be deferred.

# But wait: the problem says "deferred diamonds are limited by `deferred_diamonds_per_son`", so only diamonds have deferred option.

# Therefore, we can do:

# Variables:
#   For non-diamond items (index i not in diamond_indices): 
#        x[i] in {0,1} -> 1 if son1 gets it (immediate)
#   For diamond items (index i in diamond_indices):
#        assign[i] in {0,1} -> 1 if son1 gets the diamond (total ownership)
#        immediate[i] in {0,1} -> 1 if the diamond is transferred immediately

# Constraints:
#   - Jack Russell dogs must not be separated: if both are assigned to the same son? Actually, the original constraint was that they go to the same son. 
#     Since they are non-diamond, we have x[jr0] == x[jr1].
#   - High-value concentration: for each son, the total number of high-value items (both immediate and deferred) assigned to that son <= max_high_value_items_per_son.
#        For son1: sum_{i in high_value_indices} [if i is non-diamond: x[i]; if i is diamond: assign[i]] <= max_high_value_items_per_son
#        Similarly for son2: sum_{i in high_value_indices} [if i is non-diamond: (1-x[i]); if i is diamond: (1-assign[i])] <= max_high_value_items_per_son
#        But note: the constraint says "one son may own", so we need to enforce for both sons.
#   - Deferred diamonds per son: 
#        For son1: sum_{i in diamond_indices} (1 - immediate[i]) * assign[i] <= deferred_diamonds_per_son
#        For son2: sum_{i in diamond_indices} (1 - immediate[i]) * (1 - assign[i]) <= deferred_diamonds_per_son
#   - son1_min_share: total value of son1 >= son1_min_share * total_value
#        total_value_son1 = sum_{non-diamond i} values[i]*x[i] + sum_{diamond i} values[i]*assign[i]
#        => total_value_son1 >= son1_min_share * total_value

# Objective:
#   immediate_value_son1 = sum_{non-diamond i} values[i]*x[i] + sum_{diamond i} values[i]*assign[i]*immediate[i]
#   immediate_value_son2 = (sum_{non-diamond i} values[i]*(1-x[i])) + sum_{diamond i} values[i]*(1-assign[i])*immediate[i]
#   But note: immediate_value_son2 = (total_immediate_value - immediate_value_son1), where total_immediate_value = sum_{non-diamond} values[i] + sum_{diamond} values[i]*immediate[i]
#   However, it's easier to compute the difference: 
#        diff_immediate = immediate_value_son1 - immediate_value_son2 = 2*immediate_value_son1 - total_immediate_value
#   Similarly, total_value_son1 = T1, total_value_son2 = total_value - T1, so diff_total = 2*T1 - total_value

# We'll introduce variables for the absolute differences.

# However, note: the problem says "minimize the difference in value between the two parts" but now with two components. The objective is a weighted sum of the two absolute differences.

# Let's define:
#   T1 = total value for son1 = sum_{non-diamond i} values[i]*x[i] + sum_{diamond i} values[i]*assign[i]
#   I1 = immediate value for son1 = sum_{non-diamond i} values[i]*x[i] + sum_{diamond i} values[i]*assign[i]*immediate[i]

# Then:
#   diff_total = |2*T1 - total_value|
#   diff_immediate = |2*I1 - total_immediate_value|, but note: total_immediate_value is not fixed because it depends on immediate[i]!

# Alternatively, we can express:
#   immediate_value_son2 = (sum_{non-diamond} values[i] - sum_{non-diamond} values[i]*x[i]) + sum_{diamond} values[i]*(1-assign[i])*immediate[i]
#   = (non_diamond_total - non_diamond_son1) + (diamond_immediate_total - diamond_immediate_son1)
#   where diamond_immediate_total = sum_{diamond} values[i]*immediate[i]
#   So immediate_value_son1 - immediate_value_son2 = [non_diamond_son1 + diamond_immediate_son1] - [non_diamond_total - non_diamond_son1 + diamond_immediate_total - diamond_immediate_son1]
#        = 2*(non_diamond_son1 + diamond_immediate_son1) - (non_diamond_total + diamond_immediate_total)
#        = 2*I1 - total_immediate_value

# But total_immediate_value is variable. So we cannot precompute it.

# Approach: use auxiliary variables for the absolute differences.

# We'll create:
#   diff_total_abs >= 2*T1 - total_value
#   diff_total_abs >= total_value - 2*T1
#   diff_immediate_abs >= 2*I1 - total_immediate_value
#   diff_immediate_abs >= total_immediate_value - 2*I1

# However, total_immediate_value = non_diamond_total + sum_{diamond} values[i]*immediate[i] 
#   = (total_value - sum_{diamond} values[i]) + sum_{diamond} values[i]*immediate[i]
#   = total_value - sum_{diamond} values[i]*(1 - immediate[i])

# So 2*I1 - total_immediate_value = 2*I1 - [total_value - sum_{diamond} values[i]*(1 - immediate[i])]

# But this is messy. Alternatively, we can avoid using total_immediate_value by expressing the difference as:
#   immediate_value_son1 - immediate_value_son2 = I1 - (I_total - I1) = 2*I1 - I_total, but I_total is variable.

# Standard way: introduce a variable for the difference and then absolute value constraints.

# However, note: we can also express the immediate difference as:
#   D_immediate = I1 - I2 = I1 - (I_total - I1) = 2*I1 - I_total, but I_total is not constant.

# Instead, we can write:
#   D_immediate = [sum_{non-diamond} values[i]*(2*x[i]-1)] + [sum_{diamond} values[i]*immediate[i]*(2*assign[i]-1)]

# Then |D_immediate| is the absolute difference in immediate values.

# Similarly, D_total = [sum_{non-diamond} values[i]*(2*x[i]-1)] + [sum_{diamond} values[i]*(2*assign[i]-1)]

# So we can define:
#   D_total = gp.LinExpr()
#   for i in range(n):
#       if i in diamond_indices:
#           D_total += values[i] * (2*assign[i] - 1)
#       else:
#           D_total += values[i] * (2*x[i] - 1)
#
#   D_immediate = gp.LinExpr()
#   for i in range(n):
#       if i in diamond_indices:
#           D_immediate += values[i] * immediate[i] * (2*assign[i] - 1)
#       else:
#           D_immediate += values[i] * (2*x[i] - 1)

# Then we want to minimize: immediate_tax_weight * |D_immediate| + total_tax_weight * |D_total|

# We can model absolute values by:
#   abs_D_total >= D_total
#   abs_D_total >= -D_total
#   similarly for abs_D_immediate.

# Now, let's set up the model accordingly.

# Separate non-diamond and diamond indices
non_diamond_indices = [i for i in range(n) if i not in diamond_indices]

# Create model
model = gp.Model("Inheritance_Split")
model.setParam('OutputFlag', 0)

# Variables for non-diamond items: x[i] for i in non_diamond_indices
x_vars = {}
for i in non_diamond_indices:
    x_vars[i] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}")

# Variables for diamonds: assign[i] and immediate[i] for i in diamond_indices
assign_vars = {}
immediate_vars = {}
for i in diamond_indices:
    assign_vars[i] = model.addVar(vtype=GRB.BINARY, name=f"assign_{i}")
    immediate_vars[i] = model.addVar(vtype=GRB.BINARY, name=f"immediate_{i}")

# Auxiliary variables for absolute differences
abs_D_total = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="abs_D_total")
abs_D_immediate = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="abs_D_immediate")

# Compute D_total and D_immediate
D_total = gp.LinExpr()
D_immediate = gp.LinExpr()

# Non-diamond items
for i in non_diamond_indices:
    D_total += values[i] * (2 * x_vars[i] - 1)
    D_immediate += values[i] * (2 * x_vars[i] - 1)

# Diamond items
for i in diamond_indices:
    D_total += values[i] * (2 * assign_vars[i] - 1)
    # For immediate: only if immediate_vars[i] is 1, then the term is included; if 0, then 0.
    # We can write: values[i] * immediate_vars[i] * (2 * assign_vars[i] - 1)
    # But this is quadratic! We have a product of two binary variables.

# Problem: immediate_vars[i] * assign_vars[i] is quadratic.

# We need to linearize. Let w[i] = immediate_vars[i] * assign_vars[i]. Since both are binary, we can introduce a new variable w[i] and constraints:
#   w[i] <= immediate_vars[i]
#   w[i] <= assign_vars[i]
#   w[i] >= immediate_vars[i] + assign_vars[i] - 1
#   w[i] >= 0

# Similarly, for the term (2 * assign_vars[i] - 1) * immediate_vars[i] = 2 * w[i] - immediate_vars[i]

# So:
#   D_immediate += values[i] * (2 * w[i] - immediate_vars[i])

# Let's do that.

w_vars = {}
for i in diamond_indices:
    w_vars[i] = model.addVar(vtype=GRB.BINARY, name=f"w_{i}")
    # Linearization constraints
    model.addConstr(w_vars[i] <= immediate_vars[i])
    model.addConstr(w_vars[i] <= assign_vars[i])
    model.addConstr(w_vars[i] >= immediate_vars[i] + assign_vars[i] - 1)

# Now recompute D_immediate for diamonds:
D_immediate = gp.LinExpr()
for i in non_diamond_indices:
    D_immediate += values[i] * (2 * x_vars[i] - 1)
for i in diamond_indices:
    D_immediate += values[i] * (2 * w_vars[i] - immediate_vars[i])

# Constraints for absolute values
model.addConstr(abs_D_total >= D_total)
model.addConstr(abs_D_total >= -D_total)
model.addConstr(abs_D_immediate >= D_immediate)
model.addConstr(abs_D_immediate >= -D_immediate)

# Constraint: Jack Russell dogs must not be separated
if len(jr_indices) == 2:
    # Both are non-diamond, so we have x_vars for them
    model.addConstr(x_vars[jr_indices[0]] == x_vars[jr_indices[1]])

# Constraint: son1_min_share on total ownership
T1 = gp.LinExpr()  # total value for son1
for i in non_diamond_indices:
    T1 += values[i] * x_vars[i]
for i in diamond_indices:
    T1 += values[i] * assign_vars[i]
model.addConstr(T1 >= params['son1_min_share'] * total_value)

# Constraint: high-value concentration
# Count high-value items for son1 and son2
high_value_son1 = gp.LinExpr()
high_value_son2 = gp.LinExpr()
for i in high_value_indices:
    if i in non_diamond_indices:
        high_value_son1 += x_vars[i]
        high_value_son2 += (1 - x_vars[i])
    else:  # diamond
        high_value_son1 += assign_vars[i]
        high_value_son2 += (1 - assign_vars[i])

max_high = params['max_high_value_items_per_son']
model.addConstr(high_value_son1 <= max_high)
model.addConstr(high_value_son2 <= max_high)

# Constraint: deferred diamonds per son
# Deferred diamonds for son1: for each diamond i, if assign_vars[i]==1 and immediate_vars[i]==0, then count 1.
# We can express: (1 - immediate_vars[i]) * assign_vars[i] = assign_vars[i] - w_vars[i]  [because w_vars[i] = immediate_vars[i]*assign_vars[i]]
deferred_son1 = gp.LinExpr()
deferred_son2 = gp.LinExpr()
for i in diamond_indices:
    deferred_son1 += assign_vars[i] - w_vars[i]
    # For son2: (1 - assign_vars[i]) * (1 - immediate_vars[i]) = 1 - assign_vars[i] - immediate_vars[i] + w_vars[i]
    # But note: we can also express as: (1 - immediate_vars[i]) - (assign_vars[i] - w_vars[i])? 
    # Alternatively, we can use: 
    #   deferred_son2 += (1 - assign_vars[i]) - (immediate_vars[i] - w_vars[i])? 
    # Actually, let's define:
    #   For son2: the diamond is assigned to son2 (so 1-assign_vars[i]) and deferred (so 1-immediate_vars[i]), so the product is (1-assign_vars[i])*(1-immediate_vars[i])
    #   = 1 - assign_vars[i] - immediate_vars[i] + assign_vars[i]*immediate_vars[i] = 1 - assign_vars[i] - immediate_vars[i] + w_vars[i]
    # But we don't want to introduce more variables. However, we can compute it as:
    #   total deferred diamonds for son2 = (number of diamonds) - (immediate diamonds) - (deferred diamonds for son1) ??? Not exactly.

# Instead, we can use the same linearization idea for son2? But note: we don't have a variable for son2 assignment.

# Alternatively, note:
#   (1 - assign_vars[i]) * (1 - immediate_vars[i]) = 1 - assign_vars[i] - immediate_vars[i] + w_vars[i]
# So:
deferred_son2_expr = gp.LinExpr()
for i in diamond_indices:
    deferred_son2_expr += 1 - assign_vars[i] - immediate_vars[i] + w_vars[i]

max_deferred = params['deferred_diamonds_per_son']
model.addConstr(deferred_son1 <= max_deferred)
model.addConstr(deferred_son2_expr <= max_deferred)

# Objective
obj = params['immediate_tax_weight'] * abs_D_immediate + params['total_tax_weight'] * abs_D_total
model.setObjective(obj, GRB.MINIMIZE)

# Optimize
model.optimize()

# Output the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, but the problem should be feasible
    print("FINAL_OBJ_VALUE: inf")
