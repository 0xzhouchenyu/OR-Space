import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load container data
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            params[param_name] = float(row['Value'])

    fixed_setup_cost = params['fixed_setup_cost']
    energy_cost_per_kwh = params['energy_cost_per_kwh']
    max_total_energy_kwh = params['max_total_energy_kwh']
    eco_capacity_share = params['eco_capacity_share']
    eco_overhead_cost = params['eco_overhead_cost']
    regular_energy_intensity = params['regular_energy_intensity_kwh_per_unit']
    eco_energy_intensity = params['eco_energy_intensity_kwh_per_unit']

    n = len(containers)

    # Create model
    model = gp.Model("PlasticContainers_Revised")
    model.setParam('OutputFlag', 0)

    # Binary setup variables for regular and eco modes
    y_reg = model.addVars(n, vtype=GRB.BINARY, name="y_reg")
    y_eco = model.addVars(n, vtype=GRB.BINARY, name="y_eco")

    # Production variables: x[i][j][mode] where mode=0 (regular), 1 (eco)
    # Only allowed if volume[i] >= volume[j]
    x_reg = {}
    x_eco = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x_reg[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_reg_{i}_{j}")
                x_eco[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_eco_{i}_{j}")

    # Demand constraints: for each type j, total supplied (regular + eco) >= demand[j]
    for j in range(n):
        supply_reg = gp.quicksum(x_reg[i, j] for i in range(n) if (i, j) in x_reg)
        supply_eco = gp.quicksum(x_eco[i, j] for i in range(n) if (i, j) in x_eco)
        model.addConstr(supply_reg + supply_eco >= containers[j]['demand'], f"demand_{j}")

    # Linking constraints for regular mode: if any regular production of type i, y_reg[i] must be 1
    M = sum(c['demand'] for c in containers)
    for i in range(n):
        total_reg_i = gp.quicksum(x_reg[i, j] for j in range(n) if (i, j) in x_reg)
        model.addConstr(total_reg_i <= M * y_reg[i], f"setup_reg_{i}")

    # Linking constraints for eco mode: if any eco production of type i, y_eco[i] must be 1
    for i in range(n):
        total_eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(total_eco_i <= M * y_eco[i], f"setup_eco_{i}")

    # Eco capacity constraint: eco production cannot exceed eco_capacity_share of total production for type i
    for i in range(n):
        total_prod_i = gp.quicksum(x_reg[i, j] + x_eco[i, j] for j in range(n) if (i, j) in x_reg)
        total_eco_i = gp.quicksum(x_eco[i, j] for j in range(n) if (i, j) in x_eco)
        model.addConstr(total_eco_i <= eco_capacity_share * total_prod_i, f"eco_capacity_{i}")

    # Total energy consumption constraint
    total_energy = gp.quicksum(
        regular_energy_intensity * x_reg[i, j] + eco_energy_intensity * x_eco[i, j]
        for i in range(n) for j in range(n) if (i, j) in x_reg
    )
    model.addConstr(total_energy <= max_total_energy_kwh, "total_energy")

    # Objective function
    variable_production_cost = gp.quicksum(
        containers[i]['cost'] * (x_reg[i, j] + x_eco[i, j])
        for i in range(n) for j in range(n) if (i, j) in x_reg
    )
    fixed_setup_costs = gp.quicksum(
        fixed_setup_cost * (y_reg[i] + y_eco[i]) for i in range(n)
    )
    eco_overhead_costs = gp.quicksum(
        eco_overhead_cost * y_eco[i] for i in range(n)
    )
    energy_costs = energy_cost_per_kwh * total_energy

    model.setObjective(
        variable_production_cost + fixed_setup_costs + eco_overhead_costs + energy_costs,
        GRB.MINIMIZE
    )

    # Optimize
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case no optimal solution found, but problem should be feasible
        obj_val = float('inf')

    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
