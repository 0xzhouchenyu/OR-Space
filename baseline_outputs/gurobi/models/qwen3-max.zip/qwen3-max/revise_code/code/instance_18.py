import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

fabric_production_rate = params['fabric_production_rate']
min_curtain_fabric_sales = params['min_curtain_fabric_sales']
min_clothing_fabric_sales = params['min_clothing_fabric_sales']

day_shift_regular_capacity = params['day_shift_regular_capacity']
night_shift_regular_capacity = params['night_shift_regular_capacity']
day_overtime_limit = params['day_overtime_limit']
night_overtime_limit = params['night_overtime_limit']
day_overtime_penalty = params['day_overtime_penalty']
night_overtime_penalty = params['night_overtime_penalty']
day_min_utilization_ratio = params['day_min_utilization_ratio']
night_min_utilization_ratio = params['night_min_utilization_ratio']

# Convert sales requirements to hours
min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

# Create model
model = gp.Model("Textile_Factory_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
# Regular production hours in day and night shifts
day_regular = model.addVar(lb=0, ub=day_shift_regular_capacity, name="day_regular")
night_regular = model.addVar(lb=0, ub=night_shift_regular_capacity, name="night_regular")

# Overtime hours in day and night shifts
day_ot = model.addVar(lb=0, ub=day_overtime_limit, name="day_overtime")
night_ot = model.addVar(lb=0, ub=night_overtime_limit, name="night_overtime")

# Allocation of production to fabrics in each shift (regular + overtime combined per shift)
# We can split total production per shift into clothing and curtain
day_clothing = model.addVar(lb=0, name="day_clothing")
day_curtain = model.addVar(lb=0, name="day_curtain")
night_clothing = model.addVar(lb=0, name="night_clothing")
night_curtain = model.addVar(lb=0, name="night_curtain")

# Total production constraints per shift
model.addConstr(day_clothing + day_curtain == day_regular + day_ot, "day_total")
model.addConstr(night_clothing + night_curtain == night_regular + night_ot, "night_total")

# Sales requirements
model.addConstr(day_clothing + night_clothing >= min_clothing_hours, "clothing_sales")
model.addConstr(day_curtain + night_curtain >= min_curtain_hours, "curtain_sales")

# Utilization constraints: regular hours must meet minimum ratios of total regular hours
total_regular = day_regular + night_regular
model.addConstr(day_regular >= day_min_utilization_ratio * total_regular, "day_min_util")
model.addConstr(night_regular >= night_min_utilization_ratio * total_regular, "night_min_util")

# Note: The above two constraints imply that day_min_utilization_ratio + night_min_utilization_ratio <= 1.
# Given both are 0.45, sum is 0.9 <= 1, so feasible.

# Objective: minimize total overtime penalty cost
model.setObjective(day_overtime_penalty * day_ot + night_overtime_penalty * night_ot, GRB.MINIMIZE)

# Optimize
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, output a large number or handle appropriately
    print("FINAL_OBJ_VALUE: inf")
