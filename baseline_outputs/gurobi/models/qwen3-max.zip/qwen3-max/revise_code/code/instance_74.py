import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            if row['Unit'] == 'boolean':
                params[key] = bool(int(value_str))
            else:
                params[key] = float(value_str)

    precedences = []
    with open(os.path.join(data_dir, 'table_1.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))

    activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    dur = {a: int(params[f'activity_{a}_duration']) for a in activities}
    work_cost = params['work_cost_per_day']
    machine_cost = params['machine_rental_cost_per_day']
    e_overtime_reduction = int(params['activity_E_overtime_reduction'])
    e_overtime_cost = params['activity_E_overtime_cost']
    e_followup_review_cost = params['activity_E_followup_review_cost']

    model = gp.Model("Project_Cost_Minimization")
    model.setParam('OutputFlag', 0)

    S = {a: model.addVar(lb=0, name=f"S_{a}") for a in activities}
    T = model.addVar(lb=0, name="T")

    y = model.addVar(vtype=GRB.BINARY, name="y")  # 1 if E is accelerated (overtime used), 0 otherwise

    # Duration of E becomes dur['E'] - e_overtime_reduction * y
    # But we cannot have negative duration, so we assume reduction is feasible (given as 3 days from 10)
    # Precedence constraints must account for the actual duration of E
    for pred, succ in precedences:
        if pred == 'E':
            # E's duration depends on y
            model.addConstr(S[succ] >= S[pred] + dur[pred] - e_overtime_reduction * y)
        else:
            model.addConstr(S[succ] >= S[pred] + dur[pred])

    # Project completion time T must be at least the finish time of C and B
    model.addConstr(T >= S['C'] + dur['C'])
    model.addConstr(T >= S['B'] + dur['B'])

    # Machine rental cost: from start of A to end of B
    # Original: machine_cost * (S['B'] + dur['B'] - S['A'])
    # This remains the same because A and B durations are fixed
    machine_rental = machine_cost * (S['B'] + dur['B'] - S['A'])

    # Work cost: work_cost * T
    work_total = work_cost * T

    # Overtime cost for E: e_overtime_cost * y
    overtime_cost = e_overtime_cost * y

    # Follow-up review cost: e_followup_review_cost * y
    followup_cost = e_followup_review_cost * y

    total_cost = work_total + machine_rental + overtime_cost + followup_cost
    model.setObjective(total_cost, GRB.MINIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of no solution, but problem should be feasible
        print("FINAL_OBJ_VALUE: None")

solve()
