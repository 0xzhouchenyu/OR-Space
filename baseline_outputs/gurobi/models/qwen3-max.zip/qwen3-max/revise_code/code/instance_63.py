import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

produce = params['produce_to_transport']
horse_poll = params['horse_pollution_per_trip']
bike_poll = params['bicycle_pollution_per_trip']
cart_poll = params['handcart_pollution_per_trip']
max_poll = params['max_total_pollution']
min_horse = params['min_horse_trips']
horse_cap = params['horse_capacity_per_trip']
bike_cap = params['bicycle_capacity_per_trip']
cart_cap = params['handcart_capacity_per_trip']
min_produce = params['min_total_produce']

# New cost parameters
horse_cost_per_trip = params['horse_cost_per_trip']
bike_cost_per_trip = params['bicycle_cost_per_trip']
cart_cost_per_trip = params['handcart_cost_per_trip']
horse_fixed_cost = params['horse_fixed_cost']
bike_fixed_cost = params['bicycle_fixed_cost']
cart_fixed_cost = params['handcart_fixed_cost']
pollution_penalty_per_unit = params['pollution_penalty_per_unit']
permit_threshold = params['horse_pollution_permit_threshold']
permit_fee = params['horse_pollution_permit_fee']

# Create model
model = gp.Model("FarmTransport")
model.setParam('OutputFlag', 0)

# Decision variables: number of trips (non-negative integers)
x_horse = model.addVar(vtype=GRB.INTEGER, lb=0, name="horse_trips")
x_bike = model.addVar(vtype=GRB.INTEGER, lb=0, name="bike_trips")
x_cart = model.addVar(vtype=GRB.INTEGER, lb=0, name="cart_trips")

# Binary variable: y=1 means bicycle chosen, y=0 means handcart chosen
y = model.addVar(vtype=GRB.BINARY, name="choose_bike")

# Binary variable for permit fee: z=1 if total pollution > permit_threshold, else 0
z = model.addVar(vtype=GRB.BINARY, name="permit_fee_indicator")

# Total pollution expression
total_pollution = horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart

# Big-M for linking pollution to permit fee
M_poll = max_poll  # Since max_total_pollution is 1000, this is a safe upper bound

# Link z to total_pollution: if total_pollution > permit_threshold then z=1
# total_pollution <= permit_threshold + M_poll * z
model.addConstr(total_pollution <= permit_threshold + M_poll * z, "permit_upper")
# To ensure z=0 when total_pollution <= permit_threshold, we also need:
# total_pollution >= permit_threshold + epsilon - M_poll * (1 - z)
# But since pollution is integer and permit_threshold=600, we can use:
epsilon = 1e-5
model.addConstr(total_pollution >= permit_threshold + epsilon - M_poll * (1 - z), "permit_lower")

# Either bicycle or handcart, not both
# If y=1, bicycle is allowed, handcart must be 0
# If y=0, handcart is allowed, bicycle must be 0
M_trips = 10000  # Big-M for trips (since produce is 1000, max trips needed is < 10000)
model.addConstr(x_bike <= M_trips * y, "bike_if_chosen")
model.addConstr(x_cart <= M_trips * (1 - y), "cart_if_not_chosen")

# Must transport at least min_produce
model.addConstr(horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce, "min_produce")

# Pollution constraint
model.addConstr(total_pollution <= max_poll, "max_pollution")

# Minimum horse trips
model.addConstr(x_horse >= min_horse, "min_horse_trips")

# Fixed cost indicators
use_horse = model.addVar(vtype=GRB.BINARY, name="use_horse")
use_bike = model.addVar(vtype=GRB.BINARY, name="use_bike")
use_cart = model.addVar(vtype=GRB.BINARY, name="use_cart")

# Link usage indicators to trips
model.addConstr(x_horse <= M_trips * use_horse, "horse_usage")
model.addConstr(x_bike <= M_trips * use_bike, "bike_usage")
model.addConstr(x_cart <= M_trips * use_cart, "cart_usage")

# Note: Since x_horse >= min_horse (which is 8), use_horse will be forced to 1.
# Similarly, either use_bike or use_cart will be 1 (but not both) because we must meet min_produce and horse alone may not be enough.

# Objective: minimize total cost
# Variable costs
var_cost = (horse_cost_per_trip * x_horse +
            bike_cost_per_trip * x_bike +
            cart_cost_per_trip * x_cart)

# Fixed costs
fixed_cost = (horse_fixed_cost * use_horse +
              bike_fixed_cost * use_bike +
              cart_fixed_cost * use_cart)

# Pollution penalty cost
pollution_cost = pollution_penalty_per_unit * total_pollution

# Permit fee
permit_cost = permit_fee * z

total_cost = var_cost + fixed_cost + pollution_cost + permit_cost

model.setObjective(total_cost, GRB.MINIMIZE)

# Optimize
model.optimize()

# Output the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, but the problem should be feasible
    print("FINAL_OBJ_VALUE: None")
