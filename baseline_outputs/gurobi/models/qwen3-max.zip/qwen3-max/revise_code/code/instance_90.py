import os
import csv
from gurobipy import Model, GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
shirts_inventory = params['shirts_inventory']
pants_inventory = params['pants_inventory']
package_a_price = params['package_a_price']
package_b_price = params['package_b_price']
package_c_price = params['package_c_price']
package_a_shirts = params['package_a_shirts']
package_a_pants = params['package_a_pants']
package_b_shirts = params['package_b_shirts']
package_b_pants = params['package_b_pants']
package_c_shirts = params['package_c_shirts']
package_c_pants = params['package_c_pants']
min_campaign_batch_a = params['min_campaign_batch_a']
min_campaign_batch_b = params['min_campaign_batch_b']
min_campaign_batch_c = params['min_campaign_batch_c']
activation_cost_a = params['activation_cost_a']
activation_cost_b = params['activation_cost_b']
activation_cost_c = params['activation_cost_c']
labor_hours_per_A = params['labor_hours_per_A']
labor_hours_per_B = params['labor_hours_per_B']
labor_hours_per_C = params['labor_hours_per_C']
labor_hours_total = params['labor_hours_total']
bigM_a = params['bigM_a']
bigM_b = params['bigM_b']
bigM_c = params['bigM_c']
package_b_review_threshold = params['package_b_review_threshold']
package_b_review_charge = params['package_b_review_charge']
package_c_review_threshold = params['package_c_review_threshold']
package_c_review_charge = params['package_c_review_charge']

# Create the model
model = Model("Maximize_Revenue")
model.setParam('OutputFlag', 0)

# Decision variables for quantities (non-negative integers)
x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_A")
x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_B")
x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="Package_C")

# Binary variables indicating if a campaign is launched
y_a = model.addVar(vtype=GRB.BINARY, name="Launch_A")
y_b = model.addVar(vtype=GRB.BINARY, name="Launch_B")
y_c = model.addVar(vtype=GRB.BINARY, name="Launch_C")

# Binary variables for review charges
z_b = model.addVar(vtype=GRB.BINARY, name="Review_Charge_B")
z_c = model.addVar(vtype=GRB.BINARY, name="Review_Charge_C")

# Objective: maximize revenue minus activation costs and review charges
revenue = package_a_price * x_a + package_b_price * x_b + package_c_price * x_c
activation_costs = activation_cost_a * y_a + activation_cost_b * y_b + activation_cost_c * y_c
review_charges = package_b_review_charge * z_b + package_c_review_charge * z_c
model.setObjective(revenue - activation_costs - review_charges, GRB.MAXIMIZE)

# Inventory constraints
model.addConstr(package_a_shirts * x_a + package_b_shirts * x_b + package_c_shirts * x_c <= shirts_inventory, "Shirts_Inventory")
model.addConstr(package_a_pants * x_a + package_b_pants * x_b + package_c_pants * x_c <= pants_inventory, "Pants_Inventory")

# Labor constraint
model.addConstr(labor_hours_per_A * x_a + labor_hours_per_B * x_b + labor_hours_per_C * x_c <= labor_hours_total, "Labor_Hours")

# Linking constraints for campaign activation
model.addConstr(x_a >= min_campaign_batch_a * y_a, "Min_A_if_launched")
model.addConstr(x_a <= bigM_a * y_a, "Max_A_if_not_launched")
model.addConstr(x_b >= min_campaign_batch_b * y_b, "Min_B_if_launched")
model.addConstr(x_b <= bigM_b * y_b, "Max_B_if_not_launched")
model.addConstr(x_c >= min_campaign_batch_c * y_c, "Min_C_if_launched")
model.addConstr(x_c <= bigM_c * y_c, "Max_C_if_not_launched")

# Review charge constraints for Package B
model.addConstr(x_b <= package_b_review_threshold + bigM_b * z_b, "Review_B_threshold")
# If x_b > package_b_review_threshold, then z_b must be 1. The above constraint ensures that if z_b=0, then x_b <= package_b_review_threshold.
# We don't need a lower bound on z_b because the objective will set it to 0 if possible.

# Review charge constraints for Package C
model.addConstr(x_c <= package_c_review_threshold + bigM_c * z_c, "Review_C_threshold")

# Optimize
model.optimize()

# Output the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, output 0 or handle as needed. But per problem, we assume feasible.
    print("FINAL_OBJ_VALUE: 0")
