import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            })
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    budget = params['company_budget']
    max_employees = int(params['max_employees'])
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_gj = int(params['max_one_candidate_g_j'])
    lead_premium = params['lead_premium']
    min_leads = int(params['min_leads'])
    mentor_bonus = params['mentor_bonus']
    max_pairs = int(params['max_pairs'])
    
    # Create Gurobi model
    model = gp.Model("HiringOptimization")
    model.setParam('OutputFlag', 0)
    
    candidate_names = [c['name'] for c in candidates]
    
    # Decision variables:
    # x[i] = 1 if candidate i is hired, 0 otherwise
    x = model.addVars(candidate_names, vtype=GRB.BINARY, name="x")
    
    # y[i] = 1 if candidate i is assigned as Lead, 0 if Engineer (only defined if hired)
    y = model.addVars(candidate_names, vtype=GRB.BINARY, name="y")
    
    # z = number of mentorship pairs (integer between 0 and max_pairs)
    z = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_pairs, name="z")
    
    # Constraints: if a candidate is not hired, they cannot be assigned a role
    for name in candidate_names:
        model.addConstr(y[name] <= x[name], name=f"role_if_hired_{name}")
    
    # Each hired candidate must have exactly one role -> automatically satisfied by y <= x and binary y
    
    # Budget constraint: net cost = sum(salary_i * x_i) + lead_premium * sum(y_i) - mentor_bonus * z <= budget
    total_base_salary = gp.quicksum(c['salary'] * x[c['name']] for c in candidates)
    total_lead_premium = lead_premium * gp.quicksum(y[c['name']] for c in candidates)
    net_cost = total_base_salary + total_lead_premium - mentor_bonus * z
    model.addConstr(net_cost <= budget, name="Budget")
    
    # Max employees constraint
    model.addConstr(gp.quicksum(x[name] for name in candidate_names) <= max_employees, name="MaxEmployees")
    
    # Min skill level constraint
    model.addConstr(gp.quicksum(c['skill'] * x[c['name']] for c in candidates) >= min_skill, name="MinSkill")
    
    # Min project management experience constraint
    model.addConstr(gp.quicksum(c['pm_exp'] * x[c['name']] for c in candidates) >= min_pm_exp, name="MinPMExp")
    
    # At most one of G and J can be hired
    model.addConstr(x['G'] + x['J'] <= max_gj, name="MaxOneGJ")
    
    # Minimum number of leads
    model.addConstr(gp.quicksum(y[name] for name in candidate_names) >= min_leads, name="MinLeads")
    
    # Mentorship pairs: z <= number of leads, z <= number of engineers, and z <= max_pairs (already set as ub)
    num_leads = gp.quicksum(y[name] for name in candidate_names)
    num_engineers = gp.quicksum(x[name] - y[name] for name in candidate_names)
    model.addConstr(z <= num_leads, name="PairsByLeads")
    model.addConstr(z <= num_engineers, name="PairsByEngineers")
    
    # Objective: minimize net cost = total_base_salary + total_lead_premium - mentor_bonus * z
    model.setObjective(net_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case no feasible solution, but problem should be feasible
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
