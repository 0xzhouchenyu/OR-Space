import os
import sys
import gurobipy as gp
from gurobipy import GRB
import csv

def load_processing_times(filepath):
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            name = row[0]
            value = float(row[1]) if '.' in row[1] else int(row[1])
            params[name] = value
    return params

def main():
    # Set up file paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    table_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    
    # Load data
    processing_times = load_processing_times(table_path)
    params = load_general_parameters(params_path)
    
    n_products = len(processing_times)
    n_machines = len(processing_times[0])
    
    # Extract parameters
    time_window = [params['time_window_1'], params['time_window_2'], params['time_window_3']]
    overtime_window = [params['overtime_window_1'], params['overtime_window_2'], params['overtime_window_3']]
    overtime_penalty = params['overtime_penalty_per_unit']
    M_vals = [params['M_1'], params['M_2'], params['M_3']]
    machine1_overtime_threshold = params['machine1_overtime_review_threshold']
    machine1_review_fee = params['machine1_overtime_review_fee']
    
    # Create model
    model = gp.Model("FlowShopScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Binary variables for job sequencing: x[i][k] = 1 if job i is in position k
    x = {}
    for i in range(n_products):
        for k in range(n_products):
            x[i, k] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{k}")
    
    # Start and completion times for each job on each machine
    start = {}
    comp = {}
    for k in range(n_products):
        for j in range(n_machines):
            start[k, j] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"start_{k}_{j}")
            comp[k, j] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"comp_{k}_{j}")
    
    # Overtime usage for each machine
    overtime = {}
    for j in range(n_machines):
        overtime[j] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=overtime_window[j], name=f"overtime_{j}")
    
    # Binary variable for Machine 1 overtime review fee trigger
    y = model.addVar(vtype=GRB.BINARY, name="machine1_review_trigger")
    
    # Constraints
    # Each job assigned to exactly one position
    for i in range(n_products):
        model.addConstr(gp.quicksum(x[i, k] for k in range(n_products)) == 1)
    
    # Each position has exactly one job
    for k in range(n_products):
        model.addConstr(gp.quicksum(x[i, k] for i in range(n_products)) == 1)
    
    # Processing time constraints
    for k in range(n_products):
        for j in range(n_machines):
            # Completion time = start time + processing time of the job in position k
            model.addConstr(comp[k, j] == start[k, j] + 
                           gp.quicksum(processing_times[i][j] * x[i, k] for i in range(n_products)))
    
    # Flow shop constraints: job must finish on previous machine before starting on next
    for k in range(n_products):
        for j in range(1, n_machines):
            model.addConstr(start[k, j] >= comp[k, j-1])
    
    # Machine capacity constraints: next job starts after previous job finishes on same machine
    for k in range(1, n_products):
        for j in range(n_machines):
            model.addConstr(start[k, j] >= comp[k-1, j])
    
    # Overtime constraints: total time on machine j <= time_window[j] + overtime[j]
    for j in range(n_machines):
        model.addConstr(comp[n_products-1, j] <= time_window[j] + overtime[j])
    
    # Machine 1 review fee trigger constraint
    # If overtime[0] > machine1_overtime_threshold, then y = 1
    # We use: overtime[0] <= machine1_overtime_threshold + M * y
    # And: overtime[0] >= machine1_overtime_threshold + epsilon - M * (1 - y)  [but we can skip the second if we only care about cost]
    # However, to ensure y=1 when overtime[0] > threshold, we need both directions.
    # Since overtime[0] is continuous, we use a small epsilon to handle strict inequality.
    epsilon = 1e-5
    M_big = M_vals[0]  # Use the provided big-M for machine 1
    
    model.addConstr(overtime[0] <= machine1_overtime_threshold + M_big * y)
    model.addConstr(overtime[0] >= machine1_overtime_threshold + epsilon - M_big * (1 - y))
    
    # Objective: minimize makespan + overtime penalties + review fee if triggered
    makespan = comp[n_products-1, n_machines-1]
    total_overtime_penalty = overtime_penalty * (overtime[0] + overtime[1] + overtime[2])
    review_fee = machine1_review_fee * y
    
    model.setObjective(makespan + total_overtime_penalty + review_fee, GRB.MINIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # Fallback: if no optimal solution, try to compute with original heuristic but that won't capture new constraints
        # But per problem, we assume Gurobi will find optimal
        obj_val = float('inf')
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
