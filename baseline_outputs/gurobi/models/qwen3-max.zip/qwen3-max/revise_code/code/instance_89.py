import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
profit_A = params['profit_per_kg_product_A']
profit_B = params['profit_per_kg_product_B']
max_hours_w1 = params['max_production_hours_week_1']
max_hours_w2 = params['max_production_hours_week_2']
hours_A = params['hours_per_kg_product_A']
hours_B = params['hours_per_kg_product_B']
min_ratio_B_to_A = params['min_output_ratio_product_B_to_A']
storage_ratio_A_to_B = params['storage_space_ratio_product_A_to_B']
max_storage_A_w1 = params['max_storage_product_A_equiv_week_1']
max_storage_A_w2 = params['max_storage_product_A_equiv_week_2']
initial_inv_A = params['initial_inventory_A']
initial_inv_B = params['initial_inventory_B']
storage_cost_A = params['storage_cost_per_kg_A']
storage_cost_B = params['storage_cost_per_kg_B']
promo_bonus_A = params['promo_profit_bonus_A']
promo_bonus_B = params['promo_profit_bonus_B']
max_promo_A = int(params['max_promotions_product_A'])
max_promo_B = int(params['max_promotions_product_B'])

# Create model
model = gp.Model("TwoWeek_Production")

# Decision variables
# Production quantities
prod_A_w1 = model.addVar(name="prod_A_w1", lb=0)
prod_A_w2 = model.addVar(name="prod_A_w2", lb=0)
prod_B_w1 = model.addVar(name="prod_B_w1", lb=0)
prod_B_w2 = model.addVar(name="prod_B_w2", lb=0)

# Sales quantities (assume all produced and inventory is sold, so sales = available - ending inventory)
# But we need to track inventory carry-over
inv_A_w1_end = model.addVar(name="inv_A_w1_end", lb=0)
inv_B_w1_end = model.addVar(name="inv_B_w1_end", lb=0)

# Ending inventory for week 2 should be zero? Not specified, but typically we don't require it.
# However, the problem says "carry-over inventory" only from week1 to week2, so week2 ending inventory is not carried beyond.
# We'll allow non-negative ending inventory in week2, but no cost or benefit, so optimal will be zero if no salvage.
inv_A_w2_end = model.addVar(name="inv_A_w2_end", lb=0)
inv_B_w2_end = model.addVar(name="inv_B_w2_end", lb=0)

# Promotion binary variables: 1 if product is promoted in that week
promo_A_w1 = model.addVar(vtype=GRB.BINARY, name="promo_A_w1")
promo_A_w2 = model.addVar(vtype=GRB.BINARY, name="promo_A_w2")
promo_B_w1 = model.addVar(vtype=GRB.BINARY, name="promo_B_w1")
promo_B_w2 = model.addVar(vtype=GRB.BINARY, name="promo_B_w2")

# Inventory balance constraints
# Week 1
model.addConstr(initial_inv_A + prod_A_w1 == inv_A_w1_end + (initial_inv_A + prod_A_w1 - inv_A_w1_end), "dummy_A_w1_sales_def")
# Instead, let's define sales explicitly or use inventory balance without sales variable.
# Standard approach: 
#   initial + production = sales + ending_inventory
# But since profit is from sales, and we don't have unsold penalty (except storage cost for carry-over),
# and no salvage value, we can assume all available is sold except what is carried over.

# Actually, we don't need sales variables. Profit is from the amount sold, which is (initial + production - ending_inventory).
# For week1: sales_A_w1 = initial_inv_A + prod_A_w1 - inv_A_w1_end
# For week2: sales_A_w2 = inv_A_w1_end + prod_A_w2 - inv_A_w2_end

# So we'll compute profit based on these expressions.

# Inventory balance constraints
# Week 1 for A
model.addConstr(initial_inv_A + prod_A_w1 - inv_A_w1_end >= 0, "nonneg_sales_A_w1")
# But actually, we don't need to constrain sales to be non-negative because the model will naturally not have negative sales if we set ending inventory <= available.
# Instead, we set:
model.addConstr(inv_A_w1_end <= initial_inv_A + prod_A_w1, "inv_A_w1_ub")
# Similarly for B
model.addConstr(inv_B_w1_end <= initial_inv_B + prod_B_w1, "inv_B_w1_ub")

# Week 2 for A
model.addConstr(inv_A_w2_end <= inv_A_w1_end + prod_A_w2, "inv_A_w2_ub")
# Week 2 for B
model.addConstr(inv_B_w2_end <= inv_B_w1_end + prod_B_w2, "inv_B_w2_ub")

# However, the standard way is to use equality for inventory balance, assuming no waste.
# Let's use equality: what comes in must go to sales or inventory.
# But since we don't have sales variables, we can express sales as the difference, and the model will maximize profit so it will sell as much as possible unless constrained by demand? 
# However, there is no upper bound on sales (demand is only a ratio constraint on production? Wait, the requirement says: "Market demand requires output of product B to be at least three times the output of product A in each week"

# Note: the original constraint was on output (production), not sales. The revised requirement says: "in each week", and the parameter name is "min_output_ratio_product_B_to_A", so it's on production per week.

# So constraints on production ratio per week:
model.addConstr(prod_B_w1 >= min_ratio_B_to_A * prod_A_w1, "Market_Demand_w1")
model.addConstr(prod_B_w2 >= min_ratio_B_to_A * prod_A_w2, "Market_Demand_w2")

# Production time constraints
model.addConstr(hours_A * prod_A_w1 + hours_B * prod_B_w1 <= max_hours_w1, "Prod_Hours_w1")
model.addConstr(hours_A * prod_A_w2 + hours_B * prod_B_w2 <= max_hours_w2, "Prod_Hours_w2")

# Storage capacity constraints (week by week)
# The storage capacity is given as "max_storage_product_A_equiv", meaning the total storage space used cannot exceed max_storage_A_equiv * storage_ratio_A_to_B (which is 4) in space units.
# But note: the description says "expressed as equivalent kg of product A", so:
#   For week 1: storage space used = storage_ratio_A_to_B * (inventory of A at end of week1) + 1 * (inventory of B at end of week1) <= max_storage_A_w1 * storage_ratio_A_to_B
# However, the parameter is named "max_storage_product_A_equiv_week_1", and the unit is kg, and context says "expressed as equivalent kg of product A".
# This means: the total storage capacity is equivalent to max_storage_A_w1 kg of product A.
# Since product A takes 4 times the space of B, then 1 kg of A = 4 space units, 1 kg of B = 1 space unit.
# So total space capacity = max_storage_A_w1 * 4.
# And the space used by inventory at end of week1 = 4 * inv_A_w1_end + 1 * inv_B_w1_end.
# Therefore:
max_space_w1 = max_storage_A_w1 * storage_ratio_A_to_B
max_space_w2 = max_storage_A_w2 * storage_ratio_A_to_B

model.addConstr(storage_ratio_A_to_B * inv_A_w1_end + inv_B_w1_end <= max_space_w1, "Storage_w1")
model.addConstr(storage_ratio_A_to_B * inv_A_w2_end + inv_B_w2_end <= max_space_w2, "Storage_w2")

# Promotion constraints: total promotions per product over two weeks cannot exceed the max
model.addConstr(promo_A_w1 + promo_A_w2 <= max_promo_A, "Max_Promo_A")
model.addConstr(promo_B_w1 + promo_B_w2 <= max_promo_B, "Max_Promo_B")

# Objective function: maximize total profit
# Profit from sales:
#   Week1: 
#       sales_A_w1 = initial_inv_A + prod_A_w1 - inv_A_w1_end
#       sales_B_w1 = initial_inv_B + prod_B_w1 - inv_B_w1_end
#   Week2:
#       sales_A_w2 = inv_A_w1_end + prod_A_w2 - inv_A_w2_end
#       sales_B_w2 = inv_B_w1_end + prod_B_w2 - inv_B_w2_end

# Base profit:
base_profit = (profit_A * (initial_inv_A + prod_A_w1 - inv_A_w1_end) +
               profit_B * (initial_inv_B + prod_B_w1 - inv_B_w1_end) +
               profit_A * (inv_A_w1_end + prod_A_w2 - inv_A_w2_end) +
               profit_B * (inv_B_w1_end + prod_B_w2 - inv_B_w2_end))

# Promotion bonus:
promo_profit = (promo_bonus_A * (initial_inv_A + prod_A_w1 - inv_A_w1_end) * promo_A_w1 +
                promo_bonus_B * (initial_inv_B + prod_B_w1 - inv_B_w1_end) * promo_B_w1 +
                promo_bonus_A * (inv_A_w1_end + prod_A_w2 - inv_A_w2_end) * promo_A_w2 +
                promo_bonus_B * (inv_B_w1_end + prod_B_w2 - inv_B_w2_end) * promo_B_w2)

# Storage cost: only for inventory carried from week1 to week2 (i.e., inv_A_w1_end and inv_B_w1_end)
storage_cost = storage_cost_A * inv_A_w1_end + storage_cost_B * inv_B_w1_end

# Total objective
objective = base_profit + promo_profit - storage_cost

model.setObjective(objective, GRB.MAXIMIZE)

# However, the above objective has products of continuous and binary variables (sales * promo), which is nonlinear.
# We need to linearize.

# Approach: introduce auxiliary variables for promoted sales.
# Let sales_A_w1 = sA1, etc., but we don't have sales variables. Alternatively, we can define:
#   promoted_sales_A_w1 = sales_A_w1 if promo_A_w1=1, else 0.
# But note: the bonus is only applied to the sales in the week when promoted.

# We can avoid introducing sales variables by expressing the bonus as:
#   bonus_A_w1 = promo_bonus_A * (initial_inv_A + prod_A_w1 - inv_A_w1_end) * promo_A_w1
# This is bilinear (continuous * binary). We linearize by introducing a new variable for the product.

# Let yA1 = (initial_inv_A + prod_A_w1 - inv_A_w1_end) * promo_A_w1
# But note: initial_inv_A is constant (0 in this case, but let's keep general).

# Since initial_inv_A and initial_inv_B are given as 0, we can simplify:
#   sales_A_w1 = prod_A_w1 - inv_A_w1_end
#   sales_B_w1 = prod_B_w1 - inv_B_w1_end
#   sales_A_w2 = inv_A_w1_end + prod_A_w2 - inv_A_w2_end
#   sales_B_w2 = inv_B_w1_end + prod_B_w2 - inv_B_w2_end

# Given initial_inv_A = 0 and initial_inv_B = 0.

# So:
#   base_profit = profit_A*(prod_A_w1 - inv_A_w1_end) + profit_B*(prod_B_w1 - inv_B_w1_end) +
#                 profit_A*(inv_A_w1_end + prod_A_w2 - inv_A_w2_end) + profit_B*(inv_B_w1_end + prod_B_w2 - inv_B_w2_end)
# Simplify: 
#   = profit_A*prod_A_w1 + profit_B*prod_B_w1 + profit_A*prod_A_w2 + profit_B*prod_B_w2 - profit_A*inv_A_w2_end - profit_B*inv_B_w2_end
# But wait, the inv_A_w1_end terms cancel? 
#   - profit_A*inv_A_w1_end + profit_A*inv_A_w1_end = 0.
# So base profit is independent of week1 ending inventory? That can't be right because we have storage cost.

# However, the storage cost is separate. And indeed, the base profit only depends on total production and final ending inventory (week2). 
# But the problem is that we might not want to carry inventory to week2 if there's no benefit, but here there is no discounting and same profit, so why carry? 
# However, production constraints might force us to produce in week1 and sell in week2 if week2 production capacity is tight? But in this case, both weeks have same capacity.

# But note: the promotion might make it beneficial to shift sales to a promoted week.

# Now, for the bonus: 
#   bonus = promo_bonus_A * (prod_A_w1 - inv_A_w1_end) * promo_A_w1 + ... 

# Since we have bilinear terms, we linearize.

# We'll create auxiliary variables for the sales in each week for each product.
sA1 = model.addVar(lb=0, name="sales_A_w1")
sB1 = model.addVar(lb=0, name="sales_B_w1")
sA2 = model.addVar(lb=0, name="sales_A_w2")
sB2 = model.addVar(lb=0, name="sales_B_w2")

# Inventory balance with sales variables
model.addConstr(initial_inv_A + prod_A_w1 == sA1 + inv_A_w1_end, "inv_bal_A_w1")
model.addConstr(initial_inv_B + prod_B_w1 == sB1 + inv_B_w1_end, "inv_bal_B_w1")
model.addConstr(inv_A_w1_end + prod_A_w2 == sA2 + inv_A_w2_end, "inv_bal_A_w2")
model.addConstr(inv_B_w1_end + prod_B_w2 == sB2 + inv_B_w2_end, "inv_bal_B_w2")

# Now, the bonus terms: 
#   We want: bonus_A_w1 = promo_bonus_A * sA1 * promo_A_w1
# Introduce zA1 = sA1 * promo_A_w1, then bonus_A_w1 = promo_bonus_A * zA1

zA1 = model.addVar(lb=0, name="zA1")
zB1 = model.addVar(lb=0, name="zB1")
zA2 = model.addVar(lb=0, name="zA2")
zB2 = model.addVar(lb=0, name="zB2")

# Linearization constraints for zA1 = sA1 * promo_A_w1
# Since sA1 >=0 and promo_A_w1 binary, we use:
M = 1000  # big-M, should be an upper bound on sA1. Max production in a week: max_hours / hours_per_kg = 40/6 ~ 6.67, so M=10 is safe, but let's use 100.
model.addConstr(zA1 <= M * promo_A_w1, "zA1_ub1")
model.addConstr(zA1 <= sA1, "zA1_ub2")
model.addConstr(zA1 >= sA1 - M * (1 - promo_A_w1), "zA1_lb")
model.addConstr(zA1 >= 0, "zA1_lb0")

# Similarly for others
model.addConstr(zB1 <= M * promo_B_w1, "zB1_ub1")
model.addConstr(zB1 <= sB1, "zB1_ub2")
model.addConstr(zB1 >= sB1 - M * (1 - promo_B_w1), "zB1_lb")
model.addConstr(zB1 >= 0, "zB1_lb0")

model.addConstr(zA2 <= M * promo_A_w2, "zA2_ub1")
model.addConstr(zA2 <= sA2, "zA2_ub2")
model.addConstr(zA2 >= sA2 - M * (1 - promo_A_w2), "zA2_lb")
model.addConstr(zA2 >= 0, "zA2_lb0")

model.addConstr(zB2 <= M * promo_B_w2, "zB2_ub1")
model.addConstr(zB2 <= sB2, "zB2_ub2")
model.addConstr(zB2 >= sB2 - M * (1 - promo_B_w2), "zB2_lb")
model.addConstr(zB2 >= 0, "zB2_lb0")

# Objective
base_profit = profit_A * sA1 + profit_B * sB1 + profit_A * sA2 + profit_B * sB2
promo_profit = promo_bonus_A * zA1 + promo_bonus_B * zB1 + promo_bonus_A * zA2 + promo_bonus_B * zB2
storage_cost = storage_cost_A * inv_A_w1_end + storage_cost_B * inv_B_w1_end

model.setObjective(base_profit + promo_profit - storage_cost, GRB.MAXIMIZE)

# Set solver parameters
model.setParam('OutputFlag', 0)

# Optimize
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
else:
    obj_val = 0.0

print(f"FINAL_OBJ_VALUE: {obj_val:.3f}")
