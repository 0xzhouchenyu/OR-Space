import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    
    n = len(shifts)  # number of periods (6)
    required = [s['required'] for s in shifts]
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name']
            if key in ['shift_duration', 'driver_rest_gap', 'crew_rest_gap', 'max_overtime_shifts']:
                params[key] = int(row['Value'])
            else:
                params[key] = float(row['Value'])
    
    shift_duration = params['shift_duration']  # 8 hours
    periods_per_shift = shift_duration // 4  # = 2
    
    max_night_driver_fraction = params['max_night_driver_fraction']
    max_night_crew_fraction = params['max_night_crew_fraction']
    max_overtime_shifts = params['max_overtime_shifts']
    overtime_cost_factor = params['overtime_cost_factor']
    
    # Late-night periods: 5 and 6 (0-indexed: 4 and 5)
    night_periods = [4, 5]
    
    # Create model
    model = gp.Model("RevisedBusScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables:
    # x_d[i] = regular driver starts at period i
    # x_c[i] = regular crew starts at period i
    # y_d[i] = overtime driver starts at period i
    # y_c[i] = overtime crew starts at period i
    x_d = model.addVars(n, vtype=GRB.INTEGER, name="x_d", lb=0)
    x_c = model.addVars(n, vtype=GRB.INTEGER, name="x_c", lb=0)
    y_d = model.addVars(n, vtype=GRB.INTEGER, name="y_d", lb=0)
    y_c = model.addVars(n, vtype=GRB.INTEGER, name="y_c", lb=0)
    
    # Objective: minimize total cost = sum(regular) + overtime_cost_factor * sum(overtime)
    total_regular = gp.quicksum(x_d[i] + x_c[i] for i in range(n))
    total_overtime = gp.quicksum(y_d[i] + y_c[i] for i in range(n))
    model.setObjective(total_regular + overtime_cost_factor * total_overtime, GRB.MINIMIZE)
    
    # Coverage constraints for each period j and for both drivers and crew
    for j in range(n):
        # Drivers covering period j
        driver_cover = gp.LinExpr()
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                driver_cover += x_d[i] + y_d[i]
        model.addConstr(driver_cover >= required[j], f"Driver_demand_period_{j+1}")
        
        # Crew covering period j
        crew_cover = gp.LinExpr()
        for i in range(n):
            covered_periods = [(i + k) % n for k in range(periods_per_shift)]
            if j in covered_periods:
                crew_cover += x_c[i] + y_c[i]
        model.addConstr(crew_cover >= required[j], f"Crew_demand_period_{j+1}")
    
    # Night shift fraction constraints for drivers
    total_drivers = gp.quicksum(x_d[i] + y_d[i] for i in range(n))
    night_drivers = gp.quicksum(x_d[i] + y_d[i] for i in night_periods)
    model.addConstr(night_drivers <= max_night_driver_fraction * total_drivers, "Driver_night_fraction")
    
    # Night shift fraction constraints for crew
    total_crew = gp.quicksum(x_c[i] + y_c[i] for i in range(n))
    night_crew = gp.quicksum(x_c[i] + y_c[i] for i in night_periods)
    model.addConstr(night_crew <= max_night_crew_fraction * total_crew, "Crew_night_fraction")
    
    # Total overtime shifts constraint
    model.addConstr(total_overtime <= max_overtime_shifts, "Max_overtime_shifts")
    
    # Solve the model
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # In case no optimal solution is found, we try to get the best bound or raise error
        # But per problem statement, we assume feasible instance
        raise RuntimeError("No optimal solution found")

if __name__ == "__main__":
    main()
