import os
import gurobipy as gp
from gurobipy import GRB
import csv

def load_toy_data(filepath):
    toys = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                'type': row['Toy_Type'].strip(),
                'profit': float(row['Profit_Per_Unit']),
                'wood': float(row['Wood_Required_Per_Unit']),
                'steel': float(row['Steel_Required_Per_Unit']),
            })
    return toys

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
toys = load_toy_data(os.path.join(data_dir, 'table_1.csv'))
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

available_wood = params['available_wood']
available_steel = params['available_steel']
truck_train_exclusion = params['truck_train_exclusion']
boat_airplane_dependency = params['boat_airplane_dependency']
boat_train_limit = params['boat_train_limit']
profit_premium_bonus = params['profit_premium_bonus']
premium_steel_factor = params['premium_steel_factor']
premium_shift_capacity = params['premium_shift_capacity']

# Create model
model = gp.Model("HausToys_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
x_std = {}  # standard shift production
x_prem = {} # premium shift production
y_std = {}  # binary: produce on standard shift?
y_prem = {} # binary: produce on premium shift?

toy_types = [t['type'] for t in toys]

for t in toy_types:
    x_std[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"x_std_{t}")
    x_prem[t] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"x_prem_{t}")
    y_std[t] = model.addVar(vtype=GRB.BINARY, name=f"y_std_{t}")
    y_prem[t] = model.addVar(vtype=GRB.BINARY, name=f"y_prem_{t}")

# Big M for linking (upper bound on production per toy type)
M = 1000

# Linking constraints: if not assigned to a shift, production must be zero
for t in toy_types:
    model.addConstr(x_std[t] <= M * y_std[t], name=f"link_std_{t}")
    model.addConstr(x_prem[t] <= M * y_prem[t], name=f"link_prem_{t}")
    # A toy type can be produced on at most one shift
    model.addConstr(y_std[t] + y_prem[t] <= 1, name=f"shift_excl_{t}")

# Resource constraints
# Wood: same for both shifts
model.addConstr(
    gp.quicksum(t['wood'] * (x_std[t['type']] + x_prem[t['type']]) for t in toys) <= available_wood,
    name="Wood_Constraint"
)

# Steel: premium shift uses more steel
model.addConstr(
    gp.quicksum(t['steel'] * x_std[t['type']] + 
                t['steel'] * premium_steel_factor * x_prem[t['type']] for t in toys) <= available_steel,
    name="Steel_Constraint"
)

# Premium shift capacity
model.addConstr(
    gp.quicksum(x_prem[t] for t in toy_types) <= premium_shift_capacity,
    name="Premium_Shift_Capacity"
)

# Original business rules (now applied to total production across shifts)
total_prod = {t: x_std[t] + x_prem[t] for t in toy_types}

# Truck-train exclusion: if trucks produced (any shift), no trains (any shift)
model.addConstr(
    (x_std['truck'] + x_prem['truck'] > 0) >> (x_std['train'] + x_prem['train'] == 0),
    name="Truck_Train_Exclusion_Indicator"
)
# However, Gurobi doesn't support direct implication with continuous vars in this way.
# Instead, use binary variables to indicate if a toy is produced at all.
y_produced = {}
for t in toy_types:
    y_produced[t] = model.addVar(vtype=GRB.BINARY, name=f"y_produced_{t}")
    # If any production, then y_produced[t] = 1
    model.addConstr(x_std[t] + x_prem[t] <= M * y_produced[t], name=f"prod_link_upper_{t}")
    model.addConstr(x_std[t] + x_prem[t] >= 0.0001 * y_produced[t], name=f"prod_link_lower_{t}")

# Now use y_produced for the logical constraints
model.addConstr(y_produced['truck'] + y_produced['train'] <= 1, name="Truck_Train_Exclusion")

# Boat-airplane dependency: if boats produced, airplanes must be too
model.addConstr(y_produced['boat'] <= y_produced['airplane'], name="Boat_Airplane_Dependency")

# Boat-train limit: total boats <= total trains
model.addConstr(total_prod['boat'] <= total_prod['train'], name="Boat_Train_Limit")

# Objective: maximize profit
# Standard shift: base profit
# Premium shift: base profit + bonus
obj = gp.quicksum(
    t['profit'] * x_std[t['type']] + 
    (t['profit'] + profit_premium_bonus) * x_prem[t['type']]
    for t in toys
)
model.setObjective(obj, GRB.MAXIMIZE)

# Optimize
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, output 0 or handle appropriately
    print("FINAL_OBJ_VALUE: 0")
