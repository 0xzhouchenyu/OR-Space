import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Parse table_1.csv
    proc_time = {}
    capacity = {}
    cost_rate = {}
    raw_cost = {}
    price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            if equip == 'Raw_Material_Cost':
                raw_cost = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            elif equip == 'Unit_Price':
                price = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            else:
                for prod, col in [('I', 'Product_I'), ('II', 'Product_II'), ('III', 'Product_III')]:
                    val = row[col].strip()
                    if val != '-':
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row['Effective_Machine_Hours'])
                cost_rate[equip] = float(row['Processing_Cost_per_Machine_Hour'])
    
    # Parse setup_costs.csv
    setup_cost = {}
    with open(os.path.join(data_dir, 'setup_costs.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            setup_cost[equip] = float(row['Fixed_Setup_Cost'])
    
    # Parse general_parameters.csv for the joint calibration parameters
    joint_calibration_trigger = 0
    joint_calibration_fee = 0
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            if param_name == 'A2_B2_joint_calibration_trigger':
                joint_calibration_trigger = int(float(row['Value']))
            elif param_name == 'A2_B2_joint_calibration_fee':
                joint_calibration_fee = float(row['Value'])
    
    # Equipment assignments
    stage_A_equip = {'I': ['A1', 'A2'], 'II': ['A1', 'A2'], 'III': ['A2']}
    stage_B_equip = {'I': ['B1', 'B2', 'B3'], 'II': ['B1'], 'III': ['B2']}
    
    # Create model
    model = gp.Model("Factory_Production")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[(equip, prod)] = units of product processed on equipment
    x = {}
    for prod in ['I', 'II', 'III']:
        for equip in stage_A_equip[prod]:
            x[(equip, prod)] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"x_{equip}_{prod}")
        for equip in stage_B_equip[prod]:
            x[(equip, prod)] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"x_{equip}_{prod}")
    
    # Binary variables for setup costs: y[equip] = 1 if equipment is used, 0 otherwise
    y = {}
    for equip in ['A1', 'A2', 'B1', 'B2', 'B3']:
        y[equip] = model.addVar(vtype=GRB.BINARY, name=f"y_{equip}")
    
    # Binary variable for joint calibration: z = 1 if both A2 and B2 are active
    z = model.addVar(vtype=GRB.BINARY, name="z")
    
    # Total production of each product (stage A flow = stage B flow)
    total = {}
    for prod in ['I', 'II', 'III']:
        total[prod] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"total_{prod}")
        # Flow conservation
        model.addConstr(gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod]) == total[prod])
        model.addConstr(gp.quicksum(x[(e, prod)] for e in stage_B_equip[prod]) == total[prod])
    
    # Link production variables to setup binary variables
    M = 1e6  # Big-M value (sufficiently large)
    for equip in ['A1', 'A2', 'B1', 'B2', 'B3']:
        relevant_products = []
        if equip in ['A1', 'A2']:
            if equip == 'A1':
                relevant_products = ['I', 'II']
            else:  # A2
                relevant_products = ['I', 'II', 'III']
        else:  # B1, B2, B3
            if equip == 'B1':
                relevant_products = ['I', 'II']
            elif equip == 'B2':
                relevant_products = ['I', 'III']
            elif equip == 'B3':
                relevant_products = ['I']
        
        # If any production on this equipment, then y[equip] must be 1
        model.addConstr(gp.quicksum(x[(equip, prod)] for prod in relevant_products) <= M * y[equip])
        # If y[equip] is 0, then no production
        for prod in relevant_products:
            model.addConstr(x[(equip, prod)] <= M * y[equip])
    
    # Joint calibration constraint: z = 1 if both A2 and B2 are active
    model.addConstr(z >= y['A2'] + y['B2'] - 1)
    model.addConstr(z <= y['A2'])
    model.addConstr(z <= y['B2'])
    
    # Capacity constraints
    for equip in ['A1', 'A2', 'B1', 'B2', 'B3']:
        relevant_products = []
        if equip in ['A1', 'A2']:
            if equip == 'A1':
                relevant_products = ['I', 'II']
            else:  # A2
                relevant_products = ['I', 'II', 'III']
        else:  # B1, B2, B3
            if equip == 'B1':
                relevant_products = ['I', 'II']
            elif equip == 'B2':
                relevant_products = ['I', 'III']
            elif equip == 'B3':
                relevant_products = ['I']
        
        if relevant_products:
            model.addConstr(gp.quicksum(proc_time[(equip, prod)] * x[(equip, prod)] for prod in relevant_products) <= capacity[equip])
    
    # Objective: profit = revenue - raw material - processing cost - setup costs - joint calibration fee
    revenue = gp.quicksum(price[p] * total[p] for p in ['I', 'II', 'III'])
    raw_mat = gp.quicksum(raw_cost[p] * total[p] for p in ['I', 'II', 'III'])
    proc_cost = gp.quicksum(cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x)
    setup_costs_total = gp.quicksum(setup_cost[e] * y[e] for e in ['A1', 'A2', 'B1', 'B2', 'B3'])
    joint_calib_cost = joint_calibration_fee * z
    
    objective = revenue - raw_mat - proc_cost - setup_costs_total - joint_calib_cost
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
    else:
        # In case of no solution, output 0.00 or handle appropriately
        print("FINAL_OBJ_VALUE: 0.00")

if __name__ == "__main__":
    main()
