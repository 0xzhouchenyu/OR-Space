import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'table_1.csv')
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    machine_avail = params['machine_time_available']  # hours
    craftsman_regular_avail = params['craftsman_regular_time_available']  # hours
    craftsman_overtime_avail = params['craftsman_overtime_available']  # hours
    machine_cost = params['machine_time_cost']  # GBP per hour
    craftsman_regular_cost = params['craftsman_time_cost']  # GBP per hour
    craftsman_overtime_cost = params['craftsman_overtime_cost']  # GBP per hour
    rev_X = params['revenue_product_X']  # GBP per batch
    rev_Y = params['revenue_product_Y']  # GBP per batch
    min_X = params['min_batches_product_X']  # batches
    qa_threshold = params['product_Y_QA_threshold']  # batches
    qa_fee = params['product_Y_QA_fee']  # GBP
    
    # Create model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables (continuous, non-negative)
    X = model.addVar(lb=0, name="X")
    Y = model.addVar(lb=0, name="Y")
    
    # Binary variable for QA fee: 1 if Y > qa_threshold, else 0
    z = model.addVar(vtype=GRB.BINARY, name="z")
    
    # Craftsman time split: regular and overtime
    total_craftsman_minutes = products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y
    total_craftsman_hours = total_craftsman_minutes / 60.0
    
    # We'll model the craftsman time cost by splitting into regular and overtime
    # But note: the problem states that the split remains unchanged, meaning we have two separate resources.
    # So we don't need to split the usage; we just have two constraints: regular <= 25, overtime <= 10, and total <= 35.
    # However, the cost is different for regular and overtime. But the problem does not specify that we can choose how to allocate.
    # Actually, the revision says: "the regular and overtime craftsman-hour split remains unchanged", meaning we have two separate pools.
    # Therefore, we must ensure that the total craftsman time used does not exceed regular + overtime, but we are charged differently for each pool?
    # However, the problem does not specify that we can decide how much to use from regular vs overtime. It's more natural to assume that we use regular first, then overtime.
    # But in linear programming, we can model it by having two constraints and the cost will be minimized by using regular first if we set up the cost correctly? 
    # However, note: we are maximizing profit. The cost of craftsman time is subtracted. So we want to minimize the cost of craftsman time for a given total usage.
    # But the problem states: "Costs are incurred for machine time and craftsman time", and now we have two types of craftsman time with different costs.
    # The key is: the company has 25 hours of regular and 10 hours of overtime available. They can use up to 25 hours at 2 GBP/hour and up to 10 hours at 7 GBP/hour.
    # How to model the cost? We can introduce two variables: 
    #   C_reg = craftsman regular hours used (<=25)
    #   C_ot = craftsman overtime hours used (<=10)
    # and constraint: C_reg + C_ot >= total_craftsman_hours
    # But note: we don't want to overpay, so the optimal solution will set C_reg + C_ot = total_craftsman_hours (if total_craftsman_hours <= 35) and use as much regular as possible.
    # However, since we are maximizing profit, and the cost is linear, we can avoid introducing extra variables by noting that the minimal cost for a given total_craftsman_hours T is:
    #   if T <= 25: cost = 2*T
    #   else: cost = 2*25 + 7*(T-25) = 50 + 7*(T-25)
    # But this is piecewise linear and convex, so we can model it with additional variables and constraints.
    
    # However, the problem does not require us to model the split explicitly for the constraint? The constraint is that total craftsman time cannot exceed 35 hours (25+10). 
    # But the cost depends on how much is in regular and overtime. Since the company will always use the cheaper regular time first, the cost function is as above.
    # Therefore, we can model the craftsman cost as a piecewise linear function. But note: Gurobi can handle piecewise linear objectives, but it's easier to use auxiliary variables.
    
    # Approach: introduce two non-negative variables for craftsman regular and overtime hours used.
    C_reg = model.addVar(lb=0, ub=craftsman_regular_avail, name="C_reg")
    C_ot = model.addVar(lb=0, ub=craftsman_overtime_avail, name="C_ot")
    
    # Constraint: total craftsman hours used must equal the sum of regular and overtime used
    model.addConstr(C_reg + C_ot == total_craftsman_hours, "Craftsman_Time_Balance")
    
    # Machine hours used
    machine_hours_used = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0
    model.addConstr(machine_hours_used <= machine_avail, "Machine_Time_Constraint")
    
    # Minimum production for X
    model.addConstr(X >= min_X, "Min_Production_X")
    
    # QA fee constraint: if Y > qa_threshold, then z=1, else z can be 0 (and we want it to be 0 to avoid fee)
    # We use a big-M constraint. Since Y is nonnegative and we don't have an explicit upper bound, but note:
    #   machine time: 19*Y/60 <= 40 -> Y <= 40*60/19 ≈ 126.3
    #   craftsman time: 29*Y/60 <= 35 -> Y <= 35*60/29 ≈ 72.4
    # So we can set M = 100 (or 80) to be safe.
    M = 100.0
    model.addConstr(Y <= qa_threshold + M * z, "QA_Threshold_Upper")
    # Note: we don't need a lower bound constraint because if Y <= qa_threshold, then z can be 0 and the constraint holds. 
    # And if Y > qa_threshold, then z must be 1 to satisfy the constraint.
    
    # Objective: maximize revenue - costs
    revenue = rev_X * X + rev_Y * Y
    machine_cost_total = machine_cost * machine_hours_used
    craftsman_cost_total = craftsman_regular_cost * C_reg + craftsman_overtime_cost * C_ot
    qa_cost = qa_fee * z
    profit = revenue - machine_cost_total - craftsman_cost_total - qa_cost
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case of no solution, but the problem should be feasible
        obj_val = 0.0
    
    print(f"FINAL_OBJ_VALUE: {obj_val:.2f}")

if __name__ == "__main__":
    main()
