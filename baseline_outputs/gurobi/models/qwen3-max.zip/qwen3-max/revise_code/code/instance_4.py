import os
import csv
from utils import load_parameters
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract original parameters
cow_price = params['cow_selling_price']
sheep_price = params['sheep_selling_price']
chicken_price = params['chicken_selling_price']
cow_feed = params['cow_feed_cost']
sheep_feed = params['sheep_feed_cost']
chicken_feed = params['chicken_feed_cost']
cow_manure = params['cow_manure_production']
sheep_manure = params['sheep_manure_production']
chicken_manure = params['chicken_manure_production']
max_manure = params['max_manure_capacity']
max_chickens = params['max_chickens']
min_cows = params['min_cows']
min_sheep = params['min_sheep']
max_total = params['max_total_animals']

# Extract new parameters for expanded setup
premium_capacity_multiplier = params['premium_capacity_multiplier']
premium_manure_multiplier = params['premium_manure_multiplier']
expansion_cost = params['expansion_cost']
premium_feed_multiplier = params['premium_feed_multiplier']
base_land_usage_cow = params['base_land_usage_cow']
base_land_usage_sheep = params['base_land_usage_sheep']
base_land_usage_chicken = params['base_land_usage_chicken']
base_land_capacity = params['base_land_capacity']
expansion_land_increase = params['expansion_land_increase']

# Create a new model
model = gp.Model("FarmProfit_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
cows = model.addVar(vtype=GRB.INTEGER, name="cows")
sheep = model.addVar(vtype=GRB.INTEGER, name="sheep")
chickens = model.addVar(vtype=GRB.INTEGER, name="chickens", lb=0, ub=max_chickens)

# Binary variable for expanded setup
expanded = model.addVar(vtype=GRB.BINARY, name="expanded")

# Apply minimum constraints for cows and sheep (must be met regardless of mode)
model.addConstr(cows >= min_cows, "min_cows")
model.addConstr(sheep >= min_sheep, "min_sheep")

# Land constraint: base_land_capacity + expansion_land_increase * expanded
land_used = base_land_usage_cow * cows + base_land_usage_sheep * sheep + base_land_usage_chicken * chickens
model.addConstr(land_used <= base_land_capacity + expansion_land_increase * expanded, "land_capacity")

# Manure constraint: max_manure * (1 + (premium_manure_multiplier - 1) * expanded)
manure_produced = cow_manure * cows + sheep_manure * sheep + chicken_manure * chickens
max_manure_effective = max_manure * (1 + (premium_manure_multiplier - 1) * expanded)
model.addConstr(manure_produced <= max_manure_effective, "manure_capacity")

# Total animals constraint: max_total * (1 + (premium_capacity_multiplier - 1) * expanded)
total_animals = cows + sheep + chickens
max_total_effective = max_total * (1 + (premium_capacity_multiplier - 1) * expanded)
model.addConstr(total_animals <= max_total_effective, "total_animals_capacity")

# Premium feed cost only applies when expanded is 1.
# We model feed cost as: 
#   base_feed_cost + (premium_feed_multiplier - 1) * base_feed_cost * expanded
# But since expanded is binary, we can express total feed cost as:
#   (cow_feed * (1 + (premium_feed_multiplier - 1) * expanded)) * cows + ...
# However, this is nonlinear (product of continuous and binary). Instead, we linearize.

# Introduce auxiliary variables for feed costs in expanded mode
# But note: the problem states that premium animals are only credible when expanded is in use.
# However, the business rule implies that if expanded=0, then we cannot have any "premium" animals,
# but the problem does not introduce separate premium animal variables. Instead, the same animals
# have higher feed cost when in expanded mode.

# Since the feed cost multiplier applies to all animals when expanded=1, we can write:
# Total feed cost = 
#   cow_feed * cows + sheep_feed * sheep + chicken_feed * chickens 
#   + (premium_feed_multiplier - 1) * (cow_feed * cows + sheep_feed * sheep + chicken_feed * chickens) * expanded
# This is bilinear (expanded * cows, etc.). We need to linearize.

# We introduce auxiliary variables for the extra feed cost due to expansion.
extra_feed_cows = model.addVar(vtype=GRB.CONTINUOUS, name="extra_feed_cows")
extra_feed_sheep = model.addVar(vtype=GRB.CONTINUOUS, name="extra_feed_sheep")
extra_feed_chickens = model.addVar(vtype=GRB.CONTINUOUS, name="extra_feed_chickens")

M = 1000000  # Big-M constant, should be larger than max possible animals

# Link extra_feed_cows to cows and expanded
model.addConstr(extra_feed_cows <= M * expanded, "extra_feed_cows_upper1")
model.addConstr(extra_feed_cows <= cow_feed * (premium_feed_multiplier - 1) * cows, "extra_feed_cows_upper2")
model.addConstr(extra_feed_cows >= cow_feed * (premium_feed_multiplier - 1) * cows - M * (1 - expanded), "extra_feed_cows_lower")

# Similarly for sheep
model.addConstr(extra_feed_sheep <= M * expanded, "extra_feed_sheep_upper1")
model.addConstr(extra_feed_sheep <= sheep_feed * (premium_feed_multiplier - 1) * sheep, "extra_feed_sheep_upper2")
model.addConstr(extra_feed_sheep >= sheep_feed * (premium_feed_multiplier - 1) * sheep - M * (1 - expanded), "extra_feed_sheep_lower")

# And for chickens
model.addConstr(extra_feed_chickens <= M * expanded, "extra_feed_chickens_upper1")
model.addConstr(extra_feed_chickens <= chicken_feed * (premium_feed_multiplier - 1) * chickens, "extra_feed_chickens_upper2")
model.addConstr(extra_feed_chickens >= chicken_feed * (premium_feed_multiplier - 1) * chickens - M * (1 - expanded), "extra_feed_chickens_lower")

# Total profit = revenue - base feed cost - extra feed cost - expansion cost * expanded
revenue = cow_price * cows + sheep_price * sheep + chicken_price * chickens
base_feed_cost = cow_feed * cows + sheep_feed * sheep + chicken_feed * chickens
extra_feed_cost = extra_feed_cows + extra_feed_sheep + extra_feed_chickens
total_cost = base_feed_cost + extra_feed_cost + expansion_cost * expanded

# Objective: maximize profit
model.setObjective(revenue - total_cost, GRB.MAXIMIZE)

# Optimize
model.optimize()

# Output the objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case no solution found, output 0 or handle appropriately
    print("FINAL_OBJ_VALUE: 0")
