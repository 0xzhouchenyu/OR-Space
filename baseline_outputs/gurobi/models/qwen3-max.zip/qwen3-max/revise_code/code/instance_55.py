import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_courses(data_dir):
    """Load course data from table_1.csv"""
    filepath = os.path.join(data_dir, 'table_1.csv')
    courses = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            categories = [c.strip() for c in row['Category'].split(';')]
            courses[course] = categories
    return courses

def load_parameters(data_dir):
    """Load general parameters from general_parameters.csv"""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    prerequisites = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if name == 'min_courses_required':
                params['min_courses_required'] = int(value)
            elif name.startswith('prerequisite_'):
                course_key = name[len('prerequisite_'):]
                prerequisites[course_key] = value
            elif name == 'mandatory_foundation_for_cs_counting':
                params['mandatory_foundation_for_cs_counting'] = value
            elif name == 'cs_category_name':
                params['cs_category_name'] = value
    return params, prerequisites

def match_prerequisite_course(prereq_key, course_list):
    """Match a prerequisite key (like 'computer_simulation') to actual course name"""
    key_lower = prereq_key.lower().replace('_', ' ')
    for course in course_list:
        if course.lower() == key_lower:
            return course
    return None

# Data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load data
courses = load_courses(data_dir)
params, prereq_raw = load_parameters(data_dir)

min_required = params['min_courses_required']
cs_category = params['cs_category_name']
foundation_course = params['mandatory_foundation_for_cs_counting']

# Build prerequisite mapping: course -> list of prerequisites
course_list = list(courses.keys())
prerequisites = {}

for prereq_key, prereq_value in prereq_raw.items():
    course_name = match_prerequisite_course(prereq_key, course_list)
    if course_name:
        if course_name not in prerequisites:
            prerequisites[course_name] = []
        prerequisites[course_name].append(prereq_value.strip())

# Get all categories
all_categories = set()
for cats in courses.values():
    for c in cats:
        all_categories.add(c)

# Create optimization model
model = gp.Model("RevisedCourseSelection")
model.setParam('OutputFlag', 0)

# Decision variables: binary, whether to take each course
x = model.addVars(course_list, vtype=GRB.BINARY, name="x")

# New variables: for each course and each category it belongs to, whether it is counted toward that category
y = {}
for course in course_list:
    for cat in courses[course]:
        y[(course, cat)] = model.addVar(vtype=GRB.BINARY, name=f"y_{course}_{cat}")

# Objective: minimize total number of courses taken
model.setObjective(gp.quicksum(x[course] for course in course_list), GRB.MINIMIZE)

# Constraint: a course can only be counted toward a category if it is taken
for course in course_list:
    for cat in courses[course]:
        model.addConstr(y[(course, cat)] <= x[course], f"count_if_taken_{course}_{cat}")

# Constraint: a course can be counted toward at most one category (cross-listed courses cannot satisfy multiple minima)
for course in course_list:
    if len(courses[course]) > 1:
        model.addConstr(gp.quicksum(y[(course, cat)] for cat in courses[course]) <= 1, f"one_category_per_course_{course}")
    else:
        # For single-category courses, we can link y directly (optional, but consistent)
        cat = courses[course][0]
        model.addConstr(y[(course, cat)] == x[course], f"single_cat_link_{course}")

# Constraint: at least min_required distinct counted courses in each category
for category in all_categories:
    model.addConstr(gp.quicksum(y[(course, category)] for course in course_list if category in courses[course]) >= min_required, f"Min_{category}")

# Prerequisite constraints: if you take a course, you must take its prerequisites
for course, prereqs in prerequisites.items():
    for prereq in prereqs:
        if prereq in course_list:
            model.addConstr(x[course] <= x[prereq], f"Prereq_{course}_needs_{prereq}")

# Special constraint: if any course is counted toward Computer Science, then the foundation course must be taken
# We check if the CS category has any counted courses, then enforce foundation
cs_counted_courses = [course for course in course_list if cs_category in courses[course]]
if cs_counted_courses:
    # Create a binary variable that is 1 if at least one CS course is counted
    z_cs = model.addVar(vtype=GRB.BINARY, name="z_cs")
    # z_cs >= y[(course, cs_category)] for each course in CS
    for course in cs_counted_courses:
        model.addConstr(z_cs >= y[(course, cs_category)], f"z_cs_ge_{course}")
    # If z_cs is 1, then foundation must be taken
    if foundation_course in course_list:
        model.addConstr(x[foundation_course] >= z_cs, f"foundation_if_cs_counted")
    else:
        # If foundation course is not in the list, then we cannot count any CS course
        for course in cs_counted_courses:
            model.addConstr(y[(course, cs_category)] == 0, f"no_cs_without_foundation_{course}")

# Optimize
model.optimize()

# Output the objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, but the problem should be feasible
    print("FINAL_OBJ_VALUE: -1")
