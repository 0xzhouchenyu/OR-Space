import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Original parameters
    a = params['a']  # hours per batch, method 1
    b = params['b']  # hours per batch, method 2
    k = params['k']  # tons per batch
    d = params['d']  # minimum production (tons)
    
    # Peak and off-peak costs
    m_peak = params['m_peak']
    n_peak = params['n_peak']
    m_offpeak = params['m_offpeak']
    n_offpeak = params['n_offpeak']
    
    # Time capacities per furnace
    c_peak = params['c_peak']      # max peak time per furnace
    c_offpeak = params['c_offpeak'] # max off-peak time per furnace
    
    # Plant-wide time capacities
    cap_peak = params['cap_peak']
    cap_offpeak = params['cap_offpeak']
    
    # Fixed activation overheads
    f_peak = params['f_peak']
    f_offpeak = params['f_offpeak']
    
    # Cooldown rule parameters
    threshold = params['offpeak_cooldown_batch_threshold']  # 2 batches
    cooldown_fee = params['offpeak_cooldown_fee']           # $20
    
    # Create model
    model = gp.Model("RevisedSteelFurnace")
    model.setParam('OutputFlag', 0)
    
    # Decision variables for each furnace (1 and 2) and each period (peak, off-peak) and method (1,2)
    # Continuous non-negative variables for number of batches
    x = {}
    for furnace in [1, 2]:
        for period in ['peak', 'offpeak']:
            for method in [1, 2]:
                var_name = f"x_f{furnace}_{period}_m{method}"
                x[(furnace, period, method)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=var_name)
    
    # Binary variables: whether furnace is used in peak/off-peak
    y_peak = {}
    y_offpeak = {}
    for furnace in [1, 2]:
        y_peak[furnace] = model.addVar(vtype=GRB.BINARY, name=f"y_peak_f{furnace}")
        y_offpeak[furnace] = model.addVar(vtype=GRB.BINARY, name=f"y_offpeak_f{furnace}")
    
    # Binary variables for cooldown: 1 if off-peak batches for furnace > threshold
    z = {}
    for furnace in [1, 2]:
        z[furnace] = model.addVar(vtype=GRB.BINARY, name=f"z_f{furnace}")
    
    # Total off-peak batches per furnace
    offpeak_batches = {}
    for furnace in [1, 2]:
        offpeak_batches[furnace] = x[(furnace, 'offpeak', 1)] + x[(furnace, 'offpeak', 2)]
    
    # Link y_peak: if any peak batch > 0 then y_peak = 1
    M_large = 1000  # big-M, since max batches per furnace is limited by time (e.g., 8/2=4 for peak method1)
    for furnace in [1, 2]:
        total_peak_batches = x[(furnace, 'peak', 1)] + x[(furnace, 'peak', 2)]
        model.addConstr(total_peak_batches <= M_large * y_peak[furnace])
        # Also, if y_peak=0 then total_peak_batches=0 (the above constraint enforces that)
    
    # Link y_offpeak: if any off-peak batch > 0 then y_offpeak = 1
    for furnace in [1, 2]:
        model.addConstr(offpeak_batches[furnace] <= M_large * y_offpeak[furnace])
    
    # Cooldown logic: if offpeak_batches[furnace] > threshold then z[furnace] = 1
    # We use: offpeak_batches[furnace] <= threshold + M_large * z[furnace]
    # And to ensure z=1 when exceeding, we also need: offpeak_batches[furnace] >= threshold + epsilon - M_large*(1-z)
    # But since batches can be fractional? However, note: the problem says "batches", and original model used continuous.
    # But the cooldown rule is defined on "batches", and threshold is integer. However, the problem does not specify integrality of batches.
    # Since the original heuristic used continuous, we assume continuous batches. But the cooldown rule is triggered when >2.
    # We'll model: if offpeak_batches > 2 then z=1. We can use:
    epsilon = 1e-5
    for furnace in [1, 2]:
        # If z=0, then offpeak_batches <= threshold
        model.addConstr(offpeak_batches[furnace] <= threshold + M_large * z[furnace])
        # If z=1, then offpeak_batches >= threshold + epsilon (to avoid z=1 when exactly at threshold)
        # But note: the rule says "more than 2", so at 2 it's okay. So we want z=1 only when >2.
        # However, without integer batches, we might have fractional. The constraint below ensures that if offpeak_batches > threshold, then z must be 1.
        # But the first constraint already forces z=1 when offpeak_batches > threshold (if we set M_large appropriately). Actually, the first constraint is sufficient for the implication: if offpeak_batches > threshold then z must be 1 (because if z=0, then offpeak_batches<=threshold). 
        # However, we don't need the reverse because we are minimizing cost and cooldown_fee is positive, so z will be 0 if possible.
        # So we only need the first constraint for the implication.
    
    # Objective: minimize total cost
    # Fuel costs
    fuel_cost = 0
    for furnace in [1,2]:
        # Peak
        fuel_cost += m_peak * x[(furnace, 'peak', 1)] + n_peak * x[(furnace, 'peak', 2)]
        # Off-peak
        fuel_cost += m_offpeak * x[(furnace, 'offpeak', 1)] + n_offpeak * x[(furnace, 'offpeak', 2)]
    
    # Fixed activation overheads
    fixed_cost = 0
    for furnace in [1,2]:
        fixed_cost += f_peak * y_peak[furnace] + f_offpeak * y_offpeak[furnace]
    
    # Cooldown fees
    cooldown_cost = 0
    for furnace in [1,2]:
        cooldown_cost += cooldown_fee * z[furnace]
    
    total_cost = fuel_cost + fixed_cost + cooldown_cost
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Time constraints per furnace
    for furnace in [1,2]:
        # Peak time: a*x1_peak + b*x2_peak <= c_peak
        model.addConstr(a * x[(furnace, 'peak', 1)] + b * x[(furnace, 'peak', 2)] <= c_peak, f"Furnace{furnace}_PeakTime")
        # Off-peak time: a*x1_offpeak + b*x2_offpeak <= c_offpeak
        model.addConstr(a * x[(furnace, 'offpeak', 1)] + b * x[(furnace, 'offpeak', 2)] <= c_offpeak, f"Furnace{furnace}_OffpeakTime")
    
    # Plant-wide time capacities
    total_peak_time = 0
    total_offpeak_time = 0
    for furnace in [1,2]:
        total_peak_time += a * x[(furnace, 'peak', 1)] + b * x[(furnace, 'peak', 2)]
        total_offpeak_time += a * x[(furnace, 'offpeak', 1)] + b * x[(furnace, 'offpeak', 2)]
    model.addConstr(total_peak_time <= cap_peak, "PlantWide_PeakTime")
    model.addConstr(total_offpeak_time <= cap_offpeak, "PlantWide_OffpeakTime")
    
    # Minimum production requirement
    total_batches = 0
    for furnace in [1,2]:
        for period in ['peak', 'offpeak']:
            for method in [1,2]:
                total_batches += x[(furnace, period, method)]
    model.addConstr(k * total_batches >= d, "MinProduction")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case of no solution, but the problem should be feasible
        obj_val = float('inf')
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
