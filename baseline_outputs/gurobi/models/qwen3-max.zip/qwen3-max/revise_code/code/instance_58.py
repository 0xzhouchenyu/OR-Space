import os
import csv
from itertools import combinations

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']

    profits = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons'],
    }

    water_use = {}
    for fruit in fruits:
        for season in seasons:
            key = f'water_per_acre_{fruit}_{season}'
            water_use[(fruit, season)] = params[key]

    total_area = params['total_farm_area']
    min_a_to_p = params['min_apples_to_pears_ratio']
    min_a_to_l = params['min_apples_to_lemons_ratio']
    o_to_l = params['oranges_to_lemons_ratio']
    max_types = int(params['max_fruit_types'])
    water_cap_spring = params['water_cap_spring']
    water_cap_autumn = params['water_cap_autumn']
    total_water_budget = params['total_water_budget']
    min_annual_water_per_fruit = params['min_annual_water_per_fruit']
    diversification_reward = params['diversification_reward']

    best_obj = -1e30
    best_sol = None

    # Enumerate all subsets of size 1 to max_types
    for size in range(1, max_types + 1):
        for subset in combinations(fruits, size):
            subset_set = set(subset)

            # Create a Gurobi model
            model = gp.Model("farm_revised")
            model.setParam('OutputFlag', 0)

            # Decision variables: x[fruit, season] = acres of fruit in season
            x = {}
            for fruit in fruits:
                for season in seasons:
                    x[fruit, season] = model.addVar(lb=0, name=f"x_{fruit}_{season}")

            # Binary variables: y[fruit] = 1 if fruit is grown (i.e., has positive annual water)
            y = {}
            for fruit in fruits:
                y[fruit] = model.addVar(vtype=GRB.BINARY, name=f"y_{fruit}")

            # Objective: maximize total profit + diversification reward
            total_profit = gp.quicksum(profits[fruit] * x[fruit, season] for fruit in fruits for season in seasons)
            diversification = diversification_reward * (gp.quicksum(y[fruit] for fruit in fruits) >= 2)
            # But we cannot use indicator directly in linear objective. Instead, we linearize:
            # Let z be a binary variable that is 1 if at least two fruits are grown.
            z = model.addVar(vtype=GRB.BINARY, name="z")
            model.addConstr(gp.quicksum(y[fruit] for fruit in fruits) >= 2 * z)
            model.addConstr(gp.quicksum(y[fruit] for fruit in fruits) <= 1 + z)  # if sum>=2 then z=1; if sum<=1 then z=0
            model.setObjective(total_profit + diversification_reward * z, GRB.MAXIMIZE)

            # Fix non-selected fruits to 0
            for fruit in fruits:
                if fruit not in subset_set:
                    for season in seasons:
                        model.addConstr(x[fruit, season] == 0)
                    model.addConstr(y[fruit] == 0)

            # Seasonal land constraints
            for season in seasons:
                model.addConstr(gp.quicksum(x[fruit, season] for fruit in fruits) <= total_area)

            # Water constraints
            model.addConstr(gp.quicksum(water_use[fruit, 'spring'] * x[fruit, 'spring'] for fruit in fruits) <= water_cap_spring)
            model.addConstr(gp.quicksum(water_use[fruit, 'autumn'] * x[fruit, 'autumn'] for fruit in fruits) <= water_cap_autumn)
            model.addConstr(gp.quicksum(water_use[fruit, season] * x[fruit, season] for fruit in fruits for season in seasons) <= total_water_budget)

            # Annual water per fruit and linking to y
            for fruit in fruits:
                annual_water = gp.quicksum(water_use[fruit, season] * x[fruit, season] for season in seasons)
                # If y[fruit] = 1, then annual_water >= min_annual_water_per_fruit
                model.addConstr(annual_water >= min_annual_water_per_fruit * y[fruit])
                # Also, if annual_water > 0 then y[fruit] must be 1. But since we have the above and y is binary, 
                # and we are maximizing, the solver will set y[fruit]=1 only if it helps (and we have the constraint that forces y=0 for non-subset).
                # However, to be safe, we can also add: annual_water <= M * y[fruit]. But note: we don't have an upper bound on annual_water per fruit? 
                # But the total water budget is 8000, so we can set M = total_water_budget.
                M = total_water_budget
                model.addConstr(annual_water <= M * y[fruit])

            # Annual mix constraints (on total annual acreage)
            total_apples = x['apples','spring'] + x['apples','autumn']
            total_pears = x['pears','spring'] + x['pears','autumn']
            total_oranges = x['oranges','spring'] + x['oranges','autumn']
            total_lemons = x['lemons','spring'] + x['lemons','autumn']

            model.addConstr(total_apples >= min_a_to_p * total_pears)
            model.addConstr(total_apples >= min_a_to_l * total_lemons)
            model.addConstr(total_oranges == o_to_l * total_lemons)

            # Solve
            model.optimize()

            if model.status == GRB.OPTIMAL:
                obj_val = model.objVal
                if obj_val > best_obj:
                    best_obj = obj_val
                    # We don't need to store the solution, just the objective

    print(f"FINAL_OBJ_VALUE: {best_obj}")

if __name__ == "__main__":
    import gurobipy as gp
    from gurobipy import GRB
    main()
