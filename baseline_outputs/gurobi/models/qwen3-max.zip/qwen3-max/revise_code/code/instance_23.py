import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'name': row['Product Name'].strip(),
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            })
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    available_labor = params['available_labor']
    available_material = params['available_material']
    fixed_costs = {
        'Shirt': params['fixed_cost_shirts'],
        'Short-sleeve': params['fixed_cost_short_sleeves'],
        'Casual Cloth': params['fixed_cost_casual_clothes']
    }
    regular_discount = params['segment_regular_discount']
    promo_discount = params['segment_promo_discount']
    promo_labor_cap = params['segment_promo_labor_cap']
    promo_material_cap = params['segment_promo_material_cap']
    min_batch = {
        'Shirt': params['min_batch_shirts'],
        'Short-sleeve': params['min_batch_short_sleeves'],
        'Casual Cloth': params['min_batch_casual_clothes']
    }
    max_prod = {
        'Shirt': params['max_prod_shirts'],
        'Short-sleeve': params['max_prod_short_sleeves'],
        'Casual Cloth': params['max_prod_casual_clothes']
    }
    
    # Create model
    model = gp.Model("clothing_production")
    model.setParam('OutputFlag', 0)
    
    n = len(products)
    product_names = [p['name'] for p in products]
    
    # Decision variables
    # y[i] = 1 if product i is produced (equipment activated), 0 otherwise
    y = {}
    # x_reg[i] = units of product i in regular segment
    x_reg = {}
    # x_promo[i] = units of product i in promotional segment
    x_promo = {}
    
    for i, name in enumerate(product_names):
        y[name] = model.addVar(vtype=GRB.BINARY, name=f"y_{name}")
        x_reg[name] = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_prod[name], name=f"x_reg_{name}")
        x_promo[name] = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_prod[name], name=f"x_promo_{name}")
    
    # Total production per product
    x_total = {name: x_reg[name] + x_promo[name] for name in product_names}
    
    # Constraints: if a product is not activated, total production must be 0
    for name in product_names:
        model.addConstr(x_total[name] <= max_prod[name] * y[name], name=f"activation_{name}")
    
    # Minimum batch size: if activated, total production >= min_batch
    for name in product_names:
        model.addConstr(x_total[name] >= min_batch[name] * y[name], name=f"min_batch_{name}")
    
    # Resource constraints: total labor and material
    total_labor = gp.quicksum(products[i]['labor'] * x_total[product_names[i]] for i in range(n))
    total_material = gp.quicksum(products[i]['material'] * x_total[product_names[i]] for i in range(n))
    model.addConstr(total_labor <= available_labor, name="total_labor")
    model.addConstr(total_material <= available_material, name="total_material")
    
    # Promotional segment caps
    promo_labor = gp.quicksum(products[i]['labor'] * x_promo[product_names[i]] for i in range(n))
    promo_material = gp.quicksum(products[i]['material'] * x_promo[product_names[i]] for i in range(n))
    model.addConstr(promo_labor <= promo_labor_cap, name="promo_labor_cap")
    model.addConstr(promo_material <= promo_material_cap, name="promo_material_cap")
    
    # Objective: maximize profit
    # Revenue from regular segment: price * regular_discount * x_reg
    # Revenue from promo segment: price * promo_discount * x_promo
    # Variable cost: var_cost * (x_reg + x_promo)
    # Fixed cost: fixed_cost * y
    revenue_reg = gp.quicksum(products[i]['price'] * regular_discount * x_reg[product_names[i]] for i in range(n))
    revenue_promo = gp.quicksum(products[i]['price'] * promo_discount * x_promo[product_names[i]] for i in range(n))
    var_cost_total = gp.quicksum(products[i]['var_cost'] * x_total[product_names[i]] for i in range(n))
    fixed_cost_total = gp.quicksum(fixed_costs[product_names[i]] * y[product_names[i]] for i in range(n))
    
    profit = revenue_reg + revenue_promo - var_cost_total - fixed_cost_total
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    # Output the objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case no feasible solution, output 0 or negative infinity? 
        # But problem should be feasible (e.g., produce nothing). However, note: if we produce nothing, then y=0, which is allowed.
        # So it should be feasible. If not optimal, we output the best found?
        # The problem says to output the optimal objective value. If infeasible, we might output a very negative number?
        # But the problem likely expects a number. Let's assume it's always feasible.
        # If infeasible, Gurobi would have status INFEASIBLE, but we can check.
        if model.SolCount > 0:
            print(f"FINAL_OBJ_VALUE: {model.objVal}")
        else:
            # No solution found, output negative infinity? But the problem requires a number.
            # Since producing nothing is feasible (y=0, x=0) and gives profit = 0 - 0 = 0? 
            # Actually, fixed costs are only paid if y=1. So if y=0, fixed cost=0, and profit=0.
            # So the problem is always feasible with profit 0.
            # Therefore, we should always have an optimal solution.
            print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
