import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    product_units = params['product_units']
    truck_pollution = params['truck_pollution']
    van_pollution = params['van_pollution']
    motorcycle_pollution = params['motorcycle_pollution']
    ev_pollution = params['electric_vehicle_pollution']
    max_total_pollution = params['max_total_pollution']
    min_truck_trips = params['min_truck_trips']
    truck_capacity = params['truck_capacity']
    van_capacity = params['van_capacity']
    motorcycle_capacity = params['motorcycle_capacity']
    ev_capacity = params['electric_vehicle_capacity']
    
    sales_point_shares = [
        params['sales_point_share_sp1'],
        params['sales_point_share_sp2'],
        params['sales_point_share_sp3']
    ]
    
    min_truck_shares = [
        params['min_truck_share_sp1'],
        params['min_truck_share_sp2'],
        params['min_truck_share_sp3']
    ]
    
    M_truck = params['M_truck_sp_day']
    M_ev = params['M_ev_sp_day']
    M_van = params['M_van_sp_day']
    M_moto = params['M_moto_sp_day']
    
    # Compute demand per sales point
    demands = [share * product_units for share in sales_point_shares]
    
    # Create model
    model = gp.Model("Revised_Transportation_Pollution_Minimization")
    model.setParam('OutputFlag', 0)
    
    # Sets: 3 sales points (0,1,2) and 3 days (0,1,2)
    sales_points = range(3)
    days = range(3)
    
    # Decision variables: number of trips for each vehicle type at each sales point and day
    x_truck = model.addVars(sales_points, days, vtype=GRB.INTEGER, name="truck_trips", lb=0)
    x_van = model.addVars(sales_points, days, vtype=GRB.INTEGER, name="van_trips", lb=0)
    x_moto = model.addVars(sales_points, days, vtype=GRB.INTEGER, name="moto_trips", lb=0)
    x_ev = model.addVars(sales_points, days, vtype=GRB.INTEGER, name="ev_trips", lb=0)
    
    # Binary variables to enforce the family constraint per sales point-day
    # y[sp,day] = 1 if using truck/ev family, 0 if using van/moto family
    y = model.addVars(sales_points, days, vtype=GRB.BINARY, name="family_choice")
    
    # Objective: minimize total pollution
    total_pollution = (
        truck_pollution * gp.quicksum(x_truck[sp, d] for sp in sales_points for d in days) +
        van_pollution * gp.quicksum(x_van[sp, d] for sp in sales_points for d in days) +
        motorcycle_pollution * gp.quicksum(x_moto[sp, d] for sp in sales_points for d in days) +
        ev_pollution * gp.quicksum(x_ev[sp, d] for sp in sales_points for d in days)
    )
    model.setObjective(total_pollution, GRB.MINIMIZE)
    
    # Constraint: all products must be delivered per sales point
    for sp in sales_points:
        model.addConstr(
            truck_capacity * gp.quicksum(x_truck[sp, d] for d in days) +
            van_capacity * gp.quicksum(x_van[sp, d] for d in days) +
            motorcycle_capacity * gp.quicksum(x_moto[sp, d] for d in days) +
            ev_capacity * gp.quicksum(x_ev[sp, d] for d in days) >= demands[sp],
            name=f"Demand_sp{sp}"
        )
    
    # Constraint: total pollution must not exceed maximum
    model.addConstr(total_pollution <= max_total_pollution, name="Max_Pollution")
    
    # Constraint: minimum total truck trips across all sales points and days
    model.addConstr(
        gp.quicksum(x_truck[sp, d] for sp in sales_points for d in days) >= min_truck_trips,
        name="Min_Truck_Trips"
    )
    
    # Family constraints per sales point and day
    for sp in sales_points:
        for d in days:
            # If y[sp,d] = 1, then van and moto must be 0; if y[sp,d] = 0, then truck and ev must be 0.
            model.addConstr(x_van[sp, d] <= M_van * (1 - y[sp, d]), name=f"Van_Family_sp{sp}_d{d}")
            model.addConstr(x_moto[sp, d] <= M_moto * (1 - y[sp, d]), name=f"Moto_Family_sp{sp}_d{d}")
            model.addConstr(x_truck[sp, d] <= M_truck * y[sp, d], name=f"Truck_Family_sp{sp}_d{d}")
            model.addConstr(x_ev[sp, d] <= M_ev * y[sp, d], name=f"EV_Family_sp{sp}_d{d}")
    
    # Minimum truck share per sales point (applies only to the truck/ev family days)
    # For each sales point, total truck trips >= min_truck_share * total trips in truck/ev family
    # But note: on days when y=0, truck trips are 0, so we only consider days with y=1.
    # We can express: sum_d x_truck[sp,d] >= min_truck_shares[sp] * sum_d (x_truck[sp,d] + x_ev[sp,d])
    for sp in sales_points:
        total_truck_trips_sp = gp.quicksum(x_truck[sp, d] for d in days)
        total_family_trips_sp = gp.quicksum(x_truck[sp, d] + x_ev[sp, d] for d in days)
        model.addConstr(
            total_truck_trips_sp >= min_truck_shares[sp] * total_family_trips_sp,
            name=f"Min_Truck_Share_sp{sp}"
        )
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case no solution is found, but problem should be feasible
        obj_val = float('inf')
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
