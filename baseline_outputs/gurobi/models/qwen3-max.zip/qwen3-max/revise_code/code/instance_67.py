import os
import csv
from gurobipy import GRB
import gurobipy as gp

def load_csv(filename):
    """Load a CSV file and return list of dictionaries."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return [row for row in reader]

def load_demand():
    """Load demand data from table_1.csv."""
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        month = row['Month']
        product = row['Product']
        units = int(row['Market_Demand_Units'])
        demand[(month, product)] = units
    return demand

def load_parameters():
    """Load general parameters."""
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = float(row['Value'])
        params[name] = value
    return params

def main():
    demand_data = load_demand()
    params = load_parameters()
    
    # Planning months: July to December
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']
    
    # Production costs (June-Dec)
    cost_I = params['product_I_cost_jun_to_dec']
    cost_II = params['product_II_cost_jun_to_dec']
    prod_cost = {'Product_I': cost_I, 'Product_II': cost_II}
    
    # Volumes for inventory
    vol_I = params['product_I_volume']
    vol_II = params['product_II_volume']
    volume = {'Product_I': vol_I, 'Product_II': vol_II}
    
    # Warehouse capacity and cost
    warehouse_cap = params['warehouse_capacity']
    own_cost = params['own_warehouse_cost']
    
    # Machine hours
    mh_I = params['product_I_machine_hours']
    mh_II = params['product_II_machine_hours']
    machine_hours = {'Product_I': mh_I, 'Product_II': mh_II}
    machine_hours_capacity = params['machine_hours_capacity_monthly']
    
    # Electricity parameters
    power_I = params['product_I_power_kwh']
    power_II = params['product_II_power_kwh']
    power = {'Product_I': power_I, 'Product_II': power_II}
    
    grid_elec_cost = params['grid_electricity_cost']
    gen_elec_cost = params['generator_electricity_cost']
    
    # Grid quotas and generator max per month
    grid_quota = {
        'July': params['grid_quota_july'],
        'August': params['grid_quota_august'],
        'September': params['grid_quota_september'],
        'October': params['grid_quota_october'],
        'November': params['grid_quota_november'],
        'December': params['grid_quota_december']
    }
    
    generator_max = {
        'July': params['generator_max_july'],
        'August': params['generator_max_august'],
        'September': params['generator_max_september'],
        'October': params['generator_max_october'],
        'November': params['generator_max_november'],
        'December': params['generator_max_december']
    }
    
    # Demand for planning months
    demand = {}
    for m in months:
        for p in products:
            demand[(m, p)] = demand_data[(m, p)]
    
    # Create model
    model = gp.Model("Revised_Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Production quantities
    x = model.addVars(months, products, lb=0, name="prod")
    
    # Inventory at end of month
    inv = model.addVars(months, products, lb=0, name="inv")
    
    # Grid electricity usage per month
    grid_elec = model.addVars(months, lb=0, name="grid_elec")
    
    # Generator electricity usage per month
    gen_elec = model.addVars(months, lb=0, name="gen_elec")
    
    # Objective: minimize production cost + inventory holding cost + electricity cost
    obj = gp.quicksum(prod_cost[p] * x[m, p] for m in months for p in products) + \
          gp.quicksum(own_cost * (volume['Product_I'] * inv[m, 'Product_I'] + volume['Product_II'] * inv[m, 'Product_II']) for m in months) + \
          gp.quicksum(grid_elec_cost * grid_elec[m] + gen_elec_cost * gen_elec[m] for m in months)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    for i, m in enumerate(months):
        # Inventory balance
        for p in products:
            if i == 0:
                model.addConstr(inv[m, p] == 0 + x[m, p] - demand[(m, p)], name=f"inv_balance_{m}_{p}")
            else:
                prev_m = months[i-1]
                model.addConstr(inv[m, p] == inv[prev_m, p] + x[m, p] - demand[(m, p)], name=f"inv_balance_{m}_{p}")
        
        # Machine hours capacity
        model.addConstr(
            machine_hours['Product_I'] * x[m, 'Product_I'] + machine_hours['Product_II'] * x[m, 'Product_II'] <= machine_hours_capacity,
            name=f"machine_hours_{m}"
        )
        
        # Electricity requirement: total electricity needed = sum over products (power per unit * production)
        total_power_needed = power['Product_I'] * x[m, 'Product_I'] + power['Product_II'] * x[m, 'Product_II']
        model.addConstr(grid_elec[m] + gen_elec[m] >= total_power_needed, name=f"elec_supply_{m}")
        
        # Grid quota constraint
        model.addConstr(grid_elec[m] <= grid_quota[m], name=f"grid_quota_{m}")
        
        # Generator max constraint
        model.addConstr(gen_elec[m] <= generator_max[m], name=f"gen_max_{m}")
        
        # Warehouse capacity: total volume of inventory must be <= warehouse_capacity
        total_vol = volume['Product_I'] * inv[m, 'Product_I'] + volume['Product_II'] * inv[m, 'Product_II']
        model.addConstr(total_vol <= warehouse_cap, name=f"warehouse_{m}")
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        obj_val = float('inf')
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
