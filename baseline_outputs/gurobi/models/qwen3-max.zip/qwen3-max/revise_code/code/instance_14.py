import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load food items
    items = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })
    
    # Load parameters
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_daily_calories = params['min_daily_calories']
    max_daily_calories = params['max_daily_calories']
    max_daily_sodium = params['max_daily_sodium']
    
    n_items = len(items)
    max_units = int(total_weight_limit // 100)  # max 100g units per item for the day
    max_meal_units = 3  # because each meal is exactly 300g = 3 units
    
    # Create model
    model = gp.Model("dinner_lunch")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    purchase_units = model.addVars(n_items, vtype=GRB.INTEGER, name="purchase_units", lb=0)
    lunch_units = model.addVars(n_items, vtype=GRB.INTEGER, name="lunch_units", lb=0)
    dinner_units = model.addVars(n_items, vtype=GRB.INTEGER, name="dinner_units", lb=0)
    select_item = model.addVars(n_items, vtype=GRB.BINARY, name="select_item")
    
    # Vegetable indices
    veg_indices = [i for i in range(n_items) if items[i]['type'] == 'Vegetable']
    
    # Binary variables for vegetable selection per meal
    lunch_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg_selected")
    dinner_veg_selected = model.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg_selected")
    
    # Objective: maximize total protein from assigned units (lunch + dinner)
    model.setObjective(
        gp.quicksum(items[i]['protein'] * (lunch_units[i] + dinner_units[i]) for i in range(n_items)),
        GRB.MAXIMIZE
    )
    
    # Budget constraint: total cost of purchases <= max_budget
    model.addConstr(
        gp.quicksum(items[i]['cost'] * purchase_units[i] for i in range(n_items)) <= max_budget,
        "budget"
    )
    
    # Total weight limit: total purchased grams <= total_weight_limit
    model.addConstr(
        gp.quicksum(100 * purchase_units[i] for i in range(n_items)) <= total_weight_limit,
        "total_weight"
    )
    
    # Per-meal weight balance: exactly 300g per meal
    model.addConstr(
        gp.quicksum(lunch_units[i] for i in range(n_items)) == 3,
        "lunch_weight"
    )
    model.addConstr(
        gp.quicksum(dinner_units[i] for i in range(n_items)) == 3,
        "dinner_weight"
    )
    
    # Linking purchase and meal assignments
    for i in range(n_items):
        model.addConstr(
            purchase_units[i] >= lunch_units[i] + dinner_units[i],
            f"link_purchase_{i}"
        )
    
    # Purchase selection linkage
    for i in range(n_items):
        model.addConstr(
            purchase_units[i] <= max_units * select_item[i],
            f"purchase_select_{i}"
        )
        model.addConstr(
            lunch_units[i] <= max_meal_units * select_item[i],
            f"lunch_select_{i}"
        )
        model.addConstr(
            dinner_units[i] <= max_meal_units * select_item[i],
            f"dinner_select_{i}"
        )
    
    # Vegetable selection constraints for lunch
    for idx, i in enumerate(veg_indices):
        model.addConstr(
            lunch_units[i] >= lunch_veg_selected[i],
            f"lunch_veg_lb_{i}"
        )
        model.addConstr(
            lunch_units[i] <= max_meal_units * lunch_veg_selected[i],
            f"lunch_veg_ub_{i}"
        )
    
    # Vegetable selection constraints for dinner
    for idx, i in enumerate(veg_indices):
        model.addConstr(
            dinner_units[i] >= dinner_veg_selected[i],
            f"dinner_veg_lb_{i}"
        )
        model.addConstr(
            dinner_units[i] <= max_meal_units * dinner_veg_selected[i],
            f"dinner_veg_ub_{i}"
        )
    
    # Minimum vegetable types per meal
    model.addConstr(
        gp.quicksum(lunch_veg_selected[i] for i in veg_indices) >= min_veg_types,
        "min_veg_lunch"
    )
    model.addConstr(
        gp.quicksum(dinner_veg_selected[i] for i in veg_indices) >= min_veg_types,
        "min_veg_dinner"
    )
    
    # Daily calorie bounds
    total_calories = gp.quicksum(
        items[i]['calories'] * (lunch_units[i] + dinner_units[i]) for i in range(n_items)
    )
    model.addConstr(total_calories >= min_daily_calories, "min_calories")
    model.addConstr(total_calories <= max_daily_calories, "max_calories")
    
    # Daily sodium bound
    total_sodium = gp.quicksum(
        items[i]['sodium'] * (lunch_units[i] + dinner_units[i]) for i in range(n_items)
    )
    model.addConstr(total_sodium <= max_daily_sodium, "max_sodium")
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        obj_val = 0.0
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
