import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Load data using the same logic as in utils.py but inline to be self-contained
def load_monthly_data(filepath):
    months = []
    purchasing_prices = {}
    selling_prices = {}
    with open(filepath, 'r') as f:
        lines = f.readlines()
        headers = lines[0].strip().split(',')
        for line in lines[1:]:
            parts = line.strip().split(',')
            month = int(parts[0])
            months.append(month)
            purchasing_prices[month] = float(parts[1])
            selling_prices[month] = float(parts[2])
    return months, purchasing_prices, selling_prices

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        lines = f.readlines()
        headers = lines[0].strip().split(',')
        for line in lines[1:]:
            parts = line.strip().split(',')
            param_name = parts[0]
            value = float(parts[1])
            params[param_name] = value
    return params

# Set up file paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")
table1_path = os.path.join(data_dir, "table_1.csv")
general_params_path = os.path.join(data_dir, "general_parameters.csv")

# Load data
months, purchasing_prices, selling_prices = load_monthly_data(table1_path)
params = load_general_parameters(general_params_path)

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params['fixed_ordering_cost']
month2_bulk_receiving_threshold = params['month2_bulk_receiving_threshold']
month2_bulk_receiving_fee = params['month2_bulk_receiving_fee']

# Create Gurobi model
model = gp.Model("Maximize_Profit")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}  # purchase in month m
s = {}  # sell in month m
inv = {}  # inventory at end of month m
y = {}  # binary: 1 if purchase in month m > 0 (for fixed ordering cost)
z = None  # binary: 1 if February purchase > month2_bulk_receiving_threshold

for m in months:
    x[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"purchase_{m}")
    s[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"sell_{m}")
    inv[m] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"inventory_{m}")
    y[m] = model.addVar(vtype=GRB.BINARY, name=f"order_indicator_{m}")

# Special binary variable for February (month 2) bulk receiving fee
if 2 in months:
    z = model.addVar(vtype=GRB.BINARY, name="feb_bulk_receiving")

# Objective: maximize profit = revenue - purchase cost - fixed ordering costs - Feb bulk fee
objective = gp.quicksum(selling_prices[m] * s[m] - purchasing_prices[m] * x[m] for m in months)
objective -= fixed_ordering_cost * gp.quicksum(y[m] for m in months)
if 2 in months:
    objective -= month2_bulk_receiving_fee * z

model.setObjective(objective, GRB.MAXIMIZE)

# Constraints
M = 1000000  # Big-M value

for i, m in enumerate(months):
    # Inventory balance
    if i == 0:
        prev_inv = initial_stock
    else:
        prev_inv = inv[months[i-1]]
    
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], f"inventory_balance_{m}")
    
    # Warehouse capacity after purchase (before selling)
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, f"warehouse_after_purchase_{m}")
    
    # End-of-month inventory capacity
    model.addConstr(inv[m] <= warehouse_capacity, f"warehouse_end_{m}")
    
    # Cannot sell more than available
    model.addConstr(s[m] <= prev_inv + x[m], f"sell_limit_{m}")
    
    # Link purchase to fixed ordering cost indicator
    # If x[m] > 0 then y[m] = 1; if x[m] = 0 then y[m] can be 0
    model.addConstr(x[m] <= M * y[m], f"ordering_link_{m}")

# February bulk receiving constraint (only if month 2 exists)
if 2 in months:
    # If x[2] > month2_bulk_receiving_threshold, then z must be 1
    model.addConstr(x[2] <= month2_bulk_receiving_threshold + M * z, "feb_bulk_upper")
    # If z = 0, then x[2] <= month2_bulk_receiving_threshold
    # The above constraint already enforces this

# Optimize
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, output a fallback (though problem should be feasible)
    print("FINAL_OBJ_VALUE: 0")
