import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    profit_corn = params['profit_per_acre_corn']
    profit_wheat = params['profit_per_acre_wheat']
    profit_soybeans = params['profit_per_acre_soybeans']
    profit_sorghum = params['profit_per_acre_sorghum']
    total_area = params['total_farm_area']
    corn_wheat_ratio = params['corn_wheat_ratio']
    soybeans_sorghum_ratio = params['soybeans_sorghum_ratio']
    wheat_sorghum_ratio = params['wheat_sorghum_ratio']
    
    # Create a new model
    model = gp.Model("Farm_Optimization_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables for acreage
    corn = model.addVar(lb=0, name="corn")
    wheat = model.addVar(lb=0, name="wheat")
    soybeans = model.addVar(lb=0, name="soybeans")
    sorghum = model.addVar(lb=0, name="sorghum")
    
    # Binary variable to enforce mutual exclusion between corn and soybeans
    # y = 1 means corn is planted (soybeans not allowed), y = 0 means soybeans is planted (corn only at minimum)
    y = model.addVar(vtype=GRB.BINARY, name="y")
    
    # Objective: maximize profit
    model.setObjective(
        profit_corn * corn + 
        profit_wheat * wheat + 
        profit_soybeans * soybeans + 
        profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )
    
    # Constraints
    
    # Total area constraint
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")
    
    # Corn >= 2 * wheat
    model.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio")
    
    # Soybeans >= 0.5 * sorghum
    model.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio")
    
    # Wheat = 3 * sorghum
    model.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_ratio")
    
    # Mutual exclusion: corn and soybeans cannot both be positive
    # If y = 1, then soybeans must be 0; if y = 0, then corn can only be at minimum (but we also have a minimum corn constraint)
    # We'll use a big-M approach. Since total area is 100, we can set M = 100.
    M = total_area
    model.addConstr(soybeans <= M * (1 - y), "soybeans_exclusion")
    model.addConstr(corn <= M * y, "corn_exclusion")
    
    # Minimum corn requirement: at least 20 acres of corn
    model.addConstr(corn >= 20, "min_corn")
    
    # However, note: if y=0, then corn <= 0 from the corn_exclusion constraint, but we also require corn>=20.
    # This would be infeasible. Therefore, y must be 1 to satisfy corn>=20.
    # But wait: the problem says "Tom and Jerry are not free to skip corn entirely, because a standing outlet agreement calls for a minimum of 20 acres of corn"
    # So corn must be at least 20, which forces y=1 (because if y=0, corn<=0, which contradicts corn>=20).
    # Therefore, soybeans must be 0.
    # However, let's model it as above and let the solver figure it out.
    
    # Optimize the model
    model.optimize()
    
    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of infeasibility, but the problem should be feasible
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
