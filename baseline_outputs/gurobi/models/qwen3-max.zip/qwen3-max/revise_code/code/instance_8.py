import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read table_1.csv
    filepath = os.path.join(data_dir, 'table_1.csv')
    workers = []
    tasks = []
    time_cost = {}
    fixed_cost = {}
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        tasks = [h.strip() for h in header[1:-1]]  # ['A', 'B', 'C', 'D']
        fixed_cost_col_index = len(header) - 1
        
        for row in reader:
            worker = row[0].strip()
            workers.append(worker)
            for j, task in enumerate(tasks):
                time_cost[(worker, task)] = int(row[j + 1])
            fixed_cost[worker] = int(row[fixed_cost_col_index])
    
    # Read general_parameters.csv
    param_filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(param_filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = int(row['Value'])
    
    shared_temp_handoff_cost = params['shared_temp_handoff_cost']  # 6
    worker_II_V_pair_fee = params['worker_II_V_pair_fee']  # 5
    
    # Create the optimization model
    model = gp.Model("Revised_Assignment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i,j] = 1 if worker i is assigned to task j
    x = {}
    for w in workers:
        for t in tasks:
            x[(w, t)] = model.addVar(vtype=GRB.BINARY, name=f"x_{w}_{t}")
    
    # Auxiliary binary variables for the special conditions
    y_III_V = model.addVar(vtype=GRB.BINARY, name="y_III_V")  # 1 if both III and V are assigned
    y_II_V = model.addVar(vtype=GRB.BINARY, name="y_II_V")    # 1 if both II and V are assigned
    
    # Objective: minimize total cost = time costs + fixed costs + special fees
    total_time_cost = gp.quicksum(time_cost[(w, t)] * x[(w, t)] for w in workers for t in tasks)
    total_fixed_cost = gp.quicksum(fixed_cost[w] * gp.quicksum(x[(w, t)] for t in tasks) for w in workers)
    total_special_cost = shared_temp_handoff_cost * y_III_V + worker_II_V_pair_fee * y_II_V
    model.setObjective(total_time_cost + total_fixed_cost + total_special_cost, GRB.MINIMIZE)
    
    # Each task must be assigned to exactly one worker
    for t in tasks:
        model.addConstr(gp.quicksum(x[(w, t)] for w in workers) == 1, name=f"task_{t}")
    
    # Each worker can be assigned to at most one task
    for w in workers:
        model.addConstr(gp.quicksum(x[(w, t)] for t in tasks) <= 1, name=f"worker_{w}")
    
    # Exactly 4 workers are assigned (since there are 4 tasks, this is implied but we can add for clarity)
    # However, the constraints above already ensure exactly 4 assignments.
    
    # Constraints for y_III_V: y_III_V >= assignment_III + assignment_V - 1
    assigned_III = gp.quicksum(x[('III', t)] for t in tasks)
    assigned_V = gp.quicksum(x[('V', t)] for t in tasks)
    model.addConstr(y_III_V >= assigned_III + assigned_V - 1, name="y_III_V_lower")
    model.addConstr(y_III_V <= assigned_III, name="y_III_V_upper1")
    model.addConstr(y_III_V <= assigned_V, name="y_III_V_upper2")
    
    # Constraints for y_II_V: y_II_V >= assignment_II + assignment_V - 1
    assigned_II = gp.quicksum(x[('II', t)] for t in tasks)
    model.addConstr(y_II_V >= assigned_II + assigned_V - 1, name="y_II_V_lower")
    model.addConstr(y_II_V <= assigned_II, name="y_II_V_upper1")
    model.addConstr(y_II_V <= assigned_V, name="y_II_V_upper2")
    
    # Optimize
    model.optimize()
    
    # Output the final objective value
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
