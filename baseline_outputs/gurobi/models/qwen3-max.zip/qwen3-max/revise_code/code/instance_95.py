import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_table_1(data_dir):
    """Load the weekly demand, capacity, and cost data."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    weeks = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })
    return weeks

def load_general_parameters(data_dir):
    """Load general parameters."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")
weeks_data = load_table_1(data_dir)
params = load_general_parameters(data_dir)

storage_cost = params['storage_cost_per_thousand_boxes']
fixed_setup_cost = params['fixed_setup_cost']
week2_push_threshold = params['week2_push_threshold']
week3_capacity_loss_after_week2_push = params['week3_capacity_loss_after_week2_push']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']

n_weeks = len(weeks_data)

# Create the model
model = gp.Model("Beverage_Production_Planning")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVars(n_weeks, lb=0, name="x")  # production in week t (thousand boxes)
s = model.addVars(n_weeks, lb=0, name="s")  # inventory at end of week t (thousand boxes)
y = model.addVars(n_weeks, vtype=GRB.BINARY, name="y")  # 1 if production > 0 in week t
z_microclean = model.addVar(vtype=GRB.BINARY, name="z_microclean")  # 1 if week2 production > week2_microclean_threshold
z_push = model.addVar(vtype=GRB.BINARY, name="z_push")  # 1 if week2 production > week2_push_threshold

# Original capacity constraints (to be adjusted for week 3 if push occurs)
for t in range(n_weeks):
    model.addConstr(x[t] <= weeks_data[t]['capacity'] * y[t], name=f"capacity_week_{t+1}")

# Week 2 micro-clean constraint: if x[1] > week2_microclean_threshold then z_microclean = 1
M_large = 1000  # big-M value, larger than max possible production
model.addConstr(x[1] <= week2_microclean_threshold + M_large * z_microclean, name="microclean_upper")
model.addConstr(x[1] >= week2_microclean_threshold + 0.001 - M_large * (1 - z_microclean), name="microclean_lower")

# Week 2 push constraint: if x[1] > week2_push_threshold then z_push = 1
model.addConstr(x[1] <= week2_push_threshold + M_large * z_push, name="push_upper")
model.addConstr(x[1] >= week2_push_threshold + 0.001 - M_large * (1 - z_push), name="push_lower")

# Adjust week 3 capacity if push occurred
original_week3_capacity = weeks_data[2]['capacity']
reduced_week3_capacity = original_week3_capacity - week3_capacity_loss_after_week2_push
model.addConstr(x[2] <= reduced_week3_capacity + (original_week3_capacity - reduced_week3_capacity) * (1 - z_push), name="week3_capacity_adjusted")

# Inventory balance constraints
# Assume initial inventory is 0
for t in range(n_weeks):
    if t == 0:
        model.addConstr(x[t] - s[t] == weeks_data[t]['demand'], name=f"balance_week_{t+1}")
    else:
        model.addConstr(s[t-1] + x[t] - s[t] == weeks_data[t]['demand'], name=f"balance_week_{t+1}")

# Link production to setup binary: if x[t] > 0 then y[t] = 1
epsilon = 0.001
for t in range(n_weeks):
    model.addConstr(x[t] >= epsilon * y[t], name=f"setup_link_{t+1}")

# Objective: minimize total production cost + storage cost + fixed setup costs + micro-clean fee (if applicable)
production_cost = gp.quicksum(weeks_data[t]['cost'] * x[t] for t in range(n_weeks))
storage_cost_total = gp.quicksum(storage_cost * s[t] for t in range(n_weeks))
setup_cost_total = gp.quicksum(fixed_setup_cost * y[t] for t in range(n_weeks))
microclean_cost = week2_microclean_fee * z_microclean

model.setObjective(production_cost + storage_cost_total + setup_cost_total + microclean_cost, GRB.MINIMIZE)

# Solve
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no optimal solution, but problem should be feasible
    print("FINAL_OBJ_VALUE: inf")
