import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read costs from table_1.csv
    children = []
    cost_budget = {}
    cost_balanced = {}
    cost_premium = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            child = row['Child'].strip()
            children.append(child)
            cost_budget[child] = float(row['Cost_budget'].strip())
            cost_balanced[child] = float(row['Cost_balanced'].strip())
            cost_premium[child] = float(row['Cost_premium'].strip())
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children = int(params['max_children'])
    min_children = int(params['min_children'])
    mandatory_ginny = int(params['mandatory_ginny'])
    harry_no_fred = int(params['harry_no_fred'])
    harry_no_george = int(params['harry_no_george'])
    george_requires_fred = int(params['george_requires_fred'])
    george_requires_hermione = int(params['george_requires_hermione'])
    fairness_penalty = float(params['fairness_penalty'])
    max_total_cost = float(params['max_total_cost'])
    min_children_per_mode = int(params['min_children_per_mode'])
    
    # Create model
    model = gp.Model("ZhangFamilyTrip_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[child] = 1 if child is selected
    x = model.addVars(children, vtype=GRB.BINARY, name="x")
    
    # Mode selection variables: one of budget, balanced, premium
    mode_budget = model.addVar(vtype=GRB.BINARY, name="mode_budget")
    mode_balanced = model.addVar(vtype=GRB.BINARY, name="mode_balanced")
    mode_premium = model.addVar(vtype=GRB.BINARY, name="mode_premium")
    
    # Exactly one mode must be selected
    model.addConstr(mode_budget + mode_balanced + mode_premium == 1, "one_mode")
    
    # Ginny must go
    model.addConstr(x['Ginny'] == 1, "Ginny_must_go")
    
    # Total number of children constraints
    total_children = model.addVar(vtype=GRB.INTEGER, name="total_children")
    model.addConstr(total_children == gp.quicksum(x[child] for child in children), "total_children_def")
    model.addConstr(total_children <= max_children, "Max_children")
    model.addConstr(total_children >= min_children, "Min_children_base")
    
    # For balanced or premium mode, require at least min_children_per_mode
    model.addConstr(total_children >= min_children_per_mode * (mode_balanced + mode_premium), "Min_children_mode")
    
    # Compatibility constraints
    if harry_no_fred:
        model.addConstr(x['Harry'] + x['Fred'] <= 1, "Harry_no_Fred")
    if harry_no_george:
        model.addConstr(x['Harry'] + x['George'] <= 1, "Harry_no_George")
    if george_requires_fred:
        model.addConstr(x['George'] <= x['Fred'], "George_requires_Fred")
    if george_requires_hermione:
        model.addConstr(x['George'] <= x['Hermione'], "George_requires_Hermione")
    
    # Cost calculation per mode
    cost_expr = gp.quicksum(
        cost_budget[child] * x[child] * mode_budget +
        cost_balanced[child] * x[child] * mode_balanced +
        cost_premium[child] * x[child] * mode_premium
        for child in children
    )
    
    # Fairness: spread between max and min cost among selected children
    # We need to compute the actual cost per child under the selected mode
    child_cost = {}
    for child in children:
        child_cost[child] = (
            cost_budget[child] * mode_budget +
            cost_balanced[child] * mode_balanced +
            cost_premium[child] * mode_premium
        )
    
    # Variables for min and max cost among selected children
    min_cost = model.addVar(vtype=GRB.CONTINUOUS, name="min_cost")
    max_cost = model.addVar(vtype=GRB.CONTINUOUS, name="max_cost")
    
    # Constraints for min_cost and max_cost
    M = 10000  # Big-M value, larger than any possible cost
    for child in children:
        # If child is selected, then min_cost <= child_cost[child]
        model.addConstr(min_cost <= child_cost[child] + M * (1 - x[child]), f"min_cost_{child}")
        # If child is selected, then max_cost >= child_cost[child]
        model.addConstr(max_cost >= child_cost[child] - M * (1 - x[child]), f"max_cost_{child}")
    
    # Also, min_cost should be at least the minimum possible cost (to avoid being too low when no child is selected, but Ginny is always selected)
    # Since Ginny is always selected, we can set a lower bound based on her costs
    min_possible = min(cost_budget['Ginny'], cost_balanced['Ginny'], cost_premium['Ginny'])
    max_possible = max(cost_budget['Ginny'], cost_balanced['Ginny'], cost_premium['Ginny'])
    model.addConstr(min_cost >= min_possible, "min_cost_lb")
    model.addConstr(max_cost <= max_possible + M * (1 - mode_budget) + M * (1 - mode_balanced) + M * (1 - mode_premium), "max_cost_ub")
    
    # However, the above big-M for max_cost_ub is not tight. Instead, we can use:
    # Since exactly one mode is selected, the child costs are fixed per mode.
    # But to keep it simple and correct, we rely on the fact that at least Ginny is selected.
    
    # The spread
    spread = model.addVar(vtype=GRB.CONTINUOUS, name="spread")
    model.addConstr(spread == max_cost - min_cost, "spread_def")
    
    # Total cost must be within max_total_cost
    model.addConstr(cost_expr <= max_total_cost, "max_total_cost_constraint")
    
    # Objective: minimize total cost + fairness_penalty * spread
    model.setObjective(cost_expr + fairness_penalty * spread, GRB.MINIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case no solution found, but problem should be feasible
        obj_val = float('inf')
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
