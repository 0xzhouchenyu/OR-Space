import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read property data
properties = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties.append({
            'name': row['Property'],
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_risky_multiplier = params['scen_1_risky_multiplier']
scen_2_risky_multiplier = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = int(params['max_risky_properties'])

# Create optimization model
model = gp.Model("RealEstateInvestment")
model.setParam('OutputFlag', 0)

# Decision variables
x = {}  # binary: whether to buy property
y = {}  # continuous: fraction of property allocated to risky tenants (0 <= y_i <= 1)
z = {}  # binary: whether property has any risky tenants (to count number of risky properties)

property_names = [p['name'] for p in properties]
for name in property_names:
    x[name] = model.addVar(vtype=GRB.BINARY, name=f"buy_{name}")
    y[name] = model.addVar(vtype=GRB.CONTINUOUS, lb=0.0, ub=1.0, name=f"risky_frac_{name}")
    z[name] = model.addVar(vtype=GRB.BINARY, name=f"has_risky_{name}")

# Objective: maximize expected annual income
# For each property:
#   dependable income = (1 - y_i) * base_income
#   risky income = y_i * base_income * [scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier]
expected_risky_multiplier = scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier

obj_expr = gp.quicksum(
    (1 - y[p['name']]) * p['income'] + y[p['name']] * p['income'] * expected_risky_multiplier
    for p in properties
)
model.setObjective(obj_expr, GRB.MAXIMIZE)

# Budget constraint: total cost of purchased properties <= budget
model.addConstr(gp.quicksum(p['cost'] * x[p['name']] for p in properties) <= budget)

# Exclusion constraint: if Property 4 is purchased, Property 3 cannot be purchased
model.addConstr(x['Property_4'] + x['Property_3'] <= 1)

# Risky allocation only allowed on purchased properties
for p in properties:
    name = p['name']
    model.addConstr(y[name] <= x[name])  # if not bought, y must be 0
    model.addConstr(y[name] <= per_property_risky_cap)  # per-property risky cap

# Link y and z: if y_i > 0 then z_i = 1; if y_i = 0 then z_i can be 0
# We use a big-M constraint: y_i <= M * z_i, with M = 1 (since y_i <= 1)
for p in properties:
    name = p['name']
    model.addConstr(y[name] <= z[name])

# Total risky exposure constraint: sum of costs of properties with any risky tenants <= total_risky_budget
model.addConstr(gp.quicksum(p['cost'] * z[p['name']] for p in properties) <= total_risky_budget)

# Maximum number of properties with risky tenants
model.addConstr(gp.quicksum(z[p['name']] for p in properties) <= max_risky_properties)

# Solve
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: 0")
