import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')

    # Read parameters
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']

    num_customers = int(params['num_customers'])
    max_trucks = int(params['max_trucks'])  # legacy, not used directly
    truck_capacity = float(params['truck_capacity'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])

    depot_str = params['depot_coordinates'].strip('()')
    if ',' in depot_str:
        depot_x, depot_y = map(float, depot_str.split(','))
    else:
        depot_x, depot_y = map(float, depot_str.split())

    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])

    # Read customer data
    coords = [(depot_x, depot_y)]
    demands_list = [0]
    tw_list = [(depot_tw_start, depot_tw_end)]
    svc_list = [0]
    outsource_cost_list = [0.0]
    mandatory_external_list = [0]

    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((float(row['Coordinates_X']), float(row['Coordinates_Y'])))
            demands_list.append(float(row['Demand']))
            tw_list.append((float(row['Time_Window_Start']), float(row['Time_Window_End'])))
            svc_list.append(float(row['Service_Duration']))
            outsource_cost_list.append(float(row['Outsource_Cost']))
            mandatory_external_list.append(int(row['Mandatory_External']))

    n = len(coords)  # total nodes including depot (0)
    N = list(range(1, n))  # customer indices
    V = list(range(n))     # all nodes including depot

    # Precompute distances
    dist = {}
    for i in V:
        for j in V:
            dist[i, j] = calculate_distance(coords[i], coords[j])

    # Identify customers that must be outsourced
    must_outsource = set()
    for i in N:
        if mandatory_external_list[i] == 1:
            must_outsource.add(i)

    # Build model
    model = gp.Model("VRPHTW_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[i,j] = 1 if arc (i,j) is used in the in-house routes
    x = {}
    for i in V:
        for j in V:
            if i != j:
                # Feasibility check for time windows
                feasible = True
                if i == 0 and j != 0:
                    if depot_tw_start + dist[i, j] > tw_list[j][1]:
                        feasible = False
                elif i != 0 and j == 0:
                    if tw_list[i][0] + svc_list[i] + dist[i, j] > depot_tw_end:
                        feasible = False
                elif i != 0 and j != 0:
                    if tw_list[i][0] + svc_list[i] + dist[i, j] > tw_list[j][1]:
                        feasible = False
                if feasible and i not in must_outsource and j not in must_outsource:
                    x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")

    # y[i] = 1 if customer i is served by in-house truck, 0 if outsourced
    y = {}
    for i in N:
        if i in must_outsource:
            y[i] = model.addVar(vtype=GRB.BINARY, lb=0, ub=0, name=f"y_{i}")
        else:
            y[i] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}")

    # t[i] = arrival time at node i
    t = {}
    for i in V:
        if i == 0:
            t[i] = model.addVar(lb=depot_tw_start, ub=depot_tw_end, name=f"t_{i}")
        else:
            t[i] = model.addVar(lb=tw_list[i][0], ub=tw_list[i][1], name=f"t_{i}")

    # Objective: minimize total in-house distance + outsourcing cost
    inhouse_distance = gp.quicksum(dist[i, j] * x[i, j] for (i, j) in x)
    outsourcing_cost = gp.quicksum(outsource_cost_list[i] * (1 - y[i]) for i in N)
    model.setObjective(inhouse_distance + outsourcing_cost, GRB.MINIMIZE)

    # Constraints
    # 1. Fleet size limit
    model.addConstr(gp.quicksum(x[0, j] for j in N if (0, j) in x) <= inhouse_truck_limit, "FleetLimit")

    # 2. Flow conservation and service assignment
    for i in N:
        if i in must_outsource:
            continue
        # If served in-house, exactly one incoming and one outgoing arc
        incoming = gp.quicksum(x[j, i] for j in V if (j, i) in x)
        outgoing = gp.quicksum(x[i, j] for j in V if (i, j) in x)
        model.addConstr(incoming == y[i], f"Incoming_{i}")
        model.addConstr(outgoing == y[i], f"Outgoing_{i}")

    # 3. Time window constraints with big-M
    M = depot_tw_end + max(svc_list) + max(dist.values())
    for (i, j) in x:
        if j != 0:
            model.addConstr(t[i] + svc_list[i] + dist[i, j] - t[j] <= M * (1 - x[i, j]), f"Time_{i}_{j}")

    # 4. Capacity constraints: use MTZ-like or aggregate?
    # We'll use a standard capacity constraint via flow variables
    # Introduce load variables
    u = {}
    for i in N:
        if i not in must_outsource:
            u[i] = model.addVar(lb=demands_list[i], ub=truck_capacity, name=f"u_{i}")

    for (i, j) in x:
        if i != 0 and j != 0:
            model.addConstr(u[i] + demands_list[j] <= u[j] + truck_capacity * (1 - x[i, j]), f"Capacity_{i}_{j}")
        elif i == 0 and j != 0:
            model.addConstr(demands_list[j] <= u[j], f"CapacityStart_{j}")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL or model.status == GRB.TIME_LIMIT:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val:.2f}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
