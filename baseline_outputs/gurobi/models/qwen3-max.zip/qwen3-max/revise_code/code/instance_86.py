import os
import csv
from utils import load_csv_data
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load data
    products = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params_raw = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Parse general parameters
    params = {}
    for row in params_raw:
        params[row['Parameter_Name']] = float(row['Value'])
    
    max_grains = params['max_grains']
    price_grains = params['price_per_lb_grains']
    max_meat = params['max_meat']
    price_meat = params['price_per_lb_meat']
    line_fixed_cost = params['line_fixed_cost']
    line_capacity_packs = params['line_capacity_packs']
    min_batch_packs = params['min_batch_packs']
    min_yummies = params['min_yummies']
    retailer_rebate_yummies_threshold = params['retailer_rebate_yummies_threshold']
    retailer_rebate_min_meaties = params['retailer_rebate_min_meaties']
    retailer_rebate_fixed = params['retailer_rebate_fixed']
    
    # Parse product data
    product_data = {}
    for row in products:
        name = row['Product']
        product_data[name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'variable_cost': float(row['Variable_cost_per_pack']),
            'capacity': float(row['Production_capacity']) if row['Production_capacity'].strip() else None
        }
    
    m = product_data['Meaties']
    y = product_data['Yummies']
    
    # Create a new model
    model = gp.Model("HealthyPetFoods_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of packs produced
    x_meaties = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="Meaties")
    x_yummies = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="Yummies")
    
    # Binary variable for whether the co-packing line is used
    z_line = model.addVar(vtype=GRB.BINARY, name="LineUsed")
    
    # Binary variable for whether the rebate conditions are met
    w_rebate = model.addVar(vtype=GRB.BINARY, name="RebateEligible")
    
    # Profit per pack = selling price - variable cost - raw material cost per pack
    profit_meaties = m['price'] - m['variable_cost'] - (m['grains'] * price_grains + m['meat'] * price_meat)
    profit_yummies = y['price'] - y['variable_cost'] - (y['grains'] * price_grains + y['meat'] * price_meat)
    
    # Objective: maximize total profit = revenue from products - line fixed cost + rebate (if eligible)
    model.setObjective(
        profit_meaties * x_meaties + profit_yummies * x_yummies 
        - line_fixed_cost * z_line 
        + retailer_rebate_fixed * w_rebate,
        GRB.MAXIMIZE
    )
    
    # Constraints
    
    # Grains availability
    model.addConstr(m['grains'] * x_meaties + y['grains'] * x_yummies <= max_grains, "Grains_Constraint")
    
    # Meat availability
    model.addConstr(m['meat'] * x_meaties + y['meat'] * x_yummies <= max_meat, "Meat_Constraint")
    
    # Production capacity for Meaties
    if m['capacity'] is not None:
        model.addConstr(x_meaties <= m['capacity'], "Meaties_Capacity")
    
    # Co-packing line constraints
    # Total production cannot exceed line capacity if line is used; if not used, production must be zero.
    model.addConstr(x_meaties + x_yummies <= line_capacity_packs * z_line, "LineCapacity")
    
    # Minimum batch size if line is used
    model.addConstr(x_meaties + x_yummies >= min_batch_packs * z_line, "MinBatch")
    
    # Minimum Yummies production if line is used
    model.addConstr(x_yummies >= min_yummies * z_line, "MinYummies")
    
    # Rebate eligibility: w_rebate can be 1 only if both thresholds are met
    # We use big-M constraints to link w_rebate to the production levels.
    M1 = 1e6  # Big enough for Meaties (max possible is 90000)
    M2 = 1e6  # Big enough for Yummies (max possible is around 133333 from grains constraint)
    
    # If w_rebate = 1, then x_meaties >= retailer_rebate_min_meaties
    model.addConstr(x_meaties >= retailer_rebate_min_meaties - M1 * (1 - w_rebate), "RebateMeaties")
    
    # If w_rebate = 1, then x_yummies >= retailer_rebate_yummies_threshold
    model.addConstr(x_yummies >= retailer_rebate_yummies_threshold - M2 * (1 - w_rebate), "RebateYummies")
    
    # Additionally, if either threshold is not met, w_rebate must be 0.
    # We enforce this by ensuring that if x_meaties < retailer_rebate_min_meaties, then w_rebate=0.
    # Similarly for x_yummies.
    # We use two more constraints with big-M.
    model.addConstr(x_meaties <= retailer_rebate_min_meaties + M1 * w_rebate, "RebateMeatiesUpper")
    model.addConstr(x_yummies <= retailer_rebate_yummies_threshold + M2 * w_rebate, "RebateYummiesUpper")
    
    # However, note: the above two upper constraints are not standard. Actually, the standard way is:
    # To force w_rebate=0 when x_meaties < threshold, we can do:
    #   x_meaties <= (retailer_rebate_min_meaties - epsilon) + M1 * w_rebate
    # But since we are in continuous, we can avoid epsilon by using the following two constraints for each condition?
    # Actually, the common approach is to use:
    #   x_meaties >= retailer_rebate_min_meaties * w_rebate
    #   x_yummies >= retailer_rebate_yummies_threshold * w_rebate
    # But that would force x_meaties to be at least the threshold when w_rebate=1, but when w_rebate=0, it forces x_meaties>=0 (which is already true).
    # However, that does not prevent w_rebate=1 when the thresholds are not met? Actually, no: because if w_rebate=1, then x_meaties must be >= threshold, so if the solution has x_meaties < threshold, then w_rebate cannot be 1.
    # But we also need to ensure that if both thresholds are met, w_rebate can be 1 (and we want it to be 1 because it adds profit). So we don't need an upper bound on w_rebate from the production variables? The objective will push w_rebate to 1 if possible.
    #
    # Let's change to the simpler and standard formulation:
    #   x_meaties >= retailer_rebate_min_meaties * w_rebate
    #   x_yummies >= retailer_rebate_yummies_threshold * w_rebate
    #
    # This ensures that if w_rebate=1, then both thresholds are met. And if both thresholds are met, then w_rebate can be set to 1 (and the objective will choose 1 because it adds profit).
    #
    # So we replace the four constraints above with these two.
    
    # Remove the previous four rebate constraints and add these two:
    model.remove(model.getConstrByName("RebateMeaties"))
    model.remove(model.getConstrByName("RebateYummies"))
    model.remove(model.getConstrByName("RebateMeatiesUpper"))
    model.remove(model.getConstrByName("RebateYummiesUpper"))
    
    model.addConstr(x_meaties >= retailer_rebate_min_meaties * w_rebate, "RebateMeaties")
    model.addConstr(x_yummies >= retailer_rebate_yummies_threshold * w_rebate, "RebateYummies")
    
    # Now, solve the model
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case of no solution, but the problem should be feasible
        obj_val = 0.0
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
