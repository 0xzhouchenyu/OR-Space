import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_distances(data_dir):
    """Load distance data from table_1.csv"""
    filepath = os.path.join(data_dir, 'table_1.csv')
    distances = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            yard = row['Coal_Yard'].strip()
            area = int(row['Residential_Area'].strip())
            dist = float(row['Distance_km'].strip())
            distances[(yard, area)] = dist
    return distances

def load_parameters(data_dir):
    """Load general parameters from general_parameters.csv"""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Set up data directory
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Load data
distances = load_distances(data_dir)
params = load_parameters(data_dir)

# Extract parameters
min_supply = {
    'A': params['min_coal_yard_A'],
    'B': params['min_coal_yard_B_adjusted']
}

demand = {
    1: params['residential_area_1_demand'],
    2: params['residential_area_2_demand'],
    3: params['residential_area_3_demand']
}

min_share_area3_from_A = params['min_share_area3_from_A']
area3_A_staging_threshold = params['area3_A_staging_threshold']
area3_A_excess_staging_cost = params['area3_A_excess_staging_cost']

coal_yards = ['A', 'B']
areas = [1, 2, 3]

# Create the model
model = gp.Model("Coal_Distribution_Revised")
model.setParam('OutputFlag', 0)

# Decision variables: amount of coal shipped from yard i to area j
x = {}
for yard in coal_yards:
    for area in areas:
        # Note: For (B,3), distance is missing in table_1.csv, so we assume it's not allowed (infinite cost)
        # But since demand must be met, and min_share_area3_from_A requires A to supply at least some to area 3,
        # we need to check if B->3 is allowed. The original table_1.csv had B,3,15 but revised doesn't.
        # Since it's missing, we assume B cannot supply to area 3.
        if yard == 'B' and area == 3:
            # Skip creating variable for B->3 since it's not in the distance table
            continue
        x[(yard, area)] = model.addVar(lb=0, name=f"x_{yard}_{area}")

# For area 3, we need to handle the excess cost for A->3 above 40 tons.
# We'll split x[('A',3)] into two parts: normal and excess.
# But note: the problem says "any A-to-Area-3 tonnage above 40 tons carries an extra handling cost of 3 per ton"
# So total cost for A->3 = 6 * x_A3 + 3 * max(0, x_A3 - 40)
# To model this linearly, we introduce an auxiliary variable for the excess.

x_A3 = x[('A', 3)]
excess_A3 = model.addVar(lb=0, name="excess_A3")

# Constraint: excess_A3 >= x_A3 - 40
model.addConstr(excess_A3 >= x_A3 - area3_A_staging_threshold, "excess_A3_constraint")

# Objective: minimize total transportation cost plus excess handling cost
obj_expr = gp.LinExpr()

# Add transportation costs for all existing routes
for (yard, area), var in x.items():
    if (yard, area) in distances:
        obj_expr += distances[(yard, area)] * var
    else:
        # This should not happen because we skipped B->3, but just in case
        pass

# Add excess handling cost for A->3
obj_expr += area3_A_excess_staging_cost * excess_A3

model.setObjective(obj_expr, GRB.MINIMIZE)

# Constraints:
# 1. Each coal yard must supply at least its minimum requirement
for yard in coal_yards:
    supply_expr = gp.LinExpr()
    for area in areas:
        if (yard, area) in x:
            supply_expr += x[(yard, area)]
    model.addConstr(supply_expr >= min_supply[yard], f"Min_Supply_{yard}")

# 2. Each residential area must receive exactly its demand
for area in areas:
    demand_expr = gp.LinExpr()
    for yard in coal_yards:
        if (yard, area) in x:
            demand_expr += x[(yard, area)]
    model.addConstr(demand_expr == demand[area], f"Demand_{area}")

# 3. Minimum share of residential area 3 demand that must be supplied by coal yard A
model.addConstr(x[('A', 3)] >= min_share_area3_from_A * demand[3], "Min_Share_Area3_From_A")

# Optimize
model.optimize()

# Print the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, but the problem should be feasible
    print("FINAL_OBJ_VALUE: None")
