import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']
T1_normal = params['available_time_process_1']
T2_normal = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']
c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
bigM_disposal = params['bigM_disposal']
disposal_cost_base = params['disposal_cost_per_unit_c']
disposal_cost_high = params['disposal_cost_per_unit_c_high']
profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

# Create the model
model = gp.Model("MaxProfit_Revised")

# Decision variables
xA = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="xA")
xB = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="xB")
cSold = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="cSold")
cDisposed = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="cDisposed")

# Binary variables for high-throughput mode: y1 for process 1, y2 for process 2
y1 = model.addVar(vtype=GRB.BINARY, name="y1")
y2 = model.addVar(vtype=GRB.BINARY, name="y2")

# Binary variable for disposal cost regime: z = 1 if cDisposed > threshold_c
z = model.addVar(vtype=GRB.BINARY, name="z")

# Constraint: at most one reaction stage may use high-throughput setting
model.addConstr(y1 + y2 <= 1, "AtMostOneHighThroughput")

# Process 1 time constraint: if y1=0, use T1_normal; if y1=1, use T1_high
model.addConstr(a_p1 * xA + b_p1 * xB <= T1_normal + (T1_high - T1_normal) * y1, "Process1Time")

# Process 2 time constraint: if y2=0, use T2_normal; if y2=1, use T2_high
model.addConstr(a_p2 * xA + b_p2 * xB <= T2_normal + (T2_high - T2_normal) * y2, "Process2Time")

# By-product C balance
model.addConstr(cSold + cDisposed == c_per_b * xB, "ByproductBalance")

# Maximum C that can be sold
model.addConstr(cSold <= max_c_sales, "MaxCSales")

# Disposal cost piecewise linearization using binary variable z
# If z=0, then cDisposed <= threshold_c; if z=1, then cDisposed >= threshold_c (but we don't need lower bound strictly)
model.addConstr(cDisposed <= threshold_c + bigM_disposal * z, "DisposalThresholdUpper")
# Note: We don't need a lower bound constraint for z because the objective will naturally set z=0 when possible.

# Objective: maximize total profit
# Profit from A + Profit from B + Profit from selling C - Disposal cost
# Disposal cost = base_cost * min(cDisposed, threshold_c) + high_cost * max(0, cDisposed - threshold_c)
# We express this as: base_cost * cDisposed + (high_cost - base_cost) * (cDisposed - threshold_c)^+
# But using z, we can write the cost as:
#   base_cost * cDisposed + (high_cost - base_cost) * w, where w >= cDisposed - threshold_c and w >= 0, and w <= bigM_disposal * z
# However, an easier way is to split cDisposed into two parts: cDisposed_low and cDisposed_high
# But the problem says to use the given bigM and threshold, so we introduce an auxiliary variable for the high-cost portion.

cDisposed_high = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="cDisposed_high")
model.addConstr(cDisposed_high >= cDisposed - threshold_c, "HighDisposalLower")
model.addConstr(cDisposed_high <= bigM_disposal * z, "HighDisposalUpper")
model.addConstr(cDisposed_high >= 0, "HighDisposalNonNeg")

# Total disposal cost = disposal_cost_base * (cDisposed - cDisposed_high) + disposal_cost_high * cDisposed_high
# But note: (cDisposed - cDisposed_high) is the amount disposed at base cost, which should be <= threshold_c.
# However, the above constraints ensure that cDisposed_high = max(0, cDisposed - threshold_c) at optimality.

# Objective
obj = profit_a * xA + profit_b * xB + profit_c * cSold - (disposal_cost_base * (cDisposed - cDisposed_high) + disposal_cost_high * cDisposed_high)
model.setObjective(obj, GRB.MAXIMIZE)

# Set solver parameters
model.setParam('OutputFlag', 0)

# Optimize
model.optimize()

# Output the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no optimal solution, output 0 or handle appropriately
    print("FINAL_OBJ_VALUE: 0")
