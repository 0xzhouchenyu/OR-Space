import os
import re
import csv
import gurobipy as gp
from gurobipy import GRB

def get_data_dir():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def main():
    data_dir = get_data_dir()
    
    # Read general parameters
    num_customers = 7
    start_location = 1
    end_location = 1
    max_route_length_day = 1000
    route_cost_day = 20
    
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'num_customers':
                num_customers = int(row['Value'])
            elif row['Parameter_Name'] == 'start_location':
                start_location = int(row['Value'])
            elif row['Parameter_Name'] == 'end_location':
                end_location = int(row['Value'])
            elif row['Parameter_Name'] == 'max_route_length_day':
                max_route_length_day = float(row['Value'])
            elif row['Parameter_Name'] == 'route_cost_day':
                route_cost_day = float(row['Value'])
    
    # Read distance matrix
    D = [[0] * num_customers for _ in range(num_customers)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:
            nums = re.findall(r'\d+', line)
            if not nums:
                continue
            row_idx = int(nums[0]) - 1
            for j, val in enumerate(nums[1:]):
                col_idx = row_idx + 1 + j
                if col_idx < num_customers:
                    D[row_idx][col_idx] = int(val)
                    D[col_idx][row_idx] = int(val)
    
    # Ensure diagonal is zero
    for i in range(num_customers):
        D[i][i] = 0
    
    # Create model
    model = gp.Model("TwoDayTSP")
    model.setParam('OutputFlag', 0)
    
    # Sets
    n = num_customers
    depot = 0  # location 1 is index 0
    customers = list(range(1, n))  # indices 1 to 6 for locations 2 to 7
    days = [0, 1]  # day 0 and day 1 (representing day 1 and day 2)
    
    # Decision variables
    # x[i,j,d] = 1 if arc (i,j) is used on day d
    x = {}
    for d in days:
        for i in range(n):
            for j in range(n):
                if i != j:
                    x[i, j, d] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}_{d}")
    
    # y[i,d] = 1 if customer i is assigned to day d (for i in customers)
    y = {}
    for i in customers:
        for d in days:
            y[i, d] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{d}")
    
    # z[d] = 1 if day d is used (i.e., at least one customer assigned)
    z = {}
    for d in days:
        z[d] = model.addVar(vtype=GRB.BINARY, name=f"z_{d}")
    
    # u[i,d] for MTZ subtour elimination (for customers only, per day)
    u = {}
    for d in days:
        for i in customers:
            u[i, d] = model.addVar(vtype=GRB.CONTINUOUS, lb=1, ub=n-1, name=f"u_{i}_{d}")
    
    # Objective: minimize total distance + fixed cost for each used day
    obj = gp.quicksum(D[i][j] * x[i, j, d] for d in days for i in range(n) for j in range(n) if i != j) + \
          gp.quicksum(route_cost_day * z[d] for d in days)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Each customer must be assigned to exactly one day
    for i in customers:
        model.addConstr(gp.quicksum(y[i, d] for d in days) == 1, name=f"assign_{i}")
    
    # Link y and z: if a customer is assigned to day d, then z[d] must be 1
    for d in days:
        for i in customers:
            model.addConstr(y[i, d] <= z[d], name=f"link_yz_{i}_{d}")
    
    # Flow conservation for each day
    for d in days:
        # Out of depot: sum of outgoing arcs from depot equals z[d] (if day used, must leave depot once)
        model.addConstr(gp.quicksum(x[depot, j, d] for j in range(n) if j != depot) == z[d], name=f"out_depot_{d}")
        # Into depot: sum of incoming arcs to depot equals z[d]
        model.addConstr(gp.quicksum(x[i, depot, d] for i in range(n) if i != depot) == z[d], name=f"in_depot_{d}")
        
        # For each customer i: if assigned to day d, then exactly one incoming and one outgoing arc
        for i in customers:
            model.addConstr(gp.quicksum(x[i, j, d] for j in range(n) if j != i) == y[i, d], name=f"out_customer_{i}_{d}")
            model.addConstr(gp.quicksum(x[j, i, d] for j in range(n) if j != i) == y[i, d], name=f"in_customer_{i}_{d}")
    
    # Subtour elimination (MTZ) for each day
    for d in days:
        for i in customers:
            for j in customers:
                if i != j:
                    model.addConstr(u[i, d] - u[j, d] + (n - 1) * x[i, j, d] <= n - 2, name=f"mtz_{i}_{j}_{d}")
    
    # Daily route length constraint
    for d in days:
        total_distance = gp.quicksum(D[i][j] * x[i, j, d] for i in range(n) for j in range(n) if i != j)
        model.addConstr(total_distance <= max_route_length_day * z[d], name=f"max_route_{d}")
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_value = model.objVal
    else:
        # In case no solution found, but problem should be feasible
        obj_value = float('inf')
    
    print(f"FINAL_OBJ_VALUE: {obj_value}")

if __name__ == "__main__":
    main()
