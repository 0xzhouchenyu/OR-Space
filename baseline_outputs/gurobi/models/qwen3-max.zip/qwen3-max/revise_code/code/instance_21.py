import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Parse general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    cost_a = params['cost_supplier_a']       # 120 USD per table
    cost_b = params['cost_supplier_b']       # 110 USD per table
    cost_c = params['cost_supplier_c']       # 100 USD per table
    size_a = int(params['order_size_supplier_a'])  # 20 tables per order
    size_b = int(params['order_size_supplier_b'])  # 15 tables per order
    size_c = int(params['order_size_supplier_c'])  # 15 tables per order
    min_tables = int(params['min_tables_required'])  # 150
    max_tables = int(params['max_tables_allowed'])   # 600
    min_b_if_a = int(params['min_tables_supplier_b_if_a'])  # 30 tables from B if A is used
    b_requires_c = bool(int(params['supplier_b_requires_c']))      # 1 (boolean)
    max_free_orders_c = int(params['max_free_orders_c'])  # 5 free orders from C
    penalty_per_extra_order_c = params['penalty_per_extra_order_c']  # 600 USD per extra order
    supplier_bc_shared_inbound_trigger = bool(int(params['supplier_bc_shared_inbound_trigger']))  # True
    supplier_bc_shared_inbound_fee = params['supplier_bc_shared_inbound_fee']  # 1000 USD
    
    # Create model
    model = gp.Model("Restaurant_Tables")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of orders from each supplier (integer >= 0)
    x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_a")
    x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_b")
    x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="orders_c")
    
    # Binary variables for conditional constraints
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")  # 1 if ordering from A
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")  # 1 if ordering from B
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")  # 1 if ordering from C
    
    # For the shared inbound fee: binary variable indicating if both B and C are used
    y_bc = model.addVar(vtype=GRB.BINARY, name="y_bc")
    
    # For penalty on extra orders from C beyond free limit
    extra_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="extra_c")
    
    # Objective: minimize total cost
    base_cost = cost_a * size_a * x_a + cost_b * size_b * x_b + cost_c * size_c * x_c
    penalty_cost = penalty_per_extra_order_c * extra_c
    shared_inbound_cost = supplier_bc_shared_inbound_fee * y_bc
    model.setObjective(base_cost + penalty_cost + shared_inbound_cost, GRB.MINIMIZE)
    
    # Total tables constraints
    total_tables = size_a * x_a + size_b * x_b + size_c * x_c
    model.addConstr(total_tables >= min_tables, "min_tables")
    model.addConstr(total_tables <= max_tables, "max_tables")
    
    # Link binary variables to order variables
    M = 1000  # Big-M (sufficiently large given max_tables=600 and min order size=15 -> max orders ~40)
    model.addConstr(x_a <= M * y_a, "link_xa_ya")
    model.addConstr(x_a >= y_a, "link_xa_ya_lower")
    model.addConstr(x_b <= M * y_b, "link_xb_yb")
    model.addConstr(x_b >= y_b, "link_xb_yb_lower")
    model.addConstr(x_c <= M * y_c, "link_xc_yc")
    model.addConstr(x_c >= y_c, "link_xc_yc_lower")
    
    # If ordering from A, then tables from B >= 30
    model.addConstr(size_b * x_b >= min_b_if_a * y_a, "min_b_if_a")
    
    # If ordering from B, must order from C
    if b_requires_c:
        model.addConstr(y_c >= y_b, "b_requires_c")
    
    # Shared inbound desk: if both B and C are used, then y_bc = 1
    if supplier_bc_shared_inbound_trigger:
        model.addConstr(y_bc >= y_b + y_c - 1, "y_bc_lower")
        model.addConstr(y_bc <= y_b, "y_bc_upper1")
        model.addConstr(y_bc <= y_c, "y_bc_upper2")
    
    # Penalty for extra orders from C beyond free limit
    model.addConstr(extra_c >= x_c - max_free_orders_c, "extra_c_def")
    model.addConstr(extra_c >= 0, "extra_c_nonneg")
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # In case no solution found, but problem should be feasible
        print("FINAL_OBJ_VALUE: inf")

if __name__ == "__main__":
    main()
