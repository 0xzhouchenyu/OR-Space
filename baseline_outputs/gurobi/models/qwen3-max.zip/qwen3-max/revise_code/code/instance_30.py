import os
import csv
from gurobipy import Model, GRB

def load_feed_data(filepath):
    feeds = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            feed = {
                'Feed': int(row['Feed']),
                'Protein_g': float(row['Protein_g']),
                'Minerals_g': float(row['Minerals_g']),
                'Vitamins_mg': float(row['Vitamins_mg']),
                'Price_Y_per_kg': float(row['Price_Y_per_kg']),
            }
            feeds.append(feed)
    return feeds

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

# Construct paths
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")

# Load data
feeds = load_feed_data(os.path.join(data_dir, 'table_1.csv'))
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

min_protein = params['min_protein_requirement']
min_minerals = params['min_minerals_requirement']
min_vitamins = params['min_vitamins_requirement']

# Create model
model = Model("MinimizeFeedCost")
model.setParam('OutputFlag', 0)

# Decision variables: amount of each feed (kg), non-negative
x = {}
for f in feeds:
    feed_id = f['Feed']
    x[feed_id] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{feed_id}")

# Binary variables to enforce mutual exclusion between Feed 4 and Feed 5
y4 = model.addVar(vtype=GRB.BINARY, name="y4")
y5 = model.addVar(vtype=GRB.BINARY, name="y5")

# Link continuous variables to binary variables with a big-M constraint
M = 1e6  # sufficiently large number
model.addConstr(x[4] <= M * y4, "link_x4_y4")
model.addConstr(x[5] <= M * y5, "link_x5_y5")
model.addConstr(y4 + y5 <= 1, "mutual_exclusion")

# Objective: minimize total cost
model.setObjective(sum(f['Price_Y_per_kg'] * x[f['Feed']] for f in feeds), GRB.MINIMIZE)

# Constraints
# Protein constraint
model.addConstr(sum(f['Protein_g'] * x[f['Feed']] for f in feeds) >= min_protein, "ProteinRequirement")

# Minerals constraint
model.addConstr(sum(f['Minerals_g'] * x[f['Feed']] for f in feeds) >= min_minerals, "MineralsRequirement")

# Vitamins constraint
model.addConstr(sum(f['Vitamins_mg'] * x[f['Feed']] for f in feeds) >= min_vitamins, "VitaminsRequirement")

# Optimize
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case no optimal solution is found, output a large number or handle accordingly
    print("FINAL_OBJ_VALUE: inf")
