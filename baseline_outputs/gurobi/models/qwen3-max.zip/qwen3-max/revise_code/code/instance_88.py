import os
import csv
from utils import load_general_parameters
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract original parameters
m1_liquid = params['machine_1_time_per_liquid_lot']  # 50 min per lot
m2_liquid = params['machine_2_time_per_liquid_lot']  # 30 min per lot
m1_solid = params['machine_1_time_per_solid_lot']    # 24 min per lot
m2_solid = params['machine_2_time_per_solid_lot']    # 33 min per lot

init_liquid = params['initial_liquid_inventory']  # 30 lots
init_solid = params['initial_solid_inventory']    # 90 lots

m1_avail_base = params['machine_1_available_time'] * 60  # 40 hours -> 2400 minutes
m2_avail_base = params['machine_2_available_time'] * 60  # 35 hours -> 2100 minutes

demand_liquid = params['forecast_liquid_demand']  # 75 lots
demand_solid = params['forecast_solid_demand']    # 95 lots

# New parameters from revision
extended_extra_minutes = params['extended_extra_minutes']  # 600 minutes
labor_hours_per_machine_extended = params['labor_hours_per_machine_extended']  # 8 hours
labor_budget_hours = params['labor_budget_hours']  # 10 hours
extended_mode_penalty = params['extended_mode_penalty']  # 0.5 score per extended machine
priority_reserve_lots = params['priority_reserve_lots']  # 10 lots
excess_reserve_credit = params['excess_reserve_credit']  # 0.35 score/lot

# Decision variables:
# x_l = lots of liquid fertilizer produced
# x_s = lots of solid fertilizer produced
# y1 = binary variable: 1 if Machine 1 is extended, 0 otherwise
# y2 = binary variable: 1 if Machine 2 is extended, 0 otherwise

model = gp.Model("Revised_Fertilizer_Production")
model.setParam('OutputFlag', 0)

x_l = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="x_liquid")
x_s = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="x_solid")
y1 = model.addVar(vtype=GRB.BINARY, name="machine1_extended")
y2 = model.addVar(vtype=GRB.BINARY, name="machine2_extended")

# Ending inventories
end_liquid = init_liquid + x_l - demand_liquid
end_solid = init_solid + x_s - demand_solid

# Constraints: ending inventory must be non-negative (to satisfy demand)
model.addConstr(end_liquid >= 0, "Liquid_Demand_Satisfaction")
model.addConstr(end_solid >= 0, "Solid_Demand_Satisfaction")

# Machine capacity constraints with extension option
# Machine 1: base time + extra if extended
model.addConstr(m1_liquid * x_l + m1_solid * x_s <= m1_avail_base + extended_extra_minutes * y1, "Machine1_Capacity")
# Machine 2: base time + extra if extended
model.addConstr(m2_liquid * x_l + m2_solid * x_s <= m2_avail_base + extended_extra_minutes * y2, "Machine2_Capacity")

# Skilled labor constraint: total labor for extended machines <= labor budget
model.addConstr(labor_hours_per_machine_extended * (y1 + y2) <= labor_budget_hours, "Labor_Budget")

# Resilience score calculation
# For each product, the first `priority_reserve_lots` count fully (score = 1 per lot),
# and inventory above that counts at `excess_reserve_credit` per lot.

# Liquid resilience score
liquid_priority = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="liquid_priority")
liquid_excess = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="liquid_excess")
model.addConstr(liquid_priority + liquid_excess == end_liquid, "Liquid_Inventory_Split")
model.addConstr(liquid_priority <= priority_reserve_lots, "Liquid_Priority_Cap")

# Solid resilience score
solid_priority = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="solid_priority")
solid_excess = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="solid_excess")
model.addConstr(solid_priority + solid_excess == end_solid, "Solid_Inventory_Split")
model.addConstr(solid_priority <= priority_reserve_lots, "Solid_Priority_Cap")

# Total resilience score = 
#   (liquid_priority * 1 + liquid_excess * excess_reserve_credit) +
#   (solid_priority * 1 + solid_excess * excess_reserve_credit) -
#   (extended_mode_penalty * (y1 + y2))

resilience_score = (liquid_priority + excess_reserve_credit * liquid_excess +
                    solid_priority + excess_reserve_credit * solid_excess -
                    extended_mode_penalty * (y1 + y2))

# Objective: maximize resilience score
model.setObjective(resilience_score, GRB.MAXIMIZE)

# Optimize
model.optimize()

# Output the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal:.6f}")
else:
    # In case of no optimal solution, output 0 or handle as needed
    print("FINAL_OBJ_VALUE: 0.000000")
