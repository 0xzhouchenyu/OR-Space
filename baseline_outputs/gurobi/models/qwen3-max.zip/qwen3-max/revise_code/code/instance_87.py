import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    base_fleet_a = params['base_fleet_type_a']
    base_fleet_b = params['base_fleet_type_b']
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    type_b_threshold = params['type_b_recovery_threshold']
    type_b_fee = params['type_b_recovery_fee']
    total_fleet_threshold = params['total_fleet_surge_threshold']
    total_fleet_fee = params['total_fleet_surge_fee']
    
    # Create the optimization model
    model = gp.Model("TruckRental_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables (integer, non-negative)
    x = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeA_trucks")
    y = model.addVar(vtype=GRB.INTEGER, lb=0, name="TypeB_trucks")
    
    # Binary variables for the fixed fees
    z1 = model.addVar(vtype=GRB.BINARY, name="exceeds_type_b_threshold")
    z2 = model.addVar(vtype=GRB.BINARY, name="exceeds_total_fleet_threshold")
    
    # Objective: minimize total cost including penalties and fixed fees
    base_cost = cost_a * x + cost_b * y
    penalty_cost = penalty_a * gp.max_(x - base_fleet_a, 0) + penalty_b * gp.max_(y - base_fleet_b, 0)
    fixed_fees = type_b_fee * z1 + total_fleet_fee * z2
    model.setObjective(base_cost + penalty_cost + fixed_fees, GRB.MINIMIZE)
    
    # Constraints for cargo requirements
    model.addConstr(rc_a * x + rc_b * y >= ref_req, "RefrigeratedRequirement")
    model.addConstr(nc_a * x + nc_b * y >= nonref_req, "NonRefrigeratedRequirement")
    
    # Constraints for the binary variable z1 (Type B threshold)
    model.addConstr(y <= type_b_threshold + (1 - z1) * (ref_req + nonref_req), "TypeBThreshold1")
    model.addConstr(y >= type_b_threshold + 1 - (ref_req + nonref_req) * z1, "TypeBThreshold2")
    
    # Constraints for the binary variable z2 (Total fleet threshold)
    total_trucks = x + y
    M_total = ref_req + nonref_req  # A big number
    model.addConstr(total_trucks <= total_fleet_threshold + (1 - z2) * M_total, "TotalFleetThreshold1")
    model.addConstr(total_trucks >= total_fleet_threshold + 1 - M_total * z2, "TotalFleetThreshold2")
    
    # Since gp.max_ is not directly available in Gurobi for linear models, we linearize the penalty terms.
    # We introduce auxiliary variables for the excesses.
    excess_a = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="excess_a")
    excess_b = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="excess_b")
    
    model.addConstr(excess_a >= x - base_fleet_a, "excess_a_def")
    model.addConstr(excess_a >= 0, "excess_a_nonneg")
    model.addConstr(excess_b >= y - base_fleet_b, "excess_b_def")
    model.addConstr(excess_b >= 0, "excess_b_nonneg")
    
    # Update the objective to use the auxiliary variables
    model.setObjective(cost_a * x + cost_b * y + penalty_a * excess_a + penalty_b * excess_b + type_b_fee * z1 + total_fleet_fee * z2, GRB.MINIMIZE)
    
    # Optimize the model
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # In case of no optimal solution, we try to get the best bound or raise an error.
        # But per problem statement, we assume feasible.
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
