import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read table_1.csv
toys = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        toys.append({
            'type': row['Toy_Type'],
            'labor': float(row['Manufacturing_Labor_Hours']),
            'inspection': float(row['Inspection_Hours']),
            'profit': float(row['Profit_Per_Unit'])
        })

# Read general_parameters.csv
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Period-specific parameters
available_labor_p1 = params['available_labor_hours_period1']
available_labor_p2 = params['available_labor_hours_period2']
available_inspection_p1 = params['available_inspection_hours_period1']
available_inspection_p2 = params['available_inspection_hours_period2']

max_demand_p1 = {
    'High-End': params['max_demand_high_end_period1'],
    'Mid-Range': params['max_demand_mid_range_period1'],
    'Low-End': params['max_demand_low_end_period1']
}
max_demand_p2 = {
    'High-End': params['max_demand_high_end_period2'],
    'Mid-Range': params['max_demand_mid_range_period2'],
    'Low-End': params['max_demand_low_end_period2']
}

overtime_labor_cap = params['overtime_labor_cap']
overtime_labor_cost = params['overtime_labor_cost']
period1_overtime_fatigue_threshold = params['period1_overtime_fatigue_threshold']
period2_labor_recovery_loss = params['period2_labor_recovery_loss']
overtime_review_threshold = params['overtime_review_threshold']
seasonal_safety_review_fee = params['seasonal_safety_review_fee']

# Create model
model = gp.Model("TwoPeriodToyProduction")
model.setParam('OutputFlag', 0)

# Decision variables: production quantities per period and toy type
x = {}
for toy in toys:
    x[(toy['type'], 1)] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"x_{toy['type']}_p1")
    x[(toy['type'], 2)] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"x_{toy['type']}_p2")

# Overtime variables
overtime_p1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="overtime_p1")
overtime_p2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="overtime_p2")
total_overtime = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="total_overtime")

# Binary variable for safety review fee
review_flag = model.addVar(vtype=GRB.BINARY, name="review_flag")

# Link total overtime
model.addConstr(total_overtime == overtime_p1 + overtime_p2, "total_overtime_def")

# Total overtime cap
model.addConstr(total_overtime <= overtime_labor_cap, "overtime_cap")

# Safety review fee activation
M = overtime_labor_cap  # big-M for the constraint
model.addConstr(total_overtime >= overtime_review_threshold - M * (1 - review_flag), "review_activation1")
model.addConstr(total_overtime <= overtime_review_threshold + M * review_flag, "review_activation2")

# Period 1 labor constraint
labor_used_p1 = gp.quicksum(toy['labor'] * x[(toy['type'], 1)] for toy in toys)
model.addConstr(labor_used_p1 <= available_labor_p1 + overtime_p1, "labor_p1")

# Period 2 labor constraint with fatigue carryover
# If overtime_p1 > period1_overtime_fatigue_threshold, then period2 regular labor is reduced by period2_labor_recovery_loss
# We model this with a binary variable for fatigue
fatigue_flag = model.addVar(vtype=GRB.BINARY, name="fatigue_flag")
M_overtime = overtime_labor_cap  # big-M for overtime

# If fatigue_flag = 1, then overtime_p1 >= period1_overtime_fatigue_threshold
model.addConstr(overtime_p1 >= period1_overtime_fatigue_threshold - M_overtime * (1 - fatigue_flag), "fatigue1")
# If fatigue_flag = 0, then overtime_p1 <= period1_overtime_fatigue_threshold
model.addConstr(overtime_p1 <= period1_overtime_fatigue_threshold + M_overtime * fatigue_flag, "fatigue2")

# Period 2 labor constraint: base labor minus recovery loss if fatigue_flag=1
effective_labor_p2 = available_labor_p2 - period2_labor_recovery_loss * fatigue_flag
labor_used_p2 = gp.quicksum(toy['labor'] * x[(toy['type'], 2)] for toy in toys)
model.addConstr(labor_used_p2 <= effective_labor_p2 + overtime_p2, "labor_p2")

# Inspection constraints per period
inspection_used_p1 = gp.quicksum(toy['inspection'] * x[(toy['type'], 1)] for toy in toys)
model.addConstr(inspection_used_p1 <= available_inspection_p1, "inspection_p1")

inspection_used_p2 = gp.quicksum(toy['inspection'] * x[(toy['type'], 2)] for toy in toys)
model.addConstr(inspection_used_p2 <= available_inspection_p2, "inspection_p2")

# Demand constraints per period
for toy in toys:
    model.addConstr(x[(toy['type'], 1)] <= max_demand_p1[toy['type']], f"demand_p1_{toy['type']}")
    model.addConstr(x[(toy['type'], 2)] <= max_demand_p2[toy['type']], f"demand_p2_{toy['type']}")

# Objective: maximize total profit minus overtime costs minus safety review fee
total_profit = gp.quicksum(
    toy['profit'] * (x[(toy['type'], 1)] + x[(toy['type'], 2)]) for toy in toys
)
overtime_cost = overtime_labor_cost * total_overtime
safety_fee = seasonal_safety_review_fee * review_flag

model.setObjective(total_profit - overtime_cost - safety_fee, GRB.MAXIMIZE)

# Optimize
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: None")
