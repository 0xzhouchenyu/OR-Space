import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "table_1.csv")
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    
    df = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)
    
    # Extract parameters
    budget_total = float(params[params['Parameter_Name'] == 'budget']['Value'].iloc[0])
    food_intake_per_dinner = float(params[params['Parameter_Name'] == 'food_intake']['Value'].iloc[0])
    weekday_budget_share = float(params[params['Parameter_Name'] == 'weekday_budget_share']['Value'].iloc[0])
    max_prep_time_weekday = float(params[params['Parameter_Name'] == 'max_prep_time_weekday']['Value'].iloc[0])
    max_prep_time_weekend = float(params[params['Parameter_Name'] == 'max_prep_time_weekend']['Value'].iloc[0])
    weekend_protein_ban = int(params[params['Parameter_Name'] == 'weekend_protein_ban']['Value'].iloc[0])
    veg_balance_penalty = float(params[params['Parameter_Name'] == 'veg_balance_penalty']['Value'].iloc[0])
    
    # Fill missing fiber content with 0
    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)
    
    foods = df['Food'].tolist()
    types = df.set_index('Food')['Type'].to_dict()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()
    
    proteins = [f for f in foods if types[f] == 'protein']
    vegetables = [f for f in foods if types[f] == 'vegetable']
    
    # Create model
    model = gp.Model("Maximize_Fiber_Weekday_Weekend")
    model.setParam('OutputFlag', 0)
    
    # Variables: x_d_f is amount (in 100g units) of food f on day d (0=weekday, 1=weekend)
    x = {}
    for d in [0, 1]:  # 0: weekday, 1: weekend
        for f in foods:
            x[d, f] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{d}_{f}")
    
    # Binary variables: y_f indicates if food f is used in at least one of the two meals
    y = {}
    for f in foods:
        y[f] = model.addVar(vtype=GRB.BINARY, name=f"y_{f}")
    
    # Total vegetable amounts per day (in 100g units)
    veg_weekday = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="veg_weekday")
    veg_weekend = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="veg_weekend")
    
    # Link veg_weekday and veg_weekend to x variables
    model.addConstr(veg_weekday == gp.quicksum(x[0, f] for f in vegetables), "veg_weekday_def")
    model.addConstr(veg_weekend == gp.quicksum(x[1, f] for f in vegetables), "veg_weekend_def")
    
    # Absolute deviation variable for vegetable balance penalty
    veg_dev = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="veg_dev")
    model.addConstr(veg_dev >= veg_weekday - veg_weekend, "veg_dev1")
    model.addConstr(veg_dev >= veg_weekend - veg_weekday, "veg_dev2")
    
    # Objective: maximize total fiber minus penalty for vegetable imbalance
    total_fiber = gp.quicksum(fiber[f] * x[d, f] for d in [0,1] for f in foods)
    objective = total_fiber - veg_balance_penalty * veg_dev
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Constraints per dinner: total food intake (in 100g units)
    model.addConstr(gp.quicksum(x[0, f] for f in foods) == food_intake_per_dinner / 100.0, "food_intake_weekday")
    model.addConstr(gp.quicksum(x[1, f] for f in foods) == food_intake_per_dinner / 100.0, "food_intake_weekend")
    
    # Budget constraints
    weekday_budget = weekday_budget_share * budget_total
    weekend_budget = (1 - weekday_budget_share) * budget_total
    model.addConstr(gp.quicksum(price[f] * x[0, f] for f in foods) <= weekday_budget, "budget_weekday")
    model.addConstr(gp.quicksum(price[f] * x[1, f] for f in foods) <= weekend_budget, "budget_weekend")
    
    # Prep time constraints
    model.addConstr(gp.quicksum(prep_time[f] * x[0, f] for f in foods) <= max_prep_time_weekday, "prep_time_weekday")
    model.addConstr(gp.quicksum(prep_time[f] * x[1, f] for f in foods) <= max_prep_time_weekend, "prep_time_weekend")
    
    # Weekend protein ban: if weekend_protein_ban is 1, then no protein on weekend
    if weekend_protein_ban == 1:
        for f in proteins:
            model.addConstr(x[1, f] == 0, f"no_protein_weekend_{f}")
    
    # Exactly one protein source across both meals (must appear in at least one meal)
    # But note: the requirement says "avoid using a protein label on paper unless that protein appears in at least one of the two meals"
    # And originally: "choosing one protein source among salmon, beef, and pork" -> so exactly one protein type is selected for the week.
    # We interpret: exactly one protein type is used in the two meals combined.
    model.addConstr(gp.quicksum(y[f] for f in proteins) == 1, "exactly_one_protein")
    
    # At least two kinds of vegetables across the two meals? 
    # Original: "at least two kinds of vegetables" per meal? But revision says "the pair must share the same shopping logic"
    # The revision brief does not explicitly change the vegetable count requirement per meal, but the original said "at least two kinds of vegetables"
    # However, the new context is two meals together. The requirement likely means that across the two meals, at least two kinds of vegetables are used.
    # But note: the original problem had "at least two kinds of vegetables" for one meal. Now we have two meals.
    # The revision says: "the same front-office choices have to make sense across the cases", meaning the set of vegetables chosen should be consistent?
    # However, the business brief does not specify per-meal vegetable count. Given the ambiguity, we stick to the original intent: 
    # Since it's two separate dinners, and the original required at least two kinds per meal, but the revision doesn't specify, 
    # and the risk reviewer says "the same shopping logic", it is reasonable to require at least two kinds of vegetables in total for the week.
    # But note: the problem says "Mary is planning a weekday dinner and a weekend dinner together", so the vegetable selection is for the pair.
    # We'll require at least two kinds of vegetables used in at least one of the two meals.
    model.addConstr(gp.quicksum(y[f] for f in vegetables) >= 2, "at_least_two_vegetables")
    
    # Linking constraints: y[f] = 1 if food f is used in at least one meal
    M = (2 * food_intake_per_dinner) / 100.0  # maximum possible amount for any food across two meals
    for f in foods:
        # If y[f] = 0, then x[0,f] and x[1,f] must be 0.
        # If y[f] = 1, then at least one of x[0,f] or x[1,f] must be at least a small amount (we use 0.1 as minimum 10g)
        model.addConstr(x[0, f] + x[1, f] <= M * y[f], f"link_upper_{f}")
        model.addConstr(x[0, f] + x[1, f] >= 0.1 * y[f], f"link_lower_{f}")
    
    # Additionally, for proteins: since we require exactly one protein type, and it must appear in at least one meal,
    # the above linking constraints already ensure that if y[f]=1 for a protein, then it appears in at least one meal.
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        return round(model.objVal, 4)
    else:
        # In case of no solution, return 0 or raise error? But problem expects a value.
        return 0.0

if __name__ == '__main__':
    result = solve()
    print(f"FINAL_OBJ_VALUE: {result}")
