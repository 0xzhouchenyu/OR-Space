import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load table_1_7.csv
    table_path = os.path.join(base_dir, 'table_1_7.csv')
    table_data = []
    with open(table_path, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            table_data.append(row)
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'general_parameters.csv')
    general_params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            value_str = row['Value']
            # Try to convert to float or int, otherwise keep as string
            try:
                if '.' in value_str:
                    value = float(value_str)
                else:
                    value = int(value_str)
            except ValueError:
                value = value_str
            general_params[param_name] = value
    
    return table_data, general_params

def main():
    table_data, general_params = load_data()
    
    # Parse table_1_7.csv
    # The structure is:
    # Row0: ['Item', 'A', 'B', 'C', 'Raw Material Cost (Yuan/kg)', 'Monthly Limit (kg)']
    # Row1: ['A', '>=60%', '>=15%', '', '2.00', '2000']
    # Row2: ['B', '', '', '', '1.50', '2500']
    # Row3: ['C', '<=20%', '<=60%', '<=50%', '1.00', '1200']
    # Row4: ['Processing Fee (Yuan/kg)', '0.50', '0.40', '0.30', '', '']
    # Row5: ['Selling Price (Yuan/kg)', '3.40', '2.85', '2.25', '', '']
    
    raw_materials = ['A', 'B', 'C']
    brands = ['A', 'B', 'C']
    
    # Raw material costs and limits
    raw_cost = [float(table_data[1][4]), float(table_data[2][4]), float(table_data[3][4])]
    limits = [float(table_data[1][5]), float(table_data[2][5]), float(table_data[3][5])]
    
    # Processing fees and selling prices
    proc_fee = [float(table_data[4][1]), float(table_data[4][2]), float(table_data[4][3])]
    sell_price = [float(table_data[5][1]), float(table_data[5][2]), float(table_data[5][3])]
    
    # Setup costs from general_parameters
    setup_cost_A = general_params['SetupCost_A']
    setup_cost_B = general_params['SetupCost_B']
    setup_cost_C = general_params['SetupCost_C']
    shared_wrapper_fee = general_params['BrandAB_SharedWrapper_Fee']
    
    # Create model
    model = gp.Model("CandyFactory_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i][j] = kg of raw material i used in brand j
    x = {}
    for i in range(3):
        for j in range(3):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    # Total production of each brand
    y = {}
    for j in range(3):
        y[j] = model.addVar(lb=0, name=f"y_{j}")
    
    # Binary variables for setup costs
    z = {}
    for j in range(3):
        z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{j}")
    
    # Binary variable for shared wrapper fee (1 if both A and B are produced)
    w = model.addVar(vtype=GRB.BINARY, name="w")
    
    # Link y and x: y[j] = sum_i x[i,j]
    for j in range(3):
        model.addConstr(y[j] == gp.quicksum(x[i, j] for i in range(3)), name=f"link_y_{j}")
    
    # Link y and z: if y[j] > 0 then z[j] = 1; if y[j] = 0 then z[j] can be 0
    # We use a big-M constraint. Since the maximum production for any brand is limited by raw materials,
    # we can set M to the sum of all raw material limits (which is 2000+2500+1200 = 5700)
    M = 5700
    for j in range(3):
        model.addConstr(y[j] <= M * z[j], name=f"setup_link_{j}")
    
    # Shared wrapper constraint: w = 1 if both z[0] and z[1] are 1
    # We enforce: w >= z[0] + z[1] - 1, and w <= z[0], w <= z[1]
    model.addConstr(w >= z[0] + z[1] - 1, name="shared_wrapper_lower")
    model.addConstr(w <= z[0], name="shared_wrapper_upper1")
    model.addConstr(w <= z[1], name="shared_wrapper_upper2")
    
    # Raw material supply constraints
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= limits[i], name=f"raw_limit_{i}")
    
    # Composition constraints
    # Raw material A (i=0): >=60% in brand A (j=0), >=15% in brand B (j=1)
    model.addConstr(x[0, 0] >= 0.60 * y[0], name="comp_A_in_A")
    model.addConstr(x[0, 1] >= 0.15 * y[1], name="comp_A_in_B")
    
    # Raw material C (i=2): <=20% in brand A (j=0), <=60% in brand B (j=1), <=50% in brand C (j=2)
    model.addConstr(x[2, 0] <= 0.20 * y[0], name="comp_C_in_A")
    model.addConstr(x[2, 1] <= 0.60 * y[1], name="comp_C_in_B")
    model.addConstr(x[2, 2] <= 0.50 * y[2], name="comp_C_in_C")
    
    # Objective: maximize profit
    revenue = gp.quicksum(sell_price[j] * y[j] for j in range(3))
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in range(3))
    setup_costs = setup_cost_A * z[0] + setup_cost_B * z[1] + setup_cost_C * z[2]
    shared_wrapper_cost = shared_wrapper_fee * w
    
    profit = revenue - material_cost - processing_cost - setup_costs - shared_wrapper_cost
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_value = model.objVal
    else:
        # In case no solution is found, output 0 or handle appropriately
        obj_value = 0.0
    
    print(f"FINAL_OBJ_VALUE: {obj_value:.1f}")

if __name__ == "__main__":
    main()
