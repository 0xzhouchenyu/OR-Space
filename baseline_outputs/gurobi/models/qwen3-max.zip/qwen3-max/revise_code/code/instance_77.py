import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load processing costs from table_1.csv
    cost = {}  # cost[(machine, part)] = value
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p) for p in header[1:]]
        for row in reader:
            machine = row[0].strip()
            for j, p in enumerate(parts):
                cost[(machine, p)] = float(row[j + 1])

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    d = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    max_C = int(params['max_parts_on_C'])
    overtime_threshold = int(params['overtime_threshold'])
    overtime_penalty = params['overtime_penalty']

    machines = ['A', 'B', 'C']

    # Create model
    model = gp.Model("MachineAssignment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[m][p] = 1 if part p is assigned to machine m
    x = model.addVars(machines, parts, vtype=GRB.BINARY, name="x")

    # y[m] = 1 if machine m is used (any part assigned to it)
    y = model.addVars(machines, vtype=GRB.BINARY, name="y")

    # z[m] = 1 if machine m incurs overtime (i.e., processes more than overtime_threshold parts)
    z = model.addVars(machines, vtype=GRB.BINARY, name="z")

    # Objective: minimize processing costs + setup costs + overtime penalties
    model.setObjective(
        gp.quicksum(cost[(m, p)] * x[m, p] for m in machines for p in parts) +
        gp.quicksum(d[m] * y[m] for m in machines) +
        gp.quicksum(overtime_penalty * z[m] for m in machines),
        GRB.MINIMIZE
    )

    # Each part assigned to exactly one machine
    for p in parts:
        model.addConstr(gp.quicksum(x[m, p] for m in machines) == 1, name=f"assign_part_{p}")

    # Linking y to x: if any part on machine m, y[m] = 1
    for m in machines:
        for p in parts:
            model.addConstr(x[m, p] <= y[m], name=f"link_y_{m}_{p}")

    # Constraint 2: Parts 1 and 2 - if part1 on A then part2 on B or C, and vice versa
    # This means: part1 on A ↔ part2 not on A, i.e., x[A,1] + x[A,2] = 1
    model.addConstr(x['A', 1] + x['A', 2] == 1, name="constraint_2")

    # Constraint 3: Fixed assignments
    model.addConstr(x['A', 3] == 1, name="part3_on_A")
    model.addConstr(x['B', 4] == 1, name="part4_on_B")
    model.addConstr(x['C', 5] == 1, name="part5_on_C")

    # Constraint 4: At most 3 parts on machine C
    model.addConstr(gp.quicksum(x['C', p] for p in parts) <= max_C, name="max_parts_on_C")

    # Overtime constraints: if total parts on machine m > overtime_threshold, then z[m] = 1
    for m in machines:
        total_parts = gp.quicksum(x[m, p] for p in parts)
        # total_parts <= overtime_threshold + M * z[m], where M is a big number (e.g., 10 since only 10 parts)
        model.addConstr(total_parts <= overtime_threshold + 10 * z[m], name=f"overtime_link_{m}")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # In case no optimal solution found, but problem should be feasible
        print("FINAL_OBJ_VALUE: None")

if __name__ == '__main__':
    main()
