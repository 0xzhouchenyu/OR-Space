import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Get data directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read table_1.csv
    materials = []
    sulfur_content = {}
    purchase_price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            mat = row['Material'].strip()
            materials.append(mat)
            sulfur_content[mat] = float(row['Sulfur_Content_Percentage'].strip())
            purchase_price[mat] = float(row['Purchase_Price_Thousand_Yuan_Per_Ton'].strip())
    
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[param_name] = val
    
    # Sulfur limits
    max_sulfur_A_premium = params['max_sulfur_content_A_premium']
    max_sulfur_A_standard = params['max_sulfur_content_A_standard']
    max_sulfur_B_premium = params['max_sulfur_content_B_premium']
    max_sulfur_B_standard = params['max_sulfur_content_B_standard']
    
    # Selling prices
    price_A_premium = params['selling_price_A_premium']
    price_A_standard = params['selling_price_A_standard']
    price_B_premium = params['selling_price_B_premium']
    price_B_standard = params['selling_price_B_standard']
    
    # Supply and demand
    max_supply_D = params['max_supply_D']
    market_demand_A = params['market_demand_A']
    market_demand_B = params['market_demand_B']
    
    # Premium share constraints
    min_premium_A = params['min_premium_share_A']
    max_premium_A = params['max_premium_share_A']
    min_premium_B = params['min_premium_share_B']
    max_premium_B = params['max_premium_share_B']
    
    # Define products: (family, tier)
    products = [('A', 'premium'), ('A', 'standard'), ('B', 'premium'), ('B', 'standard')]
    
    # Create model
    model = gp.Model("Revised_Mixing_Problem")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[m, family, tier] = tons of material m used in product (family, tier)
    x = {}
    for m in materials:
        for family, tier in products:
            var_name = f"x_{m}_{family}_{tier}"
            x[m, family, tier] = model.addVar(lb=0, name=var_name)
    
    # Total production per product stream
    total_A_premium = gp.quicksum(x[m, 'A', 'premium'] for m in materials)
    total_A_standard = gp.quicksum(x[m, 'A', 'standard'] for m in materials)
    total_B_premium = gp.quicksum(x[m, 'B', 'premium'] for m in materials)
    total_B_standard = gp.quicksum(x[m, 'B', 'standard'] for m in materials)
    
    # Revenue
    revenue = (price_A_premium * total_A_premium +
               price_A_standard * total_A_standard +
               price_B_premium * total_B_premium +
               price_B_standard * total_B_standard)
    
    # Cost
    cost = gp.quicksum(purchase_price[m] * (
        x[m, 'A', 'premium'] + x[m, 'A', 'standard'] +
        x[m, 'B', 'premium'] + x[m, 'B', 'standard']
    ) for m in materials)
    
    # Objective: maximize profit = revenue - cost
    model.setObjective(revenue - cost, GRB.MAXIMIZE)
    
    # Sulfur constraints for each stream
    # A premium
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'A', 'premium'] for m in materials) <= 
        max_sulfur_A_premium * total_A_premium,
        name="Sulfur_A_premium"
    )
    
    # A standard
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'A', 'standard'] for m in materials) <= 
        max_sulfur_A_standard * total_A_standard,
        name="Sulfur_A_standard"
    )
    
    # B premium
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'B', 'premium'] for m in materials) <= 
        max_sulfur_B_premium * total_B_premium,
        name="Sulfur_B_premium"
    )
    
    # B standard
    model.addConstr(
        gp.quicksum(sulfur_content[m] * x[m, 'B', 'standard'] for m in materials) <= 
        max_sulfur_B_standard * total_B_standard,
        name="Sulfur_B_standard"
    )
    
    # Supply limit for material D
    model.addConstr(
        gp.quicksum(x['D', family, tier] for family, tier in products) <= max_supply_D,
        name="Supply_D"
    )
    
    # Market demand constraints (by family)
    model.addConstr(total_A_premium + total_A_standard <= market_demand_A, name="Demand_A")
    model.addConstr(total_B_premium + total_B_standard <= market_demand_B, name="Demand_B")
    
    # Premium share constraints
    model.addConstr(total_A_premium >= min_premium_A, name="Min_Premium_A")
    model.addConstr(total_A_premium <= max_premium_A, name="Max_Premium_A")
    model.addConstr(total_B_premium >= min_premium_B, name="Min_Premium_B")
    model.addConstr(total_B_premium <= max_premium_B, name="Max_Premium_B")
    
    # Optimize
    model.optimize()
    
    # Output final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case no optimal solution found, output 0 or handle accordingly
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
