import os
import sys
import csv
import gurobipy as gp
from gurobipy import GRB

def load_coverage_data(data_dir):
    """Load the coverage data from table_1.csv.
    
    Returns:
        areas: list of all area codes
        coverage: dict mapping each area to the set of areas it can cover
    """
    filepath = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        header = next(reader)  # skip header
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
    
    return areas, coverage

def load_general_parameters(data_dir):
    """Load general parameters from general_parameters.csv."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row['Parameter_Name'].strip()
            val_str = row['Value'].strip()
            # Try to convert to int if possible
            try:
                params[key] = int(val_str)
            except ValueError:
                params[key] = val_str
    
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load data
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)
    
    # Extract parameters
    distance_limit = params['distance_limit']
    small_cost = params['small_cost']
    large_cost = params['large_cost']
    small_cap_areas = params['small_cap_areas']
    max_large_stores = params['max_large_stores']
    minimum_neighborhood_counters = params['minimum_neighborhood_counters']
    small_store_counter_credit = params['small_store_counter_credit']  # This is 1, so we just need count of small stores >= 6
    
    # All residential areas that must be covered
    all_areas = set(areas)
    
    # Create model
    model = gp.Model("RevisedMinChainStores")
    model.setParam('OutputFlag', 0)
    
    # Decision variables:
    # For each area j, we can open a Small store (s_j) or a Large store (l_j)
    s = model.addVars(areas, vtype=GRB.BINARY, name="small")
    l = model.addVars(areas, vtype=GRB.BINARY, name="large")
    
    # Constraint: cannot open both small and large in the same area
    for j in areas:
        model.addConstr(s[j] + l[j] <= 1, name=f"exclusive_{j}")
    
    # Coverage constraints: each area i must be covered by at least one store (small or large)
    for i in all_areas:
        covering_vars = []
        for j in areas:
            # If store at j (either type) covers area i
            if i in coverage[j]:
                covering_vars.append(s[j])
                covering_vars.append(l[j])
        model.addConstr(gp.quicksum(covering_vars) >= 1, name=f"cover_{i}")
    
    # Small store capacity constraint: each small store can serve at most small_cap_areas areas
    # But note: the coverage set for a small store is limited to at most small_cap_areas areas from its full coverage list.
    # However, the problem does not require us to choose which subset; instead, we must ensure that the small store's actual served areas <= small_cap_areas.
    # But since we only require coverage (and don't assign specific areas to stores beyond the binary decision), we need to model the capacity as:
    # For each small store at j, the number of areas i that are covered ONLY by this small store? 
    # However, the standard way in set covering with capacity is to use assignment variables. But the problem says: "Maximum number of areas a Small store can serve from its physical coverage list"
    # This implies that if we open a small store at j, then it can cover at most `small_cap_areas` of the areas in its coverage set.
    # Therefore, we need to introduce assignment variables or use a different formulation.
    
    # Alternative approach: Since the problem is small, we can use the following:
    # We require that for each small store j, the total number of areas that are covered by j (and that are not covered by any other store) is not the right way because coverage is redundant.
    # Actually, the capacity constraint is on the store's service capability: even if an area is covered by multiple stores, the small store j can only serve up to small_cap_areas areas in total (from its coverage set).
    # But note: the problem does not specify that we have to assign each area to exactly one store. It only requires that every area is covered by at least one store.
    # However, the capacity constraint for small stores implies that we must account for the load on the small store.
    # Therefore, we need to decide which areas are served by which small store, but large stores have no capacity limit (so they can cover all in their set).
    
    # Given the complexity and the fact that the problem size is small (12 areas), we introduce assignment variables for small stores.
    # Let y[i,j] = 1 if area i is served by a small store at j, 0 otherwise.
    # But note: an area can be covered by a large store without being assigned to a small store.
    
    # Revised plan:
    # - Large stores: if opened, they cover all areas in their coverage set (no capacity limit).
    # - Small stores: if opened, they can cover at most `small_cap_areas` areas from their coverage set, and we must assign which ones.
    # - Each area must be covered by at least one store (either by a large store that covers it, or by being assigned to a small store that covers it).
    
    # Add assignment variables for small stores
    y = {}
    for i in all_areas:
        for j in areas:
            if i in coverage[j]:
                y[i,j] = model.addVar(vtype=GRB.BINARY, name=f"assign_{i}_{j}")
    
    # Each area must be covered: either by a large store that covers it, or by being assigned to a small store that covers it.
    for i in all_areas:
        large_covering = [l[j] for j in areas if i in coverage[j]]
        small_assigning = [y[i,j] for j in areas if (i,j) in y]
        model.addConstr(gp.quicksum(large_covering) + gp.quicksum(small_assigning) >= 1, name=f"cover_assignment_{i}")
    
    # Assignment only to open small stores
    for (i,j) in y:
        model.addConstr(y[i,j] <= s[j], name=f"assign_open_{i}_{j}")
    
    # Small store capacity: for each small store j, the number of areas assigned to it <= small_cap_areas
    for j in areas:
        assigned_areas = [y[i,j] for i in all_areas if (i,j) in y]
        if assigned_areas:
            model.addConstr(gp.quicksum(assigned_areas) <= small_cap_areas * s[j], name=f"capacity_{j}")
    
    # Maximum number of large stores
    model.addConstr(gp.quicksum(l[j] for j in areas) <= max_large_stores, name="max_large")
    
    # Minimum number of small stores (neighborhood counters)
    model.addConstr(gp.quicksum(s[j] for j in areas) >= minimum_neighborhood_counters, name="min_small")
    
    # Objective: minimize total cost = small_cost * (number of small stores) + large_cost * (number of large stores)
    obj = small_cost * gp.quicksum(s[j] for j in areas) + large_cost * gp.quicksum(l[j] for j in areas)
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case no solution, but the problem should be feasible
        obj_val = float('inf')
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
