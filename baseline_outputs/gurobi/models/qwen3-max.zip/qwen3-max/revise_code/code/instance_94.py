import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

# Extract parameters
min_A_I = params['min_proportion_crude_A_type_I'] / 100.0
min_A_II = params['min_proportion_crude_A_type_II'] / 100.0
price_I = params['selling_price_type_I']
price_II = params['selling_price_type_II']
inv_A = params['inventory_crude_A']
inv_B = params['inventory_crude_B']
max_purchase_A = params['max_purchase_crude_A']
cost_tier1 = params['market_price_crude_A_tier_1']
cost_tier2 = params['market_price_crude_A_tier_2']
cost_tier3 = params['market_price_crude_A_tier_3']
processing_capacity = params['processing_capacity']
min_total_gasoline_output = params['min_total_gasoline_output']
processing_cost_per_ton = params['processing_cost_per_ton']
type_II_contract_threshold = params['type_II_contract_threshold']
type_II_price_lift = params['type_II_price_lift']
bulk_purchase_rebate_threshold = params['bulk_purchase_rebate_threshold']
bulk_purchase_rebate = params['bulk_purchase_rebate']

# Create model
model = gp.Model("Revised_Oil_Blending")
model.setParam('OutputFlag', 0)

# Decision variables
a1 = model.addVar(lb=0, name="crude_A_in_I")
a2 = model.addVar(lb=0, name="crude_A_in_II")
b1 = model.addVar(lb=0, name="crude_B_in_I")
b2 = model.addVar(lb=0, name="crude_B_in_II")

p1 = model.addVar(lb=0, ub=500, name="purchase_tier1")
p2 = model.addVar(lb=0, ub=500, name="purchase_tier2")
p3 = model.addVar(lb=0, ub=500, name="purchase_tier3")

y1 = model.addVar(vtype=GRB.BINARY, name="y1")
y2 = model.addVar(vtype=GRB.BINARY, name="y2")

# Binary variables for new thresholds
z_typeII = model.addVar(vtype=GRB.BINARY, name="z_typeII")  # 1 if Type II output >= threshold
z_bulk = model.addVar(vtype=GRB.BINARY, name="z_bulk")      # 1 if total purchase >= bulk threshold

# Tiered ordering constraints
model.addConstr(p1 <= 500)
model.addConstr(p2 <= 500 * y1)
model.addConstr(p3 <= 500 * y2)
model.addConstr(p1 >= 500 * y1)
model.addConstr(p2 >= 500 * y2)

# Total crude A available
total_A_purchased = p1 + p2 + p3
model.addConstr(a1 + a2 <= inv_A + total_A_purchased)
model.addConstr(b1 + b2 <= inv_B)

# Blending constraints
model.addConstr(a1 >= min_A_I * (a1 + b1))
model.addConstr(a2 >= min_A_II * (a2 + b2))

# Processing capacity and minimum output
total_gasoline = (a1 + b1) + (a2 + b2)
model.addConstr(total_gasoline <= processing_capacity)
model.addConstr(total_gasoline >= min_total_gasoline_output)

# Type II contract threshold constraint
gasoline_II = a2 + b2
M_large = 10000  # Big-M value, larger than max possible gasoline_II (which is <=2500)
model.addConstr(gasoline_II >= type_II_contract_threshold - M_large * (1 - z_typeII))
model.addConstr(gasoline_II <= type_II_contract_threshold + M_large * z_typeII - 1e-5)  # Ensure strict when not met

# Bulk purchase rebate threshold constraint
M_purchase = 2000  # Larger than max purchase (1500)
model.addConstr(total_A_purchased >= bulk_purchase_rebate_threshold - M_purchase * (1 - z_bulk))
model.addConstr(total_A_purchased <= bulk_purchase_rebate_threshold + M_purchase * z_bulk - 1e-5)

# Objective: Revenue - Cost + Rebates + Lifts
revenue_I = price_I * (a1 + b1)
revenue_II_base = price_II * (a2 + b2)
revenue_II_lift = type_II_price_lift * (a2 + b2) * z_typeII

total_revenue = revenue_I + revenue_II_base + revenue_II_lift

processing_cost = processing_cost_per_ton * total_gasoline
purchase_cost = cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3
total_cost = processing_cost + purchase_cost

rebate = bulk_purchase_rebate * z_bulk

objective = total_revenue - total_cost + rebate

model.setObjective(objective, GRB.MAXIMIZE)

# Optimize
model.optimize()

if model.status == GRB.OPTIMAL:
    final_obj = model.objVal
else:
    final_obj = 0.0

print(f"FINAL_OBJ_VALUE: {final_obj}")
