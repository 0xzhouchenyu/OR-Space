import os
import sys
import gurobipy as gp
from gurobipy import GRB

# Add parent directory to path if needed
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utils import load_general_parameters, load_reliability_table

def solve():
    # Load data
    params = load_general_parameters()
    reliability = load_reliability_table()
    
    # Extract parameters
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    total_budget_A = params['total_budget_scenario_A']
    total_budget_B = params['total_budget_scenario_B']
    weight_limit_A = params['weight_limit_scenario_A']
    weight_limit_B = params['weight_limit_scenario_B']
    
    # The possible number of spares is 0 to 5 (as per table_1.csv)
    max_spares = 5
    
    # Create a mapping from spare count to reliability for each component
    # reliability[n] = [r1, r2, r3] for n spares
    # We'll create lists for each component
    r1_vals = [reliability[i][0] for i in range(max_spares+1)]
    r2_vals = [reliability[i][1] for i in range(max_spares+1)]
    r3_vals = [reliability[i][2] for i in range(max_spares+1)]
    
    # Create model
    model = gp.Model("spare_parts_optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: s_i_j = 1 if we choose j spares for component i, 0 otherwise
    # Component 1
    s1 = model.addVars(range(max_spares+1), vtype=GRB.BINARY, name="s1")
    # Component 2
    s2 = model.addVars(range(max_spares+1), vtype=GRB.BINARY, name="s2")
    # Component 3
    s3 = model.addVars(range(max_spares+1), vtype=GRB.BINARY, name="s3")
    
    # Each component must have exactly one spare count selected
    model.addConstr(gp.quicksum(s1[j] for j in range(max_spares+1)) == 1, "select_s1")
    model.addConstr(gp.quicksum(s2[j] for j in range(max_spares+1)) == 1, "select_s2")
    model.addConstr(gp.quicksum(s3[j] for j in range(max_spares+1)) == 1, "select_s3")
    
    # Total cost and weight expressions
    total_cost = gp.quicksum(j * unit_price[0] * s1[j] for j in range(max_spares+1)) + \
                 gp.quicksum(j * unit_price[1] * s2[j] for j in range(max_spares+1)) + \
                 gp.quicksum(j * unit_price[2] * s3[j] for j in range(max_spares+1))
    
    total_weight = gp.quicksum(j * unit_weight[0] * s1[j] for j in range(max_spares+1)) + \
                   gp.quicksum(j * unit_weight[1] * s2[j] for j in range(max_spares+1)) + \
                   gp.quicksum(j * unit_weight[2] * s3[j] for j in range(max_spares+1))
    
    # Constraints for both scenarios: must satisfy the stricter of the two for each resource
    # Since we need to satisfy both scenarios, we take the minimum budget and minimum weight limit
    model.addConstr(total_cost <= total_budget_A, "budget_A")
    model.addConstr(total_cost <= total_budget_B, "budget_B")
    model.addConstr(total_weight <= weight_limit_A, "weight_A")
    model.addConstr(total_weight <= weight_limit_B, "weight_B")
    
    # The objective is the expected system reliability = 0.5 * (R1*R2*R3) + 0.5 * (R1*R2*R3) = R1*R2*R3
    # However, the product of variables is nonlinear. We can linearize by taking logarithm?
    # But note: the problem is small (only 6*6*6=216 combinations). However, the requirement says to use Gurobi.
    # Since the reliability values are fixed for each spare count, we can express the objective as:
    # sum_{i,j,k} (r1[i] * r2[j] * r3[k]) * s1[i] * s2[j] * s3[k]
    # This is a cubic term, which is not directly supported in Gurobi for MIP.
    
    # Alternative approach: since the problem is very small, we can use the fact that only one combination is chosen.
    # We can introduce a variable for the objective and use indicator constraints, but that's complex.
    
    # However, note: the original heuristic enumerated all possibilities. Given the small size, we might consider
    # that the intended solution is to use enumeration. But the problem states: "You MUST use gurobipy".
    
    # Another idea: because the objective is the product and the choices are discrete, we can precompute all possible
    # objective values and then use a linear expression by introducing a variable for each combination.
    # But that would be 216 variables, which is acceptable.
    
    # Let's create a variable for each combination (i,j,k) that is 1 if we choose i spares for comp1, j for comp2, k for comp3.
    # But note: we already have s1, s2, s3. We can link them by: x[i,j,k] = s1[i] * s2[j] * s3[k]. 
    # However, that requires many constraints.
    
    # Given the small size, and since the problem is actually separable in the sense that the objective is multiplicative,
    # but Gurobi doesn't handle products of binaries well in the objective, we can use the following trick:
    # Because the objective value for a combination (i,j,k) is known (r1[i]*r2[j]*r3[k]), we can write:
    # objective = sum_{i,j,k} (r1[i]*r2[j]*r3[k]) * y[i,j,k]
    # where y[i,j,k] is 1 if we choose (i,j,k), and 0 otherwise.
    # And we have constraints: 
    #   sum_{j,k} y[i,j,k] = s1[i] for all i
    #   sum_{i,k} y[i,j,k] = s2[j] for all j
    #   sum_{i,j} y[i,j,k] = s3[k] for all k
    # But this is overkill and creates 216 variables.
    
    # However, note: the problem is so small that even if we do enumeration in Python without Gurobi, it would be acceptable.
    # But the instructions say: "You MUST use gurobipy as the solver."
    
    # Let me re-read: the original heuristic was enumeration. The revision says: "build a correct optimization model that captures the full requirements".
    # And "You MUST use gurobipy".
    
    # Since the objective is nonlinear (product of three terms, each of which is a piecewise constant function of integer variables),
    # and the problem is small, one common approach is to use the fact that the objective can be represented by a set of points.
    # But Gurobi has a feature for piecewise linear functions, but here we have a multivariate function.
    
    # Given the complexity and the small size, and because the problem is actually equivalent to:
    #   maximize { r1[i] * r2[j] * r3[k] }
    #   subject to: 
    #       i*20 + j*30 + k*40 <= min(150,140) = 140
    #       i*2 + j*4 + k*6 <= min(20,18) = 18
    #       i,j,k in {0,1,2,3,4,5}
    #
    # So the feasible set is defined by the stricter constraints: budget <= 140 and weight <= 18.
    #
    # Therefore, we can simply change the constraints to use the minimum of the two scenarios for each resource.
    #
    # Why? Because if a solution satisfies cost <= 140 and weight <= 18, then it automatically satisfies:
    #   cost <= 150 (since 140<150) and weight <= 20 (since 18<20).
    #
    # So the feasible region is: 
    #   cost <= min(total_budget_A, total_budget_B) = 140
    #   weight <= min(weight_limit_A, weight_limit_B) = 18
    #
    # Therefore, we can model it as a single scenario with budget=140 and weight=18.
    #
    # And the objective is just the product r1*r2*r3 (since both scenarios have the same reliability for a given config).
    #
    # Now, how to model the product in Gurobi? We cannot put a product in the objective for a MIP.
    #
    # But note: the reliability values are fixed for each spare count. So we can precompute the objective value for every feasible (i,j,k).
    # However, the requirement is to use Gurobi. 
    #
    # Alternative: since the problem is small, we can use Gurobi to enumerate? But that's not standard.
    #
    # Actually, the problem is a pure integer program with a nonlinear objective. Gurobi can handle nonlinear objectives if we use the right interface.
    # But the problem says "MIP", and the objective is nonlinear. However, Gurobi does support quadratic and general nonlinear objectives, but for MIP it's limited.
    #
    # However, note: the objective is not quadratic, it's a product of three terms, each of which is a step function. But we have modeled the spare counts as binaries.
    #
    # Let me try to express the objective as:
    #   obj = (sum_i r1[i]*s1[i]) * (sum_j r2[j]*s2[j]) * (sum_k r3[k]*s3[k])
    # This is a cubic expression. Gurobi does not support cubic objectives in MIP.
    #
    # Given the above, and because the problem is very small (only 216 combinations), the intended solution might be to use enumeration within the Gurobi framework? 
    # But that doesn't make sense.
    #
    # However, note: the problem says "the REVISION description, and the REVISED data", and the original heuristic was enumeration. 
    # But the instruction says: "You MUST use gurobipy as the solver."
    #
    # After re-thinking: the problem is actually a mixed-integer linear program if we linearize the objective by precomputation? 
    # But the objective is not linear.
    #
    # Another idea: take logarithm. Since the reliability values are positive, we can maximize log(obj) = log(r1) + log(r2) + log(r3).
    # And log(r1) = sum_i log(r1[i]) * s1[i], similarly for r2 and r3.
    # Then the objective becomes linear in the s variables.
    #
    # This is valid because the logarithm is a monotonic transformation, so maximizing the product is equivalent to maximizing the sum of logs.
    #
    # Let's do that.
    
    # Precompute log reliabilities (to avoid log(0), but note: the smallest reliability is 0.5, so safe)
    import math
    log_r1 = [math.log(r) for r in r1_vals]
    log_r2 = [math.log(r) for r in r2_vals]
    log_r3 = [math.log(r) for r in r3_vals]
    
    # Objective: maximize log_r1 + log_r2 + log_r3
    obj_expr = gp.quicksum(log_r1[i] * s1[i] for i in range(max_spares+1)) + \
               gp.quicksum(log_r2[j] * s2[j] for j in range(max_spares+1)) + \
               gp.quicksum(log_r3[k] * s3[k] for k in range(max_spares+1))
    
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Update model and optimize
    model.update()
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        # Retrieve the solution
        s1_val = None
        s2_val = None
        s3_val = None
        for i in range(max_spares+1):
            if s1[i].x > 0.5:
                s1_val = i
            if s2[i].x > 0.5:
                s2_val = i
            if s3[i].x > 0.5:
                s3_val = i
        
        # Compute the actual objective (the product, not the log)
        obj_value = r1_vals[s1_val] * r2_vals[s2_val] * r3_vals[s3_val]
        print(f"FINAL_OBJ_VALUE: {obj_value}")
    else:
        # In case no solution found, but there should be at least (0,0,0)
        print("FINAL_OBJ_VALUE: 0.0")

if __name__ == '__main__':
    solve()
