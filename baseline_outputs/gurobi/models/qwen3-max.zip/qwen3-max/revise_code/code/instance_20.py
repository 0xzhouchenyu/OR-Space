import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass
            params[name] = value
    return params

def solve():
    params = load_parameters()
    
    # Extract parameters
    profit_robot = params['profit_per_robot']
    profit_car = params['profit_per_model_car']
    profit_blocks = params['profit_per_building_blocks']
    profit_doll = params['profit_per_doll']
    
    plastic_avail = params['plastic_available']
    plastic_robot = params['plastic_per_robot']
    plastic_car = params['plastic_per_model_car']
    plastic_blocks = params['plastic_per_building_blocks']
    plastic_doll = params['plastic_per_doll']
    
    electronics_avail = params['electronic_components_available']
    electronics_robot = params['electronics_per_robot']
    electronics_car = params['electronics_per_model_car']
    electronics_blocks = params['electronics_per_building_blocks']
    electronics_doll = params['electronics_per_doll']
    
    # Create model
    model = gp.Model("ToyManufacturing")
    model.setParam('OutputFlag', 0)
    
    # Decision variables (integer, number of toys)
    x_robot = model.addVar(vtype=GRB.INTEGER, lb=0, name="robots")
    x_car = model.addVar(vtype=GRB.INTEGER, lb=0, name="model_cars")
    x_blocks = model.addVar(vtype=GRB.INTEGER, lb=0, name="building_blocks")
    x_doll = model.addVar(vtype=GRB.INTEGER, lb=0, name="dolls")
    
    # Binary variables for logical constraints
    y_robot = model.addVar(vtype=GRB.BINARY, name="y_robot")
    y_doll = model.addVar(vtype=GRB.BINARY, name="y_doll")
    y_car = model.addVar(vtype=GRB.BINARY, name="y_car")
    y_blocks = model.addVar(vtype=GRB.BINARY, name="y_blocks")
    
    # Objective
    model.setObjective(
        profit_robot * x_robot + 
        profit_car * x_car + 
        profit_blocks * x_blocks + 
        profit_doll * x_doll,
        GRB.MAXIMIZE
    )
    
    # Resource constraints
    model.addConstr(
        plastic_robot * x_robot + 
        plastic_car * x_car + 
        plastic_blocks * x_blocks + 
        plastic_doll * x_doll <= plastic_avail,
        "Plastic"
    )
    
    model.addConstr(
        electronics_robot * x_robot + 
        electronics_car * x_car + 
        electronics_blocks * x_blocks + 
        electronics_doll * x_doll <= electronics_avail,
        "Electronics"
    )
    
    # Link binary variables to production quantities
    M = 10000
    model.addConstr(x_robot <= M * y_robot, "Link_robot")
    model.addConstr(x_doll <= M * y_doll, "Link_doll")
    model.addConstr(x_car <= M * y_car, "Link_car")
    model.addConstr(x_blocks <= M * y_blocks, "Link_blocks")
    
    # Ensure binary variables are 1 if production > 0
    model.addConstr(y_robot <= x_robot, "Binary_Link_Robot")
    model.addConstr(y_doll <= x_doll, "Binary_Link_Doll")
    model.addConstr(y_car <= x_car, "Binary_Link_Car")
    model.addConstr(y_blocks <= x_blocks, "Binary_Link_Blocks")
    
    # Original constraints
    # If robots are manufactured, dolls cannot be manufactured (exclusion)
    model.addConstr(y_robot + y_doll <= 1, "Robot_Doll_Exclusion")
    
    # If model cars are manufactured, building blocks must also be manufactured
    model.addConstr(y_car <= y_blocks, "Car_Blocks_Dependency")
    
    # Dolls cannot exceed model cars
    model.addConstr(x_doll <= x_car, "Dolls_leq_Cars")
    
    # NEW constraint: model cars and building blocks cannot be produced together
    # This overrides the previous dependency constraint in practice, but we keep both for correctness
    # However, note: the new rule says they cannot be produced in the same plan.
    # So we add: y_car + y_blocks <= 1
    model.addConstr(y_car + y_blocks <= 1, "Car_Blocks_Mutual_Exclusion")
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        obj_val = 0.0
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    solve()
