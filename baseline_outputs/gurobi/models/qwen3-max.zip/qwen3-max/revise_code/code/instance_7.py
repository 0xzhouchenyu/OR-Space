import os
import csv
from utils import load_csv_data
import gurobipy as gp
from gurobipy import GRB


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")

    # Load warehouse data
    warehouses_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    warehouses = []
    supply = {}
    for row in warehouses_data:
        name = row['Warehouse']
        warehouses.append(name)
        supply[name] = int(row['Empty_Containers'])

    # Load port data
    ports_data = load_csv_data(os.path.join(data_dir, 'table_2.csv'))
    ports = []
    demand = {}
    for row in ports_data:
        name = row['Port']
        ports.append(name)
        demand[name] = int(row['Container_Demand'])

    # Load distance data
    distance_data = load_csv_data(os.path.join(data_dir, 'table_3.csv'))
    distance = {}
    for row in distance_data:
        wh = row['Warehouse']
        for port in ports:
            distance[(wh, port)] = float(row[port])

    # Load general parameters
    params_data = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    params = {}
    for row in params_data:
        params[row['Parameter_Name']] = float(row['Value'])

    cost_per_km = params['cost_per_km']
    truck_capacity = int(params['truck_capacity'])
    adriatic_pool_shortage_trigger = int(params['adriatic_pool_shortage_trigger'])
    adriatic_pool_recovery_fee = params['adriatic_pool_recovery_fee']

    # Load shortage penalty data
    shortage_penalty_data = load_csv_data(os.path.join(data_dir, 'shortage_penalty.csv'))
    shortage_charge = {}
    grace_containers = {}
    recovery_fee = {}
    for row in shortage_penalty_data:
        port = row['Port']
        shortage_charge[port] = float(row['Shortage_Charge'])
        grace_containers[port] = int(row['Grace_Containers'])
        recovery_fee[port] = float(row['Recovery_Fee'])

    # Identify Adriatic ports: Venice, Ancona, Bari (as per business context)
    adriatic_ports = ['Venice', 'Ancona', 'Bari']

    # Create model
    model = gp.Model("Revised_Container_Transportation")
    model.setParam('OutputFlag', 0)

    # Decision variables:
    # x[i,j] = number of containers shipped from warehouse i to port j (integer >=0)
    x = {}
    for i in warehouses:
        for j in ports:
            x[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}")

    # Shortage at each port: s[j] = max(0, demand[j] - sum_i x[i,j])
    s = {}
    for j in ports:
        s[j] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"s_{j}")

    # Binary variable: y[j] = 1 if port j opens its recovery desk (i.e., shortage > grace_containers[j])
    y = {}
    for j in ports:
        y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")

    # Binary variable: z = 1 if combined Adriatic shortage > adriatic_pool_shortage_trigger
    z = model.addVar(vtype=GRB.BINARY, name="z_adriatic_pool")

    # Constraints: define shortage s[j] = demand[j] - sum_i x[i,j] (but non-negative)
    for j in ports:
        model.addConstr(s[j] >= demand[j] - gp.quicksum(x[i, j] for i in warehouses), name=f"shortage_def_{j}")
        model.addConstr(s[j] >= 0, name=f"shortage_nonneg_{j}")

    # Link y[j] to shortage: if s[j] > grace_containers[j] then y[j] = 1
    # We use a big-M constraint. Since max shortage is at most total_demand (114), we set M = 200.
    M = 200
    for j in ports:
        model.addConstr(s[j] <= grace_containers[j] + M * y[j], name=f"recovery_trigger_{j}")

    # Link z to combined Adriatic shortage
    total_adriatic_shortage = gp.quicksum(s[j] for j in adriatic_ports)
    model.addConstr(total_adriatic_shortage <= adriatic_pool_shortage_trigger + M * z, name="adriatic_pool_trigger")

    # Supply constraints
    for i in warehouses:
        model.addConstr(gp.quicksum(x[i, j] for j in ports) <= supply[i], name=f"supply_{i}")

    # Objective: transport cost + shortage charges + individual recovery fees + adriatic pool fee
    transport_cost = gp.quicksum(x[i, j] * distance[i, j] * cost_per_km for i in warehouses for j in ports)
    shortage_cost = gp.quicksum(s[j] * shortage_charge[j] for j in ports)
    individual_recovery_cost = gp.quicksum(y[j] * recovery_fee[j] for j in ports)
    adriatic_pool_cost = z * adriatic_pool_recovery_fee

    total_cost = transport_cost + shortage_cost + individual_recovery_cost + adriatic_pool_cost
    model.setObjective(total_cost, GRB.MINIMIZE)

    # Optimize
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of no optimal solution, we try to get the best bound or throw an error.
        # But per problem statement, we assume feasible.
        print("FINAL_OBJ_VALUE: None")


if __name__ == "__main__":
    main()
