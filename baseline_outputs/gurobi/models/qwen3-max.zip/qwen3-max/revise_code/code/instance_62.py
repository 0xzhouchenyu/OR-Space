import os
import csv
from gurobipy import GRB, Model


def load_restaurant_data(filepath):
    """Load restaurant data from CSV file."""
    restaurants = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'standard_staff_hours': float(row['Standard_Staff_Hours'].strip()),
                'premium_staff_hours': float(row['Premium_Staff_Hours'].strip())
            })
    return restaurants


def load_general_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    return params


def main():
    # Determine data directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load data
    restaurants = load_restaurant_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    budget = params['investment_budget']
    premium_revenue_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']
    
    # Create the optimization model
    model = Model("Restaurant_Investment")
    model.setParam('OutputFlag', 0)
    
    # Decision variables:
    # y[r] = 1 if restaurant r is acquired (either standard or premium), 0 otherwise
    # z[r] = 1 if restaurant r is operated in Premium mode, 0 otherwise (only meaningful if y[r]=1)
    y = {}
    z = {}
    for r in restaurants:
        name = r['name']
        y[name] = model.addVar(vtype=GRB.BINARY, name=f"y_{name}")
        z[name] = model.addVar(vtype=GRB.BINARY, name=f"z_{name}")
        # Enforce that z[r] <= y[r] (can't operate in premium if not acquired)
        model.addConstr(z[name] <= y[name], f"Premium_implies_acquired_{name}")
    
    # Objective: maximize total annual revenue
    # Revenue for a restaurant = base_revenue * (1 + premium_revenue_uplift * z[r])
    obj_expr = gp.LinExpr()
    for r in restaurants:
        name = r['name']
        base_rev = r['revenue']
        premium_rev = base_rev * (1 + premium_revenue_uplift)
        # Total revenue = base_rev * y[r] + (premium_rev - base_rev) * z[r]
        obj_expr += base_rev * y[name] + (premium_rev - base_rev) * z[name]
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Budget constraint: total cost = acquisition cost + premium upgrade cost
    budget_expr = gp.LinExpr()
    for r in restaurants:
        name = r['name']
        budget_expr += r['cost'] * y[name] + premium_upgrade_cost * z[name]
    model.addConstr(budget_expr <= budget, "Budget_Constraint")
    
    # Staff hours constraint: total staff hours based on operation mode
    staff_expr = gp.LinExpr()
    for r in restaurants:
        name = r['name']
        staff_expr += r['standard_staff_hours'] * (y[name] - z[name]) + r['premium_staff_hours'] * z[name]
    model.addConstr(staff_expr <= staff_hours_cap, "Staff_Hours_Constraint")
    
    # If Restaurant D is purchased, Restaurant A cannot be purchased
    if 'Restaurant_D' in y and 'Restaurant_A' in y:
        model.addConstr(y['Restaurant_D'] + y['Restaurant_A'] <= 1, "D_A_Exclusion_Constraint")
    
    # Optimize
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case no optimal solution found, output 0 or handle as needed
        print("FINAL_OBJ_VALUE: 0")


if __name__ == "__main__":
    main()
