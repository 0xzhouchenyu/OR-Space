import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_table1(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in ['Product_I', 'Product_II', 'Product_III']:
                val = row[p].strip() if row[p].strip() else None
                proc_times[e][p] = float(val) if val else None
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())
    
    return equipment, proc_times, eff_hours, op_costs

def load_general_params(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    raw_costs = {}
    prices = {}
    shared_labor_hours = None
    labor_coeff = {}
    b2_activation_fee = None
    
    mapping_raw = {
        'raw_material_cost_product_I': 'Product_I',
        'raw_material_cost_product_II': 'Product_II',
        'raw_material_cost_product_III': 'Product_III',
    }
    mapping_price = {
        'unit_price_product_I': 'Product_I',
        'unit_price_product_II': 'Product_II',
        'unit_price_product_III': 'Product_III',
    }
    
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            if name in mapping_raw:
                raw_costs[mapping_raw[name]] = val
            if name in mapping_price:
                prices[mapping_price[name]] = val
            if name == 'shared_labor_hours':
                shared_labor_hours = val
            if name.startswith('labor_coeff_'):
                equip_name = name[len('labor_coeff_'):]
                labor_coeff[equip_name] = val
            if name == 'b2_activation_fee':
                b2_activation_fee = val
    
    return raw_costs, prices, shared_labor_hours, labor_coeff, b2_activation_fee

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    equipment, proc_times, eff_hours, op_costs = load_table1(data_dir)
    raw_costs, prices, shared_labor_hours, labor_coeff, b2_activation_fee = load_general_params(data_dir)
    
    products = ['Product_I', 'Product_II', 'Product_III']
    A_equip = [e for e in equipment if e.startswith('A')]
    B_equip = [e for e in equipment if e.startswith('B')]
    
    model = gp.Model("Factory_Production_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[e][p] = number of units of product p processed on equipment e
    x = {}
    for e in equipment:
        x[e] = {}
        for p in products:
            if proc_times[e][p] is not None:
                x[e][p] = model.addVar(lb=0, name=f"x_{e}_{p}")
    
    # Binary variable for B2 activation
    y_b2 = model.addVar(vtype=GRB.BINARY, name="y_b2")
    
    # Capacity constraints: total processing time <= effective machine hours
    for e in equipment:
        model.addConstr(
            gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None) <= eff_hours[e],
            name=f"capacity_{e}"
        )
    
    # Flow balance: for each product, total A-processed = total B-processed
    for p in products:
        a_sum = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
        b_sum = gp.quicksum(x[e][p] for e in B_equip if proc_times[e][p] is not None)
        model.addConstr(a_sum == b_sum, name=f"balance_{p}")
    
    # Total production of each product
    total_prod = {}
    for p in products:
        total_prod[p] = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
    
    # Shared labor constraint
    total_labor = gp.quicksum(
        labor_coeff[e] * gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None)
        for e in equipment
    )
    model.addConstr(total_labor <= shared_labor_hours, name="shared_labor")
    
    # B2 activation constraint: if any product is processed on B2, y_b2 must be 1
    if 'B2' in B_equip:
        total_b2_usage = gp.quicksum(x['B2'][p] * proc_times['B2'][p] for p in products if proc_times['B2'][p] is not None)
        # If total_b2_usage > 0 then y_b2 = 1. We use a big-M constraint.
        M = eff_hours['B2']  # Maximum possible usage of B2
        model.addConstr(total_b2_usage <= M * y_b2, name="b2_activation")
    
    # Revenue
    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)
    
    # Raw material costs
    raw_cost_total = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)
    
    # Operating costs: proportional to usage fraction
    operating_cost = gp.quicksum(
        op_costs[e] * gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None) / eff_hours[e]
        for e in equipment
    )
    
    # B2 activation fee
    b2_fee = b2_activation_fee * y_b2 if 'B2' in B_equip else 0
    
    # Objective: maximize profit
    model.setObjective(revenue - raw_cost_total - operating_cost - b2_fee, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        obj_val = 0.0
    
    print(f"FINAL_OBJ_VALUE: {obj_val:.4f}")

if __name__ == "__main__":
    main()
