import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read table_1.csv for workshop capacities and production rates
    workshops = []
    total_capacities = {}
    rates = {}
    
    filepath_table1 = os.path.join(data_dir, 'table_1.csv')
    with open(filepath_table1, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            total_capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
    
    components = [1, 2, 3]
    shifts = ['day', 'night']
    
    # Read general_parameters.csv
    params = {}
    filepath_params = os.path.join(data_dir, 'general_parameters.csv')
    with open(filepath_params, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    
    # Extract parameters
    regular_hours_limit = {}
    overtime_capacity = {}
    bigM_shift = {}
    
    for w in workshops:
        for shift in shifts:
            key_reg = f"regular_hours_limit_{shift}_{w}"
            key_ot = f"overtime_capacity_{shift}_{w}"
            regular_hours_limit[(w, shift)] = params[key_reg]
            overtime_capacity[(w, shift)] = params[key_ot]
        bigM_shift[w] = params[f"bigM_shift_{w}"]
    
    penalty_night = params['penalty_night_hour']
    penalty_overtime = params['penalty_overtime_hour']
    penalty_shortage = params['penalty_shortage_per_unit']
    z_target = params['z_target']
    
    # Create model
    model = gp.Model("Revised_Maximize_Completed_Products")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Hours each workshop allocates to each component in each shift (regular and overtime)
    x_reg = {}  # x_reg[w, shift, c] = regular hours
    x_ot = {}   # x_ot[w, shift, c] = overtime hours
    for w in workshops:
        for shift in shifts:
            for c in components:
                x_reg[(w, shift, c)] = model.addVar(lb=0, name=f"x_reg_{w}_{shift}_{c}")
                x_ot[(w, shift, c)] = model.addVar(lb=0, name=f"x_ot_{w}_{shift}_{c}")
    
    # Total production per component
    total_prod = {}
    for c in components:
        total_prod[c] = model.addVar(lb=0, name=f"total_prod_{c}")
    
    # Number of completed products (min of total units per component)
    z = model.addVar(lb=0, name="z")
    
    # Binary variables: whether a workshop is active in a shift
    y = {}
    for w in workshops:
        for shift in shifts:
            y[(w, shift)] = model.addVar(vtype=GRB.BINARY, name=f"y_{w}_{shift}")
    
    # Auxiliary variable for shortage
    shortage = model.addVar(lb=0, name="shortage")
    
    # Objective: maximize z - (penalty costs)
    # But note: the problem says "keep burdens small", and we have a target z_target.
    # The penalty_shortage is for shortfall below z_target, so we minimize total penalty cost
    # while trying to achieve high z. However, the original objective was to maximize z.
    # The revision implies a multi-objective: maximize z but penalize night, overtime, and shortage.
    # Since the problem states: "the schedule should meet requirements while keeping those burdens small",
    # and given the presence of z_target and penalty_shortage, we interpret the objective as:
    # Maximize [ z - (penalty_night * total_night_regular_hours + penalty_overtime * total_overtime_hours + penalty_shortage * shortage) ]
    # BUT: note that z is bounded by the min of components, and shortage = max(0, z_target - z)
    #
    # However, the problem says "maximize the number of completed products" as the primary goal, but now with additional constraints and penalties.
    # The business brief says: "meet requirements while keeping those burdens small". The requirement is to maximize completed products, but with new operational constraints.
    # The penalties are provided, so we form a single objective that combines:
    #   maximize z - [penalty terms]
    # But note: the penalties are costs, so we can minimize total cost = (penalty_night * night_hrs + penalty_overtime * ot_hrs + penalty_shortage * shortage)
    # and we also want to maximize z. However, the problem does not specify weights between z and the penalties.
    #
    # Re-examining: the original objective was to maximize z. The revision adds constraints (shift limits, at most two workshops per shift) and introduces penalties for night and overtime, and a penalty for shortage relative to z_target.
    # The natural interpretation is to maximize z, but if we cannot reach z_target, we incur a shortage penalty. However, the problem says "maximize the number of completed products", so z is still the main output.
    # But the penalties for night and overtime are to be minimized. This is a multi-objective problem.
    #
    # However, the problem statement in the revised business requirement still says: "The objective is to determine the number of hours ... to maximize the number of completed products."
    # The penalties are not part of the objective in the original sense, but the revision says "keeping those burdens small". 
    # Given the data provides penalty coefficients and a z_target, and the instruction says "the schedule should meet requirements while keeping those burdens small", 
    # and the example of penalty_shortage_per_unit, it is likely that the intended model is to minimize the total penalty cost, where:
    #   total_penalty = penalty_night * (total night regular hours) + penalty_overtime * (total overtime hours) + penalty_shortage * max(0, z_target - z)
    # BUT: note that the primary goal is still to maximize z. However, without a clear trade-off, and given that the problem says "maximize completed products", 
    # and the penalties are only for the purpose of breaking ties or as secondary, but the problem does not specify.
    #
    # Looking at the parameters: 
    #   penalty_shortage_per_unit = 0.05, which is small, and z_target=2924.
    #   penalty_night_hour=1.0, penalty_overtime_hour=1.5.
    #
    # Another interpretation: the business wants to achieve at least z_target if possible, and if not, then the shortage is penalized. But the main goal is still to maximize z.
    # However, the problem says "maximize the number of completed products", so we should keep z as the primary objective. But the penalties for night and overtime are to be minimized only after maximizing z?
    # That would be a lexicographic objective. But the problem does not specify.
    #
    # Given the context of the problem and the fact that the original heuristic maximized z, and the revision adds constraints and penalties, 
    # and the problem says "Formulate this problem as a linear programming problem", but now with integer variables (for the shift activation) so it's MILP,
    # and the penalties are provided, the intended model is likely to have a single objective that combines:
    #   maximize [ z - (penalty_night * total_night_regular + penalty_overtime * total_overtime + penalty_shortage * (z_target - z)^+ ) ]
    # However, note that (z_target - z)^+ is not linear. We can model it with:
    #   shortage >= z_target - z
    #   shortage >= 0
    # and then use shortage in the objective.
    #
    # But the problem says "maximize completed products", so if we subtract penalties, we might end up with a lower z to avoid penalties? 
    # That contradicts the primary goal.
    #
    # After re-thinking: the business brief says "the schedule should meet requirements while keeping those burdens small". 
    # The requirement is to produce as many products as possible (so maximize z), but subject to the new constraints (shift limits, at most two workshops per shift). 
    # The penalties for night and overtime are not part of the objective function per se, but the problem states they "carry their listed drawbacks", meaning we should avoid them. 
    # However, without a trade-off specified, and given that the original objective was to maximize z, and the new constraints might reduce z, 
    # the penalties might be used only for the shortage relative to z_target? 
    #
    # But note: the problem provides penalty_night_hour and penalty_overtime_hour, and also penalty_shortage_per_unit. 
    # And the instruction says: "the schedule should meet requirements while keeping those burdens small". 
    # This suggests a single objective that minimizes the total burden (penalties) while achieving the production. 
    # However, the primary requirement is still to maximize z. 
    #
    # Clarification from the problem: the original objective remains "maximize the number of completed products", but now with additional constraints. 
    # The penalties for night and overtime are not to be minimized in the objective, but the constraints on shifts and the limit of two workshops per shift are hard constraints. 
    # The penalties might be red herrings? But the problem says "night work and overtime each carry their listed drawbacks, so the schedule should meet requirements while keeping those burdens small". 
    # This implies that among schedules that achieve the same z, we prefer the one with less night and overtime. 
    # However, the problem does not specify a multi-objective approach. 
    #
    # Given the complexity, and the fact that the problem provides a z_target and penalty_shortage, it is likely that the intended model is:
    #   We want to achieve at least z_target if possible. If not, we incur a shortage penalty. 
    #   Additionally, we want to minimize the use of night and overtime, but only after ensuring we get as much z as possible? 
    #   But the problem says "maximize z", so we must maximize z first. 
    #
    # However, the problem statement in the revised business requirement still says: "The objective is to ... maximize the number of completed products." 
    # So the primary objective is z. The penalties for night and overtime are not part of the objective function; they are just to be minimized as a secondary goal, but the problem does not require that in the objective. 
    # But the problem says "keeping those burdens small", so if we have multiple solutions with the same z, we pick the one with smallest penalties. 
    # However, the problem does not specify how to handle that. 
    #
    # Looking at the parameters: the penalty_shortage is very small (0.05 per unit), while penalty_night is 1.0 per hour and penalty_overtime is 1.5 per hour. 
    # And note: producing one unit of a component might take a fraction of an hour. For example, in workshop A, component 1: 10 units/hour -> 0.1 hour per unit. 
    # So the cost of producing one unit in night regular time: 0.1 * 1.0 = 0.1, which is more than the shortage penalty of 0.05. 
    # This suggests that it might be cheaper to have a shortage than to produce in night time? 
    # But that contradicts the goal of maximizing z. 
    #
    # Therefore, the intended interpretation is likely: 
    #   We are allowed to not meet z_target, and we pay a penalty for the shortage. 
    #   We also pay penalties for using night and overtime. 
    #   The overall objective is to minimize the total penalty cost, which includes:
    #       cost = (night regular hours)*1.0 + (overtime hours)*1.5 + (shortage)*0.05
    #   BUT: note that the production z is determined by the min of the components, and shortage = max(0, z_target - z). 
    #   However, we can also produce more than z_target, but that doesn't help because the product is limited by the min component. 
    #   And producing more than needed for z_target doesn't reduce shortage (which is only for shortfall). 
    #
    # However, the problem says "maximize the number of completed products", not minimize penalty. 
    # This is confusing.
    #
    # Let me read the revision brief again: "The plan has to follow the commercial interpretation below, with the data-pack labels read literally." 
    # and "the schedule should meet requirements while keeping those burdens small". 
    # The requirement is to produce products, but the burdens (night, overtime) should be small. 
    # And they provide penalty coefficients. 
    #
    # In operations research, when penalties are provided for deviations, it is common to form a single objective that minimizes the weighted sum of penalties. 
    # Here, the "requirement" might be interpreted as achieving z_target, and any deviation (shortfall) is penalized. 
    # Additionally, the use of night and overtime is penalized. 
    # So the objective becomes: minimize [ penalty_night * (total night regular hours) + penalty_overtime * (total overtime hours) + penalty_shortage * (z_target - z)^+ ]
    # BUT: note that z is not fixed; we can choose to produce less than z_target to avoid high night/overtime costs. 
    # However, the problem says "maximize completed products", which suggests we should not arbitrarily reduce z. 
    #
    # Given the ambiguity, and the fact that the original problem maximized z, and the revision adds constraints and penalties, 
    # and the problem provides a z_target and penalty_shortage, I think the intended model is to maximize z, 
    # but subject to the new constraints, and the penalties for night and overtime are not in the objective. 
    # However, the constraint "no more than two workshops should be active in the same shift" is hard. 
    # And the shift hour limits (regular and overtime) are hard constraints. 
    #
    # But wait: the problem says "keeping those burdens small", which implies they are not hard constraints but soft. 
    # However, the shift hour limits are given as maximums, so they are hard. 
    # The "burdens" refer to the fact that night and overtime are undesirable, but we are allowed to use them up to the capacity. 
    # So the only role of the penalty coefficients might be for the shortage. 
    #
    # However, the problem provides penalty_night_hour and penalty_overtime_hour, and also uses them in the context of "drawbacks", 
    # and the objective should reflect that we want to minimize these drawbacks. 
    #
    # After careful thought, I believe the correct approach is to treat the problem as a single objective that maximizes:
    #   z - [ penalty_night * (total night regular hours) + penalty_overtime * (total overtime hours) + penalty_shortage * max(0, z_target - z) ]
    # But this is not linear because of the max(0, z_target - z). 
    # We can linearize the shortage part by introducing a variable 'shortage' with:
    #   shortage >= z_target - z
    #   shortage >= 0
    # and then the objective becomes:
    #   maximize z - [ penalty_night * (total night regular hours) + penalty_overtime * (total overtime hours) + penalty_shortage * shortage ]
    #
    # However, note: if we do this, then increasing z beyond z_target would increase the objective (since shortage=0 and z increases), 
    # which is good. And if we are below z_target, then shortage = z_target - z, so the term becomes:
    #   z - [ ... + penalty_shortage*(z_target - z) ] = (1+penalty_shortage)*z - [ ... + penalty_shortage*z_target ]
    # So it's still beneficial to increase z.
    #
    # Given the parameters, this seems reasonable.
    #
    # Steps:
    # 1. Define variables for regular and overtime hours per workshop, shift, component.
    # 2. Total production per component = sum over workshops and shifts of (rate * (x_reg + x_ot))
    # 3. z <= total production for each component.
    # 4. Shift constraints:
    #    For each workshop and shift:
    #        sum_{c} x_reg[(w,shift,c)] <= regular_hours_limit[(w,shift)]
    #        sum_{c} x_ot[(w,shift,c)] <= overtime_capacity[(w,shift)]
    #    Also, total hours for workshop w: sum_{shift, c} (x_reg + x_ot) <= total_capacities[w]  [from table_1.csv]
    # 5. At most two workshops active per shift:
    #        For each shift, sum_{w} y[(w,shift)] <= 2
    #    And link y to hours: 
    #        For each w, shift: 
    #            sum_{c} (x_reg[(w,shift,c)] + x_ot[(w,shift,c)]) <= bigM_shift[w] * y[(w,shift)]
    # 6. Shortage variable: shortage >= z_target - z, shortage >= 0.
    # 7. Objective: maximize z - (penalty_night * total_night_regular + penalty_overtime * total_overtime + penalty_shortage * shortage)
    #
    # Note: total_night_regular = sum_{w, c} x_reg[(w, 'night', c)]
    #       total_overtime = sum_{w, shift, c} x_ot[(w, shift, c)]
    
    # Define total production constraints
    for c in components:
        model.addConstr(
            total_prod[c] == gp.quicksum(
                rates[(w, c)] * (x_reg[(w, shift, c)] + x_ot[(w, shift, c)])
                for w in workshops for shift in shifts
            ),
            name=f"total_prod_{c}"
        )
        model.addConstr(z <= total_prod[c], name=f"z_le_prod_{c}")
    
    # Workshop total capacity constraints (from table_1.csv)
    for w in workshops:
        model.addConstr(
            gp.quicksum(x_reg[(w, shift, c)] + x_ot[(w, shift, c)] for shift in shifts for c in components) <= total_capacities[w],
            name=f"total_capacity_{w}"
        )
    
    # Shift-specific regular and overtime constraints
    for w in workshops:
        for shift in shifts:
            model.addConstr(
                gp.quicksum(x_reg[(w, shift, c)] for c in components) <= regular_hours_limit[(w, shift)],
                name=f"reg_limit_{w}_{shift}"
            )
            model.addConstr(
                gp.quicksum(x_ot[(w, shift, c)] for c in components) <= overtime_capacity[(w, shift)],
                name=f"ot_limit_{w}_{shift}"
            )
    
    # Linking active indicator y to hours
    for w in workshops:
        for shift in shifts:
            model.addConstr(
                gp.quicksum(x_reg[(w, shift, c)] + x_ot[(w, shift, c)] for c in components) <= bigM_shift[w] * y[(w, shift)],
                name=f"link_y_{w}_{shift}"
            )
    
    # At most two workshops active per shift
    for shift in shifts:
        model.addConstr(
            gp.quicksum(y[(w, shift)] for w in workshops) <= 2,
            name=f"max_two_workshops_{shift}"
        )
    
    # Shortage variable constraints
    model.addConstr(shortage >= z_target - z, name="shortage_def1")
    model.addConstr(shortage >= 0, name="shortage_def2")
    
    # Total night regular hours and total overtime hours
    total_night_regular = gp.quicksum(x_reg[(w, 'night', c)] for w in workshops for c in components)
    total_overtime = gp.quicksum(x_ot[(w, shift, c)] for w in workshops for shift in shifts for c in components)
    
    # Objective
    obj_expr = z - (
        penalty_night * total_night_regular +
        penalty_overtime * total_overtime +
        penalty_shortage * shortage
    )
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    # Output the objective value as required
    if model.status == GRB.OPTIMAL or model.status == GRB.SUBOPTIMAL:
        final_obj = model.objVal
    else:
        # In case of no solution, we try to get the best bound or set to 0, but the problem likely has a solution.
        final_obj = 0.0
    
    print(f"FINAL_OBJ_VALUE: {final_obj:.6f}")

if __name__ == "__main__":
    main()
