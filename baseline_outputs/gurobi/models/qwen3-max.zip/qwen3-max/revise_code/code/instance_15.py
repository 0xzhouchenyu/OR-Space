import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    params_df = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    
    param_dict = dict(zip(params_df['Parameter_Name'], params_df['Value']))
    demand = dict(zip(table_1['stage'], table_1['tool_requirement']))
    
    n = int(param_dict['n'])
    cost_new = float(param_dict['cost_new_tool'])
    cost_slow = float(param_dict['cost_slow_repair'])
    cost_fast = float(param_dict['cost_fast_repair'])
    dur_slow = int(param_dict['slow_repair_duration'])
    dur_fast = int(param_dict['fast_repair_duration'])
    max_fast_stage = int(param_dict['max_fast_stage'])
    max_slow_stage = int(param_dict['max_slow_stage'])
    emission_buy = float(param_dict['emission_buy'])
    emission_fast = float(param_dict['emission_fast_repair'])
    emission_slow = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_shortage = float(param_dict['penalty_shortage'])
    
    # Create model
    model = gp.Model("Tool_Repair_Problem")
    model.setParam('OutputFlag', 0)
    
    stages = list(range(1, n+1))
    
    # Decision variables
    buy = model.addVars(stages, vtype=GRB.INTEGER, name="buy", lb=0)
    fast = model.addVars(stages, vtype=GRB.INTEGER, name="fast", lb=0)
    slow = model.addVars(stages, vtype=GRB.INTEGER, name="slow", lb=0)
    clean = model.addVars(range(0, n+1), vtype=GRB.INTEGER, name="clean", lb=0)
    dirty = model.addVars(range(0, n+1), vtype=GRB.INTEGER, name="dirty", lb=0)
    shortage = model.addVars(stages, vtype=GRB.INTEGER, name="shortage", lb=0)
    
    # Initial conditions
    model.addConstr(clean[0] >= 0, "init_clean_nonneg")
    model.addConstr(dirty[0] == 0, "init_dirty_zero")
    
    # Flow balance constraints for each stage
    for i in stages:
        # Tools available at stage i: initial clean stock (if i=1, then clean[0]), 
        # plus new purchases, plus repairs that finish at stage i
        fast_ready = 0
        if i - dur_fast >= 1:
            fast_ready = fast[i - dur_fast]
        elif i - dur_fast == 0:
            # Repairs sent at stage 0? But we don't have stage 0 for repair decisions.
            # According to problem, prebuy_clean is allowed at stage 0, but no dirty tools at start.
            # So no repairs can be initiated before stage 1. Thus, only repairs from stage >=1.
            fast_ready = 0
        else:
            fast_ready = 0
            
        slow_ready = 0
        if i - dur_slow >= 1:
            slow_ready = slow[i - dur_slow]
        elif i - dur_slow == 0:
            slow_ready = 0
        else:
            slow_ready = 0
        
        # Clean inventory balance: 
        # clean[i-1] + buy[i] + fast_ready + slow_ready = demand[i] - shortage[i] + clean[i]
        model.addConstr(
            clean[i-1] + buy[i] + fast_ready + slow_ready == demand[i] - shortage[i] + clean[i],
            name=f"clean_balance_{i}"
        )
        
        # Dirty inventory balance:
        # dirty[i-1] + (demand[i] - shortage[i]) = fast[i] + slow[i] + dirty[i]
        model.addConstr(
            dirty[i-1] + (demand[i] - shortage[i]) == fast[i] + slow[i] + dirty[i],
            name=f"dirty_balance_{i}"
        )
        
        # Repair capacity constraints
        model.addConstr(fast[i] <= max_fast_stage, name=f"fast_cap_{i}")
        model.addConstr(slow[i] <= max_slow_stage, name=f"slow_cap_{i}")
        
        # Shortage cannot exceed demand
        model.addConstr(shortage[i] <= demand[i], name=f"shortage_cap_{i}")
    
    # Carbon budget constraint
    total_emission = (
        emission_buy * gp.quicksum(buy[i] for i in stages) +
        emission_fast * gp.quicksum(fast[i] for i in stages) +
        emission_slow * gp.quicksum(slow[i] for i in stages)
    )
    model.addConstr(total_emission <= carbon_budget, name="carbon_budget")
    
    # Objective: minimize total cost
    total_cost = (
        cost_new * gp.quicksum(buy[i] for i in stages) +
        cost_fast * gp.quicksum(fast[i] for i in stages) +
        cost_slow * gp.quicksum(slow[i] for i in stages) +
        penalty_shortage * gp.quicksum(shortage[i] for i in stages)
    )
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case of no solution, but problem should be feasible
        obj_val = float('inf')
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
