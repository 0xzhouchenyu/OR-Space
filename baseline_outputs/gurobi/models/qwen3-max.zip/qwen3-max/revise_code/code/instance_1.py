import os
import sys
from gurobipy import GRB
import gurobipy as gp

def load_csv(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", filename)
    with open(filepath, 'r') as f:
        import csv
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            rows.append(row)
    return rows

def load_parameters():
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name'].strip()
        val = row['Value'].strip()
        try:
            if '.' in val:
                params[name] = float(val)
            else:
                params[name] = int(val)
        except ValueError:
            params[name] = val
    return params

def load_demand():
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        week = int(row['Week'].strip())
        demand[week] = {
            'I': int(row['I'].strip()),
            'II': int(row['II'].strip())
        }
    return demand

def main():
    params = load_parameters()
    demand = load_demand()

    T = 8
    weeks = range(1, T+1)

    S0 = params['skilled_worker_count']
    rate_I = params['food_I_production_rate']
    rate_II = params['food_II_production_rate']
    normal_hours = params['worker_weekly_hours']
    overtime_hours = params['skilled_worker_overtime_hours']
    train_cap = params['training_capacity']
    train_period = params['training_period']
    wage_skilled = params['skilled_worker_weekly_wage']
    wage_trainee_during = params['trainee_weekly_wage_during_training']
    wage_trainee_after = params['trainee_weekly_wage_after_training']
    wage_overtime = params['skilled_worker_overtime_wage']
    comp_I = params['compensation_fee_food_I']
    comp_II = params['compensation_fee_food_II']
    new_worker_goal = params['new_worker_training_goal']

    model = gp.Model("factory_training")
    model.setParam('OutputFlag', 0)

    # Decision variables
    n_train = {}
    for t in weeks:
        if t <= T - 1:
            n_train[t] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_train_{t}")

    # Binary variable: 1 if week t is dedicated to Food I, 0 if to Food II (or idle, but then production=0)
    y = {}
    for t in weeks:
        y[t] = model.addVar(vtype=GRB.BINARY, name=f"y_{t}")

    # Hours for skilled workers (normal and overtime) - only one product per week
    h_s = {}   # total normal hours by skilled workers in week t (for the chosen product)
    h_ot = {}  # total overtime hours by skilled workers in week t (for the chosen product)
    h_g = {}   # total hours by graduated trainees in week t (for the chosen product)

    for t in weeks:
        h_s[t] = model.addVar(lb=0, name=f"h_s_{t}")
        h_ot[t] = model.addVar(lb=0, name=f"h_ot_{t}")
        h_g[t] = model.addVar(lb=0, name=f"h_g_{t}")

    # Number of skilled workers doing overtime in week t
    n_overtime = {}
    for t in weeks:
        n_overtime[t] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"n_ot_{t}")

    # Backlog variables
    backlog_I = {}
    backlog_II = {}
    for t in weeks:
        backlog_I[t] = model.addVar(lb=0, name=f"bI_{t}")
        backlog_II[t] = model.addVar(lb=0, name=f"bII_{t}")

    # Helper functions for constraints
    def trainers_busy(t):
        expr = gp.LinExpr()
        for s in n_train:
            if s <= t <= s + train_period - 1:
                expr += n_train[s]
        return expr

    def graduates_available(t):
        expr = gp.LinExpr()
        for s in n_train:
            if s + train_period <= t:
                expr += train_cap * n_train[s]
        return expr

    # Constraints
    for t in weeks:
        busy_t = trainers_busy(t)
        avail_skilled_t = S0 - busy_t
        grads_t = graduates_available(t)

        # Overtime workers cannot exceed available skilled workers
        model.addConstr(n_overtime[t] <= avail_skilled_t, f"ot_limit_{t}")

        # Normal skilled hours: (avail_skilled_t - n_overtime[t]) * normal_hours
        model.addConstr(h_s[t] <= (avail_skilled_t - n_overtime[t]) * normal_hours, f"skilled_normal_hours_{t}")

        # Overtime skilled hours: n_overtime[t] * overtime_hours
        model.addConstr(h_ot[t] <= n_overtime[t] * overtime_hours, f"skilled_ot_hours_{t}")

        # Graduated trainees hours
        model.addConstr(h_g[t] <= grads_t * normal_hours, f"grad_hours_{t}")

        # Mutual exclusion: if y[t]=1 (Food I), then all hours go to Food I; if y[t]=0, then to Food II.
        # But note: we don't produce both. So production of Food I in week t is (h_s[t] + h_ot[t] + h_g[t]) * rate_I * y[t]
        # However, linearizing product of continuous and binary is tricky. Instead, we can use:
        # Let prod_I[t] = (h_s[t] + h_ot[t] + h_g[t]) * rate_I if y[t]=1, else 0.
        # Similarly for Food II.

        # We'll handle production via the backlog constraints using big-M or direct linking.
        # Since we have separate backlogs, we can express:
        # Production of Food I in week t = (h_s[t] + h_ot[t] + h_g[t]) * rate_I * y[t]
        # Production of Food II in week t = (h_s[t] + h_ot[t] + h_g[t]) * rate_II * (1 - y[t])

        # But to keep linearity, we avoid multiplying variables. Instead, we note:
        # If y[t]=1, then we must have no production of Food II -> which is already enforced by not having separate hour vars.
        # However, the backlog constraints need the actual production amounts.

        # We'll compute production in the backlog constraints by branching on y[t].
        # Alternative: introduce auxiliary variables for production, but that complicates.

        # Instead, we can write the backlog constraints as:
        # backlog_I[t] >= backlog_I[t-1] + demand[t]['I'] - (h_s[t] + h_ot[t] + h_g[t]) * rate_I * y[t]
        # backlog_II[t] >= backlog_II[t-1] + demand[t]['II'] - (h_s[t] + h_ot[t] + h_g[t]) * rate_II * (1 - y[t])

        # But this is nonlinear (product of continuous and binary). We linearize using big-M.

        # Let P_I[t] = production of Food I in week t
        # Then: P_I[t] <= (h_s[t] + h_ot[t] + h_g[t]) * rate_I
        #       P_I[t] <= M * y[t]
        #       P_I[t] >= (h_s[t] + h_ot[t] + h_g[t]) * rate_I - M * (1 - y[t])
        # Similarly for P_II[t].

        # However, to avoid adding more variables, we can use the following trick in the backlog constraints:
        # Since the objective minimizes backlog cost, and production reduces backlog, the solver will set production as high as possible when y[t] is fixed.
        # But we must enforce that if y[t]=0, then production of Food I is 0, and vice versa.

        # We'll add constraints to force production to zero for the non-selected product.

        # Actually, we don't have separate production variables. The backlog constraints must reflect the actual production.

        # Approach: use two sets of constraints for backlog, but conditionally.
        # Instead, we introduce auxiliary production variables.

    # Introduce production variables to linearize
    prod_I = {}
    prod_II = {}
    for t in weeks:
        prod_I[t] = model.addVar(lb=0, name=f"prod_I_{t}")
        prod_II[t] = model.addVar(lb=0, name=f"prod_II_{t}")

    # Link production to hours and y[t]
    M = 1e6  # big-M, large enough
    for t in weeks:
        total_hours = h_s[t] + h_ot[t] + h_g[t]
        # If y[t]=1, then prod_I[t] = total_hours * rate_I, and prod_II[t] = 0
        # If y[t]=0, then prod_I[t] = 0, and prod_II[t] = total_hours * rate_II

        model.addConstr(prod_I[t] <= total_hours * rate_I, f"prodI_ub1_{t}")
        model.addConstr(prod_I[t] <= M * y[t], f"prodI_ub2_{t}")
        model.addConstr(prod_I[t] >= total_hours * rate_I - M * (1 - y[t]), f"prodI_lb_{t}")

        model.addConstr(prod_II[t] <= total_hours * rate_II, f"prodII_ub1_{t}")
        model.addConstr(prod_II[t] <= M * (1 - y[t]), f"prodII_ub2_{t}")
        model.addConstr(prod_II[t] >= total_hours * rate_II - M * y[t], f"prodII_lb_{t}")

    # Backlog balance constraints
    for t in weeks:
        prev_bI = backlog_I[t-1] if t > 1 else 0
        prev_bII = backlog_II[t-1] if t > 1 else 0

        model.addConstr(backlog_I[t] >= prev_bI + demand[t]['I'] - prod_I[t], f"backlog_I_{t}")
        model.addConstr(backlog_II[t] >= prev_bII + demand[t]['II'] - prod_II[t], f"backlog_II_{t}")

    # Ensure skilled workers are not over-allocated
    for t in weeks:
        busy_t = trainers_busy(t)
        model.addConstr(S0 - busy_t >= 0, f"enough_skilled_{t}")

    # Training goal: total trained workers by end of week 8 >= new_worker_goal
    total_trained = gp.LinExpr()
    for s in n_train:
        if s + train_period <= T:  # training started in s finishes by s+1, so by week 8 if s<=7
            total_trained += train_cap * n_train[s]
    model.addConstr(total_trained >= new_worker_goal, "training_goal")

    # Objective function
    total_cost = gp.LinExpr()

    # Wages for skilled workers (including trainers and those in production, normal or overtime)
    # Every skilled worker is paid wage_skilled per week, regardless of role (trainer, normal production, or overtime)
    # Because: trainers get wage_skilled, normal production gets wage_skilled, overtime gets wage_overtime (which replaces wage_skilled)
    # So: for each week t, 
    #   number of skilled workers = S0
    #   but those in overtime are paid wage_overtime instead of wage_skilled
    #   so cost for skilled workers in week t = (S0 - n_overtime[t]) * wage_skilled + n_overtime[t] * wage_overtime
    for t in weeks:
        total_cost += (S0 - n_overtime[t]) * wage_skilled + n_overtime[t] * wage_overtime

    # Trainee wages during training
    # For each training start week s, there are train_cap * n_train[s] trainees
    # They are in training for 2 weeks: weeks s and s+1
    for s in n_train:
        num_trainees = train_cap * n_train[s]
        total_cost += num_trainees * wage_trainee_during  # week s
        if s+1 <= T:
            total_cost += num_trainees * wage_trainee_during  # week s+1

    # Wages for graduated trainees (after training)
    # A trainee who started in week s is available from week s+2 to week T
    for t in weeks:
        grads_t = graduates_available(t)
        total_cost += grads_t * wage_trainee_after

    # Compensation cost for backlog
    for t in weeks:
        total_cost += backlog_I[t] * comp_I + backlog_II[t] * comp_II

    model.setObjective(total_cost, GRB.MINIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of no solution, but problem should be feasible
        print("FINAL_OBJ_VALUE: inf")

if __name__ == "__main__":
    main()
