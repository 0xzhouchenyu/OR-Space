import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read device data
devices = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        devices.append({
            'name': row['Device'].strip(),
            'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
            'max_cap': float(row['Max_Processing_Capacity_Units'].strip())
        })

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        params[param_name] = float(row['Value'].strip())

required_units = params['required_units']
energy_budget_peak = params['energy_budget_peak']
energy_budget_offpeak = params['energy_budget_offpeak']
startup_budget = params['startup_budget']
energy_price_peak = params['energy_price_peak']
energy_price_offpeak = params['energy_price_offpeak']
startup_cost_per = params['startup_cost']

# Extract energy per unit and startup energy per device
energy_per_unit = {}
startup_energy = {}
for device in devices:
    name = device['name']
    energy_per_unit[name] = params[f'energy_per_unit_{name}']
    startup_energy[name] = params[f'startup_energy_{name}']

# Create model
model = gp.Model("MinCostProduction")
model.setParam('OutputFlag', 0)

n = len(devices)
device_names = [d['name'] for d in devices]

# Decision variables
# x[i][t]: units produced on device i in period t (0: peak, 1: off-peak)
x = {}
for i in range(n):
    for t in range(2):
        x[i, t] = model.addVar(lb=0, ub=devices[i]['max_cap'], name=f"x_{device_names[i]}_{t}")

# y[i][t]: binary variable indicating if device i is used in period t
y = {}
for i in range(n):
    for t in range(2):
        y[i, t] = model.addVar(vtype=GRB.BINARY, name=f"y_{device_names[i]}_{t}")

# Total production constraint
model.addConstr(gp.quicksum(x[i, t] for i in range(n) for t in range(2)) == required_units, "TotalProduction")

# Linking constraints: x[i,t] <= max_cap * y[i,t]
for i in range(n):
    for t in range(2):
        model.addConstr(x[i, t] <= devices[i]['max_cap'] * y[i, t], f"Link_{device_names[i]}_{t}")

# Energy budget constraints
# Peak period energy: sum_i (startup_energy_i * y[i,0] + energy_per_unit_i * x[i,0]) <= energy_budget_peak
model.addConstr(
    gp.quicksum(startup_energy[device_names[i]] * y[i, 0] + energy_per_unit[device_names[i]] * x[i, 0] 
                for i in range(n)) <= energy_budget_peak, "EnergyBudgetPeak")

# Off-peak period energy: sum_i (startup_energy_i * y[i,1] + energy_per_unit_i * x[i,1]) <= energy_budget_offpeak
model.addConstr(
    gp.quicksum(startup_energy[device_names[i]] * y[i, 1] + energy_per_unit[device_names[i]] * x[i, 1] 
                for i in range(n)) <= energy_budget_offpeak, "EnergyBudgetOffpeak")

# Startup budget constraint: total startup cost over both periods <= startup_budget
model.addConstr(
    gp.quicksum(startup_cost_per * y[i, t] for i in range(n) for t in range(2)) <= startup_budget, "StartupBudget")

# Objective function
# Total cost = 
#   sum_i (prep_cost_i * (y[i,0] OR y[i,1]))  --> but note: prep cost is incurred if device is used in either period
# However, the problem states: "Every device-period combination that is brought into service consumes startup energy and startup spend"
# and the original prep_completion_cost is likely a one-time setup per device (not per period). 
# But the revision says: "Crossing a named business line changes eligibility..." and "startup budgets" are separate.
# The original prep_completion_cost is still present in table_1.csv and must be accounted for.
# Clarification: The prep_completion_cost is a fixed cost for using the device at all (in any period), while startup_cost is per period.
# So we need a new binary variable z[i] = 1 if device i is used in either period.

z = {}
for i in range(n):
    z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{device_names[i]}")
    # z[i] >= y[i,0] and z[i] >= y[i,1]
    model.addConstr(z[i] >= y[i, 0])
    model.addConstr(z[i] >= y[i, 1])
    # Also, if neither period is used, z[i] should be 0. But since we minimize cost, it will be 0 if not needed.
    # To enforce: z[i] <= y[i,0] + y[i,1]
    model.addConstr(z[i] <= y[i, 0] + y[i, 1])

# Now, objective:
# Fixed prep cost: sum_i (prep_cost_i * z[i])
# Startup costs: sum_{i,t} (startup_cost_per * y[i,t])
# Production costs: sum_{i,t} (unit_cost_i * x[i,t])
# Energy costs: 
#   peak: energy_price_peak * sum_i (energy_per_unit_i * x[i,0])
#   offpeak: energy_price_offpeak * sum_i (energy_per_unit_i * x[i,1])
# Note: startup energy is already constrained by energy budgets but does not incur monetary cost beyond the startup_cost_per?
# According to data: startup_cost is "Monetary cost incurred each time a device is started in a period", so that's separate from energy cost.
# And energy cost is only for the electricity used in production (and startup energy is just a constraint, not charged?).
# But wait: the problem says "unit production uses period-specific electricity", and startup consumes startup energy (which is constrained by energy_budgets) but the monetary cost for startup is given as startup_cost (a fixed CNY per startup).
# So energy cost is only for the production units, not for the startup energy.

obj = gp.quicksum(devices[i]['prep_cost'] * z[i] for i in range(n)) + \
      gp.quicksum(startup_cost_per * y[i, t] for i in range(n) for t in range(2)) + \
      gp.quicksum(devices[i]['unit_cost'] * x[i, t] for i in range(n) for t in range(2)) + \
      energy_price_peak * gp.quicksum(energy_per_unit[device_names[i]] * x[i, 0] for i in range(n)) + \
      energy_price_offpeak * gp.quicksum(energy_per_unit[device_names[i]] * x[i, 1] for i in range(n))

model.setObjective(obj, GRB.MINIMIZE)

# Optimize
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, but problem should be feasible
    print("FINAL_OBJ_VALUE: inf")
