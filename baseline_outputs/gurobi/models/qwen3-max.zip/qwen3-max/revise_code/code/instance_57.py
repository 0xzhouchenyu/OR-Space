import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def main():
    # Read orders
    table_1_path = get_data_path('table_1.csv')
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
    
    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    n_orders = len(orders)
    
    # Read parameters
    params_path = get_data_path('general_parameters.csv')
    params = {}
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            value = float(row['Value'])
            params[param_name] = value
    
    std_widths = [params['standard_width_1'], params['standard_width_2']]
    pattern_setup_penalty = params['pattern_setup_penalty']
    wide_roll_threshold = params['wide_roll_threshold_width']
    wide_roll_extra_penalty = params['wide_roll_extra_setup_penalty']
    
    total_required_area = sum(w * l for w, l in zip(widths, lengths))
    
    # Generate all feasible cutting patterns for each standard width
    patterns_by_std_width = {}
    for idx, sw in enumerate(std_widths):
        patterns = []
        def build_pattern(order_idx, current_pattern, current_sum):
            if order_idx == n_orders:
                if any(c > 0 for c in current_pattern):
                    patterns.append(current_pattern[:])
                return
            
            max_count = int(math.floor((sw - current_sum + 1e-7) / widths[order_idx]))
            for count in range(max_count + 1):
                current_pattern.append(count)
                build_pattern(order_idx + 1, current_pattern, current_sum + count * widths[order_idx])
                current_pattern.pop()
                
        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {'sw': sw, 'patterns': patterns}
    
    # Create Gurobi model
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_vars = {}  # continuous variables for length of each pattern
    y_vars = {}  # binary variables indicating if a pattern is used
    
    for idx, data in patterns_by_std_width.items():
        sw = data['sw']
        for i, pattern in enumerate(data['patterns']):
            var_name = f"x_{idx}_{i}"
            x_vars[(idx, i)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=var_name)
            y_vars[(idx, i)] = model.addVar(vtype=GRB.BINARY, name=f"y_{idx}_{i}")
            
            # Link x and y: if pattern is used (x>0) then y must be 1
            # We use a big-M constraint: x <= M * y
            # M can be set to the maximum possible length needed, which is sum of all lengths
            M = sum(lengths)
            model.addConstr(x_vars[(idx, i)] <= M * y_vars[(idx, i)], name=f"link_{idx}_{i}")
    
    # Objective: minimize total area used + setup penalties
    total_area_expr = gp.LinExpr()
    setup_penalty_expr = gp.LinExpr()
    
    for idx, data in patterns_by_std_width.items():
        sw = data['sw']
        for i, pattern in enumerate(data['patterns']):
            total_area_expr += sw * x_vars[(idx, i)]
            base_penalty = pattern_setup_penalty
            if sw >= wide_roll_threshold:
                base_penalty += wide_roll_extra_penalty
            setup_penalty_expr += base_penalty * y_vars[(idx, i)]
    
    model.setObjective(total_area_expr + setup_penalty_expr, GRB.MINIMIZE)
    
    # Constraints: satisfy length requirements for each order
    for j in range(n_orders):
        demand_expr = gp.LinExpr()
        for idx, data in patterns_by_std_width.items():
            for i, pattern in enumerate(data['patterns']):
                demand_expr += pattern[j] * x_vars[(idx, i)]
        model.addConstr(demand_expr >= lengths[j], name=f"demand_{j}")
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        total_area_used = model.ObjVal
        waste = total_area_used - total_required_area
        print(f"FINAL_OBJ_VALUE: {waste}")
    else:
        # In case of no optimal solution, fallback to a large number or error
        # But per problem statement, we assume feasible
        print("FINAL_OBJ_VALUE: inf")

if __name__ == "__main__":
    main()
