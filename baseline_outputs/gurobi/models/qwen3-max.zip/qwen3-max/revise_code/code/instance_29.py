import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def main():
    # Load data
    demand_df = pd.read_csv(get_data_path('table_4_3.csv'))
    supply_df = pd.read_csv(get_data_path('table_4_4.csv'))
    params_df = pd.read_csv(get_data_path('general_parameters.csv'))
    
    # Parse parameters
    p2_target = int(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])
    
    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]
        spec = int(row['Specialty'])
        dem = int(row['Demand'])
        demand[(city, spec)] = dem
        
    # Parse supply
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = int(row['Number_of_People'])
        suit = [int(x) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }
        
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]
    
    # Create model
    model = gp.Model("Revised_Jieli_Staffing")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i, j, k] = number of type i assigned to city j in specialty k
    x = {}
    for i in types:
        for j in cities:
            for k in specs:
                if k in supply[i]['suit']:
                    x[i, j, k] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}_{k}")
                else:
                    x[i, j, k] = 0  # Not allowed
    
    # Objective: maximize number of recruits with both preferred specialty and preferred city
    obj_expr = gp.LinExpr()
    for i in types:
        pref_spec = supply[i]['pref_spec']
        pref_city = supply[i]['pref_city']
        if (i, pref_city, pref_spec) in x:
            obj_expr += x[i, pref_city, pref_spec]
    model.setObjective(obj_expr, GRB.MAXIMIZE)
    
    # Constraint: Priority 1 - meet all demands
    for j in cities:
        for k in specs:
            model.addConstr(gp.quicksum(x[i, j, k] for i in types if (i, j, k) in x) >= demand[(j, k)], 
                           name=f"demand_{j}_{k}")
    
    # Constraint: do not exceed available applicants per type
    for i in types:
        model.addConstr(gp.quicksum(x[i, j, k] for j in cities for k in specs if (i, j, k) in x) <= supply[i]['num'], 
                       name=f"supply_{i}")
    
    # Constraint: Priority 2 - at least p2_target people get their preferred specialty
    p2_expr = gp.LinExpr()
    for i in types:
        pref_spec = supply[i]['pref_spec']
        for j in cities:
            if (i, j, pref_spec) in x:
                p2_expr += x[i, j, pref_spec]
    model.addConstr(p2_expr >= p2_target, name="priority2_min")
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        final_obj = int(model.objVal)
    else:
        final_obj = 0  # In case no solution found, though problem should be feasible
    
    print(f"FINAL_OBJ_VALUE: {final_obj}")

if __name__ == '__main__':
    main()
