import os
import sys
from gurobipy import GRB
import gurobipy as gp

def load_csv(filename):
    """Load a CSV file and return headers and rows."""
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        lines = f.readlines()
        headers = lines[0].strip().split(',')
        rows = []
        for line in lines[1:]:
            rows.append(line.strip().split(','))
    return headers, rows

def load_general_parameters(filename='general_parameters.csv'):
    """Load general parameters into a dictionary."""
    headers, rows = load_csv(filename)
    params = {}
    for row in rows:
        name = row[0].strip()
        try:
            value = float(row[1].strip())
        except ValueError:
            value = row[1].strip()
        params[name] = value
    return params

def load_crop_data(filename='table_1.csv'):
    """Load crop data from table_1.csv."""
    headers, rows = load_csv(filename)
    crops = [h.strip() for h in headers[1:]]
    data = {}
    for row in rows:
        item = row[0].strip()
        values = [float(v.strip()) for v in row[1:]]
        data[item] = dict(zip(crops, values))
    return crops, data

def main():
    # Load data
    params = load_general_parameters()
    crops, crop_data = load_crop_data()
    
    # Extract parameters
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']
    
    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = params['max_chickens']
    max_dairy_cows = params['max_dairy_cows']
    
    fixed_cost_chicken_setup = params['fixed_cost_chicken_setup']
    min_chickens_if_coop_open = params['min_chickens_if_coop_open']
    second_biosecurity_threshold = params['second_biosecurity_threshold']
    second_biosecurity_cost = params['second_biosecurity_cost']
    biosecurity_training_aw_days = params['biosecurity_training_aw_days']
    biosecurity_training_ss_days = params['biosecurity_training_ss_days']
    
    # Crop data
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']
    
    # Create model
    model = gp.Model("Farm_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # Crop areas
    x = {}
    for c in crops:
        x[c] = model.addVar(lb=0, name=f"x_{c}")
    
    # Number of dairy cows and chickens
    y_dairy = model.addVar(lb=0, ub=max_dairy_cows, name="dairy_cows")
    y_chicken = model.addVar(lb=0, ub=max_chickens, name="chickens")
    
    # Binary variables for chicken coop decisions
    z_open = model.addVar(vtype=GRB.BINARY, name="coop_open")  # 1 if any chickens are raised
    z_large = model.addVar(vtype=GRB.BINARY, name="large_flock")  # 1 if flock >= second_biosecurity_threshold
    
    # Surplus labor for external work
    surplus_aw = model.addVar(lb=0, name="surplus_aw")
    surplus_ss = model.addVar(lb=0, name="surplus_ss")
    
    # Constraints for chicken coop logic
    # If coop is not open, then chickens must be 0
    model.addConstr(y_chicken <= max_chickens * z_open, "coop_open_implies_chickens")
    
    # If coop is open, then chickens must be at least min_chickens_if_coop_open
    model.addConstr(y_chicken >= min_chickens_if_coop_open * z_open, "min_chickens_if_open")
    
    # Link large flock binary: if y_chicken >= second_biosecurity_threshold, then z_large = 1
    model.addConstr(y_chicken <= second_biosecurity_threshold - 1 + (max_chickens - second_biosecurity_threshold + 1) * z_large, "large_flock_upper")
    model.addConstr(y_chicken >= second_biosecurity_threshold * z_large, "large_flock_lower")
    
    # Land constraint
    model.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, "Land")
    
    # Funds constraint: includes fixed costs for chicken setup and second biosecurity
    model.addConstr(
        inv_dairy * y_dairy + inv_chicken * y_chicken + 
        fixed_cost_chicken_setup * z_open + second_biosecurity_cost * z_large <= funds_available, 
        "Funds"
    )
    
    # Labor autumn/winter constraint: includes training if coop is open
    model.addConstr(
        gp.quicksum(crop_aw[c] * x[c] for c in crops) + 
        labor_aw_dairy * y_dairy + labor_aw_chicken * y_chicken + 
        biosecurity_training_aw_days * z_open + surplus_aw <= labor_aw, 
        "Labor_AW"
    )
    
    # Labor spring/summer constraint: includes training if coop is open
    model.addConstr(
        gp.quicksum(crop_ss[c] * x[c] for c in crops) + 
        labor_ss_dairy * y_dairy + labor_ss_chicken * y_chicken + 
        biosecurity_training_ss_days * z_open + surplus_ss <= labor_ss, 
        "Labor_SS"
    )
    
    # Objective: maximize net income from crops + animals + external work - fixed costs
    obj = (
        gp.quicksum(crop_income[c] * x[c] for c in crops) + 
        income_dairy * y_dairy + income_chicken * y_chicken + 
        ext_rate_aw * surplus_aw + ext_rate_ss * surplus_ss -
        fixed_cost_chicken_setup * z_open - second_biosecurity_cost * z_large
    )
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        obj_val = 0.0
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
