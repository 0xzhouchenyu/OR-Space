import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    warehouse_capacity = int(params['warehouse_capacity'])
    initial_stock = int(params['initial_stock'])
    fixed_order_cost = params['fixed_order_cost']
    august_bulk_order_threshold = int(params['august_bulk_order_threshold'])
    august_bulk_receiving_fee = params['august_bulk_receiving_fee']
    
    # Load monthly data
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
    
    # Create Gurobi model
    model = gp.Model("MaxRevenue")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    buy = {}
    sell = {}
    stock = {}
    order_indicator = {}  # Binary variable: 1 if any purchase in month m, else 0
    august_bulk_indicator = model.addVar(vtype=GRB.BINARY, name="august_bulk_indicator")
    
    for m in months:
        buy[m] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"buy_{m}")
        sell[m] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"sell_{m}")
        stock[m] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=warehouse_capacity, name=f"stock_{m}")
        order_indicator[m] = model.addVar(vtype=GRB.BINARY, name=f"order_indicator_{m}")
    
    # Objective: maximize total profit (revenue - cost - fixed costs - august bulk fee)
    objective = gp.quicksum(sell_price[m] * sell[m] - buy_price[m] * buy[m] for m in months)
    objective -= fixed_order_cost * gp.quicksum(order_indicator[m] for m in months)
    objective -= august_bulk_receiving_fee * august_bulk_indicator
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Stock balance constraints
    for i, m in enumerate(months):
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_stock = stock[months[i-1]]
        
        # Stock balance: stock[m] = prev_stock + buy[m] - sell[m]
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m], f"balance_{m}")
        
        # After buying, before selling, warehouse constraint:
        # prev_stock + buy[m] <= warehouse_capacity
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity, f"warehouse_after_buy_{m}")
    
    # Link buy and order_indicator: if buy[m] > 0 then order_indicator[m] = 1
    # Use a big-M constraint. Since warehouse capacity is 500 and initial stock is 200,
    # the maximum we can buy in a month is warehouse_capacity (since prev_stock >=0, so buy <= warehouse_capacity)
    M = warehouse_capacity
    for m in months:
        model.addConstr(buy[m] <= M * order_indicator[m], f"order_link_{m}")
    
    # August bulk receiving constraint
    august = 8
    # If buy[8] > 300, then august_bulk_indicator must be 1
    # We use: buy[8] <= 300 + M2 * august_bulk_indicator
    # Choose M2 as warehouse_capacity (max possible buy in August)
    M2 = warehouse_capacity
    model.addConstr(buy[august] <= august_bulk_order_threshold + M2 * august_bulk_indicator, "august_bulk_constraint")
    
    # Solve
    model.optimize()
    
    # Print final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of no solution, output 0 or handle appropriately
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
