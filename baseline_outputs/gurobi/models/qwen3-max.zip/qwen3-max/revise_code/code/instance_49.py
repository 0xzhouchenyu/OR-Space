import pandas as pd
import os
import gurobipy as gp
from gurobipy import GRB

def get_data_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

def main():
    # Load data
    table_1 = pd.read_csv(get_data_path('table_1.csv'))
    table_2 = pd.read_csv(get_data_path('table_2.csv'))
    params_df = pd.read_csv(get_data_path('general_parameters.csv'))

    # Parse parameters
    param_dict = dict(zip(params_df['Parameter_Name'], params_df['Value']))
    min_contract_types = int(param_dict['min_contract_types'])
    max_contract_types = int(param_dict['max_contract_types'])
    mutual_exclusion = str(param_dict['mutual_exclusion_1_and_4']).strip().lower() == 'true'
    monthly_max_parallel_contracts = int(param_dict['monthly_max_parallel_contracts'])
    min_area_per_contract_units = float(param_dict['min_area_per_contract_units'])
    activation_fee_per_contract = float(param_dict['activation_fee_per_contract'])
    onboarding_loss_units = float(param_dict['onboarding_loss_units'])
    expedited_onboarding_fee = float(param_dict['expedited_onboarding_fee'])

    # Convert required area to units of 100 ㎡
    demands = {int(row['Month']): float(row['Required_area_㎡']) / 100.0 for _, row in table_1.iterrows()}
    costs = {int(row['Contract_length_months']): float(row['Rental_fee_per_100㎡_yuan']) for _, row in table_2.iterrows()}

    months = sorted(demands.keys())
    max_month = max(months)
    contract_lengths = sorted(costs.keys())

    # Create model
    model = gp.Model("Warehouse_Rental")
    model.setParam('OutputFlag', 0)

    # Decision variables
    # x[i, j] = number of 100 sqm units rented starting at month i for j months (integer >=0)
    x = {}
    for i in months:
        for j in contract_lengths:
            if i + j - 1 <= max_month:
                x[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}_{j}")

    # y[j] = 1 if contract length j is used, 0 otherwise (binary)
    y = {}
    for j in contract_lengths:
        y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")

    # z[i, j] = 1 if expedited onboarding is bought for a contract starting at month i with length j, 0 otherwise (binary)
    z = {}
    for (i, j) in x:
        z[i, j] = model.addVar(vtype=GRB.BINARY, name=f"z_{i}_{j}")

    # w[i, j] = number of contracts (not area units) starting at month i with length j (integer >=0)
    # Since each contract must have at least min_area_per_contract_units, we have: x[i,j] >= min_area_per_contract_units * w[i,j]
    w = {}
    for (i, j) in x:
        w[i, j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"w_{i}_{j}")

    model.update()

    # Objective: Minimize total cost = rental cost + activation fees + expedited onboarding fees
    rental_cost = gp.quicksum(costs[j] * x[i, j] for (i, j) in x)
    activation_cost = gp.quicksum(activation_fee_per_contract * w[i, j] for (i, j) in w)
    expedited_cost = gp.quicksum(expedited_onboarding_fee * z[i, j] for (i, j) in z)
    model.setObjective(rental_cost + activation_cost + expedited_cost, GRB.MINIMIZE)

    # Constraints
    # 1. Demand fulfillment for each month
    for m in months:
        # For each contract (i,j) that covers month m: 
        #   if m == i (start month): usable area = x[i,j] - onboarding_loss_units * (number of contracts without expedited)
        #   But note: we don't have per-contract area, so we model the loss as: 
        #   usable area in start month = x[i,j] - onboarding_loss_units * (w[i,j] - z[i,j])
        # However, the problem states: "Every newly opened contract loses `onboarding_loss_units` units ... unless expedited"
        # So for a contract starting at i, in month i: available area = x[i,j] - onboarding_loss_units * (w[i,j] - z[i,j])
        # But note: x[i,j] is the total area (in 100 sqm units) for contracts starting at i with length j.
        # And w[i,j] is the number of such contracts. We must have x[i,j] >= min_area_per_contract_units * w[i,j].
        #
        # The total available area in month m is:
        #   Sum over all (i,j) covering m: 
        #       if m == i: x[i,j] - onboarding_loss_units * (w[i,j] - z[i,j])
        #       else: x[i,j]
        expr = gp.LinExpr()
        for (i, j) in x:
            if i <= m <= i + j - 1:
                if m == i:
                    expr += x[i, j] - onboarding_loss_units * (w[i, j] - z[i, j])
                else:
                    expr += x[i, j]
        model.addConstr(expr == demands[m], name=f"demand_month_{m}")

    # 2. Link x and w: minimum area per contract
    for (i, j) in x:
        model.addConstr(x[i, j] >= min_area_per_contract_units * w[i, j], name=f"min_area_{i}_{j}")
        # Also, if w[i,j] > 0 then x[i,j] > 0, but the above constraint and non-negativity should handle it.

    # 3. Link w to y: if any contract of length j is used, then y[j]=1
    M_w = sum(demands.values())  # big-M for number of contracts (overestimate)
    for j in contract_lengths:
        # Sum of w[i,j] over i <= M_w * y[j]
        model.addConstr(gp.quicksum(w[i, j] for i in months if (i, j) in w) <= M_w * y[j], name=f"link_w_y_upper_{j}")
        # If y[j]=1, then at least one contract of length j must be used (but note: we have min_contract_types constraint, so this might be redundant, but safe)
        # However, the problem doesn't require that if y[j]=1 then there is a contract, but our linking from w to y is only one way.
        # Actually, we want: if there is any contract of length j, then y[j]=1. The above constraint does that.
        # We don't need the reverse because the objective will not set y[j]=1 unnecessarily.

    # 4. Contract types limits
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) >= min_contract_types, name="min_contract_types")
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) <= max_contract_types, name="max_contract_types")

    # 5. Mutual exclusion between 1-month and 4-month contracts
    if mutual_exclusion:
        if 1 in y and 4 in y:
            model.addConstr(y[1] + y[4] <= 1, name="mutual_exclusion")

    # 6. Maximum active contracts in any month
    for m in months:
        active_contracts = gp.quicksum(w[i, j] for (i, j) in w if i <= m <= i + j - 1)
        model.addConstr(active_contracts <= monthly_max_parallel_contracts, name=f"max_parallel_{m}")

    # 7. Expedited onboarding can only be bought if there is a contract
    for (i, j) in x:
        model.addConstr(z[i, j] <= w[i, j], name=f"expedited_implies_contract_{i}_{j}")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of no solution, but the problem should be feasible
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
