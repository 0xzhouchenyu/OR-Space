import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(data_path)
    
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = row['Value']
        
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = int(params['raw_bar_length'])
    setup_cost_per_pattern = float(params['setup_cost_per_pattern'])
    max_distinct_patterns = int(params['max_distinct_patterns'])
    
    # Lengths of the three types of steel bars
    len1, len2, len3 = 3, 4, 5
    
    # Generate all valid cutting patterns
    patterns = []
    for x in range(L // len1 + 1):
        for y in range(L // len2 + 1):
            for z in range(L // len3 + 1):
                if len1 * x + len2 * y + len3 * z <= L:
                    if x > 0 or y > 0 or z > 0:
                        patterns.append((x, y, z))
    
    num_patterns = len(patterns)
    
    # Create Gurobi model
    model = gp.Model("CuttingStockRevised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: number of times each pattern is used (non-negative integers)
    use_pattern = model.addVars(num_patterns, vtype=GRB.INTEGER, name="use_pattern")
    
    # Binary variables: whether a pattern is used at all
    is_used = model.addVars(num_patterns, vtype=GRB.BINARY, name="is_used")
    
    # Linking constraints: if a pattern is used, then is_used must be 1
    for i in range(num_patterns):
        model.addConstr(use_pattern[i] <= 1000000 * is_used[i], name=f"link_{i}")
    
    # Constraint: maximum number of distinct patterns
    model.addConstr(gp.quicksum(is_used[i] for i in range(num_patterns)) <= max_distinct_patterns, name="max_patterns")
    
    # Demand constraints
    model.addConstr(gp.quicksum(patterns[i][0] * use_pattern[i] for i in range(num_patterns)) >= q3, name="demand_3m")
    model.addConstr(gp.quicksum(patterns[i][1] * use_pattern[i] for i in range(num_patterns)) >= q4, name="demand_4m")
    model.addConstr(gp.quicksum(patterns[i][2] * use_pattern[i] for i in range(num_patterns)) >= q5, name="demand_5m")
    
    # Objective: minimize total waste
    # Total raw material used: L * sum(use_pattern[i])
    # Total required length: 3*q3 + 4*q4 + 5*q5
    # Setup cost: setup_cost_per_pattern * sum(is_used[i])
    total_raw = L * gp.quicksum(use_pattern[i] for i in range(num_patterns))
    total_required = 3*q3 + 4*q4 + 5*q5
    setup_waste = setup_cost_per_pattern * gp.quicksum(is_used[i] for i in range(num_patterns))
    
    model.setObjective(total_raw - total_required + setup_waste, GRB.MINIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case no optimal solution found, we try to get the best bound or set a large value
        obj_val = float('inf')
        if model.SolCount > 0:
            obj_val = model.objVal
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    solve()
