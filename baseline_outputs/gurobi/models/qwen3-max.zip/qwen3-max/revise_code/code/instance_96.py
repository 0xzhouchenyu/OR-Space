import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")
    
    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    params = {}
    for _, row in df_params.iterrows():
        params[row['Parameter_Name']] = row['Value']
    
    # Supplier 1 parameters
    L1 = float(params['raw_pipe_length_supplier1'])
    max_patterns1 = int(params['max_cutting_patterns_supplier1'])
    max_cuts1 = int(params['max_cuts_per_pipe_supplier1'])
    max_leftover1 = float(params['max_leftover_length_supplier1'])
    min_length1 = L1 - max_leftover1
    cost_rates1 = [
        float(params['most_frequent_pattern_cost_rate_supplier1']),
        float(params['second_frequent_pattern_cost_rate_supplier1']),
        float(params['third_frequent_pattern_cost_rate_supplier1'])
    ]
    purchase_cost1 = float(params['purchase_cost_per_pipe_supplier1'])
    discount_tier1_max_qty = int(params['discount_tier1_supplier1_max_qty'])
    fixed_discount = float(params['fixed_discount_tier2_supplier1'])
    bigM_discount = int(params['bigM_discount'])
    
    # Supplier 2 parameters
    L2 = float(params['raw_pipe_length_supplier2'])
    max_patterns2 = int(params['max_cutting_patterns_supplier2'])
    max_cuts2 = int(params['max_cuts_per_pipe_supplier2'])
    max_leftover2 = float(params['max_leftover_length_supplier2'])
    min_length2 = L2 - max_leftover2
    cost_rates2 = [
        float(params['most_frequent_pattern_cost_rate_supplier2']),
        float(params['second_frequent_pattern_cost_rate_supplier2']),
        float(params['third_frequent_pattern_cost_rate_supplier2'])
    ]
    purchase_cost2 = float(params['purchase_cost_per_pipe_supplier2'])
    
    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)
    
    # Generate patterns for supplier 1
    patterns1 = []
    def generate_patterns_s1(current_pattern, current_length, current_cuts, item_idx):
        if item_idx == n_items:
            if current_length >= min_length1 and current_length <= L1 and current_cuts > 0:
                patterns1.append(tuple(current_pattern))
            return
        
        max_qty = min(
            int((L1 - current_length) // lengths[item_idx]),
            max_cuts1 - current_cuts
        )
        
        for q in range(max_qty + 1):
            generate_patterns_s1(
                current_pattern + [q],
                current_length + q * lengths[item_idx],
                current_cuts + q,
                item_idx + 1
            )
    
    generate_patterns_s1([], 0, 0, 0)
    
    # Generate patterns for supplier 2
    patterns2 = []
    def generate_patterns_s2(current_pattern, current_length, current_cuts, item_idx):
        if item_idx == n_items:
            if current_length >= min_length2 and current_length <= L2 and current_cuts > 0:
                patterns2.append(tuple(current_pattern))
            return
        
        max_qty = min(
            int((L2 - current_length) // lengths[item_idx]),
            max_cuts2 - current_cuts
        )
        
        for q in range(max_qty + 1):
            generate_patterns_s2(
                current_pattern + [q],
                current_length + q * lengths[item_idx],
                current_cuts + q,
                item_idx + 1
            )
    
    generate_patterns_s2([], 0, 0, 0)
    
    # Create model
    model = gp.Model("Revised_Pipe_Cutting")
    model.setParam('OutputFlag', 0)
    
    # Variables for supplier 1
    y1 = model.addVars(len(patterns1), vtype=GRB.INTEGER, name="y1", lb=0)
    z1 = model.addVars(len(patterns1), vtype=GRB.BINARY, name="z1")
    u1 = model.addVars(1, max_patterns1+1, vtype=GRB.BINARY, name="u1")
    
    # Variables for supplier 2
    y2 = model.addVars(len(patterns2), vtype=GRB.INTEGER, name="y2", lb=0)
    z2 = model.addVars(len(patterns2), vtype=GRB.BINARY, name="z2")
    u2 = model.addVars(1, max_patterns2+1, vtype=GRB.BINARY, name="u2")
    
    # Discount variables for supplier 1
    total_pipes1 = model.addVar(vtype=GRB.INTEGER, name="total_pipes1", lb=0)
    discount_active = model.addVar(vtype=GRB.BINARY, name="discount_active")
    
    # Link total_pipes1 to y1
    model.addConstr(total_pipes1 == gp.quicksum(y1[p] for p in range(len(patterns1))), "total_pipes1_def")
    
    # Discount constraints
    model.addConstr(total_pipes1 <= discount_tier1_max_qty + bigM_discount * discount_active, "discount_upper")
    model.addConstr(total_pipes1 >= discount_tier1_max_qty + 1 - bigM_discount * (1 - discount_active), "discount_lower")
    
    # Demand constraints
    for i in range(n_items):
        model.addConstr(
            gp.quicksum(patterns1[p][i] * y1[p] for p in range(len(patterns1))) +
            gp.quicksum(patterns2[p][i] * y2[p] for p in range(len(patterns2))) >= demands[i],
            f"demand_{i}"
        )
    
    # Link y and z for supplier 1
    M1 = sum(demands)
    for p in range(len(patterns1)):
        model.addConstr(y1[p] <= M1 * z1[p], f"link_y1_z1_{p}")
    
    # Link y and z for supplier 2
    M2 = sum(demands)
    for p in range(len(patterns2)):
        model.addConstr(y2[p] <= M2 * z2[p], f"link_y2_z2_{p}")
    
    # Number of patterns used for supplier 1
    model.addConstr(gp.quicksum(z1[p] for p in range(len(patterns1))) == gp.quicksum(u1[k] for k in range(1, max_patterns1+1)), "patterns_used1")
    model.addConstr(gp.quicksum(z1[p] for p in range(len(patterns1))) <= max_patterns1, "max_patterns1")
    
    # Ordering constraints for u1 (to ensure u1[1] >= u1[2] >= ...)
    for k in range(1, max_patterns1):
        model.addConstr(u1[k] >= u1[k+1], f"order_u1_{k}")
    
    # Number of patterns used for supplier 2
    model.addConstr(gp.quicksum(z2[p] for p in range(len(patterns2))) == gp.quicksum(u2[k] for k in range(1, max_patterns2+1)), "patterns_used2")
    model.addConstr(gp.quicksum(z2[p] for p in range(len(patterns2))) <= max_patterns2, "max_patterns2")
    
    # Ordering constraints for u2
    for k in range(1, max_patterns2):
        model.addConstr(u2[k] >= u2[k+1], f"order_u2_{k}")
    
    # Objective: raw pipe costs + pattern cost rates - discount
    raw_cost = purchase_cost1 * total_pipes1 + purchase_cost2 * gp.quicksum(y2[p] for p in range(len(patterns2)))
    
    pattern_cost1 = gp.quicksum(cost_rates1[k-1] * u1[k] for k in range(1, min(max_patterns1, len(cost_rates1)) + 1))
    pattern_cost2 = gp.quicksum(cost_rates2[k-1] * u2[k] for k in range(1, min(max_patterns2, len(cost_rates2)) + 1))
    
    total_cost = raw_cost + pattern_cost1 + pattern_cost2 - fixed_discount * discount_active
    
    model.setObjective(total_cost, GRB.MINIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case no solution found, try to get best bound or set to a large number
        obj_val = model.objBound if model.objBound is not None else float('inf')
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
