import os
import csv
from utils import load_parameters
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

a1 = params['a1']
a2 = params['a2']
training_capacity_per_jet = params['training_capacity_per_jet']
training_duration = params['training_duration']
dual_use_training_efficiency = params['dual_use_training_efficiency']
training_intensity_cap = params['training_intensity_cap']
combat_jet_min_year2 = params['combat_jet_min_year2']
combat_weight = params['combat_weight']
training_weight = params['training_weight']

# Total jets available each year
total_jets_year1 = a1
total_jets_year2 = a1 + a2  # Year 1 jets carry over to year 2

# Create model
model = gp.Model("Fighter_Jet_Allocation")

# Decision variables for Year 1
train_only_y1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="train_only_y1")
dual_use_y1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="dual_use_y1")
combat_y1 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="combat_y1")

# Decision variables for Year 2
train_only_y2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="train_only_y2")
dual_use_y2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="dual_use_y2")
combat_y2 = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="combat_y2")

# Jet balance constraints
model.addConstr(train_only_y1 + dual_use_y1 + combat_y1 == total_jets_year1, "Year1_Jet_Balance")
model.addConstr(train_only_y2 + dual_use_y2 + combat_y2 == total_jets_year2, "Year2_Jet_Balance")

# Training intensity cap: training-only + dual-use <= training_intensity_cap * total fleet in each year
model.addConstr(train_only_y1 + dual_use_y1 <= training_intensity_cap * total_jets_year1, "Training_Intensity_Year1")
model.addConstr(train_only_y2 + dual_use_y2 <= training_intensity_cap * total_jets_year2, "Training_Intensity_Year2")

# Minimum combat jets in year 2
model.addConstr(combat_y2 >= combat_jet_min_year2, "Min_Combat_Year2")

# Training pipeline: pilots trained in year 1 and year 2
# Each training-only jet trains `training_capacity_per_jet` pilots per year
# Each dual-use jet trains `dual_use_training_efficiency * training_capacity_per_jet` pilots per year
pilots_trained_y1 = training_capacity_per_jet * train_only_y1 + dual_use_training_efficiency * training_capacity_per_jet * dual_use_y1
pilots_trained_y2 = training_capacity_per_jet * train_only_y2 + dual_use_training_efficiency * training_capacity_per_jet * dual_use_y2

# Total trained pilots (since training duration is 2 years, but we are only planning 2 years,
# and pilots trained in year 1 and year 2 are both counted as they complete training within the horizon)
total_pilots = pilots_trained_y1 + pilots_trained_y2

# Objective: maximize combat_weight * combat_y2 + training_weight * total_pilots
model.setObjective(combat_weight * combat_y2 + training_weight * total_pilots, GRB.MAXIMIZE)

# Solve
model.setParam('OutputFlag', 0)
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: None")
