import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    t1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    t2 = pd.read_csv(os.path.join(data_dir, 'table_2.csv'))
    t3 = pd.read_csv(os.path.join(data_dir, 'table_3.csv'))
    gp_df = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    
    # Merge product data
    df = t1.merge(t2, on='Product').merge(t3, on='Product')
    
    # Parse general parameters
    params = {}
    for _, row in gp_df.iterrows():
        params[row['Parameter_Name']] = float(row['Value'])
    
    return df, params

def solve():
    df, params = load_data()
    
    # Extract general parameters
    production_days = params['production_days']
    a1_watch_threshold = params['a1_watch_threshold']
    a1_deep_service_threshold = params['a1_deep_service_threshold']
    maintenance_penalty_watch = params['maintenance_penalty_watch']
    maintenance_penalty_deep = params['maintenance_penalty_deep']
    a1_quality_release_fee = params['a1_quality_release_fee']
    a1_deep_service_fee = params['a1_deep_service_fee']
    a1_priority_price_lift = params['a1_priority_price_lift']
    
    # Create model
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    # Product list
    products = df['Product'].tolist()
    
    # Decision variables
    x = {}  # production quantity for each product
    y = {}  # binary activation variable for each product
    for p in products:
        x[p] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"x_{p}")
        y[p] = model.addVar(vtype=GRB.BINARY, name=f"y_{p}")
    
    # Additional binary variables for A1 thresholds
    z1 = model.addVar(vtype=GRB.BINARY, name="z1")  # 1 if A1 >= watch threshold
    z2 = model.addVar(vtype=GRB.BINARY, name="z2")  # 1 if A1 >= deep service threshold
    
    # Variables for A1 above thresholds
    a1_above_watch = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="a1_above_watch")
    a1_above_deep = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="a1_above_deep")
    
    # Link a1_above_watch and a1_above_deep to x['A1']
    model.addConstr(a1_above_watch <= x['A1'] - a1_watch_threshold + (1 - z1) * 1e6, "above_watch_ub")
    model.addConstr(a1_above_watch >= 0, "above_watch_lb")
    model.addConstr(a1_above_watch <= z1 * 1e6, "above_watch_link")
    
    model.addConstr(a1_above_deep <= x['A1'] - a1_deep_service_threshold + (1 - z2) * 1e6, "above_deep_ub")
    model.addConstr(a1_above_deep >= 0, "above_deep_lb")
    model.addConstr(a1_above_deep <= z2 * 1e6, "above_deep_link")
    
    # Threshold logic: z2 implies z1
    model.addConstr(z2 <= z1, "threshold_order")
    
    # If x['A1'] < watch threshold, then z1 = 0
    model.addConstr(x['A1'] <= a1_watch_threshold + (1 - z1) * 1e6, "watch_threshold_upper")
    # If x['A1'] >= watch threshold, then z1 = 1 (enforced by objective and other constraints, but we add a constraint for safety)
    model.addConstr(x['A1'] >= a1_watch_threshold * z1, "watch_threshold_lower")
    
    # If x['A1'] < deep service threshold, then z2 = 0
    model.addConstr(x['A1'] <= a1_deep_service_threshold + (1 - z2) * 1e6, "deep_threshold_upper")
    # If x['A1'] >= deep service threshold, then z2 = 1
    model.addConstr(x['A1'] >= a1_deep_service_threshold * z2, "deep_threshold_lower")
    
    # Activation constraints: the problem states all three products must be produced
    for p in products:
        model.addConstr(y[p] == 1, f"activate_{p}")
    
    # Demand and batch constraints
    for _, row in df.iterrows():
        p = row['Product']
        model.addConstr(x[p] <= row['Maximum_Demand'] * y[p], f"demand_{p}")
        model.addConstr(x[p] >= row['Minimum_Batch'] * y[p], f"min_batch_{p}")
    
    # Production days constraint with penalties
    total_days = gp.quicksum(x[row['Product']] / row['Production_Quota'] for _, row in df.iterrows())
    total_days += maintenance_penalty_watch * z1 + maintenance_penalty_deep * z2
    model.addConstr(total_days <= production_days, "production_days")
    
    # Objective function
    profit = 0
    for _, row in df.iterrows():
        p = row['Product']
        if p == 'A1':
            # Base profit for A1: (Selling_Price - Production_Cost) * x[A1]
            base_profit = (row['Selling_Price'] - row['Production_Cost']) * x[p]
            # Plus priority uplift for units above watch threshold
            uplift_profit = a1_priority_price_lift * a1_above_watch
            profit += base_profit + uplift_profit - row['Activation_Cost'] * y[p]
        else:
            profit += (row['Selling_Price'] - row['Production_Cost']) * x[p] - row['Activation_Cost'] * y[p]
    
    # Subtract additional fees for A1 thresholds
    profit -= a1_quality_release_fee * z1
    profit -= a1_deep_service_fee * z2
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        return model.objVal
    else:
        raise Exception("Optimization failed")

if __name__ == "__main__":
    obj_val = solve()
    print(f"FINAL_OBJ_VALUE: {obj_val}")
