import os
import csv
from gurobipy import GRB, Model
import gurobipy as gp


def load_distance_matrix(filepath):
    """Load distance matrix from CSV file.
    
    Returns:
        cities: list of city labels
        dist: 2D list of distances (dist[i][j] = distance from city i to city j)
    """
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        city_labels = header[1:]
        
        dist = []
        cities = []
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
    
    return cities, dist


def load_general_parameters(filepath):
    """Load general parameters from CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['parameter']] = row['value']
    return params


def main():
    # Set up file paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    dist_file = os.path.join(data_dir, "table_1.csv")
    param_file = os.path.join(data_dir, "general_parameters.csv")
    
    # Load data
    cities, dist = load_distance_matrix(dist_file)
    params = load_general_parameters(param_file)
    
    # Map city names to indices
    city_to_index = {city: idx for idx, city in enumerate(cities)}
    
    # Parse parameters
    start_city_name = params['start_city']
    end_city_name = params['end_city']
    prohibited_from_name = params['prohibited_from']
    prohibited_to_name = params['prohibited_to']
    inspection_arc_from_name = params['inspection_arc_from']
    inspection_arc_to_name = params['inspection_arc_to']
    inspection_stop_cost = float(params['inspection_stop_cost'])
    
    start_idx = city_to_index[start_city_name]
    end_idx = city_to_index[end_city_name]
    prohibited_from_idx = city_to_index[prohibited_from_name]
    prohibited_to_idx = city_to_index[prohibited_to_name]
    inspection_from_idx = city_to_index[inspection_arc_from_name]
    inspection_to_idx = city_to_index[inspection_arc_to_name]
    
    n = len(cities)
    
    # Create model
    model = Model("Revised_TSP")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: x[i,j] = 1 if travel from i to j
    x = {}
    for i in range(n):
        for j in range(n):
            if i != j:
                x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
    
    # MTZ variables for subtour elimination (u[i] for i=1..n-1, but we'll use for all except start)
    u = {}
    for i in range(n):
        if i != start_idx:
            u[i] = model.addVar(vtype=GRB.CONTINUOUS, lb=1, ub=n-1, name=f"u_{i}")
    
    # Objective: minimize total distance + inspection cost
    obj_expr = gp.LinExpr()
    for i in range(n):
        for j in range(n):
            if i != j:
                cost = dist[i][j]
                # Add inspection cost if this arc is the special one
                if i == inspection_from_idx and j == inspection_to_idx:
                    cost += inspection_stop_cost
                obj_expr += cost * x[i, j]
    model.setObjective(obj_expr, GRB.MINIMIZE)
    
    # Constraint: start at start_city
    model.addConstr(gp.quicksum(x[start_idx, j] for j in range(n) if j != start_idx) == 1, "Start_departure")
    
    # Constraint: end at end_city
    model.addConstr(gp.quicksum(x[i, end_idx] for i in range(n) if i != end_idx) == 1, "End_arrival")
    
    # Each city (except start and end?) must be entered and left exactly once?
    # But note: in TSP we visit each city exactly once, so every city must have in-degree=1 and out-degree=1
    for i in range(n):
        # Outgoing edges
        model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1, f"Out_{i}")
        # Incoming edges
        model.addConstr(gp.quicksum(x[j, i] for j in range(n) if j != i) == 1, f"In_{i}")
    
    # Prohibition: cannot go directly from prohibited_from to prohibited_to
    if (prohibited_from_idx, prohibited_to_idx) in x:
        model.addConstr(x[prohibited_from_idx, prohibited_to_idx] == 0, "Prohibition")
    
    # MTZ subtour elimination constraints
    for i in range(n):
        if i == start_idx:
            continue
        for j in range(n):
            if j == start_idx or i == j:
                continue
            model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1, f"MTZ_{i}_{j}")
    
    # Special handling: since we have fixed start and end, but TSP normally returns to start.
    # However, the problem says: "departing from a certain city ... and returning to the original starting city"
    # BUT the revision says: "The start at city 1, the end at city 4"
    # This is a contradiction. Let's re-read:
    # Original: "returning to the original starting city"
    # Revision: "The start at city 1, the end at city 4"
    
    # Clarification: The revision states "the start at city 1, the end at city 4", which implies it's not a cycle?
    # However, the original TSP is a cycle. But the revision changes it to a path from 1 to 4?
    
    # Looking at the revision: "The start at city 1, the end at city 4, and the direct 1-to-3 prohibition remain unchanged."
    # This suggests that the problem is now an open TSP: start at 1, end at 4, visit all cities exactly once, without returning to start.
    
    # Therefore, we should NOT have the return to start. So the constraints are:
    # - Start city (1) has out-degree 1, in-degree 0? 
    # - End city (4) has in-degree 1, out-degree 0?
    # - All other cities have in-degree 1 and out-degree 1.
    
    # But wait: the original problem says "returning to the original starting city", but the revision overrides that by specifying start and end.
    # The revision brief says: "The start at city 1, the end at city 4 ... remain unchanged", meaning that in the revised problem, we start at 1 and end at 4 (without returning to 1).
    
    # So we need to adjust the degree constraints:
    # For start city (1): out-degree = 1, in-degree = 0
    # For end city (4): in-degree = 1, out-degree = 0
    # For others: in-degree = 1, out-degree = 1
    
    # However, in our current constraints we set every city to have in-degree=1 and out-degree=1, which forces a cycle.
    # We must change that.
    
    # Let's remove the previous degree constraints and add the correct ones.
    model.remove(model.getConstrs())  # Remove all constraints added so far for degrees and start/end
    
    # Re-add the prohibition constraint (it was added after the degree constraints, so we need to re-add it too)
    # But actually, we haven't added any constraints yet because we just created the model and then added variables.
    # The constraints we added above (start_departure, end_arrival, and the for-loop for in/out) were added, but then we removed all.
    # So we need to rebuild.
    
    # Actually, let's restart the constraint building properly.
    
    # Clear the model constraints (but we just created the model, so we can rebuild from scratch)
    # Instead, we'll create a new model to avoid confusion.
    model = Model("Revised_TSP")
    model.setParam('OutputFlag', 0)
    
    # Redefine variables
    x = {}
    for i in range(n):
        for j in range(n):
            if i != j:
                x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
    
    u = {}
    for i in range(n):
        if i != start_idx:
            u[i] = model.addVar(vtype=GRB.CONTINUOUS, lb=1, ub=n-1, name=f"u_{i}")
    
    # Objective
    obj_expr = gp.LinExpr()
    for i in range(n):
        for j in range(n):
            if i != j:
                cost = dist[i][j]
                if i == inspection_from_idx and j == inspection_to_idx:
                    cost += inspection_stop_cost
                obj_expr += cost * x[i, j]
    model.setObjective(obj_expr, GRB.MINIMIZE)
    
    # Degree constraints for open TSP (path from start to end)
    for i in range(n):
        if i == start_idx:
            # Start: out=1, in=0
            model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1, f"Out_{i}")
            model.addConstr(gp.quicksum(x[j, i] for j in range(n) if j != i) == 0, f"In_{i}")
        elif i == end_idx:
            # End: in=1, out=0
            model.addConstr(gp.quicksum(x[j, i] for j in range(n) if j != i) == 1, f"In_{i}")
            model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 0, f"Out_{i}")
        else:
            # Others: in=1, out=1
            model.addConstr(gp.quicksum(x[i, j] for j in range(n) if j != i) == 1, f"Out_{i}")
            model.addConstr(gp.quicksum(x[j, i] for j in range(n) if j != i) == 1, f"In_{i}")
    
    # Prohibition constraint
    if (prohibited_from_idx, prohibited_to_idx) in x:
        model.addConstr(x[prohibited_from_idx, prohibited_to_idx] == 0, "Prohibition")
    
    # MTZ constraints for subtour elimination (for the path version)
    # Note: MTZ for open TSP: we can use the same idea, but we fix u[start]=0? 
    # However, we don't have u for start. We have u for non-start nodes.
    # Standard MTZ for open TSP: 
    #   u[i] - u[j] + n * x[i,j] <= n - 1, for i != start, j != start, i != j
    # But also, we need to ensure that the start is first and end is last? 
    # Alternatively, we can set u[start] = 0 implicitly by not having it, and then for any arc from start to j: u[j] >= 1
    # However, our current u variables are only for non-start nodes.
    
    # We'll add constraints for all i,j not start and i != j
    for i in range(n):
        if i == start_idx:
            continue
        for j in range(n):
            if j == start_idx or i == j:
                continue
            model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1, f"MTZ_{i}_{j}")
    
    # Additionally, to connect start to the rest: for any j != start, if x[start, j] = 1 then u[j] >= 1
    # But the MTZ constraints above don't cover arcs from start. So we need to add:
    for j in range(n):
        if j == start_idx:
            continue
        # If we go from start to j, then u[j] should be at least 1
        model.addConstr(u[j] >= 1 - n * (1 - x[start_idx, j]), f"Start_to_{j}_lower")
        # And u[j] <= n-1 is already in the variable bound
    
    # Also, for arcs to end: we don't have a specific constraint, but the MTZ should handle it.
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # In case of no solution, but the problem should be feasible
        # Try to compute a fallback? But the problem states there is a solution.
        # We'll assume optimal solution exists.
        print("FINAL_OBJ_VALUE: inf")


if __name__ == "__main__":
    main()
