import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_children_trip = int(params['max_children_trip'])
    min_children_trip = int(params['min_children_trip'])
    max_distinct_children_trip = int(params['max_distinct_children_trip'])
    total_cost_budget = float(params['total_cost_budget'])
    bonus_saving = float(params['bonus_saving'])
    min_bob_days = int(params['min_bob_days'])
    
    # Read table_1 for children and costs
    children = []
    costs = {}
    availability = {}  # 'day1', 'day2', or 'both'
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Child'].strip()
            cost = float(row['Cost'].strip())
            constraint = row['Relationship_Constraint'].strip()
            children.append(name)
            costs[name] = cost
            
            # Determine availability from constraints
            if "Only available on day 1" in constraint:
                availability[name] = 'day1'
            elif "Only available on day 2" in constraint:
                availability[name] = 'day2'
            else:
                availability[name] = 'both'
    
    # Create the optimization model
    model = gp.Model("TwoDayFamilyTrip")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: 
    # x[child, day] = 1 if child is taken on that day, 0 otherwise (for day in [1,2])
    days = [1, 2]
    x = {}
    for child in children:
        for day in days:
            # Check availability
            if (availability[child] == 'day1' and day == 2) or (availability[child] == 'day2' and day == 1):
                # Not available on this day, fix to 0
                x[child, day] = 0
            else:
                var_name = f"x_{child}_day{day}"
                x[child, day] = model.addVar(vtype=GRB.BINARY, name=var_name)
    
    # y[child] = 1 if child is taken on both days, 0 otherwise
    y = {}
    for child in children:
        # Only define y if the child is available on both days; otherwise y=0
        if availability[child] == 'both':
            y[child] = model.addVar(vtype=GRB.BINARY, name=f"y_{child}")
        else:
            y[child] = 0  # Fixed to 0 if not available both days
    
    model.update()
    
    # Link y[child] to x[child,1] and x[child,2] for children available both days
    for child in children:
        if availability[child] == 'both':
            # y[child] <= x[child,1]
            model.addConstr(y[child] <= x[child, 1], f"y_le_x1_{child}")
            # y[child] <= x[child,2]
            model.addConstr(y[child] <= x[child, 2], f"y_le_x2_{child}")
            # y[child] >= x[child,1] + x[child,2] - 1
            model.addConstr(y[child] >= x[child, 1] + x[child, 2] - 1, f"y_ge_x1x2_{child}")
    
    # Objective: minimize total two-day cost minus total bonus savings
    total_cost = gp.quicksum(costs[child] * x[child, day] for child in children for day in days if x[child, day] != 0)
    total_bonus = gp.quicksum(bonus_saving * y[child] for child in children if y[child] != 0)
    model.setObjective(total_cost - total_bonus, GRB.MINIMIZE)
    
    # Daily min/max constraints
    for day in days:
        model.addConstr(gp.quicksum(x[child, day] for child in children if x[child, day] != 0) >= min_children_trip, f"MinChildren_day{day}")
        model.addConstr(gp.quicksum(x[child, day] for child in children if x[child, day] != 0) <= max_children_trip, f"MaxChildren_day{day}")
    
    # Bob must attend at least min_bob_days days
    bob_days = gp.quicksum(x['Bob', day] for day in days if x['Bob', day] != 0)
    model.addConstr(bob_days >= min_bob_days, "MinBobDays")
    
    # Relationship constraints per day
    for day in days:
        # Alice and Diana cannot both be taken on the same day
        if x['Alice', day] != 0 and x['Diana', day] != 0:
            model.addConstr(x['Alice', day] + x['Diana', day] <= 1, f"AliceDianaConflict_day{day}")
        elif x['Alice', day] != 0:  # Diana not available on day1, so only check when both are available
            # On day1: Diana is not available, so no conflict. On day2: Alice not available.
            pass
        # But note: Alice only day1, Diana only day2 -> they never on same day, so constraint redundant but safe to skip.
        
        # Bob and Charlie cannot both be taken on the same day
        if x['Bob', day] != 0 and x['Charlie', day] != 0:
            model.addConstr(x['Bob', day] + x['Charlie', day] <= 1, f"BobCharlieConflict_day{day}")
        
        # Charlie must be accompanied by Diana on the same day (if Charlie goes, Diana must go)
        if x['Charlie', day] != 0 and x['Diana', day] != 0:
            model.addConstr(x['Charlie', day] <= x['Diana', day], f"CharlieRequiresDiana_day{day}")
        elif x['Charlie', day] != 0:
            # Diana not available on this day -> Charlie cannot go, but Charlie only available day2 and Diana also only day2, so both available on day2.
            pass
        
        # Diana must be accompanied by Ella on the same day (if Diana goes, Ella must go)
        if x['Diana', day] != 0 and x['Ella', day] != 0:
            model.addConstr(x['Diana', day] <= x['Ella', day], f"DianaRequiresElla_day{day}")
        elif x['Diana', day] != 0:
            # Ella should be available on same day as Diana (both only day2), so we assume Ella is available.
            pass
    
    # Max distinct children over both days
    # z[child] = 1 if child appears at least once
    z = {}
    for child in children:
        if availability[child] == 'day1':
            z[child] = x[child, 1]
        elif availability[child] == 'day2':
            z[child] = x[child, 2]
        else:  # both
            # z[child] >= x[child,1], z[child] >= x[child,2], z[child] <= x[child,1] + x[child,2]
            z_var = model.addVar(vtype=GRB.BINARY, name=f"z_{child}")
            z[child] = z_var
            model.addConstr(z_var >= x[child, 1], f"z_ge_x1_{child}")
            model.addConstr(z_var >= x[child, 2], f"z_ge_x2_{child}")
            model.addConstr(z_var <= x[child, 1] + x[child, 2], f"z_le_x1x2_{child}")
    
    model.addConstr(gp.quicksum(z[child] for child in children) <= max_distinct_children_trip, "MaxDistinctChildren")
    
    # Total cost budget constraint (net cost after savings must be <= total_cost_budget)
    net_cost = total_cost - total_bonus
    model.addConstr(net_cost <= total_cost_budget, "TotalCostBudget")
    
    # Optimize
    model.optimize()
    
    # Output the objective value
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case no feasible solution, but problem should be feasible
        obj_val = None
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
