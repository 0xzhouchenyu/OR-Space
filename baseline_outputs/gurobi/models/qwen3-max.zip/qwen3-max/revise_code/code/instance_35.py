import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def load_data():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, "general_parameters.csv"), 'r') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            key, value = row[0], float(row[1])
            params[key] = int(value) if key == 'planning_horizon_T' else value
    
    # Load batch processing times
    batches = []
    processing_times = []
    with open(os.path.join(base_dir, "table_1.csv"), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        num_vats = len(header) - 1
        
        for row in reader:
            batch_id = int(row[0])
            times = [math.ceil(float(row[j+1])) for j in range(num_vats)]
            batches.append(batch_id)
            processing_times.append(times)
    
    return params, batches, processing_times, num_vats

def main():
    params, batches, processing_times, num_vats = load_data()
    n_batches = len(batches)
    T = params['planning_horizon_T']
    energy_costs = [params['energy_cost_v1'], params['energy_cost_v2'], params['energy_cost_v3']]
    peak_mult = params['peak_energy_multiplier']
    peak_cap = params['peak_energy_cap']
    makespan_weight = params['makespan_weight']
    energy_weight = params['energy_weight']
    
    # Time periods are 1-indexed from 1 to T
    time_periods = list(range(1, T+1))
    peak_periods = [6,7,8]
    
    # Create model
    model = gp.Model("Dyeing_Schedule")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[b][v][t] = 1 if batch b starts on vat v at time t
    x = {}
    for b in range(n_batches):
        for v in range(num_vats):
            for t in time_periods:
                # Check if starting at t would exceed horizon
                if t + processing_times[b][v] - 1 <= T:
                    x[b,v,t] = model.addVar(vtype=GRB.BINARY, name=f"x_{b}_{v}_{t}")
    
    # y[v][t] = 1 if vat v is active (processing some batch) at time t
    y = {}
    for v in range(num_vats):
        for t in time_periods:
            y[v,t] = model.addVar(vtype=GRB.BINARY, name=f"y_{v}_{t}")
    
    # Makespan variable: completion time of last batch on last vat
    C_max = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="C_max")
    
    # Constraint: each batch must be processed exactly once on each vat
    for b in range(n_batches):
        for v in range(num_vats):
            valid_starts = [t for t in time_periods if t + processing_times[b][v] - 1 <= T]
            model.addConstr(gp.quicksum(x[b,v,t] for t in valid_starts) == 1, 
                           name=f"assign_batch_{b}_vat_{v}")
    
    # Constraint: no overlap on same vat
    for v in range(num_vats):
        for t in time_periods:
            # y[v,t] = 1 if any batch is active on vat v at time t
            active_expr = gp.LinExpr()
            for b in range(n_batches):
                # Batch b is active on vat v at time t if it started at s and s <= t <= s + p - 1
                for s in time_periods:
                    if (s, t) in [(s_val, t_val) for s_val in time_periods for t_val in time_periods 
                                 if s_val <= t_val <= s_val + processing_times[b][v] - 1 and 
                                    s_val + processing_times[b][v] - 1 <= T]:
                        if (b,v,s) in x:
                            active_expr += x[b,v,s]
            model.addConstr(y[v,t] >= active_expr, name=f"y_lower_{v}_{t}")
            model.addConstr(y[v,t] <= active_expr, name=f"y_upper_{v}_{t}")
    
    # Maintenance constraint for Vat 2 (index 1) during periods 4-5
    # No activity allowed in periods 4 and 5
    for t in [4,5]:
        model.addConstr(y[1,t] == 0, name=f"maintenance_vat2_period_{t}")
    
    # Flow constraints: batch must finish on vat v before starting on vat v+1
    # But can start on next vat in same period it finishes on previous vat
    for b in range(n_batches):
        for v in range(num_vats-1):
            # Completion time on vat v
            comp_v = gp.LinExpr()
            for t in time_periods:
                if (b,v,t) in x:
                    comp_v += x[b,v,t] * (t + processing_times[b][v] - 1)
            
            # Start time on vat v+1
            start_v1 = gp.LinExpr()
            for t in time_periods:
                if (b,v+1,t) in x:
                    start_v1 += x[b,v+1,t] * t
            
            # Start time on next vat >= completion time on current vat
            model.addConstr(start_v1 >= comp_v, name=f"flow_{b}_{v}")
    
    # Define makespan: max completion time of all batches on last vat
    for b in range(n_batches):
        comp_last = gp.LinExpr()
        for t in time_periods:
            if (b, num_vats-1, t) in x:
                comp_last += x[b, num_vats-1, t] * (t + processing_times[b][num_vats-1] - 1)
        model.addConstr(C_max >= comp_last, name=f"makespan_batch_{b}")
    
    # Peak energy usage constraint
    peak_energy_usage = gp.LinExpr()
    for v in range(num_vats):
        for t in peak_periods:
            peak_energy_usage += y[v,t] * energy_costs[v] * peak_mult
    model.addConstr(peak_energy_usage <= peak_cap, name="peak_energy_cap")
    
    # Objective: weighted sum of makespan and energy cost
    total_energy_cost = gp.LinExpr()
    for v in range(num_vats):
        for t in time_periods:
            if t in peak_periods:
                total_energy_cost += y[v,t] * energy_costs[v] * peak_mult
            else:
                total_energy_cost += y[v,t] * energy_costs[v]
    
    obj = makespan_weight * C_max + energy_weight * total_energy_cost
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        # In case of no solution, try to provide a fallback (though problem should be feasible)
        print("FINAL_OBJ_VALUE: inf")

if __name__ == '__main__':
    main()
