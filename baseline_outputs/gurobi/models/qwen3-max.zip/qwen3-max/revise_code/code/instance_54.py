import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_table_1(data_dir):
    """Load and parse table_1.csv to extract equipment hours, processing times, and profits."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    equipment_names = []
    products = []
    processing_times = {}  # (equipment, product) -> time
    effective_hours = {}   # equipment -> hours
    base_profit = {}       # product -> profit
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        products = header[1:-1]  # ['I', 'II', 'III']
        
        for row in reader:
            if row[0].startswith('Unit_Product_Profit'):
                for j, prod in enumerate(products):
                    base_profit[prod] = float(row[j + 1])
            else:
                equip = row[0]
                equipment_names.append(equip)
                effective_hours[equip] = float(row[-1])
                for j, prod in enumerate(products):
                    processing_times[(equip, prod)] = float(row[j + 1])
    
    return products, equipment_names, processing_times, effective_hours, base_profit

def load_general_parameters(data_dir):
    """Load general parameters from general_parameters.csv."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            value = float(row['Value'])
            params[param_name] = value
    return params

# Set up data directory
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, '..', 'data')

# Load data
products, equipment_names, processing_times, effective_hours, base_profit = load_table_1(data_dir)
params = load_general_parameters(data_dir)

overtime_hours_cap = params['overtime_hours_cap']
overtime_cost_multiplier = params['overtime_cost_multiplier']
min_prod = {
    'I': params['min_prod_I'],
    'II': params['min_prod_II'],
    'III': params['min_prod_III']
}

# Create Gurobi model
model = gp.Model("Revised_Factory_Production_Optimization")
model.setParam('OutputFlag', 0)

# Decision variables: regular and overtime production for each product
x_reg = model.addVars(products, lb=0, name="x_reg")
x_ot = model.addVars(products, lb=0, name="x_ot")

# Objective: minimize total production cost
# Regular cost = base_profit[p] * x_reg[p]
# Overtime cost = overtime_cost_multiplier * base_profit[p] * x_ot[p]
obj = gp.quicksum(base_profit[p] * x_reg[p] + overtime_cost_multiplier * base_profit[p] * x_ot[p] for p in products)
model.setObjective(obj, GRB.MINIMIZE)

# Constraints: equipment capacity (regular + overtime must not exceed effective hours)
for equip in equipment_names:
    model.addConstr(
        gp.quicksum(processing_times[(equip, p)] * (x_reg[p] + x_ot[p]) for p in products) <= effective_hours[equip],
        name=f"Equipment_{equip}_capacity"
    )

# Constraint: total overtime hours across all equipment and products <= overtime_hours_cap
# Note: Overtime hours = sum over equipment and products of (processing time * overtime units)
overtime_total = gp.quicksum(
    processing_times[(equip, p)] * x_ot[p] for equip in equipment_names for p in products
)
model.addConstr(overtime_total <= overtime_hours_cap, name="Overtime_Hours_Cap")

# Minimum production constraints for each product
for p in products:
    model.addConstr(x_reg[p] + x_ot[p] >= min_prod[p], name=f"Min_Prod_{p}")

# Optimize
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, but problem should be feasible
    print("FINAL_OBJ_VALUE: None")
