import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_demand(filepath):
    """Load nurse demand per time period from CSV."""
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand

def load_parameters(filepath):
    """Load general parameters from CSV."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    return params

# Set up file paths
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")
demand_file = os.path.join(data_dir, "table_1.csv")
params_file = os.path.join(data_dir, "general_parameters.csv")

# Load data
demand = load_demand(demand_file)
params = load_parameters(params_file)

shift_duration = int(params['shift_duration'])  # 8 hours
regular_pay = float(params['regular_nurse_pay'])  # 10 yuan/hour
contract_pay = float(params['contract_nurse_pay'])  # 15 yuan/hour

num_periods = len(demand)  # 6 periods, each 4 hours
periods_per_shift = shift_duration // 4  # 2 periods per shift

# Parse new parameters
outsourced_regular_start_index = int(params['outsourced_regular_start_index'])  # index 2 (10:00 shift)
banned_contract_start_index = int(params['banned_contract_start_index'])  # index 5 (22:00 shift)
max_total_contract_starts = int(params['max_total_contract_starts'])
min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])
daytime_period_indices = [int(x) for x in params['daytime_period_indices'].split(';')]  # [1,2,3,4]

# Create model
model = gp.Model("RevisedNurseScheduling")
model.setParam('OutputFlag', 0)

# Decision variables: regular and contract nurses starting at each shift
x = model.addVars(num_periods, vtype=GRB.INTEGER, name="regular", lb=0)
y = model.addVars(num_periods, vtype=GRB.INTEGER, name="contract", lb=0)

# Objective: minimize total cost
# Each nurse works 8 hours
total_cost = gp.quicksum(
    (regular_pay * shift_duration) * x[j] + (contract_pay * shift_duration) * y[j] 
    for j in range(num_periods)
)
model.setObjective(total_cost, GRB.MINIMIZE)

# Coverage constraints: for each time period i, sum of nurses from shifts that cover period i >= demand[i]
# Shift j covers periods j and (j+1) % num_periods
for i in range(num_periods):
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(
        gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i],
        name=f"Demand_period_{i}"
    )

# Constraint: Regular nurses cannot start the outsourced shift (index 2)
model.addConstr(x[outsourced_regular_start_index] == 0, name="NoRegularOnOutsourcedShift")

# Constraint: Contract nurses cannot start the banned shift (index 5)
model.addConstr(y[banned_contract_start_index] == 0, name="NoContractOnBannedShift")

# Constraint: Total contract starts are capped
model.addConstr(
    gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts,
    name="MaxTotalContractStarts"
)

# Constraint: Daytime periods must have at least min_regular_daytime_coverage regular nurses
for i in daytime_period_indices:
    covering_shifts = []
    for j in range(num_periods):
        covered = [j, (j + 1) % num_periods]
        if i in covered:
            covering_shifts.append(j)
    model.addConstr(
        gp.quicksum(x[j] for j in covering_shifts) >= min_regular_daytime_coverage,
        name=f"MinRegularDaytime_{i}"
    )

# Optimize
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case no optimal solution found, but problem should be feasible
    print("FINAL_OBJ_VALUE: inf")
