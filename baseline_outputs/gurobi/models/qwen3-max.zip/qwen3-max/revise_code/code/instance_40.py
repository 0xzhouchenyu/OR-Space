import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Read data
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(csv_path)
    params = dict(zip(df['Parameter_Name'], df['Value']))

    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # Create model
    model = gp.Model("Maximize_GDP")
    model.setParam('OutputFlag', 0)

    # Variables: Production levels for each commodity
    x = {}
    for c in commodities:
        # Apply production upper bounds if they exist
        ub = float('inf')
        for suffix in ['_production_limit', '_limit', '_capacity']:
            key = f"{c}{suffix}"
            if key in params:
                ub = params[key]
                break
        x[c] = model.addVar(lb=0, ub=ub, name=f"x_{c}")

    # Variables: Imports for each commodity (if needed to meet domestic demand)
    imports = {}
    for c in commodities:
        imports[c] = model.addVar(lb=0, ub=params['import_quota'], name=f"import_{c}")

    # Net export of each commodity = Production + Imports - Domestic Consumption
    # Domestic consumption of commodity c = sum over all other commodities c' of (c'_c_requirement * x[c'])
    net_export = {}
    for c in commodities:
        consumed = gp.quicksum(
            params.get(f"{c_prime}_{c}_requirement", 0.0) * x[c_prime]
            for c_prime in commodities
        )
        net_export[c] = x[c] + imports[c] - consumed

    # Labor usage: regular labor + overtime labor
    total_labor = gp.quicksum(params.get(f"{c}_labor_requirement", 0.0) * x[c] for c in commodities)
    # Overtime labor is the amount beyond the regular labor_force, but capped by overtime_cap
    overtime = model.addVar(lb=0, ub=params['overtime_cap'], name="overtime")
    model.addConstr(total_labor <= params['labor_force'] + overtime, "Labor_Constraint")

    # Import costs for production (other imported goods required in production)
    production_import_costs = gp.quicksum(params.get(f"{c}_import_cost", 0.0) * x[c] for c in commodities)

    # Cost of overtime labor
    overtime_cost = params['overtime_wage'] * overtime

    # Revenue from net exports (only positive net exports are exported; negative would mean we need more imports, but we already have import variables)
    # However, note: net_export can be negative? But the problem says we can import up to import_quota to cover domestic demand.
    # The constraint below ensures that net_export >= 0? Actually, no: the business allows imports to cover domestic demand, so net_export can be negative only if imports are insufficient? 
    # But we have imports variable to cover the gap. Actually, the net_export as defined (x + imports - consumed) must be >=0? 
    # The problem doesn't require net_export >=0 because we can have imports to cover the domestic consumption. However, note:
    # The objective: GDP = Export revenue - Import costs (for production) - Overtime cost - Cost of importing finished goods?
    # But wait: when we import a finished good, we pay for it. How is that accounted?

    # Clarification from the revision: 
    # "each commodity may be imported up to `import_quota` at `import_premium_ratio` times its world price"
    # So the cost of importing a finished commodity c is: import_premium_ratio * world_price * imports[c]
    # And the export revenue is: world_price * max(0, net_export_without_imports) ??? 
    # But note: our net_export = (x - consumed) + imports. However, the imports are used to meet domestic demand, so they are not available for export.
    # Actually, the net export for trade is: (x - consumed) [which could be negative] and then we import to cover the negative part. 
    # But the trade balance for commodity c is: (x - consumed) [this is the net production available for trade]. If positive, we export; if negative, we must import to cover the deficit.
    # However, in our formulation, we have:
    #   domestic consumption = consumed (which is fixed by production of other goods)
    #   total supply = x[c] + imports[c]
    #   so the amount available for export = x[c] + imports[c] - consumed = net_export[c]
    # But if net_export[c] is positive, we export that amount and get revenue = price * net_export[c].
    # If net_export[c] is negative, that would mean we are importing more than needed? That doesn't make sense.

    # Actually, the imports[c] should only be used to cover the deficit in domestic supply. So we should have:
    #   x[c] + imports[c] >= consumed   --> which is net_export[c] >= 0.
    # The problem states: "If local production cannot economically cover domestic demand, each commodity may be imported up to import_quota"
    # So we must have: x[c] + imports[c] >= consumed, i.e., net_export[c] >= 0.

    # Therefore, we add constraints: net_export[c] >= 0 for each c.
    for c in commodities:
        model.addConstr(net_export[c] >= 0, f"Domestic_Demand_{c}")

    # Now, the export revenue: for each commodity, we export net_export[c] (which is nonnegative) and get revenue = price * net_export[c].
    export_revenue = gp.quicksum(params[f"{c}_price"] * net_export[c] for c in commodities)

    # The cost of importing finished goods: we pay import_premium_ratio * world_price for each unit imported.
    import_finished_cost = gp.quicksum(params['import_premium_ratio'] * params[f"{c}_price"] * imports[c] for c in commodities)

    # Total import costs = production_import_costs (for intermediate imports) + import_finished_cost (for finished goods imports) + overtime_cost
    total_import_costs = production_import_costs + import_finished_cost + overtime_cost

    # Objective: GDP = Export revenue - Total import costs
    gdp = export_revenue - total_import_costs
    model.setObjective(gdp, GRB.MAXIMIZE)

    # Solve the model
    model.optimize()

    if model.status == GRB.OPTIMAL:
        return model.objVal
    else:
        return None

if __name__ == '__main__':
    result = solve()
    if result is not None:
        print(f"FINAL_OBJ_VALUE: {result}")
    else:
        print("FINAL_OBJ_VALUE: None")
