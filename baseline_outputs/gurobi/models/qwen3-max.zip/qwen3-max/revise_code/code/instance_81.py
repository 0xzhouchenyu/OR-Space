import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_car_data(data_dir):
    filepath = os.path.join(data_dir, 'table_1.csv')
    cars = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            i = int(row['i'])
            length = float(row['lambda_i'])
            cars[i] = length
    return cars

def load_parameters(data_dir):
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'])
            params[name] = value
    return params

# Data directory
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load data
cars = load_car_data(data_dir)
params = load_parameters(data_dir)

num_cars = int(params['num_cars'])
max_length_one_side = params['max_length_one_side']
available_party_side_count = int(params['available_party_side_count'])

# According to the revision: only one side is available for party cars.
# Therefore, all cars must be parked on that single side, and the total length must not exceed max_length_one_side.
# The objective is to minimize the total length of the street occupied, which is simply the sum of all car lengths (since they all go on one side).
# However, we must check feasibility: if the total length exceeds max_length_one_side, the problem is infeasible.

total_length = sum(cars.values())

# But note: the problem says "minimize the total length of the street occupied", and since all cars must be on one side,
# the occupied length is fixed as total_length. However, we must ensure it fits within max_length_one_side.

# However, the problem might be interpreted as: we have to assign all cars to the one available side, so the objective is just total_length,
# but we must check the constraint.

# Since the problem requires an optimization model, and the assignment is forced (all cars on the one side), 
# the model is trivial: we just need to check if total_length <= max_length_one_side.

# But to follow the instruction of building an optimization model, we can create a model that assigns all cars to the one side.

# However, note: the revision says "one entire side must remain clear", so only one side is available. 
# Therefore, we don't have a choice: all cars must go on the other side.

# So the problem reduces to: 
#   minimize total_length (which is fixed) 
#   subject to total_length <= max_length_one_side.

# But if total_length > max_length_one_side, then it's infeasible.

# However, the problem statement says: "The usable side still has to respect its parking-length limit"

# Since the problem asks for an optimization model, and the original had a MIP, but now the decision is forced, 
# we can still set up a model that doesn't have any binary variables (because there's no choice) but we must check feasibility.

# But the instructions say: "write a complete Python script that solves the REVISED optimization problem"

# We'll create a model that simply checks the constraint and returns the total_length as the objective if feasible.

# However, note: the problem might be expecting a model that could potentially leave out some cars? 
# But the business requirement says: "they will arrive in 15 cars" and we have to park them. So all cars must be parked.

# Therefore, the only issue is feasibility.

# Steps:
# 1. Compute total_length.
# 2. If total_length <= max_length_one_side, then the objective is total_length.
# 3. Else, the problem is infeasible.

# But the problem says: "minimize the total length of the street occupied", and since we have to park all cars, the total length is fixed.

# However, to strictly follow the instruction of using Gurobi and building an optimization model, we can create a model without variables (or with a dummy variable) but that's odd.

# Alternatively, we can think: maybe the problem allows not parking some cars? But the business requirement says 15 cars are arriving and we have to arrange parking for them.

# Given the context, we assume all cars must be parked.

# But let's read the revision again: "the party cars can use only the other side". It doesn't say we can leave cars unparked.

# So we must park all 15 cars on the one side.

# Therefore, the model is:
#   minimize total_length (which is a constant)
#   subject to total_length <= max_length_one_side.

# However, in optimization, if the objective is constant, then we just need to check feasibility.

# Since the problem requires an optimization model and we must use Gurobi, we can set up a model that has no variables and just a constraint.

# But Gurobi requires at least one variable? Actually, no: we can have a model with no variables and just constraints.

# However, the standard way is to have an objective. We can set the objective to 0 and then the constraint, but then how do we get the total_length?

# Alternatively, we can create a model that has a variable representing the total length, but it's fixed.

# Actually, the simplest is to not use Gurobi for this trivial case? But the instruction says: "You MUST use gurobipy (Gurobi) as the solver."

# So we have to create a Gurobi model.

# Approach:
# Let T be the total length used (which is fixed). But we don't have a choice, so T = total_length.
# We can set T as a variable and constrain it to be equal to total_length, and also T <= max_length_one_side.
# Then minimize T.

# However, that's redundant because T is fixed. But it satisfies the requirement of using Gurobi.

# Steps in Gurobi:
#   Create model.
#   Add a continuous variable T (with lower bound 0).
#   Add constraint: T == total_length.
#   Add constraint: T <= max_length_one_side.
#   Set objective: minimize T.

# But note: if total_length > max_length_one_side, then the constraint T==total_length and T<=max_length_one_side is infeasible.

# This model will correctly report infeasibility.

# However, the problem says: "Print exactly one line at the end: FINAL_OBJ_VALUE: <number>"

# What if it's infeasible? The problem doesn't specify. But looking at the original heuristic, it printed the objective value only when feasible.

# Since the data provided: 
#   total_length = 4+4.5+5+4.1+2.4+5.2+3.7+3.5+3.2+4.5+2.3+3.3+3.8+4.6+3
# Let's compute: 
#   4+4.5=8.5; +5=13.5; +4.1=17.6; +2.4=20; +5.2=25.2; +3.7=28.9; +3.5=32.4; +3.2=35.6; +4.5=40.1; +2.3=42.4; +3.3=45.7; +3.8=49.5; +4.6=54.1; +3=57.1
# And max_length_one_side = 60 -> 57.1 <= 60 -> feasible.

# So we expect a feasible solution.

# Therefore, we can build the model as described.

# But note: the problem says "minimize the total length of the street occupied", and that total length is 57.1.

# So the objective value should be 57.1.

# However, to be generic and use Gurobi as required:

model = gp.Model("RevisedParking")
model.setParam('OutputFlag', 0)

# Variable: T, the total length used (which will be set to the sum of all car lengths)
T = model.addVar(lb=0, name="T")

# Constraint: T must equal the total length of all cars
model.addConstr(T == total_length, "total_length_constraint")

# Constraint: T must not exceed the maximum allowed on the one side
model.addConstr(T <= max_length_one_side, "max_length_constraint")

# Objective: minimize T
model.setObjective(T, GRB.MINIMIZE)

# Optimize
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
else:
    # According to the problem, we assume it's feasible, but to be safe, if infeasible we might need to handle.
    # However, the problem states the data and we computed 57.1 <= 60, so it should be optimal.
    # But if infeasible, the problem doesn't specify what to print. Since the problem says "exactly one line", and the example in the original printed the objective, 
    # and the revision data is feasible, we assume optimal.
    # In a real scenario, we might print an error, but the instruction says to print the objective value.
    # Given the context, we'll assume feasibility.
    # If infeasible, we cannot provide an objective value. But the problem states the data so we know it's feasible.
    # So we'll just use the optimal case.
    # For safety, we can check and if not optimal, print an error value? But the problem expects a number.
    # Since the problem states the data and we know total_length=57.1 and max=60, we can hardcode? No, we must compute.
    # Instead, we rely on the model being feasible.
    # If the model is infeasible, we might output a negative value or something, but the problem doesn't specify.
    # Given the instructions and the data, we assume optimal.
    # We'll raise an exception in non-optimal cases for debugging, but the problem says to print the objective.
    # However, the problem says: "Print exactly one line at the end: FINAL_OBJ_VALUE: <number>"
    # So we must print a number. In the infeasible case, what? The original problem didn't consider infeasible.
    # Since the data provided is feasible, we assume optimal.
    # We'll do:
    #   if not optimal, then we try to compute the minimal possible? But we can't park all cars -> not allowed.
    # So the problem is infeasible and there is no solution. But the problem statement implies a solution exists.
    # Therefore, we assume optimal.
    # We'll just use the optimal branch.
    # For the given data, it's optimal.
    obj_val = model.objVal
    print(f"FINAL_OBJ_VALUE: {obj_val}")
