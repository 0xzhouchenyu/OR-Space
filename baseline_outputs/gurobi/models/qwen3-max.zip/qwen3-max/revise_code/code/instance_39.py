import os
import sys
from itertools import combinations
import gurobipy as gp
from gurobipy import GRB

# Add parent directory to path if needed
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from utils import load_general_parameters

# Load data
data_dir = os.path.join(script_dir, 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
motorcycle_pollution = params['motorcycle_pollution']
small_truck_pollution = params['small_truck_pollution']
large_truck_pollution = params['large_truck_pollution']
max_motorcycle_trips = int(params['max_motorcycle_trips'])
motorcycle_capacity = params['motorcycle_capacity']
small_truck_capacity = params['small_truck_capacity']
large_truck_capacity = params['large_truck_capacity']
max_total_trips = int(params['max_total_trips'])
demand_peak = params['demand_peak_units']
demand_offpeak = params['demand_offpeak_units']
leasing_capacity = params['leasing_capacity']
leasing_pollution_per_unit = params['leasing_pollution_per_unit']
leasing_fixed_pollution = params['leasing_fixed_pollution']
max_leasing_fraction_peak = params['max_leasing_fraction_peak']
bigM_leasing = params['bigM_leasing']
epsilon = params['epsilon']

methods = ['motorcycle', 'small_truck', 'large_truck']
pollution = {
    'motorcycle': motorcycle_pollution,
    'small_truck': small_truck_pollution,
    'large_truck': large_truck_pollution
}
capacity = {
    'motorcycle': motorcycle_capacity,
    'small_truck': small_truck_capacity,
    'large_truck': large_truck_capacity
}

best_obj = float('inf')
best_solution = None

for combo in combinations(methods, 2):
    model = gp.Model(f"Transport_{'_'.join(combo)}")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: trips for each method in peak and off-peak
    trips_peak = {}
    trips_offpeak = {}
    for m in combo:
        trips_peak[m] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"trips_peak_{m}")
        trips_offpeak[m] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"trips_offpeak_{m}")
    
    # Leasing variables
    leasing_peak = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="leasing_peak")
    leasing_offpeak = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="leasing_offpeak")
    leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")
    
    # Objective: minimize total pollution
    owned_pollution = gp.quicksum(
        pollution[m] * (trips_peak[m] + trips_offpeak[m]) for m in combo
    )
    leasing_pollution = leasing_fixed_pollution * leasing_used + leasing_pollution_per_unit * (leasing_peak + leasing_offpeak)
    model.setObjective(owned_pollution + leasing_pollution, GRB.MINIMIZE)
    
    # Constraints for peak period demand
    model.addConstr(
        gp.quicksum(capacity[m] * trips_peak[m] for m in combo) + leasing_peak >= demand_peak,
        "peak_demand"
    )
    
    # Constraints for off-peak period demand
    model.addConstr(
        gp.quicksum(capacity[m] * trips_offpeak[m] for m in combo) + leasing_offpeak >= demand_offpeak,
        "offpeak_demand"
    )
    
    # Maximum leasing fraction in peak
    model.addConstr(
        leasing_peak <= max_leasing_fraction_peak * demand_peak,
        "max_leasing_peak"
    )
    
    # Total leasing capacity over the day
    model.addConstr(
        leasing_peak + leasing_offpeak <= leasing_capacity,
        "total_leasing_capacity"
    )
    
    # Link leasing_used to actual leasing (using big-M and epsilon)
    model.addConstr(
        leasing_peak + leasing_offpeak <= bigM_leasing * leasing_used,
        "leasing_activation_upper"
    )
    model.addConstr(
        leasing_peak + leasing_offpeak >= epsilon * leasing_used,
        "leasing_activation_lower"
    )
    
    # Motorcycle trip limit (applies across both periods)
    if 'motorcycle' in combo:
        model.addConstr(
            trips_peak['motorcycle'] + trips_offpeak['motorcycle'] <= max_motorcycle_trips,
            "motorcycle_limit"
        )
    
    # Maximum total trips across both periods
    total_trips = gp.quicksum(trips_peak[m] + trips_offpeak[m] for m in combo)
    model.addConstr(total_trips <= max_total_trips, "max_total_trips")
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        if obj_val < best_obj:
            best_obj = obj_val
            best_solution = {
                'combo': combo,
                'trips_peak': {m: trips_peak[m].x for m in combo},
                'trips_offpeak': {m: trips_offpeak[m].x for m in combo},
                'leasing_peak': leasing_peak.x,
                'leasing_offpeak': leasing_offpeak.x,
                'leasing_used': leasing_used.x
            }

print(f"FINAL_OBJ_VALUE: {best_obj}")
