import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            
            # Handle ratio values like "5:2"
            if ':' in value_str:
                params[name + '_raw'] = value_str
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_hours = params['machine_working_time']
    machine_working_time_minutes = machine_working_time_hours * 60  # convert to minutes
    
    # Production ratio: "at least 2 units of B for every 5 units of A"
    # This means B >= (2/5)*A, or equivalently 2A - 5B <= 0
    ratio_A, ratio_B = params['production_ratio_A_to_B']  # (5, 2)
    
    # Overtime parameters
    max_overtime_hours = params['max_overtime_hours']
    overtime_penalty_per_hour = params['overtime_penalty_per_hour']
    overtime_review_threshold_hours = params['overtime_review_threshold_hours']
    overtime_review_fee = params['overtime_review_fee']
    
    # Product A senior batch parameters
    product_A_senior_batch_threshold = params['product_A_senior_batch_threshold']
    product_A_senior_batch_fee = params['product_A_senior_batch_fee']
    
    # Create model
    model = gp.Model("Revised_Product_Mix")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    A = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_A")
    B = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_B")
    
    # Overtime variable (in hours)
    overtime_hours = model.addVar(lb=0, ub=max_overtime_hours, vtype=GRB.CONTINUOUS, name="Overtime_Hours")
    
    # Binary variable for overtime review fee: 1 if overtime > threshold, else 0
    y_overtime = model.addVar(vtype=GRB.BINARY, name="Overtime_Review_Flag")
    
    # Binary variable for Product A senior batch fee: 1 if A > 100, else 0
    y_senior = model.addVar(vtype=GRB.BINARY, name="Senior_Batch_Flag")
    
    # Total assembly time in minutes
    total_assembly_time = assembly_time_A * A + assembly_time_B * B
    
    # Constraint: total assembly time <= regular time + overtime (converted to minutes)
    model.addConstr(total_assembly_time <= machine_working_time_minutes + overtime_hours * 60, "Time_Constraint")
    
    # Production ratio constraint: B >= (2/5) * A  =>  2A - 5B <= 0
    model.addConstr(ratio_B * A - ratio_A * B <= 0, "Production_Ratio")
    
    # Overtime review fee logic: if overtime_hours > overtime_review_threshold_hours then y_overtime = 1
    # We use a big-M constraint. Since max overtime is max_overtime_hours, we can set M = max_overtime_hours
    M_overtime = max_overtime_hours
    model.addConstr(overtime_hours <= overtime_review_threshold_hours + M_overtime * y_overtime, "Overtime_Review_Upper")
    # To ensure y_overtime=1 when overtime_hours > threshold, we also need:
    # But note: if overtime_hours <= threshold, y_overtime can be 0 or 1? We want to minimize cost so it will be 0.
    # However, to force y_overtime=1 when overtime_hours > threshold, we can use:
    #   overtime_hours >= (overtime_review_threshold_hours + epsilon) - M*(1-y_overtime)
    # But since the problem is continuous, we avoid epsilon by using the fact that the fee is fixed and we are minimizing cost.
    # Alternatively, we can use a constraint that if y_overtime=0 then overtime_hours <= threshold.
    # We already have: overtime_hours <= threshold + M*y_overtime -> if y_overtime=0, then overtime_hours<=threshold.
    # And if overtime_hours > threshold, then y_overtime must be 1 (because if y_overtime=0, the constraint would be violated).
    # So the above constraint is sufficient.
    
    # Senior batch fee logic: if A > 100 then y_senior = 1
    # Similarly, we use a big-M constraint. We don't have an explicit upper bound on A, but we can compute one.
    # Maximum possible A: if we use all time for A (including overtime), then A_max = (machine_working_time_minutes + max_overtime_hours*60) / assembly_time_A
    A_max = (machine_working_time_minutes + max_overtime_hours * 60) / assembly_time_A
    M_senior = A_max
    # Constraint: A <= 100 + M_senior * y_senior
    model.addConstr(A <= product_A_senior_batch_threshold + M_senior * y_senior, "Senior_Batch_Upper")
    # This ensures: if y_senior=0, then A<=100; if A>100, then y_senior must be 1.
    
    # Objective: maximize profit - costs
    # Profit: profit_A * A + profit_B * B
    # Costs: 
    #   - overtime penalty: overtime_penalty_per_hour * overtime_hours
    #   - overtime review fee: overtime_review_fee * y_overtime
    #   - senior batch fee: product_A_senior_batch_fee * y_senior
    objective = profit_A * A + profit_B * B - \
                overtime_penalty_per_hour * overtime_hours - \
                overtime_review_fee * y_overtime - \
                product_A_senior_batch_fee * y_senior
    
    model.setObjective(objective, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case of no solution, output 0 or handle appropriately, but problem should be feasible.
        obj_val = 0.0
    
    print(f"FINAL_OBJ_VALUE: {obj_val:.1f}")

if __name__ == "__main__":
    main()
