import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    # Create model
    model = gp.Model("Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    for p in products:
        x[p['Product']] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"x_{p['Product']}")
    
    # Overtime variable (non-negative, up to max_overtime)
    overtime = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=params['max_overtime'], name="overtime")
    
    # Binary variable for Product A line audit: 1 if x_A > 29, else 0
    y_audit = model.addVar(vtype=GRB.BINARY, name="y_audit")
    
    # Binary variable for overtime review fee: 1 if overtime > overtime_review_threshold, else 0
    y_overtime_review = model.addVar(vtype=GRB.BINARY, name="y_overtime_review")
    
    # Link x_A and y_audit: if x_A > 29 then y_audit must be 1
    # Use big-M constraint: x_A <= 29 + M * y_audit
    M_audit = 10000  # sufficiently large number
    model.addConstr(x['A'] <= params['product_A_line_audit_threshold'] + M_audit * y_audit, "audit_link")
    
    # Link overtime and y_overtime_review: if overtime > overtime_review_threshold then y_overtime_review = 1
    # Use big-M: overtime <= overtime_review_threshold + M * y_overtime_review
    M_overtime = params['max_overtime']  # since overtime <= max_overtime
    model.addConstr(overtime <= params['overtime_review_threshold'] + M_overtime * y_overtime_review, "overtime_review_link")
    
    # Total labor used
    total_labor = gp.quicksum(float(p['Labor_Required_hours']) * x[p['Product']] for p in products)
    
    # Labor constraint: total labor <= available_labor + overtime
    model.addConstr(total_labor <= params['available_labor'] + overtime, "Labor_with_overtime")
    
    # Resource constraints
    model.addConstr(gp.quicksum(float(p['Steel_Required_kg']) * x[p['Product']] for p in products) <= params['available_steel'], "Steel")
    model.addConstr(gp.quicksum(float(p['Aluminum_Required_kg']) * x[p['Product']] for p in products) <= params['available_aluminum'], "Aluminum")
    
    # Objective: maximize profit - setup costs - overtime cost - audit fees - overtime review fee
    total_profit = gp.quicksum(float(p['Profit_yuan']) * x[p['Product']] for p in products)
    total_setup = gp.quicksum(float(p['Setup_Cost_yuan']) * (1 if x[p['Product']].X >= 1e-6 else 0) for p in products)
    # However, setup costs are fixed per product if produced at all. We need binary variables for production.
    
    # Since setup costs are fixed if the product is produced, we need to introduce binary variables for production
    z = {}
    M_prod = 10000
    for p in products:
        z[p['Product']] = model.addVar(vtype=GRB.BINARY, name=f"z_{p['Product']}")
        # Link x and z: x_p <= M * z_p
        model.addConstr(x[p['Product']] <= M_prod * z[p['Product']], f"link_x_z_{p['Product']}")
    
    total_setup = gp.quicksum(float(p['Setup_Cost_yuan']) * z[p['Product']] for p in products)
    
    # Overtime cost
    overtime_cost = params['overtime_pay'] * overtime
    
    # Audit fee
    audit_fee = params['product_A_line_audit_fee'] * y_audit
    
    # Overtime review fee
    overtime_review_fee = params['overtime_review_fee'] * y_overtime_review
    
    # Objective
    model.setObjective(
        total_profit - total_setup - overtime_cost - audit_fee - overtime_review_fee,
        GRB.MAXIMIZE
    )
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        obj_val = 0.0
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
