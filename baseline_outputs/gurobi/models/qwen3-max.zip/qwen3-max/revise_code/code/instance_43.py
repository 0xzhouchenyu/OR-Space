import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    return params

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
min_A = params['min_raw_material_A']
min_B = params['min_raw_material_B']
min_C = params['min_raw_material_C']

cap_A_a = params['warehouse_A_truck_capacity_A']
cap_A_b = params['warehouse_A_truck_capacity_B']
cap_A_c = params['warehouse_A_truck_capacity_C']
cost_A = params['warehouse_A_truck_cost']
fixed_A = params['warehouse_A_fixed_cost']

cap_B_a = params['warehouse_B_truck_capacity_A']
cap_B_b = params['warehouse_B_truck_capacity_B']
cap_B_c = params['warehouse_B_truck_capacity_C']
cost_B = params['warehouse_B_truck_cost']
fixed_B = params['warehouse_B_fixed_cost']
overflow_threshold = params['warehouse_B_overflow_threshold_trucks']
overflow_cost = params['warehouse_B_overflow_coordination_cost']

dual_warehouse_fee = params['dual_warehouse_reconciliation_fee']

# Create the model
model = gp.Model("MinFreightCost")

# Decision variables
x = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_A")
y = model.addVar(vtype=GRB.INTEGER, lb=0, name="trucks_from_B")

# Binary variables for fixed costs and overflow
use_A = model.addVar(vtype=GRB.BINARY, name="use_A")
use_B = model.addVar(vtype=GRB.BINARY, name="use_B")
both_used = model.addVar(vtype=GRB.BINARY, name="both_used")
overflow_B = model.addVar(vtype=GRB.BINARY, name="overflow_B")

# Constraints linking trucks to binary usage
M = 100000  # Big-M value (sufficiently large)
model.addConstr(x <= M * use_A, "link_x_use_A")
model.addConstr(y <= M * use_B, "link_y_use_B")

# Both warehouses used if both are active
model.addConstr(use_A + use_B - 1 <= both_used, "both_used_lower")
model.addConstr(both_used <= use_A, "both_used_upper1")
model.addConstr(both_used <= use_B, "both_used_upper2")

# Overflow constraint for warehouse B
model.addConstr(y >= overflow_threshold + 1 - M * (1 - overflow_B), "overflow_trigger1")
model.addConstr(y <= overflow_threshold + M * overflow_B, "overflow_trigger2")

# Raw material constraints
model.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
model.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
model.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# Objective: minimize total cost
total_cost = (
    cost_A * x + 
    cost_B * y + 
    fixed_A * use_A + 
    fixed_B * use_B + 
    dual_warehouse_fee * both_used + 
    overflow_cost * overflow_B
)
model.setObjective(total_cost, GRB.MINIMIZE)

# Solve
model.setParam('OutputFlag', 0)
model.optimize()

# Output the final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, but problem should be feasible
    print("FINAL_OBJ_VALUE: inf")
