import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    # Read table_1.csv
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
    
    # Read general_parameters.csv
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        params = {}
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    
    max_storage = float(params['max_storage_capacity'])  # 200000 m³
    storage_cost_a = float(params['storage_cost_a'])      # 70 yuan/m³
    storage_cost_b = float(params['storage_cost_b'])      # 100 yuan/m³/quarter
    safety_inventory_level = float(params['safety_inventory_level_10k_m3'])  # 20 (10k m³)
    terminal_inventory_value = float(params['terminal_inventory_value_per_10k_m3'])  # 455 (10k yuan per 10k m³)
    over_purchase_penalty = float(params['over_purchase_penalty_cost_per_10k_m3'])  # 300 (10k yuan per 10k m³)
    
    # Convert storage capacity to 10k m³ (万m³)
    max_storage_wm3 = max_storage / 10000.0  # 20 万m³
    
    # Storage costs are already in yuan/m³; we'll work in 10k m³ and 10k yuan units.
    # So: 
    #   storage_cost_a = 70 yuan/m³ = 70 * 10000 yuan / 10000 m³ = 700000 yuan per 10k m³ = 70 (10k yuan per 10k m³)
    #   Similarly, storage_cost_b = 100 yuan/m³/quarter = 100 (10k yuan per 10k m³ per quarter)
    # But note: the prices in table_1 are already in 10k yuan per 10k m³, so we can use storage costs directly as:
    #   storage_cost_a_w = 70 (10k yuan per 10k m³)
    #   storage_cost_b_w = 100 (10k yuan per 10k m³ per quarter)
    storage_cost_a_w = storage_cost_a  # because 70 yuan/m³ = 70 * 10^4 yuan / 10^4 m³ = 70 (in 10k yuan per 10k m³)
    storage_cost_b_w = storage_cost_b  # same reasoning
    
    n = len(quarters)  # 4 quarters: Winter, Spring, Summer, Autumn
    
    # Create model
    model = gp.Model("Timber_Profit_Maximization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables:
    # x[i][j] = amount purchased in quarter i and sold in quarter j (in 10k m³), for j >= i and j <= 3 (Autumn)
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
    
    # End-of-autumn inventory: total purchased minus total sold
    # But note: all timber must be either sold by autumn or remain as inventory at end of autumn.
    # So inventory at end of autumn = sum_{i=0}^{3} (total purchased in i) - sum_{i=0}^{3} sum_{j=i}^{3} x[i,j]
    # However, total purchased in i = sum_{j=i}^{3} x[i,j]
    # Therefore, end_inventory = sum_{i=0}^{3} sum_{j=i}^{3} x[i,j] - sum_{i=0}^{3} sum_{j=i}^{3} x[i,j] = 0? 
    # That's not right. Actually, the inventory at the end of autumn is the amount that was purchased but not sold in any quarter.
    # But by our definition, x[i,j] covers all sales from purchase i in quarter j. So if we don't sell it, it's not in x[i,j] for any j.
    # However, the problem states that timber must be sold by the end of autumn, but now there is a safety inventory requirement at the end of autumn.
    # This implies that we are allowed to have inventory at the end of autumn (the safety stock and possibly more).
    # Therefore, we need to account for unsold timber from each purchase quarter that remains at the end of autumn.
    
    # Let's redefine: 
    # We have for each purchase quarter i, the total amount purchased is P_i = sum_{j=i}^{3} x[i,j] + I_i
    # where I_i is the amount from purchase i that is not sold during the year (and thus is in the end-of-autumn inventory).
    # But note: the problem says "timber must be sold by the end of autumn" in the original, but the revision adds a safety inventory at end of autumn.
    # So the revision overrides: we can have inventory at end of autumn.
    
    # However, the current variable definition x[i,j] only covers sales. We need to account for the leftover.
    # Alternative approach: define the end-of-autumn inventory as a separate variable, but it is determined by purchases and sales.
    
    # Total purchased in quarter i: let's call it buy[i] = sum_{j=i}^{3} x[i,j] + inv_end_i
    # But we don't have inv_end_i. Instead, we can compute total end inventory as:
    #   end_inventory = sum_{i=0}^{3} (buy[i]) - sum_{j=0}^{3} (sales in j)
    # and sales in j = sum_{i=0}^{j} x[i,j]
    # and buy[i] = sum_{j=i}^{3} x[i,j] + (amount from i not sold) 
    # But note: the amount from i not sold is exactly the part that goes to end_inventory from purchase i.
    
    # However, the problem does not require tracking which purchase the end inventory comes from, only the total.
    # So we can define:
    #   total_end_inventory = sum_{i=0}^{3} [ buy[i] - sum_{j=i}^{3} x[i,j] ]
    # but buy[i] is not a variable, it's constrained by max_purchase[i].
    
    # Actually, we can express total_end_inventory as:
    #   total_end_inventory = sum_{i=0}^{3} buy[i] - sum_{j=0}^{3} sales_j
    # and sales_j = sum_{i=0}^{j} x[i,j]
    # and buy[i] = sum_{j=i}^{3} x[i,j] + (leftover from i)
    # but the leftover from i is not sold, so it's part of end_inventory.
    
    # However, note: we don't have a variable for buy[i]. Instead, we have the constraint that buy[i] <= max_purchase[i], and buy[i] = sum_{j=i}^{3} x[i,j] + leftover_i.
    # But the leftover_i is not used in any other constraint except the end_inventory and the purchase cap.
    
    # To avoid introducing extra variables, we can note:
    #   total_end_inventory = sum_{i=0}^{3} [ (sum_{j=i}^{3} x[i,j] + leftover_i) ] - sum_{j=0}^{3} (sum_{i=0}^{j} x[i,j])
    #   = sum_{i} leftover_i   [because the x terms cancel: sum_i sum_{j>=i} x[i,j] = sum_j sum_{i<=j} x[i,j]]
    # So total_end_inventory = sum_{i} leftover_i.
    
    # But we don't have leftover_i as variables. However, we can express the purchase constraint as:
    #   sum_{j=i}^{3} x[i,j] + leftover_i <= max_purchase[i]
    # and then total_end_inventory = sum_i leftover_i.
    
    # Alternatively, we can avoid explicit leftover_i by noting that the purchase constraint is:
    #   sum_{j=i}^{3} x[i,j] <= max_purchase[i]   ??? 
    # But wait: the purchase cap is on the total purchased, which includes what is sold and what is left as inventory.
    # So: total purchased in i = (amount sold from i) + (amount left from i) <= max_purchase[i]
    # => sum_{j=i}^{3} x[i,j] + (leftover from i) <= max_purchase[i]
    # But we don't have leftover from i as a variable. However, the leftover from i is exactly the part that contributes to end_inventory from purchase i.
    
    # Since the end_inventory is the sum of leftovers, and we need to compute the penalty and terminal value based on total end_inventory, 
    # we can introduce a variable for total_end_inventory and link it.
    
    # But note: the storage constraints during the year only care about the inventory carried between quarters, which is determined by the x[i,j] for j>i.
    # The end_inventory doesn't affect the storage constraints during the year because it's only present at the very end (after autumn sales).
    
    # How about this: 
    #   Let I = total end-of-autumn inventory (in 10k m³). Then:
    #       I = sum_{i=0}^{3} [ (total purchased in i) - sum_{j=i}^{3} x[i,j] ]
    #   and total purchased in i = sum_{j=i}^{3} x[i,j] + (contribution to I from i)
    #   so I = sum_{i} (contribution to I from i)
    #
    #   Also, the purchase constraint for quarter i: 
    #        total purchased in i = sum_{j=i}^{3} x[i,j] + (contribution to I from i) <= max_purchase[i]
    #
    #   We can avoid introducing per-i leftover by using:
    #        I = (sum_{i=0}^{3} total_purchased_i) - (sum_{j=0}^{3} sales_j)
    #        = (sum_{i=0}^{3} total_purchased_i) - (sum_{i=0}^{3} sum_{j=i}^{3} x[i,j])
    #
    #   But we don't have total_purchased_i as variables. However, we can express the purchase constraint as:
    #        sum_{j=i}^{3} x[i,j] <= max_purchase[i]   [this would be incorrect because it ignores the leftover]
    #
    #   Actually, the purchase constraint must include the leftover. So we need to account for it.
    
    # Given the complexity, let's introduce a variable for the end inventory from each purchase quarter? 
    # But the problem doesn't require that level of detail. Only the total end inventory matters for the penalty and terminal value.
    
    # Alternative: express the purchase constraint as:
    #   For each i: sum_{j=i}^{3} x[i,j] + y_i <= max_purchase[i]
    #   where y_i >=0 is the amount from purchase i that is not sold (and goes to end inventory).
    #   Then total end inventory I = sum_i y_i.
    #
    # This is clean and matches the problem structure.
    
    y = {}
    for i in range(n):
        y[i] = model.addVar(lb=0, name=f"y_{i}")
    
    # Total end inventory
    I = model.addVar(lb=0, name="I")
    model.addConstr(I == gp.quicksum(y[i] for i in range(n)), "end_inventory_def")
    
    # Purchase constraints: for each quarter i, total purchased = (sold from i) + (leftover from i) <= max_purchase[i]
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(i, n)) + y[i] <= max_purchase[quarters[i]], f"purchase_cap_{i}")
    
    # Sales constraints: total sold in quarter j <= max_sales[j]
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(j+1)) <= max_sales[quarters[j]], f"sales_cap_{j}")
    
    # Storage constraints: at the end of each quarter t (for t=0,1,2; i.e., after Winter, Spring, Summer), 
    # the stored timber = sum of x[i,j] for i<=t and j>t, plus the y[i] for i<=t? 
    # But note: y[i] is the amount that is never sold, so it is stored from quarter i until the end of autumn.
    # Therefore, at the end of quarter t, the inventory includes:
    #   - All x[i,j] with i<=t and j>t (to be sold in future quarters)
    #   - All y[i] with i<=t (the leftover that will remain until end of autumn)
    #
    # So stored at end of quarter t = sum_{i=0}^{t} [ sum_{j=t+1}^{3} x[i,j] + y[i] ]
    #
    for t in range(n-1):  # t=0,1,2 (Winter, Spring, Summer); after these quarters, before next quarter
        stored = gp.quicksum( 
            gp.quicksum(x[i, j] for j in range(t+1, n)) + y[i] 
            for i in range(t+1)
        )
        model.addConstr(stored <= max_storage_wm3, f"storage_cap_{t}")
    
    # Objective function
    # Profit components:
    # 1. Revenue from sales: for each x[i,j]: sale_price[j] * x[i,j]
    # 2. Purchase cost: for each purchase i: purchase_price[i] * (sum_{j} x[i,j] + y[i])
    # 3. Storage cost: for each x[i,j] with j>i: 
    #        storage_cost = (storage_cost_a_w + storage_cost_b_w * (j-i)) * x[i,j]
    #    Note: for y[i] (leftover), it is stored from quarter i to the end of autumn (which is after quarter 3).
    #    How many quarters is it stored? 
    #        If purchased in quarter i, then:
    #          - From beginning of i to end of i: no storage cost for same quarter? But note: the problem says "same-quarter turn requires no storage charge"
    #          - However, y[i] is not sold in quarter i, so it is stored starting from the end of quarter i.
    #        It is stored for (3 - i) full quarters? 
    #        Example: 
    #          Winter (i=0): stored through Spring, Summer, Autumn -> 3 quarters? 
    #          But the storage cost formula: base cost + additional per quarter.
    #        The problem states: "storage cost for u quarters: (a + b*u)"
    #        For y[i], u = (3 - i)  [because from end of quarter i to end of quarter 3, there are (3-i) quarters of storage?]
    #        However, note the original storage cost for x[i,j] with j>i: u = j-i.
    #        For y[i], it is as if it is "sold" at a virtual quarter 4? But the problem doesn't say that.
    #
    #    Let's read: "timber must be sold by the end of autumn" in the original, but now we have end inventory. 
    #    The storage cost during the year: the timber is stored from the purchase quarter until the sale quarter (or until end of autumn for leftovers).
    #    For leftovers, they are stored from the purchase quarter through the end of autumn. 
    #    How many quarters of storage? 
    #        Purchased at beginning of quarter i.
    #        If not sold in quarter i, then it occupies storage during quarter i (from beginning to end) and then subsequent quarters until autumn.
    #        But the problem says: "same-quarter turn requires no storage charge", meaning if sold in the same quarter, no storage.
    #        If held beyond the same quarter, then storage cost applies for the time held.
    #
    #    For y[i] (leftover from purchase i), it is held for (3 - i + 1) quarters? 
    #        Actually, from the beginning of quarter i to the end of quarter 3: that's (4 - i) quarters? 
    #        But note: the storage cost parameters are defined per quarter of storage.
    #
    #    However, looking at the original heuristic: for x[i,j] with j>i, u = j-i.
    #        Example: bought in Winter (i=0), sold in Spring (j=1): u=1.
    #        This implies storage during the period between Winter and Spring, i.e., one quarter of storage (during Winter? or after Winter?).
    #
    #    The problem states: "storage cost for u quarters", and u = j-i.
    #    For leftovers, they are not sold in any quarter, so they are stored from purchase until the end of autumn.
    #    The number of quarters stored = (3 - i + 1)? But note: 
    #        - If bought in Winter (i=0) and held until end of Autumn (after quarter 3), then it is stored during Winter, Spring, Summer, Autumn? 
    #        However, the problem says "same-quarter turn requires no storage", meaning if you buy and sell in Winter, no storage.
    #        If you buy in Winter and hold, then you incur storage for the time after Winter until sale.
    #
    #    Clarification from the storage cost formula in the original code: 
    #        For x[i,j] with j>i: storage cost = (a + b*(j-i))
    #        So for Winter->Spring: j-i=1 -> cost = a + b*1.
    #        This suggests that the storage cost is incurred for the number of quarters between purchase and sale, not including the purchase quarter?
    #        But actually, the timber is stored during the quarters after purchase until the sale quarter.
    #
    #    For leftovers: they are stored from the purchase quarter until the end of autumn, which is after the autumn quarter.
    #    How many quarters of storage? 
    #        From the end of purchase quarter i to the end of autumn (quarter 3): that's (3 - i) quarters.
    #        Example: 
    #          Winter (i=0): stored during Spring, Summer, Autumn -> 3 quarters? 
    #          But the original code for Winter->Autumn (j=3): u=3, so cost = a + b*3.
    #        Therefore, for leftovers from Winter, it should be stored for 3 quarters? 
    #        However, note: if you buy in Winter and sell in Autumn, you store for 3 quarters (Winter to Spring, Spring to Summer, Summer to Autumn) -> 3 intervals, so u=3.
    #        For leftovers, you don't sell in Autumn, so you store through Autumn? 
    #        The problem says: "end of autumn" is when the season ends, and the safety inventory is measured at that point.
    #        So the storage for leftovers should be the same as if they were sold in a virtual quarter 4? But the problem doesn't specify.
    #
    #    However, note the business requirement: "timber must be sold by the end of autumn" in the original, but the revision allows inventory at end of autumn.
    #    The storage cost during the year: the warehouse is used until the end of autumn. So the leftovers are stored for the entire period from purchase until the end of autumn.
    #    The number of quarters stored = (3 - i + 1) ? 
    #        But the original storage cost for a sale in quarter j is u = j - i.
    #        For leftovers, if we consider they are "held" until a virtual quarter 4, then u = 4 - i.
    #        However, the problem states: "storage_time_u=u,quarters", and the context is within the year (through autumn).
    #
    #    Let's look at the storage constraints: 
    #        At the end of quarter t, the stored amount includes leftovers from quarters <= t.
    #        This implies that leftovers are stored during every quarter from their purchase quarter until the end of autumn.
    #        Therefore, the number of quarters of storage for leftover from quarter i is (3 - i + 1) ? 
    #        But note: 
    #          - Quarter indices: 0=Winter, 1=Spring, 2=Summer, 3=Autumn.
    #          - If purchased in Winter (0), then it is stored during Winter (if not sold in Winter), Spring, Summer, Autumn -> 4 quarters? 
    #        However, the problem says "same-quarter turn requires no storage", meaning if sold in Winter, no storage. 
    #        If not sold in Winter, then it incurs storage for Winter? 
    #
    #    The original heuristic did not have leftovers, so we have to infer.
    #    The storage cost formula in the problem: "storage cost for u quarters: (a + b*u)"
    #    and u is the storage time in quarters.
    #
    #    For a unit bought in quarter i and sold in quarter j (j>i), u = j - i.
    #    For a unit bought in quarter i and not sold (leftover), it is stored from quarter i to the end of quarter 3, so the storage time is (3 - i + 1) quarters? 
    #    But note: from the beginning of quarter i to the end of quarter 3 is 4 - i quarters? 
    #        Winter to end of Autumn: 4 quarters (Winter, Spring, Summer, Autumn).
    #    However, the problem likely considers that storage cost is incurred for each full quarter that the timber is held beyond the purchase quarter.
    #    Standard interpretation: 
    #        - If bought at start of Winter and sold at start of Spring, then stored for 1 quarter (Winter).
    #        - If bought at start of Winter and held until end of Autumn, then stored for 4 quarters? 
    #    But the original example: Winter to Spring -> u=1, which matches 1 quarter of storage (Winter).
    #
    #    Therefore, for leftovers from quarter i, the storage time u = (3 - i + 1) = 4 - i? 
    #        Winter (i=0): u=4
    #        Spring (i=1): u=3
    #        Summer (i=2): u=2
    #        Autumn (i=3): u=1  -> but wait, if bought in Autumn and not sold, then it is stored during Autumn? 
    #        However, the problem says "same-quarter turn requires no storage", so if bought in Autumn and not sold in Autumn, then it is stored for 1 quarter (Autumn).
    #
    #    But note: the storage constraints at the end of Autumn are not enforced (since there is no quarter after Autumn in the storage constraints loop, which goes to t=2). 
    #    However, the warehouse capacity might be an issue during Autumn? 
    #    The storage constraint for t=2 (end of Summer) ensures that the inventory going into Autumn is within capacity.
    #    During Autumn, the company sells some and may add new purchases, but the storage constraint during Autumn is not explicitly modeled? 
    #    Actually, the storage constraint at the end of Summer (t=2) covers the inventory that is carried into Autumn.
    #    Then in Autumn, they purchase up to max_purchase[Autumn] and sell up to max_sales[Autumn], and the leftover is the end inventory.
    #    The warehouse must be able to hold the inventory during Autumn, but the problem doesn't specify a storage constraint at the end of Autumn.
    #    However, the max_storage_capacity is a physical limit that applies at all times, so we should also have a constraint at the end of Autumn?
    #    But the problem states: "warehouse use is limited by max_storage_capacity", and the original code only had constraints for t in [0, n-2] (i.e., up to end of Summer).
    #    The revision doesn't mention adding a storage constraint at end of Autumn, and the safety inventory is allowed to be up to ... well, the penalty applies but there's no hard cap from storage? 
    #    However, the warehouse capacity is a physical limit, so the end-of-autumn inventory must also be <= max_storage_capacity.
    #
    #    But note: the storage constraint at the end of Summer (t=2) ensures that the inventory entering Autumn is <= max_storage.
    #    Then in Autumn, they purchase additional timber (up to max_purchase[Autumn]), so the total inventory at the beginning of Autumn = (inventory from end of Summer) + (new purchase in Autumn).
    #    This total must be <= max_storage? 
    #    However, the problem doesn't specify that the warehouse can be refilled during the quarter. Typically, storage constraints are on the maximum inventory at any time.
    #    The original code did not have a constraint for the beginning of Autumn, only the end of previous quarters.
    #
    #    Given the complexity and that the original problem didn't have this, and the revision doesn't specify, we will follow the original pattern: 
    #        storage constraints only at the end of Winter, Spring, Summer (t=0,1,2).
    #    And assume that the warehouse can handle the Autumn operations without exceeding capacity during the quarter, or that the end-of-Autumn inventory is allowed to exceed? 
    #    But the problem says "warehouse use is limited by max_storage_capacity", so it should apply at all times.
    #
    #    However, looking at the revised business requirement: "any stock that remains after Winter, Spring, or Summer still counts against the warehouse’s physical limit", 
    #    implying that after Autumn, it might be different? But the safety inventory is stored in the same warehouse.
    #
    #    To be safe, we should add a storage constraint at the end of Autumn? 
    #    But the problem states: "timber planned for the current selling season still cannot be left in ordinary storage indefinitely", but the safety inventory is for the next cycle, so maybe it's moved to a different facility? 
    #    The requirement doesn't specify. 
    #
    #    Given the ambiguity, and since the original code did not have a constraint for end of Autumn, and the revision focuses on the safety inventory as a separate requirement, 
    #    we will NOT add a storage constraint for end of Autumn. The storage constraints are only for the end of quarters 0,1,2 (Winter, Spring, Summer).
    #
    #    Now back to storage cost for leftovers:
    #        The storage cost should be incurred for every quarter that the timber is stored.
    #        For a unit bought in quarter i and leftover, it is stored during quarters i, i+1, ..., 3 -> that's (4 - i) quarters.
    #        But the original storage cost for a sale in quarter j is u = j - i, which corresponds to storage during quarters i, i+1, ..., j-1 -> (j-i) quarters.
    #        So for leftovers, if we consider they are stored until the end of quarter 3, then the number of quarters stored = (3 - i + 1) = 4 - i.
    #        However, note that in the sale case, the timber is removed at the beginning of quarter j, so it is not stored during quarter j.
    #        For leftovers, they are stored during quarter 3 (Autumn) because they are not sold in Autumn.
    #
    #    Therefore, storage time for leftover from quarter i = (3 - i + 1) = 4 - i.
    #        Winter (0): 4 quarters
    #        Spring (1): 3 quarters
    #        Summer (2): 2 quarters
    #        Autumn (3): 1 quarter
    #
    #    But wait, the problem states: "same-quarter turn requires no storage charge". 
    #        For Autumn purchase: if sold in Autumn, no storage. If not sold, then stored for 1 quarter (Autumn).
    #    This matches.
    #
    #    However, the storage cost formula in the problem is: (a + b * u)
    #    So for leftover from i: storage cost = (storage_cost_a_w + storage_cost_b_w * (4 - i))
    #
    # 4. Terminal inventory value: terminal_inventory_value * I
    # 5. Over-purchase penalty: 
    #        Let excess = max(0, I - safety_inventory_level)
    #        Penalty = over_purchase_penalty * excess
    #
    # But note: the penalty is applied to inventory above safety level, so we need to model excess.
    # We can do: 
    #   excess = I - safety_inventory_level, but only if positive.
    #   Introduce a variable excess >=0, and constraint: excess >= I - safety_inventory_level
    #   Then penalty = over_purchase_penalty * excess
    #
    excess = model.addVar(lb=0, name="excess")
    model.addConstr(excess >= I - safety_inventory_level, "excess_def")
    
    # Now build the objective
    revenue = gp.quicksum(sale_price[quarters[j]] * x[i, j] for i in range(n) for j in range(i, n))
    
    purchase_cost = gp.quicksum(purchase_price[quarters[i]] * (gp.quicksum(x[i, j] for j in range(i, n)) + y[i]) for i in range(n))
    
    storage_cost_sales = gp.quicksum(
        (storage_cost_a_w + storage_cost_b_w * (j - i)) * x[i, j] 
        for i in range(n) for j in range(i+1, n)
    )
    
    storage_cost_leftover = gp.quicksum(
        (storage_cost_a_w + storage_cost_b_w * (4 - i)) * y[i] 
        for i in range(n)
    )
    
    terminal_value = terminal_inventory_value * I
    penalty = over_purchase_penalty * excess
    
    profit = revenue - purchase_cost - storage_cost_sales - storage_cost_leftover + terminal_value - penalty
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case of no solution, but the problem should be feasible
        obj_val = 0.0
    
    print(f"FINAL_OBJ_VALUE: {obj_val:.1f}")

if __name__ == "__main__":
    main()
