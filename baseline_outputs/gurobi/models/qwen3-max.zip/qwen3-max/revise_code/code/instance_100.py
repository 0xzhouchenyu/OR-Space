import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load the bandwidth table
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    filepath = os.path.join(data_dir, "table_1.csv")
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        
        bandwidth = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                bandwidth[(row_node, col_node)] = bw

    # Build cost matrix: cost = 100 - bandwidth (if bandwidth > 0), else no edge
    cost = {}
    for (i, j), bw in bandwidth.items():
        if bw > 0:
            cost[(i, j)] = 100 - bw

    # Create a list of edges
    edges = list(cost.keys())

    # Create model
    model = gp.Model("MinCostPath_A_to_E_via_C")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[i,j] = 1 if edge (i,j) is used, 0 otherwise
    x = model.addVars(edges, vtype=GRB.BINARY, name="x")

    # Flow conservation constraints
    # We'll model this as two flows: from A to C and from C to E, but without node repetition.
    # However, a simpler approach: enforce that the path goes from A to E via C by using flow constraints with intermediate node C.

    # Alternative: use a single path from A to E that must include C. We can do this by:
    # - Enforce flow conservation at all nodes except A (source), E (sink), and C (which must be visited).
    # But standard flow doesn't enforce visiting C.

    # Better: use two-commodity flow or simply enforce that the path is simple and includes C.
    # Since the graph is small, we can use MTZ-like constraints or just use flow with an extra constraint that C has inflow >=1 and outflow>=1.

    # Standard approach for path from A to E via C:
    # Let’s define flow variables for a single path. We require:
    # - Outflow from A: 1
    # - Inflow to E: 1
    # - For C: inflow = 1 and outflow = 1 (so it's an intermediate node)
    # - For other nodes (B, D): inflow = outflow (and either 0 or 1)

    # But note: the path must be simple (no loops). The flow formulation with binary variables and flow conservation will naturally avoid cycles if we don't allow fractional flows? 
    # However, with only flow conservation, we might get subtours. But since we have a single unit of flow from A to E, and we require C to be visited, we can do:

    # Constraints:
    # 1. Flow out of A: sum_{j} x[A,j] = 1
    # 2. Flow into E: sum_{i} x[i,E] = 1
    # 3. For node C: sum_{i} x[i,C] = 1 and sum_{j} x[C,j] = 1
    # 4. For other nodes (B, D): sum_{i} x[i,k] = sum_{j} x[k,j]  (flow conservation)
    # 5. Additionally, to prevent subtours that don't include the whole path, we rely on the fact that we have a single path from A to E and the graph is small.

    # However, note: the path must be connected and simple. The above constraints might allow two separate cycles? But we have only one unit of flow from A to E, so it should be a single path.

    # But caution: without additional constraints, we might have a path that goes A->...->C->...->E and also a separate cycle? However, because we are minimizing cost and all costs are positive (since bandwidth <=100, cost>=0), the optimal solution won't include extra cycles.

    # So we assume that the flow conservation and the requirement of one unit from A to E will yield a simple path.

    # Define the set of nodes
    all_nodes = set(nodes)
    source = 'A'
    target = 'E'
    via = 'C'

    # Constraint: outflow from source = 1
    model.addConstr(gp.quicksum(x[i,j] for (i,j) in edges if i == source) == 1, "outflow_A")

    # Constraint: inflow to target = 1
    model.addConstr(gp.quicksum(x[i,j] for (i,j) in edges if j == target) == 1, "inflow_E")

    # Constraint: for via node C, inflow = 1 and outflow = 1
    model.addConstr(gp.quicksum(x[i,j] for (i,j) in edges if j == via) == 1, "inflow_C")
    model.addConstr(gp.quicksum(x[i,j] for (i,j) in edges if i == via) == 1, "outflow_C")

    # Flow conservation for other nodes (not A, not E, not C)
    other_nodes = all_nodes - {source, target, via}
    for node in other_nodes:
        inflow = gp.quicksum(x[i,j] for (i,j) in edges if j == node)
        outflow = gp.quicksum(x[i,j] for (i,j) in edges if i == node)
        model.addConstr(inflow == outflow, f"flow_conservation_{node}")

    # Additionally, we must ensure that the path is connected and that there are no disconnected components.
    # However, with the above and the fact that we have a single unit of flow, and positive costs, it should be okay.

    # But note: what if there is a path that goes A->C and then C->E, but also a separate cycle? The flow conservation for other nodes would allow a cycle if the inflow=outflow, but then the total flow from A would be more than 1? 
    # Actually, our constraint for A is exactly 1 outflow, and for E exactly 1 inflow, and for C exactly 1 in and 1 out. So any extra cycle would require extra flow, which we don't have. So it's safe.

    # Objective: minimize total cost
    model.setObjective(gp.quicksum(cost[e] * x[e] for e in edges), GRB.MINIMIZE)

    # Optimize
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # In case of no solution, but the problem should have a solution
        # Let's try to find a feasible path by brute force as fallback? But the problem states there is a solution.
        # We'll assume Gurobi finds it.
        print("FINAL_OBJ_VALUE: inf")

if __name__ == '__main__':
    main()
