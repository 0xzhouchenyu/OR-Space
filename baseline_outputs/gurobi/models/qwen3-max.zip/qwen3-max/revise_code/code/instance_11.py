import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    # Read CSVs
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    # Parse Table 1
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]
    
    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    # Note: Inspection hours in table_1 are not used directly due to revision
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])
    
    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])
    
    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp_internal = float(row_cap['Inspection_hours_per_unit'])  # internal inspection capacity
    
    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])
    cost_asm = float(row_cost['Assembly_hours_per_unit'])
    # cost_insp from table_1 is overridden by new parameters
    
    # Parse Parameters
    min_profit = float(df_params[df_params['Parameter_Name'] == 'min_weekly_profit']['Value'].iloc[0])
    min_a = float(df_params[df_params['Parameter_Name'] == 'min_type_a_production']['Value'].iloc[0])
    planning_horizon_weeks = int(df_params[df_params['Parameter_Name'] == 'planning_horizon_weeks']['Value'].iloc[0])
    idle_tolerance = float(df_params[df_params['Parameter_Name'] == 'idle_tolerance']['Value'].iloc[0])
    
    # New inspection parameters
    insp_a_M = float(df_params[df_params['Parameter_Name'] == 'insp_a_M']['Value'].iloc[0])
    insp_b_M = float(df_params[df_params['Parameter_Name'] == 'insp_b_M']['Value'].iloc[0])
    insp_a_E = float(df_params[df_params['Parameter_Name'] == 'insp_a_E']['Value'].iloc[0])
    insp_b_E = float(df_params[df_params['Parameter_Name'] == 'insp_b_E']['Value'].iloc[0])
    cap_ext = float(df_params[df_params['Parameter_Name'] == 'cap_ext']['Value'].iloc[0])
    cost_insp_M = float(df_params[df_params['Parameter_Name'] == 'cost_insp_M']['Value'].iloc[0])
    cost_insp_E = float(df_params[df_params['Parameter_Name'] == 'cost_insp_E']['Value'].iloc[0])
    cost_ext = float(df_params[df_params['Parameter_Name'] == 'cost_ext']['Value'].iloc[0])
    mode_fee_M = float(df_params[df_params['Parameter_Name'] == 'mode_fee_M']['Value'].iloc[0])
    mode_fee_E = float(df_params[df_params['Parameter_Name'] == 'mode_fee_E']['Value'].iloc[0])
    risk_penalty_M = float(df_params[df_params['Parameter_Name'] == 'risk_penalty_M']['Value'].iloc[0])
    cost_insp_weight = float(df_params[df_params['Parameter_Name'] == 'cost_insp_weight']['Value'].iloc[0])
    
    # Create model
    model = gp.Model("TwoWeekMotorcycleProduction")
    model.setParam('OutputFlag', 0)
    
    # Decision variables for each week (0 and 1)
    x_A = {}  # production of Type A in week w
    x_B = {}  # production of Type B in week w
    y_M = {}  # 1 if Manual inspection mode is used in week w, 0 otherwise
    y_E = {}  # 1 if Enhanced inspection mode is used in week w, 0 otherwise
    
    for w in range(planning_horizon_weeks):
        x_A[w] = model.addVar(vtype=GRB.INTEGER, lb=min_a, name=f"x_A_{w}")
        x_B[w] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_B_{w}")
        y_M[w] = model.addVar(vtype=GRB.BINARY, name=f"y_M_{w}")
        y_E[w] = model.addVar(vtype=GRB.BINARY, name=f"y_E_{w}")
    
    # Constraint: exactly one inspection mode per week
    for w in range(planning_horizon_weeks):
        model.addConstr(y_M[w] + y_E[w] == 1, f"inspection_mode_{w}")
    
    # Capacity constraints for manufacturing and assembly (same every week)
    for w in range(planning_horizon_weeks):
        model.addConstr(mfg_a * x_A[w] + mfg_b * x_B[w] <= cap_mfg, f"mfg_cap_{w}")
        model.addConstr(asm_a * x_A[w] + asm_b * x_B[w] <= cap_asm, f"asm_cap_{w}")
    
    # Inspection constraints: two cases per week
    for w in range(planning_horizon_weeks):
        # Internal inspection capacity constraint: only active when the mode is selected
        # For Manual: total internal inspection hours <= cap_insp_internal
        model.addConstr(
            insp_a_M * x_A[w] + insp_b_M * x_B[w] <= cap_insp_internal + (1 - y_M[w]) * 1e6,
            f"insp_internal_M_{w}"
        )
        # For Enhanced: internal inspection hours <= cap_insp_internal
        model.addConstr(
            insp_a_E * x_A[w] + insp_b_E * x_B[w] <= cap_insp_internal + (1 - y_E[w]) * 1e6,
            f"insp_internal_E_{w}"
        )
        # External inspection capacity constraint for Enhanced mode
        model.addConstr(
            insp_a_E * x_A[w] + insp_b_E * x_B[w] <= cap_insp_internal + cap_ext + (1 - y_E[w]) * 1e6,
            f"insp_total_E_{w}"
        )
        # But note: in Enhanced mode, we can use up to cap_insp_internal internally and cap_ext externally.
        # However, the problem does not require splitting internal/external usage explicitly; 
        # the total inspection time required in Enhanced mode must be <= cap_insp_internal + cap_ext.
        # And in Manual mode, no external inspection is used, so total must be <= cap_insp_internal.
        # The above two constraints for Enhanced are redundant? Let's clarify:
        # Actually, the internal capacity is always capped at cap_insp_internal, and external adds cap_ext only in Enhanced.
        # So total inspection capacity in Enhanced = cap_insp_internal + cap_ext.
        # In Manual, total inspection capacity = cap_insp_internal.
        # Therefore, we can write:
        model.addConstr(
            insp_a_M * x_A[w] * y_M[w] + insp_b_M * x_B[w] * y_M[w] +
            insp_a_E * x_A[w] * y_E[w] + insp_b_E * x_B[w] * y_E[w] <= 
            cap_insp_internal + cap_ext * y_E[w],
            f"insp_total_{w}"
        )
    
    # Profit calculation per week
    profit = {}
    for w in range(planning_horizon_weeks):
        # Cost for Type A
        cost_a_M = mfg_a * cost_mfg + asm_a * cost_asm + insp_a_M * cost_insp_M
        cost_a_E = mfg_a * cost_mfg + asm_a * cost_asm + insp_a_E * cost_insp_E
        # Cost for Type B
        cost_b_M = mfg_b * cost_mfg + asm_b * cost_asm + insp_b_M * cost_insp_M
        cost_b_E = mfg_b * cost_mfg + asm_b * cost_asm + insp_b_E * cost_insp_E
        
        # Total cost in week w
        total_cost = (
            (cost_a_M * x_A[w] + cost_b_M * x_B[w] + mode_fee_M + risk_penalty_M) * y_M[w] +
            (cost_a_E * x_A[w] + cost_b_E * x_B[w] + mode_fee_E) * y_E[w]
        )
        
        # Revenue
        revenue = price_a * x_A[w] + price_b * x_B[w]
        
        profit[w] = revenue - total_cost
        
        # Minimum profit constraint per week
        model.addConstr(profit[w] >= min_profit, f"min_profit_{w}")
    
    # Idle time calculation for each process and week
    # Manufacturing idle time
    idle_mfg = {}
    idle_asm = {}
    idle_insp = {}
    for w in range(planning_horizon_weeks):
        used_mfg = mfg_a * x_A[w] + mfg_b * x_B[w]
        used_asm = asm_a * x_A[w] + asm_b * x_B[w]
        # For inspection, the used time depends on the mode
        used_insp = (
            (insp_a_M * x_A[w] + insp_b_M * x_B[w]) * y_M[w] +
            (insp_a_E * x_A[w] + insp_b_E * x_B[w]) * y_E[w]
        )
        idle_mfg[w] = cap_mfg - used_mfg
        idle_asm[w] = cap_asm - used_asm
        idle_insp[w] = (cap_insp_internal + cap_ext * y_E[w]) - used_insp
        
    # Weighted idle time cost (to be minimized first)
    # Weights: cost_mfg, cost_asm, cost_insp_weight (for inspection)
    weighted_idle = gp.quicksum(
        cost_mfg * idle_mfg[w] + 
        cost_asm * idle_asm[w] + 
        cost_insp_weight * idle_insp[w]
        for w in range(planning_horizon_weeks)
    )
    
    # Total profit over two weeks (to be maximized secondarily)
    total_profit = gp.quicksum(profit[w] for w in range(planning_horizon_weeks))
    
    # Lexicographic optimization: first minimize weighted idle, then maximize total profit
    # Step 1: Minimize weighted idle
    model.setObjective(weighted_idle, GRB.MINIMIZE)
    model.optimize()
    
    if model.status != GRB.OPTIMAL:
        raise Exception("Step 1: No optimal solution found")
    
    min_idle_val = model.objVal
    
    # Step 2: Maximize total profit subject to weighted idle <= min_idle_val + tolerance
    model.addConstr(weighted_idle <= min_idle_val + idle_tolerance, "idle_tolerance_constr")
    model.setObjective(total_profit, GRB.MAXIMIZE)
    model.optimize()
    
    if model.status != GRB.OPTIMAL:
        raise Exception("Step 2: No optimal solution found")
    
    final_obj = model.objVal
    print(f"FINAL_OBJ_VALUE: {round(final_obj, 4)}")

if __name__ == '__main__':
    solve()
