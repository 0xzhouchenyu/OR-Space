import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # Load data
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            if val.lower() == 'unlimited':
                params[name] = float('inf')
            else:
                params[name] = float(val)
    
    # Extract parameters
    a1_yield = params['product_A1_yield']       # 3 kg per barrel
    a1_time = params['product_A1_time']         # 12 hours per barrel
    a2_yield = params['product_A2_yield']       # 4 kg per barrel
    a2_time = params['product_A2_time']         # 8 hours per barrel
    a3_yield = params['product_A3_yield']       # 2 kg per barrel
    a3_time = params['product_A3_time']         # 10 hours per barrel
    
    profit_a1 = params['profit_per_kg_A1']      # 24 yuan/kg
    profit_a2 = params['profit_per_kg_A2']      # 16 yuan/kg
    profit_a3 = params['profit_per_kg_A3']      # 30 yuan/kg
    
    milk_supply = params['daily_milk_supply']    # 50 barrels
    labor_hours = params['daily_labor_hours']    # 480 hours
    cap_A_shared = params['cap_A_shared']        # 90 kg shared capacity for A1 and A3
    min_A2_kg = params['min_A2_kg']              # 40 kg minimum A2
    min_A3_kg = params['min_A3_kg']              # 20 kg minimum A3
    cleaning_loss = params['type_A_cleaning_loss_if_A3']  # 12 kg
    bonus_threshold = params['cold_chain_bonus_threshold_kg']  # 30 kg
    bonus_amount = params['cold_chain_bonus_yuan']  # 300 yuan
    
    # Create model
    model = gp.Model("Dairy_Production_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables: barrels of milk for each product
    x1 = model.addVar(lb=0, name="x1")  # barrels for A1
    x2 = model.addVar(lb=0, name="x2")  # barrels for A2
    x3 = model.addVar(lb=0, name="x3")  # barrels for A3
    
    # Binary variable for cold-chain bonus: 1 if A3 production >= bonus_threshold, else 0
    y = model.addVar(vtype=GRB.BINARY, name="y")
    
    # Production quantities in kg
    prod_A1 = a1_yield * x1
    prod_A2 = a2_yield * x2
    prod_A3 = a3_yield * x3
    
    # Objective: maximize profit + bonus
    total_profit = (profit_a1 * prod_A1 + 
                    profit_a2 * prod_A2 + 
                    profit_a3 * prod_A3 + 
                    bonus_amount * y)
    model.setObjective(total_profit, GRB.MAXIMIZE)
    
    # Constraints
    # Milk supply
    model.addConstr(x1 + x2 + x3 <= milk_supply, "Milk_Supply")
    
    # Labor hours
    model.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours, "Labor_Hours")
    
    # Shared Type A capacity for A1 and A3
    # If A3 is produced at all (x3 > 0), then we lose cleaning_loss from the shared capacity.
    # However, note: the problem states "Running A3 requires a cleaning block that removes `type_A_cleaning_loss_if_A3` kg from the shared Type A ceiling."
    # This implies that if we produce any A3, the available capacity for A1 and A3 together is reduced by cleaning_loss.
    # But note: the shared capacity is already given as cap_A_shared = 90 kg. The cleaning loss is an additional reduction only when A3 is run.
    # So the effective capacity for A1 and A3 is: cap_A_shared - (cleaning_loss if x3 > 0 else 0)
    # We model this with a big-M constraint using the binary variable for A3 production.
    
    # First, we need a binary variable to indicate if A3 is produced (x3 > 0). However, note that we have a minimum production for A3 (min_A3_kg).
    # Since min_A3_kg = 20 kg, and a3_yield = 2 kg/barrel, then x3 >= 10 barrels. So if we produce A3, it's at least 10 barrels.
    # But the problem says "Running A3" - so if we produce any positive amount (which we must at least min_A3_kg if we choose to run it? Actually, the min_A3_kg is a hard constraint: we must produce at least 20 kg of A3).
    # However, note: the business requirement says "min_A3_kg,20,kg,Minimum daily A3 production", so we must have prod_A3 >= 20.
    # Therefore, if the model decides to produce A3, it must be at least 20 kg. So we don't have the option of producing a tiny amount.
    # But the cleaning loss applies whenever A3 is run, and since we have a minimum, if we produce A3 we are definitely running it.
    # However, what if we don't produce A3? The min_A3_kg constraint would force us to produce at least 20 kg, so actually we must produce A3? 
    # Let me check: the constraint is "min_A3_kg,20,kg,Minimum daily A3 production". So yes, we must produce at least 20 kg of A3. Therefore, A3 is always produced.
    # But wait: the problem says "min_A3_kg,20,kg,Minimum daily A3 production", so it's a hard constraint. Therefore, we must have prod_A3 >= 20.
    # Similarly, min_A2_kg = 40 kg, so prod_A2 >= 40.
    
    # However, let me re-read: "A2 must still satisfy the butter bundle" -> which is the min_A2_kg. And "min_A3_kg,20,kg,Minimum daily A3 production" is also a constraint.
    # So both A2 and A3 have minimum production requirements. Therefore, we will always produce A3 (at least 20 kg) and A2 (at least 40 kg).
    # Thus, the cleaning loss always applies? Because we are always running A3.
    
    # But wait: what if the constraints make it impossible to produce A3? Then the problem would be infeasible. However, the problem states these as requirements, so we assume feasibility.
    # Given that, we can simply subtract the cleaning loss from the shared capacity because A3 is always produced (due to the minimum constraint).
    
    # However, let's check the numbers:
    #   min_A3_kg = 20 kg -> x3 >= 10 barrels.
    #   min_A2_kg = 40 kg -> x2 >= 10 barrels.
    #   Milk: x1 + x2 + x3 <= 50 -> x1 <= 30.
    #   Labor: 12*x1 + 8*x2 + 10*x3 <= 480.
    #   With x2>=10, x3>=10: 8*10 + 10*10 = 180, so 12*x1 <= 300 -> x1 <= 25.
    #   Type A: A1 production = 3*x1, and A3 production = 2*x3 (but note: A3 uses Type A? The problem says: "Running A3 requires a cleaning block that removes ... from the shared Type A ceiling", so A3 uses Type A equipment? 
    #   The original problem: A1 uses Type A, A2 uses Type B. Now A3 is introduced and it uses Type A (because it affects Type A capacity).
    #   So both A1 and A3 use Type A equipment. The shared capacity for Type A is cap_A_shared = 90 kg, but when A3 is run, we lose cleaning_loss = 12 kg, so the effective capacity is 90 - 12 = 78 kg.
    #   And we must have: A1 + A3 <= 78 kg.
    #   With min_A3_kg=20, then A1 <= 58 kg -> x1 <= 58/3 ≈ 19.33.
    
    # Therefore, since we must produce A3 (at least 20 kg), the cleaning loss always applies. So we can model the Type A constraint as:
    #   prod_A1 + prod_A3 <= cap_A_shared - cleaning_loss
    #   => 3*x1 + 2*x3 <= 90 - 12 = 78
    
    # But wait: what if the business intended that the cleaning loss is only applied if we produce A3, and without the minimum constraint we might not produce A3? However, the data includes min_A3_kg=20, so we must produce A3.
    # Therefore, we can hardcode the reduction.
    
    # However, the problem statement says: "Running A3 requires a cleaning block that removes `type_A_cleaning_loss_if_A3` kg from the shared Type A ceiling." 
    # And the data has min_A3_kg=20, so we are always running A3. So the constraint is:
    model.addConstr(prod_A1 + prod_A3 <= cap_A_shared - cleaning_loss, "Type_A_Capacity")
    
    # Minimum production constraints
    model.addConstr(prod_A2 >= min_A2_kg, "Min_A2")
    model.addConstr(prod_A3 >= min_A3_kg, "Min_A3")
    
    # Cold-chain bonus: y = 1 if prod_A3 >= bonus_threshold, else 0.
    # We use a big-M constraint. Since prod_A3 is at most (milk_supply * a3_yield) = 50*2=100 kg, we can set M=100.
    M = 100
    model.addConstr(prod_A3 >= bonus_threshold * y, "Bonus_Threshold_Lower")
    model.addConstr(prod_A3 <= bonus_threshold - 1e-5 + M * y, "Bonus_Threshold_Upper")
    # Note: The second constraint ensures that if prod_A3 < bonus_threshold, then y must be 0.
    # However, because of the minimum production (20 kg) and bonus_threshold=30, it's possible that prod_A3 is between 20 and 30, then y=0; or >=30, then y=1.
    
    # Optimize
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case of infeasibility, we might need to handle, but the problem assumes feasibility.
        obj_val = 0
    
    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == "__main__":
    main()
