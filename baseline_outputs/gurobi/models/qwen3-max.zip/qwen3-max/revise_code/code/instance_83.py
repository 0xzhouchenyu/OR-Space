import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Read time periods and minimum waiters needed
time_periods = []
min_waiters = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        time_periods.append(row['Time'].strip())
        min_waiters.append(int(row['Minimum_Number_of_Waiters_Needed'].strip()))

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        param_name = row['Parameter_Name'].strip()
        value = float(row['Value'].strip())
        params[param_name] = value

n = len(time_periods)  # 6 periods

# Extract peak indicators and quality weights
peak = [int(params[f'peak_{i}']) for i in range(n)]
quality = [params[f'quality_{i}'] for i in range(n)]
waiter_cost_per_shift = params['waiter_cost_per_shift']
waiter_budget = params['waiter_budget']

# Each waiter works 8 hours = 2 consecutive 4-hour periods
# x_i = number of waiters starting work at the beginning of period i
# They work during periods i and (i+1) mod n

model = gp.Model("Restaurant_Waiters_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="x")

# Objective: maximize total service_quality_score
# Service quality in period j is (number of waiters working in j) * quality_j
# Waiters working in period j = x[(j-1) % n] + x[j]
total_quality = gp.quicksum((x[(j-1) % n] + x[j]) * quality[j] for j in range(n))
model.setObjective(total_quality, GRB.MAXIMIZE)

# Constraints:
# 1. Coverage: for each period j, waiters working >= min_waiters[j]
for j in range(n):
    model.addConstr(x[(j-1) % n] + x[j] >= min_waiters[j], f"coverage_period_{j}")

# 2. Budget: total cost <= waiter_budget
# Each waiter shift costs waiter_cost_per_shift
total_cost = gp.quicksum(x[i] * waiter_cost_per_shift for i in range(n))
model.addConstr(total_cost <= waiter_budget, "budget")

# Solve
model.optimize()

# Print final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case no feasible solution, but problem should be feasible
    print("FINAL_OBJ_VALUE: -1")
