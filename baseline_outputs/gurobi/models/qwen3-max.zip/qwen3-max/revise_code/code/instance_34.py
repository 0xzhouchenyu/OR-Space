import os
import gurobipy as gp
from gurobipy import GRB
from utils import load_goods_data, load_parameters

# Load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")
goods = load_goods_data(os.path.join(data_dir, 'table_1.csv'))
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

max_cap = params['max_container_capacity']
min_load = params['min_container_load']
min_d_per_container = int(params['min_d_goods_per_container'])
min_c_per_a = int(params['min_c_per_a'])

goods_types = list(goods.keys())
quantities = {g: goods[g]['quantity'] for g in goods_types}
weights = {g: goods[g]['weight'] for g in goods_types}

# Compute a safe upper bound on the number of containers
# Total weight of all goods
total_weight = sum(quantities[g] * weights[g] for g in goods_types)
# Minimum containers needed by weight (using min_load per container)
min_containers_by_weight = total_weight / max_cap
# Also, D constraint: 90 units, min 10 per container -> at least ceil(90/10)=9 containers? 
# But note: we can put more than 10 D in a container, so max containers needed for D is 90 (if 1 per container) but that's not binding.
# However, the fragile constraint might force more containers. Let's use a generous bound.
# Total items: 120+90+300+90+120 = 720. Max per container? Not clear, but 20 containers should be safe.
max_containers = 20

# Create model
model = gp.Model("ContainerMinimization")
model.setParam('OutputFlag', 0)

# Decision variables
# x[g][j] = number of units of goods type g in container j
x = {}
for g in goods_types:
    x[g] = {}
    for j in range(max_containers):
        x[g][j] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{g}_{j}")

# y[j] = 1 if container j is used
y = {}
for j in range(max_containers):
    y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")

# z[j] = 1 if container j has any A goods (for the A->C constraint)
z = {}
for j in range(max_containers):
    z[j] = model.addVar(vtype=GRB.BINARY, name=f"z_{j}")

# w[j] = 1 if container j has any E goods (for the fragile constraint)
w = {}
for j in range(max_containers):
    w[j] = model.addVar(vtype=GRB.BINARY, name=f"w_{j}")

# Objective: minimize number of containers
model.setObjective(gp.quicksum(y[j] for j in range(max_containers)), GRB.MINIMIZE)

# All goods must be transported
for g in goods_types:
    model.addConstr(gp.quicksum(x[g][j] for j in range(max_containers)) == quantities[g], f"demand_{g}")

# Container capacity constraints
# For containers without E: capacity = 60
# For containers with E: capacity = 45
M = max_cap  # big-M for E indicator
for j in range(max_containers):
    # Link w[j] to presence of E: if x['E'][j] >= 1 then w[j] = 1; if x['E'][j] = 0 then w[j] can be 0.
    # We use: x['E'][j] <= quantities['E'] * w[j]
    model.addConstr(x['E'][j] <= quantities['E'] * w[j], f"E_indicator_upper_{j}")
    # Also, to ensure w[j]=0 when x['E'][j]=0, we don't need a lower bound because the objective minimizes containers and w[j] only appears in constraints that are relaxed when w[j]=0.
    # But to be safe, we can also add: w[j] <= x['E'][j] (but x['E'][j] is integer, so if x['E'][j]>=1 then w[j] must be 1). However, the above constraint already forces w[j]=1 if x['E'][j]>=1, and if x['E'][j]=0, w[j] can be 0 (which is optimal). So it's sufficient.

    # Capacity constraint: total weight <= 60*(1-w[j]) + 45*w[j] = 60 - 15*w[j]
    total_weight_j = gp.quicksum(weights[g] * x[g][j] for g in goods_types)
    model.addConstr(total_weight_j <= max_cap - 15 * w[j], f"capacity_{j}")

# Minimum load constraint: if container is used, total weight >= min_load
for j in range(max_containers):
    total_weight_j = gp.quicksum(weights[g] * x[g][j] for g in goods_types)
    model.addConstr(total_weight_j >= min_load * y[j], f"min_load_{j}")

# Minimum D goods per container (if container is used)
for j in range(max_containers):
    model.addConstr(x['D'][j] >= min_d_per_container * y[j], f"min_D_{j}")

# If A goods are loaded, at least min_c_per_a C goods must be loaded
M_A = quantities['A']
for j in range(max_containers):
    # z[j] = 1 if A is present
    model.addConstr(x['A'][j] <= M_A * z[j], f"A_indicator_{j}")
    model.addConstr(x['C'][j] >= min_c_per_a * z[j], f"C_if_A_{j}")
    # Also, we need to link z[j] to y[j]? Actually, if the container is not used (y[j]=0), then x['A'][j]=0, so z[j] can be 0. The constraint x['A'][j] <= M_A * z[j] will be satisfied with z[j]=0. And the C constraint becomes x['C'][j] >= 0, which is always true. So no extra constraint needed.

# Additionally, we must ensure that if a container is not used, then no goods are in it.
# But note: the demand constraints and the capacity constraints (with y[j]) already imply that if y[j]=0, then total weight=0, so all x[g][j]=0. However, to be explicit and safe, we can add:
for j in range(max_containers):
    for g in goods_types:
        model.addConstr(x[g][j] <= quantities[g] * y[j], f"link_x_y_{g}_{j}")

# Symmetry breaking: order the containers so that if container j is not used, then j+1 is not used.
for j in range(max_containers - 1):
    model.addConstr(y[j] >= y[j+1], f"symmetry_{j}")

# Optimize
model.optimize()

if model.status == GRB.OPTIMAL or model.status == GRB.SUBOPTIMAL:
    obj_val = model.objVal
else:
    # In case of no solution, we try to get the best bound or set to a large number, but the problem should be feasible.
    obj_val = float('inf')

print(f"FINAL_OBJ_VALUE: {obj_val}")
