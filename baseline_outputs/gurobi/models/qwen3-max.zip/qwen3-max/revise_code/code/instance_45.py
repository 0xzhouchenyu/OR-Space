import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    # Read product segments and profits
    products = []
    segments = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row['Product']
            if p not in segments:
                segments[p] = []
                products.append(p)
            rng = row['Sales_Volume_Range']
            profit = float(row['Profit'])
            if rng.startswith('Above_'):
                lower = float(rng.split('_')[1])
                upper = None
            else:
                parts = rng.split('_')
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({'lower': lower, 'upper': upper, 'profit': profit})

    model = gp.Model("Maximize_Profit")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {}  # production quantities
    y = {}  # segment selection binaries
    p_var = {}  # profit contribution per product

    for prod in products:
        pname = prod.split('_')[1]
        x[prod] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{pname}")
        p_var[prod] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"p_{pname}")
        y[prod] = []
        for i in range(len(segments[prod])):
            yi = model.addVar(vtype=GRB.BINARY, name=f"y_{pname}_{i}")
            y[prod].append(yi)

    # Overtime variable
    overtime = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=params['overtime_cap_hours'], name="overtime")
    # Binary variable for second review fee
    z = model.addVar(vtype=GRB.BINARY, name="z")

    M = 10000

    # Objective: total profit minus overtime cost minus second review fee
    total_profit = gp.quicksum(p_var[prod] for prod in products)
    overtime_cost = params['overtime_cost_per_hour'] * overtime
    second_review_fee = params['overtime_second_review_fee'] * z
    model.setObjective(total_profit - overtime_cost - second_review_fee, GRB.MAXIMIZE)

    # Segment constraints
    for prod in products:
        segs = segments[prod]
        # Mutual exclusivity: at most one segment active
        model.addConstr(gp.quicksum(y[prod]) <= 1, name=f"mutual_excl_{prod}")

        for i, seg in enumerate(segs):
            lo = seg['lower']
            hi = seg['upper']
            profit = seg['profit']

            # If y[i]=1, x must be in [lo+1, hi] (or [lo+1, inf] for last segment)
            if lo == 0:
                model.addConstr(x[prod] >= 1 - M * (1 - y[prod][i]), name=f"seg_lo_{prod}_{i}")
            else:
                model.addConstr(x[prod] >= (lo + 1) - M * (1 - y[prod][i]), name=f"seg_lo_{prod}_{i}")

            if hi is not None:
                model.addConstr(x[prod] <= hi + M * (1 - y[prod][i]), name=f"seg_hi_{prod}_{i}")

            # Profit bound
            model.addConstr(p_var[prod] <= profit * x[prod] + M * (1 - y[prod][i]), name=f"profit_bound_{prod}_{i}")

        # If no segment active (production=0), force x=0 and profit=0
        model.addConstr(x[prod] <= M * gp.quicksum(y[prod]), name=f"x_zero_if_no_seg_{prod}")
        model.addConstr(p_var[prod] <= M * gp.quicksum(y[prod]), name=f"profit_zero_if_no_seg_{prod}")

    # Resource constraints
    # Technical preparation time
    model.addConstr(
        gp.quicksum(params[f"technical_prep_time_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params['available_technical_prep_time'],
        name="tech_prep"
    )

    # Labor time: regular + overtime
    total_labor = gp.quicksum(params[f"labor_time_{prod.split('_')[1]}"] * x[prod] for prod in products)
    model.addConstr(
        total_labor <= params['available_labor_time'] + overtime,
        name="labor"
    )

    # Materials
    model.addConstr(
        gp.quicksum(params[f"materials_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params['available_materials'],
        name="materials"
    )

    # Packaging constraint
    model.addConstr(
        gp.quicksum(params[f"pack_units_{prod.split('_')[1]}"] * x[prod] for prod in products)
        <= params['packaging_cap_units'],
        name="packaging"
    )

    # Second review tier constraints
    # If overtime > 100, then z must be 1
    model.addConstr(overtime <= params['overtime_second_review_threshold'] + M * z, name="overtime_threshold_ub")
    # If z=0, then overtime <= 100
    model.addConstr(overtime >= params['overtime_second_review_threshold'] + 1 - M * (1 - z), name="overtime_threshold_lb")

    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
        print(f"FINAL_OBJ_VALUE: {obj_val:.2f}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
