import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = params['min_manager_experience']
    manager_bonus_per_candidate = params['manager_bonus_per_candidate']

    # Create optimization model
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0)

    # Decision variables: 
    # x[c] = 1 if candidate c is hired (in any role), 0 otherwise
    # y[c] = 1 if candidate c is hired as a manager, 0 otherwise
    x = {}
    y = {}
    for c in candidates:
        name = c['name']
        x[name] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}")
        y[name] = model.addVar(vtype=GRB.BINARY, name=f"y_{name}")

    # Each hired candidate can serve in at most one role, and if hired as manager then must be hired
    for c in candidates:
        name = c['name']
        model.addConstr(y[name] <= x[name], name=f"role_link_{name}")

    # Objective: minimize total cost = base salaries + manager bonuses
    total_cost = gp.quicksum(c['salary'] * x[c['name']] for c in candidates) + \
                 manager_bonus_per_candidate * gp.quicksum(y[c['name']] for c in candidates)
    model.setObjective(total_cost, GRB.MINIMIZE)

    # Constraint 1: max employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) <= max_employees, "max_employees")

    # Constraint 2: budget (base salaries only, excluding manager bonus)
    model.addConstr(gp.quicksum(c['salary'] * x[c['name']] for c in candidates) <= budget_limit, "budget")

    # Constraint 3: at least one with Master's or Doctoral degree
    advanced_candidates = [c for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(x[c['name']] for c in advanced_candidates) >= min_advanced, "min_advanced")

    # Constraint 4: minimum total work experience of all selected candidates
    model.addConstr(gp.quicksum(c['experience'] * x[c['name']] for c in candidates) >= min_experience, "min_experience_total")

    # Constraint 5: at most one from pair A and E
    model.addConstr(x['A'] + x['E'] <= max_equivalent, "max_equivalent_A_E")

    # Constraint 6: minimum employees
    model.addConstr(gp.quicksum(x[c['name']] for c in candidates) >= min_employees, "min_employees")

    # Constraint 7: manager headcount limits
    total_managers = gp.quicksum(y[c['name']] for c in candidates)
    model.addConstr(total_managers >= min_managers, "min_managers")
    model.addConstr(total_managers <= max_managers, "max_managers")

    # Constraint 8: minimum total work experience of hired managers
    model.addConstr(gp.quicksum(c['experience'] * y[c['name']] for c in candidates) >= min_manager_experience, "min_manager_experience")

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        obj_val = model.objVal
    else:
        # In case no solution found, but problem should be feasible
        obj_val = 0

    print(f"FINAL_OBJ_VALUE: {obj_val}")

if __name__ == '__main__':
    main()
