import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load demand forecast
demand = {}
with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for i, row in enumerate(reader):
        demand[i] = float(row['Demand_Forecast'])

T = len(demand)  # 6 months

# Load general parameters
params = {}
with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

W0 = int(params['initial_workforce'])
I0 = params['initial_inventory']
sp = params['sales_price']
rmc = params['raw_material_cost']
oc = params['outsourcing_cost']
hc = params['inventory_holding_cost']
bc = params['backorder_cost']
lr = params['labor_requirement']
rh = params['regular_labor_hours']
rw = params['regular_wage']
otl = params['overtime_hours_limit']
ow = params['overtime_wage']
hire_cost = params['hiring_cost']
fire_cost = params['firing_cost']
term_inv = params['terminal_inventory']
term_bo = params['terminal_backorders']
contract_min_units = params['contract_min_units']
contract_bigM = params['contract_bigM']

# Create model
model = gp.Model("FoldableTableProduction")
model.setParam('OutputFlag', 0)

# Decision variables
W = model.addVars(T, lb=0, name="W")  # workforce
H = model.addVars(T, lb=0, name="H")  # hired
F = model.addVars(T, lb=0, name="F")  # fired
P = model.addVars(T, lb=0, name="P")  # in-house production
OT_total = model.addVars(T, lb=0, name="OT")  # total overtime hours
O = model.addVars(T, lb=0, name="O")  # outsourced units
Inv = model.addVars(T, lb=0, name="Inv")  # inventory
B = model.addVars(T, lb=0, name="B")  # backorders

# For the contract requirement: regular-time production in April-June (t=3,4,5)
# We need to know how much of P[t] is produced in regular time vs overtime.
# Since regular time capacity is W[t] * rh, and each unit takes lr hours,
# the maximum regular-time production is (W[t] * rh) / lr.
# Let R[t] be the amount produced in regular time in month t (for t=3,4,5)
R = model.addVars([3,4,5], lb=0, name="R")

# Also, we need binary variables to handle the constraint that R[t] cannot exceed the actual demand fulfilled in that month.
# However, note the requirement: "the qualifying quantity cannot be larger than the factory’s standard-time output for that month, 
# and it also cannot be larger than the month’s own requirement once the carried backlog is added to the forecast."
# The "month's own requirement" is: demand[t] + B[t-1] (since B[t-1] is the backlog coming in)
# But note: the total amount shipped in month t is: (Inv[t-1] - B[t-1]) + P[t] + O[t] - (Inv[t] - B[t]) = demand[t] + (B[t-1] - B[t])
# Actually, the amount that is used to satisfy the current period's demand (including clearing backlog) is: 
#   shipped = (previous net inventory) + production + outsourcing - ending net inventory
# But the requirement says: "the month’s own requirement once the carried backlog is added to the forecast" -> that is: demand[t] + B[t-1]
# However, note that we might not clear all backlog? But the contract requires that at least contract_min_units are satisfied by regular production.
# And the regular production R[t] must be <= min( (W[t]*rh)/lr , demand[t] + B[t-1] )
# But we cannot have R[t] > P[t] and also R[t] <= (W[t]*rh)/lr.

# Constraints for R[t]:
# 1. R[t] <= P[t]  (cannot produce more in regular time than total production)
# 2. R[t] <= (W[t] * rh) / lr   (regular time capacity in units)
# 3. R[t] <= demand[t] + (B[t-1] if t>0 else 0)   ??? But note: the requirement says "the month’s own requirement once the carried backlog is added to the forecast"
#    However, the problem states: "it also cannot be larger than the month’s own requirement once the carried backlog is added to the forecast"
#    So the upper bound for R[t] is: min( (W[t]*rh)/lr, demand[t] + (B[t-1] if t>0 else 0) )
# But we cannot use B[t-1] in a linear constraint without knowing it? And we have to enforce R[t] <= demand[t] + (B[t-1] if t>0 else 0)
# However, note: the total amount that is available to satisfy the current period's demand (including backlog) is: 
#   available = (I0 if t==0 else Inv[t-1]) + P[t] + O[t] 
#   and the amount that is used to satisfy the current period's demand (including backlog) is: min(available, demand[t] + (B[t-1] if t>0 else 0)) 
#   but actually the model already enforces: 
#        Inv[t] - B[t] = (I0 if t==0 else Inv[t-1]) - (0 if t==0 else B[t-1]) + P[t] + O[t] - demand[t]
#   => The amount shipped in period t = demand[t] + (B[t-1] if t>0 else 0) - B[t]
#   So the total demand (including backlog) that is satisfied in period t is: demand[t] + (B[t-1] if t>0 else 0) - B[t]
#   But the contract requires that at least contract_min_units are satisfied by regular production. However, note the problem says:
#        "at least contract_min_units monthly demand must be fulfilled by in-house production without overtime"
#   and "the qualifying quantity cannot be larger than ... the month’s own requirement once the carried backlog is added to the forecast"
#   So the maximum that can be counted toward the contract is the total demand (including backlog) that is satisfied in that month? 
#   But the problem states: "the month’s own requirement once the carried backlog is added to the forecast" -> that is: demand[t] + (B[t-1] if t>0 else 0)
#   However, we might not satisfy all of that? But the contract requires that we satisfy at least contract_min_units by regular production, so we must satisfy at least contract_min_units of that total requirement by regular production.
#   Therefore, we require: R[t] >= contract_min_units, and also R[t] <= demand[t] + (B[t-1] if t>0 else 0) [because we cannot satisfy more than the total requirement by regular production?]
#   But note: we could satisfy more than the current month's requirement? However, the contract is about fulfilling the demand (including backlog) for that month.
#   Actually, the problem says: "at least contract_min_units monthly demand must be fulfilled by in-house production without overtime"
#   and the "monthly demand" in the context of April-June includes the backlog from March for April, etc.
#   So the requirement is: the amount of regular production that is used to satisfy the demand (including backlog) of that month must be at least contract_min_units.
#   However, the model does not track which production satisfies which demand. But note: we can assume that we use the cheapest or most constrained resource first? 
#   But the problem does not specify. However, the constraint is: we must have at least contract_min_units of regular production that is allocated to the current month's total requirement (demand[t] + backlog_in).
#   Since we are free to allocate, we can always allocate up to min(R[t], demand[t] + backlog_in) to the current month's requirement.
#   Therefore, to satisfy the contract, we require: R[t] >= contract_min_units, and we also require that the total requirement (demand[t] + backlog_in) is at least contract_min_units? 
#   But the problem does not require that the total requirement is at least contract_min_units, it requires that we fulfill at least contract_min_units by regular production.
#   However, if the total requirement is less than contract_min_units, then we cannot fulfill contract_min_units? But the problem states: "at least contract_min_units monthly demand must be fulfilled", meaning that the company must produce at least contract_min_units in regular time and use it to fulfill the demand (which might be less, but then we would have extra? but the contract is about fulfilling demand, so if demand is less, then we only need to fulfill the demand?).
#   But the problem says: "at least contract_min_units monthly demand must be fulfilled", so if the total requirement (demand[t] + backlog_in) is less than contract_min_units, then we only need to fulfill that total requirement by regular production? However, the contract_min_units is a floor on the amount that must be fulfilled by regular production, so if the total requirement is less than contract_min_units, then we must fulfill all of it by regular production? But the problem states "at least contract_min_units", which would be impossible if the total requirement is less. 
#   However, looking at the data: 
#        April: 35000, May:19000, June:18500 -> all are above 15000, and backlog from previous months might add, but even without backlog, they are above 15000.
#   So we assume that the total requirement (demand[t] + backlog_in) is at least contract_min_units? But to be safe, the constraint should be:
#        R[t] >= contract_min_units
#   and we don't need an upper bound from the demand side because if the total requirement is less than contract_min_units, then the constraint R[t] >= contract_min_units would be infeasible. But the problem states that the contract_min_units is 15000 and the demands are 35000, 19000, 18500, so it's feasible.

# However, the problem also says: "the qualifying quantity cannot be larger than ... the month’s own requirement once the carried backlog is added to the forecast"
# This is a natural upper bound: we cannot fulfill more demand than exists. So we must have R[t] <= demand[t] + (B[t-1] if t>0 else 0)
# But note: B[t-1] is the backlog at the end of month t-1, which is the backlog carried into month t.

# How to model R[t] <= demand[t] + (B[t-1] if t>0 else 0) for t in {3,4,5}?
# For t=3 (April): R[3] <= demand[3] + B[2]
# For t=4 (May): R[4] <= demand[4] + B[3]
# For t=5 (June): R[5] <= demand[5] + B[4]

# But note: B[2], B[3], B[4] are variables. So we can write these as linear constraints.

# Also, we have:
#   R[t] <= P[t]   for t in {3,4,5}
#   R[t] <= (W[t] * rh) / lr   for t in {3,4,5}

# And the contract requirement: R[t] >= contract_min_units for t in {3,4,5}

# Now, the production constraint: total production P[t] is limited by total labor hours (regular + overtime)
#   P[t] * lr <= W[t] * rh + OT_total[t]   for all t
# And overtime limit: OT_total[t] <= W[t] * otl

# Inventory balance: 
#   For t=0: Inv[0] - B[0] = I0 + P[0] + O[0] - demand[0]
#   For t>=1: Inv[t] - B[t] = Inv[t-1] - B[t-1] + P[t] + O[t] - demand[t]

# Workforce balance:
#   t=0: W[0] = W0 + H[0] - F[0]
#   t>=1: W[t] = W[t-1] + H[t] - F[t]

# Terminal conditions:
#   Inv[5] >= term_inv
#   B[5] <= term_bo (which is 0)

# Objective: maximize net profit
# Revenue = sp * total_demand (since all demand is met by end of June, because B[5]=0)
total_demand = sum(demand[t] for t in range(T))
revenue = sp * total_demand

# Costs:
#   material_cost = rmc * sum(P[t])
#   outsource_cost = oc * sum(O[t])
#   holding_cost = hc * sum(Inv[t])
#   backorder_cost = bc * sum(B[t])
#   regular_labor_cost = rw * rh * sum(W[t])   [because each worker works rh hours at rw per hour]
#   overtime_cost = ow * sum(OT_total[t])
#   hiring_cost = hire_cost * sum(H[t])
#   firing_cost = fire_cost * sum(F[t])

# Note: the regular labor cost is for the regular hours, which is fixed per worker per month, regardless of how much they produce (as long as they are employed). Similarly, overtime cost is only for the overtime hours used.

# Now, set up the model.

# Workforce balance constraints
for t in range(T):
    if t == 0:
        model.addConstr(W[t] == W0 + H[t] - F[t], name=f"workforce_0")
    else:
        model.addConstr(W[t] == W[t-1] + H[t] - F[t], name=f"workforce_{t}")

# Production and overtime constraints
for t in range(T):
    # Total production limited by total labor hours
    model.addConstr(P[t] * lr <= W[t] * rh + OT_total[t], name=f"prod_capacity_{t}")
    # Overtime limit
    model.addConstr(OT_total[t] <= W[t] * otl, name=f"overtime_limit_{t}")

# Inventory balance constraints
for t in range(T):
    if t == 0:
        model.addConstr(Inv[t] - B[t] == I0 + P[t] + O[t] - demand[t], name=f"inv_balance_0")
    else:
        model.addConstr(Inv[t] - B[t] == Inv[t-1] - B[t-1] + P[t] + O[t] - demand[t], name=f"inv_balance_{t}")

# Terminal conditions
model.addConstr(Inv[T-1] >= term_inv, name="terminal_inv")
model.addConstr(B[T-1] <= term_bo, name="terminal_bo")  # term_bo is 0

# Contract constraints for April (t=3), May (t=4), June (t=5)
for t in [3,4,5]:
    # R[t] <= P[t]
    model.addConstr(R[t] <= P[t], name=f"R_le_P_{t}")
    # R[t] <= (W[t] * rh) / lr
    model.addConstr(R[t] <= (W[t] * rh) / lr, name=f"R_le_regcap_{t}")
    # R[t] <= demand[t] + (B[t-1] if t>0 else 0)
    if t == 0:
        model.addConstr(R[t] <= demand[t], name=f"R_le_req_{t}")
    else:
        model.addConstr(R[t] <= demand[t] + B[t-1], name=f"R_le_req_{t}")
    # Contract minimum
    model.addConstr(R[t] >= contract_min_units, name=f"contract_min_{t}")

# Objective function
material_cost = rmc * gp.quicksum(P[t] for t in range(T))
outsource_cost = oc * gp.quicksum(O[t] for t in range(T))
holding_cost = hc * gp.quicksum(Inv[t] for t in range(T))
backorder_cost_total = bc * gp.quicksum(B[t] for t in range(T))
regular_labor_cost = rw * rh * gp.quicksum(W[t] for t in range(T))
overtime_cost = ow * gp.quicksum(OT_total[t] for t in range(T))
hiring_cost_total = hire_cost * gp.quicksum(H[t] for t in range(T))
firing_cost_total = fire_cost * gp.quicksum(F[t] for t in range(T))

total_cost = (material_cost + outsource_cost + holding_cost + backorder_cost_total +
              regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total)

model.setObjective(revenue - total_cost, GRB.MAXIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    obj_val = model.objVal
else:
    # In case of infeasibility, we might want to check, but the problem should be feasible.
    # For the purpose of this problem, we assume optimal solution exists.
    obj_val = 0.0

print(f"FINAL_OBJ_VALUE: {obj_val}")
