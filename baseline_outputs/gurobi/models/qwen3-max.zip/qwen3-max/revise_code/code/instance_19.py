import os
import csv
from utils import load_general_parameters
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract original parameters
cost_A = params['cost_per_chair_A']
cost_B = params['cost_per_chair_B']
cost_C = params['cost_per_chair_C']
chairs_per_order_A = params['chairs_per_order_A']
chairs_per_order_B = params['chairs_per_order_B']
chairs_per_order_C = params['chairs_per_order_C']
min_total = params['min_total_chairs']
max_total = params['max_total_chairs']
min_chairs_B_if_A = params['min_chairs_B_if_A']
dependency_B_C = params['dependency_B_C']

# Extract new parameters from revision
fixed_fee_A_regular = params['fixed_fee_A_regular']
fixed_fee_A_express = params['fixed_fee_A_express']
fixed_fee_B_regular = params['fixed_fee_B_regular']
fixed_fee_B_express = params['fixed_fee_B_express']
fixed_fee_C_regular = params['fixed_fee_C_regular']
fixed_fee_C_express = params['fixed_fee_C_express']
weekly_order_budget = params['weekly_order_budget']

# Create model
model = gp.Model("FurnitureOrderRevised")
model.setParam('OutputFlag', 0)

# Decision variables: number of orders from each manufacturer (integer, >= 0)
max_orders_A = max_total // chairs_per_order_A + 1
max_orders_B = max_total // chairs_per_order_B + 1
max_orders_C = max_total // chairs_per_order_C + 1

x_A = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_A, name="orders_A")
x_B = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_B, name="orders_B")
x_C = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_C, name="orders_C")

# Binary variables for channel selection per manufacturer
# For A: y_A_reg = 1 if regular channel is used, y_A_exp = 1 if express channel is used
y_A_reg = model.addVar(vtype=GRB.BINARY, name="y_A_reg")
y_A_exp = model.addVar(vtype=GRB.BINARY, name="y_A_exp")
y_B_reg = model.addVar(vtype=GRB.BINARY, name="y_B_reg")
y_B_exp = model.addVar(vtype=GRB.BINARY, name="y_B_exp")
y_C_reg = model.addVar(vtype=GRB.BINARY, name="y_C_reg")
y_C_exp = model.addVar(vtype=GRB.BINARY, name="y_C_exp")

# Total chairs
chairs_A = chairs_per_order_A * x_A
chairs_B = chairs_per_order_B * x_B
chairs_C = chairs_per_order_C * x_C

# Objective: minimize total cost = variable chair cost + fixed fees
total_cost = (cost_A * chairs_A + cost_B * chairs_B + cost_C * chairs_C +
              fixed_fee_A_regular * y_A_reg + fixed_fee_A_express * y_A_exp +
              fixed_fee_B_regular * y_B_reg + fixed_fee_B_express * y_B_exp +
              fixed_fee_C_regular * y_C_reg + fixed_fee_C_express * y_C_exp)
model.setObjective(total_cost, GRB.MINIMIZE)

# Constraint: total chairs between min and max
model.addConstr(chairs_A + chairs_B + chairs_C >= min_total, "MinChairs")
model.addConstr(chairs_A + chairs_B + chairs_C <= max_total, "MaxChairs")

# Link orders to channel selection: if any order from a manufacturer, exactly one channel must be selected
M = max_total + 1

# For manufacturer A
model.addConstr(x_A <= M * (y_A_reg + y_A_exp), "LinkA_orders_to_channel")
model.addConstr(y_A_reg + y_A_exp <= 1, "ChannelExclusiveA")  # Cannot use both channels

# For manufacturer B
model.addConstr(x_B <= M * (y_B_reg + y_B_exp), "LinkB_orders_to_channel")
model.addConstr(y_B_reg + y_B_exp <= 1, "ChannelExclusiveB")

# For manufacturer C
model.addConstr(x_C <= M * (y_C_reg + y_C_exp), "LinkC_orders_to_channel")
model.addConstr(y_C_reg + y_C_exp <= 1, "ChannelExclusiveC")

# Dependency: if ordering from A, must order at least min_chairs_B_if_A chairs from B
# Note: chairs_B >= min_chairs_B_if_A if x_A > 0
# We use: chairs_B >= min_chairs_B_if_A * (y_A_reg + y_A_exp)
model.addConstr(chairs_B >= min_chairs_B_if_A * (y_A_reg + y_A_exp), "DepAB")

# Dependency: if ordering from B, must also order from C
# i.e., if (y_B_reg + y_B_exp) == 1 then (y_C_reg + y_C_exp) >= 1
model.addConstr(y_B_reg + y_B_exp <= y_C_reg + y_C_exp, "DepBC")

# Weekly order budget: maximum number of active manufacturer-mode combinations
# Each active combination is when a channel is selected for a manufacturer
active_combinations = (y_A_reg + y_A_exp + y_B_reg + y_B_exp + y_C_reg + y_C_exp)
model.addConstr(active_combinations <= weekly_order_budget, "WeeklyOrderBudget")

# Optimize
model.optimize()

# Output the objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case no solution found, but problem should be feasible
    print("FINAL_OBJ_VALUE: None")
