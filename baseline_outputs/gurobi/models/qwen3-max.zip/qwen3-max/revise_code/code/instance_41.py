import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# Load general parameters
initial_capital = None
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Parameter_Name'].strip() == 'initial_capital':
            initial_capital = float(row['Value'].strip())

# Load liquidity policy parameters
min_year3_reserve = None
reserve_shortfall_penalty = None
with open(os.path.join(data_dir, 'liquidity_policy.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row['Parameter_Name'].strip() == 'min_year3_reserve':
            min_year3_reserve = float(row['Value'].strip())
        elif row['Parameter_Name'].strip() == 'reserve_shortfall_penalty':
            reserve_shortfall_penalty = float(row['Value'].strip())

# Load project data
projects = []
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        projects.append(row)

# Create Gurobi model
model = gp.Model("Investment_Maximization_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
x1_1 = model.addVar(lb=0, name="x1_1")  # Project 1, Year 1
x1_2 = model.addVar(lb=0, name="x1_2")  # Project 1, Year 2
x1_3 = model.addVar(lb=0, name="x1_3")  # Project 1, Year 3
x2 = model.addVar(lb=0, ub=120000, name="x2")   # Project 2
x3 = model.addVar(lb=0, ub=150000, name="x3")   # Project 3
x4 = model.addVar(lb=0, ub=100000, name="x4")   # Project 4

# Auxiliary variable for shortfall in Year 3 reserve
shortfall = model.addVar(lb=0, name="shortfall")

# Year 1 budget constraint
model.addConstr(x1_1 + x2 <= initial_capital, "Year1_Budget")

# Year 2 budget constraint: cash available at beginning of Year 2 is from x1_1 matured (end of Year 1)
model.addConstr(x1_2 + x3 <= x1_1 * 1.20, "Year2_Budget")

# Cash available at beginning of Year 3: 
#   from x1_2 (matures end of Year 2) -> x1_2 * 1.20
#   from x2 (matures end of Year 2) -> x2 * 1.50
#   from x3 (matures end of Year 2) -> x3 * 1.60
cash_year3_start = x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60

# Year 3 investment constraint: only invest what is available beyond the reserve requirement?
# But note: the reserve is uninvested cash that remains through Year 3.
# So: x1_3 + x4 + (uninvested cash) = cash_year3_start
# And the uninvested cash must be at least (min_year3_reserve - shortfall), but we model shortfall as max(0, min_year3_reserve - uninvested_cash)
# Instead, we define: uninvested_cash = cash_year3_start - (x1_3 + x4)
# Then: shortfall >= min_year3_reserve - uninvested_cash = min_year3_reserve - (cash_year3_start - x1_3 - x4)
# So: shortfall >= min_year3_reserve - cash_year3_start + x1_3 + x4
model.addConstr(shortfall >= min_year3_reserve - (cash_year3_start - x1_3 - x4), "Reserve_Shortfall")

# Objective: 
#   Ending wealth = 
#       returns from Year 3 investments: x1_3 * 1.20 + x4 * 1.40
#       plus uninvested cash (which carries through Year 3): (cash_year3_start - x1_3 - x4)
#   Minus penalty: reserve_shortfall_penalty * shortfall
#
# Total ending wealth = x1_3*1.20 + x4*1.40 + (cash_year3_start - x1_3 - x4) - reserve_shortfall_penalty * shortfall
# Simplify: 
#   = cash_year3_start + x1_3*(1.20 - 1) + x4*(1.40 - 1) - reserve_shortfall_penalty * shortfall
#   = cash_year3_start + 0.20*x1_3 + 0.40*x4 - reserve_shortfall_penalty * shortfall
#
# But note: cash_year3_start = 1.20*x1_2 + 1.50*x2 + 1.60*x3
# So total objective = 1.20*x1_2 + 1.50*x2 + 1.60*x3 + 0.20*x1_3 + 0.40*x4 - reserve_shortfall_penalty * shortfall

obj_expr = (1.20 * x1_2 + 1.50 * x2 + 1.60 * x3 + 
            0.20 * x1_3 + 0.40 * x4 - 
            reserve_shortfall_penalty * shortfall)

model.setObjective(obj_expr, GRB.MAXIMIZE)

# Optimize
model.optimize()

# Output final objective value
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    # In case of no solution, output 0 or handle appropriately; but problem should be feasible
    print("FINAL_OBJ_VALUE: 0")
