import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')

    # Load general parameters
    params_data = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    params = {}
    for row in params_data:
        params[row['Parameter_Name']] = float(row['Value'])

    cost_per_km = params['cost_per_km']
    adriatic_pool_shortage_trigger = params['adriatic_pool_shortage_trigger']
    adriatic_pool_recovery_fee = params['adriatic_pool_recovery_fee']

    # Load warehouse data
    warehouses_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    warehouses = []
    supply = {}
    for row in warehouses_data:
        name = row['Warehouse']
        warehouses.append(name)
        supply[name] = int(row['Empty_Containers'])

    # Load port data
    ports_data = load_csv_data(os.path.join(data_dir, 'table_2.csv'))
    ports = []
    demand = {}
    for row in ports_data:
        name = row['Port']
        ports.append(name)
        demand[name] = int(row['Container_Demand'])

    # Load distance data
    distance_data = load_csv_data(os.path.join(data_dir, 'table_3.csv'))
    distance = {}
    for row in distance_data:
        wh = row['Warehouse']
        for port in ports:
            distance[(wh, port)] = float(row[port])

    # Load shortage penalty data
    shortage_data = load_csv_data(os.path.join(data_dir, 'shortage_penalty.csv'))
    shortage_charge = {}
    grace_containers = {}
    recovery_fee = {}
    for row in shortage_data:
        port = row['Port']
        shortage_charge[port] = float(row['Shortage_Charge'])
        grace_containers[port] = float(row['Grace_Containers'])
        recovery_fee[port] = float(row['Recovery_Fee'])

    adriatic_ports = ['Venice', 'Ancona', 'Bari']

    model = gp.Model("Container_Transportation_Revised")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {}
    for i in warehouses:
        for j in ports:
            x[i, j] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{i}_{j}")
    
    s = {}
    y = {}
    for j in ports:
        s[j] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"s_{j}")
        y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")
        
    z = model.addVar(vtype=GRB.BINARY, name="z")

    # Supply constraints
    for i in warehouses:
        model.addConstr(gp.quicksum(x[i, j] for j in ports) <= supply[i], name=f"supply_{i}")

    # Demand constraints
    for j in ports:
        model.addConstr(gp.quicksum(x[i, j] for i in warehouses) + s[j] == demand[j], name=f"demand_{j}")

    # Local recovery desk constraints
    for j in ports:
        # If s[j] > grace_containers[j], then y[j] must be 1
        M = demand[j]
        model.addConstr(s[j] <= grace_containers[j] + M * y[j], name=f"local_recovery_{j}")

    # Adriatic pool recovery desk constraint
    adriatic_shortage = gp.quicksum(s[j] for j in adriatic_ports)
    M_pool = sum(demand[j] for j in adriatic_ports)
    model.addConstr(adriatic_shortage <= adriatic_pool_shortage_trigger + M_pool * z, name="adriatic_pool_recovery")

    # Objective function
    transport_cost = gp.quicksum(x[i, j] * distance[i, j] * cost_per_km for i in warehouses for j in ports)
    shortage_cost = gp.quicksum(s[j] * shortage_charge[j] for j in ports)
    local_recovery_cost = gp.quicksum(y[j] * recovery_fee[j] for j in ports)
    adriatic_recovery_cost = z * adriatic_pool_recovery_fee

    model.setObjective(transport_cost + shortage_cost + local_recovery_cost + adriatic_recovery_cost, GRB.MINIMIZE)

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == '__main__':
    main()
