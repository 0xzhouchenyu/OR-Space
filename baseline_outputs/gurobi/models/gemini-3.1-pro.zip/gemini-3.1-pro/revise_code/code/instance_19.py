import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            try:
                value = int(value_str)
            except ValueError:
                try:
                    value = float(value_str)
                except ValueError:
                    value = value_str
            params[name] = value
    return params

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

cost_A = params['cost_per_chair_A']
cost_B = params['cost_per_chair_B']
cost_C = params['cost_per_chair_C']
chairs_per_order_A = params['chairs_per_order_A']
chairs_per_order_B = params['chairs_per_order_B']
chairs_per_order_C = params['chairs_per_order_C']
min_total = params['min_total_chairs']
max_total = params['max_total_chairs']
min_chairs_B_if_A = params['min_chairs_B_if_A']
dependency_B_C = params['dependency_B_C']

fixed_fee_A_regular = params['fixed_fee_A_regular']
fixed_fee_A_express = params['fixed_fee_A_express']
fixed_fee_B_regular = params['fixed_fee_B_regular']
fixed_fee_B_express = params['fixed_fee_B_express']
fixed_fee_C_regular = params['fixed_fee_C_regular']
fixed_fee_C_express = params['fixed_fee_C_express']
weekly_order_budget = params['weekly_order_budget']

model = gp.Model("FurnitureOrder")
model.setParam('OutputFlag', 0)

max_orders_A = max_total // int(chairs_per_order_A) + 1
max_orders_B = max_total // int(chairs_per_order_B) + 1
max_orders_C = max_total // int(chairs_per_order_C) + 1

x_A = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_A, name="orders_A")
x_B = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_B, name="orders_B")
x_C = model.addVar(vtype=GRB.INTEGER, lb=0, ub=max_orders_C, name="orders_C")

y_A_reg = model.addVar(vtype=GRB.BINARY, name="y_A_reg")
y_A_exp = model.addVar(vtype=GRB.BINARY, name="y_A_exp")
y_B_reg = model.addVar(vtype=GRB.BINARY, name="y_B_reg")
y_B_exp = model.addVar(vtype=GRB.BINARY, name="y_B_exp")
y_C_reg = model.addVar(vtype=GRB.BINARY, name="y_C_reg")
y_C_exp = model.addVar(vtype=GRB.BINARY, name="y_C_exp")

y_A = model.addVar(vtype=GRB.BINARY, name="y_A")
y_B = model.addVar(vtype=GRB.BINARY, name="y_B")
y_C = model.addVar(vtype=GRB.BINARY, name="y_C")

model.addConstr(y_A == y_A_reg + y_A_exp)
model.addConstr(y_A_reg + y_A_exp <= 1)

model.addConstr(y_B == y_B_reg + y_B_exp)
model.addConstr(y_B_reg + y_B_exp <= 1)

model.addConstr(y_C == y_C_reg + y_C_exp)
model.addConstr(y_C_reg + y_C_exp <= 1)

M = max_total + 1
model.addConstr(x_A <= M * y_A)
model.addConstr(x_A >= y_A)
model.addConstr(x_B <= M * y_B)
model.addConstr(x_B >= y_B)
model.addConstr(x_C <= M * y_C)
model.addConstr(x_C >= y_C)

chairs_A = chairs_per_order_A * x_A
chairs_B = chairs_per_order_B * x_B
chairs_C = chairs_per_order_C * x_C

model.addConstr(chairs_A + chairs_B + chairs_C >= min_total)
model.addConstr(chairs_A + chairs_B + chairs_C <= max_total)

model.addConstr(chairs_B >= min_chairs_B_if_A * y_A)

if dependency_B_C:
    model.addConstr(y_B <= y_C)

model.addConstr(y_A_reg + y_A_exp + y_B_reg + y_B_exp + y_C_reg + y_C_exp <= weekly_order_budget)

total_cost = (cost_A * chairs_A + cost_B * chairs_B + cost_C * chairs_C +
              fixed_fee_A_regular * y_A_reg + fixed_fee_A_express * y_A_exp +
              fixed_fee_B_regular * y_B_reg + fixed_fee_B_express * y_B_exp +
              fixed_fee_C_regular * y_C_reg + fixed_fee_C_express * y_C_exp)

model.setObjective(total_cost, GRB.MINIMIZE)
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: None")
