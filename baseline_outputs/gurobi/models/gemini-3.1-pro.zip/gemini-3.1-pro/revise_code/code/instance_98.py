import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read product data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'Product': row['Product'],
                'Steel': float(row['Steel_Required_kg']),
                'Aluminum': float(row['Aluminum_Required_kg']),
                'Labor': float(row['Labor_Required_hours']),
                'Profit': float(row['Profit_yuan']),
                'SetupCost': float(row['Setup_Cost_yuan'])
            })
            
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
            
    model = gp.Model("Production_Optimization")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {}
    y = {}
    for p in products:
        name = p['Product']
        x[name] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{name}")
        y[name] = model.addVar(vtype=GRB.BINARY, name=f"y_{name}")
        
    ot = model.addVar(lb=0, ub=params['max_overtime'], vtype=GRB.CONTINUOUS, name="ot")
    z_ot = model.addVar(vtype=GRB.BINARY, name="z_ot")
    z_A = model.addVar(vtype=GRB.BINARY, name="z_A")
    
    # Setup constraints
    BIG_M = 10000
    for p in products:
        name = p['Product']
        model.addConstr(x[name] <= BIG_M * y[name])
        
    # Overtime review constraint
    model.addConstr(ot <= params['overtime_review_threshold'] + (params['max_overtime'] - params['overtime_review_threshold']) * z_ot)
    
    # Line audit constraint for Product A
    model.addConstr(x['A'] <= params['product_A_line_audit_threshold'] + BIG_M * z_A)
    
    # Resource constraints
    model.addConstr(gp.quicksum(p['Steel'] * x[p['Product']] for p in products) <= params['available_steel'], "Steel")
    model.addConstr(gp.quicksum(p['Aluminum'] * x[p['Product']] for p in products) <= params['available_aluminum'], "Aluminum")
    model.addConstr(gp.quicksum(p['Labor'] * x[p['Product']] for p in products) <= params['available_labor'] + ot, "Labor")
    
    # Objective
    profit = gp.quicksum(p['Profit'] * x[p['Product']] for p in products)
    setup_cost = gp.quicksum(p['SetupCost'] * y[p['Product']] for p in products)
    overtime_cost = params['overtime_pay'] * ot
    review_fee = params['overtime_review_fee'] * z_ot
    audit_fee = params['product_A_line_audit_fee'] * z_A
    
    model.setObjective(profit - setup_cost - overtime_cost - review_fee - audit_fee, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
