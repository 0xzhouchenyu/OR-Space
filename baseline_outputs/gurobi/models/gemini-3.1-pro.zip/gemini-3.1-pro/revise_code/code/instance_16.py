import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Setup data loading
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

months = []
purchasing_prices = {}
selling_prices = {}

with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        m = int(row['Month'])
        months.append(m)
        purchasing_prices[m] = float(row['Purchasing_Price_Yuan'])
        selling_prices[m] = float(row['Selling_Price_Yuan'])

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params.get('fixed_ordering_cost', 400.0)
month2_bulk_receiving_threshold = params.get('month2_bulk_receiving_threshold', 300.0)
month2_bulk_receiving_fee = params.get('month2_bulk_receiving_fee', 600.0)

# Create model
model = gp.Model("Maximize_Profit")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVars(months, vtype=GRB.CONTINUOUS, name="purchase")
s = model.addVars(months, vtype=GRB.CONTINUOUS, name="sell")
inv = model.addVars(months, vtype=GRB.CONTINUOUS, name="inventory")
y = model.addVars(months, vtype=GRB.BINARY, name="purchase_indicator")
z = model.addVar(vtype=GRB.BINARY, name="month2_bulk_indicator")

# Constraints
for m in months:
    prev_inv = initial_stock if m == months[0] else inv[m - 1]
    
    # Inventory balance
    model.addConstr(inv[m] == prev_inv + x[m] - s[m], name=f"inventory_balance_{m}")
    
    # Warehouse capacity constraint (after purchase, before sell)
    model.addConstr(prev_inv + x[m] <= warehouse_capacity, name=f"warehouse_after_purchase_{m}")
    
    # Sell limit
    model.addConstr(s[m] <= prev_inv + x[m], name=f"sell_limit_{m}")
    
    # Fixed ordering cost indicator constraint
    model.addConstr(x[m] <= warehouse_capacity * y[m], name=f"purchase_indicator_constr_{m}")

# Month 2 bulk receiving constraint
if 2 in months:
    model.addConstr(x[2] <= month2_bulk_receiving_threshold + warehouse_capacity * z, name="month2_bulk_constr")

# Objective
revenue = gp.quicksum(selling_prices[m] * s[m] for m in months)
purchasing_cost = gp.quicksum(purchasing_prices[m] * x[m] for m in months)
fixed_costs = gp.quicksum(fixed_ordering_cost * y[m] for m in months)
bulk_fee = month2_bulk_receiving_fee * z if 2 in months else 0

model.setObjective(revenue - purchasing_cost - fixed_costs - bulk_fee, GRB.MAXIMIZE)

# Solve
model.optimize()

# Output
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: None")
