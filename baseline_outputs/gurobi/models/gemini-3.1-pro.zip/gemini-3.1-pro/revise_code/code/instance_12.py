import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })

    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    fixed_setup_cost = params['fixed_setup_cost']
    energy_cost_per_kwh = params['energy_cost_per_kwh']
    max_total_energy_kwh = params['max_total_energy_kwh']
    eco_capacity_share = params['eco_capacity_share']
    eco_overhead_cost = params['eco_overhead_cost']
    reg_energy = params['regular_energy_intensity_kwh_per_unit']
    eco_energy = params['eco_energy_intensity_kwh_per_unit']

    n = len(containers)
    M = sum(c['demand'] for c in containers)

    model = gp.Model("PlasticContainersRevised")
    model.setParam('OutputFlag', 0)

    y = model.addVars(n, vtype=GRB.BINARY, name="y")
    z = model.addVars(n, vtype=GRB.BINARY, name="z")
    
    p_reg = model.addVars(n, vtype=GRB.CONTINUOUS, name="p_reg")
    p_eco = model.addVars(n, vtype=GRB.CONTINUOUS, name="p_eco")
    
    x = {}
    for i in range(n):
        for j in range(n):
            if containers[i]['volume'] >= containers[j]['volume']:
                x[i, j] = model.addVar(vtype=GRB.CONTINUOUS, name=f"x_{i}_{j}")

    # Objective
    obj = gp.quicksum(fixed_setup_cost * y[i] + eco_overhead_cost * z[i] for i in range(n))
    obj += gp.quicksum((p_reg[i] + p_eco[i]) * containers[i]['cost'] for i in range(n))
    obj += gp.quicksum((p_reg[i] * reg_energy + p_eco[i] * eco_energy) * energy_cost_per_kwh for i in range(n))
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(n) if (i, j) in x) >= containers[j]['demand'], name=f"demand_{j}")

    for i in range(n):
        model.addConstr(p_reg[i] + p_eco[i] == gp.quicksum(x[i, j] for j in range(n) if (i, j) in x), name=f"prod_balance_{i}")
        model.addConstr(p_reg[i] + p_eco[i] <= M * y[i], name=f"setup_{i}")
        model.addConstr(p_eco[i] <= M * z[i], name=f"eco_setup_{i}")
        model.addConstr(p_eco[i] <= eco_capacity_share * (p_reg[i] + p_eco[i]), name=f"eco_share_{i}")

    model.addConstr(
        gp.quicksum(p_reg[i] * reg_energy + p_eco[i] * eco_energy for i in range(n)) <= max_total_energy_kwh,
        name="max_energy"
    )

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
