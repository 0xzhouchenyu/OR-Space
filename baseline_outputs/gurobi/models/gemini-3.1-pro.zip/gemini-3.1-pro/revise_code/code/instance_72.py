import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    properties = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            properties.append({
                'name': row['Property'],
                'income': float(row['Annual_Income']),
                'cost': float(row['Cost'])
            })

    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    budget = params['budget']
    scen_1_prob = params['scen_1_prob']
    scen_2_prob = params['scen_2_prob']
    scen_1_risky_multiplier = params['scen_1_risky_multiplier']
    scen_2_risky_multiplier = params['scen_2_risky_multiplier']
    total_risky_budget = params['total_risky_budget']
    per_property_risky_cap = params['per_property_risky_cap']
    max_risky_properties = params.get('max_risky_properties', 2)

    model = gp.Model("RealEstateInvestment")
    model.setParam('OutputFlag', 0)

    x = {}
    y = {}
    z = {}

    for p in properties:
        name = p['name']
        x[name] = model.addVar(vtype=GRB.BINARY, name=f"buy_{name}")
        z[name] = model.addVar(vtype=GRB.BINARY, name=f"has_risky_{name}")
        y[name] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, ub=1, name=f"risky_frac_{name}")

    expected_risky_mult = scen_1_prob * scen_1_risky_multiplier + scen_2_prob * scen_2_risky_multiplier

    obj_expr = gp.LinExpr()
    for p in properties:
        name = p['name']
        inc = p['income']
        # Long term income + expected risky income
        obj_expr += inc * (x[name] - y[name]) + inc * y[name] * expected_risky_mult

    model.setObjective(obj_expr, GRB.MAXIMIZE)

    # Budget constraint
    model.addConstr(gp.quicksum(p['cost'] * x[p['name']] for p in properties) <= budget, "budget")

    # Property 4 excludes Property 3
    if 'Property_4' in x and 'Property_3' in x:
        model.addConstr(x['Property_4'] + x['Property_3'] <= 1, "exclude_3_4")

    # Risky logic constraints
    for p in properties:
        name = p['name']
        model.addConstr(z[name] <= x[name], f"z_le_x_{name}")
        model.addConstr(y[name] <= per_property_risky_cap * z[name], f"y_le_cap_z_{name}")

    model.addConstr(gp.quicksum(p['cost'] * z[p['name']] for p in properties) <= total_risky_budget, "total_risky_budget")
    model.addConstr(gp.quicksum(z[p['name']] for p in properties) <= max_risky_properties, "max_risky_properties")

    model.optimize()

    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
