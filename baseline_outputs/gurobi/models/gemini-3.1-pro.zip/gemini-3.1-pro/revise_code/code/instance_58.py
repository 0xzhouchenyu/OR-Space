import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    fruits = ['apples', 'pears', 'oranges', 'lemons']
    seasons = ['spring', 'autumn']

    profits = {
        'apples': params['profit_per_acre_apples'],
        'pears': params['profit_per_acre_pears'],
        'oranges': params['profit_per_acre_oranges'],
        'lemons': params['profit_per_acre_lemons'],
    }
    
    water_req = {
        ('apples', 'spring'): params['water_per_acre_apples_spring'],
        ('apples', 'autumn'): params['water_per_acre_apples_autumn'],
        ('pears', 'spring'): params['water_per_acre_pears_spring'],
        ('pears', 'autumn'): params['water_per_acre_pears_autumn'],
        ('oranges', 'spring'): params['water_per_acre_oranges_spring'],
        ('oranges', 'autumn'): params['water_per_acre_oranges_autumn'],
        ('lemons', 'spring'): params['water_per_acre_lemons_spring'],
        ('lemons', 'autumn'): params['water_per_acre_lemons_autumn'],
    }

    total_area = params['total_farm_area']
    min_a_to_p = params['min_apples_to_pears_ratio']
    min_a_to_l = params['min_apples_to_lemons_ratio']
    o_to_l = params['oranges_to_lemons_ratio']
    max_types = int(params['max_fruit_types'])
    
    water_cap_spring = params['water_cap_spring']
    water_cap_autumn = params['water_cap_autumn']
    total_water_budget = params['total_water_budget']
    min_annual_water = params['min_annual_water_per_fruit']
    div_reward = params['diversification_reward']

    model = gp.Model("farm_revised")
    model.setParam('OutputFlag', 0)

    x = model.addVars(fruits, seasons, vtype=GRB.CONTINUOUS, name="x")
    y = model.addVars(fruits, vtype=GRB.BINARY, name="y")
    z = model.addVar(vtype=GRB.BINARY, name="z")

    # Objective
    profit = gp.quicksum((x[f, 'spring'] + x[f, 'autumn']) * profits[f] for f in fruits) + z * div_reward
    model.setObjective(profit, GRB.MAXIMIZE)

    # Land constraints
    model.addConstr(gp.quicksum(x[f, 'spring'] for f in fruits) <= total_area)
    model.addConstr(gp.quicksum(x[f, 'autumn'] for f in fruits) <= total_area)

    # Water constraints
    spring_water = gp.quicksum(x[f, 'spring'] * water_req[f, 'spring'] for f in fruits)
    autumn_water = gp.quicksum(x[f, 'autumn'] * water_req[f, 'autumn'] for f in fruits)
    
    model.addConstr(spring_water <= water_cap_spring)
    model.addConstr(autumn_water <= water_cap_autumn)
    model.addConstr(spring_water + autumn_water <= total_water_budget)

    # Fruit selection and min water
    for f in fruits:
        f_water = x[f, 'spring'] * water_req[f, 'spring'] + x[f, 'autumn'] * water_req[f, 'autumn']
        model.addConstr(f_water >= min_annual_water * y[f])
        model.addConstr(f_water <= total_water_budget * y[f])

    model.addConstr(gp.quicksum(y[f] for f in fruits) <= max_types)

    # Ratio constraints
    annual_area = {f: x[f, 'spring'] + x[f, 'autumn'] for f in fruits}
    model.addConstr(annual_area['apples'] >= min_a_to_p * annual_area['pears'])
    model.addConstr(annual_area['apples'] >= min_a_to_l * annual_area['lemons'])
    model.addConstr(annual_area['oranges'] == o_to_l * annual_area['lemons'])

    # Diversification reward
    model.addConstr(2 * z <= gp.quicksum(y[f] for f in fruits))

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    solve()
