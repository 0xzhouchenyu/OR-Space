import os
import re
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    num_customers = 7
    max_route_length_day = 1000
    route_cost_day = 20
    
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'num_customers':
                num_customers = int(row['Value'])
            elif row['Parameter_Name'] == 'max_route_length_day':
                max_route_length_day = float(row['Value'])
            elif row['Parameter_Name'] == 'route_cost_day':
                route_cost_day = float(row['Value'])

    D = [[0] * num_customers for _ in range(num_customers)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        lines = f.readlines()
        for line in lines[1:]:
            nums = re.findall(r'\d+', line)
            if not nums:
                continue
            row_idx = int(nums[0]) - 1
            for j, val in enumerate(nums[1:]):
                col_idx = row_idx + 1 + j
                if col_idx < num_customers:
                    D[row_idx][col_idx] = int(val)
                    D[col_idx][row_idx] = int(val)

    num_days = 2
    
    model = gp.Model("TSP_Revised")
    model.setParam('OutputFlag', 0)

    x = model.addVars(num_customers, num_customers, num_days, vtype=GRB.BINARY, name="x")
    y = model.addVars(num_customers, num_days, vtype=GRB.BINARY, name="y")
    z = model.addVars(num_days, vtype=GRB.BINARY, name="z")
    u = model.addVars(num_customers, num_days, lb=1, ub=num_customers-1, vtype=GRB.CONTINUOUS, name="u")

    model.setObjective(
        gp.quicksum(D[i][j] * x[i, j, d] for i in range(num_customers) for j in range(num_customers) for d in range(num_days) if i != j) +
        gp.quicksum(route_cost_day * z[d] for d in range(num_days)),
        GRB.MINIMIZE
    )

    for i in range(1, num_customers):
        model.addConstr(gp.quicksum(y[i, d] for d in range(num_days)) == 1)

    for d in range(num_days):
        model.addConstr(y[0, d] == z[d])
        for i in range(1, num_customers):
            model.addConstr(y[i, d] <= z[d])

    for i in range(num_customers):
        for d in range(num_days):
            model.addConstr(gp.quicksum(x[i, j, d] for j in range(num_customers) if i != j) == y[i, d])
            model.addConstr(gp.quicksum(x[j, i, d] for j in range(num_customers) if i != j) == y[i, d])

    for i in range(1, num_customers):
        for j in range(1, num_customers):
            if i != j:
                for d in range(num_days):
                    model.addConstr(u[i, d] - u[j, d] + (num_customers - 1) * x[i, j, d] <= num_customers - 2)

    for d in range(num_days):
        model.addConstr(
            gp.quicksum(D[i][j] * x[i, j, d] for i in range(num_customers) for j in range(num_customers) if i != j) <= max_route_length_day * z[d]
        )

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
