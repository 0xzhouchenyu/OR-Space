import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    precedences = []
    with open(os.path.join(data_dir, 'table_1.csv')) as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))

    activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    dur = {a: int(params[f'activity_{a}_duration']) for a in activities}
    work_cost = params['work_cost_per_day']
    machine_cost = params['machine_rental_cost_per_day']
    
    e_reduction = params.get('activity_E_overtime_reduction', 0)
    e_ot_cost = params.get('activity_E_overtime_cost', 0)
    e_review_cost = params.get('activity_E_followup_review_cost', 0)

    model = gp.Model("Project_Cost_Minimization")
    model.setParam('OutputFlag', 0)

    S = {a: model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f'S_{a}') for a in activities}
    T = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name='T')
    use_ot_E = model.addVar(vtype=GRB.BINARY, name='use_ot_E')

    model.setObjective(
        work_cost * T + 
        machine_cost * (S['B'] + dur['B'] - S['A']) + 
        (e_ot_cost + e_review_cost) * use_ot_E, 
        GRB.MINIMIZE
    )

    for pred, succ in precedences:
        if pred == 'E':
            model.addConstr(S[succ] >= S[pred] + dur[pred] - e_reduction * use_ot_E)
        else:
            model.addConstr(S[succ] >= S[pred] + dur[pred])

    model.addConstr(T >= S['C'] + dur['C'])
    model.addConstr(T >= S['B'] + dur['B'])
    
    # Optional but good for correctness: T must be >= end of all activities
    for a in activities:
        if a == 'E':
            model.addConstr(T >= S[a] + dur[a] - e_reduction * use_ot_E)
        else:
            model.addConstr(T >= S[a] + dur[a])

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

solve()
