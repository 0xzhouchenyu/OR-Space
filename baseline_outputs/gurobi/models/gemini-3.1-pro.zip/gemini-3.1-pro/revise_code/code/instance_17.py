import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    parts = []
    with open(os.path.join(base_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
            
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    max_heavy = int(params['max_heavy_bombs'])
    max_light = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    overhead_A = params['sortie_fuel_overhead_A']
    overhead_B = params['sortie_fuel_overhead_B']
    max_sorties = min(max_sorties_A, max_sorties_B)
    
    n = len(parts)
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    model.setParam('NonConvex', 2)
    
    x = {}
    y = {}
    
    for i in range(n):
        y[i] = model.addVar(lb=0.0, ub=1.0, name=f"y_{i}")
        
        sum_x = gp.LinExpr()
        prob_miss = gp.LinExpr()
        
        for h in range(max_sorties + 1):
            for l in range(max_sorties + 1):
                if h + l > max_sorties:
                    continue
                var = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{h}_{l}")
                x[i, h, l] = var
                sum_x += var
                
                p_miss = ((1.0 - parts[i]['p_heavy']) ** h) * ((1.0 - parts[i]['p_light']) ** l)
                prob_miss += p_miss * var
                
        model.addConstr(sum_x == 1)
        model.addConstr(y[i] == prob_miss)
        
    total_h = gp.LinExpr()
    total_l = gp.LinExpr()
    total_sorties = gp.LinExpr()
    fuel_A = gp.LinExpr()
    fuel_B = gp.LinExpr()
    
    for i in range(n):
        d = parts[i]['distance']
        f_h_A = d / params['fuel_efficiency_heavy_bomb'] + d / params['fuel_efficiency_empty'] + params['fuel_takeoff_landing'] + overhead_A
        f_l_A = d / params['fuel_efficiency_light_bomb'] + d / params['fuel_efficiency_empty'] + params['fuel_takeoff_landing'] + overhead_A
        f_h_B = d / params['fuel_efficiency_heavy_bomb'] + d / params['fuel_efficiency_empty'] + params['fuel_takeoff_landing'] + overhead_B
        f_l_B = d / params['fuel_efficiency_light_bomb'] + d / params['fuel_efficiency_empty'] + params['fuel_takeoff_landing'] + overhead_B
        
        for h in range(max_sorties + 1):
            for l in range(max_sorties + 1):
                if h + l > max_sorties:
                    continue
                var = x[i, h, l]
                total_h += h * var
                total_l += l * var
                total_sorties += (h + l) * var
                fuel_A += (h * f_h_A + l * f_l_A) * var
                fuel_B += (h * f_h_B + l * f_l_B) * var
                
    model.addConstr(total_h <= max_heavy)
    model.addConstr(total_l <= max_light)
    model.addConstr(total_sorties <= max_sorties)
    model.addConstr(fuel_A <= fuel_limit)
    model.addConstr(fuel_B <= fuel_limit)
    
    z01 = model.addVar(lb=0.0, ub=1.0)
    z23 = model.addVar(lb=0.0, ub=1.0)
    z012 = model.addVar(lb=0.0, ub=1.0)
    z013 = model.addVar(lb=0.0, ub=1.0)
    z023 = model.addVar(lb=0.0, ub=1.0)
    z123 = model.addVar(lb=0.0, ub=1.0)
    z0123 = model.addVar(lb=0.0, ub=1.0)
    
    model.addConstr(z01 == y[0] * y[1])
    model.addConstr(z23 == y[2] * y[3])
    model.addConstr(z012 == z01 * y[2])
    model.addConstr(z013 == z01 * y[3])
    model.addConstr(z023 == y[0] * z23)
    model.addConstr(z123 == y[1] * z23)
    model.addConstr(z0123 == z01 * z23)
    
    p_fail = z012 + z013 + z023 + z123 - 3 * z0123
    model.setObjective(1.0 - p_fail, GRB.MAXIMIZE)
    
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal:.4f}")

if __name__ == '__main__':
    solve()
