import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load parameters
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

# Extract parameters
min_A_I = params['min_proportion_crude_A_type_I'] / 100.0
min_A_II = params['min_proportion_crude_A_type_II'] / 100.0
price_I = params['selling_price_type_I']
price_II = params['selling_price_type_II']
inv_A = params['inventory_crude_A']
inv_B = params['inventory_crude_B']
max_purchase_A = params['max_purchase_crude_A']
cost_tier1 = params['market_price_crude_A_tier_1']
cost_tier2 = params['market_price_crude_A_tier_2']
cost_tier3 = params['market_price_crude_A_tier_3']
proc_cap = params['processing_capacity']
min_output = params['min_total_gasoline_output']
proc_cost = params['processing_cost_per_ton']
type_II_thresh = params['type_II_contract_threshold']
type_II_lift = params['type_II_price_lift']
rebate_thresh = params['bulk_purchase_rebate_threshold']
rebate_val = params['bulk_purchase_rebate']

# Create model
model = gp.Model("Oil_Blending_Revised")
model.setParam('OutputFlag', 0)

# Decision variables
a1 = model.addVar(lb=0, name="crude_A_in_I")
a2 = model.addVar(lb=0, name="crude_A_in_II")
b1 = model.addVar(lb=0, name="crude_B_in_I")
b2 = model.addVar(lb=0, name="crude_B_in_II")

p1 = model.addVar(lb=0, ub=500, name="purchase_tier1")
p2 = model.addVar(lb=0, ub=500, name="purchase_tier2")
p3 = model.addVar(lb=0, ub=500, name="purchase_tier3")

y1 = model.addVar(vtype=GRB.BINARY, name="y1")
y2 = model.addVar(vtype=GRB.BINARY, name="y2")

z_typeII = model.addVar(vtype=GRB.BINARY, name="z_typeII")
v_typeII = model.addVar(lb=0, name="v_typeII")

z_rebate = model.addVar(vtype=GRB.BINARY, name="z_rebate")

# Tiered ordering constraints
model.addConstr(p2 <= 500 * y1)
model.addConstr(p3 <= 500 * y2)
model.addConstr(p1 >= 500 * y1)
model.addConstr(p2 >= 500 * y2)

total_A_purchased = p1 + p2 + p3
model.addConstr(a1 + a2 <= inv_A + total_A_purchased)
model.addConstr(b1 + b2 <= inv_B)

# Blending constraints
model.addConstr(a1 >= min_A_I * (a1 + b1))
model.addConstr(a2 >= min_A_II * (a2 + b2))

# Throughput constraints
total_output = a1 + b1 + a2 + b2
model.addConstr(total_output >= min_output)
model.addConstr(total_output <= proc_cap)

# Type II price lift constraints
total_type_II = a2 + b2
model.addConstr(total_type_II >= type_II_thresh * z_typeII)
model.addConstr(v_typeII <= proc_cap * z_typeII)
model.addConstr(v_typeII <= total_type_II)

# Bulk purchase rebate constraints
model.addConstr(total_A_purchased >= rebate_thresh * z_rebate)

# Objective
revenue = price_I * (a1 + b1) + price_II * total_type_II + type_II_lift * v_typeII
crude_cost = cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3
processing_cost = proc_cost * total_output
rebate = rebate_val * z_rebate

model.setObjective(revenue + rebate - crude_cost - processing_cost, GRB.MAXIMIZE)

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: None")
