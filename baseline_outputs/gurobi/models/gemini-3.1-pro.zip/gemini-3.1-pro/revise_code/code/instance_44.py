import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

m = int(params['m'])
n = int(params['n'])
p = int(params['p'])

a = {i: params[f'a_{i}'] for i in range(1, m+1)}
b = {j: params[f'b_{j}'] for j in range(1, n+1)}
f_cost = {k: params[f'f_{k}'] for k in range(1, p+1)}
q = {k: params[f'q_{k}'] for k in range(1, p+1)}
qexp = {k: params[f'qexp_{k}'] for k in range(1, p+1)}
alpha = {j: params[f'alpha_{j}'] for j in range(1, n+1)}
eps = params['eps']
M = params['M']

cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        i = int(row['i'])
        k = int(row['k'])
        cR_ik[(i, k)] = float(row['cR_ik'])
        cE_ik[(i, k)] = float(row['cE_ik'])

cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, 'table_2.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        k = int(row['k'])
        j = int(row['j'])
        cR_kj[(k, j)] = float(row['cR_kj'])
        cE_kj[(k, j)] = float(row['cE_kj'])

model = gp.Model("Revised_Transportation_Problem")
model.setParam('OutputFlag', 0)

xR = model.addVars(range(1, m+1), range(1, p+1), vtype=GRB.CONTINUOUS, name="xR")
xE = model.addVars(range(1, m+1), range(1, p+1), vtype=GRB.CONTINUOUS, name="xE")
yR = model.addVars(range(1, p+1), range(1, n+1), vtype=GRB.CONTINUOUS, name="yR")
yE = model.addVars(range(1, p+1), range(1, n+1), vtype=GRB.CONTINUOUS, name="yE")
z = model.addVars(range(1, p+1), vtype=GRB.BINARY, name="z")
w = model.addVars(range(1, p+1), range(1, n+1), vtype=GRB.BINARY, name="w")
z_multi = model.addVar(vtype=GRB.BINARY, name="z_multi")

obj = (
    gp.quicksum(cR_ik[i, k] * xR[i, k] + cE_ik[i, k] * xE[i, k] for i in range(1, m+1) for k in range(1, p+1)) +
    gp.quicksum(cR_kj[k, j] * yR[k, j] + cE_kj[k, j] * yE[k, j] for k in range(1, p+1) for j in range(1, n+1)) +
    gp.quicksum(f_cost[k] * z[k] for k in range(1, p+1))
)
model.setObjective(obj, GRB.MINIMIZE)

for i in range(1, m+1):
    model.addConstr(gp.quicksum(xR[i, k] + xE[i, k] for k in range(1, p+1)) <= a[i], name=f"Supply_{i}")

for j in range(1, n+1):
    model.addConstr(gp.quicksum(yR[k, j] + yE[k, j] for k in range(1, p+1)) >= b[j], name=f"Demand_{j}")

for k in range(1, p+1):
    model.addConstr(gp.quicksum(xR[i, k] for i in range(1, m+1)) == gp.quicksum(yR[k, j] for j in range(1, n+1)), name=f"FlowBalanceR_{k}")
    model.addConstr(gp.quicksum(xE[i, k] for i in range(1, m+1)) == gp.quicksum(yE[k, j] for j in range(1, n+1)), name=f"FlowBalanceE_{k}")
    model.addConstr(gp.quicksum(xR[i, k] + xE[i, k] for i in range(1, m+1)) <= q[k] * z[k], name=f"Capacity_{k}")
    model.addConstr(gp.quicksum(xE[i, k] for i in range(1, m+1)) <= qexp[k] * z[k], name=f"ExpCapacity_{k}")

model.addConstr(gp.quicksum(z[k] for k in range(1, p+1)) - 1 <= p * z_multi, name="Z_multi_def")

for j in range(1, n+1):
    model.addConstr(gp.quicksum(w[k, j] for k in range(1, p+1)) >= 2 * z_multi, name=f"DivExpress_{j}")
    for k in range(1, p+1):
        model.addConstr(yE[k, j] <= M * w[k, j], name=f"w_upper_{k}_{j}")
        model.addConstr(yE[k, j] >= eps * w[k, j], name=f"w_lower_{k}_{j}")
        model.addConstr(yE[k, j] >= alpha[j] * b[j] - M * (1 - w[k, j]), name=f"alpha_share_{k}_{j}")

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: -1")
