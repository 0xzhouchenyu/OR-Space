import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    demand = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            demand[i] = float(row['Demand_Forecast'])
            
    T = len(demand)
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
            
    W0 = int(params['initial_workforce'])
    I0 = params['initial_inventory']
    sp = params['sales_price']
    rmc = params['raw_material_cost']
    oc = params['outsourcing_cost']
    hc = params['inventory_holding_cost']
    bc = params['backorder_cost']
    lr = params['labor_requirement']
    rh = params['regular_labor_hours']
    rw = params['regular_wage']
    otl = params['overtime_hours_limit']
    ow = params['overtime_wage']
    hire_cost = params['hiring_cost']
    fire_cost = params['firing_cost']
    term_inv = params['terminal_inventory']
    term_bo = params['terminal_backorders']
    contract_min = params.get('contract_min_units', 15000)
    contract_bigM = params.get('contract_bigM', 60000)
    
    model = gp.Model("FoldableTableProduction")
    model.setParam('OutputFlag', 0)
    
    W = model.addVars(T, vtype=GRB.CONTINUOUS, name="W")
    H = model.addVars(T, vtype=GRB.CONTINUOUS, name="H")
    F = model.addVars(T, vtype=GRB.CONTINUOUS, name="F")
    P_reg = model.addVars(T, vtype=GRB.CONTINUOUS, name="P_reg")
    P_ot = model.addVars(T, vtype=GRB.CONTINUOUS, name="P_ot")
    OT_total = model.addVars(T, vtype=GRB.CONTINUOUS, name="OT_total")
    O = model.addVars(T, vtype=GRB.CONTINUOUS, name="O")
    Inv = model.addVars(T, vtype=GRB.CONTINUOUS, name="Inv")
    B = model.addVars(T, vtype=GRB.CONTINUOUS, name="B")
    
    for t in range(T):
        if t == 0:
            model.addConstr(W[t] == W0 + H[t] - F[t])
        else:
            model.addConstr(W[t] == W[t-1] + H[t] - F[t])
            
        model.addConstr(P_reg[t] * lr <= W[t] * rh)
        model.addConstr(P_ot[t] * lr <= OT_total[t])
        model.addConstr(OT_total[t] <= W[t] * otl)
        
        prev_inv = I0 if t == 0 else Inv[t-1]
        prev_b = 0 if t == 0 else B[t-1]
        model.addConstr(Inv[t] - B[t] == prev_inv - prev_b + P_reg[t] + P_ot[t] + O[t] - demand[t])
        
        if t >= 3:
            model.addConstr(P_reg[t] >= contract_min)
            
    model.addConstr(Inv[T-1] >= term_inv)
    model.addConstr(B[T-1] <= term_bo)
    
    total_demand = sum(demand[t] for t in range(T))
    revenue = sp * total_demand
    
    material_cost = gp.quicksum(rmc * (P_reg[t] + P_ot[t]) for t in range(T))
    outsource_cost = gp.quicksum(oc * O[t] for t in range(T))
    holding_cost = gp.quicksum(hc * Inv[t] for t in range(T))
    backorder_cost_total = gp.quicksum(bc * B[t] for t in range(T))
    regular_labor_cost = gp.quicksum(rw * rh * W[t] for t in range(T))
    overtime_cost = gp.quicksum(ow * OT_total[t] for t in range(T))
    hiring_cost_total = gp.quicksum(hire_cost * H[t] for t in range(T))
    firing_cost_total = gp.quicksum(fire_cost * F[t] for t in range(T))
    
    total_cost = (material_cost + outsource_cost + holding_cost + backorder_cost_total +
                  regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total)
                  
    model.setObjective(revenue - total_cost, GRB.MAXIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
