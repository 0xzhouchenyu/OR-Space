import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Read general parameters
    gen_params_path = os.path.join(data_dir, "general_parameters.csv")
    general_params = {}
    with open(gen_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name']:
                general_params[row['Parameter_Name']] = float(row['Value'])
                
    overtime_hours_cap = general_params['overtime_hours_cap']
    overtime_cost_multiplier = general_params['overtime_cost_multiplier']
    
    min_prod = {
        'I': general_params['min_prod_I'],
        'II': general_params['min_prod_II'],
        'III': general_params['min_prod_III']
    }
    
    # Read table 1
    table1_path = os.path.join(data_dir, "table_1.csv")
    equipment_names = []
    products = ['I', 'II', 'III']
    processing_times = {}
    effective_hours = {}
    base_profit = {}
    
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if row[0].startswith('Unit_Product_Profit'):
                base_profit['I'] = float(row[1])
                base_profit['II'] = float(row[2])
                base_profit['III'] = float(row[3])
            else:
                equip = row[0]
                equipment_names.append(equip)
                processing_times[(equip, 'I')] = float(row[1])
                processing_times[(equip, 'II')] = float(row[2])
                processing_times[(equip, 'III')] = float(row[3])
                effective_hours[equip] = float(row[4])
                
    # Model
    model = gp.Model("Revised_Factory_Production")
    model.setParam('OutputFlag', 0)
    
    # Variables
    x_reg = {p: model.addVar(lb=0, name=f"x_reg_{p}") for p in products}
    x_ot = {p: model.addVar(lb=0, name=f"x_ot_{p}") for p in products}
    
    # Objective
    regular_cost = {p: base_profit[p] for p in products}
    overtime_cost = {p: overtime_cost_multiplier * base_profit[p] for p in products}
    
    model.setObjective(
        gp.quicksum(regular_cost[p] * x_reg[p] + overtime_cost[p] * x_ot[p] for p in products),
        GRB.MINIMIZE
    )
    
    # Constraints
    # 1. Minimum production
    for p in products:
        model.addConstr(x_reg[p] + x_ot[p] >= min_prod[p], name=f"min_prod_{p}")
        
    # 2. Equipment capacity
    for e in equipment_names:
        model.addConstr(
            gp.quicksum(processing_times[(e, p)] * (x_reg[p] + x_ot[p]) for p in products) <= effective_hours[e],
            name=f"equip_cap_{e}"
        )
        
    # 3. Overtime hours cap
    model.addConstr(
        gp.quicksum(processing_times[(e, p)] * x_ot[p] for e in equipment_names for p in products) <= overtime_hours_cap,
        name="overtime_cap"
    )
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
