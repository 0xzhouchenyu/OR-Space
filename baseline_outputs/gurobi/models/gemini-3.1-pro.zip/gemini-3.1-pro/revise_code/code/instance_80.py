import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        return list(reader)

def load_general_parameters(filepath):
    rows = load_csv(filepath)
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = row['Value']
        try:
            if '.' in value:
                params[name] = float(value)
            else:
                params[name] = int(value)
        except ValueError:
            params[name] = value
    return params

def load_task_methods(filepath):
    rows = load_csv(filepath)
    data = []
    for row in rows:
        data.append({
            'Task': row['Task'],
            'Method': row['Method'],
            'Effective_Hours': float(row['Effective_Hours']),
            'Fixed_Cost': float(row['Fixed_Cost'])
        })
    return data

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    params_path = os.path.join(base_dir, 'data', 'general_parameters.csv')
    table1_path = os.path.join(base_dir, 'data', 'table_1.csv')

    params = load_general_parameters(params_path)
    task_methods = load_task_methods(table1_path)

    skilled_wage = params['skilled_worker_weekly_wage']
    laborer_wage = params['laborer_weekly_wage']
    skilled_hours = params['skilled_worker_weekly_hours']
    laborer_hours = params['laborer_weekly_hours']
    max_skilled = params['max_skilled_workers']
    max_laborers = params['max_laborers']
    min_skilled_task3_B = params['min_skilled_workers_task3_methodB']
    skilled_hiring_ratio = params['skilled_worker_hiring_ratio']

    tasks = ['Task_1', 'Task_2', 'Task_3']
    methods = ['Method_A', 'Method_B']

    tm_data = {}
    for row in task_methods:
        key = (row['Task'], row['Method'])
        tm_data[key] = row

    model = gp.Model("WorkerAllocation")
    model.setParam('OutputFlag', 0)

    y = {}
    for t in tasks:
        for m in methods:
            y[t, m] = model.addVar(vtype=GRB.BINARY, name=f"y_{t}_{m}")

    s = {}
    l = {}
    for t in tasks:
        s[t] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"s_{t}")
        l[t] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"l_{t}")

    total_skilled = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_skilled")
    total_laborers = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_laborers")

    model.addConstr(total_skilled == gp.quicksum(s[t] for t in tasks))
    model.addConstr(total_laborers == gp.quicksum(l[t] for t in tasks))

    obj = skilled_wage * total_skilled + laborer_wage * total_laborers + \
          gp.quicksum(tm_data[t, m]['Fixed_Cost'] * y[t, m] for t in tasks for m in methods)
    model.setObjective(obj, GRB.MINIMIZE)

    for t in tasks:
        model.addConstr(gp.quicksum(y[t, m] for m in methods) == 1)
        req_hours = gp.quicksum(tm_data[t, m]['Effective_Hours'] * y[t, m] for m in methods)
        model.addConstr(skilled_hours * s[t] + laborer_hours * l[t] >= req_hours)

    model.addConstr(total_skilled <= max_skilled)
    model.addConstr(total_laborers <= max_laborers)
    model.addConstr(total_skilled <= skilled_hiring_ratio * total_laborers)

    model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1)
    model.addConstr(s['Task_3'] >= min_skilled_task3_B * y['Task_3', 'Method_B'])

    for i in range(1, 4):
        t = f'Task_{i}'
        min_share = params[f'min_skilled_share_task{i}']
        max_share = params[f'max_skilled_share_task{i}']
        model.addConstr(s[t] >= min_share * (s[t] + l[t]))
        model.addConstr(s[t] <= max_share * (s[t] + l[t]))

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
