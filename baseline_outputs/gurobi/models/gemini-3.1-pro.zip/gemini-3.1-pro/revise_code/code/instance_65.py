import os
import csv
import gurobipy as gp
from gurobipy import GRB

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv')) as f:
    for row in csv.DictReader(f):
        params[row['Parameter_Name'].strip()] = float(row['Value'])

products = {}
with open(os.path.join(data_dir, 'table_1.csv')) as f:
    for row in csv.DictReader(f):
        products[row['Product'].strip()] = {
            'a_hrs': float(row['Workshop_A_Hours']),
            'b_hrs': float(row['Workshop_B_Hours']),
            'insp_cost': float(row['Inspection_Sales_Cost'])
        }

m = products['Microwave_Oven']
w = products['Water_Heater']

model = gp.Model("production")
model.setParam('OutputFlag', 0)

x1 = model.addVar(lb=params['microwave_minimum_sales'], vtype=GRB.CONTINUOUS, name="microwave")
x2 = model.addVar(lb=params['water_heater_minimum_sales'], vtype=GRB.CONTINUOUS, name="water_heater")

y_m = model.addVar(vtype=GRB.BINARY, name="y_m")
y_w = model.addVar(vtype=GRB.BINARY, name="y_w")

model.addConstr(x1 <= params['bigM'] * y_m)
model.addConstr(x2 <= params['bigM'] * y_w)

rev_m = m['a_hrs']*params['workshop_a_hourly_cost'] + m['b_hrs']*params['workshop_b_hourly_cost'] + m['insp_cost'] + params['green_bonus_m']
rev_w = w['a_hrs']*params['workshop_a_hourly_cost'] + w['b_hrs']*params['workshop_b_hourly_cost'] + w['insp_cost'] + params['green_bonus_w']

model.setObjective(rev_m * x1 + rev_w * x2, GRB.MAXIMIZE)

model.addConstr(m['a_hrs']*x1 + w['a_hrs']*x2 + params['setup_hours_A']*y_m + params['setup_hours_A']*y_w <= params['workshop_a_available_hours'] + params['workshop_a_overtime_limit'])
model.addConstr(m['b_hrs']*x1 + w['b_hrs']*x2 <= params['workshop_b_available_hours'])
model.addConstr(m['insp_cost']*x1 + w['insp_cost']*x2 <= params['inspection_sales_cost_limit'])
model.addConstr(params['tech_rate_m']*x1 + params['tech_rate_w']*x2 <= params['tech_pool_hours'])

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
