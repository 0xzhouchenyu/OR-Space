import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load toys data
    toys = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                'type': row['Toy_Type'].strip(),
                'profit': float(row['Profit_Per_Unit']),
                'wood': float(row['Wood_Required_Per_Unit']),
                'steel': float(row['Steel_Required_Per_Unit']),
            })
            
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
            
    available_wood = params['available_wood']
    available_steel = params['available_steel']
    profit_premium_bonus = params['profit_premium_bonus']
    premium_steel_factor = params['premium_steel_factor']
    premium_shift_capacity = params['premium_shift_capacity']
    
    model = gp.Model("HausToys_Revised")
    model.setParam('OutputFlag', 0)
    
    M = 10000
    
    x_std = {}
    x_prem = {}
    y_std = {}
    y_prem = {}
    
    for t in toys:
        name = t['type']
        x_std[name] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_std_{name}")
        x_prem[name] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_prem_{name}")
        y_std[name] = model.addVar(vtype=GRB.BINARY, name=f"y_std_{name}")
        y_prem[name] = model.addVar(vtype=GRB.BINARY, name=f"y_prem_{name}")
        
        # A toy type can only run on one shift (or none)
        model.addConstr(y_std[name] + y_prem[name] <= 1, name=f"shift_excl_{name}")
        
        # Linking constraints
        model.addConstr(x_std[name] <= M * y_std[name], name=f"link_std_{name}")
        model.addConstr(x_prem[name] <= M * y_prem[name], name=f"link_prem_{name}")

    # Objective
    obj = gp.quicksum(t['profit'] * x_std[t['type']] + (t['profit'] + profit_premium_bonus) * x_prem[t['type']] for t in toys)
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Resource constraints
    model.addConstr(
        gp.quicksum(t['wood'] * (x_std[t['type']] + x_prem[t['type']]) for t in toys) <= available_wood,
        name="Wood_Constraint"
    )
    model.addConstr(
        gp.quicksum(t['steel'] * (x_std[t['type']] + premium_steel_factor * x_prem[t['type']]) for t in toys) <= available_steel,
        name="Steel_Constraint"
    )
    
    # Premium shift capacity
    model.addConstr(
        gp.quicksum(x_prem[t['type']] for t in toys) <= premium_shift_capacity,
        name="Premium_Capacity"
    )
    
    # Truck-train exclusion
    model.addConstr(
        (y_std['truck'] + y_prem['truck']) + (y_std['train'] + y_prem['train']) <= 1,
        name="Truck_Train_Exclusion"
    )
    
    # Boat-airplane dependency
    model.addConstr(
        (y_std['boat'] + y_prem['boat']) <= (y_std['airplane'] + y_prem['airplane']),
        name="Boat_Airplane_Dependency"
    )
    
    # Boat-train limit
    model.addConstr(
        (x_std['boat'] + x_prem['boat']) <= (x_std['train'] + x_prem['train']),
        name="Boat_Train_Limit"
    )
    
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
