import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_feed_data(filepath):
    feeds = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            feed = {
                'Feed': int(row['Feed']),
                'Protein_g': float(row['Protein_g']),
                'Minerals_g': float(row['Minerals_g']),
                'Vitamins_mg': float(row['Vitamins_mg']),
                'Price_Y_per_kg': float(row['Price_Y_per_kg']),
            }
            feeds.append(feed)
    return feeds

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    feeds = load_feed_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    min_protein = params['min_protein_requirement']
    min_minerals = params['min_minerals_requirement']
    min_vitamins = params['min_vitamins_requirement']

    model = gp.Model("MinimizeFeedCost")
    model.setParam('OutputFlag', 0)

    x = {}
    for f in feeds:
        x[f['Feed']] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{f['Feed']}")

    y4 = model.addVar(vtype=GRB.BINARY, name="y_4")
    y5 = model.addVar(vtype=GRB.BINARY, name="y_5")

    M = 10000

    model.addConstr(x[4] <= M * y4, "BigM_4")
    model.addConstr(x[5] <= M * y5, "BigM_5")
    model.addConstr(y4 + y5 <= 1, "MutuallyExclusive_4_5")

    model.addConstr(
        gp.quicksum(f['Protein_g'] * x[f['Feed']] for f in feeds) >= min_protein,
        "ProteinRequirement"
    )
    model.addConstr(
        gp.quicksum(f['Minerals_g'] * x[f['Feed']] for f in feeds) >= min_minerals,
        "MineralsRequirement"
    )
    model.addConstr(
        gp.quicksum(f['Vitamins_mg'] * x[f['Feed']] for f in feeds) >= min_vitamins,
        "VitaminsRequirement"
    )

    model.setObjective(
        gp.quicksum(f['Price_Y_per_kg'] * x[f['Feed']] for f in feeds),
        GRB.MINIMIZE
    )

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
