import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Extract parameters
shirts_inventory = params['shirts_inventory']
pants_inventory = params['pants_inventory']

price_a = params['package_a_price']
price_b = params['package_b_price']
price_c = params['package_c_price']

shirts_a = params['package_a_shirts']
pants_a = params['package_a_pants']
shirts_b = params['package_b_shirts']
pants_b = params['package_b_pants']
shirts_c = params['package_c_shirts']
pants_c = params['package_c_pants']

min_a = params['min_campaign_batch_a']
min_b = params['min_campaign_batch_b']
min_c = params['min_campaign_batch_c']

act_cost_a = params['activation_cost_a']
act_cost_b = params['activation_cost_b']
act_cost_c = params['activation_cost_c']

labor_a = params['labor_hours_per_A']
labor_b = params['labor_hours_per_B']
labor_c = params['labor_hours_per_C']
labor_total = params['labor_hours_total']

bigM_a = params['bigM_a']
bigM_b = params['bigM_b']
bigM_c = params['bigM_c']

thresh_b = params['package_b_review_threshold']
charge_b = params['package_b_review_charge']
thresh_c = params['package_c_review_threshold']
charge_c = params['package_c_review_charge']

model = gp.Model("Maximize_Revenue")
model.setParam('OutputFlag', 0)

# Decision variables
x_a = model.addVar(vtype=GRB.INTEGER, name="x_a", lb=0)
x_b = model.addVar(vtype=GRB.INTEGER, name="x_b", lb=0)
x_c = model.addVar(vtype=GRB.INTEGER, name="x_c", lb=0)

y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
y_c = model.addVar(vtype=GRB.BINARY, name="y_c")

z_b = model.addVar(vtype=GRB.BINARY, name="z_b")
z_c = model.addVar(vtype=GRB.BINARY, name="z_c")

# Objective
revenue = price_a * x_a + price_b * x_b + price_c * x_c
costs = act_cost_a * y_a + act_cost_b * y_b + act_cost_c * y_c + charge_b * z_b + charge_c * z_c
model.setObjective(revenue - costs, GRB.MAXIMIZE)

# Constraints
model.addConstr(shirts_a * x_a + shirts_b * x_b + shirts_c * x_c <= shirts_inventory, "Shirts_Inventory")
model.addConstr(pants_a * x_a + pants_b * x_b + pants_c * x_c <= pants_inventory, "Pants_Inventory")
model.addConstr(labor_a * x_a + labor_b * x_b + labor_c * x_c <= labor_total, "Labor_Capacity")

model.addConstr(x_a >= min_a * y_a, "Min_A")
model.addConstr(x_a <= bigM_a * y_a, "Max_A")

model.addConstr(x_b >= min_b * y_b, "Min_B")
model.addConstr(x_b <= bigM_b * y_b, "Max_B")

model.addConstr(x_c >= min_c * y_c, "Min_C")
model.addConstr(x_c <= bigM_c * y_c, "Max_C")

model.addConstr(x_b <= thresh_b + bigM_b * z_b, "Threshold_B")
model.addConstr(x_c <= thresh_c + bigM_c * z_c, "Threshold_C")

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: None")
