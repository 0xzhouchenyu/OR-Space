import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
            
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    std_widths = []
    pattern_setup_penalty = 0.0
    wide_roll_threshold_width = 0.0
    wide_roll_extra_setup_penalty = 0.0
    
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            val = float(row['Value'])
            if 'standard_width' in row['Parameter_Name']:
                std_widths.append(val)
            elif row['Parameter_Name'] == 'pattern_setup_penalty':
                pattern_setup_penalty = val
            elif row['Parameter_Name'] == 'wide_roll_threshold_width':
                wide_roll_threshold_width = val
            elif row['Parameter_Name'] == 'wide_roll_extra_setup_penalty':
                wide_roll_extra_setup_penalty = val
                
    widths = [o['width'] for o in orders]
    lengths = [o['length'] for o in orders]
    
    total_required_area = sum(w * l for w, l in zip(widths, lengths))
    
    patterns_by_std_width = {}
    for idx, sw in enumerate(std_widths):
        patterns = []
        def build_pattern(index, current_pattern, current_sum):
            if index == len(widths):
                if any(c > 0 for c in current_pattern):
                    patterns.append(current_pattern)
                return
            
            max_count = int(math.floor((sw - current_sum + 1e-7) / widths[index]))
            for count in range(max_count + 1):
                build_pattern(index + 1, current_pattern + [count], current_sum + count * widths[index])
                
        build_pattern(0, [], 0.0)
        patterns_by_std_width[idx] = {'sw': sw, 'patterns': patterns}
        
    model = gp.Model("Minimize_Waste")
    model.setParam('OutputFlag', 0)
    
    x_vars = {}
    y_vars = {}
    
    M = sum(lengths)
    
    for idx, data in patterns_by_std_width.items():
        sw = data['sw']
        penalty = pattern_setup_penalty
        if sw >= wide_roll_threshold_width - 1e-5:
            penalty += wide_roll_extra_setup_penalty
            
        for i, p in enumerate(data['patterns']):
            x_vars[(idx, i)] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{idx}_{i}")
            y_vars[(idx, i)] = model.addVar(vtype=GRB.BINARY, name=f"y_{idx}_{i}")
            model.addConstr(x_vars[(idx, i)] <= M * y_vars[(idx, i)])
            
    # Objective
    total_area_used = gp.quicksum(data['sw'] * x_vars[(idx, i)] for idx, data in patterns_by_std_width.items() for i, p in enumerate(data['patterns']))
    total_penalty = gp.quicksum((pattern_setup_penalty + (wide_roll_extra_setup_penalty if data['sw'] >= wide_roll_threshold_width - 1e-5 else 0)) * y_vars[(idx, i)] for idx, data in patterns_by_std_width.items() for i, p in enumerate(data['patterns']))
    
    model.setObjective(total_area_used + total_penalty, GRB.MINIMIZE)
    
    # Constraints
    for j in range(len(widths)):
        model.addConstr(gp.quicksum(p[j] * x_vars[(idx, i)] for idx, data in patterns_by_std_width.items() for i, p in enumerate(data['patterns'])) >= lengths[j])
        
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        waste = model.objVal - total_required_area
        print(f"FINAL_OBJ_VALUE: {round(waste, 4)}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    solve()
