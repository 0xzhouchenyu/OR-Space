import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    profit_A = params['profit_per_kg_product_A']
    profit_B = params['profit_per_kg_product_B']
    max_hours = {1: params['max_production_hours_week_1'], 2: params['max_production_hours_week_2']}
    hours_A = params['hours_per_kg_product_A']
    hours_B = params['hours_per_kg_product_B']
    min_ratio_B_to_A = params['min_output_ratio_product_B_to_A']
    storage_ratio_A_to_B = params['storage_space_ratio_product_A_to_B']
    max_storage_A_equiv = {1: params['max_storage_product_A_equiv_week_1'], 2: params['max_storage_product_A_equiv_week_2']}
    init_inv_A = params['initial_inventory_A']
    init_inv_B = params['initial_inventory_B']
    storage_cost_A = params['storage_cost_per_kg_A']
    storage_cost_B = params['storage_cost_per_kg_B']
    promo_bonus_A = params['promo_profit_bonus_A']
    promo_bonus_B = params['promo_profit_bonus_B']
    max_promo_A = params['max_promotions_product_A']
    max_promo_B = params['max_promotions_product_B']
    max_promo_per_period = params.get('max_promotions_per_period', None)

    model = gp.Model("Revised_Production_Planning")
    model.setParam('OutputFlag', 0)

    # Variables
    P_A = {t: model.addVar(lb=0, name=f"P_A_{t}") for t in [1, 2]}
    P_B = {t: model.addVar(lb=0, name=f"P_B_{t}") for t in [1, 2]}
    S_A = {t: model.addVar(lb=0, name=f"S_A_{t}") for t in [1, 2]}
    S_B = {t: model.addVar(lb=0, name=f"S_B_{t}") for t in [1, 2]}
    I_A = {t: model.addVar(lb=0, name=f"I_A_{t}") for t in [1, 2]}
    I_B = {t: model.addVar(lb=0, name=f"I_B_{t}") for t in [1, 2]}
    Z_A = {t: model.addVar(vtype=GRB.BINARY, name=f"Z_A_{t}") for t in [1, 2]}
    Z_B = {t: model.addVar(vtype=GRB.BINARY, name=f"Z_B_{t}") for t in [1, 2]}

    # Inventory Balance
    model.addConstr(I_A[1] == init_inv_A + P_A[1] - S_A[1])
    model.addConstr(I_B[1] == init_inv_B + P_B[1] - S_B[1])
    model.addConstr(I_A[2] == I_A[1] + P_A[2] - S_A[2])
    model.addConstr(I_B[2] == I_B[1] + P_B[2] - S_B[2])

    for t in [1, 2]:
        # Production Time
        model.addConstr(hours_A * P_A[t] + hours_B * P_B[t] <= max_hours[t])
        
        # Market Demand
        model.addConstr(P_B[t] >= min_ratio_B_to_A * P_A[t])
        
        # Storage Capacity
        max_storage_units = max_storage_A_equiv[t] * storage_ratio_A_to_B
        model.addConstr(storage_ratio_A_to_B * I_A[t] + I_B[t] <= max_storage_units)

        # Max promotions per period
        if max_promo_per_period is not None:
            model.addConstr(Z_A[t] + Z_B[t] <= max_promo_per_period)

    # Max promotions per product
    model.addConstr(gp.quicksum(Z_A[t] for t in [1, 2]) <= max_promo_A)
    model.addConstr(gp.quicksum(Z_B[t] for t in [1, 2]) <= max_promo_B)

    # Objective
    revenue = gp.quicksum(profit_A * S_A[t] + profit_B * S_B[t] + 
                          promo_bonus_A * S_A[t] * Z_A[t] + promo_bonus_B * S_B[t] * Z_B[t] 
                          for t in [1, 2])
    costs = storage_cost_A * I_A[1] + storage_cost_B * I_B[1]
    
    model.setObjective(revenue - costs, GRB.MAXIMIZE)
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal:.3f}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
