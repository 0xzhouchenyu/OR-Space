import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

cow_price = params['cow_selling_price']
sheep_price = params['sheep_selling_price']
chicken_price = params['chicken_selling_price']
cow_feed = params['cow_feed_cost']
sheep_feed = params['sheep_feed_cost']
chicken_feed = params['chicken_feed_cost']
cow_manure = params['cow_manure_production']
sheep_manure = params['sheep_manure_production']
chicken_manure = params['chicken_manure_production']
max_manure = params['max_manure_capacity']
max_chickens = params['max_chickens']
min_cows = params['min_cows']
min_sheep = params['min_sheep']
max_total = params['max_total_animals']

premium_capacity_multiplier = params.get('premium_capacity_multiplier', 1.0)
premium_manure_multiplier = params.get('premium_manure_multiplier', 1.0)
expansion_cost = params.get('expansion_cost', 0.0)
premium_feed_multiplier = params.get('premium_feed_multiplier', 1.0)
base_land_usage_cow = params.get('base_land_usage_cow', 0.0)
base_land_usage_sheep = params.get('base_land_usage_sheep', 0.0)
base_land_usage_chicken = params.get('base_land_usage_chicken', 0.0)
base_land_capacity = params.get('base_land_capacity', 0.0)
expansion_land_increase = params.get('expansion_land_increase', 0.0)

model = gp.Model("FarmProfit_Revised")
model.setParam('OutputFlag', 0)

expanded = model.addVar(vtype=GRB.BINARY, name="expanded")

cows_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="cows_reg")
sheep_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="sheep_reg")
chickens_reg = model.addVar(vtype=GRB.INTEGER, lb=0, name="chickens_reg")

cows_prem = model.addVar(vtype=GRB.INTEGER, lb=0, name="cows_prem")
sheep_prem = model.addVar(vtype=GRB.INTEGER, lb=0, name="sheep_prem")
chickens_prem = model.addVar(vtype=GRB.INTEGER, lb=0, name="chickens_prem")

total_cows = cows_reg + cows_prem
total_sheep = sheep_reg + sheep_prem
total_chickens = chickens_reg + chickens_prem
total_animals = total_cows + total_sheep + total_chickens

model.addConstr(total_cows >= min_cows, "min_cows")
model.addConstr(total_sheep >= min_sheep, "min_sheep")
model.addConstr(total_chickens <= max_chickens, "max_chickens")

M = 10000
model.addConstr(cows_prem + sheep_prem + chickens_prem <= M * expanded, "premium_only_if_expanded")

model.addConstr(total_animals <= max_total + expanded * (max_total * premium_capacity_multiplier - max_total), "max_total_animals")

total_manure = cow_manure * total_cows + sheep_manure * total_sheep + chicken_manure * total_chickens
model.addConstr(total_manure <= max_manure + expanded * (max_manure * premium_manure_multiplier - max_manure), "max_manure")

total_land = base_land_usage_cow * total_cows + base_land_usage_sheep * total_sheep + base_land_usage_chicken * total_chickens
model.addConstr(total_land <= base_land_capacity + expanded * expansion_land_increase, "max_land")

profit = (cow_price * total_cows + sheep_price * total_sheep + chicken_price * total_chickens) \
         - (cow_feed * cows_reg + sheep_feed * sheep_reg + chicken_feed * chickens_reg) \
         - (cow_feed * premium_feed_multiplier * cows_prem + sheep_feed * premium_feed_multiplier * sheep_prem + chicken_feed * premium_feed_multiplier * chickens_prem) \
         - expansion_cost * expanded

model.setObjective(profit, GRB.MAXIMIZE)
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: None")
