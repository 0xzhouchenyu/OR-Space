import gurobipy as gp
from gurobipy import GRB
import os
import csv

def solve():
    # Setup paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params_file = os.path.join(data_dir, 'general_parameters.csv')
    
    # Load parameters
    params = {}
    with open(params_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
            
    a1 = params['a1']
    a2 = params['a2']
    training_capacity = params['training_capacity_per_jet']
    dual_use_efficiency = params['dual_use_training_efficiency']
    intensity_cap = params['training_intensity_cap']
    combat_min_y2 = params['combat_jet_min_year2']
    combat_weight = params['combat_weight']
    training_weight = params['training_weight']
    
    # Initialize model
    m = gp.Model("Fighter_Jet_Plan")
    m.setParam('OutputFlag', 0)
    
    # Variables for Year 1
    T1 = m.addVar(vtype=GRB.INTEGER, name="T1", lb=0)
    M1 = m.addVar(vtype=GRB.INTEGER, name="M1", lb=0)
    C1 = m.addVar(vtype=GRB.INTEGER, name="C1", lb=0)
    
    # Variables for Year 2
    T2 = m.addVar(vtype=GRB.INTEGER, name="T2", lb=0)
    M2 = m.addVar(vtype=GRB.INTEGER, name="M2", lb=0)
    C2 = m.addVar(vtype=GRB.INTEGER, name="C2", lb=0)
    
    # Variable for fully trained pilots (completing the 2-year program)
    P = m.addVar(vtype=GRB.INTEGER, name="P", lb=0)
    
    # Fleet sizes
    N1 = a1
    N2 = a1 + a2
    
    # Constraints
    # 1. Fleet allocation per year
    m.addConstr(T1 + M1 + C1 == N1, "Alloc_Y1")
    m.addConstr(T2 + M2 + C2 == N2, "Alloc_Y2")
    
    # 2. Training intensity cap
    m.addConstr(T1 + M1 <= intensity_cap * N1, "Cap_Y1")
    m.addConstr(T2 + M2 <= intensity_cap * N2, "Cap_Y2")
    
    # 3. Combat minimum year 2 (Mixed-use aircraft support combat availability)
    m.addConstr(C2 + M2 >= combat_min_y2, "Combat_Min_Y2")
    
    # 4. Pilot training yield (bottleneck over the 2-year duration)
    m.addConstr(P <= training_capacity * T1 + training_capacity * dual_use_efficiency * M1, "Yield_Y1")
    m.addConstr(P <= training_capacity * T2 + training_capacity * dual_use_efficiency * M2, "Yield_Y2")
    
    # Objective: Maximize weighted sum of year-2 combat availability and total trained pilots
    m.setObjective(combat_weight * (C2 + M2) + training_weight * P, GRB.MAXIMIZE)
    
    # Solve
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == '__main__':
    solve()
