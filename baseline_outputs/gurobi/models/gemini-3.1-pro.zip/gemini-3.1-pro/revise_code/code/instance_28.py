import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

initial_fund = params['initial_fund']
annual_rate = params['annual_profit_rate'] / 100
inv_limit_y1 = params['investment_limit_year1']
return_rate_y1y2 = params['return_rate_year1_to_year2'] / 100
inv_limit_y2 = params['investment_limit_year2']
return_rate_y2y3 = params['return_rate_year2_to_year3'] / 100
inv_limit_y3 = params['investment_limit_year3']
profit_rate_y3 = params['profit_rate_year3'] / 100

fee_year1 = params['fee_year1']
fee_year2 = params['fee_year2']
fee_year3 = params['fee_year3']

# Model
model = gp.Model("Investment_Optimization")
model.setParam('OutputFlag', 0)

# Variables
a1 = model.addVar(lb=0, name="a1")
a2 = model.addVar(lb=0, name="a2")
a3 = model.addVar(lb=0, name="a3")

b1 = model.addVar(lb=0, ub=inv_limit_y1, name="b1")
c2 = model.addVar(lb=0, ub=inv_limit_y2, name="c2")
d3 = model.addVar(lb=0, ub=inv_limit_y3, name="d3")

y1 = model.addVar(vtype=GRB.BINARY, name="y1")
y2 = model.addVar(vtype=GRB.BINARY, name="y2")
y3 = model.addVar(vtype=GRB.BINARY, name="y3")

cash_y1_end = model.addVar(lb=0, name="cash_y1_end")
cash_y2_end = model.addVar(lb=0, name="cash_y2_end")
cash_y3_end = model.addVar(lb=0, name="cash_y3_end")

# Constraints
model.addConstr(b1 <= inv_limit_y1 * y1)
model.addConstr(c2 <= inv_limit_y2 * y2)
model.addConstr(d3 <= inv_limit_y3 * y3)

# Year 1
model.addConstr(a1 + b1 + cash_y1_end == initial_fund)

# Year 2
model.addConstr(a2 + c2 + cash_y2_end == cash_y1_end + a1 * (1 + annual_rate))

# Year 3
model.addConstr(a3 + d3 + cash_y3_end == cash_y2_end + a2 * (1 + annual_rate) + b1 * return_rate_y1y2)

# Objective
total_end = cash_y3_end + a3 * (1 + annual_rate) + c2 * return_rate_y2y3 + d3 * (1 + profit_rate_y3)
objective = total_end - fee_year1 * y1 - fee_year2 * y2 - fee_year3 * y3

model.setObjective(objective, GRB.MAXIMIZE)

model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
