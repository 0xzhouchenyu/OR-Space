import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load candidates
    candidates = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Candidate'].strip()
            candidates[name] = {
                'salary': float(row['Salary'].strip()),
                'skill': float(row['Skill_Level'].strip()),
                'pm_exp': float(row['Project_Management_Experience'].strip())
            }
    
    # Load parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    budget = params['company_budget']
    max_employees = params['max_employees']
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_gj = params['max_one_candidate_g_j']
    lead_premium = params['lead_premium']
    min_leads = params['min_leads']
    mentor_bonus = params['mentor_bonus']
    max_pairs = params['max_pairs']
    
    model = gp.Model("HiringOptimization")
    model.setParam('OutputFlag', 0)
    
    # Variables
    x = {}
    L = {}
    E = {}
    for c in candidates:
        x[c] = model.addVar(vtype=GRB.BINARY, name=f"x_{c}")
        L[c] = model.addVar(vtype=GRB.BINARY, name=f"L_{c}")
        E[c] = model.addVar(vtype=GRB.BINARY, name=f"E_{c}")
        
    P = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="P")
    
    # Constraints
    for c in candidates:
        model.addConstr(L[c] + E[c] == x[c], f"role_assignment_{c}")
        
    sum_L = gp.quicksum(L[c] for c in candidates)
    sum_E = gp.quicksum(E[c] for c in candidates)
    
    model.addConstr(sum_L >= min_leads, "min_leads")
    
    model.addConstr(P <= max_pairs, "max_pairs_bound")
    model.addConstr(P <= sum_L, "pairs_le_leads")
    model.addConstr(P <= sum_E, "pairs_le_engineers")
    
    net_cost = gp.quicksum(candidates[c]['salary'] * x[c] + lead_premium * L[c] for c in candidates) - mentor_bonus * P
    
    model.addConstr(net_cost <= budget, "budget")
    model.addConstr(gp.quicksum(x[c] for c in candidates) <= max_employees, "max_emp")
    model.addConstr(gp.quicksum(candidates[c]['skill'] * x[c] for c in candidates) >= min_skill, "min_skill")
    model.addConstr(gp.quicksum(candidates[c]['pm_exp'] * x[c] for c in candidates) >= min_pm_exp, "min_pm")
    
    if 'G' in candidates and 'J' in candidates:
        model.addConstr(x['G'] + x['J'] <= max_gj, "max_gj")
        
    model.setObjective(net_cost, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
