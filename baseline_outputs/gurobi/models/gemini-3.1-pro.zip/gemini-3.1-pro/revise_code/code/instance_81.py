import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load car lengths
    cars = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cars[int(row['i'])] = float(row['lambda_i'])
            
    # Load parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
            
    max_length_one_side = params['max_length_one_side']
    
    # Create model
    m = gp.Model("ParkingMinStreetLength")
    m.setParam('OutputFlag', 0)
    
    # Decision variables: x[i] = 1 if car i is parked on the usable side
    # Since only one side is available and all cars must park, they all must go to this side.
    x = m.addVars(cars.keys(), vtype=GRB.BINARY, name="x")
    
    # Constraint: All cars must be parked on the usable side
    for i in cars:
        m.addConstr(x[i] == 1, name=f"park_{i}")
        
    # Total length on the usable side
    side_length = gp.quicksum(cars[i] * x[i] for i in cars)
    
    # Constraint: Must respect the parking-length limit
    m.addConstr(side_length <= max_length_one_side, name="max_length")
    
    # Objective: Minimize the total length of the street occupied
    # Since all cars are on one side, this is simply the length of that side.
    m.setObjective(side_length, GRB.MINIMIZE)
    
    # Solve
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    solve()
