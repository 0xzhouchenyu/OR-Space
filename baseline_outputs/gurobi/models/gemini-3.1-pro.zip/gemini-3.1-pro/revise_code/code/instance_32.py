import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read table_1.csv
    workshops = []
    capacities = {}
    rates = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            capacities[w] = float(row['Production_Capacity_hours'].strip())
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())
            
    # Read general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            if name:
                params[name] = float(row['Value'].strip())
                
    # Initialize Gurobi Model
    model = gp.Model("Maximize_Completed_Products_Revised")
    model.setParam('OutputFlag', 0)
    
    components = [1, 2, 3]
    
    # Decision Variables
    x = {}
    for w in workshops:
        for c in components:
            x[(w, c)] = model.addVar(lb=0, name=f"x_{w}_{c}")
            
    z = model.addVar(lb=0, name="z")
    
    h_day_reg = {}
    h_day_ot = {}
    h_night_reg = {}
    h_night_ot = {}
    y_day = {}
    y_night = {}
    
    for w in workshops:
        h_day_reg[w] = model.addVar(lb=0, ub=params[f'regular_hours_limit_day_{w}'], name=f"h_day_reg_{w}")
        h_day_ot[w] = model.addVar(lb=0, ub=params[f'overtime_capacity_day_{w}'], name=f"h_day_ot_{w}")
        h_night_reg[w] = model.addVar(lb=0, ub=params[f'regular_hours_limit_night_{w}'], name=f"h_night_reg_{w}")
        h_night_ot[w] = model.addVar(lb=0, ub=params[f'overtime_capacity_night_{w}'], name=f"h_night_ot_{w}")
        
        y_day[w] = model.addVar(vtype=GRB.BINARY, name=f"y_day_{w}")
        y_night[w] = model.addVar(vtype=GRB.BINARY, name=f"y_night_{w}")
        
    S = model.addVar(lb=0, name="Shortage")
    
    # Constraints
    # 1. No more than two workshops active in the same shift
    model.addConstr(gp.quicksum(y_day[w] for w in workshops) <= 2, "Max_active_day")
    model.addConstr(gp.quicksum(y_night[w] for w in workshops) <= 2, "Max_active_night")
    
    # 2. Big-M constraints linking active indicators to hours
    for w in workshops:
        M = params[f'bigM_shift_{w}']
        model.addConstr(h_day_reg[w] + h_day_ot[w] <= M * y_day[w], f"BigM_day_{w}")
        model.addConstr(h_night_reg[w] + h_night_ot[w] <= M * y_night[w], f"BigM_night_{w}")
        
    # 3. Total hours per workshop and capacity limits
    for w in workshops:
        total_h = h_day_reg[w] + h_day_ot[w] + h_night_reg[w] + h_night_ot[w]
        model.addConstr(gp.quicksum(x[(w, c)] for c in components) == total_h, f"Total_hours_match_{w}")
        model.addConstr(total_h <= capacities[w], f"Capacity_{w}")
        
    # 4. Component production limits the number of completed products
    for c in components:
        model.addConstr(z <= gp.quicksum(rates[(w, c)] * x[(w, c)] for w in workshops), f"Min_component_{c}")
        
    # 5. Shortage definition
    model.addConstr(S >= params['z_target'] - z, "Shortage_def")
    
    # Objective Function
    penalty_night = params['penalty_night_hour']
    penalty_ot = params['penalty_overtime_hour']
    penalty_shortage = params['penalty_shortage_per_unit']
    
    total_penalty = (
        penalty_night * gp.quicksum(h_night_reg[w] for w in workshops) +
        penalty_ot * gp.quicksum(h_day_ot[w] + h_night_ot[w] for w in workshops) +
        penalty_shortage * S
    )
    
    model.setObjective(z - total_penalty, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
