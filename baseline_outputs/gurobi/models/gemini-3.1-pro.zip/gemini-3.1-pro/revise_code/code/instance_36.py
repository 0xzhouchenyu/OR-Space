import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def calculate_distance(c1, c2):
    return math.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')

    params = {}
    with open(params_path, 'r') as f:
        reader = csv.reader(f)
        for parts in reader:
            if not parts or parts[0] == 'Parameter_Name':
                continue
            params[parts[0]] = parts[1]

    truck_capacity = float(params['truck_capacity'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])

    depot_str = params['depot_coordinates'].replace('"', '').strip('()')
    if ',' in depot_str:
        depot_x, depot_y = map(float, depot_str.split(','))
    else:
        depot_x, depot_y = map(float, depot_str.split())

    depot_tw_start = float(params['depot_time_window_start'])
    depot_tw_end = float(params['depot_time_window_end'])

    coords = [(depot_x, depot_y)]
    demands = [0.0]
    tw_start = [depot_tw_start]
    tw_end = [depot_tw_end]
    svc = [0.0]
    outsource_cost = [0.0]
    mandatory_ext = [0]

    with open(table_1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((float(row['Coordinates_X']), float(row['Coordinates_Y'])))
            demands.append(float(row['Demand']))
            tw_start.append(float(row['Time_Window_Start']))
            tw_end.append(float(row['Time_Window_End']))
            svc.append(float(row['Service_Duration']))
            outsource_cost.append(float(row['Outsource_Cost']))
            mandatory_ext.append(int(row['Mandatory_External']))

    n = len(coords)
    N = list(range(1, n))
    V = list(range(n))

    dist = {}
    for i in V:
        for j in V:
            dist[i, j] = calculate_distance(coords[i], coords[j])

    model = gp.Model("VRPHTW_Outsourcing")
    model.setParam('OutputFlag', 0)

    x = model.addVars(V, V, vtype=GRB.BINARY, name="x")
    z = model.addVars(N, vtype=GRB.BINARY, name="z")
    t = model.addVars(V, vtype=GRB.CONTINUOUS, name="t")
    u = model.addVars(N, vtype=GRB.CONTINUOUS, name="u")

    # Objective
    model.setObjective(
        gp.quicksum(dist[i, j] * x[i, j] for i in V for j in V if i != j) +
        gp.quicksum(outsource_cost[i] * z[i] for i in N),
        GRB.MINIMIZE
    )

    # Constraints
    for i in V:
        x[i, i].ub = 0

    for i in N:
        model.addConstr(gp.quicksum(x[i, j] for j in V if i != j) + z[i] == 1)
        model.addConstr(gp.quicksum(x[j, i] for j in V if i != j) + z[i] == 1)
        if mandatory_ext[i] == 1:
            model.addConstr(z[i] == 1)

    model.addConstr(gp.quicksum(x[0, j] for j in N) <= inhouse_truck_limit)
    model.addConstr(gp.quicksum(x[0, j] for j in N) == gp.quicksum(x[j, 0] for j in N))

    for i in V:
        model.addConstr(t[i] >= tw_start[i])
        model.addConstr(t[i] <= tw_end[i])

    for i in V:
        for j in N:
            if i != j:
                M = tw_end[i] + svc[i] + dist[i, j] - tw_start[j]
                if M > 0:
                    model.addConstr(t[i] + svc[i] + dist[i, j] - t[j] <= M * (1 - x[i, j]))

    for i in N:
        M = tw_end[i] + svc[i] + dist[i, 0] - tw_start[0]
        if M > 0:
            model.addConstr(t[i] + svc[i] + dist[i, 0] - t[0] <= M * (1 - x[i, 0]))

    for i in N:
        model.addConstr(u[i] >= demands[i])
        model.addConstr(u[i] <= truck_capacity)
        for j in N:
            if i != j:
                model.addConstr(u[i] + demands[j] - u[j] <= truck_capacity * (1 - x[i, j]))

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == '__main__':
    solve()
