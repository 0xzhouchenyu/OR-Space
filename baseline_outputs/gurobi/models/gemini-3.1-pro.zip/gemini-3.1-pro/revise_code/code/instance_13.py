import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    profit_corn = params['profit_per_acre_corn']
    profit_wheat = params['profit_per_acre_wheat']
    profit_soybeans = params['profit_per_acre_soybeans']
    profit_sorghum = params['profit_per_acre_sorghum']
    total_area = params['total_farm_area']
    corn_wheat_ratio = params['corn_wheat_ratio']
    soybeans_sorghum_ratio = params['soybeans_sorghum_ratio']
    wheat_sorghum_ratio = params['wheat_sorghum_ratio']
    
    model = gp.Model("Farm_Optimization")
    model.setParam('OutputFlag', 0)
    
    corn = model.addVar(lb=0, ub=total_area, name="corn")
    wheat = model.addVar(lb=0, ub=total_area, name="wheat")
    soybeans = model.addVar(lb=0, ub=total_area, name="soybeans")
    sorghum = model.addVar(lb=0, ub=total_area, name="sorghum")
    
    y_corn = model.addVar(vtype=GRB.BINARY, name="y_corn")
    y_soy = model.addVar(vtype=GRB.BINARY, name="y_soy")
    
    model.setObjective(
        profit_corn * corn + profit_wheat * wheat + profit_soybeans * soybeans + profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )
    
    # Constraints
    model.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")
    
    model.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio")
    model.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio")
    model.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_ratio")
    
    # Mutual exclusion between corn and soybeans
    model.addConstr(y_corn + y_soy <= 1, "mut_excl")
    model.addConstr(corn <= total_area * y_corn, "corn_ind")
    model.addConstr(soybeans <= total_area * y_soy, "soy_ind")
    
    # Minimum corn obligation
    model.addConstr(corn >= 20, "min_corn")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
