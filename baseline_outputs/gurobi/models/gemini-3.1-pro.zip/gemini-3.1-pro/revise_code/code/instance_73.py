import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
            
    max_children = int(params['max_children_trip'])
    min_children = int(params['min_children_trip'])
    max_distinct = int(params['max_distinct_children_trip'])
    budget = float(params['total_cost_budget'])
    bonus_saving = float(params['bonus_saving'])
    min_bob_days = int(params['min_bob_days'])
    
    children = []
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Child'].strip()
            cost = float(row['Cost'].strip())
            children.append(name)
            costs[name] = cost
            
    days = [1, 2]
    
    model = gp.Model("FamilyTripTwoDays")
    model.setParam('OutputFlag', 0)
    
    x = model.addVars(children, days, vtype=GRB.BINARY, name="x")
    y = model.addVars(children, vtype=GRB.BINARY, name="y")
    z = model.addVars(children, vtype=GRB.BINARY, name="z")
    
    # Day constraints
    for d in days:
        model.addConstr(gp.quicksum(x[c, d] for c in children) >= min_children)
        model.addConstr(gp.quicksum(x[c, d] for c in children) <= max_children)
        
        model.addConstr(x['Alice', d] + x['Diana', d] <= 1)
        model.addConstr(x['Bob', d] + x['Charlie', d] <= 1)
        model.addConstr(x['Charlie', d] <= x['Diana', d])
        model.addConstr(x['Diana', d] <= x['Ella', d])
        
    # Availability
    model.addConstr(x['Charlie', 1] == 0)
    model.addConstr(x['Diana', 1] == 0)
    model.addConstr(x['Alice', 2] == 0)
    
    # Bob minimum days
    model.addConstr(x['Bob', 1] + x['Bob', 2] >= min_bob_days)
    
    # y and z variables
    for c in children:
        model.addConstr(y[c] <= x[c, 1])
        model.addConstr(y[c] <= x[c, 2])
        model.addConstr(y[c] >= x[c, 1] + x[c, 2] - 1)
        
        model.addConstr(z[c] >= x[c, 1])
        model.addConstr(z[c] >= x[c, 2])
        model.addConstr(z[c] <= x[c, 1] + x[c, 2])
        
    # Distinct children limit
    model.addConstr(gp.quicksum(z[c] for c in children) <= max_distinct)
    
    # Cost calculation
    total_cost = gp.quicksum(costs[c] * x[c, d] for c in children for d in days)
    total_bonus = gp.quicksum(bonus_saving * y[c] for c in children)
    net_cost = total_cost - total_bonus
    
    model.addConstr(net_cost <= budget)
    
    model.setObjective(net_cost, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
