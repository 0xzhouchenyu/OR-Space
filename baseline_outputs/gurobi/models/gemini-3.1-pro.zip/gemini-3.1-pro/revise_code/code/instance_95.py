import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
            
    storage_cost = params['storage_cost_per_thousand_boxes']
    w2_push_thresh = params['week2_push_threshold']
    w3_cap_loss = params['week3_capacity_loss_after_week2_push']
    w2_micro_thresh = params['week2_microclean_threshold']
    w2_micro_fee = params['week2_microclean_fee']
    
    # Load table 1
    weeks = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })
            
    n_weeks = len(weeks)
    
    model = gp.Model("Beverage_Production_Planning")
    model.setParam('OutputFlag', 0)
    
    x = []
    s = []
    for t in range(n_weeks):
        x.append(model.addVar(lb=0, ub=weeks[t]['capacity'], name=f"x_{t+1}"))
        s.append(model.addVar(lb=0, name=f"s_{t+1}"))
        
    y_push = model.addVar(vtype=GRB.BINARY, name="y_push")
    y_micro = model.addVar(vtype=GRB.BINARY, name="y_micro")
    
    # Week 2 push logic
    model.addConstr(x[1] - w2_push_thresh <= (weeks[1]['capacity'] - w2_push_thresh) * y_push)
    model.addConstr(x[2] <= weeks[2]['capacity'] - w3_cap_loss * y_push)
    
    # Week 2 micro-clean logic
    model.addConstr(x[1] - w2_micro_thresh <= (weeks[1]['capacity'] - w2_micro_thresh) * y_micro)
    
    # Inventory balance
    for t in range(n_weeks):
        if t == 0:
            model.addConstr(x[t] - s[t] == weeks[t]['demand'])
        else:
            model.addConstr(s[t-1] + x[t] - s[t] == weeks[t]['demand'])
            
    # Objective
    prod_cost = gp.quicksum(weeks[t]['cost'] * x[t] for t in range(n_weeks))
    stor_cost = gp.quicksum(storage_cost * s[t] for t in range(n_weeks))
    
    model.setObjective(prod_cost + stor_cost + w2_micro_fee * y_micro, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
