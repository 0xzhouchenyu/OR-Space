import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            params[name] = float(val)

    a1_yield = params['product_A1_yield']
    a1_time = params['product_A1_time']
    a2_yield = params['product_A2_yield']
    a2_time = params['product_A2_time']
    a3_yield = params['product_A3_yield']
    a3_time = params['product_A3_time']
    profit_a1 = params['profit_per_kg_A1']
    profit_a2 = params['profit_per_kg_A2']
    profit_a3 = params['profit_per_kg_A3']
    milk_supply = params['daily_milk_supply']
    labor_hours = params['daily_labor_hours']
    cap_a_shared = params['cap_A_shared']
    min_a2 = params['min_A2_kg']
    min_a3 = params['min_A3_kg']
    cleaning_loss_a3 = params['type_A_cleaning_loss_if_A3']
    bonus_threshold = params['cold_chain_bonus_threshold_kg']
    bonus_yuan = params['cold_chain_bonus_yuan']

    model = gp.Model("Dairy_Production_Revised")
    model.setParam('OutputFlag', 0)

    x1 = model.addVar(lb=0, name="x1")
    x2 = model.addVar(lb=0, name="x2")
    x3 = model.addVar(lb=0, name="x3")

    y3 = model.addVar(vtype=GRB.BINARY, name="y3")
    z = model.addVar(vtype=GRB.BINARY, name="z")

    a1_kg = model.addVar(lb=0, name="a1_kg")
    a2_kg = model.addVar(lb=0, name="a2_kg")
    a3_kg = model.addVar(lb=0, name="a3_kg")

    model.addConstr(a1_kg == x1 * a1_yield)
    model.addConstr(a2_kg == x2 * a2_yield)
    model.addConstr(a3_kg == x3 * a3_yield)

    model.addConstr(x1 + x2 + x3 <= milk_supply)
    model.addConstr(a1_time * x1 + a2_time * x2 + a3_time * x3 <= labor_hours)

    model.addConstr(a2_kg >= min_a2)
    model.addConstr(a3_kg >= min_a3)

    model.addConstr(a3_kg <= 10000 * y3)
    model.addConstr(a1_kg + a3_kg <= cap_a_shared - cleaning_loss_a3 * y3)

    model.addConstr((z == 1) >> (a3_kg >= bonus_threshold))

    obj = profit_a1 * a1_kg + profit_a2 * a2_kg + profit_a3 * a3_kg + bonus_yuan * z
    model.setObjective(obj, GRB.MAXIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
