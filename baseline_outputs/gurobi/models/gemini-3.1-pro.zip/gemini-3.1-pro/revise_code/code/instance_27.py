import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load Table 1
    table1_path = os.path.join(data_dir, 'table_1.csv')
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    
    products = ['Product_I', 'Product_II', 'Product_III']
    
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in products:
                val = row[p].strip() if row[p].strip() else None
                proc_times[e][p] = float(val) if val else None
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())
            
    # Load General Parameters
    gen_params_path = os.path.join(data_dir, 'general_parameters.csv')
    raw_costs = {}
    prices = {}
    labor_coeffs = {}
    shared_labor_hours = 0
    b2_activation_fee = 0
    
    mapping_raw = {
        'raw_material_cost_product_I': 'Product_I',
        'raw_material_cost_product_II': 'Product_II',
        'raw_material_cost_product_III': 'Product_III',
    }
    mapping_price = {
        'unit_price_product_I': 'Product_I',
        'unit_price_product_II': 'Product_II',
        'unit_price_product_III': 'Product_III',
    }
    
    with open(gen_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            if name in mapping_raw:
                raw_costs[mapping_raw[name]] = val
            elif name in mapping_price:
                prices[mapping_price[name]] = val
            elif name == 'shared_labor_hours':
                shared_labor_hours = val
            elif name == 'b2_activation_fee':
                b2_activation_fee = val
            elif name.startswith('labor_coeff_'):
                e = name.replace('labor_coeff_', '')
                labor_coeffs[e] = val

    A_equip = [e for e in equipment if e.startswith('A')]
    B_equip = [e for e in equipment if e.startswith('B')]
    
    model = gp.Model("Revised_Factory_Production")
    model.setParam('OutputFlag', 0)
    
    x = {}
    for e in equipment:
        x[e] = {}
        for p in products:
            if proc_times[e][p] is not None:
                x[e][p] = model.addVar(lb=0, name=f"x_{e}_{p}")
                
    y_B2 = model.addVar(vtype=GRB.BINARY, name="y_B2")
    
    # Capacity constraints
    for e in equipment:
        used_time = gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None)
        if e == 'B2':
            model.addConstr(used_time <= eff_hours[e] * y_B2, name=f"capacity_{e}")
        else:
            model.addConstr(used_time <= eff_hours[e], name=f"capacity_{e}")
            
    # Flow balance
    for p in products:
        a_sum = gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None)
        b_sum = gp.quicksum(x[e][p] for e in B_equip if proc_times[e][p] is not None)
        model.addConstr(a_sum == b_sum, name=f"balance_{p}")
        
    # Labor constraint
    total_labor = gp.quicksum(
        labor_coeffs[e] * gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None)
        for e in equipment
    )
    model.addConstr(total_labor <= shared_labor_hours, name="shared_labor")
    
    # Objective
    total_prod = {p: gp.quicksum(x[e][p] for e in A_equip if proc_times[e][p] is not None) for p in products}
    
    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)
    raw_cost_total = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)
    operating_cost = gp.quicksum(
        op_costs[e] * gp.quicksum(x[e][p] * proc_times[e][p] for p in products if proc_times[e][p] is not None) / eff_hours[e]
        for e in equipment
    )
    
    profit = revenue - raw_cost_total - operating_cost - b2_activation_fee * y_B2
    model.setObjective(profit, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
