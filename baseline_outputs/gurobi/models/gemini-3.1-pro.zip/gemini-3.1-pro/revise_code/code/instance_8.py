import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read table_1.csv
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    workers = []
    tasks = ['A', 'B', 'C', 'D']
    cost = {}
    fixed_cost = {}
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            worker = row[0].strip()
            workers.append(worker)
            cost[(worker, 'A')] = float(row[1])
            cost[(worker, 'B')] = float(row[2])
            cost[(worker, 'C')] = float(row[3])
            cost[(worker, 'D')] = float(row[4])
            fixed_cost[worker] = float(row[5])
            
    # Read general_parameters.csv
    param_path = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(param_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            params[row[0].strip()] = float(row[1])
            
    handoff_cost = params.get('shared_temp_handoff_cost', 6.0)
    pair_fee = params.get('worker_II_V_pair_fee', 5.0)
    
    model = gp.Model("Assignment")
    model.setParam('OutputFlag', 0)
    
    x = {}
    for w in workers:
        for t in tasks:
            x[(w, t)] = model.addVar(vtype=GRB.BINARY, name=f"x_{w}_{t}")
            
    y = {}
    for w in workers:
        y[w] = model.addVar(vtype=GRB.BINARY, name=f"y_{w}")
        
    z1 = model.addVar(vtype=GRB.BINARY, name="z1")
    z2 = model.addVar(vtype=GRB.BINARY, name="z2")
    
    for t in tasks:
        model.addConstr(gp.quicksum(x[(w, t)] for w in workers) == 1)
        
    for w in workers:
        model.addConstr(gp.quicksum(x[(w, t)] for t in tasks) == y[w])
        model.addConstr(y[w] <= 1)
        
    if 'III' in workers and 'V' in workers:
        model.addConstr(z1 >= y['III'] + y['V'] - 1)
    if 'II' in workers and 'V' in workers:
        model.addConstr(z2 >= y['II'] + y['V'] - 1)
    
    obj = gp.quicksum(cost[(w, t)] * x[(w, t)] for w in workers for t in tasks) \
          + gp.quicksum(fixed_cost[w] * y[w] for w in workers) \
          + handoff_cost * z1 + pair_fee * z2
          
    model.setObjective(obj, GRB.MINIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    main()
