import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load parameters
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    min_courses = 2
    prereqs = {}
    cs_foundation = None
    cs_category = None
    
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            if name == 'min_courses_required':
                min_courses = int(val)
            elif name.startswith('prerequisite_'):
                course_key = name.replace('prerequisite_', '').replace('_', ' ').lower()
                prereqs[course_key] = val
            elif name == 'mandatory_foundation_for_cs_counting':
                cs_foundation = val
            elif name == 'cs_category_name':
                cs_category = val

    # Load courses
    courses_path = os.path.join(data_dir, 'table_1.csv')
    course_cats = {}
    all_categories = set()
    with open(courses_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            cats = [c.strip() for c in row['Category'].split(';')]
            course_cats[course] = cats
            for c in cats:
                all_categories.add(c)
                
    course_list = list(course_cats.keys())
    
    # Match prereqs
    matched_prereqs = []
    for c_key, p_val in prereqs.items():
        matched_c = None
        for c in course_list:
            if c.lower() == c_key:
                matched_c = c
                break
        if matched_c:
            matched_prereqs.append((matched_c, p_val))

    # Model
    model = gp.Model("CourseSelection")
    model.setParam('OutputFlag', 0)
    
    x = model.addVars(course_list, vtype=GRB.BINARY, name="x")
    
    # y[c, k] = 1 if course c is counted towards category k
    y = model.addVars(course_list, all_categories, vtype=GRB.BINARY, name="y")
    
    # Objective: minimize total courses
    model.setObjective(gp.quicksum(x[c] for c in course_list), GRB.MINIMIZE)
    
    # y[c, k] <= x[c]
    for c in course_list:
        for k in all_categories:
            model.addConstr(y[c, k] <= x[c])
            
    # each course counts towards at most one category
    for c in course_list:
        model.addConstr(gp.quicksum(y[c, k] for k in all_categories) <= 1)
        
    # only count towards valid categories
    for c in course_list:
        for k in all_categories:
            if k not in course_cats[c]:
                model.addConstr(y[c, k] == 0)
                
    # min courses per category
    for k in all_categories:
        model.addConstr(gp.quicksum(y[c, k] for c in course_list) >= min_courses)
        
    # prereqs
    for c, p in matched_prereqs:
        model.addConstr(x[c] <= x[p])
        
    # CS foundation rule
    if cs_foundation and cs_category:
        for c in course_list:
            model.addConstr(y[c, cs_category] <= x[cs_foundation])

    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    solve()
