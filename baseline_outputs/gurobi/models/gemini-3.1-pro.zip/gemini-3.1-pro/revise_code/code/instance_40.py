import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Read data
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    df = pd.read_csv(csv_path)
    params = dict(zip(df['Parameter_Name'], df['Value']))

    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # Create model
    model = gp.Model("Maximize_GDP")
    model.setParam('OutputFlag', 0)

    # Variables
    x = {}
    for c in commodities:
        ub = GRB.INFINITY
        for suffix in ['_production_limit', '_limit', '_capacity']:
            key = f"{c}{suffix}"
            if key in params:
                ub = params[key]
                break
        x[c] = model.addVar(lb=0, ub=ub, name=f"x_{c}")

    # Imports of finished goods
    I = {}
    import_quota = params.get('import_quota', 0)
    for c in commodities:
        I[c] = model.addVar(lb=0, ub=import_quota, name=f"I_{c}")

    # Exports
    E = {}
    for c in commodities:
        E[c] = model.addVar(lb=0, name=f"E_{c}")

    # Overtime labor
    overtime_cap = params.get('overtime_cap', 0)
    L_ot = model.addVar(lb=0, ub=overtime_cap, name="L_ot")

    # Domestic consumption
    D = {}
    for c in commodities:
        D[c] = gp.quicksum(
            params.get(f"{c_prime}_{c}_requirement", 0.0) * x[c_prime]
            for c_prime in commodities
        )

    # Balance constraints
    for c in commodities:
        model.addConstr(E[c] == x[c] + I[c] - D[c], name=f"Balance_{c}")

    # Labor constraint
    total_labor = gp.quicksum(params.get(f"{c}_labor_requirement", 0.0) * x[c] for c in commodities)
    model.addConstr(total_labor <= params.get('labor_force', 0) + L_ot, name="Labor_Limit")

    # Objective function components
    export_revenue = gp.quicksum(params[f"{c}_price"] * E[c] for c in commodities)
    prod_import_costs = gp.quicksum(params.get(f"{c}_import_cost", 0.0) * x[c] for c in commodities)
    finished_import_costs = gp.quicksum(params[f"{c}_price"] * params.get('import_premium_ratio', 1.0) * I[c] for c in commodities)
    overtime_cost = params.get('overtime_wage', 0) * L_ot

    gdp = export_revenue - prod_import_costs - finished_import_costs - overtime_cost
    model.setObjective(gdp, GRB.MAXIMIZE)

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        return model.ObjVal
    else:
        return None

if __name__ == '__main__':
    result = solve()
    if result is not None:
        print(f"FINAL_OBJ_VALUE: {result}")
    else:
        print("FINAL_OBJ_VALUE: None")
