import pandas as pd
import os
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Load data
    table_1_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'table_1.csv')
    params_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    
    df = pd.read_csv(table_1_path)
    params = pd.read_csv(params_path)
    
    def get_param(name):
        return float(params[params['Parameter_Name'] == name]['Value'].iloc[0])
    
    budget = get_param('budget')
    food_intake = get_param('food_intake')
    weekday_budget_share = get_param('weekday_budget_share')
    max_prep_time_weekday = get_param('max_prep_time_weekday')
    max_prep_time_weekend = get_param('max_prep_time_weekend')
    weekend_protein_ban = get_param('weekend_protein_ban')
    veg_balance_penalty = get_param('veg_balance_penalty')
    
    df['Fiber_Content_per_100g'] = df['Fiber_Content_per_100g'].fillna(0)
    
    foods = df['Food'].tolist()
    types = df.set_index('Food')['Type'].to_dict()
    fiber = df.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df.set_index('Food')['prep_time_per_100g'].to_dict()
    
    proteins = [f for f in foods if types[f] == 'protein']
    vegetables = [f for f in foods if types[f] == 'vegetable']
    
    model = gp.Model("Maximize_Fiber_Revised")
    model.setParam('OutputFlag', 0)
    
    meals = ['weekday', 'weekend']
    
    # Variables
    x = model.addVars(foods, meals, lb=0, vtype=GRB.CONTINUOUS, name="x")
    z = model.addVars(foods, meals, vtype=GRB.BINARY, name="z")
    y = model.addVars(foods, vtype=GRB.BINARY, name="y")
    D = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="D")
    
    # Objective
    total_fiber = gp.quicksum(fiber[f] * x[f, m] for f in foods for m in meals)
    penalty = veg_balance_penalty * D
    model.setObjective(total_fiber - penalty, GRB.MAXIMIZE)
    
    M_val = food_intake / 100.0
    
    # Constraints
    for m in meals:
        model.addConstr(gp.quicksum(x[f, m] for f in foods) == M_val, name=f"intake_{m}")
        
    model.addConstr(gp.quicksum(price[f] * x[f, 'weekday'] for f in foods) <= budget * weekday_budget_share, name="budget_weekday")
    model.addConstr(gp.quicksum(price[f] * x[f, 'weekend'] for f in foods) <= budget * (1 - weekday_budget_share), name="budget_weekend")
    
    model.addConstr(gp.quicksum(prep_time[f] * x[f, 'weekday'] for f in foods) <= max_prep_time_weekday, name="prep_weekday")
    model.addConstr(gp.quicksum(prep_time[f] * x[f, 'weekend'] for f in foods) <= max_prep_time_weekend, name="prep_weekend")
    
    if int(weekend_protein_ban) == 1:
        for p in proteins:
            model.addConstr(x[p, 'weekend'] == 0, name=f"ban_{p}")
            
    for f in foods:
        for m in meals:
            model.addConstr(x[f, m] >= 0.1 * z[f, m], name=f"min_inc_{f}_{m}")
            model.addConstr(x[f, m] <= M_val * z[f, m], name=f"max_inc_{f}_{m}")
            model.addConstr(z[f, m] <= y[f], name=f"link_z_y_{f}_{m}")
        
        model.addConstr(y[f] <= z[f, 'weekday'] + z[f, 'weekend'], name=f"link_y_z_{f}")
        
    model.addConstr(gp.quicksum(y[p] for p in proteins) == 1, name="protein_req")
    model.addConstr(gp.quicksum(y[v] for v in vegetables) >= 2, name="veg_req")
    
    veg_wd = gp.quicksum(x[v, 'weekday'] for v in vegetables)
    veg_we = gp.quicksum(x[v, 'weekend'] for v in vegetables)
    model.addConstr(D >= veg_wd - veg_we, name="dev_pos")
    model.addConstr(D >= veg_we - veg_wd, name="dev_neg")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        return round(model.ObjVal, 4)
    else:
        return -1

if __name__ == '__main__':
    print(f"FINAL_OBJ_VALUE: {solve()}")
