import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = list(reader)
    return headers, rows

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load general parameters
    gen_params_path = os.path.join(data_dir, 'general_parameters.csv')
    _, gen_rows = load_csv(gen_params_path)
    params = {}
    for row in gen_rows:
        name = row[0].strip()
        try:
            val = float(row[1].strip())
        except ValueError:
            val = row[1].strip()
        params[name] = val
        
    # Load crop data
    table1_path = os.path.join(data_dir, 'table_1.csv')
    t1_headers, t1_rows = load_csv(table1_path)
    crops = [h.strip() for h in t1_headers[1:]]
    crop_data = {}
    for row in t1_rows:
        item = row[0].strip()
        crop_data[item] = {crops[i]: float(row[i+1].strip()) for i in range(len(crops))}
        
    # Extract parameters
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']
    
    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = params['max_chickens']
    max_dairy_cows = params['max_dairy_cows']
    
    fixed_cost_chicken_setup = params['fixed_cost_chicken_setup']
    min_chickens_if_coop_open = params['min_chickens_if_coop_open']
    second_biosecurity_threshold = params['second_biosecurity_threshold']
    second_biosecurity_cost = params['second_biosecurity_cost']
    biosecurity_training_aw_days = params['biosecurity_training_aw_days']
    biosecurity_training_ss_days = params['biosecurity_training_ss_days']
    
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']
    
    # Create model
    m = gp.Model("Farm_Optimization")
    m.setParam('OutputFlag', 0)
    
    # Decision variables
    x = {c: m.addVar(lb=0, name=f"x_{c}") for c in crops}
    y_dairy = m.addVar(lb=0, ub=max_dairy_cows, name="dairy_cows")
    y_chicken = m.addVar(lb=0, ub=max_chickens, name="chickens")
    surplus_aw = m.addVar(lb=0, name="surplus_aw")
    surplus_ss = m.addVar(lb=0, name="surplus_ss")
    
    z_chicken = m.addVar(vtype=GRB.BINARY, name="z_chicken")
    z_second = m.addVar(vtype=GRB.BINARY, name="z_second")
    
    # Objective
    obj = gp.quicksum(crop_income[c] * x[c] for c in crops) + \
          income_dairy * y_dairy + income_chicken * y_chicken + \
          ext_rate_aw * surplus_aw + ext_rate_ss * surplus_ss - \
          fixed_cost_chicken_setup * z_chicken - second_biosecurity_cost * z_second
    m.setObjective(obj, GRB.MAXIMIZE)
    
    # Constraints
    m.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, "Land")
    m.addConstr(inv_dairy * y_dairy + inv_chicken * y_chicken + fixed_cost_chicken_setup * z_chicken + second_biosecurity_cost * z_second <= funds_available, "Funds")
    
    m.addConstr(gp.quicksum(crop_aw[c] * x[c] for c in crops) + labor_aw_dairy * y_dairy + labor_aw_chicken * y_chicken + biosecurity_training_aw_days * z_chicken + surplus_aw <= labor_aw, "Labor_AW")
    m.addConstr(gp.quicksum(crop_ss[c] * x[c] for c in crops) + labor_ss_dairy * y_dairy + labor_ss_chicken * y_chicken + biosecurity_training_ss_days * z_chicken + surplus_ss <= labor_ss, "Labor_SS")
    
    m.addConstr(y_chicken >= min_chickens_if_coop_open * z_chicken, "Min_Chickens")
    m.addConstr(y_chicken <= max_chickens * z_chicken, "Max_Chickens_Open")
    
    m.addConstr(y_chicken - second_biosecurity_threshold <= (max_chickens - second_biosecurity_threshold) * z_second, "Second_Threshold")
    
    # Solve
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
