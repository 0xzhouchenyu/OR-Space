import pandas as pd
import gurobipy as gp
from gurobipy import GRB
import os

def solve():
    # Paths to data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    demand_path = os.path.join(base_dir, 'data', 'table_4_3.csv')
    supply_path = os.path.join(base_dir, 'data', 'table_4_4.csv')
    params_path = os.path.join(base_dir, 'data', 'general_parameters.csv')
    
    # Load data
    demand_df = pd.read_csv(demand_path)
    supply_df = pd.read_csv(supply_path)
    params_df = pd.read_csv(params_path)
    
    # Parse parameters
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])
    
    # Parse demand
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem
        
    # Parse supply
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        num = float(row['Number_of_People'])
        suit = [int(x) for x in str(row['Suitable_Specialty']).split(',')]
        pref_spec = int(row['Preferred_Specialty'])
        pref_city = row['Preferred_City']
        supply[t] = {
            'num': num,
            'suit': suit,
            'pref_spec': pref_spec,
            'pref_city': pref_city
        }
        
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = [1, 2, 3, 4, 5, 6]
    
    # Initialize model
    model = gp.Model("Revised_Personnel_Arrangement")
    model.setParam('OutputFlag', 0)
    
    # Variables
    x = model.addVars(types, cities, specs, vtype=GRB.INTEGER, name="x")
    
    # Priority 1: Meet demand
    for j in cities:
        for k in specs:
            model.addConstr(gp.quicksum(x[i, j, k] for i in types) >= demand[(j, k)])
            
    # Capacity constraints and suitable specialty constraints
    for i in types:
        model.addConstr(gp.quicksum(x[i, j, k] for j in cities for k in specs) <= supply[i]['num'])
        for j in cities:
            for k in specs:
                if k not in supply[i]['suit']:
                    model.addConstr(x[i, j, k] == 0)
                    
    # Priority 2: Meet preferred specialty target
    p2_expr = gp.quicksum(x[i, j, supply[i]['pref_spec']] for i in types for j in cities)
    model.addConstr(p2_expr >= p2_target)
    
    # New Objective: Maximize dual-match placement
    dual_match_expr = gp.quicksum(x[i, supply[i]['pref_city'], supply[i]['pref_spec']] for i in types)
    
    model.setObjective(dual_match_expr, GRB.MAXIMIZE)
    
    # Solve
    model.optimize()
    
    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    solve()
