import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    W = params.get('initial_investment', 100000)
    r1 = params.get('return_rate_option_1', 0.7)
    r2 = params.get('return_rate_option_2', 2.0)
    min_reserve_year1 = params.get('min_reserve_year1', 10000)
    min_reserve_year2 = params.get('min_reserve_year2', 15000)
    max_option2_start = params.get('max_option2_start', 30000)
    option2_year0_late_settlement_rate = params.get('option2_year0_late_settlement_rate', 0.02)
    
    model = gp.Model("Investment")
    model.setParam('OutputFlag', 0)
    
    x0_1 = model.addVar(lb=0, name="x0_1")
    x0_2 = model.addVar(lb=0, ub=max_option2_start, name="x0_2")
    c0 = model.addVar(lb=0, name="c0")
    
    x1_1 = model.addVar(lb=0, name="x1_1")
    x1_2 = model.addVar(lb=0, ub=max_option2_start, name="x1_2")
    c1 = model.addVar(lb=min_reserve_year1, name="c1")
    
    x2_1 = model.addVar(lb=0, name="x2_1")
    c2 = model.addVar(lb=min_reserve_year2, name="c2")
    
    model.addConstr(x0_1 + x0_2 + c0 == W, "year0_budget")
    model.addConstr(x1_1 + x1_2 + c1 == x0_1 * (1 + r1) + c0, "year1_budget")
    model.addConstr(x2_1 + c2 == x1_1 * (1 + r1) + c1, "year2_budget")
    
    final_wealth = (
        x2_1 * (1 + r1) + 
        c2 + 
        x1_2 * (1 + r2) + 
        x0_2 * (1 + r2) * (1 - option2_year0_late_settlement_rate)
    )
    
    model.setObjective(final_wealth, GRB.MAXIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
