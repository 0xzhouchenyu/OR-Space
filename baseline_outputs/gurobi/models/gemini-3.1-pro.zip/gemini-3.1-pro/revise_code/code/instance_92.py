import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    num_students = int(params['num_students'])
    num_buses = int(params['num_buses'])
    bus_capacity = int(params['bus_capacity'])
    num_minibuses = int(params['num_minibuses'])
    minibus_capacity = int(params['minibus_capacity'])
    num_drivers = int(params['num_drivers'])
    bus_rental_cost = float(params['bus_rental_cost'])
    minibus_rental_cost = float(params['minibus_rental_cost'])

    model = gp.Model("SchoolTrip")
    model.setParam('OutputFlag', 0)

    x = model.addVar(lb=0, ub=num_buses, vtype=GRB.INTEGER, name="buses")
    y = model.addVar(lb=1, ub=num_minibuses, vtype=GRB.INTEGER, name="minibuses")

    model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

    model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, "StudentCapacity")
    model.addConstr(x + y <= num_drivers, "DriverLimit")
    model.addConstr(x >= 2 * y, "EscortPolicy")

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
