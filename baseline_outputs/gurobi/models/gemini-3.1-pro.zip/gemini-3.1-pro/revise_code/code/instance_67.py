import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return [row for row in reader]

def main():
    # Load demand data
    demand_rows = load_csv('table_1.csv')
    demand = {}
    for row in demand_rows:
        month = row['Month']
        product = row['Product']
        units = int(row['Market_Demand_Units'])
        demand[(month, product)] = units

    # Load parameters
    param_rows = load_csv('general_parameters.csv')
    params = {}
    for row in param_rows:
        name = row['Parameter_Name']
        value = float(row['Value'])
        params[name] = value

    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']

    prod_cost = {
        'Product_I': params['product_I_cost_jun_to_dec'],
        'Product_II': params['product_II_cost_jun_to_dec']
    }
    volume = {
        'Product_I': params['product_I_volume'],
        'Product_II': params['product_II_volume']
    }
    machine_hours = {
        'Product_I': params['product_I_machine_hours'],
        'Product_II': params['product_II_machine_hours']
    }
    power_kwh = {
        'Product_I': params['product_I_power_kwh'],
        'Product_II': params['product_II_power_kwh']
    }

    warehouse_cap = params['warehouse_capacity']
    own_wh_cost = params['own_warehouse_cost']
    mh_cap = params['machine_hours_capacity_monthly']
    grid_cost = params['grid_electricity_cost']
    gen_cost = params['generator_electricity_cost']
    init_inv = params['initial_inventory_july']

    grid_quota = {
        'July': params['grid_quota_july'],
        'August': params['grid_quota_august'],
        'September': params['grid_quota_september'],
        'October': params['grid_quota_october'],
        'November': params['grid_quota_november'],
        'December': params['grid_quota_december']
    }

    gen_max = {
        'July': params['generator_max_july'],
        'August': params['generator_max_august'],
        'September': params['generator_max_september'],
        'October': params['generator_max_october'],
        'November': params['generator_max_november'],
        'December': params['generator_max_december']
    }

    model = gp.Model("Revised_Production_Planning")
    model.setParam('OutputFlag', 0)

    # Variables
    x = model.addVars(months, products, lb=0, name="x")
    inv = model.addVars(months, products, lb=0, name="inv")
    grid = model.addVars(months, lb=0, name="grid")
    gen = model.addVars(months, lb=0, name="gen")
    own_wh = model.addVars(months, lb=0, name="own_wh")

    # Objective
    obj = gp.quicksum(prod_cost[p] * x[m, p] for m in months for p in products) \
          + gp.quicksum(own_wh_cost * own_wh[m] for m in months) \
          + gp.quicksum(grid_cost * grid[m] + gen_cost * gen[m] for m in months)
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    for i, m in enumerate(months):
        for p in products:
            if i == 0:
                model.addConstr(inv[m, p] == init_inv + x[m, p] - demand[m, p])
            else:
                prev_m = months[i-1]
                model.addConstr(inv[m, p] == inv[prev_m, p] + x[m, p] - demand[m, p])

        # Warehouse
        total_vol = gp.quicksum(volume[p] * inv[m, p] for p in products)
        model.addConstr(own_wh[m] >= total_vol)
        model.addConstr(own_wh[m] <= warehouse_cap)

        # Machine hours
        model.addConstr(gp.quicksum(machine_hours[p] * x[m, p] for p in products) <= mh_cap)

        # Electricity
        total_elec = gp.quicksum(power_kwh[p] * x[m, p] for p in products)
        model.addConstr(grid[m] + gen[m] == total_elec)
        model.addConstr(grid[m] <= grid_quota[m])
        model.addConstr(gen[m] <= gen_max[m])

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
