import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')

    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    params = {}
    for _, row in df_params.iterrows():
        params[row['Parameter_Name']] = row['Value']

    L1 = float(params['raw_pipe_length_supplier1'])
    L2 = float(params['raw_pipe_length_supplier2'])
    max_pat1 = int(params['max_cutting_patterns_supplier1'])
    max_pat2 = int(params['max_cutting_patterns_supplier2'])
    
    cost_rates1 = []
    for prefix in ['most', 'second', 'third']:
        key = f"{prefix}_frequent_pattern_cost_rate_supplier1"
        if key in params:
            cost_rates1.append(float(params[key]))
            
    cost_rates2 = []
    for prefix in ['most', 'second', 'third']:
        key = f"{prefix}_frequent_pattern_cost_rate_supplier2"
        if key in params:
            cost_rates2.append(float(params[key]))

    max_cuts1 = int(params['max_cuts_per_pipe_supplier1'])
    max_cuts2 = int(params['max_cuts_per_pipe_supplier2'])
    max_leftover1 = float(params['max_leftover_length_supplier1'])
    max_leftover2 = float(params['max_leftover_length_supplier2'])
    min_len1 = L1 - max_leftover1
    min_len2 = L2 - max_leftover2

    cost1 = float(params['purchase_cost_per_pipe_supplier1'])
    cost2 = float(params['purchase_cost_per_pipe_supplier2'])
    disc_tier1_max = float(params['discount_tier1_supplier1_max_qty'])
    fixed_disc = float(params['fixed_discount_tier2_supplier1'])
    bigM_disc = float(params['bigM_discount'])

    lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(lengths)

    def generate_patterns(L, max_cuts, min_len):
        patterns = []
        def dfs(current_pattern, current_length, current_cuts, item_idx):
            if item_idx == n_items:
                if current_length >= min_len and current_length <= L and current_cuts > 0:
                    patterns.append(tuple(current_pattern))
                return
            max_qty = min(
                int((L - current_length) // lengths[item_idx]),
                max_cuts - current_cuts
            )
            for q in range(max_qty + 1):
                dfs(
                    current_pattern + [q],
                    current_length + q * lengths[item_idx],
                    current_cuts + q,
                    item_idx + 1
                )
        dfs([], 0, 0, 0)
        return patterns

    patterns1 = generate_patterns(L1, max_cuts1, min_len1)
    patterns2 = generate_patterns(L2, max_cuts2, min_len2)

    model = gp.Model()
    model.setParam('OutputFlag', 0)

    y1 = model.addVars(len(patterns1), vtype=GRB.INTEGER, name="y1")
    z1 = model.addVars(len(patterns1), vtype=GRB.BINARY, name="z1")
    u1 = model.addVars(max_pat1, vtype=GRB.BINARY, name="u1")

    y2 = model.addVars(len(patterns2), vtype=GRB.INTEGER, name="y2")
    z2 = model.addVars(len(patterns2), vtype=GRB.BINARY, name="z2")
    u2 = model.addVars(max_pat2, vtype=GRB.BINARY, name="u2")

    b_disc = model.addVar(vtype=GRB.BINARY, name="b_disc")

    M = sum(demands)

    for p in range(len(patterns1)):
        model.addConstr(y1[p] <= M * z1[p])
    for p in range(len(patterns2)):
        model.addConstr(y2[p] <= M * z2[p])

    for i in range(n_items):
        model.addConstr(
            gp.quicksum(patterns1[p][i] * y1[p] for p in range(len(patterns1))) +
            gp.quicksum(patterns2[p][i] * y2[p] for p in range(len(patterns2))) >= demands[i]
        )

    model.addConstr(gp.quicksum(z1[p] for p in range(len(patterns1))) == gp.quicksum(u1[k] for k in range(max_pat1)))
    model.addConstr(gp.quicksum(z2[p] for p in range(len(patterns2))) == gp.quicksum(u2[k] for k in range(max_pat2)))

    for k in range(max_pat1 - 1):
        model.addConstr(u1[k] >= u1[k+1])
    for k in range(max_pat2 - 1):
        model.addConstr(u2[k] >= u2[k+1])

    total_y1 = gp.quicksum(y1[p] for p in range(len(patterns1)))
    model.addConstr(total_y1 - disc_tier1_max <= bigM_disc * b_disc)
    model.addConstr(total_y1 - disc_tier1_max >= 0.0001 - bigM_disc * (1 - b_disc))

    extra_cost1 = gp.quicksum(cost_rates1[k] * u1[k] for k in range(min(max_pat1, len(cost_rates1))))
    extra_cost2 = gp.quicksum(cost_rates2[k] * u2[k] for k in range(min(max_pat2, len(cost_rates2))))

    total_cost = (
        cost1 * total_y1 +
        cost2 * gp.quicksum(y2[p] for p in range(len(patterns2))) +
        extra_cost1 +
        extra_cost2 -
        fixed_disc * b_disc
    )

    model.setObjective(total_cost, GRB.MINIMIZE)
    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
