import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    params = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    
    param_dict = dict(zip(params['Parameter_Name'], params['Value']))
    demand = dict(zip(table_1['stage'], table_1['tool_requirement']))
    
    n = int(param_dict['n'])
    cost_new = float(param_dict['cost_new_tool'])
    cost_slow = float(param_dict['cost_slow_repair'])
    cost_fast = float(param_dict['cost_fast_repair'])
    dur_slow = int(param_dict['slow_repair_duration'])
    dur_fast = int(param_dict['fast_repair_duration'])
    max_fast = float(param_dict['max_fast_stage'])
    max_slow = float(param_dict['max_slow_stage'])
    em_buy = float(param_dict['emission_buy'])
    em_fast = float(param_dict['emission_fast_repair'])
    em_slow = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_shortage = float(param_dict['penalty_shortage'])
    
    model = gp.Model("Tool_Repair_Problem")
    model.setParam('OutputFlag', 0)
    
    stages = list(range(1, n + 1))
    
    buy = model.addVars(stages, vtype=GRB.INTEGER, name="buy", lb=0)
    prebuy_clean = model.addVar(vtype=GRB.INTEGER, name="prebuy_clean", lb=0)
    fast = model.addVars(stages, vtype=GRB.INTEGER, name="fast", lb=0, ub=max_fast)
    slow = model.addVars(stages, vtype=GRB.INTEGER, name="slow", lb=0, ub=max_slow)
    clean = model.addVars([0] + stages, vtype=GRB.INTEGER, name="clean", lb=0)
    dirty = model.addVars([0] + stages, vtype=GRB.INTEGER, name="dirty", lb=0)
    short = model.addVars(stages, vtype=GRB.INTEGER, name="short", lb=0)
    
    model.addConstr(clean[0] == prebuy_clean)
    model.addConstr(dirty[0] == 0)
    
    for i in stages:
        model.addConstr(short[i] <= demand[i])
        
        fast_ready = fast[i - dur_fast - 1] if i - dur_fast - 1 >= 1 else 0
        slow_ready = slow[i - dur_slow - 1] if i - dur_slow - 1 >= 1 else 0
        
        actual_demand = demand[i] - short[i]
        
        model.addConstr(buy[i] + clean[i-1] + fast_ready + slow_ready == actual_demand + clean[i])
        model.addConstr(actual_demand + dirty[i-1] == fast[i] + slow[i] + dirty[i])
        
    model.addConstr(
        em_buy * (prebuy_clean + gp.quicksum(buy[i] for i in stages)) +
        em_fast * gp.quicksum(fast[i] for i in stages) +
        em_slow * gp.quicksum(slow[i] for i in stages) <= carbon_budget
    )
    
    obj = (
        cost_new * (prebuy_clean + gp.quicksum(buy[i] for i in stages)) +
        cost_fast * gp.quicksum(fast[i] for i in stages) +
        cost_slow * gp.quicksum(slow[i] for i in stages) +
        penalty_shortage * gp.quicksum(short[i] for i in stages)
    )
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
