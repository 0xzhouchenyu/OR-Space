import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    t1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    t2 = pd.read_csv(os.path.join(data_dir, 'table_2.csv'))
    t3 = pd.read_csv(os.path.join(data_dir, 'table_3.csv'))
    gp_df = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    
    df = t1.merge(t2, on='Product').merge(t3, on='Product')
    
    gp_dict = dict(zip(gp_df['Parameter_Name'], gp_df['Value']))
    prod_days = float(gp_dict['production_days'])
    a1_watch_threshold = float(gp_dict['a1_watch_threshold'])
    a1_deep_service_threshold = float(gp_dict['a1_deep_service_threshold'])
    maintenance_penalty_watch = float(gp_dict['maintenance_penalty_watch'])
    maintenance_penalty_deep = float(gp_dict.get('maintenance_penalty_deep', 1.0))
    a1_quality_release_fee = float(gp_dict['a1_quality_release_fee'])
    a1_deep_service_fee = float(gp_dict['a1_deep_service_fee'])
    a1_priority_price_lift = float(gp_dict['a1_priority_price_lift'])
    
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    products = df['Product'].tolist()
    
    x = model.addVars(products, lb=0, name="x")
    y = model.addVars(products, vtype=GRB.BINARY, name="y")
    
    z_watch = model.addVar(vtype=GRB.BINARY, name="z_watch")
    z_deep = model.addVar(vtype=GRB.BINARY, name="z_deep")
    x_watch = model.addVar(lb=0, name="x_watch")
    
    M = 10000
    
    # Must produce all three products
    for p in products:
        model.addConstr(y[p] == 1)
        
    for _, row in df.iterrows():
        p = row['Product']
        model.addConstr(x[p] <= row['Maximum_Demand'] * y[p])
        model.addConstr(x[p] >= row['Minimum_Batch'] * y[p])
        
    # Threshold constraints
    model.addConstr(x['A1'] - a1_watch_threshold <= M * z_watch)
    model.addConstr(x['A1'] - a1_deep_service_threshold <= M * z_deep)
    
    # x_watch constraints
    model.addConstr(x_watch <= x['A1'] - a1_watch_threshold + M * (1 - z_watch))
    model.addConstr(x_watch <= M * z_watch)
    
    # Production days constraint
    days_used = gp.quicksum(x[row['Product']] / row['Production_Quota'] for _, row in df.iterrows())
    days_avail = prod_days - maintenance_penalty_watch * z_watch - maintenance_penalty_deep * z_deep
    model.addConstr(days_used <= days_avail)
    
    # Objective
    profit = gp.quicksum(
        (row['Selling_Price'] - row['Production_Cost']) * x[row['Product']] - row['Activation_Cost'] * y[row['Product']] 
        for _, row in df.iterrows()
    )
    profit += a1_priority_price_lift * x_watch
    profit -= a1_quality_release_fee * z_watch
    profit -= a1_deep_service_fee * z_deep
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    model.optimize()
    
    return model.ObjVal

if __name__ == "__main__":
    obj = solve()
    print(f"FINAL_OBJ_VALUE: {obj}")
