import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    quarters = []
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q = row['Quarter'].strip()
            quarters.append(q)
            purchase_price[q] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[q] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[q] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[q] = float(row['max_purchase_10k_m3'].strip())
            
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
            
    max_storage_wm3 = float(params['max_storage_capacity']) / 10000.0
    storage_cost_a_w = float(params['storage_cost_a']) * 10000.0 / 10000.0
    storage_cost_b_w = float(params['storage_cost_b']) * 10000.0 / 10000.0
    safety_inventory = float(params['safety_inventory_level_10k_m3'])
    terminal_value = float(params['terminal_inventory_value_per_10k_m3'])
    penalty_cost = float(params['over_purchase_penalty_cost_per_10k_m3'])
    
    n = len(quarters)
    
    model = gp.Model("Timber_Optimization")
    model.setParam('OutputFlag', 0)
    
    x = {}
    for i in range(n):
        for j in range(i, n):
            x[i, j] = model.addVar(lb=0, name=f"x_{i}_{j}")
            
    y = {}
    for i in range(n):
        y[i] = model.addVar(lb=0, name=f"y_{i}")
        
    excess_inv = model.addVar(lb=0, name="excess_inv")
    
    # Objective
    profit_terms = []
    for i in range(n):
        for j in range(i, n):
            u = j - i
            revenue = sale_price[quarters[j]]
            cost = purchase_price[quarters[i]]
            s_cost = storage_cost_a_w + storage_cost_b_w * u if u > 0 else 0
            profit_terms.append((revenue - cost - s_cost) * x[i, j])
            
        # For reserve inventory y[i]
        u_y = 4 - i
        cost_y = purchase_price[quarters[i]]
        s_cost_y = storage_cost_a_w + storage_cost_b_w * u_y
        profit_terms.append((terminal_value - cost_y - s_cost_y) * y[i])
        
    profit_terms.append(-penalty_cost * excess_inv)
    
    model.setObjective(gp.quicksum(profit_terms), GRB.MAXIMIZE)
    
    # Constraints
    # Sales limit
    for j in range(n):
        model.addConstr(gp.quicksum(x[i, j] for i in range(j + 1)) <= max_sales[quarters[j]])
        
    # Purchase limit
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, j] for j in range(i, n)) + y[i] <= max_purchase[quarters[i]])
        
    # Storage limit
    for t in range(n - 1):
        stored = gp.quicksum(x[i, j] for i in range(t + 1) for j in range(t + 1, n)) + \
                 gp.quicksum(y[i] for i in range(t + 1))
        model.addConstr(stored <= max_storage_wm3)
        
    # Excess inventory
    total_y = gp.quicksum(y[i] for i in range(n))
    model.addConstr(excess_inv >= total_y - safety_inventory)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
