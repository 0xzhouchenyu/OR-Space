import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_goods_data(filepath):
    goods = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            goods[row['Goods_Type'].strip()] = {
                'quantity': int(row['Quantity'].strip()),
                'weight': float(row['Weight_per_Unit'].strip())
            }
    return goods

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    goods = load_goods_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    max_cap = params['max_container_capacity']
    min_load = params['min_container_load']
    min_d_per_container = int(params['min_d_goods_per_container'])
    min_c_per_a = int(params['min_c_per_a'])
    
    reduced_cap_E = 45.0

    goods_types = list(goods.keys())
    quantities = {g: goods[g]['quantity'] for g in goods_types}
    weights = {g: goods[g]['weight'] for g in goods_types}

    max_containers = quantities['D'] // min_d_per_container
    N = range(max_containers)

    model = gp.Model("ContainerMinimization")
    model.setParam('OutputFlag', 0)

    x = {}
    for g in goods_types:
        x[g] = {}
        for j in N:
            x[g][j] = model.addVar(lb=0, ub=quantities[g], vtype=GRB.INTEGER, name=f"x_{g}_{j}")

    y = {}
    z_A = {}
    z_E = {}
    for j in N:
        y[j] = model.addVar(vtype=GRB.BINARY, name=f"y_{j}")
        z_A[j] = model.addVar(vtype=GRB.BINARY, name=f"z_A_{j}")
        z_E[j] = model.addVar(vtype=GRB.BINARY, name=f"z_E_{j}")

    model.setObjective(gp.quicksum(y[j] for j in N), GRB.MINIMIZE)

    for g in goods_types:
        model.addConstr(gp.quicksum(x[g][j] for j in N) == quantities[g], name=f"demand_{g}")

    for j in N:
        total_weight = gp.quicksum(weights[g] * x[g][j] for g in goods_types)
        
        # Min load
        model.addConstr(total_weight >= min_load * y[j], name=f"min_load_{j}")
        
        # Max cap considering E
        model.addConstr(total_weight <= max_cap * y[j] - (max_cap - reduced_cap_E) * z_E[j], name=f"max_cap_{j}")
        
        # E indicator
        model.addConstr(x['E'][j] <= quantities['E'] * z_E[j], name=f"E_indicator_{j}")
        model.addConstr(z_E[j] <= y[j], name=f"z_E_y_{j}")

        # Min D goods
        model.addConstr(x['D'][j] >= min_d_per_container * y[j], name=f"min_D_{j}")
        model.addConstr(x['D'][j] <= quantities['D'] * y[j], name=f"max_D_{j}")

        # A indicator and C requirement
        model.addConstr(x['A'][j] <= quantities['A'] * z_A[j], name=f"A_indicator_{j}")
        model.addConstr(x['C'][j] >= min_c_per_a * z_A[j], name=f"C_if_A_{j}")
        model.addConstr(z_A[j] <= y[j], name=f"z_A_y_{j}")

    # Symmetry breaking
    for j in range(len(N) - 1):
        model.addConstr(y[j] >= y[j+1], name=f"symmetry_{j}")

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()
