import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_csv(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, 'data', filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    return rows

# Load parameters
params_rows = load_csv('general_parameters.csv')
params = {}
for row in params_rows:
    name = row['Parameter_Name'].strip()
    val = row['Value'].strip()
    try:
        if '.' in val:
            params[name] = float(val)
        else:
            params[name] = int(val)
    except ValueError:
        params[name] = val

# Load demand
demand_rows = load_csv('table_1.csv')
demand = {}
for row in demand_rows:
    week = int(row['Week'].strip())
    demand[week] = {
        'I': int(row['I'].strip()),
        'II': int(row['II'].strip())
    }

T = 8
S0 = params['skilled_worker_count']
rate_I = params['food_I_production_rate']
rate_II = params['food_II_production_rate']
normal_hours = params['worker_weekly_hours']
overtime_hours = params['skilled_worker_overtime_hours']
train_cap = params['training_capacity']
train_period = params['training_period']
wage_skilled = params['skilled_worker_weekly_wage']
wage_trainee_during = params['trainee_weekly_wage_during_training']
wage_trainee_after = params['trainee_weekly_wage_after_training']
wage_overtime = params['skilled_worker_overtime_wage']
comp_I = params['compensation_fee_food_I']
comp_II = params['compensation_fee_food_II']
new_worker_goal = params['new_worker_training_goal']

model = gp.Model("factory_training_revised")
model.setParam('OutputFlag', 0)

# Decision Variables
n_train = model.addVars(range(1, T+1), vtype=GRB.INTEGER, name="n_train")
n_ot = model.addVars(range(1, T+1), vtype=GRB.INTEGER, name="n_ot")

y_I = model.addVars(range(1, T+1), vtype=GRB.BINARY, name="y_I")
y_II = model.addVars(range(1, T+1), vtype=GRB.BINARY, name="y_II")

h_I_s = model.addVars(range(1, T+1), vtype=GRB.CONTINUOUS, name="h_I_s")
h_II_s = model.addVars(range(1, T+1), vtype=GRB.CONTINUOUS, name="h_II_s")
h_I_ot = model.addVars(range(1, T+1), vtype=GRB.CONTINUOUS, name="h_I_ot")
h_II_ot = model.addVars(range(1, T+1), vtype=GRB.CONTINUOUS, name="h_II_ot")
h_I_g = model.addVars(range(1, T+1), vtype=GRB.CONTINUOUS, name="h_I_g")
h_II_g = model.addVars(range(1, T+1), vtype=GRB.CONTINUOUS, name="h_II_g")

inv_I = model.addVars(range(1, T+1), vtype=GRB.CONTINUOUS, name="inv_I")
inv_II = model.addVars(range(1, T+1), vtype=GRB.CONTINUOUS, name="inv_II")
backlog_I = model.addVars(range(1, T+1), vtype=GRB.CONTINUOUS, name="backlog_I")
backlog_II = model.addVars(range(1, T+1), vtype=GRB.CONTINUOUS, name="backlog_II")

# Constraints
model.addConstr(n_train[8] == 0, name="no_train_start_week_8")

for t in range(1, T+1):
    # Workforce availability
    busy_t = n_train[t] + (n_train[t-1] if t > 1 else 0)
    avail_t = S0 - busy_t
    
    model.addConstr(avail_t >= 0, name=f"avail_skilled_{t}")
    model.addConstr(n_ot[t] <= avail_t, name=f"ot_limit_{t}")
    
    grads_t = gp.quicksum(train_cap * n_train[s] for s in range(1, t-1))
    
    # Hours limits
    model.addConstr(h_I_s[t] + h_II_s[t] <= (avail_t - n_ot[t]) * normal_hours, name=f"normal_hours_{t}")
    model.addConstr(h_I_ot[t] + h_II_ot[t] <= n_ot[t] * overtime_hours, name=f"overtime_hours_{t}")
    model.addConstr(h_I_g[t] + h_II_g[t] <= grads_t * normal_hours, name=f"grad_hours_{t}")
    
    # Mutual exclusion
    model.addConstr(y_I[t] + y_II[t] <= 1, name=f"mutual_exclusion_{t}")
    
    M = 10000
    model.addConstr(h_I_s[t] + h_I_ot[t] + h_I_g[t] <= M * y_I[t], name=f"force_yI_{t}")
    model.addConstr(h_II_s[t] + h_II_ot[t] + h_II_g[t] <= M * y_II[t], name=f"force_yII_{t}")
    
    # Production
    prod_I_t = (h_I_s[t] + h_I_ot[t] + h_I_g[t]) * rate_I
    prod_II_t = (h_II_s[t] + h_II_ot[t] + h_II_g[t]) * rate_II
    
    # Inventory and Backlog balance
    prev_invI = inv_I[t-1] if t > 1 else 0
    prev_invII = inv_II[t-1] if t > 1 else 0
    prev_bI = backlog_I[t-1] if t > 1 else 0
    prev_bII = backlog_II[t-1] if t > 1 else 0
    
    model.addConstr(inv_I[t] - backlog_I[t] == prev_invI - prev_bI + prod_I_t - demand[t]['I'], name=f"bal_I_{t}")
    model.addConstr(inv_II[t] - backlog_II[t] == prev_invII - prev_bII + prod_II_t - demand[t]['II'], name=f"bal_II_{t}")

# Training goal
model.addConstr(gp.quicksum(train_cap * n_train[t] for t in range(1, T)) >= new_worker_goal, name="training_goal")

# Objective
total_cost = 0
for t in range(1, T+1):
    busy_t = n_train[t] + (n_train[t-1] if t > 1 else 0)
    grads_t = gp.quicksum(train_cap * n_train[s] for s in range(1, t-1))
    
    cost_skilled = S0 * wage_skilled + n_ot[t] * (wage_overtime - wage_skilled)
    cost_trainee_during = busy_t * train_cap * wage_trainee_during
    cost_trainee_after = grads_t * wage_trainee_after
    cost_comp = comp_I * backlog_I[t] + comp_II * backlog_II[t]
    
    total_cost += cost_skilled + cost_trainee_during + cost_trainee_after + cost_comp

model.setObjective(total_cost, GRB.MINIMIZE)
model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
