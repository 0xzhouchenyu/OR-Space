import pandas as pd
import gurobipy as gp
from gurobipy import GRB
import os

def solve():
    # Load data
    base_dir = os.path.dirname(os.path.abspath(__file__))
    table_path = os.path.join(base_dir, 'data', 'table_3_3.csv')
    params_path = os.path.join(base_dir, 'data', 'general_parameters.csv')
    
    df = pd.read_csv(table_path)
    params_df = pd.read_csv(params_path)
    
    # Extract parameters
    sales_goal = float(params_df.loc[params_df['Parameter_Name'] == 'monthly_sales_goal', 'Value'].values[0])
    try:
        pt_ft_ratio = float(params_df.loc[params_df['Parameter_Name'] == 'pt_ft_overtime_ratio', 'Value'].values[0])
    except IndexError:
        pt_ft_ratio = 0.5
        
    # Extract clerk data
    ft_row = df[df['Role'] == 'Full-time'].iloc[0]
    pt_row = df[df['Role'] == 'Part-time'].iloc[0]
    
    num_ft = 5
    num_pt = 4
    for col in df.columns:
        if any(kw in col.lower() for kw in ['num', 'clerks', 'employees', 'count', '人员', '数量']):
            num_ft = float(ft_row[col])
            num_pt = float(pt_row[col])
            break
            
    # Calculate normal sales from full employment of all sales clerks
    normal_sales_ft = num_ft * ft_row['Monthly_Working_Hours'] * ft_row['Sales_Volume_Pairs_Per_Hour']
    normal_sales_pt = num_pt * pt_row['Monthly_Working_Hours'] * pt_row['Sales_Volume_Pairs_Per_Hour']
    total_normal_sales = normal_sales_ft + normal_sales_pt
    
    # Setup LP
    model = gp.Model("Minimize_Overtime")
    model.setParam('OutputFlag', 0)
    
    # Variables for overtime hours
    y_ft = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name='y_ft')
    y_pt = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name='y_pt')
    
    # Objective: Minimize total overtime hours
    model.setObjective(y_ft + y_pt, GRB.MINIMIZE)
    
    # Constraint: Achieve monthly sales goal
    model.addConstr(y_ft * ft_row['Sales_Volume_Pairs_Per_Hour'] + y_pt * pt_row['Sales_Volume_Pairs_Per_Hour'] >= sales_goal - total_normal_sales, "Sales_Goal")
    
    # Constraint: Part-time overtime ratio
    model.addConstr(y_pt >= pt_ft_ratio * y_ft, "PT_FT_Ratio")
    
    # Solve
    model.optimize()
    
    # Output
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {round(model.ObjVal, 4)}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    solve()
