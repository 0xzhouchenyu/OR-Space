import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def solve():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            params[row[0]] = float(row[1])
            
    T = int(params['planning_horizon_T'])
    energy_cost = [params['energy_cost_v1'], params['energy_cost_v2'], params['energy_cost_v3']]
    peak_mult = params['peak_energy_multiplier']
    peak_cap = params['peak_energy_cap']
    w_makespan = params['makespan_weight']
    w_energy = params['energy_weight']
    
    batches = []
    p_times = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            batches.append(int(row[0]))
            p_times.append([math.ceil(float(row[1])), math.ceil(float(row[2])), math.ceil(float(row[3]))])
            
    B = len(batches)
    V = 3
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    x = {}
    for b in range(B):
        for v in range(V):
            for t in range(1, T + 1):
                if t + p_times[b][v] - 1 <= T:
                    x[b, v, t] = model.addVar(vtype=GRB.BINARY, name=f"x_{b}_{v}_{t}")
                else:
                    x[b, v, t] = 0

    for b in range(B):
        for v in range(V):
            model.addConstr(gp.quicksum(x[b, v, t] for t in range(1, T + 1) if type(x[b, v, t]) != int) == 1)
            
    for v in range(V):
        for t in range(1, T + 1):
            active = gp.quicksum(x[b, v, t_start] 
                                 for b in range(B) 
                                 for t_start in range(max(1, t - p_times[b][v] + 1), t + 1)
                                 if type(x[b, v, t_start]) != int)
            model.addConstr(active <= 1)
            
            if v == 1 and t in [4, 5]:
                model.addConstr(active == 0)

    for b in range(B):
        for v in range(V - 1):
            for t in range(1, T + 1):
                if type(x[b, v, t]) != int:
                    end_time = t + p_times[b][v] - 1
                    model.addConstr(
                        gp.quicksum(t_next * x[b, v+1, t_next] for t_next in range(1, T + 1) if type(x[b, v+1, t_next]) != int) 
                        >= end_time - (1 - x[b, v, t]) * 1000
                    )

    makespan = model.addVar(vtype=GRB.CONTINUOUS, name="makespan")
    for b in range(B):
        for t in range(1, T + 1):
            if type(x[b, 2, t]) != int:
                model.addConstr(makespan >= (t + p_times[b][2] - 1) * x[b, 2, t])
                
    energy_cost_total = model.addVar(vtype=GRB.CONTINUOUS, name="energy_cost")
    total_cost_expr = 0
    peak_usage_expr = 0
    
    for v in range(V):
        for t in range(1, T + 1):
            active = gp.quicksum(x[b, v, t_start] 
                                 for b in range(B) 
                                 for t_start in range(max(1, t - p_times[b][v] + 1), t + 1)
                                 if type(x[b, v, t_start]) != int)
            if t in [6, 7, 8]:
                cost = energy_cost[v] * peak_mult
                peak_usage_expr += cost * active
            else:
                cost = energy_cost[v]
            total_cost_expr += cost * active
            
    model.addConstr(energy_cost_total == total_cost_expr)
    model.addConstr(peak_usage_expr <= peak_cap)
    
    model.setObjective(w_makespan * makespan + w_energy * energy_cost_total, GRB.MINIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == '__main__':
    solve()
