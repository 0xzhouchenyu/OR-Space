import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            
            if ':' in value_str:
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    machine_working_time_minutes = params['machine_working_time'] * 60
    
    ratio_A = params['production_ratio_A_to_B'][0]
    ratio_B = params['production_ratio_A_to_B'][1]
    
    max_overtime_hours = params['max_overtime_hours']
    overtime_penalty_per_hour = params['overtime_penalty_per_hour']
    overtime_review_threshold_hours = params['overtime_review_threshold_hours']
    overtime_review_fee = params['overtime_review_fee']
    
    product_A_senior_batch_threshold = params['product_A_senior_batch_threshold']
    product_A_senior_batch_fee = params['product_A_senior_batch_fee']
    
    model = gp.Model("Product_Mix_Revised")
    model.setParam('OutputFlag', 0)
    
    A = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_A")
    B = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Product_B")
    overtime_hours = model.addVar(lb=0, ub=max_overtime_hours, vtype=GRB.CONTINUOUS, name="overtime_hours")
    
    z_ot_review = model.addVar(vtype=GRB.BINARY, name="z_ot_review")
    z_A_batch = model.addVar(vtype=GRB.BINARY, name="z_A_batch")
    
    model.setObjective(
        profit_A * A + profit_B * B 
        - overtime_penalty_per_hour * overtime_hours 
        - overtime_review_fee * z_ot_review 
        - product_A_senior_batch_fee * z_A_batch,
        GRB.MAXIMIZE
    )
    
    model.addConstr(assembly_time_A * A + assembly_time_B * B <= machine_working_time_minutes + overtime_hours * 60, "Machine_Time")
    
    model.addConstr(ratio_B * A - ratio_A * B <= 0, "Production_Ratio")
    
    model.addConstr(overtime_hours <= overtime_review_threshold_hours + (max_overtime_hours - overtime_review_threshold_hours) * z_ot_review, "OT_Review_Gate")
    
    bigM_A = 10000 
    model.addConstr(A <= product_A_senior_batch_threshold + bigM_A * z_A_batch, "A_Batch_Gate")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
