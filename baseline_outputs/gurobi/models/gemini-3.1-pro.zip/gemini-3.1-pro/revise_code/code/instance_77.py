import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load processing costs
    cost = {}
    parts = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p) for p in header[1:]]
        for row in reader:
            machine = row[0].strip()
            for j, p in enumerate(parts):
                cost[(machine, p)] = float(row[j + 1])

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    d = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    max_C = int(params['max_parts_on_C'])
    overtime_threshold = int(params['overtime_threshold'])
    overtime_penalty = float(params['overtime_penalty'])

    machines = ['A', 'B', 'C']

    model = gp.Model("MachineAssignment")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = model.addVars(machines, parts, vtype=GRB.BINARY, name="x")
    y = model.addVars(machines, vtype=GRB.BINARY, name="y")
    z = model.addVars(machines, vtype=GRB.BINARY, name="z")

    # Objective
    obj = gp.quicksum(cost[(m, p)] * x[m, p] for m in machines for p in parts) \
          + gp.quicksum(d[m] * y[m] for m in machines) \
          + gp.quicksum(overtime_penalty * z[m] for m in machines)
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraints
    # 1. Each part assigned to exactly one machine
    for p in parts:
        model.addConstr(gp.quicksum(x[m, p] for m in machines) == 1)

    # Setup linking
    for m in machines:
        for p in parts:
            model.addConstr(x[m, p] <= y[m])

    # 2. Constraint 2
    model.addConstr(x['A', 1] + x['A', 2] == 1)

    # 3. Constraint 3
    model.addConstr(x['A', 3] == 1)
    model.addConstr(x['B', 4] == 1)
    model.addConstr(x['C', 5] == 1)

    # 4. Constraint 4
    model.addConstr(gp.quicksum(x['C', p] for p in parts) <= max_C)

    # 5. Overtime penalty
    for m in machines:
        model.addConstr(gp.quicksum(x[m, p] for p in parts) <= overtime_threshold + len(parts) * z[m])

    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == '__main__':
    main()
