import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    table_2 = pd.read_csv(os.path.join(data_dir, 'table_2.csv'))
    params = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))

    def get_param(name, default, ptype):
        val = params.loc[params['Parameter_Name'] == name, 'Value']
        if val.empty:
            return default
        if ptype == bool:
            return str(val.values[0]).strip().lower() == 'true'
        return ptype(val.values[0])

    min_contract_types = get_param('min_contract_types', 2, int)
    max_contract_types = get_param('max_contract_types', 3, int)
    mutual_exclusion = get_param('mutual_exclusion_1_and_4', True, bool)
    monthly_max_parallel_contracts = get_param('monthly_max_parallel_contracts', 3, int)
    min_area = get_param('min_area_per_contract_units', 2, int)
    activation_fee = get_param('activation_fee_per_contract', 2500, float)
    onboarding_loss = get_param('onboarding_loss_units', 1, float)
    expedited_fee = get_param('expedited_onboarding_fee', 1800, float)

    demands = {int(row['Month']): float(row['Required_area_㎡']) / 100.0 for _, row in table_1.iterrows()}
    costs = {int(row['Contract_length_months']): float(row['Rental_fee_per_100㎡_yuan']) for _, row in table_2.iterrows()}

    months = list(demands.keys())
    max_month = max(months)
    contract_lengths = list(costs.keys())
    valid_contracts = [(i, j) for i in months for j in contract_lengths if i + j - 1 <= max_month]

    model = gp.Model("Warehouse_Rental")
    model.setParam('OutputFlag', 0)

    x = model.addVars(valid_contracts, vtype=GRB.INTEGER, name="x")
    z = model.addVars(valid_contracts, vtype=GRB.BINARY, name="z")
    w = model.addVars(valid_contracts, vtype=GRB.BINARY, name="w")
    y = model.addVars(contract_lengths, vtype=GRB.BINARY, name="y")

    M = sum(demands.values()) + len(valid_contracts) * onboarding_loss

    model.setObjective(
        gp.quicksum(costs[j] * x[i, j] for (i, j) in valid_contracts) +
        gp.quicksum(activation_fee * z[i, j] for (i, j) in valid_contracts) +
        gp.quicksum(expedited_fee * w[i, j] for (i, j) in valid_contracts),
        GRB.MINIMIZE
    )

    for i, j in valid_contracts:
        model.addConstr(x[i, j] >= min_area * z[i, j])
        model.addConstr(x[i, j] <= M * z[i, j])
        model.addConstr(w[i, j] <= z[i, j])

    for m in months:
        monthly_area = gp.LinExpr()
        active_contracts = gp.LinExpr()
        for i, j in valid_contracts:
            if i <= m <= i + j - 1:
                active_contracts += z[i, j]
                if i == m:
                    monthly_area += x[i, j] - onboarding_loss * z[i, j] + onboarding_loss * w[i, j]
                else:
                    monthly_area += x[i, j]
        model.addConstr(monthly_area == demands[m])
        model.addConstr(active_contracts <= monthly_max_parallel_contracts)

    for j in contract_lengths:
        model.addConstr(gp.quicksum(z[i, j] for i in months if (i, j) in valid_contracts) >= y[j])
        model.addConstr(gp.quicksum(z[i, j] for i in months if (i, j) in valid_contracts) <= M * y[j])

    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) >= min_contract_types)
    model.addConstr(gp.quicksum(y[j] for j in contract_lengths) <= max_contract_types)

    if mutual_exclusion and 1 in contract_lengths and 4 in contract_lengths:
        model.addConstr(y[1] + y[4] <= 1)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    solve()
