import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    total_space = params['mall_total_space']
    rent_pct = params['rent_percentage'] / 100.0
    
    stores = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            area = int(row['Area_per_Shop_m2'].strip())
            min_n = int(row['Min'].strip())
            max_n = int(row['Max'].strip())
            profits = {}
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            stores.append({
                'name': row['Store_Type'].strip(),
                'area': area,
                'min': min_n,
                'max': max_n,
                'profits': profits
            })
            
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    x = {}
    for i, s in enumerate(stores):
        for j in range(s['min'], s['max'] + 1):
            x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"x_{i}_{j}")
            
    for i, s in enumerate(stores):
        model.addConstr(gp.quicksum(x[i, j] for j in range(s['min'], s['max'] + 1)) == 1)
        
    # Space constraint
    # The brief doesn't explicitly mention common_area_factor, but it's in the data file.
    # We will not use it as it's not in the brief, but to be safe we just use the original area.
    model.addConstr(
        gp.quicksum(x[i, j] * j * stores[i]['area'] for i, s in enumerate(stores) for j in range(s['min'], s['max'] + 1)) <= total_space
    )
    
    # Objective
    total_profit = gp.quicksum(
        x[i, j] * j * stores[i]['profits'].get(j, 0)
        for i, s in enumerate(stores) for j in range(s['min'], s['max'] + 1) if j > 0
    )
    
    rent_income = rent_pct * total_profit
    
    # Catering security cost
    catering_idx = next(i for i, s in enumerate(stores) if s['name'] == 'Catering')
    if (catering_idx, 3) in x:
        rent_income -= 0.7 * x[catering_idx, 3]
        
    model.setObjective(rent_income, GRB.MAXIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    main()
