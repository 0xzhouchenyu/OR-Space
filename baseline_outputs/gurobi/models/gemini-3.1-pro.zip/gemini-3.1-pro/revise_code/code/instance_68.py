import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load parameters
    params = {}
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    # Load distances
    distances = {}
    dist_path = os.path.join(data_dir, 'table_1.csv')
    with open(dist_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            yard = row['Coal_Yard'].strip()
            area = int(row['Residential_Area'].strip())
            dist = float(row['Distance_km'].strip())
            distances[(yard, area)] = dist

    yards = list(set([k[0] for k in distances.keys()]))
    areas = list(set([k[1] for k in distances.keys()]))

    model = gp.Model("Revised_Coal_Distribution")
    model.setParam('OutputFlag', 0)

    x = {}
    for (yard, area) in distances.keys():
        x[(yard, area)] = model.addVar(lb=0, name=f"x_{yard}_{area}")

    excess_A_3 = model.addVar(lb=0, name="excess_A_3")

    # Objective
    obj = gp.quicksum(distances[(y, a)] * x[(y, a)] for (y, a) in distances.keys())
    
    if 'area3_A_excess_staging_cost' in params:
        obj += excess_A_3 * params['area3_A_excess_staging_cost']
        
    model.setObjective(obj, GRB.MINIMIZE)

    # Supply constraints
    if 'min_coal_yard_A' in params:
        model.addConstr(gp.quicksum(x[('A', a)] for a in areas if ('A', a) in x) >= params['min_coal_yard_A'])
    if 'min_coal_yard_B_adjusted' in params:
        model.addConstr(gp.quicksum(x[('B', a)] for a in areas if ('B', a) in x) >= params['min_coal_yard_B_adjusted'])

    # Demand constraints
    demand_map = {
        1: params.get('residential_area_1_demand', 0),
        2: params.get('residential_area_2_demand', 0),
        3: params.get('residential_area_3_demand', 0)
    }
    
    for a in areas:
        model.addConstr(gp.quicksum(x[(y, a)] for y in yards if (y, a) in x) == demand_map[a])

    # Min share constraint
    if 'min_share_area3_from_A' in params and ('A', 3) in x:
        model.addConstr(x[('A', 3)] >= params['min_share_area3_from_A'] * demand_map[3])

    # Excess staging constraint
    if 'area3_A_staging_threshold' in params and ('A', 3) in x:
        model.addConstr(excess_A_3 >= x[('A', 3)] - params['area3_A_staging_threshold'])

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    solve()
