import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'table_1.csv')
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        nodes = [h.strip() for h in header[1:]]
        
        edges = {}
        for row in reader:
            row_node = row[0].strip()
            for j, val in enumerate(row[1:]):
                col_node = nodes[j]
                bw = int(val.strip())
                if bw > 0:
                    edges[(row_node, col_node)] = 100 - bw
                    
    model = gp.Model("RoutingCost")
    model.setParam('OutputFlag', 0)
    
    x = {}
    for (i, j), cost in edges.items():
        x[i, j] = model.addVar(vtype=GRB.BINARY, obj=cost, name=f"x_{i}_{j}")
        
    source = 'A'
    target = 'E'
    intermediate = 'C'
    
    for i in nodes:
        out_flow = gp.quicksum(x[i, j] for j in nodes if (i, j) in edges)
        in_flow = gp.quicksum(x[j, i] for j in nodes if (j, i) in edges)
        
        if i == source:
            model.addConstr(out_flow - in_flow == 1, name=f"flow_{i}")
        elif i == target:
            model.addConstr(out_flow - in_flow == -1, name=f"flow_{i}")
        else:
            model.addConstr(out_flow - in_flow == 0, name=f"flow_{i}")
            
    # Must pass through C
    out_flow_C = gp.quicksum(x[intermediate, j] for j in nodes if (intermediate, j) in edges)
    model.addConstr(out_flow_C == 1, name="visit_C")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    main()
