import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    proc_time = {}
    capacity = {}
    cost_rate = {}
    raw_cost = {}
    price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            equip = row['Equipment'].strip()
            if equip == 'Raw_Material_Cost':
                raw_cost = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            elif equip == 'Unit_Price':
                price = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            else:
                for prod, col in [('I', 'Product_I'), ('II', 'Product_II'), ('III', 'Product_III')]:
                    val = row[col].strip()
                    if val != '-':
                        proc_time[(equip, prod)] = float(val)
                capacity[equip] = float(row['Effective_Machine_Hours'])
                cost_rate[equip] = float(row['Processing_Cost_per_Machine_Hour'])
                
    setup_costs = {}
    with open(os.path.join(data_dir, 'setup_costs.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            setup_costs[row['Equipment'].strip()] = float(row['Fixed_Setup_Cost'])
            
    joint_calibration_fee = 100.0
    
    stage_A_equip = {'I': ['A1', 'A2'], 'II': ['A1', 'A2'], 'III': ['A2']}
    stage_B_equip = {'I': ['B1', 'B2', 'B3'], 'II': ['B1'], 'III': ['B2']}
    
    model = gp.Model("Factory_Production")
    model.setParam('OutputFlag', 0)
    
    x = {}
    for prod in ['I', 'II', 'III']:
        for equip in stage_A_equip[prod]:
            x[(equip, prod)] = model.addVar(lb=0, name=f"x_{equip}_{prod}")
        for equip in stage_B_equip[prod]:
            x[(equip, prod)] = model.addVar(lb=0, name=f"x_{equip}_{prod}")
            
    y = {}
    for equip in capacity.keys():
        y[equip] = model.addVar(vtype=GRB.BINARY, name=f"y_{equip}")
        
    z = model.addVar(vtype=GRB.BINARY, name="z_joint")
    
    for prod in ['I', 'II', 'III']:
        model.addConstr(
            gp.quicksum(x[(e, prod)] for e in stage_A_equip[prod]) == 
            gp.quicksum(x[(e, prod)] for e in stage_B_equip[prod]),
            name=f"flow_{prod}"
        )
        
    for equip in capacity.keys():
        relevant = [(equip, prod) for prod in ['I', 'II', 'III'] if (equip, prod) in x]
        if relevant:
            model.addConstr(
                gp.quicksum(proc_time[(equip, prod)] * x[(equip, prod)] for equip2, prod in relevant) <= capacity[equip],
                name=f"cap_{equip}"
            )
            # Big-M constraint
            M = capacity[equip] / min([proc_time[(equip, prod)] for equip2, prod in relevant])
            model.addConstr(
                gp.quicksum(x[(equip, prod)] for equip2, prod in relevant) <= M * y[equip],
                name=f"active_{equip}"
            )
            
    model.addConstr(z >= y['A2'] + y['B2'] - 1, name="joint_calib")
    
    revenue = gp.quicksum(price[p] * gp.quicksum(x[(e, p)] for e in stage_A_equip[p]) for p in ['I', 'II', 'III'])
    raw_mat = gp.quicksum(raw_cost[p] * gp.quicksum(x[(e, p)] for e in stage_A_equip[p]) for p in ['I', 'II', 'III'])
    proc_cost = gp.quicksum(cost_rate[e] * proc_time[(e, p)] * x[(e, p)] for (e, p) in x)
    setup_cost = gp.quicksum(setup_costs[e] * y[e] for e in y)
    
    profit = revenue - raw_mat - proc_cost - setup_cost - joint_calibration_fee * z
    
    model.setObjective(profit, GRB.MAXIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal:.2f}")
    else:
        print("FINAL_OBJ_VALUE: 0.00")

if __name__ == "__main__":
    main()
