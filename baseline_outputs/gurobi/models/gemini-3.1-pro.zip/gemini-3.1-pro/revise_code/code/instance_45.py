import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    products = []
    segments = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            p = row['Product']
            if p not in segments:
                segments[p] = []
                products.append(p)
            rng = row['Sales_Volume_Range']
            profit = float(row['Profit'])
            if rng.startswith('Above_'):
                lower = float(rng.split('_')[1])
                upper = None
            else:
                parts = rng.split('_')
                lower = float(parts[0])
                upper = float(parts[1])
            segments[p].append({'lower': lower, 'upper': upper, 'profit': profit})

    model = gp.Model("Maximize_Profit")
    model.setParam('OutputFlag', 0)
    M = 10000

    x = {}
    p_var = {}
    y = {}

    for prod in products:
        pname = prod.split('_')[1]
        x[prod] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_{pname}")
        p_var[prod] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"p_{pname}")
        y[prod] = []
        for i in range(len(segments[prod])):
            yi = model.addVar(vtype=GRB.BINARY, name=f"y_{pname}_{i}")
            y[prod].append(yi)

    O = model.addVar(lb=0, ub=params.get('overtime_cap_hours', 120), vtype=GRB.CONTINUOUS, name="overtime")
    z = model.addVar(vtype=GRB.BINARY, name="overtime_review_flag")

    model.setObjective(
        gp.quicksum(p_var[prod] for prod in products) 
        - params.get('overtime_cost_per_hour', 0.5) * O 
        - params.get('overtime_second_review_fee', 10) * z,
        GRB.MAXIMIZE
    )

    for prod in products:
        segs = segments[prod]
        model.addConstr(gp.quicksum(y[prod]) <= 1)

        for i, seg in enumerate(segs):
            lo = seg['lower']
            hi = seg['upper']
            profit = seg['profit']

            if lo == 0:
                model.addConstr(x[prod] >= 1 - M * (1 - y[prod][i]))
            else:
                model.addConstr(x[prod] >= (lo + 1) - M * (1 - y[prod][i]))

            if hi is not None:
                model.addConstr(x[prod] <= hi + M * (1 - y[prod][i]))

            model.addConstr(p_var[prod] <= profit * x[prod] + M * (1 - y[prod][i]))

        model.addConstr(x[prod] <= M * gp.quicksum(y[prod]))
        model.addConstr(p_var[prod] <= M * gp.quicksum(y[prod]))

    for res_prefix, res_limit in [
        ('technical_prep_time', 'available_technical_prep_time'),
        ('materials', 'available_materials')
    ]:
        model.addConstr(
            gp.quicksum(params[f"{res_prefix}_{prod.split('_')[1]}"] * x[prod] for prod in products) <= params[res_limit]
        )

    model.addConstr(
        gp.quicksum(params[f"labor_time_{prod.split('_')[1]}"] * x[prod] for prod in products) 
        <= params['available_labor_time'] + O
    )

    model.addConstr(
        gp.quicksum(params.get(f"pack_units_{prod.split('_')[1]}", 0) * x[prod] for prod in products) 
        <= params.get('packaging_cap_units', 180)
    )

    threshold = params.get('overtime_second_review_threshold', 100)
    cap = params.get('overtime_cap_hours', 120)
    model.addConstr(O <= threshold + (cap - threshold) * z)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
