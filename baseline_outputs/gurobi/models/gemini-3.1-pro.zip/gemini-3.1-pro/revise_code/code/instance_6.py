import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    demand = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        quarters = [int(h) for h in header[1:]]
        for row in reader:
            product = row[0].strip()
            for j, q in enumerate(quarters):
                demand[(product, q)] = int(row[j+1])
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
            
    products = ['I', 'II', 'III']
    quarters = [1, 2, 3, 4]
    
    init_inv = params['initial_inventory']
    end_inv_req = params['end_inventory_requirement']
    base_hours = params['production_hours_per_quarter']
    
    hours_per_unit = {
        'I': params['product_I_hours_per_unit'],
        'II': params['product_II_hours_per_unit'],
        'III': params['product_III_hours_per_unit']
    }
    delay_penalty = {
        'I': params['delay_penalty_product_I'],
        'II': params['delay_penalty_product_II'],
        'III': params['delay_penalty_product_III']
    }
    inv_cost = params['inventory_cost_per_unit']
    
    normal_cap = {q: base_hours * params[f'normal_hours_cap_fraction_q{q}'] for q in quarters}
    peak_cap = {q: params[f'peak_hours_cap_q{q}'] for q in quarters}
    peak_cost = {q: params[f'peak_cost_per_hour_q{q}'] for q in quarters}
    
    model = gp.Model("ProductionScheduling")
    model.setParam('OutputFlag', 0)
    
    x = model.addVars(products, quarters, vtype=GRB.INTEGER, name="x")
    inv = model.addVars(products, quarters, lb=-GRB.INFINITY, name="inv")
    inv_pos = model.addVars(products, quarters, lb=0, name="inv_pos")
    inv_neg = model.addVars(products, quarters, lb=0, name="inv_neg")
    
    hours_normal = model.addVars(quarters, lb=0, name="hours_normal")
    hours_peak = model.addVars(quarters, lb=0, name="hours_peak")
    
    model.addConstr(x['I', 2] == 0)
    
    for p in products:
        model.addConstr(inv[p, 1] == init_inv + x[p, 1] - demand[p, 1])
        for t in range(2, 5):
            model.addConstr(inv[p, t] == inv[p, t-1] + x[p, t] - demand[p, t])
            
    for p in products:
        for t in quarters:
            model.addConstr(inv[p, t] == inv_pos[p, t] - inv_neg[p, t])
            
    for p in products:
        model.addConstr(inv[p, 4] >= end_inv_req)
        
    for t in quarters:
        model.addConstr(hours_normal[t] <= normal_cap[t])
        model.addConstr(hours_peak[t] <= peak_cap[t])
        model.addConstr(
            gp.quicksum(hours_per_unit[p] * x[p, t] for p in products) == hours_normal[t] + hours_peak[t]
        )
        
    obj = gp.quicksum(delay_penalty[p] * inv_neg[p, t] + inv_cost * inv_pos[p, t] 
                      for p in products for t in quarters)
    obj += gp.quicksum(peak_cost[t] * hours_peak[t] for t in quarters)
    
    model.setObjective(obj, GRB.MINIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
