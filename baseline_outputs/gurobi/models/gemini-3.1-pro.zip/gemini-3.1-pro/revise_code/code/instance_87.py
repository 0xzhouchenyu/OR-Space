import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    rc_a = params['refrigerated_capacity_type_a']
    nc_a = params['non_refrigerated_capacity_type_a']
    rc_b = params['refrigerated_capacity_type_b']
    nc_b = params['non_refrigerated_capacity_type_b']
    ref_req = params['refrigerated_cargo_requirement']
    nonref_req = params['non_refrigerated_cargo_requirement']
    cost_a = params['rental_cost_type_a']
    cost_b = params['rental_cost_type_b']
    
    base_a = params['base_fleet_type_a']
    base_b = params['base_fleet_type_b']
    penalty_a = params['penalty_cost_type_a']
    penalty_b = params['penalty_cost_type_b']
    
    tb_thresh = params['type_b_recovery_threshold']
    tb_fee = params['type_b_recovery_fee']
    
    tot_thresh = params['total_fleet_surge_threshold']
    tot_fee = params['total_fleet_surge_fee']
    
    model = gp.Model("TruckRental")
    model.setParam('OutputFlag', 0)
    
    x = model.addVar(vtype=GRB.INTEGER, lb=0, name="x")
    y = model.addVar(vtype=GRB.INTEGER, lb=0, name="y")
    
    excess_a = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="excess_a")
    excess_b = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name="excess_b")
    
    z_b = model.addVar(vtype=GRB.BINARY, name="z_b")
    z_tot = model.addVar(vtype=GRB.BINARY, name="z_tot")
    
    model.addConstr(rc_a * x + rc_b * y >= ref_req)
    model.addConstr(nc_a * x + nc_b * y >= nonref_req)
    
    model.addConstr(excess_a >= x - base_a)
    model.addConstr(excess_b >= y - base_b)
    
    M = 100000
    model.addConstr(y - tb_thresh <= M * z_b)
    model.addConstr(x + y - tot_thresh <= M * z_tot)
    
    obj = cost_a * x + cost_b * y + penalty_a * excess_a + penalty_b * excess_b + tb_fee * z_b + tot_fee * z_tot
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
