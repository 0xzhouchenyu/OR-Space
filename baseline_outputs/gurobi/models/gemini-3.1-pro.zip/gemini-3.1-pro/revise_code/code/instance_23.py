import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Read product data
    products = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Product Name'].strip()
            products[name] = {
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            }
    
    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    prod_map = {
        'Shirt': 'shirts',
        'Short-sleeve': 'short_sleeves',
        'Casual Cloth': 'casual_clothes'
    }
    
    for p_name, p_key in prod_map.items():
        products[p_name]['fixed_cost'] = params[f'fixed_cost_{p_key}']
        products[p_name]['min_batch'] = params[f'min_batch_{p_key}']
        products[p_name]['max_prod'] = params[f'max_prod_{p_key}']
        
    available_labor = params['available_labor']
    available_material = params['available_material']
    reg_discount = params['segment_regular_discount']
    promo_discount = params['segment_promo_discount']
    promo_labor_cap = params['segment_promo_labor_cap']
    promo_material_cap = params['segment_promo_material_cap']
    
    model = gp.Model("clothing_production_revised")
    model.setParam('OutputFlag', 0)
    
    x_reg = {}
    x_pro = {}
    y_reg = {}
    y_pro = {}
    z = {}
    
    for p_name in products:
        x_reg[p_name] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_reg_{p_name}")
        x_pro[p_name] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_pro_{p_name}")
        y_reg[p_name] = model.addVar(vtype=GRB.BINARY, name=f"y_reg_{p_name}")
        y_pro[p_name] = model.addVar(vtype=GRB.BINARY, name=f"y_pro_{p_name}")
        z[p_name] = model.addVar(vtype=GRB.BINARY, name=f"z_{p_name}")
    
    # Constraints
    for p_name, p_data in products.items():
        min_b = p_data['min_batch']
        max_p = p_data['max_prod']
        
        # Segment presence implies min batch
        model.addConstr(x_reg[p_name] >= min_b * y_reg[p_name])
        model.addConstr(x_reg[p_name] <= max_p * y_reg[p_name])
        
        model.addConstr(x_pro[p_name] >= min_b * y_pro[p_name])
        model.addConstr(x_pro[p_name] <= max_p * y_pro[p_name])
        
        # Total production limit
        model.addConstr(x_reg[p_name] + x_pro[p_name] <= max_p * z[p_name])
        
        # Equipment activation
        model.addConstr(z[p_name] >= y_reg[p_name])
        model.addConstr(z[p_name] >= y_pro[p_name])

    # Resource constraints
    model.addConstr(
        gp.quicksum(products[p]['labor'] * (x_reg[p] + x_pro[p]) for p in products) <= available_labor
    )
    model.addConstr(
        gp.quicksum(products[p]['material'] * (x_reg[p] + x_pro[p]) for p in products) <= available_material
    )
    
    # Promo segment caps
    model.addConstr(
        gp.quicksum(products[p]['labor'] * x_pro[p] for p in products) <= promo_labor_cap
    )
    model.addConstr(
        gp.quicksum(products[p]['material'] * x_pro[p] for p in products) <= promo_material_cap
    )
    
    # Objective
    profit = gp.quicksum(
        (products[p]['price'] * reg_discount - products[p]['var_cost']) * x_reg[p] +
        (products[p]['price'] * promo_discount - products[p]['var_cost']) * x_pro[p] -
        products[p]['fixed_cost'] * z[p]
        for p in products
    )
    
    model.setObjective(profit, GRB.MAXIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
