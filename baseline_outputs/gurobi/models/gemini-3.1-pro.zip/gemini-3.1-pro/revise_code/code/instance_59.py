import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load general parameters
    gen_params_path = os.path.join(base_dir, 'data', 'general_parameters.csv')
    setup_costs = [0.0, 0.0, 0.0]
    shared_trigger = False
    shared_fee = 0.0
    
    with open(gen_params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'SetupCost_A':
                setup_costs[0] = float(row['Value'])
            elif row['Parameter_Name'] == 'SetupCost_B':
                setup_costs[1] = float(row['Value'])
            elif row['Parameter_Name'] == 'SetupCost_C':
                setup_costs[2] = float(row['Value'])
            elif row['Parameter_Name'] == 'BrandAB_SharedWrapper_Trigger':
                shared_trigger = (float(row['Value']) == 1)
            elif row['Parameter_Name'] == 'BrandAB_SharedWrapper_Fee':
                shared_fee = float(row['Value'])
                
    # Load table parameters
    table_path = os.path.join(base_dir, 'data', 'table_1_7.csv')
    raw_cost = [0.0, 0.0, 0.0]
    limits = [0.0, 0.0, 0.0]
    proc_fee = [0.0, 0.0, 0.0]
    sell_price = [0.0, 0.0, 0.0]
    
    with open(table_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if row[0] == 'A':
                raw_cost[0] = float(row[4])
                limits[0] = float(row[5])
            elif row[0] == 'B':
                raw_cost[1] = float(row[4])
                limits[1] = float(row[5])
            elif row[0] == 'C':
                raw_cost[2] = float(row[4])
                limits[2] = float(row[5])
            elif row[0] == 'Processing Fee (Yuan/kg)':
                proc_fee[0] = float(row[1])
                proc_fee[1] = float(row[2])
                proc_fee[2] = float(row[3])
            elif row[0] == 'Selling Price (Yuan/kg)':
                sell_price[0] = float(row[1])
                sell_price[1] = float(row[2])
                sell_price[2] = float(row[3])
                
    model = gp.Model("CandyFactory")
    model.setParam('OutputFlag', 0)
    
    # Variables
    x = model.addVars(3, 3, vtype=GRB.CONTINUOUS, name="x")
    y = model.addVars(3, vtype=GRB.CONTINUOUS, name="y")
    z = model.addVars(3, vtype=GRB.BINARY, name="z")
    w = model.addVar(vtype=GRB.BINARY, name="w")
    
    # Link y to x
    for j in range(3):
        model.addConstr(y[j] == gp.quicksum(x[i, j] for i in range(3)))
        
    # Link z to y
    BIG_M = sum(limits)
    for j in range(3):
        model.addConstr(y[j] <= BIG_M * z[j])
        
    # Shared wrapper
    if shared_trigger:
        model.addConstr(w >= z[0] + z[1] - 1)
        
    # Raw material limits
    for i in range(3):
        model.addConstr(gp.quicksum(x[i, j] for j in range(3)) <= limits[i])
        
    # Composition constraints
    model.addConstr(x[0, 0] >= 0.60 * y[0])
    model.addConstr(x[0, 1] >= 0.15 * y[1])
    
    model.addConstr(x[2, 0] <= 0.20 * y[0])
    model.addConstr(x[2, 1] <= 0.60 * y[1])
    model.addConstr(x[2, 2] <= 0.50 * y[2])
    
    # Objective
    revenue = gp.quicksum(sell_price[j] * y[j] for j in range(3))
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(3) for j in range(3))
    processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in range(3))
    setup_cost_total = gp.quicksum(setup_costs[j] * z[j] for j in range(3))
    wrapper_cost = shared_fee * w if shared_trigger else 0
    
    profit = revenue - material_cost - processing_cost - setup_cost_total - wrapper_cost
    model.setObjective(profit, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: 0.0")

if __name__ == "__main__":
    main()
