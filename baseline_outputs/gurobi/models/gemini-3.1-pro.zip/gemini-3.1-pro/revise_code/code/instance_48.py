import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    table1 = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    
    param_dict = {}
    for row in params:
        param_dict[row['Parameter_Name']] = float(row['Value'])
    
    proc_I = table1[0]
    proc_II = table1[1]
    profit_row = table1[2]
    
    a_I = float(proc_I['Model_A_hours_per_unit'])
    b_I = float(proc_I['Model_B_hours_per_unit'])
    proc_I_hours = param_dict['process_I_hours']
    
    a_II = float(proc_II['Model_A_hours_per_unit'])
    b_II = float(proc_II['Model_B_hours_per_unit'])
    cap_II = float(proc_II['Maximum_Weekly_Processing_Capacity'])
    
    profit_A = float(profit_row['Model_A_hours_per_unit'])
    profit_B = float(profit_row['Model_B_hours_per_unit'])
    
    min_profit = param_dict['min_weekly_profit']
    min_A = param_dict['min_model_A_units']
    min_B = param_dict['min_model_B_units']
    max_overtime = param_dict['process_II_max_overtime']
    red_A = param_dict['model_A_overtime_profit_reduction']
    red_B = param_dict['model_B_overtime_profit_reduction']
    
    model = gp.Model("Microcomputer_Production")
    model.setParam('OutputFlag', 0)
    
    xA_r = model.addVar(lb=0, name="xA_r")
    xA_o = model.addVar(lb=0, name="xA_o")
    xB_r = model.addVar(lb=0, name="xB_r")
    xB_o = model.addVar(lb=0, name="xB_o")
    
    total_A = xA_r + xA_o
    total_B = xB_r + xB_o
    
    model.addConstr(a_I * total_A + b_I * total_B == proc_I_hours, "Process_I_Exact")
    model.addConstr(a_II * xA_r + b_II * xB_r <= cap_II, "Process_II_Regular")
    model.addConstr(a_II * xA_o + b_II * xB_o <= max_overtime, "Process_II_Overtime")
    
    model.addConstr(total_A >= min_A, "Min_A")
    model.addConstr(total_B >= min_B, "Min_B")
    
    total_profit = profit_A * xA_r + profit_B * xB_r + (profit_A - red_A) * xA_o + (profit_B - red_B) * xB_o
    model.addConstr(total_profit >= min_profit, "Min_Profit")
    
    model.setObjective(total_A + total_B, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
