import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    n = int(params['n'])
    premium_cost_multiplier = params['premium_cost_multiplier']
    min_premium_share = params['min_premium_share']

    # Read table 1
    d = []
    c = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            d_row = [float(row[f'Transportation_volume_to_Location_{j+1}']) for j in range(n)]
            c_row = [float(row[f'Transportation_cost_to_Location_{j+1}']) for j in range(n)]
            d.append(d_row)
            c.append(c_row)

    # Calculate outbound volume for each factory
    outbound_volume = [sum(d[i]) for i in range(n)]

    # Calculate standard and premium unit costs for each factory-location pair
    c_std = [[0.0 for p in range(n)] for i in range(n)]
    c_prem = [[0.0 for p in range(n)] for i in range(n)]

    for i in range(n):
        for p in range(n):
            if outbound_volume[i] > 0:
                sum_cost = sum(d[i][j] * c[p][j] for j in range(n))
                c_std[i][p] = sum_cost / outbound_volume[i]
            else:
                c_std[i][p] = 0.0
            c_prem[i][p] = premium_cost_multiplier * c_std[i][p]

    # Initialize Gurobi model
    model = gp.Model()
    model.setParam('OutputFlag', 0)

    # Variables
    x = model.addVars(n, n, vtype=GRB.BINARY, name="x")
    y = model.addVars(n, n, vtype=GRB.BINARY, name="y")
    v_std = model.addVars(n, n, vtype=GRB.CONTINUOUS, name="v_std")
    v_prem = model.addVars(n, n, vtype=GRB.CONTINUOUS, name="v_prem")

    # Constraints
    # Each factory must be assigned to exactly one location
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, p] for p in range(n)) == 1)

    # No location should host more than one factory
    for p in range(n):
        model.addConstr(gp.quicksum(x[i, p] for i in range(n)) <= 1)

    for i in range(n):
        for p in range(n):
            # Total volume split
            model.addConstr(v_std[i, p] + v_prem[i, p] == outbound_volume[i] * x[i, p])
            
            # Premium volume constraints
            model.addConstr(v_prem[i, p] <= outbound_volume[i] * y[i, p])
            model.addConstr(v_prem[i, p] >= min_premium_share * outbound_volume[i] * y[i, p])
            
            # Premium mode can only be selected if the factory is assigned to that location
            model.addConstr(y[i, p] <= x[i, p])

    # Objective: Minimize total transportation and handling cost
    obj = gp.quicksum(v_std[i, p] * c_std[i][p] + v_prem[i, p] * c_prem[i][p] for i in range(n) for p in range(n))
    model.setObjective(obj, GRB.MINIMIZE)

    # Optimize
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    solve()
