import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    data = []
    with open(filepath, 'r', newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    products = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params_raw = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    
    params = {}
    for row in params_raw:
        params[row['Parameter_Name']] = float(row['Value'])
    
    max_grains = params['max_grains']
    price_grains = params['price_per_lb_grains']
    max_meat = params['max_meat']
    price_meat = params['price_per_lb_meat']
    
    line_fixed_cost = params.get('line_fixed_cost', 0)
    line_capacity_packs = params.get('line_capacity_packs', 120000)
    min_batch_packs = params.get('min_batch_packs', 20000)
    min_yummies = params.get('min_yummies', 15000)
    retailer_rebate_yummies_threshold = params.get('retailer_rebate_yummies_threshold', 50000)
    retailer_rebate_min_meaties = params.get('retailer_rebate_min_meaties', 40000)
    retailer_rebate_fixed = params.get('retailer_rebate_fixed', 12000)
    
    product_data = {}
    for row in products:
        name = row['Product']
        product_data[name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'variable_cost': float(row['Variable_cost_per_pack']),
            'capacity': float(row['Production_capacity']) if row['Production_capacity'].strip() else None
        }
    
    m = gp.Model("HealthyPetFoods")
    m.setParam('OutputFlag', 0)
    
    x_meaties = m.addVar(lb=0, name="Meaties")
    x_yummies = m.addVar(lb=0, name="Yummies")
    
    z_line = m.addVar(vtype=GRB.BINARY, name="LineActive")
    y_rebate = m.addVar(vtype=GRB.BINARY, name="RebateActive")
    
    p_m = product_data['Meaties']
    p_y = product_data['Yummies']
    
    profit_meaties = p_m['price'] - p_m['variable_cost'] - (p_m['grains'] * price_grains + p_m['meat'] * price_meat)
    profit_yummies = p_y['price'] - p_y['variable_cost'] - (p_y['grains'] * price_grains + p_y['meat'] * price_meat)
    
    m.setObjective(profit_meaties * x_meaties + profit_yummies * x_yummies - line_fixed_cost * z_line + retailer_rebate_fixed * y_rebate, GRB.MAXIMIZE)
    
    m.addConstr(p_m['grains'] * x_meaties + p_y['grains'] * x_yummies <= max_grains, "Grains_Constraint")
    m.addConstr(p_m['meat'] * x_meaties + p_y['meat'] * x_yummies <= max_meat, "Meat_Constraint")
    
    if p_m['capacity'] is not None:
        m.addConstr(x_meaties <= p_m['capacity'], "Meaties_Capacity")
    if p_y['capacity'] is not None:
        m.addConstr(x_yummies <= p_y['capacity'], "Yummies_Capacity")
        
    m.addConstr(x_meaties + x_yummies <= line_capacity_packs * z_line, "Line_Capacity")
    m.addConstr(x_meaties + x_yummies >= min_batch_packs * z_line, "Min_Batch")
    m.addConstr(x_yummies >= min_yummies * z_line, "Min_Yummies")
    
    m.addConstr(x_yummies >= retailer_rebate_yummies_threshold * y_rebate, "Rebate_Yummies")
    m.addConstr(x_meaties >= retailer_rebate_min_meaties * y_rebate, "Rebate_Meaties")
    
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.objVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
