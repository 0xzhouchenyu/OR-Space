import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'data', 'table_1.csv')
    with open(table1_path, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = list(reader)
    
    a_I = float(rows[0][1])
    b_I = float(rows[0][2])
    
    a_II = float(rows[1][1])
    b_II = float(rows[1][2])
    
    profit_A = float(rows[2][1])
    profit_B = float(rows[2][2])
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'data', 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    
    min_weekly_profit = params['min_weekly_profit']
    min_model_A_units = params['min_model_A_units']
    min_model_B_units = params['min_model_B_units']
    w1_min_A = params['week1_min_model_A_units']
    w1_min_B = params['week1_min_model_B_units']
    w2_min_A = params['week2_min_model_A_units']
    w2_min_B = params['week2_min_model_B_units']
    reg_I = params['process_I_hours']
    reg_II = params['process_II_hours']
    max_ot_I = params['max_overtime_I_per_week']
    max_ot_II = params['max_overtime_II_per_week']
    ot_cost_I = params['overtime_premium_I']
    ot_cost_II = params['overtime_premium_II']
    min_util_I = params['min_avg_utilization_I']
    min_util_II = params['min_avg_utilization_II']
    fatigue_I = params['week1_overtime_fatigue_threshold_I']
    fatigue_II = params['week1_overtime_fatigue_threshold_II']
    rec_loss_I = params['week2_recovery_loss_I']
    rec_loss_II = params['week2_recovery_loss_II']
    
    model = gp.Model("Revised_Microcomputer_Production")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_A_1 = model.addVar(lb=0, name="x_A_1")
    x_B_1 = model.addVar(lb=0, name="x_B_1")
    x_A_2 = model.addVar(lb=0, name="x_A_2")
    x_B_2 = model.addVar(lb=0, name="x_B_2")
    
    ot_I_1 = model.addVar(lb=0, ub=max_ot_I, name="ot_I_1")
    ot_II_1 = model.addVar(lb=0, ub=max_ot_II, name="ot_II_1")
    ot_I_2 = model.addVar(lb=0, ub=max_ot_I, name="ot_I_2")
    ot_II_2 = model.addVar(lb=0, ub=max_ot_II, name="ot_II_2")
    
    z_fatigue_I = model.addVar(vtype=GRB.BINARY, name="z_fatigue_I")
    z_fatigue_II = model.addVar(vtype=GRB.BINARY, name="z_fatigue_II")
    
    # Overtime fatigue logic
    M = 1000
    # if ot_I_1 > fatigue_I -> z_fatigue_I = 1
    model.addConstr(ot_I_1 - fatigue_I <= M * z_fatigue_I)
    # if z_fatigue_I = 1 -> ot_I_1 > fatigue_I (or >= fatigue_I + eps, but standard big-M is fine)
    # Actually, if it's strictly greater, we can use a small epsilon, but standard is:
    # ot_I_1 - fatigue_I >= -M * (1 - z_fatigue_I) + 1e-4 * z_fatigue_I
    # A simpler way: we want to penalize if z_fatigue_I = 0.
    # We can just enforce: ot_I_1 <= fatigue_I + M * z_fatigue_I
    model.addConstr(ot_I_1 <= fatigue_I + M * z_fatigue_I)
    
    model.addConstr(ot_II_1 <= fatigue_II + M * z_fatigue_II)
    
    # Capacity constraints Week 1
    model.addConstr(a_I * x_A_1 + b_I * x_B_1 <= reg_I + ot_I_1)
    model.addConstr(a_II * x_A_1 + b_II * x_B_1 <= reg_II + ot_II_1)
    
    # Capacity constraints Week 2
    model.addConstr(a_I * x_A_2 + b_I * x_B_2 <= reg_I - rec_loss_I * z_fatigue_I + ot_I_2)
    model.addConstr(a_II * x_A_2 + b_II * x_B_2 <= reg_II - rec_loss_II * z_fatigue_II + ot_II_2)
    
    # Minimum production
    model.addConstr(x_A_1 >= w1_min_A)
    model.addConstr(x_B_1 >= w1_min_B)
    model.addConstr(x_A_2 >= w2_min_A)
    model.addConstr(x_B_2 >= w2_min_B)
    model.addConstr(x_A_1 + x_A_2 >= min_model_A_units)
    model.addConstr(x_B_1 + x_B_2 >= min_model_B_units)
    
    # Minimum utilization
    # Utilization is based on regular hours used.
    # Total regular hours available over two weeks is 2 * reg_I and 2 * reg_II
    # But wait, the constraint is on "average use of regular Process I hours".
    # Time used is a_I * (x_A_1 + x_A_2) + b_I * (x_B_1 + x_B_2)
    # If this includes overtime, we just require the total time to be >= min_util * 2 * reg_I
    model.addConstr(a_I * (x_A_1 + x_A_2) + b_I * (x_B_1 + x_B_2) >= min_util_I * 2 * reg_I)
    model.addConstr(a_II * (x_A_1 + x_A_2) + b_II * (x_B_1 + x_B_2) >= min_util_II * 2 * reg_II)
    
    # Profit
    total_revenue = profit_A * (x_A_1 + x_A_2) + profit_B * (x_B_1 + x_B_2)
    total_ot_cost = ot_cost_I * (ot_I_1 + ot_I_2) + ot_cost_II * (ot_II_1 + ot_II_2)
    net_profit = total_revenue - total_ot_cost
    
    model.addConstr(net_profit >= min_weekly_profit)
    
    model.setObjective(net_profit, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
