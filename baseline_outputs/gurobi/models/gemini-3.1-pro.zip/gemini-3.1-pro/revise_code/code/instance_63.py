import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

produce = params['produce_to_transport']
horse_poll = params['horse_pollution_per_trip']
bike_poll = params['bicycle_pollution_per_trip']
cart_poll = params['handcart_pollution_per_trip']
max_poll = params['max_total_pollution']
min_horse = params['min_horse_trips']
horse_cap = params['horse_capacity_per_trip']
bike_cap = params['bicycle_capacity_per_trip']
cart_cap = params['handcart_capacity_per_trip']
min_produce = params['min_total_produce']

horse_cost = params.get('horse_cost_per_trip', 15)
bike_cost = params.get('bicycle_cost_per_trip', 5)
cart_cost = params.get('handcart_cost_per_trip', 4)
horse_fixed = params.get('horse_fixed_cost', 100)
bike_fixed = params.get('bicycle_fixed_cost', 50)
cart_fixed = params.get('handcart_fixed_cost', 200)
poll_penalty = params.get('pollution_penalty_per_unit', 2)
permit_threshold = params.get('horse_pollution_permit_threshold', 600)
permit_fee = params.get('horse_pollution_permit_fee', 100)

# Model
model = gp.Model("FarmTransport")
model.setParam('OutputFlag', 0)

# Decision variables
x_horse = model.addVar(vtype=GRB.INTEGER, lb=0, name="horse_trips")
x_bike = model.addVar(vtype=GRB.INTEGER, lb=0, name="bike_trips")
x_cart = model.addVar(vtype=GRB.INTEGER, lb=0, name="cart_trips")

u_horse = model.addVar(vtype=GRB.BINARY, name="use_horse")
u_bike = model.addVar(vtype=GRB.BINARY, name="use_bike")
u_cart = model.addVar(vtype=GRB.BINARY, name="use_cart")

z_permit = model.addVar(vtype=GRB.BINARY, name="permit_fee_incurred")

M = 10000

# Constraints
model.addConstr(x_horse >= min_horse)
model.addConstr(horse_cap * x_horse + bike_cap * x_bike + cart_cap * x_cart >= min_produce)

total_poll = horse_poll * x_horse + bike_poll * x_bike + cart_poll * x_cart
model.addConstr(total_poll <= max_poll)

model.addConstr(x_horse <= M * u_horse)
model.addConstr(x_bike <= M * u_bike)
model.addConstr(x_cart <= M * u_cart)

# Either bicycle or handcart, not both
model.addConstr(u_bike + u_cart <= 1)

# Permit fee condition
model.addConstr(total_poll - permit_threshold <= M * z_permit)

# Objective
total_var_cost = horse_cost * x_horse + bike_cost * x_bike + cart_cost * x_cart
total_fixed_cost = horse_fixed * u_horse + bike_fixed * u_bike + cart_fixed * u_cart
total_poll_cost = poll_penalty * total_poll
total_permit_cost = permit_fee * z_permit

model.setObjective(total_var_cost + total_fixed_cost + total_poll_cost + total_permit_cost, GRB.MINIMIZE)

# Solve
model.optimize()

print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
