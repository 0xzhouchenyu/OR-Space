import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass
            params[name] = value
    return params

def solve():
    params = load_parameters()
    
    profit_robot = params['profit_per_robot']
    profit_car = params['profit_per_model_car']
    profit_blocks = params['profit_per_building_blocks']
    profit_doll = params['profit_per_doll']
    
    plastic_avail = params['plastic_available']
    plastic_robot = params['plastic_per_robot']
    plastic_car = params['plastic_per_model_car']
    plastic_blocks = params['plastic_per_building_blocks']
    plastic_doll = params['plastic_per_doll']
    
    elec_avail = params['electronic_components_available']
    elec_robot = params['electronics_per_robot']
    elec_car = params['electronics_per_model_car']
    elec_blocks = params['electronics_per_building_blocks']
    elec_doll = params['electronics_per_doll']
    
    M = 100000
    
    model = gp.Model("ToyManufacturing")
    model.setParam('OutputFlag', 0)
    
    x_robot = model.addVar(vtype=GRB.INTEGER, lb=0, name="robots")
    x_car = model.addVar(vtype=GRB.INTEGER, lb=0, name="model_cars")
    x_blocks = model.addVar(vtype=GRB.INTEGER, lb=0, name="building_blocks")
    x_doll = model.addVar(vtype=GRB.INTEGER, lb=0, name="dolls")
    
    y_robot = model.addVar(vtype=GRB.BINARY, name="y_robot")
    y_doll = model.addVar(vtype=GRB.BINARY, name="y_doll")
    y_car = model.addVar(vtype=GRB.BINARY, name="y_car")
    y_blocks = model.addVar(vtype=GRB.BINARY, name="y_blocks")
    
    model.setObjective(profit_robot * x_robot + profit_car * x_car + profit_blocks * x_blocks + profit_doll * x_doll, GRB.MAXIMIZE)
    
    model.addConstr(plastic_robot * x_robot + plastic_car * x_car + plastic_blocks * x_blocks + plastic_doll * x_doll <= plastic_avail, "Plastic")
    model.addConstr(elec_robot * x_robot + elec_car * x_car + elec_blocks * x_blocks + elec_doll * x_doll <= elec_avail, "Electronics")
    
    model.addConstr(x_robot <= M * y_robot, "Link_robot")
    model.addConstr(x_doll <= M * y_doll, "Link_doll")
    model.addConstr(x_car <= M * y_car, "Link_car")
    model.addConstr(x_blocks <= M * y_blocks, "Link_blocks")
    
    model.addConstr(y_robot <= x_robot, "Binary_Link_Robot")
    model.addConstr(y_doll <= x_doll, "Binary_Link_Doll")
    model.addConstr(y_car <= x_car, "Binary_Link_Car")
    model.addConstr(y_blocks <= x_blocks, "Binary_Link_Blocks")
    
    model.addConstr(y_robot + y_doll <= 1, "Robot_Doll_Exclusion")
    model.addConstr(y_car <= y_blocks, "Car_Blocks_Dependency")
    model.addConstr(x_doll <= x_car, "Dolls_leq_Cars")
    
    # Revised constraint
    model.addConstr(y_car + y_blocks <= 1, "Car_Blocks_Exclusion")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")

if __name__ == "__main__":
    solve()
