import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            costs[row['Child'].strip()] = {
                'budget': float(row['Cost_budget'].strip()),
                'balanced': float(row['Cost_balanced'].strip()),
                'premium': float(row['Cost_premium'].strip())
            }
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    max_children = int(params['max_children'])
    min_children = int(params['min_children'])
    fairness_penalty = params['fairness_penalty']
    max_total_cost = params['max_total_cost']
    min_children_per_mode = int(params['min_children_per_mode'])
    
    children = list(costs.keys())
    modes = ['budget', 'balanced', 'premium']
    
    model = gp.Model("ZhangFamilyTrip")
    model.setParam('OutputFlag', 0)
    
    x = model.addVars(children, vtype=GRB.BINARY, name="x")
    y = model.addVars(modes, vtype=GRB.BINARY, name="y")
    z = model.addVars(children, modes, vtype=GRB.BINARY, name="z")
    
    max_cost = model.addVar(vtype=GRB.CONTINUOUS, name="max_cost")
    min_cost = model.addVar(vtype=GRB.CONTINUOUS, name="min_cost")
    
    model.addConstr(y.sum() == 1, "One_mode")
    
    for c in children:
        for m in modes:
            model.addConstr(z[c, m] <= x[c])
            model.addConstr(z[c, m] <= y[m])
            model.addConstr(z[c, m] >= x[c] + y[m] - 1)
    
    model.addConstr(x['Ginny'] == 1, "Ginny_must_go")
    model.addConstr(x.sum() <= max_children, "Max_children")
    model.addConstr(x.sum() >= min_children, "Min_children")
    
    model.addConstr(x.sum() >= min_children_per_mode * (y['balanced'] + y['premium']), "Min_children_per_mode")
    
    model.addConstr(x['Harry'] + x['Fred'] <= 1, "Harry_no_Fred")
    model.addConstr(x['Harry'] + x['George'] <= 1, "Harry_no_George")
    model.addConstr(x['George'] <= x['Fred'], "George_requires_Fred")
    model.addConstr(x['George'] <= x['Hermione'], "George_requires_Hermione")
    
    total_cost = gp.quicksum(costs[c][m] * z[c, m] for c in children for m in modes)
    model.addConstr(total_cost <= max_total_cost, "Max_total_cost")
    
    BIG_M = 20000
    for c in children:
        child_cost = gp.quicksum(costs[c][m] * z[c, m] for m in modes)
        model.addConstr(max_cost >= child_cost)
        model.addConstr(min_cost <= child_cost + BIG_M * (1 - x[c]))
    
    objective = total_cost + fairness_penalty * (max_cost - min_cost)
    model.setObjective(objective, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
