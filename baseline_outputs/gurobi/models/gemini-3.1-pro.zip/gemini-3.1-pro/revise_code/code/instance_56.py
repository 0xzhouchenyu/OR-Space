import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

months = []
purchase_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        m = int(row['Month'])
        months.append(m)
        purchase_prices[m] = float(row['Purchase_Price_yuan_per_dan'])
        selling_prices[m] = float(row['Selling_Price_yuan_per_dan'])

params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
initial_funds = params['initial_funds']
end_inventory = params['end_of_quarter_inventory']
buy_fast_capacity = params['buy_fast_capacity']
fast_purchase_premium_ratio = params['fast_purchase_premium_ratio']
credit_limit = params['credit_limit']
monthly_interest_rate = params['monthly_interest_rate']
min_inventory = {
    1: params['min_inventory_month_1'],
    2: params['min_inventory_month_2'],
    3: params['min_inventory_month_3']
}

# Create model
model = gp.Model("Grain_Trading_Revised")
model.setParam('OutputFlag', 0)

buy_reg = {m: model.addVar(lb=0, name=f"buy_reg_{m}") for m in months}
buy_fast = {m: model.addVar(lb=0, ub=buy_fast_capacity, name=f"buy_fast_{m}") for m in months}
sell = {m: model.addVar(lb=0, name=f"sell_{m}") for m in months}
stock = {m: model.addVar(lb=0, ub=warehouse_capacity, name=f"stock_{m}") for m in months}
funds = {m: model.addVar(lb=0, name=f"funds_{m}") for m in months}
credit = {m: model.addVar(lb=0, ub=credit_limit, name=f"credit_{m}") for m in months}
interest = {m: model.addVar(lb=0, name=f"interest_{m}") for m in months}

# Constraints for each month
for m in months:
    prev_stock = initial_stock if m == 1 else stock[m - 1]
    prev_funds = initial_funds if m == 1 else funds[m - 1]
    prev_credit = 0 if m == 1 else credit[m - 1]

    # Stock balance
    model.addConstr(stock[m] == prev_stock - sell[m] + buy_reg[m] + buy_fast[m], f"stock_balance_{m}")
    
    # Sell limit
    model.addConstr(sell[m] <= prev_stock, f"sell_limit_{m}")
    
    # Min inventory
    model.addConstr(stock[m] >= min_inventory[m], f"min_inv_{m}")

    # Interest
    model.addConstr(interest[m] == credit[m] * monthly_interest_rate, f"interest_calc_{m}")

    # Funds balance
    revenue = sell[m] * selling_prices[m]
    cost_reg = buy_reg[m] * purchase_prices[m]
    cost_fast = buy_fast[m] * purchase_prices[m] * (1 + fast_purchase_premium_ratio)
    
    model.addConstr(funds[m] - credit[m] == prev_funds - prev_credit + revenue - cost_reg - cost_fast - interest[m], f"funds_balance_{m}")

# End of quarter inventory requirement
model.addConstr(stock[months[-1]] >= end_inventory, "end_inventory")

# Objective: maximize final net funds - initial funds - total interest
total_interest = gp.quicksum(interest[m] for m in months)
model.setObjective(funds[months[-1]] - credit[months[-1]] - initial_funds - total_interest, GRB.MAXIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: None")
