import os
import csv
from itertools import product
import gurobipy as gp
from gurobipy import GRB

def load_csv(filepath):
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

def solve():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    params_file = os.path.join(base_dir, 'data', 'general_parameters.csv')
    table_file = os.path.join(base_dir, 'data', 'table_1.csv')
    
    params_data = load_csv(params_file)
    params = {row['Parameter_Name']: float(row['Value']) for row in params_data}
    
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    
    budget_A = params['total_budget_scenario_A']
    budget_B = params['total_budget_scenario_B']
    weight_A = params['weight_limit_scenario_A']
    weight_B = params['weight_limit_scenario_B']
    
    table_data = load_csv(table_file)
    reliability = {}
    for row in table_data:
        n = int(row['Number_of_Spares'])
        reliability[n] = [
            float(row['Component_1_Reliability']),
            float(row['Component_2_Reliability']),
            float(row['Component_3_Reliability'])
        ]
        
    spares_options = list(reliability.keys())
    
    model = gp.Model("SpareParts")
    model.setParam('OutputFlag', 0)
    
    y = {}
    for s1, s2, s3 in product(spares_options, repeat=3):
        y[s1, s2, s3] = model.addVar(vtype=GRB.BINARY, name=f"y_{s1}_{s2}_{s3}")
        
    model.addConstr(gp.quicksum(y[s1, s2, s3] for s1, s2, s3 in product(spares_options, repeat=3)) == 1)
    
    # Cost constraints
    model.addConstr(
        gp.quicksum((s1*unit_price[0] + s2*unit_price[1] + s3*unit_price[2]) * y[s1, s2, s3] 
                    for s1, s2, s3 in product(spares_options, repeat=3)) <= budget_A
    )
    model.addConstr(
        gp.quicksum((s1*unit_price[0] + s2*unit_price[1] + s3*unit_price[2]) * y[s1, s2, s3] 
                    for s1, s2, s3 in product(spares_options, repeat=3)) <= budget_B
    )
    
    # Weight constraints
    model.addConstr(
        gp.quicksum((s1*unit_weight[0] + s2*unit_weight[1] + s3*unit_weight[2]) * y[s1, s2, s3] 
                    for s1, s2, s3 in product(spares_options, repeat=3)) <= weight_A
    )
    model.addConstr(
        gp.quicksum((s1*unit_weight[0] + s2*unit_weight[1] + s3*unit_weight[2]) * y[s1, s2, s3] 
                    for s1, s2, s3 in product(spares_options, repeat=3)) <= weight_B
    )
    
    # Objective
    obj = gp.quicksum(
        (reliability[s1][0] * reliability[s2][1] * reliability[s3][2]) * y[s1, s2, s3]
        for s1, s2, s3 in product(spares_options, repeat=3)
    )
    
    model.setObjective(obj, GRB.MAXIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: 0.0")

if __name__ == '__main__':
    solve()
