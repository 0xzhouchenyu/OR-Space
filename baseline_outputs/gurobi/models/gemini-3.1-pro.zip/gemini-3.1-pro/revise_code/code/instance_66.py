import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    toys = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                'type': row['Toy_Type'],
                'labor': float(row['Manufacturing_Labor_Hours']),
                'inspection': float(row['Inspection_Hours']),
                'profit': float(row['Profit_Per_Unit'])
            })

    periods = [1, 2]
    
    demands = {}
    demands[(1, 'High-End')] = params['max_demand_high_end_period1']
    demands[(1, 'Mid-Range')] = params['max_demand_mid_range_period1']
    demands[(1, 'Low-End')] = params['max_demand_low_end_period1']
    demands[(2, 'High-End')] = params['max_demand_high_end_period2']
    demands[(2, 'Mid-Range')] = params['max_demand_mid_range_period2']
    demands[(2, 'Low-End')] = params['max_demand_low_end_period2']

    avail_labor = {
        1: params['available_labor_hours_period1'],
        2: params['available_labor_hours_period2']
    }
    avail_inspection = {
        1: params['available_inspection_hours_period1'],
        2: params['available_inspection_hours_period2']
    }

    model = gp.Model("ToyProduction")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = {}
    for p in periods:
        for toy in toys:
            x[(p, toy['type'])] = model.addVar(lb=0, ub=demands[(p, toy['type'])], vtype=GRB.CONTINUOUS, name=f"x_{p}_{toy['type']}")

    ot = {}
    for p in periods:
        ot[p] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"ot_{p}")

    total_ot = model.addVar(lb=0, ub=params['overtime_labor_cap'], vtype=GRB.CONTINUOUS, name="total_ot")
    
    ot_fatigue_indicator = model.addVar(vtype=GRB.BINARY, name="ot_fatigue_ind")
    ot_review_indicator = model.addVar(vtype=GRB.BINARY, name="ot_review_ind")

    model.addConstr(total_ot == ot[1] + ot[2])

    # Inspection hours
    for p in periods:
        model.addConstr(
            gp.quicksum(x[(p, toy['type'])] * toy['inspection'] for toy in toys) <= avail_inspection[p],
            name=f"Insp_{p}"
        )

    # Labor hours
    model.addConstr(
        gp.quicksum(x[(1, toy['type'])] * toy['labor'] for toy in toys) <= avail_labor[1] + ot[1],
        name="Labor_1"
    )
    
    model.addConstr(
        gp.quicksum(x[(2, toy['type'])] * toy['labor'] for toy in toys) <= avail_labor[2] - params['period2_labor_recovery_loss'] * ot_fatigue_indicator + ot[2],
        name="Labor_2"
    )

    # Big-M constraints for indicators
    M_ot = params['overtime_labor_cap']
    model.addConstr(ot[1] - params['period1_overtime_fatigue_threshold'] <= M_ot * ot_fatigue_indicator)
    model.addConstr(total_ot - params['overtime_review_threshold'] <= M_ot * ot_review_indicator)

    # Objective
    profit = gp.quicksum(x[(p, toy['type'])] * toy['profit'] for p in periods for toy in toys)
    cost = total_ot * params['overtime_labor_cost'] + ot_review_indicator * params['seasonal_safety_review_fee']
    
    model.setObjective(profit - cost, GRB.MAXIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
