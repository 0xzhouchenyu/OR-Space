import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    initial_capital = 500000.0
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'].strip() == 'initial_capital':
                initial_capital = float(row['Value'].strip())
                
    min_year3_reserve = 80000.0
    reserve_shortfall_penalty = 0.5
    with open(os.path.join(data_dir, 'liquidity_policy.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'].strip() == 'min_year3_reserve':
                min_year3_reserve = float(row['Value'].strip())
            elif row['Parameter_Name'].strip() == 'reserve_shortfall_penalty':
                reserve_shortfall_penalty = float(row['Value'].strip())

    m = gp.Model("Investment_Maximization_Revised")
    m.setParam('OutputFlag', 0)

    x1_1 = m.addVar(lb=0, name="x1_1")
    x1_2 = m.addVar(lb=0, name="x1_2")
    x1_3 = m.addVar(lb=0, name="x1_3")
    x2 = m.addVar(lb=0, ub=120000, name="x2")
    x3 = m.addVar(lb=0, ub=150000, name="x3")
    x4 = m.addVar(lb=0, ub=100000, name="x4")
    
    s1 = m.addVar(lb=0, name="s1")
    s2 = m.addVar(lb=0, name="s2")
    s3 = m.addVar(lb=0, name="s3")
    
    shortfall = m.addVar(lb=0, name="shortfall")

    m.addConstr(x1_1 + x2 + s1 == initial_capital, "Year1_Budget")
    m.addConstr(x1_2 + x3 + s2 == s1 + x1_1 * 1.20, "Year2_Budget")
    m.addConstr(x1_3 + x4 + s3 == s2 + x1_2 * 1.20 + x2 * 1.50 + x3 * 1.60, "Year3_Budget")

    m.addConstr(shortfall >= min_year3_reserve - s3, "Shortfall_Def")

    total_end_year3 = x1_3 * 1.20 + x4 * 1.40 + s3
    objective = total_end_year3 - reserve_shortfall_penalty * shortfall

    m.setObjective(objective, GRB.MAXIMIZE)
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == '__main__':
    solve()
