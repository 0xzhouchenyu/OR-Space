import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read general parameters
    full_time_cost = 1.0
    part_time_cost = 0.7
    part_time_cap = 6
    min_full_time = 8
    
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param = row['Parameter_Name'].strip()
            val = row['Value'].strip()
            if param == 'full_time_cost':
                full_time_cost = float(val)
            elif param == 'part_time_cost':
                part_time_cost = float(val)
            elif param == 'part_time_cap_per_period':
                part_time_cap = int(val)
            elif param == 'min_full_time_per_period':
                min_full_time = int(val)
                
    # Read requirements
    req_values = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            req_values.append(int(row['Required_Salespeople'].strip()))
            
    n = len(req_values)
    
    # Model
    model = gp.Model("MinCost")
    model.setParam('OutputFlag', 0)
    
    # Variables
    F = model.addVars(n, vtype=GRB.INTEGER, lb=0, name="F")
    P = model.addVars(n, vtype=GRB.INTEGER, lb=0, ub=part_time_cap, name="P")
    
    # Objective
    model.setObjective(
        gp.quicksum(full_time_cost * F[i] for i in range(n)) + 
        gp.quicksum(part_time_cost * P[i] for i in range(n)), 
        GRB.MINIMIZE
    )
    
    # Constraints
    for i in range(n):
        f_present = F[i] + F[(i - 1) % n]
        # Total coverage
        model.addConstr(f_present + P[i] >= req_values[i], name=f"cov_{i}")
        # Min full time
        model.addConstr(f_present >= min_full_time, name=f"min_ft_{i}")
        
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
