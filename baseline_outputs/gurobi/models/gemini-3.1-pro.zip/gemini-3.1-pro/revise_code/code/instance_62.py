import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    
    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
            
    budget = params['investment_budget']
    premium_revenue_uplift = params['premium_revenue_uplift']
    premium_upgrade_cost = params['premium_upgrade_cost']
    staff_hours_cap = params['staff_hours_cap']
    
    # Load restaurant data
    restaurants = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'standard_staff': float(row['Standard_Staff_Hours'].strip()),
                'premium_staff': float(row['Premium_Staff_Hours'].strip())
            })
            
    # Create model
    model = gp.Model("Restaurant_Investment_Revised")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    x_std = {}
    x_prm = {}
    for r in restaurants:
        name = r['name']
        x_std[name] = model.addVar(vtype=GRB.BINARY, name=f"std_{name}")
        x_prm[name] = model.addVar(vtype=GRB.BINARY, name=f"prm_{name}")
        
    # Each restaurant can be at most one mode
    for r in restaurants:
        name = r['name']
        model.addConstr(x_std[name] + x_prm[name] <= 1, name=f"mode_{name}")
        
    # Objective
    obj = gp.quicksum(
        r['revenue'] * x_std[r['name']] + r['revenue'] * (1 + premium_revenue_uplift) * x_prm[r['name']]
        for r in restaurants
    )
    model.setObjective(obj, GRB.MAXIMIZE)
    
    # Budget constraint
    model.addConstr(
        gp.quicksum(
            r['cost'] * x_std[r['name']] + (r['cost'] + premium_upgrade_cost) * x_prm[r['name']]
            for r in restaurants
        ) <= budget,
        name="Budget_Constraint"
    )
    
    # Staff hours constraint
    model.addConstr(
        gp.quicksum(
            r['standard_staff'] * x_std[r['name']] + r['premium_staff'] * x_prm[r['name']]
            for r in restaurants
        ) <= staff_hours_cap,
        name="Staff_Hours_Constraint"
    )
    
    # Mutual exclusion D and A
    if 'Restaurant_D' in x_std and 'Restaurant_A' in x_std:
        model.addConstr(
            (x_std['Restaurant_D'] + x_prm['Restaurant_D']) + 
            (x_std['Restaurant_A'] + x_prm['Restaurant_A']) <= 1,
            name="D_A_Exclusion"
        )
        
    # Solve
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
