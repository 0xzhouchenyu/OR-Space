import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
            
    warehouse_capacity = params['warehouse_capacity']
    initial_stock = params['initial_stock']
    fixed_order_cost = params['fixed_order_cost']
    august_bulk_order_threshold = params['august_bulk_order_threshold']
    august_bulk_receiving_fee = params['august_bulk_receiving_fee']
    
    months = []
    buy_price = {}
    sell_price = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = int(row['Month'])
            months.append(m)
            buy_price[m] = float(row['Buy'])
            sell_price[m] = float(row['Sell'])
            
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    buy = model.addVars(months, vtype=GRB.CONTINUOUS, lb=0, name="buy")
    sell = model.addVars(months, vtype=GRB.CONTINUOUS, lb=0, name="sell")
    stock = model.addVars(months, vtype=GRB.CONTINUOUS, lb=0, ub=warehouse_capacity, name="stock")
    has_buy = model.addVars(months, vtype=GRB.BINARY, name="has_buy")
    aug_bulk = model.addVar(vtype=GRB.BINARY, name="aug_bulk")
    
    for i, m in enumerate(months):
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_stock = stock[months[i-1]]
            
        model.addConstr(stock[m] == prev_stock + buy[m] - sell[m])
        model.addConstr(prev_stock + buy[m] <= warehouse_capacity)
        model.addConstr(buy[m] <= warehouse_capacity * has_buy[m])
        
    # August bulk order constraint
    model.addConstr(buy[8] - august_bulk_order_threshold <= (warehouse_capacity - august_bulk_order_threshold) * aug_bulk)
    
    obj = gp.quicksum(sell_price[m] * sell[m] - buy_price[m] * buy[m] - fixed_order_cost * has_buy[m] for m in months) - august_bulk_receiving_fee * aug_bulk
    
    model.setObjective(obj, GRB.MAXIMIZE)
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
