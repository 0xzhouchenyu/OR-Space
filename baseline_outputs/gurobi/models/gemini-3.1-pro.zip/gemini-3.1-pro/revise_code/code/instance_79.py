import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    sell_price_table = params['sell_price_table']
    sell_price_chair = params['sell_price_chair']
    sell_price_bookshelf = params['sell_price_bookshelf']

    cost_table = params['manufacturing_cost_table']
    cost_chair = params['manufacturing_cost_chair']
    cost_bookshelf = params['manufacturing_cost_bookshelf']

    space_table = params['warehouse_space_table']
    space_chair = params['warehouse_space_chair']
    space_bookshelf = params['warehouse_space_bookshelf']

    max_warehouse = params['max_warehouse_space']
    min_tables = params['min_tables']
    min_bookshelves = params['min_bookshelves']
    max_total = params['max_total_items']

    labor_table = params['labor_hours_table']
    labor_chair = params['labor_hours_chair']
    labor_bookshelf = params['labor_hours_bookshelf']

    max_labor_reg = params['max_labor_hours_month_regular']
    max_labor_rush = params['max_labor_hours_month_rush']
    max_rush_items = params['max_rush_items_month']

    bonus_table = params['rush_profit_bonus_table']
    bonus_chair = params['rush_profit_bonus_chair']
    bonus_bookshelf = params['rush_profit_bonus_bookshelf']

    profit_reg_table = sell_price_table - cost_table
    profit_reg_chair = sell_price_chair - cost_chair
    profit_reg_bookshelf = sell_price_bookshelf - cost_bookshelf

    profit_rush_table = profit_reg_table + bonus_table
    profit_rush_chair = profit_reg_chair + bonus_chair
    profit_rush_bookshelf = profit_reg_bookshelf + bonus_bookshelf

    model = gp.Model("Furniture_Production_Revised")
    model.setParam('OutputFlag', 0)

    x_reg_table = model.addVar(lb=0, vtype=GRB.INTEGER, name="reg_tables")
    x_reg_chair = model.addVar(lb=0, vtype=GRB.INTEGER, name="reg_chairs")
    x_reg_bookshelf = model.addVar(lb=0, vtype=GRB.INTEGER, name="reg_bookshelves")

    x_rush_table = model.addVar(lb=0, vtype=GRB.INTEGER, name="rush_tables")
    x_rush_chair = model.addVar(lb=0, vtype=GRB.INTEGER, name="rush_chairs")
    x_rush_bookshelf = model.addVar(lb=0, vtype=GRB.INTEGER, name="rush_bookshelves")

    model.setObjective(
        profit_reg_table * x_reg_table + profit_reg_chair * x_reg_chair + profit_reg_bookshelf * x_reg_bookshelf +
        profit_rush_table * x_rush_table + profit_rush_chair * x_rush_chair + profit_rush_bookshelf * x_rush_bookshelf,
        GRB.MAXIMIZE
    )

    # Constraints
    model.addConstr(
        space_table * (x_reg_table + x_rush_table) +
        space_chair * (x_reg_chair + x_rush_chair) +
        space_bookshelf * (x_reg_bookshelf + x_rush_bookshelf) <= max_warehouse,
        "Warehouse_Space"
    )

    model.addConstr(x_reg_table + x_rush_table >= min_tables, "Min_Tables")
    model.addConstr(x_reg_bookshelf + x_rush_bookshelf >= min_bookshelves, "Min_Bookshelves")

    model.addConstr(
        x_reg_table + x_reg_chair + x_reg_bookshelf +
        x_rush_table + x_rush_chair + x_rush_bookshelf <= max_total,
        "Max_Total_Items"
    )

    model.addConstr(
        labor_table * x_reg_table + labor_chair * x_reg_chair + labor_bookshelf * x_reg_bookshelf <= max_labor_reg,
        "Max_Labor_Regular"
    )

    model.addConstr(
        labor_table * x_rush_table + labor_chair * x_rush_chair + labor_bookshelf * x_rush_bookshelf <= max_labor_rush,
        "Max_Labor_Rush"
    )

    model.addConstr(
        x_rush_table + x_rush_chair + x_rush_bookshelf <= max_rush_items,
        "Max_Rush_Items"
    )

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
