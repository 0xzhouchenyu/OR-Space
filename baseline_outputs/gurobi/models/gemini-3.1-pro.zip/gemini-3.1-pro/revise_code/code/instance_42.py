import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))
    
    a = params['a']
    m_offpeak = params['m_offpeak']
    b = params['b']
    n_offpeak = params['n_offpeak']
    k = params['k']
    d = params['d']
    c_offpeak = params['c_offpeak']
    c_peak = params['c_peak']
    cap_offpeak = params['cap_offpeak']
    cap_peak = params['cap_peak']
    m_peak = params['m_peak']
    n_peak = params['n_peak']
    f_offpeak = params['f_offpeak']
    f_peak = params['f_peak']
    cooldown_threshold = params['offpeak_cooldown_batch_threshold']
    cooldown_fee = params['offpeak_cooldown_fee']
    
    model = gp.Model("RevisedSteelFurnace")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    # x[i, j, p] = batches for furnace i, method j, period p
    # i in {1, 2}, j in {1, 2}, p in {'offpeak', 'peak'}
    x = {}
    for i in [1, 2]:
        for j in [1, 2]:
            for p in ['offpeak', 'peak']:
                x[i, j, p] = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name=f"x_{i}_{j}_{p}")
                
    # y[i, p] = 1 if furnace i is used in period p
    y = {}
    for i in [1, 2]:
        for p in ['offpeak', 'peak']:
            y[i, p] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{p}")
            
    # z[i] = 1 if furnace i exceeds cooldown threshold in off-peak
    z = {}
    for i in [1, 2]:
        z[i] = model.addVar(vtype=GRB.BINARY, name=f"z_{i}")
        
    # Objective function
    fuel_cost = gp.quicksum(
        m_offpeak * x[i, 1, 'offpeak'] + n_offpeak * x[i, 2, 'offpeak'] +
        m_peak * x[i, 1, 'peak'] + n_peak * x[i, 2, 'peak']
        for i in [1, 2]
    )
    
    fixed_cost = gp.quicksum(
        f_offpeak * y[i, 'offpeak'] + f_peak * y[i, 'peak']
        for i in [1, 2]
    )
    
    cooldown_cost = gp.quicksum(cooldown_fee * z[i] for i in [1, 2])
    
    model.setObjective(fuel_cost + fixed_cost + cooldown_cost, GRB.MINIMIZE)
    
    # Constraints
    # 1. Time per furnace per period & linking y
    for i in [1, 2]:
        model.addConstr(a * x[i, 1, 'offpeak'] + b * x[i, 2, 'offpeak'] <= c_offpeak * y[i, 'offpeak'])
        model.addConstr(a * x[i, 1, 'peak'] + b * x[i, 2, 'peak'] <= c_peak * y[i, 'peak'])
        
    # 2. Plant-wide max time
    model.addConstr(gp.quicksum(a * x[i, 1, 'offpeak'] + b * x[i, 2, 'offpeak'] for i in [1, 2]) <= cap_offpeak)
    model.addConstr(gp.quicksum(a * x[i, 1, 'peak'] + b * x[i, 2, 'peak'] for i in [1, 2]) <= cap_peak)
    
    # 3. Minimum production
    model.addConstr(gp.quicksum(k * x[i, j, p] for i in [1, 2] for j in [1, 2] for p in ['offpeak', 'peak']) >= d)
    
    # 4. Cooldown logic
    # Max possible off-peak batches for a single furnace is c_offpeak / min(a, b)
    max_batches = c_offpeak / min(a, b)
    big_M = max_batches
    for i in [1, 2]:
        model.addConstr(x[i, 1, 'offpeak'] + x[i, 2, 'offpeak'] <= cooldown_threshold + big_M * z[i])
        
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
