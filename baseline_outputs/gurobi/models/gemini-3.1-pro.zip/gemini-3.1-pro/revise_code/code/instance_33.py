import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Value']:
                try:
                    params[row['Parameter_Name']] = float(row['Value'])
                except ValueError:
                    params[row['Parameter_Name']] = row['Value']

    son1_min_share = params.get('son1_min_share', 0.5)
    high_value_threshold = params.get('high_value_threshold', 15000)
    max_hv_items = int(params.get('max_high_value_items_per_son', 3))
    max_def_diamonds = int(params.get('deferred_diamonds_per_son', 1))
    imm_tax_weight = params.get('immediate_tax_weight', 1.0)
    tot_tax_weight = params.get('total_tax_weight', 0.2)

    # Read items
    items = []
    values = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append(row['Item'].strip())
            values.append(float(row['Value'].strip()))

    n = len(items)
    total_value = sum(values)

    model = gp.Model("Inheritance_Split_Revised")
    model.setParam('OutputFlag', 0)

    # Variables
    # x[i, s, t] = 1 if item i goes to son s (0=son1, 1=son2) at time t (0=imm, 1=def)
    x = model.addVars(n, 2, 2, vtype=GRB.BINARY, name="x")

    # Each item assigned to exactly one son, one timing
    for i in range(n):
        model.addConstr(gp.quicksum(x[i, s, t] for s in range(2) for t in range(2)) == 1)

    # y[i, s] = 1 if item i goes to son s
    y = {}
    for i in range(n):
        for s in range(2):
            y[i, s] = x[i, s, 0] + x[i, s, 1]

    # Son 1 min share
    model.addConstr(gp.quicksum(values[i] * y[i, 0] for i in range(n)) >= son1_min_share * total_value)

    # High value items concentration
    for s in range(2):
        model.addConstr(
            gp.quicksum(y[i, s] for i in range(n) if values[i] > high_value_threshold) <= max_hv_items
        )

    # Deferred diamonds per son
    for s in range(2):
        model.addConstr(
            gp.quicksum(x[i, s, 1] for i in range(n) if 'Diamond' in items[i]) <= max_def_diamonds
        )

    # Jack Russell condition
    jr_indices = [i for i, item in enumerate(items) if 'Jack Russell' in item]
    if len(jr_indices) == 2:
        model.addConstr(y[jr_indices[0], 0] == y[jr_indices[1], 0])

    # Imbalances
    imm_val_0 = gp.quicksum(values[i] * x[i, 0, 0] for i in range(n))
    imm_val_1 = gp.quicksum(values[i] * x[i, 1, 0] for i in range(n))
    diff_imm = model.addVar(lb=0, name="diff_imm")
    model.addConstr(diff_imm >= imm_val_0 - imm_val_1)
    model.addConstr(diff_imm >= imm_val_1 - imm_val_0)

    tot_val_0 = gp.quicksum(values[i] * y[i, 0] for i in range(n))
    tot_val_1 = gp.quicksum(values[i] * y[i, 1] for i in range(n))
    diff_tot = model.addVar(lb=0, name="diff_tot")
    model.addConstr(diff_tot >= tot_val_0 - tot_val_1)
    model.addConstr(diff_tot >= tot_val_1 - tot_val_0)

    # Objective
    model.setObjective(imm_tax_weight * diff_imm + tot_tax_weight * diff_tot, GRB.MINIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    solve()
