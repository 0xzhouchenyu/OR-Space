import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    # Read time periods and minimum waiters needed
    time_periods = []
    min_waiters = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            time_periods.append(row['Time'].strip())
            min_waiters.append(int(row['Minimum_Number_of_Waiters_Needed'].strip()))

    n = len(time_periods)

    # Read general parameters
    peak = [0] * n
    quality = [0] * n
    waiter_cost = 0
    waiter_budget = 0

    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            if name.startswith('peak_'):
                idx = int(name.split('_')[1])
                peak[idx] = int(val)
            elif name.startswith('quality_'):
                idx = int(name.split('_')[1])
                quality[idx] = val
            elif name == 'waiter_cost_per_shift':
                waiter_cost = val
            elif name == 'waiter_budget':
                waiter_budget = val

    model = gp.Model("Restaurant_Waiters")
    model.setParam('OutputFlag', 0)

    # Decision variables
    x = []
    for i in range(n):
        x.append(model.addVar(vtype=GRB.INTEGER, lb=0, name=f"x_{i}"))

    # Constraints for valid shifts
    for i in range(n):
        next_i = (i + 1) % n
        if peak[i] + peak[next_i] != 1:
            model.addConstr(x[i] == 0, f"ValidShift_{i}")

    # Demand constraints
    working_waiters = []
    for j in range(n):
        prev_j = (j - 1) % n
        working = x[prev_j] + x[j]
        working_waiters.append(working)
        model.addConstr(working >= min_waiters[j], f"Demand_{j}")

    # Budget constraint
    total_cost = gp.quicksum(x[i] * waiter_cost for i in range(n))
    model.addConstr(total_cost <= waiter_budget, "Budget")

    # Objective: maximize service quality score
    total_quality = gp.quicksum(working_waiters[j] * quality[j] for j in range(n))
    model.setObjective(total_quality, GRB.MAXIMIZE)

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    main()
