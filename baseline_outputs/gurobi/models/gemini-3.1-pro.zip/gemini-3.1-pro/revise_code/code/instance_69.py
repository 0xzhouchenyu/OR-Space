import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'general_parameters.csv')
    df = pd.read_csv(data_path)
    
    params = {}
    for _, row in df.iterrows():
        params[row['Parameter_Name']] = float(row['Value'])
        
    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params.get('batch_5m_quantity', 0))
    L = int(params['raw_bar_length'])
    setup_cost = params.get('setup_cost_per_pattern', 0.0)
    max_patterns = int(params.get('max_distinct_patterns', 1000))
    
    len1 = 3
    len2 = 4
    len3 = 5
    
    patterns = []
    for x in range(L // len1 + 1):
        for y in range(L // len2 + 1):
            for z in range(L // len3 + 1):
                if len1 * x + len2 * y + len3 * z <= L:
                    if x > 0 or y > 0 or z > 0:
                        patterns.append((x, y, z))
                        
    model = gp.Model("CuttingStockRevised")
    model.setParam('OutputFlag', 0)
    
    num_patterns = len(patterns)
    v = model.addVars(num_patterns, vtype=GRB.INTEGER, lb=0, name="v")
    y = model.addVars(num_patterns, vtype=GRB.BINARY, name="y")
    
    M = q3 + q4 + q5
    
    for i in range(num_patterns):
        model.addConstr(v[i] <= M * y[i])
        
    model.addConstr(gp.quicksum(patterns[i][0] * v[i] for i in range(num_patterns)) >= q3)
    model.addConstr(gp.quicksum(patterns[i][1] * v[i] for i in range(num_patterns)) >= q4)
    model.addConstr(gp.quicksum(patterns[i][2] * v[i] for i in range(num_patterns)) >= q5)
    
    model.addConstr(gp.quicksum(y[i] for i in range(num_patterns)) <= max_patterns)
    
    total_raw_length = gp.quicksum(L * v[i] for i in range(num_patterns))
    total_required_length = len1 * q3 + len2 * q4 + len3 * q5
    total_setup_cost = gp.quicksum(setup_cost * y[i] for i in range(num_patterns))
    
    model.setObjective(total_raw_length - total_required_length + total_setup_cost, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    solve()
