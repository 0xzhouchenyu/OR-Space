import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load candidate data
    candidates = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            candidates.append({
                'name': row['Candidate'].strip(),
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            })

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    max_employees = int(params['max_employees'])
    budget_limit = params['budget_limit']
    min_advanced = int(params['min_advanced_degree_candidates'])
    min_experience = params['min_work_experience']
    max_equivalent = int(params['max_equivalent_candidates'])
    min_employees = int(params['min_employees'])
    min_managers = int(params['min_managers'])
    max_managers = int(params['max_managers'])
    min_manager_experience = params['min_manager_experience']
    manager_bonus_per_candidate = params['manager_bonus_per_candidate']

    # Create optimization model
    model = gp.Model("Recruitment")
    model.setParam('OutputFlag', 0)

    # Decision variables: binary for each candidate and role
    x = {}
    y = {}
    roles = ['Manager', 'Specialist']
    for c in candidates:
        name = c['name']
        y[name] = model.addVar(vtype=GRB.BINARY, name=f"y_{name}")
        for r in roles:
            x[(name, r)] = model.addVar(vtype=GRB.BINARY, name=f"x_{name}_{r}")

    # A candidate is hired if assigned to any role
    for c in candidates:
        name = c['name']
        model.addConstr(y[name] == x[(name, 'Manager')] + x[(name, 'Specialist')])
        model.addConstr(y[name] <= 1)

    # Objective: minimize total salary + manager bonus
    obj = gp.quicksum(c['salary'] * y[c['name']] for c in candidates) + \
          gp.quicksum(manager_bonus_per_candidate * x[(c['name'], 'Manager')] for c in candidates)
    model.setObjective(obj, GRB.MINIMIZE)

    # Constraint 1: max and min employees
    model.addConstr(gp.quicksum(y[c['name']] for c in candidates) <= max_employees)
    model.addConstr(gp.quicksum(y[c['name']] for c in candidates) >= min_employees)

    # Constraint 2: budget (excluding manager bonus)
    model.addConstr(gp.quicksum(c['salary'] * y[c['name']] for c in candidates) <= budget_limit)

    # Constraint 3: at least one with Master's or Doctoral degree
    advanced_candidates = [c for c in candidates if c['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(y[c['name']] for c in advanced_candidates) >= min_advanced)

    # Constraint 4: minimum total work experience
    model.addConstr(gp.quicksum(c['experience'] * y[c['name']] for c in candidates) >= min_experience)

    # Constraint 5: at most one from pair A and E
    model.addConstr(y['A'] + y['E'] <= max_equivalent)

    # Constraint 6: Managers count
    model.addConstr(gp.quicksum(x[(c['name'], 'Manager')] for c in candidates) >= min_managers)
    model.addConstr(gp.quicksum(x[(c['name'], 'Manager')] for c in candidates) <= max_managers)

    # Constraint 7: Manager experience
    model.addConstr(gp.quicksum(c['experience'] * x[(c['name'], 'Manager')] for c in candidates) >= min_manager_experience)

    # Solve
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    main()
