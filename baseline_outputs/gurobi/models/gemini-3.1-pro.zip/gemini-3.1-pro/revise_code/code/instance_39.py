import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    motorcycle_pollution = params['motorcycle_pollution']
    small_truck_pollution = params['small_truck_pollution']
    large_truck_pollution = params['large_truck_pollution']
    max_motorcycle_trips = int(params['max_motorcycle_trips'])
    motorcycle_capacity = params['motorcycle_capacity']
    small_truck_capacity = params['small_truck_capacity']
    large_truck_capacity = params['large_truck_capacity']
    max_total_trips = int(params['max_total_trips'])
    demand_peak = params['demand_peak_units']
    demand_offpeak = params['demand_offpeak_units']
    leasing_capacity = params['leasing_capacity']
    leasing_pollution_per_unit = params['leasing_pollution_per_unit']
    leasing_fixed_pollution = params['leasing_fixed_pollution']
    max_leasing_fraction_peak = params['max_leasing_fraction_peak']
    bigM_leasing = params['bigM_leasing']
    epsilon = params['epsilon']

    methods = ['motorcycle', 'small_truck', 'large_truck']
    periods = ['peak', 'offpeak']

    pollution = {
        'motorcycle': motorcycle_pollution,
        'small_truck': small_truck_pollution,
        'large_truck': large_truck_pollution
    }

    capacity = {
        'motorcycle': motorcycle_capacity,
        'small_truck': small_truck_capacity,
        'large_truck': large_truck_capacity
    }

    model = gp.Model("Transport_Revised")
    model.setParam('OutputFlag', 0)

    # Variables
    trips = {}
    for p in periods:
        for m in methods:
            trips[p, m] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"trips_{p}_{m}")

    leased = {}
    for p in periods:
        leased[p] = model.addVar(vtype=GRB.CONTINUOUS, lb=0, name=f"leased_{p}")

    method_used = {}
    for m in methods:
        method_used[m] = model.addVar(vtype=GRB.BINARY, name=f"used_{m}")

    leasing_used = model.addVar(vtype=GRB.BINARY, name="leasing_used")

    # Objective
    total_pollution = gp.quicksum(pollution[m] * (trips['peak', m] + trips['offpeak', m]) for m in methods) \
                      + leasing_pollution_per_unit * (leased['peak'] + leased['offpeak']) \
                      + leasing_fixed_pollution * leasing_used
    model.setObjective(total_pollution, GRB.MINIMIZE)

    # Constraints
    # 2 out of 3 methods
    model.addConstr(gp.quicksum(method_used[m] for m in methods) <= 2, "max_2_methods")

    # Link trips to method_used
    for m in methods:
        model.addConstr(trips['peak', m] + trips['offpeak', m] <= max_total_trips * method_used[m], f"link_{m}")

    # Demand satisfaction
    model.addConstr(gp.quicksum(capacity[m] * trips['peak', m] for m in methods) + leased['peak'] >= demand_peak, "demand_peak")
    model.addConstr(gp.quicksum(capacity[m] * trips['offpeak', m] for m in methods) + leased['offpeak'] >= demand_offpeak, "demand_offpeak")

    # Max trips
    model.addConstr(gp.quicksum(trips[p, m] for p in periods for m in methods) <= max_total_trips, "max_total_trips")
    model.addConstr(trips['peak', 'motorcycle'] + trips['offpeak', 'motorcycle'] <= max_motorcycle_trips, "max_motorcycle_trips")

    # Leasing constraints
    total_leased = leased['peak'] + leased['offpeak']
    model.addConstr(total_leased <= leasing_capacity, "leasing_capacity")
    model.addConstr(total_leased <= bigM_leasing * leasing_used, "leasing_upper")
    model.addConstr(total_leased >= epsilon * leasing_used, "leasing_lower")
    model.addConstr(leased['peak'] <= max_leasing_fraction_peak * demand_peak, "max_leasing_peak")

    model.optimize()

    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    solve()
