import gurobipy as gp
from gurobipy import GRB
import csv
import os

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    materials = []
    sulfur_content = {}
    purchase_price = {}
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            mat = row['Material'].strip()
            materials.append(mat)
            for k, v in row.items():
                if 'Sulfur_Content' in k:
                    sulfur_content[mat] = float(v.strip())
                if 'Purchase_Price' in k:
                    purchase_price[mat] = float(v.strip())
                    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            for k, v in row.items():
                if 'Value' in k:
                    params[param_name] = float(v.strip())
                    
    products = ['A_premium', 'A_standard', 'B_premium', 'B_standard']
    
    max_sulfur = {
        'A_premium': params['max_sulfur_content_A_premium'],
        'A_standard': params['max_sulfur_content_A_standard'],
        'B_premium': params['max_sulfur_content_B_premium'],
        'B_standard': params['max_sulfur_content_B_standard'],
    }
    
    selling_price = {
        'A_premium': params['selling_price_A_premium'],
        'A_standard': params['selling_price_A_standard'],
        'B_premium': params['selling_price_B_premium'],
        'B_standard': params['selling_price_B_standard'],
    }
    
    model = gp.Model("Mixing_Problem")
    model.setParam('OutputFlag', 0)
    
    x = {}
    for m in materials:
        for p in products:
            x[m, p] = model.addVar(lb=0, name=f"x_{m}_{p}")
            
    # Objective: Maximize Profit
    revenue = gp.quicksum(selling_price[p] * x[m, p] for m in materials for p in products)
    cost = gp.quicksum(purchase_price[m] * x[m, p] for m in materials for p in products)
    model.setObjective(revenue - cost, GRB.MAXIMIZE)
    
    # Sulfur constraints
    for p in products:
        model.addConstr(
            gp.quicksum(sulfur_content[m] * x[m, p] for m in materials) <= 
            max_sulfur[p] * gp.quicksum(x[m, p] for m in materials),
            name=f"sulfur_{p}"
        )
        
    # Demand constraints
    total_A = gp.quicksum(x[m, 'A_premium'] for m in materials) + gp.quicksum(x[m, 'A_standard'] for m in materials)
    total_B = gp.quicksum(x[m, 'B_premium'] for m in materials) + gp.quicksum(x[m, 'B_standard'] for m in materials)
    
    model.addConstr(total_A <= params['market_demand_A'], name="demand_A")
    model.addConstr(total_B <= params['market_demand_B'], name="demand_B")
    
    # Supply constraints for D
    model.addConstr(gp.quicksum(x['D', p] for p in products) <= params['max_supply_D'], name="supply_D")
    
    # Premium share constraints
    vol_A_prem = gp.quicksum(x[m, 'A_premium'] for m in materials)
    model.addConstr(vol_A_prem >= params['min_premium_share_A'], name="min_prem_A")
    model.addConstr(vol_A_prem <= params['max_premium_share_A'], name="max_prem_A")
    
    vol_B_prem = gp.quicksum(x[m, 'B_premium'] for m in materials)
    model.addConstr(vol_B_prem >= params['min_premium_share_B'], name="min_prem_B")
    model.addConstr(vol_B_prem <= params['max_premium_share_B'], name="max_prem_B")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
