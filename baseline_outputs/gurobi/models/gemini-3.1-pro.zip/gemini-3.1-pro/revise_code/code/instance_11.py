import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    # Define paths
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    # Read CSVs
    df1 = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)
    
    # Parse Table 1
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]
    
    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])
    
    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])
    
    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp = float(row_cap['Inspection_hours_per_unit'])
    
    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])
    cost_asm = float(row_cost['Assembly_hours_per_unit'])
    
    # Parse Parameters
    def get_param(name):
        return float(df_params[df_params['Parameter_Name'] == name]['Value'].iloc[0])
        
    min_profit = get_param('min_weekly_profit')
    min_a = get_param('min_type_a_production')
    insp_a_M = get_param('insp_a_M')
    insp_b_M = get_param('insp_b_M')
    insp_a_E = get_param('insp_a_E')
    insp_b_E = get_param('insp_b_E')
    cap_ext = get_param('cap_ext')
    cost_insp_M = get_param('cost_insp_M')
    cost_insp_E = get_param('cost_insp_E')
    cost_ext = get_param('cost_ext')
    mode_fee_M = get_param('mode_fee_M')
    mode_fee_E = get_param('mode_fee_E')
    risk_penalty_M = get_param('risk_penalty_M')
    cost_insp_weight = get_param('cost_insp_weight')
    planning_horizon = int(get_param('planning_horizon_weeks'))
    idle_tolerance = get_param('idle_tolerance')
    
    # Create Gurobi model
    model = gp.Model("Motorcycle_Production")
    model.setParam('OutputFlag', 0)
    
    # Variables
    x_A = {}
    x_B = {}
    z_M = {}
    z_E = {}
    insp_in_M = {}
    insp_in_E = {}
    insp_ext = {}
    
    for t in range(planning_horizon):
        x_A[t] = model.addVar(lb=min_a, vtype=GRB.INTEGER, name=f"x_A_{t}")
        x_B[t] = model.addVar(lb=0, vtype=GRB.INTEGER, name=f"x_B_{t}")
        z_M[t] = model.addVar(vtype=GRB.BINARY, name=f"z_M_{t}")
        z_E[t] = model.addVar(vtype=GRB.BINARY, name=f"z_E_{t}")
        insp_in_M[t] = model.addVar(lb=0, name=f"insp_in_M_{t}")
        insp_in_E[t] = model.addVar(lb=0, name=f"insp_in_E_{t}")
        insp_ext[t] = model.addVar(lb=0, name=f"insp_ext_{t}")
        
    # Constraints and Expressions
    profits = []
    idle_costs = []
    
    for t in range(planning_horizon):
        # Mode selection
        model.addConstr(z_M[t] + z_E[t] == 1)
        
        # Capacity constraints
        model.addConstr(mfg_a * x_A[t] + mfg_b * x_B[t] <= cap_mfg)
        model.addConstr(asm_a * x_A[t] + asm_b * x_B[t] <= cap_asm)
        
        model.addConstr(insp_in_M[t] <= cap_insp * z_M[t])
        model.addConstr(insp_in_E[t] <= cap_insp * z_E[t])
        model.addConstr(insp_ext[t] <= cap_ext * z_E[t])
        
        # Inspection hours logic
        BIG_M = 10000
        req_M = insp_a_M * x_A[t] + insp_b_M * x_B[t]
        model.addConstr(insp_in_M[t] >= req_M - BIG_M * z_E[t])
        model.addConstr(insp_in_M[t] <= req_M + BIG_M * z_E[t])
        
        req_E = insp_a_E * x_A[t] + insp_b_E * x_B[t]
        model.addConstr(insp_in_E[t] + insp_ext[t] >= req_E - BIG_M * z_M[t])
        model.addConstr(insp_in_E[t] + insp_ext[t] <= req_E + BIG_M * z_M[t])
        
        # Profit constraint
        rev = price_a * x_A[t] + price_b * x_B[t]
        cost_mfg_total = cost_mfg * (mfg_a * x_A[t] + mfg_b * x_B[t])
        cost_asm_total = cost_asm * (asm_a * x_A[t] + asm_b * x_B[t])
        cost_insp_total = cost_insp_M * insp_in_M[t] + cost_insp_E * insp_in_E[t] + cost_ext * insp_ext[t]
        fees = mode_fee_M * z_M[t] + mode_fee_E * z_E[t]
        
        profit_t = rev - cost_mfg_total - cost_asm_total - cost_insp_total - fees
        model.addConstr(profit_t >= min_profit)
        profits.append(profit_t)
        
        # Idle time calculations
        idle_mfg = cap_mfg - (mfg_a * x_A[t] + mfg_b * x_B[t])
        idle_asm = cap_asm - (asm_a * x_A[t] + asm_b * x_B[t])
        idle_insp = cap_insp - (insp_in_M[t] + insp_in_E[t])
        
        idle_cost_t = cost_mfg * idle_mfg + cost_asm * idle_asm + cost_insp_weight * idle_insp + risk_penalty_M * z_M[t]
        idle_costs.append(idle_cost_t)
        
    total_idle_cost = gp.quicksum(idle_costs)
    total_profit = gp.quicksum(profits)
    
    # Step 1: Minimize Idle Cost + Risk Penalty
    model.setObjective(total_idle_cost, GRB.MINIMIZE)
    model.optimize()
    
    min_idle_val = model.ObjVal
    
    # Step 2: Maximize Profit
    model.addConstr(total_idle_cost <= min_idle_val + idle_tolerance)
    model.setObjective(total_profit, GRB.MAXIMIZE)
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == '__main__':
    solve()
