import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = row['Value']
            try:
                params[name] = float(val)
            except ValueError:
                params[name] = val
                
    students = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            students.append(row)
            
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    student_ids = [int(s['Student_ID']) for s in students]
    grad_students = {5, 6}
    undergrad_students = {1, 2, 3, 4}
    
    wages = {int(s['Student_ID']): float(s['Wage_CNY_per_hour']) for s in students}
    avail = {(int(s['Student_ID']), d): float(s[d]) for s in students for d in days}
    
    model = gp.Model()
    model.setParam('OutputFlag', 0)
    
    x = {}
    y = {}
    for i in student_ids:
        for d in days:
            x[i,d] = model.addVar(lb=0, ub=avail[i,d], vtype=GRB.CONTINUOUS, name=f"x_{i}_{d}")
            y[i,d] = model.addVar(vtype=GRB.BINARY, name=f"y_{i}_{d}")
            
    fee = params.get('daily_open_fee_cny', 12.0)
    model.setObjective(gp.quicksum(wages[i] * x[i,d] + fee * y[i,d] for i in student_ids for d in days), GRB.MINIMIZE)
    
    for d in days:
        model.addConstr(gp.quicksum(x[i,d] for i in student_ids) == 14)
        
    for i in student_ids:
        for d in days:
            model.addConstr(x[i,d] <= avail[i,d] * y[i,d])
            
    for i in student_ids:
        model.addConstr(gp.quicksum(y[i,d] for d in days) <= params['max_shifts_per_student'])
        
    for d in days:
        model.addConstr(gp.quicksum(y[i,d] for i in student_ids) <= params['max_students_per_day'])
        
    for i in student_ids:
        if i in grad_students:
            model.addConstr(gp.quicksum(x[i,d] for d in days) >= params['min_grad_hours'])
        else:
            model.addConstr(gp.quicksum(x[i,d] for d in days) >= params['min_undergrad_hours'])
            
    model.addConstr(
        gp.quicksum(x[i,d] for i in grad_students for d in days) >= params['min_grad_weekly_coverage_hours']
    )
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == '__main__':
    main()
