import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Read shift requirements
    shifts = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts.append({
                'shift': int(row['Shift']),
                'time': row['Time'],
                'required': int(row['Required_number'])
            })
    
    n = len(shifts)
    required = [s['required'] for s in shifts]
    
    # Read general parameters
    shift_duration = 8
    max_night_driver_fraction = 0.4
    max_night_crew_fraction = 0.5
    max_overtime_shifts = 20
    overtime_cost_factor = 1.5
    
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'shift_duration':
                shift_duration = int(row['Value'])
            elif row['Parameter_Name'] == 'max_night_driver_fraction':
                max_night_driver_fraction = float(row['Value'])
            elif row['Parameter_Name'] == 'max_night_crew_fraction':
                max_night_crew_fraction = float(row['Value'])
            elif row['Parameter_Name'] == 'max_overtime_shifts':
                max_overtime_shifts = int(row['Value'])
            elif row['Parameter_Name'] == 'overtime_cost_factor':
                overtime_cost_factor = float(row['Value'])
                
    periods_per_shift = shift_duration // 4
    
    model = gp.Model("BusScheduling")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    d = model.addVars(n, vtype=GRB.INTEGER, name="d", lb=0)
    od = model.addVars(n, vtype=GRB.INTEGER, name="od", lb=0)
    c = model.addVars(n, vtype=GRB.INTEGER, name="c", lb=0)
    oc = model.addVars(n, vtype=GRB.INTEGER, name="oc", lb=0)
    
    # Objective
    obj = gp.quicksum(d[i] + c[i] for i in range(n)) + overtime_cost_factor * gp.quicksum(od[i] + oc[i] for i in range(n))
    model.setObjective(obj, GRB.MINIMIZE)
    
    # Constraints
    for j in range(n):
        driver_cov = gp.quicksum(d[(j - k) % n] + od[(j - k) % n] for k in range(periods_per_shift))
        crew_cov = gp.quicksum(c[(j - k) % n] + oc[(j - k) % n] for k in range(periods_per_shift))
        model.addConstr(driver_cov >= required[j], name=f"Driver_Cov_{j}")
        model.addConstr(crew_cov >= required[j], name=f"Crew_Cov_{j}")
        
    # Night fractions
    night_driver = d[4] + od[4] + d[5] + od[5]
    total_driver = gp.quicksum(d[i] + od[i] for i in range(n))
    model.addConstr(night_driver <= max_night_driver_fraction * total_driver, name="Night_Driver_Frac")
    
    night_crew = c[4] + oc[4] + c[5] + oc[5]
    total_crew = gp.quicksum(c[i] + oc[i] for i in range(n))
    model.addConstr(night_crew <= max_night_crew_fraction * total_crew, name="Night_Crew_Frac")
    
    # Max overtime shifts
    model.addConstr(gp.quicksum(od[i] + oc[i] for i in range(n)) <= max_overtime_shifts, name="Max_Overtime")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
