import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    m1_liquid = params['machine_1_time_per_liquid_lot']
    m2_liquid = params['machine_2_time_per_liquid_lot']
    m1_solid = params['machine_1_time_per_solid_lot']
    m2_solid = params['machine_2_time_per_solid_lot']

    init_liquid = params['initial_liquid_inventory']
    init_solid = params['initial_solid_inventory']

    m1_avail = params['machine_1_available_time'] * 60
    m2_avail = params['machine_2_available_time'] * 60

    demand_liquid = params['forecast_liquid_demand']
    demand_solid = params['forecast_solid_demand']

    extended_extra_minutes = params['extended_extra_minutes']
    labor_hours_per_machine_extended = params['labor_hours_per_machine_extended']
    labor_budget_hours = params['labor_budget_hours']
    extended_mode_penalty = params['extended_mode_penalty']
    priority_reserve_lots = params['priority_reserve_lots']
    excess_reserve_credit = params['excess_reserve_credit']

    model = gp.Model("Fertilizer_Production_Revised")
    model.setParam('OutputFlag', 0)

    x_l = model.addVar(lb=0, name="x_liquid")
    x_s = model.addVar(lb=0, name="x_solid")
    
    ext_1 = model.addVar(vtype=GRB.BINARY, name="ext_1")
    ext_2 = model.addVar(vtype=GRB.BINARY, name="ext_2")

    end_liquid = model.addVar(lb=0, name="end_liquid")
    end_solid = model.addVar(lb=0, name="end_solid")

    end_liquid_priority = model.addVar(lb=0, ub=priority_reserve_lots, name="end_liquid_priority")
    end_liquid_excess = model.addVar(lb=0, name="end_liquid_excess")

    end_solid_priority = model.addVar(lb=0, ub=priority_reserve_lots, name="end_solid_priority")
    end_solid_excess = model.addVar(lb=0, name="end_solid_excess")

    model.addConstr(end_liquid == init_liquid + x_l - demand_liquid, "Liquid_Balance")
    model.addConstr(end_solid == init_solid + x_s - demand_solid, "Solid_Balance")

    model.addConstr(m1_liquid * x_l + m1_solid * x_s <= m1_avail + extended_extra_minutes * ext_1, "Machine_1_Capacity")
    model.addConstr(m2_liquid * x_l + m2_solid * x_s <= m2_avail + extended_extra_minutes * ext_2, "Machine_2_Capacity")

    model.addConstr(labor_hours_per_machine_extended * ext_1 + labor_hours_per_machine_extended * ext_2 <= labor_budget_hours, "Labor_Budget")

    model.addConstr(end_liquid_priority <= end_liquid, "Liquid_Priority_Limit")
    model.addConstr(end_liquid_priority + end_liquid_excess == end_liquid, "Liquid_Total_End")

    model.addConstr(end_solid_priority <= end_solid, "Solid_Priority_Limit")
    model.addConstr(end_solid_priority + end_solid_excess == end_solid, "Solid_Total_End")

    objective = (end_liquid_priority + excess_reserve_credit * end_liquid_excess +
                 end_solid_priority + excess_reserve_credit * end_solid_excess -
                 extended_mode_penalty * ext_1 - extended_mode_penalty * ext_2)

    model.setObjective(objective, GRB.MAXIMIZE)
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
