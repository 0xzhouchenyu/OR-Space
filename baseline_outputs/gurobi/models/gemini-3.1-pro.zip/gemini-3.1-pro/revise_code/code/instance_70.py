import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_tsp():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    dist_file = os.path.join(data_dir, 'table_1.csv')
    params_file = os.path.join(data_dir, 'general_parameters.csv')
    
    cities = []
    dist = []
    with open(dist_file, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            cities.append(row[0].strip())
            dist.append([float(x) for x in row[1:]])
            
    n = len(cities)
    city_to_idx = {city: i for i, city in enumerate(cities)}
    
    params = {}
    with open(params_file, 'r') as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            params[row[0].strip()] = row[1].strip()
            
    start_city = city_to_idx[params['start_city']]
    end_city = city_to_idx[params['end_city']]
    prohibited_from = city_to_idx[params['prohibited_from']]
    prohibited_to = city_to_idx[params['prohibited_to']]
    inspection_arc_from = city_to_idx[params['inspection_arc_from']]
    inspection_arc_to = city_to_idx[params['inspection_arc_to']]
    inspection_stop_cost = float(params['inspection_stop_cost'])
    
    model = gp.Model("TSP_Path")
    model.setParam('OutputFlag', 0)
    
    x = {}
    for i in range(n):
        for j in range(n):
            if i != j:
                cost = dist[i][j]
                if i == inspection_arc_from and j == inspection_arc_to:
                    cost += inspection_stop_cost
                x[i, j] = model.addVar(vtype=GRB.BINARY, obj=cost, name=f"x_{i}_{j}")
                
    model.addConstr(x[prohibited_from, prohibited_to] == 0)
    
    for i in range(n):
        if i == start_city:
            model.addConstr(gp.quicksum(x[i, j] for j in range(n) if i != j) == 1)
            model.addConstr(gp.quicksum(x[j, i] for j in range(n) if i != j) == 0)
        elif i == end_city:
            model.addConstr(gp.quicksum(x[i, j] for j in range(n) if i != j) == 0)
            model.addConstr(gp.quicksum(x[j, i] for j in range(n) if i != j) == 1)
        else:
            model.addConstr(gp.quicksum(x[i, j] for j in range(n) if i != j) == 1)
            model.addConstr(gp.quicksum(x[j, i] for j in range(n) if i != j) == 1)
            
    u = {}
    for i in range(n):
        u[i] = model.addVar(lb=0, ub=n-1, vtype=GRB.CONTINUOUS)
        
    for i in range(n):
        for j in range(n):
            if i != j and j != start_city:
                model.addConstr(u[i] - u[j] + n * x[i, j] <= n - 1)
                
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve_tsp()
