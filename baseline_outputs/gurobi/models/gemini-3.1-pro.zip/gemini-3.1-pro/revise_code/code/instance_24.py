import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    product_units = params['product_units']
    pollution = {
        'truck': params['truck_pollution'],
        'van': params['van_pollution'],
        'moto': params['motorcycle_pollution'],
        'ev': params['electric_vehicle_pollution']
    }
    capacity = {
        'truck': params['truck_capacity'],
        'van': params['van_capacity'],
        'moto': params['motorcycle_capacity'],
        'ev': params['electric_vehicle_capacity']
    }
    max_total_pollution = params['max_total_pollution']
    min_truck_trips = params['min_truck_trips']
    
    sp_shares = {
        1: params['sales_point_share_sp1'],
        2: params['sales_point_share_sp2'],
        3: params['sales_point_share_sp3']
    }
    
    min_truck_shares = {
        1: params['min_truck_share_sp1'],
        2: params['min_truck_share_sp2'],
        3: params['min_truck_share_sp3']
    }
    
    M = {
        'truck': params['M_truck_sp_day'],
        'ev': params['M_ev_sp_day'],
        'van': params['M_van_sp_day'],
        'moto': params['M_moto_sp_day']
    }
    
    vehicles = ['truck', 'van', 'moto', 'ev']
    sales_points = [1, 2, 3]
    days = [1, 2, 3]
    
    model = gp.Model("Transportation_Pollution_Minimization")
    model.setParam('OutputFlag', 0)
    
    x = model.addVars(vehicles, sales_points, days, vtype=GRB.INTEGER, lb=0, name="x")
    y = model.addVars(sales_points, days, vtype=GRB.BINARY, name="y")
    
    model.setObjective(gp.quicksum(x[v, sp, d] * pollution[v] for v in vehicles for sp in sales_points for d in days), GRB.MINIMIZE)
    
    for sp in sales_points:
        model.addConstr(
            gp.quicksum(x[v, sp, d] * capacity[v] for v in vehicles for d in days) >= product_units * sp_shares[sp],
            name=f"Demand_sp{sp}"
        )
        
    for sp in sales_points:
        total_truck_sp = gp.quicksum(x['truck', sp, d] for d in days)
        total_trips_sp = gp.quicksum(x[v, sp, d] for v in vehicles for d in days)
        model.addConstr(total_truck_sp >= min_truck_shares[sp] * total_trips_sp, name=f"Min_truck_share_sp{sp}")
        
    for sp in sales_points:
        for d in days:
            model.addConstr(x['truck', sp, d] <= M['truck'] * y[sp, d])
            model.addConstr(x['ev', sp, d] <= M['ev'] * y[sp, d])
            model.addConstr(x['van', sp, d] <= M['van'] * (1 - y[sp, d]))
            model.addConstr(x['moto', sp, d] <= M['moto'] * (1 - y[sp, d]))
            
    model.addConstr(
        gp.quicksum(x['truck', sp, d] for sp in sales_points for d in days) >= min_truck_trips,
        name="Min_total_truck_trips"
    )
    
    model.addConstr(
        gp.quicksum(x[v, sp, d] * pollution[v] for v in vehicles for sp in sales_points for d in days) <= max_total_pollution,
        name="Max_total_pollution"
    )
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
