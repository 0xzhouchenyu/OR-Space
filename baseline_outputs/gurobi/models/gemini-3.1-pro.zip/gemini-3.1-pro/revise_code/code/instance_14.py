import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    items = []
    with open(os.path.join(base_dir, 'data', 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g'].strip()),
                'cost': float(row['Cost_per_100g'].strip()),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g'].strip()),
                'sodium': float(row['Sodium_mg_per_100g'].strip())
            })
            
    params = {}
    with open(os.path.join(base_dir, 'data', 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_daily_calories = params['min_daily_calories']
    max_daily_calories = params['max_daily_calories']
    max_daily_sodium = params['max_daily_sodium']
    
    max_units = int(total_weight_limit // 100)
    max_meal_units = 3
    
    model = gp.Model("lunch_and_dinner")
    model.setParam('OutputFlag', 0)
    
    purchase_units = {}
    lunch_units = {}
    dinner_units = {}
    select_item = {}
    lunch_veg_selected = {}
    dinner_veg_selected = {}
    
    for i in range(len(items)):
        purchase_units[i] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"purchase_{i}")
        lunch_units[i] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"lunch_{i}")
        dinner_units[i] = model.addVar(vtype=GRB.INTEGER, lb=0, name=f"dinner_{i}")
        select_item[i] = model.addVar(vtype=GRB.BINARY, name=f"select_{i}")
        
        if items[i]['type'] == 'Vegetable':
            lunch_veg_selected[i] = model.addVar(vtype=GRB.BINARY, name=f"lunch_veg_{i}")
            dinner_veg_selected[i] = model.addVar(vtype=GRB.BINARY, name=f"dinner_veg_{i}")
            
    # Linking purchase and meal assignment
    for i in range(len(items)):
        model.addConstr(purchase_units[i] >= lunch_units[i] + dinner_units[i])
        
    # Total daily budget
    model.addConstr(gp.quicksum(items[i]['cost'] * purchase_units[i] for i in range(len(items))) <= max_budget)
    
    # Total daily weight limit
    model.addConstr(gp.quicksum(100 * purchase_units[i] for i in range(len(items))) <= total_weight_limit)
    
    # Per-meal weight balance
    model.addConstr(gp.quicksum(100 * lunch_units[i] for i in range(len(items))) == 300)
    model.addConstr(gp.quicksum(100 * dinner_units[i] for i in range(len(items))) == 300)
    
    # Daily calorie intake bounds
    total_cals = gp.quicksum(items[i]['calories'] * (lunch_units[i] + dinner_units[i]) for i in range(len(items)))
    model.addConstr(total_cals >= min_daily_calories)
    model.addConstr(total_cals <= max_daily_calories)
    
    # Daily sodium intake bound
    total_sodium = gp.quicksum(items[i]['sodium'] * (lunch_units[i] + dinner_units[i]) for i in range(len(items)))
    model.addConstr(total_sodium <= max_daily_sodium)
    
    # Purchase selection linkage
    for i in range(len(items)):
        model.addConstr(purchase_units[i] <= max_units * select_item[i])
        model.addConstr(lunch_units[i] <= max_meal_units * select_item[i])
        model.addConstr(dinner_units[i] <= max_meal_units * select_item[i])
        
    # Vegetable coverage
    for i in range(len(items)):
        if items[i]['type'] == 'Vegetable':
            model.addConstr(lunch_units[i] >= lunch_veg_selected[i])
            model.addConstr(lunch_units[i] <= max_meal_units * lunch_veg_selected[i])
            model.addConstr(dinner_units[i] >= dinner_veg_selected[i])
            model.addConstr(dinner_units[i] <= max_meal_units * dinner_veg_selected[i])
            
    model.addConstr(gp.quicksum(lunch_veg_selected[i] for i in range(len(items)) if items[i]['type'] == 'Vegetable') >= min_veg_types)
    model.addConstr(gp.quicksum(dinner_veg_selected[i] for i in range(len(items)) if items[i]['type'] == 'Vegetable') >= min_veg_types)
    
    # Objective: maximize total protein
    total_protein = gp.quicksum(items[i]['protein'] * (lunch_units[i] + dinner_units[i]) for i in range(len(items)))
    model.setObjective(total_protein, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.objVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
