import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    min_A = params['min_raw_material_A']
    min_B = params['min_raw_material_B']
    min_C = params['min_raw_material_C']

    cap_A_a = params['warehouse_A_truck_capacity_A']
    cap_A_b = params['warehouse_A_truck_capacity_B']
    cap_A_c = params['warehouse_A_truck_capacity_C']
    cost_A = params['warehouse_A_truck_cost']
    fixed_A = params.get('warehouse_A_fixed_cost', 0)

    cap_B_a = params['warehouse_B_truck_capacity_A']
    cap_B_b = params['warehouse_B_truck_capacity_B']
    cap_B_c = params['warehouse_B_truck_capacity_C']
    cost_B = params['warehouse_B_truck_cost']
    fixed_B = params.get('warehouse_B_fixed_cost', 0)

    over_thresh_B = params.get('warehouse_B_overflow_threshold_trucks', 55)
    over_cost_B = params.get('warehouse_B_overflow_coordination_cost', 0)
    dual_cost = params.get('dual_warehouse_reconciliation_fee', 0)

    model = gp.Model("MinFreightCost")
    model.setParam('OutputFlag', 0)

    x = model.addVar(vtype=GRB.INTEGER, lb=0, name="x")
    y = model.addVar(vtype=GRB.INTEGER, lb=0, name="y")

    z_A = model.addVar(vtype=GRB.BINARY, name="z_A")
    z_B = model.addVar(vtype=GRB.BINARY, name="z_B")
    z_B_over = model.addVar(vtype=GRB.BINARY, name="z_B_over")
    z_dual = model.addVar(vtype=GRB.BINARY, name="z_dual")

    M = 10000

    model.addConstr(cap_A_a * x + cap_B_a * y >= min_A)
    model.addConstr(cap_A_b * x + cap_B_b * y >= min_B)
    model.addConstr(cap_A_c * x + cap_B_c * y >= min_C)

    model.addConstr(x <= M * z_A)
    model.addConstr(y <= M * z_B)
    model.addConstr(y - over_thresh_B <= M * z_B_over)
    model.addConstr(z_dual >= z_A + z_B - 1)

    model.setObjective(
        cost_A * x + cost_B * y + 
        fixed_A * z_A + fixed_B * z_B + 
        over_cost_B * z_B_over + dual_cost * z_dual, 
        GRB.MINIMIZE
    )

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
