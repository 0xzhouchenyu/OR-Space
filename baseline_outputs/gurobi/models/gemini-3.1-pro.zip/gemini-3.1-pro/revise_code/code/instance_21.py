import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    cost_a = params['cost_supplier_a']
    cost_b = params['cost_supplier_b']
    cost_c = params['cost_supplier_c']
    size_a = int(params['order_size_supplier_a'])
    size_b = int(params['order_size_supplier_b'])
    size_c = int(params['order_size_supplier_c'])
    min_tables = int(params['min_tables_required'])
    max_tables = int(params['max_tables_allowed'])
    min_b_if_a = int(params['min_tables_supplier_b_if_a'])
    b_requires_c = int(params['supplier_b_requires_c'])
    
    max_free_orders_c = int(params.get('max_free_orders_c', 0))
    penalty_per_extra_order_c = params.get('penalty_per_extra_order_c', 0)
    bc_shared_trigger = int(params.get('supplier_bc_shared_inbound_trigger', 0))
    bc_shared_fee = params.get('supplier_bc_shared_inbound_fee', 0)
    
    M = 1000
    
    model = gp.Model("Restaurant_Tables")
    model.setParam('OutputFlag', 0)
    
    x_a = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_a")
    x_b = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_b")
    x_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="x_c")
    
    y_a = model.addVar(vtype=GRB.BINARY, name="y_a")
    y_b = model.addVar(vtype=GRB.BINARY, name="y_b")
    y_c = model.addVar(vtype=GRB.BINARY, name="y_c")
    
    y_bc = model.addVar(vtype=GRB.BINARY, name="y_bc")
    z_c = model.addVar(vtype=GRB.INTEGER, lb=0, name="z_c")
    
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c >= min_tables)
    model.addConstr(size_a * x_a + size_b * x_b + size_c * x_c <= max_tables)
    
    model.addConstr(x_a <= M * y_a)
    model.addConstr(x_b <= M * y_b)
    model.addConstr(x_c <= M * y_c)
    
    model.addConstr(size_b * x_b >= min_b_if_a * y_a)
    
    if b_requires_c:
        model.addConstr(x_c >= y_b)
        
    model.addConstr(z_c >= x_c - max_free_orders_c)
    
    if bc_shared_trigger:
        model.addConstr(y_bc >= y_b + y_c - 1)
    
    obj = (cost_a * size_a * x_a +
           cost_b * size_b * x_b +
           cost_c * size_c * x_c +
           penalty_per_extra_order_c * z_c +
           bc_shared_fee * y_bc)
           
    model.setObjective(obj, GRB.MINIMIZE)
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    main()
