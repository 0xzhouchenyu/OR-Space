import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    a_p1 = params['product_a_process_1_time']
    a_p2 = params['product_a_process_2_time']
    b_p1 = params['product_b_process_1_time']
    b_p2 = params['product_b_process_2_time']
    T1 = params['available_time_process_1']
    T2 = params['available_time_process_2']
    T1_high = params['available_time_process_1_high']
    T2_high = params['available_time_process_2_high']
    c_per_b = params['byproduct_c_per_unit_b']
    max_c_sales = params['max_byproduct_c_sales']
    threshold_c = params['threshold_c']
    disposal_cost = params['disposal_cost_per_unit_c']
    disposal_cost_high = params['disposal_cost_per_unit_c_high']
    profit_a = params['profit_per_unit_a']
    profit_b = params['profit_per_unit_b']
    profit_c = params['profit_per_unit_c']

    model = gp.Model("MaxProfit")
    model.setParam('OutputFlag', 0)

    xA = model.addVar(lb=0, name="xA")
    xB = model.addVar(lb=0, name="xB")
    cSold = model.addVar(lb=0, name="cSold")
    cDisposed = model.addVar(lb=0, name="cDisposed")
    cDisposed_base = model.addVar(lb=0, ub=threshold_c, name="cDisposed_base")
    cDisposed_high = model.addVar(lb=0, name="cDisposed_high")
    
    y1 = model.addVar(vtype=GRB.BINARY, name="y1")
    y2 = model.addVar(vtype=GRB.BINARY, name="y2")

    model.setObjective(
        profit_a * xA + profit_b * xB + profit_c * cSold 
        - disposal_cost * cDisposed_base - disposal_cost_high * cDisposed_high,
        GRB.MAXIMIZE
    )

    model.addConstr(y1 + y2 <= 1, "MaxOneHighThroughput")

    model.addConstr(a_p1 * xA + b_p1 * xB <= T1 * (1 - y1) + T1_high * y1, "Process1Time")
    model.addConstr(a_p2 * xA + b_p2 * xB <= T2 * (1 - y2) + T2_high * y2, "Process2Time")

    model.addConstr(cSold + cDisposed == c_per_b * xB, "ByproductBalance")
    model.addConstr(cSold <= max_c_sales, "MaxCSales")
    model.addConstr(cDisposed == cDisposed_base + cDisposed_high, "DisposalBreakdown")

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
