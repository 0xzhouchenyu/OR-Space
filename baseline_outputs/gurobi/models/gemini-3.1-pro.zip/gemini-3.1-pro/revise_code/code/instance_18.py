import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

fabric_production_rate = params['fabric_production_rate']
min_curtain_fabric_sales = params['min_curtain_fabric_sales']
min_clothing_fabric_sales = params['min_clothing_fabric_sales']
day_shift_regular_capacity = params['day_shift_regular_capacity']
night_shift_regular_capacity = params['night_shift_regular_capacity']
day_overtime_limit = params['day_overtime_limit']
night_overtime_limit = params['night_overtime_limit']
day_overtime_penalty = params['day_overtime_penalty']
night_overtime_penalty = params['night_overtime_penalty']
day_min_utilization_ratio = params['day_min_utilization_ratio']
night_min_utilization_ratio = params['night_min_utilization_ratio']

min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

# Create model
model = gp.Model("Textile_Factory_Shift_Overtime_Minimization")
model.setParam('OutputFlag', 0)

# Decision variables
clothing_hours = model.addVar(lb=min_clothing_hours, vtype=GRB.CONTINUOUS, name="clothing_hours")
curtain_hours = model.addVar(lb=min_curtain_hours, vtype=GRB.CONTINUOUS, name="curtain_hours")

day_reg = model.addVar(lb=0, ub=day_shift_regular_capacity, vtype=GRB.CONTINUOUS, name="day_reg")
night_reg = model.addVar(lb=0, ub=night_shift_regular_capacity, vtype=GRB.CONTINUOUS, name="night_reg")

day_overtime = model.addVar(lb=0, ub=day_overtime_limit, vtype=GRB.CONTINUOUS, name="day_overtime")
night_overtime = model.addVar(lb=0, ub=night_overtime_limit, vtype=GRB.CONTINUOUS, name="night_overtime")

total_reg = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="total_reg")

# Objective: minimize overtime penalty
model.setObjective(day_overtime * day_overtime_penalty + night_overtime * night_overtime_penalty, GRB.MINIMIZE)

# Constraints
model.addConstr(clothing_hours + curtain_hours == day_reg + night_reg + day_overtime + night_overtime, "Total_Hours_Balance")
model.addConstr(total_reg == day_reg + night_reg, "Total_Reg_Def")
model.addConstr(day_reg >= day_min_utilization_ratio * total_reg, "Day_Min_Util")
model.addConstr(night_reg >= night_min_utilization_ratio * total_reg, "Night_Min_Util")

# Solve
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.objVal}")
else:
    print("FINAL_OBJ_VALUE: None")
