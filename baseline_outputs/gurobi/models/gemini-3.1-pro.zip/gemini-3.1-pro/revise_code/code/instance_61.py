import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Load data
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Read device data
devices = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        name = row['Device'].strip()
        devices[name] = {
            'prep_cost': float(row['Prep_Completion_Cost_Yuan'].strip()),
            'unit_cost': float(row['Unit_Production_Cost_Yuan_per_Unit'].strip()),
            'max_cap': float(row['Max_Processing_Capacity_Units'].strip())
        }

# Read general parameters
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

required_units = params['required_units']
energy_budget_peak = params['energy_budget_peak']
energy_budget_offpeak = params['energy_budget_offpeak']
startup_budget = params['startup_budget']
startup_cost = params['startup_cost']
energy_price_peak = params['energy_price_peak']
energy_price_offpeak = params['energy_price_offpeak']

energy_per_unit = {
    'A': params['energy_per_unit_A'],
    'B': params['energy_per_unit_B'],
    'C': params['energy_per_unit_C'],
    'D': params['energy_per_unit_D']
}

startup_energy = {
    'A': params['startup_energy_A'],
    'B': params['startup_energy_B'],
    'C': params['startup_energy_C'],
    'D': params['startup_energy_D']
}

periods = ['peak', 'offpeak']
device_names = list(devices.keys())

# Create the optimization model
model = gp.Model("MinCostProduction")
model.setParam('OutputFlag', 0)

# Decision variables
x = model.addVars(device_names, periods, vtype=GRB.CONTINUOUS, name="x")
y = model.addVars(device_names, periods, vtype=GRB.BINARY, name="y")

# Objective function
total_cost = gp.quicksum(
    devices[i]['unit_cost'] * x[i, p] +
    (devices[i]['prep_cost'] + startup_cost) * y[i, p] +
    (startup_energy[i] * y[i, p] + energy_per_unit[i] * x[i, p]) * (energy_price_peak if p == 'peak' else energy_price_offpeak)
    for i in device_names for p in periods
)
model.setObjective(total_cost, GRB.MINIMIZE)

# Constraints
# Total production
model.addConstr(gp.quicksum(x[i, p] for i in device_names for p in periods) == required_units, "TotalProduction")

# Linking constraints and max capacity per device total
for i in device_names:
    model.addConstr(gp.quicksum(x[i, p] for p in periods) <= devices[i]['max_cap'], f"MaxCap_{i}")
    for p in periods:
        model.addConstr(x[i, p] <= devices[i]['max_cap'] * y[i, p], f"Link_{i}_{p}")

# Energy budgets
model.addConstr(
    gp.quicksum(startup_energy[i] * y[i, 'peak'] + energy_per_unit[i] * x[i, 'peak'] for i in device_names) <= energy_budget_peak,
    "EnergyBudgetPeak"
)
model.addConstr(
    gp.quicksum(startup_energy[i] * y[i, 'offpeak'] + energy_per_unit[i] * x[i, 'offpeak'] for i in device_names) <= energy_budget_offpeak,
    "EnergyBudgetOffpeak"
)

# Startup budget
model.addConstr(
    gp.quicksum(startup_cost * y[i, p] for i in device_names for p in periods) <= startup_budget,
    "StartupBudget"
)

# Solve
model.optimize()

# Print result
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("FINAL_OBJ_VALUE: None")
