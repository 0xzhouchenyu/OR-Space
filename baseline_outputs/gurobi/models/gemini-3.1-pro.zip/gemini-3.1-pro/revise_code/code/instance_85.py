import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load table_1.csv
    table1_path = os.path.join(base_dir, 'data', 'table_1.csv')
    products = {}
    with open(table1_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Item'].strip()
            products[item] = {
                'machine_time': float(row['Machine_Time_minutes'].strip()),
                'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
            }
    
    # Load general_parameters.csv
    params_path = os.path.join(base_dir, 'data', 'general_parameters.csv')
    params = {}
    with open(params_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    
    machine_avail = params['machine_time_available']
    craftsman_reg_avail = params['craftsman_regular_time_available']
    craftsman_ot_avail = params['craftsman_overtime_available']
    machine_cost = params['machine_time_cost']
    craftsman_reg_cost = params['craftsman_time_cost']
    craftsman_ot_cost = params['craftsman_overtime_cost']
    rev_X = params['revenue_product_X']
    rev_Y = params['revenue_product_Y']
    min_X = params['min_batches_product_X']
    y_qa_threshold = params.get('product_Y_QA_threshold', 60.0)
    y_qa_fee = params.get('product_Y_QA_fee', 10.0)
    
    model = gp.Model("Production_Planning")
    model.setParam('OutputFlag', 0)
    
    X = model.addVar(lb=min_X, vtype=GRB.CONTINUOUS, name="X")
    Y = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Y")
    
    machine_hours_used = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="machine_hours_used")
    craftsman_hours_used = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="craftsman_hours_used")
    
    craftsman_reg_used = model.addVar(lb=0, ub=craftsman_reg_avail, vtype=GRB.CONTINUOUS, name="craftsman_reg_used")
    craftsman_ot_used = model.addVar(lb=0, ub=craftsman_ot_avail, vtype=GRB.CONTINUOUS, name="craftsman_ot_used")
    
    z_qa = model.addVar(vtype=GRB.BINARY, name="z_qa")
    
    model.addConstr(machine_hours_used == (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0)
    model.addConstr(craftsman_hours_used == (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0)
    
    model.addConstr(machine_hours_used <= machine_avail)
    model.addConstr(craftsman_hours_used == craftsman_reg_used + craftsman_ot_used)
    
    # Big-M for Y > threshold
    # Max possible Y is around 150
    M = 10000
    model.addConstr(Y <= y_qa_threshold + M * z_qa)
    
    profit = rev_X * X + rev_Y * Y - machine_cost * machine_hours_used - craftsman_reg_cost * craftsman_reg_used - craftsman_ot_cost * craftsman_ot_used - y_qa_fee * z_qa
    
    model.setObjective(profit, GRB.MAXIMIZE)
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    main()
