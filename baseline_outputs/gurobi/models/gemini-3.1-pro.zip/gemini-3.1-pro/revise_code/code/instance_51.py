import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load demand
    demand = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
            
    num_periods = len(demand)
    
    # Load parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
            
    shift_duration = int(params['shift_duration'])
    regular_pay = float(params['regular_nurse_pay'])
    contract_pay = float(params['contract_nurse_pay'])
    outsourced_regular_start_index = int(params['outsourced_regular_start_index'])
    banned_contract_start_index = int(params['banned_contract_start_index'])
    max_total_contract_starts = int(params['max_total_contract_starts'])
    min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])
    daytime_period_indices = [int(idx) for idx in params['daytime_period_indices'].split(';')]
    
    model = gp.Model("NurseScheduling")
    model.setParam('OutputFlag', 0)
    
    x = model.addVars(num_periods, vtype=GRB.INTEGER, name="x")
    y = model.addVars(num_periods, vtype=GRB.INTEGER, name="y")
    
    # Objective
    model.setObjective(gp.quicksum((regular_pay * shift_duration) * x[j] + (contract_pay * shift_duration) * y[j] for j in range(num_periods)), GRB.MINIMIZE)
    
    # Coverage constraints
    for i in range(num_periods):
        covering_shifts = [(i - 1) % num_periods, i]
        model.addConstr(gp.quicksum(x[j] + y[j] for j in covering_shifts) >= demand[i], name=f"Demand_{i}")
        
    # Daytime regular coverage
    for i in daytime_period_indices:
        covering_shifts = [(i - 1) % num_periods, i]
        model.addConstr(gp.quicksum(x[j] for j in covering_shifts) >= min_regular_daytime_coverage, name=f"DaytimeReg_{i}")
        
    # Banned starts
    model.addConstr(x[outsourced_regular_start_index] == 0, name="NoRegStart")
    model.addConstr(y[banned_contract_start_index] == 0, name="NoContStart")
    
    # Max contract starts
    model.addConstr(gp.quicksum(y[j] for j in range(num_periods)) <= max_total_contract_starts, name="MaxCont")
    
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
