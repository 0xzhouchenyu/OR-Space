import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load processing times
    processing_times = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            processing_times.append([int(val) for val in row[1:]])
            
    # Load parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if row[1]:
                params[row[0]] = float(row[1])
                
    return processing_times, params

def main():
    processing_times, params = load_data()
    n_products = len(processing_times)
    n_machines = len(processing_times[0])
    
    time_windows = [params[f'time_window_{m+1}'] for m in range(n_machines)]
    overtime_windows = [params[f'overtime_window_{m+1}'] for m in range(n_machines)]
    penalty = params['overtime_penalty_per_unit']
    review_threshold = params['machine1_overtime_review_threshold']
    review_fee = params['machine1_overtime_review_fee']
    
    model = gp.Model("FlowShop")
    model.setParam('OutputFlag', 0)
    
    # x[p, k] = 1 if product p is assigned to position k
    x = model.addVars(n_products, n_products, vtype=GRB.BINARY, name="x")
    
    # C[k, m] = completion time of position k on machine m
    C = model.addVars(n_products, n_machines, vtype=GRB.CONTINUOUS, name="C")
    
    # O[m] = overtime on machine m
    O = model.addVars(n_machines, vtype=GRB.CONTINUOUS, name="O")
    
    # Z = 1 if O[0] > review_threshold
    Z = model.addVar(vtype=GRB.BINARY, name="Z")
    
    C_max = model.addVar(vtype=GRB.CONTINUOUS, name="C_max")
    
    # Assignment constraints
    for p in range(n_products):
        model.addConstr(gp.quicksum(x[p, k] for k in range(n_products)) == 1)
    for k in range(n_products):
        model.addConstr(gp.quicksum(x[p, k] for p in range(n_products)) == 1)
        
    # Processing time of job at position k on machine m
    P = {}
    for k in range(n_products):
        for m in range(n_machines):
            P[k, m] = gp.quicksum(x[p, k] * processing_times[p][m] for p in range(n_products))
            
    # Completion time constraints
    for k in range(n_products):
        for m in range(n_machines):
            if k == 0 and m == 0:
                model.addConstr(C[k, m] == P[k, m])
            elif k == 0:
                model.addConstr(C[k, m] >= C[k, m-1] + P[k, m])
            elif m == 0:
                model.addConstr(C[k, m] >= C[k-1, m] + P[k, m])
            else:
                model.addConstr(C[k, m] >= C[k, m-1] + P[k, m])
                model.addConstr(C[k, m] >= C[k-1, m] + P[k, m])
                
    # Makespan
    model.addConstr(C_max >= C[n_products-1, n_machines-1])
    
    # Overtime constraints
    for m in range(n_machines):
        model.addConstr(O[m] >= C[n_products-1, m] - time_windows[m])
        model.addConstr(O[m] >= 0)
        model.addConstr(O[m] <= overtime_windows[m])
        
    # Review fee constraint for machine 1
    model.addConstr(O[0] <= review_threshold + (overtime_windows[0] - review_threshold) * Z)
    
    # Objective
    obj = C_max + penalty * gp.quicksum(O[m] for m in range(n_machines)) + review_fee * Z
    model.setObjective(obj, GRB.MINIMIZE)
    
    model.optimize()
    
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
