import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    
    # Load table_1.csv
    table1_path = os.path.join(data_dir, 'table_1.csv')
    coverage = {}
    areas = []
    with open(table1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if not row or not row[0].strip():
                continue
            area_code = row[0].strip()
            areas.append(area_code)
            covered_raw = ','.join(row[1:])
            covered_areas = [x.strip() for x in covered_raw.split(',') if x.strip()]
            coverage[area_code] = set(covered_areas)
            
    # Load general_parameters.csv
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
            
    small_cost = params.get('small_cost', 1.0)
    large_cost = params.get('large_cost', 2.0)
    small_cap_areas = int(params.get('small_cap_areas', 3))
    max_large_stores = int(params.get('max_large_stores', 1))
    min_small_stores = int(params.get('minimum_neighborhood_counters', 6))
    
    model = gp.Model("RevisedChainStores")
    model.setParam('OutputFlag', 0)
    
    # Decision variables
    y = {} # Small store at j
    z = {} # Large store at j
    x = {} # Area i covered by small store at j
    
    for j in areas:
        y[j] = model.addVar(vtype=GRB.BINARY, name=f"small_{j}")
        z[j] = model.addVar(vtype=GRB.BINARY, name=f"large_{j}")
        
    for j in areas:
        for i in coverage[j]:
            x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"assign_{i}_{j}")
            
    # Objective: minimize total cost
    model.setObjective(gp.quicksum(small_cost * y[j] + large_cost * z[j] for j in areas), GRB.MINIMIZE)
    
    # Constraints
    
    # Max large stores
    model.addConstr(gp.quicksum(z[j] for j in areas) <= max_large_stores, "MaxLargeStores")
    
    # Min small stores
    model.addConstr(gp.quicksum(y[j] for j in areas) >= min_small_stores, "MinSmallStores")
    
    # Small store capacity and assignment limits
    for j in areas:
        model.addConstr(gp.quicksum(x[i, j] for i in coverage[j]) <= small_cap_areas * y[j], f"CapSmall_{j}")
        for i in coverage[j]:
            model.addConstr(x[i, j] <= y[j], f"AssignLimit_{i}_{j}")
            
    # Coverage requirement for each area
    for i in areas:
        covered_by_small = gp.quicksum(x[i, j] for j in areas if i in coverage[j])
        covered_by_large = gp.quicksum(z[j] for j in areas if i in coverage[j])
        model.addConstr(covered_by_small + covered_by_large >= 1, f"Cover_{i}")
        
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: -1")

if __name__ == "__main__":
    main()
