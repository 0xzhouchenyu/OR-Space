import gurobipy as gp
from gurobipy import GRB
import os
import csv

def solve_textile_problem():
    """
    Solves the revised textile factory optimization problem.
    """
    # --- Data Loading ---
    # The script is executed from the workspace root directory.
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Fallback for interactive environments
        script_dir = os.getcwd()

    data_dir = os.path.join(script_dir, "data")

    # Read general parameters from CSV
    params = {}
    params_filepath = os.path.join(data_dir, 'general_parameters.csv')
    with open(params_filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # --- Parameter Extraction ---
    fabric_production_rate = params['fabric_production_rate']
    min_curtain_fabric_sales = params['min_curtain_fabric_sales']
    min_clothing_fabric_sales = params['min_clothing_fabric_sales']
    
    weekly_production_time = params['weekly_production_time']
    
    day_shift_regular_capacity = params['day_shift_regular_capacity']
    night_shift_regular_capacity = params['night_shift_regular_capacity']
    
    day_overtime_limit = params['day_overtime_limit']
    night_overtime_limit = params['night_overtime_limit']
    
    day_overtime_penalty = params['day_overtime_penalty']
    night_overtime_penalty = params['night_overtime_penalty']
    
    day_min_utilization_ratio = params['day_min_utilization_ratio']
    night_min_utilization_ratio = params['night_min_utilization_ratio']

    # Convert sales requirements from meters to hours
    min_curtain_hours = min_curtain_fabric_sales / fabric_production_rate
    min_clothing_hours = min_clothing_fabric_sales / fabric_production_rate

    # --- Model Setup ---
    model = gp.Model("Revised_Textile_Factory_Optimization")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # Total production hours for each fabric type in each shift
    x_clothing_day = model.addVar(name="clothing_hours_day", lb=0)
    x_clothing_night = model.addVar(name="clothing_hours_night", lb=0)
    x_curtain_day = model.addVar(name="curtain_hours_day", lb=0)
    x_curtain_night = model.addVar(name="curtain_hours_night", lb=0)

    # Regular and overtime hours for each shift
    reg_day = model.addVar(name="regular_hours_day", lb=0)
    reg_night = model.addVar(name="regular_hours_night", lb=0)
    ot_day = model.addVar(name="overtime_hours_day", lb=0)
    ot_night = model.addVar(name="overtime_hours_night", lb=0)

    # --- Objective Function ---
    # Minimize the total penalty cost of overtime
    objective = ot_day * day_overtime_penalty + ot_night * night_overtime_penalty
    model.setObjective(objective, GRB.MINIMIZE)

    # --- Constraints ---
    # 1. Sales Requirements: Total hours for each fabric must meet minimums
    model.addConstr(x_clothing_day + x_clothing_night >= min_clothing_hours, "Min_Clothing_Production")
    model.addConstr(x_curtain_day + x_curtain_night >= min_curtain_hours, "Min_Curtain_Production")

    # 2. Shift Hour Balance: Total production hours in a shift equal regular plus overtime
    model.addConstr(x_clothing_day + x_curtain_day == reg_day + ot_day, "Day_Shift_Hour_Balance")
    model.addConstr(x_clothing_night + x_curtain_night == reg_night + ot_night, "Night_Shift_Hour_Balance")

    # 3. Regular Hour Capacity: Regular hours per shift cannot exceed capacity
    model.addConstr(reg_day <= day_shift_regular_capacity, "Day_Regular_Capacity")
    model.addConstr(reg_night <= night_shift_regular_capacity, "Night_Regular_Capacity")

    # 4. Overtime Limits: Overtime hours per shift cannot exceed limits
    model.addConstr(ot_day <= day_overtime_limit, "Day_Overtime_Limit")
    model.addConstr(ot_night <= night_overtime_limit, "Night_Overtime_Limit")

    # 5. Total Regular Time: The sum of regular hours across shifts must equal the weekly target
    model.addConstr(reg_day + reg_night == weekly_production_time, "Total_Regular_Time")

    # 6. Shift Utilization: Each shift's regular hours must meet the minimum utilization ratio
    # of the total regular hours (weekly_production_time)
    model.addConstr(reg_day >= day_min_utilization_ratio * weekly_production_time, "Day_Min_Utilization")
    model.addConstr(reg_night >= night_min_utilization_ratio * weekly_production_time, "Night_Min_Utilization")

    # --- Solve and Output ---
    model.optimize()

    if model.status == GRB.OPTIMAL:
        final_obj_value = model.ObjVal
        print(f"FINAL_OBJ_VALUE: {final_obj_value}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_textile_problem()
