import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    Solves the revised warehouse rental optimization problem.
    """

    def get_data_path(filename):
        """
        Returns the absolute path to a file in the data directory,
        as specified by the problem instructions.
        """
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)

    # Load all data from CSV files
    params_df = pd.read_csv(get_data_path('general_parameters.csv'), index_col='Parameter_Name')
    demand_df = pd.read_csv(get_data_path('table_1.csv'))
    cost_df = pd.read_csv(get_data_path('table_2.csv'))

    # Helper function to parse parameters from the dataframe
    def get_param(name, dtype=float):
        return dtype(params_df.loc[name, 'Value'])

    # Extract all business rules and parameters
    min_contract_types = get_param('min_contract_types', int)
    max_contract_types = get_param('max_contract_types', int)
    mutual_exclusion = str(params_df.loc['mutual_exclusion_1_and_4', 'Value']).strip().lower() == 'true'
    monthly_max_parallel_contracts = get_param('monthly_max_parallel_contracts', int)
    min_area_per_contract_units = get_param('min_area_per_contract_units')
    activation_fee_per_contract = get_param('activation_fee_per_contract')
    onboarding_loss_units = get_param('onboarding_loss_units')
    expedited_onboarding_fee = get_param('expedited_onboarding_fee')

    # Prepare data structures for the model
    # Convert demand to 100 sq.m. units
    demands = {row['Month']: row['Required_area_㎡'] / 100.0 for _, row in demand_df.iterrows()}
    # Rental fees per 100 sq.m. unit
    costs = {row['Contract_length_months']: row['Rental_fee_per_100㎡_yuan'] for _, row in cost_df.iterrows()}
    
    months = sorted(demands.keys())
    max_month = max(months)
    contract_lengths = sorted(costs.keys())

    # Define the set of all possible valid contracts, identified by (start_month, length)
    possible_contracts = [(i, j) for i in months for j in contract_lengths if i + j - 1 <= max_month]

    # --- Gurobi Model Setup ---
    model = gp.Model("RevisedWarehouseRental")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # N[i,j]: Number of standard (non-expedited) contracts starting in month i for j months
    N = model.addVars(possible_contracts, vtype=GRB.INTEGER, name="N", lb=0)
    # E[i,j]: Number of expedited contracts starting in month i for j months
    E = model.addVars(possible_contracts, vtype=GRB.INTEGER, name="E", lb=0)
    # A_N[i,j]: Total area (in 100 sqm units) for standard contracts (i,j)
    A_N = model.addVars(possible_contracts, vtype=GRB.CONTINUOUS, name="A_N", lb=0)
    # A_E[i,j]: Total area (in 100 sqm units) for expedited contracts (i,j)
    A_E = model.addVars(possible_contracts, vtype=GRB.CONTINUOUS, name="A_E", lb=0)
    # y[j]: Binary indicator, 1 if any contract of length j is used, 0 otherwise
    y = model.addVars(contract_lengths, vtype=GRB.BINARY, name="y")

    # --- Objective Function ---
    # Minimize the sum of rental, activation, and expedited fees
    rental_cost = gp.quicksum((A_N[i, j] + A_E[i, j]) * costs[j] for i, j in possible_contracts)
    activation_cost = gp.quicksum((N[i, j] + E[i, j]) * activation_fee_per_contract for i, j in possible_contracts)
    expedited_cost = gp.quicksum(E[i, j] * expedited_onboarding_fee for i, j in possible_contracts)
    
    model.setObjective(rental_cost + activation_cost + expedited_cost, GRB.MINIMIZE)

    # --- Constraints ---
    # 1. Demand Fulfillment: Usable area must exactly meet demand for each month
    for m in months:
        area_provided = gp.LinExpr()
        for i, j in possible_contracts:
            # Check if contract (i, j) is active in month m
            if i <= m < i + j:
                if i == m:  # First month of the contract: apply onboarding loss for standard contracts
                    area_provided += A_N[i, j] - N[i, j] * onboarding_loss_units
                    area_provided += A_E[i, j]
                else:  # Subsequent months: full area is available
                    area_provided += A_N[i, j] + A_E[i, j]
        model.addConstr(area_provided == demands[m], name=f"Demand_{m}")

    # 2. Minimum Area per Contract
    for i, j in possible_contracts:
        model.addConstr(A_N[i, j] >= min_area_per_contract_units * N[i, j], name=f"MinArea_N_{i}_{j}")
        model.addConstr(A_E[i, j] >= min_area_per_contract_units * E[i, j], name=f"MinArea_E_{i}_{j}")

    # 3. Maximum Active Contracts per Month
    for m in months:
        active_contracts_count = gp.quicksum(N[i, j] + E[i, j] for i, j in possible_contracts if i <= m < i + j)
        model.addConstr(active_contracts_count <= monthly_max_parallel_contracts, name=f"MaxParallel_{m}")

    # 4. Link contract counts (N, E) to binary indicators (y) using Big-M
    M = 100  # A sufficiently large number
    for j_len in contract_lengths:
        contracts_of_length_j = gp.quicksum(N[i, j] + E[i, j] for i, j in possible_contracts if j == j_len)
        model.addConstr(contracts_of_length_j <= M * y[j_len], name=f"Link_y_upper_{j_len}")
        model.addConstr(contracts_of_length_j >= y[j_len], name=f"Link_y_lower_{j_len}")

    # 5. Contract Type Limits
    model.addConstr(y.sum() >= min_contract_types, name="MinContractTypes")
    model.addConstr(y.sum() <= max_contract_types, name="MaxContractTypes")

    # 6. Mutual Exclusion for 1-month and 4-month contracts
    if mutual_exclusion:
        if 1 in y and 4 in y:
            model.addConstr(y[1] + y[4] <= 1, name="MutualExclusion")

    # --- Solve and Output ---
    model.optimize()
    
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
