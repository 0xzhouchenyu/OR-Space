import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_trip():
    """
    Solves the revised two-day family trip optimization problem.
    """
    # Define the path to the data directory
    try:
        # This works when the script is run from the root directory
        data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
        if not os.path.exists(data_dir):
            # Fallback for different execution contexts (e.g., interactive)
            data_dir = "data"
    except NameError:
        # __file__ is not defined in some environments (e.g., Jupyter)
        data_dir = "data"

    # --- 1. Load Data ---

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()

    max_children_trip = int(params['max_children_trip'])
    min_children_trip = int(params['min_children_trip'])
    max_distinct_children_trip = int(params['max_distinct_children_trip'])
    total_cost_budget = float(params['total_cost_budget'])
    bonus_saving = float(params['bonus_saving'])
    min_bob_days = int(params['min_bob_days'])

    # Read child-specific data
    children = []
    costs = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Child'].strip()
            cost = int(row['Cost'].strip())
            children.append(name)
            costs[name] = cost

    days = [1, 2]

    # --- 2. Create Optimization Model ---
    m = gp.Model("FamilyTripRevised")
    m.setParam('OutputFlag', 0)

    # --- 3. Define Decision Variables ---

    # x[c, d]: 1 if child c attends on day d, 0 otherwise
    x = m.addVars(children, days, vtype=GRB.BINARY, name="attends")

    # y[c]: 1 if child c attends on at least one day
    y = m.addVars(children, vtype=GRB.BINARY, name="distinct_child")

    # b[c]: 1 if child c attends on both days
    b = m.addVars(children, vtype=GRB.BINARY, name="both_days_bonus")

    # --- 4. Define Objective Function ---
    # Minimize total cost minus total bonus savings
    total_cost_expr = gp.quicksum(costs[c] * x[c, d] for c in children for d in days)
    total_savings_expr = gp.quicksum(bonus_saving * b[c] for c in children)
    
    m.setObjective(total_cost_expr - total_savings_expr, GRB.MINIMIZE)

    # --- 5. Define Constraints ---

    # Linking variables
    for c in children:
        # Link y[c] to x[c,d]: y[c] = 1 if child c attends on day 1 OR day 2
        m.addConstr(y[c] >= x[c, 1], f"link_y_{c}_day1")
        m.addConstr(y[c] >= x[c, 2], f"link_y_{c}_day2")
        m.addConstr(y[c] <= x[c, 1] + x[c, 2], f"link_y_{c}_sum")

        # Link b[c] to x[c,d]: b[c] = 1 if child c attends on day 1 AND day 2
        # Using general constraint for clarity
        m.addGenConstrAnd(b[c], [x[c, 1], x[c, 2]], f"link_b_{c}")

    # Daily headcount constraints
    for d in days:
        m.addConstr(gp.quicksum(x[c, d] for c in children) >= min_children_trip, f"MinChildren_Day{d}")
        m.addConstr(gp.quicksum(x[c, d] for c in children) <= max_children_trip, f"MaxChildren_Day{d}")

    # Trip-wide constraints
    m.addConstr(gp.quicksum(y[c] for c in children) <= max_distinct_children_trip, "MaxDistinctChildren")
    m.addConstr(total_cost_expr - total_savings_expr <= total_cost_budget, "TotalBudget")
    m.addConstr(gp.quicksum(x['Bob', d] for d in days) >= min_bob_days, "MinBobDays")

    # Relationship constraints (per day)
    for d in days:
        m.addConstr(x['Alice', d] + x['Diana', d] <= 1, f"AliceDianaConflict_Day{d}")
        m.addConstr(x['Bob', d] + x['Charlie', d] <= 1, f"BobCharlieConflict_Day{d}")
        m.addConstr(x['Charlie', d] <= x['Diana', d], f"CharlieRequiresDiana_Day{d}")
        m.addConstr(x['Diana', d] <= x['Ella', d], f"DianaRequiresElla_Day{d}")

    # Availability constraints
    m.addConstr(x['Alice', 2] == 0, "Alice_Day2_Unavailable")
    m.addConstr(x['Charlie', 1] == 0, "Charlie_Day1_Unavailable")
    m.addConstr(x['Diana', 1] == 0, "Diana_Day1_Unavailable")

    # --- 6. Solve the Model ---
    m.optimize()

    # --- 7. Output the Result ---
    if m.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("No optimal solution found.")
        # In a real scenario, you might print status, infeasibility details, etc.
        # For this problem, we expect an optimal solution.

if __name__ == "__main__":
    solve_revised_trip()
