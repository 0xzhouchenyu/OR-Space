import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    """
    This script formulates and solves the revised machine assignment problem
    using Gurobi.
    """
    # Per instructions, the script is run from the root, and data is in a 'data' subdirectory.
    data_dir = 'data'

    # --- Data Loading ---

    # Load processing costs from table_1.csv
    cost = {}  # cost[(machine, part)] = value
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader)
        parts = [int(p) for p in header[1:]]
        for row in reader:
            machine = row[0].strip()
            for j, p in enumerate(parts):
                cost[(machine, p)] = float(row[j + 1])

    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    # Extract parameters into variables
    d = {'A': params['d_A'], 'B': params['d_B'], 'C': params['d_C']}
    max_C = int(params['max_parts_on_C'])
    overtime_threshold = int(params['overtime_threshold'])
    overtime_penalty = params['overtime_penalty']

    machines = ['A', 'B', 'C']
    num_parts = len(parts)

    # --- Model Formulation ---

    # Create a new Gurobi model
    model = gp.Model("RevisedMachineAssignment")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---

    # x[m, p] = 1 if part p is assigned to machine m, 0 otherwise
    x = model.addVars(machines, parts, vtype=GRB.BINARY, name="x")

    # y[m] = 1 if machine m is used, 0 otherwise
    y = model.addVars(machines, vtype=GRB.BINARY, name="y")

    # z[m] = 1 if machine m operates in overtime, 0 otherwise
    z = model.addVars(machines, vtype=GRB.BINARY, name="z")

    # --- Objective Function ---

    # Minimize the sum of processing costs, setup costs, and overtime penalties
    processing_cost = gp.quicksum(cost[m, p] * x[m, p] for m in machines for p in parts)
    setup_cost = gp.quicksum(d[m] * y[m] for m in machines)
    overtime_cost = gp.quicksum(overtime_penalty * z[m] for m in machines)

    model.setObjective(processing_cost + setup_cost + overtime_cost, GRB.MINIMIZE)

    # --- Constraints ---

    # 1. Each part must be assigned to exactly one machine.
    model.addConstrs((gp.quicksum(x[m, p] for m in machines) == 1 for p in parts), name="part_assignment")

    # Link y[m] to x[m, p]: if any part is assigned to machine m, y[m] must be 1.
    # The objective function will ensure y[m] is 0 if no parts are assigned to m.
    model.addConstrs((x[m, p] <= y[m] for m in machines for p in parts), name="setup_link")

    # 2. If part 1 is on A, then part 2 is on B or C; and vice versa.
    # This is equivalent to stating that exactly one of part 1 or part 2 is on machine A.
    model.addConstr(x['A', 1] + x['A', 2] == 1, name="part1_2_dependency")

    # 3. Fixed assignments for parts 3, 4, and 5.
    model.addConstr(x['A', 3] == 1, name="fixed_A3")
    model.addConstr(x['B', 4] == 1, name="fixed_B4")
    model.addConstr(x['C', 5] == 1, name="fixed_C5")

    # 4. The number of parts processed on machine C should not exceed max_C.
    model.addConstr(gp.quicksum(x['C', p] for p in parts) <= max_C, name="max_on_C")

    # 5. If a machine processes more than the threshold, an overtime penalty is incurred.
    # We model this with an indicator constraint: if sum(x) > threshold, then z = 1.
    # This is done using the big-M method: sum(x) <= threshold + M * z.
    # A tight value for M is (total number of parts - threshold).
    M = num_parts - overtime_threshold
    model.addConstrs((gp.quicksum(x[m, p] for p in parts) <= overtime_threshold + M * z[m] for m in machines), name="overtime_logic")

    # --- Solve and Output ---

    # Optimize the model
    model.optimize()

    # Print the final objective value in the required format
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()
