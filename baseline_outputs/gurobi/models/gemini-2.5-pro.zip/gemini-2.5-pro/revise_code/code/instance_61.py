import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_production():
    """
    Loads data, formulates, and solves the revised production optimization problem.
    """
    # --- Data Loading ---

    # Define file paths relative to the script location
    try:
        # This path works when the script is run from the root directory
        data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
        if not os.path.exists(data_dir):
             # This path works for local testing if the script is in a subdirectory like 'src'
             data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    except NameError:
        # Fallback for environments where __file__ is not defined
        data_dir = 'data'


    general_params_file = os.path.join(data_dir, 'general_parameters.csv')
    table_1_file = os.path.join(data_dir, 'table_1.csv')

    # Initialize parameter storage
    params = {
        'energy_per_unit': {},
        'startup_energy': {},
        'energy_price': {},
        'max_cap': {}
    }
    devices = ['A', 'B', 'C', 'D']
    periods = ['peak', 'offpeak']

    # Read general parameters from general_parameters.csv
    with open(general_params_file, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            
            if name.startswith('energy_per_unit_'):
                device = name.split('_')[-1]
                params['energy_per_unit'][device] = value
            elif name.startswith('startup_energy_'):
                device = name.split('_')[-1]
                params['startup_energy'][device] = value
            elif name == 'energy_price_peak':
                params['energy_price']['peak'] = value
            elif name == 'energy_price_offpeak':
                params['energy_price']['offpeak'] = value
            else:
                params[name] = value

    # Read device-specific data from table_1.csv
    with open(table_1_file, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            device = row['Device'].strip()
            if device in devices:
                params['max_cap'][device] = float(row['Max_Processing_Capacity_Units'].strip())
                # Note: Prep_Completion_Cost and Unit_Production_Cost are considered obsolete
                # by the revised business requirements, which introduce a new cost structure
                # based on energy and startups.

    # --- Model Formulation ---

    # Create the Gurobi model
    m = gp.Model("RevisedProductionPlan")
    m.setParam('OutputFlag', 0)

    # Decision Variables
    # x[d, t]: number of units produced on device d in period t
    x = m.addVars(devices, periods, vtype=GRB.CONTINUOUS, name="x", lb=0)
    # y[d, t]: binary, 1 if device d is started in period t, 0 otherwise
    y = m.addVars(devices, periods, vtype=GRB.BINARY, name="y")

    # Objective Function: Minimize total cost
    # Total cost = (monetary startup cost) + (monetary energy cost)
    # Monetary startup cost = sum(startup_cost * y_dt)
    # Monetary energy cost = sum(price_t * (startup_energy_d * y_dt + production_energy_d * x_dt))
    # Combining terms by variable:
    # cost = sum_{d,t} [ (startup_cost + price_t * startup_energy_d) * y_dt + (price_t * energy_per_unit_d) * x_dt ]
    total_cost = gp.quicksum(
        (params['startup_cost'] + params['energy_price'][t] * params['startup_energy'][d]) * y[d, t] +
        (params['energy_price'][t] * params['energy_per_unit'][d]) * x[d, t]
        for d in devices for t in periods
    )
    m.setObjective(total_cost, GRB.MINIMIZE)

    # Constraints
    # 1. Total production requirement
    m.addConstr(x.sum() == params['required_units'], name="TotalProduction")

    # 2. Device capacity constraint (total production on a device across all periods)
    m.addConstrs((x.sum(d, '*') <= params['max_cap'][d] for d in devices), name="DeviceCapacity")

    # 3. Linking production and startup variables
    # If x[d,t] > 0, then y[d,t] must be 1.
    m.addConstrs((x[d, t] <= params['max_cap'][d] * y[d, t] for d in devices for t in periods), name="Linking")

    # 4. Peak energy budget
    peak_energy_consumption = gp.quicksum(
        params['startup_energy'][d] * y[d, 'peak'] + params['energy_per_unit'][d] * x[d, 'peak']
        for d in devices
    )
    m.addConstr(peak_energy_consumption <= params['energy_budget_peak'], name="PeakEnergyBudget")

    # 5. Off-peak energy budget
    offpeak_energy_consumption = gp.quicksum(
        params['startup_energy'][d] * y[d, 'offpeak'] + params['energy_per_unit'][d] * x[d, 'offpeak']
        for d in devices
    )
    m.addConstr(offpeak_energy_consumption <= params['energy_budget_offpeak'], name="OffPeakEnergyBudget")

    # 6. Startup monetary budget
    total_startup_cost = gp.quicksum(params['startup_cost'] * y[d, t] for d in devices for t in periods)
    m.addConstr(total_startup_cost <= params['startup_budget'], name="StartupBudget")

    # --- Solve and Output ---

    # Optimize the model
    m.optimize()

    # Print the final objective value
    if m.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        # This case should not be reached with the given data, but is good practice.
        # An empty line or error message might be printed if no solution is found.
        pass

if __name__ == "__main__":
    solve_revised_production()
