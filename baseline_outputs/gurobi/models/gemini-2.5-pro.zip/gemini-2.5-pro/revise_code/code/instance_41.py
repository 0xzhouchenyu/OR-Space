import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    # --- Data Loading ---
    # Define file paths relative to the script location
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    general_params_path = os.path.join(data_dir, "general_parameters.csv")
    liquidity_policy_path = os.path.join(data_dir, "liquidity_policy.csv")
    projects_path = os.path.join(data_dir, "table_1.csv")

    # Load general parameters
    with open(general_params_path, 'r') as f:
        reader = csv.DictReader(f)
        params = {row['Parameter_Name'].strip(): float(row['Value'].strip()) for row in reader}
    initial_capital = params['initial_capital']

    # Load liquidity policy parameters
    with open(liquidity_policy_path, 'r') as f:
        reader = csv.DictReader(f)
        policy_params = {row['Parameter_Name'].strip(): float(row['Value'].strip()) for row in reader}
    min_year3_reserve = policy_params['min_year3_reserve']
    reserve_shortfall_penalty = policy_params['reserve_shortfall_penalty']

    # Load project data into a dictionary for easy access
    projects = {}
    with open(projects_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            projects[row['Project_ID']] = {
                'Interest_Rate': float(row['Interest_Rate']),
                'Investment_Capacity': float(row['Investment_Capacity']) if row['Investment_Capacity'] != 'Unlimited' else GRB.INFINITY
            }

    # --- Model Setup ---
    m = gp.Model("RevisedInvestment")
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # x1_1, x1_2, x1_3: amount invested in Project 1 in Years 1, 2, 3
    # x2: amount invested in Project 2 in Year 1
    # x3: amount invested in Project 3 in Year 2
    # x4: amount invested in Project 4 in Year 3
    x1_1 = m.addVar(name="x1_1", lb=0)
    x1_2 = m.addVar(name="x1_2", lb=0)
    x1_3 = m.addVar(name="x1_3", lb=0)
    x2 = m.addVar(name="x2", lb=0, ub=projects['2']['Investment_Capacity'])
    x3 = m.addVar(name="x3", lb=0, ub=projects['3']['Investment_Capacity'])
    x4 = m.addVar(name="x4", lb=0, ub=projects['4']['Investment_Capacity'])

    # Variables for Year 3 liquidity policy
    uninvested_y3 = m.addVar(name="uninvested_y3", lb=0)
    shortfall_y3 = m.addVar(name="shortfall_y3", lb=0)

    # --- Constraints ---
    # Year 1 budget constraint
    m.addConstr(x1_1 + x2 <= initial_capital, "Year1_Budget")

    # Year 2 budget constraint: cash available from matured Year 1 investments
    cash_y2_start = x1_1 * projects['1']['Interest_Rate']
    m.addConstr(x1_2 + x3 <= cash_y2_start, "Year2_Budget")

    # Year 3 cash flow and budget balance
    # Cash available at start of Year 3 from matured Year 2 investments
    cash_y3_start = (x1_2 * projects['1']['Interest_Rate'] + 
                     x2 * projects['2']['Interest_Rate'] + 
                     x3 * projects['3']['Interest_Rate'])
    
    # The cash available at start of Year 3 is allocated to Year 3 investments or remains uninvested
    m.addConstr(x1_3 + x4 + uninvested_y3 == cash_y3_start, "Year3_Cash_Balance")

    # Year 3 liquidity reserve shortfall calculation
    # shortfall = max(0, required_reserve - actual_uninvested_cash)
    m.addConstr(shortfall_y3 >= min_year3_reserve - uninvested_y3, "Shortfall_Calculation")

    # --- Objective Function ---
    # Total wealth at the end of Year 3 is the sum of:
    # 1. Proceeds from Year 3 investments
    # 2. Uninvested cash from the start of Year 3 (which carries through)
    total_wealth_eoy3 = (x1_3 * projects['1']['Interest_Rate'] + 
                         x4 * projects['4']['Interest_Rate'] + 
                         uninvested_y3)

    # The penalty for not meeting the liquidity reserve target
    penalty = shortfall_y3 * reserve_shortfall_penalty

    # Maximize the final wealth minus the penalty
    m.setObjective(total_wealth_eoy3 - penalty, GRB.MAXIMIZE)

    # --- Solve and Output ---
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == "__main__":
    main()
