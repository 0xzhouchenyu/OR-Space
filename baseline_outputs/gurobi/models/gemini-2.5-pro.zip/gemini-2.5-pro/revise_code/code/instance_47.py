import gurobipy as gp
from gurobipy import GRB
import csv
import os
import sys

def load_csv(filename):
    """Load a CSV file and return headers and rows."""
    # The script is executed from the root, so the path is relative to the root.
    filepath = os.path.join("data", filename)
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = []
        for row in reader:
            rows.append(row)
    return headers, rows

def load_general_parameters(filename='general_parameters.csv'):
    """Load general parameters into a dictionary."""
    headers, rows = load_csv(filename)
    params = {}
    for row in rows:
        name = row[0].strip()
        try:
            value = float(row[1].strip())
        except ValueError:
            value = row[1].strip()
        params[name] = value
    return params

def load_crop_data(filename='table_1.csv'):
    """Load crop data from table_1.csv."""
    headers, rows = load_csv(filename)
    # headers: Item, Soybean, Corn, Wheat
    crops = [h.strip() for h in headers[1:]]
    data = {}
    for row in rows:
        item = row[0].strip()
        values = [float(v.strip()) for v in row[1:]]
        data[item] = dict(zip(crops, values))
    return crops, data

def main():
    # Load data
    params = load_general_parameters()
    crops, crop_data = load_crop_data()

    # Extract general parameters
    land_area = params['land_area']
    funds_available = params['funds_available']
    labor_aw = params['labor_autumn_winter']
    labor_ss = params['labor_spring_summer']
    ext_rate_ss = params['external_work_rate_spring_summer']
    ext_rate_aw = params['external_work_rate_autumn_winter']

    # Extract animal parameters
    inv_dairy = params['investment_per_dairy_cow']
    inv_chicken = params['investment_per_chicken']
    land_dairy = params['land_per_dairy_cow']
    labor_aw_dairy = params['labor_autumn_winter_per_dairy_cow']
    labor_ss_dairy = params['labor_spring_summer_per_dairy_cow']
    income_dairy = params['net_income_per_dairy_cow']
    labor_aw_chicken = params['labor_autumn_winter_per_chicken']
    labor_ss_chicken = params['labor_spring_summer_per_chicken']
    income_chicken = params['net_income_per_chicken']
    max_chickens = params['max_chickens']
    max_dairy_cows = params['max_dairy_cows']

    # Extract revised chicken biosecurity parameters
    fixed_cost_chicken_setup = params['fixed_cost_chicken_setup']
    min_chickens_if_coop_open = params['min_chickens_if_coop_open']
    second_biosecurity_threshold = params['second_biosecurity_threshold']
    second_biosecurity_cost = params['second_biosecurity_cost']
    biosecurity_training_aw_days = params['biosecurity_training_aw_days']
    biosecurity_training_ss_days = params['biosecurity_training_ss_days']

    # Extract crop data
    crop_aw = crop_data['Person-days (Autumn/Winter)']
    crop_ss = crop_data['Person-days (Spring/Summer)']
    crop_income = crop_data['Annual Net Income (Yuan/hectare)']

    # Create Gurobi model
    m = gp.Model("Farm_Optimization_Revised")

    # Decision variables
    # Crop areas (continuous)
    x = m.addVars(crops, name="x", lb=0)

    # Number of animals (integer)
    y_dairy = m.addVar(name="dairy_cows", vtype=GRB.INTEGER, lb=0, ub=max_dairy_cows)
    y_chicken = m.addVar(name="chickens", vtype=GRB.INTEGER, lb=0, ub=max_chickens)

    # Surplus labor for external work (continuous)
    surplus_aw = m.addVar(name="surplus_aw", lb=0)
    surplus_ss = m.addVar(name="surplus_ss", lb=0)

    # Binary variables for chicken biosecurity rules
    b_coop_open = m.addVar(name="coop_open", vtype=GRB.BINARY)
    b_second_inspection = m.addVar(name="second_inspection", vtype=GRB.BINARY)

    # Objective: maximize net income
    obj = (gp.quicksum(crop_income[c] * x[c] for c in crops) +
           income_dairy * y_dairy +
           income_chicken * y_chicken +
           ext_rate_aw * surplus_aw +
           ext_rate_ss * surplus_ss -
           fixed_cost_chicken_setup * b_coop_open -
           second_biosecurity_cost * b_second_inspection)
    m.setObjective(obj, GRB.MAXIMIZE)

    # Constraints
    # Land constraint
    m.addConstr(gp.quicksum(x[c] for c in crops) + land_dairy * y_dairy <= land_area, "Land")

    # Funds constraint
    m.addConstr(inv_dairy * y_dairy + inv_chicken * y_chicken <= funds_available, "Funds")

    # Labor autumn/winter constraint (including biosecurity training)
    m.addConstr(gp.quicksum(crop_aw[c] * x[c] for c in crops) +
                labor_aw_dairy * y_dairy +
                labor_aw_chicken * y_chicken +
                surplus_aw +
                biosecurity_training_aw_days * b_coop_open <= labor_aw, "Labor_AW")

    # Labor spring/summer constraint (including biosecurity training)
    m.addConstr(gp.quicksum(crop_ss[c] * x[c] for c in crops) +
                labor_ss_dairy * y_dairy +
                labor_ss_chicken * y_chicken +
                surplus_ss +
                biosecurity_training_ss_days * b_coop_open <= labor_ss, "Labor_SS")

    # Chicken biosecurity constraints
    # If coop is open, must have at least min_chickens_if_coop_open
    m.addConstr(y_chicken >= min_chickens_if_coop_open * b_coop_open, "Min_Chickens_If_Open")
    # If coop is closed, must have zero chickens (and links b_coop_open to y_chicken)
    m.addConstr(y_chicken <= max_chickens * b_coop_open, "Max_Chickens_If_Open")

    # Second biosecurity inspection cost trigger
    # If y_chicken > second_biosecurity_threshold, b_second_inspection must be 1
    # Using a big-M formulation: y_chicken <= threshold + M * binary_var
    M = max_chickens - second_biosecurity_threshold
    m.addConstr(y_chicken <= second_biosecurity_threshold + M * b_second_inspection, "Second_Inspection_Trigger")

    # Suppress solver output
    m.setParam('OutputFlag', 0)

    # Solve the model
    m.optimize()

    # Output results
    if m.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("No optimal solution found.")
        print("FINAL_OBJ_VALUE: 0")

if __name__ == "__main__":
    main()
