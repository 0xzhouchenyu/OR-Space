import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_distances(data_dir):
    """Load distance data from table_1.csv and return distances and routes."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    distances = {}
    routes = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            yard = row['Coal_Yard'].strip()
            area = int(row['Residential_Area'].strip())
            dist = float(row['Distance_km'].strip())
            key = (yard, area)
            distances[key] = dist
            routes.append(key)
    return distances, routes

def load_parameters(data_dir):
    """Load general parameters from general_parameters.csv"""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    """
    Main function to set up and solve the optimization problem.
    """
    # Define the data directory relative to the script location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")

    # Load data
    distances, routes = load_distances(data_dir)
    params = load_parameters(data_dir)

    # Extract parameters
    min_supply = {
        'A': params['min_coal_yard_A'],
        'B': params['min_coal_yard_B_adjusted']
    }

    demand = {
        1: params['residential_area_1_demand'],
        2: params['residential_area_2_demand'],
        3: params['residential_area_3_demand']
    }
    
    area3_A_staging_threshold = params['area3_A_staging_threshold']
    area3_A_excess_staging_cost = params['area3_A_excess_staging_cost']
    min_share_area3_from_A = params['min_share_area3_from_A']

    coal_yards = ['A', 'B']
    areas = [1, 2, 3]

    # Create the Gurobi model
    model = gp.Model("RevisedCoalDistribution")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # Amount of coal shipped from yard i to area j
    x = model.addVars(routes, name="x", lb=0)

    # Special variables for piecewise cost on route A -> 3
    x_A3_normal = model.addVar(name="x_A3_normal", lb=0)
    x_A3_excess = model.addVar(name="x_A3_excess", lb=0)

    # --- Objective Function ---
    # Minimize total transportation cost
    objective = gp.LinExpr()
    
    # Add standard costs for all routes except A->3
    for (yard, area) in routes:
        if (yard, area) != ('A', 3):
            objective += distances[(yard, area)] * x[(yard, area)]

    # Add piecewise cost for route A->3
    dist_A3 = distances[('A', 3)]
    objective += (dist_A3 * x_A3_normal) + ((dist_A3 + area3_A_excess_staging_cost) * x_A3_excess)
    
    model.setObjective(objective, GRB.MINIMIZE)

    # --- Constraints ---
    # 1. Link total shipment on A->3 to its piecewise components
    if ('A', 3) in x:
        model.addConstr(x[('A', 3)] == x_A3_normal + x_A3_excess, "Link_A3_piecewise")
        model.addConstr(x_A3_normal <= area3_A_staging_threshold, "Threshold_A3_normal")

    # 2. Each coal yard must supply at least its minimum requirement
    for yard in coal_yards:
        model.addConstr(
            gp.quicksum(x[r] for r in routes if r[0] == yard) >= min_supply[yard],
            f"Min_Supply_{yard}"
        )

    # 3. Each residential area must receive exactly its demand
    for area in areas:
        model.addConstr(
            gp.quicksum(x[r] for r in routes if r[1] == area) == demand[area],
            f"Demand_{area}"
        )
        
    # 4. Minimum share of residential area 3 demand from coal yard A
    if ('A', 3) in x:
        model.addConstr(
            x[('A', 3)] >= min_share_area3_from_A * demand[3],
            "Min_Share_A3"
        )

    # Solve the model
    model.optimize()

    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
