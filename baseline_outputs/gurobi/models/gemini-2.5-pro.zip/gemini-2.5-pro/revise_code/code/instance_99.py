import gurobipy as gp
from gurobipy import GRB
import os
import csv
import math

def load_csv(filename):
    """Load a CSV file and return rows as a list of dictionaries."""
    # The prompt specifies this exact path construction.
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    return rows

def load_general_parameters(filename='general_parameters.csv'):
    """Load general parameters from the revised CSV into a dictionary."""
    rows = load_csv(filename)
    params = {}
    for row in rows:
        params[row['Parameter_Name']] = float(row['Value'])
    return params

def load_reliability_table(filename='table_1.csv'):
    """Load reliability table. Returns dict: {num_spares: [r1, r2, r3]}"""
    rows = load_csv(filename)
    reliability = {}
    for row in rows:
        n_spares = int(row['Number_of_Spares'])
        r1 = float(row['Component_1_Reliability'])
        r2 = float(row['Component_2_Reliability'])
        r3 = float(row['Component_3_Reliability'])
        reliability[n_spares] = [r1, r2, r3]
    return reliability

def solve():
    """
    Formulates and solves the revised spare parts optimization problem.
    """
    # 1. Load data from CSV files
    params = load_general_parameters()
    reliability_data = load_reliability_table()

    # 2. Extract and process parameters for the model
    unit_price = [
        params['unit_price_component_1'],
        params['unit_price_component_2'],
        params['unit_price_component_3']
    ]
    unit_weight = [
        params['unit_weight_component_1'],
        params['unit_weight_component_2'],
        params['unit_weight_component_3']
    ]
    
    # According to the revised requirements, the spare package must satisfy
    # the constraints of both scenarios. This means using the minimum of the
    # budget and weight limits.
    total_budget = min(params['total_budget_scenario_A'], params['total_budget_scenario_B'])
    weight_limit = min(params['weight_limit_scenario_A'], params['weight_limit_scenario_B'])

    # Re-structure reliability data for easier access and create log-transformed version
    # for the linearized objective function.
    num_components = 3
    max_spares = max(reliability_data.keys())
    
    reliability_table = [[0.0] * (max_spares + 1) for _ in range(num_components)]
    log_reliability_table = [[0.0] * (max_spares + 1) for _ in range(num_components)]
    
    for n_spares, r_values in reliability_data.items():
        for i in range(num_components):
            reliability_table[i][n_spares] = r_values[i]
            # The objective is to maximize the product of reliabilities. This is equivalent
            # to maximizing the sum of their logarithms.
            if r_values[i] > 0:
                log_reliability_table[i][n_spares] = math.log(r_values[i])
            else:
                # Use a large negative number to make this choice highly undesirable
                log_reliability_table[i][n_spares] = -1e9 

    # 3. Create Gurobi model
    m = gp.Model("RevisedSparePartsOptimization")
    m.setParam('OutputFlag', 0)

    # 4. Define decision variables
    # x[i, j] is a binary variable that is 1 if we choose j spares for component i, and 0 otherwise.
    x = m.addVars(num_components, max_spares + 1, vtype=GRB.BINARY, name="x")

    # 5. Set objective function
    # Maximize the sum of log-reliabilities, which is equivalent to maximizing their product.
    m.setObjective(
        gp.quicksum(log_reliability_table[i][j] * x[i, j] 
                    for i in range(num_components) 
                    for j in range(max_spares + 1)),
        GRB.MAXIMIZE
    )

    # 6. Add constraints
    # Constraint: For each component, exactly one number of spares must be chosen.
    for i in range(num_components):
        m.addConstr(gp.quicksum(x[i, j] for j in range(max_spares + 1)) == 1, name=f"one_choice_c{i}")

    # Constraint: Total cost of spares must not exceed the budget limit.
    m.addConstr(
        gp.quicksum(unit_price[i] * j * x[i, j] 
                    for i in range(num_components) 
                    for j in range(max_spares + 1)) <= total_budget,
        name="budget"
    )

    # Constraint: Total weight of spares must not exceed the weight limit.
    m.addConstr(
        gp.quicksum(unit_weight[i] * j * x[i, j] 
                    for i in range(num_components) 
                    for j in range(max_spares + 1)) <= weight_limit,
        name="weight"
    )

    # 7. Solve the model
    m.optimize()

    # 8. Extract and print the final objective value
    if m.status == GRB.OPTIMAL:
        # The objective is the expected reliability. As per the problem description,
        # this simplifies to the system reliability R1*R2*R3.
        # We calculate this from the optimal solution variables.
        
        # First, find the number of spares chosen for each component.
        spares_chosen = [0] * num_components
        for i in range(num_components):
            for j in range(max_spares + 1):
                if x[i, j].X > 0.5:  # Check if variable is selected
                    spares_chosen[i] = j
                    break
        
        # Then, calculate the system reliability for this configuration.
        final_reliability = 1.0
        for i in range(num_components):
            num_spares = spares_chosen[i]
            final_reliability *= reliability_table[i][num_spares]
            
        print(f"FINAL_OBJ_VALUE: {final_reliability}")
    else:
        # This case should not be reached for this problem as it is feasible
        # (e.g., choosing zero spares for all components is a valid solution).
        print("FINAL_OBJ_VALUE: Error - No optimal solution found.")

if __name__ == "__main__":
    solve()
