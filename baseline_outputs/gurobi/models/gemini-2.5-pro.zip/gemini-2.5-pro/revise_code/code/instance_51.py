import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_demand(filepath):
    """Load nurse demand per time period from CSV."""
    demand = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            demand.append(int(row['Required_Nurses']))
    return demand

def load_parameters(filepath):
    """Load general parameters from CSV."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = row['Value']
    return params

def solve_revised_problem():
    """
    Solves the revised nurse scheduling problem using Gurobi.
    """
    # --- 1. Data Loading and Parameter Setup ---
    
    # Define file paths relative to the script location
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    demand_filepath = os.path.join(data_dir, 'table_1.csv')
    params_filepath = os.path.join(data_dir, 'general_parameters.csv')

    # Load data from CSV files
    demand = load_demand(demand_filepath)
    params = load_parameters(params_filepath)

    # Extract and process parameters
    shift_duration = int(params['shift_duration'])
    regular_pay = float(params['regular_nurse_pay'])
    contract_pay = float(params['contract_nurse_pay'])
    
    outsourced_regular_start_index = int(params['outsourced_regular_start_index'])
    banned_contract_start_index = int(params['banned_contract_start_index'])
    max_total_contract_starts = int(params['max_total_contract_starts'])
    min_regular_daytime_coverage = int(params['min_regular_daytime_coverage'])
    daytime_period_indices = [int(i) for i in params['daytime_period_indices'].split(';')]

    num_periods = len(demand)
    periods = range(num_periods)

    # --- 2. Model Formulation ---

    # Create a new model
    m = gp.Model("RevisedNurseScheduling")
    m.setParam('OutputFlag', 0)

    # Decision variables
    # x[j]: number of regular nurses starting shift j
    # y[j]: number of contract nurses starting shift j
    x = m.addVars(periods, vtype=GRB.INTEGER, name="Regular", lb=0)
    y = m.addVars(periods, vtype=GRB.INTEGER, name="Contract", lb=0)

    # Objective function: Minimize total cost
    regular_shift_cost = regular_pay * shift_duration
    contract_shift_cost = contract_pay * shift_duration
    
    m.setObjective(
        gp.quicksum(regular_shift_cost * x[j] + contract_shift_cost * y[j] for j in periods),
        GRB.MINIMIZE
    )

    # --- 3. Constraints ---

    # Constraint 1: Demand coverage for each period
    # Nurses working in period i are those who started in shift i-1 and shift i.
    # The modulo operator handles the wrap-around for the first period.
    for i in periods:
        nurses_on_duty = x[i] + y[i] + x[(i - 1 + num_periods) % num_periods] + y[(i - 1 + num_periods) % num_periods]
        m.addConstr(nurses_on_duty >= demand[i], f"Demand_period_{i}")

    # Constraint 2: Shift start restrictions
    # Regular nurses cannot start the outsourced shift
    m.addConstr(x[outsourced_regular_start_index] == 0, "Outsourced_Regular_Start")
    # Contract nurses cannot start the banned overnight shift
    m.addConstr(y[banned_contract_start_index] == 0, "Banned_Contract_Start")

    # Constraint 3: Cap on total contract nurse starts
    m.addConstr(gp.quicksum(y[j] for j in periods) <= max_total_contract_starts, "Max_Contract_Starts")

    # Constraint 4: Minimum regular nurse coverage during daytime periods
    for i in daytime_period_indices:
        regular_nurses_on_duty = x[i] + x[(i - 1 + num_periods) % num_periods]
        m.addConstr(regular_nurses_on_duty >= min_regular_daytime_coverage, f"Min_Regular_Daytime_Coverage_{i}")

    # --- 4. Solve and Output ---

    # Optimize the model
    m.optimize()

    # Print the final objective value in the required format
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_revised_problem()
