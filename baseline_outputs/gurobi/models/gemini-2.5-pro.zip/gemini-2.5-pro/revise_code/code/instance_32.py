import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    This function formulates and solves the revised production planning problem.
    """
    # --- 1. Data Loading ---
    
    # Define base directory for file access
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            try:
                value = float(row['Value'].strip())
            except ValueError:
                value = row['Value'].strip()
            params[param_name] = value

    # Load workshop-specific data from table_1.csv
    workshops = []
    rates = {}  # rates[(workshop, component)]
    
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            w = row['Workshop'].strip()
            workshops.append(w)
            rates[(w, 1)] = float(row['Production_Rate_Component_1_units_per_hour'].strip())
            rates[(w, 2)] = float(row['Production_Rate_Component_2_units_per_hour'].strip())
            rates[(w, 3)] = float(row['Production_Rate_Component_3_units_per_hour'].strip())

    # Define model sets
    components = [1, 2, 3]
    shifts = ['day', 'night']
    time_types = ['reg', 'ot']

    # --- 2. Model Initialization ---
    
    model = gp.Model("RevisedProductionPlan")
    model.setParam('OutputFlag', 0)

    # --- 3. Decision Variables ---

    # h[w, c, s, t]: hours workshop 'w' allocates to component 'c' in shift 's' of time type 't'
    h = model.addVars(workshops, components, shifts, time_types, name="h", lb=0)

    # y[w, s]: binary, 1 if workshop 'w' is active in shift 's'
    y = model.addVars(workshops, shifts, name="y", vtype=GRB.BINARY)

    # z: number of completed products
    z = model.addVar(name="z", lb=0)

    # shortfall: units below the target z_target
    shortfall = model.addVar(name="shortfall", lb=0)

    # --- 4. Objective Function ---
    
    # Minimize total penalty costs
    
    # Penalty for night shift regular hours
    night_penalty = gp.quicksum(
        params['penalty_night_hour'] * h[w, c, 'night', 'reg']
        for w in workshops for c in components
    )

    # Penalty for overtime hours (any shift)
    overtime_penalty = gp.quicksum(
        params['penalty_overtime_hour'] * h[w, c, s, 'ot']
        for w in workshops for c in components for s in shifts
    )

    # Penalty for shortfall from target
    shortfall_penalty = params['penalty_shortage_per_unit'] * shortfall

    model.setObjective(night_penalty + overtime_penalty + shortfall_penalty, GRB.MINIMIZE)

    # --- 5. Constraints ---

    # Hour limits for each workshop, shift, and time type
    for w in workshops:
        # Regular hours limits
        model.addConstr(gp.quicksum(h[w, c, 'day', 'reg'] for c in components) <= params[f'regular_hours_limit_day_{w}'], f"RegDayLimit_{w}")
        model.addConstr(gp.quicksum(h[w, c, 'night', 'reg'] for c in components) <= params[f'regular_hours_limit_night_{w}'], f"RegNightLimit_{w}")
        
        # Overtime hours limits
        model.addConstr(gp.quicksum(h[w, c, 'day', 'ot'] for c in components) <= params[f'overtime_capacity_day_{w}'], f"OtDayLimit_{w}")
        model.addConstr(gp.quicksum(h[w, c, 'night', 'ot'] for c in components) <= params[f'overtime_capacity_night_{w}'], f"OtNightLimit_{w}")

    # Production constraints: z is the minimum of total components produced
    for c in components:
        total_production_c = gp.quicksum(
            rates[w, c] * h.sum(w, c, '*', '*') for w in workshops
        )
        model.addConstr(z <= total_production_c, f"Production_{c}")

    # Target fulfillment constraint
    model.addConstr(z + shortfall >= params['z_target'], "TargetFulfillment")

    # Supervision constraint: no more than two workshops active per shift
    for s in shifts:
        model.addConstr(gp.quicksum(y[w, s] for w in workshops) <= 2, f"Supervision_{s}")

    # Big-M constraints: link active status (y) to hours worked (h)
    for w in workshops:
        for s in shifts:
            total_hours_in_shift = gp.quicksum(h[w, c, s, t] for c in components for t in time_types)
            big_m_val = params[f'bigM_shift_{w}']
            model.addConstr(total_hours_in_shift <= big_m_val * y[w, s], f"BigM_{w}_{s}")

    # --- 6. Solve and Output ---
    
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
