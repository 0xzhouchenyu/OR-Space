import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    """
    Solves the revised worker assignment problem.
    """
    # --- Data Loading ---
    # The script is executed from the workspace root, so data is in 'data/'
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        data_dir = os.path.join(base_dir, "data")

        # Load general parameters from general_parameters.csv
        params = {}
        with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            for row in reader:
                if row:
                    params[row[0]] = float(row[1])

        cost_III_V = params['shared_temp_handoff_cost']
        cost_II_V = params['worker_II_V_pair_fee']

        # Load worker-task costs and fixed costs from table_1.csv
        workers = []
        tasks = []
        assignment_costs = {}
        fixed_costs = {}
        with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            header = next(reader)
            tasks = header[1:-1]  # e.g., ['A', 'B', 'C', 'D']
            
            for row in reader:
                worker = row[0]
                workers.append(worker)
                
                # Assignment costs for each task
                for i, task in enumerate(tasks):
                    assignment_costs[(worker, task)] = int(row[i + 1])
                
                # Fixed cost for using the worker
                fixed_costs[worker] = int(row[-1])

    except FileNotFoundError as e:
        print(f"Error: Data file not found. {e}")
        return
    except (KeyError, IndexError) as e:
        print(f"Error: Data file format is incorrect. {e}")
        return

    # --- Model Formulation ---
    m = gp.Model("RevisedAssignment")
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # x[w, t]: 1 if worker w is assigned to task t, 0 otherwise
    x = m.addVars(workers, tasks, vtype=GRB.BINARY, name="x")
    
    # y[w]: 1 if worker w is selected for any task, 0 otherwise
    y = m.addVars(workers, vtype=GRB.BINARY, name="y")
    
    # z_III_V: 1 if both workers III and V are selected
    z_III_V = m.addVar(vtype=GRB.BINARY, name="z_III_V")
    
    # z_II_V: 1 if both workers II and V are selected
    z_II_V = m.addVar(vtype=GRB.BINARY, name="z_II_V")

    # --- Objective Function ---
    # Minimize total cost: assignment costs + fixed costs + conditional pairing costs
    total_assignment_cost = gp.quicksum(assignment_costs[w, t] * x[w, t] for w, t in assignment_costs)
    total_fixed_cost = gp.quicksum(fixed_costs[w] * y[w] for w in workers)
    total_pairing_cost = cost_III_V * z_III_V + cost_II_V * z_II_V
    
    m.setObjective(total_assignment_cost + total_fixed_cost + total_pairing_cost, GRB.MINIMIZE)

    # --- Constraints ---
    # 1. Each task must be assigned to exactly one worker.
    m.addConstrs((x.sum('*', t) == 1 for t in tasks), name="TaskCoverage")

    # 2. Link worker selection (y) to task assignments (x).
    # This also ensures a worker is assigned to at most one task.
    m.addConstrs((x.sum(w, '*') == y[w] for w in workers), name="WorkerUsage")

    # 3. Exactly 4 workers must be selected for the 4 tasks.
    m.addConstr(y.sum() == 4, name="TotalWorkers")

    # 4. Define pairing cost for workers III and V.
    # z_III_V = 1 if y['III'] = 1 AND y['V'] = 1
    m.addConstr(z_III_V >= y['III'] + y['V'] - 1, name="Pairing_III_V")

    # 5. Define pairing cost for workers II and V.
    # z_II_V = 1 if y['II'] = 1 AND y['V'] = 1
    m.addConstr(z_II_V >= y['II'] + y['V'] - 1, name="Pairing_II_V")

    # --- Solve and Output ---
    m.optimize()

    if m.status == GRB.OPTIMAL:
        # Print the final objective value as required
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
