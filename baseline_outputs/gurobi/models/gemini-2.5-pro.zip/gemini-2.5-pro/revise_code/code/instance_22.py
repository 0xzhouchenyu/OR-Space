import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def load_data():
    """
    Loads all data from the data subdirectory, merges product tables,
    and parses general parameters into a dictionary.
    """
    # Correctly locate the data directory relative to the script's location
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')

    # Load product-specific data
    t1 = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))
    t2 = pd.read_csv(os.path.join(data_dir, 'table_2.csv'))
    t3 = pd.read_csv(os.path.join(data_dir, 'table_3.csv'))

    # Merge product data into a single DataFrame and set Product as index
    df = t1.merge(t2, on='Product').merge(t3, on='Product')
    df.set_index('Product', inplace=True)

    # Load and parse general parameters
    gp_df = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    params = pd.Series(gp_df.Value.values, index=gp_df.Parameter_Name).to_dict()

    # Convert numeric parameter values from string/object to float
    for k, v in params.items():
        try:
            params[k] = float(v)
        except (ValueError, TypeError):
            # Keep as string if conversion fails
            pass
            
    return df, params

def solve():
    """
    Builds and solves the revised production planning MIP model using Gurobi.
    """
    # Load data from CSV files
    df, params = load_data()
    products = df.index.tolist()

    # Create a new Gurobi model
    m = gp.Model("RevisedProductionPlanning")
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---

    # Production quantity for each product
    x = m.addVars(products, name="x", lb=0)

    # Binary variable: 1 if product p is produced, 0 otherwise
    y = m.addVars(products, name="y", vtype=GRB.BINARY)

    # Binary variables for A1 production thresholds
    z_watch = m.addVar(name="z_watch", vtype=GRB.BINARY)
    z_deep = m.addVar(name="z_deep", vtype=GRB.BINARY)

    # Continuous variable for A1 quantity above the watch threshold (eligible for price lift)
    x_a1_prio = m.addVar(name="x_a1_prio", lb=0)

    # --- Objective Function ---

    # Base profit from all products (revenue - production cost - activation cost)
    base_profit = gp.quicksum(
        (df.loc[p, 'Selling_Price'] - df.loc[p, 'Production_Cost']) * x[p] - df.loc[p, 'Activation_Cost'] * y[p]
        for p in products
    )

    # Additional revenue and costs for A1 based on production levels
    a1_adjustments = (
        params['a1_priority_price_lift'] * x_a1_prio
        - params['a1_quality_release_fee'] * z_watch
        - params['a1_deep_service_fee'] * z_deep
    )

    m.setObjective(base_profit + a1_adjustments, GRB.MAXIMIZE)

    # --- Constraints ---

    # The company plans to produce all three types of products
    for p in products:
        m.addConstr(y[p] == 1, name=f"activate_{p}")

    # Link production quantity to activation, enforcing min/max and batch size limits
    for p in products:
        m.addConstr(x[p] <= df.loc[p, 'Maximum_Demand'] * y[p], name=f"max_demand_{p}")
        m.addConstr(x[p] >= df.loc[p, 'Minimum_Batch'] * y[p], name=f"min_batch_{p}")

    # Production capacity constraint (days), adjusted for A1 penalties
    total_days_used = gp.quicksum(x[p] / df.loc[p, 'Production_Quota'] for p in products)
    day_penalties = params['maintenance_penalty_watch'] * z_watch + params['maintenance_penalty_deep'] * z_deep
    available_days = params['production_days'] - day_penalties
    m.addConstr(total_days_used <= available_days, name="production_days")

    # --- Special Constraints for Product A1 ---

    # Link binary z_watch to A1 production level. z_watch = 1 if x['A1'] >= a1_watch_threshold
    m.addGenConstrIndicator(z_watch, True, x['A1'], GRB.GREATER_EQUAL, params['a1_watch_threshold'])
    m.addGenConstrIndicator(z_watch, False, x['A1'], GRB.LESS_EQUAL, params['a1_watch_threshold'] - 1e-6)

    # Link binary z_deep to A1 production level. z_deep = 1 if x['A1'] >= a1_deep_service_threshold
    m.addGenConstrIndicator(z_deep, True, x['A1'], GRB.GREATER_EQUAL, params['a1_deep_service_threshold'])
    m.addGenConstrIndicator(z_deep, False, x['A1'], GRB.LESS_EQUAL, params['a1_deep_service_threshold'] - 1e-6)

    # Define x_a1_prio as the amount of A1 produced above the watch threshold
    # This models: x_a1_prio = max(0, x['A1'] - a1_watch_threshold)
    x_a1_diff = m.addVar(lb=-GRB.INFINITY, name="x_a1_diff")
    m.addConstr(x_a1_diff == x['A1'] - params['a1_watch_threshold'])
    m.addGenConstrMax(x_a1_prio, [x_a1_diff, 0.0])

    # --- Solve the Model ---
    m.optimize()

    # Return the optimal objective value
    return m.ObjVal

if __name__ == "__main__":
    # Execute the solver and print the final result
    objective_value = solve()
    print(f"FINAL_OBJ_VALUE: {objective_value}")
