import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    Solves the revised factory assignment and handling mode selection problem.
    """
    # --- 1. Data Loading and Parameter Setup ---
    try:
        # This works when the script is run as a file.
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Fallback for interactive environments.
        base_dir = os.getcwd()

    data_dir = os.path.join(base_dir, "data")

    # Load general parameters from CSV
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] and row['Value']:
                try:
                    params[row['Parameter_Name']] = float(row['Value'])
                except (ValueError, TypeError):
                    params[row['Parameter_Name']] = row['Value']

    n = int(params['n'])
    premium_cost_multiplier = params['premium_cost_multiplier']
    min_premium_share = params['min_premium_share']

    # Load table data from table_1.csv
    rows_data = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', newline='') as f:
        reader = csv.DictReader(f)
        rows_data = list(reader)

    # d[i][j]: volume from factory i to market j
    # c[p][q]: cost from location p to location q
    d = []
    c = []
    for i in range(n):
        row = rows_data[i]
        d.append([float(row[f'Transportation_volume_to_Location_{j+1}']) for j in range(n)])
        c.append([float(row[f'Transportation_cost_to_Location_{j+1}']) for j in range(n)])

    # --- 2. Pre-calculation of Model Coefficients ---

    # Calculate total outbound volume for each factory
    outbound_volume = [sum(d[i]) for i in range(n)]

    base_cost = {}          # Cost of assigning factory i to location p with standard handling
    premium_surcharge = {}  # Additional cost for choosing premium handling

    for i in range(n):
        for p in range(n):
            # BaseCost_ip = sum_j d_ij * c_pj
            # This is the total transport cost if factory i is at location p.
            cost_ip = 0.0
            if outbound_volume[i] > 0:
                for j in range(n):
                    cost_ip += d[i][j] * c[p][j]
            
            base_cost[i, p] = cost_ip

            # Surcharge = (min_share * out_vol) * (c_prem - c_std)
            #           = min_share * (multiplier - 1) * (out_vol * c_std)
            #           = min_share * (multiplier - 1) * BaseCost
            surcharge_ip = min_premium_share * (premium_cost_multiplier - 1) * cost_ip
            premium_surcharge[i, p] = surcharge_ip

    # --- 3. Gurobi Model Formulation ---

    m = gp.Model("FactoryAssignmentRevised")
    m.setParam('OutputFlag', 0)

    # x[i, p] = 1 if factory i is assigned to location p
    x = m.addVars(n, n, vtype=GRB.BINARY, name="x")
    # y[i, p] = 1 if premium mode is chosen for factory i at location p
    y = m.addVars(n, n, vtype=GRB.BINARY, name="y")

    # Objective: Minimize total cost
    objective = gp.quicksum(base_cost[i, p] * x[i, p] + premium_surcharge[i, p] * y[i, p]
                            for i in range(n) for p in range(n))
    m.setObjective(objective, GRB.MINIMIZE)

    # --- 4. Constraints ---

    # Each factory must be assigned to exactly one location
    m.addConstrs((x.sum(i, '*') == 1 for i in range(n)), "FactoryAssignment")

    # Each location hosts exactly one factory
    m.addConstrs((x.sum('*', p) == 1 for p in range(n)), "LocationAssignment")

    # Premium mode can only be selected for an active assignment
    m.addConstrs((y[i, p] <= x[i, p] for i in range(n) for p in range(n)), "PremiumLogic")

    # --- 5. Solve and Output ---

    m.optimize()

    if m.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        # This path should not be taken for this problem, but is good practice.
        print("FINAL_OBJ_VALUE: No optimal solution found.")

if __name__ == "__main__":
    solve()
