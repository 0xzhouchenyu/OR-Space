import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_processing_times(filepath):
    """Load processing times from CSV file.
    Returns a list of lists: processing_times[i][j] = time for product i on machine j.
    """
    processing_times = []
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # Skip header
        for row in reader:
            # First column is product name, rest are processing times
            times = [int(val) for val in row[1:]]
            processing_times.append(times)
    return processing_times

def load_general_parameters(filepath):
    """Load general parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if not row: continue
            param_name = row[0]
            try:
                value = float(row[1])
                if value.is_integer():
                    value = int(value)
            except (ValueError, IndexError):
                value = row[1]
            params[param_name] = value
    return params

def main():
    """
    Solves the revised flow shop scheduling problem with overtime and special costs.
    """
    # --- 1. Load Data ---
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    params_filepath = os.path.join(data_dir, 'general_parameters.csv')
    times_filepath = os.path.join(data_dir, 'table_1.csv')

    params = load_general_parameters(params_filepath)
    processing_times = load_processing_times(times_filepath)

    # --- 2. Problem Constants ---
    n_products = len(processing_times)
    n_machines = len(processing_times[0]) if n_products > 0 else 0
    
    products = range(n_products)
    machines = range(n_machines)

    time_windows = [params['time_window_1'], params['time_window_2'], params['time_window_3']]
    overtime_windows = [params['overtime_window_1'], params['overtime_window_2'], params['overtime_window_3']]
    overtime_penalty = params['overtime_penalty_per_unit']
    m1_review_threshold = params['machine1_overtime_review_threshold']
    m1_review_fee = params['machine1_overtime_review_fee']
    bigM = [params['M_1'], params['M_2'], params['M_3']]

    # --- 3. Create Gurobi Model ---
    model = gp.Model("RevisedFlowShop")
    model.setParam('OutputFlag', 0)

    # --- 4. Define Decision Variables ---
    # S_ij: Start time of product i on machine j
    S = model.addVars(products, machines, name="S", lb=0)
    
    # C_ij: Completion time of product i on machine j
    C = model.addVars(products, machines, name="C", lb=0)

    # y_ik: Binary variable, 1 if product i is processed before product k
    y = model.addVars([(i, k) for i in products for k in products if i < k], vtype=GRB.BINARY, name="y")

    # C_max: Makespan (total processing cycle)
    C_max = model.addVar(name="C_max", lb=0)

    # L_j: Latest completion time on machine j
    L = model.addVars(machines, name="L", lb=0)

    # O_j: Overtime used on machine j
    O = model.addVars(machines, name="O", lb=0)

    # z_1: Binary variable, 1 if Machine 1 overtime exceeds the review threshold
    z_1 = model.addVar(vtype=GRB.BINARY, name="z_1")

    # --- 5. Set Objective Function ---
    # The objective is to minimize a total cost function comprising makespan, overtime penalties, and the special review fee.
    total_overtime_cost = overtime_penalty * gp.quicksum(O[j] for j in machines)
    m1_review_cost = m1_review_fee * z_1
    
    model.setObjective(C_max + total_overtime_cost + m1_review_cost, GRB.MINIMIZE)

    # --- 6. Add Constraints ---
    # Relation between start and completion times
    model.addConstrs((C[i, j] == S[i, j] + processing_times[i][j] for i in products for j in machines), name="completion_time")

    # Job precedence constraints (flow shop: machine 1 -> 2 -> 3)
    model.addConstrs((S[i, j + 1] >= C[i, j] for i in products for j in range(n_machines - 1)), name="job_precedence")

    # Machine precedence constraints (disjunctive: only one job at a time on a machine)
    for j in machines:
        for i in products:
            for k in products:
                if i < k:
                    # S_kj >= C_ij OR S_ij >= C_kj
                    model.addConstr(S[k, j] >= C[i, j] - bigM[j] * (1 - y[i, k]), name=f"disj_{i}_{k}_{j}_1")
                    model.addConstr(S[i, j] >= C[k, j] - bigM[j] * y[i, k], name=f"disj_{i}_{k}_{j}_2")

    # Makespan definition
    model.addConstrs((C_max >= C[i, n_machines - 1] for i in products), name="makespan_def")

    # Overtime calculation
    # 1. Latest completion time on each machine
    model.addConstrs((L[j] >= C[i, j] for i in products for j in machines), name="latest_completion")
    
    # 2. Overtime is the amount by which latest completion exceeds the regular time window
    model.addConstrs((O[j] >= L[j] - time_windows[j] for j in machines), name="overtime_calc")
    
    # 3. Total machine time (including overtime) cannot exceed the max availability
    model.addConstrs((L[j] <= time_windows[j] + overtime_windows[j] for j in machines), name="max_availability")

    # Machine 1 special review fee constraint
    # z_1 must be 1 if O[0] > m1_review_threshold.
    # This is modeled as: O[0] <= m1_review_threshold + M * z_1
    # A suitable M is the maximum possible value of O[0], which is overtime_windows[0].
    m_special = overtime_windows[0]
    model.addConstr(O[0] <= m1_review_threshold + m_special * z_1, name="m1_review_fee_trigger")

    # --- 7. Solve the Model ---
    model.optimize()

    # --- 8. Print the Final Objective Value ---
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # This part is for robustness in case a solution is not found
        print("FINAL_OBJ_VALUE: Error - No optimal solution found.")

if __name__ == "__main__":
    main()
