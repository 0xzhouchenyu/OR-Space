import gurobipy as gp
from gurobipy import GRB
import os
import csv

def solve_dairy_production():
    """
    Formulates and solves the revised dairy production optimization problem.
    """
    # --- Data Loading ---
    # The script is executed from the root, so the path is relative to the root.
    # Using the robust path construction as per instructions.
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Handle case where __file__ is not defined (e.g., interactive environment)
        script_dir = os.getcwd()
        
    data_path = os.path.join(script_dir, "data", "general_parameters.csv")

    params = {}
    with open(data_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            try:
                val = float(row['Value'].strip())
                params[name] = val
            except (ValueError, TypeError):
                # Handle non-numeric values if any, though not expected here
                params[name] = row['Value'].strip()

    # --- Model Formulation ---
    m = gp.Model("RevisedDairyProduction")

    # --- Decision Variables ---
    # x1, x2, x3: barrels of milk allocated to products A1, A2, A3
    x1 = m.addVar(name="x1", lb=0.0)  # Barrels for A1
    x2 = m.addVar(name="x2", lb=0.0)  # Barrels for A2
    x3 = m.addVar(name="x3", lb=0.0)  # Barrels for A3

    # y_A3: binary variable, 1 if product A3 is produced, 0 otherwise
    y_A3 = m.addVar(name="y_A3", vtype=GRB.BINARY)

    # z_bonus: binary variable, 1 if cold-chain bonus for A3 is achieved, 0 otherwise
    z_bonus = m.addVar(name="z_bonus", vtype=GRB.BINARY)

    # --- Objective Function ---
    # Maximize total profit from product sales plus any bonuses
    profit_A1 = params['profit_per_kg_A1'] * params['product_A1_yield'] * x1
    profit_A2 = params['profit_per_kg_A2'] * params['product_A2_yield'] * x2
    profit_A3 = params['profit_per_kg_A3'] * params['product_A3_yield'] * x3
    bonus_A3 = params['cold_chain_bonus_yuan'] * z_bonus

    m.setObjective(profit_A1 + profit_A2 + profit_A3 + bonus_A3, GRB.MAXIMIZE)

    # --- Constraints ---
    # 1. Milk Supply: Total milk used cannot exceed daily supply
    m.addConstr(x1 + x2 + x3 <= params['daily_milk_supply'], "Milk_Supply")

    # 2. Labor Hours: Total labor hours used cannot exceed daily availability
    m.addConstr(params['product_A1_time'] * x1 +
                params['product_A2_time'] * x2 +
                params['product_A3_time'] * x3 <= params['daily_labor_hours'], "Labor_Hours")

    # 3. Minimum A2 Production (Butter Bundle)
    m.addConstr(params['product_A2_yield'] * x2 >= params['min_A2_kg'], "Min_A2_Production")

    # 4. Type A Shared Capacity & Cleaning Logic
    # If A3 is produced (y_A3=1), capacity is reduced by the cleaning loss.
    m.addConstr(params['product_A1_yield'] * x1 +
                params['product_A3_yield'] * x3 <=
                params['cap_A_shared'] - params['type_A_cleaning_loss_if_A3'] * y_A3,
                "Type_A_Shared_Capacity")

    # 5. A3 Production Logic (Semi-continuous)
    # If A3 is produced (y_A3=1), its production must meet a minimum threshold.
    m.addConstr(params['product_A3_yield'] * x3 >= params['min_A3_kg'] * y_A3, "Min_A3_If_Produced")
    # If A3 is not produced (y_A3=0), the amount of milk for it must be zero.
    # Using daily_milk_supply as a safe "Big M".
    m.addConstr(x3 <= params['daily_milk_supply'] * y_A3, "Link_x3_y_A3")

    # 6. Cold-Chain Bonus Logic
    # The bonus can only be achieved if A3 production reaches the threshold.
    m.addConstr(params['product_A3_yield'] * x3 >= params['cold_chain_bonus_threshold_kg'] * z_bonus,
                "Bonus_Threshold")
    # The bonus cannot be achieved if A3 is not produced at all.
    m.addConstr(z_bonus <= y_A3, "Link_Bonus_to_Production")

    # --- Solve ---
    m.setParam('OutputFlag', 0)  # Suppress Gurobi solver output
    m.optimize()

    # --- Output ---
    if m.status == GRB.OPTIMAL:
        final_obj_value = m.ObjVal
    else:
        final_obj_value = 0 # Or handle other statuses as needed

    print(f"FINAL_OBJ_VALUE: {final_obj_value}")

if __name__ == "__main__":
    solve_dairy_production()
