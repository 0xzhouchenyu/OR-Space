import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_monthly_data(filepath):
    """Load monthly purchasing and selling price data."""
    months = []
    purchasing_prices = {}
    selling_prices = {}
    
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            month = int(row['Month'])
            months.append(month)
            purchasing_prices[month] = float(row['Purchasing_Price_Yuan'])
            selling_prices[month] = float(row['Selling_Price_Yuan'])
    
    # Ensure months are sorted for sequential processing
    months.sort()
    return months, purchasing_prices, selling_prices

def load_general_parameters(filepath):
    """Load general parameters."""
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

# --- Main Script ---

# 1. Construct file paths and load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")
monthly_data_path = os.path.join(data_dir, "table_1.csv")
general_params_path = os.path.join(data_dir, "general_parameters.csv")

months, purchasing_prices, selling_prices = load_monthly_data(monthly_data_path)
params = load_general_parameters(general_params_path)

# Assign parameters to variables for clarity
warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
fixed_ordering_cost = params['fixed_ordering_cost']
month2_bulk_receiving_threshold = params['month2_bulk_receiving_threshold']
month2_bulk_receiving_fee = params['month2_bulk_receiving_fee']

# 2. Create Gurobi Model
model = gp.Model("MaximizeProfitRevised")
model.setParam('OutputFlag', 0)

# 3. Define Decision Variables
# Continuous variables
purchase = model.addVars(months, name="purchase", lb=0)
sell = model.addVars(months, name="sell", lb=0)
inventory = model.addVars(months, name="inventory", lb=0)

# Binary variables for fixed costs
is_purchased = model.addVars(months, name="is_purchased", vtype=GRB.BINARY)
is_feb_bulk = model.addVar(name="is_feb_bulk", vtype=GRB.BINARY)

# 4. Set Objective Function
total_revenue = gp.quicksum(sell[m] * selling_prices[m] for m in months)
variable_purchase_cost = gp.quicksum(purchase[m] * purchasing_prices[m] for m in months)
total_fixed_ordering_cost = gp.quicksum(is_purchased[m] * fixed_ordering_cost for m in months)
feb_special_fee = is_feb_bulk * month2_bulk_receiving_fee

model.setObjective(
    total_revenue - variable_purchase_cost - total_fixed_ordering_cost - feb_special_fee,
    GRB.MAXIMIZE
)

# 5. Add Constraints
for m in months:
    # Determine previous month's inventory
    if m == months[0]:
        prev_inv = initial_stock
    else:
        prev_inv = inventory[m - 1]

    # Inventory balance: inv[m] = prev_inv + purchase[m] - sell[m]
    model.addConstr(inventory[m] == prev_inv + purchase[m] - sell[m], f"inventory_balance_{m}")

    # Sales limit: cannot sell more than what's available
    model.addConstr(sell[m] <= prev_inv + purchase[m], f"sell_limit_{m}")

    # Warehouse capacity: stock after purchasing cannot exceed capacity
    model.addConstr(prev_inv + purchase[m] <= warehouse_capacity, f"warehouse_capacity_{m}")

    # Fixed ordering cost link (Big-M): if purchase[m] > 0, then is_purchased[m] must be 1
    # M = warehouse_capacity is a safe upper bound on any single purchase amount
    model.addConstr(purchase[m] <= warehouse_capacity * is_purchased[m], f"link_purchase_{m}")

# February special fee constraint (Big-M)
month_feb = 2
# If purchase[2] > threshold, then is_feb_bulk must be 1
# M can be warehouse_capacity, but a tighter M is better.
# Max value of (purchase[2] - threshold) is (warehouse_capacity - threshold)
M_feb = warehouse_capacity - month2_bulk_receiving_threshold
model.addConstr(purchase[month_feb] - month2_bulk_receiving_threshold <= M_feb * is_feb_bulk, "feb_bulk_fee_link")

# 6. Solve the model
model.optimize()

# 7. Print the final objective value as required
if model.Status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("No optimal solution found.")
