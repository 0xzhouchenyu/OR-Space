import os
import csv
import gurobipy as gp
from gurobipy import GRB

# This script solves the revised oil blending optimization problem.
# It determines the optimal purchasing and processing plan to maximize profit,
# incorporating all original and revised business requirements.

# --- 1. Load Parameters ---
# The script is expected to be run from the workspace root, with data in a 'data' subdirectory.
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params_file = os.path.join(data_dir, 'general_parameters.csv')

params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'].strip())


# --- 2. Extract and Assign Parameters ---
# Blending and Sales
min_A_I = params['min_proportion_crude_A_type_I'] / 100.0
min_A_II = params['min_proportion_crude_A_type_II'] / 100.0
price_I = params['selling_price_type_I']
price_II = params['selling_price_type_II']

# Inventory and Purchasing
inv_A = params['inventory_crude_A']
inv_B = params['inventory_crude_B']
max_purchase_A = params['max_purchase_crude_A']
cost_tier1 = params['market_price_crude_A_tier_1']
cost_tier2 = params['market_price_crude_A_tier_2']
cost_tier3 = params['market_price_crude_A_tier_3']
tier_size = 500.0  # Deduced from original heuristic and problem structure

# Processing
processing_capacity = params['processing_capacity']
min_total_gasoline_output = params['min_total_gasoline_output']
processing_cost_per_ton = params['processing_cost_per_ton']

# Commercial Thresholds (Revisions)
type_II_contract_threshold = params['type_II_contract_threshold']
type_II_price_lift = params['type_II_price_lift']
bulk_purchase_rebate_threshold = params['bulk_purchase_rebate_threshold']
bulk_purchase_rebate = params['bulk_purchase_rebate']


# --- 3. Initialize Gurobi Model ---
m = gp.Model("Revised_Oil_Blending")
m.setParam('OutputFlag', 0)


# --- 4. Define Decision Variables ---
# Amounts of crude oil to blend
a1 = m.addVar(name="crude_A_in_I", lb=0)
a2 = m.addVar(name="crude_A_in_II", lb=0)
b1 = m.addVar(name="crude_B_in_I", lb=0)
b2 = m.addVar(name="crude_B_in_II", lb=0)

# Tiered purchase variables for crude A
p1 = m.addVar(name="purchase_tier1", lb=0, ub=tier_size)
p2 = m.addVar(name="purchase_tier2", lb=0, ub=tier_size)
p3 = m.addVar(name="purchase_tier3", lb=0, ub=max_purchase_A - 2 * tier_size)

# Binary variables to enforce tiered purchasing order
y_tier2_active = m.addVar(name="y_tier2_active", vtype=GRB.BINARY)
y_tier3_active = m.addVar(name="y_tier3_active", vtype=GRB.BINARY)

# Binary variables for the revised commercial thresholds
z_price_lift = m.addVar(name="z_price_lift", vtype=GRB.BINARY)
z_rebate = m.addVar(name="z_rebate", vtype=GRB.BINARY)

# Helper variable to linearize the conditional revenue lift
revenue_lift = m.addVar(name="revenue_lift", lb=0)


# --- 5. Define Helper Expressions ---
total_gasoline_I = a1 + b1
total_gasoline_II = a2 + b2
total_gasoline = total_gasoline_I + total_gasoline_II
total_A_purchased = p1 + p2 + p3


# --- 6. Set Objective Function (Maximize Profit) ---
# Revenue = Base Sales + Conditional Lift
base_revenue = price_I * total_gasoline_I + price_II * total_gasoline_II
lift_revenue = type_II_price_lift * revenue_lift
total_revenue = base_revenue + lift_revenue

# Cost = Purchase Cost + Processing Cost - Conditional Rebate
purchase_cost = cost_tier1 * p1 + cost_tier2 * p2 + cost_tier3 * p3
processing_cost = processing_cost_per_ton * total_gasoline
rebate = bulk_purchase_rebate * z_rebate
total_cost = purchase_cost + processing_cost - rebate

m.setObjective(total_revenue - total_cost, GRB.MAXIMIZE)


# --- 7. Add Constraints ---
# Supply constraints for crude oils
m.addConstr(a1 + a2 <= inv_A + total_A_purchased, "crude_A_supply")
m.addConstr(b1 + b2 <= inv_B, "crude_B_supply")
m.addConstr(total_A_purchased <= max_purchase_A, "max_purchase_A_limit")

# Blending quality constraints (minimum proportion of crude A)
m.addConstr(a1 >= min_A_I * total_gasoline_I, "quality_gasoline_I")
m.addConstr(a2 >= min_A_II * total_gasoline_II, "quality_gasoline_II")

# Tiered purchasing constraints for crude A
m.addConstr(p1 >= tier_size * y_tier2_active, "force_tier1_full_for_tier2")
m.addConstr(p2 <= tier_size * y_tier2_active, "enable_tier2_use")
m.addConstr(p2 >= tier_size * y_tier3_active, "force_tier2_full_for_tier3")
m.addConstr(p3 <= (max_purchase_A - 2 * tier_size) * y_tier3_active, "enable_tier3_use")

# Processing throughput constraints
m.addConstr(total_gasoline <= processing_capacity, "max_throughput")
m.addConstr(total_gasoline >= min_total_gasoline_output, "min_throughput")

# Logic for Type II price lift
# Link z_price_lift to total_gasoline_II production volume using indicator constraints
m.addGenConstrIndicator(z_price_lift, 1, total_gasoline_II, GRB.GREATER_EQUAL, type_II_contract_threshold, "price_lift_on")
m.addGenConstrIndicator(z_price_lift, 0, total_gasoline_II, GRB.LESS_EQUAL, type_II_contract_threshold - 1e-6, "price_lift_off")

# Linearization of the quadratic term: revenue_lift = total_gasoline_II * z_price_lift
M_lift = processing_capacity  # A valid upper bound for total_gasoline_II
m.addConstr(revenue_lift <= total_gasoline_II, "linearize_lift_1")
m.addConstr(revenue_lift <= M_lift * z_price_lift, "linearize_lift_2")
m.addConstr(revenue_lift >= total_gasoline_II - M_lift * (1 - z_price_lift), "linearize_lift_3")

# Logic for bulk purchase rebate
# Link z_rebate to total_A_purchased volume using indicator constraints
m.addGenConstrIndicator(z_rebate, 1, total_A_purchased, GRB.GREATER_EQUAL, bulk_purchase_rebate_threshold, "rebate_on")
m.addGenConstrIndicator(z_rebate, 0, total_A_purchased, GRB.LESS_EQUAL, bulk_purchase_rebate_threshold - 1e-6, "rebate_off")


# --- 8. Solve the Model and Print Output ---
m.optimize()

if m.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
else:
    print(f"Optimization was not successful. Status code: {m.status}")
