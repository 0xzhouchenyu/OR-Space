import os
import csv
import math
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    Models and solves the revised Vehicle Routing Problem with Hard Time Windows,
    Outsourcing, and a limited in-house fleet.
    """
    # --- 1. Data Loading and Pre-processing ---

    # Construct paths to data files from the script's location
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        script_dir = os.getcwd()
        
    data_dir = os.path.join(script_dir, 'data')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    table_1_path = os.path.join(data_dir, 'table_1.csv')

    # Load general parameters from general_parameters.csv
    params = {}
    with open(params_path, 'r', newline='') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if len(row) > 1:
                params[row[0]] = row[1]

    truck_capacity = float(params['truck_capacity'])
    inhouse_truck_limit = int(params['inhouse_truck_limit'])
    
    depot_coord_str = params['depot_coordinates'].strip('()')
    if ',' in depot_coord_str:
        depot_x, depot_y = map(float, depot_coord_str.split(','))
    else:
        depot_x, depot_y = map(float, depot_coord_str.split())

    depot = {
        'id': 0,
        'x': depot_x,
        'y': depot_y,
        'demand': 0,
        'tw_start': float(params['depot_time_window_start']),
        'tw_end': float(params['depot_time_window_end']),
        'service_time': 0,
        'outsource_cost': 0,
        'mandatory_external': 0
    }

    # Load customer data from table_1.csv
    customers = []
    with open(table_1_path, 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            customers.append({
                'id': int(row['Customer_ID']),
                'x': float(row['Coordinates_X']),
                'y': float(row['Coordinates_Y']),
                'demand': float(row['Demand']),
                'tw_start': float(row['Time_Window_Start']),
                'tw_end': float(row['Time_Window_End']),
                'service_time': float(row['Service_Duration']),
                'outsource_cost': float(row['Outsource_Cost']),
                'mandatory_external': int(row['Mandatory_External'])
            })

    # Combine depot and customers into a single list of locations, indexed by ID
    locations = [depot] + sorted(customers, key=lambda c: c['id'])
    num_locations = len(locations)

    # Calculate distance matrix
    dist = {}
    for i in range(num_locations):
        for j in range(num_locations):
            loc_i = locations[i]
            loc_j = locations[j]
            dist[i, j] = math.sqrt((loc_i['x'] - loc_j['x'])**2 + (loc_i['y'] - loc_j['y'])**2)

    # Partition customers based on the mandatory_external flag
    routable_customer_ids = [c['id'] for c in customers if c['mandatory_external'] == 0]
    mandatory_outsource_ids = [c['id'] for c in customers if c['mandatory_external'] == 1]
    
    # Define the set of nodes that can be part of an in-house route
    routable_node_ids = [0] + routable_customer_ids

    # --- 2. Model Formulation ---
    
    model = gp.Model("VRPHTW_Outsource")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---

    # y_i: 1 if routable customer i is served in-house, 0 if outsourced
    y = model.addVars(routable_customer_ids, vtype=GRB.BINARY, name="y")

    # x_ij: 1 if a truck travels from location i to j
    # Pre-filter arcs to remove those that are obviously infeasible due to time windows
    arcs = []
    for i in routable_node_ids:
        for j in routable_node_ids:
            if i == j:
                continue
            # Check if travel from i to j is possible within time windows
            if locations[i]['tw_start'] + locations[i]['service_time'] + dist[i, j] <= locations[j]['tw_end']:
                arcs.append((i, j))
    
    x = model.addVars(arcs, vtype=GRB.BINARY, name="x")

    # t_i: Arrival time at location i
    t = model.addVars(routable_node_ids, name="t")
    for i in routable_node_ids:
        t[i].LB = locations[i]['tw_start']
        t[i].UB = locations[i]['tw_end']

    # u_i: Cumulative load on a truck route up to and including customer i
    u = model.addVars(routable_customer_ids, lb=0, ub=truck_capacity, name="u")

    # --- Objective Function ---
    
    # Cost from in-house travel distance
    travel_cost = gp.quicksum(dist[i, j] * x[i, j] for i, j in arcs)
    
    # Cost for optionally outsourced customers
    optional_outsource_cost = gp.quicksum(locations[i]['outsource_cost'] * (1 - y[i]) for i in routable_customer_ids)
    
    # Cost for mandatorily outsourced customers
    mandatory_outsource_cost = sum(locations[i]['outsource_cost'] for i in mandatory_outsource_ids)

    model.setObjective(travel_cost + optional_outsource_cost + mandatory_outsource_cost, GRB.MINIMIZE)

    # --- Constraints ---

    # Each routable customer is either visited (if y_i=1) or not (if y_i=0)
    for i in routable_customer_ids:
        # If served in-house, exactly one arc must enter customer i
        model.addConstr(gp.quicksum(x.get((j, i), 0) for j in routable_node_ids) == y[i], name=f"in_flow_{i}")
        # If served in-house, exactly one arc must leave customer i
        model.addConstr(gp.quicksum(x.get((i, j), 0) for j in routable_node_ids) == y[i], name=f"out_flow_{i}")

    # Number of trucks used is limited by the in-house truck limit
    model.addConstr(gp.quicksum(x.get((0, j), 0) for j in routable_customer_ids) <= inhouse_truck_limit, name="truck_limit")
    
    # Every truck that leaves the depot must return
    model.addConstr(gp.quicksum(x.get((0, j), 0) for j in routable_customer_ids) == 
                    gp.quicksum(x.get((i, 0), 0) for i in routable_customer_ids), name="depot_flow_balance")

    # Time window and time propagation constraints
    for i, j in arcs:
        if j != 0: # No service time or arrival time propagation at the depot
            # If arc (i,j) is used, t_j must be after arrival from i and service at i
            model.addGenConstrIndicator(x[i, j], True, t[j] >= t[i] + locations[i]['service_time'] + dist[i, j], name=f"time_prop_{i}_{j}")

    # Capacity and subtour elimination constraints using load variables
    for i in routable_customer_ids:
        # Load variable is bounded by capacity and only non-zero if customer is served
        model.addConstr(u[i] <= truck_capacity * y[i], name=f"load_ub_{i}")
        model.addConstr(u[i] >= locations[i]['demand'] * y[i], name=f"load_lb_{i}")

        # Load propagation from depot (initializes load for a route)
        if (0, i) in arcs:
            model.addGenConstrIndicator(x[0, i], True, u[i] == locations[i]['demand'], name=f"load_from_depot_{i}")
        
        # Load propagation between customers
        for j in routable_customer_ids:
            if i != j and (i, j) in arcs:
                # If arc (i,j) is used, the load at j is the load at i plus j's demand
                # This also serves as a subtour elimination constraint
                model.addGenConstrIndicator(x[i, j], True, u[j] - u[i] == locations[j]['demand'], name=f"load_prop_{i}_{j}")

    # --- 3. Solve and Output ---
    
    model.setParam('TimeLimit', 100) # Set a time limit for the solver
    model.solve()

    if model.Status in (GRB.OPTIMAL, GRB.SUBOPTIMAL, GRB.TIME_LIMIT):
        if model.ObjVal < float('inf'):
            print(f"FINAL_OBJ_VALUE: {round(model.ObjVal, 2)}")
        else:
            print("FINAL_OBJ_VALUE: None")
    else:
        print("FINAL_OBJ_VALUE: None")

if __name__ == "__main__":
    solve()
