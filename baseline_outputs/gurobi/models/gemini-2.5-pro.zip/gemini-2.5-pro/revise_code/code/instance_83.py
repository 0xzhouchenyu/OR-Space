import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    Solves the revised waiter scheduling problem.
    """
    # Define the number of time periods
    n_periods = 6

    # --- Data Loading ---
    # Construct the path to the data directory
    try:
        # This works when the script is run from the workspace root
        data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
        if not os.path.isdir(data_dir):
             # This is a fallback for local execution if the structure is different
             data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
    except NameError:
        # This works when __file__ is not defined (e.g., in an interactive session)
        data_dir = "data"


    # Read minimum waiters needed from table_1.csv
    min_waiters = [0] * n_periods
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', newline='') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            min_waiters[i] = int(row['Minimum_Number_of_Waiters_Needed'].strip())

    # Read general parameters from general_parameters.csv
    peak = [0] * n_periods
    quality = [0] * n_periods
    waiter_cost_per_shift = 0
    waiter_budget = 0

    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            if param_name.startswith('peak_'):
                idx = int(param_name.split('_')[1])
                if 0 <= idx < n_periods:
                    peak[idx] = int(value)
            elif param_name.startswith('quality_'):
                idx = int(param_name.split('_')[1])
                if 0 <= idx < n_periods:
                    quality[idx] = int(value)
            elif param_name == 'waiter_cost_per_shift':
                waiter_cost_per_shift = int(value)
            elif param_name == 'waiter_budget':
                waiter_budget = int(value)

    # --- Model Formulation ---
    # Create a new model
    m = gp.Model("RevisedWaiterScheduling")

    # Suppress Gurobi output
    m.setParam('OutputFlag', 0)

    # Decision Variables: x_i is the number of waiters starting at period i
    x = m.addVars(n_periods, vtype=GRB.INTEGER, name="x", lb=0)

    # Objective Function: Maximize the total service quality score
    # The quality of a shift starting at period i is the sum of quality points
    # for the two periods it covers (i and i+1).
    shift_quality = [(quality[i] + quality[(i + 1) % n_periods]) for i in range(n_periods)]
    m.setObjective(gp.quicksum(shift_quality[i] * x[i] for i in range(n_periods)), GRB.MAXIMIZE)

    # --- Constraints ---
    # 1. Minimum Coverage Constraint: For each period j, the number of waiters working
    #    must meet the minimum requirement. Waiters working in period j are those who
    #    started in period j or period (j-1).
    for j in range(n_periods):
        m.addConstr(x[j] + x[(j - 1 + n_periods) % n_periods] >= min_waiters[j], f"coverage_{j}")

    # 2. Budget Constraint: Total cost of waiters must not exceed the budget.
    m.addConstr(gp.quicksum(x[i] for i in range(n_periods)) * waiter_cost_per_shift <= waiter_budget, "budget")

    # 3. Peak/Off-Peak Shift Structure Constraint: A compliant shift must consist of
    #    one peak and one off-peak window. A shift starting at period i covers
    #    periods i and i+1. The sum of their peak indicators must be 1.
    for i in range(n_periods):
        if peak[i] + peak[(i + 1) % n_periods] != 1:
            # If the shift is not compliant (e.g., peak+peak or off-peak+off-peak),
            # no waiters can start at this time.
            m.addConstr(x[i] == 0, f"invalid_shift_{i}")

    # --- Solve and Output ---
    # Optimize the model
    m.optimize()

    # Print the final objective value
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
