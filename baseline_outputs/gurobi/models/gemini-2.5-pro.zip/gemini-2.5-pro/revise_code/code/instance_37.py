import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # --- 1. Load Data ---
    try:
        # This works when running as a script file.
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # This is a fallback for interactive environments where __file__ is not defined.
        base_dir = os.getcwd()

    data_dir = os.path.join(base_dir, "data")

    # Load general_parameters.csv into a dictionary
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    # Load table_1.csv
    table1_path = os.path.join(data_dir, 'table_1.csv')
    with open(table1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        next(reader)  # Skip headers
        rows = list(reader)

    # Parse process-specific data from table_1.csv
    a_I = float(rows[0][1])      # Model A hours for Process I
    b_I = float(rows[0][2])      # Model B hours for Process I
    a_II = float(rows[1][1])     # Model A hours for Process II
    b_II = float(rows[1][2])     # Model B hours for Process II
    profit_A = float(rows[2][1]) # Profit per unit Model A
    profit_B = float(rows[2][2]) # Profit per unit Model B

    # --- 2. Create Gurobi Model ---
    m = gp.Model("TwoWeekProduction")
    m.setParam('OutputFlag', 0)

    # --- 3. Define Decision Variables ---
    weeks = range(2)  # Represents Week 1 (index 0) and Week 2 (index 1)

    # Production quantities (continuous)
    x_A = m.addVars(weeks, name="x_A", lb=0)
    x_B = m.addVars(weeks, name="x_B", lb=0)

    # Overtime hours (continuous, non-negative)
    ot_I = m.addVars(weeks, name="ot_I", lb=0)
    ot_II = m.addVars(weeks, name="ot_II", lb=0)

    # Binary variables to model the week 1 overtime fatigue rule
    y_I = m.addVar(vtype=GRB.BINARY, name="fatigue_trigger_I")
    y_II = m.addVar(vtype=GRB.BINARY, name="fatigue_trigger_II")

    # --- 4. Set Objective Function ---
    # Maximize total two-week profit = total revenue - total overtime cost
    total_revenue = gp.quicksum(profit_A * x_A[w] + profit_B * x_B[w] for w in weeks)
    total_overtime_cost = gp.quicksum(params['overtime_premium_I'] * ot_I[w] + params['overtime_premium_II'] * ot_II[w] for w in weeks)
    
    m.setObjective(total_revenue - total_overtime_cost, GRB.MAXIMIZE)

    # --- 5. Add Constraints ---

    # Production Capacity Constraints
    # Week 1 (index 0)
    m.addConstr(a_I * x_A[0] + b_I * x_B[0] <= params['process_I_hours'] + ot_I[0], "Capacity_I_W1")
    m.addConstr(a_II * x_A[0] + b_II * x_B[0] <= params['process_II_hours'] + ot_II[0], "Capacity_II_W1")

    # Week 2 (index 1) - regular capacity is reduced if fatigue is triggered
    week2_regular_hours_I = params['process_I_hours'] - params['week2_recovery_loss_I'] * y_I
    week2_regular_hours_II = params['process_II_hours'] - params['week2_recovery_loss_II'] * y_II
    m.addConstr(a_I * x_A[1] + b_I * x_B[1] <= week2_regular_hours_I + ot_I[1], "Capacity_I_W2")
    m.addConstr(a_II * x_A[1] + b_II * x_B[1] <= week2_regular_hours_II + ot_II[1], "Capacity_II_W2")

    # Overtime Limit Constraints
    for w in weeks:
        m.addConstr(ot_I[w] <= params['max_overtime_I_per_week'], f"Max_OT_I_W{w+1}")
        m.addConstr(ot_II[w] <= params['max_overtime_II_per_week'], f"Max_OT_II_W{w+1}")

    # Fatigue Rule Constraints (Big-M formulation)
    M_I = params['max_overtime_I_per_week']
    M_II = params['max_overtime_II_per_week']
    m.addConstr(ot_I[0] - params['week1_overtime_fatigue_threshold_I'] <= M_I * y_I, "Fatigue_Rule_I")
    m.addConstr(ot_II[0] - params['week1_overtime_fatigue_threshold_II'] <= M_II * y_II, "Fatigue_Rule_II")

    # Production Requirement Constraints
    # Total over two weeks
    m.addConstr(x_A.sum() >= params['min_model_A_units'], "Total_Min_A")
    m.addConstr(x_B.sum() >= params['min_model_B_units'], "Total_Min_B")

    # Weekly delivery promises
    m.addConstr(x_A[0] >= params['week1_min_model_A_units'], "Weekly_Min_A_W1")
    m.addConstr(x_B[0] >= params['week1_min_model_B_units'], "Weekly_Min_B_W1")
    m.addConstr(x_A[1] >= params['week2_min_model_A_units'], "Weekly_Min_A_W2")
    m.addConstr(x_B[1] >= params['week2_min_model_B_units'], "Weekly_Min_B_W2")

    # Minimum Profit Constraint
    m.addConstr(total_revenue - total_overtime_cost >= params['min_weekly_profit'], "Min_Total_Profit")

    # Minimum Utilization Constraints
    total_hours_used_I = gp.quicksum(a_I * x_A[w] + b_I * x_B[w] for w in weeks)
    total_hours_used_II = gp.quicksum(a_II * x_A[w] + b_II * x_B[w] for w in weeks)
    
    total_regular_hours_I = params['process_I_hours'] * 2
    total_regular_hours_II = params['process_II_hours'] * 2

    m.addConstr(total_hours_used_I >= params['min_avg_utilization_I'] * total_regular_hours_I, "Min_Util_I")
    m.addConstr(total_hours_used_II >= params['min_avg_utilization_II'] * total_regular_hours_II, "Min_Util_II")

    # --- 6. Solve and Output ---
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == "__main__":
    main()
