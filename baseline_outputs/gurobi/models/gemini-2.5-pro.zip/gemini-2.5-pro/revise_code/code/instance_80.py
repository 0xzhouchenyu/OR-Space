import gurobipy as gp
from gurobipy import GRB
import csv
import os
import sys

def load_csv(filename):
    """Load a CSV file and return a list of dictionaries."""
    # The script is executed from the root, so the path is relative to the root.
    filepath = os.path.join("data", filename)
    if not os.path.exists(filepath):
        # Fallback for local execution if the script is in a 'src' folder
        filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', filename)
    
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        return list(reader)

def load_general_parameters(filename='general_parameters.csv'):
    """Load general parameters into a dictionary."""
    rows = load_csv(filename)
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = row['Value']
        # Try to convert to numeric
        try:
            if '.' in value:
                params[name] = float(value)
            else:
                params[name] = int(value)
        except (ValueError, TypeError):
            params[name] = value
    return params

def load_task_methods(filename='table_1.csv'):
    """Load task-method data."""
    rows = load_csv(filename)
    data = []
    for row in rows:
        data.append({
            'Task': row['Task'],
            'Method': row['Method'],
            'Effective_Hours': float(row['Effective_Hours']),
            'Fixed_Cost': float(row['Fixed_Cost'])
        })
    return data

def main():
    """
    Main function to set up and solve the optimization problem.
    """
    # Load data from revised files
    params = load_general_parameters('general_parameters.csv')
    task_methods_data = load_task_methods('table_1.csv')

    # Extract parameters
    skilled_wage = params['skilled_worker_weekly_wage']
    laborer_wage = params['laborer_weekly_wage']
    skilled_hours = params['skilled_worker_weekly_hours']
    laborer_hours = params['laborer_weekly_hours']
    max_skilled = params['max_skilled_workers']
    max_laborers = params['max_laborers']
    min_skilled_task3_B = params['min_skilled_workers_task3_methodB']

    # Organize task-method data
    tasks = sorted(list(set(row['Task'] for row in task_methods_data)))
    methods = sorted(list(set(row['Method'] for row in task_methods_data)))
    
    tm_data = {}
    for row in task_methods_data:
        key = (row['Task'], row['Method'])
        tm_data[key] = row

    # Create the Gurobi model
    model = gp.Model("RevisedWorkerAllocation")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---

    # y[t, m]: Binary, 1 if method m is chosen for task t
    y = model.addVars(tm_data.keys(), vtype=GRB.BINARY, name="y")

    # s[t, m]: Continuous, number of skilled workers for task t, method m
    s = model.addVars(tm_data.keys(), vtype=GRB.CONTINUOUS, name="s")

    # l[t, m]: Continuous, number of laborers for task t, method m
    l = model.addVars(tm_data.keys(), vtype=GRB.CONTINUOUS, name="l")

    # Total skilled workers and laborers
    total_skilled = model.addVar(vtype=GRB.CONTINUOUS, name="total_skilled")
    total_laborers = model.addVar(vtype=GRB.CONTINUOUS, name="total_laborers")

    # --- Objective Function ---
    # Minimize total weekly cost (wages + fixed costs)
    total_wage_cost = skilled_wage * total_skilled + laborer_wage * total_laborers
    total_fixed_cost = gp.quicksum(tm_data[t, m]['Fixed_Cost'] * y[t, m] for t, m in tm_data.keys())
    model.setObjective(total_wage_cost + total_fixed_cost, GRB.MINIMIZE)

    # --- Constraints ---

    # Total worker definitions
    model.addConstr(total_skilled == s.sum(), "TotalSkilledDef")
    model.addConstr(total_laborers == l.sum(), "TotalLaborersDef")

    # Exactly one method per task
    for t in tasks:
        model.addConstr(y.sum(t, '*') == 1, f"OneMethod_{t}")

    # Hours requirement and linking variables
    # Using Big-M constraints to link worker assignments to method selection
    M_skilled = max_skilled
    M_laborer = max_laborers

    for t, m in tm_data.keys():
        req_hours = tm_data[t, m]['Effective_Hours']
        # Hours constraint: must be met if method is chosen
        model.addConstr(
            skilled_hours * s[t, m] + laborer_hours * l[t, m] >= req_hours * y[t, m],
            f"Hours_{t}_{m}"
        )
        # Linking constraints: workers can only be assigned if method is chosen
        model.addConstr(s[t, m] <= M_skilled * y[t, m], f"LinkS_{t}_{m}")
        model.addConstr(l[t, m] <= M_laborer * y[t, m], f"LinkL_{t}_{m}")

    # Max worker constraints
    model.addConstr(total_skilled <= max_skilled, "MaxSkilled")
    model.addConstr(total_laborers <= max_laborers, "MaxLaborers")

    # Exclusion rule: Task 1 Method B excludes Task 3 Method A
    model.addConstr(y['Task_1', 'Method_B'] + y['Task_3', 'Method_A'] <= 1, "ExclusionRule")

    # Minimum skilled workers for Task 3 if Method B is chosen
    model.addConstr(
        s['Task_3', 'Method_B'] >= min_skilled_task3_B * y['Task_3', 'Method_B'],
        "MinSkilledTask3B"
    )

    # REVISED: Task-level skill-balance bands
    # The overall hiring ratio is replaced by these task-level constraints.
    for t in tasks:
        task_num = t.split('_')[1]
        min_share_param = f'min_skilled_share_task{task_num}'
        max_share_param = f'max_skilled_share_task{task_num}'
        
        min_share = params[min_share_param]
        max_share = params[max_share_param]

        # Total workers for this task (sum across methods A and B)
        s_task = s.sum(t, '*')
        l_task = l.sum(t, '*')
        
        # Linearized form of: s_task >= min_share * (s_task + l_task)
        # s_task * (1 - min_share) >= l_task * min_share
        model.addConstr(
            s_task * (1 - min_share) >= l_task * min_share,
            f"MinSkilledShare_{t}"
        )

        # Linearized form of: s_task <= max_share * (s_task + l_task)
        # s_task * (1 - max_share) <= l_task * max_share
        model.addConstr(
            s_task * (1 - max_share) <= l_task * max_share,
            f"MaxSkilledShare_{t}"
        )

    # --- Solve ---
    model.optimize()

    # --- Output ---
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
