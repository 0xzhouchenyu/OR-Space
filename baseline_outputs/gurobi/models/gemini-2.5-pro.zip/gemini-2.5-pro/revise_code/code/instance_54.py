import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_data(data_dir):
    """
    Loads all necessary data from the CSV files in the specified directory.
    """
    # --- Load table_1.csv ---
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    
    equipment_names = []
    products = []
    processing_times = {}  # (equipment, product) -> time
    effective_hours = {}   # equipment -> hours
    base_profit = {}       # product -> profit (used as base cost)
    
    with open(table_1_path, 'r', newline='') as f:
        reader = csv.reader(f)
        header = next(reader)
        products = header[1:-1]
        
        for row in reader:
            if not row or not row[0]:
                continue
            if row[0].startswith('Unit_Product_Profit'):
                for j, prod in enumerate(products):
                    base_profit[prod] = float(row[j + 1])
            else:
                equip = row[0]
                equipment_names.append(equip)
                effective_hours[equip] = float(row[-1])
                for j, prod in enumerate(products):
                    processing_times[(equip, prod)] = float(row[j + 1])

    # --- Load general_parameters.csv ---
    general_params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    params = {}
    with open(general_params_path, 'r', newline='') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if row:
                params[row[0]] = float(row[1])

    overtime_hours_cap = params['overtime_hours_cap']
    overtime_cost_multiplier = params['overtime_cost_multiplier']
    
    min_production = {
        'I': params['min_prod_I'],
        'II': params['min_prod_II'],
        'III': params['min_prod_III']
    }

    return (products, equipment_names, processing_times, effective_hours, 
            base_profit, overtime_hours_cap, overtime_cost_multiplier, min_production)

def main():
    """
    Main function to set up and solve the optimization problem.
    """
    # Define the data directory relative to the script's location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")

    # Load all data
    (products, equipment_names, processing_times, effective_hours, 
     base_profit, overtime_hours_cap, overtime_cost_multiplier, min_production) = load_data(data_dir)

    # Calculate costs
    regular_cost = base_profit
    overtime_cost = {p: base_profit[p] * overtime_cost_multiplier for p in products}

    # --- Gurobi Model ---
    
    # Create a new model
    m = gp.Model("Revised_Factory_Production")

    # --- Decision Variables ---
    # x_reg[p]: quantity of product p produced in regular time
    x_reg = m.addVars(products, name="x_reg", vtype=GRB.CONTINUOUS, lb=0)
    
    # x_ot[p]: quantity of product p produced in overtime
    x_ot = m.addVars(products, name="x_ot", vtype=GRB.CONTINUOUS, lb=0)

    # --- Objective Function ---
    # Minimize total production cost
    total_cost = gp.quicksum(regular_cost[p] * x_reg[p] + overtime_cost[p] * x_ot[p] for p in products)
    m.setObjective(total_cost, GRB.MINIMIZE)

    # --- Constraints ---
    
    # 1. Equipment Capacity Constraints
    # Total hours used on each equipment (regular + overtime) cannot exceed its effective monthly hours.
    for e in equipment_names:
        m.addConstr(
            gp.quicksum(processing_times[e, p] * (x_reg[p] + x_ot[p]) for p in products) <= effective_hours[e],
            name=f"capacity_{e}"
        )

    # 2. Minimum Production Commitment Constraints
    # Total production for each product must meet its minimum commitment level.
    for p in products:
        m.addConstr(
            x_reg[p] + x_ot[p] >= min_production[p],
            name=f"min_prod_{p}"
        )

    # 3. Overtime Hours Cap Constraint
    # The total equipment hours consumed by all overtime work cannot exceed the cap.
    m.addConstr(
        gp.quicksum(processing_times[e, p] * x_ot[p] for e in equipment_names for p in products) <= overtime_hours_cap,
        name="ot_hours_cap"
    )

    # --- Solve ---
    
    # Suppress Gurobi output
    m.setParam('OutputFlag', 0)
    
    # Optimize the model
    m.optimize()

    # --- Output ---
    
    # Print the final objective value in the required format
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
