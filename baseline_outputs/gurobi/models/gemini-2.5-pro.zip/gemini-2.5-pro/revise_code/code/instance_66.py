import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_problem():
    """
    This function formulates and solves the revised two-period toy manufacturing problem.
    """
    # --- Data Loading ---

    # The script is executed from the root directory.
    # os.path.dirname(os.path.abspath(__file__)) gives the directory of the script (the root).
    # We join with 'data' to get the data directory.
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Handle case where __file__ is not defined (e.g., interactive environment)
        script_dir = os.getcwd()
        
    data_dir = os.path.join(script_dir, 'data')

    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                params[row['Parameter_Name']] = float(row['Value'])
            except (ValueError, TypeError):
                params[row['Parameter_Name']] = row['Value']

    # Load toy-specific data from table_1.csv
    toy_data = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toy_type = row['Toy_Type']
            toy_data[toy_type] = {
                'labor': float(row['Manufacturing_Labor_Hours']),
                'inspection': float(row['Inspection_Hours']),
                'profit': float(row['Profit_Per_Unit'])
            }

    # Define sets for easier iteration
    toy_types = list(toy_data.keys())
    periods = [1, 2]

    # --- Model Formulation ---

    # Create a new Gurobi model
    m = gp.Model("RevisedToyProduction")

    # Suppress Gurobi's console output
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---

    # Production quantities: x[toy_type, period]
    x = m.addVars(toy_types, periods, name="x", lb=0, vtype=GRB.CONTINUOUS)

    # Overtime hours: ot[period]
    ot = m.addVars(periods, name="ot", lb=0, vtype=GRB.CONTINUOUS)

    # Binary variable for fatigue carryover effect
    y_fatigue = m.addVar(vtype=GRB.BINARY, name="y_fatigue")

    # Binary variable for seasonal safety review fee
    y_review = m.addVar(vtype=GRB.BINARY, name="y_review")

    # --- Objective Function ---
    # Maximize: Total Profit from Sales - Total Overtime Cost - Seasonal Safety Review Fee

    total_profit_from_sales = gp.quicksum(toy_data[t]['profit'] * x[t, p] for t in toy_types for p in periods)
    total_overtime_cost = params['overtime_labor_cost'] * gp.quicksum(ot[p] for p in periods)
    safety_review_fee = params['seasonal_safety_review_fee'] * y_review

    m.setObjective(total_profit_from_sales - total_overtime_cost - safety_review_fee, GRB.MAXIMIZE)

    # --- Constraints ---

    # Labor constraints for each period
    m.addConstr(
        gp.quicksum(toy_data[t]['labor'] * x[t, 1] for t in toy_types) <= params['available_labor_hours_period1'] + ot[1],
        "Labor_Period1"
    )
    m.addConstr(
        gp.quicksum(toy_data[t]['labor'] * x[t, 2] for t in toy_types) <= params['available_labor_hours_period2'] - params['period2_labor_recovery_loss'] * y_fatigue + ot[2],
        "Labor_Period2"
    )

    # Inspection constraints for each period
    m.addConstr(
        gp.quicksum(toy_data[t]['inspection'] * x[t, 1] for t in toy_types) <= params['available_inspection_hours_period1'],
        "Inspection_Period1"
    )
    m.addConstr(
        gp.quicksum(toy_data[t]['inspection'] * x[t, 2] for t in toy_types) <= params['available_inspection_hours_period2'],
        "Inspection_Period2"
    )

    # Demand constraints for each toy and period
    for t in toy_types:
        # Dynamically construct the parameter key from the toy type string
        toy_slug = t.lower().replace('-', '_')
        key_p1 = f"max_demand_{toy_slug}_period1"
        key_p2 = f"max_demand_{toy_slug}_period2"
        m.addConstr(x[t, 1] <= params[key_p1], f"Demand_{t}_Period1")
        m.addConstr(x[t, 2] <= params[key_p2], f"Demand_{t}_Period2")

    # Total overtime cap across both periods
    m.addConstr(ot[1] + ot[2] <= params['overtime_labor_cap'], "Overtime_Cap")

    # Fatigue carryover logic (Big-M formulation)
    # If ot[1] > period1_overtime_fatigue_threshold, then y_fatigue must be 1.
    # This is modeled as: ot[1] <= threshold + M * y_fatigue
    # A safe (though not tightest) value for M is the max possible value of ot[1], which is overtime_labor_cap.
    M_fatigue = params['overtime_labor_cap']
    m.addConstr(
        ot[1] <= params['period1_overtime_fatigue_threshold'] + M_fatigue * y_fatigue,
        "Fatigue_Indicator"
    )

    # Seasonal safety review logic (Big-M formulation)
    # If (ot[1] + ot[2]) > overtime_review_threshold, then y_review must be 1.
    # This is modeled as: (ot[1] + ot[2]) <= threshold + M * y_review
    # A safe M is the max possible value of (ot[1] + ot[2]), which is overtime_labor_cap.
    M_review = params['overtime_labor_cap']
    m.addConstr(
        ot[1] + ot[2] <= params['overtime_review_threshold'] + M_review * y_review,
        "Review_Indicator"
    )

    # --- Solve and Print Results ---

    # Optimize the model
    m.optimize()

    # Print the final objective value in the required format
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        # This part is for robustness, in case no optimal solution is found.
        print("FINAL_OBJ_VALUE: Error - No optimal solution found.")

if __name__ == "__main__":
    solve_revised_problem()
