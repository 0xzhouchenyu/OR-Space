import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- Main script ---

# Load data
# The script is executed from the root, so the path is relative to it.
data_path = os.path.join("data", "general_parameters.csv")
params = load_parameters(data_path)

# Extract parameters into variables for clarity
a_p1 = params['product_a_process_1_time']
a_p2 = params['product_a_process_2_time']
b_p1 = params['product_b_process_1_time']
b_p2 = params['product_b_process_2_time']

T1_norm = params['available_time_process_1']
T2_norm = params['available_time_process_2']
T1_high = params['available_time_process_1_high']
T2_high = params['available_time_process_2_high']

c_per_b = params['byproduct_c_per_unit_b']
max_c_sales = params['max_byproduct_c_sales']
threshold_c = params['threshold_c']
bigM_disposal = params['bigM_disposal']

cost_c_low = params['disposal_cost_per_unit_c']
cost_c_high = params['disposal_cost_per_unit_c_high']

profit_a = params['profit_per_unit_a']
profit_b = params['profit_per_unit_b']
profit_c = params['profit_per_unit_c']

# Create the Gurobi model
model = gp.Model("RevisedProfitMaximization")
model.setParam('OutputFlag', 0)

# --- Decision Variables ---

# Production quantities (continuous)
xA = model.addVar(name="xA", vtype=GRB.CONTINUOUS, lb=0)  # units of product A
xB = model.addVar(name="xB", vtype=GRB.CONTINUOUS, lb=0)  # units of product B

# By-product C handling (continuous)
cSold = model.addVar(name="cSold", vtype=GRB.CONTINUOUS, lb=0)  # units of C sold
cDisposed_low = model.addVar(name="cDisposed_low", vtype=GRB.CONTINUOUS, lb=0) # C disposed at low cost
cDisposed_high = model.addVar(name="cDisposed_high", vtype=GRB.CONTINUOUS, lb=0) # C disposed at high cost

# High-throughput mode selection (binary)
y1 = model.addVar(name="y1", vtype=GRB.BINARY) # 1 if process 1 is high-throughput
y2 = model.addVar(name="y2", vtype=GRB.BINARY) # 1 if process 2 is high-throughput

# Disposal cost tier selection (binary)
z = model.addVar(name="z", vtype=GRB.BINARY) # 1 if disposal exceeds threshold_c

# --- Objective Function ---
# Maximize total profit
total_profit = (profit_a * xA + 
                profit_b * xB + 
                profit_c * cSold - 
                cost_c_low * cDisposed_low - 
                cost_c_high * cDisposed_high)
model.setObjective(total_profit, GRB.MAXIMIZE)

# --- Constraints ---

# 1. Process time constraints with high-throughput option
model.addConstr(a_p1 * xA + b_p1 * xB <= T1_norm + (T1_high - T1_norm) * y1, "Process1Time")
model.addConstr(a_p2 * xA + b_p2 * xB <= T2_norm + (T2_high - T2_norm) * y2, "Process2Time")

# 2. At most one process can be in high-throughput mode
model.addConstr(y1 + y2 <= 1, "MaxOneHighThroughput")

# 3. By-product C balance
total_c_produced = c_per_b * xB
total_c_disposed = cDisposed_low + cDisposed_high
model.addConstr(total_c_produced == cSold + total_c_disposed, "ByproductBalance")

# 4. Maximum by-product C sales
model.addConstr(cSold <= max_c_sales, "MaxCSales")

# 5. Tiered disposal cost constraints for by-product C
# Amount in low-cost tier is at most the threshold
model.addConstr(cDisposed_low <= threshold_c, "DisposalLowTierLimit")

# High-cost tier is only used if binary variable z is 1
model.addConstr(cDisposed_high <= bigM_disposal * z, "DisposalHighTierActivation")

# If z is 1, the low-cost tier must be full
model.addConstr(cDisposed_low >= threshold_c * z, "DisposalLowTierFill")

# --- Solve and Output ---

# Optimize the model
model.optimize()

# Print the final objective value in the required format
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("No optimal solution found.")
