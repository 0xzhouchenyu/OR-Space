import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_toy_data(filepath):
    """Loads toy-specific data from a CSV file."""
    toys = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            toys.append({
                'type': row['Toy_Type'].strip(),
                'profit': float(row['Profit_Per_Unit']),
                'wood': float(row['Wood_Required_Per_Unit']),
                'steel': float(row['Steel_Required_Per_Unit']),
            })
    return toys

def load_general_parameters(filepath):
    """Loads general model parameters from a CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

def solve_revised_problem():
    """
    Builds and solves the revised Haus Toys optimization problem using Gurobi.
    """
    # --- 1. Load Data ---
    # Construct absolute paths to data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    toy_list = load_toy_data(os.path.join(data_dir, 'table_1.csv'))
    params = load_general_parameters(os.path.join(data_dir, 'general_parameters.csv'))

    # Re-structure toy data into a dictionary for easier access
    toy_data = {t['type']: t for t in toy_list}
    toy_types = list(toy_data.keys())

    # Extract parameters into variables
    available_wood = params['available_wood']
    available_steel = params['available_steel']
    profit_premium_bonus = params['profit_premium_bonus']
    premium_steel_factor = params['premium_steel_factor']
    premium_shift_capacity = params['premium_shift_capacity']
    
    # Big M for linking constraints
    M = 1000 

    # --- 2. Create Gurobi Model ---
    model = gp.Model("HausToysRevised")
    model.setParam('OutputFlag', 0)

    # --- 3. Define Decision Variables ---
    # Quantity of toy 't' produced on standard shift
    x_std = model.addVars(toy_types, name="x_std", vtype=GRB.CONTINUOUS)
    # Quantity of toy 't' produced on premium shift
    x_prm = model.addVars(toy_types, name="x_prm", vtype=GRB.CONTINUOUS)

    # Binary: 1 if toy 't' is produced on standard shift, 0 otherwise
    z_std = model.addVars(toy_types, name="z_std", vtype=GRB.BINARY)
    # Binary: 1 if toy 't' is produced on premium shift, 0 otherwise
    z_prm = model.addVars(toy_types, name="z_prm", vtype=GRB.BINARY)
    
    # Binary: 1 if toy 't' is produced at all (on any shift), 0 otherwise
    y = model.addVars(toy_types, name="y", vtype=GRB.BINARY)

    # --- 4. Set Objective Function ---
    # Maximize total profit from both standard and premium shifts
    std_profit = gp.quicksum(toy_data[t]['profit'] * x_std[t] for t in toy_types)
    prm_profit = gp.quicksum((toy_data[t]['profit'] + profit_premium_bonus) * x_prm[t] for t in toy_types)
    
    model.setObjective(std_profit + prm_profit, GRB.MAXIMIZE)

    # --- 5. Add Constraints ---
    # Resource Constraints
    model.addConstr(
        gp.quicksum(toy_data[t]['wood'] * (x_std[t] + x_prm[t]) for t in toy_types) <= available_wood,
        "Wood_Constraint"
    )
    model.addConstr(
        gp.quicksum(toy_data[t]['steel'] * x_std[t] for t in toy_types) +
        gp.quicksum(toy_data[t]['steel'] * premium_steel_factor * x_prm[t] for t in toy_types) <= available_steel,
        "Steel_Constraint"
    )

    # Premium Shift Capacity Constraint
    model.addConstr(
        gp.quicksum(x_prm[t] for t in toy_types) <= premium_shift_capacity,
        "Premium_Shift_Capacity"
    )

    # Shift Exclusivity and Linking Constraints
    for t in toy_types:
        # A toy is produced if it's on the standard OR premium shift
        model.addConstr(y[t] == z_std[t] + z_prm[t], f"Shift_Choice_{t}")
        
        # A toy type can only be on one shift (implicit in the above with y being binary)
        # but we can also be explicit: z_std[t] + z_prm[t] <= 1. This is handled by y[t] being binary.

        # Link production quantity to the shift choice
        model.addConstr(x_std[t] <= M * z_std[t], f"Link_Std_{t}")
        model.addConstr(x_prm[t] <= M * z_prm[t], f"Link_Prm_{t}")

    # Business Logic Constraints (applied to overall production)
    # If trucks are made (any shift), trains are not (any shift)
    model.addConstr(y['truck'] + y['train'] <= 1, "Truck_Train_Exclusion")

    # If boats are made (any shift), airplanes must also be made (any shift)
    model.addConstr(y['boat'] <= y['airplane'], "Boat_Airplane_Dependency")

    # Total boats produced cannot exceed total trains produced
    total_boats = x_std['boat'] + x_prm['boat']
    total_trains = x_std['train'] + x_prm['train']
    model.addConstr(total_boats <= total_trains, "Boat_Train_Limit")

    # --- 6. Solve the Model ---
    model.optimize()

    # --- 7. Print Final Result ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print(f"Optimization was not successful. Status: {model.status}")

if __name__ == "__main__":
    solve_revised_problem()
