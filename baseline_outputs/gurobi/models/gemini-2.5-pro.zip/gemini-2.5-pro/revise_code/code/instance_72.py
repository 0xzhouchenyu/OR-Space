import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Data Loading ---

# The script is expected to be run from the workspace root directory.
# This path construction will correctly find the 'data' subdirectory.
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# Read general parameters from the CSV file into a dictionary.
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        # Convert numeric values to float for calculations.
        try:
            params[row['Parameter_Name']] = float(row['Value'])
        except (ValueError, TypeError):
            params[row['Parameter_Name']] = row['Value']

# Assign parameters to variables for better readability in the model.
budget = params['budget']
scen_1_prob = params['scen_1_prob']
scen_2_prob = params['scen_2_prob']
scen_1_risky_multiplier = params['scen_1_risky_multiplier']
scen_2_risky_multiplier = params['scen_2_risky_multiplier']
total_risky_budget = params['total_risky_budget']
per_property_risky_cap = params['per_property_risky_cap']
max_risky_properties = params['max_risky_properties']

# Read property-specific data into a dictionary for easy lookup.
properties_data = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        properties_data[row['Property']] = {
            'income': float(row['Annual_Income']),
            'cost': float(row['Cost'])
        }
property_names = list(properties_data.keys())

# --- Model Formulation ---

# Initialize the Gurobi model.
model = gp.Model("RealEstateInvestmentRevised")

# Suppress solver output as per instructions.
model.setParam('OutputFlag', 0)

# --- Decision Variables ---

# x_i: Binary variable, 1 if property i is purchased, 0 otherwise.
x = model.addVars(property_names, vtype=GRB.BINARY, name="x")

# y_i: Binary variable, 1 if property i has any risky allocation, 0 otherwise.
y = model.addVars(property_names, vtype=GRB.BINARY, name="y")

# rf_i: Continuous variable, represents the fraction of property i allocated to risky tenants.
rf = model.addVars(property_names, vtype=GRB.CONTINUOUS, lb=0.0, name="rf")

# --- Objective Function ---

# The objective is to maximize the total expected annual income.
# First, calculate the single expected income multiplier for the risky portion.
expected_risky_multiplier = (scen_1_prob * scen_1_risky_multiplier +
                             scen_2_prob * scen_2_risky_multiplier)

# The total expected income for a property is a linear combination of the income from
# the dependable part and the expected income from the risky part.
# Linearized objective: sum over properties i of:
# x_i * income_i + rf_i * income_i * (expected_risky_multiplier - 1)
objective_expr = gp.quicksum(
    x[p] * properties_data[p]['income'] +
    rf[p] * properties_data[p]['income'] * (expected_risky_multiplier - 1)
    for p in property_names
)
model.setObjective(objective_expr, GRB.MAXIMIZE)

# --- Constraints ---

# 1. Total budget constraint for purchasing properties.
model.addConstr(
    gp.quicksum(x[p] * properties_data[p]['cost'] for p in property_names) <= budget,
    name="TotalBudget"
)

# 2. Exclusion constraint: If Property 4 is purchased, Property 3 cannot be.
model.addConstr(
    x['Property_4'] + x['Property_3'] <= 1,
    name="Exclusion"
)

# 3. Constraints to link the decision variables (x, y, rf) for each property.
for p in property_names:
    # The risky fraction (rf) cannot exceed the per-property cap and can only be non-zero
    # if the property is purchased (x=1).
    model.addConstr(rf[p] <= per_property_risky_cap * x[p], name=f"RiskyCap_{p}")
    
    # Link the continuous risky fraction (rf) to the binary risky indicator (y).
    # If rf > 0, then y must be 1. Since rf is a fraction <= 1, this is a tight "big-M" constraint.
    model.addConstr(rf[p] <= y[p], name=f"Link_rf_y_{p}")
    
    # A property can be designated as risky (y=1) only if it is purchased (x=1).
    model.addConstr(y[p] <= x[p], name=f"Link_y_x_{p}")

# 4. Total risky budget constraint: The sum of costs of properties with any risky
#    allocation (where y=1) must not exceed the total risky budget.
model.addConstr(
    gp.quicksum(y[p] * properties_data[p]['cost'] for p in property_names) <= total_risky_budget,
    name="TotalRiskyBudget"
)

# 5. Maximum number of properties with risky tenants.
model.addConstr(
    gp.quicksum(y[p] for p in property_names) <= max_risky_properties,
    name="MaxRiskyProperties"
)

# --- Solve and Output ---

# Optimize the model to find the best investment strategy.
model.optimize()

# Print the final optimal objective value in the specified format.
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
