import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    This function sets up and solves the foldable table production optimization problem.
    """
    # --- Data Loading ---
    # Set base directory relative to the script file
    try:
        # This works when running the script directly
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # This works in interactive environments like Jupyter or when exec is used
        base_dir = os.path.abspath('.')

    data_dir = os.path.join(base_dir, "data")

    # Load demand forecast
    demand = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            demand[i] = float(row['Demand_Forecast'])

    T = len(demand)  # 6 months
    months = range(T)

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    W0 = params['initial_workforce']
    I0 = params['initial_inventory']
    sp = params['sales_price']
    rmc = params['raw_material_cost']
    oc = params['outsourcing_cost']
    hc = params['inventory_holding_cost']
    bc = params['backorder_cost']
    lr = params['labor_requirement']
    rh = params['regular_labor_hours']
    rw = params['regular_wage']
    otl = params['overtime_hours_limit']
    ow = params['overtime_wage']
    hire_cost = params['hiring_cost']
    fire_cost = params['firing_cost']
    term_inv = params['terminal_inventory']
    term_bo = params['terminal_backorders']
    contract_min_units = params['contract_min_units']
    contract_bigM = params['contract_bigM']

    # --- Model ---
    m = gp.Model("RevisedFoldableTableProduction")

    # --- Decision Variables ---
    W = m.addVars(months, name="W", lb=0)  # Workforce
    H = m.addVars(months, name="H", lb=0)  # Hired
    F = m.addVars(months, name="F", lb=0)  # Fired
    P_reg = m.addVars(months, name="P_reg", lb=0) # In-house production (regular)
    P_ot = m.addVars(months, name="P_ot", lb=0)   # In-house production (overtime)
    OT_total = m.addVars(months, name="OT", lb=0) # Total overtime hours
    O = m.addVars(months, name="O", lb=0)         # Outsourced units
    Inv = m.addVars(months, name="Inv", lb=0)     # Inventory
    B = m.addVars(months, name="B", lb=0)         # Backorders

    # Binary variables for the new contract constraint (April-June, i.e., t=3,4,5)
    contract_months = [3, 4, 5]
    y = m.addVars(contract_months, name="y", vtype=GRB.BINARY)

    # --- Objective Function ---
    # Total revenue (all demand is met by the end)
    total_demand_val = sum(demand.values())
    revenue = sp * total_demand_val

    # Total costs
    material_cost = rmc * gp.quicksum(P_reg[t] + P_ot[t] for t in months)
    outsource_cost = oc * gp.quicksum(O[t] for t in months)
    holding_cost = hc * gp.quicksum(Inv[t] for t in months)
    backorder_cost_total = bc * gp.quicksum(B[t] for t in months)
    regular_labor_cost = rw * rh * gp.quicksum(W[t] for t in months)
    overtime_cost = ow * gp.quicksum(OT_total[t] for t in months)
    hiring_cost_total = hire_cost * gp.quicksum(H[t] for t in months)
    firing_cost_total = fire_cost * gp.quicksum(F[t] for t in months)

    total_cost = (material_cost + outsource_cost + holding_cost + backorder_cost_total +
                  regular_labor_cost + overtime_cost + hiring_cost_total + firing_cost_total)

    m.setObjective(revenue - total_cost, GRB.MAXIMIZE)

    # --- Constraints ---
    for t in months:
        # Workforce balance
        if t == 0:
            m.addConstr(W[t] == W0 + H[t] - F[t], name=f"workforce_balance_{t}")
        else:
            m.addConstr(W[t] == W[t-1] + H[t] - F[t], name=f"workforce_balance_{t}")

        # Production capacity
        m.addConstr(P_reg[t] * lr <= W[t] * rh, name=f"regular_prod_capacity_{t}")
        m.addConstr(P_ot[t] * lr <= OT_total[t], name=f"overtime_prod_capacity_{t}")

        # Overtime limit
        m.addConstr(OT_total[t] <= W[t] * otl, name=f"overtime_limit_{t}")

        # Inventory balance
        P_total = P_reg[t] + P_ot[t]
        prev_inv = I0 if t == 0 else Inv[t-1]
        prev_b = 0 if t == 0 else B[t-1]
        m.addConstr(Inv[t] - B[t] == prev_inv - prev_b + P_total + O[t] - demand[t], name=f"inventory_balance_{t}")

    # New contract constraints for April-June (t=3,4,5)
    for t in contract_months:
        live_req = demand[t] + B[t-1]
        M = contract_bigM

        # Set binary variable y[t]: y[t]=1 if live_req < contract_min_units, 0 otherwise
        m.addConstr(live_req - contract_min_units <= M * (1 - y[t]) - 1e-6, name=f"set_y_upper_{t}")
        m.addConstr(live_req - contract_min_units >= -M * y[t], name=f"set_y_lower_{t}")

        # Enforce P_reg[t] >= min(contract_min_units, live_req)
        # If y[t]=1 (live_req is smaller), then P_reg[t] >= live_req
        m.addConstr(P_reg[t] >= live_req - M * (1 - y[t]), name=f"contract_cond1_{t}")
        # If y[t]=0 (contract_min_units is smaller or equal), then P_reg[t] >= contract_min_units
        m.addConstr(P_reg[t] >= contract_min_units - M * y[t], name=f"contract_cond2_{t}")

    # Terminal conditions
    m.addConstr(Inv[T-1] >= term_inv, name="terminal_inventory")
    m.addConstr(B[T-1] == term_bo, name="terminal_backorders")

    # --- Solve and Output ---
    m.setParam('OutputFlag', 0)
    m.optimize()

    if m.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("No optimal solution found or an error occurred.")
        # In case of error, it's useful to re-run with output enabled
        # m.setParam('OutputFlag', 1)
        # m.optimize()

if __name__ == "__main__":
    solve()
