import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Loads parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- 1. Load Data and Parameters ---
# Construct the full path to the data file, assuming script is run from workspace root
data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
params = load_parameters(data_path)

# Define sets
fruits = ['apples', 'pears', 'oranges', 'lemons']
seasons = ['spring', 'autumn']

# Extract parameters into structured dictionaries
profits = {f: params[f'profit_per_acre_{f}'] for f in fruits}
water_reqs = {(f, s): params[f'water_per_acre_{f}_{s}'] for f in fruits for s in seasons}

total_farm_area = params['total_farm_area']
min_a_to_p = params['min_apples_to_pears_ratio']
min_a_to_l = params['min_apples_to_lemons_ratio']
o_to_l = params['oranges_to_lemons_ratio']
max_fruit_types = int(params['max_fruit_types'])

water_cap_spring = params['water_cap_spring']
water_cap_autumn = params['water_cap_autumn']
total_water_budget = params['total_water_budget']
min_annual_water_per_fruit = params['min_annual_water_per_fruit']
diversification_reward = params['diversification_reward']

# --- 2. Create Gurobi Model ---
model = gp.Model("FarmOptimizationRevised")
model.setParam('OutputFlag', 0)

# --- 3. Define Decision Variables ---
# x[f, s]: acres of fruit f planted in season s
x = model.addVars(fruits, seasons, name="acres", lb=0)

# y[f]: binary, 1 if fruit f is grown at all, 0 otherwise
y = model.addVars(fruits, vtype=GRB.BINARY, name="is_grown")

# d: binary, 1 if diversification reward is earned (>= 2 fruits)
d = model.addVar(vtype=GRB.BINARY, name="diversification_bonus")

# --- 4. Define Helper Expressions ---
# Total annual acres per fruit
total_annual_acres = {f: gp.quicksum(x[f, s] for s in seasons) for f in fruits}

# Total annual water per fruit
total_annual_water = {f: gp.quicksum(water_reqs[f, s] * x[f, s] for s in seasons) for f in fruits}

# --- 5. Set Objective Function ---
# Maximize total profit from fruit sales plus diversification reward
profit_from_fruits = gp.quicksum(profits[f] * total_annual_acres[f] for f in fruits)
model.setObjective(profit_from_fruits + diversification_reward * d, GRB.MAXIMIZE)

# --- 6. Add Constraints ---
# Land Area Constraints (per season)
model.addConstr(gp.quicksum(x[f, 'spring'] for f in fruits) <= total_farm_area, "SpringArea")
model.addConstr(gp.quicksum(x[f, 'autumn'] for f in fruits) <= total_farm_area, "AutumnArea")

# Water Constraints
# Seasonal water caps
model.addConstr(gp.quicksum(water_reqs[f, 'spring'] * x[f, 'spring'] for f in fruits) <= water_cap_spring, "SpringWater")
model.addConstr(gp.quicksum(water_reqs[f, 'autumn'] * x[f, 'autumn'] for f in fruits) <= water_cap_autumn, "AutumnWater")
# Total annual water budget
model.addConstr(gp.quicksum(total_annual_water[f] for f in fruits) <= total_water_budget, "TotalWaterBudget")

# Annual Fruit Mix Ratio Constraints
model.addConstr(total_annual_acres['apples'] >= min_a_to_p * total_annual_acres['pears'], "ApplesToPearsRatio")
model.addConstr(total_annual_acres['apples'] >= min_a_to_l * total_annual_acres['lemons'], "ApplesToLemonsRatio")
model.addConstr(total_annual_acres['oranges'] == o_to_l * total_annual_acres['lemons'], "OrangesToLemonsRatio")

# Max Fruit Types Constraint
model.addConstr(gp.quicksum(y[f] for f in fruits) <= max_fruit_types, "MaxFruitTypes")

# Linking acres (x) to grown status (y)
# If any acres are planted for a fruit, its 'is_grown' flag must be 1.
# A safe Big-M is 2 * total_farm_area, as a fruit can't occupy more than the total farm area in each of the two seasons.
M_area = 2 * total_farm_area
for f in fruits:
    model.addConstr(total_annual_acres[f] <= M_area * y[f], f"Link_Acres_{f}")

# Minimum Annual Water per Fruit Constraint
# If a fruit is grown (y[f]=1), it must use a minimum amount of water.
for f in fruits:
    model.addConstr(total_annual_water[f] >= min_annual_water_per_fruit * y[f], f"MinWater_{f}")

# Diversification Reward Constraint
# The bonus 'd' can be 1 only if at least two fruits are grown.
model.addConstr(gp.quicksum(y[f] for f in fruits) >= 2 * d, "DiversificationCondition")

# --- 7. Solve the Model ---
model.optimize()

# --- 8. Print the Final Objective Value ---
print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
