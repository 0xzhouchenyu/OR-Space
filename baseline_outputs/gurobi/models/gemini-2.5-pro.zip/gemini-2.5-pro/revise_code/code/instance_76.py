import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    # --- Path Setup ---
    # The script is executed from the workspace root.
    # The instruction specifies using os.path.join with __file__ for robustness.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # --- Data Loading ---

    # Read general_parameters.csv
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        params = {row['Parameter_Name'].strip(): row['Value'].strip() for row in reader}

    # Read table_1.csv
    quarters_map = {}
    purchase_price = {}
    sale_price = {}
    max_sales = {}
    max_purchase = {}

    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            q_name = row['Quarter'].strip()
            quarters_map[i] = q_name
            purchase_price[i] = float(row['Purchase_Price_10k_yuan_per_10k_m2'].strip())
            sale_price[i] = float(row['Sale_Price_10k_yuan_per_10k_m2'].strip())
            max_sales[i] = float(row['Estimated_Max_Sales_Volume_10k_m3'].strip())
            max_purchase[i] = float(row['max_purchase_10k_m3'].strip())

    # --- Parameter Processing and Unit Conversion ---
    n = len(quarters_map) # Number of quarters (should be 4)

    # Convert units to be consistent: volumes in 10k m³, money in 10k yuan.
    max_storage_capacity = float(params['max_storage_capacity']) / 10000.0
    storage_cost_a = float(params['storage_cost_a'])
    storage_cost_b = float(params['storage_cost_b'])
    safety_inventory_level = float(params['safety_inventory_level_10k_m3'])
    terminal_inventory_value = float(params['terminal_inventory_value_per_10k_m3'])
    over_purchase_penalty_cost = float(params['over_purchase_penalty_cost_per_10k_m3'])

    # --- Model Creation ---
    model = gp.Model("Timber_Profit_Maximization_Revised")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # x[i, j]: amount purchased in quarter i, sold in quarter j (unit: 10k m³)
    x_keys = [(i, j) for i in range(n) for j in range(i, n)]
    x = model.addVars(x_keys, name="x", lb=0)

    # y[i]: amount purchased in quarter i, held as terminal inventory (unit: 10k m³)
    y = model.addVars(n, name="y", lb=0)

    # I_over: amount of terminal inventory above safety level (unit: 10k m³)
    I_over = model.addVar(name="I_over", lb=0)

    # --- Objective Function ---
    # Maximize: Revenue - Purchase Cost - Storage Cost + Terminal Value - Penalty
    
    revenue = gp.quicksum(sale_price[j] * x[i, j] for i, j in x_keys)

    total_purchased_in_i = {i: (gp.quicksum(x[i, j] for j in range(i, n)) + y[i]) for i in range(n)}
    purchase_cost = gp.quicksum(purchase_price[i] * total_purchased_in_i[i] for i in range(n))

    storage_cost_sales = gp.quicksum(
        (storage_cost_a + storage_cost_b * (j - i)) * x[i, j]
        for i, j in x_keys if j > i
    )

    storage_cost_terminal = gp.quicksum(
        (storage_cost_a + storage_cost_b * (4 - i)) * y[i]
        for i in range(n)
    )

    total_terminal_inventory = y.sum()
    terminal_value = terminal_inventory_value * total_terminal_inventory
    penalty = over_purchase_penalty_cost * I_over

    model.setObjective(
        revenue - purchase_cost - storage_cost_sales - storage_cost_terminal + terminal_value - penalty,
        GRB.MAXIMIZE
    )

    # --- Constraints ---

    # 1. Purchase caps per quarter
    for i in range(n):
        model.addConstr(total_purchased_in_i[i] <= max_purchase[i], name=f"PurchaseCap_{quarters_map[i]}")

    # 2. Sales caps per quarter
    for j in range(n):
        total_sold_in_j = gp.quicksum(x[i, j] for i in range(j + 1))
        model.addConstr(total_sold_in_j <= max_sales[j], name=f"SalesCap_{quarters_map[j]}")

    # 3. Storage capacity at the end of each quarter (t=0, 1, 2)
    for t in range(n - 1): # End of Winter, Spring, Summer
        stored_for_sale = gp.quicksum(x[i, j] for i in range(t + 1) for j in range(t + 1, n))
        stored_for_terminal = gp.quicksum(y[i] for i in range(t + 1))
        model.addConstr(stored_for_sale + stored_for_terminal <= max_storage_capacity, name=f"StorageCap_{quarters_map[t]}")

    # 4. Link terminal inventory to the over-purchase variable
    model.addConstr(total_terminal_inventory - I_over <= safety_inventory_level, name="OverPurchaseLink")

    # --- Solve and Output ---
    model.optimize()

    # Print the final objective value as required
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")


if __name__ == "__main__":
    main()
