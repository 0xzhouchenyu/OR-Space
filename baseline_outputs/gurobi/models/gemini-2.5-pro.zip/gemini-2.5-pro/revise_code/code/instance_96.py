import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def get_data_paths():
    """Constructs absolute paths to data files."""
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    table_1_path = os.path.join(data_dir, 'table_1.csv')
    params_path = os.path.join(data_dir, 'general_parameters.csv')
    return table_1_path, params_path

def generate_patterns_for_supplier(supplier_params, item_lengths, n_items):
    """Generates all valid cutting patterns for a single supplier."""
    patterns = []
    raw_pipe_length = supplier_params['raw_pipe_length']
    max_pieces = supplier_params['max_cuts_per_pipe']
    max_leftover = supplier_params['max_leftover_length']
    min_used_length = raw_pipe_length - max_leftover

    def find_combinations(item_idx, current_pattern, current_length, current_pieces):
        if item_idx == n_items:
            if current_pieces > 0 and current_length >= min_used_length and current_length <= raw_pipe_length:
                patterns.append(tuple(current_pattern))
            return

        if item_lengths[item_idx] <= 0: # Should not happen with valid data
             max_q = 0
        else:
            max_q = min(
                max_pieces - current_pieces,
                int((raw_pipe_length - current_length) // item_lengths[item_idx])
            )

        for q in range(max_q + 1):
            find_combinations(
                item_idx + 1,
                current_pattern + (q,),
                current_length + q * item_lengths[item_idx],
                current_pieces + q
            )

    find_combinations(0, (), 0, 0)
    return patterns

def solve():
    """Solves the revised pipe cutting optimization problem."""
    # 1. Load data
    table_1_path, params_path = get_data_paths()
    df_items = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path).set_index('Parameter_Name')['Value']

    # 2. Parse parameters
    suppliers = [1, 2]
    s_params = {}
    for s in suppliers:
        s_params[s] = {
            'raw_pipe_length': float(df_params[f'raw_pipe_length_supplier{s}']),
            'max_cutting_patterns': int(df_params[f'max_cutting_patterns_supplier{s}']),
            'max_cuts_per_pipe': int(df_params[f'max_cuts_per_pipe_supplier{s}']),
            'max_leftover_length': float(df_params[f'max_leftover_length_supplier{s}']),
            'purchase_cost_per_pipe': float(df_params[f'purchase_cost_per_pipe_supplier{s}']),
            'cost_rates': [
                float(df_params[f'most_frequent_pattern_cost_rate_supplier{s}']),
                float(df_params[f'second_frequent_pattern_cost_rate_supplier{s}']),
                float(df_params[f'third_frequent_pattern_cost_rate_supplier{s}'])
            ]
        }

    discount_tier1_s1_qty = int(df_params['discount_tier1_supplier1_max_qty'])
    fixed_discount_s1 = float(df_params['fixed_discount_tier2_supplier1'])
    big_m = float(df_params['bigM_discount'])

    item_lengths = df_items['Length'].tolist()
    demands = df_items['Quantity'].tolist()
    n_items = len(item_lengths)

    # 3. Generate patterns for each supplier
    all_patterns = {s: generate_patterns_for_supplier(s_params[s], item_lengths, n_items) for s in suppliers}

    # 4. Create Gurobi model
    model = gp.Model("RevisedPipeCutting")

    # 5. Define variables
    y = model.addVars([(s, p) for s in suppliers for p in range(len(all_patterns[s]))], vtype=GRB.INTEGER, name="y")
    z = model.addVars(y.keys(), vtype=GRB.BINARY, name="z")
    u = model.addVars([(s, k) for s in suppliers for k in range(1, s_params[s]['max_cutting_patterns'] + 1)], vtype=GRB.BINARY, name="u")
    d1 = model.addVar(vtype=GRB.BINARY, name="discount_s1")

    # 6. Set objective function
    total_pipes = {s: gp.quicksum(y[s, p] for p in range(len(all_patterns[s]))) for s in suppliers}
    
    purchase_cost = gp.quicksum(total_pipes[s] * s_params[s]['purchase_cost_per_pipe'] for s in suppliers)
    
    pattern_cost = gp.quicksum(u[s, k] * s_params[s]['cost_rates'][k-1] for s, k in u.keys())
    
    discount_value = fixed_discount_s1 * d1
    
    model.setObjective(purchase_cost + pattern_cost - discount_value, GRB.MINIMIZE)

    # 7. Add constraints
    # Demand fulfillment
    for i in range(n_items):
        model.addConstr(
            gp.quicksum(all_patterns[s][p][i] * y[s, p] for s, p in y.keys()) >= demands[i],
            name=f"demand_{i}"
        )

    # Link y and z variables
    for s, p in y.keys():
        model.addConstr(y[s, p] <= big_m * z[s, p], name=f"yz_link_{s}_{p}")

    # Pattern counting and cost logic
    for s in suppliers:
        max_k = s_params[s]['max_cutting_patterns']
        model.addConstr(
            gp.quicksum(z[s, p] for p in range(len(all_patterns[s]))) == gp.quicksum(u[s, k] for k in range(1, max_k + 1)),
            name=f"pattern_count_{s}"
        )
        for k in range(1, max_k):
            model.addConstr(u[s, k] >= u[s, k+1], name=f"pattern_order_{s}_{k}")

    # Supplier 1 discount logic
    model.addConstr(total_pipes[1] >= (discount_tier1_s1_qty + 1) * d1, name="discount_trigger")

    # 8. Solve and print output
    model.setParam('OutputFlag', 0)
    model.optimize()

    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
