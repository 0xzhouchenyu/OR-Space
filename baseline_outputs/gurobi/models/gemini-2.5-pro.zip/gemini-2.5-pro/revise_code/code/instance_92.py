import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = row['Value'].strip()
    return params

# --- Main script ---

# Load data
# The script is executed from the root, so the path is relative to the root.
# Using the robust path construction as requested.
try:
    script_dir = os.path.dirname(os.path.abspath(__file__))
except NameError:
    # Handle case where __file__ is not defined (e.g., in an interactive session)
    script_dir = os.getcwd()

data_dir = os.path.join(script_dir, 'data')
params = load_parameters(os.path.join(data_dir, 'general_parameters.csv'))

# Assign parameters from loaded data
num_students = int(params['num_students'])
num_buses = int(params['num_buses'])
bus_capacity = int(params['bus_capacity'])
num_minibuses = int(params['num_minibuses'])
minibus_capacity = int(params['minibus_capacity'])
num_drivers = int(params['num_drivers'])
bus_rental_cost = float(params['bus_rental_cost'])
minibus_rental_cost = float(params['minibus_rental_cost'])

# Create the optimization model
model = gp.Model("RevisedSchoolTrip")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# Decision variables
# x: number of buses
# y: number of minibuses
x = model.addVar(vtype=GRB.INTEGER, name="buses", lb=0, ub=num_buses)
# New requirement: at least one minibus must be rented
y = model.addVar(vtype=GRB.INTEGER, name="minibuses", lb=1, ub=num_minibuses)

# Objective: minimize total rental cost
model.setObjective(bus_rental_cost * x + minibus_rental_cost * y, GRB.MINIMIZE)

# Constraints
# 1. Must transport all students
model.addConstr(bus_capacity * x + minibus_capacity * y >= num_students, "StudentCapacity")

# 2. Total vehicles cannot exceed the number of available drivers
model.addConstr(x + y <= num_drivers, "DriverLimit")

# 3. New safety policy: for every minibus, at least two buses must be rented
model.addConstr(x >= 2 * y, "SafetyRatio")

# Solve the model
model.optimize()

# Output the final objective value
if model.status == GRB.OPTIMAL:
    final_obj_value = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {final_obj_value}")
else:
    print("No optimal solution found.")
