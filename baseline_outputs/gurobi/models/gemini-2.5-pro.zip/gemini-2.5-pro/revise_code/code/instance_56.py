import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Data Loading ---
# The script is executed from the root, so data files are in the 'data' subdirectory.
# Using os.path.join with __file__ makes the path robust.
try:
    script_dir = os.path.dirname(os.path.abspath(__file__))
except NameError:
    # Fallback for environments where __file__ is not defined
    script_dir = os.getcwd()

data_dir = os.path.join(script_dir, 'data')

# Load general parameters from CSV into a dictionary
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        params[row['Parameter_Name']] = float(row['Value'])

# Assign parameters to variables for clarity
warehouse_capacity = params['warehouse_capacity']
initial_stock = params['initial_stock']
initial_funds = params['initial_funds']
end_of_quarter_inventory = params['end_of_quarter_inventory']
buy_fast_capacity = params['buy_fast_capacity']
fast_purchase_premium_ratio = params['fast_purchase_premium_ratio']
credit_limit = params['credit_limit']
monthly_interest_rate = params['monthly_interest_rate']
min_inventory_by_month = {
    1: params['min_inventory_month_1'],
    2: params['min_inventory_month_2'],
    3: params['min_inventory_month_3']
}

# Load monthly price data from CSV
months = []
purchase_prices = {}
selling_prices = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        m = int(row['Month'])
        months.append(m)
        purchase_prices[m] = float(row['Purchase_Price_yuan_per_dan'])
        selling_prices[m] = float(row['Selling_Price_yuan_per_dan'])

# --- Model Formulation ---
model = gp.Model("Grain_Trading_Revised")
model.setParam('OutputFlag', 0)

# --- Decision Variables ---
# Non-negative variables for physical quantities and credit
buy_regular = model.addVars(months, name="buy_regular", lb=0)
buy_fast = model.addVars(months, name="buy_fast", lb=0)
sell = model.addVars(months, name="sell", lb=0)
stock = model.addVars(months, name="stock", lb=0)
credit_used = model.addVars(months, name="credit_used", lb=0)

# Net funds can be positive (cash) or negative (debt), so it's a free variable
net_funds = model.addVars(months, name="net_funds", lb=-GRB.INFINITY)

# --- Objective Function ---
# The commercial objective is to maximize the financial gain.
# This is the change in net worth: final net funds - initial net funds.
# Setting this as the objective makes model.objVal the total profit.
model.setObjective(net_funds[months[-1]] - initial_funds, GRB.MAXIMIZE)

# --- Constraints ---
for m in months:
    # Define state variables from the previous month
    if m == 1:
        prev_stock = initial_stock
        prev_net_funds = initial_funds
        prev_credit_used = 0  # No debt initially
    else:
        prev_stock = stock[m - 1]
        prev_net_funds = net_funds[m - 1]
        prev_credit_used = credit_used[m - 1]

    # Calculate costs for the current month
    fast_purchase_price = purchase_prices[m] * (1 + fast_purchase_premium_ratio)
    # Interest is paid in month m on the debt from the end of month m-1
    interest_payment = prev_credit_used * monthly_interest_rate

    # Stock balance: inventory at end of month
    model.addConstr(stock[m] == prev_stock + buy_regular[m] + buy_fast[m] - sell[m], f"stock_balance_{m}")

    # Funds balance: net financial position at end of month
    model.addConstr(net_funds[m] == prev_net_funds
                                    + sell[m] * selling_prices[m]
                                    - buy_regular[m] * purchase_prices[m]
                                    - buy_fast[m] * fast_purchase_price
                                    - interest_payment, f"funds_balance_{m}")

    # Link net_funds to credit_used. If net_funds is negative, credit_used must be at least its absolute value.
    # Since interest costs are minimized, the model will set credit_used to exactly -net_funds when net_funds is negative.
    model.addConstr(credit_used[m] >= -net_funds[m], f"credit_definition_{m}")

    # Operational and policy constraints
    model.addConstr(stock[m] <= warehouse_capacity, f"warehouse_capacity_{m}")
    model.addConstr(sell[m] <= prev_stock, f"sell_limit_{m}")
    model.addConstr(buy_fast[m] <= buy_fast_capacity, f"fast_buy_capacity_{m}")
    model.addConstr(credit_used[m] <= credit_limit, f"credit_limit_{m}")
    model.addConstr(stock[m] >= min_inventory_by_month[m], f"min_inventory_{m}")

# End-of-quarter inventory requirement
model.addConstr(stock[months[-1]] >= end_of_quarter_inventory, "end_of_quarter_inventory")

# --- Solve and Output ---
model.optimize()

if model.status == GRB.OPTIMAL:
    final_obj_value = model.objVal
    print(f"FINAL_OBJ_VALUE: {final_obj_value}")
else:
    print(f"Optimization was not successful. Status code: {model.status}")
