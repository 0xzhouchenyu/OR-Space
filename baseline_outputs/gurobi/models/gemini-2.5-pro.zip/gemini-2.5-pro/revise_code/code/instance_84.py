import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_recruitment():
    """
    Solves the revised employee recruitment optimization problem.
    """
    # Define base directory and data directory
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # This is for environments where __file__ is not defined (e.g., interactive)
        base_dir = os.getcwd()
        
    data_dir = os.path.join(base_dir, "data")

    # --- Data Loading ---

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Load candidate data and create a lookup dictionary
    candidate_data = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Candidate'].strip()
            candidate_data[name] = {
                'salary': int(row['Salary'].strip()),
                'qualification': row['Qualification'].strip(),
                'experience': int(row['Work_Experience'].strip())
            }
    
    candidate_names = list(candidate_data.keys())

    # --- Model Formulation ---

    # Create a new model
    model = gp.Model("RevisedRecruitment")

    # --- Decision Variables ---
    # m[c] = 1 if candidate c is hired as a Manager, 0 otherwise
    # s[c] = 1 if candidate c is hired as a Specialist, 0 otherwise
    m = model.addVars(candidate_names, vtype=GRB.BINARY, name="manager")
    s = model.addVars(candidate_names, vtype=GRB.BINARY, name="specialist")

    # A candidate can be at most one role (Manager or Specialist), or not hired
    model.addConstrs((m[c] + s[c] <= 1 for c in candidate_names), "one_role_per_candidate")

    # --- Objective Function ---
    # Minimize total cost = sum of base salaries + sum of manager bonuses
    total_base_salary = gp.quicksum(candidate_data[c]['salary'] * (m[c] + s[c]) for c in candidate_names)
    total_manager_bonus = params['manager_bonus_per_candidate'] * gp.quicksum(m[c] for c in candidate_names)
    
    model.setObjective(total_base_salary + total_manager_bonus, GRB.MINIMIZE)

    # --- Constraints ---

    # Total number of hired employees
    total_hired = gp.quicksum(m[c] + s[c] for c in candidate_names)
    model.addConstr(total_hired <= params['max_employees'], "max_total_employees")
    model.addConstr(total_hired >= params['min_employees'], "min_total_employees")

    # Budget for base salaries
    model.addConstr(total_base_salary <= params['budget_limit'], "budget_constraint")

    # At least one candidate with an advanced degree (Master's or Doctoral)
    advanced_degree_candidates = [c for c in candidate_names if candidate_data[c]['qualification'] in ["Master's degree", "Doctoral degree"]]
    model.addConstr(gp.quicksum(m[c] + s[c] for c in advanced_degree_candidates) >= params['min_advanced_degree_candidates'], "min_advanced_degree")

    # Minimum total work experience of all selected candidates
    total_experience = gp.quicksum(candidate_data[c]['experience'] * (m[c] + s[c]) for c in candidate_names)
    model.addConstr(total_experience >= params['min_work_experience'], "min_total_experience")

    # At most one from the equivalent pair (A and E)
    model.addConstr((m['A'] + s['A']) + (m['E'] + s['E']) <= params['max_equivalent_candidates'], "equivalent_pair_A_E")

    # --- Revised Constraints ---

    # Manager headcount limits
    total_managers = gp.quicksum(m[c] for c in candidate_names)
    model.addConstr(total_managers >= params['min_managers'], "min_managers")
    model.addConstr(total_managers <= params['max_managers'], "max_managers")

    # Minimum total work experience for hired managers
    total_manager_experience = gp.quicksum(candidate_data[c]['experience'] * m[c] for c in candidate_names)
    model.addConstr(total_manager_experience >= params['min_manager_experience'], "min_manager_experience")

    # --- Solve ---
    
    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)
    
    # Optimize the model
    model.optimize()

    # --- Output ---
    
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # Handle cases where no solution is found
        print("No optimal solution found.")

if __name__ == '__main__':
    solve_recruitment()
