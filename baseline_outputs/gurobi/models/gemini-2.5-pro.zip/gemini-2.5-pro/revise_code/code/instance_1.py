import gurobipy as gp
from gurobipy import GRB
import os
import csv
import sys

def load_csv(filename):
    """
    Loads a CSV file from the 'data' subdirectory.
    Assumes the script is run from the project root.
    """
    # The instruction specifies a particular pathing style.
    # This implementation ensures it works whether the script is in root or a subdir.
    # Assuming the script is run from the root, __file__ is the script name.
    # os.path.dirname(__file__) will be the directory containing the script.
    # If the script is in root, this is ''. If in 'src', this is 'src'.
    # The problem states "Your script will be saved and executed from the revised workspace root directory."
    # So, os.path.dirname(__file__) will be the root directory.
    # The path should be 'data/filename.csv'.
    filepath = os.path.join("data", filename)
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            rows.append(row)
    return rows

def load_parameters():
    """
    Loads general parameters from general_parameters.csv.
    """
    rows = load_csv('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name'].strip()
        val = row['Value'].strip()
        try:
            if '.' in val:
                params[name] = float(val)
            else:
                params[name] = int(val)
        except ValueError:
            params[name] = val
    return params

def load_demand():
    """
    Loads weekly demand from table_1.csv.
    """
    rows = load_csv('table_1.csv')
    demand = {}
    for row in rows:
        week = int(row['Week'].strip())
        demand[week] = {
            'I': int(row['I'].strip()),
            'II': int(row['II'].strip())
        }
    return demand

def solve_model():
    """
    Defines and solves the optimization problem.
    """
    # Load data
    params = load_parameters()
    demand = load_demand()

    # Time horizon
    T = 8
    weeks = range(1, T + 1)

    # Model
    model = gp.Model("FactoryTrainingRevised")

    # Parameters
    S0 = params['skilled_worker_count']
    rate_I = params['food_I_production_rate']
    rate_II = params['food_II_production_rate']
    normal_hours = params['worker_weekly_hours']
    overtime_hours = params['skilled_worker_overtime_hours']
    train_cap = params['training_capacity']
    train_period = params['training_period']
    wage_skilled = params['skilled_worker_weekly_wage']
    wage_trainee_during = params['trainee_weekly_wage_during_training']
    wage_trainee_after = params['trainee_weekly_wage_after_training']
    wage_overtime = params['skilled_worker_overtime_wage']
    comp_I = params['compensation_fee_food_I']
    comp_II = params['compensation_fee_food_II']
    new_worker_goal = params['new_worker_training_goal']

    # Week ranges for training
    train_start_weeks = range(1, T - train_period + 2)  # Weeks 1..7

    # Decision Variables
    # y_I[t], y_II[t]: binary, choice of production in week t
    y_I = model.addVars(weeks, vtype=GRB.BINARY, name="y_I")
    y_II = model.addVars(weeks, vtype=GRB.BINARY, name="y_II")

    # n_train[t]: integer, number of trainers starting in week t
    n_train = model.addVars(train_start_weeks, vtype=GRB.INTEGER, lb=0, name="n_train")

    # n_overtime[t]: integer, number of skilled workers on overtime in week t
    n_overtime = model.addVars(weeks, vtype=GRB.INTEGER, lb=0, name="n_overtime")

    # backlog_I[t], backlog_II[t]: continuous, unmet demand
    backlog_I = model.addVars(weeks, vtype=GRB.CONTINUOUS, lb=0, name="backlog_I")
    backlog_II = model.addVars(weeks, vtype=GRB.CONTINUOUS, lb=0, name="backlog_II")

    # h_I[t], h_II[t]: continuous, total hours allocated to each food type
    h_I = model.addVars(weeks, vtype=GRB.CONTINUOUS, lb=0, name="h_I")
    h_II = model.addVars(weeks, vtype=GRB.CONTINUOUS, lb=0, name="h_II")

    # Big-M constant for production hour allocation
    M = S0 * overtime_hours + new_worker_goal * normal_hours

    # Constraints
    for t in weeks:
        # --- Worker Availability Expressions ---
        trainers_busy_t = gp.quicksum(n_train[s] for s in train_start_weeks if s <= t < s + train_period)
        avail_skilled_prod_t = S0 - trainers_busy_t
        graduates_available_t = gp.quicksum(train_cap * n_train[s] for s in train_start_weeks if s + train_period <= t)

        # --- Production Hours ---
        total_hours_t = (avail_skilled_prod_t - n_overtime[t]) * normal_hours + \
                        n_overtime[t] * overtime_hours + \
                        graduates_available_t * normal_hours

        # --- Production and Backlog ---
        prod_I_t = h_I[t] * rate_I
        prod_II_t = h_II[t] * rate_II

        prev_bI = backlog_I[t - 1] if t > 1 else 0
        prev_bII = backlog_II[t - 1] if t > 1 else 0

        model.addConstr(backlog_I[t] >= prev_bI + demand[t]['I'] - prod_I_t, f"backlog_balance_I_{t}")
        model.addConstr(backlog_II[t] >= prev_bII + demand[t]['II'] - prod_II_t, f"backlog_balance_II_{t}")

        # --- Core Revision Constraints ---
        # Mutual exclusion: only one food type per week
        model.addConstr(y_I[t] + y_II[t] <= 1, f"mutual_exclusion_{t}")

        # Link total hours to allocated hours
        model.addConstr(h_I[t] + h_II[t] == total_hours_t, f"total_hours_match_{t}")

        # Link allocated hours to production choice (Big-M)
        model.addConstr(h_I[t] <= M * y_I[t], f"bigM_I_{t}")
        model.addConstr(h_II[t] <= M * y_II[t], f"bigM_II_{t}")

        # --- Workforce Constraints ---
        model.addConstr(n_overtime[t] <= avail_skilled_prod_t, f"overtime_limit_{t}")
        model.addConstr(avail_skilled_prod_t >= 0, f"nonnegative_producers_{t}")

    # Training Goal Constraint
    total_trained = gp.quicksum(train_cap * n_train[s] for s in train_start_weeks)
    model.addConstr(total_trained >= new_worker_goal, "training_goal")

    # Objective Function: Minimize Total Cost
    total_wage_cost = gp.LinExpr()
    total_backlog_cost = gp.LinExpr()

    for t in weeks:
        # --- Wage Costs ---
        graduates_available_t = gp.quicksum(train_cap * n_train[s] for s in train_start_weeks if s + train_period <= t)
        trainees_in_training_t = gp.quicksum(train_cap * n_train[s] for s in train_start_weeks if s <= t < s + train_period)

        skilled_wage_t = (S0 - n_overtime[t]) * wage_skilled + n_overtime[t] * wage_overtime
        trainee_during_wage_t = trainees_in_training_t * wage_trainee_during
        trainee_after_wage_t = graduates_available_t * wage_trainee_after

        total_wage_cost += skilled_wage_t + trainee_during_wage_t + trainee_after_wage_t

        # --- Backlog Costs ---
        total_backlog_cost += backlog_I[t] * comp_I + backlog_II[t] * comp_II

    model.setObjective(total_wage_cost + total_backlog_cost, GRB.MINIMIZE)

    # Solve
    model.setParam('OutputFlag', 0)
    model.optimize()

    # Print result
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")
        # In a real scenario, you might print model status, IIS, etc.
        # For this problem, we assume a solution will be found.

if __name__ == "__main__":
    solve_model()
