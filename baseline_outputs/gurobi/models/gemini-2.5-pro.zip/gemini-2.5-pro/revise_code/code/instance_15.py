import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    """
    Solves the revised tool repair and purchasing optimization problem.
    """
    # --- Data Loading ---
    # Per instructions, construct path relative to the script file's location.
    # This assumes the script is in the root directory and data is in a 'data' subdirectory.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    params_df = pd.read_csv(os.path.join(data_dir, 'general_parameters.csv'))
    demand_df = pd.read_csv(os.path.join(data_dir, 'table_1.csv'))

    # Create parameter dictionary
    param_dict = dict(zip(params_df['Parameter_Name'], params_df['Value']))
    
    # Create demand dictionary
    demand = dict(zip(demand_df['stage'], demand_df['tool_requirement']))

    # --- Model Parameters ---
    n = int(param_dict['n'])
    cost_new = float(param_dict['cost_new_tool'])
    cost_slow = float(param_dict['cost_slow_repair'])
    cost_fast = float(param_dict['cost_fast_repair'])
    dur_slow = int(param_dict['slow_repair_duration'])
    dur_fast = int(param_dict['fast_repair_duration'])
    max_fast_stage = float(param_dict['max_fast_stage'])
    max_slow_stage = float(param_dict['max_slow_stage'])
    emission_buy = float(param_dict['emission_buy'])
    emission_fast = float(param_dict['emission_fast_repair'])
    emission_slow = float(param_dict['emission_slow_repair'])
    carbon_budget = float(param_dict['carbon_budget'])
    penalty_shortage = float(param_dict['penalty_shortage'])
    
    stages = range(1, n + 1)

    # --- Gurobi Model ---
    m = gp.Model("RevisedToolRepairProblem")
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    prebuy_clean = m.addVar(vtype=GRB.INTEGER, name="prebuy_clean", lb=0)
    buy = m.addVars(stages, vtype=GRB.INTEGER, name="buy", lb=0)
    fast = m.addVars(stages, vtype=GRB.INTEGER, name="fast", lb=0)
    slow = m.addVars(stages, vtype=GRB.INTEGER, name="slow", lb=0)
    shortage = m.addVars(stages, vtype=GRB.INTEGER, name="shortage", lb=0)
    
    # --- State/Helper Variables ---
    used = m.addVars(stages, vtype=GRB.INTEGER, name="used", lb=0)
    clean = m.addVars(range(n + 1), vtype=GRB.INTEGER, name="clean", lb=0)
    dirty = m.addVars(range(n + 1), vtype=GRB.INTEGER, name="dirty", lb=0)

    # --- Objective Function ---
    cost_expression = (
        prebuy_clean * cost_new +
        gp.quicksum(buy[t] * cost_new for t in stages) +
        gp.quicksum(fast[t] * cost_fast for t in stages) +
        gp.quicksum(slow[t] * cost_slow for t in stages) +
        gp.quicksum(shortage[t] * penalty_shortage for t in stages)
    )
    m.setObjective(cost_expression, GRB.MINIMIZE)

    # --- Constraints ---
    
    # Initial conditions
    m.addConstr(clean[0] == prebuy_clean, name="initial_clean")
    m.addConstr(dirty[0] == 0, name="initial_dirty")

    for t in stages:
        # Tool usage constraint
        m.addConstr(used[t] == demand[t] - shortage[t], name=f"usage_{t}")
        # Shortage cannot exceed demand (ensures used[t] is non-negative)
        m.addConstr(shortage[t] <= demand[t], name=f"shortage_cap_{t}")

        # Clean tool balance
        fast_ready = fast[t - dur_fast] if t > dur_fast else 0
        slow_ready = slow[t - dur_slow] if t > dur_slow else 0
        m.addConstr(
            clean[t] == clean[t-1] + buy[t] + fast_ready + slow_ready - used[t],
            name=f"clean_balance_{t}"
        )

        # Dirty tool balance
        m.addConstr(
            dirty[t] == dirty[t-1] + used[t] - fast[t] - slow[t],
            name=f"dirty_balance_{t}"
        )

        # Stage-wise repair capacity
        m.addConstr(fast[t] <= max_fast_stage, name=f"fast_cap_{t}")
        m.addConstr(slow[t] <= max_slow_stage, name=f"slow_cap_{t}")

    # Global carbon budget constraint
    carbon_expression = (
        prebuy_clean * emission_buy +
        gp.quicksum(buy[t] * emission_buy for t in stages) +
        gp.quicksum(fast[t] * emission_fast for t in stages) +
        gp.quicksum(slow[t] * emission_slow for t in stages)
    )
    m.addConstr(carbon_expression <= carbon_budget, name="carbon_budget")

    # --- Solve ---
    m.optimize()

    # --- Output ---
    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == "__main__":
    solve()
