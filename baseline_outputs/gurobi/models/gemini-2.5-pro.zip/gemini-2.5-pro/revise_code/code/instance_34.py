import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_goods_data(filepath):
    """Loads goods data from a CSV file."""
    goods = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            goods[row['Goods_Type'].strip()] = {
                'quantity': int(row['Quantity'].strip()),
                'weight': float(row['Weight_per_Unit'].strip())
            }
    return goods

def load_parameters(filepath):
    """Loads general parameters from a CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    return params

def solve_optimization_problem():
    """
    Models and solves the container minimization problem based on revised requirements.
    """
    # Define file paths relative to the script location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, 'data')
    goods_filepath = os.path.join(data_dir, 'table_1.csv')
    params_filepath = os.path.join(data_dir, 'general_parameters.csv')

    # Load data
    goods = load_goods_data(goods_filepath)
    params = load_parameters(params_filepath)

    # Extract parameters from loaded data
    max_cap = params['max_container_capacity']
    min_load = params['min_container_load']
    min_d_per_container = int(params['min_d_goods_per_container'])
    min_c_per_a = int(params['min_c_per_a'])
    
    # New parameter from revised requirements
    fragile_cap_e = 45

    goods_types = list(goods.keys())
    quantities = {g: goods[g]['quantity'] for g in goods_types}
    weights = {g: goods[g]['weight'] for g in goods_types}

    # Calculate a reasonable upper bound on the number of containers
    # Total D goods are 90, and each used container needs at least 10.
    # So, max containers <= 90 / 10 = 9. We use 10 as a safe upper bound.
    max_containers = 10
    containers = range(max_containers)

    # Create a new model
    m = gp.Model("RevisedContainerMinimization")
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # x[g, j]: number of units of goods type g in container j
    x = m.addVars(goods_types, containers, vtype=GRB.INTEGER, name="x")
    # y[j]: 1 if container j is used, 0 otherwise
    y = m.addVars(containers, vtype=GRB.BINARY, name="y")
    # a_in_j[j]: 1 if goods A are in container j
    a_in_j = m.addVars(containers, vtype=GRB.BINARY, name="a_in_j")
    # e_in_j[j]: 1 if goods E are in container j
    e_in_j = m.addVars(containers, vtype=GRB.BINARY, name="e_in_j")

    # --- Objective Function ---
    # Minimize the total number of containers used
    m.setObjective(gp.quicksum(y[j] for j in containers), GRB.MINIMIZE)

    # --- Constraints ---
    # 1. All goods must be transported
    for g in goods_types:
        m.addConstr(gp.quicksum(x[g, j] for j in containers) == quantities[g], f"demand_{g}")

    for j in containers:
        total_weight = gp.quicksum(weights[g] * x[g, j] for g in goods_types)

        # 2. Link indicator variables with goods presence (Big-M formulation)
        # If x['A', j] > 0, a_in_j[j] must be 1
        m.addConstr(x['A', j] <= quantities['A'] * a_in_j[j], f"a_indicator_link_{j}")
        # If x['E', j] > 0, e_in_j[j] must be 1
        m.addConstr(x['E', j] <= quantities['E'] * e_in_j[j], f"e_indicator_link_{j}")

        # 3. Container capacity constraint (revised)
        # The capacity is reduced if goods E are present.
        # If e_in_j=0, capacity is max_cap. If e_in_j=1, capacity is fragile_cap_e.
        # This is modeled as: weight <= max_cap*y - (max_cap - fragile_cap)*e_in_j
        m.addConstr(total_weight <= max_cap * y[j] - (max_cap - fragile_cap_e) * e_in_j[j], f"max_cap_{j}")

        # 4. Minimum load constraint
        m.addConstr(total_weight >= min_load * y[j], f"min_load_{j}")

        # 5. Minimum D goods per container (if used)
        m.addConstr(x['D', j] >= min_d_per_container * y[j], f"min_D_{j}")

        # 6. If A goods are loaded, at least min_c_per_a C goods must be loaded
        m.addConstr(x['C', j] >= min_c_per_a * a_in_j[j], f"C_if_A_{j}")

    # 7. Symmetry breaking: force used containers to have lower indices
    for j in range(max_containers - 1):
        m.addConstr(y[j] >= y[j+1], f"symmetry_{j}")

    # Solve the model
    m.optimize()

    # Print the final objective value in the required format
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_optimization_problem()
