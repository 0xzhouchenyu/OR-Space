import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_feed_data(filepath):
    """Loads feed composition and cost data from a CSV file."""
    feeds = []
    with open(filepath, 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            feed = {
                'Feed': int(row['Feed']),
                'Protein_g': float(row['Protein_g']),
                'Minerals_g': float(row['Minerals_g']),
                'Vitamins_mg': float(row['Vitamins_mg']),
                'Price_Y_per_kg': float(row['Price_Y_per_kg']),
            }
            feeds.append(feed)
    return feeds

def load_general_parameters(filepath):
    """Loads general nutritional requirements from a CSV file."""
    params = {}
    with open(filepath, 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
    return params

def main():
    """
    Formulates and solves the feed mix optimization problem with a mutual exclusion constraint.
    """
    # Construct paths to data files
    # The script is executed from the root, so paths are relative from there.
    # Using the robust path construction as requested.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    feed_data_path = os.path.join(data_dir, "table_1.csv")
    params_path = os.path.join(data_dir, "general_parameters.csv")

    # Load data from CSV files
    feeds_list = load_feed_data(feed_data_path)
    params = load_general_parameters(params_path)

    # Re-structure data for easier access in the model
    feeds_data = {f['Feed']: f for f in feeds_list}
    feed_ids = list(feeds_data.keys())

    # Create a new Gurobi model
    model = gp.Model("RevisedFeedMix")

    # Suppress solver output
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # Continuous variables for the amount (kg) of each feed
    x = model.addVars(feed_ids, name="x", lb=0.0, vtype=GRB.CONTINUOUS)
    
    # Binary variables to model the choice of using Feed 4 or Feed 5
    y = model.addVars([4, 5], name="y", vtype=GRB.BINARY)

    # --- Objective Function ---
    # Minimize the total cost of the feed mix
    model.setObjective(
        gp.quicksum(feeds_data[i]['Price_Y_per_kg'] * x[i] for i in feed_ids),
        GRB.MINIMIZE
    )

    # --- Constraints ---
    # Nutritional requirements
    model.addConstr(
        gp.quicksum(feeds_data[i]['Protein_g'] * x[i] for i in feed_ids) >= params['min_protein_requirement'],
        "ProteinRequirement"
    )
    model.addConstr(
        gp.quicksum(feeds_data[i]['Minerals_g'] * x[i] for i in feed_ids) >= params['min_minerals_requirement'],
        "MineralsRequirement"
    )
    model.addConstr(
        gp.quicksum(feeds_data[i]['Vitamins_mg'] * x[i] for i in feed_ids) >= params['min_vitamins_requirement'],
        "VitaminsRequirement"
    )

    # Mutual exclusion constraint: cannot use both Feed 4 and Feed 5
    model.addConstr(y[4] + y[5] <= 1, "MutualExclusion")

    # Big-M constraints to link continuous variables (x) with binary variables (y)
    # If a feed is used (x > 0), its corresponding binary must be 1.
    # A safe upper bound M on the amount of any feed can be calculated.
    # E.g., to meet the 700g protein requirement with the least potent feed (Feed 3, 1g/kg),
    # one would need 700kg. A value of 1000 is a safe M.
    M = 1000
    model.addConstr(x[4] <= M * y[4], "BigM_Link_4")
    model.addConstr(x[5] <= M * y[5], "BigM_Link_5")

    # --- Solve the Model ---
    model.optimize()

    # --- Print the Final Result ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # In case of non-optimal solution, still print a value if available
        # or indicate an issue. For this problem, an optimal solution is expected.
        print(f"FINAL_OBJ_VALUE: {model.ObjVal if hasattr(model, 'ObjVal') else 'N/A'}")

if __name__ == "__main__":
    main()
