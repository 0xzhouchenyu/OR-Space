import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            params[name] = val
    return params

# Set up file paths
# The script is assumed to be run from the workspace root.
# Using os.path.join with __file__ makes it robust to execution location.
script_dir = os.path.dirname(os.path.abspath(__file__))
data_file = os.path.join(script_dir, "data", "general_parameters.csv")

# Load all parameters from the data file
params = load_parameters(data_file)

# Extract parameters for the model
min_A = params['min_raw_material_A']
min_B = params['min_raw_material_B']
min_C = params['min_raw_material_C']

cap_A_a = params['warehouse_A_truck_capacity_A']
cap_A_b = params['warehouse_A_truck_capacity_B']
cap_A_c = params['warehouse_A_truck_capacity_C']
cost_A = params['warehouse_A_truck_cost']

cap_B_a = params['warehouse_B_truck_capacity_A']
cap_B_b = params['warehouse_B_truck_capacity_B']
cap_B_c = params['warehouse_B_truck_capacity_C']
cost_B = params['warehouse_B_truck_cost']

# Extract revised parameters
fixed_cost_A = params['warehouse_A_fixed_cost']
fixed_cost_B = params['warehouse_B_fixed_cost']
overflow_threshold = params['warehouse_B_overflow_threshold_trucks']
overflow_cost = params['warehouse_B_overflow_coordination_cost']
reconciliation_fee = params['dual_warehouse_reconciliation_fee']

# Create Gurobi model
m = gp.Model("RevisedFreightCost")
m.setParam('OutputFlag', 0)

# --- Decision Variables ---
# Number of trucks from each warehouse (non-negative integers)
x = m.addVar(vtype=GRB.INTEGER, name="trucks_from_A", lb=0)
y = m.addVar(vtype=GRB.INTEGER, name="trucks_from_B", lb=0)

# Binary variables to model fixed and conditional costs
use_A = m.addVar(vtype=GRB.BINARY, name="use_A")
use_B = m.addVar(vtype=GRB.BINARY, name="use_B")
use_both = m.addVar(vtype=GRB.BINARY, name="use_both")
B_overflow = m.addVar(vtype=GRB.BINARY, name="B_overflow")

# --- Objective Function ---
# Minimize total cost: variable + fixed + conditional
variable_cost = cost_A * x + cost_B * y
fixed_costs = fixed_cost_A * use_A + fixed_cost_B * use_B
conditional_costs = reconciliation_fee * use_both + overflow_cost * B_overflow

m.setObjective(variable_cost + fixed_costs + conditional_costs, GRB.MINIMIZE)

# --- Constraints ---
# 1. Material requirements must be met
m.addConstr(cap_A_a * x + cap_B_a * y >= min_A, "RawMaterialA")
m.addConstr(cap_A_b * x + cap_B_b * y >= min_B, "RawMaterialB")
m.addConstr(cap_A_c * x + cap_B_c * y >= min_C, "RawMaterialC")

# 2. Linking constraints for binary variables
# A "big M" value, a safe upper bound on the number of trucks.
# A value of 500 is more than sufficient for this problem.
M = 500

# Link use_A to x: if x > 0, use_A must be 1.
m.addConstr(x <= M * use_A, "link_x_use_A")

# Link use_B to y: if y > 0, use_B must be 1.
m.addConstr(y <= M * use_B, "link_y_use_B")

# Link use_both to use_A and use_B: use_both = 1 if use_A=1 AND use_B=1.
# Gurobi's general constraint `addGenConstrAnd` is a clean way to model this.
m.addGenConstrAnd(use_both, [use_A, use_B], "link_use_both")

# Link B_overflow to y: if y > threshold, B_overflow must be 1.
# The constraint y - overflow_threshold <= M * B_overflow enforces this.
# If y > overflow_threshold, then y - overflow_threshold is positive, forcing B_overflow to be 1.
# If y <= overflow_threshold, the solver can set B_overflow to 0 to minimize cost.
m.addConstr(y - overflow_threshold <= M * B_overflow, "link_y_overflow")

# --- Solve and Output ---
m.optimize()

if m.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
else:
    # This case should not be reached with the given data but is good practice.
    print("No optimal solution found.")
