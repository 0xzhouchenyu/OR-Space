import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    Solves the revised R&D team hiring optimization problem.
    """
    # Define file paths relative to the script location
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # If __file__ is not defined (e.g., in an interactive environment),
        # use the current working directory.
        base_dir = os.getcwd()
        
    data_dir = os.path.join(base_dir, "data")

    # --- 1. Load Data ---

    # Load general parameters from CSV
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Load candidate data from CSV
    candidates = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Candidate'].strip()
            candidates[name] = {
                'salary': int(row['Salary'].strip()),
                'skill': int(row['Skill_Level'].strip()),
                'pm_exp': int(row['Project_Management_Experience'].strip())
            }
    candidate_names = list(candidates.keys())

    # --- 2. Extract Parameters ---
    budget = params['company_budget']
    max_employees = int(params['max_employees'])
    min_skill = params['min_skill_level']
    min_pm_exp = params['min_project_experience']
    max_gj = int(params['max_one_candidate_g_j'])
    lead_premium = params['lead_premium']
    min_leads = int(params['min_leads'])
    mentor_bonus = params['mentor_bonus']
    max_pairs = int(params['max_pairs'])

    # --- 3. Create Gurobi Model ---
    m = gp.Model("RevisedHiringOptimization")
    m.setParam('OutputFlag', 0)

    # --- 4. Define Decision Variables ---
    # l[c] = 1 if candidate c is hired as a Lead, 0 otherwise
    l = m.addVars(candidate_names, vtype=GRB.BINARY, name="lead")
    # e[c] = 1 if candidate c is hired as an Engineer, 0 otherwise
    e = m.addVars(candidate_names, vtype=GRB.BINARY, name="engineer")
    # p = number of mentorship pairs to be counted for bonus
    p = m.addVar(vtype=GRB.INTEGER, lb=0, ub=max_pairs, name="pairs")

    # Helper expression: hired[c] = 1 if candidate c is hired (in any role)
    hired = {c: l[c] + e[c] for c in candidate_names}

    # --- 5. Define Objective Function ---
    # Minimize the net cost: (base salaries + lead premiums - mentorship bonus)
    base_salaries = gp.quicksum(candidates[c]['salary'] * hired[c] for c in candidate_names)
    total_lead_premiums = gp.quicksum(lead_premium * l[c] for c in candidate_names)
    total_mentor_bonus = mentor_bonus * p
    
    net_cost = base_salaries + total_lead_premiums - total_mentor_bonus
    m.setObjective(net_cost, GRB.MINIMIZE)

    # --- 6. Add Constraints ---

    # Each candidate can be assigned at most one role (i.e., hired at most once)
    m.addConstrs((hired[c] <= 1 for c in candidate_names), name="C_RoleAssignment")

    # Total net cost must not exceed the company budget
    m.addConstr(net_cost <= budget, name="C_Budget")

    # Total number of hired employees cannot exceed the maximum
    m.addConstr(gp.quicksum(hired[c] for c in candidate_names) <= max_employees, name="C_MaxEmployees")

    # Total skill level of the hired team must meet the minimum requirement
    m.addConstr(gp.quicksum(candidates[c]['skill'] * hired[c] for c in candidate_names) >= min_skill, name="C_MinSkill")

    # Total project management experience must meet the minimum requirement
    m.addConstr(gp.quicksum(candidates[c]['pm_exp'] * hired[c] for c in candidate_names) >= min_pm_exp, name="C_MinPMExp")

    # At most one candidate can be hired from the set {G, J}
    m.addConstr(hired['G'] + hired['J'] <= max_gj, name="C_MaxOneGJ")

    # The number of leads must meet the minimum requirement
    num_leads = gp.quicksum(l[c] for c in candidate_names)
    m.addConstr(num_leads >= min_leads, name="C_MinLeads")

    # Constraints for calculating mentorship pairs (p <= num_leads and p <= num_engineers)
    num_engineers = gp.quicksum(e[c] for c in candidate_names)
    m.addConstr(p <= num_leads, name="C_Pairs_Leads")
    m.addConstr(p <= num_engineers, name="C_Pairs_Engineers")
    # The constraint p <= max_pairs is handled by the variable's upper bound

    # --- 7. Solve the Model ---
    m.optimize()

    # --- 8. Print Final Result ---
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        # This part is for robustness in case no solution is found
        print("No optimal solution found or an error occurred.")
        print(f"Model status: {m.status}")

if __name__ == "__main__":
    solve()
