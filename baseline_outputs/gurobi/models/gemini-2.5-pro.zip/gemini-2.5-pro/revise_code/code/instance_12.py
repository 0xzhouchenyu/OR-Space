import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_problem():
    """
    Solves the revised Red Star Plastics Factory optimization problem.
    """
    # --- 1. Data Loading ---
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load container data from table_1.csv
    containers = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            containers.append({
                'code': int(row['Container_Type_Code']),
                'volume': int(row['Volume_cm3']),
                'demand': int(row['Market_Demand_units']),
                'cost': float(row['Unit_Variable_Production_Cost_Yuan_per_unit'])
            })
    
    n = len(containers)
    indices = range(n)

    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    fixed_setup_cost = params['fixed_setup_cost']
    energy_cost_per_kwh = params['energy_cost_per_kwh']
    max_total_energy_kwh = params['max_total_energy_kwh']
    eco_capacity_share = params['eco_capacity_share']
    eco_overhead_cost = params['eco_overhead_cost']
    regular_energy_intensity = params['regular_energy_intensity_kwh_per_unit']
    eco_energy_intensity = params['eco_energy_intensity_kwh_per_unit']

    # --- 2. Model Formulation ---
    model = gp.Model("RevisedPlasticContainers")
    model.setParam('OutputFlag', 0)

    # --- 3. Decision Variables ---
    
    # y_i: Binary, 1 if container type i is produced at all
    y = model.addVars(indices, vtype=GRB.BINARY, name="y")
    
    # z_i: Binary, 1 if container type i is produced in eco mode
    z = model.addVars(indices, vtype=GRB.BINARY, name="z")

    # Define valid substitution pairs (i can substitute for j if volume_i >= volume_j)
    substitutable_pairs = [(i, j) for i in indices for j in indices if containers[i]['volume'] >= containers[j]['volume']]

    # x_reg_ij: Units of type i produced in regular mode for demand j
    x_reg = model.addVars(substitutable_pairs, vtype=GRB.INTEGER, name="x_reg", lb=0)
    
    # x_eco_ij: Units of type i produced in eco mode for demand j
    x_eco = model.addVars(substitutable_pairs, vtype=GRB.INTEGER, name="x_eco", lb=0)

    # --- 4. Objective Function ---
    
    # Variable production costs
    var_prod_cost = gp.quicksum(
        containers[i]['cost'] * (x_reg.get((i, j), 0) + x_eco.get((i, j), 0))
        for i, j in substitutable_pairs
    )

    # Fixed setup costs for producing a container type
    fixed_cost = gp.quicksum(fixed_setup_cost * y[i] for i in indices)

    # Additional overhead for using eco mode for a container type
    eco_overhead = gp.quicksum(eco_overhead_cost * z[i] for i in indices)

    # Total production quantities for energy calculation
    total_reg_prod = gp.quicksum(x_reg.values())
    total_eco_prod = gp.quicksum(x_eco.values())

    # Energy costs
    energy_cost = energy_cost_per_kwh * (
        regular_energy_intensity * total_reg_prod +
        eco_energy_intensity * total_eco_prod
    )

    model.setObjective(var_prod_cost + fixed_cost + eco_overhead + energy_cost, GRB.MINIMIZE)

    # --- 5. Constraints ---

    # Demand fulfillment constraint for each container type j
    model.addConstrs(
        (gp.quicksum(x_reg.get((i, j), 0) + x_eco.get((i, j), 0) for i in indices if (i,j) in substitutable_pairs) >= containers[j]['demand']
        for j in indices), name="Demand"
    )

    # Big-M for linking production to setup variables
    M = sum(c['demand'] for c in containers)

    # Linking total production of type i to setup variable y_i
    model.addConstrs(
        (gp.quicksum(x_reg.get((i, j), 0) + x_eco.get((i, j), 0) for j in indices if (i,j) in substitutable_pairs) <= M * y[i]
        for i in indices), name="SetupLink"
    )

    # Linking eco production of type i to eco setup variable z_i
    model.addConstrs(
        (gp.quicksum(x_eco.get((i, j), 0) for j in indices if (i,j) in substitutable_pairs) <= M * z[i]
        for i in indices), name="EcoSetupLink"
    )

    # Eco capacity share constraint for each container type i
    model.addConstrs(
        (gp.quicksum(x_eco.get((i, j), 0) for j in indices if (i,j) in substitutable_pairs) <= 
         eco_capacity_share * gp.quicksum(x_reg.get((i, j), 0) + x_eco.get((i, j), 0) for j in indices if (i,j) in substitutable_pairs)
        for i in indices), name="EcoShare"
    )

    # Total energy consumption constraint
    total_energy_consumption = (
        regular_energy_intensity * total_reg_prod +
        eco_energy_intensity * total_eco_prod
    )
    model.addConstr(total_energy_consumption <= max_total_energy_kwh, name="MaxEnergy")

    # --- 6. Solve and Output ---
    model.optimize()

    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_revised_problem()
