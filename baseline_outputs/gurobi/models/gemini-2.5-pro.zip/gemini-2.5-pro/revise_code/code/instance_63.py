import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Data Loading ---
# Construct the path to the data file relative to the script location
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
params_file = os.path.join(data_dir, 'general_parameters.csv')

# Load parameters from CSV into a dictionary
params = {}
with open(params_file, 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        try:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
        except (ValueError, TypeError):
            params[row['Parameter_Name'].strip()] = row['Value'].strip()

# Assign parameters to variables for clarity
min_total_produce = params['min_total_produce']
max_total_pollution = params['max_total_pollution']
min_horse_trips = params['min_horse_trips']

horse_capacity_per_trip = params['horse_capacity_per_trip']
bicycle_capacity_per_trip = params['bicycle_capacity_per_trip']
handcart_capacity_per_trip = params['handcart_capacity_per_trip']

horse_pollution_per_trip = params['horse_pollution_per_trip']
# Bicycle and handcart pollution are 0, so not needed in calculations

horse_cost_per_trip = params['horse_cost_per_trip']
bicycle_cost_per_trip = params['bicycle_cost_per_trip']
handcart_cost_per_trip = params['handcart_cost_per_trip']

horse_fixed_cost = params['horse_fixed_cost']
bicycle_fixed_cost = params['bicycle_fixed_cost']
handcart_fixed_cost = params['handcart_fixed_cost']

pollution_penalty_per_unit = params['pollution_penalty_per_unit']
horse_pollution_permit_threshold = params['horse_pollution_permit_threshold']
horse_pollution_permit_fee = params['horse_pollution_permit_fee']

# --- Model ---
# Initialize the Gurobi model
model = gp.Model("RevisedFarmTransport")

# --- Decision Variables ---
# Number of trips for each transport method (Integer)
x_horse = model.addVar(vtype=GRB.INTEGER, name="horse_trips", lb=0)
x_bike = model.addVar(vtype=GRB.INTEGER, name="bike_trips", lb=0)
x_cart = model.addVar(vtype=GRB.INTEGER, name="cart_trips", lb=0)

# Binary variables to indicate if a transport method is used (for fixed costs)
# Since min_horse_trips > 0, horse is always used. Its fixed cost is a constant.
z_bike = model.addVar(vtype=GRB.BINARY, name="use_bike")
z_cart = model.addVar(vtype=GRB.BINARY, name="use_cart")

# Binary variable to indicate if the pollution permit fee is incurred
p_exceed = model.addVar(vtype=GRB.BINARY, name="exceed_pollution_permit")

# --- Expressions for Objective and Constraints ---
# Total produce transported
total_produce = (horse_capacity_per_trip * x_horse +
                 bicycle_capacity_per_trip * x_bike +
                 handcart_capacity_per_trip * x_cart)

# Total pollution generated (only from horse)
total_pollution = horse_pollution_per_trip * x_horse

# Total cost components
variable_cost = (horse_cost_per_trip * x_horse +
                 bicycle_cost_per_trip * x_bike +
                 handcart_cost_per_trip * x_cart)

fixed_cost = (horse_fixed_cost +  # Horse is always used
              bicycle_fixed_cost * z_bike +
              handcart_fixed_cost * z_cart)

pollution_penalty_cost = pollution_penalty_per_unit * total_pollution

permit_fee_cost = horse_pollution_permit_fee * p_exceed

# --- Objective Function ---
# Minimize the total cost
model.setObjective(
    variable_cost + fixed_cost + pollution_penalty_cost + permit_fee_cost,
    GRB.MINIMIZE
)

# --- Constraints ---
# 1. Must transport at least the minimum required produce
model.addConstr(total_produce >= min_total_produce, "C1_MinProduce")

# 2. Total pollution must not exceed the maximum allowed
model.addConstr(total_pollution <= max_total_pollution, "C2_MaxPollution")

# 3. Minimum number of horse trips
model.addConstr(x_horse >= min_horse_trips, "C3_MinHorseTrips")

# 4. Choose only one of bicycle or handcart
model.addConstr(z_bike + z_cart <= 1, "C4_ExclusiveChoice")

# 5. Link trip variables to usage binaries (for fixed costs) using a Big-M
# A safe Big-M can be calculated as ceil(total_produce / min_capacity)
M = 1000 # A sufficiently large number
model.addConstr(x_bike <= M * z_bike, "C5a_LinkBike")
model.addConstr(x_cart <= M * z_cart, "C5b_LinkCart")

# 6. Link pollution level to the permit fee binary variable (p_exceed)
# If total_pollution > threshold, then p_exceed must be 1.
# total_pollution - threshold <= M_poll * p_exceed
# A tight Big-M for this constraint is (max_total_pollution - threshold)
M_poll = max_total_pollution - horse_pollution_permit_threshold
model.addConstr(total_pollution - horse_pollution_permit_threshold <= M_poll * p_exceed, "C6_PermitFee")

# --- Solve ---
# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# Optimize the model
model.optimize()

# --- Output ---
# Print the final objective value in the required format
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("No optimal solution found.")
