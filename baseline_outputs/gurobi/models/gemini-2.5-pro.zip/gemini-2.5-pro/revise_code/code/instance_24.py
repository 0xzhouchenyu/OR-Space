import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_problem():
    """
    Solves the revised transportation optimization problem using Gurobi.
    """
    # --- 1. Load Data and Define Sets ---
    
    # Construct the path to the data file relative to the script's location
    try:
        data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    except NameError:
        # Handle case where __file__ is not defined (e.g., in an interactive session)
        data_dir = "data"

    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Define model sets
    vehicles = ['truck', 'van', 'motorcycle', 'electric_vehicle']
    sales_points = ['sp1', 'sp2', 'sp3']
    days = [1, 2, 3]

    # --- 2. Prepare Parameters ---

    # Map internal vehicle names to CSV parameter name fragments
    vehicle_param_map = {
        'truck': 'truck',
        'van': 'van',
        'motorcycle': 'motorcycle',
        'electric_vehicle': 'electric_vehicle'
    }
    
    # Map internal vehicle names to Big-M parameter name fragments
    big_m_param_map = {
        'truck': 'truck',
        'van': 'van',
        'motorcycle': 'moto',
        'electric_vehicle': 'ev'
    }

    pollution = {v: params[f"{vehicle_param_map[v]}_pollution"] for v in vehicles}
    capacity = {v: params[f"{vehicle_param_map[v]}_capacity"] for v in vehicles}
    
    demand = {
        sp: params['product_units'] * params[f"sales_point_share_{sp}"]
        for sp in sales_points
    }
    
    min_truck_share = {
        sp: params[f"min_truck_share_{sp}"] for sp in sales_points
    }
    
    big_M = {
        v: params[f"M_{big_m_param_map[v]}_sp_day"] for v in vehicles
    }

    max_total_pollution = params['max_total_pollution']
    min_total_truck_trips = params['min_truck_trips']

    # --- 3. Create Gurobi Model ---
    
    model = gp.Model("RevisedTransportationOptimization")
    model.setParam('OutputFlag', 0)

    # --- 4. Define Decision Variables ---

    # Number of trips for each vehicle, to each sales point, on each day
    trips = model.addVars(vehicles, sales_points, days, vtype=GRB.INTEGER, name="trips", lb=0)

    # Binary variable to model the "gate" or "family" constraint
    # 1 if {truck, EV} family is used, 0 if {van, motorcycle} family is used
    use_truck_ev_family = model.addVars(sales_points, days, vtype=GRB.BINARY, name="use_truck_ev_family")

    # --- 5. Set Objective Function ---
    
    # Minimize total pollution
    total_pollution_expr = gp.quicksum(
        trips[v, s, d] * pollution[v] for v in vehicles for s in sales_points for d in days
    )
    model.setObjective(total_pollution_expr, GRB.MINIMIZE)

    # --- 6. Add Constraints ---

    # Constraint 1: Demand fulfillment for each sales point
    model.addConstrs(
        (gp.quicksum(trips[v, s, d] * capacity[v] for v in vehicles for d in days) >= demand[s]
         for s in sales_points),
        name="DemandFulfillment"
    )

    # Constraint 2: Maximum total pollution
    model.addConstr(total_pollution_expr <= max_total_pollution, name="MaxTotalPollution")

    # Constraint 3: Minimum total truck trips across all operations
    model.addConstr(
        gp.quicksum(trips['truck', s, d] for s in sales_points for d in days) >= min_total_truck_trips,
        name="MinTotalTruckTrips"
    )

    # Constraint 4: Minimum truck share of trips for each sales point
    model.addConstrs(
        (gp.quicksum(trips['truck', s, d] for d in days) >=
         min_truck_share[s] * gp.quicksum(trips[v, s, d] for v in vehicles for d in days)
         for s in sales_points),
        name="MinTruckShare"
    )

    # Constraint 5: Mutually exclusive vehicle families (the "gate")
    # For each (sales_point, day), use either {truck, EV} or {van, motorcycle}
    for s in sales_points:
        for d in days:
            # If use_truck_ev_family is 1, only truck and EV trips are allowed
            model.addConstr(trips['truck', s, d] <= big_M['truck'] * use_truck_ev_family[s, d], name=f"Gate_Truck_{s}_{d}")
            model.addConstr(trips['electric_vehicle', s, d] <= big_M['electric_vehicle'] * use_truck_ev_family[s, d], name=f"Gate_EV_{s}_{d}")
            
            # If use_truck_ev_family is 0, only van and motorcycle trips are allowed
            model.addConstr(trips['van', s, d] <= big_M['van'] * (1 - use_truck_ev_family[s, d]), name=f"Gate_Van_{s}_{d}")
            model.addConstr(trips['motorcycle', s, d] <= big_M['motorcycle'] * (1 - use_truck_ev_family[s, d]), name=f"Gate_Motorcycle_{s}_{d}")

    # --- 7. Solve the Model ---
    
    model.optimize()

    # --- 8. Print Final Result ---
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")
        print(f"Model status: {model.status}")

if __name__ == "__main__":
    solve_revised_problem()
