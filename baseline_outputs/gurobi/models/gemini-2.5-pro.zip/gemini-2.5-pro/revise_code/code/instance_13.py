import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    """
    Solves the revised farm optimization problem for Tom and Jerry.
    """
    # --- Data Loading ---
    # The script is executed from the workspace root, so the data path is relative from there.
    # Using a robust path construction method as requested.
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        data_file_path = os.path.join(script_dir, "data", "general_parameters.csv")

        params = {}
        with open(data_file_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                params[row['Parameter_Name'].strip()] = float(row['Value'].strip())
    except FileNotFoundError:
        print("Error: Data file 'data/general_parameters.csv' not found.")
        print("Please ensure the script is run from the workspace root directory.")
        return

    profit_corn = params['profit_per_acre_corn']
    profit_wheat = params['profit_per_acre_wheat']
    profit_soybeans = params['profit_per_acre_soybeans']
    profit_sorghum = params['profit_per_acre_sorghum']
    total_area = params['total_farm_area']
    corn_wheat_ratio = params['corn_wheat_ratio']
    soybeans_sorghum_ratio = params['soybeans_sorghum_ratio']
    wheat_sorghum_ratio = params['wheat_sorghum_ratio']
    
    # New parameter from the business requirement revision
    min_corn_if_planted = 20.0

    # --- Model Setup ---
    m = gp.Model("Farm_Optimization_Revised")
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # Continuous variables for acres of each crop
    corn = m.addVar(name="corn", lb=0)
    wheat = m.addVar(name="wheat", lb=0)
    soybeans = m.addVar(name="soybeans", lb=0)
    sorghum = m.addVar(name="sorghum", lb=0)
    
    # Binary variable to model the mutual exclusion between corn and soybeans
    # y_corn = 1 if we choose to plant corn, 0 if we choose to plant soybeans
    y_corn = m.addVar(vtype=GRB.BINARY, name="plant_corn_choice")

    # --- Objective Function ---
    # Maximize total profit
    m.setObjective(
        profit_corn * corn + profit_wheat * wheat + profit_soybeans * soybeans + profit_sorghum * sorghum,
        GRB.MAXIMIZE
    )

    # --- Constraints ---
    # 1. Total farm area cannot be exceeded
    m.addConstr(corn + wheat + soybeans + sorghum <= total_area, "total_area")

    # 2. Original crop ratio constraints
    m.addConstr(corn >= corn_wheat_ratio * wheat, "corn_wheat_ratio")
    m.addConstr(soybeans >= soybeans_sorghum_ratio * sorghum, "soybeans_sorghum_ratio")
    m.addConstr(wheat == wheat_sorghum_ratio * sorghum, "wheat_sorghum_ratio")

    # 3. Revised constraints using a Big-M formulation
    # M can be set to total_area, as no single crop can occupy more than the total available land.
    M = total_area
    
    # 3a. If we choose to plant corn (y_corn=1), then soybeans cannot be planted.
    #     If we choose to plant soybeans (y_corn=0), then corn cannot be planted.
    m.addConstr(corn <= M * y_corn, "corn_if_chosen")
    m.addConstr(soybeans <= M * (1 - y_corn), "soybeans_if_chosen")
    
    # 3b. If we choose to plant corn (y_corn=1), we must plant at least 20 acres.
    #     If y_corn=0, this constraint becomes corn >= 0, which is already true.
    m.addConstr(corn >= min_corn_if_planted * y_corn, "min_corn_if_chosen")

    # --- Solve and Output ---
    m.optimize()

    if m.status == GRB.OPTIMAL:
        obj_val = m.ObjVal
        print(f"FINAL_OBJ_VALUE: {obj_val}")
    else:
        # This part is for robustness, in case no optimal solution is found.
        print("Optimization did not find an optimal solution.")
        print(f"Gurobi status code: {m.status}")

if __name__ == "__main__":
    main()
