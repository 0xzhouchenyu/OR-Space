import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    """
    Main function to set up and solve the revised Zhang family trip optimization problem.
    """
    # --- Load Data ---
    # Construct paths based on the script's location, assuming it's in the root directory.
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Fallback for environments where __file__ is not defined (e.g., interactive)
        base_dir = os.getcwd()

    data_dir = os.path.join(base_dir, "data")
    general_params_path = os.path.join(data_dir, 'general_parameters.csv')
    costs_path = os.path.join(data_dir, 'table_1.csv')

    # Read general parameters from general_parameters.csv
    params = {}
    with open(general_params_path, 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Only read non-cost parameters from this file, as costs are structured in table_1.csv
            if 'cost' not in row['Parameter_Name']:
                try:
                    value = float(row['Value'])
                    if value.is_integer():
                        value = int(value)
                    params[row['Parameter_Name']] = value
                except (ValueError, TypeError):
                    params[row['Parameter_Name']] = row['Value']

    max_children = params['max_children']
    min_children = params['min_children']
    fairness_penalty = params['fairness_penalty']
    max_total_cost = params['max_total_cost']
    min_children_per_mode = params['min_children_per_mode']

    # Read mode-dependent costs from table_1.csv
    costs = {}
    children = []
    modes = []
    max_cost_val = 0
    with open(costs_path, 'r', newline='') as f:
        reader = csv.DictReader(f)
        cost_fields = [field for field in reader.fieldnames if field.lower().startswith('cost_')]
        modes = [field.replace('Cost_', '').lower() for field in cost_fields]
        
        for row in reader:
            child_name = row['Child'].strip()
            children.append(child_name)
            costs[child_name] = {}
            for i, mode in enumerate(modes):
                cost_val = float(row[cost_fields[i]].strip())
                costs[child_name][mode] = cost_val
                if cost_val > max_cost_val:
                    max_cost_val = cost_val

    # --- Model Setup ---
    model = gp.Model("ZhangFamilyTripRevised")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # x[c]: 1 if child c is taken, 0 otherwise
    x = model.addVars(children, vtype=GRB.BINARY, name="x")
    
    # y[m]: 1 if mode m is chosen, 0 otherwise
    y = model.addVars(modes, vtype=GRB.BINARY, name="y")
    
    # z[c,m]: auxiliary variable for the product x[c] * y[m]
    z = model.addVars(children, modes, vtype=GRB.BINARY, name="z")

    # Variables for fairness calculation
    MaxCost = model.addVar(name="MaxCost", lb=0)
    MinCost = model.addVar(name="MinCost", lb=0)

    # --- Constraints ---

    # 1. Original problem constraints on children
    model.addConstr(x['Ginny'] == 1, "Ginny_must_go")
    model.addConstr(gp.quicksum(x[c] for c in children) <= max_children, "Max_children")
    model.addConstr(x['Harry'] + x['Fred'] <= 1, "Harry_no_Fred")
    model.addConstr(x['Harry'] + x['George'] <= 1, "Harry_no_George")
    model.addConstr(x['George'] <= x['Fred'], "George_requires_Fred")
    model.addConstr(x['George'] <= x['Hermione'], "George_requires_Hermione")

    # 2. Mode selection: exactly one mode must be chosen
    model.addConstr(gp.quicksum(y[m] for m in modes) == 1, "One_mode_only")

    # 3. Mode-dependent minimum children constraint
    min_children_expr = min_children * y['budget'] + \
                        min_children_per_mode * y['balanced'] + \
                        min_children_per_mode * y['premium']
    model.addConstr(gp.quicksum(x[c] for c in children) >= min_children_expr, "Min_children_mode_dependent")

    # 4. Linearization of z[c,m] = x[c] * y[m]
    for c in children:
        for m in modes:
            model.addConstr(z[c, m] <= x[c], f"z_lin1_{c}_{m}")
            model.addConstr(z[c, m] <= y[m], f"z_lin2_{c}_{m}")
            model.addConstr(z[c, m] >= x[c] + y[m] - 1, f"z_lin3_{c}_{m}")

    # 5. Total spend calculation and constraint
    TotalSpend = gp.quicksum(costs[c][m] * z[c, m] for c in children for m in modes)
    model.addConstr(TotalSpend <= max_total_cost, "Max_total_cost_cap")

    # 6. Fairness cost constraints (Big-M formulation)
    M = max_cost_val + 1 

    for c in children:
        effective_child_cost = gp.quicksum(costs[c][m] * y[m] for m in modes)
        
        # If x[c]=1, then MaxCost >= effective_child_cost
        model.addConstr(MaxCost >= effective_child_cost - M * (1 - x[c]), f"MaxCost_constr_{c}")

        # If x[c]=1, then MinCost <= effective_child_cost
        model.addConstr(MinCost <= effective_child_cost + M * (1 - x[c]), f"MinCost_constr_{c}")

    # --- Objective Function ---
    FairnessSpread = MaxCost - MinCost
    Objective = TotalSpend + fairness_penalty * FairnessSpread
    model.setObjective(Objective, GRB.MINIMIZE)

    # --- Solve and Output ---
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # This case should not be reached for this problem but is good practice.
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
