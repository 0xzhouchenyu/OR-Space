import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    """
    Solves the revised restaurant table ordering problem.
    """
    # --- 1. Data Loading ---
    # The script is expected to be run from the workspace root.
    # The path to data files is relative to the root.
    data_dir = "data"
    params_path = os.path.join(data_dir, 'general_parameters.csv')

    # Fallback for cases where the script might be in a 'src' directory
    # as hinted by the original heuristic's structure.
    if not os.path.exists(params_path):
        try:
            # This path works if the script is in 'src' and data is in 'data' at the same level as 'src'
            alt_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'general_parameters.csv')
            if os.path.exists(alt_path):
                params_path = alt_path
            else:
                raise FileNotFoundError("Cannot locate general_parameters.csv")
        except NameError:
             # __file__ is not defined in some environments
             raise FileNotFoundError("Cannot determine script path to find data files.")

    params = {}
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Extract parameters from the dictionary
    cost_a = params['cost_supplier_a']
    cost_b = params['cost_supplier_b']
    cost_c = params['cost_supplier_c']
    size_a = int(params['order_size_supplier_a'])
    size_b = int(params['order_size_supplier_b'])
    size_c = int(params['order_size_supplier_c'])
    min_tables = int(params['min_tables_required'])
    max_tables = int(params['max_tables_allowed'])
    min_b_if_a = int(params['min_tables_supplier_b_if_a'])
    b_requires_c = int(params['supplier_b_requires_c'])
    
    # Revised parameters from the new data file
    max_free_c = int(params['max_free_orders_c'])
    penalty_c = params['penalty_per_extra_order_c']
    bc_shared_fee = params['supplier_bc_shared_inbound_fee']
    bc_shared_trigger = int(params['supplier_bc_shared_inbound_trigger'])

    # --- 2. Model Initialization ---
    m = gp.Model("RevisedRestaurantTables")
    m.setParam('OutputFlag', 0)

    # --- 3. Decision Variables ---
    # Number of orders from each supplier (integer)
    x_a = m.addVar(vtype=GRB.INTEGER, name="orders_a", lb=0)
    x_b = m.addVar(vtype=GRB.INTEGER, name="orders_b", lb=0)
    x_c = m.addVar(vtype=GRB.INTEGER, name="orders_c", lb=0)

    # Binary variables indicating if a supplier is used
    y_a = m.addVar(vtype=GRB.BINARY, name="use_a")
    y_b = m.addVar(vtype=GRB.BINARY, name="use_b")
    y_c = m.addVar(vtype=GRB.BINARY, name="use_c")

    # Variable for extra orders from supplier C (for penalty)
    x_c_extra = m.addVar(vtype=GRB.INTEGER, name="extra_c_orders", lb=0)

    # Binary variable for the shared B-C inbound fee
    z_bc = m.addVar(vtype=GRB.BINARY, name="use_b_and_c")

    # --- 4. Objective Function ---
    # Total cost is the sum of table costs, penalty costs, and fixed fees
    total_cost = (
        cost_a * size_a * x_a +
        cost_b * size_b * x_b +
        cost_c * size_c * x_c +
        penalty_c * x_c_extra +
        bc_shared_fee * z_bc
    )
    m.setObjective(total_cost, GRB.MINIMIZE)

    # --- 5. Constraints ---
    # Total tables constraints
    total_tables = size_a * x_a + size_b * x_b + size_c * x_c
    m.addConstr(total_tables >= min_tables, "min_total_tables")
    m.addConstr(total_tables <= max_tables, "max_total_tables")

    # Link integer order variables (x) to binary usage variables (y)
    # Using Gurobi's general constraints for indicator variables is best practice
    m.addGenConstrIndicator(y_a, True, x_a >= 1, "ind_a_true")
    m.addGenConstrIndicator(y_a, False, x_a == 0, "ind_a_false")
    m.addGenConstrIndicator(y_b, True, x_b >= 1, "ind_b_true")
    m.addGenConstrIndicator(y_b, False, x_b == 0, "ind_b_false")
    m.addGenConstrIndicator(y_c, True, x_c >= 1, "ind_c_true")
    m.addGenConstrIndicator(y_c, False, x_c == 0, "ind_c_false")

    # If ordering from A, then tables from B >= min_b_if_a
    m.addConstr(size_b * x_b >= min_b_if_a * y_a, "if_a_then_b")

    # If ordering from B, must order from C
    if b_requires_c:
        m.addConstr(y_c >= y_b, "if_b_then_c")

    # Supplier C penalty for orders beyond the free limit
    # x_c_extra must be at least the number of orders over the max free limit
    m.addConstr(x_c_extra >= x_c - max_free_c, "c_penalty_calc")

    # Shared inbound fee for using both B and C
    if bc_shared_trigger:
        # z_bc = 1 if and only if y_b = 1 AND y_c = 1
        m.addGenConstrAnd(z_bc, [y_b, y_c], "b_and_c_used")

    # --- 6. Solve and Output ---
    m.optimize()

    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print(f"Optimization ended with status {m.status}")

if __name__ == "__main__":
    main()
