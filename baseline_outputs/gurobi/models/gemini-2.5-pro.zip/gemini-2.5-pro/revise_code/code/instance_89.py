import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- Main Script ---

# 1. Load and organize parameters
try:
    # This path works when the script is run from the project root directory.
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = load_general_parameters(data_path)

    # Organize parameters for easier access
    products = ['A', 'B']
    weeks = [1, 2]

    profit = {
        'A': params['profit_per_kg_product_A'],
        'B': params['profit_per_kg_product_B']
    }
    max_hours = {
        1: params['max_production_hours_week_1'],
        2: params['max_production_hours_week_2']
    }
    hours_per_kg = {
        'A': params['hours_per_kg_product_A'],
        'B': params['hours_per_kg_product_B']
    }
    min_ratio_B_to_A = params['min_output_ratio_product_B_to_A']
    storage_ratio_A_to_B = params['storage_space_ratio_product_A_to_B']
    max_storage_A_equiv = {
        1: params['max_storage_product_A_equiv_week_1'],
        2: params['max_storage_product_A_equiv_week_2']
    }
    initial_inventory = {
        'A': params['initial_inventory_A'],
        'B': params['initial_inventory_B']
    }
    storage_cost = {
        'A': params['storage_cost_per_kg_A'],
        'B': params['storage_cost_per_kg_B']
    }
    promo_bonus = {
        'A': params['promo_profit_bonus_A'],
        'B': params['promo_profit_bonus_B']
    }
    max_promotions = {
        'A': params['max_promotions_product_A'],
        'B': params['max_promotions_product_B']
    }

    # 2. Create Gurobi Model
    m = gp.Model("revised_liquid_products")

    # 3. Define Decision Variables
    # Continuous variables
    produce = m.addVars(products, weeks, name="produce", lb=0)
    sell = m.addVars(products, weeks, name="sell", lb=0)
    inventory = m.addVars(products, weeks, name="inventory", lb=0)
    
    # Binary variables for promotions
    promote = m.addVars(products, weeks, name="promote", vtype=GRB.BINARY)

    # Variables for linearization of objective function
    # promo_sell[p, t] = sell[p, t] * promote[p, t]
    promo_sell = m.addVars(products, weeks, name="promo_sell", lb=0)

    # 4. Set Objective Function
    # Profit = (Revenue from sales + promotion bonus) - Inventory holding costs
    total_revenue = gp.quicksum(sell[p, t] * profit[p] for p in products for t in weeks)
    total_promo_bonus = gp.quicksum(promo_sell[p, t] * promo_bonus[p] for p in products for t in weeks)
    total_holding_cost = gp.quicksum(inventory[p, 1] * storage_cost[p] for p in products)

    m.setObjective(total_revenue + total_promo_bonus - total_holding_cost, GRB.MAXIMIZE)

    # 5. Add Constraints
    # Inventory Balance Constraints
    for p in products:
        # Week 1
        m.addConstr(inventory[p, 1] == initial_inventory[p] + produce[p, 1] - sell[p, 1], f"inv_balance_{p}_w1")
        # Week 2
        m.addConstr(inventory[p, 2] == inventory[p, 1] + produce[p, 2] - sell[p, 2], f"inv_balance_{p}_w2")

    # Production Time Constraints
    for t in weeks:
        m.addConstr(gp.quicksum(produce[p, t] * hours_per_kg[p] for p in products) <= max_hours[t], f"prod_hours_w{t}")

    # Market Demand (Sales Ratio) Constraints
    for t in weeks:
        m.addConstr(sell['B', t] >= min_ratio_B_to_A * sell['A', t], f"market_demand_w{t}")

    # Storage Capacity Constraints
    for t in weeks:
        # Total storage capacity in space units
        total_storage_units = max_storage_A_equiv[t] * storage_ratio_A_to_B
        # Space used by inventory at the end of the week
        space_used = inventory['A', t] * storage_ratio_A_to_B + inventory['B', t]
        m.addConstr(space_used <= total_storage_units, f"storage_cap_w{t}")

    # Promotion Limit Constraints
    for p in products:
        m.addConstr(gp.quicksum(promote[p, t] for t in weeks) <= max_promotions[p], f"promo_limit_{p}")

    # Linearization Constraints for promo_sell
    # A safe upper bound (Big M) for weekly sales of any product.
    # Max possible production of any product is 40/3 ~ 13.3. Max inventory is 16.
    # Max sale is roughly 13.3 + 16 = 29.3. M=100 is a safe, simple choice.
    M = 100 
    for p in products:
        for t in weeks:
            m.addConstr(promo_sell[p, t] <= M * promote[p, t], f"lin1_{p}_w{t}")
            m.addConstr(promo_sell[p, t] <= sell[p, t], f"lin2_{p}_w{t}")
            m.addConstr(promo_sell[p, t] >= sell[p, t] - M * (1 - promote[p, t]), f"lin3_{p}_w{t}")

    # 6. Solve the Model
    m.setParam('OutputFlag', 0)
    m.optimize()

    # 7. Print the final objective value
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal:.3f}")
    else:
        # Handle cases where no optimal solution is found
        print("No optimal solution found.")
        print(f"Model status: {m.status}")

except FileNotFoundError:
    # This error handling is for robustness, in case the script is run from a wrong location
    # or the data file is missing.
    print(f"Error: Data file not found. Please ensure the script is run from the workspace root.")
except Exception as e:
    print(f"An error occurred: {e}")
