import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            # Try to convert to numeric
            try:
                value = int(value_str)
            except ValueError:
                try:
                    value = float(value_str)
                except ValueError:
                    value = value_str
            params[name] = value
    return params

# Construct the path to the data file relative to the script's location
# This assumes the script is run from the workspace root, and data is in a 'data' subdirectory.
try:
    script_dir = os.path.dirname(os.path.abspath(__file__))
except NameError:
    script_dir = os.getcwd()
data_path = os.path.join(script_dir, "data", "general_parameters.csv")

# Load parameters from the CSV file
params = load_general_parameters(data_path)

# Extract parameters into variables for easier access
cost_A = params['cost_per_chair_A']
cost_B = params['cost_per_chair_B']
cost_C = params['cost_per_chair_C']
chairs_per_order_A = params['chairs_per_order_A']
chairs_per_order_B = params['chairs_per_order_B']
chairs_per_order_C = params['chairs_per_order_C']
min_total_chairs = params['min_total_chairs']
max_total_chairs = params['max_total_chairs']
min_chairs_B_if_A = params['min_chairs_B_if_A']

# New parameters from the revision
fixed_fee_A_regular = params['fixed_fee_A_regular']
fixed_fee_A_express = params['fixed_fee_A_express']
fixed_fee_B_regular = params['fixed_fee_B_regular']
fixed_fee_B_express = params['fixed_fee_B_express']
fixed_fee_C_regular = params['fixed_fee_C_regular']
fixed_fee_C_express = params['fixed_fee_C_express']
weekly_order_budget = params['weekly_order_budget']

# Create Gurobi model
m = gp.Model("RevisedFurnitureOrder")

# Suppress Gurobi output
m.setParam('OutputFlag', 0)

# --- Decision Variables ---

# Number of orders from each manufacturer (integer, non-negative)
orders_A = m.addVar(vtype=GRB.INTEGER, name="orders_A", lb=0)
orders_B = m.addVar(vtype=GRB.INTEGER, name="orders_B", lb=0)
orders_C = m.addVar(vtype=GRB.INTEGER, name="orders_C", lb=0)

# Binary variables for channel selection (regular or express) for each manufacturer
z_A_reg = m.addVar(vtype=GRB.BINARY, name="z_A_reg")
z_A_exp = m.addVar(vtype=GRB.BINARY, name="z_A_exp")
z_B_reg = m.addVar(vtype=GRB.BINARY, name="z_B_reg")
z_B_exp = m.addVar(vtype=GRB.BINARY, name="z_B_exp")
z_C_reg = m.addVar(vtype=GRB.BINARY, name="z_C_reg")
z_C_exp = m.addVar(vtype=GRB.BINARY, name="z_C_exp")

# Helper binary variables to indicate if a manufacturer is used at all
y_A = m.addVar(vtype=GRB.BINARY, name="y_A")
y_B = m.addVar(vtype=GRB.BINARY, name="y_B")
y_C = m.addVar(vtype=GRB.BINARY, name="y_C")

# --- Objective Function ---

# Calculate total chairs from each manufacturer
chairs_A = chairs_per_order_A * orders_A
chairs_B = chairs_per_order_B * orders_B
chairs_C = chairs_per_order_C * orders_C

# Variable cost based on the number of chairs ordered
variable_cost = (cost_A * chairs_A +
                 cost_B * chairs_B +
                 cost_C * chairs_C)

# Fixed cost based on the selected channels
fixed_cost = (fixed_fee_A_regular * z_A_reg + fixed_fee_A_express * z_A_exp +
              fixed_fee_B_regular * z_B_reg + fixed_fee_B_express * z_B_exp +
              fixed_fee_C_regular * z_C_reg + fixed_fee_C_express * z_C_exp)

# Set the objective to minimize the sum of variable and fixed costs
m.setObjective(variable_cost + fixed_cost, GRB.MINIMIZE)

# --- Constraints ---

# 1. Link manufacturer usage (y) to channel selection (z).
# A manufacturer is used if either its regular or express channel is selected.
# This also enforces that at most one channel can be chosen per manufacturer.
m.addConstr(y_A == z_A_reg + z_A_exp, "link_y_A_to_z")
m.addConstr(y_B == z_B_reg + z_B_exp, "link_y_B_to_z")
m.addConstr(y_C == z_C_reg + z_C_exp, "link_y_C_to_z")

# 2. Total chairs must be within the specified min and max bounds.
total_chairs = chairs_A + chairs_B + chairs_C
m.addConstr(total_chairs >= min_total_chairs, "MinTotalChairs")
m.addConstr(total_chairs <= max_total_chairs, "MaxTotalChairs")

# 3. Link order quantities to manufacturer usage (y variables) using Big-M.
# If a manufacturer is not used (y=0), its order quantity must be 0.
# If used (y=1), its order quantity must be at least 1.
max_orders_A = max_total_chairs / chairs_per_order_A
max_orders_B = max_total_chairs / chairs_per_order_B
max_orders_C = max_total_chairs / chairs_per_order_C

m.addConstr(orders_A <= max_orders_A * y_A, "link_orders_A_upper")
m.addConstr(orders_A >= y_A, "link_orders_A_lower")

m.addConstr(orders_B <= max_orders_B * y_B, "link_orders_B_upper")
m.addConstr(orders_B >= y_B, "link_orders_B_lower")

m.addConstr(orders_C <= max_orders_C * y_C, "link_orders_C_upper")
m.addConstr(orders_C >= y_C, "link_orders_C_lower")

# 4. Dependency: if ordering from A, must order at least min_chairs_B_if_A from B.
m.addConstr(chairs_B >= min_chairs_B_if_A * y_A, "Dependency_A_B")

# 5. Dependency: if ordering from B, must also order from C.
m.addConstr(y_B <= y_C, "Dependency_B_C")

# 6. REVISED: Weekly order budget constraint.
# The total number of active manufacturer-mode combinations is limited.
active_combinations = z_A_reg + z_A_exp + z_B_reg + z_B_exp + z_C_reg + z_C_exp
m.addConstr(active_combinations <= weekly_order_budget, "WeeklyBudget")

# --- Solve and Output ---

# Solve the model
m.optimize()

# Print the final objective value in the specified format
if m.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
else:
    print(f"Optimization ended with status {m.status}")
