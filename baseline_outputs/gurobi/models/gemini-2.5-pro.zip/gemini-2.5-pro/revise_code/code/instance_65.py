import os
import csv
import gurobipy as gp
from gurobipy import GRB

# This script is designed to be run from the workspace root directory.
# It constructs file paths relative to its own location.
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, 'data')

# --- Data Loading ---

# Load general parameters from CSV into a dictionary
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), mode='r', encoding='utf-8') as infile:
    reader = csv.DictReader(infile)
    for row in reader:
        params[row['Parameter_Name'].strip()] = float(row['Value'])

# Load product-specific data from CSV into a dictionary of dictionaries
products = {}
with open(os.path.join(data_dir, 'table_1.csv'), mode='r', encoding='utf-8') as infile:
    reader = csv.DictReader(infile)
    for row in reader:
        products[row['Product'].strip()] = {
            'a_hrs': float(row['Workshop_A_Hours']),
            'b_hrs': float(row['Workshop_B_Hours']),
            'insp_cost': float(row['Inspection_Sales_Cost'])
        }

# --- Model Formulation ---

# Create a new Gurobi model
model = gp.Model("revised_production_plan")

# Suppress solver output
model.setParam('OutputFlag', 0)

# --- Define Constants and Variables ---

# Convenience references to product data
m_prod_data = products['Microwave_Oven']
w_prod_data = products['Water_Heater']

# Decision Variables: Number of units to produce for each product.
# Lower bounds are set by the minimum sales requirements.
x_m = model.addVar(name="microwave", lb=params['microwave_minimum_sales'])
x_w = model.addVar(name="water_heater", lb=params['water_heater_minimum_sales'])

# --- Objective Function ---

# The objective is to minimize the total net cost.
# Total Net Cost = (Production Costs + Inspection Costs) - Green Bonuses
# Production costs include variable costs per unit and fixed setup costs.

# Per-unit net cost (cost - bonus) for microwaves
cost_per_m = (m_prod_data['a_hrs'] * params['workshop_a_hourly_cost'] +
              m_prod_data['b_hrs'] * params['workshop_b_hourly_cost'] +
              m_prod_data['insp_cost'] -
              params['green_bonus_m'])

# Per-unit net cost (cost - bonus) for water heaters
cost_per_w = (w_prod_data['a_hrs'] * params['workshop_a_hourly_cost'] +
              w_prod_data['b_hrs'] * params['workshop_b_hourly_cost'] +
              w_prod_data['insp_cost'] -
              params['green_bonus_w'])

# The fixed setup cost for Workshop A is incurred for each product line that uses it.
# Since minimum sales for both products are > 0 and both use Workshop A,
# the setup cost is incurred for both.
fixed_setup_cost = (2 * params['setup_hours_A'] * params['workshop_a_hourly_cost'])

# Set the objective function in the model
objective_expr = (cost_per_m * x_m + cost_per_w * x_w + fixed_setup_cost)
model.setObjective(objective_expr, GRB.MINIMIZE)

# --- Constraints ---

# 1. Workshop A Capacity Constraint:
# Total hours (variable production + fixed setup) must not exceed available time (regular + overtime).
model.addConstr(
    (m_prod_data['a_hrs'] * x_m + w_prod_data['a_hrs'] * x_w + 2 * params['setup_hours_A'])
    <= (params['workshop_a_available_hours'] + params['workshop_a_overtime_limit']),
    "Workshop_A_Capacity"
)

# 2. Workshop B Minimum Utilization Constraint:
# This constraint is carried over from the original problem's logic.
model.addConstr(
    (m_prod_data['b_hrs'] * x_m + w_prod_data['b_hrs'] * x_w)
    >= params['workshop_b_available_hours'],
    "Workshop_B_Utilization"
)

# 3. Inspection and Sales Cost Limit Constraint:
# Total inspection/sales cost must not exceed the revised monthly limit.
model.addConstr(
    (m_prod_data['insp_cost'] * x_m + w_prod_data['insp_cost'] * x_w)
    <= params['inspection_sales_cost_limit'],
    "Inspection_Cost_Limit"
)

# 4. Shared Technician Pool Constraint:
# Total technician hours used must not exceed the available pool.
model.addConstr(
    (params['tech_rate_m'] * x_m + params['tech_rate_w'] * x_w)
    <= params['tech_pool_hours'],
    "Technician_Pool"
)

# Note: Minimum sales constraints are already defined as lower bounds on the decision variables.

# --- Solve and Output ---

# Optimize the model
model.optimize()

# Print the final objective value in the specified format
if model.Status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    # This case should not be reached for a feasible problem
    print(f"Optimization failed with status: {model.Status}")
