import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_parameters(filepath):
    """
    Loads parameters from a CSV file into a dictionary.
    Assumes the CSV has columns: Parameter_Name, Value, Unit, Context_Description.
    """
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                params[row['Parameter_Name']] = float(row['Value'])
            except (ValueError, TypeError):
                params[row['Parameter_Name']] = row['Value']
    return params

def solve_fighter_jet_allocation():
    """
    Formulates and solves the fighter jet allocation optimization problem.
    """
    # --- 1. Load Data and Parameters ---
    # Construct the path to the data file relative to the script location
    try:
        # This works when the script is run as a file
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # This is a fallback for environments where __file__ is not defined (e.g., some notebooks)
        base_dir = os.getcwd()

    data_path = os.path.join(base_dir, "data", "general_parameters.csv")
    params = load_parameters(data_path)

    # Assign parameters to variables for clarity
    a1 = params['a1']
    a2 = params['a2']
    training_capacity_per_jet = params['training_capacity_per_jet']
    dual_use_training_efficiency = params['dual_use_training_efficiency']
    training_intensity_cap = params['training_intensity_cap']
    combat_jet_min_year2 = params['combat_jet_min_year2']
    combat_weight = params['combat_weight']
    training_weight = params['training_weight']

    # --- 2. Create Gurobi Model ---
    model = gp.Model("FighterJetAllocation")
    model.setParam('OutputFlag', 0)

    # --- 3. Define Decision Variables ---
    # Number of jets in each role for Year 1
    T1 = model.addVar(name="T1", lb=0)  # Training-only jets
    D1 = model.addVar(name="D1", lb=0)  # Dual-use jets
    C1 = model.addVar(name="C1", lb=0)  # Combat-only jets

    # Number of jets in each role for Year 2
    T2 = model.addVar(name="T2", lb=0)  # Training-only jets
    D2 = model.addVar(name="D2", lb=0)  # Dual-use jets
    C2 = model.addVar(name="C2", lb=0)  # Combat-only jets

    # --- 4. Define Constraints ---
    # Total available jets in Year 1
    model.addConstr(T1 + D1 + C1 == a1, name="fleet_balance_y1")

    # Total available jets in Year 2
    model.addConstr(T2 + D2 + C2 == a1 + a2, name="fleet_balance_y2")

    # Training intensity cap for Year 1
    model.addConstr(T1 + D1 <= training_intensity_cap * a1, name="training_cap_y1")

    # Training intensity cap for Year 2
    model.addConstr(T2 + D2 <= training_intensity_cap * (a1 + a2), name="training_cap_y2")

    # Minimum required combat jets in Year 2 (dual-use count as combat)
    model.addConstr(C2 + D2 >= combat_jet_min_year2, name="min_combat_y2")

    # --- 5. Define Objective Function ---
    # Total pilots trained over two years
    total_pilots_trained = training_capacity_per_jet * (
        T1 + dual_use_training_efficiency * D1 +
        T2 + dual_use_training_efficiency * D2
    )

    # Total combat-ready jets in Year 2
    total_combat_jets_y2 = C2 + D2

    # Weighted objective function to maximize
    objective = (training_weight * total_pilots_trained) + (combat_weight * total_combat_jets_y2)
    model.setObjective(objective, GRB.MAXIMIZE)

    # --- 6. Solve the Model ---
    model.optimize()

    # --- 7. Output Results ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("Optimization was not successful.")

if __name__ == "__main__":
    solve_fighter_jet_allocation()
