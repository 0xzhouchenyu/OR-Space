import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- Main script ---

# Define file path relative to the script location
data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")

# Load parameters from the CSV file
params = load_general_parameters(data_path)

# Create a new Gurobi model
model = gp.Model("Revised_Revenue_Maximization")

# Suppress Gurobi output
model.setParam('OutputFlag', 0)

# --- Decision Variables ---

# Number of each package to sell (integer)
x_a = model.addVar(vtype=GRB.INTEGER, name="Package_A", lb=0)
x_b = model.addVar(vtype=GRB.INTEGER, name="Package_B", lb=0)
x_c = model.addVar(vtype=GRB.INTEGER, name="Package_C", lb=0)

# Binary variables to decide whether to activate a package campaign
y_a = model.addVar(vtype=GRB.BINARY, name="Activate_A")
y_b = model.addVar(vtype=GRB.BINARY, name="Activate_B")
y_c = model.addVar(vtype=GRB.BINARY, name="Activate_C")

# Binary variables for the one-time review charges
z_b = model.addVar(vtype=GRB.BINARY, name="Review_Charge_B")
z_c = model.addVar(vtype=GRB.BINARY, name="Review_Charge_C")

# --- Objective Function ---
# Maximize total revenue minus all costs

revenue = (params['package_a_price'] * x_a +
           params['package_b_price'] * x_b +
           params['package_c_price'] * x_c)

activation_costs = (params['activation_cost_a'] * y_a +
                    params['activation_cost_b'] * y_b +
                    params['activation_cost_c'] * y_c)

review_charges = (params['package_b_review_charge'] * z_b +
                  params['package_c_review_charge'] * z_c)

model.setObjective(revenue - activation_costs - review_charges, GRB.MAXIMIZE)

# --- Constraints ---

# Inventory constraints
model.addConstr(params['package_a_shirts'] * x_a + params['package_b_shirts'] * x_b + params['package_c_shirts'] * x_c <= params['shirts_inventory'], "Shirts_Inventory")
model.addConstr(params['package_a_pants'] * x_a + params['package_b_pants'] * x_b + params['package_c_pants'] * x_c <= params['pants_inventory'], "Pants_Inventory")

# Labor budget constraint
model.addConstr(params['labor_hours_per_A'] * x_a + params['labor_hours_per_B'] * x_b + params['labor_hours_per_C'] * x_c <= params['labor_hours_total'], "Labor_Budget")

# Campaign activation constraints (linking x and y variables)
# If a campaign is not activated (y=0), sales must be zero.
# If a campaign is activated (y=1), sales must be at least the minimum batch size.
model.addConstr(x_a <= params['bigM_a'] * y_a, "Upper_Bound_A")
model.addConstr(x_a >= params['min_campaign_batch_a'] * y_a, "Min_Sales_A")

model.addConstr(x_b <= params['bigM_b'] * y_b, "Upper_Bound_B")
model.addConstr(x_b >= params['min_campaign_batch_b'] * y_b, "Min_Sales_B")

model.addConstr(x_c <= params['bigM_c'] * y_c, "Upper_Bound_C")
model.addConstr(x_c >= params['min_campaign_batch_c'] * y_c, "Min_Sales_C")

# Review charge constraints (linking x and z variables)
# If sales exceed the threshold, the corresponding binary z variable is forced to 1.
# The Big-M value must be large enough to not constrain x when z=1.
model.addConstr(x_b - params['package_b_review_threshold'] <= params['bigM_b'] * z_b, "Review_Trigger_B")
model.addConstr(x_c - params['package_c_review_threshold'] <= params['bigM_c'] * z_c, "Review_Trigger_C")

# --- Solve and Output ---

# Optimize the model
model.optimize()

# Print the final objective value in the required format
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("No optimal solution found.")
