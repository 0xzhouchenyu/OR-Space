import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve_farm_optimization():
    """
    Solves the revised farm optimization problem.
    """
    # --- 1. Load Data ---
    # Construct the absolute path to the data file
    try:
        data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
        params_path = os.path.join(data_dir, 'general_parameters.csv')
        params = load_parameters(params_path)
    except FileNotFoundError:
        # Fallback for different execution environments (e.g., interactive)
        params_path = os.path.join("data", "general_parameters.csv")
        params = load_parameters(params_path)


    # --- 2. Extract Parameters ---
    # Prices and Costs
    cow_selling_price = params['cow_selling_price']
    sheep_selling_price = params['sheep_selling_price']
    chicken_selling_price = params['chicken_selling_price']
    cow_feed_cost = params['cow_feed_cost']
    sheep_feed_cost = params['sheep_feed_cost']
    chicken_feed_cost = params['chicken_feed_cost']
    
    # Production and Base Capacities
    cow_manure_production = params['cow_manure_production']
    sheep_manure_production = params['sheep_manure_production']
    chicken_manure_production = params['chicken_manure_production']
    max_manure_capacity = params['max_manure_capacity']
    max_total_animals = params['max_total_animals']
    base_land_capacity = params['base_land_capacity']

    # Animal Bounds
    min_cows = params['min_cows']
    min_sheep = params['min_sheep']
    max_chickens = params['max_chickens']

    # Land Usage
    base_land_usage_cow = params['base_land_usage_cow']
    base_land_usage_sheep = params['base_land_usage_sheep']
    base_land_usage_chicken = params['base_land_usage_chicken']

    # Expansion Parameters
    expansion_cost = params['expansion_cost']
    premium_capacity_multiplier = params['premium_capacity_multiplier']
    premium_manure_multiplier = params['premium_manure_multiplier']
    premium_feed_multiplier = params['premium_feed_multiplier']
    expansion_land_increase = params['expansion_land_increase']

    # --- 3. Create Gurobi Model ---
    m = gp.Model("RevisedFarmProfit")
    m.setParam('OutputFlag', 0)

    # --- 4. Define Decision Variables ---
    # Number of each animal type
    cows = m.addVar(vtype=GRB.INTEGER, name="cows", lb=min_cows)
    sheep = m.addVar(vtype=GRB.INTEGER, name="sheep", lb=min_sheep)
    chickens = m.addVar(vtype=GRB.INTEGER, name="chickens", lb=0, ub=max_chickens)

    # Binary variable to decide on expansion
    is_expanded = m.addVar(vtype=GRB.BINARY, name="is_expanded")

    # --- 5. Define Objective Function ---
    # Revenue is independent of the mode
    revenue = (cow_selling_price * cows +
               sheep_selling_price * sheep +
               chicken_selling_price * chickens)

    # Expansion cost is applied only if is_expanded is 1
    expansion_fixed_cost = expansion_cost * is_expanded

    # Feed cost depends on the mode (regular vs. premium)
    # We use an auxiliary variable and indicator constraints to model this
    total_feed_cost = m.addVar(name="total_feed_cost")
    
    base_feed_expr = (cow_feed_cost * cows +
                      sheep_feed_cost * sheep +
                      chicken_feed_cost * chickens)
    
    premium_feed_expr = (cow_feed_cost * premium_feed_multiplier * cows +
                         sheep_feed_cost * premium_feed_multiplier * sheep +
                         chicken_feed_cost * premium_feed_multiplier * chickens)

    # If not expanded, use base feed cost
    m.addGenConstrIndicator(is_expanded, 0, total_feed_cost == base_feed_expr, name="regular_feed_cost")
    # If expanded, use premium feed cost
    m.addGenConstrIndicator(is_expanded, 1, total_feed_cost == premium_feed_expr, name="premium_feed_cost")

    # Set the objective to maximize total profit
    m.setObjective(revenue - total_feed_cost - expansion_fixed_cost, GRB.MAXIMIZE)

    # --- 6. Add Constraints ---
    # Total animal capacity constraint (conditional on expansion)
    max_animals_expanded = max_total_animals * premium_capacity_multiplier
    m.addConstr(cows + sheep + chickens <= max_total_animals + (max_animals_expanded - max_total_animals) * is_expanded, "total_animal_capacity")

    # Manure capacity constraint (conditional on expansion)
    manure_produced = (cow_manure_production * cows +
                       sheep_manure_production * sheep +
                       chicken_manure_production * chickens)
    max_manure_expanded = max_manure_capacity * premium_manure_multiplier
    m.addConstr(manure_produced <= max_manure_capacity + (max_manure_expanded - max_manure_capacity) * is_expanded, "manure_capacity")

    # Land capacity constraint (conditional on expansion)
    land_used = (base_land_usage_cow * cows +
                 base_land_usage_sheep * sheep +
                 base_land_usage_chicken * chickens)
    max_land_expanded = base_land_capacity + expansion_land_increase
    m.addConstr(land_used <= base_land_capacity + (max_land_expanded - base_land_capacity) * is_expanded, "land_capacity")

    # --- 7. Solve the Model ---
    m.optimize()

    # --- 8. Print Output ---
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_farm_optimization()
