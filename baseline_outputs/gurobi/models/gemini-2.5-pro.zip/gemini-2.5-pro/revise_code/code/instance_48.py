import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

def main():
    """
    Solves the revised microcomputer production problem using Gurobi.
    """
    # Define file paths relative to the script location
    try:
        # This pathing works when the script is in a subdirectory like 'src'
        base_dir = os.path.dirname(os.path.abspath(__file__))
        data_dir = os.path.join(base_dir, 'data')
        if not os.path.exists(data_dir):
             # This pathing works when the script is at the root
             base_dir = os.getcwd()
             data_dir = os.path.join(base_dir, 'data')
    except NameError:
        # Fallback for environments where __file__ is not defined
        base_dir = os.getcwd()
        data_dir = os.path.join(base_dir, 'data')

    general_params_path = os.path.join(data_dir, 'general_parameters.csv')
    table1_path = os.path.join(data_dir, 'table_1.csv')

    # Load data from CSV files
    params_data = load_csv_data(general_params_path)
    table1_data = load_csv_data(table1_path)

    # Parse general parameters into a dictionary
    params = {row['Parameter_Name']: float(row['Value']) for row in params_data}

    # Parse table 1 data
    proc_I_row = table1_data[0]
    proc_II_row = table1_data[1]
    profit_row = table1_data[2]

    # Assign parameters to variables for clarity
    min_profit = params['min_weekly_profit']
    min_A = params['min_model_A_units']
    min_B = params['min_model_B_units']
    proc_I_hours = params['process_I_hours']
    max_overtime_II = params['process_II_max_overtime']
    red_A = params['model_A_overtime_profit_reduction']
    red_B = params['model_B_overtime_profit_reduction']

    a_I = float(proc_I_row['Model_A_hours_per_unit'])
    b_I = float(proc_I_row['Model_B_hours_per_unit'])
    # cap_I is used as an exact target from general_parameters

    a_II = float(proc_II_row['Model_A_hours_per_unit'])
    b_II = float(proc_II_row['Model_B_hours_per_unit'])
    cap_II = float(proc_II_row['Maximum_Weekly_Processing_Capacity'])

    profit_A = float(profit_row['Model_A_hours_per_unit'])
    profit_B = float(profit_row['Model_B_hours_per_unit'])

    # Create a new Gurobi model
    model = gp.Model("RevisedProduction")

    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # To handle the profit reduction for overtime, we split production into regular and overtime.
    # This keeps the profit calculation linear.
    # xA_r: units of model A produced using regular Process II capacity
    # xA_o: units of model A produced using overtime Process II capacity
    # xB_r: units of model B produced using regular Process II capacity
    # xB_o: units of model B produced using overtime Process II capacity
    xA_r = model.addVar(name="xA_r", vtype=GRB.CONTINUOUS, lb=0)
    xA_o = model.addVar(name="xA_o", vtype=GRB.CONTINUOUS, lb=0)
    xB_r = model.addVar(name="xB_r", vtype=GRB.CONTINUOUS, lb=0)
    xB_o = model.addVar(name="xB_o", vtype=GRB.CONTINUOUS, lb=0)

    # Helper expressions for total units
    total_A = xA_r + xA_o
    total_B = xB_r + xB_o

    # --- Objective Function ---
    # Maximize the total number of units produced (market share)
    total_units = total_A + total_B
    model.setObjective(total_units, GRB.MAXIMIZE)

    # --- Constraints ---
    # 1. Process I: Must use an exact number of hours.
    model.addConstr(a_I * total_A + b_I * total_B == proc_I_hours, "Process_I_Exact")

    # 2. Process II: Regular time capacity.
    model.addConstr(a_II * xA_r + b_II * xB_r <= cap_II, "Process_II_Regular")

    # 3. Process II: Overtime capacity.
    model.addConstr(a_II * xA_o + b_II * xB_o <= max_overtime_II, "Process_II_Overtime")

    # 4. Minimum production requirement for model A.
    model.addConstr(total_A >= min_A, "Min_Units_A")

    # 5. Minimum production requirement for model B.
    model.addConstr(total_B >= min_B, "Min_Units_B")

    # 6. Minimum weekly profit constraint.
    profit_regular = profit_A * xA_r + profit_B * xB_r
    profit_overtime = (profit_A - red_A) * xA_o + (profit_B - red_B) * xB_o
    total_profit = profit_regular + profit_overtime
    model.addConstr(total_profit >= min_profit, "Min_Profit")

    # Solve the model
    model.optimize()

    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
