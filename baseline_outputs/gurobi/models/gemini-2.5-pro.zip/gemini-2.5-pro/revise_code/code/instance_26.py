import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    """
    Solves the revised convenience store staffing problem to minimize total daily labor cost.
    """
    # --- Data Loading ---
    # Define the base directory for data files relative to the script's location
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Handle case where __file__ is not defined (e.g., in an interactive session)
        script_dir = os.getcwd()
        
    data_dir = os.path.join(script_dir, 'data')

    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            # Convert numeric values from string to float
            try:
                params[param_name] = float(value_str)
            except ValueError:
                params[param_name] = value_str

    # Extract specific parameters needed for the model
    full_time_cost = params['full_time_cost']
    part_time_cost = params['part_time_cost']
    part_time_cap_per_period = int(params['part_time_cap_per_period'])
    min_full_time_per_period = int(params['min_full_time_per_period'])

    # Load staffing requirements from table_1.csv
    # The order in the CSV corresponds to periods 0 through 5
    requirements = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            requirements.append(int(row['Required_Salespeople'].strip()))
    
    num_periods = len(requirements)

    # --- Model Formulation ---
    # Create a new Gurobi model
    m = gp.Model("RevisedStaffing")
    
    # Suppress Gurobi's console output
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # ft_starts[i]: number of full-time staff starting an 8-hour shift in period i
    ft_starts = m.addVars(num_periods, vtype=GRB.INTEGER, name="ft_starts", lb=0)
    
    # pt_workers[j]: number of part-time staff working a 4-hour shift in period j
    pt_workers = m.addVars(num_periods, vtype=GRB.INTEGER, name="pt_workers", lb=0)

    # --- Objective Function ---
    # Minimize the total daily labor cost
    total_ft_cost = full_time_cost * gp.quicksum(ft_starts[i] for i in range(num_periods))
    total_pt_cost = part_time_cost * gp.quicksum(pt_workers[j] for j in range(num_periods))
    m.setObjective(total_ft_cost + total_pt_cost, GRB.MINIMIZE)

    # --- Constraints ---
    for j in range(num_periods):
        # The number of full-time staff present in period j are those who started
        # in period j and those who started in the previous period (j-1).
        # The modulo operator (%) handles the wrap-around from period 0 to period 5.
        ft_present_in_j = ft_starts[j] + ft_starts[(j - 1) % num_periods]

        # 1. Total Staffing Requirement:
        # The total number of staff on duty (full-time + part-time) must meet the demand for period j.
        m.addConstr(
            ft_present_in_j + pt_workers[j] >= requirements[j],
            name=f"total_demand_{j}"
        )

        # 2. Part-Time Cap:
        # The number of part-time workers in any period cannot exceed the specified cap.
        m.addConstr(
            pt_workers[j] <= part_time_cap_per_period,
            name=f"pt_cap_{j}"
        )

        # 3. Minimum Full-Time Presence:
        # The number of full-time staff present in any period must meet a minimum threshold.
        m.addConstr(
            ft_present_in_j >= min_full_time_per_period,
            name=f"min_ft_{j}"
        )

    # --- Solve and Output ---
    # Optimize the model to find the minimum cost solution
    m.optimize()

    # Print the final objective value in the required format if a solution is found
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        # This part is for robustness, in case no optimal solution is found.
        print("Optimization was not successful. Status code:", m.status)

if __name__ == "__main__":
    main()
