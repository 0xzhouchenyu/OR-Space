import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    """
    Solves the revised bus scheduling optimization problem using Gurobi.
    """
    # --- 1. Data Loading ---
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read general parameters from CSV
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                value = float(row['Value'])
                if value.is_integer():
                    value = int(value)
                params[row['Parameter_Name']] = value
            except (ValueError, TypeError):
                params[row['Parameter_Name']] = row['Value']

    # Read shift requirements from CSV
    shifts_data = []
    with open(os.path.join(data_dir, 'table_1_2.csv'), 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            shifts_data.append({
                'shift': int(row['Shift']),
                'required': int(row['Required_number'])
            })
    
    shifts_data.sort(key=lambda x: x['shift'])
    required = [s['required'] for s in shifts_data]
    n = len(required)

    # --- 2. Model Setup ---
    m = gp.Model("RevisedBusScheduling")
    m.setParam('OutputFlag', 0)

    # --- 3. Decision Variables ---
    # d: regular drivers, c: regular crew
    # od: overtime drivers, oc: overtime crew
    # Index i corresponds to the starting period (0-indexed)
    d = m.addVars(n, vtype=GRB.INTEGER, name="d", lb=0)
    c = m.addVars(n, vtype=GRB.INTEGER, name="c", lb=0)
    od = m.addVars(n, vtype=GRB.INTEGER, name="od", lb=0)
    oc = m.addVars(n, vtype=GRB.INTEGER, name="oc", lb=0)

    # --- 4. Objective Function ---
    # Minimize total cost, where overtime is more expensive
    overtime_cost_factor = params['overtime_cost_factor']
    
    total_cost = (gp.quicksum(d[i] for i in range(n)) + 
                  gp.quicksum(c[i] for i in range(n)) + 
                  overtime_cost_factor * (gp.quicksum(od[i] for i in range(n)) + 
                                          gp.quicksum(oc[i] for i in range(n))))
    
    m.setObjective(total_cost, GRB.MINIMIZE)

    # --- 5. Constraints ---
    # a) Demand Coverage Constraints for each period j
    for j in range(n):
        # Staff covering period j are those who started in period j or the previous period (j-1)
        # This covers an 8-hour shift (2 periods) with wrap-around
        prev_period = (j - 1 + n) % n
        
        drivers_on_duty = d[j] + d[prev_period] + od[j] + od[prev_period]
        crew_on_duty = c[j] + c[prev_period] + oc[j] + oc[prev_period]
        
        m.addConstr(drivers_on_duty >= required[j], f"DriverDemand_P{j+1}")
        m.addConstr(crew_on_duty >= required[j], f"CrewDemand_P{j+1}")

    # b) Total Overtime Limit
    max_overtime_shifts = params['max_overtime_shifts']
    total_overtime = gp.quicksum(od[i] for i in range(n)) + gp.quicksum(oc[i] for i in range(n))
    m.addConstr(total_overtime <= max_overtime_shifts, "MaxOvertime")

    # c) Night Shift Fraction Constraints
    # Late-night periods are 5 and 6, which are 0-indexed as 4 and 5
    night_periods = [4, 5]
    day_periods = [0, 1, 2, 3]

    # Driver night shift fraction
    max_night_driver_fraction = params['max_night_driver_fraction']
    driver_night_starts = gp.quicksum(d[i] + od[i] for i in night_periods)
    driver_day_starts = gp.quicksum(d[i] + od[i] for i in day_periods)
    m.addConstr((1 - max_night_driver_fraction) * driver_night_starts - 
                max_night_driver_fraction * driver_day_starts <= 0, "DriverNightFraction")

    # Crew night shift fraction
    max_night_crew_fraction = params['max_night_crew_fraction']
    crew_night_starts = gp.quicksum(c[i] + oc[i] for i in night_periods)
    crew_day_starts = gp.quicksum(c[i] + oc[i] for i in day_periods)
    m.addConstr((1 - max_night_crew_fraction) * crew_night_starts - 
                max_night_crew_fraction * crew_day_starts <= 0, "CrewNightFraction")

    # --- 6. Solve and Output ---
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: Infeasible or Unbounded")

if __name__ == "__main__":
    main()
