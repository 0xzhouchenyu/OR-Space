import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_parameters(filepath):
    """Load parameters from a CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    # Construct the path to the data file relative to the script's location.
    # This assumes the script is run from the workspace root directory.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(script_dir, "data", "general_parameters.csv")
    
    # Load all parameters from the CSV file
    params = load_parameters(data_path)

    # Create the Gurobi model
    m = gp.Model("TruckRentalRevised")
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # Number of trucks of each type (integer, non-negative)
    x = m.addVar(vtype=GRB.INTEGER, name="TypeA_trucks", lb=0)
    y = m.addVar(vtype=GRB.INTEGER, name="TypeB_trucks", lb=0)

    # Variables to model the number of trucks exceeding the base fleet size
    # These are used for the piecewise linear penalty costs
    x_over = m.addVar(vtype=GRB.CONTINUOUS, name="TypeA_over_base", lb=0)
    y_over = m.addVar(vtype=GRB.CONTINUOUS, name="TypeB_over_base", lb=0)

    # Binary variables to model the fixed fees ("gates")
    # z_b = 1 if number of Type B trucks exceeds its threshold
    z_b = m.addVar(vtype=GRB.BINARY, name="TypeB_recovery_flag")
    # z_total = 1 if the total number of trucks exceeds its threshold
    z_total = m.addVar(vtype=GRB.BINARY, name="Total_fleet_surge_flag")

    # --- Objective Function ---
    # The goal is to minimize the total cost per kilometer, which includes:
    # - Base rental costs for each truck type
    # - Penalty costs for trucks exceeding the base fleet
    # - Fixed fees triggered by exceeding certain thresholds
    objective_expr = (
        params['rental_cost_type_a'] * x +
        params['rental_cost_type_b'] * y +
        params['penalty_cost_type_a'] * x_over +
        params['penalty_cost_type_b'] * y_over +
        params['type_b_recovery_fee'] * z_b +
        params['total_fleet_surge_fee'] * z_total
    )
    m.setObjective(objective_expr, GRB.MINIMIZE)

    # --- Constraints ---
    # 1. Cargo capacity requirements must be met
    m.addConstr(
        params['refrigerated_capacity_type_a'] * x + params['refrigerated_capacity_type_b'] * y >= params['refrigerated_cargo_requirement'],
        "RefrigeratedRequirement"
    )
    m.addConstr(
        params['non_refrigerated_capacity_type_a'] * x + params['non_refrigerated_capacity_type_b'] * y >= params['non_refrigerated_cargo_requirement'],
        "NonRefrigeratedRequirement"
    )

    # 2. Link the 'over' variables to the actual number of trucks
    # x_over must be at least the amount by which x exceeds its base
    m.addConstr(x_over >= x - params['base_fleet_type_a'], "Calc_x_over")
    # y_over must be at least the amount by which y exceeds its base
    m.addConstr(y_over >= y - params['base_fleet_type_b'], "Calc_y_over")

    # 3. Link the binary 'gate' variables to their conditions using Big-M formulation
    # A sufficiently large constant 'M' is needed. M=1000 is a safe choice.
    M = 1000

    # If y > type_b_recovery_threshold, the fee applies. This is modeled by forcing z_b=1.
    # The constraint y <= threshold + M*z_b enforces that if y > threshold, z_b cannot be 0.
    m.addConstr(
        y <= params['type_b_recovery_threshold'] + M * z_b,
        "TypeB_recovery_gate"
    )

    # If x + y > total_fleet_surge_threshold, the fee applies. This is modeled by forcing z_total=1.
    # The constraint x+y <= threshold + M*z_total enforces that if x+y > threshold, z_total cannot be 0.
    m.addConstr(
        x + y <= params['total_fleet_surge_threshold'] + M * z_total,
        "Total_fleet_surge_gate"
    )

    # --- Solve and Output ---
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == "__main__":
    main()
