import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    Solves the revised project scheduling optimization problem.
    """
    # Define the path to the data directory
    try:
        # This works when the script is executed from the root directory
        data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
        if not os.path.exists(data_dir):
             # Fallback for environments where __file__ is not defined or points elsewhere
             data_dir = "data"
    except NameError:
        # Fallback for interactive environments
        data_dir = "data"


    # --- Load Data ---

    # Load general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Load precedence relationships
    precedences = []
    with open(os.path.join(data_dir, 'table_1.csv'), mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            precedences.append((row['Predecessor'].strip(), row['Successor'].strip()))

    # --- Prepare Model Data ---

    activities = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    
    # Base durations
    dur = {a: int(params[f'activity_{a}_duration']) for a in activities}

    # Costs
    work_cost_per_day = params['work_cost_per_day']
    machine_rental_cost_per_day = params['machine_rental_cost_per_day']
    
    # Revision-specific parameters for Activity E
    e_overtime_reduction = params['activity_E_overtime_reduction']
    e_overtime_cost = params['activity_E_overtime_cost']
    e_followup_review_cost = params['activity_E_followup_review_cost']
    
    # --- Create Gurobi Model ---

    m = gp.Model("RevisedProjectCostMinimization")
    m.setParam('OutputFlag', 0)

    # --- Define Decision Variables ---

    # S_a: Start time of activity a
    S = m.addVars(activities, name="S", lb=0.0)
    
    # T: Total project duration
    T = m.addVar(name="T", lb=0.0)
    
    # x_E: Binary variable, 1 if Activity E is accelerated, 0 otherwise
    x_E = m.addVar(name="x_E", vtype=GRB.BINARY)

    # --- Set Objective Function ---

    # Cost of daily work based on total project duration
    work_cost = work_cost_per_day * T
    
    # Cost of machine rental (from start of A to end of B)
    machine_rental_duration = S['B'] + dur['B'] - S['A']
    machine_cost = machine_rental_cost_per_day * machine_rental_duration
    
    # Additional costs if Activity E is accelerated
    e_acceleration_cost = (e_overtime_cost + e_followup_review_cost) * x_E
    
    m.setObjective(work_cost + machine_cost + e_acceleration_cost, GRB.MINIMIZE)

    # --- Add Constraints ---

    # Precedence constraints
    for pred, succ in precedences:
        if pred == 'E':
            # Duration of E depends on the decision to accelerate it
            effective_duration_E = dur['E'] - e_overtime_reduction * x_E
            m.addConstr(S[succ] >= S[pred] + effective_duration_E, f"precedence_{pred}_{succ}")
        else:
            # Standard precedence constraint for other activities
            m.addConstr(S[succ] >= S[pred] + dur[pred], f"precedence_{pred}_{succ}")

    # Total project duration T must be greater than or equal to the completion time
    # of all terminal activities (B and C).
    m.addConstr(T >= S['C'] + dur['C'], "makespan_C")
    m.addConstr(T >= S['B'] + dur['B'], "makespan_B")

    # --- Solve the Model ---

    m.optimize()

    # --- Print the Final Result ---
    
    if m.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("Optimization was not successful.")

if __name__ == "__main__":
    solve()
