import gurobipy as gp
from gurobipy import GRB
import csv
import os

def load_data():
    """
    Loads data from the CSV files in the 'data' subdirectory.
    """
    # The script is executed from the workspace root, so data files are in 'data/'.
    # This path construction is robust.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Load general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])
            
    # Load table_1.csv
    parts = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            parts.append({
                'id': int(row['Key_Part']),
                'distance': float(row['Distance_from_Airport_km']),
                'p_heavy': float(row['Probability_of_Destruction_per_Heavy_Bomb']),
                'p_light': float(row['Probability_of_Destruction_per_Light_Bomb']),
            })
            
    return parts, params

def main():
    """
    Formulates and solves the robust bomber allocation optimization problem.
    """
    # 1. Load data and parameters
    parts, params = load_data()
    n = len(parts)

    max_heavy_bombs = int(params['max_heavy_bombs'])
    max_light_bombs = int(params['max_light_bombs'])
    fuel_limit = params['fuel_limit']
    min_parts_destroyed = int(params['min_parts_destroyed'])
    
    max_sorties_A = int(params['max_sorties_A'])
    max_sorties_B = int(params['max_sorties_B'])
    sortie_fuel_overhead_A = params['sortie_fuel_overhead_A']
    sortie_fuel_overhead_B = params['sortie_fuel_overhead_B']

    # 2. Pre-calculate constants
    # The plan must be feasible for the more restrictive sortie limit
    max_sorties = min(max_sorties_A, max_sorties_B)

    # Fuel calculation helper
    def fuel_per_trip(distance, eff_bomb, eff_empty, takeoff_landing, overhead):
        return (distance / eff_bomb) + (distance / eff_empty) + takeoff_landing + overhead

    # Calculate fuel costs per bomb, per part, for each scenario
    fuel_h_A = [fuel_per_trip(p['distance'], params['fuel_efficiency_heavy_bomb'], params['fuel_efficiency_empty'], params['fuel_takeoff_landing'], sortie_fuel_overhead_A) for p in parts]
    fuel_l_A = [fuel_per_trip(p['distance'], params['fuel_efficiency_light_bomb'], params['fuel_efficiency_empty'], params['fuel_takeoff_landing'], sortie_fuel_overhead_A) for p in parts]
    fuel_h_B = [fuel_per_trip(p['distance'], params['fuel_efficiency_heavy_bomb'], params['fuel_efficiency_empty'], params['fuel_takeoff_landing'], sortie_fuel_overhead_B) for p in parts]
    fuel_l_B = [fuel_per_trip(p['distance'], params['fuel_efficiency_light_bomb'], params['fuel_efficiency_empty'], params['fuel_takeoff_landing'], sortie_fuel_overhead_B) for p in parts]

    # Probabilities of *not* destroying a part with one bomb (survival probabilities)
    q_h = [1.0 - p['p_heavy'] for p in parts]
    q_l = [1.0 - p['p_light'] for p in parts]

    # 3. Create Gurobi model
    m = gp.Model("RobustBombAllocation")
    m.setParam('OutputFlag', 0)
    # Required for non-convex constraints (quadratic, ExpA)
    m.setParam('NonConvex', 2)

    # 4. Define decision variables
    # Number of bombs of each type allocated to each part
    x_h = m.addVars(n, vtype=GRB.INTEGER, name="heavy_bombs", lb=0)
    x_l = m.addVars(n, vtype=GRB.INTEGER, name="light_bombs", lb=0)

    # Auxiliary variables for non-linear expressions
    # p[i]: Probability of destroying part i
    p = m.addVars(n, vtype=GRB.CONTINUOUS, lb=0, ub=1, name="prob_destroy")
    # term_h[i]: Survival probability from heavy bombs, i.e., q_h[i] ^ x_h[i]
    term_h = m.addVars(n, vtype=GRB.CONTINUOUS, name="term_h")
    # term_l[i]: Survival probability from light bombs, i.e., q_l[i] ^ x_l[i]
    term_l = m.addVars(n, vtype=GRB.CONTINUOUS, name="term_l")

    # DP table for probability of k successes
    # E[i, j]: Probability of exactly j successes among the first i parts
    E = m.addVars(n + 1, n + 1, vtype=GRB.CONTINUOUS, lb=0, ub=1, name="E")

    # 5. Add constraints
    # Resource constraints (bomb stockpile)
    m.addConstr(x_h.sum() <= max_heavy_bombs, "max_heavy_bombs")
    m.addConstr(x_l.sum() <= max_light_bombs, "max_light_bombs")
    
    # Robust sortie constraint (must be feasible in both scenarios)
    m.addConstr(x_h.sum() + x_l.sum() <= max_sorties, "max_sorties")

    # Robust fuel constraints (must be feasible in both scenarios)
    m.addConstr(gp.quicksum(fuel_h_A[i] * x_h[i] + fuel_l_A[i] * x_l[i] for i in range(n)) <= fuel_limit, "fuel_A")
    m.addConstr(gp.quicksum(fuel_h_B[i] * x_h[i] + fuel_l_B[i] * x_l[i] for i in range(n)) <= fuel_limit, "fuel_B")

    # Non-linear constraints to link bomb counts to destruction probabilities
    for i in range(n):
        # p_i = 1 - (q_h_i ^ x_h_i) * (q_l_i ^ x_l_i)
        m.addGenConstrExpA(x_h[i], q_h[i], term_h[i], f"exp_h_{i}")
        m.addGenConstrExpA(x_l[i], q_l[i], term_l[i], f"exp_l_{i}")
        # This is a quadratic constraint: p[i] + term_h[i] * term_l[i] == 1
        m.addConstr(p[i] == 1 - term_h[i] * term_l[i], f"prob_def_{i}")

    # DP table constraints to calculate overall success probability
    # Base case: 0 parts, 0 successes has probability 1
    m.addConstr(E[0, 0] == 1)
    for j in range(1, n + 1):
        m.addConstr(E[0, j] == 0)

    # Recursive step for the DP table
    for i in range(1, n + 1):
        part_idx = i - 1
        # Probability of 0 successes among first i parts
        m.addConstr(E[i, 0] == E[i - 1, 0] * (1 - p[part_idx]))
        # Probability of j successes (1 <= j <= i) among first i parts
        for j in range(1, i + 1):
            m.addConstr(E[i, j] == E[i - 1, j] * (1 - p[part_idx]) + E[i - 1, j - 1] * p[part_idx])
        # Probability of j > i successes is 0
        for j in range(i + 1, n + 1):
            m.addConstr(E[i, j] == 0)

    # 6. Set objective
    # Maximize the probability of destroying at least min_parts_destroyed
    objective = gp.quicksum(E[n, j] for j in range(min_parts_destroyed, n + 1))
    m.setObjective(objective, GRB.MAXIMIZE)

    # 7. Solve and print results
    m.optimize()

    if m.Status in (GRB.OPTIMAL, GRB.SUBOPTIMAL):
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        # Provide a fallback value if no solution is found
        print("FINAL_OBJ_VALUE: 0.0")

if __name__ == '__main__':
    main()
