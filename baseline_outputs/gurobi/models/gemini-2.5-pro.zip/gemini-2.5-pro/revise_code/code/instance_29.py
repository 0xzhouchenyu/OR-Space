import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    """
    Formulates and solves the revised Jieli Company staffing optimization problem.

    The objective is to maximize the number of employees assigned to both their
    preferred city and preferred specialty, subject to hard constraints on
    meeting all position demands and a minimum target for specialty preference
    satisfaction.
    """

    # --- Data Loading and Parsing ---

    # Per instructions, the script is run from the workspace root, and data is in a 'data' subdirectory.
    def get_data_path(filename):
        return os.path.join("data", filename)

    # Load all required data from CSV files
    try:
        params_df = pd.read_csv(get_data_path('general_parameters.csv'))
        demand_df = pd.read_csv(get_data_path('table_4_3.csv'))
        supply_df = pd.read_csv(get_data_path('table_4_4.csv'))
    except FileNotFoundError as e:
        print(f"Error loading data file: {e}. Make sure the 'data' directory is in the same folder as the script.")
        return

    # Parse general parameters
    p2_target = float(params_df[params_df['Parameter_Name'] == 'priority_2_target']['Value'].iloc[0])

    # Parse demand data into a dictionary: demand[(city, specialty)] = value
    demand = {}
    for _, row in demand_df.iterrows():
        city = row['Branch_Location'].split(' ')[0]
        spec = int(row['Specialty'])
        dem = float(row['Demand'])
        demand[(city, spec)] = dem

    # Parse supply (applicant) data into a dictionary: supply[type] = {details}
    supply = {}
    for _, row in supply_df.iterrows():
        t = int(row['Type'])
        supply[t] = {
            'num': float(row['Number_of_People']),
            'suit': [int(s) for s in str(row['Suitable_Specialty']).split(',')],
            'pref_spec': int(row['Preferred_Specialty']),
            'pref_city': row['Preferred_City']
        }

    # Define model sets
    cities = ['Donghai', 'Nanjiang']
    specs = [1, 2, 3]
    types = sorted(list(supply.keys()))

    # --- Model Formulation ---

    # Initialize the Gurobi model
    m = gp.Model("RevisedJieliStaffing")
    m.setParam('OutputFlag', 0)

    # Define decision variables: x[i, j, k]
    # Represents the number of people of applicant type 'i' assigned to city 'j' for specialty 'k'.
    # Variables are only created for valid assignments where the specialty is suitable for the applicant type.
    valid_assignments = []
    for i in types:
        for j in cities:
            for k in supply[i]['suit']:
                valid_assignments.append((i, j, k))

    x = m.addVars(valid_assignments, vtype=GRB.INTEGER, name="x")

    # Define the objective function: Maximize dual-match placements.
    # A dual-match occurs when an applicant is assigned to their preferred city AND preferred specialty.
    dual_match_assignments = []
    for i in types:
        # The dual-match assignment must be a valid one (i.e., the variable must exist).
        # This implicitly checks if the preferred specialty is in the suitable list.
        if (i, supply[i]['pref_city'], supply[i]['pref_spec']) in x:
            dual_match_assignments.append((i, supply[i]['pref_city'], supply[i]['pref_spec']))
    
    m.setObjective(gp.quicksum(x[i, j, k] for i, j, k in dual_match_assignments), GRB.MAXIMIZE)

    # --- Constraints ---

    # Constraint 1: Demand Fulfillment (Hard Constraint)
    # All required positions in each branch for each specialty must be filled.
    m.addConstrs(
        (x.sum('*', j, k) >= demand[(j, k)] for j in cities for k in specs),
        name="DemandFulfillment"
    )

    # Constraint 2: Supply Limit
    # The number of assigned people from an applicant type cannot exceed the available supply.
    m.addConstrs(
        (x.sum(i, '*', '*') <= supply[i]['num'] for i in types),
        name="SupplyLimit"
    )

    # Constraint 3: Specialty Preference Target (Hard Constraint)
    # The total number of people assigned to their preferred specialty must meet the target.
    pref_spec_sum = gp.quicksum(
        x[i, j, k] for i, j, k in valid_assignments if k == supply[i]['pref_spec']
    )
    m.addConstr(pref_spec_sum >= p2_target, name="SpecialtyPreferenceTarget")

    # --- Solve and Output ---

    # Optimize the model
    m.optimize()

    # Print the final objective value in the specified format
    if m.status == GRB.OPTIMAL:
        final_value = round(m.ObjVal)
        print(f"FINAL_OBJ_VALUE: {final_value}")
    else:
        # This case indicates an issue, e.g., an infeasible model.
        print("FINAL_OBJ_VALUE: 0")

if __name__ == '__main__':
    solve()
