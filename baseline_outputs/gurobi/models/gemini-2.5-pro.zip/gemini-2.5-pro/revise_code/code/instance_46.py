import gurobipy as gp
from gurobipy import GRB
import csv
import os

def load_data():
    """
    Loads student data and general parameters from CSV files.
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    students = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            s = {
                'Student_ID': int(row['Student_ID']),
                'Wage_CNY_per_hour': float(row['Wage_CNY_per_hour'])
            }
            for d in ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']:
                s[d] = float(row[d])
            students.append(s)

    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name']
            val = row['Value']
            try:
                params[name] = int(val)
            except ValueError:
                try:
                    params[name] = float(val)
                except ValueError:
                    params[name] = val
    return students, params

def solve_lab_scheduling():
    """
    Builds and solves the lab scheduling optimization model.
    """
    # 1. Load data
    students_data, params = load_data()

    # 2. Prepare model inputs
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    student_ids = [s['Student_ID'] for s in students_data]
    
    # As per problem description: students 1-4 are undergrads, 5-6 are grads
    undergrad_ids = [i for i in student_ids if i <= 4]
    grad_ids = [i for i in student_ids if i > 4]

    # Extract parameters
    hours_per_day = 14  # 8:00 AM to 10:00 PM
    min_undergrad_hours = params['min_undergrad_hours']
    min_grad_hours = params['min_grad_hours']
    max_shifts_per_student = params['max_shifts_per_student']
    max_students_per_day = params['max_students_per_day']
    daily_open_fee = params['daily_open_fee_cny']
    min_grad_weekly_coverage = params['min_grad_weekly_coverage_hours']

    # Create lookup dictionaries
    wages = {s['Student_ID']: s['Wage_CNY_per_hour'] for s in students_data}
    availability = {(s['Student_ID'], d): s[d] for s in students_data for d in days}

    # 3. Create Gurobi model
    model = gp.Model("LabScheduling")
    model.setParam('OutputFlag', 0)

    # 4. Define decision variables
    # x[i, d]: hours worked by student i on day d
    x = model.addVars(student_ids, days, vtype=GRB.CONTINUOUS, name="hours")
    
    # y[i, d]: binary, 1 if student i works on day d, 0 otherwise
    y = model.addVars(student_ids, days, vtype=GRB.BINARY, name="works_on_day")

    # 5. Set objective function
    # Minimize total cost = (sum of wages) + (sum of daily fees)
    total_wage_cost = gp.quicksum(wages[i] * x[i, d] for i in student_ids for d in days)
    total_fee_cost = gp.quicksum(daily_open_fee * y[i, d] for i in student_ids for d in days)
    model.setObjective(total_wage_cost + total_fee_cost, GRB.MINIMIZE)

    # 6. Add constraints
    # Daily Coverage: Exactly 14 hours of coverage needed each day
    model.addConstrs(
        (gp.quicksum(x[i, d] for i in student_ids) == hours_per_day for d in days),
        name="daily_coverage"
    )

    # Link x and y: If a student works (x > 0), the binary y must be 1.
    # This also enforces the daily availability limit.
    for i in student_ids:
        for d in days:
            model.addConstr(x[i, d] <= availability[i, d] * y[i, d], name=f"link_x_y_{i}_{d}")

    # Maximum shifts per student per week
    model.addConstrs(
        (y.sum(i, '*') <= max_shifts_per_student for i in student_ids),
        name="max_shifts_per_student"
    )

    # Maximum number of students per day
    model.addConstrs(
        (y.sum('*', d) <= max_students_per_day for d in days),
        name="max_students_per_day"
    )

    # Minimum weekly hours for each undergraduate student
    model.addConstrs(
        (x.sum(i, '*') >= min_undergrad_hours for i in undergrad_ids),
        name="min_hours_undergrad"
    )

    # Minimum weekly hours for each graduate student
    model.addConstrs(
        (x.sum(i, '*') >= min_grad_hours for i in grad_ids),
        name="min_hours_grad"
    )

    # NEW: Minimum total weekly hours collectively covered by graduate students
    model.addConstr(
        gp.quicksum(x[i, d] for i in grad_ids for d in days) >= min_grad_weekly_coverage,
        name="min_grad_collective_coverage"
    )

    # 7. Solve the model
    model.optimize()

    # 8. Print the final objective value
    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_lab_scheduling()
