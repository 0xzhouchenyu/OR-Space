import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

# --- Main execution ---

# Define file path relative to the script location
# The script is expected to be in the root directory.
data_file = os.path.join("data", "general_parameters.csv")

# Load data
params = load_general_parameters(data_file)

# Extract parameters from the loaded dictionary
# Prices and Costs
sell_price_table = params['sell_price_table']
sell_price_chair = params['sell_price_chair']
sell_price_bookshelf = params['sell_price_bookshelf']
manufacturing_cost_table = params['manufacturing_cost_table']
manufacturing_cost_chair = params['manufacturing_cost_chair']
manufacturing_cost_bookshelf = params['manufacturing_cost_bookshelf']

# Warehouse parameters
warehouse_space_table = params['warehouse_space_table']
warehouse_space_chair = params['warehouse_space_chair']
warehouse_space_bookshelf = params['warehouse_space_bookshelf']
max_warehouse_space = params['max_warehouse_space']

# Production limits
min_tables = params['min_tables']
min_bookshelves = params['min_bookshelves']
max_total_items = params['max_total_items']

# Labor parameters
labor_hours_table = params['labor_hours_table']
labor_hours_chair = params['labor_hours_chair']
labor_hours_bookshelf = params['labor_hours_bookshelf']
max_labor_hours_month_regular = params['max_labor_hours_month_regular']
max_labor_hours_month_rush = params['max_labor_hours_month_rush']

# Rush order parameters
max_rush_items_month = params['max_rush_items_month']
rush_profit_bonus_table = params['rush_profit_bonus_table']
rush_profit_bonus_chair = params['rush_profit_bonus_chair']
rush_profit_bonus_bookshelf = params['rush_profit_bonus_bookshelf']

# Calculate profit per item
profit_table_reg = sell_price_table - manufacturing_cost_table
profit_chair_reg = sell_price_chair - manufacturing_cost_chair
profit_bookshelf_reg = sell_price_bookshelf - manufacturing_cost_bookshelf

profit_table_rush = profit_table_reg + rush_profit_bonus_table
profit_chair_rush = profit_chair_reg + rush_profit_bonus_chair
profit_bookshelf_rush = profit_bookshelf_reg + rush_profit_bonus_bookshelf

# Create Gurobi model
model = gp.Model("FurnitureProductionRevised")
model.setParam('OutputFlag', 0)

# --- Decision Variables ---
# Regular production quantities
x_table_reg = model.addVar(vtype=GRB.INTEGER, name="tables_regular", lb=0)
x_chair_reg = model.addVar(vtype=GRB.INTEGER, name="chairs_regular", lb=0)
x_bookshelf_reg = model.addVar(vtype=GRB.INTEGER, name="bookshelves_regular", lb=0)

# Rush production quantities
x_table_rush = model.addVar(vtype=GRB.INTEGER, name="tables_rush", lb=0)
x_chair_rush = model.addVar(vtype=GRB.INTEGER, name="chairs_rush", lb=0)
x_bookshelf_rush = model.addVar(vtype=GRB.INTEGER, name="bookshelves_rush", lb=0)

# --- Objective Function ---
# Maximize total profit from regular and rush orders
objective_expr = (
    profit_table_reg * x_table_reg +
    profit_chair_reg * x_chair_reg +
    profit_bookshelf_reg * x_bookshelf_reg +
    profit_table_rush * x_table_rush +
    profit_chair_rush * x_chair_rush +
    profit_bookshelf_rush * x_bookshelf_rush
)
model.setObjective(objective_expr, GRB.MAXIMIZE)

# --- Constraints ---
# Warehouse space constraint (applies to all items)
model.addConstr(
    (warehouse_space_table * (x_table_reg + x_table_rush) +
     warehouse_space_chair * (x_chair_reg + x_chair_rush) +
     warehouse_space_bookshelf * (x_bookshelf_reg + x_bookshelf_rush)) <= max_warehouse_space,
    "Warehouse_Space"
)

# Minimum production requirements (total of regular + rush)
model.addConstr((x_table_reg + x_table_rush) >= min_tables, "Min_Tables")
model.addConstr((x_bookshelf_reg + x_bookshelf_rush) >= min_bookshelves, "Min_Bookshelves")

# Maximum total production (total of all items)
model.addConstr(
    (x_table_reg + x_table_rush +
     x_chair_reg + x_chair_rush +
     x_bookshelf_reg + x_bookshelf_rush) <= max_total_items,
    "Max_Total_Items"
)

# Regular labor hours constraint
model.addConstr(
    (labor_hours_table * x_table_reg +
     labor_hours_chair * x_chair_reg +
     labor_hours_bookshelf * x_bookshelf_reg) <= max_labor_hours_month_regular,
    "Regular_Labor_Hours"
)

# Rush labor hours constraint
model.addConstr(
    (labor_hours_table * x_table_rush +
     labor_hours_chair * x_chair_rush +
     labor_hours_bookshelf * x_bookshelf_rush) <= max_labor_hours_month_rush,
    "Rush_Labor_Hours"
)

# Maximum total rush items constraint
model.addConstr(
    (x_table_rush + x_chair_rush + x_bookshelf_rush) <= max_rush_items_month,
    "Max_Rush_Items"
)

# --- Solve and Output ---
model.optimize()

# Print the final objective value in the required format
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    print("No optimal solution found.")
