import gurobipy as gp
from gurobipy import GRB
import os
import csv
import sys

def load_courses(data_dir):
    """Load course data from table_1.csv"""
    filepath = os.path.join(data_dir, 'table_1.csv')
    courses = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            course = row['Course'].strip()
            categories = [c.strip() for c in row['Category'].split(';')]
            courses[course] = categories
    return courses

def load_parameters(data_dir):
    """Load general parameters and prerequisites from general_parameters.csv"""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    prereq_keys = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            
            if name == 'min_courses_required':
                params['min_courses_required'] = int(value)
            elif name == 'cs_category_name':
                params['cs_category_name'] = value
            elif name == 'mandatory_foundation_for_cs_counting':
                params['mandatory_foundation_for_cs_counting'] = value
            elif name.startswith('prerequisite_'):
                course_key = name[len('prerequisite_'):]
                prereq_keys.append({'key': course_key, 'prereq': value})

    return params, prereq_keys

def match_course_from_key(prereq_key, course_list):
    """Match a prerequisite key (like 'computer_simulation') to an actual course name."""
    key_lower = prereq_key.lower().replace('_', ' ')
    for course in course_list:
        if course.lower() == key_lower:
            return course
    return None

def solve_course_selection():
    """
    Main function to set up and solve the optimization problem.
    """
    # The script is executed from the workspace root.
    # Data files are in a subdirectory named 'data'.
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        data_dir = os.path.join(script_dir, "data")
        # Test if the directory exists, if not, fall back.
        if not os.path.isdir(data_dir):
            raise FileNotFoundError
    except (FileNotFoundError, NameError):
        # Fallback for environments where __file__ is not defined or path is different
        data_dir = "data"

    # Load all data
    courses_data = load_courses(data_dir)
    params, prereq_keys = load_parameters(data_dir)

    # --- Data Processing ---
    course_list = list(courses_data.keys())
    
    # Resolve prerequisite names
    prerequisites = []
    for item in prereq_keys:
        course_name = match_course_from_key(item['key'], course_list)
        if course_name:
            prerequisites.append((course_name, item['prereq']))

    # Extract key parameters
    min_required = params['min_courses_required']
    cs_category = params['cs_category_name']
    foundation_course = params['mandatory_foundation_for_cs_counting']

    # Get all unique categories
    all_categories = sorted(list(set(cat for cats in courses_data.values() for cat in cats)))

    # Create a list of valid (course, category) pairs for variable definition
    course_category_pairs = [(c, cat) for c, cats in courses_data.items() for cat in cats]

    # --- Model Formulation ---
    m = gp.Model("RevisedCourseSelection")
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # x[i]: 1 if course i is taken, 0 otherwise
    x = m.addVars(course_list, vtype=GRB.BINARY, name="x")

    # y[i, j]: 1 if course i is used to satisfy category j's requirement
    y = m.addVars(course_category_pairs, vtype=GRB.BINARY, name="y")

    # --- Objective Function ---
    # Minimize the total number of courses taken
    m.setObjective(x.sum(), GRB.MINIMIZE)

    # --- Constraints ---

    # 1. Prerequisite constraints: If a course is taken, its prerequisites must also be taken.
    m.addConstrs((x[course] <= x[prereq] for course, prereq in prerequisites), name="prereq")

    # 2. Category requirement: At least min_required distinct courses must be counted for each category.
    m.addConstrs((y.sum('*', cat) >= min_required for cat in all_categories), name="min_courses")

    # 3. Linking y and x: A course can only be counted for a category if it is taken.
    m.addConstrs((y[course, cat] <= x[course] for course, cat in course_category_pairs), name="link_y_x")

    # 4. No double counting: A course can be counted towards at most one category's minimum requirement.
    m.addConstrs((y.sum(course, '*') <= 1 for course in course_list), name="no_double_count")

    # 5. CS foundation course requirement: If any course is counted towards the CS category,
    # the mandatory foundation course must be taken.
    courses_in_cs = [c for c, cats in courses_data.items() if cs_category in cats]
    m.addConstrs((y[course, cs_category] <= x[foundation_course] for course in courses_in_cs if (course, cs_category) in y.keys()), name="cs_foundation")

    # --- Solve and Output ---
    m.optimize()

    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        # This case should not happen for a feasible problem but is good practice.
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_course_selection()
