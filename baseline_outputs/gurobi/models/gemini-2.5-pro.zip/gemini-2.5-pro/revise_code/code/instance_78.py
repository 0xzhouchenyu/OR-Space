import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve_revised_problem():
    """
    Solves the revised shoe store optimization problem using Gurobi.
    """
    # --- 1. Data Loading ---
    # The script is executed from the workspace root, so paths are relative.
    # Using os.path.join for cross-platform compatibility.
    params_path = os.path.join("data", "general_parameters.csv")
    table_path = os.path.join("data", "table_3_3.csv")

    try:
        params_df = pd.read_csv(params_path)
        df = pd.read_csv(table_path)
    except FileNotFoundError as e:
        print(f"Error loading data files: {e}")
        return

    # --- 2. Parameter Extraction ---
    # Helper function to safely extract parameter values from the dataframe
    def get_param_value(df, param_name):
        return df.loc[df['Parameter_Name'] == param_name, 'Value'].iloc[0]

    # General business parameters
    sales_goal = float(get_param_value(params_df, 'monthly_sales_goal'))
    pt_ft_ratio = float(get_param_value(params_df, 'pt_ft_overtime_ratio'))

    # Clerk-specific data
    ft_row = df[df['Role'] == 'Full-time'].iloc[0]
    pt_row = df[df['Role'] == 'Part-time'].iloc[0]

    ft_hours = ft_row['Monthly_Working_Hours']
    ft_sales_rate = ft_row['Sales_Volume_Pairs_Per_Hour']
    
    pt_hours = pt_row['Monthly_Working_Hours']
    pt_sales_rate = pt_row['Sales_Volume_Pairs_Per_Hour']

    # Number of clerks (defaulted as per original heuristic's logic, as not in CSV)
    num_ft = 5
    num_pt = 4

    # --- 3. Pre-calculation ---
    # Calculate total sales from normal working hours, assuming full employment
    normal_sales = (num_ft * ft_hours * ft_sales_rate) + \
                   (num_pt * pt_hours * pt_sales_rate)

    # Calculate the sales shortfall that must be covered by overtime
    sales_shortfall = sales_goal - normal_sales
    
    # If sales goal is already met, no overtime is needed.
    # The model will handle this by setting variables to 0, but we can check.
    if sales_shortfall <= 0:
        print("FINAL_OBJ_VALUE: 0.0")
        return

    # --- 4. Gurobi Model Formulation ---
    # Initialize the model
    m = gp.Model("revised_shoe_store_optimization")
    
    # Suppress Gurobi output
    m.setParam('OutputFlag', 0)

    # Define decision variables: total overtime hours for each clerk type
    y_ft = m.addVar(name="total_ft_overtime_hours", lb=0, vtype=GRB.CONTINUOUS)
    y_pt = m.addVar(name="total_pt_overtime_hours", lb=0, vtype=GRB.CONTINUOUS)

    # Set the objective: Minimize the total overtime hours
    m.setObjective(y_ft + y_pt, GRB.MINIMIZE)

    # Add Constraint 1: Sales Goal
    # The sales generated from overtime hours must cover the shortfall.
    m.addConstr(
        (y_ft * ft_sales_rate) + (y_pt * pt_sales_rate) >= sales_shortfall,
        "sales_goal_constraint"
    )

    # Add Constraint 2: Overtime Dependency (The Revision)
    # Part-time overtime hours must be at least a certain ratio of full-time hours.
    m.addConstr(
        y_pt >= pt_ft_ratio * y_ft,
        "overtime_ratio_constraint"
    )

    # --- 5. Solve and Output ---
    # Optimize the model
    m.optimize()

    # Check solver status
    if m.status == GRB.OPTIMAL:
        # Print the final objective value in the required format
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("Optimization was not successful. Status code:", m.status)

if __name__ == '__main__':
    solve_revised_problem()
