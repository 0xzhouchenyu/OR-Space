import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_csv_data(filename):
    """Load a CSV file and return a list of dictionaries."""
    # The script is run from the root, so the path is relative to the root.
    # The instruction says: os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "filename.csv")
    # This is robust for locating the script file itself.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(base_dir, "data", filename)
    if not os.path.exists(filepath):
        # Fallback for environments where __file__ might not be defined as expected,
        # or script is run from a different CWD.
        filepath = os.path.join("data", filename)

    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        return [row for row in reader]

def load_demand_data():
    """Load demand data from table_1.csv."""
    rows = load_csv_data('table_1.csv')
    demand = {}
    for row in rows:
        month = row['Month']
        product = row['Product']
        units = int(row['Market_Demand_Units'])
        demand[(month, product)] = units
    return demand

def load_general_parameters():
    """Load general parameters from general_parameters.csv."""
    rows = load_csv_data('general_parameters.csv')
    params = {}
    for row in rows:
        name = row['Parameter_Name']
        value = float(row['Value'])
        params[name] = value
    return params

def main():
    """Solves the revised production planning problem."""
    # Load data
    demand_data = load_demand_data()
    params = load_general_parameters()

    # Define sets
    months = ['July', 'August', 'September', 'October', 'November', 'December']
    products = ['Product_I', 'Product_II']

    # Extract parameters into structured dictionaries
    prod_cost = {
        'Product_I': params['product_I_cost_jun_to_dec'],
        'Product_II': params['product_II_cost_jun_to_dec']
    }
    demand = {
        (m, p): demand_data.get((m, p), 0) for m in months for p in products
    }
    volume = {
        'Product_I': params['product_I_volume'],
        'Product_II': params['product_II_volume']
    }
    machine_hours = {
        'Product_I': params['product_I_machine_hours'],
        'Product_II': params['product_II_machine_hours']
    }
    power_consumption = {
        'Product_I': params['product_I_power_kwh'],
        'Product_II': params['product_II_power_kwh']
    }
    
    grid_quotas = {m: params[f'grid_quota_{m.lower()}'] for m in months}
    generator_max = {m: params[f'generator_max_{m.lower()}'] for m in months}

    # Scalar parameters
    initial_inventory = params['initial_inventory_july']
    warehouse_capacity = params['warehouse_capacity']
    own_warehouse_cost = params['own_warehouse_cost']
    machine_hours_capacity = params['machine_hours_capacity_monthly']
    grid_electricity_cost = params['grid_electricity_cost']
    generator_electricity_cost = params['generator_electricity_cost']

    # Create a new model
    model = gp.Model("RevisedProductionPlanning")

    # --- Decision Variables ---
    # Production quantities
    x = model.addVars(months, products, name="prod", lb=0)
    # Inventory at end of month
    inv = model.addVars(months, products, name="inv", lb=0)
    # Electricity from grid (kWh)
    grid_elec = model.addVars(months, name="grid_elec", lb=0)
    # Electricity from generator (kWh)
    gen_elec = model.addVars(months, name="gen_elec", lb=0)

    # --- Objective Function ---
    # Minimize total costs: production + inventory + electricity
    total_production_cost = gp.quicksum(prod_cost[p] * x[m, p] for m in months for p in products)
    total_inventory_cost = gp.quicksum(own_warehouse_cost * volume[p] * inv[m, p] for m in months for p in products)
    total_electricity_cost = gp.quicksum(grid_electricity_cost * grid_elec[m] + generator_electricity_cost * gen_elec[m] for m in months)
    
    model.setObjective(total_production_cost + total_inventory_cost + total_electricity_cost, GRB.MINIMIZE)

    # --- Constraints ---
    for i, m in enumerate(months):
        # 1. Inventory Balance Constraint
        for p in products:
            if i == 0:
                # For July, use initial inventory
                model.addConstr(inv[m, p] == initial_inventory + x[m, p] - demand[m, p], f"inv_balance_{m}_{p}")
            else:
                # For other months, use previous month's inventory
                prev_m = months[i - 1]
                model.addConstr(inv[m, p] == inv[prev_m, p] + x[m, p] - demand[m, p], f"inv_balance_{m}_{p}")

        # 2. Machine Hour Capacity Constraint
        model.addConstr(
            gp.quicksum(machine_hours[p] * x[m, p] for p in products) <= machine_hours_capacity,
            f"machine_hours_{m}"
        )

        # 3. Electricity Balance Constraint
        total_power_needed = gp.quicksum(power_consumption[p] * x[m, p] for p in products)
        model.addConstr(grid_elec[m] + gen_elec[m] == total_power_needed, f"power_balance_{m}")

        # 4. Electricity Source Limits
        model.addConstr(grid_elec[m] <= grid_quotas[m], f"grid_quota_{m}")
        model.addConstr(gen_elec[m] <= generator_max[m], f"gen_limit_{m}")

        # 5. Warehouse Capacity Constraint
        total_inventory_volume = gp.quicksum(volume[p] * inv[m, p] for p in products)
        model.addConstr(total_inventory_volume <= warehouse_capacity, f"warehouse_cap_{m}")

    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)

    # Optimize the model
    model.optimize()

    # Print the final objective value as required
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
