import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    This function sets up and solves the investment optimization problem.
    """
    # --- 1. Load Data ---
    # The script is executed from the root, so the path to data is relative from there.
    # Using the specified robust path construction.
    try:
        data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
        if not os.path.exists(data_path):
             # Fallback for environments where __file__ is not defined or path is different
             data_path = os.path.join("data", "general_parameters.csv")
    except NameError:
        data_path = os.path.join("data", "general_parameters.csv")


    params = {}
    with open(data_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Assign parameters to variables for clarity
    initial_fund = params['initial_fund']
    annual_rate = params['annual_profit_rate'] / 100
    inv_limit_y1 = params['investment_limit_year1']
    return_rate_y1y2 = params['return_rate_year1_to_year2'] / 100
    inv_limit_y2 = params['investment_limit_year2']
    return_rate_y2y3 = params['return_rate_year2_to_year3'] / 100
    inv_limit_y3 = params['investment_limit_year3']
    profit_rate_y3 = params['profit_rate_year3'] / 100
    fee_year1 = params['fee_year1']
    fee_year2 = params['fee_year2']
    fee_year3 = params['fee_year3']

    # --- 2. Create Gurobi Model ---
    model = gp.Model("RevisedInvestmentOptimization")

    # --- 3. Define Decision Variables ---
    # Investment amounts (continuous)
    a1 = model.addVar(name="a1", lb=0)  # Annual investment year 1
    a2 = model.addVar(name="a2", lb=0)  # Annual investment year 2
    a3 = model.addVar(name="a3", lb=0)  # Annual investment year 3

    b1 = model.addVar(name="b1", lb=0, ub=inv_limit_y1)  # Special investment year 1
    c2 = model.addVar(name="c2", lb=0, ub=inv_limit_y2)  # Special investment year 2
    d3 = model.addVar(name="d3", lb=0, ub=inv_limit_y3)  # Special investment year 3

    # Binary variables to indicate if a special investment is used
    y_b1 = model.addVar(name="y_b1", vtype=GRB.BINARY)  # Fee trigger for b1
    y_c2 = model.addVar(name="y_c2", vtype=GRB.BINARY)  # Fee trigger for c2
    y_d3 = model.addVar(name="y_d3", vtype=GRB.BINARY)  # Fee trigger for d3

    # --- 4. Set up Constraints ---

    # Link continuous investment variables to their binary counterparts (Big-M formulation)
    model.addConstr(b1 <= inv_limit_y1 * y_b1, "link_b1")
    model.addConstr(c2 <= inv_limit_y2 * y_c2, "link_c2")
    model.addConstr(d3 <= inv_limit_y3 * y_d3, "link_d3")

    # Budget and cash flow constraints year-by-year
    # Year 1:
    # Investments (a1, b1) and the fee for b1 cannot exceed the initial fund.
    cash_spent_y1 = a1 + b1 + fee_year1 * y_b1
    model.addConstr(cash_spent_y1 <= initial_fund, "Year1_budget")
    cash_rem_y1 = initial_fund - cash_spent_y1

    # Year 2:
    # Funds available are the remaining cash from Y1 plus returns from the annual investment a1.
    cash_avail_y2 = cash_rem_y1 + a1 * (1 + annual_rate)
    # Investments (a2, c2) and the fee for c2 cannot exceed the available funds.
    cash_spent_y2 = a2 + c2 + fee_year2 * y_c2
    model.addConstr(cash_spent_y2 <= cash_avail_y2, "Year2_budget")
    cash_rem_y2 = cash_avail_y2 - cash_spent_y2

    # Year 3:
    # Funds available are remaining cash from Y2 plus returns from a2 and b1.
    cash_avail_y3 = cash_rem_y2 + a2 * (1 + annual_rate) + b1 * return_rate_y1y2
    # Investments (a3, d3) and the fee for d3 cannot exceed the available funds.
    cash_spent_y3 = a3 + d3 + fee_year3 * y_d3
    model.addConstr(cash_spent_y3 <= cash_avail_y3, "Year3_budget")
    cash_rem_y3 = cash_avail_y3 - cash_spent_y3

    # --- 5. Define Objective Function ---
    # The total value at the end of year 3 is the sum of:
    # 1. Cash remaining after year 3 investments.
    # 2. Returns from investments that mature at the end of year 3 (a3, c2, d3).
    final_value = cash_rem_y3 + a3 * (1 + annual_rate) + c2 * return_rate_y2y3 + d3 * (1 + profit_rate_y3)
    model.setObjective(final_value, GRB.MAXIMIZE)

    # --- 6. Configure and Solve ---
    model.setParam('OutputFlag', 0)
    model.optimize()

    # --- 7. Print Output ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # This part is for robustness in case no solution is found.
        print("FINAL_OBJ_VALUE: Infeasible or Unbounded")

if __name__ == "__main__":
    solve()
