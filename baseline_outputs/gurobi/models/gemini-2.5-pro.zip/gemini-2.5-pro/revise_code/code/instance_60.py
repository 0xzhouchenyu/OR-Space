import os
import csv
import re
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    This function formulates and solves the multi-day vehicle routing problem
    as described in the revised business requirements.
    """
    # --- Data Loading ---
    
    # Get the directory of the current script to build robust file paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")

    # Load general parameters from CSV
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                value = float(row['Value'])
                if value.is_integer():
                    value = int(value)
                params[row['Parameter_Name']] = value
            except (ValueError, TypeError):
                params[row['Parameter_Name']] = row['Value']

    num_locations = params['num_customers']
    start_loc_1based = params['start_location']
    max_route_length_day = params['max_route_length_day']
    route_cost_day = params['route_cost_day']
    
    # Load the symmetric distance matrix from CSV
    dist_matrix = [[0] * num_locations for _ in range(num_locations)]
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        lines = f.readlines()[1:]  # Skip header row
        for line in lines:
            # Use regex to find all numbers in the line
            nums = re.findall(r'\d+', line)
            if not nums:
                continue
            
            # Convert to 0-indexed row
            row_idx = int(nums[0]) - 1
            
            # Populate the upper triangle of the matrix
            for j, val_str in enumerate(nums[1:]):
                col_idx = row_idx + 1 + j
                if col_idx < num_locations:
                    val = int(val_str)
                    dist_matrix[row_idx][col_idx] = val
                    dist_matrix[col_idx][row_idx] = val # Matrix is symmetric

    # --- Model Formulation ---

    # Define model sets and indices
    NUM_DAYS = 2
    depot_idx = start_loc_1based - 1
    
    Locations = range(num_locations)
    Customers = [i for i in Locations if i != depot_idx]
    Days = range(NUM_DAYS)
    
    num_customers_only = len(Customers)
    arcs = [(i, j) for i in Locations for j in Locations if i != j]

    # Create a new Gurobi model
    m = gp.Model("MultiDayTSP")

    # --- Decision Variables ---

    # x[i,j,d] = 1 if arc (i,j) is traversed on day d, 0 otherwise
    x = m.addVars(arcs, Days, vtype=GRB.BINARY, name="x")
    
    # y[c,d] = 1 if customer c is visited on day d, 0 otherwise
    y = m.addVars(Customers, Days, vtype=GRB.BINARY, name="y")
    
    # z[d] = 1 if a route is used on day d, 0 otherwise
    z = m.addVars(Days, vtype=GRB.BINARY, name="z")
    
    # u[c,d] = auxiliary variable for MTZ subtour elimination
    u = m.addVars(Customers, Days, vtype=GRB.CONTINUOUS, name="u")

    # --- Objective Function ---

    # Minimize total travel distance plus fixed costs for each day a route is operated
    travel_cost = gp.quicksum(dist_matrix[i][j] * x[i, j, d] for i, j in arcs for d in Days)
    fixed_operating_cost = gp.quicksum(route_cost_day * z[d] for d in Days)
    m.setObjective(travel_cost + fixed_operating_cost, GRB.MINIMIZE)

    # --- Constraints ---

    # Each customer must be visited exactly once across all days
    m.addConstrs((y.sum(c, '*') == 1 for c in Customers), name="VisitOnce")

    # Flow conservation: if a customer is visited on a day, one arc must enter and one must leave
    m.addConstrs((x.sum('*', c, d) == y[c, d] for c in Customers for d in Days), name="FlowIn")
    m.addConstrs((x.sum(c, '*', d) == y[c, d] for c in Customers for d in Days), name="FlowOut")

    # Depot flow: if a day is used, one route leaves and one returns to the depot
    m.addConstrs((x.sum(depot_idx, '*', d) == z[d] for d in Days), name="DepotLeave")
    m.addConstrs((x.sum('*', depot_idx, d) == z[d] for d in Days), name="DepotReturn")

    # Maximum route length constraint for each day
    m.addConstrs((gp.quicksum(dist_matrix[i][j] * x[i, j, d] for i, j in arcs) <= max_route_length_day for d in Days), name="MaxLength")

    # Subtour Elimination (Miller-Tucker-Zemlin formulation adapted for VRP)
    # Set bounds for u variables, activating them only if the customer is visited on that day
    m.addConstrs((u[c, d] >= y[c, d] for c in Customers for d in Days), name="u_lower_bound")
    m.addConstrs((u[c, d] <= num_customers_only * y[c, d] for c in Customers for d in Days), name="u_upper_bound")
    
    # The MTZ constraints prevent subtours among the customers visited on a given day
    m.addConstrs((u[i, d] - u[j, d] + num_customers_only * x[i, j, d] <= num_customers_only - 1
                  for i in Customers for j in Customers for d in Days if i != j), name="MTZ")

    # --- Solve and Output ---

    # Suppress Gurobi's console output
    m.setParam('OutputFlag', 0)
    
    # Optimize the model
    m.optimize()

    # Print the final objective value in the specified format
    if m.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
