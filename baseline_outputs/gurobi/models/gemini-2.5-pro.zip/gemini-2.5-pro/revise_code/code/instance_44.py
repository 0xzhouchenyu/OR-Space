import os
import csv
import gurobipy as gp
from gurobipy import GRB

# --- Data Loading ---
# The instruction specifies using os.path.dirname(__file__) for robustness.
try:
    # This works when running the script directly from a file.
    script_dir = os.path.dirname(os.path.abspath(__file__))
except NameError:
    # This is a fallback for environments where __file__ is not defined (e.g., interactive shells).
    script_dir = os.getcwd()

data_dir = os.path.join(script_dir, "data")

# Load general parameters from the CSV file into a dictionary.
params = {}
with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', newline='') as f:
    reader = csv.DictReader(f)
    for row in reader:
        try:
            params[row['Parameter_Name']] = float(row['Value'])
        except (ValueError, TypeError):
            params[row['Parameter_Name']] = row['Value']

# Assign parameters to variables
m = int(params['m'])
n = int(params['n'])
p = int(params['p'])
a = {i: params[f'a_{i}'] for i in range(1, m + 1)}
b = {j: params[f'b_{j}'] for j in range(1, n + 1)}
f_cost = {k: params[f'f_{k}'] for k in range(1, p + 1)}
q = {k: params[f'q_{k}'] for k in range(1, p + 1)}
qexp = {k: params[f'qexp_{k}'] for k in range(1, p + 1)}
alpha = {j: params[f'alpha_{j}'] for j in range(1, n + 1)}
eps = params['eps']
M = params['M']

# Load transportation costs from production to marshaling stations (regular and express)
cR_ik = {}
cE_ik = {}
with open(os.path.join(data_dir, 'table_1.csv'), 'r', newline='') as f:
    reader = csv.DictReader(f)
    for row in reader:
        i, k = int(row['i']), int(row['k'])
        cR_ik[(i, k)] = float(row['cR_ik'])
        cE_ik[(i, k)] = float(row['cE_ik'])

# Load transportation costs from marshaling stations to demand points (regular and express)
cR_kj = {}
cE_kj = {}
with open(os.path.join(data_dir, 'table_2.csv'), 'r', newline='') as f:
    reader = csv.DictReader(f)
    for row in reader:
        k, j = int(row['k']), int(row['j'])
        cR_kj[(k, j)] = float(row['cR_kj'])
        cE_kj[(k, j)] = float(row['cE_kj'])

# --- Model Formulation ---
model = gp.Model("RevisedTransportationProblem")

# Create ranges for indices (1-based to match data)
I = range(1, m + 1)
J = range(1, n + 1)
K = range(1, p + 1)

# Decision Variables
xR = model.addVars(I, K, name="xR", vtype=GRB.CONTINUOUS, lb=0)
xE = model.addVars(I, K, name="xE", vtype=GRB.CONTINUOUS, lb=0)
yR = model.addVars(K, J, name="yR", vtype=GRB.CONTINUOUS, lb=0)
yE = model.addVars(K, J, name="yE", vtype=GRB.CONTINUOUS, lb=0)
z = model.addVars(K, name="z", vtype=GRB.BINARY)

# Auxiliary variables for revised constraints
u = model.addVars(K, J, name="u", vtype=GRB.BINARY)  # 1 if express link k->j is used
d = model.addVars(K, J, name="d", vtype=GRB.BINARY)  # 1 if any flow on k->j
D = model.addVars(J, name="D", vtype=GRB.BINARY)  # 1 if j is served by >1 station

# Objective Function: Minimize total regular, express, and fixed costs
obj = (
    gp.quicksum(cR_ik[i, k] * xR[i, k] for i in I for k in K) +
    gp.quicksum(cE_ik[i, k] * xE[i, k] for i in I for k in K) +
    gp.quicksum(cR_kj[k, j] * yR[k, j] for k in K for j in J) +
    gp.quicksum(cE_kj[k, j] * yE[k, j] for k in K for j in J) +
    gp.quicksum(f_cost[k] * z[k] for k in K)
)
model.setObjective(obj, GRB.MINIMIZE)

# --- Constraints ---

# 1. Supply constraints: Total shipped from production point i <= a_i
model.addConstrs((gp.quicksum(xR[i, k] + xE[i, k] for k in K) <= a[i] for i in I), name="Supply")

# 2. Demand constraints: Total received at demand point j >= b_j
model.addConstrs((gp.quicksum(yR[k, j] + yE[k, j] for k in K) >= b[j] for j in J), name="Demand")

# 3. Flow conservation at marshaling stations (by mode)
model.addConstrs((gp.quicksum(xR[i, k] for i in I) == gp.quicksum(yR[k, j] for j in J) for k in K), name="FlowBalance_Regular")
model.addConstrs((gp.quicksum(xE[i, k] for i in I) == gp.quicksum(yE[k, j] for j in J) for k in K), name="FlowBalance_Express")

# 4. Total station capacity (linked with z_k)
model.addConstrs((gp.quicksum(xR[i, k] + xE[i, k] for i in I) <= q[k] * z[k] for k in K), name="TotalCapacity")

# 5. Express station capacity (linked with z_k)
model.addConstrs((gp.quicksum(xE[i, k] for i in I) <= qexp[k] * z[k] for k in K), name="ExpressCapacity")

# 6. Link d_kj to flow (yR + yE). Big-M is total demand at j, b[j].
model.addConstrs((yR[k, j] + yE[k, j] <= b[j] * d[k, j] for k in K for j in J), name="Link_d_flow")

# 7. Link D_j to d_kj (D_j=1 if sum(d_kj) > 1). Big-M is number of stations, p.
model.addConstrs((2 - gp.quicksum(d[k, j] for k in K) <= p * (1 - D[j]) for j in J), name="Link_D_ge2")
model.addConstrs((gp.quicksum(d[k, j] for k in K) - 1 <= p * D[j] for j in J), name="Link_D_le1")

# 8. Link u_kj to express flow yE_kj using given M and eps.
model.addConstrs((yE[k, j] <= M * u[k, j] for k in K for j in J), name="Link_u_upper")
model.addConstrs((yE[k, j] >= eps * u[k, j] for k in K for j in J), name="Link_u_lower")

# 9. Conditional Express Share: (1-alpha)*sum(yE) - alpha*sum(yR) >= -M_share * (1-D)
# A tight Big-M for the slack is alpha_j * b_j.
for j in J:
    M_share = alpha[j] * b[j]
    model.addConstr(
        (1 - alpha[j]) * gp.quicksum(yE[k, j] for k in K) - alpha[j] * gp.quicksum(yR[k, j] for k in K) >= -M_share * (1 - D[j]),
        name=f"ConditionalExpressShare_{j}"
    )

# 10. Conditional Diversification: sum(u_kj) >= 2 if D_j=1. Big-M is p.
model.addConstrs((gp.quicksum(u[k, j] for k in K) >= 2 - p * (1 - D[j]) for j in J), name="ConditionalDiversification")

# --- Solve and Output ---
model.setParam('OutputFlag', 0)
model.optimize()

if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    # This part is for robustness in case the model is infeasible or has other issues.
    print("No optimal solution found.")
