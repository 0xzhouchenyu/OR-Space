import os
import csv
import gurobipy as gp
from gurobipy import GRB

# Self-contained utility functions as per instructions
def load_table_1(data_dir):
    """Load the weekly demand, capacity, and cost data."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    weeks = []
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Week'].strip().lower() == 'total':
                continue
            weeks.append({
                'week': int(row['Week']),
                'demand': float(row['Demand_1000_boxes']),
                'capacity': float(row['Production_Capacity_1000_boxes']),
                'cost': float(row['Cost_per_1000_boxes_1000_yuan'])
            })
    return weeks

def load_general_parameters(data_dir):
    """Load general parameters."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])
    return params

# --- Main script ---

# 1. Setup paths and load data
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(script_dir, "data")

# Load data from CSV files
weeks_data = load_table_1(data_dir)
params = load_general_parameters(data_dir)

# Extract parameters into simple lists and variables for easier access
n_weeks = len(weeks_data)
demands = [d['demand'] for d in weeks_data]
capacities = [d['capacity'] for d in weeks_data]
var_costs = [d['cost'] for d in weeks_data]

storage_cost = params['storage_cost_per_thousand_boxes']
fixed_setup_cost = params['fixed_setup_cost']
week2_push_threshold = params['week2_push_threshold']
week3_capacity_loss = params['week3_capacity_loss_after_week2_push']
week2_microclean_threshold = params['week2_microclean_threshold']
week2_microclean_fee = params['week2_microclean_fee']

# 2. Create Gurobi model
model = gp.Model("RevisedBeverageProduction")
model.setParam('OutputFlag', 0)

# 3. Define decision variables
# x[t]: production in week t (0-indexed)
# s[t]: inventory at end of week t
# y_setup[t]: binary, 1 if production > 0 in week t
# y_clean: binary, 1 if week 2 production > microclean_threshold
# y_push: binary, 1 if week 2 production > push_threshold
x = model.addVars(n_weeks, name="x", lb=0)
s = model.addVars(n_weeks, name="s", lb=0)
y_setup = model.addVars(n_weeks, vtype=GRB.BINARY, name="y_setup")
y_clean = model.addVar(vtype=GRB.BINARY, name="y_clean")
y_push = model.addVar(vtype=GRB.BINARY, name="y_push")

# 4. Set objective function
total_var_cost = gp.quicksum(var_costs[t] * x[t] for t in range(n_weeks))
total_storage_cost = gp.quicksum(storage_cost * s[t] for t in range(n_weeks))
total_setup_cost = gp.quicksum(fixed_setup_cost * y_setup[t] for t in range(n_weeks))
microclean_cost = week2_microclean_fee * y_clean

model.setObjective(
    total_var_cost + total_storage_cost + total_setup_cost + microclean_cost,
    GRB.MINIMIZE
)

# 5. Add constraints
# Inventory balance constraints
for t in range(n_weeks):
    initial_inventory = s[t-1] if t > 0 else 0
    model.addConstr(initial_inventory + x[t] - s[t] == demands[t], name=f"balance_week_{t+1}")

# Production setup and capacity constraints
for t in range(n_weeks):
    # Link setup binary to production variable using capacity as Big-M.
    # This also enforces the capacity limit when y_setup[t] is 1.
    model.addConstr(x[t] <= capacities[t] * y_setup[t], name=f"setup_capacity_link_{t+1}")

# Week 3 (t=2) has an additional conditional capacity reduction based on Week 2's production
week_3_idx = 2
model.addConstr(x[week_3_idx] <= capacities[week_3_idx] - week3_capacity_loss * y_push, name=f"capacity_reduction_week_3")

# Week 2 (t=1) special constraints
week_2_idx = 1

# Micro-clean trigger: if x[1] > threshold, y_clean must be 1.
# Formulated as: x[1] - threshold <= M * y_clean
m_clean = capacities[week_2_idx] - week2_microclean_threshold
model.addConstr(x[week_2_idx] - week2_microclean_threshold <= m_clean * y_clean, name="clean_trigger")

# Capacity reduction trigger: if x[1] > threshold, y_push must be 1.
# Formulated as: x[1] - threshold <= M * y_push
m_push = capacities[week_2_idx] - week2_push_threshold
model.addConstr(x[week_2_idx] - week2_push_threshold <= m_push * y_push, name="push_trigger")

# 6. Optimize the model
model.optimize()

# 7. Print the final objective value in the required format
if model.status == GRB.OPTIMAL:
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
else:
    # This case should not happen for a feasible problem but is included for robustness.
    print("FINAL_OBJ_VALUE: Error - No optimal solution found")
