import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    """
    Solves the revised production scheduling problem.
    """
    # Per instructions, construct the path to the data directory.
    # The script is at the root, so the 'data' folder is a subdirectory.
    # This approach is robust for different execution environments.
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        base_dir = os.path.join(script_dir, 'data')
    except NameError:
        # Fallback for environments where __file__ is not defined (e.g., interactive sessions)
        # Assumes the script is run from the project root directory.
        base_dir = 'data'

    # --- Data Loading ---

    # Load demand data from table_1.csv
    demand = {}
    with open(os.path.join(base_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader)
        quarters_from_file = [int(h) for h in header[1:]]
        for row in reader:
            product = row[0].strip()
            for j, q in enumerate(quarters_from_file):
                demand[(product, q)] = int(row[j+1])

    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(base_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    # --- Model Setup ---

    products = ['I', 'II', 'III']
    quarters = [1, 2, 3, 4]

    # Extract parameters from the loaded dictionary
    initial_inventory = params['initial_inventory']
    end_inventory_requirement = params['end_inventory_requirement']
    total_hours_per_quarter = params['production_hours_per_quarter']
    inventory_cost_per_unit = params['inventory_cost_per_unit']

    hours_per_unit = {
        'I': params['product_I_hours_per_unit'],
        'II': params['product_II_hours_per_unit'],
        'III': params['product_III_hours_per_unit']
    }

    delay_penalty = {
        'I': params['delay_penalty_product_I'],
        'II': params['delay_penalty_product_II'],
        'III': params['delay_penalty_product_III']
    }

    # Extract new quarterly parameters for the revised model
    normal_hours_cap = {t: total_hours_per_quarter * params[f'normal_hours_cap_fraction_q{t}'] for t in quarters}
    peak_hours_cap = {t: params[f'peak_hours_cap_q{t}'] for t in quarters}
    peak_cost_per_hour = {t: params[f'peak_cost_per_hour_q{t}'] for t in quarters}

    # --- Gurobi Model ---

    m = gp.Model("RevisedProductionScheduling")

    # --- Decision Variables ---

    # Production quantities (normal and peak hours)
    x_norm = m.addVars(products, quarters, vtype=GRB.INTEGER, name="x_norm", lb=0)
    x_peak = m.addVars(products, quarters, vtype=GRB.INTEGER, name="x_peak", lb=0)

    # Inventory variables (positive and negative parts)
    inv_pos = m.addVars(products, quarters, vtype=GRB.CONTINUOUS, name="inv_pos", lb=0)
    inv_neg = m.addVars(products, quarters, vtype=GRB.CONTINUOUS, name="inv_neg", lb=0)

    # Helper variable for net inventory (can be positive or negative)
    inv = m.addVars(products, quarters, vtype=GRB.CONTINUOUS, lb=-GRB.INFINITY, name="inv")

    # Peak hours used per quarter (needed for the objective function)
    h_peak = m.addVars(quarters, vtype=GRB.CONTINUOUS, name="h_peak", lb=0)

    # --- Constraints ---

    # 1. Production Hour Constraints
    # Normal hours cap
    m.addConstrs(
        (gp.quicksum(hours_per_unit[p] * x_norm[p, t] for p in products) <= normal_hours_cap[t]
         for t in quarters), name="NormalHoursCap"
    )

    # Peak hours definition and cap
    m.addConstrs(
        (h_peak[t] == gp.quicksum(hours_per_unit[p] * x_peak[p, t] for p in products)
         for t in quarters), name="PeakHoursDef"
    )
    m.addConstrs(
        (h_peak[t] <= peak_hours_cap[t] for t in quarters), name="PeakHoursCap"
    )

    # 2. Inventory Balance Constraints
    # Quarter 1
    m.addConstrs(
        (inv[p, 1] == initial_inventory + x_norm[p, 1] + x_peak[p, 1] - demand[p, 1]
         for p in products), name="InvBalanceQ1"
    )
    # Quarters 2-4
    m.addConstrs(
        (inv[p, t] == inv[p, t-1] + x_norm[p, t] + x_peak[p, t] - demand[p, t]
         for p in products for t in quarters if t > 1), name="InvBalanceRest"
    )

    # 3. Inventory Decomposition
    # inv = inv_pos - inv_neg
    m.addConstrs(
        (inv[p, t] == inv_pos[p, t] - inv_neg[p, t]
         for p in products for t in quarters), name="InvDecomp"
    )

    # 4. Final Inventory Requirement
    # Inventory at the end of Q4 must meet the requirement
    m.addConstrs(
        (inv[p, 4] >= end_inventory_requirement for p in products), name="EndInvReq"
    )

    # 5. Special Production Constraint
    # Product I cannot be produced in Q2 in either normal or peak hours
    m.addConstr(x_norm['I', 2] == 0, name="NoProd_I_Q2_norm")
    m.addConstr(x_peak['I', 2] == 0, name="NoProd_I_Q2_peak")

    # --- Objective Function ---
    # Minimize: inventory cost + delay penalty + peak hour cost

    inventory_holding_cost = gp.quicksum(
        inventory_cost_per_unit * inv_pos[p, t]
        for p in products for t in quarters
    )

    delay_penalty_cost = gp.quicksum(
        delay_penalty[p] * inv_neg[p, t]
        for p in products for t in quarters
    )

    peak_hour_surcharge = gp.quicksum(
        peak_cost_per_hour[t] * h_peak[t]
        for t in quarters
    )

    m.setObjective(inventory_holding_cost + delay_penalty_cost + peak_hour_surcharge, GRB.MINIMIZE)

    # --- Solve ---
    m.setParam('OutputFlag', 0)
    m.optimize()

    # --- Output ---
    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == "__main__":
    main()
