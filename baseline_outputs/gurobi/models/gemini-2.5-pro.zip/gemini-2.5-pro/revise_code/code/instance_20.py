import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters():
    """
    Loads parameters from the CSV file into a dictionary.
    """
    # Correctly locate the data file relative to the script's location
    # The script is expected to run from the workspace root.
    # The original heuristic's pathing is for a script inside 'src'.
    # This script will be at the root, so the path is simpler.
    data_dir = "data"
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    
    params = {}
    with open(filepath, 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = row['Value'].strip()
            # Try to convert to number
            try:
                # Use float to handle potential non-integer values, then int if possible
                num_value = float(value)
                if num_value == int(num_value):
                    value = int(num_value)
                else:
                    value = num_value
            except ValueError:
                pass  # Keep as string if conversion fails
            params[name] = value
    return params

def solve():
    """
    Builds and solves the toy manufacturing optimization problem.
    """
    params = load_parameters()
    
    # --- Model Initialization ---
    model = gp.Model("ToyManufacturingRevised")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # Quantity of each toy to produce (Integer)
    x_robot = model.addVar(name="robots", vtype=GRB.INTEGER, lb=0)
    x_car = model.addVar(name="model_cars", vtype=GRB.INTEGER, lb=0)
    x_blocks = model.addVar(name="building_blocks", vtype=GRB.INTEGER, lb=0)
    x_doll = model.addVar(name="dolls", vtype=GRB.INTEGER, lb=0)

    # Binary variables to indicate if a toy type is produced at all
    y_robot = model.addVar(name="y_robot", vtype=GRB.BINARY)
    y_car = model.addVar(name="y_car", vtype=GRB.BINARY)
    y_blocks = model.addVar(name="y_blocks", vtype=GRB.BINARY)
    y_doll = model.addVar(name="y_doll", vtype=GRB.BINARY)

    # --- Objective Function ---
    # Maximize total profit
    objective = (params['profit_per_robot'] * x_robot +
                 params['profit_per_model_car'] * x_car +
                 params['profit_per_building_blocks'] * x_blocks +
                 params['profit_per_doll'] * x_doll)
    model.setObjective(objective, GRB.MAXIMIZE)

    # --- Constraints ---

    # 1. Resource Constraints
    model.addConstr(
        params['plastic_per_robot'] * x_robot +
        params['plastic_per_model_car'] * x_car +
        params['plastic_per_building_blocks'] * x_blocks +
        params['plastic_per_doll'] * x_doll
        <= params['plastic_available'], "Plastic_Limit"
    )
    
    model.addConstr(
        params['electronics_per_robot'] * x_robot +
        params['electronics_per_model_car'] * x_car +
        params['electronics_per_building_blocks'] * x_blocks +
        params['electronics_per_doll'] * x_doll
        <= params['electronic_components_available'], "Electronics_Limit"
    )

    # 2. Linking Integer and Binary Variables (Big-M formulation)
    # A sufficiently large number M. A safe upper bound can be calculated,
    # but a large constant is sufficient here.
    M = 10000
    
    # If a toy is produced (x > 0), its corresponding binary flag must be 1.
    model.addConstr(x_robot <= M * y_robot, "Link_Robot_Upper")
    model.addConstr(x_car <= M * y_car, "Link_Car_Upper")
    model.addConstr(x_blocks <= M * y_blocks, "Link_Blocks_Upper")
    model.addConstr(x_doll <= M * y_doll, "Link_Doll_Upper")

    # If the binary flag is 1, at least one unit must be produced.
    # This also ensures that if x=0, y must be 0.
    model.addConstr(x_robot >= y_robot, "Link_Robot_Lower")
    model.addConstr(x_car >= y_car, "Link_Car_Lower")
    model.addConstr(x_blocks >= y_blocks, "Link_Blocks_Lower")
    model.addConstr(x_doll >= y_doll, "Link_Doll_Lower")

    # 3. Business Rule Constraints
    
    # If robots are manufactured, dolls cannot be.
    model.addConstr(y_robot + y_doll <= 1, "Robot_Doll_Exclusion")
    
    # If model cars are manufactured, building blocks must also be.
    model.addConstr(y_car <= y_blocks, "Car_Blocks_Dependency")
    
    # The number of dolls cannot exceed the number of model cars.
    model.addConstr(x_doll <= x_car, "Dolls_leq_Cars")

    # REVISED RULE: Model cars and building blocks are mutually exclusive.
    model.addConstr(y_car + y_blocks <= 1, "Car_Blocks_Exclusion")

    # --- Solve and Output ---
    model.optimize()
    
    # Print the final objective value in the required format
    print(f"FINAL_OBJ_VALUE: {model.ObjVal}")

if __name__ == "__main__":
    solve()
