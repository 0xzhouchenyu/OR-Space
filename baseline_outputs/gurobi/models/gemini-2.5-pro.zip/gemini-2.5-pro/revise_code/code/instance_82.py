import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_optimization():
    """
    Solves the revised mall tenant optimization problem using a Gurobi MIP model.
    """
    # --- 1. Data Loading and Preparation ---
    
    # Define file paths relative to the script's location
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        data_dir = os.path.join(base_dir, "data")
    except NameError:
        # If running in an environment where __file__ is not defined
        base_dir = os.getcwd()
        data_dir = os.path.join(base_dir, "data")

    # Read general parameters from the revised CSV
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    mall_total_space = params['mall_total_space']
    rent_pct = params['rent_percentage'] / 100.0
    common_area_factor = params['common_area_factor']
    gm_concession = params['general_merchandise_third_store_concession']
    catering_cost = params['catering_third_store_security_cost']

    # Read store data from the revised CSV
    stores = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            profits = {}
            # This profit parsing logic is adapted from the original heuristic
            for k in range(1, 4):
                key = f'Profit_{k}_Store' if k == 1 else f'Profit_{k}_Stores'
                val = row.get(key, '-').strip()
                if val and val != '-':
                    profits[k] = float(val)
            
            stores.append({
                'name': row['Store_Type'].strip(),
                'area': int(row['Area_per_Shop_m2'].strip()),
                'min': int(row['Min'].strip()),
                'max': int(row['Max'].strip()),
                'profits': profits  # per-store profit when n stores of this type
            })

    # --- 2. Model Formulation ---

    # Create a new Gurobi model
    m = gp.Model("RevisedMallOptimization")
    m.setParam('OutputFlag', 0)

    # Create decision variables: b[i][j] is a binary variable,
    # 1 if we choose to open j stores of type i, 0 otherwise.
    b = {}
    for i, s in enumerate(stores):
        b[i] = {}
        # The range includes all possible numbers of stores from min to max
        for j in range(s['min'], s['max'] + 1):
            b[i][j] = m.addVar(vtype=GRB.BINARY, name=f"{s['name'].replace(' ', '_')}_{j}")

    # --- 3. Constraints ---

    # Constraint: For each store type, we must select exactly one number of stores.
    for i, s in enumerate(stores):
        m.addConstr(gp.quicksum(b[i][j] for j in range(s['min'], s['max'] + 1)) == 1,
                    name=f"choice_{s['name'].replace(' ', '_')}")

    # Constraint: Total effective area must not exceed the mall's total available space.
    # The effective area is the sum of individual store areas multiplied by the common_area_factor.
    total_area_expr = gp.LinExpr()
    for i, s in enumerate(stores):
        for j in range(s['min'], s['max'] + 1):
            total_area_expr += j * s['area'] * b[i][j]
    
    m.addConstr(common_area_factor * total_area_expr <= mall_total_space, name="space_constraint")

    # --- 4. Objective Function ---

    # Objective: Maximize the total rental income.
    objective_expr = gp.LinExpr()
    for i, s in enumerate(stores):
        for j in range(s['min'], s['max'] + 1):
            if j == 0:
                # No stores of this type, no profit, no contribution to objective.
                continue

            # Calculate total profit for j stores of this type
            # Total Profit = number of stores * per-store profit
            total_profit_j = j * s['profits'][j]
            
            # Calculate base rent income from this choice
            rent_income = rent_pct * total_profit_j
            
            # Apply special conditions from the revision brief and data files
            if s['name'] == 'General Merchandise' and j == 3:
                rent_income -= gm_concession
            
            if s['name'] == 'Catering' and j == 3:
                rent_income -= catering_cost
            
            # Add the net rent income for this choice to the objective function
            objective_expr += rent_income * b[i][j]

    m.setObjective(objective_expr, GRB.MAXIMIZE)

    # --- 5. Solve and Output ---

    # Optimize the model
    m.optimize()

    # Print the final objective value in the required format
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        # This part is for robustness in case no optimal solution is found.
        print("Optimization was not successful or did not find an optimal solution.")
        print(f"FINAL_OBJ_VALUE: 0")


if __name__ == '__main__':
    solve_optimization()
