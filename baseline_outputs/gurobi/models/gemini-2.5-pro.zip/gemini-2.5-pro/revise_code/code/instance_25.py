import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """
    Loads parameters from a CSV file into a dictionary.
    """
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    """
    Main function to set up and solve the optimization problem.
    """
    # --- 1. Load Data and Parameters ---
    # Construct the full path to the data file
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    params = load_parameters(data_path)

    W = params['initial_investment']
    r1 = params['return_rate_option_1']
    r2 = params['return_rate_option_2']
    min_reserve_y1 = params['min_reserve_year1']
    min_reserve_y2 = params['min_reserve_year2']
    max_opt2_start = params['max_option2_start']
    late_settlement_rate = params['option2_year0_late_settlement_rate']

    # --- 2. Create Gurobi Model ---
    model = gp.Model("revised_investment")
    model.setParam('OutputFlag', 0)

    # --- 3. Define Decision Variables ---
    # x_t_i: amount invested in option i at the start of year t
    x0_1 = model.addVar(name="x0_1", lb=0)
    x0_2 = model.addVar(name="x0_2", lb=0)
    x1_1 = model.addVar(name="x1_1", lb=0)
    x1_2 = model.addVar(name="x1_2", lb=0)
    x2_1 = model.addVar(name="x2_1", lb=0)

    # c_t: cash held as reserve at the end of year t
    c0 = model.addVar(name="c0", lb=0)
    c1 = model.addVar(name="c1", lb=0)
    c2 = model.addVar(name="c2", lb=0)

    # --- 4. Define Constraints ---

    # Year 0: Initial investment budget
    model.addConstr(x0_1 + x0_2 + c0 == W, "year0_budget")

    # Year 1: Reinvestment budget from matured Option 1 and cash carryover
    model.addConstr(x1_1 + x1_2 + c1 == x0_1 * (1 + r1) + c0, "year1_budget")

    # Year 2: Reinvestment budget from matured Option 1 and cash carryover
    # Note: x0_2 proceeds are NOT available here due to late settlement
    model.addConstr(x2_1 + c2 == x1_1 * (1 + r1) + c1, "year2_budget")

    # Reserve constraints
    model.addConstr(c1 >= min_reserve_y1, "min_reserve_year1")
    model.addConstr(c2 >= min_reserve_y2, "min_reserve_year2")

    # Maximum exposure for Option 2
    model.addConstr(x0_2 <= max_opt2_start, "max_option2_start_y0")
    model.addConstr(x1_2 <= max_opt2_start, "max_option2_start_y1")

    # --- 5. Define Objective Function ---
    # Maximize total wealth at the end of year 3
    # Wealth = matured x2_1 + matured x1_2 + late-settled x0_2 + final cash reserve c2
    
    final_wealth = (
        x2_1 * (1 + r1) +                                 # Matures at Y3
        x1_2 * (1 + r2) +                                 # Matures at Y3
        x0_2 * (1 + r2) * (1 - late_settlement_rate) +    # Matures late (at Y2, but available at Y3) with deduction
        c2                                                # Cash reserve from end of Y2
    )
    model.setObjective(final_wealth, GRB.MAXIMIZE)

    # --- 6. Solve the Model and Print Results ---
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
