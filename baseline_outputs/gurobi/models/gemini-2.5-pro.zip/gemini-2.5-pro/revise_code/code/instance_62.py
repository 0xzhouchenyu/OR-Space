import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_restaurant_data(filepath):
    """Load restaurant data from the revised CSV file."""
    restaurants = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            restaurants.append({
                'name': row['Restaurant'].strip(),
                'revenue': float(row['Annual_Revenue'].strip()),
                'cost': float(row['Cost'].strip()),
                'std_hours': float(row['Standard_Staff_Hours'].strip()),
                'prem_hours': float(row['Premium_Staff_Hours'].strip())
            })
    return restaurants

def load_general_parameters(filepath):
    """Load general parameters from the revised CSV file."""
    params = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[param_name] = value
    return params

def main():
    """
    Solves the revised restaurant investment optimization problem.
    """
    # Determine data directory relative to the script location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")
    
    # Load data from CSV files
    restaurant_data_path = os.path.join(data_dir, 'table_1.csv')
    general_params_path = os.path.join(data_dir, 'general_parameters.csv')
    
    restaurants = load_restaurant_data(restaurant_data_path)
    params = load_general_parameters(general_params_path)
    
    # Extract parameters for easier access
    budget = params['investment_budget']
    staff_cap = params['staff_hours_cap']
    prem_uplift = params['premium_revenue_uplift']
    prem_cost = params['premium_upgrade_cost']
    
    # Create a Gurobi model
    m = gp.Model("RevisedRestaurantInvestment")
    
    # --- Decision Variables ---
    # For each restaurant, we have two binary decisions:
    # s[r]: 1 if we buy and operate restaurant r as Standard, 0 otherwise
    # p[r]: 1 if we buy and operate restaurant r as Premium, 0 otherwise
    
    restaurant_names = [r['name'] for r in restaurants]
    s = m.addVars(restaurant_names, vtype=GRB.BINARY, name="standard")
    p = m.addVars(restaurant_names, vtype=GRB.BINARY, name="premium")
    
    # --- Logical Constraints ---
    # For each restaurant, we can choose at most one mode (Standard or Premium).
    # If not bought, both s[r] and p[r] will be 0.
    for r_name in restaurant_names:
        m.addConstr(s[r_name] + p[r_name] <= 1, f"Mode_Exclusivity_{r_name}")
        
    # --- Objective Function: Maximize total annual revenue ---
    # Revenue is base revenue for Standard, and base * (1 + uplift) for Premium.
    total_revenue = gp.quicksum(
        r['revenue'] * s[r['name']] + r['revenue'] * (1 + prem_uplift) * p[r['name']]
        for r in restaurants
    )
    m.setObjective(total_revenue, GRB.MAXIMIZE)
    
    # --- Constraints ---
    
    # 1. Budget Constraint: Total cost (acquisition + premium upgrade) must be within budget.
    total_cost = gp.quicksum(
        r['cost'] * s[r['name']] + (r['cost'] + prem_cost) * p[r['name']]
        for r in restaurants
    )
    m.addConstr(total_cost <= budget, "Budget_Constraint")
    
    # 2. Staff Hours Constraint: Total staff hours must be within the cap.
    total_hours = gp.quicksum(
        r['std_hours'] * s[r['name']] + r['prem_hours'] * p[r['name']]
        for r in restaurants
    )
    m.addConstr(total_hours <= staff_cap, "Staff_Hours_Constraint")
    
    # 3. D & A Exclusion Constraint: If Restaurant D is purchased (in any mode), A cannot be.
    # (s_D + p_D) represents buying D. (s_A + p_A) represents buying A.
    # The sum of these two indicators must be <= 1.
    if 'Restaurant_D' in restaurant_names and 'Restaurant_A' in restaurant_names:
        m.addConstr(
            (s['Restaurant_D'] + p['Restaurant_D']) + (s['Restaurant_A'] + p['Restaurant_A']) <= 1,
            "D_A_Exclusion_Constraint"
        )
        
    # --- Solve the model ---
    m.setParam('OutputFlag', 0) # Suppress Gurobi output
    m.optimize()
    
    # --- Output Results ---
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("Optimization was not successful.")

if __name__ == "__main__":
    main()
