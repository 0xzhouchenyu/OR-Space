import gurobipy as gp
from gurobipy import GRB
import os
import csv
import math

def solve():
    """
    Solves the revised fabric dyeing scheduling problem using a Gurobi MIP model.
    """
    # --- 1. Data Loading and Pre-processing ---

    # Base directory for data files
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Load general parameters
    params = {}
    with open(os.path.join(base_dir, "data", "general_parameters.csv"), 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            params[row[0]] = float(row[1])

    T_max = int(params['planning_horizon_T'])
    energy_costs_base = {
        0: params['energy_cost_v1'],  # Vat 1 (index 0)
        1: params['energy_cost_v2'],  # Vat 2 (index 1)
        2: params['energy_cost_v3']   # Vat 3 (index 2)
    }
    peak_multiplier = params['peak_energy_multiplier']
    peak_energy_cap = params['peak_energy_cap']
    makespan_weight = params['makespan_weight']
    energy_weight = params['energy_weight']

    # Load batch processing times
    batches_list = []
    proc_times_raw = {}
    with open(os.path.join(base_dir, "data", "table_1.csv"), 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        num_vats = len(header) - 1
        for row in reader:
            batch_id = int(row[0])
            batches_list.append(batch_id)
            proc_times_raw[batch_id] = [float(t) for t in row[1:]]

    # Round up processing times to the next full time unit
    proc_times = {
        b: [math.ceil(t) for t in proc_times_raw[b]]
        for b in batches_list
    }

    # --- 2. Model Setup ---

    model = gp.Model("FabricDyeingRevised")
    model.setParam('OutputFlag', 0)

    # Define sets
    batches = batches_list
    vats = range(num_vats)
    time_periods = range(1, T_max + 1)

    # --- 3. Decision Variables ---

    # x[b, v, t]: 1 if batch b starts on vat v at time t
    x = model.addVars(batches, vats, time_periods, vtype=GRB.BINARY, name="x")

    # y[v, t]: 1 if vat v is active at time t
    y = model.addVars(vats, time_periods, vtype=GRB.BINARY, name="y")

    # C_max: Makespan (completion time of the last job)
    C_max = model.addVar(vtype=GRB.CONTINUOUS, name="C_max", lb=0)

    # --- 4. Objective Function ---

    # Calculate energy cost for each vat and time period
    peak_periods = {6, 7, 8}
    energy_cost_per_period = {
        (v, t): energy_costs_base[v] * (peak_multiplier if t in peak_periods else 1)
        for v in vats for t in time_periods
    }

    # Total energy cost expression
    total_energy_cost = gp.quicksum(
        y[v, t] * energy_cost_per_period[v, t]
        for v in vats for t in time_periods
    )

    # Set weighted objective
    model.setObjective(
        makespan_weight * C_max + energy_weight * total_energy_cost,
        GRB.MINIMIZE
    )

    # --- 5. Constraints ---

    # C1: Each batch must be processed exactly once on each vat
    for b in batches:
        for v in vats:
            model.addConstr(gp.quicksum(x[b, v, t] for t in time_periods) == 1, name=f"process_once_{b}_{v}")

    # C2: Link active state (y) to start times (x) and enforce vat capacity
    for v in vats:
        for t in time_periods:
            active_jobs_at_t = gp.quicksum(
                x[b, v, t_start]
                for b in batches
                for t_start in time_periods
                if t_start <= t < t_start + proc_times[b][v]
            )
            model.addConstr(y[v, t] == active_jobs_at_t, name=f"link_y_{v}_{t}")

    # C3: Precedence constraint (flow shop)
    for b in batches:
        for v in range(num_vats - 1):
            start_time_v = gp.quicksum(t * x[b, v, t] for t in time_periods)
            start_time_v_plus_1 = gp.quicksum(t * x[b, v + 1, t] for t in time_periods)
            # Next operation can start in the same period the previous one ends
            model.addConstr(start_time_v_plus_1 >= start_time_v + proc_times[b][v] - 1, name=f"precedence_{b}_{v}")

    # C4: Maintenance window on Vat 2 (index 1) during periods 4-5
    maint_vat_idx = 1
    for b in batches:
        p_b_maint = proc_times[b][maint_vat_idx]
        for t in time_periods:
            # A start at 't' is allowed only if it finishes by period 3 OR starts at period 6 or later
            is_before = (t + p_b_maint - 1 <= 3)
            is_after = (t >= 6)
            if not (is_before or is_after):
                # This start time is forbidden, fix variable to 0
                model.addConstr(x[b, maint_vat_idx, t] == 0, name=f"maint_{b}_{t}")

    # C5: Makespan definition
    last_vat_idx = num_vats - 1
    for b in batches:
        start_time_last_vat = gp.quicksum(t * x[b, last_vat_idx, t] for t in time_periods)
        # Makespan is the index of the last period a job is active
        completion_period = start_time_last_vat + proc_times[b][last_vat_idx] - 1
        model.addConstr(C_max >= completion_period, name=f"makespan_{b}")

    # C6: Peak energy consumption cap
    peak_energy_usage = gp.quicksum(
        y[v, t] * energy_cost_per_period[v, t]
        for v in vats for t in peak_periods
    )
    model.addConstr(peak_energy_usage <= peak_energy_cap, name="peak_cap")

    # --- 6. Solve and Output ---

    model.optimize()

    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # This part is for robustness in case a solution isn't found
        print("FINAL_OBJ_VALUE: Error - No optimal solution found")


if __name__ == '__main__':
    solve()
