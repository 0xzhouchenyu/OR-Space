import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve_revised_problem():
    """
    Formulates and solves the revised fertilizer production optimization problem.
    """
    # --- 1. Load Data ---
    try:
        data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
        params_path = os.path.join(data_dir, 'general_parameters.csv')
        params = load_general_parameters(params_path)
    except FileNotFoundError:
        # Fallback for different execution environments
        data_dir = "data"
        params_path = os.path.join(data_dir, 'general_parameters.csv')
        params = load_general_parameters(params_path)


    # --- 2. Extract Parameters ---
    # Production times (minutes per lot)
    m1_liquid_time = params['machine_1_time_per_liquid_lot']
    m2_liquid_time = params['machine_2_time_per_liquid_lot']
    m1_solid_time = params['machine_1_time_per_solid_lot']
    m2_solid_time = params['machine_2_time_per_solid_lot']

    # Initial inventories (lots)
    init_liquid_inv = params['initial_liquid_inventory']
    init_solid_inv = params['initial_solid_inventory']

    # Machine availability (minutes)
    m1_base_avail = params['machine_1_available_time'] * 60
    m2_base_avail = params['machine_2_available_time'] * 60
    extended_extra_mins = params['extended_extra_minutes']

    # Demand (lots)
    demand_liquid = params['forecast_liquid_demand']
    demand_solid = params['forecast_solid_demand']

    # Labor parameters
    labor_per_ext = params['labor_hours_per_machine_extended']
    labor_budget = params['labor_budget_hours']

    # Objective function parameters
    penalty_per_ext = params['extended_mode_penalty']
    prio_reserve_lots = params['priority_reserve_lots']
    excess_credit = params['excess_reserve_credit']

    # --- 3. Create Gurobi Model ---
    model = gp.Model("RevisedFertilizerProduction")
    model.setParam('OutputFlag', 0)

    # --- 4. Define Decision Variables ---
    # Production quantities (continuous)
    x_l = model.addVar(name="prod_liquid", lb=0.0)
    x_s = model.addVar(name="prod_solid", lb=0.0)

    # Extended mode usage (binary)
    y_1 = model.addVar(name="ext_machine_1", vtype=GRB.BINARY)
    y_2 = model.addVar(name="ext_machine_2", vtype=GRB.BINARY)

    # Ending inventory variables (continuous)
    end_l = model.addVar(name="end_inv_liquid", lb=0.0)
    end_s = model.addVar(name="end_inv_solid", lb=0.0)

    # Piecewise inventory variables for the objective function
    end_l_prio = model.addVar(name="end_inv_liquid_prio", lb=0.0, ub=prio_reserve_lots)
    end_l_excess = model.addVar(name="end_inv_liquid_excess", lb=0.0)
    end_s_prio = model.addVar(name="end_inv_solid_prio", lb=0.0, ub=prio_reserve_lots)
    end_s_excess = model.addVar(name="end_inv_solid_excess", lb=0.0)

    # --- 5. Define Constraints ---
    # Inventory balance equations
    model.addConstr(end_l == init_liquid_inv + x_l - demand_liquid, "liquid_balance")
    model.addConstr(end_s == init_solid_inv + x_s - demand_solid, "solid_balance")

    # Machine time capacity constraints
    model.addConstr(m1_liquid_time * x_l + m1_solid_time * x_s <= m1_base_avail + extended_extra_mins * y_1, "machine_1_capacity")
    model.addConstr(m2_liquid_time * x_l + m2_solid_time * x_s <= m2_base_avail + extended_extra_mins * y_2, "machine_2_capacity")

    # Skilled labor budget constraint
    model.addConstr(labor_per_ext * y_1 + labor_per_ext * y_2 <= labor_budget, "labor_budget")

    # Piecewise inventory decomposition
    model.addConstr(end_l == end_l_prio + end_l_excess, "liquid_prio_split")
    model.addConstr(end_s == end_s_prio + end_s_excess, "solid_prio_split")

    # --- 6. Set Objective Function ---
    # Maximize the resilience score
    inventory_score = (1.0 * end_l_prio + excess_credit * end_l_excess) + \
                      (1.0 * end_s_prio + excess_credit * end_s_excess)
    
    extension_penalty = penalty_per_ext * y_1 + penalty_per_ext * y_2

    model.setObjective(inventory_score - extension_penalty, GRB.MAXIMIZE)

    # --- 7. Solve and Output ---
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal:.4f}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_revised_problem()
