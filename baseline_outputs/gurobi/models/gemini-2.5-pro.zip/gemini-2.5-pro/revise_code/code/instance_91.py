import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_parameters(filepath):
    """Load general parameters from CSV file and return as a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value_str = row['Value'].strip()
            
            # Handle ratio values like "5:2"
            if ':' in value_str:
                parts = value_str.split(':')
                params[name] = (int(parts[0]), int(parts[1]))
            else:
                try:
                    value = int(value_str)
                except ValueError:
                    try:
                        value = float(value_str)
                    except ValueError:
                        value = value_str
                params[name] = value
    return params

def main():
    """
    Builds and solves the revised optimization problem using Gurobi.
    """
    # --- 1. Load Data ---
    try:
        data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
        params = load_parameters(data_path)
    except FileNotFoundError:
        print(f"Error: Data file not found at {data_path}")
        return

    # --- 2. Extract Parameters ---
    # Profit
    profit_A = params['profit_product_A']
    profit_B = params['profit_product_B']
    
    # Assembly Time
    assembly_time_A = params['assembly_time_A']
    assembly_time_B = params['assembly_time_B']
    
    # Machine Time
    machine_working_time_hours = params['machine_working_time']
    machine_working_time_minutes = machine_working_time_hours * 60
    
    # Production Ratio
    ratio_tuple = params['production_ratio_A_to_B']
    ratio_A_val = ratio_tuple[0]
    ratio_B_val = ratio_tuple[1]
    
    # Overtime Parameters
    max_overtime_hours = params['max_overtime_hours']
    overtime_penalty_per_hour = params['overtime_penalty_per_hour']
    overtime_review_threshold_hours = params['overtime_review_threshold_hours']
    overtime_review_fee = params['overtime_review_fee']
    
    # Product A Senior Batch Parameters
    product_A_senior_batch_threshold = params['product_A_senior_batch_threshold']
    product_A_senior_batch_fee = params['product_A_senior_batch_fee']

    # --- 3. Create Gurobi Model ---
    m = gp.Model("RevisedProductMix")
    m.setParam('OutputFlag', 0)

    # --- 4. Define Decision Variables ---
    # Production quantities (continuous)
    A = m.addVar(name="Product_A", vtype=GRB.CONTINUOUS, lb=0)
    B = m.addVar(name="Product_B", vtype=GRB.CONTINUOUS, lb=0)
    
    # Overtime hours (continuous)
    T_over = m.addVar(name="Overtime_Hours", vtype=GRB.CONTINUOUS, lb=0, ub=max_overtime_hours)
    
    # Binary variables for fixed costs/fees
    y_A_fee = m.addVar(name="Exceeds_A_Threshold", vtype=GRB.BINARY)
    y_overtime_fee = m.addVar(name="Exceeds_Overtime_Threshold", vtype=GRB.BINARY)

    # --- 5. Set Objective Function ---
    # Maximize: Profit - Overtime Costs - Fixed Fees
    objective_expr = (profit_A * A + profit_B * B) \
                     - (overtime_penalty_per_hour * T_over) \
                     - (product_A_senior_batch_fee * y_A_fee) \
                     - (overtime_review_fee * y_overtime_fee)
    
    m.setObjective(objective_expr, GRB.MAXIMIZE)

    # --- 6. Add Constraints ---
    # Constraint 1: Machine Time
    # Total assembly time <= regular time + overtime (in minutes)
    m.addConstr(
        assembly_time_A * A + assembly_time_B * B <= machine_working_time_minutes + T_over * 60,
        "Machine_Time"
    )
    
    # Constraint 2: Production Ratio
    # B >= (ratio_B/ratio_A)*A  =>  ratio_A*B >= ratio_B*A  =>  ratio_B*A - ratio_A*B <= 0
    m.addConstr(
        ratio_B_val * A - ratio_A_val * B <= 0,
        "Production_Ratio"
    )
    
    # Constraint 3: Product A Senior Batch Fee Trigger (Big-M)
    # If A > threshold, y_A_fee must be 1.
    # A - threshold <= M * y_A_fee
    # Calculate a tight M: Max A is (1800 + 15*60) / 12 = 2700 / 12 = 225.
    # So, max (A - threshold) is 225 - 100 = 125.
    M1 = 125 
    m.addConstr(
        A - product_A_senior_batch_threshold <= M1 * y_A_fee,
        "Product_A_Fee_Trigger"
    )
    
    # Constraint 4: Overtime Review Fee Trigger (Big-M)
    # If T_over > threshold, y_overtime_fee must be 1.
    # T_over - threshold <= M * y_overtime_fee
    # Calculate a tight M: Max T_over is 15.
    # So, max (T_over - threshold) is 15 - 10 = 5.
    M2 = 5
    m.addConstr(
        T_over - overtime_review_threshold_hours <= M2 * y_overtime_fee,
        "Overtime_Fee_Trigger"
    )

    # --- 7. Solve and Print Output ---
    m.optimize()
    
    if m.status == GRB.OPTIMAL:
        final_obj_value = m.ObjVal
    else:
        # Fallback in case of non-optimal solution
        final_obj_value = 0.0

    print(f"FINAL_OBJ_VALUE: {final_obj_value:.1f}")

if __name__ == "__main__":
    main()
