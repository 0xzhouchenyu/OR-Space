import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    Solves the revised motorcycle production planning problem.
    """
    # --- Data Loading and Parsing ---
    # Define paths relative to the script's location
    try:
        data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
        table_1_path = os.path.join(data_dir, "table_1.csv")
        params_path = os.path.join(data_dir, "general_parameters.csv")

        # Read CSVs
        df1 = pd.read_csv(table_1_path)
        df_params = pd.read_csv(params_path).set_index('Parameter_Name')['Value']
    except FileNotFoundError as e:
        print(f"Error: Data file not found. {e}")
        return

    # Parse Table 1 for base parameters
    row_a = df1[df1['Type'] == 'Type_A'].iloc[0]
    row_b = df1[df1['Type'] == 'Type_B'].iloc[0]
    row_cap = df1[df1['Type'] == 'Max_weekly_capacity'].iloc[0]
    row_cost = df1[df1['Type'] == 'Process_cost_Yuan_per_hour'].iloc[0]

    mfg_a = float(row_a['Manufacturing_hours_per_unit'])
    asm_a = float(row_a['Assembly_hours_per_unit'])
    price_a = float(row_a['Selling_Price_Yuan_per_unit'])

    mfg_b = float(row_b['Manufacturing_hours_per_unit'])
    asm_b = float(row_b['Assembly_hours_per_unit'])
    price_b = float(row_b['Selling_Price_Yuan_per_unit'])

    cap_mfg = float(row_cap['Manufacturing_hours_per_unit'])
    cap_asm = float(row_cap['Assembly_hours_per_unit'])
    cap_insp = float(row_cap['Inspection_hours_per_unit'])

    cost_mfg = float(row_cost['Manufacturing_hours_per_unit'])
    cost_asm = float(row_cost['Assembly_hours_per_unit'])

    # Parse General Parameters for revised logic
    min_weekly_profit = float(df_params['min_weekly_profit'])
    min_type_a_production = float(df_params['min_type_a_production'])
    planning_horizon_weeks = int(df_params['planning_horizon_weeks'])
    
    insp_a_M = float(df_params['insp_a_M'])
    insp_b_M = float(df_params['insp_b_M'])
    insp_a_E = float(df_params['insp_a_E'])
    insp_b_E = float(df_params['insp_b_E'])
    
    cap_ext = float(df_params['cap_ext'])
    
    cost_insp_M = float(df_params['cost_insp_M'])
    cost_insp_E = float(df_params['cost_insp_E'])
    cost_ext = float(df_params['cost_ext'])
    
    mode_fee_M = float(df_params['mode_fee_M'])
    mode_fee_E = float(df_params['mode_fee_E'])
    
    risk_penalty_M = float(df_params['risk_penalty_M'])
    cost_insp_weight = float(df_params['cost_insp_weight'])
    idle_tolerance = float(df_params['idle_tolerance'])

    # --- Model Initialization ---
    model = gp.Model("MotorcycleProductionRevised")
    model.setParam('OutputFlag', 0)

    weeks = range(planning_horizon_weeks)

    # --- Decision Variables ---
    x_A = model.addVars(weeks, vtype=GRB.INTEGER, name="x_A", lb=0)
    x_B = model.addVars(weeks, vtype=GRB.INTEGER, name="x_B", lb=0)
    
    y_M = model.addVars(weeks, vtype=GRB.BINARY, name="y_M")
    y_E = model.addVars(weeks, vtype=GRB.BINARY, name="y_E")

    # Auxiliary variables for Enhanced mode inspection
    insp_inhouse_E = model.addVars(weeks, vtype=GRB.CONTINUOUS, name="insp_inhouse_E", lb=0)
    insp_external_E = model.addVars(weeks, vtype=GRB.CONTINUOUS, name="insp_external_E", lb=0)

    # Auxiliary variables for objectives
    used_insp_inhouse = model.addVars(weeks, vtype=GRB.CONTINUOUS, name="used_insp_inhouse", lb=0)
    weekly_profit = model.addVars(weeks, vtype=GRB.CONTINUOUS, name="weekly_profit", lb=-GRB.INFINITY)

    # --- Constraints ---
    for t in weeks:
        # Mode selection: exactly one mode per week
        model.addConstr(y_M[t] + y_E[t] == 1, name=f"mode_selection_{t}")

        # Minimum production of Type A
        model.addConstr(x_A[t] >= min_type_a_production, name=f"min_prod_A_{t}")

        # Capacity constraints
        model.addConstr(mfg_a * x_A[t] + mfg_b * x_B[t] <= cap_mfg, name=f"cap_mfg_{t}")
        model.addConstr(asm_a * x_A[t] + asm_b * x_B[t] <= cap_asm, name=f"cap_asm_{t}")

        # Inspection constraints (mode-dependent)
        # Manual mode
        model.addGenConstrIndicator(y_M[t], True,
            insp_a_M * x_A[t] + insp_b_M * x_B[t] <= cap_insp,
            name=f"insp_cap_M_{t}")

        # Enhanced mode
        insp_demand_E = insp_a_E * x_A[t] + insp_b_E * x_B[t]
        model.addGenConstrIndicator(y_E[t], True,
            insp_inhouse_E[t] + insp_external_E[t] == insp_demand_E,
            name=f"insp_demand_E_met_{t}")
        
        model.addConstr(insp_inhouse_E[t] <= cap_insp * y_E[t], name=f"cap_inhouse_E_{t}")
        model.addConstr(insp_external_E[t] <= cap_ext * y_E[t], name=f"cap_external_E_{t}")

        # Profit constraints and definitions (mode-dependent)
        revenue = price_a * x_A[t] + price_b * x_B[t]
        cost_mfg_asm = (mfg_a * cost_mfg + asm_a * cost_asm) * x_A[t] + (asm_b * cost_asm) * x_B[t]

        # Profit expression for Manual mode
        cost_insp_M_var = (insp_a_M * cost_insp_M) * x_A[t] + (insp_b_M * cost_insp_M) * x_B[t]
        profit_M = revenue - cost_mfg_asm - cost_insp_M_var - mode_fee_M
        model.addGenConstrIndicator(y_M[t], True, profit_M >= min_weekly_profit, name=f"min_profit_M_{t}")

        # Profit expression for Enhanced mode
        cost_insp_E_var = insp_inhouse_E[t] * cost_insp_E + insp_external_E[t] * cost_ext
        profit_E = revenue - cost_mfg_asm - cost_insp_E_var - mode_fee_E
        model.addGenConstrIndicator(y_E[t], True, profit_E >= min_weekly_profit, name=f"min_profit_E_{t}")

        # Link auxiliary variables for objectives
        # Used in-house inspection hours
        model.addGenConstrIndicator(y_M[t], True,
            used_insp_inhouse[t] == insp_a_M * x_A[t] + insp_b_M * x_B[t],
            name=f"link_used_insp_M_{t}")
        model.addGenConstrIndicator(y_E[t], True,
            used_insp_inhouse[t] == insp_inhouse_E[t],
            name=f"link_used_insp_E_{t}")

        # Weekly profit
        model.addGenConstrIndicator(y_M[t], True, weekly_profit[t] == profit_M, name=f"link_profit_M_{t}")
        model.addGenConstrIndicator(y_E[t], True, weekly_profit[t] == profit_E, name=f"link_profit_E_{t}")

    # --- Lexicographic Optimization ---

    # == Step 1: Minimize Idle Cost + Risk Penalty ==
    
    # Define Idle Cost Objective Expression
    idle_mfg_cost = gp.quicksum(cost_mfg * (cap_mfg - (mfg_a * x_A[t] + mfg_b * x_B[t])) for t in weeks)
    idle_asm_cost = gp.quicksum(cost_asm * (cap_asm - (asm_a * x_A[t] + asm_b * x_B[t])) for t in weeks)
    idle_insp_cost = gp.quicksum(cost_insp_weight * (cap_insp - used_insp_inhouse[t]) for t in weeks)
    risk_penalty_cost = gp.quicksum(risk_penalty_M * y_M[t] for t in weeks)
    
    primary_objective = idle_mfg_cost + idle_asm_cost + idle_insp_cost + risk_penalty_cost
    
    model.setObjective(primary_objective, GRB.MINIMIZE)
    model.optimize()
    
    if model.Status != GRB.OPTIMAL:
        # In a real scenario, handle infeasibility or other statuses
        print("FINAL_OBJ_VALUE: Infeasible")
        return

    min_idle_cost_val = model.ObjVal

    # == Step 2: Maximize Total Profit subject to minimal idle cost ==
    
    # Add constraint for minimal idle cost
    model.addConstr(primary_objective <= min_idle_cost_val + idle_tolerance, name="lexicographic_constraint")

    # Define and set secondary objective
    secondary_objective = gp.quicksum(weekly_profit[t] for t in weeks)
    model.setObjective(secondary_objective, GRB.MAXIMIZE)
    
    model.optimize()

    if model.Status != GRB.OPTIMAL:
        print("FINAL_OBJ_VALUE: Infeasible")
        return

    final_obj_val = model.ObjVal
    print(f"FINAL_OBJ_VALUE: {round(final_obj_val, 4)}")


if __name__ == '__main__':
    solve()
