import gurobipy as gp
from gurobipy import GRB
import csv
import math
import os

def get_data_path(filename):
    """
    Constructs the full path to a data file, assuming the script is run from the workspace root
    and data files are in a 'data' subdirectory.
    """
    # Per instructions, the script is executed from the root directory.
    # The path is relative to the script's location.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(script_dir, "data", filename)

def solve():
    """
    Reads the problem data, formulates the MIP, solves it, and prints the objective value.
    """
    # --- 1. Read Data ---
    
    # Read orders from table_1.csv
    table_1_path = get_data_path('table_1.csv')
    orders = []
    with open(table_1_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            orders.append({
                'width': float(row['Width_meters']),
                'length': float(row['Length_meters'])
            })
    
    required_widths = [o['width'] for o in orders]
    required_lengths = [o['length'] for o in orders]

    # Read parameters from general_parameters.csv
    params_path = get_data_path('general_parameters.csv')
    params = {}
    with open(params_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    std_widths = sorted([v for k, v in params.items() if 'standard_width' in k])
    pattern_setup_penalty = params['pattern_setup_penalty']
    wide_roll_threshold_width = params['wide_roll_threshold_width']
    wide_roll_extra_setup_penalty = params['wide_roll_extra_setup_penalty']

    # --- 2. Generate Patterns ---
    
    all_patterns_data = []
    for sw in std_widths:
        # Using a recursive function to find all valid patterns for a given standard width
        def find_patterns_recursive(index, current_pattern, current_width_sum):
            if index == len(required_widths):
                # A pattern is valid if it uses at least one cut
                if any(c > 0 for c in current_pattern):
                    all_patterns_data.append({'sw': sw, 'pattern': current_pattern})
                return

            # Determine max number of cuts for the current required_width
            # Use a small epsilon for float comparisons
            max_cuts = int((sw - current_width_sum + 1e-9) / required_widths[index])
            
            for num_cuts in range(max_cuts + 1):
                new_pattern = current_pattern + [num_cuts]
                new_width_sum = current_width_sum + num_cuts * required_widths[index]
                find_patterns_recursive(index + 1, new_pattern, new_width_sum)

        find_patterns_recursive(0, [], 0.0)

    # --- 3. Create Gurobi Model ---
    
    model = gp.Model("revised_cutting_stock")
    model.setParam('OutputFlag', 0)

    num_patterns = len(all_patterns_data)

    # --- 4. Define Variables ---
    
    # x[i]: length of stock roll cut using pattern i
    x = model.addVars(num_patterns, vtype=GRB.CONTINUOUS, name="x")
    # y[i]: binary variable, 1 if pattern i is used, 0 otherwise
    y = model.addVars(num_patterns, vtype=GRB.BINARY, name="y")

    # --- 5. Set Objective Function ---
    
    # The objective is to minimize total area used + penalties
    total_area_used = gp.quicksum(
        all_patterns_data[i]['sw'] * x[i] for i in range(num_patterns)
    )
    
    total_setup_penalty = gp.quicksum(
        pattern_setup_penalty * y[i] for i in range(num_patterns)
    )
    
    total_wide_roll_penalty = gp.quicksum(
        wide_roll_extra_setup_penalty * y[i] 
        for i in range(num_patterns) 
        if all_patterns_data[i]['sw'] >= wide_roll_threshold_width
    )

    model.setObjective(
        total_area_used + total_setup_penalty + total_wide_roll_penalty, 
        GRB.MINIMIZE
    )

    # --- 6. Add Constraints ---
    
    # Demand satisfaction constraints
    for j in range(len(required_widths)): # for each required width
        model.addConstr(
            gp.quicksum(all_patterns_data[i]['pattern'][j] * x[i] for i in range(num_patterns)) >= required_lengths[j],
            name=f"demand_{j}"
        )

    # Linking constraints (Big-M)
    # A safe upper bound for any x[i] is the maximum required length.
    M = max(required_lengths) if required_lengths else 1
    for i in range(num_patterns):
        model.addConstr(x[i] <= M * y[i], name=f"link_{i}")

    # --- 7. Solve and Output ---
    
    model.optimize()

    if model.Status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("FINAL_OBJ_VALUE: Error - No optimal solution found.")

if __name__ == "__main__":
    solve()
