import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    Loads data, formulates, and solves the candy factory optimization problem.
    """
    # --- Data Loading ---
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Load general parameters from general_parameters.csv
    params = {}
    gen_params_path = os.path.join(base_dir, "data", "general_parameters.csv")
    with open(gen_params_path, 'r', newline='') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if row:
                params[row[0]] = float(row[1])

    # Load table data from table_1_7.csv
    table_data = []
    table_path = os.path.join(base_dir, "data", "table_1_7.csv")
    with open(table_path, 'r', newline='') as f:
        reader = csv.reader(f)
        next(reader) # Skip header
        for row in reader:
            table_data.append(row)

    # --- Parameter Extraction ---
    # Raw materials: 0=A, 1=B, 2=C
    # Brands: 0=A, 1=B, 2=C
    raw_cost = [float(table_data[0][4]), float(table_data[1][4]), float(table_data[2][4])]
    limits = [float(table_data[0][5]), float(table_data[1][5]), float(table_data[2][5])]
    proc_fee = [float(table_data[3][1]), float(table_data[3][2]), float(table_data[3][3])]
    sell_price = [float(table_data[4][1]), float(table_data[4][2]), float(table_data[4][3])]

    setup_costs = [params['SetupCost_A'], params['SetupCost_B'], params['SetupCost_C']]
    shared_wrapper_fee = params['BrandAB_SharedWrapper_Fee']
    
    # --- Model Formulation ---
    model = gp.Model("CandyFactoryRevised")
    model.setParam('OutputFlag', 0)

    num_raw_materials = 3
    num_brands = 3
    
    # --- Decision Variables ---
    # x[i,j]: amount of raw material i in brand j
    x = model.addVars(num_raw_materials, num_brands, vtype=GRB.CONTINUOUS, name="x", lb=0)
    
    # y[j]: total production of brand j
    y = model.addVars(num_brands, vtype=GRB.CONTINUOUS, name="y", lb=0)
    
    # z[j]: binary variable, 1 if brand j is produced, 0 otherwise
    z = model.addVars(num_brands, vtype=GRB.BINARY, name="z")
    
    # w_ab: binary variable, 1 if both brand A and B are produced
    w_ab = model.addVar(vtype=GRB.BINARY, name="w_ab")

    # --- Objective Function ---
    revenue = gp.quicksum(sell_price[j] * y[j] for j in range(num_brands))
    material_cost = gp.quicksum(raw_cost[i] * x[i, j] for i in range(num_raw_materials) for j in range(num_brands))
    processing_cost = gp.quicksum(proc_fee[j] * y[j] for j in range(num_brands))
    
    fixed_setup_costs = gp.quicksum(setup_costs[j] * z[j] for j in range(num_brands))
    shared_cost = shared_wrapper_fee * w_ab
    
    total_profit = revenue - material_cost - processing_cost - fixed_setup_costs - shared_cost
    model.setObjective(total_profit, GRB.MAXIMIZE)

    # --- Constraints ---
    # Total production of each brand is the sum of its raw materials
    model.addConstrs((y[j] == gp.quicksum(x[i, j] for i in range(num_raw_materials)) for j in range(num_brands)), name="total_production")

    # Raw material supply constraints
    model.addConstrs((gp.quicksum(x[i, j] for j in range(num_brands)) <= limits[i] for i in range(num_raw_materials)), name="raw_material_limits")

    # Composition constraints (percentage constraints)
    # Raw material A (i=0)
    model.addConstr(x[0, 0] >= 0.60 * y[0], name="RM_A_in_Brand_A")
    model.addConstr(x[0, 1] >= 0.15 * y[1], name="RM_A_in_Brand_B")
    
    # Raw material C (i=2)
    model.addConstr(x[2, 0] <= 0.20 * y[0], name="RM_C_in_Brand_A")
    model.addConstr(x[2, 1] <= 0.60 * y[1], name="RM_C_in_Brand_B")
    model.addConstr(x[2, 2] <= 0.50 * y[2], name="RM_C_in_Brand_C")

    # Linking production quantity (y) with production decision (z) using Big-M
    M = sum(limits)
    model.addConstrs((y[j] <= M * z[j] for j in range(num_brands)), name="big_m_linking")

    # Constraints for the shared wrapper cost
    # w_ab = 1 if z[0]=1 and z[1]=1
    model.addConstr(w_ab >= z[0] + z[1] - 1, name="shared_cost_logic1")
    model.addConstr(w_ab <= z[0], name="shared_cost_logic2")
    model.addConstr(w_ab <= z[1], name="shared_cost_logic3")

    # --- Solve and Output ---
    model.optimize()
    
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
