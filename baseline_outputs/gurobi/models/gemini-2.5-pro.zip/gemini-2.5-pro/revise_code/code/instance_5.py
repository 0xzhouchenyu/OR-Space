import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    """
    Solves the revised dinner planning problem for Mary.
    """
    # --- Load Data ---
    # Construct absolute paths to data files
    workspace_dir = os.path.dirname(os.path.abspath(__file__))
    table_1_path = os.path.join(workspace_dir, "data", "table_1.csv")
    params_path = os.path.join(workspace_dir, "data", "general_parameters.csv")

    # Read data into pandas DataFrames
    df_foods = pd.read_csv(table_1_path)
    df_params = pd.read_csv(params_path)

    # --- Pre-process Data ---
    # Convert parameters dataframe to a dictionary for easy access
    params = df_params.set_index('Parameter_Name')['Value'].to_dict()

    # Extract general parameters
    total_budget = params['budget']
    food_intake = params['food_intake']
    weekday_budget_share = params['weekday_budget_share']
    max_prep_time_weekday = params['max_prep_time_weekday']
    max_prep_time_weekend = params['max_prep_time_weekend']
    weekend_protein_ban = params['weekend_protein_ban']
    veg_balance_penalty = params['veg_balance_penalty']

    # Calculate per-scenario budgets
    weekday_budget = total_budget * weekday_budget_share
    weekend_budget = total_budget * (1 - weekday_budget_share)

    # Fill missing fiber content with 0 (for proteins)
    df_foods['Fiber_Content_per_100g'] = df_foods['Fiber_Content_per_100g'].fillna(0)

    # Create lists and dictionaries for model construction
    foods = df_foods['Food'].tolist()
    proteins = df_foods[df_foods['Type'] == 'protein']['Food'].tolist()
    vegetables = df_foods[df_foods['Type'] == 'vegetable']['Food'].tolist()

    fiber = df_foods.set_index('Food')['Fiber_Content_per_100g'].to_dict()
    price = df_foods.set_index('Food')['Price_per_100g'].to_dict()
    prep_time = df_foods.set_index('Food')['prep_time_per_100g'].to_dict()

    scenarios = ['weekday', 'weekend']

    # --- Create Model ---
    m = gp.Model("RevisedDinnerPlan")
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # y[f]: Binary, 1 if food f is selected for the shopping list
    y = m.addVars(foods, vtype=GRB.BINARY, name="y")

    # x[f, s]: Continuous, amount of food f (in 100g units) for scenario s
    x = m.addVars(foods, scenarios, vtype=GRB.CONTINUOUS, name="x")

    # d[v]: Continuous, absolute deviation in vegetable v amount between scenarios
    d = m.addVars(vegetables, vtype=GRB.CONTINUOUS, name="d")

    # --- Objective Function ---
    # Maximize total fiber minus the vegetable balance penalty
    total_fiber = gp.quicksum(fiber[f] * x[f, s] for f in foods for s in scenarios)
    balance_penalty = veg_balance_penalty * gp.quicksum(d[v] for v in vegetables)
    m.setObjective(total_fiber - balance_penalty, GRB.MAXIMIZE)

    # --- Constraints ---
    # Food intake constraint for each scenario (in 100g units)
    m.addConstr(gp.quicksum(x[f, 'weekday'] for f in foods) == food_intake / 100.0, "intake_weekday")
    m.addConstr(gp.quicksum(x[f, 'weekend'] for f in foods) == food_intake / 100.0, "intake_weekend")

    # Budget constraints for each scenario
    m.addConstr(gp.quicksum(price[f] * x[f, 'weekday'] for f in foods) <= weekday_budget, "budget_weekday")
    m.addConstr(gp.quicksum(price[f] * x[f, 'weekend'] for f in foods) <= weekend_budget, "budget_weekend")

    # Preparation time constraints for each scenario
    m.addConstr(gp.quicksum(prep_time[f] * x[f, 'weekday'] for f in foods) <= max_prep_time_weekday, "prep_weekday")
    m.addConstr(gp.quicksum(prep_time[f] * x[f, 'weekend'] for f in foods) <= max_prep_time_weekend, "prep_weekend")

    # Shopping logic: Choose exactly one protein and at least two vegetables
    m.addConstr(gp.quicksum(y[p] for p in proteins) == 1, "one_protein")
    m.addConstr(gp.quicksum(y[v] for v in vegetables) >= 2, "min_two_veg")

    # Linking constraints: connect shopping choice (y) with consumption (x)
    M = food_intake / 100.0  # A safe big-M value
    for f in foods:
        # Can only use a food if it was selected
        m.addConstr(x[f, 'weekday'] <= M * y[f], f"link_up_{f}_weekday")
        m.addConstr(x[f, 'weekend'] <= M * y[f], f"link_up_{f}_weekend")

        # If a food is selected, a minimum total amount must be used (e.g., 10g)
        # This also enforces that y[f] must be 1 if x is positive.
        m.addConstr(x[f, 'weekday'] + x[f, 'weekend'] >= 0.1 * y[f], f"link_down_{f}")

    # Weekend protein ban
    if weekend_protein_ban == 1:
        m.addConstr(gp.quicksum(x[p, 'weekend'] for p in proteins) == 0, "weekend_protein_ban")

    # Vegetable balance penalty linearization: d[v] = |x[v, weekday] - x[v, weekend]|
    for v in vegetables:
        m.addConstr(d[v] >= x[v, 'weekday'] - x[v, 'weekend'], f"abs_bal_1_{v}")
        m.addConstr(d[v] >= x[v, 'weekend'] - x[v, 'weekday'], f"abs_bal_2_{v}")

    # --- Solve ---
    m.optimize()

    # --- Return Objective Value ---
    if m.Status == GRB.OPTIMAL:
        return m.ObjVal
    else:
        return "No optimal solution found"

if __name__ == '__main__':
    objective_value = solve()
    print(f"FINAL_OBJ_VALUE: {objective_value}")
