import os
import pandas as pd
import gurobipy as gp
from gurobipy import GRB

def solve():
    """
    Solves the revised steel bar cutting stock problem.
    """
    # --- 1. Load Data ---
    # Construct the path to the data file relative to the script's location
    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
    df = pd.read_csv(data_path)

    # Create a dictionary of parameters for easy access
    params = {row['Parameter_Name']: row['Value'] for _, row in df.iterrows()}

    q3 = int(params['batch_3m_quantity'])
    q4 = int(params['batch_4m_quantity'])
    q5 = int(params['batch_5m_quantity'])
    L = int(params['raw_bar_length'])
    C_setup = float(params['setup_cost_per_pattern'])
    P_max = int(params['max_distinct_patterns'])

    # Define the lengths of the required steel bars
    len1, len2, len3 = 3, 4, 5
    demands = {len1: q3, len2: q4, len3: q5}
    lengths = [len1, len2, len3]

    # --- 2. Generate Cutting Patterns ---
    # A pattern is a tuple (x, y, z) representing the number of pieces of each length.
    patterns = []
    for x in range(L // len1 + 1):
        for y in range(L // len2 + 1):
            for z in range(L // len3 + 1):
                if len1 * x + len2 * y + len3 * z <= L:
                    # Only include non-empty patterns
                    if x > 0 or y > 0 or z > 0:
                        patterns.append((x, y, z))
    
    num_patterns = len(patterns)

    # --- 3. Create Gurobi Model ---
    m = gp.Model("RevisedCuttingStock")
    m.setParam('OutputFlag', 0)

    # --- 4. Add Variables ---
    # N[i]: Integer variable for the number of times pattern i is used.
    N = m.addVars(num_patterns, vtype=GRB.INTEGER, name="N")
    # U[i]: Binary variable, 1 if pattern i is used (N[i] > 0), 0 otherwise.
    U = m.addVars(num_patterns, vtype=GRB.BINARY, name="U")

    # --- 5. Set Objective Function ---
    # The objective is to minimize total waste. This is equivalent to minimizing
    # the total length of raw material used plus the setup costs, since the
    # length of required material is a constant.
    total_material_length = gp.quicksum(L * N[i] for i in range(num_patterns))
    total_setup_cost = gp.quicksum(C_setup * U[i] for i in range(num_patterns))
    m.setObjective(total_material_length + total_setup_cost, GRB.MINIMIZE)

    # --- 6. Add Constraints ---
    # Demand constraints: ensure enough pieces of each length are produced.
    m.addConstr(gp.quicksum(patterns[i][0] * N[i] for i in range(num_patterns)) >= q3, "demand_3m")
    m.addConstr(gp.quicksum(patterns[i][1] * N[i] for i in range(num_patterns)) >= q4, "demand_4m")
    m.addConstr(gp.quicksum(patterns[i][2] * N[i] for i in range(num_patterns)) >= q5, "demand_5m")

    # Pattern usage limit: no more than P_max distinct patterns can be used.
    m.addConstr(gp.quicksum(U[i] for i in range(num_patterns)) <= P_max, "max_patterns")

    # Linking constraints (Big-M formulation): If N[i] > 0, then U[i] must be 1.
    # A safe upper bound for any N[i] is the total number of pieces required.
    M = q3 + q4 + q5
    for i in range(num_patterns):
        m.addConstr(N[i] <= M * U[i], f"link_{i}")

    # --- 7. Solve the Model ---
    m.optimize()

    # --- 8. Calculate and Print Final Objective Value ---
    if m.status == GRB.OPTIMAL:
        # The model's objective value is: (Total Raw Length Used) + (Total Setup Cost)
        # The total waste is this value minus the length of the required pieces.
        # Total Waste = (Cutting Waste + Overproduction Waste) + Setup Waste
        # Total Waste = (Total Raw Length Used - Required Length) + Setup Waste
        # Total Waste = (Model Objective) - Required Length
        
        required_length = len1 * q3 + len2 * q4 + len3 * q5
        final_obj_value = m.ObjVal - required_length
        
        print(f"FINAL_OBJ_VALUE: {final_obj_value}")
    else:
        # This part should not be reached for a feasible problem.
        print("No optimal solution found.")

if __name__ == "__main__":
    solve()
