import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from CSV file and return as dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def solve_revised_problem():
    """
    Formulates and solves the revised transportation optimization problem.
    """
    # --- Load Data ---
    # Construct the path to the data file relative to the script's location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(script_dir, "data", "general_parameters.csv")
    params = load_general_parameters(data_path)

    # --- Define Sets and Parameters ---
    methods = ['motorcycle', 'small_truck', 'large_truck']
    periods = ['peak', 'offpeak']

    pollution_per_trip = {
        'motorcycle': params['motorcycle_pollution'],
        'small_truck': params['small_truck_pollution'],
        'large_truck': params['large_truck_pollution']
    }

    capacity_per_trip = {
        'motorcycle': params['motorcycle_capacity'],
        'small_truck': params['small_truck_capacity'],
        'large_truck': params['large_truck_capacity']
    }

    demand = {
        'peak': params['demand_peak_units'],
        'offpeak': params['demand_offpeak_units']
    }

    max_motorcycle_trips = int(params['max_motorcycle_trips'])
    max_total_trips = int(params['max_total_trips'])
    
    leasing_capacity_max = params['leasing_capacity']
    leasing_pollution_per_unit = params['leasing_pollution_per_unit']
    leasing_fixed_pollution = params['leasing_fixed_pollution']
    max_leasing_fraction_peak = params['max_leasing_fraction_peak']
    bigM_leasing = params['bigM_leasing']
    epsilon = params['epsilon']

    # --- Create Gurobi Model ---
    model = gp.Model("RevisedTransport")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # Number of trips for each method in each period
    trips = model.addVars(methods, periods, vtype=GRB.INTEGER, name="trips", lb=0)
    
    # Amount of capacity leased in each period
    leased_units = model.addVars(periods, vtype=GRB.CONTINUOUS, name="leased_units", lb=0)
    
    # Binary variable to indicate if a method is used
    use_method = model.addVars(methods, vtype=GRB.BINARY, name="use_method")
    
    # Binary variable to indicate if leasing is used at all
    use_leasing = model.addVar(vtype=GRB.BINARY, name="use_leasing")

    # --- Objective Function: Minimize Total Pollution ---
    owned_pollution = gp.quicksum(trips[m, p] * pollution_per_trip[m] for m in methods for p in periods)
    leasing_variable_pollution = gp.quicksum(leased_units[p] for p in periods) * leasing_pollution_per_unit
    leasing_fixed_cost = use_leasing * leasing_fixed_pollution
    
    model.setObjective(owned_pollution + leasing_variable_pollution + leasing_fixed_cost, GRB.MINIMIZE)

    # --- Constraints ---
    # 1. Demand Fulfillment for each period
    for p in periods:
        model.addConstr(
            gp.quicksum(trips[m, p] * capacity_per_trip[m] for m in methods) + leased_units[p] >= demand[p],
            name=f"demand_{p}"
        )

    # 2. Choose exactly two out of three transportation methods
    model.addConstr(gp.quicksum(use_method[m] for m in methods) == 2, name="choose_two_methods")

    # 3. Link trip variables to method usage (Big-M)
    # A trip can only be made if the corresponding method is chosen.
    # max_total_trips is a valid Big-M here.
    for m in methods:
        model.addConstr(
            gp.quicksum(trips[m, p] for p in periods) <= max_total_trips * use_method[m],
            name=f"link_trips_{m}"
        )

    # 4. Maximum total trips allowed across all methods and periods
    model.addConstr(gp.quicksum(trips[m, p] for m in methods for p in periods) <= max_total_trips, name="max_total_trips")

    # 5. Maximum number of motorcycle trips
    model.addConstr(gp.quicksum(trips['motorcycle', p] for p in periods) <= max_motorcycle_trips, name="max_motorcycle_trips")

    # 6. Leasing fixed cost activation (Big-M)
    total_leased_units = gp.quicksum(leased_units[p] for p in periods)
    model.addConstr(total_leased_units <= bigM_leasing * use_leasing, name="leasing_activation_upper")
    model.addConstr(total_leased_units >= epsilon * use_leasing, name="leasing_activation_lower")

    # 7. Maximum total leasing capacity
    model.addConstr(total_leased_units <= leasing_capacity_max, name="max_leasing_capacity")

    # 8. Maximum fraction of peak demand satisfied by leasing
    model.addConstr(leased_units['peak'] <= max_leasing_fraction_peak * demand['peak'], name="max_leasing_peak_fraction")

    # --- Solve the Model ---
    model.optimize()

    # --- Print Final Objective Value ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # Handle cases where no optimal solution is found
        print(f"FINAL_OBJ_VALUE: inf")

if __name__ == "__main__":
    solve_revised_problem()
