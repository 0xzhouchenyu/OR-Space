import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_production_plan():
    """
    This function formulates and solves the revised factory production planning problem
    as a Mixed-Integer Program (MIP) using Gurobi.
    """
    # --- 1. Data Loading ---

    # Define file paths relative to the script's location
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Handle case where script is run in an interactive environment
        base_dir = os.getcwd()

    data_dir = os.path.join(base_dir, "data")
    table1_path = os.path.join(data_dir, "table_1.csv")
    general_params_path = os.path.join(data_dir, "general_parameters.csv")
    setup_costs_path = os.path.join(data_dir, "setup_costs.csv")

    # Initialize parameter dictionaries
    proc_time = {}  # (equipment, product) -> hours per unit
    capacity = {}   # equipment -> available hours
    cost_rate = {}  # equipment -> cost per machine hour
    raw_cost = {}   # product -> cost per unit
    price = {}      # product -> price per unit
    setup_cost = {} # equipment -> fixed setup cost
    joint_calib_fee = 0

    # Parse table_1.csv for processing times, capacities, costs, and prices
    with open(table1_path, 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            item = row['Equipment'].strip()
            if item == 'Raw_Material_Cost':
                raw_cost = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            elif item == 'Unit_Price':
                price = {'I': float(row['Product_I']), 'II': float(row['Product_II']), 'III': float(row['Product_III'])}
            else:
                for prod, col in [('I', 'Product_I'), ('II', 'Product_II'), ('III', 'Product_III')]:
                    val = row[col].strip()
                    if val != '-':
                        proc_time[(item, prod)] = float(val)
                capacity[item] = float(row['Effective_Machine_Hours'])
                cost_rate[item] = float(row['Processing_Cost_per_Machine_Hour'])

    # Parse setup_costs.csv for fixed costs
    with open(setup_costs_path, 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            setup_cost[row['Equipment']] = float(row['Fixed_Setup_Cost'])

    # Parse general_parameters.csv for the joint calibration fee
    with open(general_params_path, 'r', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['Parameter_Name'] == 'A2_B2_joint_calibration_fee':
                joint_calib_fee = float(row['Value'])

    # Define sets for convenience
    products = ['I', 'II', 'III']
    all_equipment = ['A1', 'A2', 'B1', 'B2', 'B3']
    
    # Define equipment options per product stage
    stage_A_equip = {'I': ['A1', 'A2'], 'II': ['A1', 'A2'], 'III': ['A2']}
    stage_B_equip = {'I': ['B1', 'B2', 'B3'], 'II': ['B1'], 'III': ['B2']}

    # --- 2. Model Formulation ---

    # Create a new Gurobi model
    model = gp.Model("RevisedFactoryProduction")
    model.setParam('OutputFlag', 0)

    # --- 3. Decision Variables ---

    # x[e, p]: continuous variable for the quantity of product p processed on equipment e
    x = model.addVars(proc_time.keys(), name="x", lb=0)

    # y[e]: binary variable, 1 if equipment e is used, 0 otherwise
    y = model.addVars(all_equipment, name="y", vtype=GRB.BINARY)

    # z: binary variable, 1 if both A2 and B2 are used
    z = model.addVar(name="z_A2_B2_joint", vtype=GRB.BINARY)

    # --- 4. Constraints ---

    # Flow Conservation: For each product, total units from stage A must equal total from stage B
    for p in products:
        inflow = gp.quicksum(x[e, p] for e in stage_A_equip[p] if (e, p) in x)
        outflow = gp.quicksum(x[e, p] for e in stage_B_equip[p] if (e, p) in x)
        model.addConstr(inflow == outflow, name=f"flow_conservation_{p}")

    # Capacity and Linking Constraints:
    # If equipment e is used (y[e]=1), its capacity is respected.
    # If not used (y[e]=0), no production can happen on it (time_used <= 0).
    for e in all_equipment:
        time_used = gp.quicksum(proc_time[e, p] * x[e, p] for p in products if (e, p) in x)
        model.addConstr(time_used <= capacity[e] * y[e], name=f"capacity_{e}")

    # Joint Calibration Constraint: z = 1 if and only if y['A2'] = 1 AND y['B2'] = 1
    model.addGenConstrAnd(z, [y['A2'], y['B2']], name="joint_calibration_logic")

    # --- 5. Objective Function ---

    # Helper expression for total production of each product
    total_prod = {p: gp.quicksum(x[e, p] for e in stage_A_equip[p] if (e, p) in x) for p in products}

    # Revenue
    revenue = gp.quicksum(price[p] * total_prod[p] for p in products)

    # Raw Material Cost
    raw_material_cost = gp.quicksum(raw_cost[p] * total_prod[p] for p in products)

    # Processing Cost (variable)
    processing_cost = gp.quicksum(cost_rate[e] * proc_time[e, p] * x[e, p] for (e, p) in x)

    # Fixed Setup Cost
    fixed_setup_cost = gp.quicksum(setup_cost[e] * y[e] for e in all_equipment)

    # Joint Calibration Cost
    joint_calibration_cost = joint_calib_fee * z

    # Total Profit = Revenue - All Costs
    profit = revenue - raw_material_cost - processing_cost - fixed_setup_cost - joint_calibration_cost
    model.setObjective(profit, GRB.MAXIMIZE)

    # --- 6. Solve and Output ---

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # This part should not be reached in a normal run but is good practice
        print("FINAL_OBJ_VALUE: Error - No optimal solution found.")

if __name__ == "__main__":
    solve_revised_production_plan()
