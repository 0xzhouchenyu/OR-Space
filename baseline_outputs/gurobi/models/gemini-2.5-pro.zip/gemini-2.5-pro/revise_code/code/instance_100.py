import gurobipy as gp
from gurobipy import GRB
import os
import csv

# This script solves the revised network optimization problem.
# The goal is to find a simple path from node A to node E, passing through node C,
# that minimizes the total routing cost. The cost of an arc is 100 minus its bandwidth.

# --- 1. Data Loading and Preprocessing ---

# Construct the path to the data file. This handles running the script from the root directory.
try:
    # This works when the script is executed as a file.
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
except NameError:
    # This is a fallback for environments where __file__ is not defined (e.g., interactive notebooks).
    # It assumes the 'data' directory is a subdirectory of the current working directory.
    data_dir = 'data'
filepath = os.path.join(data_dir, 'table_1.csv')

# Read the bandwidth matrix from the CSV file
with open(filepath, 'r') as f:
    reader = csv.reader(f)
    header = next(reader)
    # Strip whitespace from headers to get node names
    nodes = [h.strip() for h in header[1:]]
    
    bandwidth = {}
    for row in reader:
        row_node = row[0].strip()
        for j, val in enumerate(row[1:]):
            col_node = nodes[j]
            bw = int(val.strip())
            bandwidth[(row_node, col_node)] = bw

# Define problem parameters from the business requirement
source = 'A'
intermediate = 'C'
target = 'E'

# Calculate costs and define the set of valid arcs (where bandwidth > 0)
# The routing cost of a direct connection is defined as 100 - bandwidth.
costs = {}
arcs = []
for (i, j), bw in bandwidth.items():
    if bw > 0:
        costs[(i, j)] = 100 - bw
        arcs.append((i, j))

# --- 2. Model Formulation ---
m = gp.Model("minimize_total_routing_cost")
m.setParam('OutputFlag', 0)

# --- 3. Variable Definition ---
# We model the problem as finding two separate paths: A->C and C->E.
# x_ij = 1 if arc (i, j) is in the A -> C path
# y_ij = 1 if arc (i, j) is in the C -> E path
x = m.addVars(arcs, vtype=GRB.BINARY, name="path_AC")
y = m.addVars(arcs, vtype=GRB.BINARY, name="path_CE")

# --- 4. Objective Function ---
# Minimize the total routing cost, which is the sum of costs of all arcs used in both paths.
total_cost = gp.quicksum(costs[i, j] * x[i, j] for i, j in arcs) + \
             gp.quicksum(costs[i, j] * y[i, j] for i, j in arcs)
m.setObjective(total_cost, GRB.MINIMIZE)

# --- 5. Constraints ---
# For each node, we add flow conservation constraints for both paths.
# The convention is: inflow - outflow = demand.
# A source has demand = -1, a sink has demand = 1.
for k in nodes:
    # Path A -> C: A is source, C is sink
    balance_ac = 0
    if k == source:
        balance_ac = -1
    elif k == intermediate:
        balance_ac = 1
    
    m.addConstr(
        x.sum('*', k) - x.sum(k, '*') == balance_ac,
        name=f"flow_ac_{k}"
    )

    # Path C -> E: C is source, E is sink
    balance_ce = 0
    if k == intermediate:
        balance_ce = -1
    elif k == target:
        balance_ce = 1
        
    m.addConstr(
        y.sum('*', k) - y.sum(k, '*') == balance_ce,
        name=f"flow_ce_{k}"
    )

# Disjointness and Simplicity Constraints to enforce a single, non-looping path.
# The A->C path cannot pass through the final target E.
m.addConstr(x.sum('*', target) == 0, name="no_E_in_AC_path")

# The C->E path cannot pass through the original source A.
m.addConstr(y.sum('*', source) == 0, name="no_A_in_CE_path")

# Intermediate nodes (those not A, C, or E) can be used at most once across both paths combined.
# This ensures the two sub-paths are node-disjoint (except at C) and prevents loops through these nodes.
intermediate_nodes_set = [n for n in nodes if n not in {source, intermediate, target}]
for k in intermediate_nodes_set:
    m.addConstr(
        x.sum('*', k) + y.sum('*', k) <= 1,
        name=f"disjoint_{k}"
    )

# --- 6. Solve and Output ---
m.optimize()

if m.status == GRB.OPTIMAL:
    final_obj_value = m.objVal
    # Print the final objective value in the required format
    print(f"FINAL_OBJ_VALUE: {final_obj_value}")
else:
    # This case is unlikely for this problem but is good practice to handle.
    print("No optimal solution found.")
    print("FINAL_OBJ_VALUE: -1")
