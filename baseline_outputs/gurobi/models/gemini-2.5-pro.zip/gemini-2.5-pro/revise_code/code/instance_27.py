import gurobipy as gp
from gurobipy import GRB
import os
import csv

def load_data(data_dir):
    """
    Loads all necessary data from the CSV files in the specified directory.
    """
    # --- Load table_1.csv ---
    filepath_table1 = os.path.join(data_dir, 'table_1.csv')
    equipment = []
    proc_times = {}
    eff_hours = {}
    op_costs = {}
    
    with open(filepath_table1, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            e = row['Equipment'].strip()
            equipment.append(e)
            proc_times[e] = {}
            for p in ['Product_I', 'Product_II', 'Product_III']:
                val = row[p].strip() if row[p] and row[p].strip() else None
                proc_times[e][p] = float(val) if val else None
            eff_hours[e] = float(row['Effective_Machine_Hours'].strip())
            op_costs[e] = float(row['Operating_Costs_Full_Capacity_Yuan'].strip())

    # --- Load general_parameters.csv ---
    filepath_params = os.path.join(data_dir, 'general_parameters.csv')
    raw_costs = {}
    prices = {}
    labor_coeffs = {}
    shared_labor_hours = 0
    b2_activation_fee = 0

    mapping_raw = {
        'raw_material_cost_product_I': 'Product_I',
        'raw_material_cost_product_II': 'Product_II',
        'raw_material_cost_product_III': 'Product_III',
    }
    mapping_price = {
        'unit_price_product_I': 'Product_I',
        'unit_price_product_II': 'Product_II',
        'unit_price_product_III': 'Product_III',
    }

    with open(filepath_params, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            val = float(row['Value'].strip())
            
            if name in mapping_raw:
                raw_costs[mapping_raw[name]] = val
            elif name in mapping_price:
                prices[mapping_price[name]] = val
            elif name.startswith('labor_coeff_'):
                equip_name = name.split('_')[-1]
                labor_coeffs[equip_name] = val
            elif name == 'shared_labor_hours':
                shared_labor_hours = val
            elif name == 'b2_activation_fee':
                b2_activation_fee = val

    return (equipment, proc_times, eff_hours, op_costs, 
            raw_costs, prices, shared_labor_hours, labor_coeffs, b2_activation_fee)


def main():
    """
    Main function to build and solve the optimization model.
    """
    # 1. Setup paths and load data
    # The script is executed from the root, so the path is relative to the script's location.
    # Assuming the script is in the root, data is in 'data/'.
    try:
        # Path for execution from root
        script_dir = os.path.dirname(os.path.abspath(__file__))
        data_dir = os.path.join(script_dir, 'data')
        if not os.path.exists(data_dir):
             # Fallback for local testing if script is in a 'src' folder
             data_dir = os.path.join(script_dir, '..', 'data')
    except NameError:
        # __file__ is not defined in some environments (e.g. interactive)
        data_dir = 'data'


    (equipment, proc_times, eff_hours, op_costs, 
     raw_costs, prices, shared_labor_hours, labor_coeffs, b2_activation_fee) = load_data(data_dir)

    # 2. Define sets
    products = ['Product_I', 'Product_II', 'Product_III']
    A_equip = [e for e in equipment if e.startswith('A')]
    B_equip = [e for e in equipment if e.startswith('B')]
    
    # Create a list of valid (equipment, product) pairs for which processing is possible
    valid_pairs = []
    for e in equipment:
        for p in products:
            if proc_times[e].get(p) is not None:
                valid_pairs.append((e, p))

    # 3. Create Gurobi model
    model = gp.Model("FactoryProductionRevised")
    model.setParam('OutputFlag', 0)

    # 4. Define variables
    # x[e, p]: number of units of product p processed on equipment e
    x = model.addVars(valid_pairs, name="x", lb=0)
    # y_b2: binary variable, 1 if equipment B2 is used, 0 otherwise
    y_b2 = model.addVar(vtype=GRB.BINARY, name="y_b2")

    # 5. Define expressions for clarity
    # Total production of each product (defined by output of process A)
    total_prod = {p: gp.quicksum(x[e, p] for e in A_equip if (e, p) in valid_pairs) for p in products}
    
    # Total machine hours used on each equipment
    machine_hours_used = {e: gp.quicksum(x[e, p] * proc_times[e][p] for p in products if (e, p) in valid_pairs) for e in equipment}

    # 6. Set objective function: Maximize Profit
    # Profit = Revenue - Raw Material Cost - Proportional Operating Cost - Fixed Costs
    revenue = gp.quicksum(prices[p] * total_prod[p] for p in products)
    raw_material_cost = gp.quicksum(raw_costs[p] * total_prod[p] for p in products)
    operating_cost = gp.quicksum(op_costs[e] * (machine_hours_used[e] / eff_hours[e]) for e in equipment)
    
    total_profit = revenue - raw_material_cost - operating_cost - (b2_activation_fee * y_b2)
    model.setObjective(total_profit, GRB.MAXIMIZE)

    # 7. Add constraints
    # Machine capacity constraint: total processing time <= effective machine hours
    model.addConstrs((machine_hours_used[e] <= eff_hours[e] for e in equipment), name="capacity")

    # Flow balance constraint: for each product, total A-processed = total B-processed
    model.addConstrs((
        gp.quicksum(x[e, p] for e in A_equip if (e, p) in valid_pairs) == 
        gp.quicksum(x[e, p] for e in B_equip if (e, p) in valid_pairs)
        for p in products
    ), name="balance")

    # Shared skilled-operator labor constraint
    total_labor_consumed = gp.quicksum(machine_hours_used[e] * labor_coeffs[e] for e in equipment)
    model.addConstr(total_labor_consumed <= shared_labor_hours, name="labor_pool")

    # B2 activation constraint (Big-M)
    # If any time is used on B2, y_b2 must be 1. M = eff_hours['B2']
    model.addConstr(machine_hours_used['B2'] <= eff_hours['B2'] * y_b2, name="b2_activation_link")

    # 8. Solve the model
    model.optimize()
    
    # 9. Print the final objective value as required
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal:.4f}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
