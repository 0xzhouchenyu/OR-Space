import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_general_parameters(filepath):
    """Load general parameters from a key-value CSV file."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if row:
                params[row[0]] = row[1]
    return params

def load_distance_matrix(filepath):
    """Load distance matrix from CSV file.
    
    Returns:
        cities: list of city labels
        dist: 2D list of distances (dist[i][j] = distance from city i to city j)
    """
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        # header: ['City', '1', '2', '3', '4', ...]
        city_labels = header[1:]
        
        dist = []
        for row in reader:
            dist.append([float(x) for x in row[1:]])
    
    return city_labels, dist

def solve_revised_tsp():
    """
    Solves the revised TSP problem which is a Hamiltonian Path problem with
    additional constraints and costs.
    """
    # --- 1. Load Data ---
    # Construct absolute paths to data files
    base_dir = os.path.dirname(os.path.abspath(__file__))
    param_file = os.path.join(base_dir, 'data', 'general_parameters.csv')
    dist_file = os.path.join(base_dir, 'data', 'table_1.csv')

    # Load data from files
    params = load_general_parameters(param_file)
    cities, dist_matrix = load_distance_matrix(dist_file)
    
    # --- 2. Pre-process Data ---
    n = len(cities)
    city_to_idx = {city: i for i, city in enumerate(cities)}

    # Map string parameters to integer indices and values
    start_idx = city_to_idx[params['start_city']]
    end_idx = city_to_idx[params['end_city']]
    prohib_from_idx = city_to_idx[params['prohibited_from']]
    prohib_to_idx = city_to_idx[params['prohibited_to']]
    insp_from_idx = city_to_idx[params['inspection_arc_from']]
    insp_to_idx = city_to_idx[params['inspection_arc_to']]
    inspection_cost = float(params['inspection_stop_cost'])

    # --- 3. Build Gurobi Model ---
    m = gp.Model("RevisedTSP")
    m.setParam('OutputFlag', 0)

    # --- 4. Define Variables ---
    # x[i, j] is 1 if the path goes from city i to city j, 0 otherwise
    x = m.addVars(n, n, vtype=GRB.BINARY, name="x")
    
    # u[i] are auxiliary variables for MTZ subtour elimination
    u = m.addVars(n, lb=1.0, ub=n, vtype=GRB.CONTINUOUS, name="u")

    # --- 5. Define Objective Function ---
    # Base travel cost
    objective_expr = gp.quicksum(dist_matrix[i][j] * x[i, j] for i in range(n) for j in range(n) if i != j)
    # Add conditional inspection cost
    objective_expr += inspection_cost * x[insp_from_idx, insp_to_idx]
    
    m.setObjective(objective_expr, GRB.MINIMIZE)

    # --- 6. Define Constraints ---
    # No travel to self
    m.addConstrs((x[i, i] == 0 for i in range(n)), name="no_self_loops")

    # Degree constraints to form a path visiting all nodes
    # Each node except the end node must have one outgoing arc
    m.addConstrs((x.sum(i, '*') == 1 for i in range(n) if i != end_idx), name="out_degree")
    # The end node has no outgoing arcs
    m.addConstr(x.sum(end_idx, '*') == 0, name="end_out_degree")

    # Each node except the start node must have one incoming arc
    m.addConstrs((x.sum('*', j) == 1 for j in range(n) if j != start_idx), name="in_degree")
    # The start node has no incoming arcs
    m.addConstr(x.sum('*', start_idx) == 0, name="start_in_degree")

    # Prohibited arc constraint
    m.addConstr(x[prohib_from_idx, prohib_to_idx] == 0, name="prohibited_arc")

    # Miller-Tucker-Zemlin (MTZ) subtour elimination constraints
    # This formulation ensures that if x[i,j]=1, then u[j] must be greater than u[i],
    # creating a valid sequence and preventing cycles.
    m.addConstrs((u[i] - u[j] + n * x[i, j] <= n - 1 
                  for i in range(n) for j in range(n) if i != j), name="MTZ")

    # --- 7. Solve Model ---
    m.optimize()

    # --- 8. Output Result ---
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_revised_tsp()
