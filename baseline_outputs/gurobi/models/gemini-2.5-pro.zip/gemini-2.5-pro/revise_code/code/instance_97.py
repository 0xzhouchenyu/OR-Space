import gurobipy as gp
from gurobipy import GRB
import os
import csv

def main():
    """
    Solves the revised blending optimization problem using Gurobi.
    """
    # --- 1. Data Loading ---

    # Get data directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Read table_1.csv for raw material properties
    materials = []
    sulfur_content = {}
    purchase_price = {}

    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Clean up keys and values
            cleaned_row = {k.strip(): v.strip() for k, v in row.items()}
            mat = cleaned_row['Material']
            materials.append(mat)
            sulfur_content[mat] = float(cleaned_row['Sulfur_Content_Percentage'])
            purchase_price[mat] = float(cleaned_row['Purchase_Price_Thousand_Yuan_Per_Ton'])

    # Read general_parameters.csv for all other parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned_row = {k.strip(): v.strip() for k, v in row.items()}
            param_name = cleaned_row['Parameter_Name']
            params[param_name] = float(cleaned_row['Value'])

    # --- 2. Model Formulation ---

    # Define sets
    product_families = ['A', 'B']
    tiers = ['premium', 'standard']
    product_streams = [(f, t) for f in product_families for t in tiers]

    # Map loaded parameters to structured dictionaries for easier access
    max_sulfur = {
        ('A', 'premium'): params['max_sulfur_content_A_premium'],
        ('A', 'standard'): params['max_sulfur_content_A_standard'],
        ('B', 'premium'): params['max_sulfur_content_B_premium'],
        ('B', 'standard'): params['max_sulfur_content_B_standard'],
    }
    selling_price = {
        ('A', 'premium'): params['selling_price_A_premium'],
        ('A', 'standard'): params['selling_price_A_standard'],
        ('B', 'premium'): params['selling_price_B_premium'],
        ('B', 'standard'): params['selling_price_B_standard'],
    }
    market_demand = {
        'A': params['market_demand_A'],
        'B': params['market_demand_B'],
    }
    min_premium_share = {
        'A': params['min_premium_share_A'],
        'B': params['min_premium_share_B'],
    }
    max_premium_share = {
        'A': params['max_premium_share_A'],
        'B': params['max_premium_share_B'],
    }
    max_supply_D = params['max_supply_D']

    # Create Gurobi model
    model = gp.Model("RevisedMixingProblem")
    model.setParam('OutputFlag', 0)

    # Decision variables: x[m, f, t] = tons of material m used in product family f, tier t
    x = model.addVars(materials, product_families, tiers, name="x", lb=0)

    # --- 3. Objective Function: Maximize Profit ---

    # Total amount of each product stream
    total_prod = {(f, t): gp.quicksum(x[m, f, t] for m in materials) for f, t in product_streams}

    # Revenue
    revenue = gp.quicksum(selling_price[f, t] * total_prod[f, t] for f, t in product_streams)

    # Cost
    cost = gp.quicksum(purchase_price[m] * x.sum(m, '*', '*') for m in materials)

    model.setObjective(revenue - cost, GRB.MAXIMIZE)

    # --- 4. Constraints ---

    # Sulfur content constraints
    for f, t in product_streams:
        total_sulfur_in = gp.quicksum(sulfur_content[m] * x[m, f, t] for m in materials)
        model.addConstr(total_sulfur_in <= max_sulfur[f, t] * total_prod[f, t], f"Sulfur_{f}_{t}")

    # Supply limit for material D
    model.addConstr(x.sum('D', '*', '*') <= max_supply_D, "Supply_D")

    # Market demand constraints (at the product family level)
    for f in product_families:
        total_family_prod = total_prod[f, 'premium'] + total_prod[f, 'standard']
        model.addConstr(total_family_prod <= market_demand[f], f"Demand_{f}")

    # Premium share constraints (min/max volume for premium tier)
    for f in product_families:
        premium_prod = total_prod[f, 'premium']
        model.addConstr(premium_prod >= min_premium_share[f], f"Min_Premium_{f}")
        model.addConstr(premium_prod <= max_premium_share[f], f"Max_Premium_{f}")

    # --- 5. Solve and Output ---

    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
