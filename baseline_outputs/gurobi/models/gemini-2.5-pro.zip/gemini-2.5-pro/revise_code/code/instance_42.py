import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_parameters(filepath):
    """Load general parameters from CSV file into a dictionary."""
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'].strip())
            params[name] = value
    return params

def main():
    """
    Formulates and solves the revised steel furnace optimization problem.
    """
    # --- 1. Load Data and Parameters ---
    # Per instructions, the script is run from the root, so the path is relative.
    # The os.path.join is used for cross-platform compatibility.
    data_path = os.path.join("data", "general_parameters.csv")
    params = load_parameters(data_path)

    # General parameters
    a = params['a']  # Time for method 1
    b = params['b']  # Time for method 2
    k = params['k']  # Steel production per batch
    d = params['d']  # Minimum total production

    # Period-specific parameters
    m = {'peak': params['m_peak'], 'offpeak': params['m_offpeak']}
    n = {'peak': params['n_peak'], 'offpeak': params['n_offpeak']}
    c = {'peak': params['c_peak'], 'offpeak': params['c_offpeak']}
    cap = {'peak': params['cap_peak'], 'offpeak': params['cap_offpeak']}
    f = {'peak': params['f_peak'], 'offpeak': params['f_offpeak']}

    # Cooldown rule parameters
    cooldown_threshold = params['offpeak_cooldown_batch_threshold']
    cooldown_fee = params['offpeak_cooldown_fee']

    # --- 2. Model Setup ---
    model = gp.Model("RevisedSteelFurnace")
    model.setParam('OutputFlag', 0)

    # Define sets
    furnaces = [1, 2]
    methods = [1, 2]
    periods = ['peak', 'offpeak']

    # --- 3. Decision Variables ---
    # x_ijp: Number of batches of method j in furnace i during period p
    x = model.addVars(furnaces, methods, periods, vtype=GRB.INTEGER, name="x", lb=0)

    # y_ip: Binary, 1 if furnace i is used in period p
    y = model.addVars(furnaces, periods, vtype=GRB.BINARY, name="y")

    # z_i: Binary, 1 if furnace i exceeds the off-peak batch threshold
    z = model.addVars(furnaces, vtype=GRB.BINARY, name="z")

    # --- 4. Objective Function ---
    # Minimize total cost: variable fuel costs + fixed activation costs + cooldown costs
    variable_cost = gp.quicksum(x[i, 1, p] * m[p] + x[i, 2, p] * n[p] for i in furnaces for p in periods)
    fixed_cost = gp.quicksum(y[i, p] * f[p] for i in furnaces for p in periods)
    cooldown_cost = gp.quicksum(z[i] * cooldown_fee for i in furnaces)

    model.setObjective(variable_cost + fixed_cost + cooldown_cost, GRB.MINIMIZE)

    # --- 5. Constraints ---
    # Time constraint per furnace, per period
    for i in furnaces:
        for p in periods:
            model.addConstr(a * x[i, 1, p] + b * x[i, 2, p] <= c[p], f"Time_Furnace_{i}_{p}")

    # Plant-wide time constraint per period
    for p in periods:
        model.addConstr(gp.quicksum(a * x[i, 1, p] + b * x[i, 2, p] for i in furnaces) <= cap[p], f"Time_Plant_{p}")

    # Minimum production requirement
    model.addConstr(k * x.sum() >= d, "Min_Production")

    # Linking constraints for fixed activation costs (y_ip)
    # If any batches are run (x > 0), the corresponding y must be 1.
    for i in furnaces:
        for p in periods:
            # A reasonably tight M can be calculated. Max batches = c[p] / min_time_per_batch
            M = c[p] / min(a, b)
            model.addConstr(x[i, 1, p] + x[i, 2, p] <= M * y[i, p], f"Link_Activation_{i}_{p}")

    # Linking constraints for cooldown fee (z_i) using indicator constraints
    # z_i = 1 if and only if the number of off-peak batches for furnace i > threshold
    for i in furnaces:
        total_offpeak_batches = x[i, 1, 'offpeak'] + x[i, 2, 'offpeak']
        
        # If z_i is 0, then total_offpeak_batches must be <= threshold
        model.addGenConstrIndicator(z[i], False, total_offpeak_batches <= cooldown_threshold, f"Indicator_z_off_{i}")
        
        # If z_i is 1, then total_offpeak_batches must be >= threshold + 1
        # (since batches are integers, > threshold is equivalent to >= threshold + 1)
        model.addGenConstrIndicator(z[i], True, total_offpeak_batches >= cooldown_threshold + 1, f"Indicator_z_on_{i}")

    # --- 6. Solve and Output ---
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        # This part is for robustness, but the problem should have a solution.
        print(f"FINAL_OBJ_VALUE: Error - Model status is {model.status}")

if __name__ == "__main__":
    main()
