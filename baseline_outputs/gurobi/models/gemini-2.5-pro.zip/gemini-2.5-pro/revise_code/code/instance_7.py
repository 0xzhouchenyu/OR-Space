import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    """
    Models and solves the revised container transportation problem.
    """
    # --- 1. Data Loading ---
    
    # Get the base directory for data files
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Handle case where __file__ is not defined (e.g., interactive environment)
        script_dir = os.getcwd()
        
    data_dir = os.path.join(script_dir, "data")

    def load_csv_data(filepath):
        """Load CSV file and return list of dictionaries."""
        data = []
        with open(filepath, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                data.append(row)
        return data

    # Load general parameters
    params_data = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))
    params = {row['Parameter_Name']: float(row['Value']) for row in params_data}
    cost_per_km = params['cost_per_km']
    adriatic_pool_shortage_trigger = params['adriatic_pool_shortage_trigger']
    adriatic_pool_recovery_fee = params['adriatic_pool_recovery_fee']

    # Load warehouse supply
    warehouses_data = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    warehouses = [row['Warehouse'] for row in warehouses_data]
    supply = {row['Warehouse']: int(row['Empty_Containers']) for row in warehouses_data}

    # Load port demand
    ports_data = load_csv_data(os.path.join(data_dir, 'table_2.csv'))
    ports = [row['Port'] for row in ports_data]
    demand = {row['Port']: int(row['Container_Demand']) for row in ports_data}

    # Load distances
    distance_data = load_csv_data(os.path.join(data_dir, 'table_3.csv'))
    distance = {}
    for row in distance_data:
        wh = row['Warehouse']
        for port in ports:
            distance[(wh, port)] = float(row[port])

    # Load shortage penalty data
    shortage_data_raw = load_csv_data(os.path.join(data_dir, 'shortage_penalty.csv'))
    shortage_costs = {
        row['Port']: {
            'charge': int(row['Shortage_Charge']),
            'grace': int(row['Grace_Containers']),
            'fee': int(row['Recovery_Fee'])
        } for row in shortage_data_raw
    }
    
    adriatic_ports = ['Venice', 'Ancona', 'Bari']

    # --- 2. Model Formulation ---

    # Create a new model
    model = gp.Model("ContainerTransportationRevised")
    model.setParam('OutputFlag', 0)

    # Decision Variables
    # x[w, p]: number of containers from warehouse w to port p
    x = model.addVars(warehouses, ports, vtype=GRB.INTEGER, name="transport", lb=0)
    
    # s[p]: shortage of containers at port p
    s = model.addVars(ports, vtype=GRB.CONTINUOUS, name="shortage", lb=0)
    
    # y[p]: binary, 1 if local recovery desk is opened for port p
    y = model.addVars(ports, vtype=GRB.BINARY, name="local_recovery_open")
    
    # z: binary, 1 if Adriatic regional recovery desk is opened
    z = model.addVar(vtype=GRB.BINARY, name="adriatic_recovery_open")

    # Objective Function: Minimize total costs
    transport_cost = gp.quicksum(x[w, p] * distance[w, p] * cost_per_km for w in warehouses for p in ports)
    per_container_shortage_cost = gp.quicksum(s[p] * shortage_costs[p]['charge'] for p in ports)
    local_recovery_fee_cost = gp.quicksum(y[p] * shortage_costs[p]['fee'] for p in ports)
    regional_recovery_fee_cost = z * adriatic_pool_recovery_fee

    total_cost = transport_cost + per_container_shortage_cost + local_recovery_fee_cost + regional_recovery_fee_cost
    model.setObjective(total_cost, GRB.MINIMIZE)

    # Constraints
    # Supply constraints: cannot ship more than available at each warehouse
    model.addConstrs((gp.quicksum(x[w, p] for p in ports) <= supply[w] for w in warehouses), "supply")

    # Demand balance: incoming containers + shortage = demand
    model.addConstrs((gp.quicksum(x[w, p] for w in warehouses) + s[p] == demand[p] for p in ports), "demand")

    # Local recovery desk trigger (Big-M constraints)
    # If shortage s[p] > grace[p], then y[p] must be 1.
    # s[p] - grace[p] <= M * y[p]
    for p in ports:
        M = demand[p] # A safe upper bound for shortage is the total demand at that port
        model.addConstr(s[p] - shortage_costs[p]['grace'] <= M * y[p], f"local_recovery_trigger_{p}")

    # Adriatic regional recovery desk trigger (Big-M constraint)
    # If sum(shortage in Adriatic ports) > trigger, then z must be 1.
    # sum(s[p]) - trigger <= M * z
    adriatic_shortage_sum = gp.quicksum(s[p] for p in adriatic_ports)
    M_regional = sum(demand[p] for p in adriatic_ports) # Safe upper bound for combined shortage
    model.addConstr(adriatic_shortage_sum - adriatic_pool_shortage_trigger <= M_regional * z, "regional_recovery_trigger")

    # --- 3. Solve and Output ---
    
    # Optimize the model
    model.optimize()

    # Print the final objective value
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
