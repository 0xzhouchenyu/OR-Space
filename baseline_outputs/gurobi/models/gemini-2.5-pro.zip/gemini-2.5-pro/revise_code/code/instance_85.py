import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_production_planning():
    """
    Solves the revised production planning problem using Gurobi.
    """
    # --- 1. Data Loading ---
    # Construct paths relative to the script's location to ensure it runs from any directory.
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        data_dir = os.path.join(base_dir, "data")

        # Load general parameters from general_parameters.csv
        params_path = os.path.join(data_dir, 'general_parameters.csv')
        params = {}
        with open(params_path, 'r', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

        # Load product-specific data from table_1.csv
        table1_path = os.path.join(data_dir, 'table_1.csv')
        products = {}
        with open(table1_path, 'r', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                item = row['Item'].strip()
                products[item] = {
                    'machine_time': float(row['Machine_Time_minutes'].strip()),
                    'craftsman_time': float(row['Craftsman_Time_minutes'].strip())
                }
    except FileNotFoundError as e:
        print(f"Error: Data file not found. {e}")
        return

    # --- 2. Model Setup ---
    m = gp.Model("RevisedProductionPlanning")
    m.setParam('OutputFlag', 0)  # Suppress Gurobi solver output

    # --- 3. Decision Variables ---
    # Production quantities (continuous, as fractional batches are allowed)
    X = m.addVar(name="X", vtype=GRB.CONTINUOUS, lb=0)
    Y = m.addVar(name="Y", vtype=GRB.CONTINUOUS, lb=0)

    # Craftsman hours used (regular and overtime)
    craftsman_reg_hours = m.addVar(name="craftsman_regular_hours", vtype=GRB.CONTINUOUS, lb=0)
    craftsman_ovt_hours = m.addVar(name="craftsman_overtime_hours", vtype=GRB.CONTINUOUS, lb=0)

    # Binary variable to model the one-time QA fee for Product Y
    y_qa_burden_incurred = m.addVar(name="y_qa_burden_incurred", vtype=GRB.BINARY)

    # --- 4. Expressions for Resource Usage ---
    # Total machine hours used (converting minutes to hours)
    machine_hours_used = (products['X']['machine_time'] * X + products['Y']['machine_time'] * Y) / 60.0

    # Total craftsman hours required (converting minutes to hours)
    craftsman_hours_total = (products['X']['craftsman_time'] * X + products['Y']['craftsman_time'] * Y) / 60.0

    # --- 5. Objective Function ---
    # Maximize Profit = Total Revenue - Total Costs
    total_revenue = params['revenue_product_X'] * X + params['revenue_product_Y'] * Y
    
    machine_cost = params['machine_time_cost'] * machine_hours_used
    
    craftsman_cost = (params['craftsman_time_cost'] * craftsman_reg_hours +
                      params['craftsman_overtime_cost'] * craftsman_ovt_hours)
                      
    qa_cost = params['product_Y_QA_fee'] * y_qa_burden_incurred

    profit = total_revenue - machine_cost - craftsman_cost - qa_cost
    
    m.setObjective(profit, GRB.MAXIMIZE)

    # --- 6. Constraints ---
    # Resource availability constraints
    m.addConstr(machine_hours_used <= params['machine_time_available'], "Machine_Time_Limit")
    m.addConstr(craftsman_reg_hours <= params['craftsman_regular_time_available'], "Craftsman_Regular_Limit")
    m.addConstr(craftsman_ovt_hours <= params['craftsman_overtime_available'], "Craftsman_Overtime_Limit")

    # Craftsman time balance: total required time must be met by regular + overtime
    m.addConstr(craftsman_hours_total == craftsman_reg_hours + craftsman_ovt_hours, "Craftsman_Time_Balance")

    # Contractual minimum production for Product X
    m.addConstr(X >= params['min_batches_product_X'], "Min_Production_X")

    # Product Y QA tier constraint using an indicator constraint.
    # This states that if the binary variable `y_qa_burden_incurred` is 0,
    # then the production of Y must be less than or equal to the threshold.
    # If the model chooses Y > threshold, it must set `y_qa_burden_incurred` to 1,
    # which correctly adds the QA fee to the cost in the objective function.
    m.addGenConstrIndicator(y_qa_burden_incurred, 0, Y, GRB.LESS_EQUAL, params['product_Y_QA_threshold'], "Y_QA_Indicator")

    # --- 7. Solve and Output ---
    m.optimize()

    if m.status == GRB.OPTIMAL:
        final_obj_value = m.ObjVal
        print(f"FINAL_OBJ_VALUE: {final_obj_value:.2f}")
    else:
        # This block is for handling non-optimal statuses, though not expected for this problem.
        print("FINAL_OBJ_VALUE: Error - No optimal solution found.")

if __name__ == "__main__":
    solve_revised_production_planning()
