import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    """
    Solves the daily meal planning optimization problem for Mary.
    """
    # --- 1. Load Data and Parameters ---
    
    # Construct absolute paths to data files based on the script's location
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Fallback for environments where __file__ is not defined (e.g., interactive)
        script_dir = os.getcwd()
        
    table_1_path = os.path.join(script_dir, "data", "table_1.csv")
    general_params_path = os.path.join(script_dir, "data", "general_parameters.csv")

    # Load food items from table_1.csv
    items = []
    with open(table_1_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append({
                'name': row['Item'].strip(),
                'protein': float(row['Protein_Content_per_100g']),
                'cost': float(row['Cost_per_100g']),
                'type': row['Type'].strip(),
                'calories': float(row['Calories_per_100g']),
                'sodium': float(row['Sodium_mg_per_100g'])
            })
    num_items = len(items)
    item_indices = range(num_items)
    veg_indices = [i for i in item_indices if items[i]['type'] == 'Vegetable']

    # Load general parameters from general_parameters.csv
    params = {}
    with open(general_params_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'])

    # Assign parameters to variables for clarity
    min_veg_types = int(params['min_vegetable_types'])
    max_budget = params['max_budget']
    total_weight_limit = params['total_weight_limit']
    min_daily_calories = params['min_daily_calories']
    max_daily_calories = params['max_daily_calories']
    max_daily_sodium = params['max_daily_sodium']

    # Derived constants
    max_units = int(total_weight_limit // 100)
    max_meal_units = 3  # 300g per meal / 100g per unit

    # --- 2. Create Gurobi Model ---
    m = gp.Model("daily_meal_plan")
    m.setParam('OutputFlag', 0)

    # --- 3. Define Variables ---

    # Integer variables for units (1 unit = 100g)
    purchase_units = m.addVars(item_indices, vtype=GRB.INTEGER, name="purchase", lb=0)
    lunch_units = m.addVars(item_indices, vtype=GRB.INTEGER, name="lunch", lb=0)
    dinner_units = m.addVars(item_indices, vtype=GRB.INTEGER, name="dinner", lb=0)

    # Binary variables for selection
    select_item = m.addVars(item_indices, vtype=GRB.BINARY, name="select")
    lunch_veg_selected = m.addVars(veg_indices, vtype=GRB.BINARY, name="lunch_veg_sel")
    dinner_veg_selected = m.addVars(veg_indices, vtype=GRB.BINARY, name="dinner_veg_sel")

    # --- 4. Set Objective Function ---
    # Maximize total protein from consumed food (lunch + dinner)
    total_consumed_protein = gp.quicksum(
        items[i]['protein'] * (lunch_units[i] + dinner_units[i]) for i in item_indices
    )
    m.setObjective(total_consumed_protein, GRB.MAXIMIZE)

    # --- 5. Add Constraints ---

    # 1. Total daily budget
    m.addConstr(
        gp.quicksum(items[i]['cost'] * purchase_units[i] for i in item_indices) <= max_budget,
        "budget_constraint"
    )

    # 2. Total daily weight limit
    m.addConstr(
        gp.quicksum(100 * purchase_units[i] for i in item_indices) <= total_weight_limit,
        "total_weight_constraint"
    )

    # Link purchase to meal usage: purchased >= used
    m.addConstrs(
        (purchase_units[i] >= lunch_units[i] + dinner_units[i] for i in item_indices),
        "purchase_usage_link"
    )

    # 4. Per-meal weight balance (exactly 300g per meal)
    m.addConstr(gp.quicksum(lunch_units[i] for i in item_indices) == max_meal_units, "lunch_weight")
    m.addConstr(gp.quicksum(dinner_units[i] for i in item_indices) == max_meal_units, "dinner_weight")

    # 5. Daily calorie intake bounds
    total_calories = gp.quicksum(
        items[i]['calories'] * (lunch_units[i] + dinner_units[i]) for i in item_indices
    )
    m.addConstr(total_calories >= min_daily_calories, "min_calories")
    m.addConstr(total_calories <= max_daily_calories, "max_calories")

    # 6. Daily sodium intake bound
    total_sodium = gp.quicksum(
        items[i]['sodium'] * (lunch_units[i] + dinner_units[i]) for i in item_indices
    )
    m.addConstr(total_sodium <= max_daily_sodium, "max_sodium")

    # 7. Purchase selection linkage (Big-M)
    m.addConstrs(
        (purchase_units[i] <= max_units * select_item[i] for i in item_indices),
        "purchase_select_link"
    )
    m.addConstrs(
        (lunch_units[i] <= max_meal_units * select_item[i] for i in item_indices),
        "lunch_select_link"
    )
    m.addConstrs(
        (dinner_units[i] <= max_meal_units * select_item[i] for i in item_indices),
        "dinner_select_link"
    )

    # 3 & 8. Minimum vegetable types per meal and linkage
    for i in veg_indices:
        m.addConstr(lunch_units[i] >= lunch_veg_selected[i], f"lunch_veg_link_lower_{i}")
        m.addConstr(lunch_units[i] <= max_meal_units * lunch_veg_selected[i], f"lunch_veg_link_upper_{i}")
        m.addConstr(dinner_units[i] >= dinner_veg_selected[i], f"dinner_veg_link_lower_{i}")
        m.addConstr(dinner_units[i] <= max_meal_units * dinner_veg_selected[i], f"dinner_veg_link_upper_{i}")

    m.addConstr(
        gp.quicksum(lunch_veg_selected[i] for i in veg_indices) >= min_veg_types,
        "min_lunch_veg"
    )
    m.addConstr(
        gp.quicksum(dinner_veg_selected[i] for i in veg_indices) >= min_veg_types,
        "min_dinner_veg"
    )

    # --- 6. Solve and Print Output ---
    m.optimize()

    print(f"FINAL_OBJ_VALUE: {m.ObjVal}")

if __name__ == "__main__":
    main()
