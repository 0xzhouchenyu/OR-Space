import os
import csv
import gurobipy as gp
from gurobipy import GRB

def load_csv_data(filepath):
    """Load CSV file and return list of dictionaries."""
    data = []
    with open(filepath, 'r', newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Strip whitespace from keys and values
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k is not None}
            data.append(cleaned)
    return data

def main():
    """
    Main function to set up and solve the Healthy Pet Foods optimization problem.
    """
    # Define the data directory relative to the script's location
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

    # Load data from CSV files
    products_raw = load_csv_data(os.path.join(data_dir, 'table_1.csv'))
    params_raw = load_csv_data(os.path.join(data_dir, 'general_parameters.csv'))

    # Parse general parameters into a dictionary
    params = {row['Parameter_Name']: float(row['Value']) for row in params_raw}

    # Parse product data into a dictionary keyed by product name
    product_data = {}
    for row in products_raw:
        name = row['Product']
        product_data[name] = {
            'price': float(row['Price_per_pack']),
            'grains': float(row['Grains_per_pack']),
            'meat': float(row['Meat_per_pack']),
            'variable_cost': float(row['Variable_cost_per_pack']),
            'capacity': float(row['Production_capacity']) if row['Production_capacity'].strip() else None
        }

    # Extract data for easier access
    m_data = product_data['Meaties']
    y_data = product_data['Yummies']

    # Calculate profit per pack (contribution margin)
    # Profit = Price - Variable Cost - Raw Material Cost
    profit_meaties = m_data['price'] - m_data['variable_cost'] - \
                     (m_data['grains'] * params['price_per_lb_grains'] + m_data['meat'] * params['price_per_lb_meat'])
    profit_yummies = y_data['price'] - y_data['variable_cost'] - \
                     (y_data['grains'] * params['price_per_lb_grains'] + y_data['meat'] * params['price_per_lb_meat'])

    # --- Gurobi Model ---
    model = gp.Model("HealthyPetFoodsRevised")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # Production quantities
    x_meaties = model.addVar(name="Meaties", vtype=GRB.CONTINUOUS, lb=0)
    x_yummies = model.addVar(name="Yummies", vtype=GRB.CONTINUOUS, lb=0)

    # Binary variable for line activation
    y_line_active = model.addVar(name="line_active", vtype=GRB.BINARY)

    # Binary variables for retailer rebate logic
    y_rebate_earned = model.addVar(name="rebate_earned", vtype=GRB.BINARY)
    b_yummies_thresh_met = model.addVar(name="yummies_thresh_met", vtype=GRB.BINARY)
    b_meaties_thresh_met = model.addVar(name="meaties_thresh_met", vtype=GRB.BINARY)

    # --- Objective Function ---
    # Maximize total profit: (Contribution Margin) - (Fixed Costs) + (Rebates)
    objective = (profit_meaties * x_meaties) + (profit_yummies * x_yummies) - \
                (params['line_fixed_cost'] * y_line_active) + \
                (params['retailer_rebate_fixed'] * y_rebate_earned)
    model.setObjective(objective, GRB.MAXIMIZE)

    # --- Constraints ---
    # 1. Raw Material Availability
    model.addConstr(m_data['grains'] * x_meaties + y_data['grains'] * x_yummies <= params['max_grains'], "Grains_Constraint")
    model.addConstr(m_data['meat'] * x_meaties + y_data['meat'] * x_yummies <= params['max_meat'], "Meat_Constraint")

    # 2. Production Capacity for Meaties
    if m_data['capacity'] is not None:
        model.addConstr(x_meaties <= m_data['capacity'], "Meaties_Capacity")

    # 3. Co-packing Line Logic (activated by y_line_active)
    # Total production is zero if line is not active, and capped if it is
    model.addConstr(x_meaties + x_yummies <= params['line_capacity_packs'] * y_line_active, "Line_Capacity")
    # Minimum total production if line is active
    model.addConstr(x_meaties + x_yummies >= params['min_batch_packs'] * y_line_active, "Min_Batch")
    # Minimum Yummies production if line is active
    model.addConstr(x_yummies >= params['min_yummies'] * y_line_active, "Min_Yummies")

    # 4. Retailer Rebate Logic
    # Indicator constraints to link production quantities to binary threshold variables
    # For Yummies threshold
    model.addGenConstrIndicator(b_yummies_thresh_met, True, x_yummies, GRB.GREATER_EQUAL, params['retailer_rebate_yummies_threshold'])
    model.addGenConstrIndicator(b_yummies_thresh_met, False, x_yummies, GRB.LESS_EQUAL, params['retailer_rebate_yummies_threshold'] - 0.001)
    
    # For Meaties threshold
    model.addGenConstrIndicator(b_meaties_thresh_met, True, x_meaties, GRB.GREATER_EQUAL, params['retailer_rebate_min_meaties'])
    model.addGenConstrIndicator(b_meaties_thresh_met, False, x_meaties, GRB.LESS_EQUAL, params['retailer_rebate_min_meaties'] - 0.001)

    # The rebate is earned if and only if both thresholds are met
    model.addConstr(y_rebate_earned == gp.and_(b_yummies_thresh_met, b_meaties_thresh_met), "Rebate_Logic")

    # --- Solve ---
    model.optimize()

    # --- Output ---
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    main()
