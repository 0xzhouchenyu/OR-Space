import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_clothing_production():
    """
    Solves the revised Hongdou Clothing Factory production planning problem.
    """
    # --- Data Loading and Preparation ---
    
    # Define the base directory for data files
    try:
        # This works when the script is executed as a file
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # This is a fallback for environments where __file__ is not defined (e.g., some notebooks)
        base_dir = os.getcwd()
        
    data_dir = os.path.join(base_dir, "data")

    # Read general parameters
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name'].strip()] = float(row['Value'].strip())

    # Read product-specific data
    products = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append({
                'name': row['Product Name'].strip(),
                'labor': float(row['Labor per unit'].strip()),
                'material': float(row['Material per unit'].strip()),
                'price': float(row['Selling Price'].strip()),
                'var_cost': float(row['Variable Cost'].strip())
            })

    # Map product names to parameter keys (e.g., "Shirt" -> "shirts")
    product_name_map = {
        "Shirt": "shirts",
        "Short-sleeve": "short_sleeves",
        "Casual Cloth": "casual_clothes"
    }

    # Consolidate all parameters into the products list
    for p in products:
        param_key = product_name_map[p['name']]
        p['fixed_cost'] = params[f'fixed_cost_{param_key}']
        p['min_batch'] = params[f'min_batch_{param_key}']
        p['max_prod'] = params[f'max_prod_{param_key}']

    # Extract general constraints and multipliers
    available_labor = params['available_labor']
    available_material = params['available_material']
    reg_discount = params['segment_regular_discount']
    promo_discount = params['segment_promo_discount']
    promo_labor_cap = params['segment_promo_labor_cap']
    promo_material_cap = params['segment_promo_material_cap']
    
    product_names = [p['name'] for p in products]

    # --- Model Formulation ---

    # Create a new model
    model = gp.Model("Hongdou_Clothing_Revised")

    # --- Decision Variables ---

    # Production quantities for regular and promotional segments
    # x_reg[p] = quantity of product p for regular segment
    # x_promo[p] = quantity of product p for promotional segment
    x_reg = model.addVars(product_names, vtype=GRB.INTEGER, name="x_reg")
    x_promo = model.addVars(product_names, vtype=GRB.INTEGER, name="x_promo")

    # Binary variables to indicate if a product line is active
    # y[p] = 1 if product p is produced, 0 otherwise
    y = model.addVars(product_names, vtype=GRB.BINARY, name="y")

    # --- Objective Function: Maximize Profit ---

    # Profit = (Revenue from all segments) - (Total Variable Costs) - (Incurred Fixed Costs)
    # Revenue = sum(price * discount * quantity)
    # Variable Cost = sum(var_cost * quantity)
    # Fixed Cost = sum(fixed_cost * y)
    
    unit_profit_reg = {p['name']: (p['price'] * reg_discount) - p['var_cost'] for p in products}
    unit_profit_promo = {p['name']: (p['price'] * promo_discount) - p['var_cost'] for p in products}
    
    total_profit = (
        gp.quicksum(unit_profit_reg[p_name] * x_reg[p_name] for p_name in product_names) +
        gp.quicksum(unit_profit_promo[p_name] * x_promo[p_name] for p_name in product_names) -
        gp.quicksum(p['fixed_cost'] * y[p['name']] for p in products)
    )
    
    model.setObjective(total_profit, GRB.MAXIMIZE)

    # --- Constraints ---

    # Resource constraints (total)
    model.addConstr(
        gp.quicksum(p['labor'] * (x_reg[p['name']] + x_promo[p['name']]) for p in products) <= available_labor,
        "total_labor"
    )
    model.addConstr(
        gp.quicksum(p['material'] * (x_reg[p['name']] + x_promo[p['name']]) for p in products) <= available_material,
        "total_material"
    )

    # Promotional segment resource caps
    model.addConstr(
        gp.quicksum(p['labor'] * x_promo[p['name']] for p in products) <= promo_labor_cap,
        "promo_labor_cap"
    )
    model.addConstr(
        gp.quicksum(p['material'] * x_promo[p['name']] for p in products) <= promo_material_cap,
        "promo_material_cap"
    )

    # Production activation and batch size constraints
    for p in products:
        p_name = p['name']
        total_production = x_reg[p_name] + x_promo[p_name]
        
        # If a product line is active (y=1), production must be >= min_batch
        model.addConstr(
            total_production >= p['min_batch'] * y[p_name],
            f"min_batch_{p_name}"
        )
        
        # If a product line is active (y=1), production must be <= max_prod (Big-M)
        # If a product line is inactive (y=0), production must be 0
        model.addConstr(
            total_production <= p['max_prod'] * y[p_name],
            f"max_prod_{p_name}"
        )

    # --- Solve and Output ---

    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)

    # Optimize the model
    model.optimize()

    # Print the final objective value in the required format
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_clothing_production()
