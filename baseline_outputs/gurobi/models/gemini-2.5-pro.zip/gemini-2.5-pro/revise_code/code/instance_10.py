import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_problem():
    """
    This script formulates and solves the revised supermarket location problem
    using Gurobi based on the provided business requirements and data files.
    """

    # --- Data Loading Functions ---
    def load_coverage_data(data_dir):
        """Load the coverage data from table_1.csv."""
        filepath = os.path.join(data_dir, 'table_1.csv')
        coverage = {}
        areas_in_col1 = []
        
        with open(filepath, 'r', encoding='utf-8-sig') as f:
            reader = csv.reader(f)
            next(reader)  # skip header
            for row in reader:
                if not row or not row[0].strip():
                    continue
                area_code = row[0].strip()
                areas_in_col1.append(area_code)
                covered_raw = ','.join(row[1:])
                covered_areas = {x.strip() for x in covered_raw.split(',') if x.strip()}
                coverage[area_code] = covered_areas
        
        # The set of all areas includes all potential store locations and all covered areas.
        all_areas_set = set(areas_in_col1)
        for covered_set in coverage.values():
            all_areas_set.update(covered_set)

        return sorted(list(all_areas_set)), coverage

    def load_general_parameters(data_dir):
        """Load general parameters from general_parameters.csv."""
        filepath = os.path.join(data_dir, 'general_parameters.csv')
        params = {}
        
        with open(filepath, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                param_name = row['Parameter_Name'].strip()
                value_str = row['Value'].strip()
                try:
                    # Convert numeric values to int
                    params[param_name] = int(value_str)
                except (ValueError, TypeError):
                    params[param_name] = value_str
        
        return params

    # --- Main Script Logic ---
    # Construct path to data directory as per instructions.
    # This assumes the script is run from a directory that contains the 'data' subdirectory.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(script_dir, "data")

    # Load data from CSV files
    areas, coverage = load_coverage_data(data_dir)
    params = load_general_parameters(data_dir)

    # Extract parameters into variables for clarity
    small_cost = params['small_cost']
    large_cost = params['large_cost']
    small_cap_areas = params['small_cap_areas']
    max_large_stores = params['max_large_stores']
    minimum_neighborhood_counters = params['minimum_neighborhood_counters']

    # Create a new Gurobi model
    m = gp.Model("SupermarketChainRevised")
    m.setParam('OutputFlag', 0)

    # --- Decision Variables ---
    # s_j: 1 if a Small-format store is built at location j, 0 otherwise
    s = m.addVars(areas, vtype=GRB.BINARY, name="s")
    # l_j: 1 if a Large-format store is built at location j, 0 otherwise
    l = m.addVars(areas, vtype=GRB.BINARY, name="l")

    # y_ij: 1 if area i is served by a store at location j
    # Create a list of possible (i, j) assignments where j can physically cover i
    possible_assignments = []
    for j in areas:
        for i in coverage.get(j, []):
            possible_assignments.append((i, j))
    
    y = m.addVars(possible_assignments, vtype=GRB.BINARY, name="y")

    # --- Objective Function ---
    # Minimize the total cost of opening all stores
    total_cost = gp.quicksum(small_cost * s[j] for j in areas) + \
                 gp.quicksum(large_cost * l[j] for j in areas)
    m.setObjective(total_cost, GRB.MINIMIZE)

    # --- Constraints ---
    # 1. At most one store (of any type) can be built at a single location.
    m.addConstrs((s[j] + l[j] <= 1 for j in areas), name="one_store_per_loc")

    # 2. Each residential area must be covered by at least one store assignment.
    m.addConstrs((y.sum(i, '*') >= 1 for i in areas), name="coverage")

    # 3. An area i can be assigned to location j only if a store is built at j.
    # This links the y variables to the s and l variables.
    m.addConstrs((y[i, j] <= s[j] + l[j] for i, j in possible_assignments), name="assignment_link")

    # 4. Capacity constraints for stores.
    # The number of areas served by a store at j cannot exceed its capacity.
    # Large stores have no practical capacity limit (use a large number like len(areas)).
    m.addConstrs((y.sum('*', j) <= small_cap_areas * s[j] + len(areas) * l[j] for j in areas), name="capacity")

    # 5. The total number of Large-format stores cannot exceed the maximum allowed.
    m.addConstr(l.sum() <= max_large_stores, name="max_large_stores")

    # 6. The total number of Small-format stores must meet the minimum requirement for neighborhood counters.
    m.addConstr(s.sum() >= minimum_neighborhood_counters, name="min_small_stores")

    # --- Solve and Output ---
    m.optimize()

    # Print the final objective value in the specified format.
    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        # This case should not be reached for a valid problem instance.
        # The output format requires a number, so we handle this defensively.
        print("FINAL_OBJ_VALUE: Error - No optimal solution found")

if __name__ == "__main__":
    solve_revised_problem()
