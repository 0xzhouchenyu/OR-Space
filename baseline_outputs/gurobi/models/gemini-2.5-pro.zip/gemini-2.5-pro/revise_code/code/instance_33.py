import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_inheritance():
    """
    Formulates and solves the revised inheritance splitting problem.
    """
    # --- Data Loading ---

    # Get the directory of the current script to build absolute paths
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Handle case where __file__ is not defined (e.g., interactive interpreter)
        script_dir = os.getcwd()

    data_dir = os.path.join(script_dir, "data")

    # Load general parameters from general_parameters.csv
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            param_name = row['Parameter_Name']
            try:
                # Convert to float, which handles ints and floats
                value = float(row['Value'])
            except (ValueError, TypeError):
                # Keep as string if conversion fails (e.g., for conditions)
                value = row['Value']
            params[param_name] = value

    # Load item data from table_1.csv
    items = []
    values = []
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append(row['Item'].strip())
            values.append(int(row['Value'].strip()))

    # --- Data Preprocessing ---

    n = len(items)
    total_value = sum(values)

    # Identify indices for different item categories based on problem description
    immediate_indices = []
    diamond_indices = []
    high_value_indices = []
    jr_indices = []

    total_immediate_value = 0

    for i, item in enumerate(items):
        # Diamonds are considered "deferred" transfers
        if 'Diamond' in item:
            diamond_indices.append(i)
        else:
            immediate_indices.append(i)
            total_immediate_value += values[i]

        # Identify high-value items based on the threshold
        if values[i] > params['high_value_threshold']:
            high_value_indices.append(i)

        # Identify Jack Russell dogs for the separation constraint
        if 'Jack Russell' in item:
            jr_indices.append(i)

    # --- Model Formulation ---

    # Create the optimization model
    model = gp.Model("RevisedInheritance")
    model.setParam('OutputFlag', 0)

    # --- Decision Variables ---

    # x[i] = 1 if item i goes to son 1, 0 if to son 2
    x = model.addVars(n, vtype=GRB.BINARY, name="x")

    # Auxiliary variables to model absolute differences for the objective
    diff_immediate = model.addVar(name="diff_immediate", lb=0)
    diff_total = model.addVar(name="diff_total", lb=0)

    # --- Objective Function ---

    # Get weights from parameters
    immediate_tax_weight = params['immediate_tax_weight']
    total_tax_weight = params['total_tax_weight']

    # Set objective to minimize the weighted sum of imbalances
    model.setObjective(
        immediate_tax_weight * diff_immediate + total_tax_weight * diff_total,
        GRB.MINIMIZE
    )

    # --- Constraints ---

    # Define value expressions for son 1
    value_son1_total = gp.quicksum(values[i] * x[i] for i in range(n))
    value_son1_immediate = gp.quicksum(values[i] * x[i] for i in immediate_indices)

    # Constraints to linearize the absolute value for total value difference
    # diff_total >= |2 * value_son1_total - total_value|
    model.addConstr(diff_total >= 2 * value_son1_total - total_value, "total_diff_pos")
    model.addConstr(diff_total >= total_value - 2 * value_son1_total, "total_diff_neg")

    # Constraints to linearize the absolute value for immediate value difference
    # diff_immediate >= |2 * value_son1_immediate - total_immediate_value|
    model.addConstr(diff_immediate >= 2 * value_son1_immediate - total_immediate_value, "immediate_diff_pos")
    model.addConstr(diff_immediate >= total_immediate_value - 2 * value_son1_immediate, "immediate_diff_neg")

    # Jack Russell racing dogs must not be separated
    if len(jr_indices) == 2:
        model.addConstr(x[jr_indices[0]] == x[jr_indices[1]], "jack_russell_together")

    # Son 1 must receive at least son1_min_share of the total value
    model.addConstr(value_son1_total >= params['son1_min_share'] * total_value, "son1_min_share")

    # Maximum number of high-value items per son
    max_hv_items = params['max_high_value_items_per_son']
    num_hv_items = len(high_value_indices)
    hv_items_son1 = gp.quicksum(x[i] for i in high_value_indices)

    # Son 1 high-value item limit
    model.addConstr(hv_items_son1 <= max_hv_items, "max_hv_son1")
    # Son 2 high-value item limit (sum for son 2 is num_hv_items - hv_items_son1)
    model.addConstr(hv_items_son1 >= num_hv_items - max_hv_items, "max_hv_son2")

    # Maximum number of deferred diamond items per son
    max_diamonds = params['deferred_diamonds_per_son']
    num_diamonds = len(diamond_indices)
    diamonds_son1 = gp.quicksum(x[i] for i in diamond_indices)

    # Son 1 diamond limit
    model.addConstr(diamonds_son1 <= max_diamonds, "max_diamonds_son1")
    # Son 2 diamond limit (sum for son 2 is num_diamonds - diamonds_son1)
    model.addConstr(diamonds_son1 >= num_diamonds - max_diamonds, "max_diamonds_son2")

    # --- Solve and Output ---

    # Solve the model
    model.optimize()

    # Print the final objective value in the required format
    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found or an error occurred.")
        print(f"Model status: {model.status}")

if __name__ == "__main__":
    solve_inheritance()
