import gurobipy as gp
from gurobipy import GRB
import pandas as pd
import os

def solve():
    """
    Solves the revised Carelland GDP maximization problem.
    """
    # --- 1. Load Data ---
    # Path is constructed relative to the script's location, as per instructions.
    # Assumes script is in the root directory, and data is in a 'data' subdirectory.
    try:
        csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "general_parameters.csv")
        df = pd.read_csv(csv_path)
    except FileNotFoundError:
        # Fallback for cases where the execution context is different, e.g., running from a parent directory.
        csv_path = os.path.join("data", "general_parameters.csv")
        df = pd.read_csv(csv_path)


    params = dict(zip(df['Parameter_Name'], df['Value']))
    commodities = ['steel', 'engine', 'electronics', 'plastic']

    # --- 2. Create Model ---
    model = gp.Model("Maximize_GDP_Revised")

    # --- 3. Define Decision Variables ---
    # x[c]: Domestic production of commodity c
    x = model.addVars(commodities, name="x", lb=0.0)

    # y[c]: Imported units of finished commodity c
    y = model.addVars(commodities, name="y", lb=0.0)

    # z[c]: Exported units of commodity c
    z = model.addVars(commodities, name="z", lb=0.0)

    # L_overtime: Amount of overtime labor used (person-months)
    L_overtime = model.addVar(name="L_overtime", lb=0.0)

    # --- 4. Set Objective Function ---
    # GDP = Export Revenue - (Production Import Costs + Commodity Import Costs + Overtime Labor Costs)

    export_revenue = gp.quicksum(z[c] * params[f"{c}_price"] for c in commodities)

    production_import_costs = gp.quicksum(
        x[c] * params.get(f"{c}_import_cost", 0.0) for c in commodities
    )

    commodity_import_costs = gp.quicksum(
        y[c] * params[f"{c}_price"] * params['import_premium_ratio'] for c in commodities
    )

    overtime_labor_cost = L_overtime * params['overtime_wage']

    objective = export_revenue - production_import_costs - commodity_import_costs - overtime_labor_cost
    model.setObjective(objective, GRB.MAXIMIZE)

    # --- 5. Add Constraints ---

    # a. Commodity Balance Constraint: Supply (Production + Imports) = Demand (Internal Consumption + Exports)
    for c in commodities:
        internal_consumption = gp.quicksum(
            x[c_prime] * params.get(f"{c_prime}_{c}_requirement", 0.0)
            for c_prime in commodities
        )
        model.addConstr(
            x[c] + y[c] == internal_consumption + z[c],
            name=f"Balance_{c}"
        )

    # b. Labor Constraint: Total labor used <= Regular labor + Overtime labor
    total_labor_used = gp.quicksum(
        x[c] * params.get(f"{c}_labor_requirement", 0.0) for c in commodities
    )
    model.addConstr(
        total_labor_used <= params['labor_force'] + L_overtime,
        name="Labor_Limit"
    )

    # c. Overtime Labor Capacity
    model.addConstr(L_overtime <= params['overtime_cap'], name="Overtime_Cap")

    # d. Production Limits (retaining logic from original heuristic for robustness)
    for c in commodities:
        for suffix in ['_production_limit', '_limit', '_capacity']:
            key = f"{c}{suffix}"
            if key in params:
                model.addConstr(x[c] <= params[key], name=f"Production_Limit_{c}")
                break  # Assume only one limit type per commodity

    # e. Import Quotas
    for c in commodities:
        model.addConstr(y[c] <= params['import_quota'], name=f"Import_Quota_{c}")


    # --- 6. Solve the Model ---
    model.setParam('OutputFlag', 0)
    model.optimize()

    # --- 7. Return Results ---
    if model.status == GRB.OPTIMAL:
        return model.ObjVal
    else:
        return None

if __name__ == '__main__':
    optimal_value = solve()
    if optimal_value is not None:
        # The final output must be in this exact format
        print(f"FINAL_OBJ_VALUE: {optimal_value}")
    else:
        print("FINAL_OBJ_VALUE: None")
