import os
import csv
import gurobipy as gp
from gurobipy import GRB

def main():
    """
    Main function to set up and solve the revised optimization problem.
    """
    # --- 1. Data Loading ---
    # The script is executed from the root, so data is in the 'data' subdirectory.
    # Using os.path.dirname(__file__) makes the path robust.
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        # Fallback for interactive environments
        base_dir = os.getcwd()

    data_dir = os.path.join(base_dir, 'data')

    # Read general parameters into a dictionary
    params = {}
    with open(os.path.join(data_dir, 'general_parameters.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[row['Parameter_Name']] = float(row['Value'])

    # Read product-specific data into a dictionary keyed by product name
    products_data = {}
    with open(os.path.join(data_dir, 'table_1.csv'), 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            product_name = row.pop('Product')
            products_data[product_name] = {k: float(v) for k, v in row.items()}
    
    product_names = list(products_data.keys())

    # --- 2. Model Formulation ---
    m = gp.Model("RevisedProductionOptimization")
    m.setParam('OutputFlag', 0)

    # --- 3. Decision Variables ---
    # x[p]: number of units of product p to produce (integer)
    x = m.addVars(product_names, vtype=GRB.INTEGER, name="x", lb=0)

    # y[p]: binary variable, 1 if product p is produced, 0 otherwise
    y = m.addVars(product_names, vtype=GRB.BINARY, name="y")

    # z_overtime: total overtime hours used (continuous)
    z_overtime = m.addVar(vtype=GRB.CONTINUOUS, name="z_overtime", lb=0)

    # w_overtime_review: binary, 1 if overtime exceeds review threshold
    w_overtime_review = m.addVar(vtype=GRB.BINARY, name="w_overtime_review")

    # w_line_audit: binary, 1 if production of A exceeds line audit threshold
    w_line_audit = m.addVar(vtype=GRB.BINARY, name="w_line_audit")

    # --- 4. Objective Function ---
    # Maximize: Gross Profit - Setup Costs - Overtime Costs - Fixed Fees
    gross_profit = gp.quicksum(products_data[p]['Profit_yuan'] * x[p] for p in product_names)
    
    setup_costs = gp.quicksum(products_data[p]['Setup_Cost_yuan'] * y[p] for p in product_names)
    
    overtime_variable_cost = params['overtime_pay'] * z_overtime
    
    overtime_fixed_cost = params['overtime_review_fee'] * w_overtime_review
    
    line_audit_cost = params['product_A_line_audit_fee'] * w_line_audit

    total_costs = setup_costs + overtime_variable_cost + overtime_fixed_cost + line_audit_cost
    
    m.setObjective(gross_profit - total_costs, GRB.MAXIMIZE)

    # --- 5. Constraints ---
    # Resource Constraints
    m.addConstr(
        gp.quicksum(products_data[p]['Steel_Required_kg'] * x[p] for p in product_names) <= params['available_steel'],
        "Steel_Constraint"
    )
    m.addConstr(
        gp.quicksum(products_data[p]['Aluminum_Required_kg'] * x[p] for p in product_names) <= params['available_aluminum'],
        "Aluminum_Constraint"
    )

    # Labor and Overtime Constraints
    total_labor_required = gp.quicksum(products_data[p]['Labor_Required_hours'] * x[p] for p in product_names)
    m.addConstr(total_labor_required <= params['available_labor'] + z_overtime, "Labor_Usage")
    m.addConstr(z_overtime <= params['max_overtime'], "Max_Overtime")

    # Indicator Constraints for Setup Costs (if x[p] > 0, then y[p] = 1)
    for p in product_names:
        m.addGenConstrIndicator(y[p], 1, x[p], GRB.GREATER_EQUAL, 1.0, f"Indicator_Setup_On_{p}")
        m.addGenConstrIndicator(y[p], 0, x[p], GRB.EQUAL, 0.0, f"Indicator_Setup_Off_{p}")

    # Indicator Constraints for Overtime Review Fee (if z_overtime > threshold, then w_overtime_review = 1)
    overtime_threshold = params['overtime_review_threshold']
    # Use a small epsilon for strict inequality on a continuous variable
    m.addGenConstrIndicator(w_overtime_review, 1, z_overtime, GRB.GREATER_EQUAL, overtime_threshold + 1e-6, "Indicator_OvertimeReview_On")
    m.addGenConstrIndicator(w_overtime_review, 0, z_overtime, GRB.LESS_EQUAL, overtime_threshold, "Indicator_OvertimeReview_Off")

    # Indicator Constraints for Product A Line Audit Fee (if x['A'] > threshold, then w_line_audit = 1)
    audit_threshold = params['product_A_line_audit_threshold']
    # Since x['A'] is integer, x['A'] > 29 is equivalent to x['A'] >= 30
    m.addGenConstrIndicator(w_line_audit, 1, x['A'], GRB.GREATER_EQUAL, audit_threshold + 1, "Indicator_LineAudit_On")
    m.addGenConstrIndicator(w_line_audit, 0, x['A'], GRB.LESS_EQUAL, audit_threshold, "Indicator_LineAudit_Off")

    # --- 6. Solve and Output ---
    m.optimize()

    if m.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {m.ObjVal}")
    else:
        # This case should not be reached with the given data, but is good practice.
        print("FINAL_OBJ_VALUE: Infeasible or Unbounded")

if __name__ == "__main__":
    main()
