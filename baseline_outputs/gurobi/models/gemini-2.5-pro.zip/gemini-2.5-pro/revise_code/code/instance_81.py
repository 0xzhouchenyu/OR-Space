import gurobipy as gp
from gurobipy import GRB
import os
import csv
import sys

def load_car_data(data_dir):
    """Loads car data from table_1.csv."""
    filepath = os.path.join(data_dir, 'table_1.csv')
    cars = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            i = int(row['i'])
            length = float(row['lambda_i'])
            cars[i] = length
    return cars

def load_parameters(data_dir):
    """Loads general parameters from general_parameters.csv."""
    filepath = os.path.join(data_dir, 'general_parameters.csv')
    params = {}
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row['Parameter_Name'].strip()
            value = float(row['Value'])
            params[name] = value
    return params

def main():
    """
    Solves the revised Danzig Street parking problem.
    """
    # Determine the base directory and data directory
    # The script is executed from the workspace root.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")

    # Load data using the provided utility functions
    cars = load_car_data(data_dir)
    params = load_parameters(data_dir)

    # Extract parameters from loaded data
    max_length_one_side = params['max_length_one_side']
    car_lengths = list(cars.values())
    total_car_length = sum(car_lengths)

    # --- Model Formulation ---
    # Based on the revision, all cars must park on a single designated side.
    # The other side remains clear for resident and emergency access.
    # The objective is to "minimize the total length of the street occupied".
    # This is interpreted as minimizing the maximum length of the two sides.
    # With one side forced to be empty (length 0), the objective becomes
    # minimizing the length of the single occupied side.
    # Since all cars are to be parked, this length is fixed at the sum of all car lengths.
    # The problem is to find this value, subject to the capacity constraint of the side.

    # Create a new Gurobi model
    model = gp.Model("RevisedDanzigParking")

    # Suppress Gurobi output
    model.setParam('OutputFlag', 0)

    # Decision Variable:
    # 'occupied_length' represents the length of the street side used for parking.
    occupied_length = model.addVar(name="occupied_length", vtype=GRB.CONTINUOUS, lb=0)

    # Objective Function:
    # Minimize the length of the occupied side.
    model.setObjective(occupied_length, GRB.MINIMIZE)

    # Constraints:
    # 1. The occupied length must be at least the sum of all car lengths,
    #    as the problem implies all party cars are to be parked.
    model.addConstr(occupied_length >= total_car_length, "all_cars_must_park")

    # 2. The occupied length cannot exceed the maximum allowed length for the single usable side.
    #    This constraint ensures the solution is feasible.
    model.addConstr(occupied_length <= max_length_one_side, "side_capacity_limit")

    # Optimize the model
    model.optimize()

    # Output the final objective value
    if model.status == GRB.OPTIMAL:
        final_obj_value = model.getObjective().getValue()
        print(f"FINAL_OBJ_VALUE: {final_obj_value}")
    elif model.status == GRB.INFEASIBLE:
        # This would happen if total_car_length > max_length_one_side
        sys.stderr.write("Error: Problem is infeasible. Total car length exceeds the maximum allowed length for one side.\n")
        sys.stderr.write(f"Total Car Length: {total_car_length}, Max Side Length: {max_length_one_side}\n")
    else:
        sys.stderr.write(f"Error: Optimization ended with status {model.status}\n")

if __name__ == "__main__":
    main()
