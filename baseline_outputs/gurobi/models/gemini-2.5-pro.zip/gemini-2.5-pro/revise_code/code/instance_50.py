import os
import csv
import gurobipy as gp
from gurobipy import GRB

def solve_revised_problem():
    """
    Solves the revised inventory optimization problem using Gurobi.
    """
    # --- 1. Data Loading ---
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        data_dir = os.path.join(base_dir, "data")

        # Load general parameters
        params = {}
        with open(os.path.join(data_dir, 'general_parameters.csv'), 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                params[row['Parameter_Name']] = float(row['Value'])

        warehouse_capacity = params['warehouse_capacity']
        initial_stock = params['initial_stock']
        fixed_order_cost = params['fixed_order_cost']
        august_bulk_order_threshold = params['august_bulk_order_threshold']
        august_bulk_receiving_fee = params['august_bulk_receiving_fee']

        # Load monthly data
        months = []
        buy_price = {}
        sell_price = {}
        with open(os.path.join(data_dir, 'table_1.csv'), 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                m = int(row['Month'])
                months.append(m)
                buy_price[m] = float(row['Buy'])
                sell_price[m] = float(row['Sell'])
        
        # Sort months to ensure correct time sequence
        months.sort()

    except FileNotFoundError as e:
        print(f"Error loading data file: {e}")
        return

    # --- 2. Model Formulation ---
    model = gp.Model("MaxRevenueRevised")
    model.setParam('OutputFlag', 0)

    # --- 3. Decision Variables ---
    # Continuous variables for quantities
    buy = model.addVars(months, name="buy", lb=0)
    sell = model.addVars(months, name="sell", lb=0)
    stock = model.addVars(months, name="stock", lb=0, ub=warehouse_capacity)

    # Binary variables for fixed costs
    is_buying = model.addVars(months, name="is_buying", vtype=GRB.BINARY)
    august_bulk_buy = model.addVar(name="august_bulk_buy", vtype=GRB.BINARY)

    # --- 4. Objective Function ---
    # Maximize: (Revenue from sales - Cost of purchases) - Fixed costs
    
    variable_profit = gp.quicksum(
        sell_price[m] * sell[m] - buy_price[m] * buy[m] for m in months
    )
    
    total_fixed_order_cost = gp.quicksum(
        fixed_order_cost * is_buying[m] for m in months
    )
    
    august_special_fee = august_bulk_receiving_fee * august_bulk_buy
    
    model.setObjective(
        variable_profit - total_fixed_order_cost - august_special_fee,
        GRB.MAXIMIZE
    )

    # --- 5. Constraints ---
    for i, m in enumerate(months):
        # Determine previous month's stock
        if i == 0:
            prev_stock = initial_stock
        else:
            prev_m = months[i-1]
            prev_stock = stock[prev_m]

        # a) Stock balance constraint: stock_end = stock_start + buy - sell
        model.addConstr(
            stock[m] == prev_stock + buy[m] - sell[m],
            name=f"balance_{m}"
        )

        # b) Warehouse capacity after buying: stock_start + buy <= capacity
        model.addConstr(
            prev_stock + buy[m] <= warehouse_capacity,
            name=f"warehouse_after_buy_{m}"
        )
        
        # c) Link `buy` quantity to `is_buying` binary for fixed cost
        # Big-M: M can be set to warehouse_capacity, as you can't buy more than that.
        M_buy = warehouse_capacity
        model.addConstr(
            buy[m] <= M_buy * is_buying[m],
            name=f"link_buy_{m}"
        )

    # d) August special receiving fee constraint
    # If buy[8] > threshold, the binary variable must be 1.
    # Big-M: M can be the max possible purchase over the threshold.
    august_month = 8
    if august_month in months:
        M_august = warehouse_capacity - august_bulk_order_threshold
        model.addConstr(
            buy[august_month] <= august_bulk_order_threshold + M_august * august_bulk_buy,
            name="august_bulk_limit"
        )

    # --- 6. Solve and Output ---
    model.optimize()

    if model.status == GRB.OPTIMAL:
        print(f"FINAL_OBJ_VALUE: {model.ObjVal}")
    else:
        print("No optimal solution found.")

if __name__ == "__main__":
    solve_revised_problem()
