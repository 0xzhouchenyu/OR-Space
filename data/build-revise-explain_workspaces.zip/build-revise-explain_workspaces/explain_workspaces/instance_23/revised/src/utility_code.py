# Utility functions for clothing production optimization
