# Utility functions (not needed for this problem)
