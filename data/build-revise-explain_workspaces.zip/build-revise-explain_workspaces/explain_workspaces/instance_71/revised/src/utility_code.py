# Utility functions for the factory assignment problem
